# Claim catalog

- [Rules 1–73](catalog/0001.md); scope preview: `tests/test_utils.py`
- [Rules 74–146](catalog/0002.md); scope preview: `tests/test_context.py`
- [Rules 147–218](catalog/0003.md); scope preview: `tests/test_context.py`
- [Rules 219–291](catalog/0004.md); scope preview: `src/click/types.py`
- [Rules 292–363](catalog/0005.md); scope preview: `src/click/types.py`
- [Rules 364–436](catalog/0006.md); scope preview: `src/click/shell_completion.py`
- [Rules 437–478](catalog/0007.md); scope preview: `examples/aliases/aliases.py`
