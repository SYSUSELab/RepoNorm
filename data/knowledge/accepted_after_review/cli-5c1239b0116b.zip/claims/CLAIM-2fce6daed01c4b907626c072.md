# Rule details

- **Rule:** Tests for variadic Click arguments must declare the nargs=-1 argument before any fixed single arguments, because variadic arguments must precede fixed arguments in declaration order.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** when adding or modifying tests that declare a Click command with a variadic (nargs=-1) argument alongside fixed arguments
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_arguments.py:332-355`
