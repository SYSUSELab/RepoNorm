# Rule details

- **Rule:**
  ```text
  ShellComplete.complete must call get_completion_args, then get_completions, format each completion, and join results with newlines, defining the shell completion output protocol and its extension hooks.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** When modifying ShellComplete.complete's pipeline or output joining.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/shell_completion.py:285-295`
