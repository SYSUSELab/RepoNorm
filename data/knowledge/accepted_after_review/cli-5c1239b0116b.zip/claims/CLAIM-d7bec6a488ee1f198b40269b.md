# Rule details

- **Rule:**
  ```text
  The tox env_run_base environment builds a wheel package.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
package = "wheel"

```

- **Sources:**
  - `pyproject.toml:155`
