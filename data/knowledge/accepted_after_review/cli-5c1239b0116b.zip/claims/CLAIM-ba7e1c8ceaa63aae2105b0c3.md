# Rule details

- **Rule:**
  ```text
  Tests that verify progressbar behavior must preserve the observed custom item display and finished-state loop behavior when using item_show_func.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_termui.py that cover progressbar item display or finished-state behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_termui.py:311-328`
