# Rule details

- **Rule:**
  ```text
  CompositeParamType must set is_composite = True to mark the base class for parameter types composed of multiple values.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When adding or modifying composite parameter types or their base class marker.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:163-168`
