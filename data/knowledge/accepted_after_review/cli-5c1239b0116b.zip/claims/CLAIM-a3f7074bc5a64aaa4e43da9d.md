# Rule details

- **Rule:**
  ```text
  Tests that verify progressbar ETA formatting must preserve the exact format_eta outputs including zero-padded HH:MM:SS, day-prefixed output for very large ETAs ('1157407d 09:46:39'), and empty string when eta is None.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying or adding tests for progressbar ETA formatting.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_termui.py:109-123`
