# Rule details

- **Rule:**
  ```text
  The completion example's ls command must define a --dir option typed as click.Path(file_okay=False) to constrain completion to directories.
  ```
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** when modifying or extending the ls command in the completion example
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The ls command defines a --dir option typed as click.Path(file_okay=False), constraining completion to directories.
```

- **Sources:**
  - `examples/completion/completion.py:14-15`
