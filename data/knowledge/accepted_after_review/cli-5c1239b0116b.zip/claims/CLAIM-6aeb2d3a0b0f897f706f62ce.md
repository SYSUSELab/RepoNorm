# Rule details

- **Rule:**
  ```text
  Tests for hidden-input confirmation must define a password option with hide_input=True and confirmation_prompt, exercising hidden-input confirmation behavior.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** when adding or modifying tests for hidden-input confirmation behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_termui.py:449-475`
