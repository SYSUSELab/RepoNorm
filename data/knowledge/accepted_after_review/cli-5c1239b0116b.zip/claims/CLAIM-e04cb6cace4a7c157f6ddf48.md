# Rule details

- **Rule:** The aliases example's pull command must be a minimal command shape with a docstring and echo output.
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when adding or modifying a minimal command in the aliases example
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/aliases/aliases.py:107-110`
