# Rule details

- **Rule:**
  ```text
  Tests that verify open_file behavior must preserve the observed handling of pathlib.Path representing '-' for stdin/stdout.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_utils.py that cover open_file with pathlib.Path representing '-'.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:493-506`
