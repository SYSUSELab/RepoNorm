# Rule details

- **Rule:** Tests that verify choice argument behavior must preserve the observed handling of non-None values and the current unsupported status of the literal 'none'.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_basic.py that cover choice argument value handling.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_basic.py:467-482`
