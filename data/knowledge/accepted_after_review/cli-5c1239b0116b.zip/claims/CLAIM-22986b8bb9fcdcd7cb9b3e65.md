# Rule details

- **Rule:**
  ```text
  When modifying get_binary_stdin, it must continue to raise RuntimeError when no binary reader can be determined for sys.stdin, making binary stdin availability a hard precondition rather than returning None.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing get_binary_stdin or binary stdin detection.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
get_binary_stdin raises RuntimeError when _find_binary_reader returns None, preserving the hard precondition rather than returning None.
```

- **Sources:**
  - `src/click/_compat.py:316-320`
