# Rule details

- **Rule:**
  ```text
  HelpFormatter.write_paragraph must only emit a newline when the buffer is non-empty, preventing a leading blank line in formatted output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  when modifying HelpFormatter.write_paragraph or the paragraph formatting logic
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
HelpFormatter.write_paragraph guards on self.buffer before writing a newline, preserving the non-empty-buffer invariant that prevents a leading blank line.
```

- **Sources:**
  - `src/click/formatting.py:189-192`
