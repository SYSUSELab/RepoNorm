# Rule details

- **Rule:**
  ```text
  Tests for add_completion_class must assert that using it as a decorator registers the new shell immediately in click.shell_completion._available_shells and that the registered value is the class itself.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying tests for add_completion_class decorator registration
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test asserts that using add_completion_class as a decorator registers the new shell immediately in _available_shells with the class as the value.
```

- **Sources:**
  - `tests/test_shell_completion.py:437-448`
