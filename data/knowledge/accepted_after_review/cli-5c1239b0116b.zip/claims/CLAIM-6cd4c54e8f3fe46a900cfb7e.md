# Rule details

- **Rule:**
  ```text
  Tests for click.Command subclasses must assert that Command subclasses can override the context class used during invocation via context_class.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** When adding or modifying tests for click.Command subclass context class overrides.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_custom_classes.py:4-17`
