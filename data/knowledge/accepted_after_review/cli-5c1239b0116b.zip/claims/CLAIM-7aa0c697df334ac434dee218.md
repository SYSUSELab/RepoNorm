# Rule details

- **Rule:**
  ```text
  _OptionParser is deprecated since 8.2 and slated for removal in Click 9.0, marking an internal API compatibility boundary for contributors.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** When modifying or depending on the internal option parser class.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/parser.py:222-237`
