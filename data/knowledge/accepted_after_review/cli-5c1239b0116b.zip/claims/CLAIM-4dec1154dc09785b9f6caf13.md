# Rule details

- **Rule:** The create-release job depends on the build job and runs on ubuntu-latest with contents: write permission.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  create-release:
    needs: [build]
    runs-on: ubuntu-latest
    permissions:
      contents: write

```

- **Sources:**
  - `.github/workflows/publish.yaml:22-26`

## Review evidence locations

- `.github/workflows/publish.yaml:22-26`
