# Rule details

- **Rule:**
  ```text
  CompletionItem must use __slots__ and expose arbitrary metadata passed as kwargs via item.attr, returning None for attributes that were not passed, so custom type completions paired with custom shell support can rely on this access pattern.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** Modifying CompletionItem or the attribute access used by custom type completions and custom shell support.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
CompletionItem uses __slots__ including _info and exposes arbitrary kwargs metadata via item.attr with None for unset attributes, preserving the metadata access contract.
```

- **Sources:**
  - `src/click/shell_completion.py:57-91`
