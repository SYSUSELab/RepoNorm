# Rule details

- **Rule:** Tests for click.confirm with default=True must assert the yes/no echo behavior for confirmation prompts.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests for click.confirm with default=True
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:138-155`
