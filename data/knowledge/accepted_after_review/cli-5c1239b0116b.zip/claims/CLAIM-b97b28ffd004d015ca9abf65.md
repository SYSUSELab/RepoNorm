# Rule details

- **Rule:**
  ```text
  When modifying measure_table, it must continue to compute per-column maximum term_len widths and return them in column order, defining the table-width measurement used by formatting.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When changing measure_table or table-width measurement used by formatting.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
measure_table computes per-column maximum term_len widths via widths[idx] = max(widths.get(idx, 0), term_len(col)) and returns them in column order via sorted(widths.items()), preserving the table-width measurement contract.
```

- **Sources:**
  - `src/click/formatting.py:14-21`
