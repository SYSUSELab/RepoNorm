# Rule details

- **Rule:**
  ```text
  Parameter.value_is_missing must treat None as missing, and must treat an empty tuple as missing only when nargs != 1 or multiple is set; other empty/None-like values must not be reported as missing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Parameter.value_is_missing or the parameter value-handling path that decides whether a supplied value counts as absent.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Parameter.value_is_missing returns True for None, returns True for an empty tuple only when nargs != 1 or multiple is set, and otherwise returns False, exactly matching the required missing-value semantics.
```

- **Sources:**
  - `src/click/core.py:2339-2346`
