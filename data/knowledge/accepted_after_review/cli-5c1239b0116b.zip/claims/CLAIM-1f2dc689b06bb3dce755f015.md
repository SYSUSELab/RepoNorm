# Rule details

- **Rule:**
  ```text
  When modifying Choice._normalized_mapping, it must remain an internal/unsupported surface: callers should use normalize_choice instead, and the wrapper's documented role is a simple wrapper around normalize_choice.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing Choice._normalized_mapping or its callers.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Choice._normalized_mapping is documented as a simple wrapper around normalize_choice and directs callers to use normalize_choice instead, preserving it as an internal/unsupported surface.
```

- **Sources:**
  - `src/click/types.py:270-286`
