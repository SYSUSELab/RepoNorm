# Rule details

- **Rule:**
  ```text
  Tests for prompt confirmation behavior must assert the exact prompt suffix ([y/N] vs [Y/n]) and that empty input selects the default, because the prompt suffix encodes the default choice.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests for confirm prompts with a default value
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:118-155`
