# Rule details

- **Rule:** mypy is configured to target Python 3.10.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
python_version = "3.10"

```

- **Sources:**
  - `pyproject.toml:102`

## Review evidence locations

- `pyproject.toml:101-103`
