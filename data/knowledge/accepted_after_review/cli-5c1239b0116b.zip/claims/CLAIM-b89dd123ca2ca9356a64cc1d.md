# Rule details

- **Rule:**
  ```text
  The typing job caches ./.mypy_cache keyed by mypy|hashFiles('pyproject.toml').
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
        uses: actions/cache@5a3ec84eff668545956fd18022155c47e93e2684 # v4.2.3
        with:
          path: ./.mypy_cache
          key: mypy|${{ hashFiles('pyproject.toml') }}

```

- **Sources:**
  - `.github/workflows/tests.yaml:45-48`
