# Rule details

- **Rule:**
  ```text
  EchoingStdin.__repr__ must return repr of its internal _input, exposing the input value in representations.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  when modifying EchoingStdin.__repr__ or its internal _input representation
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
EchoingStdin.__repr__ returns repr(self._input), preserving the repr-of-input contract.
```

- **Sources:**
  - `src/click/testing.py:56-57`
