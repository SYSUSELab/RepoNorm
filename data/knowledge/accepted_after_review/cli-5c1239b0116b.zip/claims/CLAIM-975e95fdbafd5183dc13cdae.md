# Rule details

- **Rule:**
  ```text
  When modifying parameter shell completion, preserve that Parameter.shell_complete uses a custom shell_complete function if provided, wrapping plain string results into CompletionItem, otherwise delegating to self.type.shell_complete.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing parameter-level shell completion dispatch.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:2441-2462`
