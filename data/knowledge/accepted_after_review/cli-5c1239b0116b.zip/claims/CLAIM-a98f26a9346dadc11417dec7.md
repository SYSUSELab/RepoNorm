# Rule details

- **Rule:** Option value-taking behavior must be determined solely by the action being 'store' or 'append'; all other actions are treated as value-less.
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** When modifying option parsing or adding new option actions that affect whether an option consumes a value.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/parser.py:153-164`
