# Rule details

- **Rule:**
  ```text
  Choice.get_metavar must build a '|'-joined choices string, deduplicating type names for options without show_choices, and wrap it in curly braces for required arguments or square brackets otherwise.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  when modifying Choice.get_metavar or the metavar formatting for choice parameters
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Choice.get_metavar joins choices with '|', deduplicates type names for options without show_choices, and wraps in {} for required arguments or [] otherwise.
```

- **Sources:**
  - `src/click/types.py:308-324`
