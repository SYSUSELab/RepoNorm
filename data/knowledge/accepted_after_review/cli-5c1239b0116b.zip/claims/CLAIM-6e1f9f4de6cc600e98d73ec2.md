# Rule details

- **Rule:**
  ```text
  The lazy file wrapper's __getattr__ must delegate attribute access to the wrapped stream so wrapped file attributes remain accessible through the wrapper.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying the lazy file wrapper's __getattr__ delegation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/utils.py:143-167`
