# Rule details

- **Rule:**
  ```text
  The tox environment `typing` runs the static type checker `mypy` via its `commands` setting.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
commands = [
    ["mypy"],
]

```

- **Sources:**
  - `pyproject.toml:174-176`

## Review evidence locations

- `pyproject.toml:171-176`
