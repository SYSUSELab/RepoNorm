# Rule details

- **Rule:** Ruff shows the fixes it applies (show-fixes = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
show-fixes = true

```

- **Sources:**
  - `pyproject.toml:123`

## Review evidence locations

- `pyproject.toml:119-124`
