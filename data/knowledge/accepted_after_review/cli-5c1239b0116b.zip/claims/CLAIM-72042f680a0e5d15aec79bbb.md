# Rule details

- **Rule:** Coverage measurement is configured to track branch coverage.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
branch = true

```

- **Sources:**
  - `pyproject.toml:88`

## Review evidence locations

- `pyproject.toml:87-89`
