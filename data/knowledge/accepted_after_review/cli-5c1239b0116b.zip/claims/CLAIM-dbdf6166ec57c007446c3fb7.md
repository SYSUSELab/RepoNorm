# Rule details

- **Rule:**
  ```text
  Tests that exercise Click's default_map behavior must assert both the invoked command output and the help text default, because default_map overrides the displayed help default as well as the runtime value.
  ```
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:**
  ```text
  when adding or modifying tests for flag options that accept a default_map
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_defaults.py:64-86`
