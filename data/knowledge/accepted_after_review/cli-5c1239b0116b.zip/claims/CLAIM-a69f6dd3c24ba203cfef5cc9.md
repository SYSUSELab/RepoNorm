# Rule details

- **Rule:**
  ```text
  The tests job runs the tox environment selected by matrix.tox, defaulting to py{python} for the matrix Python version, via `uv run --locked tox run -e ...`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - run: uv run --locked tox run -e ${{ matrix.tox || format('py{0}', matrix.python) }}

```

- **Sources:**
  - `.github/workflows/tests.yaml:32`

## Review evidence locations

- `.github/workflows/tests.yaml:23-32`
