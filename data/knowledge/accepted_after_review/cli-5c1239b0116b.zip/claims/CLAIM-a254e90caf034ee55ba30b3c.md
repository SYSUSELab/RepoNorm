# Rule details

- **Rule:** The naval example's ship new command takes a name argument and echoes 'Created ship {name}'.
- **Applies to:**
  - `examples/naval/naval.py`
- **Condition:** When modifying the ship new command or its output in the naval example.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/naval/naval.py:20-24`
