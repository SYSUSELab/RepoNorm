# Rule details

- **Rule:** Tests that verify lazy file opening must preserve the behavior that a directory path as input exits 1 on first invoke but 0 on second, output invoke raises an exception, while a non-lazy input exits 2 with an invalid value message.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When modifying or adding tests for lazy file opening behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_basic.py:281-318`
