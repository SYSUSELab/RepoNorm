# Rule details

- **Rule:**
  ```text
  Tests for click.open_file must exercise the errors parameter (e.g. errors="ignore") when the file content is not valid UTF-8, asserting that open_file honors the errors argument.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when adding or modifying tests that open files with non-UTF-8 content via click.open_file
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:529-535`
