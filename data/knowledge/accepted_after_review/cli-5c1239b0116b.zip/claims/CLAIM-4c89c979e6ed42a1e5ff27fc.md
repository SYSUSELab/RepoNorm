# Rule details

- **Rule:** The imagepipe sharpen command clamps the factor to a minimum of 1.0 via max(1.0, factor) before applying ImageEnhance.Sharpness, so values below 1.0 are silently raised.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the sharpen command or its factor handling in the imagepipe example.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/imagepipe/imagepipe.py:250-260`
