# Rule details

- **Rule:**
  ```text
  Tests for progress bar item_show_func must monkeypatch isatty to True and assert that item_show_func output appears per line in the progress bar output.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  when adding or modifying tests for progress bar item_show_func behavior
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_termui.py:295-308`
