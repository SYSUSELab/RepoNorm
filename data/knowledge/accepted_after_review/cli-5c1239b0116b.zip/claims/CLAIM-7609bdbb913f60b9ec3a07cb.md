# Rule details

- **Rule:**
  ```text
  make_default_short_help must consider only the first paragraph, strip a leading \b no-rewrap marker, truncate at a sentence-ending period without adding '...', and otherwise remove trailing words until the result plus '...' fits within max_length.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying make_default_short_help or short help text generation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/utils.py:59-106`
