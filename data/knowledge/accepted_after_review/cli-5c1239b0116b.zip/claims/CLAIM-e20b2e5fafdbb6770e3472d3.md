# Rule details

- **Rule:** An issue is not required for fixing typos in documentation, or other simple non-code changes.
- **Applies to:**
  - `**`
- **Condition:** fixing typos in documentation, or other simple non-code changes
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
PR will address. An issue is not required for fixing typos in
documentation, or other simple non-code changes.

```

- **Sources:**
  - `.github/pull_request_template.md:3-4`

## Review evidence locations

- `.github/pull_request_template.md:1-4`
