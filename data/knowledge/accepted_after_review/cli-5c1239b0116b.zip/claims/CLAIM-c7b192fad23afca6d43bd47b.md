# Rule details

- **Rule:** The imagepipe example's smoothen command must use the @processor decorator and yield transformed images, demonstrating the example's generator-based image processing command protocol.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** when modifying or extending the smoothen command in the imagepipe example
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/imagepipe/imagepipe.py:220-238`
