# Rule details

- **Rule:**
  ```text
  Tests for custom Group subclasses must verify that setting command_class to a custom command class is the supported extension point for custom command behavior.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** when adding or modifying tests for custom Group subclasses with custom command classes
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_custom_classes.py:66-81`
