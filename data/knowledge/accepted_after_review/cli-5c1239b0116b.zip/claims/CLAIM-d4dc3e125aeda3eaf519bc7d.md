# Rule details

- **Rule:**
  ```text
  Tests for progress bar update_min_steps must assert that updates are batched until the step threshold is reached, with _completed_intervals accumulating and pos advancing only when the threshold is met.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When adding or modifying tests that cover progress bar update_min_steps batching.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_termui.py:331-338`
