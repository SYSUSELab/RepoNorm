# Rule details

- **Rule:**
  ```text
  The pre-commit workflow runs on pull_request events and on pushes to the main and stable branches.
  ```
- **Applies to:**
  - `**`
- **Condition:**
  ```text
  workflow predicate: pull_request: push: branches: [main, stable]
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
on:
  pull_request:
  push:
    branches: [main, stable]

```

- **Sources:**
  - `.github/workflows/pre-commit.yaml:2-5`

## Review evidence locations

- `.github/workflows/pre-commit.yaml:1-5`
