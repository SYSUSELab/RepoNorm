# Rule details

- **Rule:** Ruff uses the full output format (output-format = "full").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
output-format = "full"

```

- **Sources:**
  - `pyproject.toml:124`

## Review evidence locations

- `pyproject.toml:119-124`
