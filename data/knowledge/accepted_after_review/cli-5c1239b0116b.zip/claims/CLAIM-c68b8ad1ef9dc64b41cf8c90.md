# Rule details

- **Rule:** Tests that exercise invoking another command through the runner must assert no exception and the expected output.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying tests that invoke commands through the runner
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:8-21`
