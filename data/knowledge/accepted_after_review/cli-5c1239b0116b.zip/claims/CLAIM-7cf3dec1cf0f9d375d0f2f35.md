# Rule details

- **Rule:**
  ```text
  The project declares colorama as a dependency only on Windows (platform_system == 'Windows').
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
dependencies = [
    "colorama; platform_system == 'Windows'",
]

```

- **Sources:**
  - `pyproject.toml:17-19`

## Review evidence locations

- `pyproject.toml:16-19`
