# Rule details

- **Rule:**
  ```text
  When modifying StringParamType.__repr__, it must continue to return the literal string "STRING", providing a stable representation for the string parameter type.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing StringParamType.__repr__ or string parameter type representation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:207-230`
