# Rule details

- **Rule:** Abort must remain a RuntimeError subclass used as an internal signalling exception to abort Click processing.
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When modifying Abort or exception handling that catches it as an internal abort signal.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Abort subclasses RuntimeError and is documented as the internal signalling exception used to abort Click processing, preserving the abort exception contract.
```

- **Sources:**
  - `src/click/exceptions.py:294-295`
