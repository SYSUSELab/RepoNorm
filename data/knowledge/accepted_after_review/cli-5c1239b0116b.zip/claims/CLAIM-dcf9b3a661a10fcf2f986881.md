# Rule details

- **Rule:**
  ```text
  TextWrapper._handle_long_word must compute space_left as max(width - cur_len, 1); when break_long_words is enabled it splits the last chunk, otherwise it only moves the chunk if the current line is empty.
  ```
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:**
  ```text
  When modifying _handle_long_word's space_left computation or break_long_words handling.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_textwrap.py:9-25`
