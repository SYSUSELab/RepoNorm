# Rule details

- **Rule:** Files in the repository use space indentation with an indent size of 4 by default.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
indent_style = space

```

- **Sources:**
  - `.editorconfig:4`

### Evidence 2 — explicit

```text
indent_size = 4

```

- **Sources:**
  - `.editorconfig:5`

## Review evidence locations

- `.editorconfig:3-13`
