# Rule details

- **Rule:** The pre-commit configuration runs the ruff hook from the astral-sh/ruff-pre-commit repository at revision 9aeda5d1f4bbd212c557da1ea78eca9e8c829e19 (frozen: v0.11.13).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  - repo: https://github.com/astral-sh/ruff-pre-commit
    rev: 9aeda5d1f4bbd212c557da1ea78eca9e8c829e19  # frozen: v0.11.13
    hooks:
      - id: ruff

```

- **Sources:**
  - `.pre-commit-config.yaml:2-5`

## Review evidence locations

- `.pre-commit-config.yaml:2-5`
