# Rule details

- **Rule:**
  ```text
  The mode property must return the stored _mode attribute, exposing the mode passed at construction.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying _NamedTextIOWrapper.mode or similar stream wrapper properties.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/testing.py:103-117`
