# Rule details

- **Rule:**
  ```text
  Tests that verify click.open_file as a context manager must preserve the expected context-manager protocol where file content is read and echoed.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When modifying or adding tests for click.open_file context-manager usage.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:471-490`
