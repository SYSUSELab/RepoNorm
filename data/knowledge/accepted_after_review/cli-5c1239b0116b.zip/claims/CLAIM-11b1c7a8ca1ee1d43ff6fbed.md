# Rule details

- **Rule:** The termui example's edit command must use click.edit with a MARKER comment and split the returned message on the marker, stripping trailing newlines, to demonstrate the edit-return contract.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** when modifying or extending the edit command in the termui example
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/termui/termui.py:117-129`
