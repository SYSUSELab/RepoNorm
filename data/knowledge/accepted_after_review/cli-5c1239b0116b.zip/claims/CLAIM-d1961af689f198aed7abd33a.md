# Rule details

- **Rule:**
  ```text
  CliRunner's Result.stdout must decode stdout_bytes using the runner charset with 'replace' errors and normalize CRLF to LF, defining the text output contract that tests rely on.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying Result.stdout or the runner's output decoding behavior
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Result.stdout decodes stdout_bytes with the runner charset and 'replace' errors and normalizes CRLF to LF, preserving the documented text output contract.
```

- **Sources:**
  - `src/click/testing.py:203-207`
