# Rule details

- **Rule:** Typing tests must use @cli.command() on a function returning None to exercise the typed decorator API for aliased groups.
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:** when adding or modifying typing tests for aliased groups
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/typing/typing_aliased_group.py:31-45`
