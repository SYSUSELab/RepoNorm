# Rule details

- **Rule:**
  ```text
  Typing tests for confirmation_option must assert that the decorator can be applied to a command function returning None, documenting the expected static-typing usage pattern.
  ```
- **Applies to:**
  - `tests/typing/typing_confirmation_option.py`
- **Condition:**
  ```text
  When adding or modifying typing tests that cover confirmation_option decorator usage.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
The typing test module applies confirmation_option to a command function and asserts its type via assert_type, documenting the static-typing usage pattern required by the rule.
```

- **Sources:**
  - `tests/typing/typing_confirmation_option.py`

### Evidence 2 — current_observation

```text
The typing test applies confirmation_option to a command function returning None, documenting the static-typing usage pattern.
```

- **Sources:**
  - `tests/typing/typing_confirmation_option.py:10-11`

## Review evidence locations

- `tests/typing/typing_confirmation_option.py:8-14`
