# Rule details

- **Rule:** The typing job configures setup-python with python-version-file: pyproject.toml.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: actions/setup-python@a26af69be951a213d495a4c3e4e4022e16d87065 # v5.6.0
        with:
          python-version-file: pyproject.toml

```

- **Sources:**
  - `.github/workflows/tests.yaml:41-43`

## Review evidence locations

- `.github/workflows/tests.yaml:41-43`
