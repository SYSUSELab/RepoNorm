# Rule details

- **Rule:**
  ```text
  The naval example must use @click.group() with @click.version_option() to attach version reporting to a command group.
  ```
- **Applies to:**
  - `examples/naval/naval.py`
- **Condition:** when modifying or extending the naval example's command group
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/naval/naval.py:4-12`
