# Rule details

- **Rule:**
  ```text
  Float parameter range types must keep min, max, min_open, max_open, and clamp as public attributes set in __init__, because range validation and clamping behavior is configured through these attributes.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying the float range parameter type's constructor or its range/clamp configuration attributes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:490-503`
