# Rule details

- **Rule:**
  ```text
  Tests for boolean flags must parametrize default True/False and args --f/[] to assert the flag's return value is the inverse of default when --f is passed.
  ```
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests for click boolean flag semantics.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_basic.py:225-237`
