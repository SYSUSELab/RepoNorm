# Rule details

- **Rule:** The lock job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  lock:
    runs-on: ubuntu-latest

```

- **Sources:**
  - `.github/workflows/lock.yaml:17-18`

## Review evidence locations

- `.github/workflows/lock.yaml:17-18`
