# Rule details

- **Rule:**
  ```text
  Tests for progress bar item_show_func must force isatty True and assert each output line containing 'item' matches the pattern '<index> item <index>', verifying item_show_func renders the current yielded item.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  when adding or modifying tests that assert progress bar item_show_func rendering
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_termui.py:295-308`
