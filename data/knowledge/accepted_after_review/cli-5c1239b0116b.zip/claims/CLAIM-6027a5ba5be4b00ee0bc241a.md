# Rule details

- **Rule:**
  ```text
  Tests for ctx.call_on_close callbacks must assert that the callback can still access the current context and its obj during close, showing that context state remains available to close callbacks.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  when adding or modifying tests that register callbacks via ctx.call_on_close
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_context.py:224-242`
