# Rule details

- **Rule:** Before opening a PR, open a ticket describing the issue or feature the PR will address.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Before opening a PR, open a ticket describing the issue or feature the
PR will address. An issue is not required for fixing typos in

```

- **Sources:**
  - `.github/pull_request_template.md:2-3`

## Review evidence locations

- `.github/pull_request_template.md:1-4`
