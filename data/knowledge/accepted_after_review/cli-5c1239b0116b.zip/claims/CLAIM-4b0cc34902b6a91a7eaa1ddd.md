# Rule details

- **Rule:**
  ```text
  The tox environment `style` runs the command `pre-commit run --all-files`.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
commands = [["pre-commit", "run", "--all-files"]]

```

- **Sources:**
  - `pyproject.toml:169`

## Review evidence locations

- `pyproject.toml:165-169`
