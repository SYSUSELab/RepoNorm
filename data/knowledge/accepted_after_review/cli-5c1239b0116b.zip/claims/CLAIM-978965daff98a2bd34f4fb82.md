# Rule details

- **Rule:**
  ```text
  When modifying parser argument registration, preserve that `add_argument` appends an `_Argument` record carrying the original `obj`, `dest`, and `nargs` to the parser's ordered argument list, keeping the caller's object for later identification.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  Changing _OptionParser.add_argument or the _Argument record it appends.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/parser.py:182-186`
