# Rule details

- **Rule:**
  ```text
  Tests for Context multi-enter must assert no exception and that the called list equals [True], verifying multi-enter records a single call.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when adding or modifying tests for Context multi-enter behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_context.py:108-125`
