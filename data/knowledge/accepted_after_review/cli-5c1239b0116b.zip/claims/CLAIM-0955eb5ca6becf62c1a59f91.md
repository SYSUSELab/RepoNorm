# Rule details

- **Rule:**
  ```text
  When modifying BoolParamType.__repr__, preserve the literal string 'BOOL' as the stable representation.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** Changing BoolParamType representation or help/debug output.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:661-683`
