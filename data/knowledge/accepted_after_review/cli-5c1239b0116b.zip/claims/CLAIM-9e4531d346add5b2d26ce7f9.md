# Rule details

- **Rule:**
  ```text
  When modifying the group decorator, it must continue to support being applied without parentheses: if the first argument is callable it is treated as the decorated function, otherwise command(name, cls, **attrs) is returned.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When changing the group decorator or its argument handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/decorators.py:293-311`
