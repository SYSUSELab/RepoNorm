# Rule details

- **Rule:** When modifying the group decorator, preserve the typing overload that returns a callable producing the specified GrpType when cls is provided, documenting the expected static type for the named form.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** Changing the group decorator's typing overloads or cls handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/decorators.py:266-283`
