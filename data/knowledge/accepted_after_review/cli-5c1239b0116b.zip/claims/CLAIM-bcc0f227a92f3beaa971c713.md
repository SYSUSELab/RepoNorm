# Rule details

- **Rule:** When modifying file-like detection, preserve the duck-typing boundary that treats any object with a read or write attribute as file-like.
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Changing _is_file_like or file-like detection logic.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:831-832`
