# Rule details

- **Rule:** Tests that verify custom argument class substitution must preserve the supported extension point of subclassing click.Argument and using it via the cls parameter.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying or adding tests for custom argument class substitution.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_arguments.py:437-454`
