# Rule details

- **Rule:**
  ```text
  The stream wrapper constructor must wrap the given binary stream with _FixupStream using force_readable and force_writable flags before passing it to the superclass, applying read/write fixups at construction time.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When modifying the stream wrapper constructor or its fixup flags.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_compat.py:56-69`
