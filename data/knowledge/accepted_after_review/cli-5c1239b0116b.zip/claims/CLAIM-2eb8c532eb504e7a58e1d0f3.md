# Rule details

- **Rule:**
  ```text
  When modifying Group.shell_complete, subcommand completion must remain additive: visible subcommands contribute CompletionItems (using each command's short help) and the parent implementation's completions are then extended, not replaced.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Group.shell_complete or the completion behavior of a group command.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Group.shell_complete builds CompletionItems for visible subcommands using their short help and then extends with super().shell_complete results, preserving additive completion.
```

- **Sources:**
  - `src/click/core.py:1891-1908`
