# Rule details

- **Rule:**
  ```text
  Tests that exercise CliRunner.invoke must accept both list-form and string-form args, because invoke normalizes None, [], "", a token list, and a single quoted string to the same parsed output.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** when adding or modifying CliRunner.invoke-based tests that pass args
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_testing.py:371-390`
