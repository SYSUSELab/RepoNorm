# Rule details

- **Rule:** Tests that verify nargs ordering must assert that fixed nargs consume arguments first and star nargs consume the remainder, producing output lines ('a','b','c'), d, ('e','f') for inputs a-f.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests for argument parsing with mixed fixed and star nargs.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_arguments.py:345-355`
