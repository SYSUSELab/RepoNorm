# Rule details

- **Rule:**
  ```text
  Tests for nested subcommand help must assert that invoking a nested subcommand with --help yields usage text 'Usage: cli ARG1 cmd ARG2 subcmd [OPTIONS]' and no exception.
  ```
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests for nested subcommand help output.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_arguments.py:415-434`
