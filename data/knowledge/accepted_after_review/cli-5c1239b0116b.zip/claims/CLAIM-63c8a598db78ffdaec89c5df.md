# Rule details

- **Rule:** Add tests that demonstrate the correct behavior of the change; tests should fail without the change.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- Add tests that demonstrate the correct behavior of the change. Tests
  should fail without the change.

```

- **Sources:**
  - `.github/pull_request_template.md:20-21`

## Review evidence locations

- `.github/pull_request_template.md:17-23`
