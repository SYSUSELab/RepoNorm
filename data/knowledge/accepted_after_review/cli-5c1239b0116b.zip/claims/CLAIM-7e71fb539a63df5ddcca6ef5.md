# Rule details

- **Rule:**
  ```text
  When progressbar is used with very fast iterators, the update_min_steps parameter must control rendering so that output is only rendered after that many updates complete.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  Modifying progressbar update cadence or the update_min_steps parameter.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_termui_impl.py:305-329`
