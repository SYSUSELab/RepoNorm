# Rule details

- **Rule:** Tests for click.File streaming semantics must exercise click.File('rb')/click.File('wb') by copying input to output in 1024-byte chunks until an empty read.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests for click.File streaming read/write behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_arguments.py:104-124`
