# Rule details

- **Rule:** Tests for prompt behavior must assert exact output strings, including hidden prompts emitting the prompt text with no echoed input while the returned value still reflects the typed text.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** when adding or modifying tests for echo-stdin prompt behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_testing.py:68-75`
