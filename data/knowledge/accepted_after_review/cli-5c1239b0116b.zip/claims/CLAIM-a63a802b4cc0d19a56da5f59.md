# Rule details

- **Rule:**
  ```text
  Group.format_options must call super().format_options then format_commands so group help output includes commands after the base option formatting.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying group help formatting or the ordering of options and commands in help output.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:1745-1757`
