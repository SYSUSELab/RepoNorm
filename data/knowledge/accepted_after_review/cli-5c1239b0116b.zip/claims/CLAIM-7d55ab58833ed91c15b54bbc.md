# Rule details

- **Rule:**
  ```text
  make_metavar must return self.metavar when set, otherwise derive from type.get_metavar or the uppercased name, append '!' when deprecated, wrap in brackets when not required, and append '...' when nargs != 1.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Argument.make_metavar or metavar formatting, preserve the explicit-metavar override, type-derived/uppercased fallback, deprecation '!' suffix, non-required bracket wrapping, and nargs '...' suffix.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:3073-3085`
