# Rule details

- **Rule:** Tests that exercise click.File option behavior must define a command with a click.File('w') option and conditionally write to it, verifying writable file option handling.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests for click.File writable option behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_basic.py:281-304`
