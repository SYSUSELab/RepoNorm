# Rule details

- **Rule:**
  ```text
  Tests that touch the shell-completion module-level registry must snapshot click.shell_completion._available_shells, clear it for the test, and restore the prior contents afterward.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying tests that interact with click.shell_completion._available_shells
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:381-387`
