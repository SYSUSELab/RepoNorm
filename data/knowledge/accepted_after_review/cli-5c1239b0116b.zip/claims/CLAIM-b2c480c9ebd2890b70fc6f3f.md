# Rule details

- **Rule:**
  ```text
  The termui example's interactive menu must implement a state-machine loop using click.getchar() with main/debug/quit states, and its filter generator must yield items probabilistically (random.random() > 0.3) for streaming with progress/termui helpers.
  ```
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** when modifying the interactive menu loop or the streaming filter generator in the termui example
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/termui/termui.py:38-169`
