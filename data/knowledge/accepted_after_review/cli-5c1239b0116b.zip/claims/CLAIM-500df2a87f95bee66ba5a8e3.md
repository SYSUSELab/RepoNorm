# Rule details

- **Rule:**
  ```text
  When modifying EchoingStdin.read1, it must continue to delegate to self._input.read1(n) and pass the result through self._echo, so reads from the testing input stream are echoed.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When changing EchoingStdin.read1 or testing input stream echo behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
EchoingStdin.read1 delegates to self._input.read1(n) and passes the result through self._echo, preserving the echo wrapper.
```

- **Sources:**
  - `src/click/testing.py:44-45`
