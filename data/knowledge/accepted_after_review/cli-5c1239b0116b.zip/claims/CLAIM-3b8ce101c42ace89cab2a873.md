# Rule details

- **Rule:**
  ```text
  Tests for cli.invoke must assert that invoking a command through cli.make_context and cli.invoke returns the command's return value.
  ```
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests that cover cli.invoke return value propagation.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_basic.py:49-56`
