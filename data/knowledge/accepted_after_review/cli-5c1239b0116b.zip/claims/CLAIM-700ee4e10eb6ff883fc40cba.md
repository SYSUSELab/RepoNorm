# Rule details

- **Rule:**
  ```text
  When modifying FloatRange._clamp, it must continue to raise RuntimeError('Clamping is not supported for open bounds.') for open bounds, explicitly leaving open float range clamping to a user callback.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing FloatRange._clamp or float range clamping behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
FloatRange._clamp raises RuntimeError for open bounds, explicitly leaving open float range clamping to a user callback, matching the rule.
```

- **Sources:**
  - `src/click/types.py:651-658`
