# Rule details

- **Rule:** Tests for nargs=2 arguments must assert that tuple defaults whose length is not 2 raise ValueError matching 'nargs=2', while a 2-element tuple default is accepted.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests that cover nargs=2 argument defaults.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_arguments.py:358-393`
