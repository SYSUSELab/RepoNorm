# Rule details

- **Rule:** Tests for group decorators must exercise the bare @click.group decorator form without arguments.
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** when adding or modifying tests for group decorator forms
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_command_no_parens defines a group via the bare @click.group decorator without arguments and exercises it, satisfying the group decorator testing convention.
```

- **Sources:**
  - `tests/test_command_decorators.py:6-13`

## Review evidence locations

- `tests/test_command_decorators.py:36-59`
