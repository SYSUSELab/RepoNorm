# Rule details

- **Rule:** Tests for chained Click groups must cover both chained and non-chained invocation modes (e.g. iterating over chain in False, True) and assert the command output is unchanged with no exception.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying tests for a Click group configured with a chain parameter
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:210-228`
