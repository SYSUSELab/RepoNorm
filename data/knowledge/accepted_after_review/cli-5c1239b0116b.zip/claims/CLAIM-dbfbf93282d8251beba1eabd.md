# Rule details

- **Rule:** Ruff's isort lint rule is configured with force-single-line = true, so imports are enforced to be on single lines.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
force-single-line = true

```

- **Sources:**
  - `pyproject.toml:140`
