# Rule details

- **Rule:** The termui example's progress bar demonstration must simulate slow processing with a random sleep to illustrate progress bar behavior with variable timing.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** when modifying or extending the progress bar demonstration in the termui example
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/termui/termui.py:38-54`
