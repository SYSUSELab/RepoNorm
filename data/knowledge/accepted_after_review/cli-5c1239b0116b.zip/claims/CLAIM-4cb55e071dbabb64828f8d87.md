# Rule details

- **Rule:**
  ```text
  Example commands that need shared state must obtain it through a pass-decorator (e.g. click.make_pass_decorator(Environment, ensure=True)) and read/write it via the injected context object rather than module-level globals.
  ```
- **Applies to:**
  - `examples/complex/**/*.py`
- **Condition:** when adding or modifying a command in the complex example that needs access to shared CLI state
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/complex/complex/cli.py:10-28`
