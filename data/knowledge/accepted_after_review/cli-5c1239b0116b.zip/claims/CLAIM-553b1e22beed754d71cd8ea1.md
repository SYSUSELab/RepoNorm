# Rule details

- **Rule:**
  ```text
  The complex example's dynamic command loader must import complex.commands.cmd_<name> and return its cli attribute, and must silently return None on ImportError so unknown commands fall through to normal error handling.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:**
  ```text
  when modifying or extending the get_command method that resolves subcommands dynamically
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
ComplexCLI.get_command dynamically imports complex.commands.cmd_<name> and returns its cli attribute, returning None on ImportError.
```

- **Sources:**
  - `examples/complex/complex/cli.py:40-45`
