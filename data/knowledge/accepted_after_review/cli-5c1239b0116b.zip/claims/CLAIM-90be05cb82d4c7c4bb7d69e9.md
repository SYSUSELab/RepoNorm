# Rule details

- **Rule:**
  ```text
  Tests combining multiple pass decorators (e.g. @click.pass_context with a custom pass_foo) must assert that the command function receives all injected values, showing that multiple pass decorators can be stacked.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when adding or modifying tests that stack multiple Click pass decorators on a command
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_context.py:426-460`
