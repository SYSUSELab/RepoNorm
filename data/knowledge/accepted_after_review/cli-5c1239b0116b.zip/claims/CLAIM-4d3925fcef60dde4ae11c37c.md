# Rule details

- **Rule:** Tests that verify non-UTF-8 filename support must preserve the platform capability probe that attempts to create a file with a surrogate-escaped name and returns False on OSError.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or adding tests for non-UTF-8 filename support.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_types.py:148-162`
