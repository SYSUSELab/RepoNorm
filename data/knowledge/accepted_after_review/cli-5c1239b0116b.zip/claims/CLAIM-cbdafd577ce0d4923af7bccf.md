# Rule details

- **Rule:** Tests for nargs tuple arguments must assert that output lines name the tuple fields and format the split values correctly.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** when adding or modifying tests for nargs tuple argument parsing and formatting
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_arguments.py:31-42`
