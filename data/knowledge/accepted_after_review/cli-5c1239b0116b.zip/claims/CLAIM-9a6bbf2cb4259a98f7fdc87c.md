# Rule details

- **Rule:**
  ```text
  Date parsing helpers such as DateTime._try_to_convert_date must return None on ValueError rather than raising, so that invalid date strings fall through to alternative parsing paths.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying or adding date parsing logic in click's type conversion module.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:439-455`
