# Rule details

- **Rule:** Read the Docs builds use Python 3.13.
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
    python: '3.13'

```

- **Sources:**
  - `.readthedocs.yaml:8`
