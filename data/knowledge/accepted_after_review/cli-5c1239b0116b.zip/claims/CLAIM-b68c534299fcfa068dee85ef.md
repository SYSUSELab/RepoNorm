# Rule details

- **Rule:**
  ```text
  Tests for open_file must assert that it supports an errors argument and context-manager usage, including opening a file with errors='ignore' inside a with block and echoing its contents.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when adding or modifying tests for open_file errors argument and context-manager usage
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:509-535`
