# Rule details

- **Rule:** mypy output is formatted with pretty formatting.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
pretty = true

```

- **Sources:**
  - `pyproject.toml:105`

## Review evidence locations

- `pyproject.toml:101-106`
