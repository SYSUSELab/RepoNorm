# Rule details

- **Rule:**
  ```text
  The tox env_run_base environment runs pytest with -v, --tb=short, and --basetemp={env_tmp_dir}, extending posargs with a default of no extra arguments.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
commands = [[
    "pytest", "-v", "--tb=short", "--basetemp={env_tmp_dir}",
    {replace = "posargs", default = [], extend = true},
]]

```

- **Sources:**
  - `pyproject.toml:160-163`
