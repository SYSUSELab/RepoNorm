# Rule details

- **Rule:**
  ```text
  Tests for custom group command resolution must define a get_command override returning a fixed command to verify the resolution path.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying tests for custom group command resolution
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:274-291`
