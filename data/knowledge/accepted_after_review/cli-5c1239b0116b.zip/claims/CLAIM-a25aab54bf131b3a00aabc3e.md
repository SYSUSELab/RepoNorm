# Rule details

- **Rule:** Tests that verify unprocessed option collection must preserve the observed behavior where unknown options are collected and reported alongside parsed arguments.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_commands.py that cover unprocessed option collection.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:436-449`
