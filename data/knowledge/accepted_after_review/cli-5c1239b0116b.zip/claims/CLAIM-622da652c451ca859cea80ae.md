# Rule details

- **Rule:**
  ```text
  unstyle must remove ANSI styling via strip_ansi, and echo already strips styling automatically when necessary.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying unstyle or echo styling behavior, keep unstyle implemented via strip_ansi and preserve echo's automatic styling strip when necessary.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
unstyle returns strip_ansi(text), removing ANSI styling via strip_ansi as required by the termui ANSI-stripping contract.
```

- **Sources:**
  - `src/click/termui.py:641-650`
