# Rule details

- **Rule:**
  ```text
  When a parameter's envvar value is read, split it via type.split_envvar_value only when nargs != 1; single-value parameters must bypass splitting so the raw envvar string is used directly.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Parameter.value_from_envvar or envvar value handling for parameters with nargs.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Parameter.value_from_envvar splits the envvar value via type.split_envvar_value only when nargs != 1, so single-value parameters bypass splitting as the rule requires.
```

- **Sources:**
  - `src/click/core.py:2377-2383`
