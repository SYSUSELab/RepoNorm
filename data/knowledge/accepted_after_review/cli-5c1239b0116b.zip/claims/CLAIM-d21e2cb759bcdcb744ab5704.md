# Rule details

- **Rule:** Tests for the '--' separator must assert that option parsing stops so subsequent '-foo' is treated as an argument, while options before '--' are still parsed and reordered into the output.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** when adding or modifying tests for argument parsing with the '--' separator
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_arguments.py:316-329`
