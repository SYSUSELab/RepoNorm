# Rule details

- **Rule:**
  ```text
  pass_meta_key must build the decorator's docstring dynamically from doc_description, defaulting to a description of the Context.meta key; changing the default wording or generated docstring format is API-visible.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When modifying pass_meta_key or the docstring generation for decorators created through this helper.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/decorators.py:100-130`
