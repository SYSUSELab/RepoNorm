# Rule details

- **Rule:**
  ```text
  _resolve_incomplete must resolve completion targets in the fixed order: option-name completion for option-like incomplete values, then incomplete option value, then first unparsed argument, then falling back to the command for subcommand-name completion.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying _resolve_incomplete's resolution order or adding new completion target branches.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/shell_completion.py:621-644`
