# Rule details

- **Rule:**
  ```text
  When modifying shell completion, preserve the contract that _is_incomplete_argument treats an argument as still accepting values when nargs is -1, when its value did not originate from the command line, or when a multi-value argument has fewer values than nargs; the value is read from ctx.params, which may be None when expose_value is False.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** Changing how shell completion decides whether an argument still accepts values.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_is_incomplete_argument returns True when nargs is -1, when the parameter source is not COMMANDLINE, or when a multi-value argument has fewer values than nargs, reading value from ctx.params which may be None when expose_value is False.
```

- **Sources:**
  - `src/click/shell_completion.py:481-503`
