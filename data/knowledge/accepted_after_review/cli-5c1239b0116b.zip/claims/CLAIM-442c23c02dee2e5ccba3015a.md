# Rule details

- **Rule:**
  ```text
  The tox environment `docs-auto` uses the dependency groups `docs` and `docs-auto`.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
dependency_groups = ["docs", "docs-auto"]

```

- **Sources:**
  - `pyproject.toml:185`

## Review evidence locations

- `pyproject.toml:183-186`
