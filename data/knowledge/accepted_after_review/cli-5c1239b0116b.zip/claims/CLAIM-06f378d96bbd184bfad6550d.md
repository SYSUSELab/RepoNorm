# Rule details

- **Rule:** Tests for choice normalization must assert case-insensitive matching while preserving the original choice value in output, exit code 2 with valid choices listed for invalid values, and bracket-form choice list in help output.
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:** when adding or modifying tests for choice normalization behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_normalization.py:18-50`
