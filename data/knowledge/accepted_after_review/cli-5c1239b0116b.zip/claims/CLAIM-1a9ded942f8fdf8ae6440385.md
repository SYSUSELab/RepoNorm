# Rule details

- **Rule:**
  ```text
  Tests for option-prefix propagation must assert that a child Context inherits the parent's _opt_prefixes set.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when adding or modifying tests for option-prefix propagation to subcontexts
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_context.py:540-545`
