# Rule details

- **Rule:**
  ```text
  When modifying ParamType.shell_complete, preserve that the default returns an empty list so custom types opt into completion by overriding it.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Changing ParamType.shell_complete default behavior or completion opt-in.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:145-160`
