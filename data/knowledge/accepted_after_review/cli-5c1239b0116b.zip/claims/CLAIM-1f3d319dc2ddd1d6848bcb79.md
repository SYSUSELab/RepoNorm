# Rule details

- **Rule:** The commit command in the repo example, when no message is given, must open an editor with a hint template and abort if the edited message is None or empty after stripping the marker section.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the commit command's message handling in the repo example
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The commit command opens an editor with a hint template when no message is given and aborts if the edited message is None or empty after stripping the marker section.
```

- **Sources:**
  - `examples/repo/repo.py:126-151`
