# Rule details

- **Rule:**
  ```text
  LazyFile.__getattr__ must delegate attribute access to self.open() so attributes are resolved lazily through the opened stream; contributors must account for this delegation when adding attributes.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When adding attributes or modifying attribute access on the lazy file wrapper.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/utils.py:143-167`
