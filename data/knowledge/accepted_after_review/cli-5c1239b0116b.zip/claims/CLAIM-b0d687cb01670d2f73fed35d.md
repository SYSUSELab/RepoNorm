# Rule details

- **Rule:**
  ```text
  Tests that verify default value rendering must assert the exact bracket formatting convention, e.g. a default value is displayed as "FOO:[42.0]".
  ```
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** When modifying or adding tests that check how default values are rendered in command output.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_basic_defaults asserts the exact bracket formatting convention, checking that "FOO:[42.0]" appears in the output.
```

- **Sources:**
  - `tests/test_defaults.py:4-13`
