# Rule details

- **Rule:**
  ```text
  Tests for float option defaults must assert that the value is echoed formatted as F:[42.0], documenting the expected formatting of float option values.
  ```
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests for float option default formatting
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_basic.py:185-200`
