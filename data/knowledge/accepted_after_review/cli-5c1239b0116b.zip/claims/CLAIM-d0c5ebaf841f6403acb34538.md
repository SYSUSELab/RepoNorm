# Rule details

- **Rule:**
  ```text
  Shell completion tests for count options must assert that completing an empty word yields no completions, while completing '-' yields ['--help'].
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or adding shell completion tests for count options.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_option_count asserts that completing an empty word yields no completions and completing '-' yields ['--help'], matching the rule.
```

- **Sources:**
  - `tests/test_shell_completion.py:166-169`
