# Rule details

- **Rule:** The imagepipe example's rotation option must accept the documented alias set (90/r/right, 180/-180, -90/270/l/left), return None for None, and raise click.BadParameter for any other value.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** when modifying or extending the rotation option callback in the imagepipe example
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/imagepipe/imagepipe.py:165-175`
