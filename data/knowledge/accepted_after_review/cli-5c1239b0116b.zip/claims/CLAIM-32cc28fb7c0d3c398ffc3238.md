# Rule details

- **Rule:**
  ```text
  Tests for Choice with case_sensitive=False must assert that values in SCREAMING_SNAKE_CASE, snake_case, PascalCase, and kebab-case are accepted, documenting case-insensitive normalization across naming styles.
  ```
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:** when adding or modifying tests for case-insensitive Choice matching
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_normalization.py:18-37`
