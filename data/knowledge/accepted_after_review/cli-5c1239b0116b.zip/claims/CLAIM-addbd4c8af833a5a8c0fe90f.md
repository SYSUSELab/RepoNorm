# Rule details

- **Rule:** The termui example's clear command must simply call click.clear() to clear the screen.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** when modifying or extending the clear command in the termui example
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/termui/termui.py:132-135`
