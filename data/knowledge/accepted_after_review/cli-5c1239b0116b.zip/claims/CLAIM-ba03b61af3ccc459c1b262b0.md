# Rule details

- **Rule:** Tests that verify shell completion word filtering for Choice values containing special characters must assert prefix filtering on '!' and exact match on '!2' for values like '!1', '!2', '+3'.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When adding or modifying tests for shell completion of Choice values that contain special characters such as '!', '+', or digits.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:147-151`
