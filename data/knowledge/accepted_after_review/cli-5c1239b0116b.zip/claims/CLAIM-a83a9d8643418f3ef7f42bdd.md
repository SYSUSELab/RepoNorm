# Rule details

- **Rule:**
  ```text
  ANSI wrapper caching such as auto_wrap_for_ansi must cache colorama wrappers per stream in _ansi_stream_wrappers, return cached wrappers when present, and tolerate cache lookup/store failures silently.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying auto_wrap_for_ansi or ANSI stream wrapper caching.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_compat.py:520-555`
