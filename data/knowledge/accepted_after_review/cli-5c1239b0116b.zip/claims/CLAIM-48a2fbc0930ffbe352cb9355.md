# Rule details

- **Rule:** Tests that verify shell completion for commands registered under a renamed key must assert that completion lists the dict key rather than the command's own name.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When adding or modifying tests for shell completion of Group commands registered via a commands dict with renamed keys.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:310-314`
