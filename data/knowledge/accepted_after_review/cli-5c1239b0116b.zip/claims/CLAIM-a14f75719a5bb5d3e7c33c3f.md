# Rule details

- **Rule:**
  ```text
  When modifying CliRunner interactive prompt simulation, preserve that visible_input writes the prompt to stdout, reads the next input line stripping CR/LF, echoes the value, and flushes.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Changing how CliRunner simulates interactive prompt input.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/testing.py:348-354`
