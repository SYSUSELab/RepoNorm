# Rule details

- **Rule:**
  ```text
  iter_params_for_processing must reorder declared parameters by invocation order and eagerness, with invocation order taking precedence over declaration order, affecting callback evaluation order.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying parameter processing order or callback evaluation order.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:115-139`
