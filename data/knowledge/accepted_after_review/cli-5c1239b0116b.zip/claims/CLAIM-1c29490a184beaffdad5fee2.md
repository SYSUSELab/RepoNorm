# Rule details

- **Rule:** Tests that verify command docstring help text must assert that the docstring is used as help text and that a marker is echoed to verify execution.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests for command docstring help text and execution verification.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_basic.py:12-28`
