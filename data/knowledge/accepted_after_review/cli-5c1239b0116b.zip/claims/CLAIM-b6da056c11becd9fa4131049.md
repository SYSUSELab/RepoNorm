# Rule details

- **Rule:**
  ```text
  LazyFile.open must wrap OSError raised by open_stream into click.FileError carrying the file name and strerror hint, so callers never see a raw OSError from lazy file opening.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  Modifying LazyFile.open or the error path around open_stream.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/utils.py:151-167`
