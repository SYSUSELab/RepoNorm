# Rule details

- **Rule:**
  ```text
  batch must use zip with repeat and strict=False so the final batch may be shorter than batch_size rather than raising on length mismatch.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying the batch helper's iteration or length-handling logic.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:92-94`
