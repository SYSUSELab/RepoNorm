# Rule details

- **Rule:**
  ```text
  When modifying _make_text_stream, preserve the default errors='replace' and line_buffering=True behavior when wrapping a binary stream.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Changing _make_text_stream defaults or binary stream wrapping.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_compat.py:19-37`
