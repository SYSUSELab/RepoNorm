# Rule details

- **Rule:**
  ```text
  BadParameter.__init__ must store param and param_hint on the exception after delegating message and context to the base class, so callers can attach parameter context that Click may later use for formatting.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  Modifying BadParameter.__init__ or how parameter context is attached to the exception.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/exceptions.py:95-123`
