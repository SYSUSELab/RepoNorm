# Rule details

- **Rule:**
  ```text
  open_stream must treat filename '-' as a standard stream, ignore the atomic flag for standard streams, and reject atomic mode with 'a' or 'x' or without 'w' via ValueError; atomic writes use a temp file with O_EXCL and preserve permissions.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When modifying stream opening, atomic write behavior, or standard-stream handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_compat.py:371-449`
