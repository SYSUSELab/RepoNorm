# Rule details

- **Rule:**
  ```text
  BytesIOCopy.__init__ must store the provided copy_to BytesIO as the copy target used when capturing output in CliRunner.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying BytesIOCopy.__init__ or the copy target used by CliRunner output capture.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
BytesIOCopy.__init__ stores the provided copy_to BytesIO as self.copy_to, preserving the copy-target contract used for CliRunner output capture.
```

- **Sources:**
  - `src/click/testing.py:76-78`
