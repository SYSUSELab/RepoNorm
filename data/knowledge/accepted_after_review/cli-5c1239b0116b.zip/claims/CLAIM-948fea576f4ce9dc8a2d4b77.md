# Rule details

- **Rule:**
  ```text
  Tests for shell completion of choice parameters must parametrize case_sensitive False/True and assert the corresponding completion sets (e.g. ['Au','al'] when insensitive, ['al'] when sensitive).
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying tests that assert shell completion for a Click choice parameter with case_sensitive
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:371-378`
