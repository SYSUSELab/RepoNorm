# Rule details

- **Rule:** The lock workflow grants write permission to issues, pull-requests, and discussions.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
permissions:
  issues: write
  pull-requests: write
  discussions: write

```

- **Sources:**
  - `.github/workflows/lock.yaml:10-13`

## Review evidence locations

- `.github/workflows/lock.yaml:10-13`
