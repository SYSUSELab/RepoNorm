# Rule details

- **Rule:**
  ```text
  CliRunner.invoke must preserve its versioned result-object contract: since 8.2 the result has output_bytes mixing stdout and stderr and always returns stderr_bytes; since 8.0 it has return_value; since 3.0 it has exc_info; a string args is treated as a Unix shell command via shlex.split; and non-integer SystemExit codes are normalized to exit code 1 after writing the code to stdout.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When modifying CliRunner.invoke or the result object it returns, including argument handling and SystemExit normalization.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
CliRunner.invoke preserves the documented contract: shlex.split for string args, non-integer SystemExit normalized to 1 after writing to stdout, and Result carrying output_bytes, stderr_bytes, return_value, and exc_info.
```

- **Sources:**
  - `src/click/testing.py:423-534`
