# Rule details

- **Rule:**
  ```text
  The tox environment list (env_list) includes py3.13, py3.12, py3.11, py3.10, pypy3.11, style, typing, and docs.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
env_list = [
    "py3.13", "py3.12", "py3.11", "py3.10",
    "pypy3.11",
    "style",
    "typing",
    "docs",
]

```

- **Sources:**
  - `pyproject.toml:144-150`

## Review evidence locations

- `pyproject.toml:143-150`
