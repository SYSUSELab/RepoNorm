# Rule details

- **Rule:** mypy type-checks the files under src and tests/typing.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
files = ["src", "tests/typing"]

```

- **Sources:**
  - `pyproject.toml:103`
