# Rule details

- **Rule:**
  ```text
  When modifying version_option, it must continue to detect the package name by inspecting stack frames when version and package_name are omitted, normalizing __main__ to __package__ and taking the top-level package; it must set is_flag, expose_value=False, is_eager, and a default help message, and raise RuntimeError if version cannot be detected.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When changing version_option or its package/version detection logic.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/decorators.py:464-524`
