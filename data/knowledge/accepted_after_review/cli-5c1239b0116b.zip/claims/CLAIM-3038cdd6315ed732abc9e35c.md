# Rule details

- **Rule:**
  ```text
  When modifying pass_obj or similar decorators, preserve that only `Context.obj` is passed to the wrapped function and that metadata is preserved via `update_wrapper`.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  Changing pass_obj or adding a decorator that injects context-derived values into a wrapped function.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/decorators.py:39-48`
