# Rule details

- **Rule:** Tests for shell completion callbacks must use the signature (ctx, param, incomplete) and may return choices from ctx.obj, documenting the custom completion callable protocol.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When adding or modifying tests for custom shell completion callbacks.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:357-368`
