# Rule details

- **Rule:** The wrapper class must store the wrapped IO object in a public wrapped attribute, exposing the underlying stream for callers.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying PacifyFlushWrapper or similar IO wrapper classes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/utils.py:498-520`
