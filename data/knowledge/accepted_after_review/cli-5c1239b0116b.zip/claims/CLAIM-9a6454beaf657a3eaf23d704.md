# Rule details

- **Rule:**
  ```text
  Tests for shell completion of options with is_flag=False and flag_value set must assert _get_words returns [] for '--name' with empty prefix, ['--flag'] for '--name' with '-', and [] for '--name --flag' with '-'.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying tests for shell completion of options with flag_value.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:172-183`
