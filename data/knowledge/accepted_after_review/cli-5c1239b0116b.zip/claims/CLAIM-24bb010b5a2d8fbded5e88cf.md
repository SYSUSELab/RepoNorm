# Rule details

- **Rule:**
  ```text
  Tests for shell completion classes must define a subclass of ShellComplete with name and source_template attributes to register a custom completion class.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when adding or modifying tests for custom shell completion classes
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:390-407`
