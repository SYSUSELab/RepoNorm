# Rule details

- **Rule:** Tests for CliRunner must exercise separate capture of stdout and stderr by interleaving writes to both streams in the test command.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When adding or modifying tests for CliRunner stream capture behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_testing.py:344-368`
