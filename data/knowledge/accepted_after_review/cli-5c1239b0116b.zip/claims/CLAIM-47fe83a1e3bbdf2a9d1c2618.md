# Rule details

- **Rule:** Tests that exercise click enum choice handling must define a str-mixin enum with hyphenated values where member values differ from member names.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests for click enum choice handling
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_basic.py:409-423`
