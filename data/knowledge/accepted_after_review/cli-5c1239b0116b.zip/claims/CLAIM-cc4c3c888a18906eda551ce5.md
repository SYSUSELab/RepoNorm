# Rule details

- **Rule:**
  ```text
  The Read the Docs install job runs `asdf plugin add uv`.
  ```
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
    install:
      - echo "Installing dependencies"
      - asdf plugin add uv

```

- **Sources:**
  - `.readthedocs.yaml:10-12`
