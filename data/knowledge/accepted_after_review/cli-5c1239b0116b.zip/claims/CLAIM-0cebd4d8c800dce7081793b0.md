# Rule details

- **Rule:**
  ```text
  Tests for Group.add_command must assert that default_map lookup uses the registered name passed to add_command, not the original command's name.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  when adding or modifying tests covering Group.add_command name registration and default_map resolution
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:294-301`
