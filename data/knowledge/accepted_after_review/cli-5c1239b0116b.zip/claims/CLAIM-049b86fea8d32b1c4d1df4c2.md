# Rule details

- **Rule:** Add or update relevant docs, in the docs folder and in code.
- **Applies to:**
  - `**/*.py`
  - `docs/**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- Add or update relevant docs, in the docs folder and in code.

```

- **Sources:**
  - `.github/pull_request_template.md:22`

## Review evidence locations

- `.github/pull_request_template.md:18-24`
