# Rule details

- **Rule:**
  ```text
  The aliases example's alias command must take an alias name and command string plus a --config_file option defaulting to "aliases.ini", add the alias to the config, write the config file, and echo a confirmation message.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when modifying or extending the alias command in the aliases example
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/aliases/aliases.py:132-143`
