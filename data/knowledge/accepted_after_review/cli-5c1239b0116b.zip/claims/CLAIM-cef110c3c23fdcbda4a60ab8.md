# Rule details

- **Rule:** Tests for click.echo must assert it does not fail when sys.stdout and sys.stderr are None, covering the pythonw on Windows scenario.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for click.echo output stream handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:51-57`
