# Constraints for `docs`

## Rule

- **Rule:** Add or update relevant docs, in the docs folder and in code.
- **Applies to:**
  - `**/*.py`
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-049b86fea8d32b1c4d1df4c2.md)

## Rule

- **Rule:** The flit sdist build includes docs/, tests/, CHANGES.rst, and uv.lock in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `tests/**`
  - `uv.lock`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-05aa953bcf90e341895f2c76.md)

## Rule

- **Rule:**
  ```text
  The tox environment `docs-auto` uses the dependency groups `docs` and `docs-auto`.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-442c23c02dee2e5ccba3015a.md)

## Rule

- **Rule:**
  ```text
  The tox docs environment builds documentation by running sphinx-build with -E, -W, -b dirhtml, source directory docs, and output directory docs/_build/dirhtml.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9421c42619f014bfbe2d0f9d.md)

## Rule

- **Rule:**
  ```text
  The tox environment `docs-auto` runs the command `sphinx-autobuild -W -b dirhtml --watch src docs docs/_build/dirhtml`, continuously rebuilding docs and starting a local server.
  ```
- **Applies to:**
  - `docs/**`
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cf01051ffb3a75732040f16d.md)

## Rule

- **Rule:** The tox docs environment uses the docs dependency group.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fb7d9907f420e41e6099839c.md)
