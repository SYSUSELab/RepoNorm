# Constraints for `.pre-commit-config.yaml`

## Rule

- **Rule:** The pre-commit cache is keyed on the hashes of pyproject.toml and .pre-commit-config.yaml.
- **Applies to:**
  - `.pre-commit-config.yaml`
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-60ad6627db477093c391b21b.md)
