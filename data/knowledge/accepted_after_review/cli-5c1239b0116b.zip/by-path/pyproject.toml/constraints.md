# Constraints for `pyproject.toml`

## Rule

- **Rule:**
  ```text
  The tox env_run_base environment uses the uv-venv-lock-runner runner.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0238ebc2d7c58061d09520b4.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-actions` uses the `gha-update` dependency group.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-14fcd7a4731d7ea9928fda55.md)

## Rule

- **Rule:**
  ```text
  The tox env_run_base environment constrains package dependencies.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-159c92ca46196a31f357927c.md)

## Rule

- **Rule:** The typing job configures setup-python with python-version-file: pyproject.toml.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1baa0e81f9ebe97da7b765c8.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-requirements` is labeled `update`.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2e0ce4aff2698bb99b505fe1.md)

## Rule

- **Rule:**
  ```text
  For the mypy override targeting the colorama.* module, missing imports are ignored (ignore_missing_imports = true).
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-33781f27e45e7925cd1aa474.md)

## Rule

- **Rule:** The workflow's Python version is taken from pyproject.toml via actions/setup-python's python-version-file input.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3a637350121197a32d063fcd.md)

## Rule

- **Rule:** uv's default dependency groups are "dev", "pre-commit", "tests", and "typing".
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-51478ae42044d697cbb780ef.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-requirements` runs `uv lock` with posargs replacing the default `-U` and extending it.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-600d545f56fb970c81a2d526.md)

## Rule

- **Rule:** The pre-commit cache is keyed on the hashes of pyproject.toml and .pre-commit-config.yaml.
- **Applies to:**
  - `.pre-commit-config.yaml`
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-60ad6627db477093c391b21b.md)

## Rule

- **Rule:**
  ```text
  The tox env_run_base environment uses frozen constraints.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-673ed6a78cbe951f56430f92.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-actions` sets `skip_install = true`.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-86dbfb3cf788130fd83855bc.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-actions` is labeled "update".
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8d41762176b56f5746031da9.md)

## Rule

- **Rule:**
  ```text
  The tox env_run_base environment runs pytest with -v, --tb=short, and --basetemp={env_tmp_dir}, extending posargs with a default of no extra arguments.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-abceebea6998aa87baa55d9a.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-requirements` sets `no_default_groups = true` and an empty `dependency_groups` list.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b5e10c876f53a0f5174b1fe5.md)

## Rule

- **Rule:**
  ```text
  The typing job caches ./.mypy_cache keyed by mypy|hashFiles('pyproject.toml').
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b89dd123ca2ca9356a64cc1d.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-actions` is defined with description "update GitHub Actions pins".
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bc587901e34e30d38fc1b329.md)

## Rule

- **Rule:**
  ```text
  The tox env_run_base environment installs the tests dependency group.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c43e0dc2a7e1ba26381eb508.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-actions` runs the `gha-update` command.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cb3712c42bb4f1192bbce351.md)

## Rule

- **Rule:**
  ```text
  The tox env_run_base environment uses .pkg as its wheel build environment.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d697379c439a75f32439e739.md)

## Rule

- **Rule:**
  ```text
  The tox env_run_base environment builds a wheel package.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d7bec6a488ee1f198b40269b.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-requirements` sets `skip_install = true`.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-dbd9d284c4f077a222e96653.md)
