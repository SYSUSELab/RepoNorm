# Constraints for `tests/test_context.py`

## Rule

- **Rule:**
  ```text
  Tests that verify click.make_pass_decorator with ensure=True must assert that the command runs without exception and produces expected output.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  When adding or modifying tests for click.make_pass_decorator with ensure=True.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c7a0dca3441717a65376b6c.md)

## Rule

- **Rule:**
  ```text
  Tests that verify ParameterSource precedence must preserve the contract that COMMANDLINE is reported for both short and long option forms, ENVIRONMENT for auto and manual envvars, DEFAULT_MAP for default_map, and DEFAULT otherwise.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** When modifying or adding tests for ParameterSource reporting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-105d275690d9982fcb5ece01.md)

## Rule

- **Rule:**
  ```text
  Tests for option-prefix propagation must assert that a child Context inherits the parent's _opt_prefixes set.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when adding or modifying tests for option-prefix propagation to subcontexts
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1a9ded942f8fdf8ae6440385.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise context.meta must read language from click.get_current_context().meta with a default fallback, treating context.meta as the supported place for arbitrary per-invocation state.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** When adding or modifying tests that cover per-invocation state stored in context.meta.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-24b4e069fc02a94e4f7b13b2.md)

## Rule

- **Rule:**
  ```text
  Tests for cli.main with standalone_mode=False must assert that it returns the exit code instead of raising SystemExit.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  when adding or modifying tests for cli.main exit behavior with standalone_mode=False
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-328ab303e6b816cb9b3652a0.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise click's context-passing behavior must define a group command decorated with click.pass_context and rely on ctx.meta as the shared per-invocation state channel visible to subcommands.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when adding or modifying tests that verify group callbacks passing context state to subcommands
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-49a1029466c619f61017380c.md)

## Rule

- **Rule:**
  ```text
  Tests for click context close-before-exit must assert no exception, no output, and that a close callback recorded [True] when the command exits.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** When adding or modifying tests for click context close-before-exit behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-59bd4158135d621900b99d62.md)

## Rule

- **Rule:**
  ```text
  Tests for logger state management must assert the initial logger level before changing it and register cleanup via ctx.call_on_close to restore state.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when adding or modifying tests that change logger levels within a Click context
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-59f8fb762c3605a09ec62593.md)

## Rule

- **Rule:**
  ```text
  Tests for ctx.call_on_close callbacks must assert that the callback can still access the current context and its obj during close, showing that context state remains available to close callbacks.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  when adding or modifying tests that register callbacks via ctx.call_on_close
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6027a5ba5be4b00ee0bc241a.md)

## Rule

- **Rule:**
  ```text
  Tests for Context multi-enter must assert no exception and that the called list equals [True], verifying multi-enter records a single call.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when adding or modifying tests for Context multi-enter behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6806f085f8dcc0fb5ae3e5b4.md)

## Rule

- **Rule:**
  ```text
  Tests combining multiple pass decorators (e.g. @click.pass_context with a custom pass_foo) must assert that the command function receives all injected values, showing that multiple pass decorators can be stacked.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when adding or modifying tests that stack multiple Click pass decorators on a command
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-90be05cb82d4c7c4bb7d69e9.md)

## Rule

- **Rule:**
  ```text
  Tests that verify custom Option subclassing must assert that a DebugLoggerOption subclass with a logger_name attribute sets the debug logger name.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** When adding or modifying tests for custom Option subclasses that set a debug logger name.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b594b9d532340381a6348ac8.md)

## Rule

- **Rule:**
  ```text
  Tests for Click context metadata must store language selection in click.get_current_context().meta[LANG_KEY], establishing context metadata as the storage location for language selection.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when adding or modifying tests that set or read language selection via Click context metadata
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bcea436c57412a9fa2537027.md)

## Rule

- **Rule:**
  ```text
  Tests for Click's context and callback behavior must verify that callbacks registered via ctx.call_on_close run on close, that eager callback invocation order depends on argument order, and that ctx.exit propagates the exit code.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  When adding or modifying tests for ctx.call_on_close, eager callback ordering, or ctx.exit in tests/test_context.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d1c6cb99f1642428a2c9b84c.md)

## Rule

- **Rule:** Tests for pass-decorator value injection must use a custom pass decorator and assert the injected value is available in the command.
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when adding or modifying tests for pass-decorator value injection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f194fe615990dec35645d015.md)

## Rule

- **Rule:**
  ```text
  Tests that verify click's pass-decorator behavior must use click.make_pass_decorator and assert the invoked command runs without exception, covering both the ensuring and no-ensuring paths.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  when adding or modifying tests for click.make_pass_decorator behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f3045ffe674ee4a7c975a097.md)
