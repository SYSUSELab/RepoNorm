# Constraints for `tests/test_parser.py`

## Rule

- **Rule:**
  ```text
  Tests for split_arg_string must parametrize cases including unterminated quotes and backslash escapes and assert the specific tokenization results.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:**
  ```text
  when adding or modifying tests for split_arg_string tokenization
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-27d03943188b3038ffa1f407.md)
