# Constraints for `tests/test_basic.py`

## Rule

- **Rule:** Tests for click.Choice with custom objects must assert that the parsed value is an instance of the custom class, showing Choice supports non-string objects with custom conversion.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests for click.Choice with custom object types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0b40124787e2af85c0707337.md)

## Rule

- **Rule:** Tests that verify command docstring help text must assert that the docstring is used as help text and that a marker is echoed to verify execution.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests for command docstring help text and execution verification.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1c29490a184beaffdad5fee2.md)

## Rule

- **Rule:**
  ```text
  Tests for boolean switch options must parametrize both the default value and CLI args, and assert the command's return_value equals the expected value, falling back to the default when no explicit flag is passed.
  ```
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests that cover boolean switch option defaults and return values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29a0428f078d1b20dbb4c7a3.md)

## Rule

- **Rule:** Tests that exercise click.File option behavior must define a command with a click.File('w') option and conditionally write to it, verifying writable file option handling.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests for click.File writable option behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2b7f8c5a0ab277c2b8246baa.md)

## Rule

- **Rule:** Tests for string option parsing must parametrize missing value, '--s=42', bare '--s', '--s=', and a snowman value, and assert result.exception is set only for the error case.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests that cover string option parsing edge cases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-37d59edc094095ebe2758ab2.md)

## Rule

- **Rule:**
  ```text
  Tests for boolean flags must parametrize default True/False and args --f/[] to assert the flag's return value is the inverse of default when --f is passed.
  ```
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests for click boolean flag semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-39d6600ebfb35ec3c97c2d68.md)

## Rule

- **Rule:** Tests for hidden commands must assert that invoking the CLI with --help exits 0 and that the hidden command name does not appear in the output, verifying hidden commands are excluded from help.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests for hidden command behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3a08085578f4cd338c770a2a.md)

## Rule

- **Rule:**
  ```text
  Tests for cli.invoke must assert that invoking a command through cli.make_context and cli.invoke returns the command's return value.
  ```
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests that cover cli.invoke return value propagation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3b8ce101c42ace89cab2a873.md)

## Rule

- **Rule:** Tests that exercise click enum choice handling must define a str-mixin enum with hyphenated values where member values differ from member names.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests for click enum choice handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-47fe83a1e3bbdf2a9d1c2618.md)

## Rule

- **Rule:** Tests that exercise eager option processing must record callback invocation order and assert that eager options run before non-eager options while otherwise preserving invocation order.
- **Applies to:**
  - `tests/test_basic.py`
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When adding or modifying tests that cover eager option processing or iter_params_for_processing ordering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5b02044a5cd55b0191c6683e.md)

## Rule

- **Rule:** Tests for Group construction from a list of commands must verify that invoking the group by subcommand name produces the expected output.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests for Group construction with a list of commands
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-664291ab913b06b4f288bd36.md)

## Rule

- **Rule:** Tests that verify option callback invocation must preserve the observed callback pattern where the callback receives and returns the value, allowing observation of invocation.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_basic.py that cover option callback invocation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-87ed4b2b9e926671286a9d35.md)

## Rule

- **Rule:** Tests that verify choice argument behavior must preserve the observed handling of non-None values and the current unsupported status of the literal 'none'.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_basic.py that cover choice argument value handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-91d7b6fc06f29b7c9bfd949c.md)

## Rule

- **Rule:** Tests that verify help output formatting must preserve the observed short-help extraction behavior, including stopping at the first blank line and excluding subsequent sentences.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_basic.py that cover help output formatting or docstring short-help extraction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-99042dd57abac1762019f45a.md)

## Rule

- **Rule:** Tests that verify lazy file opening must preserve the behavior that a directory path as input exits 1 on first invoke but 0 on second, output invoke raises an exception, while a non-lazy input exits 2 with an invalid value message.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When modifying or adding tests for lazy file opening behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d1e503e815fdcdd8263928cd.md)

## Rule

- **Rule:**
  ```text
  Tests for float option defaults must assert that the value is echoed formatted as F:[42.0], documenting the expected formatting of float option values.
  ```
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests for float option default formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df057b6d5b4e9d1e761bb64e.md)

## Rule

- **Rule:**
  ```text
  Tests for Path option behavior must assert that writing to a directory creates foo.txt with content 'meh\n', passing a file path yields 'is a file' in output, and exists/is_file/is_dir checks report the expected values for missing and existing paths.
  ```
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests for Path option behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e66cd39bba3d2a0fb56458a6.md)

## Rule

- **Rule:** Tests that verify Path type behavior must assert that Path validation resolves to a filesystem path string usable with os.path.isfile and os.path.isdir checks.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests for click.Path validation and filesystem path resolution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f1bdaf81c5935f5757d1fdae.md)

## Rule

- **Rule:** Tests asserting callback evaluation order must verify that eager flags run first in command-line order, then normal flags in first-occurrence order, with a final 'missing' callback, documenting eager vs normal parameter processing order.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests that assert Click callback invocation order for eager and normal parameters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ff0944d1c3628c22a53a126c.md)
