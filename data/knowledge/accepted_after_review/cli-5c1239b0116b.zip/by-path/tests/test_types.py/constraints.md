# Constraints for `tests/test_types.py`

## Rule

- **Rule:** Tests that verify non-UTF-8 filename support must preserve the platform capability probe that attempts to create a file with a surrogate-escaped name and returns False on OSError.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or adding tests for non-UTF-8 filename support.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4d3925fcef60dde4ae11c37c.md)

## Rule

- **Rule:** Tests that verify the invalid-choice error message must preserve the exact format "'d' is not one of 'a', 'b', 'c'." for click.Choice.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or adding tests for click.Choice invalid-choice error messages.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-689f030aab474d8cc68ac182.md)

## Rule

- **Rule:** Tests that depend on symlink support must use a helper that probes by creating a temporary symlink and returns False on OSError, so tests can skip when symlinks are unavailable.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or adding tests that require symlink support.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bc4738e92e0678df1b135045.md)

## Rule

- **Rule:** Tests for path surrogates must be skipped when the OS/FS lacks non-UTF-8 filename support and must assert BadParameter messages for non-existent, file, directory, unreadable, unwritable, and non-executable paths using surrogate filenames.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or adding tests that check path validation with surrogate filenames.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cb136c1d564c1bd5465a9a21.md)

## Rule

- **Rule:**
  ```text
  Tests for IntRange/FloatRange conversion must encode clamping and open-bound behavior: clamp=True clamps out-of-range values, min_open/max_open exclude the boundary, and FloatRange clamps inf to the max.
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** when adding or modifying tests for IntRange/FloatRange conversion behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f0254caebffed170a3730d90.md)

## Rule

- **Rule:**
  ```text
  Tests for click.Path(path_type=...) must parametrize over the supported conversion types (None, str, bytes, pathlib.Path) and assert the callback receives the converted value type.
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:**
  ```text
  When adding or modifying tests for click.Path path_type conversion behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f73abd635ee1dacb7447627a.md)
