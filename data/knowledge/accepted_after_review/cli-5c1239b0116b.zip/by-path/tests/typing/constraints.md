# Constraints for `tests/typing`

## Rule

- **Rule:**
  ```text
  Pyright type checking is limited to the src and tests/typing directories via include = ["src", "tests/typing"].
  ```
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-10fdc422ff55589e1c7c75ca.md)

## Rule

- **Rule:** mypy output is formatted with pretty formatting.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-59d62dfb4ebdc4421e210e59.md)

## Rule

- **Rule:** mypy type-checks the files under src and tests/typing.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d3c79538002c059eaca6f2fa.md)

## Rule

- **Rule:** mypy reports error codes in its output.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ec9beab207c4d3ef960186f5.md)

## Rule

- **Rule:** mypy runs in strict mode.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f21b4cdc843fdc5bc137966b.md)
