# Constraints for `tests/typing/typing_confirmation_option.py`

## Rule

- **Rule:**
  ```text
  Typing tests for confirmation_option must assert that the decorator can be applied to a command function returning None, documenting the expected static-typing usage pattern.
  ```
- **Applies to:**
  - `tests/typing/typing_confirmation_option.py`
- **Condition:**
  ```text
  When adding or modifying typing tests that cover confirmation_option decorator usage.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d70811ab6e2a04106bdb3ac1.md)
