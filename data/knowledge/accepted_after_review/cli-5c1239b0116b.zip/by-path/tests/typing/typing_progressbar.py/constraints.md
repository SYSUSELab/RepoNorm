# Constraints for `tests/typing/typing_progressbar.py`

## Rule

- **Rule:**
  ```text
  Typing tests for progressbar over an iterable must assert that the result is ProgressBar[str] and that iterating the bar yields str values.
  ```
- **Applies to:**
  - `tests/typing/typing_progressbar.py`
- **Condition:** when adding or modifying typing tests for progressbar generic behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-18365232ac489f037cc65749.md)
