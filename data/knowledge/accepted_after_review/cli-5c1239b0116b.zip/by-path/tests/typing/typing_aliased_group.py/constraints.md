# Constraints for `tests/typing/typing_aliased_group.py`

## Rule

- **Rule:** Typing tests must use @cli.command() on a function returning None to exercise the typed decorator API for aliased groups.
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:** when adding or modifying typing tests for aliased groups
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6629d1bbefde4817c6b62aeb.md)
