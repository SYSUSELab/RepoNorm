# Constraints for `tests/test_shell_completion.py`

## Rule

- **Rule:**
  ```text
  Tests for shell completion classes must define a subclass of ShellComplete with name and source_template attributes to register a custom completion class.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when adding or modifying tests for custom shell completion classes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-24bb010b5a2d8fbded5e88cf.md)

## Rule

- **Rule:** Tests that verify shell completion output must preserve the exact per-shell completion strings and nargs progression behavior, including that an intervening option does not reset argument completion state.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_shell_completion.py that cover completion output for bash, zsh, or fish, or argument nargs completion progression.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2f0e2d19893e8dc2944d5e4e.md)

## Rule

- **Rule:** Tests for CompletionItem must assert that arbitrary keyword data is accepted (e.g. data a=1) and that unset attributes return None (e.g. b is None).
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when adding or modifying tests that construct CompletionItem with arbitrary keyword data
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3a2226b75acdb695e63ae858.md)

## Rule

- **Rule:** Shell completion tests for nested Group/Command structures must assert word-by-word completion: empty word lists subcommands, '-' lists options including --help, and a fully consumed command yields no completions.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or adding shell completion tests for nested groups and commands.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-401a6a9857d9be848c88fa5c.md)

## Rule

- **Rule:** Tests that verify shell completion for commands registered under a renamed key must assert that completion lists the dict key rather than the command's own name.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When adding or modifying tests for shell completion of Group commands registered via a commands dict with renamed keys.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-48a2fbc0930ffbe352cb9355.md)

## Rule

- **Rule:** Tests for shell completion callbacks must use the signature (ctx, param, incomplete) and may return choices from ctx.obj, documenting the custom completion callable protocol.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When adding or modifying tests for custom shell completion callbacks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5cd6f36b1b2a4e08a9e04f9e.md)

## Rule

- **Rule:**
  ```text
  Tests for shell completion must parametrize over bash, zsh, and fish and assert that invoking with env _CLI_COMPLETE set to '{shell}_source' produces output containing '_CLI_COMPLETE={shell}_complete'.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When adding or modifying tests that cover the shell completion source handshake.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-620431f2eacad005392919e7.md)

## Rule

- **Rule:**
  ```text
  Shell completion tests must use the _patch_for_completion fixture to monkeypatch BashComplete._check_version to always return True, isolating completion tests from the installed bash version.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or adding shell completion tests that depend on bash version.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-697336c3da806347c975498c.md)

## Rule

- **Rule:**
  ```text
  Tests for Click's shell completion registration must verify that an unregistered shell name is absent from _available_shells, that add_completion_class returns the class, and that after registration the shell appears in _available_shells mapped to that class.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying tests for add_completion_class or _available_shells in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7cb93d40b3b2d3337ef4016a.md)

## Rule

- **Rule:**
  ```text
  Tests for shell completion of choice parameters must parametrize case_sensitive False/True and assert the corresponding completion sets (e.g. ['Au','al'] when insensitive, ['al'] when sensitive).
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying tests that assert shell completion for a Click choice parameter with case_sensitive
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-948fea576f4ce9dc8a2d4b77.md)

## Rule

- **Rule:**
  ```text
  Tests for shell completion of options with is_flag=False and flag_value set must assert _get_words returns [] for '--name' with empty prefix, ['--flag'] for '--name' with '-', and [] for '--name --flag' with '-'.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying tests for shell completion of options with flag_value.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9a6454beaf657a3eaf23d704.md)

## Rule

- **Rule:** Tests that verify shell completion word filtering for Choice values containing special characters must assert prefix filtering on '!' and exact match on '!2' for values like '!1', '!2', '+3'.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When adding or modifying tests for shell completion of Choice values that contain special characters such as '!', '+', or digits.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ba03b61af3ccc459c1b262b0.md)

## Rule

- **Rule:**
  ```text
  Shell completion tests for count options must assert that completing an empty word yields no completions, while completing '-' yields ['--help'].
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or adding shell completion tests for count options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d0c5ebaf841f6403acb34538.md)

## Rule

- **Rule:**
  ```text
  Tests for add_completion_class must assert that using it as a decorator registers the new shell immediately in click.shell_completion._available_shells and that the registered value is the class itself.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying tests for add_completion_class decorator registration
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dbf23097e9d89ed1dfe9a13e.md)

## Rule

- **Rule:**
  ```text
  Tests that touch the shell-completion module-level registry must snapshot click.shell_completion._available_shells, clear it for the test, and restore the prior contents afterward.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying tests that interact with click.shell_completion._available_shells
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ddc8720aece3d1cb04dd5888.md)
