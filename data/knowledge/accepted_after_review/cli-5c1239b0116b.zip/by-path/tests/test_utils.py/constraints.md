# Constraints for `tests/test_utils.py`

## Rule

- **Rule:** Tests that exercise pager output must assert that exceptions and KeyboardInterrupt raised inside the generator propagate to the caller while the pager may remain open, and that stdout/stderr writes made during generator execution are preserved separately from pager output.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When modifying or adding tests around echo_via_pager generator execution and pager lifecycle.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0041e261cd63f4503ec0d2ed.md)

## Rule

- **Rule:**
  ```text
  Tests that verify click.open_file as a context manager must preserve the expected context-manager protocol where file content is read and echoed.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When modifying or adding tests for click.open_file context-manager usage.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0b701acd03be395aee4ff5dc.md)

## Rule

- **Rule:**
  ```text
  Tests for Click's program name detection must verify that _detect_program_name returns the basename for plain paths, python -m module for __main__.py, python -m package.module for module files, and strips ./ prefixes.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for _detect_program_name in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-187db22e0085cc37d12dc7e3.md)

## Rule

- **Rule:**
  ```text
  MockMain test helper must use __slots__ = '__package__' to constrain the mock to only that attribute for main-module detection tests.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding test helpers for main-module detection.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2d7ec76f83b5017df4031dc9.md)

## Rule

- **Rule:** Tests for click.echo with bytes messages containing non-ASCII content must verify correct output handling within a command callback.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests for click.echo with non-ASCII bytes messages
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2f83618606931f3fc1a8eec3.md)

## Rule

- **Rule:**
  ```text
  Tests for click.open_file must exercise the errors parameter (e.g. errors="ignore") when the file content is not valid UTF-8, asserting that open_file honors the errors argument.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when adding or modifying tests that open files with non-UTF-8 content via click.open_file
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3ab29efc9fb501f187150a7c.md)

## Rule

- **Rule:**
  ```text
  Tests that verify open_file behavior must preserve the observed handling of pathlib.Path representing '-' for stdin/stdout.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_utils.py that cover open_file with pathlib.Path representing '-'.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4c40f12c040f57ebe3fa16f5.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise _expand_args must assert it expands ~, environment variables, and glob patterns, but returns a bad glob pattern such as a pytest identifier unchanged.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when adding or modifying tests for _expand_args expansion behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-51d88515bbe8497e8575671b.md)

## Rule

- **Rule:** Tests for Click's testing runner must verify that getchar input is handled, that multiple prompt-enabled options are prompted sequentially, and that an Abort during a hidden prompt produces the expected interrupted output (with platform-specific skips where behavior differs).
- **Applies to:**
  - `tests/test_testing.py`
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for the Click testing runner's input handling, sequential prompting, or prompt-abort behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-545660df4b2ab5781a3d64e0.md)

## Rule

- **Rule:** Tests for confirmation prompts must assert that an empty first input produces 'Error: invalid input' and re-prompts, with the exact output sequence including the error and subsequent prompt.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests for confirmation prompt repeat behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8642e3256005b52f3ded080a.md)

## Rule

- **Rule:**
  ```text
  Tests for prompt confirmation behavior must assert the exact prompt suffix ([y/N] vs [Y/n]) and that empty input selects the default, because the prompt suffix encodes the default choice.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests for confirm prompts with a default value
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-91a9b0804a857c9ecf2df4ae.md)

## Rule

- **Rule:**
  ```text
  Tests for open_file must assert that it supports an errors argument and context-manager usage, including opening a file with errors='ignore' inside a with block and echoing its contents.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when adding or modifying tests for open_file errors argument and context-manager usage
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b68c534299fcfa068dee85ef.md)

## Rule

- **Rule:** Tests for click.confirm with default=True must assert the yes/no echo behavior for confirmation prompts.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests for click.confirm with default=True
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b9acdf79677e5638afb8fe35.md)

## Rule

- **Rule:** Tests for click.echo must assert it does not fail when sys.stdout and sys.stderr are None, covering the pythonw on Windows scenario.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for click.echo output stream handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cef110c3c23fdcbda4a60ab8.md)

## Rule

- **Rule:** Tests that exercise Click's ANSI styling and unstyling helpers must assert exact escape-sequence output, including that reset=False omits the trailing reset and that unstyle reverses both color and non-color ANSI codes.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for click.style or click.unstyle in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-daf6ba7b61a9a775adce4454.md)

## Rule

- **Rule:** Tests asserting Click output routing must verify that click.echo, click.prompt, click.confirm, and click.pause send output to stderr when err=True, with prompts written to stderr lacking a trailing newline and pause writing a newline.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests that assert Click output stream routing for echo, prompt, confirm, or pause
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e5be2c5aee6309a3a39ced9d.md)

## Rule

- **Rule:** Tests for click.confirm must exercise it through a click command callback and assert the branch taken based on the boolean return value of confirm.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for click.confirm behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fdbbe03f10b9a4d569e58c94.md)
