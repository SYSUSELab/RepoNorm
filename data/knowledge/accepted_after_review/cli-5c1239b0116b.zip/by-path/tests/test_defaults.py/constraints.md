# Constraints for `tests/test_defaults.py`

## Rule

- **Rule:**
  ```text
  Tests for multiple=True flag detection must cover the three independent flag triggers: a secondary token in '-y/-n', is_flag=True, and flag_value, including two flag_value options sharing the same destination name.
  ```
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** when adding or modifying tests for multiple=True option flag detection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-48872c869be4a6b15221a667.md)

## Rule

- **Rule:** Tests for nargs plus multiple defaults must assert that invoking with no arguments produces the expected default rendering lines.
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** When adding or modifying tests that cover nargs plus multiple default rendering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-869e2dc5614361ca6534f9d5.md)

## Rule

- **Rule:**
  ```text
  Tests that verify default value rendering must assert the exact bracket formatting convention, e.g. a default value is displayed as "FOO:[42.0]".
  ```
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** When modifying or adding tests that check how default values are rendered in command output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b0d687cb01670d2f73fed35d.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Click's default_map behavior must assert both the invoked command output and the help text default, because default_map overrides the displayed help default as well as the runtime value.
  ```
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:**
  ```text
  when adding or modifying tests for flag options that accept a default_map
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dbdf6166ec57c007446c3fb7.md)
