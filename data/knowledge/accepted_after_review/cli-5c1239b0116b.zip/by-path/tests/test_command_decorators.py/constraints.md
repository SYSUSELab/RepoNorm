# Constraints for `tests/test_command_decorators.py`

## Rule

- **Rule:** Tests that verify positional argument ordering must assert that Argument objects are registered in order with names 'a' and 'b' and that invoking with '1 2' yields output '1 2'.
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** When modifying or adding tests that check positional argument ordering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-09655316ac7389d605a68186.md)

## Rule

- **Rule:** Tests for group decorators must exercise the bare @click.group decorator form without arguments.
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** when adding or modifying tests for group decorator forms
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-50a21a037bff1eff70d3e1ab.md)

## Rule

- **Rule:** Tests for @grp.command must cover the no-parentheses decorator form, ensuring the command is registered when used directly as a decorator.
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** when adding or modifying tests for group command decorator forms
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7c682387b963ba57893bea3f.md)

## Rule

- **Rule:** Tests for custom command classes must verify that the class can be used without parentheses and that invoking it produces the expected output without raising an exception.
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** when adding or modifying tests for custom command classes used as decorators
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ee4785fbb0de63c1ea5d76a3.md)

## Rule

- **Rule:** Tests for nested groups must exercise nested group decorators.
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** when adding or modifying tests for nested group decorators
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f260a431e2b8b4e64b522cd8.md)
