# Constraints for `tests/test_custom_classes.py`

## Rule

- **Rule:**
  ```text
  Tests for click.Command subclasses must assert that Command subclasses can override the context class used during invocation via context_class.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** When adding or modifying tests for click.Command subclass context class overrides.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6cd4c54e8f3fe46a900cfb7e.md)

## Rule

- **Rule:**
  ```text
  Tests for Context subclass with a custom formatter_class must assert that help is formatted using that type, including ANSI-colored 'Options:' output when color=True, documenting the formatter_class extension point.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:**
  ```text
  when adding or modifying tests for custom Context formatter_class behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8468943dda258e48af3f5b89.md)

## Rule

- **Rule:**
  ```text
  Tests for custom Group subclasses must verify that setting command_class to a custom command class is the supported extension point for custom command behavior.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** when adding or modifying tests for custom Group subclasses with custom command classes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cff7fb239d9b24bc84e12007.md)

## Rule

- **Rule:** Tests that verify custom HelpFormatter subclassing must assert that help formatting can be customized by subclassing click.HelpFormatter.
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** When adding or modifying tests for custom help formatter subclasses.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-def11dc3e477115b23a37e86.md)

## Rule

- **Rule:** Tests for custom context invoke type must assert that a command invoked from a custom context receives a new context with the same type, and that invoking the first command produces no exception.
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** When modifying or adding tests that check custom context invoke type behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e054f207d50d3d7f5960b75d.md)

## Rule

- **Rule:**
  ```text
  Tests that verify custom context class usage must assert the passed context is a CustomContext instance and that its id differs from the first_id argument.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** when adding or modifying tests for custom context class usage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f5dd2897919f7fa8444af244.md)
