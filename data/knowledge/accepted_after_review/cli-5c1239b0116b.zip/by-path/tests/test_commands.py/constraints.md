# Constraints for `tests/test_commands.py`

## Rule

- **Rule:** Tests for context forwarding must verify that a command forwarding to another via ctx.forward receives the original context's params.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying tests for ctx.forward context forwarding behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-03a4e4cf8669c42434b856bc.md)

## Rule

- **Rule:** Tests for chained Click groups must cover both chained and non-chained invocation modes (e.g. iterating over chain in False, True) and assert the command output is unchanged with no exception.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying tests for a Click group configured with a chain parameter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0530a0986bb8fbde1b4b834d.md)

## Rule

- **Rule:**
  ```text
  Tests for Group.add_command must assert that default_map lookup uses the registered name passed to add_command, not the original command's name.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  when adding or modifying tests covering Group.add_command name registration and default_map resolution
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0cebd4d8c800dce7081793b0.md)

## Rule

- **Rule:**
  ```text
  Command.parse_args must populate ctx._opt_prefixes with the set {"-", "--", "+", "!"}, establishing the recognized option prefix characters.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When modifying or adding tests that check Command.parse_args option prefix collection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1500638ae6ead8718957f423.md)

## Rule

- **Rule:**
  ```text
  Tests for chained Click groups must initialize ctx.obj as a dict via pass_context and store the debug flag there, following the repository's expected context object pattern for chained groups.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying tests that define a chained Click group with a --debug/--no-debug option
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1b50ad7963938769df78fea3.md)

## Rule

- **Rule:** Tests for Click's command registration must verify that non-standard option prefixes such as plus-prefixed flags are handled correctly.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When adding or modifying tests for command registration with non-standard option prefixes in tests/test_commands.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1f13a31f939f7901479644d9.md)

## Rule

- **Rule:**
  ```text
  Tests for command forwarding must assert that invoking the group with 'dist' produces output 'Count: 1\nCount: 42\n' with no exception.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When modifying or adding tests that check command forwarding behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1fd93cf68832eeed081cc701.md)

## Rule

- **Rule:** Tests that exercise eager option processing must record callback invocation order and assert that eager options run before non-eager options while otherwise preserving invocation order.
- **Applies to:**
  - `tests/test_basic.py`
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When adding or modifying tests that cover eager option processing or iter_params_for_processing ordering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5b02044a5cd55b0191c6683e.md)

## Rule

- **Rule:**
  ```text
  Tests asserting that a Click group collects the set of option prefixes used across subcommands must expect the full set of custom prefixes (e.g. {'-', '--', '~', '+'}) to be tracked.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying tests that assert collected option prefixes for a Click group with subcommands
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6562994fb9ab89675cf7c5ba.md)

## Rule

- **Rule:**
  ```text
  Tests for custom group command resolution must define a get_command override returning a fixed command to verify the resolution path.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying tests for custom group command resolution
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6d356e3ab259c3760b8cba1e.md)

## Rule

- **Rule:** Tests that define a click group with a click.argument('obj') must echo the received obj value, exercising argument passing to group callbacks.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When modifying or adding tests that exercise argument passing to group callbacks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-93bd7b7293d2e0bd7a34883f.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise non-standard option prefixes in group option parsing must use click.option with a non-standard prefix such as '~t' and is_flag=True.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying tests for non-standard option prefix parsing in groups
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-93fca56e17bd921370699a5e.md)

## Rule

- **Rule:** Tests that verify integer argument conversion must assert that an INT argument is parsed and echoed correctly.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When adding or modifying tests for integer argument conversion.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-996592792eab7f644d8e5f6b.md)

## Rule

- **Rule:** Tests that verify unprocessed option collection must preserve the observed behavior where unknown options are collected and reported alongside parsed arguments.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_commands.py that cover unprocessed option collection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a25aab54bf131b3a00aabc3e.md)

## Rule

- **Rule:** Tests that exercise invoking another command through the runner must assert no exception and the expected output.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying tests that invoke commands through the runner
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c68b8ad1ef9dc64b41cf8c90.md)

## Rule

- **Rule:** Tests for aliased commands must assert that invoking via an alias produces help output whose usage line shows the canonical command name.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying tests for aliased command help output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df7ea655784349b19fb30588.md)

## Rule

- **Rule:**
  ```text
  Tests for standalone_mode=False invocation must verify that defaults are type-cast (e.g., string '15' becomes int 15) and that empty multiple values become empty tuples rather than None.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  when adding or modifying tests for standalone_mode=False invocation with defaults
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df9323259d6850b286814bbf.md)
