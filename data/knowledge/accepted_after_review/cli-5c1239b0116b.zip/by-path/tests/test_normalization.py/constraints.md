# Constraints for `tests/test_normalization.py`

## Rule

- **Rule:** Tests for choice normalization must assert case-insensitive matching while preserving the original choice value in output, exit code 2 with valid choices listed for invalid values, and bracket-form choice list in help output.
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:** when adding or modifying tests for choice normalization behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-06f378d96bbd184bfad6550d.md)

## Rule

- **Rule:**
  ```text
  Tests for Choice with case_sensitive=False must assert that values in SCREAMING_SNAKE_CASE, snake_case, PascalCase, and kebab-case are accepted, documenting case-insensitive normalization across naming styles.
  ```
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:** when adding or modifying tests for case-insensitive Choice matching
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-32cc28fb7c0d3c398ffc3238.md)
