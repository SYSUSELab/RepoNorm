# Constraints for `tests/test_arguments.py`

## Rule

- **Rule:** Tests for click.Argument must assert that constructing an Argument with both required=True and deprecated=True raises ValueError with a message matching 'is deprecated and still required'.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests for click.Argument option validation, specifically the required/deprecated incompatibility.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-204112a1442fad20396b9284.md)

## Rule

- **Rule:** Tests for variadic Click arguments must declare the nargs=-1 argument before any fixed single arguments, because variadic arguments must precede fixed arguments in declaration order.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** when adding or modifying tests that declare a Click command with a variadic (nargs=-1) argument alongside fixed arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2fce6daed01c4b907626c072.md)

## Rule

- **Rule:** Tests that exercise Click's argument/option parsing must preserve the exact observed parsing outcomes, including variadic nargs grouping, envvar-supplied flag values, and rejection of defaults on nargs=-1 arguments.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_arguments.py that cover argument nargs, envvar flag resolution, or unbounded nargs defaults.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4e884a75f1fb3bcd1d880468.md)

## Rule

- **Rule:** Tests that exercise default stdout behavior must assert that invoking the command with no args produces the expected output with no exception.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** when adding or modifying tests for default stdout behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4f4e2eb4971b549238739e50.md)

## Rule

- **Rule:** Tests for implicit optional arguments must assert that invoking with no arguments exits 0 and outputs 'test', establishing that an argument without required=True is implicitly optional.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying or adding tests that check implicit optional argument behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5545b7880a22664c4d6ec769.md)

## Rule

- **Rule:** Tests for Click's argument handling must verify that variadic arguments (nargs=-1) can be marked required and that explicit command-line values take precedence over envvar values, with envvar used only when no command-line values are supplied.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests for click.argument with nargs=-1 and required=True
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-57349639eafd51ec37a6cb11.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise reusable_argument decorator must apply it to a click command and verify argument reuse across commands.
  ```
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:**
  ```text
  When modifying or adding tests that exercise the reusable_argument decorator.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-69df2288166e14ee9408dc4f.md)

## Rule

- **Rule:** Tests for nargs=2 arguments must assert that tuple defaults whose length is not 2 raise ValueError matching 'nargs=2', while a 2-element tuple default is accepted.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests that cover nargs=2 argument defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8babce7c3f4aa864c8d5de91.md)

## Rule

- **Rule:** Tests that verify nargs ordering must assert that fixed nargs consume arguments first and star nargs consume the remainder, producing output lines ('a','b','c'), d, ('e','f') for inputs a-f.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests for argument parsing with mixed fixed and star nargs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a36687e0e3ba8d2ab2eb5e83.md)

## Rule

- **Rule:**
  ```text
  Tests for nested subcommand help must assert that invoking a nested subcommand with --help yields usage text 'Usage: cli ARG1 cmd ARG2 subcmd [OPTIONS]' and no exception.
  ```
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests for nested subcommand help output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c55fec638f2a5fbbb0189611.md)

## Rule

- **Rule:** Tests that verify custom argument class substitution must preserve the supported extension point of subclassing click.Argument and using it via the cls parameter.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying or adding tests for custom argument class substitution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c5622bdcb557c1c2ff975d2f.md)

## Rule

- **Rule:** Tests for nargs tuple arguments must assert that output lines name the tuple fields and format the split values correctly.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** when adding or modifying tests for nargs tuple argument parsing and formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cbdafd577ce0d4923af7bccf.md)

## Rule

- **Rule:** Tests for click.File streaming semantics must exercise click.File('rb')/click.File('wb') by copying input to output in 1024-byte chunks until an empty read.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests for click.File streaming read/write behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cdfe8b09e1372aad655edcf9.md)

## Rule

- **Rule:** Tests for the '--' separator must assert that option parsing stops so subsequent '-foo' is treated as an argument, while options before '--' are still parsed and reordered into the output.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** when adding or modifying tests for argument parsing with the '--' separator
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d21e2cb759bcdcb744ab5704.md)

## Rule

- **Rule:**
  ```text
  Tests for flag options with flag_value and envvar must assert that an option declared with flag_value and no explicit is_flag is implicitly treated as a flag, and that its envvar supplies the flag value when the environment variable is set.
  ```
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:**
  ```text
  when adding or modifying tests for flag options with flag_value and envvar
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f7cab40fca64798cbe51e461.md)
