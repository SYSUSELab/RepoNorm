# Constraints for `tests/test_info_dict.py`

## Rule

- **Rule:**
  ```text
  Tests that verify the info_dict shape must preserve the exact metadata fields including is_flag True, flag_value True, and default False for HELP_OPTION, and default 1 for NUMBER_OPTION.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  When modifying or adding tests for parameter info_dict metadata.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-726725cd24a7e7692895275a.md)

## Rule

- **Rule:**
  ```text
  Tests for ParamType.to_info_dict must verify that a ParamType without an explicit name reports its class name in the 'name' field.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  when adding or modifying tests for ParamType.to_info_dict name reporting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a16a4e0e9d57c004936f4037.md)
