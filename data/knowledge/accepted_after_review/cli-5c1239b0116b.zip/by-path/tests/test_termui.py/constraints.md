# Constraints for `tests/test_termui.py`

## Rule

- **Rule:**
  ```text
  Tests for progress bar item_show_func must monkeypatch isatty to True and assert that item_show_func output appears per line in the progress bar output.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  when adding or modifying tests for progress bar item_show_func behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-061a4b2736050ea02cdfefe6.md)

## Rule

- **Rule:**
  ```text
  Tests for progress bar item_show_func must force isatty True and assert each output line containing 'item' matches the pattern '<index> item <index>', verifying item_show_func renders the current yielded item.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  when adding or modifying tests that assert progress bar item_show_func rendering
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-39bea66deafa6e5cb255a291.md)

## Rule

- **Rule:**
  ```text
  Tests for hidden-input confirmation must define a password option with hide_input=True and confirmation_prompt, exercising hidden-input confirmation behavior.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** when adding or modifying tests for hidden-input confirmation behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6aeb2d3a0b0f897f706f62ce.md)

## Rule

- **Rule:** Tests for confirmation prompts must assert that when prompt is a string like 'Confirm Password', that text appears in output, and that empty input with default '' returns '' while prompt=False returns None.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When adding or modifying tests for click confirmation prompt text and return value behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6daf73e51a200823c40d57ce.md)

## Rule

- **Rule:** Tests for click.getchar on Windows must monkeypatch msvcrt.getwch to return control characters and assert KeyboardInterrupt or EOFError, and must be skipped when not on Windows.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** when adding or modifying tests for click.getchar Windows exception behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9627349a11b22dfcc39af48e.md)

## Rule

- **Rule:** Tests that exercise click.edit with an external editor must be skipped on Windows when sed is unavailable and assert that click.edit returns None with the file content transformed.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** when adding or modifying tests for click.edit with external editors
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9d3dd002755a727c45d8c165.md)

## Rule

- **Rule:**
  ```text
  Tests that verify progressbar ETA formatting must preserve the exact format_eta outputs including zero-padded HH:MM:SS, day-prefixed output for very large ETAs ('1157407d 09:46:39'), and empty string when eta is None.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying or adding tests for progressbar ETA formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a3f7074bc5a64aaa4e43da9d.md)

## Rule

- **Rule:**
  ```text
  Tests for progress bar formatting must assert exact format_progress_line() output for a given width, including zero-length progress, omitted percent/position variants, and full completion.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying or adding tests that check progress bar line formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b7e2c801f126f7dc9718588f.md)

## Rule

- **Rule:**
  ```text
  Tests that verify progressbar behavior must preserve the observed custom item display and finished-state loop behavior when using item_show_func.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_termui.py that cover progressbar item display or finished-state behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ba7e1c8ceaa63aae2105b0c3.md)

## Rule

- **Rule:**
  ```text
  Tests for progress bar update_min_steps must assert that updates are batched until the step threshold is reached, with _completed_intervals accumulating and pos advancing only when the threshold is met.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When adding or modifying tests that cover progress bar update_min_steps batching.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d4dc3e125aeda3eaf519bc7d.md)

## Rule

- **Rule:** Tests for hidden progressbars must monkeypatch isatty to True and assert empty output, verifying that a hidden progressbar emits nothing.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** when adding or modifying tests for hidden progressbar output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ea4a89a16fb31a32f075ddbb.md)
