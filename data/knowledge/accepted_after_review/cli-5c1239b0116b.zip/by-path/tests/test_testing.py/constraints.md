# Constraints for `tests/test_testing.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise CliRunner.invoke must accept both list-form and string-form args, because invoke normalizes None, [], "", a token list, and a single quoted string to the same parsed output.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** when adding or modifying CliRunner.invoke-based tests that pass args
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-14db38c5d712f53e321ee3ab.md)

## Rule

- **Rule:** Tests for prompt behavior must assert exact output strings, including hidden prompts emitting the prompt text with no echoed input while the returned value still reflects the typed text.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** when adding or modifying tests for echo-stdin prompt behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3ed187cc8a9f5bf7999ca1a2.md)

## Rule

- **Rule:** Tests for Click's testing runner must verify that getchar input is handled, that multiple prompt-enabled options are prompted sequentially, and that an Abort during a hidden prompt produces the expected interrupted output (with platform-specific skips where behavior differs).
- **Applies to:**
  - `tests/test_testing.py`
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for the Click testing runner's input handling, sequential prompting, or prompt-abort behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-545660df4b2ab5781a3d64e0.md)

## Rule

- **Rule:** Tests for CliRunner must exercise separate capture of stdout and stderr by interleaving writes to both streams in the test command.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When adding or modifying tests for CliRunner stream capture behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-653a153bc1ed6f4bdf0c5073.md)

## Rule

- **Rule:** Tests that verify stderr flushing behavior must use print with end="" and flush=False to explicitly avoid auto-flush, so the test controls when flushing occurs.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** when adding or modifying tests that assert stderr flushing behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7208328d7b2b5419665edf04.md)

## Rule

- **Rule:** Tests for CliRunner.invoke must assert that echoed input round-trips through the runner's stdin handling, producing output exactly equal to the supplied input with no exception.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** when adding or modifying tests that supply input to CliRunner.invoke and assert echoed output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7648bb44199b10a99ca86cc3.md)

## Rule

- **Rule:** Tests that verify binary stream piping must preserve the behavior of reading binary stdin in 4096-byte chunks and writing/flushing to binary stdout through CliRunner.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying or adding tests for binary stream piping through CliRunner.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b4aa09d73e4f28f76d123413.md)

## Rule

- **Rule:** Tests that exercise echo-stdin behavior must read stdin and write stdout in 4096-byte chunks with explicit flush, exercising binary stream passthrough rather than text-level input handling.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When adding or modifying tests that cover echo-stdin binary stream passthrough.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e7b169f420628aafa5ca7cf6.md)

## Rule

- **Rule:** Tests that verify color=True with non-blocking pause must preserve the behavior that no exception is raised and output is empty.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying or adding tests for color=True with non-blocking pause.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ea63b269605cb49d6a31215b.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise CLI runner exception handling must assert that CliRunner.invoke's catch_exceptions argument overrides the runner-level setting: True yields a result carrying the exception and a 3-tuple exc_info, while False propagates the exception.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** when adding or modifying tests for CliRunner.invoke exception handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ee3aa4e4b12c6ff7ced22e51.md)

## Rule

- **Rule:**
  ```text
  Tests for CliRunner(echo_stdin=True) must assert that provided input is echoed to output, so result.output contains the input line followed by the command's echoed output.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  when adding or modifying tests for CliRunner echo_stdin behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f31bbf096d9d87c6be40a343.md)
