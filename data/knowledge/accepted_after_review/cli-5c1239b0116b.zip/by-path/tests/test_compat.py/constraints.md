# Constraints for `tests/test_compat.py`

## Rule

- **Rule:**
  ```text
  Tests for should_strip_ansi must assert that ANSI stripping is disabled for Jupyter kernel output streams identified by their __module__.
  ```
- **Applies to:**
  - `tests/test_compat.py`
- **Condition:**
  ```text
  when adding or modifying tests for should_strip_ansi with Jupyter kernel streams
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-17c007391ef55550da1c78da.md)
