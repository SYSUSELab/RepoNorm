# Constraints for `.`

## Rule

- **Rule:** Add or update relevant docs, in the docs folder and in code.
- **Applies to:**
  - `**/*.py`
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-049b86fea8d32b1c4d1df4c2.md)

## Rule

- **Rule:** Ruff's isort lint rule is configured with order-by-type = false, so imports are not ordered by type.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-076afafb7433c4c73fa98446.md)

## Rule

- **Rule:** The pre-commit configuration runs the check-merge-conflict hook from the pre-commit/pre-commit-hooks repository at revision cef0300fd0fc4d2a87a85fa2093c6b283ea36f4b (frozen: v5.0.0).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09b97d2451d74e60ee179d41.md)

## Rule

- **Rule:**
  ```text
  The tox environment list (env_list) includes py3.13, py3.12, py3.11, py3.10, pypy3.11, style, typing, and docs.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0bbdb087351a74f565ef8de5.md)

## Rule

- **Rule:** Pyright is configured with pythonVersion = "3.10".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-16c9ad255272f52b8082eedf.md)

## Rule

- **Rule:** Ruff uses the full output format (output-format = "full").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1d005e77fef10e27b547c1aa.md)

## Rule

- **Rule:**
  ```text
  The tox environment `style` uses the `pre-commit` dependency group and skips installing the project package.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2be3297d743b8378877a453a.md)

## Rule

- **Rule:**
  ```text
  Add `.. versionchanged::` entries in any relevant code docs.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-2e864fa85b4bd45f32092d55.md)

## Rule

- **Rule:** CSS, HTML, JS, JSON, JSX, SCSS, TS, TSX, YAML, and YML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.jsx`
  - `**/*.scss`
  - `**/*.ts`
  - `**/*.tsx`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3aa1ff1bf121289d4dcaca48.md)

## Rule

- **Rule:** The pre-commit configuration runs the ruff hook from the astral-sh/ruff-pre-commit repository at revision 9aeda5d1f4bbd212c557da1ea78eca9e8c829e19 (frozen: v0.11.13).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3ab3a1d604bb9eb6d05a65b6.md)

## Rule

- **Rule:** The pre-commit configuration runs the uv-lock hook from the astral-sh/uv-pre-commit repository at revision a621b109bab2e7e832d98c88fd3e83399f4e6657 (frozen: 0.7.12).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3b0c6e9cfaa03c5e85ae6706.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-pre_commit` runs the command `pre-commit autoupdate --freeze -j4`.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3c08f959ae47c6a1e3940db7.md)

## Rule

- **Rule:**
  ```text
  The tox environment `typing` runs the static type checker `mypy` via its `commands` setting.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-40533f3cccf591fd1e492fb3.md)

## Rule

- **Rule:** Files in the repository use space indentation with an indent size of 4 by default.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4091ce29ff63bf5f72cf5cb8.md)

## Rule

- **Rule:** Trailing whitespace is trimmed in files in the repository.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-441d1a02e99ee100fe211849.md)

## Rule

- **Rule:** Lines in files in the repository are limited to a maximum length of 88 characters.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-58480dec96990b83111cc3a5.md)

## Rule

- **Rule:**
  ```text
  The Tests workflow runs on push events to the main and stable branches, ignoring changes under docs/** and README.md.
  ```
- **Applies to:**
  - `**`
- **Condition:** push events to main or stable
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6860682738615d563d25483b.md)

## Rule

- **Rule:** Coverage measurement is configured to track branch coverage.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-72042f680a0e5d15aec79bbb.md)

## Rule

- **Rule:**
  ```text
  The project requires Python >=3.10.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-72827b8dfa0dc9bf567ef3e4.md)

## Rule

- **Rule:**
  ```text
  The Tests workflow runs on pull_request events, ignoring changes under docs/** and README.md.
  ```
- **Applies to:**
  - `**`
- **Condition:**
  ```text
  pull_request events
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-76a2b367790f0f12e32405e9.md)

## Rule

- **Rule:**
  ```text
  The project declares colorama as a dependency only on Windows (platform_system == 'Windows').
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7cf3dec1cf0f9d375d0f2f35.md)

## Rule

- **Rule:** Ruff shows the fixes it applies (show-fixes = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7f1ac6f783332b5a3fb4c79c.md)

## Rule

- **Rule:**
  ```text
  Pytest treats warnings as errors via filterwarnings = ["error"].
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8033178ddbb67e750635e77e.md)

## Rule

- **Rule:**
  ```text
  The pre-commit workflow runs pre-commit via `uv run --locked --group pre-commit pre-commit run --show-diff-on-failure --color=always --all-files`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-834d0594f6dc5ee4dcb02700.md)

## Rule

- **Rule:** Ruff linting ignores rule UP038 to keep isinstance tuple syntax.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-84156b62b7efe5c3933315e2.md)

## Rule

- **Rule:** Files in the repository use LF line endings.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-849bff5937a894532e9903c5.md)

## Rule

- **Rule:** Ruff applies fixes automatically (fix = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8827d66b6709e71036514f58.md)

## Rule

- **Rule:** Before opening a PR, open a ticket describing the issue or feature the PR will address.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-97d2886d04a90adffdc85e67.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-pre_commit` uses the `pre-commit` dependency group.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3962eea52aeb295f1838725.md)

## Rule

- **Rule:**
  ```text
  The tests job runs the tox environment selected by matrix.tox, defaulting to py{python} for the matrix Python version, via `uv run --locked tox run -e ...`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a69f6dd3c24ba203cfef5cc9.md)

## Rule

- **Rule:**
  ```text
  The typing job runs `uv run --locked tox run -e typing`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a90be6e33b7a71725199b83e.md)

## Rule

- **Rule:**
  ```text
  The tox environment `typing` declares its dependencies through the `typing` dependency group.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b01256071b66bee0ac57e284.md)

## Rule

- **Rule:** Files in the repository use UTF-8 charset.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bc73424b1397d25e8a82dd15.md)

## Rule

- **Rule:**
  ```text
  The pre-commit workflow runs on pull_request events and on pushes to the main and stable branches.
  ```
- **Applies to:**
  - `**`
- **Condition:**
  ```text
  workflow predicate: pull_request: push: branches: [main, stable]
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bd38e94097f5c00cec37eff3.md)

## Rule

- **Rule:** Ruff linting selects the rule sets B (flake8-bugbear), E (pycodestyle error), F (pyflakes), I (isort), UP (pyupgrade), and W (pycodestyle warning).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-c1a5a3a9be86c2c898fffaf2.md)

## Rule

- **Rule:**
  ```text
  Coverage reporting excludes lines matching the patterns "if t.TYPE_CHECKING", "raise NotImplementedError", and ": \\.{3}" from coverage via exclude_also.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c4be75a30184c9fdf0376f84.md)

## Rule

- **Rule:**
  ```text
  Coverage path mapping is configured with source paths "src" and "*/site-packages".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c61743238be59f4522300d08.md)

## Rule

- **Rule:** mypy is configured to target Python 3.10.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cb6ff004df1ce906cf8c2531.md)

## Rule

- **Rule:**
  ```text
  The pre-commit-ci/lite-action step runs even when the job is cancelled, as gated by `if: ${{ !cancelled() }}`.
  ```
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: ${{ !cancelled() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dba10b17a86eb7dc9c8b162d.md)

## Rule

- **Rule:** Ruff's isort lint rule is configured with force-single-line = true, so imports are enforced to be on single lines.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dbfbf93282d8251beba1eabd.md)

## Rule

- **Rule:** An issue is not required for fixing typos in documentation, or other simple non-code changes.
- **Applies to:**
  - `**`
- **Condition:** fixing typos in documentation, or other simple non-code changes
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-e20b2e5fafdbb6770e3472d3.md)

## Rule

- **Rule:** Pyright runs in basic type checking mode (typeCheckingMode = "basic").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ea513823a7f83b3444af2f45.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-pre_commit` sets `skip_install = true`.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f02e6faddb1527f3cc9c22ce.md)

## Rule

- **Rule:** Files in the repository are configured to end with a final newline.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fc4d6ffb227cb7ab6d86c2c9.md)
