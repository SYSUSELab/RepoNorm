# Constraints for `examples/termui/termui.py`

## Rule

- **Rule:** The termui example's edit command must use click.edit with a MARKER comment and split the returned message on the marker, stripping trailing newlines, to demonstrate the edit-return contract.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** when modifying or extending the edit command in the termui example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-11b1c7a8ca1ee1d43ff6fbed.md)

## Rule

- **Rule:** The termui example's progress bar demonstration must simulate slow processing with a random sleep to illustrate progress bar behavior with variable timing.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** when modifying or extending the progress bar demonstration in the termui example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-718c355cfef9c1fac322bade.md)

## Rule

- **Rule:** The termui example's clear command must simply call click.clear() to clear the screen.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** when modifying or extending the clear command in the termui example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-addbd4c8af833a5a8c0fe90f.md)

## Rule

- **Rule:**
  ```text
  The termui example's interactive menu must implement a state-machine loop using click.getchar() with main/debug/quit states, and its filter generator must yield items probabilistically (random.random() > 0.3) for streaming with progress/termui helpers.
  ```
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** when modifying the interactive menu loop or the streaming filter generator in the termui example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b2c480c9ebd2890b70fc6f3f.md)

## Rule

- **Rule:**
  ```text
  The termui example's show_item helper must return None implicitly when item is None and otherwise format the item as "Item #<item>".
  ```
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:**
  ```text
  When modifying the show_item helper in the termui example
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f1befd90aaa887c912b3d35b.md)
