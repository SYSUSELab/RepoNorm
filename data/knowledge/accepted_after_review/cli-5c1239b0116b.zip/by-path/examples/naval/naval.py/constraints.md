# Constraints for `examples/naval/naval.py`

## Rule

- **Rule:** The naval example's ship new command takes a name argument and echoes 'Created ship {name}'.
- **Applies to:**
  - `examples/naval/naval.py`
- **Condition:** When modifying the ship new command or its output in the naval example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a254e90caf034ee55ba30b3c.md)

## Rule

- **Rule:**
  ```text
  The naval example must use @click.group() with @click.version_option() to attach version reporting to a command group.
  ```
- **Applies to:**
  - `examples/naval/naval.py`
- **Condition:** when modifying or extending the naval example's command group
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a93d6cf11a021d47f15aaf8f.md)

## Rule

- **Rule:** The naval example's remove subcommand must accept two float arguments and echo the removed coordinates.
- **Applies to:**
  - `examples/naval/naval.py`
- **Condition:** When modifying the remove subcommand in the naval example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e5ddab0f97026b298b76e520.md)
