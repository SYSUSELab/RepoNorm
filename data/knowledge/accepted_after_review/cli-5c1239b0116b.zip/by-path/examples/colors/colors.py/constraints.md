# Constraints for `examples/colors/colors.py`

## Rule

- **Rule:**
  ```text
  The colors example defines all_colors as the fixed set of 16 supported color names, including bright_* variants, which serves as the canonical list of color values exercised by the example.
  ```
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** When modifying the colors example's color list or its usage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0b9dd30506e787d0ef357bf0.md)

## Rule

- **Rule:** The colors example must demonstrate click.style usage with fg, bold, reverse, blink, and underline, and document that ANSI styles are automatically stripped when output is piped to a file.
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** when modifying or extending the colors example's style demonstration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a29d22bd40de9ba93ff568a8.md)
