# Constraints for `examples/aliases/aliases.py`

## Rule

- **Rule:**
  ```text
  Example CLI commands that load configuration from a file must expose the config path as a click.Path(exists=True, dir_okay=False) option with a callback and expose_value=False, so the parsed config is injected into the command context rather than passed as a parameter.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when adding or modifying a command that reads a configuration file in the aliases example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-32cc54ab152c72110613cbfe.md)

## Rule

- **Rule:**
  ```text
  AliasedGroup.get_command must resolve builtin commands first, then explicit aliases from a Config object, then fall back to unique-prefix abbreviation; if multiple commands match the prefix it must call ctx.fail with a 'Too many matches' message.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** When modifying command resolution or alias handling in the aliases example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-45aac825c429758b5d1eb3f7.md)

## Rule

- **Rule:**
  ```text
  AliasedGroup.resolve_command must override the base to always return the resolved command's canonical name rather than the alias used, ensuring alias invocations report the real command name.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** When modifying command resolution or alias handling in the aliases example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-84e642631987ae13243a988d.md)

## Rule

- **Rule:**
  ```text
  The aliases example must store aliases in a CWD-relative dict initialized at construction time (path = os.getcwd(), aliases = {}), and add_alias must register entries in that dict; AliasedGroup must subclass click.Group to resolve aliases from this config.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when modifying alias storage, registration, or lookup in the aliases example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c1e5e7232c96b7659871d6d6.md)

## Rule

- **Rule:** The aliases example's pull command must be a minimal command shape with a docstring and echo output.
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when adding or modifying a minimal command in the aliases example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e04cb6cace4a7c157f6ddf48.md)

## Rule

- **Rule:**
  ```text
  The aliases example's alias command must take an alias name and command string plus a --config_file option defaulting to "aliases.ini", add the alias to the config, write the config file, and echo a confirmation message.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when modifying or extending the alias command in the aliases example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e0a1ac2e0bb0c574d322f4d6.md)

## Rule

- **Rule:**
  ```text
  The aliases example's Config.read_config must use configparser.RawConfigParser to read the file and update self.aliases from the 'aliases' section, silently ignoring a missing section via NoSectionError.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:**
  ```text
  when modifying or extending Config.read_config in the aliases example
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e9448d05dd8b4ebf0b04a34a.md)
