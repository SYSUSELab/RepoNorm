# Constraints for `examples/validation/validation.py`

## Rule

- **Rule:**
  ```text
  The validation example must demonstrate three distinct validation mechanisms in one command: a callback for --count, a custom ParamType (URL) for --url, and manual BadParameter raising with param_hint for --foo.
  ```
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** when modifying or extending the validation example command
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dd54b671f8912172957aff65.md)

## Rule

- **Rule:** The validation example's URL ParamType convert method must parse values with urlparse and fail with an error message when the scheme is not http or https.
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** when modifying URL type validation in the validation example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e4370861becdd753897965f9.md)
