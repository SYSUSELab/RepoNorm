# Constraints for `examples/completion/completion.py`

## Rule

- **Rule:**
  ```text
  The completion example's ls command must define a --dir option typed as click.Path(file_okay=False) to constrain completion to directories.
  ```
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** when modifying or extending the ls command in the completion example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-04ac9b0c81b1fa9a3f5767de.md)

## Rule

- **Rule:** Shell completion callbacks may return either a plain list of strings or a list of CompletionItem objects; when returning CompletionItem objects, matching may consider both the item value and its help text.
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When modifying or adding shell completion callbacks in the completion example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-28896a764d69b7f45b79b42a.md)
