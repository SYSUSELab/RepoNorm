# Constraints for `examples/complex/complex/commands`

## Rule

- **Rule:**
  ```text
  The complex example's command modules must import pass_environment from complex.cli to share the pass_environment decorator across command modules.
  ```
- **Applies to:**
  - `examples/complex/complex/commands/**/*.py`
- **Condition:** when adding or modifying a command module in the complex example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-332c74b341c38c319f1d2a6d.md)
