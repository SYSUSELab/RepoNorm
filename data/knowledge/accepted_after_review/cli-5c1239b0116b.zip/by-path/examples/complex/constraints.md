# Constraints for `examples/complex`

## Rule

- **Rule:**
  ```text
  Example commands that need shared state must obtain it through a pass-decorator (e.g. click.make_pass_decorator(Environment, ensure=True)) and read/write it via the injected context object rather than module-level globals.
  ```
- **Applies to:**
  - `examples/complex/**/*.py`
- **Condition:** when adding or modifying a command in the complex example that needs access to shared CLI state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4cb55e071dbabb64828f8d87.md)
