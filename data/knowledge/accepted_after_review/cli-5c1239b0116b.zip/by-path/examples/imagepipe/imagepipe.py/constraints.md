# Constraints for `examples/imagepipe/imagepipe.py`

## Rule

- **Rule:** The imagepipe example's rotation option must accept the documented alias set (90/r/right, 180/-180, -90/270/l/left), return None for None, and raise click.BadParameter for any other value.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** when modifying or extending the rotation option callback in the imagepipe example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-30b7393da7d34ccba3cc5913.md)

## Rule

- **Rule:**
  ```text
  The imagepipe example's processor decorator must wrap functions to return a processor function, use update_wrapper to preserve the wrapped function's metadata, and accept arbitrary args/kwargs; copy_filename must copy the filename attribute from the old image to the new image and return the new image.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** when adding or modifying image processors or filename propagation in the imagepipe example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-400053f2e0e27ce7ce5f3598.md)

## Rule

- **Rule:**
  ```text
  The imagepipe example uses @click.group(chain=True) with a result_callback that folds each chained subcommand over the image stream and drains the final stream to force evaluation.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:**
  ```text
  When modifying the imagepipe example's command group, subcommands, or result_callback.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4837c248b1b44e4149c20ce7.md)

## Rule

- **Rule:** The imagepipe sharpen command clamps the factor to a minimum of 1.0 via max(1.0, factor) before applying ImageEnhance.Sharpness, so values below 1.0 are silently raised.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the sharpen command or its factor handling in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4c89c979e6ed42a1e5ff27fc.md)

## Rule

- **Rule:** The imagepipe transpose command applies rotate and/or flip options to each image, echoes the operation, and yields the transformed image with copied filename metadata.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the transpose command or its rotate/flip handling in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7a52e68952e7a3827afe0946.md)

## Rule

- **Rule:**
  ```text
  The imagepipe flip callback maps both lr/leftright and tb/topbottom/upsidedown/ud to Image.FLIP_LEFT_RIGHT, so the top-bottom aliases do not actually select a top-bottom flip in this example.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the flip callback or its alias mapping in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9d81a042806730ff73812b47.md)

## Rule

- **Rule:**
  ```text
  The imagepipe generator decorator passes through old values unchanged, does not pass values as a parameter, and preserves wrapped function metadata via update_wrapper.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the generator decorator or functions it wraps in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a078d7656c4fb3b9d05fc534.md)

## Rule

- **Rule:** The paste command in the imagepipe example must consume only the first two images from the iterator; if a second image is absent it yields the first unchanged and returns, otherwise it pastes the second onto the first using the pasted image as a mask when it is RGBA or has a 'transparency' info key, and yields the modified first followed by the remaining images unchanged.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the paste command's image consumption or compositing logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a402d9047bd1477ee0a7039b.md)

## Rule

- **Rule:** The imagepipe example's smoothen command must use the @processor decorator and yield transformed images, demonstrating the example's generator-based image processing command protocol.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** when modifying or extending the smoothen command in the imagepipe example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c7b192fad23afca6d43bd47b.md)

## Rule

- **Rule:** The imagepipe resize command yields images after thumbnail resizing, preserving aspect ratio and using width/height or original dimensions.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the resize command or its dimension handling in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dba101122d32682d45482a7b.md)

## Rule

- **Rule:** The imagepipe example imports PIL Image, ImageEnhance, and ImageFilter alongside click, indicating the example depends on Pillow for image processing.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the imagepipe example's imports or image processing dependencies.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fa843dd8a1ffebd19c44624d.md)
