# Constraints for `examples/repo/repo.py`

## Rule

- **Rule:**
  ```text
  The repo example's delete command stacks click.confirmation_option() with pass_repo, so invoking delete prompts for confirmation before executing and receives the repo via the pass decorator.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the delete command or its decorator stack in the repo example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-09ce301e94ae855d03c2c88f.md)

## Rule

- **Rule:** The repo example's clone command derives DEST from the last path component of SRC when DEST is omitted, falling back to '.' if that component is empty.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the clone command or its DEST derivation logic in the repo example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-10517b1ef2f71e653fea9ff8.md)

## Rule

- **Rule:** The commit command in the repo example, when no message is given, must open an editor with a hint template and abort if the edited message is None or empty after stripping the marker section.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the commit command's message handling in the repo example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1f3d319dc2ddd1d6848bcb79.md)

## Rule

- **Rule:**
  ```text
  Repo.set_config must store the key/value in self.config and, when verbose is true, echo the assignment to stderr, so verbose mode routes diagnostic output to stderr.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying configuration storage or verbose output in the repo example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-324c359efacc440bdad8dfea.md)

## Rule

- **Rule:**
  ```text
  The repo example's setuser command must combine prompt=True options with click.password_option and pass_repo, and must store the password masked as '*' * len(password).
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** when modifying credential prompting or password storage in the repo example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3e773a68313e0387393ce0f.md)
