# Constraints for `examples`

## Rule

- **Rule:** Example modules must import click at module level following the example module import convention.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example module that uses click.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1d44a6f212137464fac27484.md)

## Rule

- **Rule:** Ruff excludes the examples/ directory from its checks via extend-exclude.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f34d92e6cf63e41b32bc1389.md)
