# Constraints for `.readthedocs.yaml`

## Rule

- **Rule:**
  ```text
  The Read the Docs HTML build runs `uv run --group docs sphinx-build -W -b dirhtml docs $READTHEDOCS_OUTPUT/html`.
  ```
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0462a8e5054686e58c88a744.md)

## Rule

- **Rule:**
  ```text
  The Read the Docs install job runs `asdf install uv latest`.
  ```
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7f55f42658e863a6e5f28e48.md)

## Rule

- **Rule:**
  ```text
  The Read the Docs install job runs `asdf plugin add uv`.
  ```
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cc4c3c888a18906eda551ce5.md)

## Rule

- **Rule:**
  ```text
  The Read the Docs install job runs `asdf global uv latest`.
  ```
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cd1d40231096a077666b09e3.md)

## Rule

- **Rule:** Read the Docs builds use Python 3.13.
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d388d9c6c87ea0df346f93e8.md)

## Rule

- **Rule:** Read the Docs builds use Ubuntu 24.04 as the build OS.
- **Applies to:**
  - `.readthedocs.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f45f2f61747d3fe3a0709e57.md)
