# Constraints for `src`

## Rule

- **Rule:**
  ```text
  Pyright type checking is limited to the src and tests/typing directories via include = ["src", "tests/typing"].
  ```
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-10fdc422ff55589e1c7c75ca.md)

## Rule

- **Rule:** Ruff treats src as the source root directory.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-23768c9e923d113ab50ecf2d.md)

## Rule

- **Rule:** mypy output is formatted with pretty formatting.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-59d62dfb4ebdc4421e210e59.md)

## Rule

- **Rule:**
  ```text
  The tox environment `docs-auto` runs the command `sphinx-autobuild -W -b dirhtml --watch src docs docs/_build/dirhtml`, continuously rebuilding docs and starting a local server.
  ```
- **Applies to:**
  - `docs/**`
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cf01051ffb3a75732040f16d.md)

## Rule

- **Rule:** mypy type-checks the files under src and tests/typing.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d3c79538002c059eaca6f2fa.md)

## Rule

- **Rule:** mypy reports error codes in its output.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ec9beab207c4d3ef960186f5.md)

## Rule

- **Rule:** mypy runs in strict mode.
- **Applies to:**
  - `src/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f21b4cdc843fdc5bc137966b.md)
