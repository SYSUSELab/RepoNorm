# Constraints for `src/click/__init__.py`

## Rule

- **Rule:**
  ```text
  Deprecated public names must remain importable from the click package and must emit a DeprecationWarning naming the replacement and the removal version; BaseCommand, MultiCommand, and OptionParser are scheduled for removal in Click 9.0 and __version__ in Click 9.1.
  ```
- **Applies to:**
  - `src/click/__init__.py`
- **Condition:**
  ```text
  when modifying the module-level __getattr__ deprecation shim or the removal schedule for legacy public names
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fc8e6eee987434dcc3cb7ba9.md)
