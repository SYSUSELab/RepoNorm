# Constraints for `src/click/exceptions.py`

## Rule

- **Rule:**
  ```text
  MissingParameter must document param_type valid values as 'parameter', 'option', or 'argument', and default to inheriting the parameter type from the given param.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When modifying MissingParameter's param_type documentation or default inheritance behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0b6ffee9033861cc323036c0.md)

## Rule

- **Rule:**
  ```text
  When a command's output or error display is rendered, the color decision must flow through the active context's color setting (ctx.color) rather than a hard-coded or independently resolved value, so that resolve_color_default's explicit-argument override and context lookup remain the single source of truth.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
  - `src/click/globals.py`
- **Condition:** Modifying color resolution or error/output rendering so that a rendered message or stream color is chosen.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3c86a9ab05ba73426846f52f.md)

## Rule

- **Rule:** Abort must remain a RuntimeError subclass used as an internal signalling exception to abort Click processing.
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When modifying Abort or exception handling that catches it as an internal abort signal.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-414c19e4be10dead63efb74e.md)

## Rule

- **Rule:**
  ```text
  MissingParameter.format_message must build the message from param_hint (or param.get_error_hint), append the type's missing message, and map param_type names to translated "Missing argument"/"Missing option"/"Missing parameter" prefixes.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  Modifying MissingParameter.format_message or the missing-parameter error message format.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-482ab33439ced9154b632d83.md)

## Rule

- **Rule:**
  ```text
  BadParameter.__init__ must store param and param_hint on the exception after delegating message and context to the base class, so callers can attach parameter context that Click may later use for formatting.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  Modifying BadParameter.__init__ or how parameter context is attached to the exception.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8ae27beb4eb3a6cad0387126.md)

## Rule

- **Rule:**
  ```text
  Exit must remain a RuntimeError subclass with __slots__ = ("exit_code",), carrying the exit status as an attribute on the exception rather than via a separate mechanism.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** Modifying the Exit exception class or how exit status is carried.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8d5443c448f25c1aca904fe2.md)

## Rule

- **Rule:**
  ```text
  FileError.format_message must use the translated template 'Could not open file {filename!r}: {message}' with ui_filename and message, defining the user-facing error format for file open failures.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When modifying FileError.format_message or the user-facing message for file open failures.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c03ff8c484588109fd8043d2.md)

## Rule

- **Rule:**
  ```text
  ClickException subclasses must preserve the class-level exit_code contract (default 1) because the CLI runner reads it to determine the process exit status for handled exceptions.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When adding or modifying a ClickException subclass or its exit_code attribute.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e7eb7c00f34e26c3b8461e48.md)

## Rule

- **Rule:**
  ```text
  FileError must remain a subclass of ClickException so file-open failures flow through the standard Click error handling path, and its constructor must default a missing hint to the translated 'unknown error' while storing the raw filename and a separately formatted ui_filename.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when modifying FileError or its constructor, including its base class, hint default, or filename formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eefa3c1f077f2766e816a580.md)
