# Constraints for `src/click/_winconsole.py`

## Rule

- **Rule:**
  ```text
  When modifying the Windows console wrapper, preserve that its `name` property delegates to the underlying buffer's `name`, so stream identity follows the wrapped buffer.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** Changing ConsoleStream.name or the Windows console stream wrapper's identity delegation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-12b71541bb5f3e2789f374e3.md)

## Rule

- **Rule:**
  ```text
  _WindowsConsoleReader.readable must return the literal True, declaring the stream always readable.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying _WindowsConsoleReader.readable's return value.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-254f94112d4863db7f2979ac.md)

## Rule

- **Rule:**
  ```text
  When modifying _get_windows_console_stream, it must continue to return None unless get_buffer is available, encoding is 'utf-16-le' or None, errors is 'strict' or None, the file is a console, a stream factory is registered for the file descriptor, and the file exposes a buffer; otherwise it returns the factory applied to the buffer.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When changing _get_windows_console_stream or Windows console stream detection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7440cb51190d3d5cf7975b9a.md)

## Rule

- **Rule:**
  ```text
  Py_buffer must be defined as a ctypes Structure with fields buf, obj, len, itemsize, readonly, ndim, format, shape, strides, suboffsets, and internal, matching the CPython buffer protocol layout for Windows console handling.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying Py_buffer or Windows console FFI structures that must match the CPython buffer protocol layout.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b9547dccfd4168af6b7cd402.md)

## Rule

- **Rule:** When modifying ConsoleStream.writelines, it must continue to delegate each line to self.write, so write's encoding/error handling applies uniformly to line batches.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When changing ConsoleStream.writelines or Windows console line writing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cb3e03cb7f07405b816cccc2.md)

## Rule

- **Rule:**
  ```text
  When modifying Windows console output, preserve that _WindowsConsole write flushes before writing bytes and swallows flush exceptions so byte writes proceed even if flushing fails, while str input is routed to the text stream instead.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** Changing Windows console stream write behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e1a61473720927cb0d13351b.md)

## Rule

- **Rule:**
  ```text
  _is_console must return False when the stream lacks fileno or raises OSError/io.UnsupportedOperation, and otherwise probe GetConsoleMode, guarding Windows console detection against non-file streams.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  when modifying _is_console or Windows console detection logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fa4e1678a5b0a1258e16dc22.md)

## Rule

- **Rule:** When modifying Windows console text output, preserve the utf-16-le strict line-buffered non-closing wrapper contract for the console writer.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** Changing Windows console text stream creation or encoding behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fa5d3e230757796c3ea1945a.md)
