# Constraints for `src/click/decorators.py`

## Rule

- **Rule:**
  ```text
  The pass-context decorator wrapper must call f(get_current_context(), *args, **kwargs), injecting the context as the first positional argument before any user arguments.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When modifying the pass-context decorator wrapper or any context-injection decorator that must preserve argument ordering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0a96e29cb780c9f131878f90.md)

## Rule

- **Rule:**
  ```text
  When modifying version_option, it must continue to detect the package name by inspecting stack frames when version and package_name are omitted, normalizing __main__ to __package__ and taking the top-level package; it must set is_flag, expose_value=False, is_eager, and a default help message, and raise RuntimeError if version cannot be detected.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When changing version_option or its package/version detection logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0bfbc8a3f6a6d1bdb12aad53.md)

## Rule

- **Rule:**
  ```text
  When modifying pass_obj or similar decorators, preserve that only `Context.obj` is passed to the wrapped function and that metadata is preserved via `update_wrapper`.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  Changing pass_obj or adding a decorator that injects context-derived values into a wrapped function.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3038cdd6315ed732abc9e35c.md)

## Rule

- **Rule:**
  ```text
  When a decorator is built with make_pass_decorator(..., ensure=True), invoking it must create and store a new instance of the requested type on the context when that type is absent, so the decorator mutates context state rather than only reading it.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  Modifying make_pass_decorator or the decorators it returns, especially the ensure=True path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-49a0a70ed036596e0eb760a3.md)

## Rule

- **Rule:**
  ```text
  confirmation_option must default param_decls to ('--yes',) and set is_flag=True, callback, expose_value=False, prompt 'Do you want to continue?', and help text, so the confirmation flag is not exposed to the command callback.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When modifying confirmation_option or its option defaults, preserve the ('--yes',) param_decls, is_flag=True, callback, expose_value=False, prompt, and help text so the flag stays hidden from the callback.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4f6862ab1c9f7a272bd1761a.md)

## Rule

- **Rule:**
  ```text
  pass_meta_key must build the decorator's docstring dynamically from doc_description, defaulting to a description of the Context.meta key; changing the default wording or generated docstring format is API-visible.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When modifying pass_meta_key or the docstring generation for decorators created through this helper.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-656232f85c768ea6affedd66.md)

## Rule

- **Rule:** The option decorator must forward all keyword arguments unchanged to the parameter class constructor except cls, and must default cls to Option when not supplied, preserving this as the documented extension point for custom option classes.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When modifying the option decorator or adding custom option classes that rely on keyword forwarding and the default cls.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-873b6526cbe1880e1420012f.md)

## Rule

- **Rule:**
  ```text
  When modifying the help option or its registration, preserve the standard configuration: param_decls default `("--help",)`, `is_flag=True`, `expose_value=False`, `is_eager=True`, help text "Show this message and exit.", and callback `show_help`.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  Changing the help_option decorator or the default help option it registers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-93e95a8bf68b270866b95fa4.md)

## Rule

- **Rule:**
  ```text
  When modifying the group decorator, it must continue to support being applied without parentheses: if the first argument is callable it is treated as the decorated function, otherwise command(name, cls, **attrs) is returned.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When changing the group decorator or its argument handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9e4531d346add5b2d26ce7f9.md)

## Rule

- **Rule:** When modifying the argument decorator, preserve that it defaults cls to Argument when not provided and forwards all other keyword arguments unchanged to the parameter class constructor, establishing the extension contract for custom argument classes.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** Changing the argument decorator's cls default or keyword forwarding.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aebef0e06f64f1fda09c2010.md)

## Rule

- **Rule:** When modifying the group decorator, preserve the typing overload that returns a callable producing the specified GrpType when cls is provided, documenting the expected static type for the named form.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** Changing the group decorator's typing overloads or cls handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cfa325b912713ef06e0d13eb.md)

## Rule

- **Rule:** decorators.py must document and support the @command/@group call variants: no-call direct decorator, positional name with positional or keyword cls, name omitted with cls as keyword-only, and optional string name with no cls.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** Modifying the @command/@group decorator signatures or their documented call variants.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d4e74bc09025f1f47f3603b7.md)

## Rule

- **Rule:** The command decorator must provide an overload requiring cls as a keyword-only argument and returning a callable that produces CmdType, establishing the typed contract for custom command classes.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** when modifying the command decorator's overloads or its cls keyword-only parameter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ea266a94e09a6ff33d1a13c9.md)

## Rule

- **Rule:** When modifying the group decorator, preserve the typing overload accepting a name and returning a decorator that produces a Group, documenting the expected static type for the named form.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** Changing the group decorator's named-form typing overload.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eba8b1c5350a2595e5a46a46.md)

## Rule

- **Rule:** Eager boolean flag callbacks must abort the context when the value is false, terminating parsing rather than continuing with a false flag.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  when modifying eager boolean flag callbacks such as confirmation_option.callback
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ffc3becd9e228f99c34ea849.md)
