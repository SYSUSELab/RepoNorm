# Constraints for `src/click/core.py`

## Rule

- **Rule:**
  ```text
  When modifying Parameter, its documented compatibility boundaries must be preserved: deprecated parameters cannot be required (ValueError otherwise), duplicate parameter names warn since 8.2, process_value validates required/bounded nargs and invokes callbacks since 8.0, autocompletion is renamed to shell_complete, and empty env vars are ignored since 7.1.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Parameter or its documented compatibility behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0f594f230677e8826eeca692.md)

## Rule

- **Rule:**
  ```text
  When modifying parameter processing order, preserve the sort key that places eager parameters first and otherwise keeps the recorded invocation_order, with unrecorded parameters sorted last.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing how parameters are ordered for processing or invocation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2062a551f21b10497a151717.md)

## Rule

- **Rule:** Tuple-typed argument conversion must convert each element of the iterable through self.type with the parameter and context and return a tuple.
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Parameter.type_cast_value or the tuple conversion path, preserve per-element conversion through self.type with parameter/context and tuple return.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2387e20a7990c8d4afc8a37a.md)

## Rule

- **Rule:**
  ```text
  When modifying Group.shell_complete, subcommand completion must remain additive: visible subcommands contribute CompletionItems (using each command's short help) and the parent implementation's completions are then extended, not replaced.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Group.shell_complete or the completion behavior of a group command.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2eb8c532eb504e7a58e1d0f3.md)

## Rule

- **Rule:**
  ```text
  batch must use zip with repeat and strict=False so the final batch may be shorter than batch_size rather than raising on length mismatch.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying the batch helper's iteration or length-handling logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2ef8e2df620c29e334c55bf8.md)

## Rule

- **Rule:**
  ```text
  When adding or modifying the `group` decorator overload, preserve the typing overload that returns a decorator producing a Group, documenting the expected static type when `group` is used as a decorator.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing the Group.group method or its typing overloads.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-375f96bd0f7184e7a47034a8.md)

## Rule

- **Rule:**
  ```text
  check_iter must wrap _check_iter and convert TypeError into BadParameter('Value must be an iterable.'), since this should only occur when args are passed manually rather than parsed from the command line.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying parameter type casting or iterable validation error handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4dcf9e567c31b3954213781a.md)

## Rule

- **Rule:** Custom ParamType subclasses must implement convert(self, value, param, ctx) accepting param and ctx as keyword arguments, because parameter conversion invokes the type as self.type(value, param=self, ctx=ctx).
- **Applies to:**
  - `src/click/core.py`
  - `src/click/types.py`
- **Condition:** When adding or modifying a ParamType subclass or its convert method.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5358ac37e684c38b93bbe801.md)

## Rule

- **Rule:**
  ```text
  When a parameter's arity or required-ness is inferred or validated, the declared nargs and default must be honored: Tuple.convert must reject a value count that differs from the declared type count, and Argument.__init__ must infer required from default/nargs and reject a default combined with nargs=-1 under __debug__.
  ```
- **Applies to:**
  - `src/click/core.py`
  - `src/click/types.py`
- **Condition:** Modifying parameter construction or value conversion that infers required-ness or validates tuple arity.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-59cbb1a124c938d7e02d59e8.md)

## Rule

- **Rule:**
  ```text
  make_metavar must return self.metavar when set, otherwise derive from type.get_metavar or the uppercased name, append '!' when deprecated, wrap in brackets when not required, and append '...' when nargs != 1.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Argument.make_metavar or metavar formatting, preserve the explicit-metavar override, type-derived/uppercased fallback, deprecation '!' suffix, non-required bracket wrapping, and nargs '...' suffix.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7d55ab58833ed91c15b54bbc.md)

## Rule

- **Rule:**
  ```text
  When changing how a parameter's default value is resolved, preserve the precedence: `ctx.lookup_default` is consulted before the parameter's own default, and the default is only invoked when `call=True`; do not add type casting to default retrieval.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Parameter.get_default or any code path that resolves a parameter's default value.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7e2ca7e31d5f010a0c20b784.md)

## Rule

- **Rule:**
  ```text
  When modifying command classes, preserve _BaseCommand as a deprecated compatibility shim (deprecated since 8.2, scheduled for removal in Click 9.0) that directs users to Command; do not remove it before the 9.0 boundary.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing or removing deprecated command base classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7ff21a0fafda4c89fb6b432d.md)

## Rule

- **Rule:**
  ```text
  When modifying command resolution, preserve that resolve_command applies ctx.token_normalize_func to the command name when the initial lookup fails, and when the command is still missing and parsing is not resilient, it re-parses args if the first token looks like an option before failing with a no-such-command error.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing command lookup or fallback resolution behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-92c9d39f3687d6514913bef6.md)

## Rule

- **Rule:**
  ```text
  When modifying parameter shell completion, preserve that Parameter.shell_complete uses a custom shell_complete function if provided, wrapping plain string results into CompletionItem, otherwise delegating to self.type.shell_complete.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing parameter-level shell completion dispatch.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-975e95fdbafd5183dc13cdae.md)

## Rule

- **Rule:**
  ```text
  Group.format_options must call super().format_options then format_commands so group help output includes commands after the base option formatting.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying group help formatting or the ordering of options and commands in help output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a63a802b4cc0d19a56da5f59.md)

## Rule

- **Rule:**
  ```text
  When a parameter's envvar value is read, split it via type.split_envvar_value only when nargs != 1; single-value parameters must bypass splitting so the raw envvar string is used directly.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Parameter.value_from_envvar or envvar value handling for parameters with nargs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-be35f6065ff452bc23cfe70c.md)

## Rule

- **Rule:**
  ```text
  Parameter.value_is_missing must treat None as missing, and must treat an empty tuple as missing only when nargs != 1 or multiple is set; other empty/None-like values must not be reported as missing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Parameter.value_is_missing or the parameter value-handling path that decides whether a supplied value counts as absent.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bf27bbaa7b895fd9310e7fb2.md)

## Rule

- **Rule:**
  ```text
  iter_params_for_processing must reorder declared parameters by invocation order and eagerness, with invocation order taking precedence over declaration order, affecting callback evaluation order.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying parameter processing order or callback evaluation order.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c9e8fbb0762b5b45b808c1e7.md)

## Rule

- **Rule:**
  ```text
  Argument must remain a positional parameter that is required by default, can have infinite nargs, and reports param_type_name 'argument', distinguishing argument defaults from option defaults.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Argument or the defaults and param_type_name that distinguish arguments from options.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d13c7f62497c5f316c668486.md)

## Rule

- **Rule:** CommandCollection must remain a Group subclass that looks up subcommands first on itself then on each source group in order, without merging source parameters or invoking source callbacks, effectively flattening commands.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Modifying CommandCollection or its subcommand lookup and source-group handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fccbe986abaf237a6e993818.md)
