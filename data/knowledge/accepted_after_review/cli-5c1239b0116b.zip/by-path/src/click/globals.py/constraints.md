# Constraints for `src/click/globals.py`

## Rule

- **Rule:**
  ```text
  When a command's output or error display is rendered, the color decision must flow through the active context's color setting (ctx.color) rather than a hard-coded or independently resolved value, so that resolve_color_default's explicit-argument override and context lookup remain the single source of truth.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
  - `src/click/globals.py`
- **Condition:** Modifying color resolution or error/output rendering so that a rendered message or stream color is chosen.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3c86a9ab05ba73426846f52f.md)
