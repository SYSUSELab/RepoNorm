# Constraints for `src/click/_compat.py`

## Rule

- **Rule:**
  ```text
  _find_binary_reader must return the stream itself when it is already a binary reader, otherwise the stream's buffer when that buffer is a binary reader even if closed, and None when neither applies.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying _find_binary_reader's resolution order or closed-buffer handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0509777478db4ba9cc4ee603.md)

## Rule

- **Rule:**
  ```text
  The stream wrapper constructor must store force_readable and force_writable flags alongside the wrapped stream, establishing the internal state used to override stream capability detection.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying the stream wrapper constructor or capability-override logic that reads force_readable/force_writable.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0fb11479e93129c68d450a3e.md)

## Rule

- **Rule:**
  ```text
  _is_binary_reader must determine binary-ness by calling stream.read(0) and checking for bytes, swallowing any exception and returning the caller-supplied default, so detection tolerates streams that raise on zero-length reads.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying _is_binary_reader or stream capability detection that must tolerate streams raising on zero-length reads.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-19250a4bee3b097540e5d0dc.md)

## Rule

- **Rule:**
  ```text
  When modifying get_binary_stdin, it must continue to raise RuntimeError when no binary reader can be determined for sys.stdin, making binary stdin availability a hard precondition rather than returning None.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing get_binary_stdin or binary stdin detection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-22986b8bb9fcdcd7cb9b3e65.md)

## Rule

- **Rule:**
  ```text
  _AtomicFile.__getattr__ must delegate attribute access to the wrapped file object, making the wrapper transparent for arbitrary attributes.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying _AtomicFile.__getattr__ or the wrapper's attribute delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-23f76373bee29ac46482a549.md)

## Rule

- **Rule:**
  ```text
  The stream wrapper constructor must wrap the given binary stream with _FixupStream using force_readable and force_writable flags before passing it to the superclass, applying read/write fixups at construction time.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When modifying the stream wrapper constructor or its fixup flags.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2f5b5f68dd94c1179b64fbe0.md)

## Rule

- **Rule:**
  ```text
  Binary stream resolution such as get_binary_stderr must raise RuntimeError when no binary writer can be determined for sys.stderr, defining the failure contract for binary stream resolution.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying get_binary_stderr or binary stream resolution logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-388895ea1fbd774b91e7d9a5.md)

## Rule

- **Rule:**
  ```text
  When modifying _make_text_stream, preserve the default errors='replace' and line_buffering=True behavior when wrapping a binary stream.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Changing _make_text_stream defaults or binary stream wrapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-598de3dbc4038d6f9d37e7b2.md)

## Rule

- **Rule:**
  ```text
  When modifying _AtomicFile.__repr__, it must continue to delegate to repr(self._f), exposing the underlying file's representation.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing _AtomicFile.__repr__ or wrapper representation behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6736e9231639eea61377059d.md)

## Rule

- **Rule:**
  ```text
  When modifying `_is_binary_writer`, preserve the probe strategy: write `b""` to detect binary streams, fall back to writing `""` to detect text streams, and return the provided default when both probes fail.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Changing _is_binary_writer or the binary/text stream detection probes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-70b9f18c02f2e9a8fa76e727.md)

## Rule

- **Rule:**
  ```text
  When modifying `_FixupStream.writable`, preserve the fallback order: return True immediately when `_force_writable` is set, otherwise delegate to the stream's `writable` method if present, and otherwise probe by writing an empty bytes value, returning False if that raises.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Changing _FixupStream.writable or the writability-detection fallback logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8929f7ec31253f3dd218c40c.md)

## Rule

- **Rule:**
  ```text
  When modifying _compat.isatty, it must continue to return stream.isatty() but catch any Exception and return False, so TTY detection never raises.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing _compat.isatty or TTY detection behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8ce6b74c79613b3c6ea0d793.md)

## Rule

- **Rule:**
  ```text
  open_stream must treat filename '-' as a standard stream, ignore the atomic flag for standard streams, and reject atomic mode with 'a' or 'x' or without 'w' via ValueError; atomic writes use a temp file with O_EXCL and preserve permissions.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When modifying stream opening, atomic write behavior, or standard-stream handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9cd9b73288ba21dcad891c2c.md)

## Rule

- **Rule:**
  ```text
  ANSI wrapper caching such as auto_wrap_for_ansi must cache colorama wrappers per stream in _ansi_stream_wrappers, return cached wrappers when present, and tolerate cache lookup/store failures silently.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying auto_wrap_for_ansi or ANSI stream wrapper caching.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a83a9d8643418f3ef7f42bdd.md)

## Rule

- **Rule:**
  ```text
  When modifying ANSI-wrapped writes, preserve that `_safe_write` wraps the write call and, on any BaseException, resets all ANSI state via `ansi_wrapper.reset_all()` before re-raising, so terminal styling is not left active after a failed write.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Changing _safe_write or the ANSI-wrapped write path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b32f7700d19b30561efc6142.md)

## Rule

- **Rule:**
  ```text
  When modifying stream compatibility helpers, preserve that `_force_correct_text_writer` delegates to `_force_correct_text_stream` with the binary-writer detection and lookup helpers, so writer correction shares the same stream-wrapping logic as reader correction.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Changing _force_correct_text_writer or the shared stream-wrapping logic used by reader/writer correction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e050438c237b966962828101.md)

## Rule

- **Rule:**
  ```text
  Encoding checks such as is_ascii_encoding must return False on LookupError and otherwise compare codecs.lookup(encoding).name to 'ascii', so unknown encodings are handled safely.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When modifying or adding encoding detection helpers in click's compatibility module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e9faac90914fda6dbe9ea1e4.md)

## Rule

- **Rule:**
  ```text
  When converting or wrapping text streams, _force_correct_text_stream must return a compatible text stream as-is unless encoding is None and the stream is misconfigured, fall back to the original text stream when no binary reader can be found, and default errors to "replace" when errors is None.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** Modifying text-stream compatibility handling or encoding/errors defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eb1eb48d319104088e67a0e5.md)
