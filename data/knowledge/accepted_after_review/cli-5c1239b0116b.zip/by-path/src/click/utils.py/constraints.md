# Constraints for `src/click/utils.py`

## Rule

- **Rule:**
  ```text
  When LazyFile is represented, __repr__ must return repr of the underlying file when opened, otherwise a synthetic "<unopened file 'name' mode>" string using format_filename, so repr is stable before the file is opened.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** Modifying LazyFile representation or its pre-open state handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-07f8283781f6ec329ffaaee4.md)

## Rule

- **Rule:**
  ```text
  get_binary_stream must raise TypeError with the unknown name when the requested stream name is not one of the registered standard streams.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying standard stream lookup or adding/removing registered stream names.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-31848f8f3e6b8fc32ed2e086.md)

## Rule

- **Rule:**
  ```text
  When resolving platform-specific application directories, get_app_dir must return APPDATA/LOCALAPPDATA on Windows, ~/Library/Application Support on darwin, XDG_CONFIG_HOME or ~/.config on Unix, and a dot-prefixed home directory when force_posix is set.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  Modifying platform-specific config directory resolution or the force_posix override.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-34edc149fceb5b7924505248.md)

## Rule

- **Rule:** PacifyFlushWrapper must suppress BrokenPipeError from .flush() during interpreter shutdown/final-GC on sys.stdout/sys.stderr while proxying all other calls and attributes to minimize impact on unrelated cleanup.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying stream wrappers or shutdown/final-GC flush handling for standard streams.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-598070ba844e1f29529100d9.md)

## Rule

- **Rule:**
  ```text
  The lazy file wrapper's __getattr__ must delegate attribute access to the wrapped stream so wrapped file attributes remain accessible through the wrapper.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying the lazy file wrapper's __getattr__ delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6e1f9f4de6cc600e98d73ec2.md)

## Rule

- **Rule:**
  ```text
  LazyFile.__getattr__ must delegate attribute access to self.open() so attributes are resolved lazily through the opened stream; contributors must account for this delegation when adding attributes.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When adding attributes or modifying attribute access on the lazy file wrapper.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7267aa0a92a6b18b7e21df3f.md)

## Rule

- **Rule:**
  ```text
  When modifying KeepOpenFile.__enter__, preserve that it returns self so the object itself is the context-manager value.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** Changing KeepOpenFile context manager behavior or entered value.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-732476d77449e39ee8c67bc8.md)

## Rule

- **Rule:**
  ```text
  make_default_short_help must consider only the first paragraph, strip a leading \b no-rewrap marker, truncate at a sentence-ending period without adding '...', and otherwise remove trailing words until the result plus '...' fits within max_length.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying make_default_short_help or short help text generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7609bdbb913f60b9ec3a07cb.md)

## Rule

- **Rule:**
  ```text
  When modifying Windows argument expansion, preserve that _expand_args simulates Unix shell expansion on Windows; since 8.1 invalid glob patterns are treated as empty expansions rather than raising, and unmatched args are kept as-is.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** Changing Windows argument expansion or glob handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-81eade044616fc064a2a6883.md)

## Rule

- **Rule:**
  ```text
  LazyFile must open its underlying file lazily: __iter__ opens the file before returning an iterator, and __exit__ delegates to close_intelligently so context-manager exit only closes files the wrapper opened and never closes externally supplied streams such as stdin.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying LazyFile iteration or context-manager exit behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-94b1f11f12c179b056de83db.md)

## Rule

- **Rule:**
  ```text
  LazyFile.open must wrap OSError raised by open_stream into click.FileError carrying the file name and strerror hint, so callers never see a raw OSError from lazy file opening.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  Modifying LazyFile.open or the error path around open_stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b6da056c11becd9fa4131049.md)

## Rule

- **Rule:** The wrapper class must store the wrapped IO object in a public wrapped attribute, exposing the underlying stream for callers.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying PacifyFlushWrapper or similar IO wrapper classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-df30ed019895a49f489de8ed.md)
