# Constraints for `src/click/testing.py`

## Rule

- **Rule:**
  ```text
  EchoingStdin.__repr__ must return repr of its internal _input, exposing the input value in representations.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  when modifying EchoingStdin.__repr__ or its internal _input representation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-04fa76ceecbd29954a611f80.md)

## Rule

- **Rule:**
  ```text
  CliRunner.__init__ must default to charset="utf-8", echo_stdin=False, and catch_exceptions=True, and must normalize a None env mapping to an empty dict.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying CliRunner.__init__ or its default configuration.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c459f4bd38087c2b11fd6f1.md)

## Rule

- **Rule:** Result.output must remain an independent stream that interleaves stdout and stderr in write order, decoded with the runner charset and with CRLF normalized to LF; it must not be redefined as a stdout-only proxy.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When modifying Result.output or the CliRunner stream capture that feeds it, preserve the mixed stdout/stderr write-order stream and charset/CRLF normalization rather than reverting to a stdout-only view.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2089272fd40280a5c0da167a.md)

## Rule

- **Rule:**
  ```text
  When the test runner decides whether to strip ANSI codes, should_strip_ansi must return not default_color when color is None, otherwise not color, so the default color decision is preserved.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Modifying the test runner's ANSI-stripping decision or its color default handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-332440a1825df4855d11c74e.md)

## Rule

- **Rule:**
  ```text
  The EchoingStdin wrapper must apply the _echo transformation to data returned by the wrapped stream's read and readlines methods, so reads are subject to the same echo transformation as writes.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying EchoingStdin.read, EchoingStdin.readlines, or the _echo transformation they apply.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-424be1714150071159a3a6b5.md)

## Rule

- **Rule:**
  ```text
  The mode property must return the stored _mode attribute, exposing the mode passed at construction.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying _NamedTextIOWrapper.mode or similar stream wrapper properties.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4a72a0c01a067f79ef6bd65f.md)

## Rule

- **Rule:**
  ```text
  When modifying EchoingStdin.read1, it must continue to delegate to self._input.read1(n) and pass the result through self._echo, so reads from the testing input stream are echoed.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When changing EchoingStdin.read1 or testing input stream echo behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-500df2a87f95bee66ba5a8e3.md)

## Rule

- **Rule:**
  ```text
  _pause_echo must set _paused=True on the echoing stdin stream before yielding and reset it to False afterward, so the pause state is scoped to the context manager body.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying _pause_echo or the pause-state handling of the echoing stdin stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-58fa013d4c70184592c6f7f1.md)

## Rule

- **Rule:**
  ```text
  CliRunner.make_env must copy the runner's base environment and overlay caller-provided overrides, so per-invocation env changes never mutate the runner's stored base environment.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying CliRunner.make_env or how invocation environments are assembled.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-602ce3b9d689c409a0613e86.md)

## Rule

- **Rule:**
  ```text
  CliRunner.get_default_prog_name must return cli.name or 'root' when unset, defining the default program name used in test invocations.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying CliRunner.get_default_prog_name or the default program name used in test invocations.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-689722a3db41994c7f77b030.md)

## Rule

- **Rule:**
  ```text
  Result objects must expose stderr_bytes as non-optional, provide output_bytes, and not expose mix_stderr, reflecting the 8.2 compatibility boundary for code consuming captured CLI results.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When modifying the Result class or captured CLI result attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6b99608a03bc75746c425731.md)

## Rule

- **Rule:**
  ```text
  BytesIOCopy.__init__ must store the provided copy_to BytesIO as the copy target used when capturing output in CliRunner.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying BytesIOCopy.__init__ or the copy target used by CliRunner output capture.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6f00bf7057591eec8f94bde7.md)

## Rule

- **Rule:** When StreamMixer is used, it must mix stdout and stderr streams with the combined result available in the output attribute, as documented for version 8.2.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Modifying StreamMixer's stream-mixing behavior or its output attribute.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-74d449e958e2d025818f454a.md)

## Rule

- **Rule:**
  ```text
  EchoingStdin.__iter__ must yield bytes produced by applying _echo to each element of _input, defining the byte-level iteration contract for simulated stdin.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying EchoingStdin.__iter__ or the simulated-stdin iteration path used by CliRunner.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9075c6ecf22f9538ac5926ec.md)

## Rule

- **Rule:**
  ```text
  When the testing harness simulates hidden input, hidden_input must write the prompt plus a newline to stdout and return the next line from the scripted text input with trailing CR/LF stripped.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Modifying the testing harness's hidden-input simulation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-93e339416019365735be5890.md)

## Rule

- **Rule:**
  ```text
  When modifying CliRunner interactive prompt simulation, preserve that visible_input writes the prompt to stdout, reads the next input line stripping CR/LF, echoes the value, and flushes.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Changing how CliRunner simulates interactive prompt input.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a14f75719a5bb5d3e7c33c3f.md)

## Rule

- **Rule:**
  ```text
  The testing shim's _getchar must read one char from sys.stdin, optionally echo it to stdout, flush, and return it, wrapped with _pause_echo.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying the testing shim's _getchar or the simulated stdin character-reading path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a1b5315c78cdf1b99fe435cd.md)

## Rule

- **Rule:** When modifying the testing echo helper, preserve that pausing suppresses output while still returning the value.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Changing the testing echo helper's pause or output behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-abf7d304934349ac544e0db5.md)

## Rule

- **Rule:**
  ```text
  CliRunner.invoke must preserve its versioned result-object contract: since 8.2 the result has output_bytes mixing stdout and stderr and always returns stderr_bytes; since 8.0 it has return_value; since 3.0 it has exc_info; a string args is treated as a Unix shell command via shlex.split; and non-integer SystemExit codes are normalized to exit code 1 after writing the code to stdout.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When modifying CliRunner.invoke or the result object it returns, including argument handling and SystemExit normalization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bc6d2d7d34a46b6ab095ac2c.md)

## Rule

- **Rule:**
  ```text
  When modifying the testing Result representation, preserve that Result.__repr__ formats as <ClassName exception-or-okay>, using repr of the exception when present and the literal "okay" otherwise.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Changing the string representation of a testing Result.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bdd7e526e620972a2bc83854.md)

## Rule

- **Rule:**
  ```text
  When modifying the testing input wrapper, preserve that __getattr__ forwards unknown attributes to _input, transparently exposing the underlying input stream API.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Changing the testing input wrapper's attribute access behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c49876e606b752ed90c69a95.md)

## Rule

- **Rule:**
  ```text
  CliRunner's Result.stdout must decode stdout_bytes using the runner charset with 'replace' errors and normalize CRLF to LF, defining the text output contract that tests rely on.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying Result.stdout or the runner's output decoding behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d1961af689f198aed7abd33a.md)
