# Constraints for `src/click/formatting.py`

## Rule

- **Rule:**
  ```text
  When modifying wrap_text paragraph flushing, preserve that a paragraph whose first stripped line is `\b` is treated as a preformatted block (remaining lines joined by newlines with a True flag), while other paragraphs are joined with spaces and a False flag.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Changing wrap_text or its paragraph-flushing helper.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-023180078bdc4f740a0ff2b5.md)

## Rule

- **Rule:**
  ```text
  wrap_text must use a custom TextWrapper with replace_whitespace=False and, when preserve_paragraphs is set, treat a paragraph prefixed with a line containing \b (\x08) as raw and not rewrapped, preserving indentation via extra_indent.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When modifying text wrapping or paragraph preservation behavior in the formatting module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-556214a4d5925c50b96c1eb2.md)

## Rule

- **Rule:**
  ```text
  write_text must re-indent and rewrap text using the formatter width with preserve_paragraphs=True, then append a newline, so paragraph structure is preserved in help output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Modifying HelpFormatter.write_text or help text wrapping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-75c2884041416bf872840adf.md)

## Rule

- **Rule:**
  ```text
  write_heading must write the heading indented to the current indent level followed by a colon and newline, defining the exact heading format in help output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Modifying HelpFormatter.write_heading or the heading format in help output.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9283e4021318383eb9bd09a0.md)

## Rule

- **Rule:**
  ```text
  When modifying HelpFormatter.write_usage, preserve the layout rule: right-align the prefix to current_indent, and only place arguments on the same line when the remaining text width is at least the prefix length plus 20; otherwise write the prefix, a newline, and indent arguments by max(current_indent, term_len(prefix)) + 4.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Changing HelpFormatter.write_usage or the usage-line wrapping logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b196fb4668daab505ab31945.md)

## Rule

- **Rule:**
  ```text
  When modifying measure_table, it must continue to compute per-column maximum term_len widths and return them in column order, defining the table-width measurement used by formatting.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When changing measure_table or table-width measurement used by formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b97b28ffd004d015ca9abf65.md)

## Rule

- **Rule:**
  ```text
  HelpFormatter.write_paragraph must only emit a newline when the buffer is non-empty, preventing a leading blank line in formatted output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  when modifying HelpFormatter.write_paragraph or the paragraph formatting logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d56eabad827dea71a6c760d0.md)

## Rule

- **Rule:**
  ```text
  HelpFormatter width must default to terminal columns capped by max_width (default 80) minus 2, with a minimum of 50, unless FORCED_WIDTH is set.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Modifying HelpFormatter.__init__ or the help formatter width computation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-da63e23367f36c55d2b6ab73.md)

## Rule

- **Rule:**
  ```text
  The module-level FORCED_WIDTH hook in formatting.py must remain available and functional because the test system relies on it to force formatting width.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When modifying formatting width handling or removing module-level formatting hooks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e544b995650e5e8078783bc0.md)

## Rule

- **Rule:** HelpFormatter must write into memory and remain exposed for developers to write custom outputs, with width defaulting to terminal width clamped to a maximum of 78.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** Modifying HelpFormatter or its width defaulting and output-writing behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f86f938436b892a661aa758a.md)
