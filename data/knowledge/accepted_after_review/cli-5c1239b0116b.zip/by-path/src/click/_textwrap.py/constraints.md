# Constraints for `src/click/_textwrap.py`

## Rule

- **Rule:**
  ```text
  TextWrapper.indent_only must apply initial_indent to the first line and subsequent_indent to all later lines, joining with newlines, so indentation differs between the first and remaining lines.
  ```
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:**
  ```text
  When modifying TextWrapper.indent_only or text indentation behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-76e2d365554f323809eea364.md)

## Rule

- **Rule:**
  ```text
  TextWrapper._handle_long_word must compute space_left as max(width - cur_len, 1); when break_long_words is enabled it splits the last chunk, otherwise it only moves the chunk if the current line is empty.
  ```
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:**
  ```text
  When modifying _handle_long_word's space_left computation or break_long_words handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dcf9b3a661a10fcf2f986881.md)
