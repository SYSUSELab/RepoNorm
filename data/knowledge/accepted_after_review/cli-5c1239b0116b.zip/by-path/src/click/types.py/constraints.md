# Constraints for `src/click/types.py`

## Rule

- **Rule:**
  ```text
  Choice.get_invalid_choice_message must build the invalid-choice error via ngettext with singular/plural forms and normalized mapping values so the message stays localized and plural-aware.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing Choice error reporting or choice normalization, keep the invalid-choice message localized through ngettext with plural handling and normalized mapping values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-00d6429191b255be6b98fad1.md)

## Rule

- **Rule:**
  ```text
  When modifying BoolParamType.__repr__, preserve the literal string 'BOOL' as the stable representation.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** Changing BoolParamType representation or help/debug output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0955eb5ca6becf62c1a59f91.md)

## Rule

- **Rule:**
  ```text
  File.to_info_dict must add 'mode' and 'encoding' to the base info dict, defining the serialization contract for file parameters.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Modifying File.to_info_dict or the serialized info dict for file parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a609469c6e2cc90984c7ebe.md)

## Rule

- **Rule:**
  ```text
  When modifying Choice._normalized_mapping, it must remain an internal/unsupported surface: callers should use normalize_choice instead, and the wrapper's documented role is a simple wrapper around normalize_choice.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing Choice._normalized_mapping or its callers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1f2dc689b06bb3dce755f015.md)

## Rule

- **Rule:** UNPROCESSED is a dummy parameter type that performs no string conversion when input is bytes, distinguishing it from STRING and making it useful for byte-or-unicode file path values.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying UNPROCESSED or adding byte-preserving parameter types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2425be2d90f17a3d637dc284.md)

## Rule

- **Rule:**
  ```text
  UnprocessedParamType.__repr__ must return the literal string 'UNPROCESSED'.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying UnprocessedParamType or its repr, keep __repr__ returning the literal 'UNPROCESSED'.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-291eb946e178ce537032e572.md)

## Rule

- **Rule:**
  ```text
  When modifying ParamType.shell_complete, preserve that the default returns an empty list so custom types opt into completion by overriding it.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Changing ParamType.shell_complete default behavior or completion opt-in.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2b2f3d1f9c154fdf7483f9e5.md)

## Rule

- **Rule:** The arity property of a composite ParamType must equal len(self.types), so composite arity is the number of contained types.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying Tuple.arity or composite ParamType arity, keep arity equal to the number of contained types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-38fc5f02064d2c18575276ca.md)

## Rule

- **Rule:**
  ```text
  When modifying IntParamType, integer parameter behavior must continue to be derived from the shared _NumberParamTypeBase numeric base (name "integer", _number_class int) rather than implemented independently.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing IntParamType or integer parameter behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3bb1ce02553cd14265e02045.md)

## Rule

- **Rule:**
  ```text
  When modifying the Choice type, preserve that Choice accepts any iterable of choices (converted to a tuple and iterated once), supports non-str choices since 8.2.0, allows normalization overrides via normalize_choice, and always returns a value that is one of the originally passed choices.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** Changing Choice construction, normalization, or conversion behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3defc0d434245941d78ae986.md)

## Rule

- **Rule:** When the datetime type is used without explicit formats, it must default to the three accepted input shapes: date-only, ISO datetime with T separator, and space-separated datetime.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** Modifying DateTime format defaults or accepted input shapes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4582b1d759040ee7d8ce1a20.md)

## Rule

- **Rule:**
  ```text
  When modifying StringParamType.__repr__, it must continue to return the literal string "STRING", providing a stable representation for the string parameter type.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing StringParamType.__repr__ or string parameter type representation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-47eff06e0da0150ced62b043.md)

## Rule

- **Rule:** Lazy file resolution must return the explicit lazy setting when set, disable lazy for '-' (stdout), and enable lazy when the mode contains 'w', defining lazy behavior for write modes.
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying File.resolve_lazy_flag or file type lazy behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4f83ba9c531c2bc134c3e428.md)

## Rule

- **Rule:**
  ```text
  Choice.get_metavar must build a '|'-joined choices string, deduplicating type names for options without show_choices, and wrap it in curly braces for required arguments or square brackets otherwise.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  when modifying Choice.get_metavar or the metavar formatting for choice parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-51fc7aca58e5c157d2ad4f94.md)

## Rule

- **Rule:** Custom ParamType subclasses must implement convert(self, value, param, ctx) accepting param and ctx as keyword arguments, because parameter conversion invokes the type as self.type(value, param=self, ctx=ctx).
- **Applies to:**
  - `src/click/core.py`
  - `src/click/types.py`
- **Condition:** When adding or modifying a ParamType subclass or its convert method.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5358ac37e684c38b93bbe801.md)

## Rule

- **Rule:** UUID parameter conversion must return existing uuid.UUID values unchanged, strip whitespace before parsing, and raise a BadParameter-style error with the message '{value!r} is not a valid UUID.' on ValueError.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying UUIDParameterType.convert or adding similar identifier parameter types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-55c4b5c67160d4db66d9c98c.md)

## Rule

- **Rule:**
  ```text
  When a parameter's arity or required-ness is inferred or validated, the declared nargs and default must be honored: Tuple.convert must reject a value count that differs from the declared type count, and Argument.__init__ must infer required from default/nargs and reject a default combined with nargs=-1 under __debug__.
  ```
- **Applies to:**
  - `src/click/core.py`
  - `src/click/types.py`
- **Condition:** Modifying parameter construction or value conversion that infers required-ness or validates tuple arity.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-59cbb1a124c938d7e02d59e8.md)

## Rule

- **Rule:**
  ```text
  A range type's __repr__ must include the range description and append ' clamped' when self.clamp is set.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying _NumberRangeBase.__repr__ or range representation, preserve inclusion of the range description and the ' clamped' suffix when clamp is set.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6000ded18131c2255edbfff7.md)

## Rule

- **Rule:**
  ```text
  When modifying FloatRange._clamp, it must continue to raise RuntimeError('Clamping is not supported for open bounds.') for open bounds, explicitly leaving open float range clamping to a user callback.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing FloatRange._clamp or float range clamping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-700ee4e10eb6ff883fc40cba.md)

## Rule

- **Rule:** Numeric conversion must catch ValueError from the number class and route it through self.fail with a localized message naming the value and number type, so invalid numeric input produces a parameter failure rather than a raw ValueError.
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying _NumberParamTypeBase.convert or numeric parsing, preserve catching ValueError and routing through self.fail with a localized message naming the value and number type.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8341b95d190c8b4ef52d9e80.md)

## Rule

- **Rule:**
  ```text
  CompositeParamType must set is_composite = True to mark the base class for parameter types composed of multiple values.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When adding or modifying composite parameter types or their base class marker.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-917ac8ddfbc8fdf0bc70eaa1.md)

## Rule

- **Rule:**
  ```text
  to_info_dict for a type with formats must extend the superclass info dict by adding a 'formats' key, defining the info-dict extension contract for format-bearing types.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying to_info_dict for a format-bearing type or adding a new type that must expose formats in its info dict.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9245f321b6ff932999317806.md)

## Rule

- **Rule:**
  ```text
  Choice.__init__ must eagerly convert the choices iterable to a tuple and store case_sensitive, so later membership checks operate on a stable sequence rather than a one-shot iterable.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Choice.__init__ or choice storage, preserve eager tuple conversion of choices and storage of case_sensitive for stable membership checks.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-99345ff620d3be42da72f072.md)

## Rule

- **Rule:**
  ```text
  Date parsing helpers such as DateTime._try_to_convert_date must return None on ValueError rather than raising, so that invalid date strings fall through to alternative parsing paths.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying or adding date parsing logic in click's type conversion module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9a6bbf2cb4259a98f7fdc87c.md)

## Rule

- **Rule:**
  ```text
  FloatRange documents that open boundaries are incompatible with clamping, and min_open/max_open were added in version 8.0, establishing a compatibility boundary for range type behavior.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying FloatRange or adding open-boundary range options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a453191901c5417e1808fbcb.md)

## Rule

- **Rule:** When modifying file-like detection, preserve the duck-typing boundary that treats any object with a read or write attribute as file-like.
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Changing _is_file_like or file-like detection logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bcc0f227a92f3beaa971c713.md)

## Rule

- **Rule:**
  ```text
  Float parameter range types must keep min, max, min_open, max_open, and clamp as public attributes set in __init__, because range validation and clamping behavior is configured through these attributes.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying the float range parameter type's constructor or its range/clamp configuration attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-be1ed5f532b26bca99c9f08f.md)

## Rule

- **Rule:**
  ```text
  When modifying Choice.convert, preserve normalization via normalize_choice, matching against the normalized mapping, and failing with the invalid-choice message when no match is found.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** Changing Choice.convert normalization or invalid-choice handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d89429077e5e210e70f93dfa.md)

## Rule

- **Rule:**
  ```text
  _clamp must remain an abstract hook raising NotImplementedError so range subclasses implement clamping to open or closed bounds in a given direction.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying range clamping behavior or adding range subclasses that must implement clamping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ddf2fc21db12478009fd6619.md)

## Rule

- **Rule:**
  ```text
  FloatParamType must subclass _NumberParamTypeBase with name 'float' and _number_class float, and its __repr__ must return the literal string "FLOAT".
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when modifying FloatParamType, its base class, name, number class, or repr
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e02d08a6a21bf9253b608c2c.md)

## Rule

- **Rule:**
  ```text
  Choice.to_info_dict must extend the base info dict with 'choices' and 'case_sensitive', establishing the serialization contract for choice parameters.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  when modifying Choice.to_info_dict or the serialized info dict for choice parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e8836ce2e614f14184a64231.md)
