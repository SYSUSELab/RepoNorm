# Constraints for `src/click/termui.py`

## Rule

- **Rule:**
  ```text
  _build_prompt must append Choice choices in parentheses when show_choices is true, and append the formatted default in brackets when show_default is true, before the suffix.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying _build_prompt's choice/default formatting or ordering relative to the suffix.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-14d41392860d1396d3d6c51a.md)

## Rule

- **Rule:**
  ```text
  clear() must return without output when stdout is not a tty, and otherwise emit the ANSI escape sequence \033[2J\033[1;1H without a trailing newline to clear the screen and move the cursor.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** Modifying clear() or terminal clearing behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-274fd81db9e7c9786933df8f.md)

## Rule

- **Rule:** When modifying pause(), preserve that it is a no-op when stdin or stdout is not a TTY, swallows KeyboardInterrupt/EOFError from getchar, and always restores the prompt line via echo in finally.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** Changing pause() terminal interaction or interrupt handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-43d103005895b34f91227c6b.md)

## Rule

- **Rule:**
  ```text
  When modifying termui.edit, preserve the typed overload where text=None returns None and defaults require_save=True and extension='.txt'.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** Changing termui.edit signature, overloads, or defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5b93b609b4ba63594040c189.md)

## Rule

- **Rule:**
  ```text
  unstyle must remove ANSI styling via strip_ansi, and echo already strips styling automatically when necessary.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying unstyle or echo styling behavior, keep unstyle implemented via strip_ansi and preserve echo's automatic styling strip when necessary.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-622da652c451ca859cea80ae.md)

## Rule

- **Rule:**
  ```text
  edit() must return None when filename is provided, ignoring require_save/extension, and since 8.2.0 filename may be any Iterable[str] for editors supporting multiple files.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying edit() or its filename handling, preserve the None return when filename is provided, the ignored require_save/extension in that case, and Iterable[str] filename support for multi-file editors.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6acc1d4ce5f5c2390e621925.md)

## Rule

- **Rule:** confirm() must loop until valid input, accept y/yes and n/no case-insensitively, use the default on empty input when default is not None, raise Abort on KeyboardInterrupt or EOFError, and raise Abort on a negative answer when abort is True.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** When modifying confirm() or adding similar interactive prompt functions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7ba12e19d33b1e9599d45d78.md)

## Rule

- **Rule:**
  ```text
  When progressbar is used with very fast iterators, the update_min_steps parameter must control rendering so that output is only rendered after that many updates complete.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  Modifying progressbar update cadence or the update_min_steps parameter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7e71fb539a63df5ddcca6ef5.md)

## Rule

- **Rule:**
  ```text
  progressbar must keep its typed overload requiring length and returning ProgressBar[int], with defaults fill_char '#', empty_char '-', width 36, and update_min_steps 1.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** When changing the progressbar signature, overloads, or default parameter values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b307b0549ba82e2c266b9303.md)

## Rule

- **Rule:**
  ```text
  When modifying termui.raw_terminal, preserve its lazy delegation to _termui_impl.raw_terminal as a thin public wrapper.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  Changing termui.raw_terminal or its platform-specific implementation delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e2e676448a66dd2d7c2c10c6.md)

## Rule

- **Rule:**
  ```text
  termui must expose a module-level _getchar callable that, when set, replaces getchar() calls, serving as a stable test seam for unittesting purposes.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying termui's getchar usage or the _getchar test seam.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ea32a523d664eb538fc27623.md)

## Rule

- **Rule:**
  ```text
  The edit function's typing overload must default require_save to True and extension to '.txt', defining the public call signature for type checkers.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** When modifying the edit function's typing overload or default parameters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ff39cdb5772739b8a5aa43cf.md)
