# Constraints for `CHANGES.rst`

## Rule

- **Rule:** The flit sdist build includes docs/, tests/, CHANGES.rst, and uv.lock in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `tests/**`
  - `uv.lock`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-05aa953bcf90e341895f2c76.md)

## Rule

- **Rule:** Add an entry in CHANGES.rst summarizing the change and linking to the issue.
- **Applies to:**
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-09da50bbbf77ac13e6327177.md)
