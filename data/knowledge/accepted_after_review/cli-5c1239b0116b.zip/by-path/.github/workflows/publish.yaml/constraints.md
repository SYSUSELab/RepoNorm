# Constraints for `.github/workflows/publish.yaml`

## Rule

- **Rule:** The publish-pypi job publishes packages from the artifact/ directory using pypa/gh-action-pypi-publish.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-29862d795941e7b171ce185e.md)

## Rule

- **Rule:** The build job sets up Python using the version specified in pyproject.toml.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4b70ecb4b44e26050561cd81.md)

## Rule

- **Rule:** The create-release job depends on the build job and runs on ubuntu-latest with contents: write permission.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4dec1154dc09785b9f6caf13.md)

## Rule

- **Rule:** The build job uploads the ./dist directory as an artifact.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-603f43d4973244b59d8d5eb3.md)

## Rule

- **Rule:** The Publish workflow runs on pushes of tags matching any tag.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Condition:**
  ```text
  workflow predicate: push: tags: ['*']
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-669ef8f93d3ca8c19d1149e4.md)

## Rule

- **Rule:** The publish-pypi job depends on the build job, uses the publish environment, and runs on ubuntu-latest with id-token: write permission.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6c4a9edd233f1477370e064b.md)

## Rule

- **Rule:**
  ```text
  The build job runs `uv build` to build the package.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-89e4160b7cc2ac1bfc673096.md)

## Rule

- **Rule:**
  ```text
  The create-release job runs `gh release create --draft` against the repository using the ref name and artifact/* files.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a292a81201c517f81dd23fcb.md)

## Rule

- **Rule:** The build job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ad3cd649301656d6ef416e32.md)
