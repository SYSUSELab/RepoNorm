# Constraints for `.github/workflows/lock.yaml`

## Rule

- **Rule:**
  ```text
  The lock workflow runs on a daily schedule defined by the cron expression '0 0 * * *'.
  ```
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Condition:**
  ```text
  workflow predicate: schedule: - cron: '0 0 * * *'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-08a5fb03173a4bd8ea7a3110.md)

## Rule

- **Rule:** The lock workflow uses the concurrency group 'lock'.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-30638339f1cbaa21da6a1f26.md)

## Rule

- **Rule:** The lock workflow grants write permission to issues, pull-requests, and discussions.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-97ea3d900eb82fcbceb0411c.md)

## Rule

- **Rule:** The lock job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c1bcf1e9ef0da097945d4b9f.md)

## Rule

- **Rule:** The lock job uses the dessant/lock-threads action (v5.0.1) with issue-inactive-days, pr-inactive-days, and discussion-inactive-days all set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e01673eb971b093ef1a613bf.md)
