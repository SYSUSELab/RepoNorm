# Rule details

- **Rule:**
  ```text
  Tests that exercise a Choice with case_sensitive=False must assert that values differing only in case from the declared choices are accepted.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying tests for a Choice option with case_sensitive=False, preserve the assertion that a differently-cased value is accepted.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:550-566`
