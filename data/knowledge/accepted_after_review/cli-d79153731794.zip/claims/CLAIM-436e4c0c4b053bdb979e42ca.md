# Rule details

- **Rule:** When an option's envvar is displayed in help output, the envvar name (e.g. 'ARG1') must appear in the help text.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying envvar help display or its tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:401-409`
