# Rule details

- **Rule:**
  ```text
  Example commands that need custom group lookup or alias resolution must override get_command on a click.Group subclass, rather than modifying the group's command dictionary directly.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example CLI that requires custom group lookup or alias resolution.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/advanced.rst:13-34`
- `examples/aliases/aliases.py:37-68`
