# Rule details

- **Rule:** The gha-update tool configuration lists "slsa-framework/slsa-github-generator" in its tag-only array.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
tag-only = [
    "slsa-framework/slsa-github-generator",
]

```

- **Sources:**
  - `pyproject.toml:100-102`

## Review evidence locations

- `pyproject.toml:100-102`
