# Rule details

- **Rule:** The repo example's clone command declares an optional argument (dest, required=False) that defaults to None and is derived from the last path component of src when omitted.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When changing the repo example's clone command argument handling or its default destination derivation.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/repo/repo.py:60-82`
