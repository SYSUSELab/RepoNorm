# Rule details

- **Rule:**
  ```text
  Tests that exercise prompt default selection must preserve the mapping between the prompt's default marker and empty-input outcome: a [y/N] prompt yields 'no' on empty input, while a [Y/n] prompt yields 'yes' on empty input.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding prompt tests that assert default selection behavior for empty input.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:111-148`
