# Rule details

- **Rule:** Tests for option naming must preserve the convention that Click accepts multi-character single-dash option names such as "-whatever".
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying option-naming tests.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_options.py contains test_legacy_options, which defines and exercises the multi-character single-dash option "-whatever", preserving Click's acceptance of such names.
```

- **Sources:**
  - `tests/test_options.py`
