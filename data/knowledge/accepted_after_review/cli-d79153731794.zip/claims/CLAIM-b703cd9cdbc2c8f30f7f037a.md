# Rule details

- **Rule:**
  ```text
  FishComplete must remain a ShellComplete subclass with name 'fish' and source_template _SOURCE_FISH, defining the Fish shell completion implementation.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying shell completion classes, preserve FishComplete's subclassing of ShellComplete, its name 'fish', and its _SOURCE_FISH template.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/shell_completion.py:372-376`
