# Rule details

- **Rule:** Tests that verify chained group behavior must define a chained group with an optional variadic argument and assert the resulting behavior.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** when adding or modifying a test that verifies chained group behavior with optional variadic arguments
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_chain.py:192-205`
