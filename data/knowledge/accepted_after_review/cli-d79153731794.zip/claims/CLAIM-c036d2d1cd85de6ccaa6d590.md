# Rule details

- **Rule:** Read the Docs installs the project itself via pip from the repository root path.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    - method: pip
      path: .

```

- **Sources:**
  - `.readthedocs.yaml:9-10`

## Review evidence locations

- `.readthedocs.yaml:9-10`
