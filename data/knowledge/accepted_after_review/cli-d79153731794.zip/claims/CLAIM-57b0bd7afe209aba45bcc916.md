# Rule details

- **Rule:** Example commands that expose file input/output must use click.File with the appropriate mode and rely on the '-' convention for stdin/stdout, preserving Unix pipe compatibility.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example command that reads from or writes to files or streams.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/arguments.rst:84-104`
- `examples/inout/inout.py:4-22`
