# Rule details

- **Rule:**
  ```text
  When modifying ZshComplete.format_completion, preserve the three-line completion item of type, value, and help or '_' when help is absent.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing format_completion's output line structure or help fallback.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
ZshComplete.format_completion returns f"{item.type}\n{item.value}\n{item.help if item.help else '_'}", preserving the three-line type/value/help output with '_' fallback for absent help.
```

- **Sources:**
  - `src/click/shell_completion.py:368-369`
