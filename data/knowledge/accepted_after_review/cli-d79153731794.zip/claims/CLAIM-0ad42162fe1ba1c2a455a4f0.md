# Rule details

- **Rule:** Tests for case-insensitive choice options must assert that the exact configured choice value is returned rather than the user-supplied casing.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when adding or modifying a test for a case-insensitive choice option
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:583-591`
