# Rule details

- **Rule:**
  ```text
  When get_current_context is called with silent, its typing overload returns Context | None so static typing reflects that the context may be absent.
  ```
- **Applies to:**
  - `src/click/globals.py`
- **Condition:**
  ```text
  Modifying get_current_context's typing overloads or silent parameter handling.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/globals.py:12-20`
