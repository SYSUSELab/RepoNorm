# Rule details

- **Rule:**
  ```text
  Tests that verify default_map overrides must pass default_map to runner.invoke and assert the overridden output, covering both command parameter defaults and flag defaults (including help-text default display).
  ```
- **Applies to:**
  - `tests/test_commands.py`
  - `tests/test_defaults.py`
- **Condition:**
  ```text
  when adding or modifying a test that verifies default_map overriding of command or flag defaults
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:104-117`
- `tests/test_defaults.py:64-86`
