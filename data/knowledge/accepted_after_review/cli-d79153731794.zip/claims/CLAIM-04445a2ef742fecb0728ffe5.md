# Rule details

- **Rule:** The check-merge-conflict hook from pre-commit-hooks is enabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: check-merge-conflict

```

- **Sources:**
  - `.pre-commit-config.yaml:10`

## Review evidence locations

- `.pre-commit-config.yaml:10-10`
