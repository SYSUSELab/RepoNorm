# Rule details

- **Rule:**
  ```text
  A command configured with a custom context_class must produce a context of that type when make_context is called.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:**
  ```text
  Modifying or adding tests that verify context type selection for commands with a custom context_class.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_custom_classes.py:4-17`
