# Rule details

- **Rule:**
  ```text
  Open ``htmlcov/index.html`` in a browser to explore the coverage report.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Open ``htmlcov/index.html`` in your browser to explore the report.

```

- **Sources:**
  - `CONTRIBUTING.rst:199`

## Review evidence locations

- `CONTRIBUTING.rst:186-199`
