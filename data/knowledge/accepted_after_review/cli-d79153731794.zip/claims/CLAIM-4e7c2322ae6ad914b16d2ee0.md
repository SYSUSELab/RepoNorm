# Rule details

- **Rule:**
  ```text
  When modifying _WindowsConsoleWriter.write, preserve capping code units at MAX_BYTES_WRITTEN//2 and raising OSError with the last error message when zero bytes are written for a nonempty buffer.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When changing Windows console write chunking or zero-byte error handling in _WindowsConsoleWriter.write.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_winconsole.py:152-181`
