# Rule details

- **Rule:**
  ```text
  When modifying pass_context, preserve wrapping the callback so it receives the current Context as its first argument and finalizing the wrapper with update_wrapper to preserve the original function metadata.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When changing pass_context callback wrapping or metadata preservation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
pass_context wraps the callback so it receives the current Context first and finalizes the wrapper with update_wrapper to preserve the original function metadata.
```

- **Sources:**
  - `src/click/decorators.py:29-37`
