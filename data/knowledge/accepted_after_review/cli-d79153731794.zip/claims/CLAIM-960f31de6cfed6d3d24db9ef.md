# Rule details

- **Rule:** The testing echo-input getchar must read one character from sys.stdin, optionally echo it to sys.stdout, and flush stdout, so CliRunner input simulation routes through sys.stdin/stdout rather than a separate buffer.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When modifying CliRunner input simulation or the echo-input getchar behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/testing.py:348-373`
