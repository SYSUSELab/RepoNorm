# Rule details

- **Rule:**
  ```text
  The imagepipe example composes image-processing subcommands through a shared @processor decorator, and its result_callback receives an iterable of chained subcommand return values; process_commands folds each processor over an initially empty stream and then drains the stream to force evaluation. Subcommands such as smoothen_cmd use the shared decorator and options like -i/--iterations with default=1 and show_default=True.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:**
  ```text
  When adding or modifying imagepipe subcommands, the shared processor decorator, or the result_callback that folds and drains the chained stream.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/imagepipe/imagepipe.py:10-53`
- `examples/imagepipe/imagepipe.py:220-238`
