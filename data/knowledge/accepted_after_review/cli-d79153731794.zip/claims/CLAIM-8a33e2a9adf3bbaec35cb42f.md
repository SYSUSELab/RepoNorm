# Rule details

- **Rule:**
  ```text
  Tests that exercise per-invocation prog_name override must assert that invoking with prog_name="foobar" succeeds and produces the expected output, preserving the ability to override prog_name at invocation time.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  Modifying or adding tests that pass prog_name to a CliRunner invocation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_testing.py:371-379`
