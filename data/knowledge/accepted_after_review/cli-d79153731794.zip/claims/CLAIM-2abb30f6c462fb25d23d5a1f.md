# Rule details

- **Rule:**
  ```text
  When modifying `make_default_short_help`, preserve the truncation behavior: truncate at sentence-ending periods without adding an ellipsis, but when truncating mid-sentence remove words until the result plus '...' fits within `max_length`.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when changing short-help truncation logic
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/utils.py:59-106`
