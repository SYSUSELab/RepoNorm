# Rule details

- **Rule:**
  ```text
  When modifying `CliRunner`, preserve the documented breaking change that the `mix_stderr` parameter was removed in version 8.2, so callers passing `mix_stderr` are no longer supported.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  when changing `CliRunner`'s constructor signature or stderr handling
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/testing.py:218-243`
