# Rule details

- **Rule:**
  ```text
  Tests that assert option-prefix collection must verify that parsing args populates `ctx._opt_prefixes` with the set {"-", "--", "+", "!"}.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When adding or modifying option-prefix collection tests in tests/test_commands.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:339-349`
