# Rule details

- **Rule:**
  ```text
  When modifying EchoingStdin.__getattr__, preserve delegation of unknown attribute access to the wrapped input stream so the underlying stream's API is transparently exposed.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When changing EchoingStdin attribute delegation or the wrapped stream API surface.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/testing.py:26-39`
