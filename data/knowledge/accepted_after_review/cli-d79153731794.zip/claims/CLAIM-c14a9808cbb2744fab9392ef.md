# Rule details

- **Rule:**
  ```text
  Tests that exercise Click option parsing must drive the CLI through CliRunner.invoke with standalone_mode=False and catch_exceptions=False so the parsed return_value can be inspected directly.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when adding or modifying option-parsing tests that need to inspect the parsed result rather than the exit status
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:883-915`
