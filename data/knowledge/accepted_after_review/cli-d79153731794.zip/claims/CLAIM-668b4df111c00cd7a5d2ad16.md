# Rule details

- **Rule:**
  ```text
  Option.show_default must override Context.show_default; a string show_default value must render as a parenthesized default in help, and a False option-level value must suppress the default even when the context enables it.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  Modifying or adding tests for show_default precedence between Option and Context.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:841-861`
