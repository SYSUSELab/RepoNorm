# Rule details

- **Rule:**
  ```text
  The tox testenv `update-actions` is labeled `update`.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
[testenv:update-actions]
labels = update

```

- **Sources:**
  - `tox.ini:34-35`

## Review evidence locations

- `tox.ini:34-37`
