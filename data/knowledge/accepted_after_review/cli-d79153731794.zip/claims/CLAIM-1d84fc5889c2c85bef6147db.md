# Rule details

- **Rule:**
  ```text
  When modifying HelpOption.show_help, preserve the static callback behavior that echoes ctx.get_help() with ctx.color and exits when value is true and ctx.resilient_parsing is false, with resilient parsing suppressing the output.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When changing show_help's callback conditions or output behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/decorators.py:528-554`
