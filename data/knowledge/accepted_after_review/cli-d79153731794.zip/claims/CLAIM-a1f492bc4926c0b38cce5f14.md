# Rule details

- **Rule:** Tests for click.style and click.unstyle must verify that style keys map to the specific ANSI escape sequences (fg 30-37, bg 40-47, 256-color bg 48;5;N, truecolor bg 48;2;R;G;B, bold 1, dim 2, underline 4, overline 53, italic 3, blink 5, reverse 7, strikethrough 9) and that False values emit the corresponding reset codes (22, 24, 55, 23, 25, 27, 29), with unstyle reversing the styling.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying a test for click.style or click.unstyle ANSI escape sequence mapping
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:53-95`
