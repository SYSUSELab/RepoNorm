# Rule details

- **Rule:**
  ```text
  _get_text_stdout must wrap a Windows console writer in a non-closing text wrapper using utf-16-le with strict errors and line buffering, then cast it to a ConsoleStream.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying _get_text_stdout or Windows console text stream construction.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_get_text_stdout wraps the Windows console writer in a non-closing text wrapper using utf-16-le with strict errors and line buffering, then casts to ConsoleStream, satisfying the encoding and buffering contract.
```

- **Sources:**
  - `src/click/_winconsole.py:226-233`
