# Rule details

- **Rule:** Install the pre-commit hooks with pre-commit install.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Install the pre-commit hooks.

    .. code-block:: text

        $ pre-commit install

```

- **Sources:**
  - `CONTRIBUTING.rst:117-121`

## Review evidence locations

- `CONTRIBUTING.rst:117-121`
