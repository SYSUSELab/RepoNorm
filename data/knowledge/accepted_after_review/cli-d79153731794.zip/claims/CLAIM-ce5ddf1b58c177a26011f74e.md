# Rule details

- **Rule:** When a test stream wrapper is constructed, store name and mode separately and pass the underlying buffer to the superclass, preserving the original stream identity for testing.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying _NamedTextIOWrapper.__init__ or the test stream wrapper construction.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_NamedTextIOWrapper.__init__ stores self._name and self._mode and passes the underlying buffer to super().__init__, preserving stream identity.
```

- **Sources:**
  - `src/click/testing.py:104-109`
