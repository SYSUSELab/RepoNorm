# Rule details

- **Rule:**
  ```text
  When a command is added under a registered name different from its original name, invocation and default_map lookup must use the registered name, not the original command name.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When modifying command registration or invocation logic that handles renamed commands.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:294-301`
