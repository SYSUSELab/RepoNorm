# Rule details

- **Rule:** The create-release job depends on the provenance job and runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    needs: [provenance]
    runs-on: ubuntu-latest

```

- **Sources:**
  - `.github/workflows/publish.yaml:42-43`

## Review evidence locations

- `.github/workflows/publish.yaml:39-45`
