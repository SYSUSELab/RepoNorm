# Rule details

- **Rule:**
  ```text
  Example commands that define a generator decorator must pass through old values unchanged and not pass the values as a parameter, returning update_wrapper(new_func, f) to preserve metadata.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example command that defines a generator decorator similar to the processor decorator.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/imagepipe/imagepipe.py:42-66`
