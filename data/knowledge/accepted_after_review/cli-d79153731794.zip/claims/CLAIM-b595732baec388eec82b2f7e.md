# Rule details

- **Rule:**
  ```text
  Tests that verify to_info_dict output must assert the exact keys for ParamType and Option instances, including param_type, name, choices, formats, min/max, and flag option fields.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  When adding or modifying tests for to_info_dict, preserve the exact key set asserted for each ParamType and Option instance.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_info_dict.py:94-213`
