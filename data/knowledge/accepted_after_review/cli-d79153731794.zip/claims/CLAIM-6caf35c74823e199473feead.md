# Rule details

- **Rule:**
  ```text
  Tests that assert `ProgressBar.time_per_iteration` must verify that an empty average list returns 0.0 and [1, 4] returns 2.5, defining the averaging behavior for iteration timing.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When adding or modifying `ProgressBar.time_per_iteration` tests in tests/test_termui.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_progressbar_time_per_iteration parametrizes ([], 0.0) and ([1, 4], 2.5), asserting the empty average returns 0.0 and [1, 4] returns 2.5.
```

- **Sources:**
  - `tests/test_termui.py`
