# Rule details

- **Rule:** Create a branch to identify the issue being worked on; for bug or documentation fixes, branch off the latest ".x" branch (e.g., origin/8.1.x).
- **Applies to:**
  - `CONTRIBUTING.rst`
- **Condition:** when submitting a bug or documentation fix
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Create a branch to identify the issue you would like to work on. If
    you're submitting a bug or documentation fix, branch off of the
    latest ".x" branch.

```

- **Sources:**
  - `CONTRIBUTING.rst:134-136`

### Evidence 2 — explicit

```text
        $ git fetch origin
        $ git checkout -b your-branch-name origin/8.1.x

```

- **Sources:**
  - `CONTRIBUTING.rst:140-141`

## Review evidence locations

- `CONTRIBUTING.rst:131-149`
