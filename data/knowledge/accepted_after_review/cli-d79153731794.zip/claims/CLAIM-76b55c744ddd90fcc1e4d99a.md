# Rule details

- **Rule:** Tests that verify per-command option scoping in shell completion must define a group and subcommand sharing the same option name and assert that completion offers only the current command's options after the group option is consumed.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when adding or modifying a test that verifies option scoping across group and subcommand in shell completion
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:43-50`
