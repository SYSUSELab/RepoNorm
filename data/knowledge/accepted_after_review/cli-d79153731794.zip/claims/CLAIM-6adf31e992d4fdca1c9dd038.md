# Rule details

- **Rule:**
  ```text
  Tests that verify is_bool_flag must assert it is True only for is_flag=True, secondary options like '-a/-A', and bool flag_value=True, while int/bool non-flag options and non-bool flag_value remain False.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying tests for is_bool_flag detection, preserve the exact truth table covering is_flag, secondary options, and flag_value types.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:925-941`
