# Rule details

- **Rule:** Tests for chained groups must exercise variadic arguments to verify they are rejected or handled in a specific way.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** when adding or modifying tests for chained groups with variadic arguments
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_chain.py:192-218`
