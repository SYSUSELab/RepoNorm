# Rule details

- **Rule:** Files in the repository use UTF-8 charset.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
charset = utf-8

```

- **Sources:**
  - `.editorconfig:9`

## Review evidence locations

- `.editorconfig:9-9`
