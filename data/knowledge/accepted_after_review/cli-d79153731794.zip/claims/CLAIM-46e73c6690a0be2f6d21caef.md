# Rule details

- **Rule:**
  ```text
  Option parsing must treat a bare '--' as an unconditional terminator regardless of configured option prefixes, and only treat an arg as an option when its first character is in _opt_prefixes and length exceeds 1.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When modifying _process_args_for_options or option prefix handling.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/parser.py:325-339`
