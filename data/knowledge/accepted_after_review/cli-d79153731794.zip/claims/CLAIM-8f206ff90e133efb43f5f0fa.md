# Rule details

- **Rule:**
  ```text
  Command subclasses can override the context class used for invocation by setting context_class to a custom Context subclass.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** When modifying Command subclass context class resolution or adding tests for custom context classes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:881-884`
- `src/click/core.py:1128-1156`
- `tests/test_custom_classes.py:4-17`
