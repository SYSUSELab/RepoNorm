# Rule details

- **Rule:** Pyright is configured with pythonVersion "3.8".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
pythonVersion = "3.8"

```

- **Sources:**
  - `pyproject.toml:74`

## Review evidence locations

- `pyproject.toml:74-74`
