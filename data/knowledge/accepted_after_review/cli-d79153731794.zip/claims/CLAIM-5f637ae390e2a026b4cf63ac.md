# Rule details

- **Rule:** An entry must be added in CHANGES.rst using the same style as other entries, and relevant docstrings must include .. versionchanged:: inline changelogs.
- **Applies to:**
  - `**/*.py`
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Add an entry in ``CHANGES.rst``. Use the same style as other
    entries. Also include ``.. versionchanged::`` inline changelogs in
    relevant docstrings.

```

- **Sources:**
  - `CONTRIBUTING.rst:61-63`

## Review evidence locations

- `CONTRIBUTING.rst:52-63`
