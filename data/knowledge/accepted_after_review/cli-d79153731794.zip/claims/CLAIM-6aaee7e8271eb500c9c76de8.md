# Rule details

- **Rule:** Tests that verify custom help-option formatting must assert the exact exit code and the exact usage, help-hint, and error lines produced, rather than only checking that an error occurred.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_formatting.py that exercises custom help-option usage or missing-argument error formatting.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test asserts no exception and compares output.splitlines() to exact expected usage/help lines, satisfying the exact-line assertion rule.
```

- **Sources:**
  - `tests/test_formatting.py:52-84`

## Review evidence locations

- `tests/test_formatting.py:233-246`
