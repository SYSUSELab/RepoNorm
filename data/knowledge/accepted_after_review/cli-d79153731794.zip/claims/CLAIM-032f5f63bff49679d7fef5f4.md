# Rule details

- **Rule:** The ruff hook from ruff-pre-commit is enabled.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: ruff

```

- **Sources:**
  - `.pre-commit-config.yaml:5`

## Review evidence locations

- `.pre-commit-config.yaml:5-5`
