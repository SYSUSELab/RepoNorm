# Rule details

- **Rule:** Typing examples must pair an int-typed option with default=1 and a str-typed argument, showing the expected static typing pattern for click options and arguments.
- **Applies to:**
  - `tests/typing/typing_options.py`
- **Condition:** When adding or modifying typing examples for click options and arguments, preserve the pattern of an int-typed option with default=1 paired with a str-typed argument.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
The hello example pairs an int-typed option with default=1 and a str-typed argument, matching the expected static typing pattern for click options and arguments.
```

- **Sources:**
  - `tests/typing/typing_options.py:11-13`

## Review evidence locations

- `tests/typing/typing_options.py:8-13`
