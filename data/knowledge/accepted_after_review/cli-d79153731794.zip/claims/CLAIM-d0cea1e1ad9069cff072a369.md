# Rule details

- **Rule:**
  ```text
  Example commands that handle credentials must use prompt=True and click.password_option, and must not store or display the actual password value (e.g., mask it as '*' * len(password)).
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When adding or modifying a command in the repo example that accepts or handles user credentials.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/repo/repo.py:100-113`
