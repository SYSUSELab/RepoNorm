# Rule details

- **Rule:**
  ```text
  _BaseCommand must remain deprecated as of 8.2 and slated for removal in Click 9.0, with contributors directed to use Command instead.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying or removing deprecated command base classes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:1419-1423`
