# Rule details

- **Rule:**
  ```text
  TextWrapper.extra_indent must temporarily append the given indent to both initial_indent and subsequent_indent, restoring the previous values in a finally block.
  ```
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:**
  ```text
  When modifying TextWrapper.extra_indent or indent manipulation behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_textwrap.py:27-38`
