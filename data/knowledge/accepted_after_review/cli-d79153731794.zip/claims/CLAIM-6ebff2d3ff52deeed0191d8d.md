# Rule details

- **Rule:** FuncParamType is a ParamType subclass intended for wrapping a user-supplied callable as a Click parameter type, establishing the extension point for custom type conversion.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when adding or modifying custom parameter type wrappers
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:168-189`
- `src/click/types.py:1038-1069`
