# Rule details

- **Rule:** The docs tox environment installs its dependencies from requirements/docs.txt.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
deps = -r requirements/docs.txt

```

- **Sources:**
  - `tox.ini:31`

## Review evidence locations

- `tox.ini:30-32`
