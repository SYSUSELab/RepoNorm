# Rule details

- **Rule:**
  ```text
  formatting.py must expose a module-level FORCED_WIDTH that can force a width, explicitly used by the test system.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When changing formatting width resolution or test-controlled width overrides.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
formatting.py exposes a module-level FORCED_WIDTH annotated as used by the test system to force a width.
```

- **Sources:**
  - `src/click/formatting.py`
