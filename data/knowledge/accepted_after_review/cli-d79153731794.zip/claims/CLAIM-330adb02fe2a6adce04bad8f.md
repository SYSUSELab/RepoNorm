# Rule details

- **Rule:**
  ```text
  Running `make help` in docs/ invokes Sphinx with the `help` builder, passing SOURCEDIR, BUILDDIR, SPHINXOPTS, and O.
  ```
- **Applies to:**
  - `docs/**`
- **Condition:** command target: help
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
help:
	@$(SPHINXBUILD) -M help "$(SOURCEDIR)" "$(BUILDDIR)" $(SPHINXOPTS) $(O)

```

- **Sources:**
  - `docs/Makefile:12-13`

## Review evidence locations

- `docs/Makefile:4-13`
