# Rule details

- **Rule:** Tests that verify option-prefix collection across a group must assert the exact set of prefixes used by subcommands, not merely that collection occurred.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_commands.py that exercises option-prefix collection on a group.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:374-395`
