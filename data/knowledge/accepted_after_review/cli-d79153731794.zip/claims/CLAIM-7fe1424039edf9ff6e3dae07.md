# Rule details

- **Rule:** Files in the repository use an indent size of 4 by default.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
indent_size = 4

```

- **Sources:**
  - `.editorconfig:5`

## Review evidence locations

- `.editorconfig:5-5`
- `.editorconfig:12-13`
