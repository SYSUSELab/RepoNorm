# Rule details

- **Rule:** Invoking a deprecated command must emit 'DeprecationWarning:' in the runner output.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When modifying deprecation warning behavior or tests for deprecated commands.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:330-336`
