# Rule details

- **Rule:**
  ```text
  get_current_context must be overloaded so that calling it with silent=False (the default) is typed to return Context rather than Context | None.
  ```
- **Applies to:**
  - `src/click/globals.py`
- **Condition:**
  ```text
  When modifying get_current_context's signature or type overloads.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/globals.py:12-20`
