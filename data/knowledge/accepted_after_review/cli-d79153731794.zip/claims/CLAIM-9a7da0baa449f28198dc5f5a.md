# Rule details

- **Rule:** Progress bars must be used as context managers; iterating a progress bar outside its with block raises RuntimeError matching 'with block'.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying progress bar usage or tests that iterate progress bars.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_termui.py:183-192`
