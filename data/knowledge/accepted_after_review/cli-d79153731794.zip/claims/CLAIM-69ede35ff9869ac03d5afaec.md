# Rule details

- **Rule:** Tests for dynamic default help text must assert that help output shows the option name and dynamic default text '(current user)' while not leaking the lambda source.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When adding or modifying tests for dynamic default help text rendering.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:291-306`
