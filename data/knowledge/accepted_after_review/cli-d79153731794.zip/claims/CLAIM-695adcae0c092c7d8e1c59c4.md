# Rule details

- **Rule:** BytesIOCopy must patch io.BytesIO so the written stream can be copied to another stream, added in version 8.2.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When changing the BytesIOCopy testing utility or its stream-copy behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/testing.py:70-86`
