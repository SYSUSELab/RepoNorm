# Rule details

- **Rule:** Example validation callbacks must raise click.BadParameter when the value fails validation, demonstrating the expected callback validation pattern and error type.
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** when adding or modifying a validation callback in the validation example
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/validation/validation.py:6-9`
