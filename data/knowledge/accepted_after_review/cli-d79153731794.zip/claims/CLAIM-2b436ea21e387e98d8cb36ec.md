# Rule details

- **Rule:** The end-of-file-fixer hook from pre-commit-hooks is enabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: end-of-file-fixer

```

- **Sources:**
  - `.pre-commit-config.yaml:14`

## Review evidence locations

- `.pre-commit-config.yaml:14-14`
