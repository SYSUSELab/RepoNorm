# Rule details

- **Rule:**
  ```text
  Normalization tests must preserve the convention that CONTEXT_SETTINGS uses token_normalize_func=lambda x: x.lower(), establishing lowercase token normalization as the tested convention.
  ```
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:** When modifying token normalization tests.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The module defines CONTEXT_SETTINGS with token_normalize_func=lambda x: x.lower(), establishing lowercase token normalization.
```

- **Sources:**
  - `tests/test_normalization.py`
