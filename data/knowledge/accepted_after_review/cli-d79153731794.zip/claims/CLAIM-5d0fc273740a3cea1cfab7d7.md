# Rule details

- **Rule:**
  ```text
  Tests for Group.parse_args must assert that base option prefixes are collected into ctx._opt_prefixes.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  when adding or modifying tests for Group.parse_args option-prefix collection
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:352-371`
