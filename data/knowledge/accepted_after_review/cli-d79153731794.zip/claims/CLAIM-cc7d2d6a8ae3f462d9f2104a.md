# Rule details

- **Rule:**
  ```text
  The build job sets up Python version '3.x' with pip caching keyed on requirements*/*.txt.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: actions/setup-python@0b93645e9fea7318ecaed2b359559ac225c90a2b # v5.3.0
        with:
          python-version: '3.x'
          cache: pip
          cache-dependency-path: requirements*/*.txt

```

- **Sources:**
  - `.github/workflows/publish.yaml:13-17`
