# Rule details

- **Rule:**
  ```text
  _get_text_stderr must wrap the Windows console writer in a text stream using utf-16-le with strict errors and line buffering, reflecting the Windows console encoding contract.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying _get_text_stderr or Windows console text-stream wrapping.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_winconsole.py:236-243`
