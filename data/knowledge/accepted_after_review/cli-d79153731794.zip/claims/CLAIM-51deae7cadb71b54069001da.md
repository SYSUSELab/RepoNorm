# Rule details

- **Rule:** Files in the repository are configured to insert a final newline.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
insert_final_newline = true

```

- **Sources:**
  - `.editorconfig:6`

## Review evidence locations

- `.editorconfig:6-6`
