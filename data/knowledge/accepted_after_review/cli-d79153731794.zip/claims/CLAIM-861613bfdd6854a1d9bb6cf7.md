# Rule details

- **Rule:**
  ```text
  When modifying the prompt function, preserve the interactive prompt contract: build a value_proc from the type when none is given, loop until a non-empty value or default is provided, re-prompt on UsageError, and when confirmation_prompt is set require a matching second value or re-prompt.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** when changing interactive prompt behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/termui.py:153-191`
