# Rule details

- **Rule:**
  ```text
  The build job sets SOURCE_DATE_EPOCH from the last commit date to use the commit date instead of the current date during the build.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      # Use the commit date instead of the current date during the build.
      - run: echo "SOURCE_DATE_EPOCH=$(git log -1 --pretty=%ct)" >> $GITHUB_ENV

```

- **Sources:**
  - `.github/workflows/publish.yaml:19-20`
