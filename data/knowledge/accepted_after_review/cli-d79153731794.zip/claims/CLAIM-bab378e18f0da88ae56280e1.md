# Rule details

- **Rule:**
  ```text
  When modifying Editor.edit, preserve the mtime workaround: set the temp file's mtime 2 seconds in the past before invoking the editor, then compare the recorded timestamp to detect whether the editor actually saved changes when require_save is set.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:** when changing editor invocation or change-detection logic
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_termui_impl.py:530-565`
