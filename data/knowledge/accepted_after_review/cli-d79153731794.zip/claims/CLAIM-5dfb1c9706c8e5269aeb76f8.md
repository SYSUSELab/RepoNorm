# Rule details

- **Rule:**
  ```text
  The project declares flit_core<4 as its build requirement.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
requires = ["flit_core<4"]

```

- **Sources:**
  - `pyproject.toml:29`

## Review evidence locations

- `pyproject.toml:29-29`
