# Rule details

- **Rule:** Tests that exercise a metavar override on a positional argument must define the argument with metavar="metavar" and assert the supported override.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When adding or modifying tests for metavar override on a positional argument, preserve the use of metavar="metavar" and the assertion of the supported override.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_formatting_usage_error_metavar_missing_arg defines a positional argument with metavar="metavar" and asserts the supported override in the usage/error output.
```

- **Sources:**
  - `tests/test_formatting.py:161-179`
