# Rule details

- **Rule:**
  ```text
  When a command is invoked with standalone_mode=False, its return value must be the typed default values (e.g. a string default cast to int, an empty multiple option as an empty tuple rather than None), so tests asserting on the returned object must expect the cast/coerced form.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  Modifying or adding tests that invoke a Click command with standalone_mode=False and assert on the returned default values.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_commands.py:231-248`
