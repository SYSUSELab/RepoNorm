# Rule details

- **Rule:**
  ```text
  When modifying the termui module, preserve the module-level visible_prompt_func callable defaulting to input and the _getchar module-level hook used for unittesting getchar calls.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** when changing termui module-level prompt or getchar hooks
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The termui module defines module-level visible_prompt_func defaulting to input and a module-level _getchar hook documented for unittesting getchar calls, matching the rule.
```

- **Sources:**
  - `src/click/termui.py`
