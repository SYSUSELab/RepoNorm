# Rule details

- **Rule:** A boolean flag declared as '--shout/--no-shout' with envvar='SHOUT' must echo the parsed boolean value, demonstrating envvar-driven boolean flag parsing.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying boolean flag envvar parsing or its tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:204-212`
