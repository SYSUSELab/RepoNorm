# Rule details

- **Rule:**
  ```text
  When modifying FileError.format_message, preserve the localized message format "Could not open file {filename!r}: {message}" using the ui_filename and message attributes.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When changing file-open error message formatting or localization in FileError.format_message.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/exceptions.py:275-289`
