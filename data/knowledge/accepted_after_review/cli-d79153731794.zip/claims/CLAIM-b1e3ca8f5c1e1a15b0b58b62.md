# Rule details

- **Rule:** Add your fork as a remote named "fork" pointing at https://github.com/{username}/click, replacing {username} with your username.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Add your fork as a remote to push your work to. Replace
    ``{username}`` with your username. This names the remote "fork", the
    default Pallets remote is "origin".

    .. code-block:: text

        $ git remote add fork https://github.com/{username}/click

```

- **Sources:**
  - `CONTRIBUTING.rst:89-95`

## Review evidence locations

- `CONTRIBUTING.rst:89-95`
