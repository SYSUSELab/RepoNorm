# Rule details

- **Rule:**
  ```text
  The Publish workflow runs on pushes of tags matching '*'.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Condition:**
  ```text
  workflow predicate: push: tags: - '*'
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
on:
  push:
    tags:
      - '*'

```

- **Sources:**
  - `.github/workflows/publish.yaml:2-5`

## Review evidence locations

- `.github/workflows/publish.yaml:1-5`
