# Rule details

- **Rule:** Tests covering envvar population of variadic arguments must preserve the convention that nargs=-1 accepts any count of envvar-split values while a fixed nargs (e.g. nargs=2) raises BadParameter when the value count differs.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying envvar handling tests for variadic or fixed-nargs arguments.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_arguments.py contains test_nargs_envvar which exercises envvar='X' with nargs=-1 accepting any count and nargs=2 raising BadParameter on count mismatch, matching the envvar/nargs convention.
```

- **Sources:**
  - `tests/test_arguments.py`
