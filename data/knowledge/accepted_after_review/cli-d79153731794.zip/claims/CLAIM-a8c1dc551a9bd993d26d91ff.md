# Rule details

- **Rule:**
  ```text
  The aliases example's get_command must resolve commands in order: builtin commands first, then explicit aliases from the config object, then unique prefix abbreviation; ambiguous prefixes must fail with 'Too many matches'.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:**
  ```text
  When modifying AliasedGroup.get_command or the command resolution order.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/aliases/aliases.py:42-68`
