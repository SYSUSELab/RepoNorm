# Rule details

- **Rule:** Tests that verify CliRunner color forcing must assert both the default plain output and the color-forced styled output, rather than only one of the two.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_testing.py that exercises CliRunner color forcing.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_testing.py:187-200`
