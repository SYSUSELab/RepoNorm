# Rule details

- **Rule:** When a stream wrapper's flush encounters OSError, suppress it only if errno is EPIPE; re-raise all other OSErrors so genuine I/O failures are not silently swallowed.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** Modifying flush behavior of a stream wrapper that may write to a closed pipe.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/utils.py:498-520`
