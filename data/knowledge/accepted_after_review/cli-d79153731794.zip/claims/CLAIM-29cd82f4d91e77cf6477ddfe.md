# Rule details

- **Rule:**
  ```text
  The helper _non_utf8_filenames_supported must probe whether non-UTF-8 filenames are supported by attempting to create a file with a surrogate-escaped name in a temporary directory, returning False on OSError.
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying the non-UTF-8 filename support helper or its tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_types.py:148-156`
