# Rule details

- **Rule:** Tests that exercise a chained group with per-subcommand options must assert that each chained subcommand receives its own option value, producing distinct output lines.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** When adding or modifying tests for a chained group where subcommands take options, preserve the assertion that each subcommand receives its own option value.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_chain.py:68-85`
