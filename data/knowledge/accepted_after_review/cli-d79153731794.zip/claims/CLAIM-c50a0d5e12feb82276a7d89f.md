# Rule details

- **Rule:** When modifying StringParamType.convert, preserve bytes decoding with the argv encoding and the UnicodeError fallback to filesystem encoding if different, otherwise utf-8 with 'replace', and coerce non-bytes values with str.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing StringParamType.convert's decoding or non-bytes coercion behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:204-224`
