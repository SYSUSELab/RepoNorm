# Rule details

- **Rule:** The name property returns the real filename, providing a stable interface for accessing the underlying file name in the compatibility layer.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** when modifying the compatibility layer's file name access
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_compat.py:452-461`
