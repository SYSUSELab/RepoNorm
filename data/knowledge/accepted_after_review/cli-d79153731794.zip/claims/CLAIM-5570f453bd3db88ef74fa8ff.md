# Rule details

- **Rule:** Example commands that need shared state across subcommands must store that state on the Click context object (ctx.obj) in the group callback and read it from subcommands, rather than relying on module-level globals.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When adding or modifying a subcommand in the repo example that needs access to the Repo instance or config overrides established by the group.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/repo/repo.py:23-57`
- `examples/repo/repo.py:71-82`
