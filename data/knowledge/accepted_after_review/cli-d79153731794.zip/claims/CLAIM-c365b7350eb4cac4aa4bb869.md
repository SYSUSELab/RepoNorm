# Rule details

- **Rule:**
  ```text
  The termui example implements an interactive menu as a state machine driven by click.getchar(), transitioning between main, debug, and quit menus and echoing Invalid input for unrecognized characters; the progressbar's item_show_func extension point is demonstrated by a show_item callback returning a formatted string for item display.
  ```
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying the termui example's interactive menu state machine or its progressbar item display callback.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/termui/termui.py:56-67`
- `examples/termui/termui.py:144-169`
