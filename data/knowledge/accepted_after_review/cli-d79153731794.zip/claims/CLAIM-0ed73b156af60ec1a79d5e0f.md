# Rule details

- **Rule:** The typing tox environment runs mypy.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
commands =
    mypy
    pyright tests/typing
    pyright --verifytypes click --ignoreexternal

```

- **Sources:**
  - `tox.ini:25-28`

## Review evidence locations

- `tox.ini:23-28`
