# Rule details

- **Rule:**
  ```text
  A leading \b no-rewrap marker in the first paragraph is stripped before computing the short help, and only the first paragraph (up to a blank line) is considered.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying short help generation or no-rewrap marker handling
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/utils.py:59-75`
