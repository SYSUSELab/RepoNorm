# Rule details

- **Rule:** Shell completion word generation must respect Argument nargs, including Choice values and nargs=-1, and must skip consumed option values.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying shell completion word generation logic or adding tests for Argument nargs handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:219-241`
