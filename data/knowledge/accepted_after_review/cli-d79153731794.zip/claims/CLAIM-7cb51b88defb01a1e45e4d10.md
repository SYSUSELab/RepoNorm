# Rule details

- **Rule:**
  ```text
  Decorators that wrap user functions must use update_wrapper so the decorated function preserves the original function's metadata (name, docstring, etc.).
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When adding or modifying a click decorator that wraps a user function.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/decorators.py:29-49`
- `src/click/decorators.py:77-122`
