# Rule details

- **Rule:**
  ```text
  The colors example defines all_colors as the 16 supported color names including bright_* variants, matching the ANSI color mapping in termui.
  ```
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** When modifying or adding color definitions in the colors example.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/colors/colors.py:4-21`
- `src/click/termui.py:32-50`
