# Rule details

- **Rule:** Tests that exercise multiple-default output must assert no exception and that output lines are exactly the expected ordered and formatted values.
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** When adding or modifying tests for multiple-default output, preserve the assertion that output lines are exactly the expected ordered and formatted values with no exception.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_defaults.py:16-26`
