# Rule details

- **Rule:** The chain test must define a command 'b' that calls debug(), used to exercise chained command invocation behavior.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** When modifying chained command invocation tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_chain.py:170-189`
