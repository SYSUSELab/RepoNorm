# Rule details

- **Rule:**
  ```text
  click.Option must raise TypeError with the specific messages "'count' is not valid with 'multiple'." and "'count' is not valid with 'is_flag'." when count is combined with multiple or is_flag.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** Modifying or adding tests that assert TypeError messages for invalid count flag combinations.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:944-955`
