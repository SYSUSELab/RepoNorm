# Rule details

- **Rule:**
  ```text
  Tests that exercise `CliRunner` error-output handling must define a command raising `CLIError("Red error")` to drive the error-output path.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  When adding or modifying `CliRunner` error-output tests in tests/test_testing.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_testing.py contains test_with_color_errors, which defines a command raising CLIError("Red error") and asserts the resulting error output, matching the rule.
```

- **Sources:**
  - `tests/test_testing.py`

## Review evidence locations

- `tests/test_testing.py:203-220`
