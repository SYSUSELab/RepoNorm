# Rule details

- **Rule:**
  ```text
  Tests must override help_option_names via context_settings (e.g. to ['--man']) to verify custom help option configuration.
  ```
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:**
  ```text
  When modifying custom help option configuration or context_settings handling exercised by tests/test_formatting.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_formatting.py:233-246`
