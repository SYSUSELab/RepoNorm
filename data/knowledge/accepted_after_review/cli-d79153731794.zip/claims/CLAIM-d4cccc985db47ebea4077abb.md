# Rule details

- **Rule:** Shell completion must offer both --on and --off as completion words for a flag option, and after --on the choice argument must offer its choices.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When modifying shell completion word generation for flag options or choice arguments exercised by tests/test_shell_completion.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:177-188`
