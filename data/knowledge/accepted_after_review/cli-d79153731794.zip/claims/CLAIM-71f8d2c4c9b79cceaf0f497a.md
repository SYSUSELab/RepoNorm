# Rule details

- **Rule:** Shell completion callbacks may return either a list of plain strings or a list of CompletionItem objects carrying help strings; matching may be performed against both the value and the help text.
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When modifying or adding shell completion callbacks in the completion example.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/completion/completion.py:18-21`
- `examples/completion/completion.py:36-47`
