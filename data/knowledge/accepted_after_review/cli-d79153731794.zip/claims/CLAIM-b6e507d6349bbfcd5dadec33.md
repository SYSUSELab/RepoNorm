# Rule details

- **Rule:**
  ```text
  Tests that exercise shell-completion behavior must isolate the global `click.shell_completion._available_shells` state by snapshotting it before the test and restoring the previous contents afterward.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying a test that reads or mutates shell-completion state in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_shell_completion.py snapshots click.shell_completion._available_shells in the _restore_available_shells fixture, clears it for the test, and restores the previous contents afterward, matching the global-state isolation rule.
```

- **Sources:**
  - `tests/test_shell_completion.py`
