# Rule details

- **Rule:**
  ```text
  mypy is configured with show_error_codes = true.
  ```
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
show_error_codes = true

```

- **Sources:**
  - `pyproject.toml:63`

## Review evidence locations

- `pyproject.toml:63-63`
