# Rule details

- **Rule:** Tests that exercise a chained group must define it with click.group(chain=True) and assert the chained multi-command invocation protocol.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** When adding or modifying tests for chained group invocation, preserve the use of click.group(chain=True) and the assertion of the chained multi-command protocol.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_chain.py:15-34`
