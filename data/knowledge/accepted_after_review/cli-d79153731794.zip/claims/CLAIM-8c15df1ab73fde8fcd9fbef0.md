# Rule details

- **Rule:**
  ```text
  When modifying `echo`, preserve its role as the preferred output primitive over `print`, including handling encoding, Unicode on Windows, binary/text stream mismatches, color stripping for non-terminals, and always flushing.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  when changing `echo`'s output handling or documentation of its guarantees
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/utils.py:222-266`
- `src/click/utils.py:278-322`
