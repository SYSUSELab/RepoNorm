# Rule details

- **Rule:**
  ```text
  OptionParser._Option splits each option into prefix/value; a single-character prefix with a single-character value is classified as a short option, otherwise as a long option, and the first character of every prefix is added to the prefixes set.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** when modifying option prefix/value splitting or short/long classification
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/parser.py:128-151`
