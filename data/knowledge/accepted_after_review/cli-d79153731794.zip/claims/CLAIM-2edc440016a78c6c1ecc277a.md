# Rule details

- **Rule:** The testenv environment installs dependencies from requirements/tests.txt.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
deps = -r requirements/tests.txt

```

- **Sources:**
  - `tox.ini:15`
