# Rule details

- **Rule:**
  ```text
  When reading Bash completion state, read COMP_WORDS and COMP_CWORD from the environment, take args as cwords[1:cword], and treat a missing cwords[cword] as an empty incomplete token.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying BashComplete.get_completion_args or the Bash completion argument extraction.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/shell_completion.py:334-344`
