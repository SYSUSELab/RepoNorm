# Rule details

- **Rule:**
  ```text
  When modifying MissingParameter, preserve its BadParameter subclassing and the documented param_type values 'parameter', 'option', or 'argument', defaulting to inheriting the type from the given param.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When changing MissingParameter's inheritance or param_type defaulting.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
MissingParameter is defined as a subclass of BadParameter, preserving the BadParameter subclassing required by the rule.
```

- **Sources:**
  - `src/click/exceptions.py:137-203`
