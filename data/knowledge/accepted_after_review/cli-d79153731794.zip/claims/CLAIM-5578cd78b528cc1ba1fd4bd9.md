# Rule details

- **Rule:** Tests that verify CliRunner environment isolation must assert both that the env dict is visible to the invoked command and that os.environ is restored to its original state after invocation.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_testing.py that exercises CliRunner.invoke with an env argument.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_testing.py:304-319`
