# Rule details

- **Rule:** Color interpretation must encode int colors as 256-color SGR sequences and tuple/list colors as truecolor SGR sequences, with offset distinguishing foreground from background.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying _interpret_color or color encoding logic.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_interpret_color encodes int colors as 256-color SGR (38+offset;5;color) and tuple/list colors as truecolor (38+offset;2;r;g;b), with offset distinguishing foreground/background.
```

- **Sources:**
  - `src/click/termui.py:460-468`
