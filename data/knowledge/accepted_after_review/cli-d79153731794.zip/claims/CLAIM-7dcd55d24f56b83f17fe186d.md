# Rule details

- **Rule:** The completion example must define a click.group named cli with an empty callback as the minimal group declaration pattern.
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When adding or modifying the top-level command group in the completion example.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/completion/completion.py:7-9`
