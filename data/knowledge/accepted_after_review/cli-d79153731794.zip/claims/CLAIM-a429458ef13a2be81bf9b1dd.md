# Rule details

- **Rule:**
  ```text
  When modifying `Command.format_options`, preserve that it collects help records from `get_params`, skips params whose `get_help_record` returns `None`, and only writes the 'Options' section when at least one record exists.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** when changing help option formatting or the Options section emission
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:1100-1110`
