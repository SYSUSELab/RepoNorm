# Rule details

- **Rule:** The trailing-whitespace hook from pre-commit-hooks is enabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: trailing-whitespace

```

- **Sources:**
  - `.pre-commit-config.yaml:13`

## Review evidence locations

- `.pre-commit-config.yaml:13-13`
