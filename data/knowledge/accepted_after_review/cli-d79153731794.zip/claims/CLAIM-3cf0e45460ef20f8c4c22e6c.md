# Rule details

- **Rule:**
  ```text
  Windows console writer implementations must subclass _WindowsConsoleRawIOBase to provide the Windows console writer surface.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When adding or modifying a Windows console writer class.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_WindowsConsoleWriter is defined with _WindowsConsoleRawIOBase as its base class, establishing the required inheritance for the Windows console writer surface.
```

- **Sources:**
  - `src/click/_winconsole.py:152-181`
