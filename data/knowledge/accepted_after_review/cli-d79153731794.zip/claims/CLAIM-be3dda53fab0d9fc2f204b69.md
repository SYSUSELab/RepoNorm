# Rule details

- **Rule:** The ruff-format hook from ruff-pre-commit is enabled.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: ruff-format

```

- **Sources:**
  - `.pre-commit-config.yaml:6`

## Review evidence locations

- `.pre-commit-config.yaml:6-6`
