# Rule details

- **Rule:**
  ```text
  Tests that verify custom formatter_class on a context must assert that the custom formatter is used for help formatting, e.g. by checking colorized output in context.get_help().
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:**
  ```text
  when adding or modifying a test that verifies custom formatter_class on a context
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_custom_classes.py:47-63`
