# Rule details

- **Rule:** Tests for prompt defaults must assert that a default value is cast through the declared type before being returned.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests for prompt default handling with a declared type
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:244-249`
