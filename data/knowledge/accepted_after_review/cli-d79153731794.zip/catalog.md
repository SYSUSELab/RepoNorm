# Claim catalog

- [Rules 1–80](catalog/0001.md); scope preview: `**/*.py`
- [Rules 81–156](catalog/0002.md); scope preview: `src/click/utils.py`
- [Rules 157–231](catalog/0003.md); scope preview: `**/*.py`
- [Rules 232–309](catalog/0004.md); scope preview: `.github/workflows/publish.yaml`
- [Rules 310–384](catalog/0005.md); scope preview: `**`
- [Rules 385–458](catalog/0006.md); scope preview: `src/click/decorators.py`
- [Rules 459–493](catalog/0007.md); scope preview: `examples/complex/complex/commands/cmd_init.py`
