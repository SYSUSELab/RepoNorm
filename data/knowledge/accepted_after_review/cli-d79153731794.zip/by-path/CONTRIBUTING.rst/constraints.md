# Constraints for `CONTRIBUTING.rst`

## Rule

- **Rule:** For feature additions or changes, branch off the "main" branch (e.g., origin/main).
- **Applies to:**
  - `CONTRIBUTING.rst`
- **Condition:** when submitting a feature addition or change
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-7c59a811f665338431cf1c8d.md)

## Rule

- **Rule:** Create a branch to identify the issue being worked on; for bug or documentation fixes, branch off the latest ".x" branch (e.g., origin/8.1.x).
- **Applies to:**
  - `CONTRIBUTING.rst`
- **Condition:** when submitting a bug or documentation fix
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-c6aadb6598b3441a10ffb65f.md)
