# Constraints for `pyproject.toml`

## Rule

- **Rule:**
  ```text
  mypy is configured to ignore missing imports for modules matching "colorama.*".
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-897d46360a42d50902c31e5d.md)
