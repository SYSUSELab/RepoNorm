# Constraints for `tox.ini`

## Rule

- **Rule:**
  ```text
  The update-requirements tox environment sets skip_install to true.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0f04a1dc27abdebee6e89d9b.md)

## Rule

- **Rule:** The flit sdist build includes docs/, requirements/, tests/, CHANGES.rst, and tox.ini in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `requirements/**`
  - `tests/**`
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1d065bb8734bc157d796f0e9.md)

## Rule

- **Rule:**
  ```text
  The tox testenv `update-actions` declares `gha-update` as a dependency.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3f025800f2017d83bb644c80.md)

## Rule

- **Rule:** The testenv environment builds the package as a wheel.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5d3937932aafa73fc32d6851.md)

## Rule

- **Rule:** The update-requirements tox environment changes directory to requirements before running its commands.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-64b6be0952fad831d91f08e1.md)

## Rule

- **Rule:** The testenv environment uses frozen constraints.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6e592693bb2c580f4394955a.md)

## Rule

- **Rule:** The tox envlist defines environments py38, py39, py310, py311, py312, py313, pypy310, style, typing, and docs.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-85624daa819c6f7aef5c8844.md)

## Rule

- **Rule:**
  ```text
  The tox testenv `update-actions` runs the command `gha-update`.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-87a718e83f2513c13e73f92e.md)

## Rule

- **Rule:** The testenv environment uses .pkg as the wheel build environment.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-99f6267df723362e8f0f6adf.md)

## Rule

- **Rule:**
  ```text
  The tox environment `update-pre_commit` runs `pre-commit autoupdate -j4` as its command.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9cc6c0ab9ea73efc20c5ce5d.md)

## Rule

- **Rule:** The update-requirements tox environment declares pip-tools as its dependency.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a2a275c4ef65e73bd28aa9ad.md)

## Rule

- **Rule:** The testenv environment constrains package dependencies.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-be3e246bc4dca498f1f8e863.md)

## Rule

- **Rule:** Tox skips environments whose interpreter is missing rather than failing.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c8bcaee4108758565b8a29df.md)

## Rule

- **Rule:**
  ```text
  The tox testenv `update-actions` is labeled `update`.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d32211a6155e6b159bcbbd1f.md)

## Rule

- **Rule:** The testenv environment runs pytest with -v, --tb=short, --basetemp={envtmpdir}, and {posargs}.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d9eac712828b6a112adb51f3.md)
