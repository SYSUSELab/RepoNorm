# Constraints for `CHANGES.rst`

## Rule

- **Rule:** The flit sdist build includes docs/, requirements/, tests/, CHANGES.rst, and tox.ini in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `requirements/**`
  - `tests/**`
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1d065bb8734bc157d796f0e9.md)

## Rule

- **Rule:** An entry must be added in CHANGES.rst using the same style as other entries, and relevant docstrings must include .. versionchanged:: inline changelogs.
- **Applies to:**
  - `**/*.py`
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-5f637ae390e2a026b4cf63ac.md)
