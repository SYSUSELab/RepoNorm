# Constraints for `tests/test_info_dict.py`

## Rule

- **Rule:**
  ```text
  Tests that pin Click's public parameter/option introspection contract must keep the exact to_info_dict field set and values for each parameter kind (STRING/INT/BOOL, help option, name argument, number option, command, group), including group-only fields commands and chain.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  When modifying or extending the expected to_info_dict structures in the info-dict contract test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1126906c942ed89f50f7d7af.md)

## Rule

- **Rule:**
  ```text
  Tests that verify to_info_dict output must assert the exact keys for ParamType and Option instances, including param_type, name, choices, formats, min/max, and flag option fields.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  When adding or modifying tests for to_info_dict, preserve the exact key set asserted for each ParamType and Option instance.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b595732baec388eec82b2f7e.md)

## Rule

- **Rule:**
  ```text
  Tests that verify to_info_dict output for a nested Group must assert the commands mapping keyed by command name, each command's params including the auto-added help option, and the chain flag.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_info_dict.py that exercises to_info_dict on a nested Group.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d516a64d5e695826507c1bbe.md)
