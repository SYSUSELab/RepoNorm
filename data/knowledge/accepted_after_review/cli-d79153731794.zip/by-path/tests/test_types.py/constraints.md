# Constraints for `tests/test_types.py`

## Rule

- **Rule:**
  ```text
  Tests for click.Path(path_type=...) must assert that argument conversion returns the requested Python type (None/str/bytes/pathlib.Path).
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:**
  ```text
  When adding or modifying tests for click.Path path_type conversion behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-25bd58f0625229fe14009baf.md)

## Rule

- **Rule:**
  ```text
  The helper _non_utf8_filenames_supported must probe whether non-UTF-8 filenames are supported by attempting to create a file with a surrogate-escaped name in a temporary directory, returning False on OSError.
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying the non-UTF-8 filename support helper or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29cd82f4d91e77cf6477ddfe.md)

## Rule

- **Rule:** Tests must probe symlink support by creating a temporary directory, target file, and symlink, returning False on OSError so symlink-dependent behavior can be skipped on unsupported platforms.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:**
  ```text
  When modifying symlink-dependent test behavior or platform-skip logic exercised by tests/test_types.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4841fca006020bc9846fe612.md)

## Rule

- **Rule:**
  ```text
  Tests that verify FloatRange clamp/open interaction must assert that max_open with clamp is rejected at construction via TypeError and that enabling clamp after construction raises RuntimeError on out-of-range conversion.
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_types.py that exercises FloatRange clamp and open-bound interaction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fafb41f17edd46c36f7cc370.md)
