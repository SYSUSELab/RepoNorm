# Constraints for `tests/typing/typing_options.py`

## Rule

- **Rule:** Typing examples must pair an int-typed option with default=1 and a str-typed argument, showing the expected static typing pattern for click options and arguments.
- **Applies to:**
  - `tests/typing/typing_options.py`
- **Condition:** When adding or modifying typing examples for click options and arguments, preserve the pattern of an int-typed option with default=1 paired with a str-typed argument.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0f2b273e1ab3cf95bf0ad223.md)

## Rule

- **Rule:**
  ```text
  Typing tests must use typing_extensions.assert_type to assert that a decorated function is typed as click.Command, establishing the static typing contract for command decorators.
  ```
- **Applies to:**
  - `tests/typing/typing_options.py`
- **Condition:**
  ```text
  When adding or modifying typing tests for command decorators, preserve the use of typing_extensions.assert_type to assert the decorated function is typed as click.Command.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-81c033b38b8bd4b47060165e.md)
