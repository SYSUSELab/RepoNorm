# Constraints for `tests/typing/typing_aliased_group.py`

## Rule

- **Rule:** Typing tests for aliased groups must define commands on the aliased group to exercise the aliased-group typing surface.
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:** When adding or modifying typing tests for aliased group command definitions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-099dd9e8f60371d3c48c15b6.md)

## Rule

- **Rule:**
  ```text
  Typing tests for aliased groups must override resolve_command to return the full command name by asserting the resolved command is not None and returning cmd.name.
  ```
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:** When adding or modifying typing tests for aliased group command resolution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-29b025cb1925eb7476d62f47.md)

## Rule

- **Rule:** Typing tests for aliased groups must preserve the convention that the cli object is an AliasedGroup subclass of click.Group, tying the documented command-aliases example to the AliasedGroup type contract.
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:** When modifying typing tests for aliased groups.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-40d7f33cda41b4555684be80.md)
