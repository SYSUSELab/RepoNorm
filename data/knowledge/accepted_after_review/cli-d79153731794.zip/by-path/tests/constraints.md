# Constraints for `tests`

## Rule

- **Rule:** The flit sdist build includes docs/, requirements/, tests/, CHANGES.rst, and tox.ini in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `requirements/**`
  - `tests/**`
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1d065bb8734bc157d796f0e9.md)

## Rule

- **Rule:** Patches that add or change code must include tests, and the test must fail without the patch.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-76ab0a354e7518af7cdfa26d.md)

## Rule

- **Rule:** Coverage measurement is configured to source from the click and tests packages.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9aeaa14caa63bc7d00c05067.md)

## Rule

- **Rule:**
  ```text
  Pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bd8d44fe836bf4f6dc5dfb0f.md)
