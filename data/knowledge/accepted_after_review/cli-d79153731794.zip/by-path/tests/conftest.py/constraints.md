# Constraints for `tests/conftest.py`

## Rule

- **Rule:**
  ```text
  The shared test suite must import `CliRunner` from `click.testing` in `tests/conftest.py`, establishing the common runner fixture source.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When adding or modifying shared test fixtures in tests/conftest.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2f93c69e4e79885c2764ab9e.md)
