# Constraints for `tests/test_termui.py`

## Rule

- **Rule:** The Windows getchar test must parametrize over multi-byte and accented characters (including "é", "À", "字", "àH", "àR") and echo True/False, assert click.getchar returns the exact character, and be skipped unless running on Windows.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** Modifying or adding tests for click.getchar on Windows with multi-byte or accented characters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-11c7002fd4572619a2832829.md)

## Rule

- **Rule:**
  ```text
  Tests that assert progressbar ETA formatting must pin outputs including large values rendered as "1157407d 09:46:39" and `None` rendered as an empty string.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When adding or modifying progressbar ETA formatting tests in tests/test_termui.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3e27d5b7f4ae3a47d6301a96.md)

## Rule

- **Rule:**
  ```text
  Tests that assert `ProgressBar.time_per_iteration` must verify that an empty average list returns 0.0 and [1, 4] returns 2.5, defining the averaging behavior for iteration timing.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When adding or modifying `ProgressBar.time_per_iteration` tests in tests/test_termui.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6caf35c74823e199473feead.md)

## Rule

- **Rule:** Tests for click.secho must assert that passing None with nl=False writes no bytes rather than stringifying None.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** when adding or modifying tests for click.secho output behavior with None input
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-880cc6fd30f4d6495698eab3.md)

## Rule

- **Rule:** The progress bar update formatting must render exact percentage and elapsed-time strings across rendered lines, as asserted by monkeypatching time and isatty.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** Modifying or adding tests that assert progress bar update formatting with controlled time and isatty.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8c4c4bb4d2b39290b13f44d3.md)

## Rule

- **Rule:** Tests that exercise a hidden progressbar must assert that hidden progress rendering is suppressed, producing empty output.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When adding or modifying tests for a hidden progressbar, preserve the assertion that hidden progress rendering is suppressed and output is empty.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8e719395eb8005987e890389.md)

## Rule

- **Rule:** Progress bars must be used as context managers; iterating a progress bar outside its with block raises RuntimeError matching 'with block'.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying progress bar usage or tests that iterate progress bars.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9a7da0baa449f28198dc5f5a.md)

## Rule

- **Rule:** Progressbar length-hint handling must not raise when isatty is True.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When modifying progressbar length-hint handling or isatty-dependent rendering exercised by tests/test_termui.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e2eb17e42a8709b359bb9de2.md)

## Rule

- **Rule:**
  ```text
  Tests for confirmed hidden input must preserve the convention that a password option combines prompt, hide_input=True, default, and confirmation_prompt.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying tests for confirmed hidden input options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ed5145baea9e817a4400e4a7.md)

## Rule

- **Rule:**
  ```text
  Tests for prompt_required=False must preserve the convention that a flag without a value prompts while a flag with a value does not, and the next option flag is not consumed as the value.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When modifying prompt_required=False parametrized tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f1d38b12266a6cc75a866326.md)
