# Constraints for `tests/test_options.py`

## Rule

- **Rule:** Tests for case-insensitive choice options must assert that the exact configured choice value is returned rather than the user-supplied casing.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when adding or modifying a test for a case-insensitive choice option
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0ad42162fe1ba1c2a455a4f0.md)

## Rule

- **Rule:**
  ```text
  Tests that assert duplicate option-name detection must invoke the CLI and expect a `UserWarning`, covering both duplicate short names and duplicate long names.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying duplicate option-name detection tests in tests/test_options.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0d396bf4da64442a8797836e.md)

## Rule

- **Rule:**
  ```text
  Tests for flag_value typing must preserve the convention that an Option with flag_value infers click.INT regardless of whether a default is also supplied.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying flag_value type-inference tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1328422207e30d4f3548a151.md)

## Rule

- **Rule:**
  ```text
  A multiple option with flag_value and is_flag=False must collect a tuple mixing the flag value and explicit values in argument order, while a following option and variadic argument are parsed independently.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying multiple option parsing or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-22dd3c451d546b8784ad93a3.md)

## Rule

- **Rule:** Slash-prefixed boolean option pairs like "/debug;/no-debug" must be supported, with the semicolon separating positive and negative forms and the callback receiving the boolean value.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** Modifying or adding tests that assert slash-prefixed boolean option pair parsing and callback values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-238e4a8e5873a01714ed899d.md)

## Rule

- **Rule:** A boolean flag declared as '--shout/--no-shout' with envvar='SHOUT' must echo the parsed boolean value, demonstrating envvar-driven boolean flag parsing.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying boolean flag envvar parsing or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-302723f5ae7e95cabbcadb50.md)

## Rule

- **Rule:** Tests that verify secondary option names with a leading space must define a boolean flag option with both the --warnings/--no-warnings pair and the space-prefixed alias, asserting the alias is accepted.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_options.py that exercises secondary option names with a leading space.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-319b08f6578819459d7e543f.md)

## Rule

- **Rule:**
  ```text
  Tests for option default validation must preserve the convention that constructing click.Option with an invalid default for the given multiple/nargs combination raises ValueError matching 'default', covering (False,2,[1]) and (True,2,[[1]]).
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying option default validation tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3b8c270227634f4f93b09755.md)

## Rule

- **Rule:**
  ```text
  click.Option must raise TypeError with the specific messages "'count' is not valid with 'multiple'." and "'count' is not valid with 'is_flag'." when count is combined with multiple or is_flag.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** Modifying or adding tests that assert TypeError messages for invalid count flag combinations.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-40e372284ccab2add185b4d1.md)

## Rule

- **Rule:**
  ```text
  Tests that verify envvar splitting must assert that multiple envvar values are split on whitespace and on os.path.pathsep, producing the expected joined output for both auto_envvar_prefix and explicit env cases.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_options.py that exercises envvar value splitting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-423394c809d89d089ea542ba.md)

## Rule

- **Rule:** When an option's envvar is displayed in help output, the envvar name (e.g. 'ARG1') must appear in the help text.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying envvar help display or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-436e4c0c4b053bdb979e42ca.md)

## Rule

- **Rule:**
  ```text
  Option.show_default must override Context.show_default; a string show_default value must render as a parenthesized default in help, and a False option-level value must suppress the default even when the context enables it.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  Modifying or adding tests for show_default precedence between Option and Context.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-668b4df111c00cd7a5d2ad16.md)

## Rule

- **Rule:** Tests for dynamic default help text must assert that help output shows the option name and dynamic default text '(current user)' while not leaking the lambda source.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When adding or modifying tests for dynamic default help text rendering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-69ede35ff9869ac03d5afaec.md)

## Rule

- **Rule:**
  ```text
  Tests that verify is_bool_flag must assert it is True only for is_flag=True, secondary options like '-a/-A', and bool flag_value=True, while int/bool non-flag options and non-bool flag_value remain False.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying tests for is_bool_flag detection, preserve the exact truth table covering is_flag, secondary options, and flag_value types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6adf31e992d4fdca1c9dd038.md)

## Rule

- **Rule:** Tests that assert dynamic-default help output must verify that an unset dynamic default renders as '(dynamic)' without leaking the lambda source text, while still listing the option name.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying dynamic-default help tests in tests/test_options.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-92cd2c926c8790235d4f0a37.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Click's multiple=True option combined with envvar must assert that the environment value is split into multiple option values joined by '|'.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying a test for a multiple=True option that also declares an envvar, preserve the assertion that the envvar string is split on '|' into multiple option values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9635bf4f0b0e59a8153737c3.md)

## Rule

- **Rule:** Boolean envvar parsing must tolerate leading and trailing whitespace around the value (e.g. ' true ' parses as True).
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying boolean envvar parsing behavior exercised by tests/test_options.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9772668c9f87954fd2c1a6d4.md)

## Rule

- **Rule:**
  ```text
  When auto_envvar_prefix is supplied to runner.invoke, the help output must include the auto-generated environment variable name formed from that prefix and the option name (e.g. TEST_ARG1).
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  Modifying or adding tests that assert help output for options under an auto_envvar_prefix.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a2420003c1334a5bd4018198.md)

## Rule

- **Rule:** Tests for composite options with nargs=2 and multiple=True must assert that repeated flags each consume two values and are echoed in order.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when adding or modifying tests for composite options that combine nargs=2 with multiple=True
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a5678523612831d199c95a5c.md)

## Rule

- **Rule:** Tests for option naming must preserve the convention that Click accepts multi-character single-dash option names such as "-whatever".
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying option-naming tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b4d37864e51f0ed1c1b4e35c.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise a Choice with case_sensitive=False must assert that values differing only in case from the declared choices are accepted.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying tests for a Choice option with case_sensitive=False, preserve the assertion that a differently-cased value is accepted.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-baad81ea8ec26fc9ec396695.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Click option parsing must drive the CLI through CliRunner.invoke with standalone_mode=False and catch_exceptions=False so the parsed return_value can be inspected directly.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when adding or modifying option-parsing tests that need to inspect the parsed result rather than the exit status
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c14a9808cbb2744fab9392ef.md)

## Rule

- **Rule:** Tests for boolean flag options must declare the option with default False and type bool, using the --shout/--no-shout naming pattern.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When adding or modifying tests for boolean flag option declaration behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d69ac4a2700c8b3e40596277.md)

## Rule

- **Rule:** Tests for custom option validation must assert that invalid values produce the exact error message "Invalid value for '--foo': Value needs to be positive" and that valid values pass through unchanged.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when adding or modifying a test for a custom option callback that validates input
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dcdea4898b2757994b8eeb37.md)

## Rule

- **Rule:**
  ```text
  With help_option_names=['/?'], /debug and /no-debug must toggle a flag, absent flag defaults to False, and help output must list '/debug; /no-debug' and '/?'.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying Windows-style option handling or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dd0b0c46248e9afd8850681e.md)

## Rule

- **Rule:**
  ```text
  When a string show_default is set on an option, the help record must render the default wrapped in parentheses inside the '[default: ...]' segment (e.g. '[default: (unlimited)]').
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  Modifying or adding tests that assert help output for options configured with a string show_default.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e11c303ab9196652b4f2198d.md)

## Rule

- **Rule:**
  ```text
  Option tests use show_envvar=True with envvar="ARG1" to exercise envvar display in help output.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying or adding option tests that exercise envvar display in help output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e695eb8a1032eb000b567cea.md)

## Rule

- **Rule:**
  ```text
  With auto_envvar_prefix and an nargs>1 argument, the envvar value must be split on whitespace into individual argument values (e.g. "foo bar" -> "foo|bar", "x 1 y 2" -> "x|1\ny|2"); tests must assert this whitespace-splitting behavior.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  Modifying or adding tests for envvar handling of nargs>1 arguments under auto_envvar_prefix.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f4df59c42b144bac67b1f99f.md)

## Rule

- **Rule:** Tests for missing required choice options must assert exit code 2 and that the error output contains "Error: Missing option '--foo'. " followed by a "Choose from" list including the configured choices.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when adding or modifying a test for a missing required choice option
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f58fff794e10737bdc9800ec.md)
