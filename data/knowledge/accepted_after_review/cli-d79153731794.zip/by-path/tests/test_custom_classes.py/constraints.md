# Constraints for `tests/test_custom_classes.py`

## Rule

- **Rule:**
  ```text
  Tests that verify custom formatter_class on a context must assert that the custom formatter is used for help formatting, e.g. by checking colorized output in context.get_help().
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:**
  ```text
  when adding or modifying a test that verifies custom formatter_class on a context
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0babc649a500127d3ade9d3e.md)

## Rule

- **Rule:**
  ```text
  A command configured with a custom context_class must produce a context of that type when make_context is called.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:**
  ```text
  Modifying or adding tests that verify context type selection for commands with a custom context_class.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6f6c529b5c6f1b6d72f2a65a.md)

## Rule

- **Rule:**
  ```text
  Command subclasses can override the context class used for invocation by setting context_class to a custom Context subclass.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** When modifying Command subclass context class resolution or adding tests for custom context classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8f206ff90e133efb43f5f0fa.md)
