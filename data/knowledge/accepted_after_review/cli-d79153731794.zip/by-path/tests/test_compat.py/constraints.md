# Constraints for `tests/test_compat.py`

## Rule

- **Rule:**
  ```text
  should_strip_ansi must return False for streams whose __module__ is "ipykernel.faked", i.e. Jupyter kernel output streams are detected by module name and not stripped.
  ```
- **Applies to:**
  - `tests/test_compat.py`
- **Condition:** Modifying or adding tests that assert ANSI stripping behavior for Jupyter kernel output streams.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ba8093b71b7e08f5fbb8f1cd.md)
