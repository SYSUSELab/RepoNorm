# Constraints for `tests/test_defaults.py`

## Rule

- **Rule:** Multiple=True flags must default to empty tuples, and supplying repeated flags must accumulate values into tuples (e.g. ((True, False), (True,), (1, -1))).
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** Modifying or adding tests that assert default and accumulation behavior for multiple=True flags.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0a64c4c337cf3c20698b525b.md)

## Rule

- **Rule:**
  ```text
  Tests that verify multiple=True option handling must exercise composition with each flag-detection path: secondary token (-y/-n), is_flag=True, and flag_value.
  ```
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** when adding or modifying a test that verifies multiple=True option handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29b139bd78253d509eb39084.md)

## Rule

- **Rule:**
  ```text
  Tests that verify default_map overrides must pass default_map to runner.invoke and assert the overridden output, covering both command parameter defaults and flag defaults (including help-text default display).
  ```
- **Applies to:**
  - `tests/test_commands.py`
  - `tests/test_defaults.py`
- **Condition:**
  ```text
  when adding or modifying a test that verifies default_map overriding of command or flag defaults
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-33b65c6cf2abc0989eacad3c.md)

## Rule

- **Rule:** Tests that exercise multiple-default output must assert no exception and that output lines are exactly the expected ordered and formatted values.
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** When adding or modifying tests for multiple-default output, preserve the assertion that output lines are exactly the expected ordered and formatted values with no exception.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b1e179991bf0ce3e2ecd395.md)

## Rule

- **Rule:** Tests for click.option with multiple=True and nargs=2 must use a tuple-of-tuples default and assert repeated two-value groups are yielded to the command.
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** When adding or modifying tests for click.option with multiple=True and nargs=2.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-de0d6d036fa485836c93b6de.md)

## Rule

- **Rule:** Tests for multiple options with list defaults must assert that each default item is coerced through the declared type.
- **Applies to:**
  - `tests/test_defaults.py`
- **Condition:** when adding or modifying tests for multiple options with list defaults and a declared type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e271758116d1788b49e9272d.md)
