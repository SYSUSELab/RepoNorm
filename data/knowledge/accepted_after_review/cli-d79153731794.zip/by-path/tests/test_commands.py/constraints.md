# Constraints for `tests/test_commands.py`

## Rule

- **Rule:** Tests for deprecated commands must assert that '(Deprecated)' appears in CLI help output, parametrizing over doc values including None to cover documented and undocumented commands.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When adding or modifying tests for deprecated command help output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-06e082a3865a02c22611c068.md)

## Rule

- **Rule:** Invoking a deprecated command must emit 'DeprecationWarning:' in the runner output.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When modifying deprecation warning behavior or tests for deprecated commands.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1d73e1cde0d0a71889da4cd0.md)

## Rule

- **Rule:**
  ```text
  test_group_with_args must parametrize expected exit codes and output: missing command yields exit 2 with 'Error: Missing command.', --help yields 0, a valid subcommand yields 0 with 'obj=obj1\nmove\n', and no args yields 2 with help text.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When modifying group argument handling or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2e84983019990c1557097b38.md)

## Rule

- **Rule:**
  ```text
  Tests that verify default_map overrides must pass default_map to runner.invoke and assert the overridden output, covering both command parameter defaults and flag defaults (including help-text default display).
  ```
- **Applies to:**
  - `tests/test_commands.py`
  - `tests/test_defaults.py`
- **Condition:**
  ```text
  when adding or modifying a test that verifies default_map overriding of command or flag defaults
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-33b65c6cf2abc0989eacad3c.md)

## Rule

- **Rule:**
  ```text
  Tests that verify object propagation across the chain loop must assert that invoking the CLI produces no exception and output exactly 'Debug is off\n'.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** when adding or modifying a test that verifies object propagation across the chain loop
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-48c6b96640af39276fef29e4.md)

## Rule

- **Rule:** The custom parser test must wire an optparse.OptionParser into a Click command and assert both the parsed argument output and that --help renders the optparse usage and option list, preserving the custom parser help contract.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** Modifying or adding tests that integrate a custom parser (e.g. optparse) with a Click command.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-596b375b93ad25c15dd48287.md)

## Rule

- **Rule:**
  ```text
  Tests for Group.parse_args must assert that base option prefixes are collected into ctx._opt_prefixes.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  when adding or modifying tests for Group.parse_args option-prefix collection
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5d0fc273740a3cea1cfab7d7.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Click's no_args_is_help behavior must assert exit code 2 and that the help text is printed when the command is invoked without arguments.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  when adding or modifying a test for a command configured with no_args_is_help
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6225bd35d507d354ff7d822d.md)

## Rule

- **Rule:** Tests that verify option-prefix collection across a group must assert the exact set of prefixes used by subcommands, not merely that collection occurred.
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_commands.py that exercises option-prefix collection on a group.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7085fbceb9f2806ba0f4657c.md)

## Rule

- **Rule:**
  ```text
  Tests that assert option-prefix collection must verify that parsing args populates `ctx._opt_prefixes` with the set {"-", "--", "+", "!"}.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  When adding or modifying option-prefix collection tests in tests/test_commands.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7bebad9598cfb5c8b549ee50.md)

## Rule

- **Rule:**
  ```text
  When a command is added under a registered name different from its original name, invocation and default_map lookup must use the registered name, not the original command name.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:** When modifying command registration or invocation logic that handles renamed commands.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a8fb2598dbe73563aa1aff52.md)

## Rule

- **Rule:**
  ```text
  When a command is invoked with standalone_mode=False, its return value must be the typed default values (e.g. a string default cast to int, an empty multiple option as an empty tuple rather than None), so tests asserting on the returned object must expect the cast/coerced form.
  ```
- **Applies to:**
  - `tests/test_commands.py`
- **Condition:**
  ```text
  Modifying or adding tests that invoke a Click command with standalone_mode=False and assert on the returned default values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bf9827f43fa224efe04544aa.md)
