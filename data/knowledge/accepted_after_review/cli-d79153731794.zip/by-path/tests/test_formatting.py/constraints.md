# Constraints for `tests/test_formatting.py`

## Rule

- **Rule:** Tests for usage-error formatting must preserve the convention that a missing required argument produces exit code 2 and a four-line usage/error output including a blank line before the Error line.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying usage-error formatting tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-022c1a552ce02c81588d1173.md)

## Rule

- **Rule:** Tests that verify multi-level help formatting must define nested groups with docstrings and assert the formatted help output.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** when adding or modifying a test that verifies multi-level help formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-054ae17bcf5c01e53a50385a.md)

## Rule

- **Rule:** Tests that exercise a metavar override on a positional argument must define the argument with metavar="metavar" and assert the supported override.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When adding or modifying tests for metavar override on a positional argument, preserve the use of metavar="metavar" and the assertion of the supported override.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-536a723aadfdcb51b0daf585.md)

## Rule

- **Rule:** Tests that verify custom help-option formatting must assert the exact exit code and the exact usage, help-hint, and error lines produced, rather than only checking that an error occurred.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_formatting.py that exercises custom help-option usage or missing-argument error formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6aaee7e8271eb500c9c76de8.md)

## Rule

- **Rule:**
  ```text
  HelpFormatter.write_text must wrap text at the formatter width and apply current_indent to each wrapped line.
  ```
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:**
  ```text
  When modifying HelpFormatter.write_text wrapping or indentation behavior exercised by tests/test_formatting.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b6ed26003a1c222940f3b89f.md)

## Rule

- **Rule:**
  ```text
  Tests must override help_option_names via context_settings (e.g. to ['--man']) to verify custom help option configuration.
  ```
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:**
  ```text
  When modifying custom help option configuration or context_settings handling exercised by tests/test_formatting.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c243d4f4bcf82dd7a939c5df.md)

## Rule

- **Rule:** Help output must wrap long option strings at the formatter width, breaking the usage line across lines at the configured terminal width rather than emitting a single long line.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:**
  ```text
  When modifying help formatting or usage-line rendering behavior exercised by tests/test_formatting.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f50a423a2762de32bb7d9a5a.md)
