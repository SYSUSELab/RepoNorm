# Constraints for `tests/test_normalization.py`

## Rule

- **Rule:** Normalization tests must register a command that echoes 'here!' to exercise command-name normalization behavior.
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:** When modifying command-name normalization tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-11ac4dfa7049a919db979662.md)

## Rule

- **Rule:**
  ```text
  Tests for option-name normalization under custom context settings must define a command with context_settings and options to exercise normalization.
  ```
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:** when adding or modifying tests for option-name normalization with custom context settings
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-199762eb62d491d7deda2d38.md)

## Rule

- **Rule:**
  ```text
  Normalization tests must preserve the convention that CONTEXT_SETTINGS uses token_normalize_func=lambda x: x.lower(), establishing lowercase token normalization as the tested convention.
  ```
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:** When modifying token normalization tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9c5e243fcd27c4912ad43a3a.md)

## Rule

- **Rule:** Tests that assert CLI option-name normalization must verify that uppercase long options and short options are accepted case-insensitively while the echoed values remain unchanged.
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:**
  ```text
  When adding or modifying option-normalization tests in tests/test_normalization.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a0cdb589a7168598a613000f.md)
