# Constraints for `tests/test_utils.py`

## Rule

- **Rule:**
  ```text
  Tests defining a command that echoes a bytes literal (e.g. b'\xf6') must exercise byte output handling.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** Modifying or adding tests that define commands echoing bytes literals to exercise byte output handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0f2585559dada1bb69b8d669.md)

## Rule

- **Rule:**
  ```text
  Tests that assert `_detect_program_name` output must cover parametrized path/main/expected cases, including `__main__.py` mapping to 'python -m example' and `cli.py` mapping to 'python -m example.cli'.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying `_detect_program_name` tests in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4e6390187e53202554b57377.md)

## Rule

- **Rule:** Tests that verify click.echo robustness must assert that echo does not fail when sys.stdout and sys.stderr are None, the condition that occurs with pythonw on Windows.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_utils.py that exercises click.echo under missing streams.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5192dcdf3fb8789ce0461411.md)

## Rule

- **Rule:**
  ```text
  Tests that assert `click.echo` output must verify that it writes to stdout with a trailing newline, using `capsys` to capture output.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying `click.echo` output tests in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7f5d80147f2c33119966af97.md)

## Rule

- **Rule:** Tests for click.style and click.unstyle must verify that style keys map to the specific ANSI escape sequences (fg 30-37, bg 40-47, 256-color bg 48;5;N, truecolor bg 48;2;R;G;B, bold 1, dim 2, underline 4, overline 53, italic 3, blink 5, reverse 7, strikethrough 9) and that False values emit the corresponding reset codes (22, 24, 55, 23, 25, 27, 29), with unstyle reversing the styling.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying a test for click.style or click.unstyle ANSI escape sequence mapping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a1f492bc4926c0b38cce5f14.md)

## Rule

- **Rule:** click.echo must preserve raw bytes and bytearray output without stripping ANSI escape sequences, and must encode unicode text (e.g. snowman) as UTF-8 bytes.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** Modifying or adding tests that assert byte-level output behavior of click.echo.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ab7c2a6886ee4021454b53b1.md)

## Rule

- **Rule:** Tests for prompt defaults must assert that a default value is cast through the declared type before being returned.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests for prompt default handling with a declared type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b3af8dd7ada586771312bf78.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise prompt default selection must preserve the mapping between the prompt's default marker and empty-input outcome: a [y/N] prompt yields 'no' on empty input, while a [Y/n] prompt yields 'yes' on empty input.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding prompt tests that assert default selection behavior for empty input.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d4bbc6fed1a027641b868b2d.md)

## Rule

- **Rule:**
  ```text
  _expand_args must return unmatched glob patterns and pytest-style identifiers containing '::' unchanged rather than raising or dropping them.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When modifying _expand_args or its tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e7593bfc79bb9066e88635fa.md)

## Rule

- **Rule:** Tests for atomic file writes must assert that a newly written file's permissions match the umask-derived permissions of a reference file, and must be skipped on Windows.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests for atomic file write permissions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fda89c5e3e77b1e54ca10f7e.md)
