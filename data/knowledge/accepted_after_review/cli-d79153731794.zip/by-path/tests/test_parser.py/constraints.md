# Constraints for `tests/test_parser.py`

## Rule

- **Rule:** Tests for the option parser must preserve the convention that default option prefixes are exactly {"-", "--"}.
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:** When modifying option-prefix default tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1efffd01c04412009a1a0c45.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise internal parser and shell-completion helpers must import them directly from their private modules (click.parser._OptionParser, click.shell_completion.split_arg_string) rather than through public re-exports.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_parser.py that exercises internal parser or shell-completion helpers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-487e12d1d2429c27d07dc735.md)

## Rule

- **Rule:**
  ```text
  Option prefixes are collected dynamically: adding options with '+p' and '!e' expands _opt_prefixes to include '-', '--', '+', and '!'.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:** When modifying option prefix collection logic or adding tests for dynamic prefix expansion.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-49318b7e2d838cb311936aac.md)

## Rule

- **Rule:**
  ```text
  split_arg_string must tolerate unbalanced quotes and trailing backslashes, yielding the documented token lists (e.g. "cli 'my file" -> ["cli","my file"], "cli my\\" -> ["cli","my"], "cli my\\ file" -> ["cli","my file"]); tests must preserve these exact outputs.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:**
  ```text
  Modifying or adding tests for split_arg_string's handling of malformed quoting or trailing backslashes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a1817483a8fa11a820bbc1c2.md)
