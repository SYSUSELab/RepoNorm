# Constraints for `tests/test_chain.py`

## Rule

- **Rule:** Tests for pipeline command chaining must parametrize over args/input/expect triples and assert that pipeline commands with '-f -' and optional strip/uppercase transforms produce the expected split lines.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** When adding or modifying tests for pipeline command chaining behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2b5ccf41a26b115ec0173c27.md)

## Rule

- **Rule:** The chain test must define a command 'b' that calls debug(), used to exercise chained command invocation behavior.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** When modifying chained command invocation tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5ad73e560e645a50bbac0d09.md)

## Rule

- **Rule:** Tests that exercise a chained group must define it with click.group(chain=True) and assert the chained multi-command invocation protocol.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** When adding or modifying tests for chained group invocation, preserve the use of click.group(chain=True) and the assertion of the chained multi-command protocol.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6b0b3782ea6eea4acd88134f.md)

## Rule

- **Rule:** Tests for command name overrides must register commands with an explicit name via @cli.command('name') to override the function name.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** When adding or modifying tests that register commands with explicit name overrides.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6f584f7d6f00a09b6bd3f182.md)

## Rule

- **Rule:** Tests for chained groups must exercise variadic arguments to verify they are rejected or handled in a specific way.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** when adding or modifying tests for chained groups with variadic arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8063f5dd3d698c5a97a0d0dd.md)

## Rule

- **Rule:**
  ```text
  Tests that trace chain invocations must use a debug helper that echoes the calling function name via sys._getframe(1).f_code.co_name and the current context args via click.get_current_context().args.
  ```
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_chain.py that traces chain invocations.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ba5834a46174915b3054a1c5.md)

## Rule

- **Rule:** Tests that verify chained group behavior must define a chained group with an optional variadic argument and assert the resulting behavior.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** when adding or modifying a test that verifies chained group behavior with optional variadic arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bb7d963e1920d1d5be1afdf0.md)

## Rule

- **Rule:** Tests that exercise a chained group with per-subcommand options must assert that each chained subcommand receives its own option value, producing distinct output lines.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** When adding or modifying tests for a chained group where subcommands take options, preserve the assertion that each subcommand receives its own option value.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cf818ccc89f8d7802c595ecf.md)

## Rule

- **Rule:** Tests defining commands that call debug() must exercise chain command behavior.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** Modifying or adding tests that define commands calling debug() to exercise chain behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d87d3e6165e1ff659abbe6df.md)

## Rule

- **Rule:** Chained subcommands must be able to declare required positional arguments (e.g. 'format') and echo them.
- **Applies to:**
  - `tests/test_chain.py`
- **Condition:** Modifying or adding tests that assert chained subcommands accepting and echoing positional arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f096d111a0d8ff953397ef54.md)
