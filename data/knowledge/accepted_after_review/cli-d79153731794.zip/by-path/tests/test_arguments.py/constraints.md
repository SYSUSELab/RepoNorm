# Constraints for `tests/test_arguments.py`

## Rule

- **Rule:** Tests for CLI decorator composition must preserve the convention that a group command can combine click.argument('arg2') and click.option('--opt2') on the same callback.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying tests that compose group, argument, and option decorators on one callback.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-044d4b6d08edeb272eaa376a.md)

## Rule

- **Rule:**
  ```text
  test_arguments.py must unpack a tuple argument into name and id and format id with :d, showing tuple-typed argument handling.
  ```
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying tuple-typed argument handling or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3916d0c2dab7dc2bd9990297.md)

## Rule

- **Rule:**
  ```text
  Tests that assert unbounded `nargs=-1` arguments must verify that supplying a default raises `TypeError` matching 'nargs=-1'.
  ```
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:**
  ```text
  When adding or modifying argument-validation tests in tests/test_arguments.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-43198279193c122547207733.md)

## Rule

- **Rule:** Tests covering envvar population of variadic arguments must preserve the convention that nargs=-1 accepts any count of envvar-split values while a fixed nargs (e.g. nargs=2) raises BadParameter when the value count differs.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying envvar handling tests for variadic or fixed-nargs arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-53ef2debcc52aaedb8ed88d8.md)

## Rule

- **Rule:** Tests that verify argument decoding must assert that UTF-8 encoded arguments are implicitly converted to str.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** when adding or modifying a test that verifies argument decoding from bytes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-72b4568a06f72dd70bde223b.md)

## Rule

- **Rule:** Constructing an Argument with nargs=2 and a default whose length is not 2 must raise ValueError mentioning nargs=2; tests must assert this validation error.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** Modifying or adding tests for Argument default validation against nargs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8f251cb483707bd115594f7b.md)

## Rule

- **Rule:** A variadic argument declared with nargs=-1 and required=True must receive a tuple of values.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:**
  ```text
  When modifying variadic argument handling for nargs=-1 with required=True exercised by tests/test_arguments.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9b475fe618b337789429df4a.md)

## Rule

- **Rule:** Tests for tuple type specifications must parametrize over equivalent forms (type=(str, int), click.Tuple, nargs=2) and assert they all produce the same output.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests for tuple type argument specifications.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a9366a0242eec70a9453a1e1.md)

## Rule

- **Rule:** Tests for duplicate argument names must assert that a UserWarning is raised when the command is invoked, using pytest.warns(UserWarning).
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests for duplicate argument name handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bc8d260b834581b9343c6b92.md)

## Rule

- **Rule:** Tests for byte argument handling must patch filesystem/default encodings and stdin encoding to utf-8 before invoking a command with non-ASCII bytes.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When adding or modifying tests for byte argument handling with non-ASCII input.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e1d5481b262b585c9654a505.md)
