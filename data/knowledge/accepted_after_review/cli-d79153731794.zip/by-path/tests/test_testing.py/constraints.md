# Constraints for `tests/test_testing.py`

## Rule

- **Rule:**
  ```text
  CliRunner.invoke with input=BytesIO(...) must feed bytes to the command's stdin, and with echo_stdin=True the same input must also be echoed to output so it appears twice in result.output.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  Modifying or adding tests that exercise CliRunner.invoke stdin handling with BytesIO input and echo_stdin.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-13cb6c13f8290676937a2f8d.md)

## Rule

- **Rule:** Tests that verify CliRunner color forcing must assert both the default plain output and the color-forced styled output, rather than only one of the two.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_testing.py that exercises CliRunner color forcing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3acb20ccdc598999dd35800d.md)

## Rule

- **Rule:**
  ```text
  Tests that verify isolated_filesystem with a custom temp_dir must assert the directory persists after context exit and require explicit cleanup by the caller.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  when adding or modifying a test that verifies isolated_filesystem with a custom temp_dir
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4c6a29688421b7ab913aeef2.md)

## Rule

- **Rule:**
  ```text
  The testing test defines a getchar_echo command that echoes click.getchar(echo=True), exercising the echo parameter of getchar.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying or adding tests that exercise the echo parameter of click.getchar.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-51e924d8388fa09f020a3b47.md)

## Rule

- **Rule:** Tests for stderr encoding errors must assert that surrogate characters are escaped rather than raising UnicodeEncodeError.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** when adding or modifying tests for stderr output with unencodable characters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-522497aecc7fc709f747ae29.md)

## Rule

- **Rule:** Tests that verify CliRunner environment isolation must assert both that the env dict is visible to the invoked command and that os.environ is restored to its original state after invocation.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  When adding or modifying a test in tests/test_testing.py that exercises CliRunner.invoke with an env argument.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5578cd78b528cc1ba1fd4bd9.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise `CliRunner` error-output handling must define a command raising `CLIError("Red error")` to drive the error-output path.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  When adding or modifying `CliRunner` error-output tests in tests/test_testing.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8553e27ae8b1badcac478877.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise per-invocation prog_name override must assert that invoking with prog_name="foobar" succeeds and produces the expected output, preserving the ability to override prog_name at invocation time.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  Modifying or adding tests that pass prog_name to a CliRunner invocation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8a33e2a9adf3bbaec35cb42f.md)

## Rule

- **Rule:**
  ```text
  Tests for interactive prompting must use prompt=True on the option and exercise the CliRunner input path; hidden-input tests must additionally set hide_input=True.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** when adding or modifying a test for interactive or hidden-input prompting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8ad3da945a9136dd46058dd7.md)

## Rule

- **Rule:** The testing example command must use click.secho('hello world', fg='blue') to illustrate colored output under the CliRunner testing harness.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** Modifying or adding tests that demonstrate colored output via CliRunner.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e072b42841fc2b0c394b0b01.md)

## Rule

- **Rule:** Tests for CliRunner.invoke with input must preserve the convention that provided input is echoed back in result.output without raising an exception.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying CliRunner input-echo tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e5052f59e756a39f33bbda2b.md)

## Rule

- **Rule:** Tests that exercise CliRunner environment-variable injection must define the command to read the injected variable (e.g. via os.environ) and assert the echoed value, so env injection through CliRunner is verified end-to-end.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** when adding or modifying a CliRunner test that verifies environment-variable injection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ff589ea0cdcde090cd0e0301.md)
