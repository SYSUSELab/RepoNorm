# Constraints for `tests/test_shell_completion.py`

## Rule

- **Rule:** Shell completion must stop offering options after a literal '--' terminator and instead offer the argument's Choice values, including values that themselves look like options.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying shell completion logic or its tests for argument completion after a '--' terminator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1200bc28f2c8b7da5b958758.md)

## Rule

- **Rule:** Shell completion word generation must respect Argument nargs, including Choice values and nargs=-1, and must skip consumed option values.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying shell completion word generation logic or adding tests for Argument nargs handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1278ea342d44bad61ee29db7.md)

## Rule

- **Rule:**
  ```text
  Shell completion tests must use a _get_words helper that maps _get_completions results to their .value strings for assertions.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** Modifying or adding shell completion tests that assert completion values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-19c86316c3b175ebc72c143c.md)

## Rule

- **Rule:**
  ```text
  Shell completion tests must import click.shell_completion and specific core/type classes, and must not turn ResourceWarning into an error.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when adding or modifying imports or warning filters in shell completion tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-28296a7435e470486cd068a0.md)

## Rule

- **Rule:** Tests that verify per-command option scoping in shell completion must define a group and subcommand sharing the same option name and assert that completion offers only the current command's options after the group option is consumed.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when adding or modifying a test that verifies option scoping across group and subcommand in shell completion
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-76b55c744ddd90fcc1e4d99a.md)

## Rule

- **Rule:** Tests for choice shell completion must assert that candidates are filtered by literal prefix, including special characters like '!' and '+'.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when adding or modifying shell completion tests for choice parameters with special-character candidates
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8a6e3fc8a49570f97405faf6.md)

## Rule

- **Rule:** Tests that exercise shell completion for a Choice option must assert that candidates are filtered by the current word prefix, returning all choices for an empty prefix and narrowing as the prefix grows.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When adding or modifying tests for Choice option shell completion, preserve the assertion that candidates are filtered by the current word prefix.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-928a44b81c907ac12d64c293.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise shell-completion behavior must isolate the global `click.shell_completion._available_shells` state by snapshotting it before the test and restoring the previous contents afterward.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying a test that reads or mutates shell-completion state in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b6e507d6349bbfcd5dadec33.md)

## Rule

- **Rule:**
  ```text
  Tests that assert shell-completion type mapping must verify that `File()` and `Path()` map to completion type 'file' while `Path(file_okay=False)` maps to 'dir'.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying shell-completion type-mapping tests in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c50aff1e527b48eab2f05269.md)

## Rule

- **Rule:** Shell completion word filtering must treat a leading '+' as an option prefix even when a Choice option's values also begin with '+', so conflicting prefixes resolve to the option rather than the choice value.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying shell completion word filtering logic or adding tests for option/choice prefix conflicts.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d31e76a10a7961fc48c8ee03.md)

## Rule

- **Rule:** Shell completion must offer both --on and --off as completion words for a flag option, and after --on the choice argument must offer its choices.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When modifying shell completion word generation for flag options or choice arguments exercised by tests/test_shell_completion.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d4cccc985db47ebea4077abb.md)

## Rule

- **Rule:**
  ```text
  Shell completion tests must monkeypatch BashComplete._check_version to always return True to isolate completion tests from the installed bash version.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When adding or modifying shell completion tests that depend on bash version checks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d8403e29a511e9607d845a19.md)

## Rule

- **Rule:**
  ```text
  Tests for shell completion of the help option must assert that --help is offered when help is enabled and nothing is offered when add_help_option=False.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when adding or modifying shell completion tests for the help option
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-de518b7c3ed8d22595391eb5.md)
