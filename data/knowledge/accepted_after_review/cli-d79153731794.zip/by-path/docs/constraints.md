# Constraints for `docs`

## Rule

- **Rule:**
  ```text
  The docs tox environment builds documentation with sphinx-build using -E -W -b dirhtml, reading docs and writing to docs/_build/dirhtml.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-122e933e0d6d1919e0a52e69.md)

## Rule

- **Rule:** The flit sdist build includes docs/, requirements/, tests/, CHANGES.rst, and tox.ini in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `requirements/**`
  - `tests/**`
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1d065bb8734bc157d796f0e9.md)

## Rule

- **Rule:**
  ```text
  Running `make help` in docs/ invokes Sphinx with the `help` builder, passing SOURCEDIR, BUILDDIR, SPHINXOPTS, and O.
  ```
- **Applies to:**
  - `docs/**`
- **Condition:** command target: help
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-330adb02fe2a6adce04bad8f.md)

## Rule

- **Rule:** Relevant docs pages and docstrings must be updated, and docs pages and docstrings should be wrapped at 72 characters.
- **Applies to:**
  - `**/*.py`
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-347e1f11d878bf5c154b6cd7.md)

## Rule

- **Rule:** The docs tox environment installs its dependencies from requirements/docs.txt.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-44027ad7d9dc7c8f367ac32e.md)

## Rule

- **Rule:** Sphinx documentation builds fail on warnings.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-64089871cd8fafa367d93a42.md)

## Rule

- **Rule:** Sphinx documentation builds use the dirhtml builder.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7ca6740349bb688509da9be0.md)

## Rule

- **Rule:**
  ```text
  Running `make <target>` in docs/ delegates to Sphinx via `$(SPHINXBUILD) -M $@ "$(SOURCEDIR)" "$(BUILDDIR)" $(SPHINXOPTS) $(O)`, so any target name is passed to Sphinx's builder mode.
  ```
- **Applies to:**
  - `docs/**`
- **Condition:** command target: %
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c82b4d55167e52796499c0e3.md)

## Rule

- **Rule:**
  ```text
  The built documentation output is viewed by opening `_build/html/index.html` in a browser.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fa57ff0cf0d77fefdd65bcbd.md)
