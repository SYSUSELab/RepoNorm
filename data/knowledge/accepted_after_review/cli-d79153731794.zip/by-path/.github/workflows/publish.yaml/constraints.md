# Constraints for `.github/workflows/publish.yaml`

## Rule

- **Rule:** The create-release job depends on the provenance job and runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-09badce7dea67c9cc09244cf.md)

## Rule

- **Rule:**
  ```text
  The Publish workflow runs on pushes of tags matching '*'.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Condition:**
  ```text
  workflow predicate: push: tags: - '*'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0be9cfc51ac837c82de90018.md)

## Rule

- **Rule:** The build job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0dc920d94ee310c677b144bf.md)

## Rule

- **Rule:** The build job uploads the ./dist directory as an artifact.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-12e7c4eb856adce5f9b84b17.md)

## Rule

- **Rule:** The publish-pypi job then publishes the artifact/ directory to PyPI using the pypa/gh-action-pypi-publish action.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-18bc78f6ad3d3e041e0ba20b.md)

## Rule

- **Rule:** The build job builds the package with python -m build.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2cf6ee19e09e058617e27eef.md)

## Rule

- **Rule:** The publish-pypi job depends on the provenance job and runs in the 'publish' environment, which requires approval before uploading to PyPI.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-378aa9764d67672e0854905a.md)

## Rule

- **Rule:** The build job generates a hash by running sha256sum over dist contents and base64-encoding the result into the hash step output.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44a9cf157228d89e53ad4ade.md)

## Rule

- **Rule:** The provenance job depends on the build job and calls the SLSA generic generator workflow at v2.0.0 with base64-subjects set to the build job's hash output.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7c6dad1939f1412e732cbe97.md)

## Rule

- **Rule:** The publish-pypi job first publishes the artifact/ directory to the TestPyPI repository URL https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9c0431ce1e13bf001811ee4b.md)

## Rule

- **Rule:**
  ```text
  The build job sets SOURCE_DATE_EPOCH from the last commit date to use the commit date instead of the current date during the build.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9c31decd9dfa1cf55e32f804.md)

## Rule

- **Rule:** The build job installs build requirements via pip install -r requirements/build.txt.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af6c405fc4f618274aab8565.md)

## Rule

- **Rule:**
  ```text
  The build job sets up Python version '3.x' with pip caching keyed on requirements*/*.txt.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc7d2d6a8ae3f462d9f2104a.md)

## Rule

- **Rule:**
  ```text
  The create-release job creates a draft GitHub release for the pushed tag containing the intoto provenance and artifact files, using GH_TOKEN from github.token.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fd3222ed7be366158c52a895.md)
