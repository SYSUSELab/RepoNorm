# Constraints for `.github/workflows/pre-commit.yaml`

## Rule

- **Rule:** The pre-commit workflow runs the pre-commit/action step.
- **Applies to:**
  - `.github/workflows/pre-commit.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4682f4b89c2cd87ffd9f53d2.md)

## Rule

- **Rule:** The pre-commit workflow runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/pre-commit.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-814b68baf47e407691f1b3a2.md)

## Rule

- **Rule:**
  ```text
  The pre-commit workflow runs on pull_request events and on pushes to the main and stable branches.
  ```
- **Applies to:**
  - `.github/workflows/pre-commit.yaml`
- **Condition:**
  ```text
  workflow predicate: pull_request: push: branches: [main, stable]
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-860f7aa166e7f09fd34f57c4.md)

## Rule

- **Rule:** The pre-commit-ci/lite-action step runs when the workflow has not been cancelled.
- **Applies to:**
  - `.github/workflows/pre-commit.yaml`
- **Condition:** workflow predicate: ${{ !cancelled() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-97747fb96a5ec33c61dd8500.md)

## Rule

- **Rule:** The pre-commit workflow sets up Python version 3.x.
- **Applies to:**
  - `.github/workflows/pre-commit.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ab2025424f0881c1de97611e.md)
