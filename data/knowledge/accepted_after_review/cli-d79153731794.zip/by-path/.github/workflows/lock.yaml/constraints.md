# Constraints for `.github/workflows/lock.yaml`

## Rule

- **Rule:** The lock job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-69cf3957cbf0ad21e05148b8.md)

## Rule

- **Rule:** The lock workflow uses the concurrency group 'lock'.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9266627517c9fa8d32e616be.md)

## Rule

- **Rule:**
  ```text
  The lock workflow runs on a daily schedule defined by the cron expression '0 0 * * *'.
  ```
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Condition:**
  ```text
  workflow predicate: schedule: - cron: '0 0 * * *'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-96f240eabc30c43de84b8834.md)

## Rule

- **Rule:** The lock workflow uses the dessant/lock-threads action pinned to commit 1bf7ec25051fe7c00bdd17e6a7cf3d7bfb7dc771 (v5.0.1) with issue-inactive-days, pr-inactive-days, and discussion-inactive-days all set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b20b8fc2ffd95a4ab31e8a10.md)

## Rule

- **Rule:** The lock workflow grants write permission to issues and pull-requests.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e8508d3d7bc9e3b1ca74c11c.md)
