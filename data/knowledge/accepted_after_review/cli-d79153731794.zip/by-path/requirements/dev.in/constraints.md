# Constraints for `requirements/dev.in`

## Rule

- **Rule:** The update-requirements tox environment runs pip-compile on dev.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/dev.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e0a6747d3bd6951821a73b2e.md)
