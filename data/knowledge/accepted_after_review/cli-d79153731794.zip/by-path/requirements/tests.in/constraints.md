# Constraints for `requirements/tests.in`

## Rule

- **Rule:** The update-requirements tox environment runs pip-compile on tests.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/tests.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-adfe8cae096b7ce8d2265718.md)
