# Constraints for `requirements/typing.in`

## Rule

- **Rule:** The update-requirements tox environment runs pip-compile on typing.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/typing.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2cfb302228522e3ec36118c0.md)
