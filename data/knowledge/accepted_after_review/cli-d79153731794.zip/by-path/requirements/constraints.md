# Constraints for `requirements`

## Rule

- **Rule:** The flit sdist build includes docs/, requirements/, tests/, CHANGES.rst, and tox.ini in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `requirements/**`
  - `tests/**`
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1d065bb8734bc157d796f0e9.md)
