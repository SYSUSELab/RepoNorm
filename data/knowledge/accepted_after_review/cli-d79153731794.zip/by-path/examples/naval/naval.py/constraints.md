# Constraints for `examples/naval/naval.py`

## Rule

- **Rule:** The naval example defines subcommands such as 'remove' taking two float arguments x and y and echoing a formatted removal message, demonstrating the expected pattern for registering subcommands with typed arguments in examples.
- **Applies to:**
  - `examples/naval/naval.py`
- **Condition:** When adding or modifying subcommands with typed arguments in the naval example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-911ab133b3178087395c7b98.md)

## Rule

- **Rule:** The naval example registers a 'new' subcommand on the ship group with a required 'name' argument, demonstrating group subcommand registration with arguments.
- **Applies to:**
  - `examples/naval/naval.py`
- **Condition:** When modifying or adding subcommands in the naval example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-feaa533dcd9c583420449f4b.md)
