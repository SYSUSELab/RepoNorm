# Constraints for `examples/validation/validation.py`

## Rule

- **Rule:** Example commands that accept a URL parameter must validate that the parsed scheme is http or https and reject other schemes, using urlparse for non-tuple values.
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** When adding or modifying a URL parameter type or validator in the validation example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2721c4eed111e92b6f71e0b6.md)

## Rule

- **Rule:** Example validation callbacks must raise click.BadParameter when the value fails validation, demonstrating the expected callback validation pattern and error type.
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** when adding or modifying a validation callback in the validation example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c7ddcb46d319cd84ed867149.md)

## Rule

- **Rule:** The validation example defines a URL ParamType subclass with name 'url', demonstrating the custom ParamType extension protocol for examples.
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** When adding or modifying custom parameter types in the validation example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d92dce2a6211b077d51e353c.md)

## Rule

- **Rule:**
  ```text
  Example commands that validate parameters must use callback validation, manual BadParameter with param_hint, or custom types as appropriate, demonstrating multiple validation approaches.
  ```
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** When adding or modifying a command in the validation example that validates parameters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d972b477bc711d40a86264ef.md)
