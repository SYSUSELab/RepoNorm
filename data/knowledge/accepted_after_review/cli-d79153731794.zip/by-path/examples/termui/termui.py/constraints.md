# Constraints for `examples/termui/termui.py`

## Rule

- **Rule:**
  ```text
  The termui example must demonstrate click.progressbar accepting either an iterable or an explicit length=count, and must show width=0 with show_percent=False and show_eta=False for a minimal bar, plus manual bar.update(item) for non-linear progress.
  ```
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying progress bar usage in the termui example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-241717dee08df19ced6467e9.md)

## Rule

- **Rule:** The termui example's locate command calls click.launch(url, locate=True), demonstrating the launch API's locate mode for opening a file or URL in the default application.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying or adding locate commands in the termui example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6a95f4012da32d6dc1c0859e.md)

## Rule

- **Rule:** The termui example must remain a standalone demo script that imports math, random, time, and click, preserving these runtime dependencies.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying imports or runtime dependencies of the termui example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-afe018134cdb3abb56add0a3.md)

## Rule

- **Rule:**
  ```text
  The termui example implements an interactive menu as a state machine driven by click.getchar(), transitioning between main, debug, and quit menus and echoing Invalid input for unrecognized characters; the progressbar's item_show_func extension point is demonstrated by a show_item callback returning a formatted string for item display.
  ```
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying the termui example's interactive menu state machine or its progressbar item display callback.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c365b7350eb4cac4aa4bb869.md)

## Rule

- **Rule:**
  ```text
  The termui example's process_slowly must sleep for a random duration scaled by 0.002 to simulate work that makes progress bars visibly advance.
  ```
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying the simulated work duration in the termui example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dd00ee1cad39668dafb0c317.md)
