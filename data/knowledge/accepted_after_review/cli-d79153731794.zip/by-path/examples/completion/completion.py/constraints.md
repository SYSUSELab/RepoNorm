# Constraints for `examples/completion/completion.py`

## Rule

- **Rule:**
  ```text
  The completion example imports CompletionItem from click.shell_completion and registers a group via cli.add_command(group), showing the public shell-completion API surface used by examples.
  ```
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When modifying the completion example's shell-completion integration or command registration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-36406c01daa6d1e644143a24.md)

## Rule

- **Rule:** Shell completion callbacks may return either a list of plain strings or a list of CompletionItem objects carrying help strings; matching may be performed against both the value and the help text.
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When modifying or adding shell completion callbacks in the completion example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-71f8d2c4c9b79cceaf0f497a.md)

## Rule

- **Rule:** The completion example must define a click.group named cli with an empty callback as the minimal group declaration pattern.
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When adding or modifying the top-level command group in the completion example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7dcd55d24f56b83f17fe186d.md)

## Rule

- **Rule:**
  ```text
  The completion example must use shell_complete=list_users on an argument to provide custom shell completion, demonstrating the supported completion extension point.
  ```
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When adding or modifying shell completion behavior in the completion example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c0a817f47d35a9a51f831b8d.md)
