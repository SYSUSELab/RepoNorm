# Constraints for `examples/colors/colors.py`

## Rule

- **Rule:** Example commands that display styled output must use click.style with supported attributes (fg, bold, reverse, blink, underline) and must not assume ANSI styles persist when output is piped.
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** When adding or modifying a command in the colors example that produces styled terminal output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-40798f5295804dd295dc1987.md)

## Rule

- **Rule:**
  ```text
  The colors example defines all_colors as the 16 supported color names including bright_* variants, matching the ANSI color mapping in termui.
  ```
- **Applies to:**
  - `examples/colors/colors.py`
- **Condition:** When modifying or adding color definitions in the colors example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a21c4b2edac96fbedb663687.md)
