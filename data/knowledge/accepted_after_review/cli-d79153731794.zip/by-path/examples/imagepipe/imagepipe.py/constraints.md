# Constraints for `examples/imagepipe/imagepipe.py`

## Rule

- **Rule:** Imagepipe processor commands must be implemented as generator functions decorated with @processor that yield transformed images, so the pipeline can stream results and echo progress.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When adding or modifying an imagepipe subcommand that transforms images.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-19364f0289f93bfcde4bf129.md)

## Rule

- **Rule:**
  ```text
  The imagepipe example composes image-processing subcommands through a shared @processor decorator, and its result_callback receives an iterable of chained subcommand return values; process_commands folds each processor over an initially empty stream and then drains the stream to force evaluation. Subcommands such as smoothen_cmd use the shared decorator and options like -i/--iterations with default=1 and show_default=True.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:**
  ```text
  When adding or modifying imagepipe subcommands, the shared processor decorator, or the result_callback that folds and drains the chained stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2ff92d9f5aa38ad8436b97d9.md)

## Rule

- **Rule:** Example image processing helpers that chain operations must copy the filename attribute from the old image to the new image and return the new image, preserving filename metadata across chained operations.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** when adding or modifying a helper that chains image operations in the imagepipe example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-be51a662125a18f8fb6356d5.md)

## Rule

- **Rule:**
  ```text
  The example demonstrates a command with a show_default option and a processor decorator that yields processed images, showing the supported image processing pipeline pattern.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying or adding commands with processor decorators in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dc4a849e05cbff2eff95ebbb.md)

## Rule

- **Rule:** The imagepipe paste command pastes the second image onto the first, using the second image as a mask when its mode is RGBA or it has transparency info, appends '+filename' to the first image's filename, and yields remaining images unchanged.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying or adding image paste commands in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ed8d25c88a58b5fd2a638a7b.md)
