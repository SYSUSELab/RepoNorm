# Constraints for `examples/complex/complex/commands/cmd_status.py`

## Rule

- **Rule:**
  ```text
  Example commands that use the environment logging extension must use @pass_environment and call ctx.log and ctx.vlog to emit normal and debug messages.
  ```
- **Applies to:**
  - `examples/complex/complex/commands/cmd_status.py`
- **Condition:** when adding or modifying a command that uses the environment logging extension in the complex example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../claims/CLAIM-3037aa7de01dfc46ca0112b5.md)
