# Constraints for `examples/complex/complex/commands/cmd_init.py`

## Rule

- **Rule:**
  ```text
  Example commands that share environment-passing decorators must import pass_environment from the package CLI module rather than redefining it locally.
  ```
- **Applies to:**
  - `examples/complex/complex/commands/cmd_init.py`
- **Condition:** When adding or modifying a command in the complex example that needs environment-passing behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../claims/CLAIM-953a9b2020fdc19583d0195e.md)

## Rule

- **Rule:**
  ```text
  The complex example's init command uses a Path argument with resolve_path=True and falls back to ctx.home when no path is given, then logs the formatted filename.
  ```
- **Applies to:**
  - `examples/complex/complex/commands/cmd_init.py`
- **Condition:** When modifying or adding init commands in the complex example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../claims/CLAIM-ebc8a66e21abf02bce411f2b.md)
