# Constraints for `examples/aliases/aliases.py`

## Rule

- **Rule:**
  ```text
  The aliases example demonstrates the pass_config decorator pattern where a command receives a config object via a custom pass decorator.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** When modifying or adding commands in the aliases example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4a83a456d400eac81e3d4f88.md)

## Rule

- **Rule:**
  ```text
  The aliases example loads configuration through a Click callback: the cli group uses cls=AliasedGroup and a --config option declared with click.Path(exists=True, dir_okay=False), a read_config callback, and expose_value=False, so the config path is validated and consumed by the callback without being passed as a command parameter. Config.read_config reads with configparser.RawConfigParser and silently ignores NoSectionError when the aliases section is absent, updating aliases only when present.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** When changing how the aliases example loads, validates, or exposes its configuration file, or when adding options that consume config.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-54076763d311c85c45758202.md)

## Rule

- **Rule:**
  ```text
  The aliases example's get_command must resolve commands in order: builtin commands first, then explicit aliases from the config object, then unique prefix abbreviation; ambiguous prefixes must fail with 'Too many matches'.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:**
  ```text
  When modifying AliasedGroup.get_command or the command resolution order.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a8c1dc551a9bd993d26d91ff.md)
