# Constraints for `examples/repo/repo.py`

## Rule

- **Rule:** Example commands that need shared state across subcommands must store that state on the Click context object (ctx.obj) in the group callback and read it from subcommands, rather than relying on module-level globals.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When adding or modifying a subcommand in the repo example that needs access to the Repo instance or config overrides established by the group.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5570f453bd3db88ef74fa8ff.md)

## Rule

- **Rule:** Example commands that write configuration must echo the change to stderr via click.echo(file=sys.stderr) when verbose mode is enabled, and must store the value in self.config.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When adding or modifying a method in the repo example that writes configuration values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9ab8189a71c37317e3855a23.md)

## Rule

- **Rule:** The repo example's clone command declares an optional argument (dest, required=False) that defaults to None and is derived from the last path component of src when omitted.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When changing the repo example's clone command argument handling or its default destination derivation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c9f8dc3f1120c5ef4ca3fb59.md)

## Rule

- **Rule:**
  ```text
  Example commands that handle credentials must use prompt=True and click.password_option, and must not store or display the actual password value (e.g., mask it as '*' * len(password)).
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When adding or modifying a command in the repo example that accepts or handles user credentials.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d0cea1e1ad9069cff072a369.md)

## Rule

- **Rule:**
  ```text
  Example commands that require user confirmation must use click.confirmation_option() so the command body runs only after confirmation, and this decorator can be combined with custom pass decorators.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** when adding or modifying a destructive command in the repo example that requires user confirmation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d88e5480db02034d5cdd7ffa.md)

## Rule

- **Rule:** The repo example's state object initializes home, an empty config dict, and verbose=False, establishing the default configuration shape used by the example.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying or adding state initialization in the repo example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f62e03069b3597863f6c19d7.md)
