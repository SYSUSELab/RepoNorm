# Constraints for `examples`

## Rule

- **Rule:** Example commands that expose file input/output must use click.File with the appropriate mode and rely on the '-' convention for stdin/stdout, preserving Unix pipe compatibility.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example command that reads from or writes to files or streams.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-57b0bd7afe209aba45bcc916.md)

## Rule

- **Rule:**
  ```text
  Example commands that define multiple flag_value options for the same parameter must share the parameter name and set a default on exactly one of them, so that the flag group behaves as a single mutually exclusive choice.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:**
  ```text
  When adding or modifying an example command that defines multiple flag_value options for a single parameter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-596e8111d855b2ae3ffc6981.md)

## Rule

- **Rule:** Example CLIs that need custom group behavior must subclass click.Group (e.g. AliasedGroup, ComplexCLI) rather than reimplementing group dispatch, so that command registration and lookup continue to flow through Click's Group machinery.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example CLI that requires custom group-level behavior such as alias resolution or shared group state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-67c38ca802315b7b5e531268.md)

## Rule

- **Rule:**
  ```text
  Example commands that define a generator decorator must pass through old values unchanged and not pass the values as a parameter, returning update_wrapper(new_func, f) to preserve metadata.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example command that defines a generator decorator similar to the processor decorator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-837c9e92807acbec982bea64.md)

## Rule

- **Rule:**
  ```text
  Example commands that need custom shell completion must attach a completion callback via shell_complete= to the relevant click.argument or click.option, rather than implementing completion elsewhere.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example command that requires custom shell completion for an argument or option.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-96a9f994431d171523ba640a.md)

## Rule

- **Rule:** Ruff excludes the examples/ directory from linting via extend-exclude.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ac8f67bed5db1ab64f6db0e4.md)

## Rule

- **Rule:**
  ```text
  Example commands that need custom group lookup or alias resolution must override get_command on a click.Group subclass, rather than modifying the group's command dictionary directly.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example CLI that requires custom group lookup or alias resolution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c19bb4dff8f155000b1ade89.md)
