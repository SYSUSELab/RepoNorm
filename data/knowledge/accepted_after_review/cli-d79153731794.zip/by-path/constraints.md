# Constraints for `.`

## Rule

- **Rule:** The gha-update tool configuration lists "slsa-framework/slsa-github-generator" in its tag-only array.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-001ab97dd38f159aee87f4b5.md)

## Rule

- **Rule:** Ruff's isort lint rule is configured with order-by-type = false, so imports are not ordered by type.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-010cc208586d45fa9f0da5d4.md)

## Rule

- **Rule:** Files in the repository are configured to trim trailing whitespace.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-01bc1e7a211363912320146c.md)

## Rule

- **Rule:** The ruff hook from ruff-pre-commit is enabled.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-032f5f63bff49679d7fef5f4.md)

## Rule

- **Rule:**
  ```text
  The Tests workflow runs on pull requests, ignoring changes under docs/** and to *.md and *.rst files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-03401be7c2bda16a08a3b528.md)

## Rule

- **Rule:** The check-merge-conflict hook from pre-commit-hooks is enabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-04445a2ef742fecb0728ffe5.md)

## Rule

- **Rule:** Run the basic test suite with pytest.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-048a6258fa0537ce846ae354.md)

## Rule

- **Rule:** Files in the repository have a maximum line length of 88 characters.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09144e0af30a7a612d3e3ca3.md)

## Rule

- **Rule:**
  ```text
  Create a virtualenv with python3 -m venv env and activate it; on Windows activation uses env\Scripts\activate.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-0e5c42cbd52eefe711146243.md)

## Rule

- **Rule:** Ruff applies fixes automatically (fix = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0e89690bee8c0425b3fc64f9.md)

## Rule

- **Rule:** The typing tox environment runs mypy.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0ed73b156af60ec1a79d5e0f.md)

## Rule

- **Rule:** CI runs the full test suite when a pull request is submitted.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-10e2060f87ea893448355e90.md)

## Rule

- **Rule:** Files in the repository use LF line endings.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-14e9f8687afa5aa01024d908.md)

## Rule

- **Rule:** Ruff's isort lint rule is configured with force-single-line = true, so imports are forced onto single lines.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-27e474d49e125263b6ba5053.md)

## Rule

- **Rule:**
  ```text
  The tox `style` test environment sets `skip_install = true`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-29f8404cfe1180df5b438ac2.md)

## Rule

- **Rule:** The end-of-file-fixer hook from pre-commit-hooks is enabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2b436ea21e387e98d8cb36ec.md)

## Rule

- **Rule:** Relevant docs pages and docstrings must be updated, and docs pages and docstrings should be wrapped at 72 characters.
- **Applies to:**
  - `**/*.py`
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-347e1f11d878bf5c154b6cd7.md)

## Rule

- **Rule:** The debug-statements hook from pre-commit-hooks is enabled.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3904aae72407e5c9d01a2e2e.md)

## Rule

- **Rule:** Pyright is configured with pythonVersion "3.8".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3ef9dfe5763dce0e9c770cbc.md)

## Rule

- **Rule:** The fix-byte-order-marker hook from pre-commit-hooks is enabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-42cb7771c5714ec3add1222c.md)

## Rule

- **Rule:** Read the Docs builds use Python 3.12.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-42f1569300406e9fccd76795.md)

## Rule

- **Rule:** Ruff shows applied fixes (show-fixes = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4317cb74f2df9c31f93865eb.md)

## Rule

- **Rule:**
  ```text
  Open ``htmlcov/index.html`` in a browser to explore the coverage report.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-4d2efcf453f77e3d096b78e9.md)

## Rule

- **Rule:**
  ```text
  The project declares colorama as a runtime dependency only on Windows (platform_system == 'Windows').
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-50bea5b76416669abc6d2727.md)

## Rule

- **Rule:** Files in the repository are configured to insert a final newline.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-51deae7cadb71b54069001da.md)

## Rule

- **Rule:** The typing tox environment runs pyright --verifytypes click --ignoreexternal.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-52f88881f4150895d82fb88b.md)

## Rule

- **Rule:** Include tests that cover any code changes made, and ensure the test fails without the patch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-54d772e611de10c60ef537b4.md)

## Rule

- **Rule:** Use the verbose form of typing.Callable for @command and @group.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-57b6df2a39a262439b1d6692.md)

## Rule

- **Rule:**
  ```text
  The project declares flit_core<4 as its build requirement.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5dfb1c9706c8e5269aeb76f8.md)

## Rule

- **Rule:** An entry must be added in CHANGES.rst using the same style as other entries, and relevant docstrings must include .. versionchanged:: inline changelogs.
- **Applies to:**
  - `**/*.py`
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-5f637ae390e2a026b4cf63ac.md)

## Rule

- **Rule:**
  ```text
  The tests job installs tox with pip and runs tox for the environment named by matrix.tox, defaulting to py<matrix.python>.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7dcc6102530a6e870b198a65.md)

## Rule

- **Rule:** Files in the repository use an indent size of 4 by default.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7fe1424039edf9ff6e3dae07.md)

## Rule

- **Rule:**
  ```text
  Run ``pytest`` using ``coverage`` and generate a report to find lines lacking test coverage.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-828bbc9a99b158799e300efa.md)

## Rule

- **Rule:** The pre-commit configuration uses the pre-commit-hooks repository at rev v5.0.0.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8e3add056ee02d203b093a12.md)

## Rule

- **Rule:** Clone the main repository locally with git clone https://github.com/pallets/click and cd into it.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-8fe267cfa8a320cdde7a3415.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with python_version = "3.8".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-92a703f82650a903f27aae0e.md)

## Rule

- **Rule:** The trailing-whitespace hook from pre-commit-hooks is enabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9a8d0517b9aa7cb8d36f109e.md)

## Rule

- **Rule:** Files in the repository use UTF-8 charset.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9af6af9622a4af0528b80a4d.md)

## Rule

- **Rule:** Install the pre-commit hooks with pre-commit install.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-9ebdeace9e1eaffa68da0827.md)

## Rule

- **Rule:** Code must be formatted using Black; this and other tools run automatically if pre-commit is installed.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-a408d42065383bf4a818f909.md)

## Rule

- **Rule:** The typing job installs tox with pip and runs tox run -e typing.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a65e5a5f76bd114871ad680d.md)

## Rule

- **Rule:** Add your fork as a remote named "fork" pointing at https://github.com/{username}/click, replacing {username} with your username.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-b1e3ca8f5c1e1a15b0b58b62.md)

## Rule

- **Rule:**
  ```text
  Coverage path mapping is configured with source paths "src" and "*/site-packages".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b567f5b13df8505c31e13ee0.md)

## Rule

- **Rule:** The tests job runs on a matrix of Python versions 3.13, 3.12, 3.11, 3.10, 3.9, 3.8, and pypy-3.10, with additional Windows and macOS entries for Python 3.12.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b6b3f85fcbb67cdc6b0f32c6.md)

## Rule

- **Rule:**
  ```text
  The tox `style` test environment declares `pre-commit` as a dependency.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c003aa90ec90a222556ae063.md)

## Rule

- **Rule:** Read the Docs installs the project itself via pip from the repository root path.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c036d2d1cd85de6ccaa6d590.md)

## Rule

- **Rule:** CSS, HTML, JS, JSON, JSX, SCSS, TS, TSX, YAML, and YML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.jsx`
  - `**/*.scss`
  - `**/*.ts`
  - `**/*.tsx`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca0f468fabafbf8fc78e06a4.md)

## Rule

- **Rule:** Do not use the issue tracker for support questions; the issue tracker is only for bugs and feature requests in Click itself.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-ca1f31af07099b80b9eec518.md)

## Rule

- **Rule:**
  ```text
  The project's build backend is flit_core.buildapi.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cf5cea04f7b49e2c87e39a40.md)

## Rule

- **Rule:** Pyright runs in "basic" typeCheckingMode.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d798de9d92b8f2dc45209a54.md)

## Rule

- **Rule:** Coverage measurement is configured to track branch coverage.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dc7eebb30a696d6e65b9e285.md)

## Rule

- **Rule:** Ruff linting is configured to select the rule sets B (flake8-bugbear), E (pycodestyle error), F (pyflakes), I (isort), UP (pyupgrade), and W (pycodestyle warning).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-e4d2cc886023e635a8cc3750.md)

## Rule

- **Rule:** Files in the repository use space indentation.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eca9b807fabab4c54ec8f57f.md)

## Rule

- **Rule:** The flit module name is configured as "click".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f164664247aaf5dee56227db.md)

## Rule

- **Rule:**
  ```text
  The Tests workflow runs on pushes to the main and stable branches, ignoring changes under docs/** and to *.md and *.rst files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f31e79c6a09010be2bfbe7c5.md)

## Rule

- **Rule:** Configure git with your username and email using the global git config commands.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-f3aa44d87f4539d69e3eced7.md)

## Rule

- **Rule:** Ruff uses the full output format (output-format = "full").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f48981faf9d737f096c2ddd8.md)

## Rule

- **Rule:** The pre-commit configuration uses the ruff-pre-commit repository at rev v0.7.1.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f4ad03e4bff9b542dfb28491.md)

## Rule

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.8 via requires-python = ">=3.8".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f90ef79d34adaab7faa1b3e2.md)

## Rule

- **Rule:** Read the Docs builds use Ubuntu 22.04 as the build OS.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fd21836410b2e52f20da1020.md)

## Rule

- **Rule:**
  ```text
  Pytest is configured to turn warnings into errors via filterwarnings = ["error"].
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ff6b4c1c83875ecfa06292f2.md)
