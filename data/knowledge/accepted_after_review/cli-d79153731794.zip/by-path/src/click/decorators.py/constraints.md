# Constraints for `src/click/decorators.py`

## Rule

- **Rule:**
  ```text
  When modifying HelpOption.show_help, preserve the static callback behavior that echoes ctx.get_help() with ctx.color and exits when value is true and ctx.resilient_parsing is false, with resilient parsing suppressing the output.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When changing show_help's callback conditions or output behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1d84fc5889c2c85bef6147db.md)

## Rule

- **Rule:**
  ```text
  When modifying the `group` decorator, preserve support for applying it without parentheses: if the first positional argument is callable, treat it as the decorated function and invoke `command` with `cls` and `attrs`.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  when changing the `group` decorator's argument handling or call signature
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1f6c41c6ffa1d43b3621f438.md)

## Rule

- **Rule:**
  ```text
  pass_meta_key generates a decorator whose docstring is derived from doc_description, defaulting to the key from click.Context.meta, and passes that meta value as the first argument.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** when adding or modifying a meta-key passing decorator
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-32ed6616a8d606d72590c64d.md)

## Rule

- **Rule:** When modifying the group decorator's typing overloads, preserve the overload where calling it with cls=None returns a callable producing a Group, preserving type information for decorator usage.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** when changing the group decorator's typing overloads
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-33af13e085e37133f8f70d40.md)

## Rule

- **Rule:**
  ```text
  make_pass_decorator's new_func must retrieve the current context, ensure or find the object of the requested type, and raise RuntimeError when no such object exists, so pass_obj requires a context object of the specified type.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When modifying make_pass_decorator or the pass_obj context-object resolution path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3a62a53ad1abf1134dde4226.md)

## Rule

- **Rule:**
  ```text
  When modifying password_option, preserve the defaults param_decls='--password' and prompt, confirmation_prompt, and hide_input all True before delegating to option.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When changing password_option's default declarations or prompt/hide behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-45a6a6c8321958253925b201.md)

## Rule

- **Rule:**
  ```text
  _param_memo must append parameters directly to a Command's params list, or accumulate them in a __click_params__ attribute on plain functions for later conversion, defining how decorators attach parameters.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When changing how decorators attach parameters to commands or plain functions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4aa77ae6373abb2425a34336.md)

## Rule

- **Rule:** When modifying the command decorator, preserve support for both parenthesized and bare-callable application, and reject cls or attrs when applied without parentheses.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When changing command's callable-vs-parenthesized dispatch or its cls/attrs handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-79d95ada6235b365fb353607.md)

## Rule

- **Rule:**
  ```text
  Decorators that wrap user functions must use update_wrapper so the decorated function preserves the original function's metadata (name, docstring, etc.).
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When adding or modifying a click decorator that wraps a user function.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7cb51b88defb01a1e45e4d10.md)

## Rule

- **Rule:**
  ```text
  When modifying the `command` decorator's typing overloads, preserve the overload for the case where `name` is None and `cls` is provided as a keyword, returning a callable that produces the command class.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  when changing `command` decorator typing overloads or keyword-argument handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-982fd02b05f3cf551eb88f39.md)

## Rule

- **Rule:**
  ```text
  make_pass_decorator's ensure flag controls whether a missing object of the requested type is created and remembered on the context; this is the documented behavioral difference from pass_obj.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When modifying make_pass_decorator or its ensure parameter, preserve the ensure-controlled creation-and-remembering behavior on the context.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a7203144cde425d4504a8e25.md)

## Rule

- **Rule:**
  ```text
  The parameter decorator factory stores the constructed param on the function via _param_memo and returns the function unchanged, enabling decorator stacking.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** when adding or modifying a parameter decorator factory
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b0657f8fd057c2b7ce60751d.md)

## Rule

- **Rule:**
  ```text
  When modifying pass_context, preserve wrapping the callback so it receives the current Context as its first argument and finalizing the wrapper with update_wrapper to preserve the original function metadata.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When changing pass_context callback wrapping or metadata preservation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c20d7f2df8cddba07f5fc03b.md)

## Rule

- **Rule:**
  ```text
  confirmation_option must default param_decls to ('--yes',) and set is_flag=True, callback=callback, expose_value=False, prompt='Do you want to continue?', and help='Confirm the action without prompting.' unless overridden.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:**
  ```text
  When modifying confirmation_option defaults or adding new confirmation decorators.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dd28e7472cca902d8d867b18.md)

## Rule

- **Rule:**
  ```text
  The group decorator must provide a typed @t.overload variant accepting cls: type[GrpType] and returning a callable producing GrpType, preserving the typed decorator API for custom group classes.
  ```
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** When changing the group decorator's overloads or its typed custom-class API.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dfea4bc10eef8aa0a9bf7b87.md)

## Rule

- **Rule:** When modifying the command decorator's typing overloads, preserve the overload for the case where name is a string and cls is provided, returning a callable that produces the command class.
- **Applies to:**
  - `src/click/decorators.py`
- **Condition:** when changing the command decorator's typing overloads
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ffc4bb8ab79b6664b8713632.md)
