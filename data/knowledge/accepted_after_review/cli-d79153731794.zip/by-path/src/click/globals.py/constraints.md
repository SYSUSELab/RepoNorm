# Constraints for `src/click/globals.py`

## Rule

- **Rule:**
  ```text
  get_current_context must be overloaded so that calling it with silent=False (the default) is typed to return Context rather than Context | None.
  ```
- **Applies to:**
  - `src/click/globals.py`
- **Condition:**
  ```text
  When modifying get_current_context's signature or type overloads.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4b9ca0e5ab9fb9a633a4c13f.md)

## Rule

- **Rule:** Context state must be stored in a threading.local() so that the current context is thread-local rather than process-global.
- **Applies to:**
  - `src/click/globals.py`
- **Condition:**
  ```text
  When modifying context storage or access in click.globals, including push_context, pop_context, or get_current_context.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5d6e1a10a169ed98cc640a03.md)

## Rule

- **Rule:**
  ```text
  When modifying `get_current_context`, preserve the contract that it raises `RuntimeError` when no context is active unless `silent=True`, in which case it returns `None`.
  ```
- **Applies to:**
  - `src/click/globals.py`
- **Condition:**
  ```text
  when changing `get_current_context`'s error handling or return behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-67f27cfd627733042627ecb9.md)

## Rule

- **Rule:**
  ```text
  When get_current_context is called with silent, its typing overload returns Context | None so static typing reflects that the context may be absent.
  ```
- **Applies to:**
  - `src/click/globals.py`
- **Condition:**
  ```text
  Modifying get_current_context's typing overloads or silent parameter handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-be7d64bf090c46a0569ddd21.md)
