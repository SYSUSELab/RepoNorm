# Constraints for `src/click/termui.py`

## Rule

- **Rule:**
  ```text
  When modifying the termui module, preserve the module-level visible_prompt_func callable defaulting to input and the _getchar module-level hook used for unittesting getchar calls.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** when changing termui module-level prompt or getchar hooks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5380aad82d9c2e664dffde10.md)

## Rule

- **Rule:** Color interpretation must encode int colors as 256-color SGR sequences and tuple/list colors as truecolor SGR sequences, with offset distinguishing foreground from background.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying _interpret_color or color encoding logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-65e87a7d33f36fb3f2784baf.md)

## Rule

- **Rule:** secho must apply styling only when the message is a str; bytes/bytearray messages are passed through to echo unstyled, and other non-string messages are converted with str() before styling.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** When modifying secho's message handling or styling logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6de91578744628be55d1360c.md)

## Rule

- **Rule:**
  ```text
  hidden_prompt_func must import getpass lazily inside the function and delegate to getpass.getpass, so hidden prompt input avoids importing getpass until needed.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying hidden prompt input handling in click.termui.hidden_prompt_func.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-74e3e5c48401f5826d8428d0.md)

## Rule

- **Rule:**
  ```text
  When modifying the prompt function, preserve the interactive prompt contract: build a value_proc from the type when none is given, loop until a non-empty value or default is provided, re-prompt on UsageError, and when confirmation_prompt is set require a matching second value or re-prompt.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** when changing interactive prompt behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-861613bfdd6854a1d9bb6cf7.md)
