# Constraints for `src/click/parser.py`

## Rule

- **Rule:**
  ```text
  When modifying _Option.process, preserve support for actions store, store_const, append, append_const, and count, raising ValueError for unknown actions and appending the option object to state.order.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing option action handling or state.order bookkeeping in _Option.process.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2f54c89b9b8d8018f3ec0213.md)

## Rule

- **Rule:**
  ```text
  Option parsing must treat a bare '--' as an unconditional terminator regardless of configured option prefixes, and only treat an arg as an option when its first character is in _opt_prefixes and length exceeds 1.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When modifying _process_args_for_options or option prefix handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-46e73c6690a0be2f6d21caef.md)

## Rule

- **Rule:**
  ```text
  _process_opts splits --opt=value on the first =, normalizes the long option, and on NoSuchOption falls back to short-option matching only when the two-character prefix is not a registered option prefix; otherwise it raises unless ignore_unknown_options is set, in which case the arg is appended to state.largs.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** when modifying long option parsing or unknown-option handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-995058dfaa2229dd42483ea3.md)

## Rule

- **Rule:**
  ```text
  When modifying _OptionParser.add_option, preserve normalization via _normalize_opt, updating _opt_prefixes from the option's prefixes, registering short and long opts into _short_opt and _long_opt, and requiring dest explicitly rather than inferring it.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing option registration, prefix tracking, or dest handling in _OptionParser.add_option.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a779b45b30dc21f10dbc9170.md)

## Rule

- **Rule:**
  ```text
  When modifying option normalization, preserve applying ctx.token_normalize_func only to the option name portion after splitting the prefix, keeping the original prefix in the normalized result.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** when changing option name normalization
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b2c9983ad958e3e67d0e1467.md)

## Rule

- **Rule:**
  ```text
  OptionParser._Option splits each option into prefix/value; a single-character prefix with a single-character value is classified as a short option, otherwise as a long option, and the first character of every prefix is added to the prefixes set.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** when modifying option prefix/value splitting or short/long classification
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b68a3cbedb873e707bf39c49.md)

## Rule

- **Rule:**
  ```text
  When modifying _OptionParser._process_args_for_args, preserve unpacking state.largs + state.rargs against the nargs of self._args, processing each argument, then resetting state.largs to leftover args and clearing state.rargs.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing argument queue consumption or leftover handling in _OptionParser._process_args_for_args.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d8ed7999f2c0d4259c4ff0b9.md)
