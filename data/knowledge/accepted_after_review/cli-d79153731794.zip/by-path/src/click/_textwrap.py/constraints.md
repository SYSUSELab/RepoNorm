# Constraints for `src/click/_textwrap.py`

## Rule

- **Rule:**
  ```text
  When modifying `TextWrapper` in `_textwrap.py`, preserve that it subclasses `textwrap.TextWrapper` to customize standard-library text wrapping behavior.
  ```
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:** when changing click's text wrapping customization
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5eb7138edfb10675685d6c2e.md)

## Rule

- **Rule:**
  ```text
  TextWrapper.extra_indent must temporarily append the given indent to both initial_indent and subsequent_indent, restoring the previous values in a finally block.
  ```
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:**
  ```text
  When modifying TextWrapper.extra_indent or indent manipulation behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c4c0aa70f9f137cb11c2ddaa.md)

## Rule

- **Rule:**
  ```text
  _handle_long_word computes space_left = max(width - cur_len, 1); when break_long_words is set it splits the last reversed chunk at space_left, otherwise (if cur_line is empty) it moves the whole chunk into the line.
  ```
- **Applies to:**
  - `src/click/_textwrap.py`
- **Condition:**
  ```text
  when modifying long-word wrapping or break_long_words handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e2708ce316d9caf267a88a34.md)
