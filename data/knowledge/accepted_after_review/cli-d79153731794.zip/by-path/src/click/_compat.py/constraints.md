# Constraints for `src/click/_compat.py`

## Rule

- **Rule:** The stream wrapper caches the wrapped stream in a cache dict keyed by the source stream, tolerating cache lookup and assignment failures by falling back to creating a new wrapper.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** when modifying stream wrapper caching or its failure handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-37087bc947f4cc1d9110a30a.md)

## Rule

- **Rule:** When a stream wrapper provides read1, prefer the underlying stream's read1 method when available and fall back to read(size), preserving buffered-read semantics for wrapped streams.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** Modifying read1 on a stream wrapper that wraps another stream.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-60dd4e3440a6866ec8ece966.md)

## Rule

- **Rule:** Atomic writes must reject append mode, exclusive mode, and any mode without "w", raising ValueError with guidance to use normal w-mode or the overwrite parameter.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When changing atomic write mode validation or its error guidance.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6366e0e6798213f82a4141f5.md)

## Rule

- **Rule:**
  ```text
  _force_correct_text_writer must delegate to _force_correct_text_stream with _is_binary_writer and _find_binary_writer so text-writer correction shares the same stream-detection protocol as text readers.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying _force_correct_text_writer or stream correction logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-67713e6508ab006682688948.md)

## Rule

- **Rule:**
  ```text
  strip_ansi must remove ANSI escape sequences from a string using the module-level _ansi_re pattern.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying strip_ansi or the _ansi_re pattern in src/click/_compat.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7895c182430a437c73f5e5d7.md)

## Rule

- **Rule:**
  ```text
  When resolving the stderr text stream, first attempt the Windows console stream and fall back to _force_correct_text_writer with force_writable=True, preserving the defined resolution order.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying get_text_stderr or the stderr text-stream resolution path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8865e30065e3a9ce4816a57e.md)

## Rule

- **Rule:**
  ```text
  _FixupStream.seekable must check the wrapped stream's seekable attribute if present, otherwise probe by seeking to the current position and return False on any exception.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying _FixupStream.seekable or stream compatibility logic, preserve the attribute check, the seek-probe fallback, and the False-on-exception behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95707208a5ed0fd9d5072206.md)

## Rule

- **Rule:**
  ```text
  When a context manager wraps a file that may be deleted on error, close the file with delete=exc_type is not None so an exception during the with-block deletes the file while normal exit preserves it.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying __exit__ of the atomic file context manager.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9bf9c7e75c69d52c2b97c787.md)

## Rule

- **Rule:**
  ```text
  When modifying _get_windows_console_stream, preserve the no-op returning None on this platform so callers fall back to the generic text-stream path.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When changing platform-specific console stream detection or its fallback behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a33d1615f789b87a1d45f3fe.md)

## Rule

- **Rule:**
  ```text
  A __del__ method must detach the stream while swallowing all exceptions, so cleanup failures during garbage collection do not propagate.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying __del__ or stream-detach cleanup in src/click/_compat.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ab1b29051be779333552c8dc.md)

## Rule

- **Rule:**
  ```text
  get_binary_stdin raises RuntimeError when no binary reader can be determined for sys.stdin, making the failure mode explicit for callers.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** when modifying binary stdin resolution or its failure handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae930c857d41732a6e2e52bd.md)

## Rule

- **Rule:** The name property returns the real filename, providing a stable interface for accessing the underlying file name in the compatibility layer.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** when modifying the compatibility layer's file name access
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b5a5fe1b80b99b9e17b11a02.md)

## Rule

- **Rule:**
  ```text
  get_best_encoding must return the stream's encoding or sys.getdefaultencoding(), but substitute 'utf-8' whenever the resolved encoding is an ASCII encoding.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying get_best_encoding or encoding fallback logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c115cecc267d3850cd31ff0f.md)

## Rule

- **Rule:**
  ```text
  The stream wrapper constructor must wrap the underlying binary stream with _FixupStream using force_readable and force_writable flags before delegating to the superclass initializer.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing stream wrapper construction or _FixupStream wrapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c28b087c805934ca6c8861cf.md)

## Rule

- **Rule:**
  ```text
  When modifying _make_text_stream, preserve the default encoding resolution via get_best_encoding(stream), the 'replace' error default, and wrapping in _NonClosingTextIOWrapper with line_buffering=True and the force_readable/force_writable flags.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing text stream construction, encoding/error defaults, or wrapper flags in _make_text_stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cd1c00403944e8b53a621eac.md)

## Rule

- **Rule:**
  ```text
  get_text_stdout must first try the Windows console stream and otherwise force a correct text writer for sys.stdout with force_writable=True.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When changing stdout text writer selection or Windows console fallback.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ef3dd422b348aebb04ff19dd.md)
