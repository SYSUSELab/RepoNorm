# Constraints for `src/click/utils.py`

## Rule

- **Rule:**
  ```text
  _expand_args must treat invalid glob patterns as empty expansions rather than raising, and must fall back to the original argument when no matches are found.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying argument expansion or glob handling in click.utils._expand_args.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-134a797741de4a717465ff12.md)

## Rule

- **Rule:** When a stream wrapper's flush encounters OSError, suppress it only if errno is EPIPE; re-raise all other OSErrors so genuine I/O failures are not silently swallowed.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** Modifying flush behavior of a stream wrapper that may write to a closed pipe.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-27559ca13e0bd5df345fb7bd.md)

## Rule

- **Rule:**
  ```text
  When modifying `make_default_short_help`, preserve the truncation behavior: truncate at sentence-ending periods without adding an ellipsis, but when truncating mid-sentence remove words until the result plus '...' fits within `max_length`.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when changing short-help truncation logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2abb30f6c462fb25d23d5a1f.md)

## Rule

- **Rule:**
  ```text
  When a lazy file wrapper is closed, close the underlying file only if the wrapper opened it (should_close is true); never close files the wrapper did not open, such as stdin.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  Modifying close_intelligently or the lazy file wrapper's close path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-321626ade2cb4a7c0ffabd2a.md)

## Rule

- **Rule:**
  ```text
  LazyFile must defer opening regular files in read mode: it opens and closes once to surface errors early, then defers the real handle until first read; '-' is opened immediately via open_stream.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying LazyFile.__init__ or its open/read behavior for regular files in read mode.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-42ede5748049dae2a99c8277.md)

## Rule

- **Rule:**
  ```text
  Wrapper classes that store a wrapped IO object must expose it as self.wrapped in __init__, defining the attribute name other code uses to access the underlying stream.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying PacifyFlushWrapper or other IO wrapper classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-46cd26f9540da8e2a8f09c98.md)

## Rule

- **Rule:**
  ```text
  When modifying open_file, preserve the '-' stdin/stdout convention, KeepOpenFile wrapping so context-manager use does not close standard streams, LazyFile lazy opening, and atomic-write temporary-file replacement on close.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When changing open_file's handling of paths, standard streams, lazy opening, or atomic writes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4e861d46e22c707f2a78fec2.md)

## Rule

- **Rule:**
  ```text
  When modifying `echo`, preserve its role as the preferred output primitive over `print`, including handling encoding, Unicode on Windows, binary/text stream mismatches, color stripping for non-terminals, and always flushing.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  when changing `echo`'s output handling or documentation of its guarantees
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8c15df1ab73fde8fcd9fbef0.md)

## Rule

- **Rule:**
  ```text
  A leading \b no-rewrap marker in the first paragraph is stripped before computing the short help, and only the first paragraph (up to a blank line) is considered.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying short help generation or no-rewrap marker handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af72b820ca6194da4afe3b23.md)

## Rule

- **Rule:**
  ```text
  When modifying the KeepOpenFile context manager, preserve __exit__ as a no-op returning None so the context manager does not suppress exceptions.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when changing KeepOpenFile context manager behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b89e5d4ca7a6431a9c025353.md)

## Rule

- **Rule:** LazyFile must behave like a regular file while deferring full opening and performing early filename checks, so it is safe to open files for writing.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying LazyFile opening, filename checking, or file-like delegation behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-de924ebc8b188f550313da49.md)

## Rule

- **Rule:**
  ```text
  When modifying `get_text_stream`, preserve that it raises `TypeError` for unknown stream names and otherwise delegates to the registered opener with encoding and errors.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  when changing `get_text_stream`'s stream-name validation or opener delegation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f8cef1e8491da7a16610799c.md)

## Rule

- **Rule:**
  ```text
  When modifying LazyFile.open, preserve wrapping of OSError from open_stream into a FileError carrying the original strerror as a hint, and recording whether the file should be closed.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when changing LazyFile.open error handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fdbc1ddd2c7a6dc8fa5c4bfb.md)
