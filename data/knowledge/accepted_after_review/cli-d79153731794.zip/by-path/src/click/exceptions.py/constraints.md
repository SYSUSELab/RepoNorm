# Constraints for `src/click/exceptions.py`

## Rule

- **Rule:**
  ```text
  When modifying ClickException.format_message, preserve returning self.message directly so subclasses can override message formatting by setting the message attribute.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when changing exception message formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-171debb17a4b05be083c8d2c.md)

## Rule

- **Rule:**
  ```text
  UsageError must be a ClickException subclass with exit_code = 2, and its constructor must accept an optional ctx that Click fills in automatically in some situations.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When modifying UsageError or adding new exception types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-399a27ca153a755adb384edf.md)

## Rule

- **Rule:**
  ```text
  ClickException.__init__ must store the context and derive cmd from ctx.command when a context is provided, linking exceptions to their command.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When modifying ClickException.__init__ or exception construction, preserve storing ctx and deriving cmd from ctx.command.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-64943979968dcbbcdaa5bb05.md)

## Rule

- **Rule:**
  ```text
  ClickException.show must write the formatted error through echo with the exception's show_color, defaulting the output file to get_text_stderr().
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When modifying ClickException.show or error output formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-83552a208f993b902b4f9201.md)

## Rule

- **Rule:**
  ```text
  When modifying `Exit.__init__`, preserve that the provided code is stored as an int `exit_code`, defaulting to 0.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  when changing `Exit` construction or its exit-code storage
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8d05e855b605a0f6f6972224.md)

## Rule

- **Rule:**
  ```text
  When modifying FileError.format_message, preserve the localized message format "Could not open file {filename!r}: {message}" using the ui_filename and message attributes.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When changing file-open error message formatting or localization in FileError.format_message.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9be7ca819560ddcd3f0e41b0.md)

## Rule

- **Rule:**
  ```text
  _join_param_hints must join a sequence of param hints with ' / ' using repr() of each element, while returning a plain string hint unchanged, defining how multiple parameter hints are rendered in error messages.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When changing parameter hint rendering in error messages.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9e88b475cc9509a1f0f583c1.md)

## Rule

- **Rule:**
  ```text
  When modifying MissingParameter, preserve its BadParameter subclassing and the documented param_type values 'parameter', 'option', or 'argument', defaulting to inheriting the type from the given param.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When changing MissingParameter's inheritance or param_type defaulting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc8ecf9febf3dfcb085eb5e4.md)

## Rule

- **Rule:**
  ```text
  When modifying `MissingParameter.format_message`, preserve the missing-parameter message construction: resolve `param_hint` from `param.get_error_hint`, append the type's missing message, and translate `param_type` into 'Missing argument', 'Missing option', 'Missing parameter', or a generic 'Missing {param_type}'.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when changing missing-parameter error message formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e20f23e5237707244fe1280f.md)
