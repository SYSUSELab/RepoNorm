# Constraints for `src/click/core.py`

## Rule

- **Rule:**
  ```text
  When declaring an Argument, accept exactly one name; allow zero declarations only when expose_value is False, otherwise raise TypeError.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Argument._parse_decls or argument name-declaration validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-02e6881e25e7151292d8ea06.md)

## Rule

- **Rule:**
  ```text
  augment_usage_errors must attach the context to BadParameter/UsageError only when e.ctx is None, and attach the parameter to BadParameter only when e.param is None, preserving pre-existing exception context.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying augment_usage_errors or error-context attachment, preserve the None-guarded attachment of ctx and param.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0966be826fde449ffa386627.md)

## Rule

- **Rule:**
  ```text
  Argument must be a Parameter subclass with param_type_name "argument"; arguments are positional, required by default, and support infinite nargs, unlike options.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying Argument or adding new parameter types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1578f25d09687b54b22655d7.md)

## Rule

- **Rule:**
  ```text
  When building a usage string, delegate to format_usage and strip trailing newlines so callers receive a usage string without a trailing newline.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Command.get_usage or the usage-string formatting path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-18df819ada9d682666f601c5.md)

## Rule

- **Rule:**
  ```text
  _BaseCommand must remain deprecated as of 8.2 and slated for removal in Click 9.0, with contributors directed to use Command instead.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying or removing deprecated command base classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-61149b63adbec30e1ad2c529.md)

## Rule

- **Rule:**
  ```text
  When modifying Option.to_info_dict, preserve the stable set of introspection fields: help, prompt, is_flag, flag_value, count, and hidden, extending the parent info dict.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Option introspection output or the fields exposed by Option.to_info_dict.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6907333eade996c3f5697c11.md)

## Rule

- **Rule:**
  ```text
  batch() must group items using zip(*repeat(iter(iterable), batch_size)) and return a list of tuples of batch_size, preserving the tuple grouping contract.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying batch() or its grouping logic in src/click/core.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-829658d54c13dad74cb3e654.md)

## Rule

- **Rule:**
  ```text
  Module __getattr__ must emit DeprecationWarning for 'BaseCommand' and 'MultiCommand', returning _BaseCommand/_MultiCommand and stating removal in Click 9.0; unknown names raise AttributeError.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying module-level deprecation shims or adding new deprecated aliases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8883f673b15ed67005187ccd.md)

## Rule

- **Rule:**
  ```text
  When modifying iter_params_for_processing, preserve the ordering contract that parameters are sorted by a sort_key derived from invocation order and declaration order.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing parameter processing order or the sort_key derivation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8e33d4c1f0a976a1dea43646.md)

## Rule

- **Rule:**
  ```text
  _main_shell_completion must derive the completion env var name from prog_name by replacing '-' and '.' with '_' and uppercasing; the dot replacement was added in 8.2.0 and must be preserved.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying _main_shell_completion or the completion env var derivation, preserve replacement of both '-' and '.' with '_' followed by uppercasing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9910824d650b3f6fe8b51bc0.md)

## Rule

- **Rule:**
  ```text
  The help option callback must only echo help and exit when the option value is truthy and ctx.resilient_parsing is false, so help output must be suppressed during resilient parsing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Command.get_help_option's show_help callback or the resilient-parsing handling around help output.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a2c8ee78e5f80a68e08ef331.md)

## Rule

- **Rule:**
  ```text
  When modifying `Command.format_options`, preserve that it collects help records from `get_params`, skips params whose `get_help_record` returns `None`, and only writes the 'Options' section when at least one record exists.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** when changing help option formatting or the Options section emission
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a429458ef13a2be81bf9b1dd.md)

## Rule

- **Rule:** Code that subclasses or type-checks against the command base class must use Command, not the removed BaseCommand alias.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When adding or modifying a command class or code that subclasses/type-checks the command base class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ab2e49444548edcdf6282a81.md)

## Rule

- **Rule:**
  ```text
  get_default must be overloaded to return either a value or a callable depending on the call parameter, preserving the callable-return contract.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Option.get_default or its typing overloads.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b1be1164441b226a37bc301b.md)

## Rule

- **Rule:**
  ```text
  Since 8.1, help, epilog, and short_help must be stored unprocessed and formatting deferred to help output time, so code must not assume these attributes contain pre-wrapped text.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Command help, epilog, or short_help storage or formatting behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c8d173f3a60e1509d80dfe96.md)

## Rule

- **Rule:**
  ```text
  When modifying Option.get_help_extra, preserve deriving envvar names from auto_envvar_prefix and option name, temporarily enabling resilient parsing while computing defaults, formatting defaults specially for lists, functions, boolean flags, and empty strings, and adding range info for number range types except count options with default range.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** when changing help extra generation for options
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ecd06714083a4861254ca9da.md)

## Rule

- **Rule:**
  ```text
  When modifying Argument.get_error_hint, preserve returning the parameter's metavar wrapped in single quotes as the default hint format.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing get_error_hint's default hint formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f8e89448403a2d3c8d58c634.md)
