# Constraints for `src/click`

## Rule

- **Rule:** mypy is configured with strict = true.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-341814c09e2e121b26ab9ac0.md)

## Rule

- **Rule:** mypy is configured to check the files under src/click and tests/typing.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-50a30bf391a7e1f55b47a4b9.md)

## Rule

- **Rule:** Pyright type checking is scoped to the src/click and tests/typing directories.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7bb17a22481594b0c5dcc52c.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with show_error_codes = true.
  ```
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc85ae5ed01d6e1cb63a039c.md)

## Rule

- **Rule:** mypy is configured with pretty = true.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e313d118ce6bc5858e277b10.md)
