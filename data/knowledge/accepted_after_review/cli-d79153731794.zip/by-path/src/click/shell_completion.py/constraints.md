# Constraints for `src/click/shell_completion.py`

## Rule

- **Rule:**
  ```text
  _is_incomplete_argument must return True when nargs is -1, when the parameter source is not COMMANDLINE, or when nargs > 1 and the collected tuple/list value is shorter than nargs, defining when shell completion should continue offering values.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying _is_incomplete_argument or shell-completion continuation logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-040382aca8c70891192f4d8b.md)

## Rule

- **Rule:**
  ```text
  ShellComplete subclasses must define source_template and a class-level name; the name registers the shell and forms the {name}_source and {name}_complete completion instruction keys.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** when adding or modifying a shell completion backend subclass
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-12369758c12324118bbe2c72.md)

## Rule

- **Rule:**
  ```text
  BashComplete must register itself under the name "bash" and use the _SOURCE_BASH source template, establishing the shell-completion registration convention.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** When modifying shell-completion registration or adding a new shell completion class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a6072cc1e27ee7e4ae35287.md)

## Rule

- **Rule:**
  ```text
  When modifying ZshComplete.format_completion, preserve the three-line completion item of type, value, and help or '_' when help is absent.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing format_completion's output line structure or help fallback.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1b82c955be34bcd6abc7cc3a.md)

## Rule

- **Rule:**
  ```text
  When reading Bash completion state, read COMP_WORDS and COMP_CWORD from the environment, take args as cwords[1:cword], and treat a missing cwords[cword] as an empty incomplete token.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying BashComplete.get_completion_args or the Bash completion argument extraction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1f3fbb81f1ebff44ff9862dc.md)

## Rule

- **Rule:**
  ```text
  When modifying _resolve_context, preserve resilient_parsing=True, hierarchy walking via resolve_command, chained-group handling with allow_extra_args=True and allow_interspersed_args=False, and returning the deepest context without triggering prompts or callbacks.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing shell completion context resolution or command hierarchy walking in _resolve_context.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44c38790d266166fdfa8ea0b.md)

## Rule

- **Rule:**
  ```text
  ShellComplete subclasses must implement get_completion_args; the base method raises NotImplementedError, so custom shell completion classes are required to supply args/incomplete parsing.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** When adding or modifying a shell completion subclass.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6fa5fa131c90a10e8ad13590.md)

## Rule

- **Rule:**
  ```text
  ShellComplete.func_name must derive the completion function name from prog_name by replacing hyphens with underscores and stripping non-word characters, yielding "_{safe_name}_completion".
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying shell completion function name generation or prog_name handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8407562816bf52fc2d398f1f.md)

## Rule

- **Rule:**
  ```text
  When modifying _resolve_incomplete, preserve '=' normalization by splitting and discarding it, returning the command for option-name completion when '--' is absent and the incomplete value starts like an option, and otherwise selecting the option or argument that should provide value completion.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing incomplete-value normalization or completion target selection in _resolve_incomplete.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-86428926137ed5557576965f.md)

## Rule

- **Rule:**
  ```text
  Bash shell completion must reject Bash versions older than 4.4 and must also fail when the version cannot be detected, so any change to BashComplete._check_version or its version-parsing path must preserve this hard compatibility boundary.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying BashComplete._check_version or the Bash version detection/parsing logic used by shell completion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-abf339dcd2e10b560c8d1312.md)

## Rule

- **Rule:**
  ```text
  FishComplete must remain a ShellComplete subclass with name 'fish' and source_template _SOURCE_FISH, defining the Fish shell completion implementation.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying shell completion classes, preserve FishComplete's subclassing of ShellComplete, its name 'fish', and its _SOURCE_FISH template.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b703cd9cdbc2c8f30f7f037a.md)

## Rule

- **Rule:**
  ```text
  When modifying _start_of_option, preserve returning False for an empty value and otherwise checking whether the first character is in ctx._opt_prefixes, so option detection is context-dependent.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing option prefix detection or empty-value handling in _start_of_option.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bd846287a96323a7bc7fc6c1.md)

## Rule

- **Rule:**
  ```text
  When modifying `ShellComplete.complete`, preserve the wire format: join formatted completions with newlines after obtaining args and completions.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** when changing shell completion output formatting or the complete method
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e2d64450b3f83e79bb8a7d02.md)

## Rule

- **Rule:**
  ```text
  FishComplete.get_completion_args must remove the final argument when it equals COMP_CWORD because Fish stores the partial word in both COMP_WORDS and COMP_CWORD, preventing duplication in complete args.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When changing Fish completion argument parsing or COMP_CWORD handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f296332fddc0d5b9e4449c76.md)
