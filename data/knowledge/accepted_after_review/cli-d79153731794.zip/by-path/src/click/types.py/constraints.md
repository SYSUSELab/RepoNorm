# Constraints for `src/click/types.py`

## Rule

- **Rule:**
  ```text
  _NumberRangeBase._describe_range must format numeric range help text using open/closed comparison operators based on min_open and max_open, producing strings like x<max, x>=min, or min<=x<=max.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying _NumberRangeBase._describe_range or range help formatting, preserve the open/closed operator selection driven by min_open and max_open.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1972e8d68c5f16805afc2e58.md)

## Rule

- **Rule:**
  ```text
  When modifying Path.to_info_dict, preserve extending the parent dict with exists, file_okay, dir_okay, writable, readable, and allow_dash.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing Path.to_info_dict's introspection fields.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2711e15babc473861151b547.md)

## Rule

- **Rule:**
  ```text
  Path.shell_complete must return a CompletionItem with type 'dir' when dir_okay and not file_okay, otherwise 'file', signaling the shell to provide path completions.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Path.shell_complete or path completion behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-283e196d497659ffcd1947b6.md)

## Rule

- **Rule:** CompositeParamType.arity must raise NotImplementedError, marking it as an abstract member that subclasses must override.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying CompositeParamType or adding new composite parameter types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2b54b2586ff01cebea8d9c0a.md)

## Rule

- **Rule:**
  ```text
  Choice.convert must normalize the value and choices through ctx.token_normalize_func before casefolding when case_sensitive is False, and must report failures using the original value via get_invalid_choice_message.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying Choice.convert or the normalization/casefolding path for choice conversion.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d3588304db859dee7f150f7.md)

## Rule

- **Rule:** The module must define module-level parameter type singletons UNPROCESSED, STRING, INT, FLOAT, BOOL, and UUID, with UNPROCESSED documented as performing no string conversion for bytes input; contributors should use these public constants.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When adding or modifying parameter type constants in src/click/types.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d654b58d2b09a457b801243.md)

## Rule

- **Rule:**
  ```text
  Tuple type conversion must convert each supplied type via convert_type and store the resulting sequence of ParamType instances.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Tuple.__init__ or the type conversion pipeline for composite types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3f3f88533a23a5aeeaef083b.md)

## Rule

- **Rule:**
  ```text
  to_info_dict extends the superclass dict with a 'formats' key set to self.formats, establishing the convention that type info dicts include a formats entry.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when modifying type info dict generation or adding a new parameter type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4ee89a820e1016e4480e61cc.md)

## Rule

- **Rule:** When modifying OptionHelpExtra, preserve the TypedDict contract with optional keys envvars, default, range, and required defining the extra help metadata for options.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing the OptionHelpExtra TypedDict or the extra help metadata keys for options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5f3c4eb60b726b6750879840.md)

## Rule

- **Rule:** FuncParamType is a ParamType subclass intended for wrapping a user-supplied callable as a Click parameter type, establishing the extension point for custom type conversion.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when adding or modifying custom parameter type wrappers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6ebff2d3ff52deeed0191d8d.md)

## Rule

- **Rule:**
  ```text
  When modifying DateTime._try_to_convert_date, preserve attempting datetime.strptime and returning None on ValueError so callers treat unparseable values as non-matches rather than raising.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing date parsing or error handling in DateTime._try_to_convert_date.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-861db86231d09216609f1423.md)

## Rule

- **Rule:**
  ```text
  Path.coerce_path_result must convert values to str via os.fsdecode, to bytes via os.fsencode, or to the configured self.type, returning the value unchanged when it already matches the configured type.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying Path type coercion or adding new path result types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-908d81f91534149e248ae919.md)

## Rule

- **Rule:**
  ```text
  When modifying _NumberParamTypeBase, preserve _number_class as a ClassVar establishing the subclass contract for numeric ParamType implementations.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when changing numeric ParamType subclass contracts
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95e23d64dd3e88a8e4e377e1.md)

## Rule

- **Rule:** When modifying StringParamType.convert, preserve bytes decoding with the argv encoding and the UnicodeError fallback to filesystem encoding if different, otherwise utf-8 with 'replace', and coerce non-bytes values with str.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing StringParamType.convert's decoding or non-bytes coercion behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c50a0d5e12feb82276a7d89f.md)

## Rule

- **Rule:**
  ```text
  ParamType.to_info_dict must derive param_type by stripping 'ParamType'/'ParameterType' suffixes from the class name, falling back to that name when the instance has no name attribute, and return a dict with 'param_type' and 'name' keys.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying ParamType.to_info_dict or adding ParamType subclasses, preserve the suffix-stripping derivation and the {'param_type', 'name'} return shape.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dc6da1eaef46924e0c45191f.md)

## Rule

- **Rule:**
  ```text
  When modifying FloatRange, preserve the documented constraint that clamp is not supported when either boundary is marked open, and that min_open/max_open were added in 8.0.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when changing FloatRange parameter handling or documentation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e171901a83cd1c3b8b1d1d33.md)

## Rule

- **Rule:**
  ```text
  IntRange must subclass _NumberRangeBase and IntParamType, support min/max and min_open/max_open boundaries, and provide clamp behavior, with min_open/max_open added in version 8.0.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing IntRange boundaries, clamping, or its base classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e51b2f66fd4dfd97c1523e8b.md)

## Rule

- **Rule:**
  ```text
  Choice.shell_complete must filter choices by prefix and honor case_sensitive: when False it lowercases the incomplete value and compares against lowercased choices, returning CompletionItem objects.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Choice.shell_complete prefix filtering or case-sensitivity handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ea8ada3fb74dc46127a956bb.md)

## Rule

- **Rule:**
  ```text
  Choice.__repr__ must render as "Choice([...])" listing the choices, so repr output is part of the observable API for Choice parameters.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Choice or its repr, preserve the "Choice([...])" format listing the choices.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f6a80caf69a29796a4e61d7c.md)
