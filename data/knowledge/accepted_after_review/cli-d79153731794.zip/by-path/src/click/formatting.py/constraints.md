# Constraints for `src/click/formatting.py`

## Rule

- **Rule:** HelpFormatter.section must be a contextmanager that writes a paragraph, writes a heading, indents, yields, and always dedents in a finally block, ensuring indentation is restored even on exception.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When modifying HelpFormatter.section or its indentation-restoration behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-37a84a9b51629f3ee293fc91.md)

## Rule

- **Rule:**
  ```text
  When modifying HelpFormatter.write_dl, preserve the TypeError when the measured table does not have exactly two columns and the second-column wrapping with minimum text width 10 and preserve_paragraphs=True.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When changing write_dl's column validation or second-column wrapping parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3ac97a247e3835a7ddc2852b.md)

## Rule

- **Rule:**
  ```text
  write_heading must format the heading with right-aligned padding to current_indent followed by a colon and newline, producing the standard 'Heading:' style in help output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When modifying HelpFormatter.write_heading or help output formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5ca62725f0b6c6215697cbed.md)

## Rule

- **Rule:**
  ```text
  write_text must re-indent and rewrap text with preserve_paragraphs=True, using the same indent for initial and subsequent lines, then append a trailing newline.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When modifying HelpFormatter.write_text or its re-indent/rewrap behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-897c205bb7f74aef94d41359.md)

## Rule

- **Rule:** HelpFormatter.indentation must increase indentation on entry and guarantee dedent on exit via finally, so indentation is balanced even if the body raises.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When modifying HelpFormatter.indentation or its context-manager logic, preserve the finally-based dedent guarantee.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8980782c72337d50e6eae02a.md)

## Rule

- **Rule:**
  ```text
  formatting.py must expose a module-level FORCED_WIDTH that can force a width, explicitly used by the test system.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When changing formatting width resolution or test-controlled width overrides.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9af8ade3cc81723a7e3b4acd.md)

## Rule

- **Rule:**
  ```text
  When modifying measure_table, preserve computing per-column maximum term_len across rows and returning widths as a tuple ordered by column index.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When changing table width measurement or column ordering in measure_table.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b56942ba6a9b3b6eec3158a0.md)

## Rule

- **Rule:**
  ```text
  When modifying join_options, preserve the returned tuple of joined option string and slash-prefix boolean, and sort options by prefix length so shorter prefixes appear first.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When changing join_options' return shape or option ordering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d2c5273fd41307bd99ff0b32.md)

## Rule

- **Rule:** When modifying HelpFormatter, preserve the documented behavior of always writing into memory and defaulting its width to the terminal width clamped to a maximum of 78.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** when changing HelpFormatter output or width defaults
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ff305de690f6619ce85d2e67.md)
