# Constraints for `src/click/_termui_impl.py`

## Rule

- **Rule:**
  ```text
  When modifying _pipepager, preserve the LESS-flag-driven color decision: enable color when LESS contains 'r' or 'R', otherwise set LESS='-R' and enable color; strip ANSI when color is disabled, and loop on c.wait() to ignore KeyboardInterrupt so less handles ^C.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:**
  ```text
  When changing pager invocation, LESS environment handling, or color/ANSI stripping in _pipepager.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-21f888ed9d1e42f98937bd03.md)

## Rule

- **Rule:**
  ```text
  getchar reads up to 32 bytes from the raw terminal fd and decodes with get_best_encoding(sys.stdin) using 'replace'; echo only occurs when isatty(sys.stdout), and _translate_ch_to_exc is invoked before returning the character.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:** when modifying raw terminal character reading or its decoding and echo behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-68b3a542a1234db4063b16a9.md)

## Rule

- **Rule:**
  ```text
  getchar on Windows uses getwch instead of getch to support non-ASCII characters and handles special-key sequences starting with \x00 or \xe0 by calling the function again, so typing a non-ASCII character may require a second character before returning.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:** when modifying Windows getchar behavior or special-key handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-93b132795bb9824aa7f2f5ca.md)

## Rule

- **Rule:**
  ```text
  When modifying Editor.edit, preserve the mtime workaround: set the temp file's mtime 2 seconds in the past before invoking the editor, then compare the recorded timestamp to detect whether the editor actually saved changes when require_save is set.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:** when changing editor invocation or change-detection logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bab378e18f0da88ae56280e1.md)

## Rule

- **Rule:**
  ```text
  When modifying `_nullpager`, preserve its role as the ultimate fallback pager: write each generator chunk directly to the stream, stripping ANSI when color is false.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:** when changing pager fallback behavior or ANSI stripping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c100a0754ee5ec42da65fccc.md)

## Rule

- **Rule:**
  ```text
  _unquote_file must strip the 'file://' prefix and URL-unquote the remainder; non-file URLs are returned unchanged.
  ```
- **Applies to:**
  - `src/click/_termui_impl.py`
- **Condition:**
  ```text
  When modifying open_url's file URL handling or _unquote_file.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc93c8abae94fe4a2fbe3fa5.md)
