# Constraints for `src/click/_winconsole.py`

## Rule

- **Rule:**
  ```text
  ConsoleStream must remain a Windows-specific stream wrapper in click._winconsole, preserving platform-specific console handling.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When modifying or relocating Windows console stream handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0df4255590f62b794fa23a20.md)

## Rule

- **Rule:**
  ```text
  Py_buffer is a ctypes Structure whose _fields_ mirror CPython's Py_buffer layout (buf, obj, len, itemsize, readonly, ndim, format, shape, strides, suboffsets, internal), used for Windows console buffer handling.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  when modifying Windows console buffer handling or the Py_buffer ctypes structure
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-33dfd038680585b86a99e1c8.md)

## Rule

- **Rule:**
  ```text
  _get_text_stderr must wrap the Windows console writer in a text stream using utf-16-le with strict errors and line buffering, reflecting the Windows console encoding contract.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying _get_text_stderr or Windows console text-stream wrapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3ce3a863adbb80e3391d7cae.md)

## Rule

- **Rule:**
  ```text
  Windows console writer implementations must subclass _WindowsConsoleRawIOBase to provide the Windows console writer surface.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When adding or modifying a Windows console writer class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3cf0e45460ef20f8c4c22e6c.md)

## Rule

- **Rule:**
  ```text
  When modifying _WindowsConsoleWriter.write, preserve capping code units at MAX_BYTES_WRITTEN//2 and raising OSError with the last error message when zero bytes are written for a nonempty buffer.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When changing Windows console write chunking or zero-byte error handling in _WindowsConsoleWriter.write.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4e7c2322ae6ad914b16d2ee0.md)

## Rule

- **Rule:**
  ```text
  On PyPy, importing ctypes.pythonapi fails, so get_buffer must be set to None and buffer-based console operations must be unavailable.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying Windows console buffer handling or platform detection in click._winconsole.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-549cb93bd36215f09b2bcd2c.md)

## Rule

- **Rule:**
  ```text
  _get_text_stdout must wrap a Windows console writer in a non-closing text wrapper using utf-16-le with strict errors and line buffering, then cast it to a ConsoleStream.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying _get_text_stdout or Windows console text stream construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e7d9e6181affd73dfebdde7.md)

## Rule

- **Rule:**
  ```text
  _WindowsConsoleRawIOBase.__init__ stores the raw handle without validation, so callers are responsible for passing a valid handle.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  When modifying _WindowsConsoleRawIOBase.__init__ or its callers, preserve the no-validation contract and ensure callers pass a valid handle.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a1b2bed03f343a92b042586b.md)

## Rule

- **Rule:**
  ```text
  When modifying the Windows console stream's `isatty`, preserve that it calls `super().isatty()` and then unconditionally returns True, forcing TTY detection to true for that stream.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** when changing Windows console TTY detection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-be0c1fa0187beaaf2972f201.md)

## Rule

- **Rule:** Windows console stdin must be wrapped as a UTF-16-LE text stream with strict error handling and line buffering, and the wrapper must be non-closing so the underlying buffer stream is not closed when the text stream is closed.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When modifying Windows console stdin wrapping or text stream configuration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bf84779eb05928452f77a409.md)

## Rule

- **Rule:** When a module is Windows-only, assert sys.platform == "win32" at import time before importing msvcrt and ctypes.windll, so the module fails fast on non-Windows platforms.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** Modifying the Windows console module or its import-time platform guard.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cf0e5e5b4089934fa9023e44.md)

## Rule

- **Rule:**
  ```text
  When modifying ConsoleStream.__repr__, preserve the format '<ConsoleStream name={name!r} encoding={encoding!r}>'.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When changing ConsoleStream repr output or its name/encoding fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f8eb302e64680ffc33294c56.md)
