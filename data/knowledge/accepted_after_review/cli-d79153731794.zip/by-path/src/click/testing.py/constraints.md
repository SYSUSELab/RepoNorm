# Constraints for `src/click/testing.py`

## Rule

- **Rule:**
  ```text
  CliRunner.make_env must return a copy of self.env updated with overrides so caller-supplied overrides do not mutate the runner's base environment.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying CliRunner.make_env or environment override handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0694e7c62c707f587f925986.md)

## Rule

- **Rule:**
  ```text
  When _pause_echo is used as a context manager, set stream._paused=True on entry and False on exit, yielding immediately when stream is None, to control echo suppression during testing.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying _pause_echo or the echo-suppression context manager used in tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-08b5c06f07a6281d1f0bf1e6.md)

## Rule

- **Rule:**
  ```text
  isolated_filesystem must create a temporary directory, change CWD to it, restore the original CWD on exit, and not remove the created directory when temp_dir is provided.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying CliRunner.isolated_filesystem or temporary directory handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2969b0ef4700047d32a443c6.md)

## Rule

- **Rule:**
  ```text
  Result.__init__ must store runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception, and exc_info (defaulting to None), defining the attribute surface of CliRunner results.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying Result.__init__ or the CliRunner result attribute surface.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-620bf7f22ab9cab3e8957102.md)

## Rule

- **Rule:** BytesIOCopy must patch io.BytesIO so the written stream can be copied to another stream, added in version 8.2.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When changing the BytesIOCopy testing utility or its stream-copy behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-695adcae0c092c7d8e1c59c4.md)

## Rule

- **Rule:** CliRunner is documented to work only in single-threaded systems without concurrency because it mutates global interpreter state; do not use it in concurrent or multi-threaded test contexts.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When adding or modifying CliRunner behavior or documenting its usage, preserve the single-threaded, no-concurrency constraint.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-699c33680c622cc69fc18bc0.md)

## Rule

- **Rule:**
  ```text
  When modifying EchoingStdin.__getattr__, preserve delegation of unknown attribute access to the wrapped input stream so the underlying stream's API is transparently exposed.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When changing EchoingStdin attribute delegation or the wrapped stream API surface.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7389ea77e7f9654b4ceeba0b.md)

## Rule

- **Rule:**
  ```text
  When modifying StreamMixer.flush, preserve flushing both the superclass stream and the copy_to target so mirrored output is flushed in tandem.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when changing StreamMixer flush behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7c009ac3262b01729fcb2cd8.md)

## Rule

- **Rule:** The testing echo-input getchar must read one character from sys.stdin, optionally echo it to sys.stdout, and flush stdout, so CliRunner input simulation routes through sys.stdin/stdout rather than a separate buffer.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When modifying CliRunner input simulation or the echo-input getchar behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-960f31de6cfed6d3d24db9ef.md)

## Rule

- **Rule:**
  ```text
  The visible_input helper must write the prompt to stdout, read a line from text_input, strip CR/LF, echo the value back to stdout, and flush, defining the observable input/output contract for tests using this helper.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying CliRunner.isolation.visible_input or test input/output helpers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a811585c66eea265423bb83c.md)

## Rule

- **Rule:** When StreamMixer is used, it mixes stdout and stderr streams with the combined result available in the output attribute, as documented since version 8.2.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** Modifying StreamMixer or its documented output attribute contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b61d63efdf21bbf5a9fe8c50.md)

## Rule

- **Rule:**
  ```text
  When modifying `CliRunner`, preserve the documented breaking change that the `mix_stderr` parameter was removed in version 8.2, so callers passing `mix_stderr` are no longer supported.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  when changing `CliRunner`'s constructor signature or stderr handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cad796cca4f01ed020f75784.md)

## Rule

- **Rule:** When a test stream wrapper is constructed, store name and mode separately and pass the underlying buffer to the superclass, preserving the original stream identity for testing.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  Modifying _NamedTextIOWrapper.__init__ or the test stream wrapper construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ce5ddf1b58c177a26011f74e.md)

## Rule

- **Rule:**
  ```text
  make_input_stream must accept objects with read as binary readers, raise TypeError when no binary reader can be found, encode str input with the given charset, and treat None as empty bytes, defining the accepted input types for CliRunner.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When modifying make_input_stream or the input coercion path used by CliRunner.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e2325a7872a16efd681a5f95.md)
