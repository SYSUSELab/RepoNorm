# Constraints for `src`

## Rule

- **Rule:** Ruff treats src as the source root directory.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1d4d15fa17496dc48d128d5b.md)
