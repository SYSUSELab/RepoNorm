# Claim catalog

- [Rules 1–73](catalog/0001.md); scope preview: `dirty_equals/_numeric.py`
- [Rules 74–148](catalog/0002.md); scope preview: `dirty_equals/_numeric.py`
- [Rules 149–220](catalog/0003.md); scope preview: `dirty_equals/_sequence.py`
- [Rules 221–270](catalog/0004.md); scope preview: `**`
