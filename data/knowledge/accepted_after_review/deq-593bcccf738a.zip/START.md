# Repository knowledge

- [Catalog](catalog.md): browse rules and their scopes.
- [By path](by-path/index.md): browse rules associated with repository paths.
- Follow a rule's detail link for sources, evidence, and limitations.

This collection may omit repository conventions.
