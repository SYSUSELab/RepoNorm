# Rule details

- **Rule:** The Upload Previews workflow triggers on the completion of the CI workflow.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Condition:**
  ```text
  workflow predicate: workflow_run: workflows: [ci] types: [completed]
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
on:
  workflow_run:
    workflows: [CI]
    types: [completed]

```

- **Sources:**
  - `.github/workflows/upload-previews.yml:3-6`

## Review evidence locations

- `.github/workflows/upload-previews.yml:1-6`
