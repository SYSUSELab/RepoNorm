# Rule details

- **Rule:** The MkDocs site is configured with the Material theme.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
theme:
  name: material

```

- **Sources:**
  - `mkdocs.yml:5-6`
