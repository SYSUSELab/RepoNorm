# Rule details

- **Rule:**
  ```text
  DirtyEquals.value must raise AttributeError until __eq__ has been called, and only return the last successfully compared value when _was_equal is true.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  When modifying DirtyEquals.value or the __eq__ comparison flow in dirty_equals/_base.py that sets _was_equal and the last compared value.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_base.py:77-108`
