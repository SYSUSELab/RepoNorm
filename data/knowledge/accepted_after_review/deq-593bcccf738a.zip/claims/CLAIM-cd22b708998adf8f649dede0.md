# Rule details

- **Rule:**
  ```text
  isort is configured with color_output = true.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
color_output = true

```

- **Sources:**
  - `pyproject.toml:75`

## Review evidence locations

- `pyproject.toml:69-75`
