# Rule details

- **Rule:**
  ```text
  The positive numeric variant must be defined by a greater-than-zero constraint (super().__init__(gt=0)) with empty _repr_kwargs; changes to this initializer must preserve the gt=0 constraint and the empty repr-kwargs convention.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** When modifying the positive numeric variant's initializer or its repr-kwargs handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_numeric.py:175-194`
