# Rule details

- **Rule:**
  ```text
  DirtyEquals.__ne__ must not set _was_equal, must store the compared value in self._other, and must return True when equals raises TypeError or ValueError, preserving pytest-compatible error reporting.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__ne__ or the equality comparison path it delegates to
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_base.py:110-116`
