# Rule details

- **Rule:** Coverage report precision is configured as 2.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
precision = 2

```

- **Sources:**
  - `pyproject.toml:54`

## Review evidence locations

- `pyproject.toml:53-55`
