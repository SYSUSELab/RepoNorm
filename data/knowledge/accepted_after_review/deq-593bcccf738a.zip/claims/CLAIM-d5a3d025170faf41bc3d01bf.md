# Rule details

- **Rule:** A local pre-commit hook with id 'mypy' runs 'make mypy' on Python-typed files using the system language.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
  - id: mypy
    name: Mypy
    entry: make mypy
    types: [python]
    language: system

```

- **Sources:**
  - `.pre-commit-config.yaml:16-20`
