# Rule details

- **Rule:**
  ```text
  When a datetime matcher compares with enforce_tz enabled, approx_equals must compare only UTC offsets rather than full tzinfo identity, and a naive approx must require the other value to be naive; do not tighten to full tzinfo equality.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** Modifying timezone handling in datetime approximate comparison.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsDatetime.approx_equals compares utcoffset under enforce_tz and requires naive-to-naive matching, matching the offset/naive rule.
```

- **Sources:**
  - `dirty_equals/_datetime.py:104-116`
