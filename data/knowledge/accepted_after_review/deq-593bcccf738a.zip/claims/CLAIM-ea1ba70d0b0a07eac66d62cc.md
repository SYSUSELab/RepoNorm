# Rule details

- **Rule:**
  ```text
  isort is configured with force_grid_wrap = 0.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
force_grid_wrap = 0

```

- **Sources:**
  - `pyproject.toml:73`
