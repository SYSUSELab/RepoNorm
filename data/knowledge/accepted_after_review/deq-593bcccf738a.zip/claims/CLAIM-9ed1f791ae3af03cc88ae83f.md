# Rule details

- **Rule:** The project declares Python "^3.7.0" as its supported Python version constraint.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
python = "^3.7.0"

```

- **Sources:**
  - `pyproject.toml:34`

## Review evidence locations

- `pyproject.toml:33-36`
