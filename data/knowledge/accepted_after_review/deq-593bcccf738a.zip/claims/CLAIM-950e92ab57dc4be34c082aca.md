# Rule details

- **Rule:** IsAnyStr matches both str and bytes values, and its regex argument accepts either a str or bytes pattern regardless of the compared value type.
- **Applies to:**
  - `tests/test_strings.py`
- **Condition:** When changing IsAnyStr's type acceptance or regex argument handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_strings.py:17-26`
- `dirty_equals/_strings.py:108-122`
- `tests/test_strings.py:105-112`
