# Rule details

- **Rule:**
  ```text
  Running `make clean` removes coverage artifacts `htmlcov`, `.coverage`, and `.coverage.*`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
clean:
	rm -rf `find . -name __pycache__`
	rm -f `find . -type f -name '*.py[co]' `
	rm -f `find . -type f -name '*~' `
	rm -f `find . -type f -name '.*~' `
	rm -rf .cache
	rm -rf .pytest_cache
	rm -rf .mypy_cache
	rm -rf htmlcov
	rm -rf *.egg-info
	rm -f .coverage
	rm -f .coverage.*

```

- **Sources:**
  - `Makefile:46-57`

## Review evidence locations

- `Makefile:45-57`
