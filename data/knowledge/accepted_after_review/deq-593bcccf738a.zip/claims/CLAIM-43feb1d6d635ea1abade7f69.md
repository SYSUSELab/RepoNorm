# Rule details

- **Rule:**
  ```text
  When a sequence matcher validates length, equals must delegate to _length_correct rather than duplicating length logic; do not inline a separate length check.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying length validation in a sequence matcher's equals.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_sequence.py:54-55`
- `dirty_equals/_sequence.py:187-192`
