# Rule details

- **Rule:**
  ```text
  Codecov coverage range is configured as [90, 100].
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  range: [90, 100]

```

- **Sources:**
  - `.codecov.yml:3`

## Review evidence locations

- `.codecov.yml:1-3`
