# Rule details

- **Rule:**
  ```text
  Tests for boolean composition of dirty matchers must assert that `|` provides OR semantics, that `~` negates the combined expression, and that the combined matcher's `str` reflects the composition.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin boolean composition semantics for dirty matchers, assert the specific operator semantics exercised (OR for `|`, negation for `~`) and the composed matcher's `str` representation only where the test actually covers that operator
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_base.py:8-16`
- `tests/test_base.py:127-138`
