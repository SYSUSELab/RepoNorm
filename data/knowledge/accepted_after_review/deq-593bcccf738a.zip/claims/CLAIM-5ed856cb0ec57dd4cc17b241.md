# Rule details

- **Rule:**
  ```text
  The docs plugin's on_files hook must return remove_files(files) so that plugins.py, requirements.txt, and __pycache__/ entries are excluded from the MkDocs file list during the build.
  ```
- **Applies to:**
  - `docs/plugins.py`
- **Condition:**
  ```text
  When modifying the on_files hook or the remove_files exclusion list in docs/plugins.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/plugins.py:34-50`
