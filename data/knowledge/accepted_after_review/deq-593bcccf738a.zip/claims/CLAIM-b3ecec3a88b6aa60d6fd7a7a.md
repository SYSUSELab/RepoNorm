# Rule details

- **Rule:** Pytest treats warnings as errors via filterwarnings = "error".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
filterwarnings = "error"

```

- **Sources:**
  - `pyproject.toml:47`

## Review evidence locations

- `pyproject.toml:45-47`
