# Rule details

- **Rule:** IsTrueLike.equals must return bool(other), so truthiness rather than identity with True is the comparison rule.
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:** Modifying IsTrueLike.equals comparison logic.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsTrueLike.equals returns bool(other), matching the rule that truthiness rather than identity with True governs comparison.
```

- **Sources:**
  - `dirty_equals/_boolean.py:28-29`
