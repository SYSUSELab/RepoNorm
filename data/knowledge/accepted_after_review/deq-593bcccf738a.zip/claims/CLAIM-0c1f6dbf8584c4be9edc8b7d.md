# Rule details

- **Rule:** The test job installs test requirements from tests/requirements.txt, installs the project with poetry, runs make test, and generates a coverage XML report.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
    - run: pip install -r tests/requirements.txt

```

- **Sources:**
  - `.github/workflows/ci.yml:41`

### Evidence 2 — explicit

```text
    - run: poetry install

```

- **Sources:**
  - `.github/workflows/ci.yml:44`

### Evidence 3 — explicit

```text
    - run: make test

```

- **Sources:**
  - `.github/workflows/ci.yml:47`

### Evidence 4 — explicit

```text
    - run: coverage xml

```

- **Sources:**
  - `.github/workflows/ci.yml:49`
