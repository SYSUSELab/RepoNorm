# Rule details

- **Rule:**
  ```text
  `HasAttributes.equals` must compare each expected attribute via `getattr` and return False on AttributeError, deliberately avoiding direct equality against AnyThing or DefaultAttr sentinels.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying `HasAttributes.equals` or the attribute-inspection comparison logic
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_inspection.py:194-204`
