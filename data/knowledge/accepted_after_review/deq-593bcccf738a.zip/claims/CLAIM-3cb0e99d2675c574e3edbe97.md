# Rule details

- **Rule:**
  ```text
  Running `make clean` removes editor backup files matching `*~` and `.*~`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
clean:
	rm -rf `find . -name __pycache__`
	rm -f `find . -type f -name '*.py[co]' `
	rm -f `find . -type f -name '*~' `
	rm -f `find . -type f -name '.*~' `

```

- **Sources:**
  - `Makefile:46-50`
