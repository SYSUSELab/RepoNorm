# Rule details

- **Rule:**
  ```text
  DirtyEquals.__eq__ must catch TypeError and ValueError raised by the subclass equals() implementation and return False instead of propagating the exception.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  When modifying DirtyEquals.__eq__ or adding a new DirtyEquals subclass whose equals() may raise TypeError or ValueError.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
DirtyEquals.__eq__ wraps self.equals(other) in try/except (TypeError, ValueError) and sets _was_equal to False instead of propagating.
```

- **Sources:**
  - `dirty_equals/_base.py:101-108`
