# Rule details

- **Rule:** IsDict.settings must return a new IsDict with copied state and must support strict, partial, and ignore; partial and ignore cannot be combined and must raise TypeError.
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:** when modifying IsDict.settings or the strict/partial/ignore configuration surface
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsDict.settings returns a new IsDict with copied state, supports strict/partial/ignore, and raises TypeError when partial and ignore are combined.
```

- **Sources:**
  - `dirty_equals/_dict.py:52-98`
