# Rule details

- **Rule:**
  ```text
  IsDict.__init__ must accept keyword arguments as expected dictionary entries, in addition to positional mapping input.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  When modifying IsDict.__init__ or adding new dictionary matcher construction forms.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_dict.py:19-27`
- `dirty_equals/_dict.py:34-41`
