# Rule details

- **Rule:** IsDict, IsPartialDict, IsIgnoreDict, and IsStrictDict have distinct matching semantics, including strict ordering and partial/ignore combinations, and must not be conflated.
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:** When changing or adding dict matcher classes or their matching semantics.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_dict.py:156-176`
- `dirty_equals/_dict.py:179-209`
- `dirty_equals/_dict.py:212-231`
- `tests/test_dict.py:17-43`
