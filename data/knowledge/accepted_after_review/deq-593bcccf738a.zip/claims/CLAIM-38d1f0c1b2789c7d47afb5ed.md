# Rule details

- **Rule:**
  ```text
  IsNow supports tz, unix_number, and iso_string modes: a tz-aware now matches IsNow(tz=...), a naive now matches bare IsNow, and unix_number/iso_string modes compare against the timestamp/isoformat representations rather than the datetime itself.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:**
  ```text
  When changing IsNow matching, preserve the tz-aware vs naive distinction and the unix_number/iso_string representation-based comparisons.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_datetime.py:101-115`
