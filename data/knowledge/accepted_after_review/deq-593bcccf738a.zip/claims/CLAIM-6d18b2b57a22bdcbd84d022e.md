# Rule details

- **Rule:**
  ```text
  `IsNow` must normalize timedelta, int, and float delta arguments into timedelta seconds, including fractional seconds converted to microseconds.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:** when modifying IsNow delta argument handling
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_datetime.py:118-121`
- `dirty_equals/_datetime.py:60-70`
