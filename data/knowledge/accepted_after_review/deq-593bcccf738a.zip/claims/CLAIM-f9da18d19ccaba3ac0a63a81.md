# Rule details

- **Rule:**
  ```text
  Tests for `IsFalseLike` must assert that `0 != IsFalseLike()` raises `AssertionError`, documenting that 0 is treated as false-like and the `!=` operator is inverted.
  ```
- **Applies to:**
  - `tests/test_boolean.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `IsFalseLike` semantics for falsy values
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_boolean.py:48-51`
- `dirty_equals/_base.py:110-116`
