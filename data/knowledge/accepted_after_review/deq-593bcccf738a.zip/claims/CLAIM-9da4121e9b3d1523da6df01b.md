# Rule details

- **Rule:**
  ```text
  dirty_equals/_other.py declares an overload for __init__ accepting **expected_kwargs, indicating keyword-based construction is part of the public API; preserve this keyword-construction contract when modifying matcher constructors.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  When modifying __init__ overloads or keyword-based construction in dirty_equals/_other.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_other.py:63-76`
- `dirty_equals/_other.py:101-107`
