# Rule details

- **Rule:**
  ```text
  IsJson must compare equal to both IsJson(expected_value) and the subscript form IsJson[expected_value] for null, string, list, and object JSON values.
  ```
- **Applies to:**
  - `tests/test_other.py`
- **Condition:** when adding or modifying tests for IsJson equality across constructor and subscript forms
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_other.py contains test_is_json_specific_true asserting equality for both IsJson(expected_value) and IsJson[expected_value] across null, string, list, and object JSON values, satisfying the dual-form coverage rule.
```

- **Sources:**
  - `tests/test_other.py`
