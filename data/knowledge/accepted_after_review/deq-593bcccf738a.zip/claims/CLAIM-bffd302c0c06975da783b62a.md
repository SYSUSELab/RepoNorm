# Rule details

- **Rule:** DirtyEquals equals for a dirty tuple must return True only if all dirty values equal the other value, defining AND-composition semantics for tuple matchers.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** When modifying DirtyAnd.equals or the tuple-composition equality path.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
DirtyAnd.equals returns all(d == other for d in self.dirties), implementing all-must-match AND-composition semantics for dirty tuples.
```

- **Sources:**
  - `dirty_equals/_base.py:161-162`
