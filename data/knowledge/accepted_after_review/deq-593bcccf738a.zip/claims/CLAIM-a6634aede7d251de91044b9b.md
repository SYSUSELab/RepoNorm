# Rule details

- **Rule:**
  ```text
  Tests for `IsDict` arity errors must assert that passing more than one argument raises `TypeError` with the exact message `'IsDict expected at most 1 argument, got 2'`.
  ```
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin the arity error contract for `IsDict`
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_dict.py:73-75`
- `dirty_equals/_utils.py:43-44`
