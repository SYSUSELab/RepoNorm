# Rule details

- **Rule:**
  ```text
  IsDate must accept approx/delta/gt/lt/ge/le plus iso_string and format_string, and numeric delta must be interpreted as seconds and converted to timedelta.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  Modifying IsDate.__init__ parameter handling or delta conversion.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsDate.__init__ accepts approx/delta/gt/lt/ge/le plus iso_string and format_string, and converts numeric delta to timedelta seconds.
```

- **Sources:**
  - `dirty_equals/_datetime.py:203-255`
