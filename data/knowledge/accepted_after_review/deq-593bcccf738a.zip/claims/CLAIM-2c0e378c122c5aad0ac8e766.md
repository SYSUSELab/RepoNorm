# Rule details

- **Rule:** Black formatting targets Python 3.9.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
target-version = ["py39"]

```

- **Sources:**
  - `pyproject.toml:66`

## Review evidence locations

- `pyproject.toml:63-67`
