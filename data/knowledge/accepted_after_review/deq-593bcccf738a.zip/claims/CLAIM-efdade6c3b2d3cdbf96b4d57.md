# Rule details

- **Rule:**
  ```text
  `IsOneOf` must remain composable with boolean operators, supporting combination with other DirtyEquals matchers.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying `IsOneOf` or the boolean-operator composition protocol on DirtyEquals
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_base.py:209-230`
- `tests/test_base.py:127-138`
