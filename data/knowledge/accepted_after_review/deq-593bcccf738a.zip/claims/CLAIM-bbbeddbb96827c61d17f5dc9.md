# Rule details

- **Rule:**
  ```text
  `IsAnyStr` must set `expected_types = (str, bytes)` and serve as the base for `IsStr` and `IsBytes`, which restrict comparison to `str` or `bytes` respectively.
  ```
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:**
  ```text
  when modifying `IsAnyStr`, `IsStr`, or `IsBytes` or their `expected_types`
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_strings.py:17-26`
- `dirty_equals/_strings.py:125-164`
