# Rule details

- **Rule:** The workflow downloads artifacts from the ci.yml workflow at the triggering run's head SHA using dawidd6/action-download-artifact.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: dawidd6/action-download-artifact@v2
        with:
          workflow: ci.yml
          commit: ${{ github.event.workflow_run.head_sha }}

```

- **Sources:**
  - `.github/workflows/upload-previews.yml:24-27`
