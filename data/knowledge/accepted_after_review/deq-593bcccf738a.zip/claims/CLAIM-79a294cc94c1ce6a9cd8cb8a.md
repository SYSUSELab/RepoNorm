# Rule details

- **Rule:**
  ```text
  The mkdocs-simple-hooks plugin maps the on_pre_build hook to docs.plugins:on_pre_build.
  ```
- **Applies to:**
  - `docs/plugins.py`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
  - mkdocs-simple-hooks:
      hooks:
        on_pre_build: 'docs.plugins:on_pre_build'

```

- **Sources:**
  - `mkdocs.yml:89-91`
