# Rule details

- **Rule:**
  ```text
  Matcher equality semantics are representation-sensitive: IsToday matches date objects directly, iso_string=True matches ISO date strings, and format_string='%Y/%m/%d' matches formatted date strings; mismatched representations must not match.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:** When changing IsToday's matching logic or adding new date-representation modes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_datetime.py:180-187`
