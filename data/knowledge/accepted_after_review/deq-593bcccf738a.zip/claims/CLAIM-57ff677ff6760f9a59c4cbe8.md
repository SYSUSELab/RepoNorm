# Rule details

- **Rule:** Tests for dirty-equals matchers must verify that the matcher's value attribute is only available after a comparison has been performed, and that accessing it beforehand raises AttributeError.
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** When adding or modifying tests for a dirty-equals matcher's value attribute lifecycle.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_base.py:33-54`
