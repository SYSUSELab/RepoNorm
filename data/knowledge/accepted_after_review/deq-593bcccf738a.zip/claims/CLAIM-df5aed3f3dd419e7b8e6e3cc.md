# Rule details

- **Rule:** The docs job builds the documentation site with mkdocs build --strict.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
    - name: build site
      run: mkdocs build --strict

```

- **Sources:**
  - `.github/workflows/ci.yml:97-98`
