# Rule details

- **Rule:**
  ```text
  Tests for `IsInstance` must assert that `IsInstance(Foo)` and `IsInstance[Foo]` are equivalent forms and that non-matching values compare unequal.
  ```
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `IsInstance` call and subscript equivalence
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_is_instance_of asserts Foo() == IsInstance(Foo), Foo() == IsInstance[Foo], and 1 != IsInstance[Foo], pinning call/subscript equivalence plus inequality.
```

- **Sources:**
  - `tests/test_inspection.py:21-24`
