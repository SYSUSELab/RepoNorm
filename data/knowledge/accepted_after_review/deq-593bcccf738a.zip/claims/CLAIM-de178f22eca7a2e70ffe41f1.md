# Rule details

- **Rule:**
  ```text
  Contains.equals returns all(v in other for v in self.contained_values), defining containment as requiring every contained value to be present in other; preserve this all-must-be-present semantics when modifying containment checks.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  When modifying Contains.equals or related containment matching in dirty_equals/_sequence.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_sequence.py:63-84`
- `tests/test_list_tuple.py:77-80`
