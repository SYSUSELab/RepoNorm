# Rule details

- **Rule:** Coverage branch measurement is enabled.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
branch = true

```

- **Sources:**
  - `pyproject.toml:51`

## Review evidence locations

- `pyproject.toml:49-51`
