# Rule details

- **Rule:**
  ```text
  HasName must check the value's __name__ attribute against the expected name as a DirtyEquals[T] predicate.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:** when modifying HasName or adding name-based inspection predicates
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_inspection.py:60-68`
- `dirty_equals/_inspection.py:102-105`
