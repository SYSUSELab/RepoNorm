# Rule details

- **Rule:**
  ```text
  `IsDict.__init__` must initialize `strict`, `partial`, and `ignore` defaults before calling `_post_init` and the superclass, defining the mutable settings surface used by `.settings(...)`.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying `IsDict.__init__` or the initialization order of `strict`, `partial`, and `ignore`
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsDict.__init__ sets strict=False, partial=False, and ignore=None before calling self._post_init() and super().__init__(), establishing the mutable settings surface.
```

- **Sources:**
  - `dirty_equals/_dict.py:27-47`

## Review evidence locations

- `dirty_equals/_dict.py:41-47`
- `dirty_equals/_dict.py:52-98`
