# Rule details

- **Rule:**
  ```text
  IsInstance.__class_getitem__ must return cls(expected_type), making IsInstance[ExpectedType] equivalent to IsInstance(ExpectedType).
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  When modifying IsInstance.__class_getitem__ or adding subscriptable matcher classes in dirty_equals/_inspection.py that must preserve the subscript-to-constructor equivalence.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_inspection.py:21-25`
- `dirty_equals/_inspection.py:50-51`
