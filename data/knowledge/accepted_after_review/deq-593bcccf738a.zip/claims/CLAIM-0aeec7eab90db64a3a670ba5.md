# Rule details

- **Rule:**
  ```text
  IsNonPositive initializes via super().__init__(le=0) and clears _repr_kwargs, defining its default upper bound and repr behavior; preserve this initialization contract when modifying non-positive numeric matchers.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  When modifying IsNonPositive.__init__ or related bound initialization in dirty_equals/_numeric.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_numeric.py:242-263`
