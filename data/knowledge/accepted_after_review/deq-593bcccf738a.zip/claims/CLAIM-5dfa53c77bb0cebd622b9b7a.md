# Rule details

- **Rule:** DirtyEqualsMeta must remain an ABCMeta subclass so dirty matcher classes stay abstract-base compatible and support class-level sentinel behavior; do not replace it with a plain metaclass or type.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying the DirtyEqualsMeta metaclass definition or its base classes
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
DirtyEqualsMeta is defined as a subclass of ABCMeta, preserving abstract-base compatibility and class-level sentinel behavior.
```

- **Sources:**
  - `dirty_equals/_base.py:18-45`
