# Rule details

- **Rule:** Black formatting emits colored output.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
color = true

```

- **Sources:**
  - `pyproject.toml:64`

## Review evidence locations

- `pyproject.toml:63-67`
