# Rule details

- **Rule:**
  ```text
  _sequence.py must export HasLen, Contains, IsListOrTuple, IsList, and IsTuple, and define LengthType as Union[None, int, Tuple[int, Union[int, Any]]], establishing the accepted length argument shapes.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  Modifying _sequence.py exports or LengthType definition.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The module dirty_equals/_sequence.py exports HasLen, Contains, IsListOrTuple, IsList, and IsTuple via __all__ and defines LengthType as Union[None, int, Tuple[int, Union[int, Any]]], matching the rule.
```

- **Sources:**
  - `dirty_equals/_sequence.py`
