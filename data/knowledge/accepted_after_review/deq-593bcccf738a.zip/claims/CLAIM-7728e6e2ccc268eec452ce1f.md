# Rule details

- **Rule:** typing-extensions is declared with version "^4.0.1" and is only required for Python versions below 3.8.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
typing-extensions = {version = "^4.0.1", python = "<3.8"}

```

- **Sources:**
  - `pyproject.toml:35`

## Review evidence locations

- `pyproject.toml:33-36`
