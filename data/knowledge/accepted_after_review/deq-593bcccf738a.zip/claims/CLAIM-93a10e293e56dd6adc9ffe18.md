# Rule details

- **Rule:**
  ```text
  FunctionCheck is a DirtyEquals[Any] predicate that delegates equality checking to a user-supplied function; preserve this delegation contract when modifying function-based matchers.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  When modifying FunctionCheck or related function-delegating matchers in dirty_equals/_other.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
FunctionCheck subclasses DirtyEquals[Any] and delegates equality checking to a user-supplied function, matching the function-delegation contract.
```

- **Sources:**
  - `dirty_equals/_other.py:123-147`

### Evidence 2 — current_observation

```text
FunctionCheck.__init__ stores the user-supplied func and delegates equality checking to it, matching the function-delegation contract.
```

- **Sources:**
  - `dirty_equals/_other.py:128-144`

### Evidence 3 — current_observation

```text
FunctionCheck.equals delegates equality checking to a user-supplied function via self.func(other), matching the function-delegation contract.
```

- **Sources:**
  - `dirty_equals/_other.py:146-147`
