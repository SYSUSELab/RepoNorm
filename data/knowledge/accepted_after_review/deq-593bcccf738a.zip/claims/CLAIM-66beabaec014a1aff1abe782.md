# Rule details

- **Rule:**
  ```text
  IsDict._post_init must remain a no-op hook that subclasses override to adjust dict matcher settings after initialization.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying IsDict._post_init or a subclass that overrides it to adjust dict matcher settings
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsDict._post_init is a no-op hook (body is `pass`), preserving the extension point that subclasses override to adjust dict matcher settings.
```

- **Sources:**
  - `dirty_equals/_dict.py:49-50`
