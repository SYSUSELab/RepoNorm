# Rule details

- **Rule:**
  ```text
  DirtyEquals.__invert__ must return DirtyNot(self) so ~dirty produces a negated matcher; do not change the negation result type or drop the inversion behavior.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__invert__ or the negation operator behavior
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
DirtyEquals.__invert__ returns DirtyNot(self), preserving the negation result type and inversion behavior required by the rule.
```

- **Sources:**
  - `dirty_equals/_base.py:124-125`
