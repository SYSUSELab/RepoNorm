# Rule details

- **Rule:** The upload-previews job runs only when the triggering workflow run concluded successfully.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Condition:**
  ```text
  workflow predicate: ${{ github.event.workflow_run.conclusion == 'success' }}
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    if: ${{ github.event.workflow_run.conclusion == 'success' }}

```

- **Sources:**
  - `.github/workflows/upload-previews.yml:13`

## Review evidence locations

- `.github/workflows/upload-previews.yml:11-14`
