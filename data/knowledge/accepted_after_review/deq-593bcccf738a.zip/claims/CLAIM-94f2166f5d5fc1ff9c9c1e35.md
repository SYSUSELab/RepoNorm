# Rule details

- **Rule:**
  ```text
  dirty_equals/_sequence.py must declare an overload for __init__ accepting *items, check_order, and length, documenting the public sequence constructor parameters.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  Modifying the IsListOrTuple.__init__ overload signature or public sequence constructor parameters.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_sequence.py:94-96`
