# Rule details

- **Rule:**
  ```text
  DirtyEquals equals for expected_values must return True if any expected value equals the other value, defining OR-composition semantics.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  Modifying IsOneOf.equals or the OR-composition comparison semantics for expected_values.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsOneOf.equals body returns any(other == e for e in self.expected_values), implementing OR-composition over expected_values as the rule requires.
```

- **Sources:**
  - `dirty_equals/_base.py:235-236`
