# Rule details

- **Rule:**
  ```text
  DirtyEquals subclasses must implement `equals` as the sole comparison hook; `__eq__` catches TypeError and ValueError raised from `equals` and treats them as inequality, so `equals` may raise these to signal a non-match but must not raise other exception types for ordinary mismatches.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when adding or modifying a DirtyEquals subclass's `equals` implementation or the base `__eq__` dispatch
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_base.py:69-75`
- `dirty_equals/_base.py:101-108`
- `docs/types/custom.md:30-36`
