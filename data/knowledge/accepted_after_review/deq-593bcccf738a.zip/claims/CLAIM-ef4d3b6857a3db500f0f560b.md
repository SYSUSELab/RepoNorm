# Rule details

- **Rule:**
  ```text
  `_numeric.py` must keep its `__all__` listing the public numeric types (`IsApprox`, `IsNumeric`, `IsNumber`, `IsPositive`, `IsNegative`, `IsNonPositive`, `IsNonNegative`, `IsInt`, `IsPositiveInt`, `IsNegativeInt`, `IsFloat`, `IsPositiveFloat`, `IsNegativeFloat`) as the module's public API surface.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  when adding, removing, or renaming public numeric matcher types in `_numeric.py`
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_numeric.py:7-21`
