# Rule details

- **Rule:**
  ```text
  isort is configured with include_trailing_comma = true.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
include_trailing_comma = true

```

- **Sources:**
  - `pyproject.toml:72`
