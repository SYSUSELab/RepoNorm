# Rule details

- **Rule:**
  ```text
  Combining dirty-equals predicates with & must produce a conjunction that passes only when both operands hold, and its repr must join the two operand names with ' & '.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  when adding or modifying tests for & composition of dirty-equals predicates
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_and asserts both conjunction semantics (4 == IsPositive & IsInt(lt=5), failure for IsStr & IsInt) and the ' & '-joined repr 'IsStr & IsInt'.
```

- **Sources:**
  - `tests/test_base.py`
