# Rule details

- **Rule:** The lint job runs make lint and make mypy.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
    - run: make lint
    - run: make mypy

```

- **Sources:**
  - `.github/workflows/ci.yml:75-76`
