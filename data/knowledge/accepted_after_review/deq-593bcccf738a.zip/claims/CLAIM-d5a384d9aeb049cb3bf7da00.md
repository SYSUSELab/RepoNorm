# Rule details

- **Rule:**
  ```text
  isort is configured with multi_line_output = 3.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
multi_line_output = 3

```

- **Sources:**
  - `pyproject.toml:71`

## Review evidence locations

- `pyproject.toml:69-75`
