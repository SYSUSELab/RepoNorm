# Rule details

- **Rule:** When a numeric matcher restricts allowed types, booleans must be explicitly excluded even though they are int subclasses; do not allow bool to match an int matcher.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** Modifying allowed-type constraints for numeric matchers.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsInt sets allowed_types = int and its docstring explicitly states booleans are excluded although technically int subclasses, matching the rule that bool must not match an int matcher.
```

- **Sources:**
  - `dirty_equals/_numeric.py:266-287`
