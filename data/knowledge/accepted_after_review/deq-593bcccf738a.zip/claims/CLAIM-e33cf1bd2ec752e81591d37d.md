# Rule details

- **Rule:**
  ```text
  `IsIgnoreDict._post_init` must set `ignore={None}`, so None keys are ignored by default in that dict matcher.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying `IsIgnoreDict._post_init` or the default `ignore` set
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsIgnoreDict._post_init sets self.ignore = {None}, establishing that None keys are ignored by default, matching the r4 rule.
```

- **Sources:**
  - `dirty_equals/_dict.py:208-209`
