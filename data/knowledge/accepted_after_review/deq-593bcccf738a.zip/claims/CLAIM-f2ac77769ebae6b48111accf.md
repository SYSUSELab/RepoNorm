# Rule details

- **Rule:**
  ```text
  Coverage excludes lines matching "pragma: no cover", "raise NotImplementedError", "raise NotImplemented", "if TYPE_CHECKING:", and "@overload" from coverage reporting.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
exclude_lines = [
    "pragma: no cover",
    "raise NotImplementedError",
    "raise NotImplemented",
    "if TYPE_CHECKING:",
    "@overload",
]

```

- **Sources:**
  - `pyproject.toml:55-61`
