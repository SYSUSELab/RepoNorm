# Rule details

- **Rule:**
  ```text
  IsStr must accept str (and IsAnyStr arguments) but reject bytes; its expected_types is fixed to (str,).
  ```
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:**
  ```text
  When modifying IsStr or adding string matchers in dirty_equals/_strings.py that must preserve the str-only (bytes-rejecting) matching contract.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_strings.py:125-143`
- `tests/test_strings.py:11-16`
