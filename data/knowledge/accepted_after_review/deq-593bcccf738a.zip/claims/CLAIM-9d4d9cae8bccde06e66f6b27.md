# Rule details

- **Rule:**
  ```text
  `IsPartialDict` must remain equivalent to `IsDict(...).settings(partial=True)`, and combining `partial=True` with `strict=True` must still allow extra keys while requiring listed keys to match and enforcing key order on the compared keys.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when changing `IsPartialDict`, `IsStrictDict`, or the `partial`/`strict` settings semantics
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_dict.py:100-118`
- `dirty_equals/_dict.py:156-176`
- `tests/test_dict.py:39-43`
