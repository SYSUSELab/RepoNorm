# Rule details

- **Rule:** When a datetime matcher is documented as similar to IsDatetime(approx=datetime.now()), it must remain an IsDatetime subclass with that approximate-now semantics; do not change its base or approximate behavior.
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** Modifying the approximate-now datetime matcher.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_datetime.py:119-123`
- `dirty_equals/_datetime.py:166-177`
- `dirty_equals/_datetime.py:187-193`
