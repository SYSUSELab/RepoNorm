# Rule details

- **Rule:**
  ```text
  IsBytes subclasses IsAnyStr[bytes] and sets expected_types to (bytes,), so it inherits string constraints such as regex, length, and case while requiring bytes values; preserve this inheritance and type restriction when modifying bytes-specific string matchers.
  ```
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:**
  ```text
  When modifying IsBytes or related bytes-specific matchers in dirty_equals/_strings.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_strings.py:146-164`
