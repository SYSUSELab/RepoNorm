# Rule details

- **Rule:** The CI workflow runs on pull requests of type opened and synchronize.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  pull_request:
    types: [opened, synchronize]

```

- **Sources:**
  - `.github/workflows/ci.yml:9-10`

## Review evidence locations

- `.github/workflows/ci.yml:9-10`
