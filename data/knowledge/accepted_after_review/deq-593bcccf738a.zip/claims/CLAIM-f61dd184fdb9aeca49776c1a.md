# Rule details

- **Rule:**
  ```text
  dirty_equals/_inspection.py must define ExpectedType as a TypeVar bound to type or nested tuples of types, with T as a separate TypeVar for inspection helpers; changes to inspection typing must preserve this distinction.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:** When modifying inspection helper type variables or the ExpectedType bound.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_inspection.py:1-10`
- `dirty_equals/_inspection.py:60-63`
