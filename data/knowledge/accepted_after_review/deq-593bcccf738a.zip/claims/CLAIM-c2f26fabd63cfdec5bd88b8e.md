# Rule details

- **Rule:**
  ```text
  pytz is declared with version constraint ">=2021.3".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
pytz = ">=2021.3"

```

- **Sources:**
  - `pyproject.toml:36`

## Review evidence locations

- `pyproject.toml:33-36`
