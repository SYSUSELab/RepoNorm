# Rule details

- **Rule:**
  ```text
  `IsFalseLike.equals` must return `not bool(other)` for non-string values, but when `allow_strings` is true and `other` is a `str` it must delegate to `make_string_check`.
  ```
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:**
  ```text
  when modifying `IsFalseLike.equals` or the `allow_strings` behavior
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsFalseLike.equals returns not bool(other) for non-strings and delegates to make_string_check when allow_strings is true and other is a str, matching the rule.
```

- **Sources:**
  - `dirty_equals/_boolean.py:66-69`
