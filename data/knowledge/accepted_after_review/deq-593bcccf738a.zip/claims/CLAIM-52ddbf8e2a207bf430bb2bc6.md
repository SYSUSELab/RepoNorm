# Rule details

- **Rule:**
  ```text
  Coverage measurement is restricted to the dirty_equals package as the source.
  ```
- **Applies to:**
  - `dirty_equals/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
source = ["dirty_equals"]

```

- **Sources:**
  - `pyproject.toml:50`
