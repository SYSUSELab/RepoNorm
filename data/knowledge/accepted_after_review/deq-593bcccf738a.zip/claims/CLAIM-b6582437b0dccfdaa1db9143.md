# Rule details

- **Rule:**
  ```text
  When a regex is prepared for a string matcher, flex mode must strip flags other than re.UNICODE and extract the pattern, encoding string patterns to bytes, while non-flex mode extracts the pattern only when regex_flags is nonzero; do not change this flag-handling behavior.
  ```
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:** Modifying regex preparation for string matchers.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
IsAnyStr._prepare_regex implements the flex/non-flex flag-stripping and pattern-extraction behavior, encoding string patterns to bytes in flex mode.
```

- **Sources:**
  - `dirty_equals/_strings.py:108-122`
