# Rule details

- **Rule:** The check-yaml pre-commit hook is configured with the '--unsafe' argument.
- **Applies to:**
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  - id: check-yaml
    args: ['--unsafe']

```

- **Sources:**
  - `.pre-commit-config.yaml:5-6`

## Review evidence locations

- `.pre-commit-config.yaml:1-6`
