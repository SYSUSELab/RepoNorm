# Rule details

- **Rule:**
  ```text
  HasAttributes.__init__ has an overload accepting expected: Dict[Any, Any], documenting the dict-based initialization form as part of the public typing contract; preserve this dict-based construction contract when modifying inspection matchers.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  When modifying HasAttributes.__init__ or related inspection matcher constructors in dirty_equals/_inspection.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dirty_equals/_inspection.py:159-167`
- `dirty_equals/_inspection.py:191-192`
