# Constraints for `docs/plugins.py`

## Rule

- **Rule:**
  ```text
  The mkdocs-simple-hooks plugin maps the on_files hook to docs.plugins:on_files.
  ```
- **Applies to:**
  - `docs/plugins.py`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3265a2d5d958b3ce395ab3a3.md)

## Rule

- **Rule:**
  ```text
  The docs plugin's on_files hook must return remove_files(files) so that plugins.py, requirements.txt, and __pycache__/ entries are excluded from the MkDocs file list during the build.
  ```
- **Applies to:**
  - `docs/plugins.py`
- **Condition:**
  ```text
  When modifying the on_files hook or the remove_files exclusion list in docs/plugins.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5ed856cb0ec57dd4cc17b241.md)

## Rule

- **Rule:**
  ```text
  The mkdocs-simple-hooks plugin maps the on_pre_build hook to docs.plugins:on_pre_build.
  ```
- **Applies to:**
  - `docs/plugins.py`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-79a294cc94c1ce6a9cd8cb8a.md)

## Rule

- **Rule:**
  ```text
  The docs plugin's on_page_markdown hook must apply reinstate_code_titles before add_version, preserving that transformation order for markdown pages.
  ```
- **Applies to:**
  - `docs/plugins.py`
- **Condition:**
  ```text
  When modifying the on_page_markdown hook or either of the markdown transformations it composes in docs/plugins.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-847e53961466ae41d11b2439.md)

## Rule

- **Rule:**
  ```text
  Documentation example validation must run as part of the MkDocs build: the on_pre_build hook invokes test_examples(), which runs pytest on tests/test_docs.py and logs a warning (rather than failing the build) when the return code is nonzero, skipping entirely when pytest is unavailable.
  ```
- **Applies to:**
  - `docs/plugins.py`
- **Condition:** When modifying the docs build hook pipeline or the example-validation step in docs/plugins.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-96c94548a5f928e30a374af8.md)

## Rule

- **Rule:**
  ```text
  The mkdocs-simple-hooks plugin maps the on_page_markdown hook to docs.plugins:on_page_markdown.
  ```
- **Applies to:**
  - `docs/plugins.py`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc020b16a58b337309373e2a.md)
