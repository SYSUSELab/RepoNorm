# Constraints for `dirty_equals/_datetime.py`

## Rule

- **Rule:** The datetime prepare method must refresh self.approx to the current time on every comparison so relative datetime matchers evaluate against the moment of comparison.
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** when modifying the prepare method of a relative datetime matcher
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-15951644dd5e2fbb0955135a.md)

## Rule

- **Rule:**
  ```text
  IsDate restricts allowed_types to date, so it only matches date values rather than arbitrary numeric or datetime values; preserve this type restriction when modifying date matchers.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  When modifying IsDate or related date matchers in dirty_equals/_datetime.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-26d69322ec9fd0b612d58186.md)

## Rule

- **Rule:**
  ```text
  Datetime prepare must accept datetime values, numeric timestamps only when unix_number is set, and strings only when iso_string or format_string is configured; otherwise it must raise TypeError or ValueError.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** when modifying IsDatetime.prepare or its input-type acceptance rules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-32bdad8133f81372ed777c9f.md)

## Rule

- **Rule:**
  ```text
  IsNow._get_now must return datetime.now() when tz is None, and when tz is set must derive the current time via datetime.utcnow().replace(tzinfo=timezone.utc).astimezone(self.tz).
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  When modifying IsNow._get_now's timezone handling or the tz-aware current-time computation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-36a69591cb47dd0396bbed81.md)

## Rule

- **Rule:**
  ```text
  IsNumeric's default allowed_types must include int, float, Decimal, date, and datetime, and subclasses such as IsDatetime must narrow allowed_types to their specific type.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  when modifying IsNumeric.allowed_types or a subclass that narrows the accepted types
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3f6d5f8b15e082aa57a0487e.md)

## Rule

- **Rule:**
  ```text
  IsDate.prepare accepts a date directly, or a string parsed via date.fromisoformat when iso_string is set or via datetime.strptime(...).date() when format_string is set; other types and unparseable strings raise ValueError. Preserve this preparation contract when modifying date preparation.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  When modifying IsDate.prepare or related date preparation in dirty_equals/_datetime.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6f63769b0e01d88169195fee.md)

## Rule

- **Rule:**
  ```text
  IsNow.__init__ must default delta to 2 seconds, convert int/float deltas to timedelta, accept unix_number, iso_string, format_string, enforce_tz, and tz, and convert string tz via pytz.timezone before storing it.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  when modifying IsNow.__init__ or its parameter handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7dc4c622a8ce6e3729294d0e.md)

## Rule

- **Rule:**
  ```text
  IsToday must subclass IsDate, accept iso_string and format_string options to parse string dates, and initialize approx to date.today().
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  When modifying IsToday or adding date matchers in dirty_equals/_datetime.py that must preserve the IsDate subclassing and string-date parsing options.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-865e92714357fe8e036442fd.md)

## Rule

- **Rule:** When a datetime matcher is documented as similar to IsDatetime(approx=datetime.now()), it must remain an IsDatetime subclass with that approximate-now semantics; do not change its base or approximate behavior.
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** Modifying the approximate-now datetime matcher.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8ea8bdf2d31cbd42b70c7ba5.md)

## Rule

- **Rule:**
  ```text
  _datetime.py must import IsNumeric from ._numeric and reuse it for numeric comparison behavior rather than reimplementing numeric matching.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  When modifying _datetime.py's numeric comparison behavior or refactoring numeric matcher reuse.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a5736fc8c5fd248418b914fd.md)

## Rule

- **Rule:**
  ```text
  IsDate must accept approx/delta/gt/lt/ge/le plus iso_string and format_string, and numeric delta must be interpreted as seconds and converted to timedelta.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:**
  ```text
  Modifying IsDate.__init__ parameter handling or delta conversion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aeeb0e785b8cded510890aeb.md)

## Rule

- **Rule:**
  ```text
  When a datetime matcher compares with enforce_tz enabled, approx_equals must compare only UTC offsets rather than full tzinfo identity, and a naive approx must require the other value to be naive; do not tighten to full tzinfo equality.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
- **Condition:** Modifying timezone handling in datetime approximate comparison.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ca0d0fe49d35dabed6290582.md)
