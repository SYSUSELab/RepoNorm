# Constraints for `dirty_equals/_other.py`

## Rule

- **Rule:**
  ```text
  `IsUUID.equals` must accept UUID instances or UUID-parsable strings, return False for other types, and enforce the configured version when set.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  when modifying `IsUUID.equals` or its version enforcement
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1bc87fadefc12e1f2f66b9f4.md)

## Rule

- **Rule:**
  ```text
  `IsUUID` must accept version values None, 1, 2, 3, 4, or 5; omitting version accepts all UUID versions, and hyphenated and non-hyphenated UUID strings are both accepted.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  when modifying `IsUUID.__init__` or the accepted version values and string formats
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29cccda2d51b384a80eb52e3.md)

## Rule

- **Rule:**
  ```text
  `IsUUID` must be a `DirtyEquals[UUID]` subclass documented to check for a valid UUID and optionally check UUID version.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  when modifying `IsUUID` or its base class relationship and documented contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-426cb7e21f670a2a0f8e3964.md)

## Rule

- **Rule:** IsJson.equals must parse str/bytes via json.loads and return False for non-string/bytes inputs; AnyJson matches any valid JSON value.
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  When modifying IsJson.equals or adding JSON matchers in dirty_equals/_other.py that must preserve the str/bytes parsing and non-string/bytes rejection behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-649520fe6a537e82983dbf98.md)

## Rule

- **Rule:**
  ```text
  `plain_repr` must wrap a string in the repository-specific `PlainRepr` marker to control how values render in dirty-equals reprs, and `FunctionCheck` must use `plain_repr(func.__name__)` so custom checks display as `FunctionCheck(name)`.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
  - `dirty_equals/_utils.py`
- **Condition:**
  ```text
  when modifying `plain_repr`, `PlainRepr`, or repr rendering of matchers such as `FunctionCheck`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-92d3888710b00335abe75883.md)

## Rule

- **Rule:**
  ```text
  FunctionCheck is a DirtyEquals[Any] predicate that delegates equality checking to a user-supplied function; preserve this delegation contract when modifying function-based matchers.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  When modifying FunctionCheck or related function-delegating matchers in dirty_equals/_other.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-93a10e293e56dd6adc9ffe18.md)

## Rule

- **Rule:**
  ```text
  dirty_equals/_other.py declares an overload for __init__ accepting **expected_kwargs, indicating keyword-based construction is part of the public API; preserve this keyword-construction contract when modifying matcher constructors.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  When modifying __init__ overloads or keyword-based construction in dirty_equals/_other.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9da4121e9b3d1523da6df01b.md)

## Rule

- **Rule:** IsJson must remain a DirtyEquals subclass specialized for JSON values, preserving JSON parsing/comparison as a first-class matcher category.
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:** When modifying IsJson or adding new JSON matcher behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b746b735bac299327e60bf5a.md)

## Rule

- **Rule:**
  ```text
  Modules that import Literal from typing must fall back to typing_extensions on ImportError to preserve compatibility with older Python versions.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
  - `dirty_equals/_strings.py`
- **Condition:** when adding or modifying typing imports in dirty-equals modules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bd638db7317df2586d922dbe.md)

## Rule

- **Rule:**
  ```text
  IsJson.__init__ must raise TypeError('IsJson requires either an argument or kwargs, not both') when both expected_value and expected_kwargs are supplied, and must use plain_repr('*') when no expected value is given.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  when modifying IsJson.__init__ or the wildcard vs parameterized JSON matching contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-be0777bc306416fe652486a9.md)

## Rule

- **Rule:**
  ```text
  IsJson must remain usable both as a subscripted generic (IsJson[xyz]) and as a direct initializer (IsJson(xyz)); these two forms are documented as exactly equivalent, so changes to IsJson's typing or __init__ must preserve both call forms.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  When modifying IsJson's generic parameters, __init__ overloads, or its public typing surface.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c21349be39438afb9aa4492e.md)

## Rule

- **Rule:**
  ```text
  When a matcher class exposes a __class_getitem__ shorthand, it must return cls(expected) so that subscript syntax is exactly equivalent to the constructor call; do not change the shorthand to return a different type or defer construction.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  Modifying or adding a __class_getitem__ shorthand on a matcher class.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d305869d340f00e8c64f80cd.md)

## Rule

- **Rule:** A matcher's equals can delegate directly to a stored callable via self.func(other), supporting function-based custom matchers.
- **Applies to:**
  - `dirty_equals/_other.py`
- **Condition:** when modifying FunctionCheck.equals or adding function-based custom matchers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e9520b6558efcfe685212e7b.md)
