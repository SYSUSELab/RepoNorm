# Constraints for `dirty_equals/_numeric.py`

## Rule

- **Rule:**
  ```text
  IsNumeric.prepare must reject booleans (True/False) with TypeError even though bool is a subclass of int, and must reject values outside allowed_types.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** When modifying IsNumeric.prepare or extending numeric type acceptance in the numeric matcher.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-00770ed6c04e6a6a5c95b2c4.md)

## Rule

- **Rule:** IsNegativeFloat subclasses IsFloat, so it accepts only floats and rejects ints and Decimals even when negative; preserve this type restriction when modifying float-specific matchers.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  When modifying IsNegativeFloat or other float-specific matchers in dirty_equals/_numeric.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-03a9812a4bcda8000dd6043e.md)

## Rule

- **Rule:** IsApprox must remain a subclass of IsNumber that only permits approximate comparisons; contributors adding exact-comparison behavior to IsNumber must not assume IsApprox inherits it.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when adding or changing exact-comparison behavior on IsNumber or its subclasses
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0412eb77cbe0607c7f10b096.md)

## Rule

- **Rule:**
  ```text
  IsNonNegative matches values >= 0 across int, float, and Decimal, including zero, while negative values do not match; preserve this inclusive non-negative numeric matching when modifying numeric matchers.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  When modifying IsNonNegative or related numeric bound matchers in dirty_equals/_numeric.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-085b8e67b4ba7c7229745f40.md)

## Rule

- **Rule:**
  ```text
  IsNonPositive initializes via super().__init__(le=0) and clears _repr_kwargs, defining its default upper bound and repr behavior; preserve this initialization contract when modifying non-positive numeric matchers.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  When modifying IsNonPositive.__init__ or related bound initialization in dirty_equals/_numeric.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0aeec7eab90db64a3a670ba5.md)

## Rule

- **Rule:**
  ```text
  Negative numeric predicates (`IsNegative`, `IsNegativeInt`) must initialize their bound via `super().__init__(lt=0)` and clear `_repr_kwargs`, so their repr omits the implicit bound.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when adding or modifying negative numeric predicate classes or their repr behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c6b8ead226dc023356fa181.md)

## Rule

- **Rule:**
  ```text
  IsNumeric.__init__ must raise TypeError when approx is combined with any of gt, lt, ge, or le, and must set has_bounds_checks based on whether any comparison parameter was provided.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  Modifying IsNumeric.__init__ parameter handling or bound-check initialization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1c717c38c74a9563bf2d0d12.md)

## Rule

- **Rule:**
  ```text
  `IsPositive` must be implemented as `gt=0` with empty repr kwargs, so it renders without arguments.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  when modifying `IsPositive` or its repr rendering
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-30d625a78af012507b81bd73.md)

## Rule

- **Rule:**
  ```text
  The positive numeric variant must be defined by a greater-than-zero constraint (super().__init__(gt=0)) with empty _repr_kwargs; changes to this initializer must preserve the gt=0 constraint and the empty repr-kwargs convention.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** When modifying the positive numeric variant's initializer or its repr-kwargs handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-378739cdfd90b4a4c45bd6bb.md)

## Rule

- **Rule:**
  ```text
  `IsNonPositive` must check values `<= 0` and accept `int`, `float`, `Decimal`, or any value implementing `__le__` for 0, including `Decimal('-0')` and `Decimal('0')`.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  when modifying `IsNonPositive` or its comparison semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3e663f6d7c8e6262237902db.md)

## Rule

- **Rule:**
  ```text
  IsNumber must restrict allowed_types to int, float, and Decimal, excluding date and datetime, so numeric comparisons reject date-like values even though IsNumeric accepts them.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  Modifying IsNumber allowed_types or its relationship to IsNumeric.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3e6ba705df711dd2b01c4a1b.md)

## Rule

- **Rule:**
  ```text
  IsNumeric's default allowed_types must include int, float, Decimal, date, and datetime, and subclasses such as IsDatetime must narrow allowed_types to their specific type.
  ```
- **Applies to:**
  - `dirty_equals/_datetime.py`
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  when modifying IsNumeric.allowed_types or a subclass that narrows the accepted types
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3f6d5f8b15e082aa57a0487e.md)

## Rule

- **Rule:**
  ```text
  Numeric comparison matchers must accept the documented numeric/date type set: AnyNumber = Union[int, float, Decimal], with type vars N over int/float/Decimal/date/datetime/AnyNumber and Num over int/float/Decimal; changes to numeric matcher typing must preserve these accepted types.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** When modifying numeric comparison matchers' type variables or accepted numeric/date types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-48914f75882cd025e7be8981.md)

## Rule

- **Rule:** IsPositiveFloat must only match float values greater than zero; ints and Decimal values must not be equal even when positive.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when modifying IsPositiveFloat or its type acceptance rules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4bdffa6f7fa370cf0a17d2ad.md)

## Rule

- **Rule:** Numeric matcher classes must restrict accepted values to the documented numeric type: IsPositiveInt and IsNegativeInt accept only int (rejecting positive/negative floats and Decimals), and IsNonNegative fixes its comparison to ge=0.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  When modifying or extending numeric matcher classes in dirty_equals/_numeric.py (e.g. adding new int-only matchers or changing IsPositiveInt/IsNegativeInt/IsNonNegative comparison bounds).
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8450c347567917e401dd4a26.md)

## Rule

- **Rule:**
  ```text
  IsFloat must subclass IsNumeric[float] and set allowed_types = float, accepting only floats; changes to IsFloat must preserve this float-only restriction.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  When modifying IsFloat's allowed_types, inheritance, or accepted numeric types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-869c20bf6c40c9403a013318.md)

## Rule

- **Rule:**
  ```text
  `IsNumeric.approx_equals` must define approximate equality as an inclusive absolute-difference bound: `abs(self.approx - other) <= delta`, so the boundary value is a match.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  when modifying `IsNumeric.approx_equals` or the `approx`/`delta` numeric comparison semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-922ea0cc98628ba0f4746aa3.md)

## Rule

- **Rule:**
  ```text
  The positive-int predicate must initialize its bound via super().__init__(gt=0) and clear _repr_kwargs, so its repr omits the implicit bound.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  Modifying IsPositive.__init__ bound initialization or repr kwargs handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-96c1a14de9a7ed539b854129.md)

## Rule

- **Rule:**
  ```text
  IsPositive must accept any value implementing __gt__ against 0, not only int/float/Decimal, and must keep 0 != IsPositive and -1 != IsPositive.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when modifying IsPositive or its comparison acceptance rules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9951ee905731b3bf97adb396.md)

## Rule

- **Rule:**
  ```text
  IsNegative must initialize with lt=0 and clear _repr_kwargs so its repr omits the implicit bound while comparison still enforces less-than-zero.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** when modifying IsNegative initialization or its repr kwargs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9ce4729e46cf62f05f5e9d33.md)

## Rule

- **Rule:**
  ```text
  IsNumeric.equals must prepare the value and return bounds_checks(other) only when has_bounds_checks is set, otherwise return True, so an unconstrained numeric predicate accepts any prepared value.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** Modifying IsNumeric.equals comparison dispatch or bounds-check gating.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b2df647aa015d17765ca87c0.md)

## Rule

- **Rule:** When a numeric matcher restricts allowed types, booleans must be explicitly excluded even though they are int subclasses; do not allow bool to match an int matcher.
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:** Modifying allowed-type constraints for numeric matchers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-caae73890afbd218cdde88a1.md)

## Rule

- **Rule:**
  ```text
  `_numeric.py` must keep its `__all__` listing the public numeric types (`IsApprox`, `IsNumeric`, `IsNumber`, `IsPositive`, `IsNegative`, `IsNonPositive`, `IsNonNegative`, `IsInt`, `IsPositiveInt`, `IsNegativeInt`, `IsFloat`, `IsPositiveFloat`, `IsNegativeFloat`) as the module's public API surface.
  ```
- **Applies to:**
  - `dirty_equals/_numeric.py`
- **Condition:**
  ```text
  when adding, removing, or renaming public numeric matcher types in `_numeric.py`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ef4d3b6857a3db500f0f560b.md)
