# Constraints for `dirty_equals/_inspection.py`

## Rule

- **Rule:**
  ```text
  IsInstance equality must use exact type comparison when only_direct_instance is set, otherwise fall back to isinstance checks.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  Modifying IsInstance.equals type-matching logic or only_direct_instance handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0180222f349ad47a29ecbf98.md)

## Rule

- **Rule:**
  ```text
  When a matcher checks class-name matching, the allow_instances flag must control whether instances of a class with the expected name compare equal; setting it False must restrict matching to the class object itself.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:** Modifying class-name matching behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-05655f573da2bc6d0d8c8e44.md)

## Rule

- **Rule:**
  ```text
  `HasAttributes.equals` must compare each expected attribute via `getattr` and return False on AttributeError, deliberately avoiding direct equality against AnyThing or DefaultAttr sentinels.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying `HasAttributes.equals` or the attribute-inspection comparison logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2c670bc6c8c991eefa0463f6.md)

## Rule

- **Rule:**
  ```text
  HasRepr.__class_getitem__ must return cls(expected_repr), enabling subscript syntax HasRepr['...'] as an alternative to calling the constructor.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying HasRepr.__class_getitem__ or the subscript construction path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-575c05011a324c34b564f787.md)

## Rule

- **Rule:**
  ```text
  IsInstance.__class_getitem__ must return cls(expected_type), making IsInstance[ExpectedType] equivalent to IsInstance(ExpectedType).
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  When modifying IsInstance.__class_getitem__ or adding subscriptable matcher classes in dirty_equals/_inspection.py that must preserve the subscript-to-constructor equivalence.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-64ffab4fc121a3babe8e62ba.md)

## Rule

- **Rule:**
  ```text
  `IsInstance` must be a `DirtyEquals` subclass parameterized by `ExpectedType`, so instance checks participate in the same dirty-equals comparison protocol as other matchers.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying `IsInstance` or its base class relationship
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-86b50df4c3887309fd6af16b.md)

## Rule

- **Rule:**
  ```text
  HasName must check the value's __name__ attribute against the expected name as a DirtyEquals[T] predicate.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:** when modifying HasName or adding name-based inspection predicates
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b6ce817bfb36d9b8130bee6.md)

## Rule

- **Rule:**
  ```text
  `IsInstanceOf` must provide an overloaded `__init__` accepting `**expected: Any`, indicating keyword-based expected attribute matching in addition to positional forms.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying `IsInstanceOf.__init__` or its overloaded signatures
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-911f68e5de1b1e1c2270de33.md)

## Rule

- **Rule:**
  ```text
  `HasName.equals` must first check the value's own `__name__`; only when `allow_instances` is true may it fall back to checking the value's `__class__.__name__`, so instance matching is opt-in.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying `HasName.equals` or the `allow_instances` behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9268f6032c6f5d359c4ad32f.md)

## Rule

- **Rule:**
  ```text
  HasAttributes.__init__ has an overload accepting expected: Dict[Any, Any], documenting the dict-based initialization form as part of the public typing contract; preserve this dict-based construction contract when modifying inspection matchers.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  When modifying HasAttributes.__init__ or related inspection matcher constructors in dirty_equals/_inspection.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a58b20d5d257fc9eeccb5303.md)

## Rule

- **Rule:**
  ```text
  HasAttributes.__init__ must accept either positional dicts or keyword arguments via get_dict_arg and pass the resulting expected attributes to the superclass, so attribute expectations follow dict-style construction.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  when modifying HasAttributes.__init__ or the attribute-expectation construction path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b33039425222088d2b666c9a.md)

## Rule

- **Rule:**
  ```text
  When a matcher class exposes a __class_getitem__ shorthand, it must return cls(expected) so that subscript syntax is exactly equivalent to the constructor call; do not change the shorthand to return a different type or defer construction.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
  - `dirty_equals/_other.py`
- **Condition:**
  ```text
  Modifying or adding a __class_getitem__ shorthand on a matcher class.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d305869d340f00e8c64f80cd.md)

## Rule

- **Rule:**
  ```text
  IsInstance must accept expected_type and only_direct_instance, support both IsInstance[Foo] and IsInstance(Foo), and only_direct_instance=True must reject subclass instances.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:**
  ```text
  Modifying IsInstance constructor signature or only_direct_instance behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d696e428136ffd44f916b66c.md)

## Rule

- **Rule:**
  ```text
  HasRepr must remain a DirtyEquals[T] predicate whose matching semantics are that the value's repr() equals the expected repr string; changes to HasRepr must preserve this repr-equality behavior.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:** When modifying HasRepr's matching logic or its DirtyEquals base relationship.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dc6167f6c959867612019858.md)

## Rule

- **Rule:** HasAttributes must remain a partial check: the attributes provided to check do not need to be exhaustive, so contributors must not assume it requires an exact attribute set.
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:** when modifying HasAttributes or its attribute comparison behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-de7e13cda1d1970dd9c4bf7c.md)

## Rule

- **Rule:**
  ```text
  dirty_equals/_inspection.py must define ExpectedType as a TypeVar bound to type or nested tuples of types, with T as a separate TypeVar for inspection helpers; changes to inspection typing must preserve this distinction.
  ```
- **Applies to:**
  - `dirty_equals/_inspection.py`
- **Condition:** When modifying inspection helper type variables or the ExpectedType bound.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f61dd184fdb9aeca49776c1a.md)
