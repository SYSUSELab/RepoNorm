# Constraints for `dirty_equals/_utils.py`

## Rule

- **Rule:**
  ```text
  _utils must export plain_repr, PlainRepr, Omit, and get_dict_arg, with Omit serving as the sentinel object used to omit arguments from repr.
  ```
- **Applies to:**
  - `dirty_equals/_utils.py`
- **Condition:**
  ```text
  when modifying the public exports or sentinel behavior of dirty_equals._utils
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0880bb8b5a8930b3e77275c8.md)

## Rule

- **Rule:** PlainRepr must remain a reusable representation helper that renders a string without quotes; changes to PlainRepr must preserve this quote-free repr behavior.
- **Applies to:**
  - `dirty_equals/_utils.py`
- **Condition:** When modifying PlainRepr's repr behavior or its role as a reusable representation helper.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4b470349569b2a6a1dd3a4df.md)

## Rule

- **Rule:**
  ```text
  get_dict_arg must enforce dict-like initialization: kwargs and positional args cannot both be supplied, at most one positional dict is allowed, and a non-dict positional raises TypeError.
  ```
- **Applies to:**
  - `dirty_equals/_utils.py`
- **Condition:**
  ```text
  Modifying get_dict_arg argument validation or dict-like initialization enforcement.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-867835172502d44b9f4271c0.md)

## Rule

- **Rule:**
  ```text
  `plain_repr` must wrap a string in the repository-specific `PlainRepr` marker to control how values render in dirty-equals reprs, and `FunctionCheck` must use `plain_repr(func.__name__)` so custom checks display as `FunctionCheck(name)`.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
  - `dirty_equals/_utils.py`
- **Condition:**
  ```text
  when modifying `plain_repr`, `PlainRepr`, or repr rendering of matchers such as `FunctionCheck`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-92d3888710b00335abe75883.md)
