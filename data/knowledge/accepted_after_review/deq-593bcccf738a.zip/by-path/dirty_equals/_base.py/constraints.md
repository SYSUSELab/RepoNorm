# Constraints for `dirty_equals/_base.py`

## Rule

- **Rule:**
  ```text
  `__invert__` must return DirtyNot(self), defining the `~` operator as the negation wrapper for dirty-equals instances.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying `__invert__` or the `~` negation operator on dirty-equals instances
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0b9ef366eddc599cb5b4add8.md)

## Rule

- **Rule:**
  ```text
  DirtyEqualsMeta.__repr__ must return self.__name__, so class-level dirty sentinels repr as their bare class name.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEqualsMeta.__repr__ or the class-level sentinel repr
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-15ca403445dc11eb758a2110.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals.__or__ must return a DirtyOr combining self and other, providing the | composition operator for predicates.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  When modifying DirtyEquals.__or__ or adding composition operators in dirty_equals/_base.py that must preserve the DirtyOr combination semantics.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-17b506ce18a5a4068f5605c0.md)

## Rule

- **Rule:**
  ```text
  DirtyNot._repr_ne must return a string prefixed with '~' around the subject repr, defining the negation display convention.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  When modifying DirtyNot._repr_ne or negation display formatting in dirty_equals/_base.py that must preserve the '~' prefix convention.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-17e277d92aa2b317b8f931c5.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals.__init__ must store repr_args/repr_kwargs and initialize _other/_was_equal, establishing the shared repr and comparison-state protocol for subclasses.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  Modifying DirtyEquals.__init__ or the shared repr/comparison-state protocol used by subclasses.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-287333f88250b607da401ae8.md)

## Rule

- **Rule:**
  ```text
  The base module must import Protocol from typing but fall back to Protocol = object on Python 3.7, and define InstanceOrType as Union[DirtyEquals[Any], DirtyEqualsMeta].
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying typing imports or the InstanceOrType alias in the base module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-28cdbc64df0bebc211d0c5f8.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals equals for expected_values must return True if any expected value equals the other value, defining OR-composition semantics.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  Modifying IsOneOf.equals or the OR-composition comparison semantics for expected_values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-47fd7eaefef44e2317d81241.md)

## Rule

- **Rule:**
  ```text
  `DirtyEquals.__hash__` must be based on the class name, so matcher instances are hashable consistently with their type identity.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying `DirtyEqualsMeta.__hash__` or the hash basis for matcher instances
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4f50862cf767cd8469251a78.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals subclasses must implement `equals` as the sole comparison hook; `__eq__` catches TypeError and ValueError raised from `equals` and treats them as inequality, so `equals` may raise these to signal a non-match but must not raise other exception types for ordinary mismatches.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when adding or modifying a DirtyEquals subclass's `equals` implementation or the base `__eq__` dispatch
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-563eea9feeef95eb4f4c5fc4.md)

## Rule

- **Rule:** DirtyEqualsMeta must remain an ABCMeta subclass so dirty matcher classes stay abstract-base compatible and support class-level sentinel behavior; do not replace it with a plain metaclass or type.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying the DirtyEqualsMeta metaclass definition or its base classes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5dfa53c77bb0cebd622b9b7a.md)

## Rule

- **Rule:** The base equals implementation must return True unconditionally, defining the default equality behavior that subclasses override.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying the base equals implementation or AnyThing equality behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6cf3b3713513e18c38b14051.md)

## Rule

- **Rule:**
  ```text
  _repr_ne must dispatch to repr(v) for DirtyEqualsMeta instances and to v._repr_ne() otherwise, preserving class vs instance repr behavior under negation.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying _repr_ne or the negation repr dispatch logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-798394956447c4e31a00b331.md)

## Rule

- **Rule:**
  ```text
  When a matcher class is composed via & or |, the composed result must remain a DirtyEquals subclass so it can be used anywhere a DirtyEquals is accepted; do not change DirtyAnd/DirtyOr to non-DirtyEquals types.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** Modifying or adding composition operators on matcher classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7db8b0c1966a8b2158081f5c.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals.value must raise AttributeError until __eq__ has been called, and only return the last successfully compared value when _was_equal is true.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  When modifying DirtyEquals.value or the __eq__ comparison flow in dirty_equals/_base.py that sets _was_equal and the last compared value.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7f7abe325d4accd87c672547.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals.__or__ must return a DirtyOr combining self and other, so the | operator is part of the public composition protocol for dirty equality objects.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__or__ or the public composition protocol
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-81e44b1e290cad9446886799.md)

## Rule

- **Rule:**
  ```text
  DirtyNot must remain a DirtyEquals[Any] subclass, establishing the negation matcher type in the base module; changes to DirtyNot must preserve this base-class relationship.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** When modifying DirtyNot's base class or its role as the negation matcher.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-83df99c4074a303501281542.md)

## Rule

- **Rule:** AnyThing must match any value and is intended for use inside other comparisons such as IsList and IsStrictDict.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying AnyThing or using it as a wildcard inside composite matchers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8f417f7ca0c4a1894b74f0f2.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals.__invert__ must return DirtyNot(self) so ~dirty produces a negated matcher; do not change the negation result type or drop the inversion behavior.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__invert__ or the negation operator behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8f888d8f686bdac375efdfcd.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals.__eq__ must special-case self is DirtyEquals or other is Generic/Protocol to avoid recursive errors during generic creation, and must swallow TypeError to avoid disrupting pytest error reporting.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__eq__ or the generic-creation comparison path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-95e34caf1d3a7ef63bc2b283.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals.__eq__ must catch TypeError and ValueError raised by the subclass equals() implementation and return False instead of propagating the exception.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  When modifying DirtyEquals.__eq__ or adding a new DirtyEquals subclass whose equals() may raise TypeError or ValueError.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9896a5d47b4b4af7ba46ccaf.md)

## Rule

- **Rule:**
  ```text
  DirtyAnd requires at least two operands (a, b) plus optional extras, so `&` composition cannot produce a single-operand DirtyAnd.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyAnd.__init__ or the `&` composition operator
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9e25db71c81bdb683aa39975.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals.__ne__ must not set _was_equal, must store the compared value in self._other, and must return True when equals raises TypeError or ValueError, preserving pytest-compatible error reporting.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__ne__ or the equality comparison path it delegates to
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a701eb9236b7844f6a6dee2a.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals.__repr__ must return repr(self._other) after a successful equality and self._repr_ne() otherwise, so that failed comparisons show the expected value in diffs.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying DirtyEquals.__repr__ or the repr of a subclass that relies on the base repr
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b11510ddad5cd65e868dcc88.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals matchers compose with `&` via `__and__` returning DirtyAnd(self, other), and DirtyOr.equals returns True when any operand matches; preserve this OR-composition semantics when adding or modifying matcher combination behavior.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** When modifying DirtyEquals operator overloads or DirtyOr/DirtyAnd composition behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b62b1d13659b77f426a20e23.md)

## Rule

- **Rule:**
  ```text
  _repr_ne must omit arguments and kwargs whose value is Omit, so sentinel values are excluded from generated reprs.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying _repr_ne or its argument/kwarg filtering
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bb827b6369158f0fc3d3b1a3.md)

## Rule

- **Rule:** DirtyEquals equals for a dirty tuple must return True only if all dirty values equal the other value, defining AND-composition semantics for tuple matchers.
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** When modifying DirtyAnd.equals or the tuple-composition equality path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bffd302c0c06975da783b62a.md)

## Rule

- **Rule:**
  ```text
  IsOneOf.__init__ must store expected_value plus more_expected_values as a tuple and pass them to super, so IsOneOf supports variadic expected values and can be combined with Contains via |.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  When modifying IsOneOf.__init__ or the variadic expected-value construction path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c1650a9f39c8f129936efe9b.md)

## Rule

- **Rule:**
  ```text
  DirtyEquals subclasses that accept multiple instance-or-type arguments must store them as a tuple in self.dirties, as shown by __init__(self, a, b, *extra).
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:** when modifying a DirtyEquals subclass constructor that accepts multiple instance-or-type arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e6bc03bac8c1d939b58752bc.md)

## Rule

- **Rule:**
  ```text
  `IsOneOf` must remain composable with boolean operators, supporting combination with other DirtyEquals matchers.
  ```
- **Applies to:**
  - `dirty_equals/_base.py`
- **Condition:**
  ```text
  when modifying `IsOneOf` or the boolean-operator composition protocol on DirtyEquals
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-efdade6c3b2d3cdbf96b4d57.md)
