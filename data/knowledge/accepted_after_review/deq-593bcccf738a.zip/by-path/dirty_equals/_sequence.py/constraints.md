# Constraints for `dirty_equals/_sequence.py`

## Rule

- **Rule:**
  ```text
  HasLen.__init__ must store an int min_length as the exact length when max_length is None, otherwise store (min_length, max_length) and pass the length repr to super, with ellipsis meaning no maximum.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying HasLen.__init__ or its length argument handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-05c74579e177eefcc8db9b8a.md)

## Rule

- **Rule:**
  ```text
  _length_correct treats an int length as exact equality, a tuple length as (min, max) with max allowed to be non-int (e.g. ellipsis) meaning no upper bound, and returns True for any other length type; preserve this length validation contract when modifying sequence length checks.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  When modifying _length_correct or related sequence length validation in dirty_equals/_sequence.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c503dd71c7ffd41873048bf.md)

## Rule

- **Rule:**
  ```text
  When a sequence matcher validates length, equals must delegate to _length_correct rather than duplicating length logic; do not inline a separate length check.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying length validation in a sequence matcher's equals.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-43feb1d6d635ea1abade7f69.md)

## Rule

- **Rule:** IsListOrTuple must expose an overload accepting a positions dict plus optional length, defining a supported construction mode distinct from positional items.
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  When modifying IsListOrTuple.__init__ or adding sequence matcher construction modes in dirty_equals/_sequence.py that must preserve the positions-dict overload.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-447f16332d599e13fc5bf2a3.md)

## Rule

- **Rule:**
  ```text
  Contains.__init__ must accept one or more contained values and store them as a tuple, supporting containment checks against lists, tuples, strings, and dict keys.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying Contains.__init__ or the containment-check semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4eab746eb6a27165ae34a3db.md)

## Rule

- **Rule:**
  ```text
  IsListOrTuple must keep allowed_type defaulting to (list, tuple), constraining which container types the predicate accepts; do not broaden the default to arbitrary iterables.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  when modifying IsListOrTuple or its allowed_type default
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7c9bfc68a78dfa412c076e2d.md)

## Rule

- **Rule:**
  ```text
  IsList must subclass IsListOrTuple while setting allowed_type = list, so it shares sequence-matching behavior but rejects tuples; changes to IsList must preserve this list-only restriction.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  When modifying IsList's allowed_type, inheritance, or sequence-matching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8390818b109833b0c5954f90.md)

## Rule

- **Rule:**
  ```text
  _sequence.py must export HasLen, Contains, IsListOrTuple, IsList, and IsTuple, and define LengthType as Union[None, int, Tuple[int, Union[int, Any]]], establishing the accepted length argument shapes.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  Modifying _sequence.py exports or LengthType definition.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-922a266c4348e2cd1da65cce.md)

## Rule

- **Rule:**
  ```text
  dirty_equals/_sequence.py must declare an overload for __init__ accepting *items, check_order, and length, documenting the public sequence constructor parameters.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  Modifying the IsListOrTuple.__init__ overload signature or public sequence constructor parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-94f2166f5d5fc1ff9c9c1e35.md)

## Rule

- **Rule:**
  ```text
  When a container matcher checks containment, it must verify the object contains one or more values as a DirtyEquals[Container[Any]] matcher; do not change it to a non-DirtyEquals or non-container matcher.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying container containment matching.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-97d8262c342617d846ba03f7.md)

## Rule

- **Rule:**
  ```text
  IsTuple shares IsListOrTuple functionality but sets allowed_type = tuple, so it rejects lists while accepting tuples with the same options; preserve this type restriction when modifying tuple-specific sequence matchers.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  When modifying IsTuple or related tuple-specific matchers in dirty_equals/_sequence.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a6f52c16929662fb87c47dd8.md)

## Rule

- **Rule:**
  ```text
  IsListOrTuple.equals must enforce allowed_type and length before comparing, and for order-insensitive comparison must remove each expected item from a copy of the other sequence so duplicates are handled without set hashing.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** When modifying IsListOrTuple.equals or adding new sequence comparison modes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b4c023ecd74571ef6d80d19e.md)

## Rule

- **Rule:**
  ```text
  When a matcher accepts a length constraint, _length_repr must raise TypeError for non-int lengths that are not a 2-tuple and render a non-int upper bound as '...'; do not silently accept other length forms.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying length-constraint validation or repr.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b94d2bdd82939c86efc52737.md)

## Rule

- **Rule:**
  ```text
  HasLen must be a DirtyEquals[Sized] predicate for checking a value's length or that its length falls within a range.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:** Modifying HasLen class definition or its length-checking semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bbbb4782bfa7b7e83b14f115.md)

## Rule

- **Rule:**
  ```text
  Contains.equals returns all(v in other for v in self.contained_values), defining containment as requiring every contained value to be present in other; preserve this all-must-be-present semantics when modifying containment checks.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  When modifying Contains.equals or related containment matching in dirty_equals/_sequence.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-de178f22eca7a2e70ffe41f1.md)

## Rule

- **Rule:**
  ```text
  IsListOrTuple.__init__ must reject providing both items and positions, reject check_order=False with positions, normalize Ellipsis length to (0, ...), and pass Omit for unused repr fields.
  ```
- **Applies to:**
  - `dirty_equals/_sequence.py`
- **Condition:**
  ```text
  Modifying IsListOrTuple.__init__ argument validation or length normalization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fcc395a4910059e723aa4d15.md)
