# Constraints for `dirty_equals/_dict.py`

## Rule

- **Rule:**
  ```text
  When `ignore` is not callable, `_ignore_value` must treat it as a membership container and return `v in self.ignore`, catching `TypeError` for unhashable values and returning False; the supported ignore forms are therefore callable or membership container.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying the `ignore` handling in `IsDict._ignore_value` or the accepted forms of the `ignore` setting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-072412a09f1fb2d552740b75.md)

## Rule

- **Rule:**
  ```text
  IsDict.__init__ must accept keyword arguments as expected dictionary entries, in addition to positional mapping input.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  When modifying IsDict.__init__ or adding new dictionary matcher construction forms.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3124c43db1c5bfd7b47ce7a3.md)

## Rule

- **Rule:**
  ```text
  `IsDict.equals` must apply its comparison layers in order: reject non-dicts, apply `partial` filtering of `other` to expected keys, apply `ignore` filtering via `_filter_dict` on both sides, require exact dict equality, and only then enforce `strict` key-order equality; `strict` must not be evaluated before value equality.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying `IsDict.equals`, `_filter_dict`, or the `partial`/`ignore`/`strict` settings interaction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-39f9a49f99240680dac0e6b1.md)

## Rule

- **Rule:**
  ```text
  IsDict must expose an overloaded __init__ accepting a single expected Dict[Any, Any] argument.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  Modifying IsDict.__init__ signature or overloads.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5c82e65a78f6bba3a17a0434.md)

## Rule

- **Rule:** IsDict must remain usable as a normal dict on its own while serving as the base class for IsPartialDict and IsStrictDict and supporting .settings(...) to change comparison behavior; do not make it abstract or remove the settings hook.
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:** when modifying IsDict or its subclassing/settings extension points
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-610ec298dc8af56fe07c049c.md)

## Rule

- **Rule:** IsIgnoreDict must ignore None values by default, support .settings(ignore=...) with a set or predicate, and combine with strict=True.
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  When modifying IsIgnoreDict or adding dict matchers in dirty_equals/_dict.py that must preserve the default None-ignoring and .settings(ignore=...) behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-618693789338ed9e63d5772e.md)

## Rule

- **Rule:**
  ```text
  IsDict._post_init must remain a no-op hook that subclasses override to adjust dict matcher settings after initialization.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying IsDict._post_init or a subclass that overrides it to adjust dict matcher settings
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-66beabaec014a1aff1abe782.md)

## Rule

- **Rule:**
  ```text
  When a matcher supports partial/subset matching, the enabling flag must be set in _post_init (e.g. partial=True) rather than at comparison time; do not move the flag assignment out of initialization.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:** Modifying initialization of a partial/subset matcher.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8c6b00841730e3b9090f60c0.md)

## Rule

- **Rule:**
  ```text
  `_ignore_value` must use `type(v) in (DirtyEquals, DirtyEqualsMeta)` rather than `isinstance`, because `isinstance` reportedly always returns True on PyPy; contributors changing this check must preserve the exact-type semantics.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying the type check inside `IsDict._ignore_value` or refactoring it to use `isinstance`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8fbcfa37b3821b0c0f0e8a1b.md)

## Rule

- **Rule:**
  ```text
  `IsPartialDict` must remain equivalent to `IsDict(...).settings(partial=True)`, and combining `partial=True` with `strict=True` must still allow extra keys while requiring listed keys to match and enforcing key order on the compared keys.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when changing `IsPartialDict`, `IsStrictDict`, or the `partial`/`strict` settings semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9d4d9cae8bccde06e66f6b27.md)

## Rule

- **Rule:**
  ```text
  IsStrictDict._post_init must set self.strict = True, making strict key-order checking the default for this dict type unless overridden.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying IsStrictDict._post_init or its strict default
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ad775089bd6f5253d11e9cb1.md)

## Rule

- **Rule:**
  ```text
  _repr_ne must emit partial/ignore/strict modifiers only when they differ from the subclass defaults (IsPartialDict, IsIgnoreDict, IsStrictDict), so reprs of subclasses omit redundant default settings.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying IsDict._repr_ne or the repr modifier emission logic for dict subclasses
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b63c5266f2d7e695465cbf5f.md)

## Rule

- **Rule:**
  ```text
  `IsIgnoreDict._post_init` must set `ignore={None}`, so None keys are ignored by default in that dict matcher.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying `IsIgnoreDict._post_init` or the default `ignore` set
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e33cf1bd2ec752e81591d37d.md)

## Rule

- **Rule:** IsDict.settings must return a new IsDict with copied state and must support strict, partial, and ignore; partial and ignore cannot be combined and must raise TypeError.
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:** when modifying IsDict.settings or the strict/partial/ignore configuration surface
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ebde4cba6f58b2dec5b71433.md)

## Rule

- **Rule:**
  ```text
  `IsDict.__init__` must initialize `strict`, `partial`, and `ignore` defaults before calling `_post_init` and the superclass, defining the mutable settings surface used by `.settings(...)`.
  ```
- **Applies to:**
  - `dirty_equals/_dict.py`
- **Condition:**
  ```text
  when modifying `IsDict.__init__` or the initialization order of `strict`, `partial`, and `ignore`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-febb3ce5d86125e0940eaa69.md)
