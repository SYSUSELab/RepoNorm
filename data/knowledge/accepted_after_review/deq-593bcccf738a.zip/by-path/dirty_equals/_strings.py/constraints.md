# Constraints for `dirty_equals/_strings.py`

## Rule

- **Rule:** When a string/bytes matcher compares, equals must enforce type membership, optional fullmatch regex, min/max length, and case constraints, returning False on any failure; do not weaken any of these checks.
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:** Modifying equality logic for string/bytes matchers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-20f9ba4042a15505a87ed2dc.md)

## Rule

- **Rule:** When a string/bytes matcher is constructed, unset options must be passed to super as Omit so they do not appear in repr; do not pass None or default values that would surface in repr.
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:** Modifying construction of a string/bytes matcher.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-389073e647b7aa37b67bd771.md)

## Rule

- **Rule:**
  ```text
  IsBytes subclasses IsAnyStr[bytes] and sets expected_types to (bytes,), so it inherits string constraints such as regex, length, and case while requiring bytes values; preserve this inheritance and type restriction when modifying bytes-specific string matchers.
  ```
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:**
  ```text
  When modifying IsBytes or related bytes-specific matchers in dirty_equals/_strings.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aea868a315df2b62ab8ab83f.md)

## Rule

- **Rule:**
  ```text
  When a regex is prepared for a string matcher, flex mode must strip flags other than re.UNICODE and extract the pattern, encoding string patterns to bytes, while non-flex mode extracts the pattern only when regex_flags is nonzero; do not change this flag-handling behavior.
  ```
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:** Modifying regex preparation for string matchers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b6582437b0dccfdaa1db9143.md)

## Rule

- **Rule:**
  ```text
  `IsAnyStr` must set `expected_types = (str, bytes)` and serve as the base for `IsStr` and `IsBytes`, which restrict comparison to `str` or `bytes` respectively.
  ```
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:**
  ```text
  when modifying `IsAnyStr`, `IsStr`, or `IsBytes` or their `expected_types`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bbbeddbb96827c61d17f5dc9.md)

## Rule

- **Rule:**
  ```text
  Modules that import Literal from typing must fall back to typing_extensions on ImportError to preserve compatibility with older Python versions.
  ```
- **Applies to:**
  - `dirty_equals/_other.py`
  - `dirty_equals/_strings.py`
- **Condition:** when adding or modifying typing imports in dirty-equals modules
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bd638db7317df2586d922dbe.md)

## Rule

- **Rule:**
  ```text
  IsStr must accept str (and IsAnyStr arguments) but reject bytes; its expected_types is fixed to (str,).
  ```
- **Applies to:**
  - `dirty_equals/_strings.py`
- **Condition:**
  ```text
  When modifying IsStr or adding string matchers in dirty_equals/_strings.py that must preserve the str-only (bytes-rejecting) matching contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c4e9826ab7c611aca5918a2f.md)
