# Constraints for `dirty_equals/_boolean.py`

## Rule

- **Rule:**
  ```text
  IsFalseLike must compare by not bool(other) and optionally permit string checks when allow_strings=True, defining falsiness rather than strict False equality.
  ```
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:**
  ```text
  When modifying IsFalseLike or adding boolean matchers in dirty_equals/_boolean.py that must preserve the falsiness-based comparison and allow_strings option.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-358093a1f4431b9b137abf9e.md)

## Rule

- **Rule:** IsTrueLike compares equal to any value whose bool(other) is True, including non-empty strings and non-empty containers, while empty strings, empty dicts, and None are not equal; preserve this truthiness-based matching when modifying boolean-like matchers.
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:**
  ```text
  When modifying IsTrueLike or related truthiness-based matchers in dirty_equals/_boolean.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3d06e0407d20ffcbb86c4797.md)

## Rule

- **Rule:**
  ```text
  `IsFalseLike.equals` must return `not bool(other)` for non-string values, but when `allow_strings` is true and `other` is a `str` it must delegate to `make_string_check`.
  ```
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:**
  ```text
  when modifying `IsFalseLike.equals` or the `allow_strings` behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7c8de7d51467aac8c92d2d84.md)

## Rule

- **Rule:**
  ```text
  IsFalseLike with allow_strings=True must treat '', 'false', and any string where float(other) == 0 as False-like, while 'foobar' and 'True' must not be equal.
  ```
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:**
  ```text
  when modifying IsFalseLike string handling or the allow_strings option
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b488a69631349e2cc3752f1.md)

## Rule

- **Rule:** The false-like string check treats 'false' and '' as True, and otherwise returns whether float(other) == 0, catching ValueError for non-numeric strings; preserve this string-to-falsy matching when modifying IsFalseLike string checks.
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:**
  ```text
  When modifying IsFalseLike.make_string_check or related false-like string matching in dirty_equals/_boolean.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9c47cff1845435081a3d52e0.md)

## Rule

- **Rule:** IsTrueLike.equals must return bool(other), so truthiness rather than identity with True is the comparison rule.
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:** Modifying IsTrueLike.equals comparison logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cd8eab0e635d3798d727bc22.md)

## Rule

- **Rule:**
  ```text
  Boolean matchers must depend on DirtyEquals from _base and Omit from _utils, using Omit as the shared sentinel for suppressing repr kwargs.
  ```
- **Applies to:**
  - `dirty_equals/_boolean.py`
- **Condition:** when modifying boolean matchers or their repr-kwarg suppression behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ec9c9ad5d30440047a323911.md)
