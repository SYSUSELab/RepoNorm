# Constraints for `dirty_equals`

## Rule

- **Rule:**
  ```text
  The mkdocstrings plugin watches the dirty_equals package for documentation changes.
  ```
- **Applies to:**
  - `dirty_equals/**`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2f61f75215f7092874746547.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement is restricted to the dirty_equals package as the source.
  ```
- **Applies to:**
  - `dirty_equals/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-52ddbf8e2a207bf430bb2bc6.md)

## Rule

- **Rule:**
  ```text
  Running `make lint` executes flake8 with `--max-complexity 10 --max-line-length 120 --ignore E203,W503` over the `dirty_equals` and `tests` directories.
  ```
- **Applies to:**
  - `dirty_equals/**`
  - `tests/**`
- **Condition:** command target: lint
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-671ef278c280ea2d04a75296.md)

## Rule

- **Rule:**
  ```text
  Running `make mypy` executes `mypy dirty_equals tests/mypy_checks.py`.
  ```
- **Applies to:**
  - `dirty_equals/**`
  - `tests/mypy_checks.py`
- **Condition:** command target: mypy
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f99ae9d77f3271fc33594a73.md)
