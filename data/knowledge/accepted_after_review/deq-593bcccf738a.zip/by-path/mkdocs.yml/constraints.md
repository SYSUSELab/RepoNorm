# Constraints for `mkdocs.yml`

## Rule

- **Rule:** The MkDocs site is configured with the Material theme.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0b007da69d4b6c7c23fb969f.md)

## Rule

- **Rule:**
  ```text
  The mkdocstrings plugin watches the dirty_equals package for documentation changes.
  ```
- **Applies to:**
  - `dirty_equals/**`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2f61f75215f7092874746547.md)

## Rule

- **Rule:**
  ```text
  The mkdocs-simple-hooks plugin maps the on_files hook to docs.plugins:on_files.
  ```
- **Applies to:**
  - `docs/plugins.py`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3265a2d5d958b3ce395ab3a3.md)

## Rule

- **Rule:**
  ```text
  The mkdocs-simple-hooks plugin maps the on_pre_build hook to docs.plugins:on_pre_build.
  ```
- **Applies to:**
  - `docs/plugins.py`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-79a294cc94c1ce6a9cd8cb8a.md)

## Rule

- **Rule:**
  ```text
  The mkdocs-simple-hooks plugin maps the on_page_markdown hook to docs.plugins:on_page_markdown.
  ```
- **Applies to:**
  - `docs/plugins.py`
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cc020b16a58b337309373e2a.md)
