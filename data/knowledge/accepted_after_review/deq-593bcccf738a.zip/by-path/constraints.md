# Constraints for `.`

## Rule

- **Rule:**
  ```text
  Codecov coverage range is configured as [90, 100].
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-132ace11c0b04f6bac26b111.md)

## Rule

- **Rule:** mypy runs in strict mode for Python source files.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-139f5c61f08df4ea60677c71.md)

## Rule

- **Rule:** Black formatting targets Python 3.9.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c0e378c122c5aad0ac8e766.md)

## Rule

- **Rule:** Codecov coverage precision is configured to 2 decimal places.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-32f3ad08210f427baa826975.md)

## Rule

- **Rule:**
  ```text
  Running `make clean` removes editor backup files matching `*~` and `.*~`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3cb0e99d2675c574e3edbe97.md)

## Rule

- **Rule:**
  ```text
  Running `make clean` removes coverage artifacts `htmlcov`, `.coverage`, and `.coverage.*`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-490ffd0aae64f5cddc75412b.md)

## Rule

- **Rule:** mypy displays error codes in its output.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4b3f5208d56952cba9b94610.md)

## Rule

- **Rule:**
  ```text
  Running `make clean` removes Python bytecode caches by deleting `__pycache__` directories and `*.py[co]` files.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5187f499b90673f7ae74bd54.md)

## Rule

- **Rule:** Coverage report precision is configured as 2.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5fe13f261f65c6d8b4ef3f6c.md)

## Rule

- **Rule:**
  ```text
  isort is configured with line_length = 120.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6103633c21abf4ad0968b4e6.md)

## Rule

- **Rule:** Black formatting is configured with a line length of 120.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-61626d901f9683c265b5fd0d.md)

## Rule

- **Rule:**
  ```text
  Running `make install` installs test, linting, and docs requirements via pip, installs project dependencies via poetry, and installs pre-commit hooks.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: install
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6efa68676f601767d0a18f8d.md)

## Rule

- **Rule:** Poetry is configured with virtualenv creation disabled (virtualenvs.create = false).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-75d51813164a75f6f154d3b0.md)

## Rule

- **Rule:** typing-extensions is declared with version "^4.0.1" and is only required for Python versions below 3.8.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7728e6e2ccc268eec452ce1f.md)

## Rule

- **Rule:** dirty-equals requires Python 3.7 or later.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-8280613412667f774b933f55.md)

## Rule

- **Rule:**
  ```text
  Running `make testcov` depends on the `test` target and then runs `coverage report --show-missing` and `coverage html`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: testcov
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8b809f3a9447bc14c89e0bfe.md)

## Rule

- **Rule:** Codecov project status checks are disabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-950d79871ac23d97e85c878c.md)

## Rule

- **Rule:** The project declares Python "^3.7.0" as its supported Python version constraint.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9ed1f791ae3af03cc88ae83f.md)

## Rule

- **Rule:** mypy does not warn when a function returns a value typed as Any.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b1b0dfb04139589d7b971e4a.md)

## Rule

- **Rule:** Pytest treats warnings as errors via filterwarnings = "error".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b3ecec3a88b6aa60d6fd7a7a.md)

## Rule

- **Rule:** Black formatting skips string normalization.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c035e18121b356a0c0b146c5.md)

## Rule

- **Rule:**
  ```text
  isort is configured with combine_as_imports = true.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c25dd2e471436a13313c85de.md)

## Rule

- **Rule:**
  ```text
  pytz is declared with version constraint ">=2021.3".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c2f26fabd63cfdec5bd88b8e.md)

## Rule

- **Rule:**
  ```text
  Running `make clean` removes the `.cache`, `.pytest_cache`, and `.mypy_cache` directories.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: clean
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cb17ef3b1ca77d38f950d090.md)

## Rule

- **Rule:** Black formatting emits colored output.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ccc0450a4f2d0418f113de2f.md)

## Rule

- **Rule:**
  ```text
  isort is configured with color_output = true.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cd22b708998adf8f649dede0.md)

## Rule

- **Rule:**
  ```text
  isort is configured with multi_line_output = 3.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d5a384d9aeb049cb3bf7da00.md)

## Rule

- **Rule:** A local pre-commit hook with id 'mypy' runs 'make mypy' on Python-typed files using the system language.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d5a3d025170faf41bc3d01bf.md)

## Rule

- **Rule:** The check-yaml pre-commit hook is configured with the '--unsafe' argument.
- **Applies to:**
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-db71197eea8b888b2c4eab63.md)

## Rule

- **Rule:** A local pre-commit hook with id 'lint' runs 'make lint' on Python-typed files using the system language.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e03e1acad1bd7c3006631282.md)

## Rule

- **Rule:** Codecov comment layout is configured as 'header, diff, flags, files, footer'.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e077cda08b987a14c36ae734.md)

## Rule

- **Rule:**
  ```text
  isort is configured with include_trailing_comma = true.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e50dfb2ff33ee6293d57c356.md)

## Rule

- **Rule:**
  ```text
  Running `make test` executes `coverage run -m pytest` followed by `python tests/mypy_checks.py`.
  ```
- **Applies to:**
  - `**`
- **Condition:** command target: test
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e7c55d3a01b0b0462f73b210.md)

## Rule

- **Rule:**
  ```text
  isort is configured with force_grid_wrap = 0.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ea1ba70d0b0a07eac66d62cc.md)

## Rule

- **Rule:**
  ```text
  The poetry-version-plugin is configured with source = "init", so the package version is derived from the package's __init__ module.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ec44c231d06e220dd66ca017.md)

## Rule

- **Rule:**
  ```text
  Running `make lint` executes isort in check-only mode with `--df`.
  ```
- **Applies to:**
  - `**/*.py`
- **Condition:** command target: lint
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eef518ed001eda1c2d365c08.md)

## Rule

- **Rule:**
  ```text
  Coverage excludes lines matching "pragma: no cover", "raise NotImplementedError", "raise NotImplemented", "if TYPE_CHECKING:", and "@overload" from coverage reporting.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f2ac77769ebae6b48111accf.md)

## Rule

- **Rule:** Coverage branch measurement is enabled.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f42b0bdd48adf4b192e62588.md)

## Rule

- **Rule:** Codecov patch status checks are disabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f6d19c5ced032cb5b4081275.md)
