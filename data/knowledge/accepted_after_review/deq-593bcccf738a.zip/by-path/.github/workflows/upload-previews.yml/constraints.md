# Constraints for `.github/workflows/upload-previews.yml`

## Rule

- **Rule:** The workflow installs smokeshow via pip.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-09d0314705847ce1d629a201.md)

## Rule

- **Rule:** The workflow installs click version 8.0.4 via pip.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0b1e70a89f015c520454afa2.md)

## Rule

- **Rule:** The upload-previews job runs only when the triggering workflow run concluded successfully.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Condition:**
  ```text
  workflow predicate: ${{ github.event.workflow_run.conclusion == 'success' }}
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6f310f4ae942eab6fd34434f.md)

## Rule

- **Rule:** The workflow grants write permission to statuses.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ba0b559466ca9ea36558d201.md)

## Rule

- **Rule:** The workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bb42c5ecb945233a4219a5f0.md)

## Rule

- **Rule:** The workflow downloads artifacts from the ci.yml workflow at the triggering run's head SHA using dawidd6/action-download-artifact.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bc0ac0e8e743aff65ef354c0.md)

## Rule

- **Rule:** The Upload Previews workflow triggers on the completion of the CI workflow.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Condition:**
  ```text
  workflow predicate: workflow_run: workflows: [ci] types: [completed]
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c077dbea84aded8a80d4313c.md)

## Rule

- **Rule:**
  ```text
  The workflow runs `smokeshow upload docs` with SMOKESHOW_GITHUB_STATUS_DESCRIPTION set to 'Docs Preview', SMOKESHOW_GITHUB_CONTEXT set to 'docs', SMOKESHOW_GITHUB_TOKEN from secrets.github_token, SMOKESHOW_GITHUB_PR_HEAD_SHA from the triggering run's head SHA, and SMOKESHOW_AUTH_KEY from secrets.smokeshow_auth_key.
  ```
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c4336e423f1f99837c9edc02.md)

## Rule

- **Rule:** The upload-previews job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/upload-previews.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f4668d3f9ffc289c274f2207.md)
