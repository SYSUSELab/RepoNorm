# Constraints for `.github/workflows/ci.yml`

## Rule

- **Rule:** The test job installs test requirements from tests/requirements.txt, installs the project with poetry, runs make test, and generates a coverage XML report.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c1f6dbf8584c4be9edc8b7d.md)

## Rule

- **Rule:** The CI workflow runs on pull requests of type opened and synchronize.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-23bcc7e99f3a372c7d77a8cc.md)

## Rule

- **Rule:** The deploy job publishes the package with poetry publish --build.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-25a0d7e9866b991a7bfe08f9.md)

## Rule

- **Rule:** The CI workflow runs on pushes to the main branch and on pushes of any tag.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-513cd4b20294453c205896b9.md)

## Rule

- **Rule:** The deploy job runs only when the test, lint, and docs jobs succeed and the ref starts with refs/tags/.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Condition:**
  ```text
  workflow predicate: "success() && startswith(github.ref, 'refs/tags/')"
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-518d1370bc90a416cca50ed8.md)

## Rule

- **Rule:** The test job runs across a matrix of ubuntu and macos operating systems and Python versions 3.7, 3.8, 3.9, 3.10, pypy-3.7, pypy-3.8, and pypy-3.9.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-75090e13de93158e2d0b40e0.md)

## Rule

- **Rule:** The deploy job publishes the built docs site to the gh-pages branch.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3d0ac8084f8c7a0b55cfec4.md)

## Rule

- **Rule:** The lint job runs make lint and make mypy.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae7bda9d7d2687d337894ada.md)

## Rule

- **Rule:** The docs job builds the documentation site with mkdocs build --strict.
- **Applies to:**
  - `.github/workflows/ci.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-df5aed3f3dd419e7b8e6e3cc.md)
