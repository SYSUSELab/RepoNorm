# Constraints for `tests/test_boolean.py`

## Rule

- **Rule:**
  ```text
  `test_dirty_not_equals` must be skipped on PyPy because PyPy does not metaclass dunder methods, documenting a platform-specific limitation for dirty-equals comparison operators.
  ```
- **Applies to:**
  - `tests/test_boolean.py`
- **Condition:** when modifying dirty-equals comparison operator tests for platform compatibility
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2de3675f785ba23f52a3602a.md)

## Rule

- **Rule:**
  ```text
  Tests that pin the truthiness semantics of IsTrueLike and IsFalseLike must parametrize across bools, containers, None, and numeric zero/one, and must assert both the positive matcher and its negation (~IsTrueLike) where applicable.
  ```
- **Applies to:**
  - `tests/test_boolean.py`
- **Condition:** when adding or modifying tests for IsTrueLike or IsFalseLike truthiness behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f93e96bc743b5e6913e23b5c.md)

## Rule

- **Rule:**
  ```text
  Tests for `IsFalseLike` must assert that `0 != IsFalseLike()` raises `AssertionError`, documenting that 0 is treated as false-like and the `!=` operator is inverted.
  ```
- **Applies to:**
  - `tests/test_boolean.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `IsFalseLike` semantics for falsy values
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f9da18d19ccaba3ac0a63a81.md)
