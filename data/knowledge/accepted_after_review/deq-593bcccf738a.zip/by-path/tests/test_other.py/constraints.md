# Constraints for `tests/test_other.py`

## Rule

- **Rule:**
  ```text
  `IsJson` must reject invalid JSON strings, integers, and lists, and must raise TypeError when both a positional argument and keyword arguments are supplied.
  ```
- **Applies to:**
  - `tests/test_other.py`
- **Condition:** when modifying IsJson validation or argument handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0f39ce28845195b116aa111a.md)

## Rule

- **Rule:**
  ```text
  IsJson must compare equal to both IsJson(expected_value) and the subscript form IsJson[expected_value] for null, string, list, and object JSON values.
  ```
- **Applies to:**
  - `tests/test_other.py`
- **Condition:** when adding or modifying tests for IsJson equality across constructor and subscript forms
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-248d4ba17d8f4aed345ee6ec.md)

## Rule

- **Rule:**
  ```text
  Tests for `IsJson` must assert that a JSON array matcher does not equal a JSON object string and that its `str` is the matcher's repr.
  ```
- **Applies to:**
  - `tests/test_other.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `IsJson` inequality and repr behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-25a47df13a63df29145e0f32.md)

## Rule

- **Rule:**
  ```text
  `IsUUID(version)` must reject values whose UUID version differs from the specified version.
  ```
- **Applies to:**
  - `tests/test_other.py`
- **Condition:** when modifying IsUUID version matching behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-495f8fa1b5834b6247cc6760.md)

## Rule

- **Rule:** Tests that pin the exact repr string of a matcher must keep that repr stable; changing a matcher's repr format requires updating the corresponding repr assertion in the same change.
- **Applies to:**
  - `tests/test_datetime.py`
  - `tests/test_other.py`
- **Condition:** When modifying the repr format of a matcher such as IsDatetime or IsUUID, the exact-repr assertions in the matcher's test module must be updated together.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-589fb235f1671992e1894338.md)

## Rule

- **Rule:** Tests for dirty-equals matchers must verify that the matcher's repr/str form is preserved after a failed equality comparison, not only on successful matches.
- **Applies to:**
  - `tests/test_other.py`
- **Condition:** When adding or modifying tests for a dirty-equals matcher's repr after a failed comparison.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-78339b7911490c4c124eae22.md)

## Rule

- **Rule:** IsJson accepts keyword arguments as expected JSON fields, so IsJson(a=1, b=2) matches {"a": 1, "b": 2} and rejects a differing value.
- **Applies to:**
  - `tests/test_other.py`
- **Condition:** When changing IsJson's constructor or matching logic for keyword-argument fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9587bbba2f7464aaac286600.md)

## Rule

- **Rule:** Tests for dirty-equals matchers must exercise the matcher's documented input-form variants (e.g. UUID object vs string, timezone-aware vs naive datetimes, JSON any-value) rather than a single representative input.
- **Applies to:**
  - `tests/test_datetime.py`
  - `tests/test_other.py`
- **Condition:** When adding or modifying tests for a dirty-equals matcher that accepts multiple input forms or modes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c706c8b501cc753601bee2c2.md)

## Rule

- **Rule:** FunctionCheck(foo) invokes the predicate with the compared value: it passes for 4, records the argument as 4, and fails for 5.
- **Applies to:**
  - `tests/test_other.py`
- **Condition:** When changing FunctionCheck's predicate invocation or argument recording.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc1efd0142abb9d119164278.md)
