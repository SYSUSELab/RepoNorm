# Constraints for `tests/test_list_tuple.py`

## Rule

- **Rule:**
  ```text
  Sequence matchers IsList, IsTuple, IsListOrTuple, HasLen, and Contains must be tested across length ranges, check_order=False, positions, and AnyThing placeholders.
  ```
- **Applies to:**
  - `tests/test_list_tuple.py`
- **Condition:** When changing sequence matcher options or adding new sequence matcher parameters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-033bf0b0028129a60c8e5344.md)

## Rule

- **Rule:**
  ```text
  IsList must reject check_order=False combined with positions by raising TypeError with the message 'check_order=False is not compatible with positions'.
  ```
- **Applies to:**
  - `tests/test_list_tuple.py`
- **Condition:**
  ```text
  when adding or modifying tests for IsList argument validation involving check_order and positions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1fd2c5d9fa3304129030ef44.md)

## Rule

- **Rule:**
  ```text
  Tests for list/tuple matchers must cover the documented mismatch boundaries: length ranges, check_order=False, positions, and Contains, asserting inequality for each mismatch case.
  ```
- **Applies to:**
  - `tests/test_list_tuple.py`
- **Condition:** when adding or modifying list/tuple matcher mismatch tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2c94a5f39531ec147a96a37f.md)

## Rule

- **Rule:**
  ```text
  Tests for `IsTuple` length repr must assert that open-ended length bounds normalize a tuple length like `(6, 'x')` to `(6, ...)` while concrete bounds like `(6, 10)` are preserved.
  ```
- **Applies to:**
  - `tests/test_list_tuple.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `IsTuple` length repr canonicalization
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f2a8d3faa4773ee8e1b38bb5.md)
