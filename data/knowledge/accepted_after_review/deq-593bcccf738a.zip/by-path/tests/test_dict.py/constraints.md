# Constraints for `tests/test_dict.py`

## Rule

- **Rule:** IsDict(...).settings(ignore=...) must accept a custom ignore callable that suppresses unmatched keys, while still rejecting non-matching values.
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:** when adding or modifying tests for IsDict custom ignore callables
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0d1a950cd240c4cb303d587e.md)

## Rule

- **Rule:**
  ```text
  Tests for dict matcher reprs must parametrize `IsDict`, `IsPartialDict`, `IsIgnoreDict`, and `IsStrictDict` repr output, including settings such as partial, ignore, and strict reflected in bracket notation.
  ```
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:** when adding or modifying tests that pin repr output for dict matchers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-27929f8df7081718dfaf1750.md)

## Rule

- **Rule:** IsIgnoreDict ignore predicates must accept unhashable values; ignore matching must not require the value to be hashable.
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:** When changing IsIgnoreDict ignore matching, ensure unhashable values such as dicts can still be ignored.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-45e46e4723a548df0b9dd5c6.md)

## Rule

- **Rule:** IsDict, IsPartialDict, IsIgnoreDict, and IsStrictDict have distinct matching semantics, including strict ordering and partial/ignore combinations, and must not be conflated.
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:** When changing or adding dict matcher classes or their matching semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4cc704c758ad4f4f4cdb996c.md)

## Rule

- **Rule:**
  ```text
  Tests for nested dirty-equals matchers inside `IsIgnoreDict` must assert that the nested matcher's `.value` property returns the matched value after a successful comparison.
  ```
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:**
  ```text
  when adding or modifying tests that cover stateful nested matchers inside `IsIgnoreDict`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-83ec8274618e8c8f39dc6f77.md)

## Rule

- **Rule:**
  ```text
  Tests for `IsDict` arity errors must assert that passing more than one argument raises `TypeError` with the exact message `'IsDict expected at most 1 argument, got 2'`.
  ```
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin the arity error contract for `IsDict`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a6634aede7d251de91044b9b.md)

## Rule

- **Rule:** IsDict raises TypeError with message 'IsDict requires either a single argument or kwargs, not both' when both a positional argument and kwargs are supplied.
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:** When changing IsDict's constructor argument validation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ba4a06304064e5e14cb0351d.md)

## Rule

- **Rule:** IsIgnoreDict ignore customization accepts a callable predicate over values, and the predicate convention is a function returning a bool for a given value.
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:** When adding or modifying IsIgnoreDict ignore predicates, use a callable that returns a bool for the value being tested.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dd6977d371691e14bd425bf9.md)

## Rule

- **Rule:**
  ```text
  IsDict must raise TypeError with message "expected_values must be a dict, got <class 'int'>" when given a non-dict positional argument.
  ```
- **Applies to:**
  - `tests/test_dict.py`
- **Condition:** when adding or modifying tests for IsDict non-dict positional argument validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e059e980e410882ecc15d0d6.md)
