# Constraints for `tests/test_inspection.py`

## Rule

- **Rule:** Inspection tests must import the public matcher surface (AnyThing, HasAttributes, HasName, HasRepr, IsInstance, IsInt, IsStr), documenting the expected public API names.
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:** when modifying inspection test imports or public API surface
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0de4ea667e2ffcae83ff88cd.md)

## Rule

- **Rule:**
  ```text
  HasName must match classes, instances, functions, and attributes by __name__, support allow_instances=False to reject instances, and accept nested predicates such as IsStr(regex=...) for the name.
  ```
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:** when adding or modifying tests for HasName matching targets and options
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-15728901b989489cde5899c2.md)

## Rule

- **Rule:**
  ```text
  IsInstance must match subclasses by inheritance, reject subclasses when only_direct_instance=True, and not treat the class itself as an instance.
  ```
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:** when adding or modifying tests for IsInstance inheritance and direct-instance semantics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-57041e7528c92eef2e871c70.md)

## Rule

- **Rule:** Tests for dirty-equals matchers must verify that the matcher's repr/str form includes the matcher name and, when instantiated with arguments, the argument repr.
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:** When adding or modifying tests for a dirty-equals matcher's repr/str form with arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-983043e7c7a9ec28e9935462.md)

## Rule

- **Rule:**
  ```text
  Tests for `HasAttributes` must assert that attribute values are matched (including nested predicates like `IsInt()`/`IsStr()`), that negation is supported, and that extra expected attributes not present on the value cause a mismatch.
  ```
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `HasAttributes` matching, negation, and extra-attribute mismatch behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c125cc8f676b2477fb18f2a7.md)

## Rule

- **Rule:**
  ```text
  HasRepr must support subscript syntax HasRepr['...'], negation with ~HasRepr, regex matching, and class/object reprs, asserting equality for each case.
  ```
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:** when adding or modifying tests for HasRepr matching forms
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e171139e817bbc8a669754d9.md)

## Rule

- **Rule:**
  ```text
  Tests for `IsInstance` must assert that `IsInstance(Foo)` and `IsInstance[Foo]` are equivalent forms and that non-matching values compare unequal.
  ```
- **Applies to:**
  - `tests/test_inspection.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin `IsInstance` call and subscript equivalence
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fe0b4bd691dd4e0b1b943826.md)
