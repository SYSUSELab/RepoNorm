# Constraints for `tests/test_base.py`

## Rule

- **Rule:**
  ```text
  Tests for dirty-equals matchers must verify that the ~ operator is the logical negation of the matcher, i.e. a value not equal to the matcher is equal to ~matcher.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** When adding or modifying tests for a dirty-equals matcher's negation operator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3ae90c8d3050965093ed36b2.md)

## Rule

- **Rule:** Tests for dirty-equals matchers must verify that the matcher's value attribute is only available after a comparison has been performed, and that accessing it beforehand raises AttributeError.
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** When adding or modifying tests for a dirty-equals matcher's value attribute lifecycle.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-57ff677ff6760f9a59c4cbe8.md)

## Rule

- **Rule:**
  ```text
  Combining dirty-equals predicates with & must produce a conjunction that passes only when both operands hold, and its repr must join the two operand names with ' & '.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  when adding or modifying tests for & composition of dirty-equals predicates
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5ea0f21bb0e48863b734cbd1.md)

## Rule

- **Rule:** repr of dirty-equals matchers must remain stable across failed comparison attempts (e.g., repr(IsInt) stays 'IsInt' after a failed inequality comparison).
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** when adding or modifying tests for matcher repr stability across comparisons
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-87101367cf7075de85432186.md)

## Rule

- **Rule:**
  ```text
  Dict values in matcher comparisons may be matcher classes or instances and may be combined with &, |, and ~ operators inside a dict comparison.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** When changing dict comparison logic or operator composition support for matchers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9319a5c590ac5df3e89156ca.md)

## Rule

- **Rule:**
  ```text
  repr of dirty-equals matchers must preserve class vs instance distinction and operator composition forms, including ~, &, |, and parameterized instances like IsInt(lt=5).
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** when adding or modifying tests for matcher repr of class/instance and operator composition forms
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9a1e838856dd024611daeb5f.md)

## Rule

- **Rule:**
  ```text
  Tests for boolean composition of dirty matchers must assert that `|` provides OR semantics, that `~` negates the combined expression, and that the combined matcher's `str` reflects the composition.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  when adding or modifying tests that pin boolean composition semantics for dirty matchers, assert the specific operator semantics exercised (OR for `|`, negation for `~`) and the composed matcher's `str` representation only where the test actually covers that operator
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9d4d433d1bb242acb102e0eb.md)

## Rule

- **Rule:** Tests that verify class-level sentinel matchers such as IsApprox must assert that the sentinel class itself is usable directly in comparisons without instantiation.
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** when adding or modifying tests for class-level sentinel matchers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fe6041c7887e3d137b957772.md)
