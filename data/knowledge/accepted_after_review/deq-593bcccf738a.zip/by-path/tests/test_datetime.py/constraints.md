# Constraints for `tests/test_datetime.py`

## Rule

- **Rule:**
  ```text
  Matcher equality semantics are representation-sensitive: IsToday matches date objects directly, iso_string=True matches ISO date strings, and format_string='%Y/%m/%d' matches formatted date strings; mismatched representations must not match.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:** When changing IsToday's matching logic or adding new date-representation modes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1cf4f1b1de4eb1ab0b183010.md)

## Rule

- **Rule:**
  ```text
  Tests for `IsNow` with `iso_string=True` must assert that the matcher equals the current datetime's ISO-formatted string.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:**
  ```text
  when adding or modifying tests that cover `IsNow` ISO-string matching
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2963cb23ab4e5cc70ef8ab74.md)

## Rule

- **Rule:**
  ```text
  IsNow supports tz, unix_number, and iso_string modes: a tz-aware now matches IsNow(tz=...), a naive now matches bare IsNow, and unix_number/iso_string modes compare against the timestamp/isoformat representations rather than the datetime itself.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:**
  ```text
  When changing IsNow matching, preserve the tz-aware vs naive distinction and the unix_number/iso_string representation-based comparisons.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-38d1f0c1b2789c7d47afb5ed.md)

## Rule

- **Rule:** Tests that pin the exact repr string of a matcher must keep that repr stable; changing a matcher's repr format requires updating the corresponding repr assertion in the same change.
- **Applies to:**
  - `tests/test_datetime.py`
  - `tests/test_other.py`
- **Condition:** When modifying the repr format of a matcher such as IsDatetime or IsUUID, the exact-repr assertions in the matcher's test module must be updated together.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-589fb235f1671992e1894338.md)

## Rule

- **Rule:**
  ```text
  IsDate must support approx, iso_string, format_string, ge, gt, and delta matching, and must reject wrong types and datetime-vs-date mismatches.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:** when adding or modifying tests for IsDate matching options and type mismatches
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6be59f414e5df35b6332f566.md)

## Rule

- **Rule:**
  ```text
  `IsNow` must normalize timedelta, int, and float delta arguments into timedelta seconds, including fractional seconds converted to microseconds.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:** when modifying IsNow delta argument handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6d18b2b57a22bdcbd84d022e.md)

## Rule

- **Rule:**
  ```text
  Datetime tests must import `IsDate`, `IsDatetime`, `IsNow`, and `IsToday` from dirty_equals and may use pytz and unittest.mock.Mock for timezone and mock-based behavior.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:** when adding or modifying datetime tests that need timezone or mock-based coverage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-715a672bfa1169d910008203.md)

## Rule

- **Rule:** Tests for dirty-equals matchers must exercise the matcher's documented input-form variants (e.g. UUID object vs string, timezone-aware vs naive datetimes, JSON any-value) rather than a single representative input.
- **Applies to:**
  - `tests/test_datetime.py`
  - `tests/test_other.py`
- **Condition:** When adding or modifying tests for a dirty-equals matcher that accepts multiple input forms or modes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c706c8b501cc753601bee2c2.md)

## Rule

- **Rule:**
  ```text
  `IsNow` must compare equal to a freshly created datetime and its repr must equal the repr of that datetime.
  ```
- **Applies to:**
  - `tests/test_datetime.py`
- **Condition:** when modifying IsNow equality or repr behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e0f8ac0127e2e918809fae42.md)
