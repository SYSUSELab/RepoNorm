# Constraints for `tests/test_strings.py`

## Rule

- **Rule:**
  ```text
  Tests for dirty-equals matchers must verify that the matcher's repr/str form preserves keyword arguments such as regex, e.g. IsStr(regex='wh.*er').
  ```
- **Applies to:**
  - `tests/test_strings.py`
- **Condition:** When adding or modifying tests for a dirty-equals matcher's repr/str form with keyword arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1c9947a21b62531abfb40b47.md)

## Rule

- **Rule:** IsAnyStr matches both str and bytes values, and its regex argument accepts either a str or bytes pattern regardless of the compared value type.
- **Applies to:**
  - `tests/test_strings.py`
- **Condition:** When changing IsAnyStr's type acceptance or regex argument handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-950e92ab57dc4be34c082aca.md)

## Rule

- **Rule:**
  ```text
  IsBytes(regex=...) must match bytes patterns, including wildcard bytes regexes such as b'wh.*er'.
  ```
- **Applies to:**
  - `tests/test_strings.py`
- **Condition:** when adding or modifying tests for IsBytes regex matching
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc507b80d722c1a238b861b8.md)
