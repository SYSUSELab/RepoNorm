# Constraints for `tests`

## Rule

- **Rule:**
  ```text
  Tests that exercise the public dirty_equals matcher API must import the matchers by name from dirty_equals and assert their comparison behavior directly, rather than reimplementing matcher logic in the test module.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:**
  ```text
  when adding or modifying a test module that exercises dirty_equals matchers
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-587c2b12a55017052f83931e.md)

## Rule

- **Rule:**
  ```text
  Running `make lint` executes flake8 with `--max-complexity 10 --max-line-length 120 --ignore E203,W503` over the `dirty_equals` and `tests` directories.
  ```
- **Applies to:**
  - `dirty_equals/**`
  - `tests/**`
- **Condition:** command target: lint
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-671ef278c280ea2d04a75296.md)

## Rule

- **Rule:** Pytest test discovery is restricted to the "tests" directory via testpaths.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9417ac0939a0b7613196899c.md)

## Rule

- **Rule:**
  ```text
  Matcher classes must raise AssertionError when compared with `==` against a non-matching value, and their `repr`/`str` must remain stable after a failed comparison.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying matcher equality/repr assertions in the test suite
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c47f45683d4e522b4ff6f5f4.md)

## Rule

- **Rule:**
  ```text
  Tests for dirty-equals matchers must exercise the public dirty_equals API surface (importing matcher classes from the dirty_equals package) rather than private/internal modules.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying tests that exercise dirty-equals matcher classes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f41b81257ed865054412de8d.md)
