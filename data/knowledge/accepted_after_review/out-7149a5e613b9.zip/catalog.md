# Claim catalog

- [Rules 1–72](catalog/0001.md); scope preview: `tests/test_prompts.py`
- [Rules 73–145](catalog/0002.md); scope preview: `tests/fsm/test_parsing.py`
- [Rules 146–217](catalog/0003.md); scope preview: `**/*.py`
- [Rules 218–287](catalog/0004.md); scope preview: `outlines/fsm/parsing.py`
- [Rules 288–358](catalog/0005.md); scope preview: `outlines/fsm/parsing.py`
- [Rules 359–430](catalog/0006.md); scope preview: `outlines/fsm/parsing.py`
- [Rules 431–450](catalog/0007.md); scope preview: `tests/test_grammars.py`
