# Rule details

- **Rule:** Integration tests for typed generation must preserve the typed output contract: integer generation returns an actual int (not a string) and int(sequence) succeeds, and JSON function-enum generation returns a dict of length 2 with keys within the allowed set and int-or-float values.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
  - `tests/generate/test_integration_vllm.py`
- **Condition:** When modifying or extending typed-generation integration tests, preserve assertions that integer output is an actual int and JSON function-enum output has the documented dict shape.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_transformers.py:181-194`
