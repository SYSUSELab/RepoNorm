# Rule details

- **Rule:**
  ```text
  The token_generator must reshape outputs by batch_size and num_samples: yield a scalar string when both are 1, a list when batch_size is 1, a list of first samples when num_samples is 1, and a nested list otherwise; it must also track is_stop_at_reached per sequence and strip stop sequences before formatting.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:**
  ```text
  when modifying SequenceGenerator.stream.token_generator or its output shaping and stop-sequence handling
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
token_generator yields scalar/list/nested-list shapes per batch_size and num_samples, tracks is_stop_at_reached per sequence, and strips stop sequences before formatting.
```

- **Sources:**
  - `outlines/generate/api.py:325-388`
