# Rule details

- **Rule:**
  ```text
  Generator tests must use a MockFSM test double to drive sequence_generator tests without a real FSM, and its get_next_state helper advances state by one for any next token ids.
  ```
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:** When modifying or adding generator tests that need an FSM test double.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_generator.py:133-148`
