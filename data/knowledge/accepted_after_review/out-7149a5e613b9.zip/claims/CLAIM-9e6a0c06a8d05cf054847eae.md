# Rule details

- **Rule:**
  ```text
  Coverage measurement omits outlines/_version.py and tests/* from coverage reporting.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
omit = [
    "outlines/_version.py",
    "tests/*",
]

```

- **Sources:**
  - `pyproject.toml:154-157`
