# Rule details

- **Rule:**
  ```text
  Tests for bias_logits must assert that it sets logits at indices not listed in indices_to_mask to -math.inf while preserving listed indices, across single- and multi-row tensors.
  ```
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:**
  ```text
  when adding or modifying tests for bias_logits masking behavior
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The file contains test_bias_logits with parametrized assertions that bias_logits sets unlisted indices to -math.inf while preserving listed indices across single- and multi-row tensors.
```

- **Sources:**
  - `tests/generate/test_generator.py`
