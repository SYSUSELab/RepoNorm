# Rule details

- **Rule:** Benchmark modules must import optional array frameworks (mlx, jax) inside try/except ImportError blocks so benchmark collection tolerates missing optional dependencies.
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying benchmark imports of optional array frameworks such as mlx or jax.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `benchmarks/bench_processors.py:7-16`
