# Rule details

- **Rule:**
  ```text
  When modifying the close-paren acceptance rule, preserve the rejection of CLOSE_PAREN token types when paren_level - 1 < 0 to prevent unbalanced closing parentheses.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  Modifying accepts_token_type in outlines/fsm/parsing.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/fsm/parsing.py:881-890`
