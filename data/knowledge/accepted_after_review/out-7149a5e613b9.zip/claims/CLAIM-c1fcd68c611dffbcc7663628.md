# Rule details

- **Rule:**
  ```text
  CFG-guide benchmarks must exercise both guide sampling paths: rejection sampling via iter_valid_token_ids over shuffled vocabulary token ids and direct sampling via get_next_instruction(state).tokens with random.choice, each followed by get_next_state.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:** When adding or modifying CFG-guide benchmark execution that simulates guide stepping.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `benchmarks/bench_cfg_guide.py:35-48`
- `benchmarks/bench_cfg_guide.py:54-60`
