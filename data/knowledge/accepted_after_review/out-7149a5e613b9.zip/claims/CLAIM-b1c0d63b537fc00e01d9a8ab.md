# Rule details

- **Rule:** When modifying OpenAI model configuration updates, preserve the immutable update pattern: use copy.copy plus dataclasses.replace to produce a new instance with replaced config fields, leaving the original instance unmutated.
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:** When changing OpenAI model configuration update logic.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/openai.py:15-16`
- `outlines/models/openai.py:158-161`
