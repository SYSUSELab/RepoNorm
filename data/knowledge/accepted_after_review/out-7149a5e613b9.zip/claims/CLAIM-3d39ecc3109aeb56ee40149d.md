# Rule details

- **Rule:**
  ```text
  The test_python_types parametrization must map int, float, bool, datetime.date, datetime.time, and datetime.datetime to INTEGER, FLOAT, BOOLEAN, DATE, TIME, and DATETIME respectively, asserting python_types_to_regex returns the matching regex.
  ```
- **Applies to:**
  - `tests/fsm/test_types.py`
- **Condition:**
  ```text
  when adding or modifying python_types_to_regex type-mapping tests
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_python_types parametrizes int, float, bool, datetime.date, datetime.time, and datetime.datetime against INTEGER, FLOAT, BOOLEAN, DATE, TIME, and DATETIME and asserts python_types_to_regex returns the matching regex.
```

- **Sources:**
  - `tests/fsm/test_types.py:27-29`
