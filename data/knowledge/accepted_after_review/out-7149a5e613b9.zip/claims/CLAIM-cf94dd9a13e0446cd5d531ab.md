# Rule details

- **Rule:**
  ```text
  Prompt templates in the examples may reference attributes of passed objects (e.g. {{task.task_name}}) and iterate over collections of example objects, not only interpolate simple scalar variables.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When writing or editing a prompt template in an example, use Jinja attribute access and iteration over passed objects where the prompt needs structured data, rather than flattening all inputs to scalars.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/self_consistency.py:46-55`
- `examples/dating_profile.py:44-58`
