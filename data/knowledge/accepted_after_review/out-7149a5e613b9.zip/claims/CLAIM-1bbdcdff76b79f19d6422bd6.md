# Rule details

- **Rule:**
  ```text
  The async broadcast path must build one task per index in np.ndindex(*broadcast_shape), slice positional and keyword arguments by that index, await asyncio.gather over all tasks, and return the outputs.
  ```
- **Applies to:**
  - `outlines/base.py`
- **Condition:** Modifying the async broadcast/vectorize gather path.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/base.py:253-262`
