# Rule details

- **Rule:**
  ```text
  test_exl2_max_chunk_size constructs an exl2 model with cache_q4=True, paged=False, and max_chunk_size=128, then asserts the result is an ExLlamaV2Model, documenting supported construction parameters.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When modifying exl2 model construction parameters exercised by test_exl2_max_chunk_size.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_exllamav2.py:294-302`
