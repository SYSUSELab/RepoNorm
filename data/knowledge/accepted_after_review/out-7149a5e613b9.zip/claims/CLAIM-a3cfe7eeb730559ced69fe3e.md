# Rule details

- **Rule:**
  ```text
  When modifying GuideLogitsProcessor, preserve the state fields tokenizer, guide, _guide_states (Dict[int, Any]), and _seq_start_idx (Optional[int]) so per-sequence guide-state tracking for structured generation remains intact.
  ```
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:** When changing GuideLogitsProcessor state fields or per-sequence guide tracking.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/processors/structured.py:42-71`
