# Rule details

- **Rule:** JSON generation tests must preserve the documented output shape: batch plus multiple samples yields a nested list of parsed model instances, and union/anyOf handling remains a known limitation tracked by xfail.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** When modifying JSON generation tests that cover batch sampling or union/anyOf schemas
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_transformers.py:303-321`
