# Rule details

- **Rule:** When modifying RegexLogitsProcessor in outlines/processors/structured.py, preserve the contract that its guide attribute is an outlines.fsm.RegexGuide.
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:** Modifying RegexLogitsProcessor or its guide attribute typing.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/processors/structured.py:129-151`
