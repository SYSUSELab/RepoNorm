# Rule details

- **Rule:**
  ```text
  Backreferences in grammar regular expressions, such as `([ab]^*)\1`, cannot be simulated by a finite state machine and result in an error if used.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
#### Avoid Backreferences

Backreferences, for example `([ab]^*)\1`, cannot be simulated by a finite state machine, and will result in an error if used.

```

- **Sources:**
  - `docs/reference/generation/creating_grammars.md:56-58`

## Review evidence locations

- `docs/reference/generation/creating_grammars.md:56-58`
