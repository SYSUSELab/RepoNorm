# Rule details

- **Rule:**
  ```text
  When modifying fsm_union, preserve the API contract that it returns both the aggregate FSM and a map from each component FSM to its transitions, finals, and old-to-new state mapping in the aggregate FSM.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When changing the return value or mapping structure of fsm_union.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/fsm/parsing.py:935-944`
- `outlines/fsm/parsing.py:1030-1048`
