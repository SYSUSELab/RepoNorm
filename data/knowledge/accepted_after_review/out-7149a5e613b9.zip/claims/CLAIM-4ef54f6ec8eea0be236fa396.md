# Rule details

- **Rule:**
  ```text
  Benchmark timing methods must disable caching (via cache_disabled) so measured durations reflect uncached construction/execution rather than cached results.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark timing method that constructs a guide or FSM from a schema/regex/grammar.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The benchmark timing methods (time_cfg_guide_setup, time_cfg_guide_run, peakmem_cfg_guide_run) are decorated with @cache_disabled(), disabling caching before measured construction/execution.
```

- **Sources:**
  - `benchmarks/bench_cfg_guide.py`

### Evidence 2 — current_observation

```text
time_json_schema_to_fsm is decorated with @cache_disabled(), disabling caching before the measured construction of the regex/FSM.
```

- **Sources:**
  - `benchmarks/bench_json_schema.py`

### Evidence 3 — current_observation

```text
The benchmark timing methods time_regex_to_guide and peakmem_regex_to_guide are decorated with @cache_disabled(), disabling caching for the measured guide construction.
```

- **Sources:**
  - `benchmarks/bench_regex_guide.py`
