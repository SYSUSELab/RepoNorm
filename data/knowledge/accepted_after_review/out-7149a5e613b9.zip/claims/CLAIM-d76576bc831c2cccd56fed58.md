# Rule details

- **Rule:** The deploy job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  deploy:
    runs-on: ubuntu-latest

```

- **Sources:**
  - `.github/workflows/publish_documentation.yml:16-17`

## Review evidence locations

- `.github/workflows/publish_documentation.yml:16-17`
