# Rule details

- **Rule:**
  ```text
  Tests for extract_function_from_file must assert that an AttributeError matching 'Could not find' is raised when the requested function name is absent from the file content.
  ```
- **Applies to:**
  - `tests/test_function.py`
- **Condition:**
  ```text
  when adding or modifying tests for extract_function_from_file error behavior
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_function.py contains test_extract_function_from_file_no_function, which calls extract_function_from_file with a missing function name and asserts AttributeError matching 'Could not find'.
```

- **Sources:**
  - `tests/test_function.py`
