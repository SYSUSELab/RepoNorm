# Rule details

- **Rule:**
  ```text
  The Release Docker workflow can be triggered manually via workflow_dispatch with a release_tag input defaulting to 'latest'.
  ```
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  workflow_dispatch:
    inputs:
      release_tag:
        description: 'Release Tag (for manual dispatch)'
        required: false
        default: 'latest'

```

- **Sources:**
  - `.github/workflows/release_docker.yml:7-12`

## Review evidence locations

- `.github/workflows/release_docker.yml:7-12`
