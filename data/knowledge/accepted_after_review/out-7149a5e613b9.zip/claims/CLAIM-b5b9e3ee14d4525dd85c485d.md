# Rule details

- **Rule:**
  ```text
  When modifying the OpenAI model module, preserve OpenAI, openai, and azure_openai as the declared public exports, since these names are the supported integration surface.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:** Modifying the public exports of outlines/models/openai.py
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/openai.py:1-12`
