# Rule details

- **Rule:**
  ```text
  Function.__call__ must lazily initialize the generator and must not support batching.
  ```
- **Applies to:**
  - `outlines/function.py`
- **Condition:**
  ```text
  Modifying Function.__call__ generator initialization or batching support.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/function.py:43-62`
