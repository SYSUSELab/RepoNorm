# Rule details

- **Rule:** The workflow installs asv, virtualenv, and lf-asv-formatter via pip.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      run: |
        python -m pip install --upgrade pip
        pip install asv virtualenv lf-asv-formatter

```

- **Sources:**
  - `.github/workflows/asv_benchmark_pr.yml:45-47`
