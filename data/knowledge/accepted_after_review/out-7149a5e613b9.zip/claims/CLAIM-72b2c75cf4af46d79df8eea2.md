# Rule details

- **Rule:**
  ```text
  openai_model() must lazily import AsyncOpenAI and raise ImportError naming the openai library, and must replace config.model with the supplied model_name when a config is provided.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When modifying openai_model() or its optional-dependency import and config handling.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/openai.py:254-274`
