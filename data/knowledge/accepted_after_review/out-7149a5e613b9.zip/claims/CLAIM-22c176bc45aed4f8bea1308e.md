# Rule details

- **Rule:** Multinomial sampling tests must exercise the supported sampler parameter combinations and assert that generate.text returns a string.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** When modifying multinomial sampling tests for the llamacpp backend
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_llamacpp.py:88-107`
