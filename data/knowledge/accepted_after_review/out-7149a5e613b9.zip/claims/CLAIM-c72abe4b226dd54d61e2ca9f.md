# Rule details

- **Rule:**
  ```text
  Integration tests for vLLM-backed generation must assert beam search behavior: beam_search(1) output equals greedy output, and beam_search(2) returns a result of length 2 with distinct elements.
  ```
- **Applies to:**
  - `tests/generate/test_integration_vllm.py`
- **Condition:** When modifying or adding vLLM integration tests that exercise beam search sampling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_vllm.py:110-123`
