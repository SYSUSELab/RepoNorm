# Rule details

- **Rule:** Integration tests for the transformers backend must preserve the batched integer-format output shape: passing a two-element prompt list to generate.format(model, int) returns a list of length 2 with int elements.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** When modifying transformers integration tests or the integer-format generation path, preserve the batched output-shape assertion (list of length 2 with int elements).
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_transformers.py:188-194`
