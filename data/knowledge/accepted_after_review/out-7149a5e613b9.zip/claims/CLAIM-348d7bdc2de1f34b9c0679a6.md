# Rule details

- **Rule:**
  ```text
  The Modal example must defer importing outlines and loading the transformers model into an import_model() function, and expose a local entrypoint main that calls generate.remote(prompt).
  ```
- **Applies to:**
  - `examples/modal_example.py`
- **Condition:** When modifying model initialization or the remote invocation entrypoint in the Modal example.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/modal_example.py:14-20`
- `examples/modal_example.py:77-81`
