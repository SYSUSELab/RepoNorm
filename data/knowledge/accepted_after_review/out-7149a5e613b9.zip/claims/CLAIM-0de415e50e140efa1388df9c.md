# Rule details

- **Rule:** The project version is declared dynamically rather than statically in pyproject.toml.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
dynamic = ["version"]

```

- **Sources:**
  - `pyproject.toml:45`
