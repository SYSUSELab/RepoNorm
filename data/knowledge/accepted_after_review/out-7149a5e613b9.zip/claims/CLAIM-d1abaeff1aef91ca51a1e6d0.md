# Rule details

- **Rule:** Benchmark input fixtures must use a fixed, named set of regex samples (email, phone, date, time, ip, url, ssn, etc.) as benchmark inputs.
- **Applies to:**
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying regex guide benchmark input fixtures.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
bench_regex_guide.py defines a fixed, named regex_samples dict (email, complex_phone, simple_phone, date, time, ip, url, ssn, complex_span_constrained_relation_extraction) used as benchmark inputs.
```

- **Sources:**
  - `benchmarks/bench_regex_guide.py`
