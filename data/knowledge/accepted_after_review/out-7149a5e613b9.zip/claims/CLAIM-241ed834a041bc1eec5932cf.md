# Rule details

- **Rule:**
  ```text
  Sampler tests must verify that GreedySampler returns next_token_ids, ancestors, and weights where weights equal the log-probability of the selected token, with sampling_params for greedy being sampler='greedy', num_samples=1, top_p=None, top_k=None, temperature=0.0.
  ```
- **Applies to:**
  - `tests/test_samplers.py`
- **Condition:** When modifying or extending sampler tests that exercise greedy sampling behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_samplers.py:29-55`
