# Rule details

- **Rule:** Tests for vision sequence generator input validation must assert TypeError for mismatched prompt/media shapes such as a single prompt with a list of images or nested list mismatches, defining accepted vision input shapes.
- **Applies to:**
  - `tests/generate/test_api.py`
- **Condition:** when adding or modifying tests for vision sequence generator input shape validation
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/generate/test_api.py contains a parameterized test asserting TypeError for mismatched prompt/media shapes (single prompt with list of images, nested list mismatches) while accepting valid shapes.
```

- **Sources:**
  - `tests/generate/test_api.py`
