# Rule details

- **Rule:**
  ```text
  When modifying the lazily cached termset_fsm_info property, preserve the caching behavior: compute _termset_fsm_info only when None and return the cached value on subsequent accesses.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  Modifying termset_fsm_info in outlines/fsm/parsing.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/fsm/parsing.py:269-273`
