# Rule details

- **Rule:** The Release Docker workflow runs on release events of type created.
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Condition:** workflow predicate: release: types: - created
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
on:
  release:
    types:
      - created

```

- **Sources:**
  - `.github/workflows/release_docker.yml:3-6`

## Review evidence locations

- `.github/workflows/release_docker.yml:3-6`
