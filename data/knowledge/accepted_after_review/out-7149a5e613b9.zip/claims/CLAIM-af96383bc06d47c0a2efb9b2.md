# Rule details

- **Rule:** CFG guide tests must assert that next-instruction token sets exactly cover the tokenizer-encoded sample sequence and that the final instruction includes the EOS token id.
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** When modifying CFGGuide next-instruction token coverage assertions or the grammar sample test.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/fsm/test_cfg_guide.py:427-457`
