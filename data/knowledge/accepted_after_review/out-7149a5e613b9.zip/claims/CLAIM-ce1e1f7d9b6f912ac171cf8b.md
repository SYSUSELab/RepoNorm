# Rule details

- **Rule:**
  ```text
  Contributors install the pre-commit hooks by running `pre-commit install`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
pre-commit install

```

- **Sources:**
  - `docs/community/contribute.md:43`

## Review evidence locations

- `docs/community/contribute.md:43-43`
