# Rule details

- **Rule:**
  ```text
  Vision integration tests must use the img_from_url helper that downloads an image, wraps it in BytesIO, and converts it to RGB, establishing the expected image input format for vision tests.
  ```
- **Applies to:**
  - `tests/generate/test_integration_transformers_vision.py`
- **Condition:** When modifying or adding vision integration tests that need to supply image inputs.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_transformers_vision.py:18-20`
