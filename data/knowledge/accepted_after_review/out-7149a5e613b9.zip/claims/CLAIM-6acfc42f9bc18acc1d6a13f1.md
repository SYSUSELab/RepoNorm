# Rule details

- **Rule:** Examples that derive a platform-specific model tag from a model identifier use a deterministic transformation (such as lowercasing and replacing '/' with '--') so the tag is reproducible from the model ID.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** when adding or modifying an example that derives a platform-specific model tag from a model identifier
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/bentoml/import_model.py:3-4`
- `examples/bentoml/import_model.py:18-24`
