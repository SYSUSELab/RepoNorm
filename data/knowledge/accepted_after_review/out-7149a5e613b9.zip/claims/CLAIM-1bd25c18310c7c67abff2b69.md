# Rule details

- **Rule:** Documentation must be up-to-date.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- [ ] The documentation is up-to-date;

```

- **Sources:**
  - `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:16`

## Review evidence locations

- `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:16-16`
