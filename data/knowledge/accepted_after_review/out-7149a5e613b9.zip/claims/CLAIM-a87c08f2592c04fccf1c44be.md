# Rule details

- **Rule:**
  ```text
  Tests for the transformers model must use the tiny random GPTJ causal LM model identifier as TEST_MODEL for stable tokenizer/model tests.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** When adding or modifying tests that need a small stable transformers model.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test module defines TEST_MODEL as the tiny random GPTJ causal LM identifier ('hf-internal-testing/tiny-random-GPTJForCausalLM'), matching the rule's required stable test model constant.
```

- **Sources:**
  - `tests/models/test_transformers.py`

## Review evidence locations

- `tests/models/test_transformers.py:6-16`
