# Rule details

- **Rule:**
  ```text
  llama.cpp streaming tests must preserve the streaming output contract: the stream yields at most max_tokens tokens and the first token is a str.
  ```
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** when modifying the llama.cpp streaming API test or the streaming output contract it pins
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_llamacpp.py:55-60`
