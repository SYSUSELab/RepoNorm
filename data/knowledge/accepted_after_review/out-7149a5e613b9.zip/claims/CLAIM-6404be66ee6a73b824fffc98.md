# Rule details

- **Rule:**
  ```text
  Vision integration tests must load a small CPU-friendly model via the transformers_vision fixture (e.g. trl-internal-testing/tiny-LlavaForConditionalGeneration) and assert constrained choice generation returns a string contained in the provided choices list.
  ```
- **Applies to:**
  - `tests/generate/test_integration_transformers_vision.py`
- **Condition:** when adding or modifying vision integration tests that verify constrained choice generation
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_transformers_vision.py:23-29`
