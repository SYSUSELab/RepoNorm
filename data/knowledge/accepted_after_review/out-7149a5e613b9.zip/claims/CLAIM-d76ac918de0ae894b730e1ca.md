# Rule details

- **Rule:**
  ```text
  Benchmark setup must resolve the target schema/grammar by name from a shared mapping and initialize the tokenizer via setup_tokenizer, so cases are keyed by name.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
- **Condition:**
  ```text
  When adding or modifying benchmark setup that selects a named schema or grammar, resolve the target by name from a shared mapping; initialize the tokenizer via setup_tokenizer only when the benchmark module imports it from the shared common helper.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `benchmarks/bench_json_schema.py:64-72`
- `benchmarks/bench_cfg_guide.py:20-32`
