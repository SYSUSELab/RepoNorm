# Rule details

- **Rule:**
  ```text
  When modifying the USPhoneNumber type in outlines/types/phone_numbers.py, preserve its exposure to JSON schema consumers as Annotated[str, WithJsonSchema({'type': 'string', 'pattern': US_PHONE_NUMBER})], so the phone number type remains a string with a regex pattern.
  ```
- **Applies to:**
  - `outlines/types/phone_numbers.py`
- **Condition:** When changing the USPhoneNumber type definition or its JSON schema exposure.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/phone_numbers.py:7-16`
