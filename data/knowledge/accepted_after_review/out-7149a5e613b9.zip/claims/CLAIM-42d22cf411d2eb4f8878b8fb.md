# Rule details

- **Rule:**
  ```text
  Backend integration tests for output reformatting must assert the exact regrouping behavior: a single string is returned unchanged, a one-element list is unwrapped to its element, and with num_samples=2 a flat list is regrouped into pairs.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When adding or modifying a backend integration test that exercises reformat_output with varying sample counts.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_reformat_output asserts exact regrouping: single string unchanged, one-element list unwrapped, and num_samples=2 flat list regrouped into pairs, matching the rule.
```

- **Sources:**
  - `tests/generate/test_integration_exllamav2.py:253-291`
