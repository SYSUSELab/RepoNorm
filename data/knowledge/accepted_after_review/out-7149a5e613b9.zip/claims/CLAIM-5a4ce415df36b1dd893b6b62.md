# Rule details

- **Rule:**
  ```text
  SequenceGeneratorAdapter.__call__ must accept a prompt or list of prompts plus optional max_tokens, stop_at, seed, and model-specific params, prepare generation parameters, call model.generate with a copy of the logits processor, and format completions.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:**
  ```text
  When modifying SequenceGeneratorAdapter.__call__ or the generation call path.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
SequenceGeneratorAdapter.__call__ accepts a prompt or list of prompts plus optional max_tokens, stop_at, seed, and model-specific params, prepares generation parameters, calls model.generate with copy(self.logits_processor), and formats completions.
```

- **Sources:**
  - `outlines/generate/api.py:476-498`
