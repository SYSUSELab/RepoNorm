# Rule details

- **Rule:** When modifying the prompts module, preserve its dependency on Jinja2 for templating and Pydantic for schema handling rather than replacing them with ad-hoc string formatting or alternate schema libraries.
- **Applies to:**
  - `outlines/prompts.py`
- **Condition:** Modifying prompt templating or schema handling in outlines/prompts.py
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/prompts.py:1-25`
- `pyproject.toml:26-35`
