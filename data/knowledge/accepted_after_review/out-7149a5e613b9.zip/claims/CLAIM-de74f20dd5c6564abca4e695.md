# Rule details

- **Rule:**
  ```text
  The release_pypi workflow runs when a GitHub release is created.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Condition:** workflow predicate: release: types: - created
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
on:
  release:
    types:
      - created

```

- **Sources:**
  - `.github/workflows/release_pypi.yaml:3-6`

## Review evidence locations

- `.github/workflows/release_pypi.yaml:3-6`
