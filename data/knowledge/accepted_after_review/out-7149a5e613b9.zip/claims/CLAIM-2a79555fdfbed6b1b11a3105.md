# Rule details

- **Rule:** When modifying PartialLexerThread, preserve its role as the lark LexerThread subclass used for incremental/partial parsing.
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing the partial lexer thread or its lark integration.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/fsm/parsing.py:153-158`
- `outlines/fsm/parsing.py:171-179`
