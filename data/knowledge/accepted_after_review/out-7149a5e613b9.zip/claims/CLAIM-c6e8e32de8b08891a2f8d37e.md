# Rule details

- **Rule:** Example scripts that demonstrate self-consistency must generate multiple samples, extract the answer from each sample, and report the most frequent answer with a consensus percentage.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that demonstrates self-consistency or multi-sample aggregation.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/self_consistency.py:58-69`
- `examples/self_consistency.py:73-82`
