# Rule details

- **Rule:** The "outlines" package includes the py.typed marker file as package data.
- **Applies to:**
  - `outlines/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
[tool.setuptools.package-data]
"outlines" = ["py.typed"]

```

- **Sources:**
  - `pyproject.toml:95-96`

## Review evidence locations

- `pyproject.toml:92-96`
