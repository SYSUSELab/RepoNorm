# Rule details

- **Rule:**
  ```text
  Run `asv continuous origin/main HEAD --config benchmarks/asv.conf.json` to run continuous benchmarks comparing origin/main against HEAD using the benchmarks/asv.conf.json configuration.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
asv continuous origin/main HEAD --config benchmarks/asv.conf.json

```

- **Sources:**
  - `docs/community/contribute.md:86`

## Review evidence locations

- `docs/community/contribute.md:83-86`
