# Rule details

- **Rule:**
  ```text
  Generator tests must preserve the per-sequence FSM state mapping: get_next_fsm_states returns one next state per FSM for both single and two-FSM inputs.
  ```
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:**
  ```text
  when modifying get_next_fsm_states or its generator test coverage
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_generator.py:338-352`
