# Rule details

- **Rule:** When adding a new optional model backend factory (e.g. mamba-style), import the heavy backend dependency lazily inside the factory and raise ImportError naming the required packages, rather than importing at module top level.
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** Adding or modifying an optional model backend factory in outlines/models/transformers.py
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/transformers.py:415-425`
- `outlines/models/transformers.py:438-458`
