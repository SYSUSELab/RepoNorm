# Rule details

- **Rule:**
  ```text
  New grammar files are created as `.lark` files placed in `outlines/grammars/`, with attribution included and a compatible license.
  ```
- **Applies to:**
  - `outlines/grammars/**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Create your grammar file named `your_new_grammar.lark`, adhering to the guidelines provided above. Add it to `outlines/grammars/` (ensure attribution is included and license is compatible).

```

- **Sources:**
  - `docs/reference/generation/creating_grammars.md:66`

## Review evidence locations

- `docs/reference/generation/creating_grammars.md:62-68`
