# Rule details

- **Rule:**
  ```text
  When modifying the vision regex adapter registration, preserve the regex_vision registration for TransformersVision that builds a RegexLogitsProcessor from the model tokenizer and returns a VisionSequenceGeneratorAdapter.
  ```
- **Applies to:**
  - `outlines/generate/regex.py`
- **Condition:**
  ```text
  Modifying regex_vision in outlines/generate/regex.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generate/regex.py:38-47`
