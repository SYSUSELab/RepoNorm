# Rule details

- **Rule:**
  ```text
  When modifying the llama.cpp stream method, preserve the parameter precedence that user-supplied llama_cpp_params supersede values derived from generation_parameters and sampling_parameters, and that stream=True is forced before invoking the model.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** Modifying LlamaCpp.stream in outlines/models/llamacpp.py
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/llamacpp.py:164-223`
- `outlines/models/llamacpp.py:295-344`
