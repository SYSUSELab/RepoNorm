# Rule details

- **Rule:**
  ```text
  When modifying PartialParsingFrontend in outlines/fsm/parsing.py, do not reintroduce the abandoned _state_transition_map design built from parse_table.states and a contextual lexer; the commented-out code and TODO document it as a known performance concern.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** Modifying PartialParsingFrontend or considering a state-transition-map optimization.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
`PartialParsingFrontend` contains commented-out `_state_transition_map` construction code and a TODO documenting it as wasteful, showing the abandoned design is avoided.
```

- **Sources:**
  - `outlines/fsm/parsing.py:171-285`
