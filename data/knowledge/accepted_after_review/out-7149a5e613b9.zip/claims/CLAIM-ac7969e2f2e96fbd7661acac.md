# Rule details

- **Rule:** mypy excludes the examples directory from type checking.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
exclude=["examples"]

```

- **Sources:**
  - `pyproject.toml:113`
