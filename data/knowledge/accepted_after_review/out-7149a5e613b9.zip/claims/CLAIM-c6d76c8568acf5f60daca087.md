# Rule details

- **Rule:** Prompt template tests must assert that a for-loop without whitespace control leaves a trailing newline, while closing with -%} strips the following newline, and the same -%} behavior applies to conditionals.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When adding or modifying a prompt template test that exercises Jinja whitespace control in loops or conditionals.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_render_jinja asserts exact rendered output: a for-loop without whitespace control leaves a trailing newline, closing with -%} strips the following newline, and the same -%} behavior is asserted for conditionals.
```

- **Sources:**
  - `tests/test_prompts.py:74-112`
