# Rule details

- **Rule:** The pre-commit configuration enables the debug-statements hook from pre-commit/pre-commit-hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
    -   id: debug-statements

```

- **Sources:**
  - `.pre-commit-config.yaml:6`
