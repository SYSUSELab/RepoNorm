# Rule details

- **Rule:**
  ```text
  When modifying ExLlamaV2Model.__init__, preserve the configuration surface contract: generator, tokenizer, and max_seq_len are stored as attributes, making max_seq_len part of the model's configuration surface.
  ```
- **Applies to:**
  - `outlines/models/exllamav2.py`
- **Condition:**
  ```text
  When changing attribute storage or configuration surface in ExLlamaV2Model.__init__.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/exllamav2.py:42-53`
