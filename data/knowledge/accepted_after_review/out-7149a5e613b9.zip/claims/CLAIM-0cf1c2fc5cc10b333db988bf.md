# Rule details

- **Rule:**
  ```text
  The documentation publish workflow runs on workflow_dispatch, on pushes to the main branch, and on release events of type created.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: workflow_dispatch: push: branches: - main release: types: - created
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
on:
  workflow_dispatch:
  push:
    branches:
      - main
  release:
    types:
      - created

```

- **Sources:**
  - `.github/workflows/publish_documentation.yml:3-10`

## Review evidence locations

- `.github/workflows/publish_documentation.yml:3-10`
