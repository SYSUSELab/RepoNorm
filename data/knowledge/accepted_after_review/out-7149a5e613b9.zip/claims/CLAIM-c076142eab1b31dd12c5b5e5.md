# Rule details

- **Rule:**
  ```text
  The session-scoped model_mlxlm_phi3 fixture must continue to load the external 'mlx-community/Phi-3-mini-4k-instruct-4bit' model, so tests depending on it require that model to be available.
  ```
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  When modifying or extending the model_mlxlm_phi3 fixture, preserve the external model identifier 'mlx-community/Phi-3-mini-4k-instruct-4bit' and its session scope.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_generate.py:46-48`
