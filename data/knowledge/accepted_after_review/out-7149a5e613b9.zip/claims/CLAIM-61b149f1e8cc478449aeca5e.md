# Rule details

- **Rule:** The Tests workflow runs on pull requests targeting the main branch.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  pull_request:
    branches: [main]

```

- **Sources:**
  - `.github/workflows/tests.yml:4-5`

## Review evidence locations

- `.github/workflows/tests.yml:4-5`
