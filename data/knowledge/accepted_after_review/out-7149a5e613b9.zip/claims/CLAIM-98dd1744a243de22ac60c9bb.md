# Rule details

- **Rule:**
  ```text
  Benchmark timing methods must measure a single processor call over precomputed inputs (input_ids and logits) without generation, so the measured unit is raw processor cost.
  ```
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying a logits processor benchmark timing method.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `benchmarks/bench_processors.py:93-99`
- `benchmarks/bench_processors.py:121-131`
