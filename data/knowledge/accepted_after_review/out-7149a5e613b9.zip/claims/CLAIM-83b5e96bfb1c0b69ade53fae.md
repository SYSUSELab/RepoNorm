# Rule details

- **Rule:**
  ```text
  The cfg_test_inputs mapping must define named TestInputs cases (grammar, vocabulary, generated, legal_next_tokens) covering ambiguous terminals, overlapping tokens, optional/nested patterns, unicode, and ignored whitespace, with commented-out cases annotated by TODO notes about parser greediness and interegular lookaround limitations.
  ```
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:**
  ```text
  when modifying or extending the cfg_test_inputs mapping in tests/fsm/test_cfg_guide.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/fsm/test_cfg_guide.py:33-99`
