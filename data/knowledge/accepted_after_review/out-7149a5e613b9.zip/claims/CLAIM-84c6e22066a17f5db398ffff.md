# Rule details

- **Rule:**
  ```text
  Transformers.forward must assert input_ids.ndim is 1 or 2, and when past_key_values is provided it must slice input_ids to the last token before inference, so callers pass full sequences only on the first step.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying Transformers.forward or its past_key_values handling
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/transformers.py:140-184`
