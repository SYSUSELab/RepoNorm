# Rule details

- **Rule:** Examples that document performance tradeoffs intentionally avoid length constraints (such as constr) on free-text fields when they dramatically increase generation time, while still using collection constraints (such as conlist) where needed.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** when adding or modifying an example schema that includes length or collection constraints
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/dating_profile.py:27-35`
