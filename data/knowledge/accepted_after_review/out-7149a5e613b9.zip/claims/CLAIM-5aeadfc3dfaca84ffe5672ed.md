# Rule details

- **Rule:**
  ```text
  When modifying the vision CFG adapter registration, preserve the cfg_vision registration for TransformersVision that constructs a CFGLogitsProcessor from the cfg string and model tokenizer and returns a VisionSequenceGeneratorAdapter.
  ```
- **Applies to:**
  - `outlines/generate/cfg.py`
- **Condition:**
  ```text
  Modifying cfg_vision in outlines/generate/cfg.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generate/cfg.py:36-41`
