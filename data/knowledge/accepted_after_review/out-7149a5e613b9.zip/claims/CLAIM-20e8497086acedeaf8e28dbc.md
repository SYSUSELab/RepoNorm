# Rule details

- **Rule:** The release-job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    runs-on: ubuntu-latest

```

- **Sources:**
  - `.github/workflows/release_pypi.yaml:10`

## Review evidence locations

- `.github/workflows/release_pypi.yaml:10-10`
