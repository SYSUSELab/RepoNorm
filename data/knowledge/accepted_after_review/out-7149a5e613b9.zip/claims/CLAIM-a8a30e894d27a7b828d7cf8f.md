# Rule details

- **Rule:** Examples that generate structured output pass a schema to outlines.generate.json (or an equivalent constrained generator) and the schema is expressed as a pydantic BaseModel or a raw JSON schema with definitions/$ref, matching the generator's accepted input forms.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** when adding or modifying an example that calls outlines.generate.json with a schema argument
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/llamacpp_example.py:23-36`
- `examples/bentoml/service.py:6-41`
- `examples/bentoml/service.py:67-76`
