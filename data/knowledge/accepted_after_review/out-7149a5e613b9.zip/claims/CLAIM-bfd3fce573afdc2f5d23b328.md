# Rule details

- **Rule:**
  ```text
  get_schema_from_enum must succeed for a normal enum but raise ValueError for an empty enum, with schema title equal to the enum name and oneOf length equal to the enum length.
  ```
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:**
  ```text
  when modifying or extending enum schema tests in tests/fsm/test_json_schema.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/fsm/test_json_schema.py:52-78`
