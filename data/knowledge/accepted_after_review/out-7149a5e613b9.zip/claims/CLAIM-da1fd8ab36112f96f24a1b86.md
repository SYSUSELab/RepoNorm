# Rule details

- **Rule:** When adding a new feature, the PR must reference an existing issue discussing it.
- **Applies to:**
  - `**`
- **Condition:** when the PR adds a new feature
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- [ ] *If I add a new feature*, there is an [issue][issues] discussing it already;

```

- **Sources:**
  - `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:7`

## Review evidence locations

- `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:7-7`
