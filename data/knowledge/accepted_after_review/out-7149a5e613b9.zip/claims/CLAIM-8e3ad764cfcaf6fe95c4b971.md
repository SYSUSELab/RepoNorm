# Rule details

- **Rule:**
  ```text
  When using venv, create the virtual environment with `python -m venv .venv`.
  ```
- **Applies to:**
  - `**`
- **Condition:** when using venv
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

````text
*If you are using venv*:

```python
python -m venv .venv

````

- **Sources:**
  - `docs/community/contribute.md:32-35`

## Review evidence locations

- `docs/community/contribute.md:32-35`
