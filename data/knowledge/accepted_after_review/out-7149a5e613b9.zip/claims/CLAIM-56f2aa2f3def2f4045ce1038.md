# Rule details

- **Rule:**
  ```text
  JSON generation tests must honor the whitespace_pattern argument so that generated output contains no newline characters when the pattern forbids them.
  ```
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:**
  ```text
  When modifying JSON generation tests that pass a whitespace_pattern argument
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_transformers.py:438-454`
