# Rule details

- **Rule:**
  ```text
  The _reconstruct_fsms test helper must assert exactly one symbol per transition and must not be relied upon for reconstructing FSMs with more than one transition per symbol, as documented by its NOTE.
  ```
- **Applies to:**
  - `tests/fsm/test_parsing.py`
- **Condition:**
  ```text
  when using or modifying the _reconstruct_fsms helper in parsing tests
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_reconstruct_fsms asserts len(symbols) == 1 and carries a NOTE comment stating it does not work for more than one transition per symbol.
```

- **Sources:**
  - `tests/fsm/test_parsing.py`
