# Rule details

- **Rule:**
  ```text
  Integration tests for the exllamav2 backend must keep the session-scoped model_exllamav2 fixture loading an exl2 model with cache_q4=True and paged=False, and must continue to assert that model.generate returns a str for both string and list stop_at forms and a list whose first element is a str when SamplingParameters('multinomial', 2) is used.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When modifying exllamav2 integration tests or the exllamav2 fixture, preserve the cache_q4=True/paged=False loading convention and the stop_at and multisampling output-shape assertions.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_exllamav2.py:11-17`
