# Rule details

- **Rule:**
  ```text
  The workflow's default run working directory is ${{ env.WORKING_DIR }}, which is set to ${{ github.workspace }}/benchmarks.
  ```
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  WORKING_DIR: ${{ github.workspace }}/benchmarks

```

- **Sources:**
  - `.github/workflows/asv_benchmark_pr.yml:10`

### Evidence 2 — explicit

```text
        working-directory: ${{ env.WORKING_DIR }}

```

- **Sources:**
  - `.github/workflows/asv_benchmark_pr.yml:30`

## Review evidence locations

- `.github/workflows/asv_benchmark_pr.yml:10-10`
- `.github/workflows/asv_benchmark_pr.yml:30-30`
