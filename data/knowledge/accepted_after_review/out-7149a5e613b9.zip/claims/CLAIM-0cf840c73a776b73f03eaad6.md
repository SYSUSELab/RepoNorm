# Rule details

- **Rule:**
  ```text
  When modifying TransformerTokenizer.__eq__, preserve the comparison of model_name and kwargs when both attributes exist, with fallback to comparing tokenizers, so equality semantics for transformer model wrappers remain stable.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When changing TransformerTokenizer equality or hash behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/transformers.py:106-114`
