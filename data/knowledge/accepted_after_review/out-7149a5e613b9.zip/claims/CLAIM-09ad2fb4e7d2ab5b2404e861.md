# Rule details

- **Rule:**
  ```text
  diff-cover is configured with compare_branch set to "origin/main".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
compare_branch = "origin/main"

```

- **Sources:**
  - `pyproject.toml:173`

## Review evidence locations

- `pyproject.toml:173-173`
