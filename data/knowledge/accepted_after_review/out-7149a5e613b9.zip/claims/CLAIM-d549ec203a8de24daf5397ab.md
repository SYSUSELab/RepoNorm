# Rule details

- **Rule:**
  ```text
  Function.init_generator must load models.transformers(self.model_name) and assign generate.json(model, self.schema) to self.generator, coupling the function wrapper to the transformers backend and JSON schema generation.
  ```
- **Applies to:**
  - `outlines/function.py`
- **Condition:**
  ```text
  When modifying Function.init_generator or the backend/schema coupling it establishes.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/function.py:38-41`
