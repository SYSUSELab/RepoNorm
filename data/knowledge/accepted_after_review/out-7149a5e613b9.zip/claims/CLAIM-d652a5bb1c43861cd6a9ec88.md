# Rule details

- **Rule:** Flake8 selects the C, E, F, and W error code groups.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
select = C,E,F,W

```

- **Sources:**
  - `setup.cfg:3`

## Review evidence locations

- `setup.cfg:3-3`
