# Rule details

- **Rule:** The BentoML import example saves both the tokenizer and the model into the BentoML model reference path, establishing the expected artifact layout for packaging a transformers model as a Bento.
- **Applies to:**
  - `examples/bentoml/**/*.py`
- **Condition:** When adding or modifying a BentoML packaging example for a transformers model, save both the tokenizer and the model into the BentoML model reference path.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/bentoml/import_model.py:7-20`
