# Rule details

- **Rule:**
  ```text
  The valid_types helper must enforce that when prompts is a list, media is a list of the same length and each submedia is an iterable of PIL Image objects; when prompts is a string, media must be an iterable of PIL Image objects.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:**
  ```text
  when modifying VisionSequenceGeneratorAdapter._validate_prompt_media_types.valid_types or multimodal prompt/media validation
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generate/api.py:576-607`
