# Rule details

- **Rule:** When adding a new model type to regex-constrained generation, register a dedicated singledispatch handler on the regex generator that constructs the appropriate guide and wraps it in the matching sequence-generator adapter (including vision-specific adapters) rather than branching inside a shared handler.
- **Applies to:**
  - `outlines/generate/fsm.py`
  - `outlines/generate/regex.py`
- **Condition:** Adding or modifying support for a new model type in regex/FSM-constrained generation.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generate/fsm.py:14-30`
- `outlines/generate/regex.py:11-47`
