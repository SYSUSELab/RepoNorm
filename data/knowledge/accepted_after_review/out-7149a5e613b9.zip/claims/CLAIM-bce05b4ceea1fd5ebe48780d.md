# Rule details

- **Rule:** There is no builtin false positive testing utility; smoke testing is the recommended way to test a new grammar.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Currently there isn't a builtin false positive testing utility. It is recommended you smoke test via

```

- **Sources:**
  - `docs/reference/generation/creating_grammars.md:78`

## Review evidence locations

- `docs/reference/generation/creating_grammars.md:78-78`
