# Rule details

- **Rule:** Tests for TransformerTokenizer must assert that equality and hashing are based on the wrapped HF tokenizer state, so tokenizers wrapping the same HF tokenizer are equal and hash-equal, while one wrapping a modified HF tokenizer is unequal and hash-unequal.
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** When adding or modifying tests for TransformerTokenizer equality or hashing.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_tokenizer_eq_hash asserts equality and hash-equality for tokenizers wrapping the same HF tokenizer and inequality/hash-inequality after modifying the wrapped HF tokenizer.
```

- **Sources:**
  - `tests/models/test_transformers.py`
