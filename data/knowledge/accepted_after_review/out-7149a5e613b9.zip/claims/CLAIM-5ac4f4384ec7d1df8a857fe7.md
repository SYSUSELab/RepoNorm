# Rule details

- **Rule:**
  ```text
  RegexGuide.from_regex must inject cached_create_states_mapping as _create_states_mapping while forwarding other kwargs, preserving the cached state-mapping extension point for regex guides.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  When modifying RegexGuide.from_regex or the state-mapping creation path for regex guides.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/fsm/guide.py:75-97`
