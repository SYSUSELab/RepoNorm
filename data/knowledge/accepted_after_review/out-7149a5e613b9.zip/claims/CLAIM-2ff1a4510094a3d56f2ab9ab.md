# Rule details

- **Rule:**
  ```text
  CFGGuide.iter_valid_token_ids must yield eos_token_id immediately when state.parser_state is None, otherwise yield eos only if can_terminate_state(state) is true, and yield other token ids only if applying them via _get_parser_state_token_applied succeeds, swallowing ValueError, EOFError, UnexpectedToken, UnexpectedCharacters, and DedentError.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  When modifying CFGGuide.iter_valid_token_ids or the token-validity protocol it implements.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/fsm/guide.py:177-196`
