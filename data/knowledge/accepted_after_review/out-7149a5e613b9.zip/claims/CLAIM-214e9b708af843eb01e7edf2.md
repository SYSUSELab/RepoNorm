# Rule details

- **Rule:** Docstrings must follow the numpy style guide.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- [ ] Docstrings follow the [numpy style guide][docstring-guidelines];

```

- **Sources:**
  - `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:13`

## Review evidence locations

- `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:13-13`
