# Rule details

- **Rule:** The RegexGuide caching test must remain skipped with the note that guide caching was temporarily turned off, and when re-enabled must assert cache hit/miss statistics and that different models produce different state-to-token maps.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** When modifying or re-enabling the RegexGuide caching test, preserve the skip note about temporarily disabled guide caching and the cache hit/miss and per-model state-to-token map assertions.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_llamacpp.py:277-321`
