# Rule details

- **Rule:**
  ```text
  The temp_prompt_file fixture writes base_template.txt, include.txt, and prompt.txt into a temp dir, exercising Jinja extends, block, include, and for-loop constructs in prompt templates.
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:**
  ```text
  When modifying the temp_prompt_file fixture or the Jinja template constructs it exercises.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
temp_prompt_file writes base_template.txt, include.txt, and prompt.txt into a temp dir, exercising Jinja extends, block, include, and for-loop constructs.
```

- **Sources:**
  - `tests/test_prompts.py:325-362`
