# Rule details

- **Rule:**
  ```text
  llama.cpp integration tests must pass frequency_penalty and presence_penalty plus seed and max_tokens to a text generator and assert the result is a str, documenting accepted generation kwargs for llama.cpp.
  ```
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** When modifying or extending llama.cpp integration tests that exercise sampling parameter passthrough.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_integration_llamacpp.py:70-78`
