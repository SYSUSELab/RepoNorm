# Rule details

- **Rule:** The workflow grants contents: write permission.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
permissions:
  contents: write

```

- **Sources:**
  - `.github/workflows/publish_documentation.yml:12-13`

## Review evidence locations

- `.github/workflows/publish_documentation.yml:12-13`
