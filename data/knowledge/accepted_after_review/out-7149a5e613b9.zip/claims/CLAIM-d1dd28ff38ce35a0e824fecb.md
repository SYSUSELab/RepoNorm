# Rule details

- **Rule:**
  ```text
  Tests for the CFG guide must assert the exact token-allowance state machine: the allowed token sets after each token and the point at which must_terminate_state/can_terminate_state become true.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** When adding or modifying tests for CFGGuide token allowance and termination behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
CFG guide tests in tests/fsm/test_guide.py assert exact allowed token sets after each token and the transition of must_terminate_state/can_terminate_state.
```

- **Sources:**
  - `tests/fsm/test_guide.py`
