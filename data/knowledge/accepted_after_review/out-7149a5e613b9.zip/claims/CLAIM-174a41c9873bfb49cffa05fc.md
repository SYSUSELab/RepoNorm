# Rule details

- **Rule:**
  ```text
  The build-wheel job runs ./.github/scripts/build_sdist_and_wheel.sh.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Build SDist and Wheel
        run: ./.github/scripts/build_sdist_and_wheel.sh

```

- **Sources:**
  - `.github/workflows/tests.yml:108-109`

## Review evidence locations

- `.github/workflows/tests.yml:108-109`
