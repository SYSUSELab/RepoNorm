# Rule details

- **Rule:**
  ```text
  When modifying choice() in outlines/generate/choice.py, preserve the behavior that it builds a regex from escaped choices or from an Enum schema, and sets format_sequence to pyjson.loads for Enum choices and identity for string choices.
  ```
- **Applies to:**
  - `outlines/generate/choice.py`
- **Condition:**
  ```text
  Modifying choice() or its regex/format_sequence construction.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generate/choice.py:18-34`
