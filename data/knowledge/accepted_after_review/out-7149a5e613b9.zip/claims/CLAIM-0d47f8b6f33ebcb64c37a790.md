# Rule details

- **Rule:**
  ```text
  Tests that exercise FSM guide behavior must import guide classes (CFGGuide, Generate, RegexGuide, StopAtEOSGuide, Write) from outlines.fsm.guide, and schema-to-regex conversion must be imported from outlines_core.fsm.json_schema rather than reimplemented locally.
  ```
- **Applies to:**
  - `tests/fsm/**/*.py`
- **Condition:** when adding or modifying FSM guide tests that need guide classes or schema-to-regex conversion
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test module imports CFGGuide from outlines.fsm.guide, matching the required guide-class import convention.
```

- **Sources:**
  - `tests/fsm/test_cfg_guide.py`

### Evidence 2 — current_observation

```text
tests/fsm/test_guide.py imports guide classes (CFGGuide, Generate, RegexGuide, StopAtEOSGuide, Write) from outlines.fsm.guide.
```

- **Sources:**
  - `tests/fsm/test_guide.py`

## Review evidence locations

- `tests/fsm/test_guide.py:1-3`
