# Rule details

- **Rule:** Prompt functions in the examples are defined by decorating a function with @outlines.prompt and placing the Jinja-style template in the function docstring, using {{ ... }} placeholders for runtime values.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying a reusable prompt function in an example script, define it with the @outlines.prompt decorator and put the template in the docstring rather than building the prompt string in the function body.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/pick_odd_one_out.py:16-29`
- `examples/react.py:20-38`
