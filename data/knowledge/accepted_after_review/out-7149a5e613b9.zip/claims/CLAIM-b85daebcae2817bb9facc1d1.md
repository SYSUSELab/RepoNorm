# Rule details

- **Rule:** Read the Docs builds use Python version 3.8.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  version: "3.8"

```

- **Sources:**
  - `.readthedocs.yaml:4`

## Review evidence locations

- `.readthedocs.yaml:4-4`
