# Rule details

- **Rule:**
  ```text
  When modifying the OpenAI model __call__, preserve the defaulting protocol: each optional generation parameter (max_tokens, stop_at, temperature, samples) is resolved from self.config when the caller passes None, config is rebuilt via dataclasses.replace before calling generate_chat, and token usage counters accumulate on the instance.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  Changing how OpenAI.__call__ resolves optional generation parameters or accumulates usage counters.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/openai.py:103-151`
