# Rule details

- **Rule:**
  ```text
  Tests for the transformers model must supply 2-D token tensors; passing 3-D input_ids raises AssertionError.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:**
  ```text
  When adding or modifying tests that pass input_ids to the transformers model.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_model supplies 2-D token tensors and asserts that passing 3-D input_ids raises AssertionError via pytest.raises(AssertionError).
```

- **Sources:**
  - `tests/models/test_transformers.py`
