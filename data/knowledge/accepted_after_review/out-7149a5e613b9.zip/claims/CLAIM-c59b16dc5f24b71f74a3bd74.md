# Rule details

- **Rule:** Benchmark processor doubles must be minimal OutlinesLogitsProcessor subclasses that perform a simple deterministic transformation (e.g., halving logits) to isolate processor overhead.
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying a benchmark processor double.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `benchmarks/bench_processors.py:70-74`
