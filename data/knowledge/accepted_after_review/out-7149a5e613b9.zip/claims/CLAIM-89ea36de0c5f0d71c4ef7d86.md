# Rule details

- **Rule:** Example scripts that translate a larger agent workflow must document the simplifications (e.g. omitted vector store retrieval, reduced cycle count) in the example itself.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that is a simplified translation of a larger agent workflow.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/babyagi.py:1-5`
- `examples/babyagi.py:154-155`
