# Rule details

- **Rule:** When modifying MLXLM.generate, preserve consistency between generate and stream for the same inputs, since generate is implemented by joining the token stream from self.stream.
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:** When changing MLXLM.generate or MLXLM.stream behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/mlxlm.py:31-41`
