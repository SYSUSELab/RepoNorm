# Rule details

- **Rule:**
  ```text
  The regex batch-stream test asserts that streaming generation for a batch of two sequences maintains per-sequence order: outputs[0] accumulates tokens[0] and outputs[1] accumulates tokens[1], and each accumulated output must fully match the regex pattern.
  ```
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  When modifying batch streaming generation behavior or per-sequence ordering exercised by test_generate_regex_batch_stream.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_generate_regex_batch_stream accumulates outputs[0] from tokens[0] and outputs[1] from tokens[1] and asserts each accumulated output fully matches the regex pattern, asserting per-sequence batch streaming order.
```

- **Sources:**
  - `tests/generate/test_generate.py:384-393`
