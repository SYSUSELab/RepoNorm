# Rule details

- **Rule:**
  ```text
  When modifying PartialParserConf.__init__, preserve the per-instance configurability of the deterministic and use_value_stack flags, which are stored after delegating rules/callbacks/start to the base class.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing parser configuration initialization or flag handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/fsm/parsing.py:75-87`
