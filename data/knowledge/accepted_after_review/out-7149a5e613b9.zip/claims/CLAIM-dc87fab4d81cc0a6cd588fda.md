# Rule details

- **Rule:** Multi-stage example workflows chain outlines generation calls by appending the first answer plus a follow-up question to the prompt before generating a second answer and returning the completed prompt.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying a multi-stage example workflow, append the prior answer and follow-up question to the prompt before the next generation call rather than issuing independent generations.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/meta_prompting.py:28-37`
- `examples/pick_odd_one_out.py:38-43`
