# Rule details

- **Rule:**
  ```text
  Prompt template tests must document the args template filter by defining an @outlines.prompt function whose body uses the 'args' filter on a callable ({{ fn | args }}), and must exercise the empty-template edge case with an @outlines.prompt function whose body is pass.
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When modifying or extending prompt template tests that exercise template filters or edge cases.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_prompts.py:264-321`
