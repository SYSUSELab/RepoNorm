# Rule details

- **Rule:** When modifying the logits biasing helper, preserve the invariant that disallowed token ids are set to -inf while allowed ids retain original logits, and that a row whose allowed ids are None is left entirely unmasked.
- **Applies to:**
  - `outlines/generate/generator.py`
- **Condition:**
  ```text
  Modifying bias_logits in outlines/generate/generator.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generate/generator.py:285-312`
