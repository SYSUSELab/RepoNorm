# Rule details

- **Rule:** Grammars used with Outlines' Lark LALR(1) parser must be unambiguous at least up to the next token (one token lookahead).
- **Applies to:**
  - `**/*.grammar`
  - `**/*.lark`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Outlines utilizes Larks LALR(1) parser, meaning the grammar must be unambiguous at least up to the next token (one token lookahead). Read Lark's official LALR(1) parser documentation [here](https://lark-parser.readthedocs.io/en/stable/parsers.html#lalr-1).

```

- **Sources:**
  - `docs/reference/generation/creating_grammars.md:19`

## Review evidence locations

- `docs/reference/generation/creating_grammars.md:19-19`
