# Rule details

- **Rule:** Generator tests must use a session-scoped fixture that loads a tiny random GPT-2 transformers model on CPU, a stable convention for fast model tests without GPU.
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:** When modifying or adding generator tests that need a transformers model fixture.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/generate/test_generate.py:51-54`
