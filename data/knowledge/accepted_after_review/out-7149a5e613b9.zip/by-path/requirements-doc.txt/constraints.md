# Constraints for `requirements-doc.txt`

## Rule

- **Rule:** Read the Docs installs documentation dependencies from requirements-doc.txt.
- **Applies to:**
  - `requirements-doc.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b1d3ab165522df6db699c41d.md)
