# Constraints for `environment.yml`

## Rule

- **Rule:** The conda environment is named dottxt-ai.
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-556ffb7b42e3a5a574502b94.md)

## Rule

- **Rule:** The environment's dependencies include python==3.10.0.
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-772720d5dad762736235fec3.md)

## Rule

- **Rule:**
  ```text
  The environment installs the local project in editable mode with its test extras via pip (-e ".[test]").
  ```
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9daf0d7c8d36cb1b577e1058.md)
