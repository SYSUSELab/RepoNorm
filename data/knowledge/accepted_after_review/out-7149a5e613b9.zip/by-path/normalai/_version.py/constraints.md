# Constraints for `normalai/_version.py`

## Rule

- **Rule:**
  ```text
  Flake8 excludes normalai/_version.py from linting.
  ```
- **Applies to:**
  - `normalai/_version.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2b3836fa47856800642c1c02.md)
