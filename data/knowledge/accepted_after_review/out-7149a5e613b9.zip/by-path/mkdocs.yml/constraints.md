# Constraints for `mkdocs.yml`

## Rule

- **Rule:** The MkDocs theme is configured as material.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-03d99915e3a6423d4db3c90e.md)

## Rule

- **Rule:**
  ```text
  The extra_css setting includes stylesheets/extra.css.
  ```
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-449801259488a2118a5c4414.md)

## Rule

- **Rule:**
  ```text
  The mkdocstrings python handler sets show_submodules to true.
  ```
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4b2881042e7b79390781d8f5.md)

## Rule

- **Rule:** The git-committers plugin is configured for branch main.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-504f07f553a018e146cbba0a.md)

## Rule

- **Rule:**
  ```text
  The MkDocs theme custom_dir is docs/overrides.
  ```
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9a08369acf93027627fef1ae.md)

## Rule

- **Rule:** The mkdocstrings plugin uses the python default handler.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bbe582435bf4f34634e9a7a2.md)

## Rule

- **Rule:**
  ```text
  The mkdocstrings python handler uses docstring_style numpy.
  ```
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e8fec8c52ad51c67633642b6.md)

## Rule

- **Rule:** The git-committers plugin is configured for repository dottxt-ai/outlines.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f6ebd54b4cecb042131f061a.md)
