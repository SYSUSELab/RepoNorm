# Constraints for `tests/test_types.py`

## Rule

- **Rule:**
  ```text
  Tests for custom scalar types must verify both the JSON schema string pattern and the python_types_to_regex regex against valid and invalid examples, using parametrization over the type cases.
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** when adding or modifying a test for a custom scalar type's schema pattern or regex
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5607fdb8d9a2900c0514a566.md)

## Rule

- **Rule:** Tests that exercise custom type annotations in pydantic models must preserve the custom type handling in model generation.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying tests that define pydantic models with custom type annotations
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d168896278960a8844e1efba.md)
