# Constraints for `tests/test_cache.py`

## Rule

- **Rule:**
  ```text
  Cache entries for generation functions are keyed by the function signature together with the outlines version; changing a cached function's return arity does not invalidate the stale entry until outlines._version.__version__ is bumped.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** When modifying the cache-keying or version-bump behavior exercised by the cache invalidation test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-17f29c38c375cee844fd9805.md)

## Rule

- **Rule:**
  ```text
  Cache tests must assert that after f(1) is cached the store size stays constant on a second f(1), and that calling outlines.clear_cache() then f(1) increases the store size by one.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:**
  ```text
  When modifying or extending cache tests that exercise caching and clear_cache behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2ab16761c61a7616c2183995.md)

## Rule

- **Rule:** Cache tests must exercise caching for tuple return values by decorating a zero-argument function returning a tuple.
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** When adding or modifying a cache test that exercises caching for non-scalar return values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b5732a4a7babd5b4070d356.md)

## Rule

- **Rule:**
  ```text
  Cache tests must use the test_cache decorator around mocked calls to assert cache behavior.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** When modifying cache tests that assert caching around a mocked call
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-995718fd20597205cae01481.md)
