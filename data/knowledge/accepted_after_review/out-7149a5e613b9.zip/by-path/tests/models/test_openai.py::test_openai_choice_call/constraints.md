# Constraints for `tests/models/test_openai.py::test_openai_choice_call`

## Rule

- **Rule:**
  ```text
  OpenAI model tests must use the patched_openai context manager to patch outlines.models.openai.generate_chat to return (completion, 1, 2) and construct an OpenAI model with a MagicMock AsyncOpenAI client and OpenAIConfig(max_tokens=10, temperature=0.5, n=2, stop=['.']).
  ```
- **Applies to:**
  - `tests/models/test_openai.py::test_openai_choice_call`
- **Condition:** When modifying or adding OpenAI model test harness setup.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8aa771d84693739c6aa3ad55.md)
