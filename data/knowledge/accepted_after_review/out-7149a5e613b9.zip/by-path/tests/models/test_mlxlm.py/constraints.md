# Constraints for `tests/models/test_mlxlm.py`

## Rule

- **Rule:** Tests for the MLX model must gate execution on both MLX import availability and Apple Silicon hardware availability, skipping with a reason when unavailable, and must assert NotImplementedError for batch inference and beam search.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying MLX model tests that require MLX runtime or exercise unsupported capabilities
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-14fe27a7a4c7c0d3e4774141.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise MLX-backed models must be gated behind a HAS_MLX skipif with the reason 'MLX tests require Apple Silicon', so they only run where MLX is installed on Apple Silicon.
  ```
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying tests that exercise MLX-backed model or tokenizer behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-82d704aa32d1d9cb65721d31.md)

## Rule

- **Rule:** Tests for the MLX model must assert that concatenating streamed tokens equals the output of generate for the same prompt and parameters, establishing stream/generate equivalence.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying MLX streaming tests that compare streamed output to generate output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-876c0d92fc369f66b0e78389.md)
