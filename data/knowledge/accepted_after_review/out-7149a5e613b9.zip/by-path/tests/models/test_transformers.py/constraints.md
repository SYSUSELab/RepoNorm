# Constraints for `tests/models/test_transformers.py`

## Rule

- **Rule:** Tests for TransformerTokenizer must assert that equality and hashing are based on the wrapped HF tokenizer state, so tokenizers wrapping the same HF tokenizer are equal and hash-equal, while one wrapping a modified HF tokenizer is unequal and hash-unequal.
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** When adding or modifying tests for TransformerTokenizer equality or hashing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-091271923c7cdcb24cbd71bb.md)

## Rule

- **Rule:**
  ```text
  Tests for the transformers model must assert that the model call returns logits as a 2-D torch.FloatTensor with shape[0] equal to batch size and a kv_cache whose length equals config.n_layer with per-layer key tensor shape[1]==config.n_head, and that TransformerTokenizer.encode returns 2-D torch.LongTensor token_ids and attention_mask with matching shapes and left padding.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when adding or modifying transformers model or tokenizer tests that assert output tensor shapes and padding behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-158af57160f10f29b8519fee.md)

## Rule

- **Rule:**
  ```text
  When both an explicit device argument and a model_kwargs device_map are provided to transformers(), the explicit device argument must take precedence, leaving the model on the requested device.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:**
  ```text
  when modifying transformers() device selection or model_kwargs handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7414888eb6e36ea5f03d56d2.md)

## Rule

- **Rule:**
  ```text
  Tests for the transformers model must use the tiny random GPTJ causal LM model identifier as TEST_MODEL for stable tokenizer/model tests.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** When adding or modifying tests that need a small stable transformers model.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a87c08f2592c04fccf1c44be.md)

## Rule

- **Rule:**
  ```text
  Tests for the transformers model must supply 2-D token tensors; passing 3-D input_ids raises AssertionError.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:**
  ```text
  When adding or modifying tests that pass input_ids to the transformers model.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dbb920fe39c671ab2c756c1a.md)
