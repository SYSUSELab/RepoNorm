# Constraints for `tests/test_grammars.py`

## Rule

- **Rule:**
  ```text
  Grammar tests must use a mock tokenizer whose decode maps token ids through inverse_vocabulary, asserting a one-to-one token-id-to-string mapping.
  ```
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:** when adding or modifying grammar tests that need token decoding
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-49080b147d59a59a000e060d.md)

## Rule

- **Rule:**
  ```text
  Grammar tests must use a mock tokenizer whose fixed vocabulary maps specific tokens to ids with a defined eos_token_id.
  ```
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:** When modifying grammar tests that depend on tokenizer vocabulary or eos token id
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f6745ac30f713a5a0f9873f7.md)

## Rule

- **Rule:** Grammar module tests must parametrize over grammars.json and grammars.arithmetic and construct a CFGGuide from an inline lark grammar string with a MockTokenizer, asserting the result is a CFGGuide.
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:** When modifying or extending grammar module tests that exercise CFGGuide construction from grammar sources.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f83a89af086edca3cd3a4410.md)

## Rule

- **Rule:**
  ```text
  Test tokenizer helpers must expose inverse_vocabulary as a property computed by inverting self.vocabulary, establishing that test tokenizers provide a vocabulary mapping whose keys are tokens and values are ids.
  ```
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:** when adding or modifying test tokenizer helpers that provide a vocabulary mapping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ffe17f2e036c154eb82ea8c3.md)
