# Constraints for `tests/test_samplers.py`

## Rule

- **Rule:**
  ```text
  Sampler tests must verify that GreedySampler returns next_token_ids, ancestors, and weights where weights equal the log-probability of the selected token, with sampling_params for greedy being sampler='greedy', num_samples=1, top_p=None, top_k=None, temperature=0.0.
  ```
- **Applies to:**
  - `tests/test_samplers.py`
- **Condition:** When modifying or extending sampler tests that exercise greedy sampling behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-241ed834a041bc1eec5932cf.md)

## Rule

- **Rule:**
  ```text
  Tests for the samplers module must import the public sampler API surface: BeamSearchSampler, GreedySampler, MultinomialSampler, beam_search, greedy, keep_top_k_logits, keep_top_p_logits, multinomial, and rescale_logits.
  ```
- **Applies to:**
  - `tests/test_samplers.py`
- **Condition:** when adding or modifying sampler tests that import or reference the public sampler API
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-62f8c9219d8853964760dbe6.md)

## Rule

- **Rule:**
  ```text
  Sampler test helpers must compute log-probabilities by applying log_softmax over the last dimension, establishing the log-probability convention used by sampler tests.
  ```
- **Applies to:**
  - `tests/test_samplers.py`
- **Condition:** When modifying or adding sampler test helpers that compute log-probabilities.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f69de6a92933f31c85694872.md)

## Rule

- **Rule:**
  ```text
  Tests for BeamSearchSampler must assert that with one beam the sampler reduces to greedy search, that initial equal logits produce different initial samples, and that sampling_params expose sampler='beam_search', num_samples=beams, and default top_p/top_k/temperature.
  ```
- **Applies to:**
  - `tests/test_samplers.py`
- **Condition:**
  ```text
  when adding or modifying tests for BeamSearchSampler behavior or its sampling_params
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fb1dd35c30701e9ed76f86b6.md)
