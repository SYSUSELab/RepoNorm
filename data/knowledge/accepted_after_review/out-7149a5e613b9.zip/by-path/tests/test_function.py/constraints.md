# Constraints for `tests/test_function.py`

## Rule

- **Rule:** Function tests must define prompt templates via outlines.prompt applied to a function whose docstring is a Jinja-style template.
- **Applies to:**
  - `tests/test_function.py`
- **Condition:** When modifying or adding function tests that define prompt templates.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-93cd449cb19c94660825152a.md)

## Rule

- **Rule:**
  ```text
  Tests for extract_function_from_file must assert that an AttributeError matching 'Could not find' is raised when the requested function name is absent from the file content.
  ```
- **Applies to:**
  - `tests/test_function.py`
- **Condition:**
  ```text
  when adding or modifying tests for extract_function_from_file error behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-abebd5069ce5f11f446e29b8.md)

## Rule

- **Rule:**
  ```text
  Tests for the function extraction utility must assert that extract_function_from_file on source defining an outlines.Function returns an object whose type string is exactly `<class 'outlines.function.Function'>`, preserving the Function class identity rather than a wrapper or subclass.
  ```
- **Applies to:**
  - `tests/test_function.py`
- **Condition:**
  ```text
  When modifying or adding tests for extract_function_from_file that check the returned object's type.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d56e9cfac80d123703588f81.md)
