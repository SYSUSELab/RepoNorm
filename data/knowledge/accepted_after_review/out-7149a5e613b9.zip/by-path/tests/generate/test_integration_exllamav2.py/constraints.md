# Constraints for `tests/generate/test_integration_exllamav2.py`

## Rule

- **Rule:** model.stream yields str tokens for both a single string prompt and a list-of-strings prompt, documenting the streaming output contract across prompt types.
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When modifying model.stream behavior or the streaming output contract exercised by test_model_stream_prompt_types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-01b69a8edbc446c398abe7e3.md)

## Rule

- **Rule:**
  ```text
  Backend integration tests for output reformatting must assert the exact regrouping behavior: a single string is returned unchanged, a one-element list is unwrapped to its element, and with num_samples=2 a flat list is regrouped into pairs.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When adding or modifying a backend integration test that exercises reformat_output with varying sample counts.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-42d22cf411d2eb4f8878b8fb.md)

## Rule

- **Rule:**
  ```text
  test_exl2_max_chunk_size constructs an exl2 model with cache_q4=True, paged=False, and max_chunk_size=128, then asserts the result is an ExLlamaV2Model, documenting supported construction parameters.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When modifying exl2 model construction parameters exercised by test_exl2_max_chunk_size.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bccd0d3c8f2898a6f1c8de25.md)

## Rule

- **Rule:**
  ```text
  Integration tests for the exllamav2 backend must keep the session-scoped model_exllamav2 fixture loading an exl2 model with cache_q4=True and paged=False, and must continue to assert that model.generate returns a str for both string and list stop_at forms and a list whose first element is a str when SamplingParameters('multinomial', 2) is used.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When modifying exllamav2 integration tests or the exllamav2 fixture, preserve the cache_q4=True/paged=False loading convention and the stop_at and multisampling output-shape assertions.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bcd4777bcc86748d2cbb8942.md)

## Rule

- **Rule:**
  ```text
  ExLlamaV2 integration tests must verify that models expose generator, tokenizer, and max_seq_len attributes (with max_seq_len an int), and must treat both ImportError and AssertionError from the flash_attn import as flash attention being unavailable.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:** When modifying or extending ExLlamaV2 backend integration tests that check model attributes or probe flash attention availability.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e3a5422aad943bbb7c7a5162.md)

## Rule

- **Rule:**
  ```text
  Backend integration tests for paged attention must be skipped unless flash-attn is available and must construct the model with cache_q4=True and paged=True, asserting the expected model type.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:** When adding or modifying a backend integration test that exercises paged attention.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e42f36e1fc353bd81dc746ac.md)

## Rule

- **Rule:** Backend integration tests for streaming generation must assert that iterating the generator yields only str tokens, establishing the streaming output type contract for that backend.
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:** When adding or modifying a backend integration test that iterates a streaming generation generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-efa06fb75827d50767294e8b.md)
