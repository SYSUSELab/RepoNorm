# Constraints for `tests/generate/test_integration_transformers_vision.py`

## Rule

- **Rule:**
  ```text
  Vision integration tests must load a small CPU-friendly model via the transformers_vision fixture (e.g. trl-internal-testing/tiny-LlavaForConditionalGeneration) and assert constrained choice generation returns a string contained in the provided choices list.
  ```
- **Applies to:**
  - `tests/generate/test_integration_transformers_vision.py`
- **Condition:** when adding or modifying vision integration tests that verify constrained choice generation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6404be66ee6a73b824fffc98.md)

## Rule

- **Rule:**
  ```text
  Vision integration tests must use the img_from_url helper that downloads an image, wraps it in BytesIO, and converts it to RGB, establishing the expected image input format for vision tests.
  ```
- **Applies to:**
  - `tests/generate/test_integration_transformers_vision.py`
- **Condition:** When modifying or adding vision integration tests that need to supply image inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa69b5b714e8f8cfdcdb849e.md)

## Rule

- **Rule:** Tests that exercise multi-image text generation must preserve the contract that when the number of image tags equals the number of supplied images, generation succeeds and returns a string.
- **Applies to:**
  - `tests/generate/test_integration_transformers_vision.py`
- **Condition:** When modifying or extending multi-image text generation tests, preserve the assertion that matching image-tag and image counts yield a successful string result.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f0808c3016b03bab5437abff.md)
