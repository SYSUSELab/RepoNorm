# Constraints for `tests/generate/test_generator.py`

## Rule

- **Rule:** Generator tests must use local test doubles (e.g. MockModel, MockFSM) for model and FSM dependencies rather than real providers, and must verify that SequenceGenerator.stream yields the generated sequence then raises StopIteration.
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:** when adding or modifying generator tests that exercise streaming or FSM behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-075cf22def3ff74b950256e7.md)

## Rule

- **Rule:**
  ```text
  Tests for bias_logits must assert that it sets logits at indices not listed in indices_to_mask to -math.inf while preserving listed indices, across single- and multi-row tensors.
  ```
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:**
  ```text
  when adding or modifying tests for bias_logits masking behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-53c7b86558d2fd1ecc18abe0.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise batched generation must keep the per-row batching contract: sequence_generator over a 2-row token tensor yields one result per row with per-row sampled tokens appended, and get_allowed_tokens returns one allowed-token list per FSM in the batch.
  ```
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:**
  ```text
  When modifying or extending batched generation tests in tests/generate/test_generator.py, preserve the per-row output shape for sequence_generator and get_allowed_tokens.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-630a6d03041e7bbab42f7796.md)

## Rule

- **Rule:**
  ```text
  Generator tests must preserve the per-sequence FSM state mapping: get_next_fsm_states returns one next state per FSM for both single and two-FSM inputs.
  ```
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:**
  ```text
  when modifying get_next_fsm_states or its generator test coverage
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7d1b66ad7f9abdf55a0e9125.md)

## Rule

- **Rule:**
  ```text
  Generator tests must use a MockFSM test double to drive sequence_generator tests without a real FSM, and its get_next_state helper advances state by one for any next token ids.
  ```
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:** When modifying or adding generator tests that need an FSM test double.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a7b41b3aea75c030934efb37.md)

## Rule

- **Rule:** Sequence generator tests must preserve the iteration contract: successive next() calls append one token id per step while logits remain the initial tensor, and StopIteration is raised after the sequence completes.
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:** When modifying sequence generator tests or the generator iteration behavior, preserve the per-step token append, unchanged logits, and StopIteration-on-completion assertions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a9277045e750e4e2e52ef369.md)

## Rule

- **Rule:** Generator tests must use the MockTokenizer abstraction rather than a real model tokenizer, with encode producing a fixed two-sequence tensor with all-ones attention masks.
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:** when modifying generator tests that rely on the mock tokenizer abstraction or its fixed batch shape
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d8c85642ea1e4732d6b583dc.md)

## Rule

- **Rule:** Test-local FSM final-state predicates must treat state 0 as non-final and every other state as final.
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:** when modifying test-local FSM final-state predicates used by generator tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fa32410d4082985acee5f05e.md)
