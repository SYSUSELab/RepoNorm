# Constraints for `tests/generate/test_generate.py`

## Rule

- **Rule:** Generator tests must use a session-scoped fixture that loads a tiny random GPT-2 transformers model on CPU, a stable convention for fast model tests without GPU.
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:** When modifying or adding generator tests that need a transformers model fixture.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1431b89ea3eced71411cea82.md)

## Rule

- **Rule:** Batch generation tests with regex constraints must assert that batch generation with multiple inputs maintains FSM order and that every output fully matches the regex pattern.
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:** When adding or modifying a batch generation test that exercises regex-constrained generation with multiple inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3e4fcc99605ef0604d15a489.md)

## Rule

- **Rule:**
  ```text
  Text generation tests must parametrize over samplers and all model fixtures and wrap generation in enforce_not_implemented, encoding which sampler/model combinations are expected to be unsupported.
  ```
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  When modifying text generation tests or adding sampler/model combinations, preserve the enforce_not_implemented wrapper that encodes expected unsupported combinations.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5238e0adca71a055a05f3c92.md)

## Rule

- **Rule:**
  ```text
  The get_inputs helper selects prompts by fixture name and, for fixtures ending in '_vision', returns a dict with 'prompts' and 'media' keys, encoding the multimodal input convention used across generation tests.
  ```
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  When modifying the get_inputs helper or adding new generation-test fixtures that require multimodal inputs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5d1d00a06836a93685ea8969.md)

## Rule

- **Rule:**
  ```text
  The regex batch-stream test asserts that streaming generation for a batch of two sequences maintains per-sequence order: outputs[0] accumulates tokens[0] and outputs[1] accumulates tokens[1], and each accumulated output must fully match the regex pattern.
  ```
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  When modifying batch streaming generation behavior or per-sequence ordering exercised by test_generate_regex_batch_stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-794e6abef0c271dbaf5bec63.md)

## Rule

- **Rule:**
  ```text
  The session-scoped model_mlxlm_phi3 fixture must continue to load the external 'mlx-community/Phi-3-mini-4k-instruct-4bit' model, so tests depending on it require that model to be available.
  ```
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  When modifying or extending the model_mlxlm_phi3 fixture, preserve the external model identifier 'mlx-community/Phi-3-mini-4k-instruct-4bit' and its session scope.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c076142eab1b31dd12c5b5e5.md)

## Rule

- **Rule:**
  ```text
  The enforce_not_implemented helper must preserve the NOT_IMPLEMENTED task-to-model mapping and assert NotImplementedError for those combinations, so unsupported task/model pairs remain explicitly documented.
  ```
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  When modifying or extending the enforce_not_implemented helper or its NOT_IMPLEMENTED mapping, preserve the documented unsupported task/model combinations and their NotImplementedError assertions.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c2314d51e0a7e915a156cf16.md)

## Rule

- **Rule:** Regex test patterns must include a spaced pattern to exercise tokenizer whitespace prefix handling, an alternation to exercise consistent sequence handling during batch, and an email regex.
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  when modifying REGEX_PATTERNS or the regex edge cases exercised by generation tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d65a2a3b127b79899057c555.md)
