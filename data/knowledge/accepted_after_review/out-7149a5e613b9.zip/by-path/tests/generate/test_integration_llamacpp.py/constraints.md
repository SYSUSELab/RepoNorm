# Constraints for `tests/generate/test_integration_llamacpp.py`

## Rule

- **Rule:**
  ```text
  llama.cpp integration tests must pass frequency_penalty and presence_penalty plus seed and max_tokens to a text generator and assert the result is a str, documenting accepted generation kwargs for llama.cpp.
  ```
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** When modifying or extending llama.cpp integration tests that exercise sampling parameter passthrough.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0599ae7bfe5bd1fa69e533da.md)

## Rule

- **Rule:** Multinomial sampling tests must exercise the supported sampler parameter combinations and assert that generate.text returns a string.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** When modifying multinomial sampling tests for the llamacpp backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-22c176bc45aed4f8bea1308e.md)

## Rule

- **Rule:** Backend integration tests for multi-sample generation must assert that requesting more than one sample raises NotImplementedError with a message indicating multi-sample generation is unsupported for that backend.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** When adding or modifying a backend integration test that exercises multinomial sampling with more than one sample.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2ef09fe24a3866240461e5be.md)

## Rule

- **Rule:** The llamacpp batch inference test must remain marked xfail because batch inference is not available in llama-cpp-python, documenting a known provider capability boundary.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** When modifying llamacpp integration tests or the batch inference path, preserve the xfail marking that documents the llama-cpp-python batch inference limitation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-30d6a03d71170f03e7bf1e3f.md)

## Rule

- **Rule:** Backend integration tests for text stop sequences must assert that the generated output contains no occurrence of the stop string, verifying stop-token enforcement.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:**
  ```text
  When adding or modifying a backend integration test that supplies a stop_at or stop string to generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-49d1d6f7868f08dbe63ef181.md)

## Rule

- **Rule:** The RegexGuide caching test must remain skipped with the note that guide caching was temporarily turned off, and when re-enabled must assert cache hit/miss statistics and that different models produce different state-to-token maps.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** When modifying or re-enabling the RegexGuide caching test, preserve the skip note about temporarily disabled guide caching and the cache hit/miss and per-model state-to-token map assertions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4f582ad5548c3c98ebbc81d4.md)

## Rule

- **Rule:**
  ```text
  The llama.cpp integration test module must define TEST_MODEL as a local GGUF path './llama-test-model/TinyMistral-248M-v2-Instruct.Q4_K_M.gguf', documenting the expected local model artifact for llamacpp integration tests.
  ```
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** when adding or modifying llama.cpp integration tests that reference the local test model artifact
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5ae37fa01bee2286ddfc99fe.md)

## Rule

- **Rule:** Tests that exercise the llama.cpp backend must expect beam-search generation to raise NotImplementedError, because that backend does not support beam search.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** when adding or modifying llama.cpp backend integration tests that exercise beam-search sampling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-66b36b4c404d1428291bee86.md)

## Rule

- **Rule:**
  ```text
  llama.cpp streaming tests must preserve the streaming output contract: the stream yields at most max_tokens tokens and the first token is a str.
  ```
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** when modifying the llama.cpp streaming API test or the streaming output contract it pins
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6cad467788fa86c8ee9b28ad.md)

## Rule

- **Rule:** Integration tests that assert typed generation output must assert the returned value is an instance of the requested Python type (e.g. datetime.date, datetime.datetime, datetime.time) rather than comparing string representations.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
  - `tests/generate/test_integration_vllm.py`
- **Condition:** when adding or modifying an integration test that verifies generate.format output for a Python type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d9cb4efcea3bfd73b9ba5016.md)

## Rule

- **Rule:** Backend integration tests for constrained generation must assert that the returned value is exactly one of the supplied choices (equality against the choice set), not merely a string that contains a choice.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
  - `tests/generate/test_integration_vllm.py`
- **Condition:** When adding or modifying a backend integration test that exercises generate.choice with a set of allowed choices.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fe1db1c9d02a78752f0e2c3a.md)
