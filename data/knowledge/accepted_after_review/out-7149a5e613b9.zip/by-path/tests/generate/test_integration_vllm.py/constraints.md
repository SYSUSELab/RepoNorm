# Constraints for `tests/generate/test_integration_vllm.py`

## Rule

- **Rule:** Integration tests for the vLLM backend must assert that generate.text with a greedy sampler returns a str, and that generate.format(model, bool) returns a bool instance, preserving the minimal output-type contract for vLLM text and boolean generation.
- **Applies to:**
  - `tests/generate/test_integration_vllm.py`
- **Condition:** When modifying or extending vLLM backend integration tests that exercise text or boolean generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3e51a6481a0b06558e03623a.md)

## Rule

- **Rule:** Integration tests for typed generation must preserve the typed output contract: integer generation returns an actual int (not a string) and int(sequence) succeeds, and JSON function-enum generation returns a dict of length 2 with keys within the allowed set and int-or-float values.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
  - `tests/generate/test_integration_vllm.py`
- **Condition:** When modifying or extending typed-generation integration tests, preserve assertions that integer output is an actual int and JSON function-enum output has the documented dict shape.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5bedbb63e7b412966d6a03d6.md)

## Rule

- **Rule:** Tests for the vLLM generation API must assert that repeated calls with the same seed produce identical outputs and that a list of prompts yields a list of the same length.
- **Applies to:**
  - `tests/generate/test_integration_vllm.py`
- **Condition:** when adding or modifying vLLM generation API integration tests that check determinism or batch prompt handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a83edb0ddfd73b2e83a4f3d1.md)

## Rule

- **Rule:**
  ```text
  Integration tests for vLLM-backed generation must assert beam search behavior: beam_search(1) output equals greedy output, and beam_search(2) returns a result of length 2 with distinct elements.
  ```
- **Applies to:**
  - `tests/generate/test_integration_vllm.py`
- **Condition:** When modifying or adding vLLM integration tests that exercise beam search sampling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c72abe4b226dd54d61e2ca9f.md)

## Rule

- **Rule:** Integration tests that assert typed generation output must assert the returned value is an instance of the requested Python type (e.g. datetime.date, datetime.datetime, datetime.time) rather than comparing string representations.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
  - `tests/generate/test_integration_vllm.py`
- **Condition:** when adding or modifying an integration test that verifies generate.format output for a Python type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d9cb4efcea3bfd73b9ba5016.md)

## Rule

- **Rule:** Backend integration tests for constrained generation must assert that the returned value is exactly one of the supplied choices (equality against the choice set), not merely a string that contains a choice.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
  - `tests/generate/test_integration_vllm.py`
- **Condition:** When adding or modifying a backend integration test that exercises generate.choice with a set of allowed choices.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fe1db1c9d02a78752f0e2c3a.md)
