# Constraints for `tests/generate/test_api.py`

## Rule

- **Rule:** Tests for vision sequence generator input validation must assert TypeError for mismatched prompt/media shapes such as a single prompt with a list of images or nested list mismatches, defining accepted vision input shapes.
- **Applies to:**
  - `tests/generate/test_api.py`
- **Condition:** when adding or modifying tests for vision sequence generator input shape validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b7aa7871b60fffa2e05e7647.md)
