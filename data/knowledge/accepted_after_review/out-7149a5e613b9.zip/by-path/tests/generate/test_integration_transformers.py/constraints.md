# Constraints for `tests/generate/test_integration_transformers.py`

## Rule

- **Rule:** Integration tests for transformers-backed generation must assert the streaming batched-sampling shape: streaming with multinomial(samples=2) over a 2-prompt batch yields a list of 2 lists each of length 2.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** When modifying or adding transformers integration tests that exercise streaming generation with multinomial sampling over a batch of prompts.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-060b426d7628944d24ece8f5.md)

## Rule

- **Rule:** Integration tests for the transformers backend must preserve the batched integer-format output shape: passing a two-element prompt list to generate.format(model, int) returns a list of length 2 with int elements.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** When modifying transformers integration tests or the integer-format generation path, preserve the batched output-shape assertion (list of length 2 with int elements).
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-191b1ff0f13deeddfc9dc8f1.md)

## Rule

- **Rule:** Tests for the transformers integration must assert that generate.format(model, bool) returns a non-empty bool, verifying format-constrained generation produces the requested Python type.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** when adding or modifying transformers integration tests that exercise format-constrained generation with a Python type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1f9b8a9f3dca3734b759c463.md)

## Rule

- **Rule:** Tests for the transformers JSON batch generation must assert that passing a list of prompts returns a list of BaseModel instances, one per prompt.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** when adding or modifying transformers integration tests that exercise JSON batch generation with a list of prompts
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2f2439720aa7821bd18ba51b.md)

## Rule

- **Rule:** JSON generation tests must preserve the documented output shape: batch plus multiple samples yields a nested list of parsed model instances, and union/anyOf handling remains a known limitation tracked by xfail.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** When modifying JSON generation tests that cover batch sampling or union/anyOf schemas
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-344aa8d7ffce3b3eb45bd9b6.md)

## Rule

- **Rule:** Integration tests must preserve the ability to use enum members as callable partials in JSON function schemas.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** When modifying JSON function schema tests that define enums with callable members
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-38b27b0b62d8c002aa29233e.md)

## Rule

- **Rule:**
  ```text
  Backend integration tests for reduced vocabulary caching must assert that two tokenizer instances wrapping the same HF tokenizer are distinct objects, yet reduced_vocabulary returns the same cached object for both.
  ```
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:**
  ```text
  When adding or modifying a backend integration test that exercises reduced_vocabulary caching across tokenizer instances.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d2691f88beabea976925532.md)

## Rule

- **Rule:**
  ```text
  Integration tests for transformers-backed generation must assert the JSON-schema-constrained output contract: generate.json with a pydantic model returns a BaseModel instance whose fields match the model's declared types (e.g. user_id int, value list of int/float), and with an enum-typed field the returned value is one of the declared enum members.
  ```
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** When modifying or adding transformers integration tests that exercise generate.json with pydantic models or enum-typed fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5578f02625a8f61298fbc716.md)

## Rule

- **Rule:**
  ```text
  JSON generation tests must honor the whitespace_pattern argument so that generated output contains no newline characters when the pattern forbids them.
  ```
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:**
  ```text
  When modifying JSON generation tests that pass a whitespace_pattern argument
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-56f2aa2f3def2f4045ce1038.md)

## Rule

- **Rule:**
  ```text
  Integration tests for transformers generation must keep the pad-token normalization contract: a tiny random XLMRobertaXL causal LM loaded on device="meta" must expose tokenizer.pad_token_id == 1 and pad_token == "<pad>".
  ```
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** when modifying the transformers pad-token integration test or the pad-token normalization it pins
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-598098337316fd3dd4bb6eca.md)

## Rule

- **Rule:** Integration tests for typed generation must preserve the typed output contract: integer generation returns an actual int (not a string) and int(sequence) succeeds, and JSON function-enum generation returns a dict of length 2 with keys within the allowed set and int-or-float values.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
  - `tests/generate/test_integration_vllm.py`
- **Condition:** When modifying or extending typed-generation integration tests, preserve assertions that integer output is an actual int and JSON function-enum output has the documented dict shape.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5bedbb63e7b412966d6a03d6.md)

## Rule

- **Rule:**
  ```text
  The User model fixture in transformers integration tests must combine an int field and a List[float] field to exercise nested list schema generation.
  ```
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** When modifying or extending the transformers integration test fixture that exercises nested list schema generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a35b0228372deec593db1d29.md)

## Rule

- **Rule:**
  ```text
  The transformers integration text test asserts the generated sequence excludes the tokenizer eos_token, supports stop_at as a string and as a list, and returns a list of length 2 when given a list of prompts.
  ```
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:**
  ```text
  When modifying text generation behavior or stop_at handling exercised by test_transformers_integration_text.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc04f2c6619755e00281f4dd.md)

## Rule

- **Rule:** JSON generation with an integer enum returns a BaseModel whose enum-constrained field is an int restricted to the enum's integer values.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:**
  ```text
  When modifying integer-enum JSON generation behavior exercised by test_transformers_json_int_enum.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d9eec211486b92f1b2134f84.md)

## Rule

- **Rule:** Integration tests for transformers-backed generation must assert that generate.json with a function schema returns a dict whose unpacked kwargs satisfy the target function's return type, i.e. the JSON output is directly callable as the target function.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** When modifying or adding transformers integration tests that exercise generate.json with a function schema.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ef7afedda00e44034a704571.md)
