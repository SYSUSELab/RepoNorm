# Constraints for `tests`

## Rule

- **Rule:**
  ```text
  Coverage reporting omits files matching "tests/*" from coverage measurement.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-622392e3c513c915427738fc.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits outlines/_version.py and tests/* from coverage reporting.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9e6a0c06a8d05cf054847eae.md)

## Rule

- **Rule:**
  ```text
  pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ea81df6e07518130dfce8261.md)
