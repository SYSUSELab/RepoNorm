# Constraints for `tests/processors/test_base_processor.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise multiple array backends must build a shared `arrays` mapping keyed by backend name (list, np, jax, torch, optionally mlx) with equivalent arrays, and assert that processors preserve the input array type.
  ```
- **Applies to:**
  - `tests/processors/test_base_processor.py`
- **Condition:** When adding or modifying processor tests that run across multiple array backends.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1e29c6505f37ce93948fd30f.md)

## Rule

- **Rule:**
  ```text
  Processor tests must assert that _from_torch returns an instance of the requested array type with values numerically close to the source torch tensor.
  ```
- **Applies to:**
  - `tests/processors/test_base_processor.py`
- **Condition:** When modifying or adding cross-framework array conversion tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-25782e23e04bb028117cadc5.md)

## Rule

- **Rule:**
  ```text
  Tests for logits processors must use a test processor whose process_logits returns logits multiplied by 2, establishing the observable contract used by processor tests.
  ```
- **Applies to:**
  - `tests/processors/test_base_processor.py`
- **Condition:** when adding or modifying logits processor tests that need a mock processor
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-63c535df39abb0d8354d7440.md)

## Rule

- **Rule:**
  ```text
  The _to_torch processor conversion must convert supported array types to a float32 torch tensor, as verified by parametrized tests over the supported array keys.
  ```
- **Applies to:**
  - `tests/processors/test_base_processor.py`
- **Condition:**
  ```text
  when modifying the _to_torch conversion or adding supported array types
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d455e3bdf7689f12c16bc798.md)
