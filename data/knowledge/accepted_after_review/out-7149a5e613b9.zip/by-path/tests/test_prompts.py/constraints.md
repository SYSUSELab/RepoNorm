# Constraints for `tests/test_prompts.py`

## Rule

- **Rule:**
  ```text
  Prompt.from_file produces a prompt with signature None, and rendering with examples and a question yields a specific format: a header line, '- Q:'/'- A:' example lines, then 'Now please answer the following question:' and 'Q:'/'A:' lines.
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:**
  ```text
  When modifying Prompt.from_file or the prompt rendering format exercised by test_prompt_from_file.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-00914edc5831318fbcf5a409.md)

## Rule

- **Rule:** Prompt templates must support the schema filter for rendering a model's schema inside prompt text.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When modifying prompt templates that render a model schema inside prompt text
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0d73753d164cd8888a83fbef.md)

## Rule

- **Rule:** Prompt rendering must preserve escaped line-continuation behavior: render collapses escaped line continuations into single spaces while preserving indentation on subsequent lines and returning to normal after the escaped block.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** when modifying render's escaped line-continuation handling or its prompt rendering tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-12cff95d352304628bea5897.md)

## Rule

- **Rule:** Prompt tests must define decorated templates using the schema filter on a model argument, showing prompt templates can render a model's schema.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** when adding or modifying prompt tests that exercise schema rendering filters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-45c6a6eaa3e5b5d8e9f8649f.md)

## Rule

- **Rule:**
  ```text
  The temp_prompt_file fixture writes base_template.txt, include.txt, and prompt.txt into a temp dir, exercising Jinja extends, block, include, and for-loop constructs in prompt templates.
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:**
  ```text
  When modifying the temp_prompt_file fixture or the Jinja template constructs it exercises.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-73d41bd750b3d3adbf645f90.md)

## Rule

- **Rule:**
  ```text
  Prompt.from_str on a template string must yield a prompt with signature None and render Jinja-style variables, as asserted by prompt(name="World") == "Hello, World!".
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:**
  ```text
  When modifying or extending prompt tests that exercise Prompt.from_str and Jinja-style variable rendering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8d29c994888ab1a742f921a5.md)

## Rule

- **Rule:**
  ```text
  Prompt tests must define decorated templates using the name and signature filters ({{fn|name}}: {{fn|signature}}) to document available prompt filters for function introspection.
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** when adding or modifying prompt tests that exercise function introspection filters, specifically the name and signature filters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-931a717b3f15484256c85be8.md)

## Rule

- **Rule:** The render function must strip leading and trailing blank lines and common indentation from templates while preserving relative indentation of nested lines and a trailing newline when the template ends with a blank line.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When modifying or extending prompt rendering tests, preserve the whitespace contract: strip leading/trailing blank lines and common indentation, keep relative nested indentation, and keep a trailing newline for templates ending with a blank line.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-96398e1145c5306132173b22.md)

## Rule

- **Rule:** Tests for prompt functionality must assert that calling prompt functionality without a template raises TypeError matching "template", establishing the expected error contract for missing templates.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When modifying or adding tests for prompt functionality that exercise the missing-template error path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a191f7e2f944288a3e21a8d0.md)

## Rule

- **Rule:** Prompt functions decorated with @outlines.prompt are ordinary Python functions whose docstring is a template using {{var}} placeholders, and default argument values are usable in the template.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When adding or modifying a prompt function test that exercises template rendering with default arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bf59d09e0b3499260c66a65c.md)

## Rule

- **Rule:**
  ```text
  Prompt template tests must document the args template filter by defining an @outlines.prompt function whose body uses the 'args' filter on a callable ({{ fn | args }}), and must exercise the empty-template edge case with an @outlines.prompt function whose body is pass.
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When modifying or extending prompt template tests that exercise template filters or edge cases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c49154f97e9ea243ec6fb6f2.md)

## Rule

- **Rule:** Prompt template tests must assert that a for-loop without whitespace control leaves a trailing newline, while closing with -%} strips the following newline, and the same -%} behavior applies to conditionals.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When adding or modifying a prompt template test that exercises Jinja whitespace control in loops or conditionals.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c6d76c8568acf5f60daca087.md)

## Rule

- **Rule:**
  ```text
  Prompt template tests must exercise functions with type annotations including nested generics (e.g. Dict[int, List[str]]) and multi-parameter signatures with defaults, so annotation rendering handles complex typing constructs.
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** when adding or modifying prompt template tests that cover function signature rendering
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f661c93c400e6499935fd0e1.md)

## Rule

- **Rule:** Prompt template tests must preserve whitespace normalization: extra blank lines in a string template are trimmed so the rendered output ends with a single newline.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When modifying prompt template parsing or rendering tests that cover trailing whitespace
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f9aeeb22346582bd08d7fce0.md)
