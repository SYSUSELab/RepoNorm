# Constraints for `tests/test_base.py`

## Rule

- **Rule:**
  ```text
  The passthrough_args test helper must concatenate all positional string arguments and carry the docstring 'A passthrough function.', matching the docstring asserted by the vectorize tests.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  when adding or modifying the passthrough_args test helper used by vectorize tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0d6e80d887b925672550ad87.md)

## Rule

- **Rule:**
  ```text
  Tests for the vectorize decorator must preserve the documented signature semantics: '(m)->()' reduces over the mapped dimension to one output per outer element, '()->()' applies elementwise, and vectorize must preserve the wrapped function's __doc__ and __name__.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** When modifying vectorize tests or adding new vectorize signature cases, preserve the reduce-vs-elementwise signature semantics and the metadata-preservation assertions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-33ee09218ea33c60cdd0613a.md)

## Rule

- **Rule:**
  ```text
  Tests for vectorize must assert that it accepts a signature string such as (m)->(m) or ()->() and applies the wrapped function elementwise over nested input arrays, preserving the array shape in the output.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** when adding or modifying tests for vectorize signature handling and elementwise application
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-42068b5ad77882a064a1381d.md)

## Rule

- **Rule:**
  ```text
  The vectorize helper with output signature '(s)' expands each scalar result into a repeated dimension, so vectorizing a function returning a scalar over ['one','two'] yields [['one','one','one'],['two','two','two']].
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  When modifying vectorize expansion behavior or the '(s)' output-signature handling exercised by test_vectorize_expand.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6f31a19ccf7f35ed27b48c13.md)

## Rule

- **Rule:**
  ```text
  The vectorize test must preserve the broadcasting contract: scalar kwargs broadcast against list kwargs and nested list inputs broadcast elementwise, e.g. first=[["one","two"],["three","four"]] with second=["1","2"] yields [["one1","two2"],["three1","four2"]].
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** When modifying or extending vectorize broadcasting tests, preserve scalar-vs-list and nested-list elementwise broadcasting assertions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9852e0783610b156a904be1c.md)
