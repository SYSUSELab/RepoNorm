# Constraints for `tests/fsm/test_guide.py::test_cfg_ignore_directive`

## Rule

- **Rule:**
  ```text
  Guide tests must define a MockTokenizer with a fixed small vocabulary and eos_token/eos_token_id, and the decode helper must handle both nested token-id lists and flat token-id lists via inverse_vocabulary lookup.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py::test_cfg`
  - `tests/fsm/test_guide.py::test_cfg_allow_both_extend_and_shift_terminal`
  - `tests/fsm/test_guide.py::test_cfg_early_termination`
  - `tests/fsm/test_guide.py::test_cfg_ignore_directive`
  - `tests/fsm/test_guide.py::test_cfg_multitoken_terminal`
- **Condition:** When adding or modifying guide tests that need a tokenizer stub or decode helper.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bdc0f905e3cd53c244401e5c.md)
