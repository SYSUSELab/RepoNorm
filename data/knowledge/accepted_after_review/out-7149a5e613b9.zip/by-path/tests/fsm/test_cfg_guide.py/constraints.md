# Constraints for `tests/fsm/test_cfg_guide.py`

## Rule

- **Rule:**
  ```text
  CFG guide tests must use a convert_token_to_string stub that returns the token unchanged, modeling a tokenizer with no string conversion.
  ```
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:**
  ```text
  When modifying or adding convert_token_to_string stubs in CFG guide tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-10c347a8791d734e715e3cc2.md)

## Rule

- **Rule:**
  ```text
  The session-scoped tokenizer fixture in the CFG guide tests must load the real 'google/byt5-small' tokenizer via AutoTokenizer.from_pretrained, so tests depending on it require network/model availability.
  ```
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** when adding or modifying the session-scoped tokenizer fixture in the CFG guide tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-51013755a48f9eb9abde35a3.md)

## Rule

- **Rule:** CFG guide tests must use a session-scoped TransformerTokenizer fixture built from the pretrained 'gpt2' AutoTokenizer.
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** When modifying or adding tokenizer fixtures used by CFG guide tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-695269013663e5ab73fc2bbe.md)

## Rule

- **Rule:**
  ```text
  The cfg_test_inputs mapping must define named TestInputs cases (grammar, vocabulary, generated, legal_next_tokens) covering ambiguous terminals, overlapping tokens, optional/nested patterns, unicode, and ignored whitespace, with commented-out cases annotated by TODO notes about parser greediness and interegular lookaround limitations.
  ```
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:**
  ```text
  when modifying or extending the cfg_test_inputs mapping in tests/fsm/test_cfg_guide.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-83b5e96bfb1c0b69ade53fae.md)

## Rule

- **Rule:** CFG guide tests must assert that next-instruction token sets exactly cover the tokenizer-encoded sample sequence and that the final instruction includes the EOS token id.
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** When modifying CFGGuide next-instruction token coverage assertions or the grammar sample test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af96383bc06d47c0a2efb9b2.md)

## Rule

- **Rule:**
  ```text
  Guide tests must use Lark's interactive parser (parse_interactive + exhaust_lexer + feed_eof) to validate that each parametrized sample is a legal generation of its grammar, raising a descriptive Exception when the test data itself is invalid.
  ```
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** when adding or modifying CFG guide sample-validation tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-df9a84487d96852ad9acf939.md)

## Rule

- **Rule:**
  ```text
  CFG grammar sample tests must skip all tokenizers except tokenizer_character_level_byt5 and skip the arithmetic_lots_of_ops sample due to the known CFG bug.
  ```
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:**
  ```text
  when modifying or extending CFG grammar sample tests in tests/fsm/test_cfg_guide.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ef0ea9c1aa82266e8a088736.md)

## Rule

- **Rule:** CFG guide next-token tests must advance the guide state through generated tokens and compare the sorted set of returned next tokens against the expected legal tokens, mapping None to the tokenizer eos token.
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** when modifying CFG guide next-token behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f61196d10c2a29e35f629d14.md)

## Rule

- **Rule:**
  ```text
  Run the grammar sample test via `pytest -s tests/fsm/test_cfg_guide.py::test_cfg_grammar_sample -k "your_new_grammar"`.
  ```
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f9368bad1cf8b00bc8f7490b.md)
