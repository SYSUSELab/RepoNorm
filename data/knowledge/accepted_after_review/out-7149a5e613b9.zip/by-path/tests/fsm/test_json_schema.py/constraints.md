# Constraints for `tests/fsm/test_json_schema.py`

## Rule

- **Rule:** JSON schema tests must define a simple add(a, b) helper returning a + b as a callable target.
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:** When modifying or adding callable targets in JSON schema tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-630ce2ae621b7556277a659e.md)

## Rule

- **Rule:** JSON schema enum tests must exercise non-string enum members, including callables, strings, and integers, to verify schema generation handles mixed-type enums.
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:** when modifying enum handling in schema generation or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-85a137e770a7583092dd3ea5.md)

## Rule

- **Rule:**
  ```text
  JSON schema tests must define a User model combining constr(max_length=10) and constr(min_length=10) fields to exercise both length-bound constraints in schema generation.
  ```
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:** When modifying or adding JSON schema test models exercising length-bound constraints.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9d76be943f2d131c4754b631.md)

## Rule

- **Rule:**
  ```text
  Tests for schema-to-regex conversion must assert that build_regex_from_schema accepts a JSON schema string and returns a str, and must preserve declaration-order object properties with nested array item typing when converting function signatures to schemas.
  ```
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:** when modifying signature-to-schema conversion or schema-to-regex conversion behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b6447772413dfa1068bf5279.md)

## Rule

- **Rule:**
  ```text
  get_schema_from_enum must succeed for a normal enum but raise ValueError for an empty enum, with schema title equal to the enum name and oneOf length equal to the enum length.
  ```
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:**
  ```text
  when modifying or extending enum schema tests in tests/fsm/test_json_schema.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bfd3fce573afdc2f5d23b328.md)

## Rule

- **Rule:** Tests for schema generation must cover both annotated parameters and the error case where a parameter lacks a type annotation, which must raise ValueError.
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:**
  ```text
  When adding or modifying tests for get_schema_from_signature or schema generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dee769faa48c7f5b57d62dee.md)
