# Constraints for `tests/fsm/test_guide.py`

## Rule

- **Rule:** CFG guide tests must treat a state as terminable only after the full terminal match is consumed; a state that can still extend or shift terminal tokens must not report termination flags as true.
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** When modifying CFGGuide termination-flag logic or the tests that assert extend/shift terminal behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0a785b0d6cf8e778745d56d1.md)

## Rule

- **Rule:**
  ```text
  Tests for the FSM guide must assert that RegexGuide.from_regex reaches a final state and remains final on repeated tokens, that walk_fsm with full_match=True returns one accepted state per transition or an empty list when a transition is not accepted or the final state is not final, and that StopAtEOSGuide returns Generate with tokens None at start, Write with tokens [2] at final, transitions on token 2, stays at start on token 1, and reports is_final_state correctly.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
  - `tests/fsm/test_parsing.py`
- **Condition:**
  ```text
  when adding or modifying FSM guide tests that assert final-state persistence, walk_fsm acceptance semantics, or StopAtEOSGuide instruction and transition contracts
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-10d9b137b55a570b642d3182.md)

## Rule

- **Rule:**
  ```text
  Guide test helper assert_expected_tensor_ids must compare the tensor against the expected ids, not normalize both with sorted(map(int, tensor)) so the assertion compares the tensor against itself.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** When modifying or adding tensor-id assertion helpers in guide tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1201fa93ff05042b5e9fa339.md)

## Rule

- **Rule:**
  ```text
  MockTokenizer in tests/fsm/test_guide.py must use vocabulary {"{":1, "}":2, "[":3, "]":4, "eos":5}, special_tokens {"eos"}, eos_token "eos", and eos_token_id 5.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:**
  ```text
  when defining or modifying MockTokenizer in tests/fsm/test_guide.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2a90b7be522ea08506dc9553.md)

## Rule

- **Rule:**
  ```text
  Guide/CFG tests must assert that once the eos token is generated the guide state must_terminate_state and can_terminate_state are both true and eos is the only allowed next token.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** when modifying or extending CFG/guide termination tests that feed the eos token
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-323bb294f5a752ff9c805b36.md)

## Rule

- **Rule:**
  ```text
  Guide-test tokenizer doubles must implement decode by joining inverse_vocabulary lookups for nested token-id lists and returning a flat list of inverse_vocabulary values for flat token-id lists, because guide tests depend on that decode contract.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** when adding or modifying a MockTokenizer decode method in the FSM guide tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-60e6e9f66e38719abf4c20b7.md)

## Rule

- **Rule:**
  ```text
  The MockTokenizer test helper must expose inverse_vocabulary as a property computed by reversing the vocabulary mapping, and decode must handle both nested and flat token id lists using that inverse mapping.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** when modifying or extending the MockTokenizer helper used by guide tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-67b05d83d9966976b0ac9770.md)

## Rule

- **Rule:** Multi-byte regex guide tests must assert exact FSM transition maps, including EOS handling to state -1 and non-final state 0, for multi-byte character classes.
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** when modifying RegexGuide multi-byte transition behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-806eee6131429f42a925072b.md)

## Rule

- **Rule:**
  ```text
  Guide tests must use mock tokenizers whose decode handles both nested and flat token-id inputs via inverse_vocabulary, and whose inverse_vocabulary is the reverse of vocabulary.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:**
  ```text
  When modifying or adding MockTokenizer decode/inverse_vocabulary behavior in guide tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c7894048413ea04ed6596ecf.md)

## Rule

- **Rule:**
  ```text
  RegexGuide.from_regex must raise ValueError whose message contains "The vocabulary" when the regex uses a character class outside the tokenizer vocabulary, because tests assert that error text.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:**
  ```text
  when changing vocabulary validation in RegexGuide.from_regex
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c810ffcf664333021c2621e4.md)

## Rule

- **Rule:**
  ```text
  Tests for the CFG guide must assert the exact token-allowance state machine: the allowed token sets after each token and the point at which must_terminate_state/can_terminate_state become true.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** When adding or modifying tests for CFGGuide token allowance and termination behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d1dd28ff38ce35a0e824fecb.md)

## Rule

- **Rule:**
  ```text
  The FSM guide test for regex `[1-9]` must assert the exact transition map including that the EOS token transitions to state -1 and state 0 is not final, documenting expected RegexGuide state behavior.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:**
  ```text
  when adding or modifying RegexGuide transition-map assertions for regex `[1-9]`
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d952751687fc1d5e1068f0ab.md)

## Rule

- **Rule:**
  ```text
  Test tokenizer decode must handle both nested and flat token id lists: nested lists are decoded by joining inverse_vocabulary.get over each sublist, while flat lists index inverse_vocabulary directly.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:**
  ```text
  when modifying or extending test tokenizer decode implementations in tests/fsm/test_guide.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f8ddde640caa82437c9b342c.md)
