# Constraints for `tests/fsm`

## Rule

- **Rule:**
  ```text
  Tests that exercise FSM guide behavior must import guide classes (CFGGuide, Generate, RegexGuide, StopAtEOSGuide, Write) from outlines.fsm.guide, and schema-to-regex conversion must be imported from outlines_core.fsm.json_schema rather than reimplemented locally.
  ```
- **Applies to:**
  - `tests/fsm/**/*.py`
- **Condition:** when adding or modifying FSM guide tests that need guide classes or schema-to-regex conversion
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0d47f8b6f33ebcb64c37a790.md)
