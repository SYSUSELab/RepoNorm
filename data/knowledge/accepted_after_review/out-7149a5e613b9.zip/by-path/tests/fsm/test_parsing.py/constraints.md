# Constraints for `tests/fsm/test_parsing.py`

## Rule

- **Rule:**
  ```text
  Tests for the FSM guide must assert that RegexGuide.from_regex reaches a final state and remains final on repeated tokens, that walk_fsm with full_match=True returns one accepted state per transition or an empty list when a transition is not accepted or the final state is not final, and that StopAtEOSGuide returns Generate with tokens None at start, Write with tokens [2] at final, transitions on token 2, stays at start on token 1, and reports is_final_state correctly.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
  - `tests/fsm/test_parsing.py`
- **Condition:**
  ```text
  when adding or modifying FSM guide tests that assert final-state persistence, walk_fsm acceptance semantics, or StopAtEOSGuide instruction and transition contracts
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-10d9b137b55a570b642d3182.md)

## Rule

- **Rule:**
  ```text
  The FSM parsing test module must import fsm_union and walk_fsm from outlines.fsm.parsing as a temporary compatibility shim, with a TODO to remove once implemented in Outlines-Core.
  ```
- **Applies to:**
  - `tests/fsm/test_parsing.py`
- **Condition:** when modifying imports in the FSM parsing tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1179062b895610347fc4fffb.md)

## Rule

- **Rule:**
  ```text
  Partial parsing tests must assert that incomplete inputs yield a 'partial' last token with fsm_state_seq and is_not_finished, that an empty value_stack is expected for unfinished parses, and that incremental continuation via parse_from_state works, while invalid inputs raise UnexpectedToken.
  ```
- **Applies to:**
  - `tests/fsm/test_parsing.py`
- **Condition:** when modifying partial parsing behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-22690e16f1562d0a386b6284.md)

## Rule

- **Rule:**
  ```text
  FSM union tests must assert that fsm_union over interegular FSMs yields the same string enumeration as interegular's own '|' union, and that _reconstruct_fsms recovers component FSMs whose strings() match the originals.
  ```
- **Applies to:**
  - `tests/fsm/test_parsing.py`
- **Condition:** When modifying or adding FSM union consistency or reconstruction tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-24f9d38b4797442200350d11.md)

## Rule

- **Rule:**
  ```text
  PartialLark incremental parsing tests must drive the parser with parser='lalr', PartialPythonIndenter postlex, start='file_input', deterministic=True, and treat EOFError, UnexpectedToken, UnexpectedCharacters, and DedentError as expected rejection signals.
  ```
- **Applies to:**
  - `tests/fsm/test_parsing.py`
- **Condition:** When modifying or adding PartialLark incremental parsing tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4d1551929dc0bc23ab1b4818.md)

## Rule

- **Rule:**
  ```text
  The _reconstruct_fsms test helper must assert exactly one symbol per transition and must not be relied upon for reconstructing FSMs with more than one transition per symbol, as documented by its NOTE.
  ```
- **Applies to:**
  - `tests/fsm/test_parsing.py`
- **Condition:**
  ```text
  when using or modifying the _reconstruct_fsms helper in parsing tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4fdb995cf2fb20fa82d86c71.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise lark parsing must restore lark.lark.LarkOptions._defaults after the test, because lark mutates global default options.
  ```
- **Applies to:**
  - `tests/fsm/test_parsing.py`
- **Condition:** When adding or modifying tests that exercise lark parsing and may mutate global lark options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6eeaa3ce235b215182a74a24.md)
