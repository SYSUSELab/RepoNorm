# Constraints for `tests/fsm/test_cfg_guide.py::tokenizer_tiktoken_llama3`

## Rule

- **Rule:** Tests for the CFG guide must use a session-scoped fixture loading the yujiepan/llama-3-tiny-random tokenizer via AutoTokenizer to provide a small random Llama-3 tokenizer for CFG tests.
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py::tokenizer_tiktoken_llama3`
- **Condition:** when adding or modifying CFG guide tests that require a tokenizer fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-105ef86746620e5f42f55a8c.md)
