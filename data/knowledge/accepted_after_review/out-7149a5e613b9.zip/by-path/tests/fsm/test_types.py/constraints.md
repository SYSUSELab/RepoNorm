# Constraints for `tests/fsm/test_types.py`

## Rule

- **Rule:**
  ```text
  The test_python_types parametrization must map int, float, bool, datetime.date, datetime.time, and datetime.datetime to INTEGER, FLOAT, BOOLEAN, DATE, TIME, and DATETIME respectively, asserting python_types_to_regex returns the matching regex.
  ```
- **Applies to:**
  - `tests/fsm/test_types.py`
- **Condition:**
  ```text
  when adding or modifying python_types_to_regex type-mapping tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d39ecc3109aeb56ee40149d.md)
