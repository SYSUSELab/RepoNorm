# Constraints for `tests/fsm/test_guide.py::test_regex_multi_byte_llama_like`

## Rule

- **Rule:** Tests for the FSM guide must use MockTokenizer with byte-fragment vocabularies including multi-byte emoji fragments to exercise multi-token unicode handling, and must assert exact FSM state transitions for emoji-range regexes.
- **Applies to:**
  - `tests/fsm/test_guide.py::test_regex_multi_byte_gpt2_like`
  - `tests/fsm/test_guide.py::test_regex_multi_byte_llama_like`
- **Condition:** when adding or modifying FSM guide tests that exercise multi-byte unicode tokenization
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7cb3c7b00d178bd8b3f0a6f4.md)
