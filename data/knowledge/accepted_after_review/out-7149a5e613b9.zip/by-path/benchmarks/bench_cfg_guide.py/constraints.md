# Constraints for `benchmarks/bench_cfg_guide.py`

## Rule

- **Rule:**
  ```text
  Benchmark timing methods must disable caching (via cache_disabled) so measured durations reflect uncached construction/execution rather than cached results.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark timing method that constructs a guide or FSM from a schema/regex/grammar.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4ef54f6ec8eea0be236fa396.md)

## Rule

- **Rule:**
  ```text
  Guide-execution benchmarks must wrap guide construction and execution in cache_disabled() so timings and peak-memory measurements reflect raw guide work rather than cached reuse.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark that times or measures memory of guide construction or guide execution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8f4a0e4b0a16205d39c04172.md)

## Rule

- **Rule:**
  ```text
  CFG-guide benchmark parameter sets must be derived from the shared benched_grammars mapping (benched_grammars.keys()) rather than hard-coded grammar lists, so adding or removing a benched grammar automatically updates benchmark coverage.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:**
  ```text
  When adding, removing, or renaming a grammar in the shared benched_grammars mapping used by CFG-guide benchmarks.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c111425da0033953de6b0f7b.md)

## Rule

- **Rule:**
  ```text
  CFG-guide benchmarks must exercise both guide sampling paths: rejection sampling via iter_valid_token_ids over shuffled vocabulary token ids and direct sampling via get_next_instruction(state).tokens with random.choice, each followed by get_next_state.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:** When adding or modifying CFG-guide benchmark execution that simulates guide stepping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c1fcd68c611dffbcc7663628.md)

## Rule

- **Rule:**
  ```text
  Benchmark setup must resolve the target schema/grammar by name from a shared mapping and initialize the tokenizer via setup_tokenizer, so cases are keyed by name.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
- **Condition:**
  ```text
  When adding or modifying benchmark setup that selects a named schema or grammar, resolve the target by name from a shared mapping; initialize the tokenizer via setup_tokenizer only when the benchmark module imports it from the shared common helper.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d76ac918de0ae894b730e1ca.md)

## Rule

- **Rule:** Benchmark grammar fixtures must seed randomness with 42 and bench the json and arithmetic grammars from outlines.grammars.
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:** When adding or modifying CFG guide benchmark grammar fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f761891f7fcccdcfe70ff642.md)
