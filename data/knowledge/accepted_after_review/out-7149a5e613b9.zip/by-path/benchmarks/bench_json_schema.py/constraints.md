# Constraints for `benchmarks/bench_json_schema.py`

## Rule

- **Rule:** Benchmark input fixtures must include both modern ($defs/$ref) and legacy (draft-04 definitions/$ref) JSON Schema reference styles so both are exercised.
- **Applies to:**
  - `benchmarks/bench_json_schema.py`
- **Condition:** When adding or modifying JSON Schema benchmark input fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-14828c43ef8c042799314199.md)

## Rule

- **Rule:** Benchmark classes must parametrize over the full set of available schema/grammar keys (e.g., schemas.keys()) so every named case is exercised.
- **Applies to:**
  - `benchmarks/bench_json_schema.py`
- **Condition:** When adding or modifying a benchmark class that selects among named schemas or grammars.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-340a37246f1b42e32c0fea1a.md)

## Rule

- **Rule:**
  ```text
  Benchmark timing methods must disable caching (via cache_disabled) so measured durations reflect uncached construction/execution rather than cached results.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark timing method that constructs a guide or FSM from a schema/regex/grammar.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4ef54f6ec8eea0be236fa396.md)

## Rule

- **Rule:**
  ```text
  Benchmark setup must resolve the target schema/grammar by name from a shared mapping and initialize the tokenizer via setup_tokenizer, so cases are keyed by name.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
- **Condition:**
  ```text
  When adding or modifying benchmark setup that selects a named schema or grammar, resolve the target by name from a shared mapping; initialize the tokenizer via setup_tokenizer only when the benchmark module imports it from the shared common helper.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d76ac918de0ae894b730e1ca.md)
