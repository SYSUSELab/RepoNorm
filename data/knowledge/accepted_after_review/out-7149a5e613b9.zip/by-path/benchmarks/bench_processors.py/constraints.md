# Constraints for `benchmarks/bench_processors.py`

## Rule

- **Rule:**
  ```text
  Benchmark mock processor inputs must build logits of shape (4, num_tokens) and input_ids of shape (4, 2048) for torch/numpy/mlx/jax, with torch device parsed from the array_library suffix after '_' (defaulting to cpu) and unknown libraries raising ValueError.
  ```
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying mock processor input construction for benchmark array libraries.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-395b6bb9f0719a0729215067.md)

## Rule

- **Rule:** Benchmark modules must import optional array frameworks (mlx, jax) inside try/except ImportError blocks so benchmark collection tolerates missing optional dependencies.
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying benchmark imports of optional array frameworks such as mlx or jax.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-62ca5009a5f9c778ca91e8bc.md)

## Rule

- **Rule:**
  ```text
  Benchmark parameter sets for logits-processor passthrough must be built from available frameworks (torch, numpy, and conditionally mlx, torch_cuda, torch_mps, jax) so benchmark coverage adapts to the environment rather than assuming all frameworks are installed.
  ```
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying logits-processor passthrough benchmark parameters or framework availability checks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6e69251a17bf183144f7ecb4.md)

## Rule

- **Rule:** Benchmark optional-dependency detection must attempt an import and return False on ImportError, establishing the optional-dependency detection convention.
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying optional-dependency detection in benchmarks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-98db61334aab70fca39860e0.md)

## Rule

- **Rule:**
  ```text
  Benchmark timing methods must measure a single processor call over precomputed inputs (input_ids and logits) without generation, so the measured unit is raw processor cost.
  ```
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying a logits processor benchmark timing method.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-98dd1744a243de22ac60c9bb.md)

## Rule

- **Rule:** Benchmark processor doubles must be minimal OutlinesLogitsProcessor subclasses that perform a simple deterministic transformation (e.g., halving logits) to isolate processor overhead.
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying a benchmark processor double.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c59b16dc5f24b71f74a3bd74.md)

## Rule

- **Rule:**
  ```text
  MLX-LM benchmark paths must be gated on importing mlx.core and mx.metal.is_available() so benchmarks skip or disable MLX paths when Metal is unavailable.
  ```
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying benchmark code that exercises MLX-LM paths.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc40e39769d4e62d8ae01205.md)

## Rule

- **Rule:**
  ```text
  Benchmark array library coverage must conditionally extend the library list with mlx, torch_cuda, and torch_mps based on runtime availability, so coverage varies by environment.
  ```
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying benchmark array library coverage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d756674aa4b39f2253e50eb7.md)
