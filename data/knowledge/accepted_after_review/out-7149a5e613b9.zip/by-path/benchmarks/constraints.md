# Constraints for `benchmarks`

## Rule

- **Rule:**
  ```text
  Run the JSON schema benchmark with `asv run --config benchmarks/asv.conf.json --profile -b bench_json_schema.JsonSchemaBenchmark.time_json_schema_to_fsm`.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-018fba7b8761d749ea4d3079.md)

## Rule

- **Rule:** Commit changes before benchmarking, because uncommitted code is not benchmarked.
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-582497f5121fa5391ac54150.md)

## Rule

- **Rule:**
  ```text
  On a device with CUDA, add the argument `--launch-method spawn` when running benchmarks.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Condition:** on a device with cuda
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-62e0885a2648154c3236fd2f.md)

## Rule

- **Rule:**
  ```text
  Run benchmarks with `asv run --config benchmarks/asv.conf.json`.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8c1eaff1095b8e5e3893f035.md)

## Rule

- **Rule:**
  ```text
  Run a specific ASV benchmark with `asv run --config benchmarks/asv.conf.json -b bench_json_schema.JsonSchemaBenchmark.time_json_schema_to_fsm`.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8e23693ae8fbd4214188b788.md)

## Rule

- **Rule:**
  ```text
  Run `asv continuous origin/main HEAD --config benchmarks/asv.conf.json` to run continuous benchmarks comparing origin/main against HEAD using the benchmarks/asv.conf.json configuration.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bad4adb9d062c1bddcd697b4.md)
