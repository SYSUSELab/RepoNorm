# Constraints for `benchmarks/bench_regex_guide.py`

## Rule

- **Rule:**
  ```text
  Benchmark timing methods must disable caching (via cache_disabled) so measured durations reflect uncached construction/execution rather than cached results.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark timing method that constructs a guide or FSM from a schema/regex/grammar.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4ef54f6ec8eea0be236fa396.md)

## Rule

- **Rule:**
  ```text
  Guide-execution benchmarks must wrap guide construction and execution in cache_disabled() so timings and peak-memory measurements reflect raw guide work rather than cached reuse.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark that times or measures memory of guide construction or guide execution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8f4a0e4b0a16205d39c04172.md)

## Rule

- **Rule:** Benchmark input fixtures must use a fixed, named set of regex samples (email, phone, date, time, ip, url, ssn, etc.) as benchmark inputs.
- **Applies to:**
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying regex guide benchmark input fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d1abaeff1aef91ca51a1e6d0.md)
