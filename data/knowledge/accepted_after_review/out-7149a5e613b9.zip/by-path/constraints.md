# Constraints for `.`

## Rule

- **Rule:** Each commit must contain one logical change.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-00f42a1b68d6b8495137e9f7.md)

## Rule

- **Rule:**
  ```text
  Flake8 ignores F401 and F403 in __init__.py files at any depth.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0217c6b71ab78373db83bf76.md)

## Rule

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.9 via requires-python = ">=3.9".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-039ea611fdaa8705400f7799.md)

## Rule

- **Rule:**
  ```text
  diff-cover is configured with compare_branch set to "origin/main".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09ad2fb4e7d2ab5b2404e861.md)

## Rule

- **Rule:** Coverage reporting shows missing lines in its report output.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-11799158e292b19d60d76c68.md)

## Rule

- **Rule:**
  ```text
  The tests job runs `pytest -x --cov=outlines`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-14ae388a28684e40e230dcb4.md)

## Rule

- **Rule:**
  ```text
  The build-wheel job runs ./.github/scripts/build_sdist_and_wheel.sh.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-174a41c9873bfb49cffa05fc.md)

## Rule

- **Rule:** Grammars used with Outlines' Lark LALR(1) parser must be unambiguous at least up to the next token (one token lookahead).
- **Applies to:**
  - `**/*.grammar`
  - `**/*.lark`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1a36613b4eb45a96fda48def.md)

## Rule

- **Rule:** Documentation must be up-to-date.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1bd25c18310c7c67abff2b69.md)

## Rule

- **Rule:**
  ```text
  Create the conda environment from environment.yml with `conda env create -f environment.yml`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1c9535730a41c0cc99853e4b.md)

## Rule

- **Rule:** Flake8 ignores error codes E203, E231, E501, E741, W503, W504, C901, and E731.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1db9bf455975434177bef7c0.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with an override for the listed modules that sets ignore_missing_imports = true.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-20e6590ef707468f65bc038d.md)

## Rule

- **Rule:** Docstrings must follow the numpy style guide.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-214e9b708af843eb01e7edf2.md)

## Rule

- **Rule:**
  ```text
  Backreferences in grammar regular expressions, such as `([ab]^*)\1`, cannot be simulated by a finite state machine and result in an error if used.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-28d12fcd9c73d92db2754ddc.md)

## Rule

- **Rule:** The style job runs pre-commit/action@v3.0.0 on ubuntu-latest with Python 3.10.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2d2710333f2be523215d7c1a.md)

## Rule

- **Rule:** The mypy hook runs with the --allow-redefinition argument.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2d6031d04332e1e32182242c.md)

## Rule

- **Rule:** The mypy hook declares additional dependencies types-tqdm and types-Pillow.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3297de82406d2a128b4c3c7e.md)

## Rule

- **Rule:** Outlines' test suite can be used to verify a grammar.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-32be1356d5fe366c22565c27.md)

## Rule

- **Rule:** The Tests workflow runs on pushes to the main branch.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-339922858147b475a21496f7.md)

## Rule

- **Rule:** PRs must link to all relevant issues, discussions, and PRs.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-349c866132a1ffc6927c8f5e.md)

## Rule

- **Rule:** The pre-commit configuration enables the check-merge-conflict hook from pre-commit/pre-commit-hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3e56b5a68920962b3f45f058.md)

## Rule

- **Rule:** The setuptools package configuration declares only the "outlines" package for distribution.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-436314c5a37218f760fb80d8.md)

## Rule

- **Rule:** Flake8 enforces a maximum line length of 88 characters.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-50fb0f7e1d2e1a06e9e983f4.md)

## Rule

- **Rule:** The pre-commit configuration enables the end-of-file-fixer hook from pre-commit/pre-commit-hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-59a5e6a88e266823c559d8b5.md)

## Rule

- **Rule:** The Tests workflow runs on pull requests targeting the main branch.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-61b149f1e8cc478449aeca5e.md)

## Rule

- **Rule:** Outlines uses asv for automated benchmark testing.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-669671cefa596fa6734f5164.md)

## Rule

- **Rule:** The coverage job depends on the tests job.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-682f96af41cc10f90c064ea1.md)

## Rule

- **Rule:** Contributors may consider opening a Draft PR when work is still in progress but feedback from other contributors is desired.
- **Applies to:**
  - `**`
- **Condition:** when work is still in progress but feedback from other contributors is desired
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-6bd1c8fe5ccaafb0f9351351.md)

## Rule

- **Rule:** The PR branch must be rebased on the latest main commit.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-704331c95bc77829c8e13ff2.md)

## Rule

- **Rule:** The mypy hook excludes paths matching ^examples/.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-737f50b14c60715119a91357.md)

## Rule

- **Rule:** mypy enables the incomplete Unpack feature.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-76551dfccf229cb15baefcc6.md)

## Rule

- **Rule:** Commit messages must follow the referenced git commit message guidelines.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-77b05b53e00fc6859dbfef7e.md)

## Rule

- **Rule:** The pre-commit configuration enables the debug-statements hook from pre-commit/pre-commit-hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7990d953e65eda4a85bdc6cc.md)

## Rule

- **Rule:** Merging is blocked unless benchmarks are run for the latest commit.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-8297a7747dffa9d16ded5603.md)

## Rule

- **Rule:**
  ```text
  When using venv, create the virtual environment with `python -m venv .venv`.
  ```
- **Applies to:**
  - `**`
- **Condition:** when using venv
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8e3ad764cfcaf6fe95c4b971.md)

## Rule

- **Rule:** The issue tracker is only intended for actionable items; when in doubt, open a discussion or contact the maintainers instead.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-8f0f54576f126f15c5ca5ad0.md)

## Rule

- **Rule:** Run the code style checks.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-9019f58af63a876598e2dd7b.md)

## Rule

- **Rule:** Coverage measurement enables branch coverage.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-90e6f276b16bd31b4460049d.md)

## Rule

- **Rule:** Benchmarks fail if performance degrades by more than 10% for any individual benchmark.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b2689ce0e5fbab85c83090a7.md)

## Rule

- **Rule:**
  ```text
  diff-cover is configured with diff_range_notation set to "..".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b6208d77941cf93a338b5d79.md)

## Rule

- **Rule:** Read the Docs builds use Python version 3.8.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b85daebcae2817bb9facc1d1.md)

## Rule

- **Rule:** The tests job runs on Python 3.10.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b9e367dd149d5493dbfa4431.md)

## Rule

- **Rule:** PRs must include tests covering the changes.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-ba83a19943c772794975af65.md)

## Rule

- **Rule:** pre-commit must be installed and configured locally, and run before opening a PR.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-c00732b339438c075d2c61ef.md)

## Rule

- **Rule:** The pre-commit configuration enables the trailing-whitespace hook from pre-commit/pre-commit-hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c8c7197796948cca925661c6.md)

## Rule

- **Rule:**
  ```text
  Contributors install the pre-commit hooks by running `pre-commit install`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ce1e1f7d9b6f912ac171cf8b.md)

## Rule

- **Rule:**
  ```text
  Coverage reporting excludes lines matching "pragma: no cover", "if TYPE_CHECKING:", and "\\.\\.\\." from coverage.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d345ce173bf4bf4291870362.md)

## Rule

- **Rule:** New feature contributions should be preceded by starting a new discussion or chatting with the maintainers beforehand.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-d52f750899eaa6d2eea83182.md)

## Rule

- **Rule:** Flake8 selects the C, E, F, and W error code groups.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d652a5bb1c43861cd6a9ec88.md)

## Rule

- **Rule:** Benchmarks are run automatically before pull requests are merged to prevent performance degradation.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d9b5f8101254c1405d359ccd.md)

## Rule

- **Rule:** When adding a new feature, the PR must reference an existing issue discussing it.
- **Applies to:**
  - `**`
- **Condition:** when the PR adds a new feature
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-da1fd8ab36112f96f24a1b86.md)

## Rule

- **Rule:**
  ```text
  Run the test suite with `pytest`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-df21140e29350f088c96230e.md)

## Rule

- **Rule:** Coverage measurement records file paths relative to the project root.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e0a67bd84054172d5d6161cd.md)

## Rule

- **Rule:**
  ```text
  The coverage job installs coverage[toml]>=5.1 and diff-cover.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e0e563ae11beb0f623955424.md)

## Rule

- **Rule:** The flake8 hook is enabled.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e4ddffa01df7e907aad11921.md)

## Rule

- **Rule:**
  ```text
  pytest treats warnings as errors by default, with exceptions for pydantic deprecation warnings, FutureWarnings from transformers and huggingface_hub, all UserWarnings, and pyairports DeprecationWarnings.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e5d13f3eddb06a69bba52a3e.md)

## Rule

- **Rule:** Read the Docs installs the project from the repository root via pip with the rtd extra requirements.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e64cbdc04493872eb632a7e6.md)

## Rule

- **Rule:** Before pushing code, run the tests.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-e8d921e4e58b233db37fd0a1.md)

## Rule

- **Rule:** Code must respect the repository's current naming conventions.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-eb4c44543a288f6877e21644.md)

## Rule

- **Rule:** PRs must include a high-level description of the changes.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-f1787ce841c9b42bf895ac77.md)

## Rule

- **Rule:** The coverage job fails if diff coverage is below 100%, appending the markdown report to the GitHub step summary on failure.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fa85659864748248e7979047.md)

## Rule

- **Rule:**
  ```text
  The tests job installs the package in editable mode with the test extra via `pip install -e .[test]`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fcf3c6d9794e3974087abd9e.md)
