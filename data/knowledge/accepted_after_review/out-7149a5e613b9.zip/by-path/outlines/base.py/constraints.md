# Constraints for `outlines/base.py`

## Rule

- **Rule:**
  ```text
  The async broadcast path must build one task per index in np.ndindex(*broadcast_shape), slice positional and keyword arguments by that index, await asyncio.gather over all tasks, and return the outputs.
  ```
- **Applies to:**
  - `outlines/base.py`
- **Condition:** Modifying the async broadcast/vectorize gather path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1bbdcdff76b79f19d6422bd6.md)

## Rule

- **Rule:**
  ```text
  When modifying the vectorize __call__ dispatch, preserve the distinct no-argument path: dispatch to call_thunk when no args or kwargs are supplied, otherwise to call_with_signature if a signature exists, otherwise to call_no_signature.
  ```
- **Applies to:**
  - `outlines/base.py`
- **Condition:**
  ```text
  Modifying vectorize.__call__ in outlines/base.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b10aa91202686e3b697b0e58.md)

## Rule

- **Rule:**
  ```text
  When modifying vectorize.call_with_signature, preserve the signature validation contract: the number of positional/keyword args must equal len(input_core_dims), args and kwargs are broadcast to a common shape, a ValueError is raised when the function's output count differs from len(output_core_dims), scalar outputs are squeezed via .item(), and a single value is returned when n_results == 1.
  ```
- **Applies to:**
  - `outlines/base.py`
- **Condition:**
  ```text
  When changing argument validation, broadcasting, output-count checks, or scalar squeezing in vectorize.call_with_signature.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f0af9e5ac1aefa84a8da9af4.md)

## Rule

- **Rule:** When modifying the vectorize helper, preserve the behavioral difference that wrapped coroutines are executed concurrently while synchronous calls run in a loop like NumPy's vectorize.
- **Applies to:**
  - `outlines/base.py`
- **Condition:** Changing the vectorize helper's execution strategy for wrapped functions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f65b97a4ac24b15b45c9f958.md)
