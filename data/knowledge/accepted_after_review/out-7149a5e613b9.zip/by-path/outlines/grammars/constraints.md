# Constraints for `outlines/grammars`

## Rule

- **Rule:**
  ```text
  New grammar files are created as `.lark` files placed in `outlines/grammars/`, with attribution included and a compatible license.
  ```
- **Applies to:**
  - `outlines/grammars/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../../claims/CLAIM-bae53eb75f27b8006be8c5bf.md)
