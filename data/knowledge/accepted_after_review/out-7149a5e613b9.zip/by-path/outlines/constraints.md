# Constraints for `outlines`

## Rule

- **Rule:** The "outlines" package includes the py.typed marker file as package data.
- **Applies to:**
  - `outlines/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ac98bb5ff0e2da78dfe2d46b.md)
