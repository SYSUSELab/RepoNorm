# Constraints for `outlines/models/mlxlm.py`

## Rule

- **Rule:**
  ```text
  MLXLM must expose a _tokenizer attribute documented as an HF Tokenizer so MLX models reuse HuggingFace tokenizer semantics.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:** When modifying MLXLM or its tokenizer attribute.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-05de81971c38b8dc31fb7331.md)

## Rule

- **Rule:**
  ```text
  outlines/models/mlxlm.py must import mlx.core and mlx.nn only under TYPE_CHECKING and reuse TransformerTokenizer from .transformers, keeping MLX an optional runtime dependency while sharing tokenization with the transformers backend.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:** Modifying MLX model imports or tokenizer reuse.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-19c8284547417c1fbff9c6cd.md)

## Rule

- **Rule:** When modifying MLXLM.generate, preserve consistency between generate and stream for the same inputs, since generate is implemented by joining the token stream from self.stream.
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:** When changing MLXLM.generate or MLXLM.stream behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c4403f5fb2ae0e5a745e8bb4.md)
