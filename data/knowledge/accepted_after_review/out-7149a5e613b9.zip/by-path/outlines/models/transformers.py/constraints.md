# Constraints for `outlines/models/transformers.py`

## Rule

- **Rule:**
  ```text
  When modifying get_llama_tokenizer_types, preserve the try/except ImportError imports of LlamaTokenizer, LlamaTokenizerFast, CodeLlamaTokenizer, and CodeLlamaTokenizerFast with dummy-class fallbacks, and return all four types for work-around handling.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When changing Llama tokenizer type resolution or import fallbacks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-01e0e4f8204612f3ad35b7a1.md)

## Rule

- **Rule:**
  ```text
  When modifying TransformerTokenizer.__eq__, preserve the comparison of model_name and kwargs when both attributes exist, with fallback to comparing tokenizers, so equality semantics for transformer model wrappers remain stable.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When changing TransformerTokenizer equality or hash behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0cf840c73a776b73f03eaad6.md)

## Rule

- **Rule:**
  ```text
  _decode_generation must dispatch on tensor rank: 1D returns a single decoded string, 2D returns batch-decoded strings, 3D returns a list of per-sample decodes, and any other rank raises TypeError.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying _decode_generation or its rank-based dispatch
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1f8ddf406d0107f6e5bd8881.md)

## Rule

- **Rule:**
  ```text
  _get_generation_kwargs must map GenerationParameters/SamplingParameters into a transformers GenerationConfig with max_new_tokens defaulting to 2**30 when None, do_sample set only when sampler=='multinomial', num_beams equal to num_samples for beam_search, and seed triggering a global set_seed.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying _get_generation_kwargs or the GenerationParameters/SamplingParameters to GenerationConfig mapping
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2d081b00654e854cf1f0e503.md)

## Rule

- **Rule:**
  ```text
  When modifying TransformerTokenizer.decode, preserve the contract that token_ids are batch-decoded with skip_special_tokens=True, so special tokens are stripped from returned text.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When changing decoding behavior or special-token handling in TransformerTokenizer.decode.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6c1d4309413196812a549ab9.md)

## Rule

- **Rule:**
  ```text
  Transformers.forward must assert input_ids.ndim is 1 or 2, and when past_key_values is provided it must slice input_ids to the last token before inference, so callers pass full sequences only on the first step.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying Transformers.forward or its past_key_values handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-84c6e22066a17f5db398ffff.md)

## Rule

- **Rule:**
  ```text
  When modifying TransformerTokenizer.__hash__, preserve delegation to datasets.fingerprint.Hasher.hash(self.tokenizer) so tokenizer hash stability continues to depend on the datasets Hasher.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When changing TransformerTokenizer hashing behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b1a0836fd45c27705dfdc227.md)

## Rule

- **Rule:**
  ```text
  TransformerTokenizer.__setstate__ must reinitialize the model from state["tokenizer"], so unpickling depends on the serialized state containing a "tokenizer" key and changing serialization fields would break this compatibility path.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying TransformerTokenizer.__setstate__ or the serialized state fields it consumes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b76f37eb3a623283760d8ff2.md)

## Rule

- **Rule:** When adding a new optional model backend factory (e.g. mamba-style), import the heavy backend dependency lazily inside the factory and raise ImportError naming the required packages, rather than importing at module top level.
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** Adding or modifying an optional model backend factory in outlines/models/transformers.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bcac59702d162a028b40bdb1.md)

## Rule

- **Rule:**
  ```text
  Transformers.generate must keep the single-string path: encode one prompt as a 2D batch, move input_ids and attention_mask to the model device, drop attention_mask when the model forward signature does not accept it, squeeze the batch dimension for single-string prompts, and decode the generated ids.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying Transformers.generate or its single-string prompt handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d8b3a017f5b0f883b480e51c.md)

## Rule

- **Rule:**
  ```text
  Transformers.__call__ must return next_token_logits = logits[..., -1, :] together with the kv cache so callers receive only the last-position logits per sequence.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying Transformers.__call__ or its returned logits shape
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fe89ed93044c9256246d40a0.md)
