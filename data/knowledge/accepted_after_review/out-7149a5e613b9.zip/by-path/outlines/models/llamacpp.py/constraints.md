# Constraints for `outlines/models/llamacpp.py`

## Rule

- **Rule:**
  ```text
  When modifying the llama.cpp model factory, preserve the defaults n_ctx=0 (full context length) and verbose=False when not provided, and keep the warning that llama.cpp's pre-tokenizer mishandles unicode unless a tokenizer such as LlamaHFTokenizer is passed.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** Modifying the llamacpp factory in outlines/models/llamacpp.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3a80704b919df586bf1f7b37.md)

## Rule

- **Rule:**
  ```text
  When modifying LlamaCppTokenizer equality, preserve state-based equality: __eq__ returns False for non-LlamaCppTokenizer operands and otherwise compares __getstate__() dicts, requiring the other object to be the same tokenizer class.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** When changing LlamaCppTokenizer equality or state serialization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5852b70e80b81c8112bc3acb.md)

## Rule

- **Rule:**
  ```text
  LlamaCppTokenizer.__getstate__ must return a tuple of vocabulary, eos_token_id, eos_token, pad_token_id, and sorted special_tokens to provide a stable representation for outlines.caching.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  When modifying LlamaCppTokenizer.__getstate__ or the cache-state tuple it returns.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5f22e155a5146f1d6c44af8d.md)

## Rule

- **Rule:**
  ```text
  When modifying LlamaCppTokenizer pickling support, preserve the unsupported status: __setstate__ raises NotImplementedError("Cannot load a pickled llamacpp tokenizer").
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** When changing LlamaCppTokenizer serialization or unpickling behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6189e7d35b191cec5d01e65d.md)

## Rule

- **Rule:**
  ```text
  When modifying outlines/models/llamacpp.py, keep llama_cpp imports under TYPE_CHECKING so llama_cpp remains an optional runtime dependency for this module.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** Modifying imports or type annotations in outlines/models/llamacpp.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-748d35a5a7f7724422494c25.md)

## Rule

- **Rule:**
  ```text
  When modifying LlamaCpp.prepare_generation_parameters, preserve the translation contract: subtract one from max_tokens because llama-cpp-python generates max_tokens + 1 tokens, raise NotImplementedError for beam search and multiple samples, disable streaming, and append the structure logits processor to a LogitsProcessorList.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  When changing parameter translation, sampling restrictions, or logits processor wiring in LlamaCpp.prepare_generation_parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-78fd7b623d6a3d772f685f1d.md)

## Rule

- **Rule:**
  ```text
  LlamaCppTokenizer.__hash__ must cache hash(pickle.dumps(self)) in self._hash so the object's hash depends on its pickled representation and is computed once.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  When modifying LlamaCppTokenizer.__hash__ or the tokenizer's hashability contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9b066919aa71947d85560ca7.md)

## Rule

- **Rule:**
  ```text
  When modifying the llama.cpp stream method, preserve the parameter precedence that user-supplied llama_cpp_params supersede values derived from generation_parameters and sampling_parameters, and that stream=True is forced before invoking the model.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** Modifying LlamaCpp.stream in outlines/models/llamacpp.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b3cf043dfa51bc0cc0120705.md)

## Rule

- **Rule:** When modifying the llama.cpp tokenizer decode, preserve the error-handling contract that token ids are detokenized and bytes decoded as UTF-8 with errors="ignore", silently dropping invalid byte sequences rather than raising.
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** Changing llama.cpp tokenizer decode behavior or its byte-decoding error handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e0d55b0239ab0d1bdbd8a2a6.md)

## Rule

- **Rule:**
  ```text
  When modifying LlamaCppTokenizer.__init__, preserve the vocabulary initialization contract: use the HF tokenizer vocabulary when available, otherwise decode every token id, then sort the vocabulary by token id for stable ordering, and set pad_token_id equal to eos_token_id.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  When changing vocabulary construction or pad/eos token id assignment in LlamaCppTokenizer.__init__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ef24094b8c0d335f4442f4e0.md)
