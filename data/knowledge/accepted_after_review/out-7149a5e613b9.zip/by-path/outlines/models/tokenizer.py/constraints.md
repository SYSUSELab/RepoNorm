# Constraints for `outlines/models/tokenizer.py`

## Rule

- **Rule:**
  ```text
  When modifying the tokenizer interface, preserve the decode contract: an abstract stub taking an NDArray[np.int64] of token ids and returning List[str].
  ```
- **Applies to:**
  - `outlines/models/tokenizer.py`
- **Condition:** Modifying the Tokenizer.decode abstract method in outlines/models/tokenizer.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3b53d2a77dc8c5e962c3111d.md)
