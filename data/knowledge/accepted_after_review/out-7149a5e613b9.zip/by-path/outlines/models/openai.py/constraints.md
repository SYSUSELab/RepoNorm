# Constraints for `outlines/models/openai.py`

## Rule

- **Rule:**
  ```text
  When modifying OpenAI.__init__, preserve the per-instance cumulative token accounting contract: prompt_tokens and completion_tokens counters are initialized and documented as summed over all requests made with the model instance.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When changing token counter initialization or accounting semantics in OpenAI.__init__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-12512ce7fe051d199514ceaf.md)

## Rule

- **Rule:**
  ```text
  When modifying the OpenAI model module, preserve the centralized error-handling boundary: API calls are wrapped with an error_handler decorator intended to handle OpenAI API errors and missing API keys.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:** When changing API call wrapping or error handling in the OpenAI model module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4d7a879619bacbdb86f066eb.md)

## Rule

- **Rule:**
  ```text
  openai_model() must lazily import AsyncOpenAI and raise ImportError naming the openai library, and must replace config.model with the supplied model_name when a config is provided.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When modifying openai_model() or its optional-dependency import and config handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-72b2c75cf4af46d79df8eea2.md)

## Rule

- **Rule:** The OpenAI API call wrapper must map APITimeoutError, InternalServerError, and RateLimitError to OSError, while re-raising AuthenticationError, BadRequestError, ConflictError, PermissionDeniedError, NotFoundError, and UnprocessableEntityError unchanged.
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When modifying the OpenAI error_handler or its exception mapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8176d16aeac93b284612ec14.md)

## Rule

- **Rule:** When modifying OpenAI model configuration updates, preserve the immutable update pattern: use copy.copy plus dataclasses.replace to produce a new instance with replaced config fields, leaving the original instance unmutated.
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:** When changing OpenAI model configuration update logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b1c0d63b537fc00e01d9a8ab.md)

## Rule

- **Rule:**
  ```text
  When modifying the OpenAI model module, preserve OpenAI, openai, and azure_openai as the declared public exports, since these names are the supported integration surface.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:** Modifying the public exports of outlines/models/openai.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b5b9e3ee14d4525dd85c485d.md)

## Rule

- **Rule:**
  ```text
  When a config is supplied to azure_openai, the deployment_name must replace the configured model; when no config is supplied, the constructed OpenAIConfig must use model=deployment_name.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  Modifying azure_openai's config handling or model resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cf85f7252d68a3a30322c266.md)

## Rule

- **Rule:**
  ```text
  When modifying the OpenAI model __call__, preserve the defaulting protocol: each optional generation parameter (max_tokens, stop_at, temperature, samples) is resolved from self.config when the caller passes None, config is rebuilt via dataclasses.replace before calling generate_chat, and token usage counters accumulate on the instance.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  Changing how OpenAI.__call__ resolves optional generation parameters or accumulates usage counters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-df0b529cff9bfef45783ead7.md)

## Rule

- **Rule:**
  ```text
  When modifying the OpenAI call_api wrapper, preserve the decorator stack (error_handler and cache) and the responses.model_dump() return so caching and error normalization continue to operate on the serialized response dict rather than the raw SDK object.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When changing the OpenAI call_api wrapper's decorators or return value.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e8b90894f72dbfbcca5e8925.md)
