# Constraints for `outlines/models/exllamav2.py`

## Rule

- **Rule:**
  ```text
  When modifying OutlinesExLlamaV2Tokenizer.convert_token_to_string, preserve the behavior of returning the token unchanged, reflecting that this backend does not perform token-to-string decoding in that hook.
  ```
- **Applies to:**
  - `outlines/models/exllamav2.py`
- **Condition:** When changing token-to-string conversion for the exllamav2 backend.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2d388d93cf795c7b07554aa8.md)

## Rule

- **Rule:**
  ```text
  When modifying ExLlamaV2Model.__init__, preserve the configuration surface contract: generator, tokenizer, and max_seq_len are stored as attributes, making max_seq_len part of the model's configuration surface.
  ```
- **Applies to:**
  - `outlines/models/exllamav2.py`
- **Condition:**
  ```text
  When changing attribute storage or configuration surface in ExLlamaV2Model.__init__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-61d0185a3f11bd2aac0a445c.md)

## Rule

- **Rule:** When modifying ExLlamaV2Model.stream in outlines/models/exllamav2.py, preserve the batching protocol: enqueue one ExLlamaV2DynamicJob per prompt, increment seed per prompt when seed is not None, and track job serials in an order dict to map outputs back to batch positions.
- **Applies to:**
  - `outlines/models/exllamav2.py`
- **Condition:** Modifying ExLlamaV2Model.stream or its batching/seed handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7eb6485088c99f41eead0b44.md)

## Rule

- **Rule:**
  ```text
  ExLlamaV2Model.stream.token_generator must iterate while num_remaining_jobs() is nonzero, map each result's serial through an order index, update next_text on 'streaming' stage, clear text on eos, and yield reformatted output per iteration.
  ```
- **Applies to:**
  - `outlines/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying ExLlamaV2Model.stream.token_generator or the streaming result loop.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e022ba5ee5819cfecd2930e4.md)
