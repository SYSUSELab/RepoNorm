# Constraints for `outlines/models/vllm.py`

## Rule

- **Rule:**
  ```text
  When modifying the vLLM adapter's sampling configuration, preserve the workaround that sets repetition_penalty to 0 whenever top_k is 1, until the referenced upstream vLLM issue is fixed.
  ```
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:**
  ```text
  When changing top_k or repetition_penalty handling in the vLLM adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-36eb21b99e86a1556b1b8658.md)

## Rule

- **Rule:** When modifying the vLLM generate adapter, preserve the batch/sample-dependent return shape: a string for a single batch with a single sample, a list for one batch with several samples, a list of first samples for several batches with one sample, and a nested list otherwise.
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** When changing the vLLM generate adapter's batching or sampling logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aabd7228c3f2fa7874cd9fa4.md)

## Rule

- **Rule:**
  ```text
  vllm() must lazily import vllm.LLM inside the function, construct LLM(model_name, **vllm_model_params), and wrap it in VLLM, preserving lazy import and parameter pass-through.
  ```
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** When modifying vllm() or its model construction and parameter pass-through.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bd95a59ed66a4751d698ff0b.md)
