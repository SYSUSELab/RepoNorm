# Constraints for `outlines/function.py`

## Rule

- **Rule:**
  ```text
  Function.__call__ must lazily initialize the generator and must not support batching.
  ```
- **Applies to:**
  - `outlines/function.py`
- **Condition:**
  ```text
  Modifying Function.__call__ generator initialization or batching support.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ab0ba3bb68bd8b29e81e0419.md)

## Rule

- **Rule:**
  ```text
  Function.init_generator must load models.transformers(self.model_name) and assign generate.json(model, self.schema) to self.generator, coupling the function wrapper to the transformers backend and JSON schema generation.
  ```
- **Applies to:**
  - `outlines/function.py`
- **Condition:**
  ```text
  When modifying Function.init_generator or the backend/schema coupling it establishes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d549ec203a8de24daf5397ab.md)
