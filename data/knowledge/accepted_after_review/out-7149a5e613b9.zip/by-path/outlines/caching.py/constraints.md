# Constraints for `outlines/caching.py`

## Rule

- **Rule:**
  ```text
  When modifying the async cache decorator, preserve the call-time check of _caching_enabled so that disabling caching bypasses both cache get and set, and keep using wrapper.__cache_key__/wrapper.__memory__ with the ENOVAL sentinel and expire/retry=True on store.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:** Modifying the async cache decorator wrapper in outlines/caching.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1f9ba3693f5e8b95a7ac2887.md)

## Rule

- **Rule:**
  ```text
  When modifying disable_cache in outlines/caching.py, preserve its semantics: it only flips a global flag for the session; it does not delete existing cache entries and does not overwrite the cache with values produced during the disabled session.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:**
  ```text
  Modifying disable_cache or cache-disabled session behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-93e7fc6c06d1dec32fc1d1f7.md)

## Rule

- **Rule:**
  ```text
  The caching wrapper must bypass the cache when _caching_enabled is false; otherwise it computes a cache key, reads with retry=True, computes and stores on miss, and returns the cached result.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:** Modifying the caching decorator wrapper behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c6c101973d08f2e1c8c11be3.md)

## Rule

- **Rule:**
  ```text
  When modifying outlines/caching.py, preserve the cache lifecycle: get_cache is lru_cache(1), defaults to HOMEDIR/.cache/outlines overridable via OUTLINES_CACHE_DIR, uses no eviction, and clears the cache when the outlines version changes.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:**
  ```text
  Modifying get_cache or the cache directory/version handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e6be0cde0cb3b9eddb3f2edc.md)
