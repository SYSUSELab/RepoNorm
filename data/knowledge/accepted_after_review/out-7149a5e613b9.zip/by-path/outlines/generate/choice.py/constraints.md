# Constraints for `outlines/generate/choice.py`

## Rule

- **Rule:**
  ```text
  When modifying choice() in outlines/generate/choice.py, preserve the behavior that it builds a regex from escaped choices or from an Enum schema, and sets format_sequence to pyjson.loads for Enum choices and identity for string choices.
  ```
- **Applies to:**
  - `outlines/generate/choice.py`
- **Condition:**
  ```text
  Modifying choice() or its regex/format_sequence construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-21fc6ca8a8ff10ead96442be.md)
