# Constraints for `outlines/generate/regex.py`

## Rule

- **Rule:**
  ```text
  When modifying the vision regex adapter registration, preserve the regex_vision registration for TransformersVision that builds a RegexLogitsProcessor from the model tokenizer and returns a VisionSequenceGeneratorAdapter.
  ```
- **Applies to:**
  - `outlines/generate/regex.py`
- **Condition:**
  ```text
  Modifying regex_vision in outlines/generate/regex.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0f0ac9cf43feb50a3d680719.md)

## Rule

- **Rule:** When modifying regex-structured generation for OpenAI models in outlines/generate/regex.py, preserve the explicit unsupported boundary: the registered OpenAI regex adapter raises NotImplementedError citing OpenAI API limitations, so regex generation must not be assumed to work across all model backends.
- **Applies to:**
  - `outlines/generate/regex.py`
- **Condition:**
  ```text
  Modifying regex_openai or the OpenAI regex adapter registration.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0f0e9f2e00e17412da54a6f3.md)

## Rule

- **Rule:** When adding a new model type to regex-constrained generation, register a dedicated singledispatch handler on the regex generator that constructs the appropriate guide and wraps it in the matching sequence-generator adapter (including vision-specific adapters) rather than branching inside a shared handler.
- **Applies to:**
  - `outlines/generate/fsm.py`
  - `outlines/generate/regex.py`
- **Condition:** Adding or modifying support for a new model type in regex/FSM-constrained generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cce052aa86662c3d464c3d5d.md)
