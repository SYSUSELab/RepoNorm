# Constraints for `outlines/generate/api.py`

## Rule

- **Rule:**
  ```text
  When modifying SamplingParameters, preserve its frozen dataclass contract with fields sampler: str, num_samples: int = 1, and optional top_p, top_k, temperature, as the immutable sampling-parameter contract used across Outlines generation APIs.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:** When changing the SamplingParameters dataclass fields, defaults, or frozen status.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0125216ba8664bbfe76f7c97.md)

## Rule

- **Rule:**
  ```text
  get_generated_token_ids must strip the prompt prefix by slicing token ids at the prompt length, so generated-token reporting depends on accurate prompt lengths.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:**
  ```text
  When modifying get_generated_token_ids or how prompt lengths are computed for token slicing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-15aa9a7728e62e9c0b5e56f1.md)

## Rule

- **Rule:**
  ```text
  SequenceGeneratorAdapter.__call__ must accept a prompt or list of prompts plus optional max_tokens, stop_at, seed, and model-specific params, prepare generation parameters, call model.generate with a copy of the logits processor, and format completions.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:**
  ```text
  When modifying SequenceGeneratorAdapter.__call__ or the generation call path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5a4ce415df36b1dd893b6b62.md)

## Rule

- **Rule:**
  ```text
  The token_generator must reshape outputs by batch_size and num_samples: yield a scalar string when both are 1, a list when batch_size is 1, a list of first samples when num_samples is 1, and a nested list otherwise; it must also track is_stop_at_reached per sequence and strip stop sequences before formatting.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:**
  ```text
  when modifying SequenceGenerator.stream.token_generator or its output shaping and stop-sequence handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8a944f34f5588b3fc7aa00fb.md)

## Rule

- **Rule:**
  ```text
  When modifying SequenceGenerator.stream, preserve the repeat_interleave expansion of token ids and attention mask by num_samples and the per-batch-element FSM copy so FSM state and weights remain indexed by batch_size*num_samples.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:** When changing how SequenceGenerator.stream batches multiple samples per prompt.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8c2bf6e23675ef94cc605a71.md)

## Rule

- **Rule:**
  ```text
  The valid_types helper must enforce that when prompts is a list, media is a list of the same length and each submedia is an iterable of PIL Image objects; when prompts is a string, media must be an iterable of PIL Image objects.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:**
  ```text
  when modifying VisionSequenceGeneratorAdapter._validate_prompt_media_types.valid_types or multimodal prompt/media validation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-99b12141bdeda7c4fe163ec2.md)
