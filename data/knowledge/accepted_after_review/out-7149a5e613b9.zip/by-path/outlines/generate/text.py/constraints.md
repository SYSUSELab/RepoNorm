# Constraints for `outlines/generate/text.py`

## Rule

- **Rule:**
  ```text
  When modifying text_openai, preserve the sampler restriction: raise NotImplementedError unless the sampler is multinomial(), documenting that the OpenAI API supports only multinomial sampling and that other samplers are rejected.
  ```
- **Applies to:**
  - `outlines/generate/text.py`
- **Condition:**
  ```text
  When changing sampler validation or supported sampler handling in text_openai.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-209bcd0830728f496ae3c127.md)
