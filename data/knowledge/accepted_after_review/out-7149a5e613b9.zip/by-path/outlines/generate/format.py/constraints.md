# Constraints for `outlines/generate/format.py`

## Rule

- **Rule:**
  ```text
  OpenAI-backed generation entry points must remain explicitly unsupported: cfg_openai and format_openai are registered for OpenAI models but raise NotImplementedError, so contributors must not silently implement or bypass these paths without updating the documented limitation.
  ```
- **Applies to:**
  - `outlines/generate/cfg.py`
  - `outlines/generate/format.py`
- **Condition:** When adding or modifying OpenAI model generation support for grammar-structured (cfg) or Python type-structured (format) output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-feb3ff64ee2c97f66062e88e.md)
