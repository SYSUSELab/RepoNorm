# Constraints for `outlines/generate/cfg.py`

## Rule

- **Rule:**
  ```text
  When modifying the vision CFG adapter registration, preserve the cfg_vision registration for TransformersVision that constructs a CFGLogitsProcessor from the cfg string and model tokenizer and returns a VisionSequenceGeneratorAdapter.
  ```
- **Applies to:**
  - `outlines/generate/cfg.py`
- **Condition:**
  ```text
  Modifying cfg_vision in outlines/generate/cfg.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5aeadfc3dfaca84ffe5672ed.md)

## Rule

- **Rule:**
  ```text
  OpenAI-backed generation entry points must remain explicitly unsupported: cfg_openai and format_openai are registered for OpenAI models but raise NotImplementedError, so contributors must not silently implement or bypass these paths without updating the documented limitation.
  ```
- **Applies to:**
  - `outlines/generate/cfg.py`
  - `outlines/generate/format.py`
- **Condition:** When adding or modifying OpenAI model generation support for grammar-structured (cfg) or Python type-structured (format) output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-feb3ff64ee2c97f66062e88e.md)
