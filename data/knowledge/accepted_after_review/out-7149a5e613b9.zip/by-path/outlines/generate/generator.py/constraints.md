# Constraints for `outlines/generate/generator.py`

## Rule

- **Rule:** When modifying ContextLengthExceededError in outlines/generate/generator.py, preserve it as a dedicated Exception subclass so contributors raise/catch a specific type for context-length overflow rather than a generic error.
- **Applies to:**
  - `outlines/generate/generator.py`
- **Condition:** Modifying ContextLengthExceededError or context-length overflow error handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-109361118a33773c41b839eb.md)

## Rule

- **Rule:** When modifying the logits biasing helper, preserve the invariant that disallowed token ids are set to -inf while allowed ids retain original logits, and that a row whose allowed ids are None is left entirely unmasked.
- **Applies to:**
  - `outlines/generate/generator.py`
- **Condition:**
  ```text
  Modifying bias_logits in outlines/generate/generator.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-69babfaccbc8dd04b14df052.md)

## Rule

- **Rule:**
  ```text
  reorder_fsm_states must index fsm_states by each element of the ancestors tensor, so ancestors must contain valid integer indices into fsm_states and the output order follows ancestors order.
  ```
- **Applies to:**
  - `outlines/generate/generator.py`
- **Condition:**
  ```text
  When modifying reorder_fsm_states or the ancestors indexing it performs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3189b6aac084d56b6231281.md)

## Rule

- **Rule:**
  ```text
  update_token_ids must select rows of token_ids by ancestors before concatenating next_token_ids along the last dimension, appending generated tokens to ancestor-selected sequences rather than the original row order.
  ```
- **Applies to:**
  - `outlines/generate/generator.py`
- **Condition:**
  ```text
  Modifying update_token_ids row selection or concatenation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b8a3c884bd35f59a5655e4c5.md)

## Rule

- **Rule:**
  ```text
  is_generation_finished must treat a batch as finished only when every sequence's FSM is in a final state; the known batch-level completion limitation is documented and must not be silently changed without addressing the docstring.
  ```
- **Applies to:**
  - `outlines/generate/generator.py`
- **Condition:**
  ```text
  when modifying is_generation_finished or batch completion semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c66707855fd1c82316952fef.md)

## Rule

- **Rule:**
  ```text
  sequence_generator must call model(token_ids, attention_masks, kv_cache), convert IndexError into ContextLengthExceededError, bias logits with allowed tokens from the FSMs, sample next tokens, update token ids, attention masks, and kv cache, reorder FSMs and FSM states when ancestors > 1, and yield GenerationState until is_generation_finished.
  ```
- **Applies to:**
  - `outlines/generate/generator.py`
- **Condition:** Modifying the sequence generation loop, state updates, or termination.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f5602ebebc02dbad2cbe5995.md)
