# Constraints for `outlines/processors/structured.py`

## Rule

- **Rule:** JSONLogitsProcessor must bias generation based on a JSON schema through RegexGuide inheritance, so contributors changing JSON schema biasing must preserve the RegexLogitsProcessor subclass relationship.
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:** When modifying JSONLogitsProcessor or the JSON schema biasing path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0e7f5595237558f9f3d27558.md)

## Rule

- **Rule:** When modifying RegexLogitsProcessor in outlines/processors/structured.py, preserve the contract that its guide attribute is an outlines.fsm.RegexGuide.
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:** Modifying RegexLogitsProcessor or its guide attribute typing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2d3d4ed127e7703fbc7500bb.md)

## Rule

- **Rule:** GuideLogitsProcessor.copy must return a new processor whose guide is an independent copy (guide.copy()) while sharing the tokenizer, so callers never share mutable guide state across processors.
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:** When modifying GuideLogitsProcessor.copy or the guide-copying path used by generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7dc13b6acc595c748311e45c.md)

## Rule

- **Rule:**
  ```text
  When modifying GuideLogitsProcessor.process_logits, preserve the caching and masking contract: guide states are cached keyed by hash of generated token tuples, _seq_start_idx is initialized from the first input length, and logits are masked by setting disallowed token positions to -inf across the batch.
  ```
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:**
  ```text
  When changing guide state caching, sequence start indexing, or logits masking in GuideLogitsProcessor.process_logits.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7e418e25d9889202316e847b.md)

## Rule

- **Rule:**
  ```text
  When modifying GuideLogitsProcessor, preserve the state fields tokenizer, guide, _guide_states (Dict[int, Any]), and _seq_start_idx (Optional[int]) so per-sequence guide-state tracking for structured generation remains intact.
  ```
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:** When changing GuideLogitsProcessor state fields or per-sequence guide tracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3cfe7eeb730559ced69fe3e.md)

## Rule

- **Rule:**
  ```text
  The structured processor module must import build_regex_from_schema from outlines_core.fsm.json_schema and convert_json_schema_to_str from outlines.fsm.json_schema, preserving the schema-to-regex dependency boundary.
  ```
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:** when modifying outlines/processors/structured.py or its schema-to-regex imports
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b5e2b00a99234c32cc938e56.md)
