# Constraints for `outlines/processors/__init__.py`

## Rule

- **Rule:** The processors package must re-export CFGLogitsProcessor, GuideLogitsProcessor, JSONLogitsProcessor, OutlinesLogitsProcessor, and RegexLogitsProcessor from structured.
- **Applies to:**
  - `outlines/processors/__init__.py`
- **Condition:** Modifying the processors package public exports.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7dd092002a6f86295b693b87.md)
