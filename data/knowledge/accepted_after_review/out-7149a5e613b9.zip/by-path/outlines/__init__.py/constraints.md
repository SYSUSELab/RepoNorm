# Constraints for `outlines/__init__.py`

## Rule

- **Rule:**
  ```text
  outlines.__all__ must expose clear_cache, disable_cache, get_cache, Function, prompt, Prompt, vectorize, and grammars; submodules generate, models, processors, and types are imported but must not be listed in __all__.
  ```
- **Applies to:**
  - `outlines/__init__.py`
- **Condition:**
  ```text
  when modifying outlines.__all__ or the public API surface of the outlines package
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2026b306560027cedf5f756c.md)
