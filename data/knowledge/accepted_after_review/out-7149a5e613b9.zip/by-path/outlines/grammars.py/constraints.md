# Constraints for `outlines/grammars.py`

## Rule

- **Rule:**
  ```text
  `outlines/grammars.py` is updated with a line including the new grammar.
  ```
- **Applies to:**
  - `outlines/grammars.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../../claims/CLAIM-94449d338b7694d5a9b6372c.md)
