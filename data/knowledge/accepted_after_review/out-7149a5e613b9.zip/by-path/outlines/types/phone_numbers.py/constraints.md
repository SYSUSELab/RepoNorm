# Constraints for `outlines/types/phone_numbers.py`

## Rule

- **Rule:**
  ```text
  When modifying the USPhoneNumber type in outlines/types/phone_numbers.py, preserve its exposure to JSON schema consumers as Annotated[str, WithJsonSchema({'type': 'string', 'pattern': US_PHONE_NUMBER})], so the phone number type remains a string with a regex pattern.
  ```
- **Applies to:**
  - `outlines/types/phone_numbers.py`
- **Condition:** When changing the USPhoneNumber type definition or its JSON schema exposure.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b1a692c6ed8e70e18134cc3c.md)
