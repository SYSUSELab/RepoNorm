# Constraints for `outlines/types/locales.py`

## Rule

- **Rule:** The locales module must compose locale types from dedicated USPhoneNumber and USZipCode type modules rather than defining them inline.
- **Applies to:**
  - `outlines/types/locales.py`
- **Condition:** When modifying outlines/types/locales.py or adding locale types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fc16698fcd4be30e2aa930fc.md)
