# Constraints for `outlines/samplers.py`

## Rule

- **Rule:**
  ```text
  When modifying BeamSearchSampler.__init__, preserve self.samples = beams (defaulting to 1) so the number of samples equals the beam count.
  ```
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:** When changing BeamSearchSampler initialization or sample count defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0527945b164a5ea469cf06e3.md)

## Rule

- **Rule:**
  ```text
  When modifying keep_top_p_logits, preserve the validation that rejects p values less than or equal to 0 or greater than 1 with a ValueError, keeping the valid top-p range as (0, 1].
  ```
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:** When changing top-p sampling validation or parameter handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-584525002966f4cce3c41a73.md)

## Rule

- **Rule:**
  ```text
  When modifying BeamSearchSampler.__call__, preserve the special case where all sequence_weights are zero restricts top-k selection to the first vocab_size logits, treating that state as the beginning of the search.
  ```
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:**
  ```text
  When changing BeamSearchSampler top-k selection or sequence_weights handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6f6911cfe49405b2de0dabbd.md)

## Rule

- **Rule:** When modifying BeamSearchSampler, preserve the documented contract that its samples attribute equals the number of beams.
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:** When changing BeamSearchSampler's samples attribute or beam handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a578ef28067fb672df412f2b.md)

## Rule

- **Rule:**
  ```text
  When modifying the top-k logits processor, preserve the safety property that it keeps min(k, vocab_size) tokens and masks all logits below the k-th top value with negative infinity, so k larger than the vocabulary is handled without error.
  ```
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:** Changing the top-k logits processor's masking logic or its handling of k relative to vocabulary size.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b6cd9e9dc95f28541604f866.md)

## Rule

- **Rule:** Custom sampler implementations must expose a samples attribute to satisfy the Sampler Protocol, so contributors adding or changing sampler classes must provide that attribute.
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:** When defining or modifying a sampler class intended to satisfy the Sampler Protocol.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f5fdd4b9ededdcb276fe3651.md)
