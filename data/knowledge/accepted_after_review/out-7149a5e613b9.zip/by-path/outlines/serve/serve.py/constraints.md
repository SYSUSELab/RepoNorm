# Constraints for `outlines/serve/serve.py`

## Rule

- **Rule:** When modifying the serve app, preserve the GET /health endpoint returning a 200 Response for health checks.
- **Applies to:**
  - `outlines/serve/serve.py`
- **Condition:** When changing the serve app's routing or health-check behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-56985b5959c9e68232bfbd31.md)
