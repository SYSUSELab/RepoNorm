# Constraints for `outlines/fsm/guide.py`

## Rule

- **Rule:**
  ```text
  When modifying StopAtEOSGuide.is_final_state, preserve the invariant that it compares the given state to the single stored final_state, so the guide model assumes exactly one final state per guide.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  When changing final-state comparison or guide final-state storage in StopAtEOSGuide.is_final_state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-238786309a1b70b2b8f2e02d.md)

## Rule

- **Rule:**
  ```text
  When modifying StopAtEOSGuide.get_next_instruction, preserve the terminal instruction protocol: return Write([self.eos_token_id]) when the state is final, otherwise Generate(None).
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:** When changing guide instruction generation or final-state handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-23c9381bb4f73681239265eb.md)

## Rule

- **Rule:**
  ```text
  CFGGuide.iter_valid_token_ids must yield eos_token_id immediately when state.parser_state is None, otherwise yield eos only if can_terminate_state(state) is true, and yield other token ids only if applying them via _get_parser_state_token_applied succeeds, swallowing ValueError, EOFError, UnexpectedToken, UnexpectedCharacters, and DedentError.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  When modifying CFGGuide.iter_valid_token_ids or the token-validity protocol it implements.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2ff1a4510094a3d56f2ab9ab.md)

## Rule

- **Rule:**
  ```text
  StopAtEOSGuide must define final_state=1, start_state=0, and initial_state=0, keeping both start_state and initial_state as a compatibility boundary until the documented TODO removes start_state.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  When modifying StopAtEOSGuide state constants or removing the deprecated start_state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-43e0e8ff20fb838372ce7831.md)

## Rule

- **Rule:** When modifying the Guide abstraction, preserve the ability for guides to emit Write instructions that append token sequences directly instead of generating them, as an alternative to regex-derived DFA advancement.
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:** Changing Guide subclasses or the Guide base contract for token advancement.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-594381a061d82405c46c3a8a.md)

## Rule

- **Rule:**
  ```text
  RegexGuide.from_regex must inject cached_create_states_mapping as _create_states_mapping while forwarding other kwargs, preserving the cached state-mapping extension point for regex guides.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  When modifying RegexGuide.from_regex or the state-mapping creation path for regex guides.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5ac4f4384ec7d1df8a857fe7.md)

## Rule

- **Rule:** When modifying StopAtEOSGuide.copy, preserve the behavior of returning self rather than a new object, so guide instances remain immutable/shareable and callers must not rely on copy producing independent mutable state.
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:** When changing guide copy behavior or adding mutable state to guides.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7e684f4ddf909a2bc464d225.md)

## Rule

- **Rule:**
  ```text
  When modifying StopAtEOSGuide.get_next_state in outlines/fsm/guide.py, preserve the state transition: return final_state when the token is eos or the state is already final, otherwise return initial_state.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  Modifying StopAtEOSGuide.get_next_state or its state transition logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b436bca03e6a41e87b2178d7.md)

## Rule

- **Rule:**
  ```text
  When modifying CFGGuide.must_terminate_state, preserve the definition of termination as parser state None or accepted symbols being a subset of {'$END'}, so termination means no legal continuations other than end-of-input.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:** When changing CFGGuide termination detection or accepted-symbol handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e0cc4d8eb9a2f8ee6610a047.md)

## Rule

- **Rule:**
  ```text
  cached_create_states_mapping must delegate directly to uncached_create_states_mapping with no caching applied, remaining a no-op placeholder.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  Modifying cached_create_states_mapping or adding caching to it.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eb7c0b8c5fb29286c2f60111.md)
