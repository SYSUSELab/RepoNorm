# Constraints for `outlines/fsm/types.py`

## Rule

- **Rule:**
  ```text
  When modifying float_format_fn in outlines/fsm/types.py, preserve the callback contract: it converts a matched string sequence to float via float(sequence).
  ```
- **Applies to:**
  - `outlines/fsm/types.py`
- **Condition:**
  ```text
  Modifying float_format_fn or float-typed schema formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2bef7363774ea9819575a669.md)

## Rule

- **Rule:**
  ```text
  When modifying python_types_to_regex, preserve the supported-type mapping contract: Annotated custom types use json_schema['pattern'], EnumMeta uses alternation of member names, and float, int, bool, date, time, and datetime are supported; any other Python type raises NotImplementedError directing users to open an issue.
  ```
- **Applies to:**
  - `outlines/fsm/types.py`
- **Condition:**
  ```text
  When changing supported type handling or the fallback error in python_types_to_regex.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9cf21204f50c02a6ea75d613.md)

## Rule

- **Rule:**
  ```text
  date_format_fn must parse strings with strptime using the fixed format '%Y-%m-%d', establishing the expected date string format for this FSM type conversion.
  ```
- **Applies to:**
  - `outlines/fsm/types.py`
- **Condition:**
  ```text
  When modifying date_format_fn or the date string format used in FSM type conversion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9db0c5d25ce083526c1e774f.md)
