# Constraints for `outlines/fsm/parsing.py`

## Rule

- **Rule:**
  ```text
  PartialTerminalInfo must carry priority, terminal_name, can_transition, and is_final, tracking transition capability and finality separately.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** Modifying PartialTerminalInfo fields or partial terminal matching.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0451b721aa02e4b019f84caf.md)

## Rule

- **Rule:**
  ```text
  When modifying the CFG parser construction in outlines/fsm/parsing.py, keep options['regex'] forced to True and the parser asserted as 'lalr'; do not allow callers to override these, and continue popping 'deterministic' and 'use_value_stack' as custom options rather than passing them to Lark.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  Modifying PartialLark.__init__ or the options handling for the CFG parser.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c6106bad8de15771a447907.md)

## Rule

- **Rule:**
  ```text
  When modifying the close-paren acceptance rule, preserve the rejection of CLOSE_PAREN token types when paren_level - 1 < 0 to prevent unbalanced closing parentheses.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  Modifying accepts_token_type in outlines/fsm/parsing.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0df1ecc4e044b3b02b0df338.md)

## Rule

- **Rule:** When modifying PartialLexerThread, preserve its role as the lark LexerThread subclass used for incremental/partial parsing.
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing the partial lexer thread or its lark integration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2a79555fdfbed6b1b11a3105.md)

## Rule

- **Rule:**
  ```text
  PartialParserState.feed_eof must synthesize a $END token (borrowing position from the last token, or a default position when none) and only feed it when the last token is absent, not partial, or has a final terminal; otherwise it must raise UnexpectedToken, enforcing that generation cannot end mid-partial-token.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  when modifying PartialParserState.feed_eof or end-of-generation token handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2e6da5eea5fa93f453945009.md)

## Rule

- **Rule:**
  ```text
  walk_fsm must return [] on a missing transition unless full_match is False and a prior final state was seen, in which case it returns the accepted prefix up to last_final_idx; with full_match True it must also return [] unless the last accepted final state is exactly the final token index.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying walk_fsm's handling of missing transitions, full_match, or accepted-prefix return values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-56f71197653c4641c31210cc.md)

## Rule

- **Rule:**
  ```text
  to_tuple must canonicalize values by sorting elements by str and memoizing the mapping in old_to_new, so equivalent sets produce stable tuple ordering.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying to_tuple or the canonicalization of parser values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-586bd17847a375eb6f026ae5.md)

## Rule

- **Rule:**
  ```text
  When modifying PartialParsingFrontend in outlines/fsm/parsing.py, do not reintroduce the abandoned _state_transition_map design built from parse_table.states and a contextual lexer; the commented-out code and TODO document it as a known performance concern.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** Modifying PartialParsingFrontend or considering a state-transition-map optimization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5ee9751b49f8c88cb28ba0cb.md)

## Rule

- **Rule:**
  ```text
  When modifying PartialTokensInfo, preserve the dataclass fields fsm_state_seq, is_not_finished, terminals_and_info, and final_terminals_and_info so in-progress terminals remain distinguished from final terminals for partial-token parsing.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing PartialTokensInfo fields or partial-token terminal tracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6a5079bb6276538675fdd24f.md)

## Rule

- **Rule:**
  ```text
  When modifying PartialParserState.__copy__ in outlines/fsm/parsing.py, preserve the copy semantics: parse_conf, lexer, and state_stack are copied, value_stack is deepcopied, and use_value_stack is preserved.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  Modifying PartialParserState.__copy__ or parser state copying behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-724ba491ba650518c20f57d5.md)

## Rule

- **Rule:**
  ```text
  PartialLark._build_parser must preserve the inlined lark _construct_parsing_frontend type assertions and the side effects that mutate parser_conf.parser_type and lexer_conf.lexer_type, so contributors changing parser/lexer options keep these invariants intact.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying PartialLark._build_parser or the parser/lexer option construction path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7917386123b7ddfc8d88c862.md)

## Rule

- **Rule:**
  ```text
  When modifying PartialParserConf, preserve the __serialize_fields__ declaration including rules, start, parser_type, deterministic, and use_value_stack so serialization preserves exactly those fields.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing PartialParserConf serialization fields or adding/removing configuration attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa7a6f38134aba80c2574094.md)

## Rule

- **Rule:**
  ```text
  When modifying PartialParserState.feed_token_no_stack, preserve its deliberate divergence from ParserState.feed_token: it omits value-stack tracking to avoid parse-tree maintenance cost while still raising UnexpectedToken with the expected uppercase token set on KeyError.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When changing feed_token_no_stack or its relationship to ParserState.feed_token.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b0f2e200f7192841a7372620.md)

## Rule

- **Rule:**
  ```text
  When modifying PartialParserConf.__init__, preserve the per-instance configurability of the deterministic and use_value_stack flags, which are stored after delegating rules/callbacks/start to the base class.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing parser configuration initialization or flag handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c8f214ce9b65cd1b7291cc8d.md)

## Rule

- **Rule:**
  ```text
  When modifying fsm_union, preserve the API contract that it returns both the aggregate FSM and a map from each component FSM to its transitions, finals, and old-to-new state mapping in the aggregate FSM.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When changing the return value or mapping structure of fsm_union.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d12ce2ff94678c3b61bce6ba.md)

## Rule

- **Rule:**
  ```text
  When modifying the lazily cached termset_fsm_info property, preserve the caching behavior: compute _termset_fsm_info only when None and return the cached value on subsequent accesses.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  Modifying termset_fsm_info in outlines/fsm/parsing.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d23f5c1cb26cb85a45db5943.md)

## Rule

- **Rule:**
  ```text
  When modifying PartialLALRParser.__init__ for deterministic parser_conf, preserve the tuple-keyed parse table rebuild, start/end state remapping, optional IntParseTable conversion with states_to_rulesets recording, and forced debug=True.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing PartialLALRParser initialization or deterministic parse-table construction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d9ed8b5a234ce85ee76770ef.md)

## Rule

- **Rule:**
  ```text
  When modifying PartialBasicLexer.match, preserve the delegation to self.scanner.match with text, pos, and optional last_fsm_state_seq, maintaining the scanner matching interface.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing lexer matching or scanner delegation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dfae0b39414b76e03e924fe1.md)

## Rule

- **Rule:**
  ```text
  When modifying parser stream processing in outlines/fsm/parsing.py, preserve the invariant that paren level is updated before yielding tokens, that a close paren making paren_level negative raises UnexpectedToken, and that newline tokens are routed through handle_NL rather than yielded directly.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  Modifying PartialIndenter._process or the token stream processing logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e2c2724115206b74d462cd86.md)

## Rule

- **Rule:**
  ```text
  When modifying fsm_union.follow, preserve the failure contract: follow raises OblivionError when no indexed FSM has a valid transition for the new transition, making OblivionError the signal for an impossible combined FSM step.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When changing transition lookup or error signaling in fsm_union.follow.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e61f36dcc25e4bd5dd07beee.md)

## Rule

- **Rule:**
  ```text
  When modifying PartialParser.parse_from_state, preserve the contract that lexer tokens are fed into the parser state, EOF is fed only when is_end is true and the last token is not partial, UnexpectedInput is re-raised with an attached InteractiveParser, and the state stack dump is printed only when self.debug is set.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When changing token feeding, EOF handling, or exception behavior in PartialParser.parse_from_state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f80c805b753d5332d5c0793f.md)
