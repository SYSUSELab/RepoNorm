# Constraints for `.github/workflows/build_documentation.yml`

## Rule

- **Rule:**
  ```text
  The documentation build workflow runs on pull requests targeting the main branch and can also be triggered manually via workflow_dispatch.
  ```
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: pull_request: branches: [main] workflow_dispatch:
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-76dda2330d693052ff30aed5.md)

## Rule

- **Rule:** The documentation build job runs on ubuntu-latest and sets up Python 3.10.
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9734669421260a05413f3d60.md)

## Rule

- **Rule:**
  ```text
  The documentation build step installs dependencies from requirements-doc.txt and runs mkdocs build, with GOOGLE_ANALYTICS_KEY supplied from the GOOGLE_ANALYTICS_KEY secret.
  ```
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-99a4e82cf83080b6825e1482.md)
