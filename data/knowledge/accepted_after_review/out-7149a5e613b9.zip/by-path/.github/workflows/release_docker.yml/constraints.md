# Constraints for `.github/workflows/release_docker.yml`

## Rule

- **Rule:**
  ```text
  The workflow builds and pushes a Docker image tagged outlinesdev/outlines:latest and outlinesdev/outlines:<release tag or manual release_tag input>, with build arg BUILDKIT_CONTEXT_KEEP_GIT_DIR=true.
  ```
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-125feb7e0c27e091795e6082.md)

## Rule

- **Rule:**
  ```text
  The Release Docker workflow can be triggered manually via workflow_dispatch with a release_tag input defaulting to 'latest'.
  ```
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3dda14bdcd61b82a76a329d5.md)

## Rule

- **Rule:** The Release Docker workflow runs on release events of type created.
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Condition:** workflow predicate: release: types: - created
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-48fb4c07ff58db4c37723ed0.md)

## Rule

- **Rule:** The workflow cleans the docker cache by running docker system prune --all --force.
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5a7a0ee00b49a4088266b242.md)

## Rule

- **Rule:** The release-job runs on ubuntu-latest in the release environment.
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-730f9ce0e8a9e9b87c91070b.md)

## Rule

- **Rule:**
  ```text
  The workflow logs in to Docker Hub using the DOCKERHUB_USERNAME and DOCKERHUB_TOKEN secrets.
  ```
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8f3ac65f8c321167a4227915.md)
