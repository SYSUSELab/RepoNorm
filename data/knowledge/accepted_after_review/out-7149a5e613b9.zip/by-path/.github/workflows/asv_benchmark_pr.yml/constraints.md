# Constraints for `.github/workflows/asv_benchmark_pr.yml`

## Rule

- **Rule:**
  ```text
  The Benchmark PR workflow runs on push, pull_request (types synchronize and labeled), and workflow_dispatch events.
  ```
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Condition:**
  ```text
  workflow predicate: push: pull_request: types: [synchronize, labeled] workflow_dispatch:
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1b700e59373d72ee84a7f210.md)

## Rule

- **Rule:** The workflow creates an ASV machine config named gh-runner with asv machine --machine gh-runner --yes.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44cf7fa7e80a7fba02ddf0ad.md)

## Rule

- **Rule:**
  ```text
  The workflow uses Python version 3.10 via the PYTHON_VERSION environment variable.
  ```
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9394c4fe0fa5e0ef93e3df67.md)

## Rule

- **Rule:** The workflow installs asv, virtualenv, and lf-asv-formatter via pip.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b3a8f2fd1dc6c566eeda5116.md)

## Rule

- **Rule:**
  ```text
  The workflow's default run working directory is ${{ env.WORKING_DIR }}, which is set to ${{ github.workspace }}/benchmarks.
  ```
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b4bae798c8aca409d479a685.md)

## Rule

- **Rule:** The benchmark-pr job runs only when the pull request has the 'run-benchmarks' label or the ref is refs/heads/main.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Condition:**
  ```text
  workflow predicate: ${{ contains(github.event.pull_request.labels.*.name, 'run-benchmarks') || github.ref == 'refs/heads/main' }}
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ff412d7842d7977c43d3641c.md)
