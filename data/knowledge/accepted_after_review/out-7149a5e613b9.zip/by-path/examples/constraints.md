# Constraints for `examples`

## Rule

- **Rule:** Examples that wrap a schema-typed payload for generation define a dataclass pairing a description string with the schema-typed field, so the example's generation input is self-describing.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** when adding or modifying an example that wraps a schema-typed payload for generation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-046d96bc38fce69e7e3422f2.md)

## Rule

- **Rule:** Examples that call external HTTP APIs build the request URL with explicit query parameters (such as format=json) and parse the response to extract only the fields needed for the example's output shape.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** when adding or modifying an example that calls an external HTTP API and returns a derived value
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-44978339cb734b3c6974de65.md)

## Rule

- **Rule:** Prompt templates in examples are defined as @outlines.prompt-decorated functions whose docstrings interpolate the function's arguments by name using Jinja-style {{placeholder}} syntax, including for-loops and attribute access over iterable arguments.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** when adding or modifying an @outlines.prompt-decorated template function in an example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5815bb922171b682b053380b.md)

## Rule

- **Rule:**
  ```text
  Example scripts that integrate outlines with transformers must construct JSONPrefixAllowedTokens with the schema, tokenizer-or-pipe, and whitespace_pattern, then pass it as prefix_allowed_tokens_fn to the pipeline.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that integrates outlines with a transformers pipeline.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5c62273735dc1e4efa447979.md)

## Rule

- **Rule:** Examples that constrain generation to a fixed set of choices use outlines.generate.choice with the allowed string or enum members, rather than free-text generation, when the output must be one of a known finite set.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** when adding or modifying an example whose output must be one of a fixed finite set of choices
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-653e593869dc75ab2e222367.md)

## Rule

- **Rule:** Examples that derive a platform-specific model tag from a model identifier use a deterministic transformation (such as lowercasing and replacing '/' with '--') so the tag is reproducible from the model ID.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** when adding or modifying an example that derives a platform-specific model tag from a model identifier
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6acfc42f9bc18acc1d6a13f1.md)

## Rule

- **Rule:**
  ```text
  Integration examples wire outlines logits processors into the target runtime by constructing the processor with the schema and runtime handle, then passing it through the runtime's sampling parameters (e.g. vllm.SamplingParams(logits_processors=[...]) or a LogitsProcessorList for llama.create_completion).
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an integration example that constrains generation with an outlines logits processor, construct the processor with the schema and runtime handle and pass it through the runtime's sampling-parameter or processor-list mechanism rather than calling the model directly.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7997f36cbb044f85b96fd080.md)

## Rule

- **Rule:** Example scripts that translate a larger agent workflow must document the simplifications (e.g. omitted vector store retrieval, reduced cycle count) in the example itself.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that is a simplified translation of a larger agent workflow.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-89ea36de0c5f0d71c4ef7d86.md)

## Rule

- **Rule:** Examples that generate structured output pass a schema to outlines.generate.json (or an equivalent constrained generator) and the schema is expressed as a pydantic BaseModel or a raw JSON schema with definitions/$ref, matching the generator's accepted input forms.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** when adding or modifying an example that calls outlines.generate.json with a schema argument
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a8a30e894d27a7b828d7cf8f.md)

## Rule

- **Rule:** mypy excludes the examples directory from type checking.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ac7969e2f2e96fbd7661acac.md)

## Rule

- **Rule:** Examples that document performance tradeoffs intentionally avoid length constraints (such as constr) on free-text fields when they dramatically increase generation time, while still using collection constraints (such as conlist) where needed.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** when adding or modifying an example schema that includes length or collection constraints
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bcedc1cedb5dd9e5740b1d81.md)

## Rule

- **Rule:** Example scripts that demonstrate self-consistency must generate multiple samples, extract the answer from each sample, and report the most frequent answer with a consensus percentage.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that demonstrates self-consistency or multi-sample aggregation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c6e8e32de8b08891a2f8d37e.md)

## Rule

- **Rule:**
  ```text
  Prompt templates in the examples may reference attributes of passed objects (e.g. {{task.task_name}}) and iterate over collections of example objects, not only interpolate simple scalar variables.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When writing or editing a prompt template in an example, use Jinja attribute access and iteration over passed objects where the prompt needs structured data, rather than flattening all inputs to scalars.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cf94dd9a13e0446cd5d531ab.md)

## Rule

- **Rule:** Multi-stage example workflows chain outlines generation calls by appending the first answer plus a follow-up question to the prompt before generating a second answer and returning the completed prompt.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying a multi-stage example workflow, append the prior answer and follow-up question to the prompt before the next generation call rather than issuing independent generations.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-dc87fab4d81cc0a6cd588fda.md)

## Rule

- **Rule:** Prompt functions in the examples are defined by decorating a function with @outlines.prompt and placing the Jinja-style template in the function docstring, using {{ ... }} placeholders for runtime values.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying a reusable prompt function in an example script, define it with the @outlines.prompt decorator and put the template in the docstring rather than building the prompt string in the function body.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-de0262cb45de128fa4caa903.md)

## Rule

- **Rule:** Example scripts that implement a custom logits processor must not iterate over the entire tokenizer vocabulary with per-token deep copies of parser state without addressing the documented performance limitation.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that implements a custom logits processor for constrained generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ff8e6ba5a468ab68ecc8ab0d.md)
