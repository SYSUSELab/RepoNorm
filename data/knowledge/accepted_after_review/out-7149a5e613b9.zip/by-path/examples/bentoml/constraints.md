# Constraints for `examples/bentoml`

## Rule

- **Rule:** The BentoML import example saves both the tokenizer and the model into the BentoML model reference path, establishing the expected artifact layout for packaging a transformers model as a Bento.
- **Applies to:**
  - `examples/bentoml/**/*.py`
- **Condition:** When adding or modifying a BentoML packaging example for a transformers model, save both the tokenizer and the model into the BentoML model reference path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b8ede1aa8a3f2d142d509268.md)
