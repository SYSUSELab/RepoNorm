# Constraints for `examples/bentoml/service.py`

## Rule

- **Rule:**
  ```text
  The BentoML service example must preserve the service decorator's traffic timeout of 300 and GPU resource configuration (gpu 1, gpu_type nvidia-l4), and must resolve the model via bentoml.models.get(BENTO_MODEL_TAG) at class definition time.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
- **Condition:** When changing deployment or resource configuration in the BentoML service example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f18b7b1419d0dac423a267fc.md)
