# Constraints for `examples/modal_example.py`

## Rule

- **Rule:**
  ```text
  The Modal example must defer importing outlines and loading the transformers model into an import_model() function, and expose a local entrypoint main that calls generate.remote(prompt).
  ```
- **Applies to:**
  - `examples/modal_example.py`
- **Condition:** When modifying model initialization or the remote invocation entrypoint in the Modal example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-348d7bdc2de1f34b9c0679a6.md)
