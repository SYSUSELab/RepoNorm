# Constraints for `examples/babyagi.py`

## Rule

- **Rule:**
  ```text
  The BabyAGI example's one_cycle must pop the highest-priority task, complete a perform-task prompt, create new tasks from the result with incrementing task ids, re-prioritize the remaining task list, and return the executed task, result, prioritized tasks, and updated id counter.
  ```
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When modifying the BabyAGI task-execution cycle in examples/babyagi.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-45c5e60fb1583a383a19126f.md)
