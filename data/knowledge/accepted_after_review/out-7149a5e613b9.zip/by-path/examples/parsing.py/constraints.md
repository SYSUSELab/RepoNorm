# Constraints for `examples/parsing.py`

## Rule

- **Rule:**
  ```text
  The parser-based masking example must construct a PartialLark parser via open_from_package with package 'tests', grammar file 'partial_python.lark', parser='lalr', postlex=PartialPythonIndenter(), and start='file_input', and use it in a ParserLogitsProcessor during generation.
  ```
- **Applies to:**
  - `examples/parsing.py`
- **Condition:** When modifying parser-based masking construction or usage in examples/parsing.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-46060e29481281bdc1bae5d4.md)

## Rule

- **Rule:**
  ```text
  The example parser wrapper must initialize parser_state from parser.parse("") and seed states_stack with that state, with token_seq None and token_idx 0.
  ```
- **Applies to:**
  - `examples/parsing.py`
- **Condition:** When modifying parser state initialization in the example parser wrapper.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-72a1b4413f887241313490dd.md)
