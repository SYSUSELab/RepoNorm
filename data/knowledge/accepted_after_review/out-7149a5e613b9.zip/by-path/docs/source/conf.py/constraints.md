# Constraints for `docs/source/conf.py`

## Rule

- **Rule:** Read the Docs uses docs/source/conf.py as the Sphinx configuration file.
- **Applies to:**
  - `docs/source/conf.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-295d1b3e9ebd4334e53f3090.md)
