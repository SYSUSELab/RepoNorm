# Constraints for `docs`

## Rule

- **Rule:** Read the Docs documentation builds fail on warnings.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5c80ec00215f1dab986392b7.md)

## Rule

- **Rule:** There is no builtin false positive testing utility; smoke testing is the recommended way to test a new grammar.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-bce05b4ceea1fd5ebe48780d.md)

## Rule

- **Rule:** Read the Docs builds documentation with the html Sphinx builder.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d199b82b18589c1d2c1429a6.md)

## Rule

- **Rule:**
  ```text
  Run `mkdocs serve` to view the documentation locally, with the served site updating on each change.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-dd17e48c66e5ab9ac65c6851.md)
