# Rule details

- **Rule:**
  ```text
  _save_data_to_local_file must write training data to a UUID-named JSONL file in the finetune directory, validating each item against the selected TrainDataFormat (CHAT or COMPLETION) before serializing with ujson.
  ```
- **Applies to:**
  - `dspy/clients/databricks.py`
- **Condition:** When modifying finetuning data persistence or the TrainDataFormat validation path.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_save_data_to_local_file builds a UUID-named JSONL path in the finetune directory, validates each item against the selected TrainDataFormat, and serializes with ujson.
```

- **Sources:**
  - `dspy/clients/databricks.py:306-322`
