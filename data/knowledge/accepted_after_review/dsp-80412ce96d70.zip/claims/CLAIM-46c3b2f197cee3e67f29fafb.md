# Rule details

- **Rule:** The MkDocs documentation source directory is configured as "docs/".
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
docs_dir: "docs/"

```

- **Sources:**
  - `docs/mkdocs.yml:9`

## Review evidence locations

- `docs/mkdocs.yml:1-218`
