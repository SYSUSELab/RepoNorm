# Rule details

- **Rule:** The mkdocstrings Python handler shows signature annotations.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
                    show_signature_annotations: true

```

- **Sources:**
  - `docs/mkdocs.yml:210`
