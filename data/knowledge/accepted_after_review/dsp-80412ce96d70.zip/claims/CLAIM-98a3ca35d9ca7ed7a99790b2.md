# Rule details

- **Rule:**
  ```text
  The llm_call_test job runs pytest with -m llm_call --llm_call -vv --durations=5 over the tests/ directory.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: uv run -p .venv pytest -m llm_call --llm_call -vv --durations=5 tests/

```

- **Sources:**
  - `.github/workflows/run_tests.yml:127`
