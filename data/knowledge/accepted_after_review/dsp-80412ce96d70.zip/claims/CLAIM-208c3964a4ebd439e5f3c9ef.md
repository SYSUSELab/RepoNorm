# Rule details

- **Rule:**
  ```text
  SignatureMeta.__new__ must default unannotated FieldInfo attributes to str, preserve field order in __annotations__, inherit instructions from a base Signature when __doc__ is None, fall back to _default_instructions, and inject prefix/desc into each field's json_schema_extra.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  Modifying SignatureMeta.__new__ field handling or signature normalization
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/signatures/signature.py:137-180`
