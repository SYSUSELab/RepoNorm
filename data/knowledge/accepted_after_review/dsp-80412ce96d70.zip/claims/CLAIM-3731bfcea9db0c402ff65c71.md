# Rule details

- **Rule:** Signature parsing must auto-resolve module-level custom type annotations to the actual class, and a signature with no input or output fields must raise TypeError; signature equality must distinguish signatures whose field names differ.
- **Applies to:**
  - `tests/signatures/**/*.py`
- **Condition:** when modifying signature parsing, field resolution, or equality behavior in signature tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/signatures/test_custom_types.py:46-56`
- `tests/signatures/test_signature.py:28-39`
- `tests/signatures/test_signature.py:107-116`
