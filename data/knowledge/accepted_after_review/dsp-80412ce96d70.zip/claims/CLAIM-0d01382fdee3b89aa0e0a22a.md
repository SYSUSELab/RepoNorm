# Rule details

- **Rule:**
  ```text
  The build-and-publish-pypi job depends on extract-tag and build-and-publish-test-pypi, and only runs when github.repository_owner == 'stanfordnlp'.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Condition:**
  ```text
  workflow predicate: github.repository_owner == 'stanfordnlp'
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    needs: [extract-tag, build-and-publish-test-pypi]
    # Only publish to PyPI if the repository owner is stanfordnlp
    if: github.repository_owner == 'stanfordnlp'

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:68-70`

## Review evidence locations

- `.github/workflows/build_and_release.yml:1-144`
