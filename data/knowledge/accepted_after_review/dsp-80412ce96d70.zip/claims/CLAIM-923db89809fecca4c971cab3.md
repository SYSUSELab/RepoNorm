# Rule details

- **Rule:**
  ```text
  The litellm test server's _get_mock_llm_response must first call _throw_exception_based_on_content_if_applicable, then return a litellm.completion with a fixed mock_response, so tests can trigger server-side exceptions based on request content.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying the litellm test server mock response logic to change exception triggering or mock completion behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils/server/litellm_server.py:44-51`
