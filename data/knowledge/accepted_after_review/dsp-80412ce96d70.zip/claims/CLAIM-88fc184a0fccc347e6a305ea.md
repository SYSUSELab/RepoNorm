# Rule details

- **Rule:**
  ```text
  Usage tracking tests must assert that track_usage() records per-LM usage_data keyed by the LM identifier and that get_total_tokens() returns a dict keyed by that same LM identifier, and UsageTracker.get_total_tokens must aggregate prompt_tokens, completion_tokens, total_tokens, and nested prompt_tokens_details/completion_tokens_details by summing across entries.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:** When modifying usage tracking tests or the UsageTracker aggregation behavior they exercise, including per-LM keying and nested token detail summation.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The file asserts per-LM usage_data keying by LM identifier (test_track_usage_context_manager) and sums prompt_tokens, completion_tokens, total_tokens, and nested detail dicts across entries.
```

- **Sources:**
  - `tests/utils/test_usage_tracker.py`
