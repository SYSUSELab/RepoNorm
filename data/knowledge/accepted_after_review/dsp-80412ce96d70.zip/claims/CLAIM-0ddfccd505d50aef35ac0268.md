# Rule details

- **Rule:** The mkdocstrings rendering options show docstrings when absent.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
                        show_if_no_docstring: true

```

- **Sources:**
  - `docs/mkdocs.yml:216`

## Review evidence locations

- `docs/mkdocs.yml:1-218`
