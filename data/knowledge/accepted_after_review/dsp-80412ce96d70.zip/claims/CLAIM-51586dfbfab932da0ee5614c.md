# Rule details

- **Rule:** Pushing a semver tag by a repo maintainer triggers the GitHub Action that extracts the tag as the version.
- **Applies to:**
  - `.github/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
1. Maintainer of the repo pushes a tag following [semver](https://semver.org/) versioning for the new release.
2. This triggers the github action which extracts the tag (the version)

```

- **Sources:**
  - `.github/.internal_dspyai/internals/build-and-release.md:9-10`

## Review evidence locations

- `.github/.internal_dspyai/internals/release-checklist.md:1-24`
