# Rule details

- **Rule:**
  ```text
  Running `mkdocs build` generates a static build of the documentation site in the `site` directory.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

````text
   mkdocs build
   ```

This will generate a static build of the documentation site in the `site` directory. You can then serve this directory to view the site locally using:

````

- **Sources:**
  - `docs/README.md:46-49`

## Review evidence locations

- `docs/README.md:13-74`
