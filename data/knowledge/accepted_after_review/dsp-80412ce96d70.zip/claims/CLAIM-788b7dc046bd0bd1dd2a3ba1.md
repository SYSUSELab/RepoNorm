# Rule details

- **Rule:** Tests for nested pydantic models in adapters must define and exercise nested BaseModel structures as input and output field types.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
  - `tests/adapters/test_tool.py`
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying adapter or reliability tests that exercise nested pydantic model field types.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_json_adapter.py:124-157`
