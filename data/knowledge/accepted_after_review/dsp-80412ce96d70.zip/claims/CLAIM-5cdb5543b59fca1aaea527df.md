# Rule details

- **Rule:**
  ```text
  ParallelExecutor.execute must return results in the same order as the input tasks, even when num_threads > 1; tests assert this ordering invariant for multi-threaded execution.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** when modifying ParallelExecutor.execute or its tests to change worker-thread scheduling or result collection
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_parallelizer.py:8-17`
