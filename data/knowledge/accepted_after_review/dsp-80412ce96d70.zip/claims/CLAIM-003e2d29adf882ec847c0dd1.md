# Rule details

- **Rule:** Generated reliability programs are loaded by resolving a directory to program.py, raising ValueError when the path is missing, and returning the module's program and ProgramInputs; generated programs must therefore expose program and ProgramInputs at that layout.
- **Applies to:**
  - `tests/reliability/**/*.py`
- **Condition:** when adding or modifying generated reliability program directories or the loader that resolves them
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:229-245`
