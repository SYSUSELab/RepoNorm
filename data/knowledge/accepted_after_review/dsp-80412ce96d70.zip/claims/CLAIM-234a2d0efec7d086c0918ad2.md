# Rule details

- **Rule:**
  ```text
  dotdict_lax must map attribute access to dict.get, attribute assignment to dict.__setitem__, and attribute deletion to dict.__delitem__, so missing keys return None instead of raising AttributeError.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:**
  ```text
  When modifying dotdict_lax or its attribute access semantics in dspy/dsp/utils/utils.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/dsp/utils/utils.py:95-98`
