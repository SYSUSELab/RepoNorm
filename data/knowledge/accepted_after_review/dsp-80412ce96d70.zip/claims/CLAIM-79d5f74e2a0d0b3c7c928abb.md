# Rule details

- **Rule:**
  ```text
  When modifying grouper, preserve collecting data into fixed-length chunks using itertools.zip_longest with a fill value, the standard itertools recipe for chunking iterables.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:** changing grouper chunking implementation
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/dsp/utils/utils.py:180-188`
