# Rule details

- **Rule:**
  ```text
  Tests exercising named_sub_modules must verify that shared sub-module references are deduplicated rather than listed twice.
  ```
- **Applies to:**
  - `tests/primitives/test_module.py`
- **Condition:**
  ```text
  when modifying or extending named_sub_modules deduplication tests
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/primitives/test_module.py:122-140`
