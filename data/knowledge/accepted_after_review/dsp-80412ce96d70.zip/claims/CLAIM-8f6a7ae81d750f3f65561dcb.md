# Rule details

- **Rule:** The check-added-large-files hook runs with args --maxkb=1024.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: check-added-large-files
        args: ["--maxkb=1024"]

```

- **Sources:**
  - `.pre-commit-config.yaml:25-26`

## Review evidence locations

- `.pre-commit-config.yaml:1-28`
