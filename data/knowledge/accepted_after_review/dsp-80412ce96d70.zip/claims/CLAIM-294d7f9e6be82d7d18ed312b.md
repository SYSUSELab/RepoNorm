# Rule details

- **Rule:** Contributors must fix documentation build failures before pushing.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
If you see the build failing make sure to fix it before pushing.

```

- **Sources:**
  - `docs/README.md:55`

## Review evidence locations

- `docs/README.md:13-74`
