# Rule details

- **Rule:**
  ```text
  The reliability test helper _get_judge_program must return dspy.Predict(JudgeSignature); do not construct judge programs with a different module or signature.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  when modifying _get_judge_program or how judge programs are constructed in reliability tests
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/reliability/utils.py defines _get_judge_program, whose body returns dspy.Predict(JudgeSignature), matching the r1 rule that the helper must return dspy.Predict(JudgeSignature).
```

- **Sources:**
  - `tests/reliability/utils.py`
