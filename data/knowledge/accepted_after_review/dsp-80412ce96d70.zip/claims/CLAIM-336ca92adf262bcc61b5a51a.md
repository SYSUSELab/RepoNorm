# Rule details

- **Rule:** All pre-commit checks must pass before creating a pull request.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Please ensure all pre-commit checks pass before creating your pull request. If you're unsure about any
formatting issues, feel free to commit your changes and let the pre-commit hooks fix them automatically.

```

- **Sources:**
  - `CONTRIBUTING.md:73-74`

## Review evidence locations

- `CONTRIBUTING.md:14-147`
