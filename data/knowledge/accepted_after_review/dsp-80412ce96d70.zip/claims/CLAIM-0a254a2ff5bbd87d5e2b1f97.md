# Rule details

- **Rule:** Tests for the JSON adapter's handling of non-string input types must define a Signature with a non-string input field (such as an image wrapper) and a string output field, so adapter formatting of non-string inputs is exercised.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** when adding or modifying JSON adapter tests that exercise non-string input types
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_json_adapter.py:290-306`
