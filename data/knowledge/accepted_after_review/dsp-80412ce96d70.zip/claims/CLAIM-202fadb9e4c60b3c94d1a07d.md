# Rule details

- **Rule:** SignatureMeta must be defined as a subclass of type(BaseModel), making signature classes use a Pydantic-model metaclass.
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:** When modifying SignatureMeta or the metaclass of signature classes in dspy/signatures/signature.py.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/signatures/signature.py:34-40`
