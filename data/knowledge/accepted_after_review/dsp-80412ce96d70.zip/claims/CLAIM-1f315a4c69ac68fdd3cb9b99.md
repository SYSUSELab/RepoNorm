# Rule details

- **Rule:**
  ```text
  Coverage reporting excludes lines matching the configured patterns from coverage measurement, including "pragma: no cover", "def __repr__", "if self.debug:", "raise AssertionError", "raise NotImplementedError", "if __name__ == '__main__':", "logger", "try", "except", the regex "^\s*self\.\w+(:\s*[^=]+)?\s*=.*$", and "continue".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
exclude_lines = [
    "pragma: no cover",
    "def __repr__",
    "if self.debug:",
    "raise AssertionError",
    "raise NotImplementedError",
    "if __name__ == '__main__':",
    "logger",
    "try",
    "except",
    "^\\s*self\\.\\w+(:\\s*[^=]+)?\\s*=.*$",
    "continue",
]

```

- **Sources:**
  - `pyproject.toml:102-114`

## Review evidence locations

- `pyproject.toml:5-171`
