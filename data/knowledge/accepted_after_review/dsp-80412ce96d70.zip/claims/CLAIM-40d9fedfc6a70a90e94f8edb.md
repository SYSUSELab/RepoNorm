# Rule details

- **Rule:**
  ```text
  Ruff excludes dspy/__metadata__.py and tests/reliability/*.py from its checks.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
exclude = [
  "dspy/__metadata__.py",
  "tests/reliability/*.py",
]

```

- **Sources:**
  - `pyproject.toml:118-121`
