# Rule details

- **Rule:**
  ```text
  Reliability test inputs must be named input<N>.json and the generator CLI must be invoked with --dst_path (required) plus optional --num_inputs (default 1), --program_instructions, and --input_instructions; find_max_input_number returns the highest existing numeric suffix and 0 when the directory is absent.
  ```
- **Applies to:**
  - `tests/reliability/generate/__main__.py`
  - `tests/reliability/generate/utils.py`
- **Condition:** When adding or modifying reliability test-input generation entry points or input file naming
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/__main__.py:5-28`
