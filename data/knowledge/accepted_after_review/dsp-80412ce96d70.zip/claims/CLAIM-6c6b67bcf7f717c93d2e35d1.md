# Rule details

- **Rule:**
  ```text
  XML adapter format_field_with_value must wrap lists of Pydantic models in an <items> element containing JSON-serialized model dumps, and parse must reconstruct the list back into typed instances preserving field values.
  ```
- **Applies to:**
  - `tests/adapters/test_xml_adapter.py`
- **Condition:** When modifying XML adapter list serialization or parsing behavior in adapter tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_xml_adapter.py:115-140`
