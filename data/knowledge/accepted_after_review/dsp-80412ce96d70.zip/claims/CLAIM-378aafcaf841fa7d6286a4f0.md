# Rule details

- **Rule:**
  ```text
  When modifying ArborProvider.initialize, preserve reading each GRPO training hyperparameter from train_kwargs with a fallback to DEFAULT_TRAIN_KWARGS so callers may override any subset of training parameters.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:** changing ArborProvider.initialize training hyperparameter resolution
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/lm_local_arbor.py:84-117`
