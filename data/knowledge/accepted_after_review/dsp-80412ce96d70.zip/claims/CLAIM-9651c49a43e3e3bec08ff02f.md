# Rule details

- **Rule:**
  ```text
  When modifying ParallelExecutor._wrap_function or its safe_func, preserve the cancellation and error-accounting behavior: return None immediately when cancel_jobs is set, and on exception increment error_count under error_lock, set cancel_jobs once error_count reaches max_errors, and log with or without traceback depending on provide_traceback.
  ```
- **Applies to:**
  - `dspy/utils/parallelizer.py`
- **Condition:** Changing the parallel execution wrapper or its error handling in ParallelExecutor.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/utils/parallelizer.py:50-67`
