# Rule details

- **Rule:**
  ```text
  Saving a Predict or CustomModel with save_program=True must produce metadata.json and program.pkl, and dspy.load must restore a Predict with an equal signature or a CustomModel with the same number of predictors and each predictor's signature equal to the original's.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when modifying save/load behavior or the tests that pin the on-disk save/load contract
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_saving.py:10-37`
