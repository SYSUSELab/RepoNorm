# Rule details

- **Rule:**
  ```text
  Tests for Predict LM state serialization must assert that dump_state matches the expected dict of model, model_type, temperature, max_tokens, num_retries, cache, cache_in_memory, finetuning_model, launch_kwargs, and train_kwargs, and that dump/load_state round-trips the LM configuration.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** when adding or modifying Predict LM state serialization tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/predict/test_predict.py:40-66`
