# Rule details

- **Rule:**
  ```text
  The LiteLLM test server's streaming method must return a single `GenericStreamingChunk` with `is_finished=True`, `finish_reason='stop'`, and zeroed usage, modeling a one-chunk streamed response.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when adding or modifying the LiteLLM test server's streaming response behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils/server/litellm_server.py:21-30`
