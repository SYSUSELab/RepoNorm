# Rule details

- **Rule:**
  ```text
  When modifying dspy.utils.logging_utils, preserve the module-level LOGGING_LINE_FORMAT and LOGGING_DATETIME_FORMAT constants and the shared DSPY_LOGGING_STREAM instance used across DSPy logging.
  ```
- **Applies to:**
  - `dspy/utils/logging_utils.py`
- **Condition:**
  ```text
  Changing shared logging format constants or the logging stream in logging_utils.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/utils/logging_utils.py:5-37`
- `dspy/utils/logging_utils.py:57-63`
