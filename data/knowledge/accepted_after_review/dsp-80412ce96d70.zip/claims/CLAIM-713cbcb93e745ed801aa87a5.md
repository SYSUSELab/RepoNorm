# Rule details

- **Rule:**
  ```text
  Tests gated behind opt-in pytest flags must be registered in SKIP_DEFAULT_FLAGS and skipped by pytest_collection_modifyitems unless the matching --flag option is supplied; new opt-in test categories must add both the flag registration and the skip mapping rather than relying on markers alone.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  When adding or modifying tests that should only run under an explicit CLI flag, or when changing the SKIP_DEFAULT_FLAGS mapping or pytest_addoption registrations.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
conftest.py registers each SKIP_DEFAULT_FLAGS entry as a store_true option defaulting to False and skips tests marked with any SKIP_DEFAULT_FLAGS keyword unless the matching --flag is supplied.
```

- **Sources:**
  - `tests/conftest.py`
