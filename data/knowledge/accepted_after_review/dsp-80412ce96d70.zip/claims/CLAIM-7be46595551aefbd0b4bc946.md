# Rule details

- **Rule:**
  ```text
  When generating API documentation pages, emit mkdocstrings blocks as '::: {module_path}.{name}' with the established option set (show_source, show_root_heading, heading_level 2, google docstring style, inherited_members), list public methods under a members config for classes, and place the ':::' marker last so the generated block is not left unclosed.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Modifying the API documentation page generator that renders mkdocstrings blocks for modules, classes, and routines.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_docs.py:9-316`
