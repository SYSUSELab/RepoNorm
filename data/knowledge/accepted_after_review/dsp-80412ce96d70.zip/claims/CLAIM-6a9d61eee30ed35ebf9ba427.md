# Rule details

- **Rule:** The reliability test configuration sets adapter to chat.
- **Applies to:**
  - `tests/reliability/reliability_conf.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
adapter: chat

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:1`

## Review evidence locations

- `tests/reliability/reliability_conf.yaml:1-1`
