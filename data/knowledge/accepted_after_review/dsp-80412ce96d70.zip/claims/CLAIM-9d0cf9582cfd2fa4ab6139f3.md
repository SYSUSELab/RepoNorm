# Rule details

- **Rule:**
  ```text
  The test server package must expose LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR from tests.test_utils.server.litellm_server so tests can read the log-file path via an environment variable.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when modifying the test server package exports or the log-file path environment variable
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test server package __init__ imports LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR from tests.test_utils.server.litellm_server, exposing it for tests.
```

- **Sources:**
  - `tests/test_utils/server/__init__.py`
