# Rule details

- **Rule:** Passing field="other" to majority aggregation must select the majority value from that field rather than the default answer field.
- **Applies to:**
  - `tests/predict/test_aggregation.py`
- **Condition:** When modifying majority aggregation field selection or adding tests for custom field aggregation.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/predict/test_aggregation.py:30-37`
