# Rule details

- **Rule:** The test job runs extra tests via uv run -p .venv pytest tests/ -m extra --extra.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: uv run -p .venv pytest tests/ -m extra --extra

```

- **Sources:**
  - `.github/workflows/run_tests.yml:89`

## Review evidence locations

- `.github/workflows/run_tests.yml:86-89`
