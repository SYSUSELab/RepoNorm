# Rule details

- **Rule:** When modifying ProgramOfThought, preserve the module-level requirement that deno is installed as an external runtime prerequisite, as documented in the module docstring.
- **Applies to:**
  - `dspy/predict/program_of_thought.py`
- **Condition:** Changing ProgramOfThought's runtime dependencies or documentation.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/predict/program_of_thought.py:13-17`
