# Rule details

- **Rule:**
  ```text
  When modifying RulesInductionProgram, preserve its role as a composable dspy.Module subclass in infer_rules.py.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:** Changing RulesInductionProgram's module composition or base class.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/teleprompt/infer_rules.py:127-142`
