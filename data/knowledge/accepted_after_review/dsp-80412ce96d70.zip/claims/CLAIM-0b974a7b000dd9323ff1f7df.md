# Rule details

- **Rule:** The build-and-publish-pypi workflow builds the binary wheel and publishes the package to pypi.
- **Applies to:**
  - `.github/.internal_dspyai/internals/build-and-release.md`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
1. Builds the binary wheel

```

- **Sources:**
  - `.github/.internal_dspyai/internals/build-and-release.md:55`

### Evidence 2 — explicit

```text
1. Publishes the package to pypi.

```

- **Sources:**
  - `.github/.internal_dspyai/internals/build-and-release.md:56`

## Review evidence locations

- `.github/.internal_dspyai/internals/build-and-release.md:1-58`
