# Rule details

- **Rule:** Parameterized test decorators in tests/reliability/generate/utils.py must be implemented as decorator factories whose inner decorator returns a wrapper; do not implement them as single-level decorators.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying a parameterized test decorator in the reliability generate utils
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_retry is a decorator factory whose inner decorator returns a wrapper function, satisfying the parameterized-decorator convention.
```

- **Sources:**
  - `tests/reliability/generate/utils.py`
