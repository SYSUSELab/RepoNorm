# Rule details

- **Rule:** Reliability test utilities that remove a specific line from a fixture file must match on the stripped form of each file line while requiring the caller to pass the exact stripped line text as the argument.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying or adding line-removal helpers used to prepare reliability test fixtures.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:658-674`
