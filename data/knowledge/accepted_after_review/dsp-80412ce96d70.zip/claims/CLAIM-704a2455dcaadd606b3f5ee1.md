# Rule details

- **Rule:**
  ```text
  When modifying LM.aforward, preserve warning on any choice finish_reason equal to "length" and record usage via settings.usage_tracker only when the result is not a cache hit and exposes usage.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** changing LM.aforward truncation warning or usage tracking behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/lm.py:146-174`
