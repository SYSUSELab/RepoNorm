# Rule details

- **Rule:**
  ```text
  Set up the development environment via conda + pip by running `conda create -n dspy-dev python=3.11` followed by `conda activate dspy-dev`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
conda create -n dspy-dev python=3.11
conda activate dspy-dev

```

- **Sources:**
  - `CONTRIBUTING.md:139-140`

## Review evidence locations

- `CONTRIBUTING.md:14-147`
