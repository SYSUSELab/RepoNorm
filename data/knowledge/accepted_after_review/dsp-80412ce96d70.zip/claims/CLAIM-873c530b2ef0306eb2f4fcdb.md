# Rule details

- **Rule:** When creating a new release for a major or minor version, update the default branch on the GitHub repository to the new release branch.
- **Applies to:**
  - `**`
- **Condition:** creating a new release for a major or minor version
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
* If creating a new release for major or minor version:
    * [ ] Create a new release branch with the last commit and name it 'release/X.Y`
    * [ ] [Update the default branch](https://docs.github.com/en/organizations/managing-organization-settings/managing-the-default-branch-name-for-repositories-in-your-organization) on the github rep to the new release branch.

```

- **Sources:**
  - `.github/.internal_dspyai/internals/release-checklist.md:19-21`

## Review evidence locations

- `.github/.internal_dspyai/internals/release-checklist.md:1-24`
