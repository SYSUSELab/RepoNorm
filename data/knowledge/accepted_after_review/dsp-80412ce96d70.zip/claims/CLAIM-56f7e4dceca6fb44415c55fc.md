# Rule details

- **Rule:**
  ```text
  PythonInterpreter read-path sandbox tests must verify that enable_read_paths exposes files at /sandbox/<name> and that enable_read_paths=None denies access with a permission or no-such-file error.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** when modifying or extending PythonInterpreter read-path sandbox tests
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test asserts both the allowed read-path case (enable_read_paths exposes file at /sandbox/<name>) and the denied case (enable_read_paths=None yields permission/no-such-file error).
```

- **Sources:**
  - `tests/primitives/test_python_interpreter.py:81-106`
