# Rule details

- **Rule:** The MkDocs Material theme enables the navigation.tabs, navigation.path, navigation.indexes, navigation.expand, toc.follow, navigation.top, search.suggest, and search.highlight features.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    features:
        - navigation.tabs
        - navigation.path
        - navigation.indexes
        - navigation.expand
        - toc.follow
        - navigation.top
        - search.suggest
        - search.highlight

```

- **Sources:**
  - `docs/mkdocs.yml:153-161`

## Review evidence locations

- `docs/mkdocs.yml:1-218`
