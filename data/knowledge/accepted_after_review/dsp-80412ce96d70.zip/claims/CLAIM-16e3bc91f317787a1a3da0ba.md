# Rule details

- **Rule:** The package name is updated by the workflow to allow the same files to be used to build both the pypi and test-pypi packages.
- **Applies to:**
  - `pyproject.toml`
  - `setup.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
\* The package name is updated by the workflow to allow the same files to be used to build both the pypi and test-pypi packages.
```

- **Sources:**
  - `.github/.internal_dspyai/internals/build-and-release.md:59`

## Review evidence locations

- `.github/workflows/build_and_release.yml:1-144`
