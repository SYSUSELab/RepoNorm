# Rule details

- **Rule:**
  ```text
  Adapter test signatures must include tools as a list of dspy.Tool inputs and tool_calls as a dspy.ToolCalls output, establishing the expected tool-calling field types.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** when modifying adapter tool-calling signature field types
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_json_adapter.py:697-702`
