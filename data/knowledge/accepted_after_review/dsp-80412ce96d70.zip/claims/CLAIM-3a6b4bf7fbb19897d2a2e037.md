# Rule details

- **Rule:** Generated reliability fixtures for complex types must define enum fields with the expected option values (such as ProcessedEnumField with option1, option2, option3), establishing the expected enum surface for the fixture.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
- **Condition:** when adding or modifying generated reliability fixtures for complex types
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/complex_types/generated/test_many_types_1/program.py:52-55`
