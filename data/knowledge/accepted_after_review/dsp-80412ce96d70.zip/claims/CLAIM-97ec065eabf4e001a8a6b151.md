# Rule details

- **Rule:** dspy.configure called inside an async coroutine directly invoked by the entry task applies to that same async task, illustrating task-local settings propagation.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying async task-local dspy settings propagation or the foo4 coroutine
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
foo4 is an async coroutine that calls dspy.configure(lm=dspy.LM(...)) and is directly invoked by the entry task, illustrating task-local settings propagation as the rule states.
```

- **Sources:**
  - `tests/utils/test_settings.py:181-184`
