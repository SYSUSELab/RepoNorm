# Rule details

- **Rule:**
  ```text
  Generated API navigation must include only .md files: build_nav_structure sorts directory entries and adds only .md files to the nav dict, mapping each stem to its path relative to base_path.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:** When adding files under docs/api or modifying navigation structure generation.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_summary.py:1-132`
