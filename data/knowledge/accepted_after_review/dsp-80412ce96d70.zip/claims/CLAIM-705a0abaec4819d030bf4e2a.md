# Rule details

- **Rule:**
  ```text
  The build-and-publish-pypi job updates the package name in pyproject.toml to dspy using sed against the #replace_package_name_marker.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Update package name in pyproject.toml
        run: sed -i '/#replace_package_name_marker/{n;s/name *= *"[^"]*"/name="dspy"/;}' pyproject.toml

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:90-91`
