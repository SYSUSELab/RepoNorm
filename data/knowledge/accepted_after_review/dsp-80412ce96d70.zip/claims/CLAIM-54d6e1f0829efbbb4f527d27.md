# Rule details

- **Rule:**
  ```text
  When modifying encode_audio, preserve its normalization contract: accept dicts with data/audio_format, Audio instances, data URIs, local file paths, http URLs, numpy arrays when soundfile is available, and raw bytes, and normalize them into a dict with 'data' and 'audio_format', raising ValueError for malformed data URIs or unsupported types.
  ```
- **Applies to:**
  - `dspy/adapters/types/audio.py`
- **Condition:**
  ```text
  When changing which audio input forms encode_audio accepts or how it normalizes or rejects them.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/adapters/types/audio.py:114-145`
