# Rule details

- **Rule:** The mkdocstrings Python handler shows the root heading.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
                    show_root_heading: true

```

- **Sources:**
  - `docs/mkdocs.yml:202`
