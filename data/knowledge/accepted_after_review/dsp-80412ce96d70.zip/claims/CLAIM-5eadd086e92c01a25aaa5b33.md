# Rule details

- **Rule:**
  ```text
  After del example["a"], accessing example.a must raise AttributeError, defining the deletion semantics of Example.
  ```
- **Applies to:**
  - `tests/primitives/test_example.py`
- **Condition:** When modifying Example deletion behavior or adding tests for attribute access after deletion.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/primitives/test_example.py:42-46`
