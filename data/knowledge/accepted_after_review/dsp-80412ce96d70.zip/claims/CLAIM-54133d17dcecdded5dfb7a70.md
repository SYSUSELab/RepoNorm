# Rule details

- **Rule:**
  ```text
  JSONAdapter.format must emit each image in a nested image list as a separate image_url content entry in the user message, expanding nested image wrappers to multiple content items.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSONAdapter.format image handling or nested image list expansion.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_json_adapter.py:290-314`
