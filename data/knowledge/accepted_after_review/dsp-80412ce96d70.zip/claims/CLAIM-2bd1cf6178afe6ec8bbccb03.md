# Rule details

- **Rule:**
  ```text
  CodeAct must reject non-function tools at construction time with ValueError, and its signature must append trajectory, generated_code, and finished fields; contributors adding tool types or signature fields must preserve this function-only contract and the appended field set.
  ```
- **Applies to:**
  - `dspy/predict/code_act.py`
- **Condition:** When modifying CodeAct tool acceptance or its generated signature fields.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/predict/code_act.py:40-67`
