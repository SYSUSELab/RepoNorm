# Rule details

- **Rule:**
  ```text
  When modifying OldField.__init__, preserve accepting keyword-only prefix, desc, input, and format parameters, with prefix allowed to be None initially and set later.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:**
  ```text
  changing OldField.__init__ parameter signature or prefix handling
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/signatures/field.py:70-84`
