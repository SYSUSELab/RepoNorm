# Rule details

- **Rule:**
  ```text
  resolve_name must resolve type names by checking provided names, then built-in types, then attempting importlib.import_module(type_name) for module-based annotations like dspy.Image, raising ValueError(f"Unknown name: {type_name}") when unresolved.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When modifying resolve_name or type-name resolution in dspy/signatures/signature.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/signatures/signature.py:509-535`
