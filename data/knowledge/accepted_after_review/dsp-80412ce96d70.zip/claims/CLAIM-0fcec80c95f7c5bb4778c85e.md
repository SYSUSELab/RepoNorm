# Rule details

- **Rule:**
  ```text
  Tests that exercise Predict.dump_state()/load_state() must preserve demo content across a ujson round-trip, while allowing demo types to change after save/load.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  When modifying Predict state serialization tests or the dump_state/load_state round-trip assertions.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/predict/test_predict.py:85-113`
