# Rule details

- **Rule:** The workflow runs on pull requests of types opened, synchronize, and reopened.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  pull_request:
    types: [opened, synchronize, reopened]

```

- **Sources:**
  - `.github/workflows/run_tests.yml:7-8`

## Review evidence locations

- `.github/workflows/run_tests.yml:1-158`
