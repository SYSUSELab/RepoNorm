# Rule details

- **Rule:**
  ```text
  Tests expected to fail with certain models are marked using the `@known_failing_models` decorator, and such known failures are logged without affecting the overall test result.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Some tests may be expected to fail with certain models, especially in challenging cases. These known failures are logged but do not affect the overall test result. This setup allows us to keep track of model-specific limitations without obstructing general test outcomes. Models that are known to fail a particular test case are specified using the `@known_failing_models` decorator. For example:

```

- **Sources:**
  - `tests/reliability/README.md:77`

## Review evidence locations

- `tests/reliability/README.md:75-83`
