# Rule details

- **Rule:**
  ```text
  Tests for Example length must assert that dspy_hidden fields are excluded from len(), so len(Example(a=1,b=2,dspy_hidden=3)) is 2.
  ```
- **Applies to:**
  - `tests/primitives/test_example.py`
- **Condition:** when adding or modifying Example length tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/primitives/test_example.py:49-51`
