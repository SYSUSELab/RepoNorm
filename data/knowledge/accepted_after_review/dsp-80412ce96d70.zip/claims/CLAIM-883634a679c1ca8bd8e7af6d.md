# Rule details

- **Rule:**
  ```text
  Unbatchify must terminate its worker thread on garbage collection via __del__ calling self.close(), and on shutdown must fail remaining queued futures with RuntimeError('Unbatchify is closed'); batch_fn exceptions must be set on every pending future so callers handle per-future exceptions rather than a single batch error.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:** Modifying Unbatchify worker lifecycle, shutdown, or batch error propagation
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/utils/unbatchify.py:67-84`
- `dspy/utils/unbatchify.py:88-112`
