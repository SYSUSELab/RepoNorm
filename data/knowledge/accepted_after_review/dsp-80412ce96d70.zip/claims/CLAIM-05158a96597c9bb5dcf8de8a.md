# Rule details

- **Rule:** Syncify tests must define their program as a dspy.Module subclass; do not use a non-Module program shape in these tests.
- **Applies to:**
  - `tests/utils/test_syncify.py`
- **Condition:** when adding or modifying a syncify test program
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The syncify test file defines its programs as dspy.Module subclasses (class MyProgram(dspy.Module)), conforming to the rule.
```

- **Sources:**
  - `tests/utils/test_syncify.py`
