# Rule details

- **Rule:**
  ```text
  When modifying EnvPool.session, preserve returning an _EnvSession context manager that acquires and releases a single worker, defining the worker-acquisition protocol for the AlfWorld dataset environment.
  ```
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** changing EnvPool.session worker acquisition or release protocol
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/datasets/alfworld/alfworld.py:88-108`
- `dspy/datasets/alfworld/alfworld.py:111-128`
