# Rule details

- **Rule:** Tests that exercise the chat adapter with the Code type must define a CodeGeneration signature with a question input field and a dspy.Code output field to exercise Code type formatting.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** When adding or modifying tests that exercise chat adapter formatting of the dspy.Code type as an output field (i.e., parsing a Code-typed output), the test must define a signature with a question input field and a dspy.Code output field.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_chat_adapter.py:378-398`
