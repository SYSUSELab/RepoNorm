# Rule details

- **Rule:**
  ```text
  BootstrapFewShot with max_bootstrapped_demos=1 and max_labeled_demos=1 must produce exactly one demo matching the trainset example, and DummyLM with follow_examples=True must reuse that matching example rather than its queued second response.
  ```
- **Applies to:**
  - `tests/teleprompt/test_bootstrap.py`
- **Condition:**
  ```text
  when modifying BootstrapFewShot demo selection or DummyLM follow_examples behavior
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/teleprompt/test_bootstrap.py:56-77`
