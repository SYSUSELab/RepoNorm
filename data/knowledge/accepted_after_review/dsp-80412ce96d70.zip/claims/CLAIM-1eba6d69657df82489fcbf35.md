# Rule details

- **Rule:** When modifying the signatures field module, preserve the legacy compatibility boundary: OldInputField subclasses OldField, keeping the legacy field class alongside the current field API for backward compatibility.
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:** When changing or removing legacy field classes in the signatures field module.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/signatures/field.py:54-100`
