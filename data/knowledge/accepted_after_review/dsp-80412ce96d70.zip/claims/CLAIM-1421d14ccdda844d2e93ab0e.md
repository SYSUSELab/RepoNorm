# Rule details

- **Rule:**
  ```text
  kill_lms must collect unique LMs from a program and call kill on each, providing the cleanup path for finetuning bootstrap.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When modifying kill_lms or the finetuning bootstrap cleanup path.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/teleprompt/bootstrap_finetune.py:410-424`
