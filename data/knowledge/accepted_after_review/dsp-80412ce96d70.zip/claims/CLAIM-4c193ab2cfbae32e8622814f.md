# Rule details

- **Rule:**
  ```text
  Image-encoding output must keep the 'data:<mime>;base64,' prefix shape intact; tests assert substring containment rather than startswith to tolerate MIME parameters.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** when modifying image-encoding output format or its tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/signatures/test_adapter_image.py:377-388`
