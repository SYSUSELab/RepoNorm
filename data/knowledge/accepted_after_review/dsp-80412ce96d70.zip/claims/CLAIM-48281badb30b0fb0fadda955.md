# Rule details

- **Rule:** The assertion-generation signature must instruct the model to produce natural-language assertions, ideally about 5, and to leave them blank when accurate assertions are too difficult.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying the assertion-generation signature or its output contract
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The assertion-generation signature instructs natural-language assertions, ideally about 5, and to leave them blank when accurate assertions are too difficult.
```

- **Sources:**
  - `tests/reliability/generate/utils.py:466-493`
