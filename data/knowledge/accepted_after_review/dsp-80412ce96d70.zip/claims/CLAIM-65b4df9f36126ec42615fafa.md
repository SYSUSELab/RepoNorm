# Rule details

- **Rule:** Test signatures must intentionally leave some output fields without descriptions to exercise adapter behavior for blank versus populated field descriptions.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSON adapter test signatures or field description handling in adapter tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_json_adapter.py:15-20`
