# Rule details

- **Rule:**
  ```text
  `assert_program_output_correct` must normalize `grading_guidelines` to a list, then under `judge_dspy_configuration` call the judge program with `program_input`, `program_output`, and each guideline, asserting `judge_response.correct` and reporting `judge_response.justification` on failure.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when adding or modifying reliability test assertions that use the LLM judge helper
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/utils.py:15-40`
