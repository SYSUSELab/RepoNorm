# Rule details

- **Rule:** The workflow builds and publishes a release to test-pypi.
- **Applies to:**
  - `.github/**`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
3. Builds and publishes a release on [test-pypi](https://test.pypi.org/project/dspy-ai-test/)

```

- **Sources:**
  - `.github/.internal_dspyai/internals/build-and-release.md:11`

## Review evidence locations

- `.github/workflows/build_and_release.yml:1-144`
