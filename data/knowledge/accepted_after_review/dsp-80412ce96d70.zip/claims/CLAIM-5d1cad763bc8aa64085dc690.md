# Rule details

- **Rule:**
  ```text
  CI runs the `mkdocs build` command to verify the documentation builds successfully before merging changes.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
We have automated build checks set up in our CI pipeline to ensure the documentation builds successfully before merging changes. These checks:

1. Run the `mkdocs build` command

```

- **Sources:**
  - `docs/README.md:59-61`

## Review evidence locations

- `docs/README.md:13-74`
