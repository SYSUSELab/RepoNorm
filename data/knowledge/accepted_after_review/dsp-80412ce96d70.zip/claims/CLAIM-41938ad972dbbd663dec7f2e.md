# Rule details

- **Rule:** Colors must split sorted colors 60/40 into train/dev and shuffle both with random.Random(0) so the split is deterministic and avoids similar-color overlap between train and dev.
- **Applies to:**
  - `dspy/datasets/colors.py`
- **Condition:** When changing the Colors dataset split logic or its shuffling seed.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Colors sorts colors, splits 60/40 into train/dev, and shuffles both with random.Random(0), giving a deterministic seeded split.
```

- **Sources:**
  - `dspy/datasets/colors.py`
