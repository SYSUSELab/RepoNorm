# Rule details

- **Rule:** Contributors proposing a new feature should open a feature request to discuss it.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
We also welcome new ideas! If you would like to propose a new feature, please open a feature request to
discuss. If you already have a design in mind, please include a notebook/code example to demonstrate

```

- **Sources:**
  - `CONTRIBUTING.md:14-15`

## Review evidence locations

- `CONTRIBUTING.md:14-147`
