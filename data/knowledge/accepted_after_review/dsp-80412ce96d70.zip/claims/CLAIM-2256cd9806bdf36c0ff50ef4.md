# Rule details

- **Rule:**
  ```text
  The autouse configure_model fixture must read reliability_conf.yaml, configure dspy with the parametrized model and adapter, skip tests when no YAML config exists for the model, and store should_ignore_failure and model_name on the request node for post-test handling.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** when modifying the reliability test fixture or its model configuration and skip behavior
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
configure_model reads reliability_conf.yaml, configures dspy with the parametrized model and adapter, skips when no YAML config exists, and stores should_ignore_failure and model_name on the request node.
```

- **Sources:**
  - `tests/reliability/conftest.py:42-66`
