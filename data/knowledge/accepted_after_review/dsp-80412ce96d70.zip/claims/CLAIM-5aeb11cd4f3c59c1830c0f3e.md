# Rule details

- **Rule:**
  ```text
  Install dspy from the GitHub repository with `pip install git+https://github.com/stanfordnlp/dspy.git`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
pip install git+https://github.com/stanfordnlp/dspy.git

```

- **Sources:**
  - `README.md:37`

## Review evidence locations

- `README.md:27-38`
