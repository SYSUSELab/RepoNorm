# Rule details

- **Rule:**
  ```text
  LM.kill must delegate to the provider's kill method, so custom providers must implement a kill(self, lm, launch_kwargs) hook to support LM teardown.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** when modifying LM.kill or adding a custom provider that must support LM teardown
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
LM.kill delegates to self.provider.kill(self, launch_kwargs), establishing the provider kill hook contract for LM teardown.
```

- **Sources:**
  - `dspy/clients/lm.py:179-180`
