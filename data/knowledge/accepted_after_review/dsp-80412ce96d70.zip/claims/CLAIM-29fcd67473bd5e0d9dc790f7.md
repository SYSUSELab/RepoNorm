# Rule details

- **Rule:**
  ```text
  When modifying the ColBERT v2 request path, preserve the request_cache decoration on colbertv2_get_request_v2_wrapped so v2 ColBERT requests are cached at the wrapper boundary.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:** When changing the ColBERT v2 request wrapper or its caching behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/dsp/colbertv2.py:40-57`
