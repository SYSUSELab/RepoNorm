# Rule details

- **Rule:**
  ```text
  When modifying the version-bump helper, preserve the CLI contract that the script requires exactly two arguments (package_name, tag_version), fetches the latest version, optionally increments it, and prints the resulting version.
  ```
- **Applies to:**
  - `.github/workflows/build_utils/test_version.py`
- **Condition:** Changing the command-line interface or argument handling of the version-bump helper.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The module requires exactly two CLI arguments (package_name, tag_version), fetches the latest version, optionally increments it, and prints the result.
```

- **Sources:**
  - `.github/workflows/build_utils/test_version.py`
