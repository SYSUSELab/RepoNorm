# Rule details

- **Rule:**
  ```text
  Tests for `dspy.syncify` with optimizers must cover both `in_place=True` and `in_place=False` modes and assert that the compiled program contains exactly 2 bootstrapped demos in each case.
  ```
- **Applies to:**
  - `tests/utils/test_syncify.py`
- **Condition:**
  ```text
  when adding or modifying tests that combine `dspy.syncify` with optimizers
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_syncify.py:28-57`
