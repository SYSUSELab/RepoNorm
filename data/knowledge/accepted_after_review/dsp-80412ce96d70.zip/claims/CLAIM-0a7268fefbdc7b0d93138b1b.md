# Rule details

- **Rule:** Pre-commit hooks are used to automatically check and fix common issues, and must be set up once after cloning the repository.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
We follow the [Google Python Style Guide](https://google.github.io/styleguide/pyguide.html) and use `ruff` for both linting and formatting. To ensure consistent code quality, we use pre-commit hooks that automatically check and fix common issues.

```

- **Sources:**
  - `CONTRIBUTING.md:40`

### Evidence 2 — explicit

```text
First you need to set up the pre-commit hooks (do this once after cloning the repository):

```

- **Sources:**
  - `CONTRIBUTING.md:43`

## Review evidence locations

- `CONTRIBUTING.md:14-147`
