# Constraints for `pyproject.toml`

## Rule

- **Rule:** The package name is updated by the workflow to allow the same files to be used to build both the pypi and test-pypi packages.
- **Applies to:**
  - `pyproject.toml`
  - `setup.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-16e3bc91f317787a1a3da0ba.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-pypi job updates the version in pyproject.toml using sed against the #replace_package_version_marker.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4780dd16d6e1dbb18a3bae42.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-pypi job updates the package name in pyproject.toml to dspy using sed against the #replace_package_name_marker.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-705a0abaec4819d030bf4e2a.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-test-pypi job updates the package name in pyproject.toml to dspy-ai-test using sed against the #replace_package_name_marker.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cda5252797e736b9b6fafc66.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-test-pypi job updates the version in pyproject.toml using sed against the #replace_package_version_marker.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e3f8e56bf03010c0c5761164.md)
