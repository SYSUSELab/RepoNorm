# Constraints for `tests`

## Rule

- **Rule:**
  ```text
  Package discovery excludes the tests and tests.* packages.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-343cb164f65ac5c9639b4ad3.md)

## Rule

- **Rule:** Ruff targets Python version py310.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-49d97a1e6e6579c4ef2910c6.md)

## Rule

- **Rule:** The test job runs extra tests via uv run -p .venv pytest tests/ -m extra --extra.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5887a15bcdc1e66cd1a7c2bb.md)

## Rule

- **Rule:**
  ```text
  Tests that mutate dspy global settings must rely on the autouse clear_settings fixture in tests/conftest.py, which resets dspy settings to a deep copy of DEFAULT_CONFIG with inherit_config=False after each test; do not assume settings persist across tests.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test that configures dspy settings or depends on dspy global configuration state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5a3a492a41a8886935a6143f.md)

## Rule

- **Rule:**
  ```text
  Live-LM tests must obtain their LM through the lm_for_test fixture in tests/conftest.py, which reads the LM_FOR_TEST environment variable and skips the test when it is unset; do not hard-code live LM credentials or endpoints in tests.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test that requires a live language model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-73983f220235473637978ed9.md)

## Rule

- **Rule:** Ruff uses an indent width of 4.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-759d215093f724de19cfc1dc.md)

## Rule

- **Rule:**
  ```text
  Tests expected to fail with certain models are marked using the `@known_failing_models` decorator, and such known failures are logged without affecting the overall test result.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-91279d3ba40efe476a93ece5.md)

## Rule

- **Rule:**
  ```text
  Ruff per-file ignores for tests/**/*.py disable S101, TID252, and ARG001, allowing assert statements, relative imports, and unused arguments in test files.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9183669098b3302c3ee3a1c2.md)

## Rule

- **Rule:**
  ```text
  The llm_call_test job runs pytest with -m llm_call --llm_call -vv --durations=5 over the tests/ directory.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-98a3ca35d9ca7ed7a99790b2.md)

## Rule

- **Rule:** Ruff enforces a maximum line length of 120.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-9dc5054a7ca96baa492768a3.md)

## Rule

- **Rule:**
  ```text
  Ruff linting/formatting applies to Python files under dspy/ and tests/ as configured by include = ["dspy/**/*.py", "tests/**/*.py"].
  ```
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c96220426b095b5c3f51a757.md)

## Rule

- **Rule:** The test job runs pytest over the tests/ directory via uv run -p .venv pytest -vv tests/.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f986978ee8efc5002153cf9c.md)
