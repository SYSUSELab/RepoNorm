# Constraints for `tests/retrievers/test_embeddings.py`

## Rule

- **Rule:**
  ```text
  Retriever embedding tests must use a stable fixed fixture corpus (dummy_corpus returning three fixed sentences) rather than dynamic or external data, so embedding tests are deterministic.
  ```
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** when adding or modifying retriever embedding tests that need a corpus
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-43704d40939baa74539fcb52.md)

## Rule

- **Rule:** Tests that exercise concurrent multithreaded embeddings search must assert that search supports ThreadPoolExecutor concurrency and that results are returned in the original query order.
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** When adding or modifying tests for concurrent multithreaded embeddings search.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-89b63c61c4e3792bced7296a.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise embeddings retrieval must use a dummy_embedder mapping texts containing 'cat' to [1,0,0], 'dog' to [0,1,0], and anything else to [0,0,1], returning a stacked float32 array, so retrieval assertions rely on fixed orthogonal embeddings.
  ```
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** When adding or modifying tests for embeddings retrieval that depend on deterministic embedding vectors.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ca6186b0ef9e2a1c3ee3b2e7.md)
