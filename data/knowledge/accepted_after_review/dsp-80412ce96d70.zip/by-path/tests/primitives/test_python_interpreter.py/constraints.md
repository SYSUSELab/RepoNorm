# Constraints for `tests/primitives/test_python_interpreter.py`

## Rule

- **Rule:** Tests for PythonInterpreter.execute must assert that executing code capturing stdout returns the exact output including the trailing newline.
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** When modifying PythonInterpreter execution tests that assert captured stdout content.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-27fd083fd7ff4c618d3a4136.md)

## Rule

- **Rule:**
  ```text
  PythonInterpreter read-path sandbox tests must verify that enable_read_paths exposes files at /sandbox/<name> and that enable_read_paths=None denies access with a permission or no-such-file error.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** when modifying or extending PythonInterpreter read-path sandbox tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-56f7e4dceca6fb44415c55fc.md)
