# Constraints for `tests/primitives/test_base_module.py`

## Rule

- **Rule:** Tests for the usage tracker must assert that exactly one LM entry with positive prompt/completion/total tokens is recorded when cache is disabled, and that zero usage entries are recorded when the LM cache is enabled and the same call is repeated.
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** when adding or modifying usage tracker tests that exercise cache-disabled and cache-enabled LM calls
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-091996ce72ae5ce3132a7d3f.md)

## Rule

- **Rule:**
  ```text
  Module.deepcopy must clone parameters into distinct objects with equal __dict__ values, while sharing uncopyable objects (e.g. locks) by identity; parameter count and values are preserved.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When modifying Module.deepcopy or adding tests for deepcopy behavior of modules containing parameters or uncopyable objects.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-40f9179a5362343b68d7c6c4.md)

## Rule

- **Rule:** Tests that exercise module deepcopy with nested modules must account for non-copyable attributes such as threading.Lock stored as instance attributes.
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When modifying module deepcopy or serialization tests that include nested modules with non-copyable instance attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b12c18b52a199816860868d0.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Module.deepcopy must assert that parameter count is preserved, locks are shallow-copied (same lock object identity), and parameter objects are deep-copied so parameter ids differ while __dict__ values match.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When adding or modifying tests for Module.deepcopy of nested modules or parameters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bc8ebd6947353f0560e54f3d.md)

## Rule

- **Rule:**
  ```text
  When dspy.context(disable_history=True) is active, no new history is recorded; re-enabling with disable_history=False resumes recording.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:**
  ```text
  When modifying history recording or disable_history context behavior in base module tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d4955a38508de2b82a931518.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise usage tracking under concurrent async calls must assert that each call under a shared settings context with track_usage=True receives independent per-LM usage records keyed by model name, with prompt/completion/total token counts matching the mocked response.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When adding or modifying tests for usage tracking under concurrent async LM calls.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d92939f52c860c02d520f1f0.md)

## Rule

- **Rule:** Module history must record exactly one entry per invocation, including under concurrent execution via dspy.Parallel, for the program, its inner ChainOfThought, and its Predict.
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When modifying history recording in Module or Predict, or adding tests for concurrent execution history.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f65ba34917c0d098b3e85215.md)
