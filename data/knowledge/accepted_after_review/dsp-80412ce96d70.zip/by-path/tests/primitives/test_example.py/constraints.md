# Constraints for `tests/primitives/test_example.py`

## Rule

- **Rule:**
  ```text
  Example(base=base_dict, c=3) must expose the base dict's keys as attributes alongside the extra kwargs, merging a base mapping with direct keyword fields.
  ```
- **Applies to:**
  - `tests/primitives/test_example.py`
- **Condition:** When modifying Example initialization or attribute merging from a base mapping and keyword arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4260c4b9f83d7702bcc67080.md)

## Rule

- **Rule:**
  ```text
  After del example["a"], accessing example.a must raise AttributeError, defining the deletion semantics of Example.
  ```
- **Applies to:**
  - `tests/primitives/test_example.py`
- **Condition:** When modifying Example deletion behavior or adding tests for attribute access after deletion.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5eadd086e92c01a25aaa5b33.md)

## Rule

- **Rule:**
  ```text
  Tests for Example length must assert that dspy_hidden fields are excluded from len(), so len(Example(a=1,b=2,dspy_hidden=3)) is 2.
  ```
- **Applies to:**
  - `tests/primitives/test_example.py`
- **Condition:** when adding or modifying Example length tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6afb34eec1f20befd2f77235.md)

## Rule

- **Rule:** Tests that exercise Example hashing must assert that two Example instances constructed with identical field values produce equal hashes, establishing value-based hashing as a required invariant.
- **Applies to:**
  - `tests/primitives/test_example.py`
- **Condition:** When adding or modifying tests for Example equality or hashing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae20c86b28504b3e7f56d0b6.md)
