# Constraints for `tests/primitives/test_module.py`

## Rule

- **Rule:**
  ```text
  An empty Module's named_sub_modules must yield exactly [('self', module)], establishing the base case for module traversal.
  ```
- **Applies to:**
  - `tests/primitives/test_module.py`
- **Condition:**
  ```text
  when modifying Module traversal, named_sub_modules, or base-case behavior for empty modules
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-28881f78fef9d11f2d110b84.md)

## Rule

- **Rule:** Module tests must define a DuplicateModule subclass to exercise duplicate-module behavior.
- **Applies to:**
  - `tests/primitives/test_module.py`
- **Condition:** When modifying module tests that exercise duplicate-module behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-697b2a2bc5fd8eb6c4122775.md)

## Rule

- **Rule:**
  ```text
  Tests exercising named_sub_modules must verify that shared sub-module references are deduplicated rather than listed twice.
  ```
- **Applies to:**
  - `tests/primitives/test_module.py`
- **Condition:**
  ```text
  when modifying or extending named_sub_modules deduplication tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6cc15b7abcb003c8467a06dd.md)

## Rule

- **Rule:**
  ```text
  named_sub_modules must yield (name, module) pairs including the root as ('self', module) and nested sub-modules as dotted paths like 'self.sub'.
  ```
- **Applies to:**
  - `tests/primitives/test_module.py`
- **Condition:**
  ```text
  When modifying named_sub_modules or adding tests for sub-module enumeration.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-736338b2425dd44dbd0c4514.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Module traversal must assert that named_sub_modules traverses nested lists, dicts, and tuples and includes the same module instance multiple times, while named_parameters does not allow recursive structures.
  ```
- **Applies to:**
  - `tests/primitives/test_module.py`
- **Condition:** When adding or modifying tests for Module traversal of nested containers or repeated module instances.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9c0a574774eb234704c2d088.md)

## Rule

- **Rule:**
  ```text
  Module.named_sub_modules() must traverse nested lists, tuples, and dict values, producing names like 'self.sub_module.nested_list[1][key]' and 'self.sub_module.nested_tuple[1][0]'; contributors adding container nesting must preserve this naming scheme.
  ```
- **Applies to:**
  - `tests/primitives/test_module.py`
- **Condition:**
  ```text
  when modifying Module.named_sub_modules traversal or adding container nesting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c22989773c658db1fe75000c.md)
