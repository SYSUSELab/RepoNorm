# Constraints for `tests/utils/test_usage_tracker.py`

## Rule

- **Rule:**
  ```text
  UsageTracker must aggregate usage per model name, summing total_tokens per model, and must merge usage entries treating None prompt_tokens_details and completion_tokens_details as absent while summing present detail keys across entries.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:** When modifying UsageTracker aggregation or detail-merging behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-879aaa072410196eba740a8a.md)

## Rule

- **Rule:**
  ```text
  Usage tracking tests must assert that track_usage() records per-LM usage_data keyed by the LM identifier and that get_total_tokens() returns a dict keyed by that same LM identifier, and UsageTracker.get_total_tokens must aggregate prompt_tokens, completion_tokens, total_tokens, and nested prompt_tokens_details/completion_tokens_details by summing across entries.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:** When modifying usage tracking tests or the UsageTracker aggregation behavior they exercise, including per-LM keying and nested token detail summation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-88fc184a0fccc347e6a305ea.md)

## Rule

- **Rule:**
  ```text
  Tests exercising the usage tracker must assert that adding usage for the same model with disjoint keys preserves both keys in get_total_tokens, establishing that per-model usage entries merge rather than overwrite.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:** When adding or modifying tests for usage tracker per-model merge behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d1c6016e035147a52079d801.md)

## Rule

- **Rule:**
  ```text
  UsageTracker.add_usage must store each usage entry under the model name in usage_data, preserving the full entry dict including token detail fields.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:**
  ```text
  When modifying UsageTracker.add_usage storage keying or entry preservation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f0e9d7e17acf5da0e96c4a8b.md)
