# Constraints for `tests/utils/test_unbatchify.py`

## Rule

- **Rule:**
  ```text
  The unbatchify test helper simple_batch_processor must return [item + 1 for item in batch], establishing the expected batch-processing shape used by unbatchify tests.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** When modifying unbatchify tests or the batch-processing helper shape they exercise.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-92416b843e9e3bee581a2378.md)

## Rule

- **Rule:**
  ```text
  Tests exercising unbatchify must verify that a pending batch is flushed after max_wait_time even when max_batch_size is not reached, asserting no call before the wait and exactly one call with the accumulated items after it.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** When adding or modifying tests for unbatchify timeout-triggered flushing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a9b6ed2dab966ffc1eeae20e.md)

## Rule

- **Rule:**
  ```text
  The unbatchify submit method enqueues an (input_item, future) tuple onto input_queue and returns the Future, defining the producer-side contract that callers await for results.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** when modifying the unbatchify submit method or tests that pin its queue/future contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-acab880450faaf6162874fe2.md)

## Rule

- **Rule:**
  ```text
  `Unbatchify` must flush a batch exactly when `max_batch_size` is reached: submitting one item below the threshold must not call the batch function, and the next submission must trigger a single call with both items in order.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:**
  ```text
  when adding or modifying tests for `Unbatchify` batch-size triggering behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aff1ac6d9fa3bdf6b690bb89.md)
