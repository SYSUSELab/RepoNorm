# Constraints for `tests/utils/test_syncify.py`

## Rule

- **Rule:** Syncify tests must define their program as a dspy.Module subclass; do not use a non-Module program shape in these tests.
- **Applies to:**
  - `tests/utils/test_syncify.py`
- **Condition:** when adding or modifying a syncify test program
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-05158a96597c9bb5dcf8de8a.md)

## Rule

- **Rule:**
  ```text
  Tests for `dspy.syncify` with optimizers must cover both `in_place=True` and `in_place=False` modes and assert that the compiled program contains exactly 2 bootstrapped demos in each case.
  ```
- **Applies to:**
  - `tests/utils/test_syncify.py`
- **Condition:**
  ```text
  when adding or modifying tests that combine `dspy.syncify` with optimizers
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-96aec7d850a88031b16cdee9.md)

## Rule

- **Rule:**
  ```text
  Tests exercising dspy.syncify must verify that wrapping an async program yields a synchronous callable whose outputs equal the program's outputs plus one when `in_place=False`.
  ```
- **Applies to:**
  - `tests/utils/test_syncify.py`
- **Condition:** When adding or modifying tests for dspy.syncify's non-in-place wrapper behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ecc307640c51b4ead00f34dd.md)
