# Constraints for `tests/utils/test_mcp.py`

## Rule

- **Rule:**
  ```text
  The MCP utility test module must skip the entire module at import time when the optional 'mcp' package is not installed, using pytest.skip(allow_module_level=True).
  ```
- **Applies to:**
  - `tests/utils/test_mcp.py`
- **Condition:** When modifying the MCP utility tests or their optional-dependency handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-33f61ff99a560a23495b6a16.md)

## Rule

- **Rule:**
  ```text
  convert_mcp_tool must preserve name/desc, expose JSON-schema args, map JSON types to Python arg_types (integer→int, array→list), synthesize arg_desc as 'No description provided. (Required)' when absent, wrap call failures in a RuntimeError prefixed 'Failed to call a MCP tool:', and support nested Pydantic object args.
  ```
- **Applies to:**
  - `tests/utils/test_mcp.py`
- **Condition:**
  ```text
  when modifying convert_mcp_tool or the MCP tool conversion contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b3244f6dfe58a91d8449a60d.md)
