# Constraints for `tests/utils/test_asyncify.py`

## Rule

- **Rule:**
  ```text
  test_asyncify must use the anyio pytest marker and await verify_asyncify with varying concurrency/iteration parameters (4/10, 8/15, 8/30), asserting asyncify behaves correctly under different concurrency levels.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:**
  ```text
  when modifying test_asyncify or the asyncify concurrency test parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6f40fd0238d0f9095c685097.md)

## Rule

- **Rule:** Tests exercising dspy.asyncify must run concurrent tasks via asyncio.gather over the asyncified coroutines to verify concurrent async execution.
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** When adding or modifying tests for dspy.asyncify's concurrent execution behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cdfe5104ca608c7501b5eb47.md)

## Rule

- **Rule:**
  ```text
  The async limiter must remain a singleton whose default total_tokens is 8, and dspy.context(async_max_workers=16) must override the same singleton instance to report total_tokens 16; do not replace the singleton with per-context instances or change the default capacity.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** when modifying the async limiter singleton or its context-driven capacity override
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d9605a3d7f7931f68be00d80.md)

## Rule

- **Rule:**
  ```text
  verify_asyncify must assert total execution time falls between floor(number_of_tasks/capacity)*wait and ceil(number_of_tasks/capacity)*wait + 2*wait, verifying asyncify concurrency respects the configured async_max_workers capacity; the asyncify fixture sleeps for a given duration and returns 42.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** When modifying asyncify concurrency tests or the asyncify test fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f057c65d2eed98e0a7008515.md)
