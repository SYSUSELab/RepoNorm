# Constraints for `tests/utils/test_settings.py`

## Rule

- **Rule:**
  ```text
  Inside dspy.context(lm=..., trace=[]), the settings LM must match the context LM and the trace must contain exactly one entry after acall, verifying per-context LM/trace isolation during concurrent async prediction.
  ```
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying dspy.context or async prediction paths to change per-context LM or trace isolation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-037f20b7506c24c920bc46cb.md)

## Rule

- **Rule:** dspy.context must be usable in async tasks different from the initial task, as demonstrated by using it inside an async function with an awaited sleep.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** When modifying dspy.context async-task support or its context-variable handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0efc8991d2056dee05924a14.md)

## Rule

- **Rule:** Calling dspy.configure from a non-main thread must raise RuntimeError matching 'Cannot call dspy.configure', establishing a thread-affinity constraint on global configuration.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** When modifying dspy.configure thread-affinity behavior or its error message.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1729a4e17a14912b36f25f68.md)

## Rule

- **Rule:** dspy.configure must not be called from a different async task than the initial one; calling it from a sync function invoked by an async task must raise RuntimeError with the message 'dspy.settings.configure(...) can only be called from the same async'.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that exercises dspy.configure across async task boundaries
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-66ddcbe2e89dc225b02ec5fc.md)

## Rule

- **Rule:** dspy.configure called inside an async coroutine directly invoked by the entry task applies to that same async task, illustrating task-local settings propagation.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying async task-local dspy settings propagation or the foo4 coroutine
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-97ec065eabf4e001a8a6b151.md)

## Rule

- **Rule:** dspy.configure sets global settings so that dspy.settings.lm.model, dspy.settings.adapter, and dspy.settings.callbacks reflect the configured values, and dspy.context scopes an LM and adapter to a block so concurrent acall coroutines inside the context use the scoped LM while the outer dspy.settings.lm and trace remain unaffected after the block.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying dspy.configure, dspy.context, or the tests that pin global and scoped settings behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9defb307190e6789d7745692.md)

## Rule

- **Rule:** dspy.configure must not be called from a child thread; tests must configure dspy in the main thread and assert that a ThreadPoolExecutor worker calling dspy.configure raises.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that exercises dspy.configure from a non-main thread
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9f8416215f690a8f6575c092.md)

## Rule

- **Rule:** dspy.context must isolate context-scoped LM overrides: inside dspy.context(lm=lm) the active dspy.settings.lm.model must equal the context lm's model, and after running workers in a ThreadPoolExecutor under dspy.context the global dspy.settings.lm and callbacks must remain the configured values.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** When modifying dspy.context scoping or thread-pool interaction with global settings.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aafda584fccf126668e23e7d.md)

## Rule

- **Rule:**
  ```text
  Tests exercising `dspy.Parallel` must verify that each parallel worker runs under its own `dspy.context` LM while the main thread's `dspy.settings.lm` remains unchanged, preserving context isolation across parallel workers.
  ```
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:**
  ```text
  when adding or modifying tests that exercise `dspy.Parallel` with per-worker `dspy.context` LM overrides
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b30440a7eee50584aee5dd1b.md)

## Rule

- **Rule:** dspy.configure raises RuntimeError with the message 'dspy.settings.configure(...) can only be called from the same async' when invoked from a different async task than the initial one, documenting an async-context restriction on configuration.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying dspy.configure or the tests that pin its async-task restriction
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b7c7e8cbe80d256b9e641c09.md)

## Rule

- **Rule:** dspy.context must override lm and callbacks within the block and revert settings to the outer configuration after the context exits; tests assert this scoped-override and revert behavior.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying dspy.context behavior or its tests to change scoped settings override or restoration semantics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c91d08623bc491f3d35acf0c.md)

## Rule

- **Rule:**
  ```text
  test_dspy_configure_allowance_async must assert that dspy.configure may be called multiple times within the same async task, including setting lm and adapter, and that concurrent async tasks can run under that configuration.
  ```
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:**
  ```text
  when modifying test_dspy_configure_allowance_async or the async dspy.configure allowance behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fed5673d22e3d212c41892d3.md)
