# Constraints for `tests/utils/test_parallelizer.py`

## Rule

- **Rule:**
  ```text
  ParallelExecutor with max_errors=1 must raise an exception whose message matches 'Execution cancelled due to errors or interruption.' when a task raises; tests assert this error-handling contract.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:**
  ```text
  when modifying ParallelExecutor error handling or its tests to change max_errors behavior or cancellation messaging
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2c9bc47b57a95153c90ca99a.md)

## Rule

- **Rule:**
  ```text
  ParallelExecutor.execute must return results in the same order as the input tasks, even when num_threads > 1; tests assert this ordering invariant for multi-threaded execution.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** when modifying ParallelExecutor.execute or its tests to change worker-thread scheduling or result collection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5cdb5543b59fca1aaea527df.md)

## Rule

- **Rule:** Tests exercising the parallelizer must include a deterministic failure case (a task that raises for a specific item) to verify error propagation during parallel execution.
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** When adding or modifying tests for parallelizer error propagation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b1996dc92bb0daad7e2e68b9.md)

## Rule

- **Rule:**
  ```text
  ParallelExecutor must tolerate errors below max_errors without crashing and represent failed tasks as None in their original result positions.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** When modifying ParallelExecutor error handling or result-position semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f9cd23d3bfbafb23da639d3c.md)
