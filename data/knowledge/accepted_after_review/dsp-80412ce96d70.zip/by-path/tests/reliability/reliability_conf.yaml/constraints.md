# Constraints for `tests/reliability/reliability_conf.yaml`

## Rule

- **Rule:** The reliability test configuration sets adapter to chat.
- **Applies to:**
  - `tests/reliability/reliability_conf.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6a9d61eee30ed35ebf9ba427.md)
