# Constraints for `tests/reliability`

## Rule

- **Rule:** Generated reliability programs are loaded by resolving a directory to program.py, raising ValueError when the path is missing, and returning the module's program and ProgramInputs; generated programs must therefore expose program and ProgramInputs at that layout.
- **Applies to:**
  - `tests/reliability/**/*.py`
- **Condition:** when adding or modifying generated reliability program directories or the loader that resolves them
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-003e2d29adf882ec847c0dd1.md)

## Rule

- **Rule:**
  ```text
  Test DSPy programs and test inputs can be generated from text descriptions using the `tests.reliability.generate` CLI or the `tests.reliability.generate.generate_test_cases` API.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-12ee120a563b9f7b6519c747.md)

## Rule

- **Rule:** Reliability test cases are discovered from the test directory by recursively walking it and treating a directory as a case only when it contains both program.py and an inputs directory; each .json input file becomes a GeneratedTestCase whose name derives from the enclosing directory path, and generated cases are parametrized by case.name.
- **Applies to:**
  - `tests/reliability/**/*.py`
- **Condition:** when adding or restructuring generated reliability test cases or their discovery helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3f1a9952359fba2c6792f2a0.md)

## Rule

- **Rule:**
  ```text
  Ruff excludes dspy/__metadata__.py and tests/reliability/*.py from its checks.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-40d9fedfc6a70a90e94f8edb.md)

## Rule

- **Rule:** Reliability tests mark expected failures for known challenging cases where a specific model might struggle, while actual (unexpected) DSPy reliability issues are flagged as failures.
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-61055c40350984e4933781d0.md)

## Rule

- **Rule:**
  ```text
  Reliability tests select adapters by mapping reliability_conf.adapter values 'chat' and 'json' to ChatAdapter and JSONAdapter respectively and raising ValueError for any other value, so reliability configuration may only use those adapter names.
  ```
- **Applies to:**
  - `tests/reliability/**/*.py`
- **Condition:** when adding or changing reliability test configuration adapter values or the adapter-selection helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-831c4512dbcf7aff8650c878.md)

## Rule

- **Rule:**
  ```text
  Running `pytest .` in the tests/reliability directory executes all tests for the configured models.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a94b5e69b76eb91f8ac7503d.md)

## Rule

- **Rule:**
  ```text
  Run `python -m tests.reliability.generate -d <output_dir> -p "<program description>" -i "<input description>"` from the DSPy repository root directory to generate a test program and test inputs.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../claims/CLAIM-ad515162c90fc9b60f3a2e57.md)

## Rule

- **Rule:**
  ```text
  All generated tests should be located in directories with the structure `tests/reliability/<test_type>/generated/<test_name>`, where `<test_type>` is the test type (e.g., `classification`, `complex_types`, `chat`) and `<test_name>` is a descriptive test name.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../claims/CLAIM-dd74eef43bd0696954ab39af.md)
