# Constraints for `tests/reliability/generate/utils.py`

## Rule

- **Rule:**
  ```text
  _clean_schema must recursively strip the keys '__dspy_field_type' and 'title' from JSON schema properties when comparing or emitting cleaned schemas.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying _clean_schema or schema comparison logic to change which dspy-specific keys are removed
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-0418225427f7bad5ed5b77f2.md)

## Rule

- **Rule:** Reliability test utilities that write pretty-printed JSON must return the formatted JSON string when no output path is given, and write to the file and return None when a path is provided.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying or adding JSON-writing helpers used by reliability test generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-148e1b87d2cab28479c0841f.md)

## Rule

- **Rule:** The assertion-generation signature must instruct the model to produce natural-language assertions, ideally about 5, and to leave them blank when accurate assertions are too difficult.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying the assertion-generation signature or its output contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-48281badb30b0fb0fadda955.md)

## Rule

- **Rule:**
  ```text
  generate_test_inputs must disable caching and use temperature 0.5 so retries produce fresh inputs, validate each generated input against the program input schema before saving, and copy results into dst_path.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying generate_test_inputs or the reliability input generation path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-4a1e601a1961316238fd6eb1.md)

## Rule

- **Rule:** Reliability test utilities that remove a specific line from a fixture file must match on the stripped form of each file line while requiring the caller to pass the exact stripped line text as the argument.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying or adding line-removal helpers used to prepare reliability test fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-5aeec23d5355dabdfab5f3f9.md)

## Rule

- **Rule:**
  ```text
  Reliability test inputs must be named input<N>.json and the generator CLI must be invoked with --dst_path (required) plus optional --num_inputs (default 1), --program_instructions, and --input_instructions; find_max_input_number returns the highest existing numeric suffix and 0 when the directory is absent.
  ```
- **Applies to:**
  - `tests/reliability/generate/__main__.py`
  - `tests/reliability/generate/utils.py`
- **Condition:** When adding or modifying reliability test-input generation entry points or input file naming
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-5fba673bc09ea24421aef0aa.md)

## Rule

- **Rule:** Reliability test utilities that strip comments from fixture files must remove only full-line comments (lines whose stripped form starts with '#') and preserve inline trailing comments.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying or adding comment-stripping helpers used to prepare reliability test fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-6731fc2a9a6510f5d99392b8.md)

## Rule

- **Rule:**
  ```text
  Reliability test-generation utilities must keep the ProgramGeneration signature's program_input_fields and program_output_fields as valid JSON Schema with no backticks or explanatory prose, and must obey additional_instructions exactly; the generator is a dspy.ChainOfThought over ProgramGeneration.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the reliability test-program generator signature or its ChainOfThought wiring
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-78367e625ee77c40a7fcc9e9.md)

## Rule

- **Rule:**
  ```text
  expand_refs in the reliability generate utils must inline JSON-schema $ref definitions and preserve the DSPy-specific __dspy_field_type marker when a $ref node also carries it, so generated models retain DSPy field typing after ref expansion.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying JSON-schema ref expansion in the reliability generate utils, particularly handling of $ref nodes that also carry DSPy field-type markers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-983b3145d85c65128a003aa8.md)

## Rule

- **Rule:** Parameterized test decorators in tests/reliability/generate/utils.py must be implemented as decorator factories whose inner decorator returns a wrapper; do not implement them as single-level decorators.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying a parameterized test decorator in the reliability generate utils
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-99fbfa0bb4d2f06c2fff9809.md)

## Rule

- **Rule:**
  ```text
  generate_models must configure datamodel-code-generator with enum_field_as_literal='one', field_constraints=True, use_annotated=False, then strip 'from __future__ import annotations' and generated comments to keep generated pydantic models compatible with built-in type hints.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying generate_models or the generated pydantic model compatibility settings
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-a2f899ac33bc39c6f4c32c12.md)

## Rule

- **Rule:**
  ```text
  Generated reliability case execution must load the generated program, convert the JSON input to program input, run the program, and assert each output assertion via assert_program_output_correct with grading guidelines.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying run_generated_case or the generated reliability case execution path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-af2664ce0527a2ad6a4c0923.md)

## Rule

- **Rule:**
  ```text
  `rename_conflicting_fields` must rename output schema properties that collide with input fields by appending `_output` and update the required list accordingly, defining the collision-avoidance contract for generated reliability tests.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying generated reliability test schema handling that may have input/output field name collisions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-b15bef886df9b28d8ce8856f.md)

## Rule

- **Rule:**
  ```text
  generate_test_program must disable caching and use temperature 0.5 so retries regenerate programs, rename conflicting output fields against the input schema, generate pydantic input/output models, write program.py, validate by loading the generated program before copying files to the destination, and write a cleaned JSON schema.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the reliability generated-program pipeline (generation, validation, or file writing).
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-b7f346d0c0b814bc74704c6d.md)

## Rule

- **Rule:**
  ```text
  Reliability test utilities that retry flaky operations must retry the wrapped callable up to the configured `retries` count and re-raise the last exception once attempts are exhausted, rather than swallowing the failure or returning a sentinel.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying or adding retry-wrapped helpers in the reliability generation utilities.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-bab6e56a458989577cba23cf.md)

## Rule

- **Rule:** Reliability test inputs must be generated independently of expected program outputs: the test-input generator signature requires valid, interesting inputs that exercise the program's capabilities and explicitly forbids reasoning about how the program will respond.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the reliability test-input generation program or its signature/instructions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-c3d44f49c4a8255a2cf01858.md)

## Rule

- **Rule:**
  ```text
  Loading a DSPy program module from an arbitrary file path must temporarily prepend the program's directory to sys.path before executing the module spec, and _json_input_to_program_input must parse a JSON string, validate it against the pydantic input schema, and return a dict keyed by the model's fields.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying program-module loading or JSON-input-to-program-input conversion in the reliability generator
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-ddd086b161ef46ad87daa369.md)

## Rule

- **Rule:**
  ```text
  _get_json_schema must pop $defs from signature.schema() and pass the remaining schema plus definitions to expand_refs so returned signature JSON schemas are fully inlined without $ref.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying _get_json_schema or schema expansion helpers to change $defs handling or $ref inlining
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-e9be564ea47378b87d8e961d.md)

## Rule

- **Rule:**
  ```text
  _temporarily_prepend_to_system_path must save and restore sys.path around a yield to ensure test isolation when temporarily modifying the import path.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying _temporarily_prepend_to_system_path or other sys.path manipulation helpers to change import-path isolation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-fef5eb00130a6d8100ce7902.md)
