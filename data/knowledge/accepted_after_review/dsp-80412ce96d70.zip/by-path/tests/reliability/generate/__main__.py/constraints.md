# Constraints for `tests/reliability/generate/__main__.py`

## Rule

- **Rule:**
  ```text
  Reliability test inputs must be named input<N>.json and the generator CLI must be invoked with --dst_path (required) plus optional --num_inputs (default 1), --program_instructions, and --input_instructions; find_max_input_number returns the highest existing numeric suffix and 0 when the directory is absent.
  ```
- **Applies to:**
  - `tests/reliability/generate/__main__.py`
  - `tests/reliability/generate/utils.py`
- **Condition:** When adding or modifying reliability test-input generation entry points or input file naming
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-5fba673bc09ea24421aef0aa.md)
