# Constraints for `tests/reliability/reliability_tests_conf.yaml`

## Rule

- **Rule:**
  ```text
  The configuration must specify a DSPy adapter to use when testing, such as `"chat"` for `dspy.ChatAdapter` or `"json"` for `dspy.JSONAdapter`.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../../../claims/CLAIM-294a5a7622c7a550755a4c28.md)

## Rule

- **Rule:**
  ```text
  Models lacking configured `litellm_params` in the configuration file are ignored during testing.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../../claims/CLAIM-85cbe3780db719ed92f2a740.md)

## Rule

- **Rule:**
  ```text
  Populate `reliability_tests_conf.yaml` in the reliability tests directory with LiteLLM model/provider names and access credentials for each LLM to test and for the LLM judge, placing them in the `litellm_params` section for each model in the defined `model_list`.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eb0e889d10d50354d187fae4.md)
