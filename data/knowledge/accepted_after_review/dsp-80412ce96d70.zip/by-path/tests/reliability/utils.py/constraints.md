# Constraints for `tests/reliability/utils.py`

## Rule

- **Rule:**
  ```text
  Reliability tests must mark model-specific expected failures with the `known_failing_models` decorator naming the models that cannot meet the task standard, rather than skipping or xfailing the test outright.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When adding or modifying reliability tests that are expected to fail for specific named models.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-272391535eefe2f118340196.md)

## Rule

- **Rule:**
  ```text
  The reliability test helper _get_judge_program must return dspy.Predict(JudgeSignature); do not construct judge programs with a different module or signature.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  when modifying _get_judge_program or how judge programs are constructed in reliability tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3da6ec45ed4bd5f645d51fd8.md)

## Rule

- **Rule:**
  ```text
  parse_reliability_conf_yaml must remain lru_cache'd, require each model_list entry to have a model_name (raising ValueError otherwise), only record entries that have litellm_params, require a top-level adapter key, and wrap any failure in a ValueError naming the conf file.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  when modifying parse_reliability_conf_yaml or the reliability conf schema it validates
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5750a4716c87417d45db2223.md)

## Rule

- **Rule:**
  ```text
  `assert_program_output_correct` must normalize `grading_guidelines` to a list, then under `judge_dspy_configuration` call the judge program with `program_input`, `program_output`, and each guideline, asserting `judge_response.correct` and reporting `judge_response.justification` on failure.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when adding or modifying reliability test assertions that use the LLM judge helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7cd1fc54e08ddaaada3bd81d.md)

## Rule

- **Rule:**
  ```text
  Reliability judge configuration must load reliability_conf.yaml from the module directory, require a LiteLLM config for JUDGE_MODEL_NAME or raise ValueError, and temporarily set dspy.settings.context with the judge LM and adapter.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When modifying reliability judge configuration loading or the dspy.settings.context setup used by reliability tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-850a9640005803fdcaa607ad.md)

## Rule

- **Rule:**
  ```text
  The reliability known_failing_models decorator must attach a _known_failing_models attribute to the wrapped test function; do not change the attribute name or attachment mechanism.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  when modifying the known_failing_models decorator or how tests are marked as known-failing for specific models
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c0c6536c58a432a1c6675648.md)

## Rule

- **Rule:**
  ```text
  The judge program's JudgeSignature must define program_input, program_output, and guidelines as input fields and judge_response as a JudgeResponse output field, and judging must consider only the guidelines.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When modifying the reliability judge program signature or its judging instructions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f386252cd24e17a628c56c18.md)

## Rule

- **Rule:**
  ```text
  Reliability test configuration must be expressed as a pydantic model with an `adapter: str` field and a `models: dict[str, Any]` field, defining the configuration shape reliability tests consume.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When modifying or extending the reliability test configuration model.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f58784c5cd1708706a05f3a5.md)
