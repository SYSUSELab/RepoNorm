# Constraints for `tests/reliability/test_pydantic_models.py`

## Rule

- **Rule:**
  ```text
  A `dspy.Signature` may declare a pydantic `BaseModel` subclass as an `OutputField` type, enabling structured output validation.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying tests that declare pydantic models as Signature OutputField types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1e57e229a6a79b2e97f0c7f1.md)

## Rule

- **Rule:**
  ```text
  test_tool_calling_with_literals must parametrize over dspy.Predict and dspy.ChainOfThought and assert the predicted next_tool_name is one of a fixed set of valid tool names, checking literal-constrained tool selection.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  when modifying test_tool_calling_with_literals or the literal-constrained tool selection assertions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-512c146b1df56ae5be0d2182.md)

## Rule

- **Rule:** Enum output extraction must tolerate trailing punctuation: a response like 'The sky is blue.' must still yield the correct enum member (e.g., Color.BLUE), preserving the fix for the prior failure mode where a trailing period produced invalid enum responses.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying tests for enum output extraction from LM responses
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-52025379e02902eea1fd5ae4.md)

## Rule

- **Rule:**
  ```text
  test_qa_with_pydantic_answer_model must assert that a dspy.Predict(QA) answer exposes .value, .comments, and .certainty, with certainty in [0, 1] and at least 2 comments, and must use assert_program_output_correct with grading guidelines for both value and comments.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  when modifying test_qa_with_pydantic_answer_model or the pydantic answer model assertions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8180e43ea2b5de921842986e.md)

## Rule

- **Rule:** The Colorful signature must declare a str InputField 'text' and an OutputField 'color' typed as the custom Color type, exercising custom-type output handling in reliability tests.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** When modifying the Colorful signature or custom-type output handling in reliability pydantic-model tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-85244d27ba1f0c6c55a67841.md)

## Rule

- **Rule:**
  ```text
  Reliability tests for multi-output signatures must assert each output field separately via assert_program_output_correct with field-specific grading guidelines, including a '|'-separated categories convention.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when modifying reliability tests for multi-output signatures or their grading assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-86bbd1f356058838deeec9f2.md)

## Rule

- **Rule:** A Signature output field may be annotated with a pydantic model type (e.g., ExtractEntityFromDescriptionOutput), showing structured output types are supported in signature definitions.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when modifying signature definitions or tests to change structured output type annotations
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e7860c090f95c4ab10e83853.md)
