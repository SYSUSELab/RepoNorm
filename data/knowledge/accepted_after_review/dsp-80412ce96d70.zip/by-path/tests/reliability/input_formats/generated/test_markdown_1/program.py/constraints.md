# Constraints for `tests/reliability/input_formats/generated/test_markdown_1/program.py`

## Rule

- **Rule:** Generated reliability programs must define dspy.Signature subclasses whose docstrings specify the expected task behavior, such as markdown table-of-contents generation with hierarchical heading levels and markdown links.
- **Applies to:**
  - `tests/reliability/input_formats/generated/test_markdown_1/program.py`
- **Condition:** When modifying generated reliability programs that define dspy.Signature subclasses with task-specific docstrings.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-e92dbdcc88121f21d68fc6d9.md)
