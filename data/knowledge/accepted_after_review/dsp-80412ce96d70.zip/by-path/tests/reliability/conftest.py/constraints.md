# Constraints for `tests/reliability/conftest.py`

## Rule

- **Rule:**
  ```text
  Reliability tests must cover a standard cross-provider MODEL_LIST spanning OpenAI, Anthropic, Gemini, Llama, and DeepSeek models.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** When modifying the reliability test model matrix or adding/removing providers from the standard list.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0643d27815be511138029924.md)

## Rule

- **Rule:**
  ```text
  Reliability tests must declare known-failing models via a `_known_failing_models` attribute on the test function; the shared `pytest_generate_tests` hook parametrizes `configure_model` over MODEL_LIST and pairs each model with a boolean indicating membership in that attribute, so a test that omits the attribute is treated as expecting all models to pass.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:**
  ```text
  when adding or modifying reliability tests that use the `configure_model` fixture or need to mark specific models as known-failing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-187e90bcc4635df7936c0d72.md)

## Rule

- **Rule:**
  ```text
  The autouse configure_model fixture must read reliability_conf.yaml, configure dspy with the parametrized model and adapter, skip tests when no YAML config exists for the model, and store should_ignore_failure and model_name on the request node for post-test handling.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** when modifying the reliability test fixture or its model configuration and skip behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2256cd9806bdf36c0ff50ef4.md)

## Rule

- **Rule:**
  ```text
  The reliability conftest hook must rewrite failed test reports to passed (marked wasxfail) when item.should_ignore_failure is set, so known-failing models do not fail the reliability suite.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:**
  ```text
  When modifying the reliability conftest report hook or the should_ignore_failure handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-35d8a0c7a932252559623d13.md)
