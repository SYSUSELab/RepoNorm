# Constraints for `tests/reliability/complex_types/generated/test_nesting_1/program.py`

## Rule

- **Rule:** A program signature can be built dynamically by iterating pydantic model fields and appending dspy.InputField/OutputField with the field's annotation and description to a BaseSignature.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying generated reliability test programs that construct signatures from pydantic model fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-1bcab8bcbf42e0902b6daf8c.md)

## Rule

- **Rule:** Tests for nested pydantic models in adapters must define and exercise nested BaseModel structures as input and output field types.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
  - `tests/adapters/test_tool.py`
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying adapter or reliability tests that exercise nested pydantic model field types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-788b7dc046bd0bd1dd2a3ba1.md)

## Rule

- **Rule:** Tests for the nesting reliability fixture must define Level3 with a level4 field of type Level4 to establish the expected nested BaseModel structure.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying the nesting reliability fixture that defines nested BaseModel structures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-82d97ccc736257bfc879c168.md)
