# Constraints for `tests/reliability/complex_types/generated/test_many_types_1/program.py`

## Rule

- **Rule:** A program signature can be built dynamically by iterating pydantic model fields and appending dspy.InputField/OutputField with the field's annotation and description to a BaseSignature.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying generated reliability test programs that construct signatures from pydantic model fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-1bcab8bcbf42e0902b6daf8c.md)

## Rule

- **Rule:** Generated reliability programs must define enum-typed fields to exercise dspy handling of enum values.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
- **Condition:** When modifying generated reliability programs that exercise enum-typed fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-21884ee42643512e19b9fae7.md)

## Rule

- **Rule:** Generated reliability fixtures for complex types must define enum fields with the expected option values (such as ProcessedEnumField with option1, option2, option3), establishing the expected enum surface for the fixture.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
- **Condition:** when adding or modifying generated reliability fixtures for complex types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-3a6b4bf7fbb19897d2a2e037.md)
