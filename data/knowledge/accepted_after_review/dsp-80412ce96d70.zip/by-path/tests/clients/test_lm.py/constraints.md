# Constraints for `tests/clients/test_lm.py`

## Rule

- **Rule:**
  ```text
  LM.dump_state must return a dict containing model, model_type, temperature, max_tokens, num_retries, cache, cache_in_memory, finetuning_model, launch_kwargs, and train_kwargs, with cache defaulting to True and finetuning_model to None.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:**
  ```text
  when modifying or extending LM.dump_state serialization assertions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1219683de14c962454e24638.md)

## Rule

- **Rule:**
  ```text
  When a test asserts that dspy.LM forwards model, api_base, api_key, and azure_ad_token_provider to litellm.completion, a callable azure_ad_token_provider must be passed through to the underlying completion call.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:**
  ```text
  Modifying dspy.LM parameter forwarding to litellm.completion, especially callable parameters such as azure_ad_token_provider.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-26caf5210c689431dac3fde6.md)

## Rule

- **Rule:**
  ```text
  num_retries counts retries beyond the initial attempt, so total attempts equal num_retries + 1.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:**
  ```text
  When modifying LM retry logic or the num_retries configuration semantics.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7da31cba8c980577ca87456e.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise cache behavior must configure caches through dspy.clients.configure_cache and restore the prior dspy.cache state afterward, and must assert that a cache hit suppresses new usage-tracker entries.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:** When adding or modifying cache tests that configure disk, memory, or litellm caches.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a6ecb10ceae7bac81428c43f.md)

## Rule

- **Rule:** dspy.LM.acall with cache disabled must return the mocked completion content as a list and invoke litellm.acompletion exactly once.
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:** When modifying dspy.LM.acall or its interaction with litellm.acompletion under disabled cache.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aaeeb7296c11c006a0eb8490.md)
