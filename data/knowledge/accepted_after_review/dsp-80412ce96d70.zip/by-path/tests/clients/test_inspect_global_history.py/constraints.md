# Constraints for `tests/clients/test_inspect_global_history.py`

## Rule

- **Rule:**
  ```text
  GLOBAL_HISTORY must be a list of dict entries each containing a messages key, accumulating entries after Predict calls.
  ```
- **Applies to:**
  - `tests/clients/test_inspect_global_history.py`
- **Condition:** when modifying global history accumulation, entry structure, or history inspection behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aaac01cd2d030a2b0ff85261.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise global history state must reset GLOBAL_HISTORY before each test via an autouse fixture to preserve test isolation.
  ```
- **Applies to:**
  - `tests/clients/test_inspect_global_history.py`
- **Condition:** when adding or modifying tests that read or mutate global history state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e0a01bbdde0876be9e93309e.md)
