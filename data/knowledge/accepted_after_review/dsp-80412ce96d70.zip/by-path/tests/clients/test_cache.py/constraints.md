# Constraints for `tests/clients/test_cache.py`

## Rule

- **Rule:**
  ```text
  Cache must be instantiated with keyword configuration from a cache_config fixture, establishing the convention for Cache construction in tests.
  ```
- **Applies to:**
  - `tests/clients/test_cache.py`
- **Condition:** when modifying Cache instantiation or cache test fixtures
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7322e875771124c900c65202.md)

## Rule

- **Rule:**
  ```text
  When a test resets the memory cache, reset_memory_cache() must empty only the in-memory cache while previously stored requests remain retrievable from the disk cache.
  ```
- **Applies to:**
  - `tests/clients/test_cache.py`
- **Condition:**
  ```text
  Modifying reset_memory_cache or cache reset behavior such that persisted disk entries could be cleared or memory entries retained.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-81f57f0c528d0cd6f7ea6051.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the request_cache decorator's ignored_args_for_cache_key option must verify that excluded named arguments do not affect the cache key, so repeated calls differing only in ignored arguments hit the same cache entry.
  ```
- **Applies to:**
  - `tests/clients/test_cache.py`
- **Condition:**
  ```text
  when adding or modifying tests for request_cache decorator cache-key customization
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bd7ae6114dd833a342dff980.md)
