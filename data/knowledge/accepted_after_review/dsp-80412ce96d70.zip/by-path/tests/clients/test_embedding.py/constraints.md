# Constraints for `tests/clients/test_embedding.py`

## Rule

- **Rule:** Tests for Embedder construction must assert that a non-string model type raises ValueError.
- **Applies to:**
  - `tests/clients/test_embedding.py`
- **Condition:** When modifying Embedder constructor validation tests for model type.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e470a065c13c34a0e44c5518.md)
