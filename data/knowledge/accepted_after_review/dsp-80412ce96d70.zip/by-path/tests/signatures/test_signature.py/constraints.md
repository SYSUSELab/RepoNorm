# Constraints for `tests/signatures/test_signature.py`

## Rule

- **Rule:**
  ```text
  infer_prefix must convert camelCase, snake_case, and acronym-containing names into spaced title-case prefixes while preserving digits and acronym boundaries.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:**
  ```text
  When modifying the infer_prefix helper or any logic that derives human-readable prefixes from field names.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-036f26ac61834d3a25b6380b.md)

## Rule

- **Rule:**
  ```text
  Signature field metadata must expose a 'prefix' key in json_schema_extra for input and output fields, with defaults such as 'Modified:' and 'Output:'.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:**
  ```text
  when modifying signature field metadata or json_schema_extra generation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1476b2590bc048a064c83695.md)

## Rule

- **Rule:** Signature.prepend and Signature.append must place new fields at the first/last position of the respective field dicts, preserving the ordering contract for signature field insertion.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When modifying signature field insertion or ordering behavior in signature tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3a416203c8ebc630c8816fb2.md)

## Rule

- **Rule:** When a test constructs a Predict from a signature with multiline instructions, the Predict must still return the LM output field value, so multiline instruction text must be accepted without breaking prediction.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** Modifying instruction handling or signature parsing such that multiline instruction text could break Predict execution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4aac58e1e8a15154b3f31f41.md)

## Rule

- **Rule:**
  ```text
  Signature field annotations must be preserved verbatim on input_fields/output_fields, including generic aliases like list[str] and PEP 604 unions, so downstream code can rely on annotation fidelity.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When modifying signature field declaration or annotation handling in signature tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-550dc5eff5615a5e4d866477.md)

## Rule

- **Rule:** Signature field order must be preserved when a signature mixes annotated and unannotated fields; the resulting field keys must match the declared order.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When modifying signature field declaration or field-collection logic that determines the order of signature fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-72feaa7340086a05e896ebf9.md)

## Rule

- **Rule:**
  ```text
  dump_state must emit instructions plus per-field prefix/description, and load_state must return a new signature with that state without mutating the class it is called on.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:**
  ```text
  When modifying signature dump_state/load_state serialization or state restoration logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-75c8d2e98c577b52103789ba.md)

## Rule

- **Rule:** PEP 604 union types in class signatures must be equivalent to Optional/Union types: Sig.equals holds, input/output field annotations compare equal, and annotations are instances of UnionType.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** when modifying signature type annotation handling or equality comparison
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a41eaa5fa430a46f98ea97f0.md)

## Rule

- **Rule:** Tests for Signature equality must assert that a Signature class equals itself via the equals classmethod, pinning the reflexive equality behavior.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** when adding or modifying Signature equality tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bf031e241d39adbb7340df12.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Signature type parsing must assert that nested generic annotations and PEP 604 unions are preserved through parsing, including dict/list/Union/tuple origins and their args, and must use a pydantic BaseModel custom type resolved via the custom_types mapping.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When adding or modifying tests for Signature annotation parsing, custom types, or PEP 604 unions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d8bc9914169445f12103b07f.md)

## Rule

- **Rule:**
  ```text
  When a test updates a Signature field via with_updated_fields, the original Signature must remain unmutated (its field prefix unchanged) while the returned copy carries the modified prefix and preserves all other fields and instructions.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:**
  ```text
  Modifying with_updated_fields or Signature field-update behavior such that the original Signature could be mutated.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f7ffee0f74173e5aa2b8efa8.md)

## Rule

- **Rule:**
  ```text
  Signature field constraints must be exposed through output_fields json_schema_extra, and tests must assert minimum/maximum length and greater/less-than-or-equal bounds on those fields.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** when adding or modifying signature field constraint assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fb5794fad33aa669c1a35a44.md)
