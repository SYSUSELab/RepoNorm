# Constraints for `tests/signatures/test_adapter_image.py`

## Rule

- **Rule:**
  ```text
  Image-encoding output must keep the 'data:<mime>;base64,' prefix shape intact; tests assert substring containment rather than startswith to tolerate MIME parameters.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** when modifying image-encoding output format or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4c193ab2cfbae32e8622814f.md)

## Rule

- **Rule:**
  ```text
  dspy.Image string representation must wrap a JSON-like payload in '<<CUSTOM-TYPE-START-IDENTIFIER>>' and '<<CUSTOM-TYPE-END-IDENTIFIER>>' markers; URL images serialize as [{'type': 'image_url', 'image_url': {'url': ...}}] and PIL images produce a base64 payload, with repr as Image(url='...').
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** When modifying dspy.Image serialization or adding tests for image adapter behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8bf47d0b0dca4568b2b92750.md)

## Rule

- **Rule:** Image and PDF handling in signatures must preserve image URL counts in LM history after save/load and must serialize PDF data URIs with application/pdf and base64 markers.
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** when modifying image or PDF serialization, save/load, or adapter behavior in signature image tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af889fab0defb8e8ecca8b7d.md)

## Rule

- **Rule:**
  ```text
  Image input format tests must explicitly xfail pil_image and encoded_pil_image cases with a TODO noting they are not fully supported without dspy.from_PIL, documenting a known compatibility boundary.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** when modifying image input format support or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dd2bf2d34a5a985b2e27dd5e.md)

## Rule

- **Rule:**
  ```text
  Image adapter tests must exercise both single image and list image fields through pydantic models, with ImageModel defining image: dspy.Image, optional image_list: list[dspy.Image], and output: str.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** when modifying image adapter test fixtures or pydantic model schemas
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eaa544cc5172b75312b264c0.md)
