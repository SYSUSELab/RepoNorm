# Constraints for `tests/signatures`

## Rule

- **Rule:** Signature parsing must auto-resolve module-level custom type annotations to the actual class, and a signature with no input or output fields must raise TypeError; signature equality must distinguish signatures whose field names differ.
- **Applies to:**
  - `tests/signatures/**/*.py`
- **Condition:** when modifying signature parsing, field resolution, or equality behavior in signature tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3731bfcea9db0c402ff65c71.md)
