# Constraints for `tests/signatures/test_custom_types.py`

## Rule

- **Rule:** Signature output fields annotated with a nested class must resolve to that exact nested annotation, preserving nested class types in signature output fields.
- **Applies to:**
  - `tests/signatures/test_custom_types.py`
- **Condition:** When modifying signature type resolution or annotation handling for nested class types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3435339d0903d12b1175a43f.md)

## Rule

- **Rule:** Test modules for custom types must import pydantic and dspy and define module-level nested classes for testing custom type handling in signatures.
- **Applies to:**
  - `tests/signatures/test_custom_types.py`
- **Condition:** When modifying custom type test modules or signature custom type handling tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eba1b3f9cdf566177115e4d6.md)

## Rule

- **Rule:** When a test resolves signature string annotations, local, module-level, and nested (dot-notation) custom types must resolve, and an alias assigned to a nested type must resolve to the underlying nested class.
- **Applies to:**
  - `tests/signatures/test_custom_types.py`
- **Condition:** Modifying signature string annotation resolution for local, module-level, nested, or aliased custom types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f1834309fa5bc1dfe85174a6.md)
