# Constraints for `tests/predict/test_parallel.py`

## Rule

- **Rule:** When a test runs a Parallel batch, the output set must match expected outputs regardless of order, and each reasoning string must correspond to its output number, preserving per-item output/reasoning pairing.
- **Applies to:**
  - `tests/predict/test_parallel.py`
- **Condition:** Modifying Parallel execution or result aggregation such that per-item output/reasoning pairing could be lost or reordered incorrectly.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b3cf97771414b612d6e2fed5.md)
