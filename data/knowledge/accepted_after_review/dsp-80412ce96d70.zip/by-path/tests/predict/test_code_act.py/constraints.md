# Constraints for `tests/predict/test_code_act.py`

## Rule

- **Rule:**
  ```text
  CodeAct interpreter tests must assert that the interpreter's deno_process is None after execution completes, whether the generated code succeeded or failed, so subprocess cleanup is verified on both the success and error-recovery paths.
  ```
- **Applies to:**
  - `tests/predict/test_code_act.py`
- **Condition:** when adding or modifying CodeAct interpreter tests that run generated code to completion
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-12028f2f19a9033953052097.md)

## Rule

- **Rule:**
  ```text
  CodeAct must raise ValueError with message "CodeAct only accepts functions and not callable objects." when passed a callable object instance, and this validation is gated by skip_if_deno_not_available.
  ```
- **Applies to:**
  - `tests/predict/test_code_act.py`
- **Condition:** When modifying CodeAct tool validation or adding tests for callable object rejection.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d7761e36f276aef9013e3d84.md)

## Rule

- **Rule:** The CodeAct test suite is skipped unless the deno executable is found on PATH, so contributors must install Deno to run these tests locally.
- **Applies to:**
  - `tests/predict/test_code_act.py`
- **Condition:** When modifying CodeAct test setup or environment gating that depends on the deno executable.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f29e06f057b6ea2c145280fc.md)
