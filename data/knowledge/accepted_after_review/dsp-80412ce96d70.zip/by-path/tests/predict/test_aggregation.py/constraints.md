# Constraints for `tests/predict/test_aggregation.py`

## Rule

- **Rule:** Passing field="other" to majority aggregation must select the majority value from that field rather than the default answer field.
- **Applies to:**
  - `tests/predict/test_aggregation.py`
- **Condition:** When modifying majority aggregation field selection or adding tests for custom field aggregation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4cd5e7db807a4abe70d28729.md)
