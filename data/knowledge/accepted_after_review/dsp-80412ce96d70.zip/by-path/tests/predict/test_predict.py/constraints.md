# Constraints for `tests/predict/test_predict.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise Predict.dump_state()/load_state() must preserve demo content across a ujson round-trip, while allowing demo types to change after save/load.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  When modifying Predict state serialization tests or the dump_state/load_state round-trip assertions.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0fcec80c95f7c5bb4778c85e.md)

## Rule

- **Rule:**
  ```text
  Tests for Predict LM state serialization must assert that dump_state matches the expected dict of model, model_type, temperature, max_tokens, num_retries, cache, cache_in_memory, finetuning_model, launch_kwargs, and train_kwargs, and that dump/load_state round-trips the LM configuration.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** when adding or modifying Predict LM state serialization tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-21ee10c6d4deea51d810a3c6.md)

## Rule

- **Rule:**
  ```text
  Predict call contract must return a result whose output field matches the LM's canned response, and named_predictors must reflect the module's own predictor instances and survive deepcopy.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  when modifying Predict call behavior, output field mapping, or named_predictors traversal and deepcopy behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4c08a1c9904e2393c49a8627.md)

## Rule

- **Rule:**
  ```text
  InputField and OutputField must accept pydantic-style constraints such as min_length, max_length, gt, lt, ge, le, and multiple_of.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** when modifying InputField or OutputField constraint handling or pydantic-style validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6668a9adc840a76d76c7a41d.md)

## Rule

- **Rule:**
  ```text
  When a test constructs a Predict from a string signature such as "input1, input2 -> output", the resulting default instruction must equal Signature(signature_string).instructions, i.e. "Given the fields `input1`, `input2`, produce the fields `output`."
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** Modifying how Predict derives default instructions from a string signature, or changing Signature.instructions generation for string signatures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-831ddc53a438d0ce8f702e09.md)

## Rule

- **Rule:** Predict forward must return the answer field from the configured LM response, surfacing the LM answer directly.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying Predict forward behavior or LM response handling in predict tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8741b9d23e71b33347035c82.md)

## Rule

- **Rule:** Predict tests must define translation-style signatures with content and language inputs and a translation output.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying predict test signatures or translation-style test cases in predict tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a4576363ea3ef53abd84449c.md)

## Rule

- **Rule:**
  ```text
  After loading a saved Predict instance, the signature dump_state must equal the original instance's dump_state even when the new instance was constructed with a different signature.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying Predict save/load logic or signature state serialization that affects round-trip equality.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae1807dcefdde86e07f469ef.md)

## Rule

- **Rule:**
  ```text
  Predict.update_config must add a key and get_config must return it, establishing the config mutation/retrieval contract for Predict.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  When modifying Predict config management methods update_config or get_config.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c77568cb5ebf213cd588c5db.md)

## Rule

- **Rule:**
  ```text
  When track_usage=True, a Predict result must expose per-model token usage via get_lm_usage(), keyed by the model identifier, with total_tokens matching the mocked response usage.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  When modifying Predict usage tracking or adding tests for get_lm_usage().
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d3b22ca666527f577519f484.md)

## Rule

- **Rule:** Enum output values must be coerced back to the corresponding enum member, including enums whose names and values overlap.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying enum input/output handling or coercion in predict tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ecd8cc3731a5177269b6669d.md)
