# Constraints for `tests/predict/test_refine.py`

## Rule

- **Rule:**
  ```text
  Refine retry behavior must preserve fail_count semantics: the module is retried up to fail_count times before a ValueError propagates, and the default fail_count must still raise after exhausting retries.
  ```
- **Applies to:**
  - `tests/predict/test_refine.py`
- **Condition:** when modifying Refine retry/failure handling or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-473c07e56223294d63d63285.md)
