# Constraints for `tests/predict/test_knn.py`

## Rule

- **Rule:** KNN query must return the configured number of nearest samples ordered with the closest match first.
- **Applies to:**
  - `tests/predict/test_knn.py`
- **Condition:** when modifying KNN query behavior, sample count, or ordering logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-406f446b3dba93c53e169f0f.md)

## Rule

- **Rule:** KNN must store trainset vectors as a NumPy ndarray with one vector per trainset example.
- **Applies to:**
  - `tests/predict/test_knn.py`
- **Condition:** When modifying KNN initialization or adding tests for KNN internal representation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c01c963680307a2a422abc1b.md)
