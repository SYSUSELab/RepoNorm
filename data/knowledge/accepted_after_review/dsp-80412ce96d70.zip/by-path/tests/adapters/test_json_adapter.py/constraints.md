# Constraints for `tests/adapters/test_json_adapter.py`

## Rule

- **Rule:** Tests for the JSON adapter must define a TestSignature with nested pydantic models as input and output field types.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSON adapter tests that define Signature classes with nested pydantic model field types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-02cf27bf48857b6f125b1773.md)

## Rule

- **Rule:** Tests for the JSON adapter's handling of non-string input types must define a Signature with a non-string input field (such as an image wrapper) and a string output field, so adapter formatting of non-string inputs is exercised.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** when adding or modifying JSON adapter tests that exercise non-string input types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0a254a2ff5bbd87d5e2b1f97.md)

## Rule

- **Rule:**
  ```text
  Using structured outputs must not mutate the original signature; the signature's output_fields must remain equal to the pre-call signature after a completion call.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSON adapter structured-output handling or any code path that could alter a signature during a completion call.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1b1d2623964352e470d92f0d.md)

## Rule

- **Rule:**
  ```text
  Tests for the JSON adapter must verify that when the model provider does not support structured outputs, the completion call omits response_format.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSON adapter tests that cover provider structured-output support detection.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-260b7d34188022f6053ceea6.md)

## Rule

- **Rule:**
  ```text
  JSONAdapter.format must emit each image in a nested image list as a separate image_url content entry in the user message, expanding nested image wrappers to multiple content items.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSONAdapter.format image handling or nested image list expansion.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-54133d17dcecdded5dfb7a70.md)

## Rule

- **Rule:**
  ```text
  Formatting a signature with a dspy.History of two messages must produce exactly 6 messages, with each history turn rendered as a '[[ ## question ## ]]' content message followed by a JSON object content message for the answer.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** when modifying JSON adapter conversation history formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5f1889a6fa1abfc8873862f9.md)

## Rule

- **Rule:** Test signatures must intentionally leave some output fields without descriptions to exercise adapter behavior for blank versus populated field descriptions.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSON adapter test signatures or field description handling in adapter tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-65b4df9f36126ec42615fafa.md)

## Rule

- **Rule:** Tests for nested pydantic models in adapters must define and exercise nested BaseModel structures as input and output field types.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
  - `tests/adapters/test_tool.py`
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying adapter or reliability tests that exercise nested pydantic model field types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-788b7dc046bd0bd1dd2a3ba1.md)

## Rule

- **Rule:**
  ```text
  Adapter test signatures must include tools as a list of dspy.Tool inputs and tool_calls as a dspy.ToolCalls output, establishing the expected tool-calling field types.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** when modifying adapter tool-calling signature field types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-83b0703b9ad8cb4deb4ee0c4.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise JSON adapter image formatting must assert that formatting a signature with two image demos and one image input yields exactly 6 messages, with image_url content dicts at messages[1], [3], and [5], fixing the few-shot image message layout.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When adding or modifying tests for JSON adapter formatting of image demos or image inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc951da352c5939034c971d6.md)

## Rule

- **Rule:** Adapter formatting must include nested output field type descriptions in the system message and carry input code in the user message, and must support list-of-custom-type serialization in XML.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
  - `tests/adapters/test_xml_adapter.py`
- **Condition:** when modifying JSON or XML adapter formatting, nested type descriptions, or list-of-custom-type serialization
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ebd37cce91021d2751043d7e.md)

## Rule

- **Rule:** JSONAdapter must propagate the original exception type and message from underlying LM calls (RuntimeError, ValueError) rather than wrapping them.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSONAdapter error handling or exception propagation in adapter tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f376c10d9f62e7046c0e8547.md)

## Rule

- **Rule:**
  ```text
  When the first litellm.completion call with a pydantic response_format raises, JSONAdapter must retry with response_format={'type': 'json_object'}, resulting in exactly two completion calls.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** when modifying JSONAdapter structured output fallback behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f92b1c4f0f51bf00478fb0fd.md)
