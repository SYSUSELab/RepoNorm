# Constraints for `tests/adapters/test_code.py`

## Rule

- **Rule:** Tests for the code adapter must exercise dspy.Code through a pydantic model container (a Wrapper model), so code adapter behavior is validated in nested-type contexts.
- **Applies to:**
  - `tests/adapters/test_code.py`
- **Condition:** when adding or modifying code adapter tests that exercise dspy.Code in nested type contexts
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-39daf55a31887f64558e31c7.md)
