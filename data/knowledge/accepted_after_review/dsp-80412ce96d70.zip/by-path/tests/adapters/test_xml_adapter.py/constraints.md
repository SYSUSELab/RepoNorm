# Constraints for `tests/adapters/test_xml_adapter.py`

## Rule

- **Rule:**
  ```text
  When a test formats a signature with nested ImageWrapper demos, XMLAdapter.format must produce four messages, place each demo image as an image_url content entry in the few-shot user message, and place the query image in the last user message.
  ```
- **Applies to:**
  - `tests/adapters/test_xml_adapter.py`
- **Condition:** Modifying XMLAdapter.format handling of nested image models in demos or query inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4eb16762c5d1d0a7cc43021c.md)

## Rule

- **Rule:**
  ```text
  XML adapter format_field_with_value must wrap lists of Pydantic models in an <items> element containing JSON-serialized model dumps, and parse must reconstruct the list back into typed instances preserving field values.
  ```
- **Applies to:**
  - `tests/adapters/test_xml_adapter.py`
- **Condition:** When modifying XML adapter list serialization or parsing behavior in adapter tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6c6b67bcf7f717c93d2e35d1.md)

## Rule

- **Rule:** Tests for the XML adapter's structured output must define pydantic models with typed fields and assert that list-of-model outputs parse back into those models, preserving the structured XML parsing contract.
- **Applies to:**
  - `tests/adapters/test_xml_adapter.py`
- **Condition:** when adding or modifying XML adapter tests that exercise structured output parsing
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-71003ba9fce23241de8ab599.md)

## Rule

- **Rule:**
  ```text
  Adapter parse failures for missing required signature fields must raise AdapterParseError carrying adapter_name, signature, lm_response, and a message naming the missing field.
  ```
- **Applies to:**
  - `tests/adapters/test_xml_adapter.py`
- **Condition:** When modifying XML adapter parsing or its error handling for completions missing a required field.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-94e36327c050f8e0d0fb901a.md)

## Rule

- **Rule:** Adapter formatting must include nested output field type descriptions in the system message and carry input code in the user message, and must support list-of-custom-type serialization in XML.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
  - `tests/adapters/test_xml_adapter.py`
- **Condition:** when modifying JSON or XML adapter formatting, nested type descriptions, or list-of-custom-type serialization
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ebd37cce91021d2751043d7e.md)
