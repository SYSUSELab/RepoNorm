# Constraints for `tests/adapters/test_tool.py`

## Rule

- **Rule:**
  ```text
  Tests for the tool adapter must assert the canonical conversion from a list of {name, args} dicts to OpenAI-style tool_calls messages, including that an empty list produces an empty tool_calls array and multiple calls are grouped into one message.
  ```
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:**
  ```text
  when adding or modifying tool adapter tests that exercise tool_calls message conversion
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-055236d60ce661dc7b191916.md)

## Rule

- **Rule:**
  ```text
  Calling an async Tool in sync mode must raise ValueError unless dspy.context(allow_tool_async_sync_conversion=True) is set, in which case the awaited result is returned.
  ```
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:**
  ```text
  When modifying async Tool invocation in sync mode or the allow_tool_async_sync_conversion context flag.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0fea955e7c0355eca53a6985.md)

## Rule

- **Rule:** Tool call serialization must preserve input order and function names when converting from dict lists, and async tool calls must support nested Pydantic models returning dicts with preserved scalar and nested fields.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** when modifying tool call serialization, dict-list conversion, or async tool call handling with Pydantic models
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2c20a263f3f3e77a7b7758bf.md)

## Rule

- **Rule:** Tool argument type-validation failures must raise ValueError.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying Tool argument validation or its error behavior for type-mismatched arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-48f56843b0c35706850e0cb5.md)

## Rule

- **Rule:** Tests for the tool adapter must define nested pydantic models with optional fields and lists of nested models.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying tool adapter tests that define nested pydantic model fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-599f7d2d0d7d33ee796441b4.md)

## Rule

- **Rule:** Tests for nested pydantic models in adapters must define and exercise nested BaseModel structures as input and output field types.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
  - `tests/adapters/test_tool.py`
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying adapter or reliability tests that exercise nested pydantic model field types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-788b7dc046bd0bd1dd2a3ba1.md)

## Rule

- **Rule:** Async tool invocation tests must use async test helpers that await asyncio.sleep and return formatted results, exercising async tool invocation with default parameter handling.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** when modifying async tool invocation tests or helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7eee484a796e35349f502130.md)
