# Constraints for `tests/test_utils/server/litellm_server.py`

## Rule

- **Rule:** The litellm test server must map substrings in the first message content to specific litellm exceptions: '429' to RateLimitError, '504' to Timeout, '400' to BadRequestError, and '401' to AuthenticationError.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying the litellm test server's exception injection or message-content mapping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-306065c671f3389b4b349e2f.md)

## Rule

- **Rule:**
  ```text
  The LiteLLM test server's streaming method must return a single `GenericStreamingChunk` with `is_finished=True`, `finish_reason='stop'`, and zeroed usage, modeling a one-chunk streamed response.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when adding or modifying the LiteLLM test server's streaming response behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-7250f8ee9bcb70c720c7dff3.md)

## Rule

- **Rule:**
  ```text
  The litellm test server's _get_mock_llm_response must first call _throw_exception_based_on_content_if_applicable, then return a litellm.completion with a fixed mock_response, so tests can trigger server-side exceptions based on request content.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying the litellm test server mock response logic to change exception triggering or mock completion behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-923db89809fecca4c971cab3.md)

## Rule

- **Rule:** The mock litellm server's acompletion appends the request kwargs to a log file and returns a mock LLM response, so tests using this server can inspect logged requests and receive deterministic responses.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying the mock litellm server or tests that rely on its request logging and deterministic responses
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-98b883ff432de764602d411f.md)

## Rule

- **Rule:** The litellm test server module must define DSPyTestModel as a subclass of CustomLLM to provide a custom LLM implementation for server-based tests.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When modifying the litellm test server module or adding custom LLM implementations for server-based tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-beb12f85e281365ce86db4fb.md)

## Rule

- **Rule:**
  ```text
  _append_request_to_log_file must require the LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR environment variable, raising ValueError if unset, and append a JSON line containing model and messages to that file.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When modifying the test server request logging helper or its environment-variable contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-d5a9e32dde51bed0f71de618.md)

## Rule

- **Rule:**
  ```text
  The litellm test server's completion method must log each request kwargs and return a mock LLM response, and astreaming must yield a GenericStreamingChunk with finish_reason stop, index 0, is_finished True, text containing a JSON output_text payload, tool_use None, and zeroed usage.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When modifying the litellm test server's completion or astreaming response shape
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-e9d144730d1fde1455a8dad1.md)

## Rule

- **Rule:**
  ```text
  The LiteLLM test server must read its log file path from the `LITELLM_TEST_SERVER_LOG_FILE_PATH` environment variable and expose a module-level `dspy_test_model` instance as the integration point for tests needing a local LiteLLM-compatible server.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when adding or modifying the LiteLLM test server or tests that consume it
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-f96a388f71e705490080ba14.md)
