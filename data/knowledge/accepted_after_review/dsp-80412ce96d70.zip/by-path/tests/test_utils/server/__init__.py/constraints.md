# Constraints for `tests/test_utils/server/__init__.py`

## Rule

- **Rule:**
  ```text
  The LiteLLM test server config path must be resolved relative to the test_utils/server module directory as litellm_server_config.yaml, so the config file must live alongside that module.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when modifying the LiteLLM test server config path resolution or relocating the config file
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-046158146f54dab586c2e3ef.md)

## Rule

- **Rule:** Server tests must allocate free ports by binding a socket to ("", 0) and returning the OS-assigned port, rather than hardcoding a port number.
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** When adding or modifying server test helpers that need a free port.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-3164013c9fea6a0de4036da0.md)

## Rule

- **Rule:**
  ```text
  _wait_for_port must poll a host/port with a socket connection every 0.5 seconds until a timeout, raising TimeoutError if the server does not become ready, as the convention for waiting on test servers.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** When modifying test server readiness waiting logic or adding helpers that wait for a server to become available.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-97458439797efba5f8db6f36.md)

## Rule

- **Rule:**
  ```text
  The test server package must expose LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR from tests.test_utils.server.litellm_server so tests can read the log-file path via an environment variable.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when modifying the test server package exports or the log-file path environment variable
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-9d0cf9582cfd2fa4ab6139f3.md)

## Rule

- **Rule:**
  ```text
  The litellm_test_server fixture must start a LiteLLM proxy on a random port with a temp request-log file, wait for the port, yield (server_url, log_path), and kill the process on teardown; on port-wait timeout it must terminate the process and re-raise.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:**
  ```text
  when modifying the litellm_test_server fixture lifecycle or its port-wait and teardown behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-fda66cdd883554bfc87f9461.md)
