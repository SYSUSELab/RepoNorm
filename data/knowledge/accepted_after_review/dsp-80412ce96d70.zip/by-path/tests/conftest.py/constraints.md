# Constraints for `tests/conftest.py`

## Rule

- **Rule:**
  ```text
  The shared conftest defines an anyio_backend fixture returning 'asyncio', establishing that async tests in this repository run under the asyncio backend by default.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** when modifying the shared conftest or adding async tests that depend on the anyio backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1fa0160496361e1d8656b990.md)

## Rule

- **Rule:**
  ```text
  `conftest`'s `pytest_configure` must register each flag in `SKIP_DEFAULT_FLAGS` as a pytest marker via `config.addinivalue_line`, so tests can be skipped by default using these named markers.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  when adding or modifying default-skip markers or the `SKIP_DEFAULT_FLAGS` list in conftest
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5472eaa14095a08b17afa6b1.md)

## Rule

- **Rule:**
  ```text
  Tests gated behind opt-in pytest flags must be registered in SKIP_DEFAULT_FLAGS and skipped by pytest_collection_modifyitems unless the matching --flag option is supplied; new opt-in test categories must add both the flag registration and the skip mapping rather than relying on markers alone.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  When adding or modifying tests that should only run under an explicit CLI flag, or when changing the SKIP_DEFAULT_FLAGS mapping or pytest_addoption registrations.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-713cbcb93e745ed801aa87a5.md)
