# Constraints for `tests/datasets/test_dataset.py`

## Rule

- **Rule:**
  ```text
  The csv_file fixture must write dummy_data to a NamedTemporaryFile with .csv suffix, flush, and yield the file name, providing a stable convention for CSV dataset tests.
  ```
- **Applies to:**
  - `tests/datasets/test_dataset.py`
- **Condition:** When modifying CSV dataset test fixtures or dataset loading tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-07bf5020b2eafba82518b45c.md)
