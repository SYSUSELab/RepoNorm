# Constraints for `tests/teleprompt/test_copro_optimizer.py`

## Rule

- **Rule:**
  ```text
  When track_stats=True, the compiled student program must gain total_calls and results_best attributes, attaching optimizer statistics to the optimized program object.
  ```
- **Applies to:**
  - `tests/teleprompt/test_copro_optimizer.py`
- **Condition:** when modifying optimizer statistics tracking or compiled program attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5d6532964771aaf866db6de5.md)

## Rule

- **Rule:**
  ```text
  Teleprompt optimizer tests must supply input-marked dspy.Example objects via .with_inputs("input") rather than raw dicts, establishing the repository convention for teleprompt trainsets.
  ```
- **Applies to:**
  - `tests/teleprompt/test_copro_optimizer.py`
- **Condition:** when adding or modifying teleprompt optimizer tests that define a trainset
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-be4450cac3f3aab063fb52f5.md)

## Rule

- **Rule:**
  ```text
  When a test enables COPRO.track_stats, the compiled student must expose total_calls > 0 plus results_best and results_latest entries.
  ```
- **Applies to:**
  - `tests/teleprompt/test_copro_optimizer.py`
- **Condition:**
  ```text
  Modifying COPRO statistics tracking or compiled student statistics exposure when track_stats is enabled.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c7c8900809a9e6a0241f2a5d.md)
