# Constraints for `tests/teleprompt/test_bootstrap.py`

## Rule

- **Rule:**
  ```text
  BootstrapFewShot with max_bootstrapped_demos=1 and max_labeled_demos=1 must produce exactly one demo matching the trainset example, and DummyLM with follow_examples=True must reuse that matching example rather than its queued second response.
  ```
- **Applies to:**
  - `tests/teleprompt/test_bootstrap.py`
- **Condition:**
  ```text
  when modifying BootstrapFewShot demo selection or DummyLM follow_examples behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-09e2c96ae6877d2f1ca6d72c.md)

## Rule

- **Rule:**
  ```text
  Bootstrap test fixtures must include at least one example with with_inputs so that only input-bearing examples are treated as inputs.
  ```
- **Applies to:**
  - `tests/teleprompt/test_bootstrap.py`
- **Condition:** When modifying bootstrap test fixtures that define module-level examples/trainset/valset.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a719f276460cd32f4782e8b9.md)

## Rule

- **Rule:**
  ```text
  Bootstrap test modules must construct a single Predict instance stored as self.predictor in the module __init__.
  ```
- **Applies to:**
  - `tests/teleprompt/test_bootstrap.py`
- **Condition:** When modifying bootstrap test modules that define a module class wrapping a single Predict.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fb6580b68cc576ed5527bd6d.md)

## Rule

- **Rule:** After BootstrapFewShot.compile, the compiled student's predictor demos must be at least as numerous as the validation set.
- **Applies to:**
  - `tests/teleprompt/test_bootstrap.py`
- **Condition:** When modifying BootstrapFewShot.compile or how validation examples are incorporated into predictor demos.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fe84a253af824e3541023059.md)
