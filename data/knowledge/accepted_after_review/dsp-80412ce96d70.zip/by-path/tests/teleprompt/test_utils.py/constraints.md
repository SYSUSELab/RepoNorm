# Constraints for `tests/teleprompt/test_utils.py`

## Rule

- **Rule:**
  ```text
  eval_candidate_program must call evaluate exactly once with a devset sliced to batch_size and callback_metadata {'metric_key': 'eval_minibatch'}, returning the evaluate result.
  ```
- **Applies to:**
  - `tests/teleprompt/test_utils.py`
- **Condition:**
  ```text
  when modifying eval_candidate_program or its minibatch evaluation behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9045ef1f33975b23df9917e3.md)

## Rule

- **Rule:**
  ```text
  Test helper classes extending base test utilities must call super().__init__() in their constructor.
  ```
- **Applies to:**
  - `tests/teleprompt/test_utils.py`
- **Condition:** When modifying test helper class constructors in teleprompt test utilities
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ff99b21106f4a8a5f1d7c577.md)
