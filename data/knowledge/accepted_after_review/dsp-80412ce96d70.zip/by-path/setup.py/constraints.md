# Constraints for `setup.py`

## Rule

- **Rule:** The package name is updated by the workflow to allow the same files to be used to build both the pypi and test-pypi packages.
- **Applies to:**
  - `pyproject.toml`
  - `setup.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-16e3bc91f317787a1a3da0ba.md)
