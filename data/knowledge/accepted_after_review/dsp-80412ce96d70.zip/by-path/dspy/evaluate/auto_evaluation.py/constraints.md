# Constraints for `dspy/evaluate/auto_evaluation.py`

## Rule

- **Rule:** SemanticRecallPrecision must define recall and precision output fields whose descriptions fix their semantic meaning as fractions out of 1.0 of ground truth covered and system response covered respectively.
- **Applies to:**
  - `dspy/evaluate/auto_evaluation.py`
- **Condition:** When changing SemanticRecallPrecision output fields or their metric semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d42eed372b2ef21780261e9.md)

## Rule

- **Rule:**
  ```text
  AnswerGroundedness must define a fixed signature contract: question, retrieved_context, and system_response as inputs, with system_response_claims, discussion, and a float groundedness (fraction out of 1.0) as outputs.
  ```
- **Applies to:**
  - `dspy/evaluate/auto_evaluation.py`
- **Condition:** when modifying AnswerGroundedness or its signature field contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-787a40ab3a99b6f51aa5783e.md)

## Rule

- **Rule:**
  ```text
  CompleteAndGrounded must be a dspy Module subclass in dspy/evaluate/auto_evaluation.py, exposing the auto-evaluation subsystem as a reusable metric module rather than only functions.
  ```
- **Applies to:**
  - `dspy/evaluate/auto_evaluation.py`
- **Condition:**
  ```text
  When modifying CompleteAndGrounded or the auto-evaluation module surface in dspy/evaluate/auto_evaluation.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fd8abf814491c4cc81d2dd94.md)
