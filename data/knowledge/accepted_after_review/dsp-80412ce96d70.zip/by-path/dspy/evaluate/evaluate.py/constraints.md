# Constraints for `dspy/evaluate/evaluate.py`

## Rule

- **Rule:**
  ```text
  truncate_cell must truncate cell content to 25 words and append '...', establishing the evaluation display truncation convention.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:**
  ```text
  When modifying evaluation display truncation or the truncate_cell helper.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c22c18c57ce8a091b78304e.md)

## Rule

- **Rule:**
  ```text
  When modifying prediction_is_dictlike or its callers, preserve the duck-typing contract: any prediction with a callable items() attribute is treated as dict-like, so display logic must depend solely on the items() method rather than a concrete type.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** When changing how predictions are classified as dict-like or how display logic branches on prediction type.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1721040f6ed89c40d7cd22d2.md)

## Rule

- **Rule:**
  ```text
  merge_dicts must rename colliding keys by prefixing example_ for keys present in both dicts from d1 and pred_ for keys from d2, avoiding key collisions when merging example and prediction dicts.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:**
  ```text
  When modifying merge_dicts or the example/prediction key-collision handling in evaluation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-63700aa0e049ab35955d6b1c.md)

## Rule

- **Rule:** EvaluationResult must subclass dspy.Prediction and expose score as a float and results as a list of (example, prediction, score) tuples, defining the expected shape of evaluation outputs.
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** when modifying EvaluationResult or the shape of evaluation outputs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ba6e3099bf1383072f5e935c.md)

## Rule

- **Rule:** When modifying Evaluate, preserve the requirement that a dataset and metric function are provided and that parallel evaluation over the dataset is supported.
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** Changing Evaluate's constructor requirements or parallel evaluation behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f5b7060b2f585ba9d1d98304.md)
