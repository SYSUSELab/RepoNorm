# Constraints for `dspy/propose/utils.py`

## Rule

- **Rule:**
  ```text
  When modifying create_instruction_set_history_string, preserve the ordering contract: trial programs are loaded from program_path, deduplicated by instruction-set string, sorted by score descending, truncated to top_n, then reversed so the formatted history is ordered worst-to-best among the top programs.
  ```
- **Applies to:**
  - `dspy/propose/utils.py`
- **Condition:** When changing how instruction-set history is loaded, deduplicated, ranked, truncated, or formatted.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e2716562b9afbe288d98d40.md)

## Rule

- **Rule:**
  ```text
  propose/utils.py must import IPython's extract_symbols inside a try/except ImportError and set extract_symbols = None when unavailable, so notebook code extraction degrades gracefully without IPython installed.
  ```
- **Applies to:**
  - `dspy/propose/utils.py`
- **Condition:** Modifying notebook code extraction or IPython dependency handling in propose/utils.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a04483aed3527203cfd3ea06.md)
