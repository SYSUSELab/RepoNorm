# Constraints for `dspy/datasets/dataset.py`

## Rule

- **Rule:**
  ```text
  When modifying Dataset.prepare_by_seed, preserve the default train_seeds [1,2,3,4,5], the division of dev_size across seeds when divide_eval_per_seed is true, and the assertion that each generated train/eval split matches the requested sizes.
  ```
- **Applies to:**
  - `dspy/datasets/dataset.py`
- **Condition:**
  ```text
  Changing seed-based dataset splitting or evaluation-size division in Dataset.prepare_by_seed.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-62d843192d9f6b7b37275481.md)

## Rule

- **Rule:**
  ```text
  Dataset.__init__ must default train_seed and eval_seed to 0, use eval_seed for both dev_seed and test_seed, default input_keys to [], and set do_shuffle=True.
  ```
- **Applies to:**
  - `dspy/datasets/dataset.py`
- **Condition:**
  ```text
  when modifying Dataset.__init__ defaults or seed wiring
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6bbaf70161856ced0264e86d.md)

## Rule

- **Rule:**
  ```text
  Dataset._shuffle_and_sample must shuffle with a seeded RNG regardless of requested size, truncate to size, and stamp each returned Example with a fresh dspy_uuid and dspy_split; dedup/group_uuid semantics remain unimplemented.
  ```
- **Applies to:**
  - `dspy/datasets/dataset.py`
- **Condition:**
  ```text
  when modifying Dataset._shuffle_and_sample or the sampling path it feeds
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a199f6077349fb62ff9b2617.md)
