# Constraints for `dspy/datasets/hotpotqa.py`

## Rule

- **Rule:** HotPotQA must subclass Dataset in dspy/datasets/hotpotqa.py, exposing HotPotQA as a Dataset-family loader.
- **Applies to:**
  - `dspy/datasets/hotpotqa.py`
- **Condition:** When modifying HotPotQA or its base class in dspy/datasets/hotpotqa.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dcdc5e293f51401edc928791.md)
