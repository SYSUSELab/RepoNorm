# Constraints for `dspy/datasets/alfworld/alfworld.py`

## Rule

- **Rule:**
  ```text
  When modifying EnvPool.session, preserve returning an _EnvSession context manager that acquires and releases a single worker, defining the worker-acquisition protocol for the AlfWorld dataset environment.
  ```
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** changing EnvPool.session worker acquisition or release protocol
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-405ff245bc6841da88c0ccaa.md)

## Rule

- **Rule:**
  ```text
  EnvPool must be documented as a pool of processes each with a unique env_worker, acquired via a context manager (with pool.session() as sess) and used through sess.init(idx) and sess.step(action) returning (obs, rew, done, info).
  ```
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** when modifying EnvPool or its session/init/step protocol
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-49f627e5af7e3f034636d464.md)

## Rule

- **Rule:** When modifying the alfworld dataset module, preserve the documented environment step tuple shape (obs, rew, done, info) as the expected interaction record for this dataset.
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** Changing alfworld dataset interaction records or step handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-9482593c2e37c765b2e30b0d.md)

## Rule

- **Rule:** The alfworld init helper must communicate with a worker process by putting an ("init", idx) message on inq and blocking on outq.get(), so callers must have a corresponding worker consuming the queue.
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** When changing the alfworld environment session init helper or its worker-process IPC contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-ed63f327024d1b7c2cbdaae7.md)

## Rule

- **Rule:**
  ```text
  _EnvSession must act as a context manager that acquires a worker from a pool, exposes .init(idx) and .step(action), and releases the worker on exit; contributors changing ALFWorld environment sessions must preserve this lifecycle.
  ```
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:**
  ```text
  When modifying _EnvSession or ALFWorld environment session lifecycle.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-f6bcbfc8049db2513cb56761.md)
