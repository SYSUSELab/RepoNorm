# Constraints for `dspy/datasets/gsm8k.py`

## Rule

- **Rule:**
  ```text
  GSM8K.__init__ must load the "gsm8k"/"main" dataset, assert each answer's second-to-last token is "####", split gold reasoning from the numeric answer (stripping commas), shuffle train and test with random.Random(0), and fix splits to 200 train, 300 dev, and all test examples.
  ```
- **Applies to:**
  - `dspy/datasets/gsm8k.py`
- **Condition:**
  ```text
  When modifying GSM8K.__init__ or GSM8K dataset loading in dspy/datasets/gsm8k.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-418451cd93734498728a8382.md)

## Rule

- **Rule:**
  ```text
  When modifying gsm8k_metric, preserve comparing integer-parsed gold and predicted answers so answer equivalence is numeric rather than string-based.
  ```
- **Applies to:**
  - `dspy/datasets/gsm8k.py`
- **Condition:**
  ```text
  changing gsm8k_metric answer comparison logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f5d6ff9185919fe2501c52ee.md)
