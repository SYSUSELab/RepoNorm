# Constraints for `dspy/datasets/math.py`

## Rule

- **Rule:** dspy/datasets/math.py must define the MATH dataset class as the entry point for the MATH dataset loader.
- **Applies to:**
  - `dspy/datasets/math.py`
- **Condition:** When changing the MATH dataset loader entry point in dspy/datasets/math.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d34c15a79a0058efa1249bb6.md)

## Rule

- **Rule:**
  ```text
  dspy/datasets/math.py must document that MATH's official math_equivalence.is_equiv does not have perfect recall, citing reference values like 'left[\frac{1}{2}, \frac{4}{3}\right]' as a known failure case; contributors relying on math equivalence must account for this limitation.
  ```
- **Applies to:**
  - `dspy/datasets/math.py`
- **Condition:** When modifying or relying on MATH dataset equivalence checking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fa0b86c6fc753525e7f25c3d.md)
