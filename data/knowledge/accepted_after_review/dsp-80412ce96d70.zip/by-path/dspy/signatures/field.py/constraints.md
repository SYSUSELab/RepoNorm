# Constraints for `dspy/signatures/field.py`

## Rule

- **Rule:** When modifying the signatures field module, preserve the legacy compatibility boundary: OldInputField subclasses OldField, keeping the legacy field class alongside the current field API for backward compatibility.
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:** When changing or removing legacy field classes in the signatures field module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1eba6d69657df82489fcbf35.md)

## Rule

- **Rule:**
  ```text
  When modifying OldField.__init__, preserve accepting keyword-only prefix, desc, input, and format parameters, with prefix allowed to be None initially and set later.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:**
  ```text
  changing OldField.__init__ parameter signature or prefix handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2daa4e981d3dbcaf918f41c8.md)

## Rule

- **Rule:** When modifying field.py, preserve OldOutputField(OldField) as the legacy output-field class retained alongside the new field representation.
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:** changing or removing the legacy OldOutputField class in field.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bed8ff2320aa0c081d38086e.md)

## Rule

- **Rule:** OldField must infer prefix and desc when omitted, establishing a compatibility/ergonomics contract for signature field construction.
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:** when modifying OldField or the signature field construction ergonomics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dc5884ace8566fcd5efbccb1.md)
