# Constraints for `dspy/signatures/signature.py`

## Rule

- **Rule:**
  ```text
  _parse_type_node must recursively convert AST type annotations into Python types, raising ValueError for unhandled AST nodes with guidance to use class-based Signatures, and must special-case PEP 604 X | None into Optional and typing.Union/typing.Optional subscripts.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When extending _parse_type_node to handle additional AST node kinds or new typing constructs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1fd91fae1e6fc93bdd999a62.md)

## Rule

- **Rule:** SignatureMeta must be defined as a subclass of type(BaseModel), making signature classes use a Pydantic-model metaclass.
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:** When modifying SignatureMeta or the metaclass of signature classes in dspy/signatures/signature.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-202fadb9e4c60b3c94d1a07d.md)

## Rule

- **Rule:**
  ```text
  SignatureMeta.__new__ must default unannotated FieldInfo attributes to str, preserve field order in __annotations__, inherit instructions from a base Signature when __doc__ is None, fall back to _default_instructions, and inject prefix/desc into each field's json_schema_extra.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  Modifying SignatureMeta.__new__ field handling or signature normalization
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-208c3964a4ebd439e5f3c9ef.md)

## Rule

- **Rule:**
  ```text
  When modifying ensure_signature, preserve the behavior that passing instructions together with a non-string Signature raises ValueError, while a string signature is converted via Signature(signature, instructions).
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  Changing signature normalization or instructions handling in ensure_signature.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4fc9fcadf7a346700a087734.md)

## Rule

- **Rule:**
  ```text
  Signature.equals must compare instructions and the union of field names, requiring each field to exist on both signatures with identical json_schema_extra, and must return False for non-BaseModel types.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:** When modifying Signature.equals or adding signature comparison logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6e504b7614dd0b5dbed12195.md)

## Rule

- **Rule:**
  ```text
  resolve_name must resolve type names by checking provided names, then built-in types, then attempting importlib.import_module(type_name) for module-based annotations like dspy.Image, raising ValueError(f"Unknown name: {type_name}") when unresolved.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When modifying resolve_name or type-name resolution in dspy/signatures/signature.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7270991c76c1ab7c6bdce3ea.md)

## Rule

- **Rule:**
  ```text
  Signature.input_fields must return fields filtered by type input via _get_fields_with_type.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  when modifying Signature.input_fields or the field-type filtering helper
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-76162407b16553b1c6de6587.md)

## Rule

- **Rule:**
  ```text
  Signature.insert must place a field into input or output fields according to the field's __dspy_field_type, support negative indices, default a missing type to str, raise ValueError for out-of-range indices, and return a new Signature that preserves instructions.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:** when modifying Signature.insert or the field-insertion behavior of Signature
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c1195364185d305f5ffb3485.md)

## Rule

- **Rule:**
  ```text
  Signature.with_instructions must return a new Signature subclass derived from the existing fields with replaced instructions, preserving the immutable-style derivation contract rather than mutating the receiver.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When modifying or extending Signature.with_instructions or adding sibling derivation helpers on Signature.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f18ac16b039aa7c8b70d9afe.md)

## Rule

- **Rule:**
  ```text
  make_signature must validate that field names are strings, field values are tuples or FieldInfo, and field types are valid type constructs, silently defaulting None types to str to avoid breaking program-of-thought and teleprompters.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When changing make_signature validation or the handling of field names, values, or types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f6d3c0211e0191356edcebb8.md)
