# Constraints for `dspy/predict/predict.py`

## Rule

- **Rule:**
  ```text
  serialize_object must recursively convert Pydantic BaseModel instances via model_dump, recurse into lists, tuples, and dicts, and return other values unchanged, defining the JSON-compatible serialization contract for prediction objects.
  ```
- **Applies to:**
  - `dspy/predict/predict.py`
- **Condition:**
  ```text
  When modifying serialize_object or the serialization of prediction objects in dspy/predict/predict.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-16b2b5ad29a44c24a2699c35.md)

## Rule

- **Rule:**
  ```text
  A TODO/FIXME in predict.py flags unresolved precedence among context, __init__, and forward for parameters such as n and temperature, so contributors must not assume a settled precedence order.
  ```
- **Applies to:**
  - `dspy/predict/predict.py`
- **Condition:**
  ```text
  When changing how Predict resolves parameters such as n and temperature across context, __init__, and forward.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af3b3fdf97c4eaf077bff057.md)
