# Constraints for `dspy/predict/avatar/avatar.py`

## Rule

- **Rule:**
  ```text
  Avatar.forward must drive an actor that emits action_{idx} objects with tool_name/tool_input_query, terminate when tool_name == "Finish", append ActionOutput records, update the signature each iteration, honor an optional max_iters budget, and finally restore self.actor from actor_clone before returning a Prediction with actions.
  ```
- **Applies to:**
  - `dspy/predict/avatar/avatar.py`
- **Condition:** When modifying Avatar.forward or the avatar action loop in dspy/predict/avatar/avatar.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-c1291effc0e077e34c39213b.md)
