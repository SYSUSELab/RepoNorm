# Constraints for `dspy/predict/best_of_n.py`

## Rule

- **Rule:**
  ```text
  BestOfN must remain a Module subclass whose fail_count defaults to N when not provided; contributors changing BestOfN construction must preserve this default.
  ```
- **Applies to:**
  - `dspy/predict/best_of_n.py`
- **Condition:**
  ```text
  When modifying BestOfN class declaration or fail_count default.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-30c4fdf1ff90221311a6d29d.md)
