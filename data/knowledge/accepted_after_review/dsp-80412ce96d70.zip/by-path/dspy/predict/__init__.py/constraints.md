# Constraints for `dspy/predict/__init__.py`

## Rule

- **Rule:**
  ```text
  dspy.predict.__init__ must export the fixed set of names in __all__ including majority, BestOfN, ChainOfThought, CodeAct, KNN, MultiChainComparison, Predict, ProgramOfThought, ReAct, Refine, Tool, and Parallel, defining the public predict API surface.
  ```
- **Applies to:**
  - `dspy/predict/__init__.py`
- **Condition:**
  ```text
  when modifying dspy.predict.__init__ or the public predict API surface
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2357011e76bd132a0bde91cd.md)
