# Constraints for `dspy/predict/code_act.py`

## Rule

- **Rule:**
  ```text
  CodeAct._build_instructions must construct instructions from the signature's input/output field names, enumerate tools, and instruct the model to print outputs and mark finished=True when outputs are extractable.
  ```
- **Applies to:**
  - `dspy/predict/code_act.py`
- **Condition:**
  ```text
  when modifying CodeAct._build_instructions or the CodeAct instruction protocol
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2a409efa37492c4202407667.md)

## Rule

- **Rule:**
  ```text
  CodeAct must reject non-function tools at construction time with ValueError, and its signature must append trajectory, generated_code, and finished fields; contributors adding tool types or signature fields must preserve this function-only contract and the appended field set.
  ```
- **Applies to:**
  - `dspy/predict/code_act.py`
- **Condition:** When modifying CodeAct tool acceptance or its generated signature fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2bd1cf6178afe6ec8bbccb03.md)
