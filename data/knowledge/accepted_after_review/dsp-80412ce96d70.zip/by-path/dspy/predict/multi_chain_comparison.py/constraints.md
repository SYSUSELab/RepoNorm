# Constraints for `dspy/predict/multi_chain_comparison.py`

## Rule

- **Rule:**
  ```text
  MultiChainComparison.__init__ must append M reasoning_attempt input fields and prepend a rationale output field to the signature, capturing the last original output field as last_key; signature field ordering is part of the module contract.
  ```
- **Applies to:**
  - `dspy/predict/multi_chain_comparison.py`
- **Condition:** When modifying MultiChainComparison signature construction or field ordering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-043cd3bda95dee229c07aa80.md)

## Rule

- **Rule:** When modifying MultiChainComparison, preserve its composability as a DSPy module: it subclasses Module in dspy/predict, so it participates in the module composition contract.
- **Applies to:**
  - `dspy/predict/multi_chain_comparison.py`
- **Condition:** When changing MultiChainComparison's base class or module-composition behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e6aea3255184ed8c89a8943b.md)
