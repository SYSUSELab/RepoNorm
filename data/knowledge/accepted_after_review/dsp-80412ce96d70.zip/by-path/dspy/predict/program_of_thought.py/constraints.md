# Constraints for `dspy/predict/program_of_thought.py`

## Rule

- **Rule:** When modifying ProgramOfThought, preserve the module-level requirement that deno is installed as an external runtime prerequisite, as documented in the module docstring.
- **Applies to:**
  - `dspy/predict/program_of_thought.py`
- **Condition:** Changing ProgramOfThought's runtime dependencies or documentation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-90bc0a8eb45eaa9ff349dee4.md)
