# Constraints for `dspy/adapters/json_adapter.py`

## Rule

- **Rule:**
  ```text
  When modifying _has_open_ended_mapping, preserve returning True when any output field annotation has get_origin(...) is dict, because Structured Outputs require explicit properties and open-ended mappings like dict[str, Any] are incompatible.
  ```
- **Applies to:**
  - `dspy/adapters/json_adapter.py`
- **Condition:**
  ```text
  changing _has_open_ended_mapping detection of open-ended dict annotations
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-386e5f4ee1a1184a147329a7.md)

## Rule

- **Rule:**
  ```text
  JSONAdapter must depend on repair-based parsing via json_repair and litellm, reusing ChatAdapter utilities and AdapterParseError; contributors changing JSONAdapter parsing must preserve these dependencies and error handling.
  ```
- **Applies to:**
  - `dspy/adapters/json_adapter.py`
- **Condition:** When modifying JSONAdapter parsing or its dependency usage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b09f10d92f56765b3064c0fc.md)
