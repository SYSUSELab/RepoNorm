# Constraints for `dspy/adapters/utils.py`

## Rule

- **Rule:**
  ```text
  get_field_description_string must render each field as an indexed entry with annotation name and description, treat a field desc equal to the placeholder "${name}" as empty, and append custom type descriptions plus optional constraints; contributors changing field description formatting must preserve these behaviors.
  ```
- **Applies to:**
  - `dspy/adapters/utils.py`
- **Condition:**
  ```text
  When modifying get_field_description_string or field description rendering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b7c4fc1919e2a2559e45f63b.md)
