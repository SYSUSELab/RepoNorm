# Constraints for `dspy/adapters/types/tool.py`

## Rule

- **Rule:** The tool adapter must use a fixed JSON-schema-to-Python type mapping for string, integer, number, boolean, array, and object, constraining how tool argument types are inferred from schemas.
- **Applies to:**
  - `dspy/adapters/types/tool.py`
- **Condition:** when modifying the tool adapter's JSON-schema-to-Python type inference
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-a2c332873cd30a32aeca764d.md)
