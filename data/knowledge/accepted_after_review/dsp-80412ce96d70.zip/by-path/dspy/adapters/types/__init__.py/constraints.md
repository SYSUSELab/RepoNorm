# Constraints for `dspy/adapters/types/__init__.py`

## Rule

- **Rule:** dspy.adapters.types must export History, Image, Audio, Type, Tool, ToolCalls, and Code as the public adapter type surface.
- **Applies to:**
  - `dspy/adapters/types/__init__.py`
- **Condition:**
  ```text
  When modifying the public exports of dspy/adapters/types/__init__.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-c68ac95cac43865266bcdc14.md)
