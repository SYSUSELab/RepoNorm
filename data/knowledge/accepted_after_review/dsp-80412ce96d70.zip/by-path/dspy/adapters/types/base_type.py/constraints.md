# Constraints for `dspy/adapters/types/base_type.py`

## Rule

- **Rule:** Type is the base class for DSPy custom types; subclasses must implement format returning a list of content-part dicts matching the OpenAI content field.
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:** when adding or modifying a DSPy custom type subclass or the Type base class format contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-3c2c88ef1626eef18d01be12.md)

## Rule

- **Rule:**
  ```text
  The base adapter type module must define sentinel string constants CUSTOM_TYPE_START_IDENTIFIER and CUSTOM_TYPE_END_IDENTIFIER used to delimit custom types in serialized adapter output.
  ```
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:** Modifying adapter custom-type serialization delimiters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-4e7d8934b54d92559b4a196b.md)

## Rule

- **Rule:**
  ```text
  extract_custom_type_from_annotation must recursively extract nested custom types and wrap the issubclass check in try/except TypeError to accommodate Python 3.10 vs 3.11 differences in isinstance for nested generics; contributors changing type extraction must preserve this compatibility guard.
  ```
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:**
  ```text
  When modifying extract_custom_type_from_annotation or nested custom type extraction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-840e2b17338d30608cfa3e25.md)

## Rule

- **Rule:**
  ```text
  When modifying BaseType.serialize_model, preserve the wire-format contract: list-formatted custom type values are wrapped with CUSTOM_TYPE_START_IDENTIFIER and CUSTOM_TYPE_END_IDENTIFIER, while non-list formatted values are returned as-is.
  ```
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:**
  ```text
  Changing custom type serialization in BaseType.serialize_model.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-d6f0e2dad5dfe5953afd2574.md)
