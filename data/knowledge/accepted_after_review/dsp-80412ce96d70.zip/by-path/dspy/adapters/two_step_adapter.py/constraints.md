# Constraints for `dspy/adapters/two_step_adapter.py`

## Rule

- **Rule:**
  ```text
  TwoStepAdapter.parse must build an extractor signature of the form 'text -> {original output fields}', invoke ChatAdapter with the extraction_model and the raw completion as the 'text' input, and wrap any failure in a ValueError that includes the original completion.
  ```
- **Applies to:**
  - `dspy/adapters/two_step_adapter.py`
- **Condition:** When modifying TwoStepAdapter.parse or the extraction step of the two-step adapter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-548f35b9831e23ac7222a768.md)

## Rule

- **Rule:**
  ```text
  TwoStepAdapter.__init__ must require extraction_model to be an instance of LM and raise ValueError otherwise, so callers must pass a real LM object rather than a string or config.
  ```
- **Applies to:**
  - `dspy/adapters/two_step_adapter.py`
- **Condition:**
  ```text
  When modifying TwoStepAdapter.__init__ or its extraction_model parameter validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9f4df4e6a28fe0689904f5d0.md)
