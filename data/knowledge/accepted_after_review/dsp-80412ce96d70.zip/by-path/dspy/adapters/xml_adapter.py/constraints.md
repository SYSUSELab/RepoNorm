# Constraints for `dspy/adapters/xml_adapter.py`

## Rule

- **Rule:** XMLAdapter.parse must accept only the first occurrence of each output field name and raise AdapterParseError when the parsed field set does not exactly match the signature's output fields, enforcing strict output completeness.
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:** when modifying XMLAdapter.parse or its output-field completeness checks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-484e65e2af4b60655e70cf2d.md)

## Rule

- **Rule:**
  ```text
  XMLAdapter field extraction must use a DOTALL non-greedy regex matching <name>content</name> so multi-line field content between matching tags is captured; contributors changing field parsing must preserve multi-line support.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:** When modifying XMLAdapter field pattern compilation or field extraction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a5085aad2d9a1824afab051f.md)

## Rule

- **Rule:**
  ```text
  When modifying XMLAdapter.format_field_with_value, preserve wrapping each field value in XML tags of the form <field.name>\nformatted\n</field.name> and joining multiple fields with double newlines.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:**
  ```text
  changing XMLAdapter.format_field_with_value serialization format
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f6744e15db50561f944e6f26.md)

## Rule

- **Rule:**
  ```text
  XMLAdapter._parse_field_value must wrap parse_value failures in AdapterParseError carrying adapter name, signature, LM response, and the failing field/value, so XML adapter parse errors surface structured diagnostic context.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:**
  ```text
  when modifying XMLAdapter._parse_field_value or the structured parse-error context
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fc139a691af5f15db4a2d3e4.md)
