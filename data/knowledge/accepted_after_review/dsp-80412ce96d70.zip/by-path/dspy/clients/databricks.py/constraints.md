# Constraints for `dspy/clients/databricks.py`

## Rule

- **Rule:**
  ```text
  _validate_chat_data must enforce that each finetuning data dict has a 'messages' key whose value is a list of dicts, and each message must contain both 'role' and 'content' keys, raising ValueError with specific messages otherwise; this is the required shape for task=CHAT_COMPLETION.
  ```
- **Applies to:**
  - `dspy/clients/databricks.py`
- **Condition:**
  ```text
  when modifying _validate_chat_data or the CHAT_COMPLETION finetuning data shape checks
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-74c969489310500fd931bc2c.md)

## Rule

- **Rule:**
  ```text
  _save_data_to_local_file must write training data to a UUID-named JSONL file in the finetune directory, validating each item against the selected TrainDataFormat (CHAT or COMPLETION) before serializing with ujson.
  ```
- **Applies to:**
  - `dspy/clients/databricks.py`
- **Condition:** When modifying finetuning data persistence or the TrainDataFormat validation path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9cfba66b1a71654690b2fc6c.md)
