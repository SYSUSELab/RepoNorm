# Constraints for `dspy/clients/base_lm.py`

## Rule

- **Rule:**
  ```text
  base_lm.py must define MAX_HISTORY_SIZE = 10_000 and a module-level GLOBAL_HISTORY list as the shared history buffer and size cap used by LM history inspection.
  ```
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:**
  ```text
  Modifying LM history buffer or size cap in base_lm.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-50a30e9823c4afa6d11a3dbd.md)
