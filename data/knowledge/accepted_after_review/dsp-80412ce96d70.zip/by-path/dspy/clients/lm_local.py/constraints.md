# Constraints for `dspy/clients/lm_local.py`

## Rule

- **Rule:**
  ```text
  encode_sft_example must require a non-empty messages field, tokenize with apply_chat_template, mask non-assistant tokens with -100, and use add_generation_prompt=True only for non-assistant messages immediately followed by an assistant message; contributors changing SFT example encoding must preserve this masking and prompt-prefix behavior.
  ```
- **Applies to:**
  - `dspy/clients/lm_local.py`
- **Condition:**
  ```text
  When modifying encode_sft_example or SFT tokenization/masking logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-66482c9f782c6338a2ff5a87.md)
