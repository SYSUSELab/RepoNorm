# Constraints for `dspy/clients/lm.py`

## Rule

- **Rule:**
  ```text
  When modifying litellm_text_completion, preserve splitting the model string on the first "/" with provider defaulting to "openai" when no slash is present, resolving api_key/api_base from the request or {provider}_API_KEY/{provider}_API_BASE environment variables, joining message contents with "BEGIN RESPONSE:", and always calling litellm.text_completion with model prefixed "text-completion-openai/" and exponential_backoff_retry.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:**
  ```text
  changing litellm_text_completion provider parsing, credential resolution, message joining, or litellm call construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d5442461e9924a6edf142d5.md)

## Rule

- **Rule:**
  ```text
  LM._get_cached_completion_fn must wrap the completion function with request_cache ignoring api_key, api_base, and base_url in the cache key, and must set litellm_cache_args to no-cache/no-store when caching is disabled or litellm.cache is None.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** When modifying LM caching behavior or the cache-key exclusion set.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5d1649ce6b76683818ec4022.md)

## Rule

- **Rule:**
  ```text
  LM.kill must delegate to the provider's kill method, so custom providers must implement a kill(self, lm, launch_kwargs) hook to support LM teardown.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** when modifying LM.kill or adding a custom provider that must support LM teardown
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-67f3e3a9d92fda945ce8aadd.md)

## Rule

- **Rule:**
  ```text
  When modifying LM.aforward, preserve warning on any choice finish_reason equal to "length" and record usage via settings.usage_tracker only when the result is not a cache hit and exposes usage.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** changing LM.aforward truncation warning or usage tracking behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-704a2455dcaadd606b3f5ee1.md)

## Rule

- **Rule:** LM must be declared as a BaseLM subclass supporting chat or text completion requests for DSPy modules.
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** When modifying the LM class declaration or its base class in dspy/clients/lm.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ba305528f9482aece4c604a5.md)
