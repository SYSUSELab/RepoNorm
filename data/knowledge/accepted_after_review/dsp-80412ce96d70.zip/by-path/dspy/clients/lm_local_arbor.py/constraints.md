# Constraints for `dspy/clients/lm_local_arbor.py`

## Rule

- **Rule:**
  ```text
  When modifying ArborProvider.initialize, preserve reading each GRPO training hyperparameter from train_kwargs with a fallback to DEFAULT_TRAIN_KWARGS so callers may override any subset of training parameters.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:** changing ArborProvider.initialize training hyperparameter resolution
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-378aafcaf841fa7d6286a4f0.md)

## Rule

- **Rule:**
  ```text
  ArborProvider.get_trained_model must raise unless job.status() equals TrainingStatus.succeeded, and while retrieving the fine-tuned model it must temporarily override openai.base_url to the Arbor base API.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:**
  ```text
  when modifying ArborProvider.get_trained_model or its job-status and base_url handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-803c9b973cef663c4022801b.md)

## Rule

- **Rule:**
  ```text
  ArborReinforceJob.save_checkpoint must POST to {api_base}fine_tuning/grpo/checkpoint with a JSON body containing checkpoint_name, assert HTTP 200, then record the returned last_checkpoint and its model_path with the given score in self.checkpoints; contributors changing checkpoint saving must preserve this protocol.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:**
  ```text
  When modifying ArborReinforceJob.save_checkpoint or checkpoint recording.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-90ed0cc3651875f4baf744d9.md)

## Rule

- **Rule:**
  ```text
  ArborProvider.validate_data_format must accept only CHAT, COMPLETION, and GRPO_CHAT, raising ValueError for any other TrainDataFormat.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:**
  ```text
  When modifying ArborProvider.validate_data_format or accepted data formats in dspy/clients/lm_local_arbor.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aaf2188edd64c52b40ebc06e.md)

## Rule

- **Rule:**
  ```text
  ArborReinforceJob.__init__ must raise ValueError when 'num_generations' is absent from train_kwargs, documenting a required teleprompter-set training parameter.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:**
  ```text
  When changing ArborReinforceJob construction or the required train_kwargs contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bd66a99c41f6456b84da8fe8.md)

## Rule

- **Rule:**
  ```text
  ArborReinforceJob.DEFAULT_TRAIN_KWARGS must retain the repository-specific training defaults (temperature 0.9, beta 0.04, num_iterations 1, per_device_train_batch_size 8, learning_rate 1e-6, gradient_checkpointing True, lr_scheduler_type constant_with_warmup, scale_rewards True, max_grad_norm 1.0, report_to none, log_completions True, logging_steps 100, lora False) unless intentionally changing training behavior.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:**
  ```text
  When modifying ArborReinforceJob training defaults or overriding DEFAULT_TRAIN_KWARGS.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cde5314260b9e2cf27a2a7ac.md)
