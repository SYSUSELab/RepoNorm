# Constraints for `dspy/clients/openai.py`

## Rule

- **Rule:**
  ```text
  OpenAIProvider.get_training_status must map every provider training status to a DSPy training status, returning not_started when job_id is None; adding a new provider status requires extending this mapping rather than falling through.
  ```
- **Applies to:**
  - `dspy/clients/openai.py`
- **Condition:**
  ```text
  When adding or changing a provider training status handled by OpenAIProvider.get_training_status.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a4b5828a1d231cd69812f5a.md)

## Rule

- **Rule:**
  ```text
  OpenAIProvider.is_provider_model must strip the provider prefix, return True for models in _OPENAI_MODELS, and also return True for fine-tuned models matching ft:([^:]+): when the captured base model is in _OPENAI_MODELS; extending model detection must preserve this pattern.
  ```
- **Applies to:**
  - `dspy/clients/openai.py`
- **Condition:** When extending or modifying OpenAIProvider model detection for new model names or fine-tuned model identifiers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2884d21bb0dd053a11d0230a.md)

## Rule

- **Rule:**
  ```text
  When modifying OpenAIProvider.wait_for_job, preserve polling with default poll_frequency of 20 seconds, reporting the estimated finish time once, tracking the last seen event id to print only new events, and terminating when is_terminal_training_status(job.status()) is true.
  ```
- **Applies to:**
  - `dspy/clients/openai.py`
- **Condition:**
  ```text
  changing OpenAIProvider.wait_for_job polling, event reporting, or termination logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f292e44800d521458bac310c.md)
