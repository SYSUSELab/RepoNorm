# Constraints for `dspy/dsp/colbertv2.py`

## Rule

- **Rule:**
  ```text
  When modifying the ColBERT v2 request path, preserve the request_cache decoration on colbertv2_get_request_v2_wrapped so v2 ColBERT requests are cached at the wrapper boundary.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:** When changing the ColBERT v2 request wrapper or its caching behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-29fcd67473bd5e0d9dc790f7.md)

## Rule

- **Rule:**
  ```text
  ColBERTv2.__init__ must build self.url as '{url}:{port}' when a port is provided and otherwise use url unchanged, and store post_requests; this defines the endpoint URL construction contract.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:**
  ```text
  when modifying ColBERTv2.__init__ or its endpoint URL construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae12afed7f632acf87458f6d.md)
