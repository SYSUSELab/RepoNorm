# Constraints for `dspy/dsp/utils/settings.py`

## Rule

- **Rule:**
  ```text
  DEFAULT_CONFIG must remain the baseline settings surface and be deep-copied into main_thread_config, with thread-local overrides held in a ContextVar, so that per-thread settings isolation is preserved.
  ```
- **Applies to:**
  - `dspy/dsp/utils/settings.py`
- **Condition:**
  ```text
  When adding, removing, or renaming a setting in DEFAULT_CONFIG or changing how thread-local overrides are stored.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-05fb7395aff1b6cb9ff9fd41.md)
