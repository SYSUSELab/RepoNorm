# Constraints for `dspy/dsp/utils/utils.py`

## Rule

- **Rule:**
  ```text
  dotdict_lax must map attribute access to dict.get, attribute assignment to dict.__setitem__, and attribute deletion to dict.__delitem__, so missing keys return None instead of raising AttributeError.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:**
  ```text
  When modifying dotdict_lax or its attribute access semantics in dspy/dsp/utils/utils.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-234a2d0efec7d086c0918ad2.md)

## Rule

- **Rule:**
  ```text
  When modifying dotdict.__getattr__, preserve the mapping protocol: non-dunder attribute access delegates to item lookup, and a missing key is converted into AttributeError naming the type, so attribute and key access remain interchangeable except for dunder names.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:** When changing dotdict attribute access, item lookup, or missing-key error behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-4256984ea16c1ed3085e833f.md)

## Rule

- **Rule:**
  ```text
  When modifying groupby_first_item, preserve its grouping semantics: items are grouped by their first element, a single remaining element collapses to a scalar, and multiple remaining elements stay as a list.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:**
  ```text
  When changing how groupby_first_item groups items or collapses grouped values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-653d904a7e0d104e448f8f17.md)

## Rule

- **Rule:**
  ```text
  When modifying grouper, preserve collecting data into fixed-length chunks using itertools.zip_longest with a fill value, the standard itertools recipe for chunking iterables.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:** changing grouper chunking implementation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-79d5f74e2a0d0b3c7c928abb.md)

## Rule

- **Rule:**
  ```text
  flatten must concatenate child lists via result += child_list, meaning it only works for list-of-lists and will extend with any iterable rather than recursively flattening nested structures.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:** When modifying flatten or relying on it for nested-structure flattening.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-ece1cf49325a297e47f8220e.md)

## Rule

- **Rule:** lengths2offsets must yield (offset, offset+length) pairs cumulatively, providing the offset mapping used by downstream span utilities.
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:** when modifying lengths2offsets or its cumulative offset computation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-f7068ebd11e85194287e17f7.md)
