# Constraints for `dspy/utils/asyncify.py`

## Rule

- **Rule:** When modifying asyncify, preserve the documented behavior that the current thread's configuration context is inherited for each awaited call in a worker thread.
- **Applies to:**
  - `dspy/utils/asyncify.py`
- **Condition:** Changing asyncify's thread or context handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-36e8f83d366b182189ca0657.md)

## Rule

- **Rule:**
  ```text
  asyncify must use a lazily-initialized module-level shared concurrency limiter (_limiter initialized to None, backed by anyio.CapacityLimiter) that governs async execution behavior.
  ```
- **Applies to:**
  - `dspy/utils/asyncify.py`
- **Condition:** When changing asyncify concurrency limiting or the shared limiter initialization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e8b2c29c769b99e3588b1496.md)
