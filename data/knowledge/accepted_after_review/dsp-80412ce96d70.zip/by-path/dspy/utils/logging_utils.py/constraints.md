# Constraints for `dspy/utils/logging_utils.py`

## Rule

- **Rule:**
  ```text
  When modifying dspy.utils.logging_utils, preserve the module-level LOGGING_LINE_FORMAT and LOGGING_DATETIME_FORMAT constants and the shared DSPY_LOGGING_STREAM instance used across DSPy logging.
  ```
- **Applies to:**
  - `dspy/utils/logging_utils.py`
- **Condition:**
  ```text
  Changing shared logging format constants or the logging stream in logging_utils.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2a68eec2eda87ba3476f4abd.md)
