# Constraints for `dspy/utils/parallelizer.py`

## Rule

- **Rule:**
  ```text
  When modifying the parallel executor, preserve the repository-specific step of clearing tqdm's global _instances before wrapping the function and running parallel execution, so stale progress bars are not carried across runs.
  ```
- **Applies to:**
  - `dspy/utils/parallelizer.py`
- **Condition:** When changing ParallelExecutor.execute or the parallel execution setup that precedes running the wrapped function.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0e47d9045416a0bff20b71fc.md)

## Rule

- **Rule:**
  ```text
  When modifying ParallelExecutor._wrap_function or its safe_func, preserve the cancellation and error-accounting behavior: return None immediately when cancel_jobs is set, and on exception increment error_count under error_lock, set cancel_jobs once error_count reaches max_errors, and log with or without traceback depending on provide_traceback.
  ```
- **Applies to:**
  - `dspy/utils/parallelizer.py`
- **Condition:** Changing the parallel execution wrapper or its error handling in ParallelExecutor.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9651c49a43e3e3bec08ff02f.md)

## Rule

- **Rule:** When modifying the parallelizer, preserve its concurrency mechanism: it relies on signal-based and thread-based concurrency primitives (signal, threading, concurrent.futures).
- **Applies to:**
  - `dspy/utils/parallelizer.py`
- **Condition:** When changing the concurrency mechanism used by the parallelizer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f061e118436eb9120e7059f8.md)
