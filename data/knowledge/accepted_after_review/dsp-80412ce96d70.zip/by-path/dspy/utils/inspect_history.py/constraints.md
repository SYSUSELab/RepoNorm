# Constraints for `dspy/utils/inspect_history.py`

## Rule

- **Rule:**
  ```text
  pretty_print_history must render the last n history entries, fall back to a user message built from item['prompt'] when messages are absent, redact base64 image and audio payloads to length-annotated placeholders, and print tool calls and additional completions.
  ```
- **Applies to:**
  - `dspy/utils/inspect_history.py`
- **Condition:**
  ```text
  When modifying history rendering or the redaction/fallback behavior of pretty_print_history.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a340a49f78aaf5388687deb3.md)
