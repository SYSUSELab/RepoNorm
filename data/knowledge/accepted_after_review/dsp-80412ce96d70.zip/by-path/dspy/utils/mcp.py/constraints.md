# Constraints for `dspy/utils/mcp.py`

## Rule

- **Rule:** MCP tool results must be converted by collecting TextContent separately from non-text content: a single text item is unwrapped to a string, multiple text items remain a list, and isError raises RuntimeError.
- **Applies to:**
  - `dspy/utils/mcp.py`
- **Condition:**
  ```text
  Modifying _convert_mcp_tool_result or MCP tool result handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c96783294b7a000d3a11feb7.md)
