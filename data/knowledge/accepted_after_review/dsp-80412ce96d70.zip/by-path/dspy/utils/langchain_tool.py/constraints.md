# Constraints for `dspy/utils/langchain_tool.py`

## Rule

- **Rule:** When modifying the async LangChain tool wrapper, preserve the behavior of catching any exception from tool.ainvoke and re-raising it as RuntimeError with the tool name and original error message.
- **Applies to:**
  - `dspy/utils/langchain_tool.py`
- **Condition:** Changing error handling in the async LangChain tool wrapper.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6277b8538571b4c6c72d4f1e.md)
