# Constraints for `dspy/utils/saving.py`

## Rule

- **Rule:** When modifying the saving utility, preserve its serialization dependencies: cloudpickle is used for object serialization and ujson for JSON handling.
- **Applies to:**
  - `dspy/utils/saving.py`
- **Condition:** When changing how the saving utility serializes objects or handles JSON.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-45592b4da820a376b2a3cbf0.md)
