# Constraints for `dspy/utils/unbatchify.py`

## Rule

- **Rule:**
  ```text
  When modifying Unbatchify.__enter__, preserve the context-manager contract: __enter__ returns self so the object is usable directly as a context manager whose bound value is the unbatchify instance.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:**
  ```text
  When changing Unbatchify's context-manager protocol or what __enter__ returns.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6430195aefad2d5dbe666395.md)

## Rule

- **Rule:**
  ```text
  Unbatchify must terminate its worker thread on garbage collection via __del__ calling self.close(), and on shutdown must fail remaining queued futures with RuntimeError('Unbatchify is closed'); batch_fn exceptions must be set on every pending future so callers handle per-future exceptions rather than a single batch error.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:** Modifying Unbatchify worker lifecycle, shutdown, or batch error propagation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-883634a679c1ca8bd8e7af6d.md)

## Rule

- **Rule:**
  ```text
  Unbatchify.close must be idempotent: it only sets stop_event and joins the worker thread when stop_event is not already set, so repeated close calls do not re-join.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:** When modifying Unbatchify.close or its worker-thread shutdown logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d6b8d3e5d822740bedf50cf7.md)

## Rule

- **Rule:** dspy.utils.unbatchify must implement concurrent/threaded batch processing using queue, threading, time, concurrent.futures.Future, and typing primitives rather than a simple synchronous helper.
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:** When modifying dspy/utils/unbatchify.py or its concurrency model.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-df4a1290f52a8b14ebee8b45.md)
