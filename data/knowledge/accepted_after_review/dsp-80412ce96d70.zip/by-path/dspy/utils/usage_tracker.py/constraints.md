# Constraints for `dspy/utils/usage_tracker.py`

## Rule

- **Rule:**
  ```text
  When modifying UsageTracker.__init__, preserve storing usage_data as a defaultdict(list) mapping LM name to a list of per-call usage entries, the data model underlying per-model aggregation.
  ```
- **Applies to:**
  - `dspy/utils/usage_tracker.py`
- **Condition:**
  ```text
  changing UsageTracker.__init__ usage_data initialization or data model
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c19358a0cc8db6039aeb278.md)

## Rule

- **Rule:**
  ```text
  UsageTracker._flatten_usage_entry must copy the usage entry and convert completion_tokens_details and prompt_tokens_details to plain dicts when present, normalizing nested token-detail objects for downstream consumption.
  ```
- **Applies to:**
  - `dspy/utils/usage_tracker.py`
- **Condition:**
  ```text
  When modifying UsageTracker._flatten_usage_entry or usage-entry normalization in dspy/utils/usage_tracker.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c60d9f9bd18a04dad9f69ef9.md)
