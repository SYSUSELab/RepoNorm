# Constraints for `dspy/teleprompt/knn_fewshot.py`

## Rule

- **Rule:**
  ```text
  KNNFewShot.__init__ must store the KNN retriever and forward remaining kwargs as few_shot_bootstrap_args to BootstrapFewShot, so extra keyword arguments are not consumed by KNNFewShot itself.
  ```
- **Applies to:**
  - `dspy/teleprompt/knn_fewshot.py`
- **Condition:**
  ```text
  when modifying KNNFewShot.__init__ or its kwargs forwarding to BootstrapFewShot
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8f217539ac6e84e3e9068201.md)
