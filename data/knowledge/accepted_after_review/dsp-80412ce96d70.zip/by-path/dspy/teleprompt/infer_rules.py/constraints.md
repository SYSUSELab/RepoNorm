# Constraints for `dspy/teleprompt/infer_rules.py`

## Rule

- **Rule:**
  ```text
  When modifying RulesInductionProgram.forward, preserve running rule induction inside dspy.settings.context with teacher_settings, copying the LM with temperature sampled uniformly from [0.9, 1.0], and returning the stripped natural_language_rules.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:** changing RulesInductionProgram.forward rule-induction execution or LM temperature sampling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-38a920a12bad159e2cc8571b.md)

## Rule

- **Rule:**
  ```text
  When modifying RulesInductionProgram, preserve its role as a composable dspy.Module subclass in infer_rules.py.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:** Changing RulesInductionProgram's module composition or base class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3fbe0c5fa59a002517fad617.md)

## Rule

- **Rule:**
  ```text
  InferRules/RulesInductionProgram must initialize self.rng = random.Random(0) to keep rule induction deterministic across runs, and must default teacher_settings to an empty dict when none is provided.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  When modifying InferRules/RulesInductionProgram initialization or its randomness/teacher_settings defaults.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5688d5c8fee147f97dd9920e.md)

## Rule

- **Rule:**
  ```text
  get_predictor_demos must filter each trainset example down to keys present in the predictor signature's input or output fields, dropping extra example keys before demos are used.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when modifying get_predictor_demos or the demo-key filtering behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b774a1ac60d762716d5a122f.md)

## Rule

- **Rule:** When modifying InferRules compilation, preserve the candidate-selection flow: split trainset into train/val halves when valset is None, deep-copy the student, reset predictor instructions per candidate, induce and apply natural-language rules, evaluate each candidate on valset, and return the best-scoring program.
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:** changing InferRules.compile candidate generation, evaluation, or selection logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cb11de302cf4f3eafecb47f3.md)

## Rule

- **Rule:**
  ```text
  CustomRulesInduction must set __doc__ dynamically to request num_rules concise non-redundant natural-language rules from examples_text, defining the rule-induction prompt contract.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  When modifying the CustomRulesInduction signature or its dynamic __doc__ prompt construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc38f1f74a8cf926797fc893.md)

## Rule

- **Rule:**
  ```text
  InferRules.__init__ must default num_candidates=10 and num_rules=10, store num_threads, build a RulesInductionProgram(num_rules, teacher_settings), and pull metric and max_errors from kwargs.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when modifying InferRules.__init__ or its default configuration and program construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d7390a977a376317b5e9b239.md)
