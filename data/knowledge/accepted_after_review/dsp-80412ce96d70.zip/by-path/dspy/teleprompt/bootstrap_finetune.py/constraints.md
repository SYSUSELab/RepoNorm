# Constraints for `dspy/teleprompt/bootstrap_finetune.py`

## Rule

- **Rule:**
  ```text
  kill_lms must collect unique LMs from a program and call kill on each, providing the cleanup path for finetuning bootstrap.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When modifying kill_lms or the finetuning bootstrap cleanup path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1421d14ccdda844d2e93ab0e.md)

## Rule

- **Rule:**
  ```text
  build_call_data_from_trace must index the trace by pred_ind assuming order is preserved, and pass pred.signature plus demos (empty when exclude_demos) and the trace inputs/outputs to adapter.format_finetune_data.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  Modifying build_call_data_from_trace or finetune data formatting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3cd4311e800408bb5bb72b0f.md)

## Rule

- **Rule:**
  ```text
  all_predictors_have_lms must return True only when every predictor in the program has an LM set, serving as a precondition check for bootstrap finetuning.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  when modifying all_predictors_have_lms or the bootstrap finetuning precondition check
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-557b07e798997ba02669e374.md)

## Rule

- **Rule:**
  ```text
  When a wrapped program raises AdapterParseError, bootstrap_trace_data must locate the predictor whose signature matches the failed signature (raising ValueError if none found), compute a format_reward scaled between format_failure_score and failure_score by the ratio of present to expected output fields, and append a FailedPrediction to the trace.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When modifying bootstrap_trace_data failure handling for AdapterParseError.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7d65e27a803679f63f004d41.md)

## Rule

- **Rule:**
  ```text
  FailedPrediction must hold completion_text and an optional format_reward float defaulting to None, so failed finetuning predictions may lack a format reward.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When changing the FailedPrediction record or its format_reward default.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8eb33a18e875ac4260443d39.md)
