# Constraints for `dspy/streaming/streaming_listener.py`

## Rule

- **Rule:**
  ```text
  When allow_reuse is set, a completed stream must reset stream_end, cache_hit, field_start_queue, field_end_queue, and stream_start so the listener can be reused for a subsequent stream; otherwise receive returns early.
  ```
- **Applies to:**
  - `dspy/streaming/streaming_listener.py`
- **Condition:**
  ```text
  when modifying StreamListener.receive or the allow_reuse stream-reset behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-522896dd19291c5142b50c61.md)

## Rule

- **Rule:**
  ```text
  When modifying the streaming listener's adapter dispatch, preserve the explicit compatibility boundary: adapters not present in ADAPTER_SUPPORT_STREAMING must be rejected with a ValueError that lists the supported adapters, rather than silently accepted or handled generically.
  ```
- **Applies to:**
  - `dspy/streaming/streaming_listener.py`
- **Condition:** When changing which adapters the streaming listener accepts or how it validates them.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8b86ed4cb38a1b3c521b1688.md)

## Rule

- **Rule:**
  ```text
  When modifying JSONAdapter streaming receive handling, preserve stripping a leading double-quote from the buffered chunk after the start_identifier because splitters may appear between the colon and the opening quote.
  ```
- **Applies to:**
  - `dspy/streaming/streaming_listener.py`
- **Condition:**
  ```text
  changing JSONAdapter streaming chunk buffering or quote stripping after start_identifier
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bc37ca576dd212db78eba145.md)
