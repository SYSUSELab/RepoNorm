# Constraints for `dspy/streaming/messages.py`

## Rule

- **Rule:**
  ```text
  When modifying StatusMessageProvider or its consumers, preserve the documented extension point: users subclass it and override methods like lm_start_status_message(instance, inputs) and module_end_status_message(outputs), each returning a string, and pass an instance via dspy.streamify(..., status_message_provider=...).
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:** When changing StatusMessageProvider's overridable methods or how dspy.streamify accepts a status message provider.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1ffe877ebbe563d21767e614.md)

## Rule

- **Rule:**
  ```text
  StatusMessageProvider.module_start_status_message must remain a no-op hook (body pass) documented as the status message emitted before a Module or Predict is called, so subclasses may override it but the base does nothing.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  When changing StatusMessageProvider.module_start_status_message or its base no-op behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-49dfd53624664759432b010d.md)

## Rule

- **Rule:**
  ```text
  on_lm_end must return early when settings.send_stream is None and only emit a StatusMessage when the status message provider returns a non-empty message.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  When modifying StatusStreamingCallback.on_lm_end or the status message emission path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-be7dd451d83c67a8089b42d8.md)

## Rule

- **Rule:** StatusMessage must remain a dataclass wrapping a single message string for status streaming, defining the minimal payload shape for status stream events.
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:** when modifying StatusMessage or the status stream event payload shape
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f43b4027676823aed2fbc69e.md)
