# Constraints for `dspy/__init__.py`

## Rule

- **Rule:**
  ```text
  Ruff per-file ignores for dspy/__init__.py disable I001, E402, and F405, allowing unsorted imports, imports not at the top of the file, and undefined names from wildcard imports.
  ```
- **Applies to:**
  - `dspy/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fc8217ce89ce5e090993c1de.md)
