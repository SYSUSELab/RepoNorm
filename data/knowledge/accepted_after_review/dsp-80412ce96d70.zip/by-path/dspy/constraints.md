# Constraints for `dspy`

## Rule

- **Rule:** Ruff targets Python version py310.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-49d97a1e6e6579c4ef2910c6.md)

## Rule

- **Rule:** Ruff uses an indent width of 4.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-759d215093f724de19cfc1dc.md)

## Rule

- **Rule:** Ruff enforces a maximum line length of 120.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-9dc5054a7ca96baa492768a3.md)

## Rule

- **Rule:**
  ```text
  Package discovery includes only the dspy and dspy.* packages.
  ```
- **Applies to:**
  - `dspy/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a3f49fc8040a6325410e23b9.md)

## Rule

- **Rule:**
  ```text
  Ruff linting/formatting applies to Python files under dspy/ and tests/ as configured by include = ["dspy/**/*.py", "tests/**/*.py"].
  ```
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c96220426b095b5c3f51a757.md)
