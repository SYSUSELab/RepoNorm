# Constraints for `docs`

## Rule

- **Rule:** The MkDocs edit URI is configured as blob/main/docs/docs/.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1f0ee7c5b620b302f275083b.md)

## Rule

- **Rule:** Contributors must fix documentation build failures before pushing.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-294d7f9e6be82d7d18ed312b.md)

## Rule

- **Rule:** The MkDocs Material theme uses a custom directory named overrides.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-36252ee4e9ec4af31f04e919.md)

## Rule

- **Rule:** Once documentation changes are merged to main, they are reflected on the live website usually within 5-15 minutes.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3a05769b4f9a2791b64e301a.md)

## Rule

- **Rule:** The MkDocs documentation source directory is configured as "docs/".
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-46c3b2f197cee3e67f29fafb.md)

## Rule

- **Rule:** The MkDocs documentation site uses the Material theme.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4d6699b2cd683cf3873d8b32.md)

## Rule

- **Rule:**
  ```text
  CI runs the `mkdocs build` command to verify the documentation builds successfully before merging changes.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-5d1cad763bc8aa64085dc690.md)

## Rule

- **Rule:**
  ```text
  The docs workflow triggers on pushes to the main branch when changed paths match docs/**.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-70018092e9b95239a6c55b3d.md)

## Rule

- **Rule:**
  ```text
  Running `mkdocs build` generates a static build of the documentation site in the `site` directory.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7448eeb89f838d9c8feb2f46.md)

## Rule

- **Rule:** The Vercel configuration at docs/vercel.json sets trailingSlash to true.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-874ba594dd3961385086a54c.md)

## Rule

- **Rule:** The MkDocs Material theme enables the navigation.tabs, navigation.path, navigation.indexes, navigation.expand, toc.follow, navigation.top, search.suggest, and search.highlight features.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8af94e109fa0c38584ba7c6b.md)

## Rule

- **Rule:**
  ```text
  The docs workflow triggers on pull requests when changed paths match docs/**.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-90ad1f5ab57d1071d368590c.md)

## Rule

- **Rule:**
  ```text
  Documentation changes for the docs site are made in the `dspy/docs` folder.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-921c608e30abd081e7ac898c.md)

## Rule

- **Rule:** Contributors pull the latest version of the live documentation site by cloning the dspy repo before making documentation changes.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-9ac171f61727dfff5665904a.md)

## Rule

- **Rule:** The update-docs-subtree job runs only on push events to the stanfordnlp/dspy repository and pushes the docs directory to the dspy-docs repository's master branch.
- **Applies to:**
  - `docs/**`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push' && github.repository == 'stanfordnlp/dspy'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d91ed001e982b3a322d404e4.md)

## Rule

- **Rule:** Documentation changes are pushed on a new branch and opened as a PR for review and approval before merging into main.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-ee95e3b16036cb0f7380632a.md)

## Rule

- **Rule:** When the CI build check fails, review changes and ensure the documentation builds correctly locally before pushing updates.
- **Applies to:**
  - `docs/**`
- **Condition:** the CI build check fails
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-ef4483e22273d87f2d0f2353.md)
