# Constraints for `docs/scripts/generate_api_docs.py`

## Rule

- **Rule:**
  ```text
  When generating API documentation pages, emit mkdocstrings blocks as '::: {module_path}.{name}' with the established option set (show_source, show_root_heading, heading_level 2, google docstring style, inherited_members), list public methods under a members config for classes, and place the ':::' marker last so the generated block is not left unclosed.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Modifying the API documentation page generator that renders mkdocstrings blocks for modules, classes, and routines.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7be46595551aefbd0b4bc946.md)

## Rule

- **Rule:**
  ```text
  Method inclusion in generated API docs is governed by should_document_method: methods whose __module__ does not start with "dspy" are excluded, private/dunder methods are excluded, but __call__ is explicitly included.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** When adding or modifying methods on documented classes, or changing which methods appear in generated API docs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c49bb1a69cd0fe6fce645abe.md)

## Rule

- **Rule:**
  ```text
  API doc generation traversal must respect the exclusion and mapping gates: generate_md_docs_submodule skips excluded_modules, skips objects not in the API mapping, avoids regenerating already-processed objects, and skips private modules or modules not exposed in the package __init__.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** When modifying submodule traversal or adding modules that should or should not be documented.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d9bc1fe59719c683364cb85d.md)

## Rule

- **Rule:**
  ```text
  Directory cleanup after API doc generation must be bottom-up: remove_empty_dirs recurses into child directories first and removes a directory only if it is a directory and has no entries, preserving non-empty parents.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** When modifying cleanup logic after API doc generation or adding directory removal behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-da9f3f0d52c6e97a0e34c45c.md)

## Rule

- **Rule:**
  ```text
  Adding or renaming a public dspy symbol requires a corresponding entry in the API_MAPPING dict in docs/scripts/generate_api_docs.py, because API doc generation only emits pages for root-level objects whose category resolves through that mapping and silently skips unmapped objects.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** When adding or renaming a public dspy symbol that should appear in generated API documentation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f5d06197d16e2b213cc1a78b.md)

## Rule

- **Rule:**
  ```text
  Regenerating API docs must preserve hand-written content surrounding the generated section: write_doc_file and read_existing_content split on the START_API_REF/END_API_REF markers and recombine pre/post content, so contributors must not remove or relocate those markers.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** When modifying API doc generation or editing generated API documentation files that contain hand-written surrounding content.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f6ba057a591c9fd4a61ad54b.md)

## Rule

- **Rule:**
  ```text
  When selecting which public API entries appear in generated docs, filter documented members by __all__ when present, include submodules whose name starts with the module name, include classes/routines whose __module__ starts with the module name, and exclude underscore-prefixed names.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Modifying the member-selection logic that decides which public API entries are documented.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fd8d0d2332b1a22fa0f224c5.md)
