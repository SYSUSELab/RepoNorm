# Constraints for `docs/scripts/generate_api_summary.py`

## Rule

- **Rule:**
  ```text
  mkdocs.yml rewriting must preserve pre-nav and post-theme content and must not duplicate the auto-generated API Reference section: read_mkdocs_sections strips the existing '- API Reference:' entry and its 8-space-indented children, and main() inserts the generated section between existing nav and theme sections.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:** When modifying mkdocs.yml rewriting or the API Reference section generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-783865c9fcd374506563092c.md)

## Rule

- **Rule:**
  ```text
  Generated API navigation must include only .md files: build_nav_structure sorts directory entries and adds only .md files to the nav dict, mapping each stem to its path relative to base_path.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:** When adding files under docs/api or modifying navigation structure generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-849c98fc5eeb9968f1e71e3c.md)

## Rule

- **Rule:**
  ```text
  Generated API navigation must order submodule (dict-valued) entries before file entries at each level, as implemented by format_nav_section, so dspy.evaluate appears before dspy.ChainOfThought.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:** When modifying API navigation generation or adding entries that affect nav ordering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3f1eabebcfa6fef70eddcd5.md)

## Rule

- **Rule:**
  ```text
  Adding a new public API area or docs/api subdirectory requires a corresponding INDEX_NAME entry in docs/scripts/generate_api_summary.py, because generate_api_nav maps each docs/api subdirectory name through INDEX_NAME to a category and builds nav structures from it.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:** When adding a new public API area or a new subdirectory under docs/api that should appear in generated navigation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bccc943c881c5be06e26c9b2.md)
