# Constraints for `docs/README.md`

## Rule

- **Rule:**
  ```text
  On MacOS, building the site may additionally require installing libraries via `brew install cairo freetype libffi libjpeg libpng zlib`.
  ```
- **Applies to:**
  - `docs/README.md`
- **Condition:** On MacOS when building the site
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../claims/CLAIM-29070a9cf83a28ab8a7565d5.md)
