# Constraints for `docs/mkdocs.yml`

## Rule

- **Rule:** The mkdocstrings Python handler shows docstring parameters.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-014168498c96f7385d860696.md)

## Rule

- **Rule:** The redirects plugin maps deep-dive/optimizers/BootstrapFinetune.md to api/optimizers/BootstrapFinetune.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-035f663eb3736a40cac4210c.md)

## Rule

- **Rule:** The MkDocs site language is set to English (en).
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-06b8a854f1ed45d8e56a39f9.md)

## Rule

- **Rule:** The mkdocstrings Python handler disables separate signatures.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-06d524fd9911037a94b2362b.md)

## Rule

- **Rule:**
  ```text
  The mkdocstrings Python handler merges __init__ into the class.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-08a8196bc5f60480e4785fc9.md)

## Rule

- **Rule:** The mkdocstrings Python handler shows the root heading.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0a3b74c11bacc0e62d76eadd.md)

## Rule

- **Rule:** The mkdocstrings rendering options show docstrings when absent.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0ddfccd505d50aef35ac0268.md)

## Rule

- **Rule:** The MkDocs site defines a default palette scheme with white primary and black accent.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0e25792068e846f773a55b85.md)

## Rule

- **Rule:** The MkDocs site enables the search plugin with language en.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0f94c3701e5592c1679695f1.md)

## Rule

- **Rule:** The mkdocstrings Python handler shows signature annotations.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1fd79fdcbbec67dfb7d1105c.md)

## Rule

- **Rule:** The mkdocstrings Python handler uses the table docstring section style.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-21f120a0615458a1dbd6ad5f.md)

## Rule

- **Rule:** The redirects plugin maps deep-dive/optimizers/Ensemble.md to api/optimizers/Ensemble.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-26f0e02b92c2331bc7c056f3.md)

## Rule

- **Rule:**
  ```text
  The MkDocs site logo is static/img/dspy_logo.png.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2f4a4acd2742f8108a39e480.md)

## Rule

- **Rule:** The redirects plugin maps docs/quick-start/getting-started-02.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-31e856d90566018c6a54f99a.md)

## Rule

- **Rule:** The MkDocs site defines a slate palette scheme with black primary and lime accent.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3e656ad07c68974a66eb3010.md)

## Rule

- **Rule:** The redirects plugin maps deep-dive/optimizers/bootstrap-fewshot.md to api/optimizers/BootstrapFewShot.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-48db0a12edbb4dd32a8929d7.md)

## Rule

- **Rule:** The MkDocs site loads the extra JavaScript file js/runllm-widget.js.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4f9302a0096b617365b55012.md)

## Rule

- **Rule:** The redirects plugin maps intro/index.md to index.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-51f254b67b652d7b3d256590.md)

## Rule

- **Rule:** The mkdocstrings Python handler shows docstrings when absent.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-58d4e243ed079422f4232daa.md)

## Rule

- **Rule:** The redirects plugin maps deep-dive/optimizers/miprov2.md to api/optimizers/MIPROv2.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-629d7529fb310efbe9c54ee6.md)

## Rule

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.emoji extension using the twemoji index and to_svg generator from material.extensions.emoji.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-73e838b0a08a2ebf4700142b.md)

## Rule

- **Rule:** The redirects plugin maps docs/quick-start/getting-started-01.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-787b99d45f77c42acf42de62.md)

## Rule

- **Rule:**
  ```text
  The MkDocs search plugin uses the separator regex '[\s\-\.]+'.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8066d5d9599b06cbf697a797.md)

## Rule

- **Rule:** The MkDocs site enables the pymdownx.arithmatex extension with generic true.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-88a8b6feca94ea8dad06a884.md)

## Rule

- **Rule:** The mkdocstrings Python handler sets the annotations path to brief.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-956d6b12e22bc563da4054ea.md)

## Rule

- **Rule:** The mkdocstrings Python handler enables symbol type headings.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9974268504775de6df4988a4.md)

## Rule

- **Rule:** The MkDocs site favicon is static/img/logo.png.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a49b27d67694be8cf911d337.md)

## Rule

- **Rule:**
  ```text
  The mkdocstrings rendering options disable html_meta.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-abfc0af2fad90b2e0416d9e2.md)

## Rule

- **Rule:** The MkDocs site loads the extra stylesheet stylesheets/extra.css.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b8bab0c9293f57aa5bf60b5e.md)

## Rule

- **Rule:** The mkdocs-jupyter plugin ignores H1 titles.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bb97bca8c1be1260536e6dce.md)

## Rule

- **Rule:** The redirects plugin maps quick-start/getting-started-02.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bb9b38d920b3561b05b0cee3.md)

## Rule

- **Rule:** The redirects plugin maps intro.md to index.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bf32065d63a29068481782ca.md)

## Rule

- **Rule:** The mkdocstrings Python handler unwraps Annotated types.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bfa911e4a55dd0f1032ab8c0.md)

## Rule

- **Rule:** The mkdocstrings Python handler sets heading level 3.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c420d25dc8681e26f1c53509.md)

## Rule

- **Rule:** The mkdocstrings Python handler uses Google docstring style.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c77ccb01b8c7d67b9acf25ad.md)

## Rule

- **Rule:** The mkdocstrings Python handler enables category headings.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c8e3d601d839d34c2fb82d4b.md)

## Rule

- **Rule:** The mkdocstrings rendering options disable warnings.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c9e6eb9012b863f8c4944f93.md)

## Rule

- **Rule:** The redirects plugin maps deep-dive/optimizers/copro.md to api/optimizers/COPRO.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cbf511094cf52977e20d34fa.md)

## Rule

- **Rule:** The mkdocstrings Python handler shows source.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cf69b7791fa93da8f0a0a189.md)

## Rule

- **Rule:** The redirects plugin maps quick-start/getting-started-01.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dff9e211f6a4f46efb50a893.md)

## Rule

- **Rule:** The mkdocstrings Python handler orders members by source.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e05cd19dd3cb563a6f1b18ed.md)

## Rule

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.highlight extension with anchor_linenums true.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e1ee6b01022fe9924f613317.md)

## Rule

- **Rule:** The redirects plugin maps deep-dive/optimizers/LabeledFewShot.md to api/optimizers/LabeledFewShot.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e610178ecd5da7704c73de04.md)

## Rule

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.tabbed extension with alternate_style true.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e77cd4281d6bde3e0af17922.md)

## Rule

- **Rule:** The redirects plugin maps deep-dive/optimizers/bfrs.md to api/optimizers/BootstrapFewShotWithRandomSearch.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fb43601d97f77db3593a319d.md)
