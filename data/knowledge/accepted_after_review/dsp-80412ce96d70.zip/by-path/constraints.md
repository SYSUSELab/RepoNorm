# Constraints for `.`

## Rule

- **Rule:** Pre-commit hooks are used to automatically check and fix common issues, and must be set up once after cloning the repository.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-0a7268fefbdc7b0d93138b1b.md)

## Rule

- **Rule:** The release automation requires a trusted publisher to be set up on both the pypi and test-pypi packages.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-0bac965fa781d148d724d51a.md)

## Rule

- **Rule:** The workflow runs on pull requests of types opened, synchronize, and reopened.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-15f6bb2e484befc3c635460e.md)

## Rule

- **Rule:** Coverage measurement is configured to track branch coverage.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-16f0f0b98da0be9990ad0243.md)

## Rule

- **Rule:** Open a pull request from your branch in your fork to the main branch in the DSPy repo once your changes are ready.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-187a8d50e273d6c39dbd789a.md)

## Rule

- **Rule:**
  ```text
  Run `pre-commit install` to install the pre-commit hook.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1917971d99d80368e8b7379f.md)

## Rule

- **Rule:** Setting up the DSPy development environment requires forking the DSPy repository and cloning it locally.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-19c3d42c08f2ca4771c4a08e.md)

## Rule

- **Rule:**
  ```text
  Coverage reporting excludes lines matching the configured patterns from coverage measurement, including "pragma: no cover", "def __repr__", "if self.debug:", "raise AssertionError", "raise NotImplementedError", "if __name__ == '__main__':", "logger", "try", "except", the regex "^\s*self\.\w+(:\s*[^=]+)?\s*=.*$", and "continue".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1f315a4c69ac68fdd3cb9b99.md)

## Rule

- **Rule:** Ruff linting ignores rules B027, FBT003, C901, E501, UP035, RUF005, B904, F403, E721, UP031, and RUF022.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-249c73f85684fc6b5c08fd26.md)

## Rule

- **Rule:** The check-yaml hook runs with args --allow-multiple-documents and --unsafe.
- **Applies to:**
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2b3d672dc85db529734fd264.md)

## Rule

- **Rule:** Ruff format uses automatic line-ending detection (line-ending = "auto").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c63702fa1507f1a5274d4b5.md)

## Rule

- **Rule:** Contributors proposing a new feature should open a feature request to discuss it.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-30ac2533f5dea20b3ebfdce7.md)

## Rule

- **Rule:** All pre-commit checks must pass before creating a pull request.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-336ca92adf262bcc61b5a51a.md)

## Rule

- **Rule:** Ruff's flake8-tidy-imports rule bans all relative imports.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-34a43db1457fc3d0ed2894bc.md)

## Rule

- **Rule:** The workflow publishes the built distribution to PyPI using pypa/gh-action-pypi-publish@release/v1 with attestations disabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3564e7a14c5bed8c51e308c8.md)

## Rule

- **Rule:**
  ```text
  The workflow checks out the main branch by running `git fetch origin` and `git checkout main`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-36705d2190010a21fb660fb4.md)

## Rule

- **Rule:**
  ```text
  Ruff per-file ignores for __init__.py disable F401, allowing unused imports in init files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3e6170597c2b4cb39f82c997.md)

## Rule

- **Rule:**
  ```text
  The release workflow builds a binary wheel by running `python3 -m build`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-42a59b068689bdcbab82874a.md)

## Rule

- **Rule:**
  ```text
  Set up the development environment via conda + pip by running `conda create -n dspy-dev python=3.11` followed by `conda activate dspy-dev`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-434ae708cadc333cd6db4342.md)

## Rule

- **Rule:** The workflow runs on pushes to the main branch.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-531470264b901f8af1fff6fe.md)

## Rule

- **Rule:** The fix job runs ruff check with --fix-only --diff --exit-non-zero-on-fix, and on fixable issues prints guidance to run pre-commit run --all-files and exits with status 1.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5403f52cc53e5197151b1711.md)

## Rule

- **Rule:** Pre-commit hooks default to the python3.9 language version.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5e3ffea532c494c0833c324c.md)

## Rule

- **Rule:** The test job runs against Python versions 3.10, 3.11, 3.12, and 3.13 in its matrix.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-60a370882416151f98b7d562.md)

## Rule

- **Rule:** If there are no releases on the new project, a pending trusted publisher may have to be created to allow the first automated deployment.
- **Applies to:**
  - `**`
- **Condition:** there are no releases on the new project
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-63e6d4e6b3fd173d8e5fa6ae.md)

## Rule

- **Rule:** Pre-commit installs the pre-commit hook type by default.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6406a5f8d51b16ab2b28c034.md)

## Rule

- **Rule:** The pre-commit configuration enables the debug-statements hook.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6f6293987432ee7e71e9a7a9.md)

## Rule

- **Rule:** Python 3.10 or later is required for the DSPy development environment.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-73c4dcac80f316d5e69ade2d.md)

## Rule

- **Rule:** Ruff format does not skip magic trailing commas (skip-magic-trailing-comma = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-77fa0b25972499a2e145f6ee.md)

## Rule

- **Rule:** Pre-commit hooks default to running at the pre-commit stage.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-80210a5fe34371f8708413a6.md)

## Rule

- **Rule:** When creating a new release for a major or minor version, update the default branch on the GitHub repository to the new release branch.
- **Applies to:**
  - `**`
- **Condition:** creating a new release for a major or minor version
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-873c530b2ef0306eb2f4fcdb.md)

## Rule

- **Rule:**
  ```text
  The project requires Python >=3.10, <3.14.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-89704dbe5bc998a372e64623.md)

## Rule

- **Rule:** The check-added-large-files hook runs with args --maxkb=1024.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8f6a7ae81d750f3f65561dcb.md)

## Rule

- **Rule:**
  ```text
  Ruff's isort lint rule treats the `dspy` package as first-party when classifying imports.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-97d7b4213037c5096237b9ff.md)

## Rule

- **Rule:** Contributors may commit changes and let the pre-commit hooks fix formatting issues automatically.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-9f869fd3dd8d371997acd83b.md)

## Rule

- **Rule:** For minor changes (simple bug fixes or documentation fixes), a PR may be opened without prior discussion.
- **Applies to:**
  - `**`
- **Condition:** the change is a minor change such as a simple bug fix or documentation fix
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-a12fb83b87edcf7745e33780.md)

## Rule

- **Rule:** After running git commit, if the hooks make any changes, those changes must be staged and committed as well.
- **Applies to:**
  - `**`
- **Condition:** the hooks make changes during git commit
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-a4569c7b6f0f28a11dc2fbc2.md)

## Rule

- **Rule:** The hooks can also be run manually, including a mode that checks staged files only.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-a7a364e6bac1e834c56be323.md)

## Rule

- **Rule:** No Ruff rules are marked unfixable.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b0a1c8571b4ed8d41f2424e1.md)

## Rule

- **Rule:** Contributors are recommended to open an issue (if one doesn't already exist) and discuss proposed changes before making any changes.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-b2062b6757d226c4bffb320c.md)

## Rule

- **Rule:**
  ```text
  The workflow merges the release-<extracted tag version> branch into main with `git merge --no-ff` and pushes the result with `git push origin main`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bb138bdb5638b799c4972c2f.md)

## Rule

- **Rule:** If a code change involves fixing a bug, include a code snippet or notebook showing how to reproduce the broken behavior.
- **Applies to:**
  - `**`
- **Condition:** the code change involves fixing a bug
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-c1416aa2f0ceb87b87a2e6b9.md)

## Rule

- **Rule:** Ruff linting enables the rule sets E, W, F, I, C, B, UP, N, RUF, and Q.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-c17683e6a727a1c167a69951.md)

## Rule

- **Rule:** To make code changes, fork the repository and set up the local development environment following the instructions in the "Environment Setup" section.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-c6a17fb0c74dd0332005ac4d.md)

## Rule

- **Rule:** After installation, verify it by running some unit tests.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-c6dbd337df56240099b54234.md)

## Rule

- **Rule:** Run unit tests to verify that the development environment is set up successfully.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-c8340d2249abcf7793d36fcd.md)

## Rule

- **Rule:** Run pre-commit on specific files with: pre-commit run --files path/to/file1.py path/to/file2.py
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dcb8ee666837a0e986d99a89.md)

## Rule

- **Rule:** Python code follows the Google Python Style Guide, and ruff is used for both linting and formatting.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-e081d3d323ef2d6ff2e666f3.md)

## Rule

- **Rule:** Ruff format indents with spaces (indent-style = "space").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e5aeacedf4dd9f6fa2ecb747.md)

## Rule

- **Rule:**
  ```text
  Coverage omits __init__.py, test_*.py, tests/*.py, conftest.py, setup.py, and virtual environment directories (venv, virtualenv, .venv, .virtualenv, env, .env) from measurement.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e7baae85656a406aee4b8ad2.md)

## Rule

- **Rule:** If the package is migrated to a new project, follow the steps to create a trusted publisher.
- **Applies to:**
  - `**`
- **Condition:** the package is migrated to a new project
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-e7ed4704db620201b477207a.md)

## Rule

- **Rule:** Ruff format uses double quotes for string literals (quote-style = "double").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eaa4f89283d3668733306ba5.md)

## Rule

- **Rule:** The pre-commit configuration enables the check-merge-conflict hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eaf201c546eb39db96c8f6da.md)

## Rule

- **Rule:**
  ```text
  The workflow auto-commits changes to a branch named release-<extracted tag version> with commit message "Update versions" using stefanzweifel/git-auto-commit-action@v5.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f06d6e44cafc149c09e30e01.md)

## Rule

- **Rule:** Ruff format does not format code inside docstrings (docstring-code-format = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f0ce3d7cb437901fcb0b0e3a.md)

## Rule

- **Rule:** The pre-commit configuration enables the check-toml hook.
- **Applies to:**
  - `**/*.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f2b156d044bdb4df2b80e421.md)

## Rule

- **Rule:**
  ```text
  When you run `git commit`, the pre-commit hook runs automatically.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f64921a8735a3d83adf5e1e7.md)

## Rule

- **Rule:** Contributors who already have a design in mind for a proposed feature should include a notebook/code example demonstrating the idea.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-f7963ae825692eb3b139e53d.md)

## Rule

- **Rule:** The workflow configures the git user as actions@github.com with name "Github Actions".
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ff430f55f324e36d50d92473.md)

## Rule

- **Rule:** When creating a new release for a major or minor version, create a new release branch with the last commit named 'release/X.Y'.
- **Applies to:**
  - `**`
- **Condition:** creating a new release for a major or minor version
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-ff5e2332242cb803a3fb770d.md)
