# Constraints for `.github/workflows/build_utils/test_version.py`

## Rule

- **Rule:**
  ```text
  When modifying the version-bump helper, preserve the CLI contract that the script requires exactly two arguments (package_name, tag_version), fetches the latest version, optionally increments it, and prints the resulting version.
  ```
- **Applies to:**
  - `.github/workflows/build_utils/test_version.py`
- **Condition:** Changing the command-line interface or argument handling of the version-bump helper.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-0e13b2d3b6d81eb7b598b4d2.md)

## Rule

- **Rule:**
  ```text
  When modifying the version-bump helper, preserve the behavior that increment_version parses a PyPI version, reconstructs a semver Version including prerelease components, and returns bump_prerelease(), so prerelease versions are bumped rather than released.
  ```
- **Applies to:**
  - `.github/workflows/build_utils/test_version.py`
- **Condition:** Changing how the version-bump helper increments a version.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-38a271cb9ea48a32399bb9a1.md)
