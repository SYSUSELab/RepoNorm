# Constraints for `.github/workflows/docs-push.yml`

## Rule

- **Rule:**
  ```text
  The build-test job runs only for pull_request events and builds the docs with mkdocs after installing docs/requirements.txt.
  ```
- **Applies to:**
  - `.github/workflows/docs-push.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'pull_request'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ce5bbd650e20a1c997425732.md)
