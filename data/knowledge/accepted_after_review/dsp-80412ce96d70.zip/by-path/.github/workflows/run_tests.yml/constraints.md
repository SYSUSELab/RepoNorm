# Constraints for `.github/workflows/run_tests.yml`

## Rule

- **Rule:**
  ```text
  The build_package job creates a virtual environment at .venv and adds its bin directory to GITHUB_PATH.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-08fb4034a533c871dcbe7a0a.md)

## Rule

- **Rule:**
  ```text
  The build_package job installs dependencies with uv sync --dev -p .venv --extra dev.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-328ca82a6f995f93b34557e8.md)

## Rule

- **Rule:**
  ```text
  The build_package job verifies the built package by running python -c "import dspy" in the .venv environment.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-43aeef8ab7e66db410605731.md)

## Rule

- **Rule:**
  ```text
  The build_package job builds the package with uv run -p .venv python -m build.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8b2efa18dac198fc51051160.md)

## Rule

- **Rule:**
  ```text
  The build_package job runs on ubuntu-latest.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-97d3809d825a8fc3b5a45a91.md)

## Rule

- **Rule:**
  ```text
  The build_package job installs uv with caching enabled, keyed on **/pyproject.toml and **/uv.lock.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b7848721605a30eeff7c8fa4.md)

## Rule

- **Rule:**
  ```text
  The build_package job sets up Python using the matrix python-version value.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cdf36eeb56c94786b57e0b0c.md)

## Rule

- **Rule:**
  ```text
  The build_package job installs the built wheel from dist/*.whl into the .venv environment.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dcf7455e352a370de08a6329.md)

## Rule

- **Rule:**
  ```text
  The build_package job runs a matrix over Python versions 3.10, 3.11, 3.12, and 3.13.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ef23bc056caa8c7daa943baf.md)
