# Constraints for `.github/workflows/build_and_release.yml`

## Rule

- **Rule:**
  ```text
  The build-and-publish-pypi job depends on extract-tag and build-and-publish-test-pypi, and only runs when github.repository_owner == 'stanfordnlp'.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Condition:**
  ```text
  workflow predicate: github.repository_owner == 'stanfordnlp'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0d01382fdee3b89aa0e0a22a.md)

## Rule

- **Rule:** The build-and-publish-test-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-16895e9fe3290a4e8ed80fd2.md)

## Rule

- **Rule:**
  ```text
  The workflow runs on pushes of tags matching "*", triggering the extract-tag job.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Condition:**
  ```text
  workflow predicate: push: tags: - "*"
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-248771d7187ef08238ef2bd4.md)

## Rule

- **Rule:** The build-and-publish-test-pypi job installs setuptools, wheel, twine, build, semver, and packaging via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-53f70e4cd066c7182d219c28.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-test-pypi job creates a virtual environment named test_before_testpypi.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-692500dae9eeab8a7cd11423.md)

## Rule

- **Rule:** The build-and-publish-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-84e319b9540293f6365062b1.md)

## Rule

- **Rule:**
  ```text
  The extract-tag job runs on ubuntu-latest and extracts the tag name from GITHUB_REF into the version output.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-883011362be73225d8d8d8d3.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-test-pypi job determines the TestPyPI version by running .github/workflows/build_utils/test_version.py with package name dspy-ai-test and the extracted tag version.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9958e5275bfe527484f4c844.md)

## Rule

- **Rule:** The build-and-publish-test-pypi job depends on extract-tag and runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9c9498cf313528d72260ec37.md)

## Rule

- **Rule:** The build-and-publish-test-pypi job builds a binary wheel with python3 -m build.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c4398a90c594f2093d7c05f2.md)

## Rule

- **Rule:** The build-and-publish-test-pypi job publishes the distribution to test-PyPI using pypa/gh-action-pypi-publish@release/v1 with repository-url https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dfaf9b3364c626751a5a05b7.md)

## Rule

- **Rule:** The build-and-publish-pypi job installs setuptools, wheel, twine, and build via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ee2005a1fc19dab4fb5194da.md)
