# Constraints for `.github/workflows/precommits_check.yml`

## Rule

- **Rule:** The Pre-Commit Checks step installs and upgrades pip, installs pre-commit, and runs pre-commit run -v --files on the changed files.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1b41255bb4dd39857d12fcf7.md)

## Rule

- **Rule:**
  ```text
  The Pre-commit checks workflow is triggered only by workflow_dispatch.
  ```
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Condition:**
  ```text
  workflow predicate: workflow_dispatch:
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5a8046d0e4ac6873aa768140.md)

## Rule

- **Rule:** The workflow obtains the list of changed files using the jitterbit/get-changed-files action with step id files.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-850a668db6577ebb3778648f.md)

## Rule

- **Rule:** The pre-commit-checks job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b125e392abf26ab69d06206f.md)

## Rule

- **Rule:** The workflow sets up Python version 3.10 with pip caching.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c982f8e33a1b44c3f9a9ccd0.md)

## Rule

- **Rule:** Pull request titles are checked against a regexp requiring a conventional-commit-style type prefix followed by a scope in parentheses, a colon, a space, and a description.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ce5347d1bf8f8c1241f4c4c0.md)
