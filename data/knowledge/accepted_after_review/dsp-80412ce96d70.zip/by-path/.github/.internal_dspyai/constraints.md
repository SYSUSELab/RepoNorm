# Constraints for `.github/.internal_dspyai`

## Rule

- **Rule:**
  ```text
  The workflow builds the dspy-ai binary wheel by running `python3 -m build .github/.internal_dspyai/`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9ca58af418462cddde33941a.md)
