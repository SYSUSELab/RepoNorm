# Constraints for `.github`

## Rule

- **Rule:** Pushing a semver tag by a repo maintainer triggers the GitHub Action that extracts the tag as the version.
- **Applies to:**
  - `.github/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-51586dfbfab932da0ee5614c.md)
