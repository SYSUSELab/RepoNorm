# Claim catalog

- [Rules 1–74](catalog/0001.md); scope preview: `tests/reliability/**/*.py`
- [Rules 75–147](catalog/0002.md); scope preview: `dspy/signatures/signature.py`
- [Rules 148–221](catalog/0003.md); scope preview: `dspy/datasets/gsm8k.py`
- [Rules 222–291](catalog/0004.md); scope preview: `dspy/datasets/dataset.py`
- [Rules 292–365](catalog/0005.md); scope preview: `docs/scripts/generate_api_summary.py`
- [Rules 366–437](catalog/0006.md); scope preview: `dspy/**`
- [Rules 438–513](catalog/0007.md); scope preview: `**`
- [Rules 514–585](catalog/0008.md); scope preview: `dspy/predict/multi_chain_comparison.py`
- [Rules 586–591](catalog/0009.md); scope preview: `tests/teleprompt/test_bootstrap.py`
