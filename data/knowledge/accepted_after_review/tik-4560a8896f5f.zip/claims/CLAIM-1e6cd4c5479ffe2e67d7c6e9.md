# Rule details

- **Rule:**
  ```text
  A tiktoken extension module must contain a variable named ENCODING_CONSTRUCTORS, a dictionary mapping encoding names to zero-argument functions that return arguments passable to tiktoken.Encoding.
  ```
- **Applies to:**
  - `tiktoken_ext/**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
`my_encodings.py` should be a module that contains a variable named `ENCODING_CONSTRUCTORS`.
This is a dictionary from an encoding name to a function that takes no arguments and returns
arguments that can be passed to `tiktoken.Encoding` to construct that encoding. For an example, see
`tiktoken_ext/openai_public.py`. For precise details, see `tiktoken/registry.py`.

```

- **Sources:**
  - `README.md:112-115`

## Review evidence locations

- `README.md:112-115`
- `tiktoken/registry.py:40-54`
- `tiktoken/registry.py:85-87`
