# Rule details

- **Rule:**
  ```text
  cibuildwheel skips tests for the *-macosx_arm64 wheel.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
test-skip = "*-macosx_arm64"

```

- **Sources:**
  - `pyproject.toml:39`

## Review evidence locations

- `pyproject.toml:36-39`
