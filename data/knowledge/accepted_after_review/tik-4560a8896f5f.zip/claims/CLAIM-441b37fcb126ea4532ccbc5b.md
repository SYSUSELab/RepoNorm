# Rule details

- **Rule:**
  ```text
  cibuildwheel skips building wheels for the manylinux_i686, musllinux_i686, win32, and musllinux_aarch64 platforms.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
skip = [
  "*-manylinux_i686",
  "*-musllinux_i686",
  "*-win32",
  "*-musllinux_aarch64",
]

```

- **Sources:**
  - `pyproject.toml:30-35`

## Review evidence locations

- `pyproject.toml:30-35`
