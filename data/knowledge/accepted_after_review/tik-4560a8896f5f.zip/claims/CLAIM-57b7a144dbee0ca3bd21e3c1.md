# Rule details

- **Rule:**
  ```text
  The build_wheels_aarch64 job uses pypa/cibuildwheel@v2.22.0 with CIBW_ARCHS set to aarch64.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
        uses: pypa/cibuildwheel@v2.22.0
        env:
          CIBW_BUILD: "cp${{ matrix.python-version}}-*"
          CIBW_ARCHS: aarch64

```

- **Sources:**
  - `.github/workflows/build_wheels.yml:48-51`
