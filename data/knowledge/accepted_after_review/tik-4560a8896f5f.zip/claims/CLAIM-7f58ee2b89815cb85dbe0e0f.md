# Rule details

- **Rule:**
  ```text
  scripts/redact.py must keep redact_file deleting any file whose first line contains 'redact' and otherwise stripping content between redact-beg/redact-end markers (both '#' and HTML comment forms) by splitting on the marker regex and keeping even-indexed segments, with dry_run suppressing all writes/deletes.
  ```
- **Applies to:**
  - `scripts/redact.py`
- **Condition:**
  ```text
  When modifying redact_file's file-selection or marker-stripping logic in scripts/redact.py, preserve the first-line 'redact' deletion rule, the redact-beg/redact-end marker stripping for both comment forms, and dry_run write suppression.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
redact_file deletes files whose first line contains 'redact', strips redact-beg/redact-end marker regions for both '#' and HTML comment forms by splitting on the marker regex and keeping even-indexed segments, and guards writes/deletes with dry_run.
```

- **Sources:**
  - `scripts/redact.py:7-39`
