# Rule details

- **Rule:**
  ```text
  bpe_train must raise ValueError when vocab_size < 2**8, because the algorithm first seeds ranks with one token per byte value (range(2**8)) so all bytes can be encoded.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  When modifying bpe_train or changing the minimum vocabulary size or byte-seeding step.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tiktoken/_educational.py:119-127`
