# Rule details

- **Rule:**
  ```text
  tiktoken/_educational.py must remain an explicitly documented educational implementation of the byte pair encoding algorithm, distinct from the production Rust-backed core.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying tiktoken/_educational.py or its documented purpose
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tiktoken/_educational.py's module docstring explicitly documents it as an educational implementation of the byte pair encoding algorithm, distinct from the production core.
```

- **Sources:**
  - `tiktoken/_educational.py`
