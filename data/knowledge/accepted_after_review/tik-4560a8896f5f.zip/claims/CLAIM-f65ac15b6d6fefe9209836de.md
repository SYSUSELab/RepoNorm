# Rule details

- **Rule:** SimpleBytePairEncoding.decode must decode bytes with errors="replace", so invalid UTF-8 bytes are replaced with the replacement character rather than raising, unlike the strict decoding used elsewhere.
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:** When modifying SimpleBytePairEncoding.decode or changing its error handling for invalid UTF-8.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tiktoken/_educational.py:47-56`
- `tiktoken/core.py:309-331`
