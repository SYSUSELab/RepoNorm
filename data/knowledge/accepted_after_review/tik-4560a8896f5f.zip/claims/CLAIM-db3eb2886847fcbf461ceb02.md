# Rule details

- **Rule:**
  ```text
  A tiktoken extension's setup.py should use find_namespace_packages(include=['tiktoken_ext*']) for its packages.
  ```
- **Applies to:**
  - `setup.py`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

````text
Your `setup.py` should look something like this:
```python
from setuptools import setup, find_namespace_packages

setup(
    name="my_tiktoken_extension",
    packages=find_namespace_packages(include=['tiktoken_ext*']),

````

- **Sources:**
  - `README.md:117-123`

## Review evidence locations

- `README.md:117-126`
