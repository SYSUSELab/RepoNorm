# Rule details

- **Rule:**
  ```text
  Encoding.eot_token must resolve the end-of-text token by looking up the literal special token name "<|endoftext|>" in the encoding's special token map; encodings that do not register that key will raise rather than return a token.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.eot_token or constructing an Encoding whose special token map omits "<|endoftext|>".
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tiktoken/core.py:357-359`
- `tiktoken/core.py:21-24`
- `tests/test_encoding.py:167-172`
