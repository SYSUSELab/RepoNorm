# Rule details

- **Rule:** On Linux, cibuildwheel runs a before-all step that installs Rust via rustup with the minimal profile.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
linux.before-all = "curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal"

```

- **Sources:**
  - `pyproject.toml:25`

## Review evidence locations

- `pyproject.toml:25-26`
- `.github/workflows/build_wheels.yml:17-25`
