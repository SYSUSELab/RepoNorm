# Rule details

- **Rule:**
  ```text
  The build_sdist job runs on ubuntu-latest and installs Python 3.9 via actions/setup-python@v5.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    runs-on: ubuntu-latest
    timeout-minutes: 60
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        name: Install Python
        with:
          python-version: "3.9"

```

- **Sources:**
  - `.github/workflows/build_wheels.yml:63-70`

## Review evidence locations

- `.github/workflows/build_wheels.yml:61-70`
