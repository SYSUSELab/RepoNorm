# Rule details

- **Rule:**
  ```text
  The build_sdist job runs check-manifest -v after installing check-manifest.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Run check-manifest
        run: |
          pip install check-manifest
          check-manifest -v

```

- **Sources:**
  - `.github/workflows/build_wheels.yml:71-74`
