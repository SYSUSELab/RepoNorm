# Rule details

- **Rule:** The crate declares a minimum supported Rust version of 1.57.0.
- **Applies to:**
  - `**/*.rs`
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
rust-version = "1.57.0"

```

- **Sources:**
  - `Cargo.toml:5`
