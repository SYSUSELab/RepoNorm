# Rule details

- **Rule:**
  ```text
  Keep the declared packages as ["tiktoken", "tiktoken_ext"], include py.typed as package_data for tiktoken, and set zip_safe=False in setup.py.
  ```
- **Applies to:**
  - `setup.py`
- **Condition:**
  ```text
  When modifying package declarations, package_data, or zip_safe settings in setup.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
setup.py declares packages=["tiktoken", "tiktoken_ext"], includes py.typed as package_data for tiktoken, and sets zip_safe=False.
```

- **Sources:**
  - `setup.py`
