# Rule details

- **Rule:**
  ```text
  Encoding.__setstate__ must restore a registered encoding by name via tiktoken.registry.get_encoding (copying its __dict__) when the pickled value is a string, otherwise re-initialize from the dict form, matching the __getstate__ optimization.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.__setstate__ or pickle handling, preserve the string-name registry lookup and dict-form re-initialization paths.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Encoding.__setstate__ restores a registered encoding by name via tiktoken.registry.get_encoding (copying its __dict__) when the pickled value is a string, and otherwise re-initializes from the dict form, matching the rule.
```

- **Sources:**
  - `tiktoken/core.py:416-422`
