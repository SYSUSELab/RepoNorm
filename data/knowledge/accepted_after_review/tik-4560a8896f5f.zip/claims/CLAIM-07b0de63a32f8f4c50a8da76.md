# Rule details

- **Rule:**
  ```text
  Encoding.special_tokens_set must be a functools.cached_property returning set(self._special_tokens.keys()), so the special-token set is computed once per Encoding instance.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.special_tokens_set or changing how the special-token set is derived or cached.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tiktoken/core.py:361-363`
- `tiktoken/core.py:113-120`
