# Rule details

- **Rule:**
  ```text
  _available_plugin_modules must be lru_cached and discover encoding constructors by iterating pkgutil.iter_modules over the tiktoken_ext namespace package, relying on the namespace-package pattern for fast iteration and correct editable-install behavior.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  When modifying _available_plugin_modules or changing how plugin modules are discovered or cached.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_available_plugin_modules is decorated with functools.lru_cache and discovers plugin modules via pkgutil.iter_modules over the tiktoken_ext namespace package, matching the required lru_cached namespace-iteration contract.
```

- **Sources:**
  - `tiktoken/registry.py:20-30`
