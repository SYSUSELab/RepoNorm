# Rule details

- **Rule:** The rustc-hash dependency is pinned to version 1.1.0.
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
rustc-hash = "1.1.0"

```

- **Sources:**
  - `Cargo.toml:26`
