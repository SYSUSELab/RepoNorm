# Rule details

- **Rule:** Importing tiktoken must not eagerly import the optional blobfile dependency into sys.modules.
- **Applies to:**
  - `tests/test_misc.py`
- **Condition:** When modifying or adding tests that check optional dependency isolation or the package import behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_optional_blobfile_dependency runs a subprocess asserting blobfile is not in sys.modules after importing tiktoken, conforming to optional dependency isolation.
```

- **Sources:**
  - `tests/test_misc.py:22-28`
