# Rule details

- **Rule:**
  ```text
  Encoding.encode_ordinary must remain equivalent to encode(text, disallowed_special=()) while ignoring special tokens, and must preserve the utf-16 surrogatepass/replace fallback on UnicodeEncodeError.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.encode_ordinary or its special-token handling
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tiktoken/core.py:63-77`
- `tiktoken/core.py:123-133`
- `tests/test_encoding.py:218-223`
- `tests/test_encoding.py:94-102`
