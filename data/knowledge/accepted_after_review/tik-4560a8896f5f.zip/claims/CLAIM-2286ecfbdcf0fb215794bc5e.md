# Rule details

- **Rule:**
  ```text
  Encoding.encode_batch must resolve allowed_special='all' to the encoding's special_tokens_set and disallowed_special='all' to special_tokens_set minus allowed_special, coerce disallowed_special to a frozenset, and encode in parallel with default num_threads=8.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_batch's special-token resolution or parallel encoding defaults.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Encoding.encode_batch resolves allowed_special='all' to special_tokens_set, disallowed_special='all' to special_tokens_set minus allowed_special, coerces to frozenset, and encodes in parallel with default num_threads=8.
```

- **Sources:**
  - `tiktoken/core.py:175-203`
