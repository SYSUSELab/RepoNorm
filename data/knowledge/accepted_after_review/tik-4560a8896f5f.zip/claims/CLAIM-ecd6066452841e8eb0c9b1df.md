# Rule details

- **Rule:**
  ```text
  On macOS, cibuildwheel sets MACOSX_DEPLOYMENT_TARGET to 10.12.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
macos.environment = { MACOSX_DEPLOYMENT_TARGET = "10.12" }

```

- **Sources:**
  - `pyproject.toml:28`

## Review evidence locations

- `pyproject.toml:27-28`
- `.github/workflows/build_wheels.yml:19-27`
