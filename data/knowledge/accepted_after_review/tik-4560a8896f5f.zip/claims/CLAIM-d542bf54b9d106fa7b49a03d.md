# Rule details

- **Rule:**
  ```text
  Encoding.__init__ must compute max_token_value as the max over mergeable_ranks and special_tokens values, and when explicit_n_vocab is provided assert len(mergeable_ranks)+len(special_tokens)==explicit_n_vocab and max_token_value==explicit_n_vocab-1.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.__init__ or vocabulary composition, preserve the explicit_n_vocab consistency assertions and max_token_value computation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Encoding.__init__ computes max_token_value as max over mergeable_ranks and special_tokens values, and asserts len(mergeable_ranks)+len(special_tokens)==explicit_n_vocab and max_token_value==explicit_n_vocab-1 when explicit_n_vocab is provided.
```

- **Sources:**
  - `tiktoken/core.py:17-54`
