# Rule details

- **Rule:**
  ```text
  The build_wheels job builds wheels across ubuntu-latest, windows-latest, and macos-latest with Python versions 39, 310, 311, 312, and 313.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        os: [ubuntu-latest, windows-latest, macos-latest]
        python-version: [39, 310, 311, 312, 313]

```

- **Sources:**
  - `.github/workflows/build_wheels.yml:19-20`

## Review evidence locations

- `.github/workflows/build_wheels.yml:10-20`
- `.github/workflows/build_wheels.yml:23-27`
