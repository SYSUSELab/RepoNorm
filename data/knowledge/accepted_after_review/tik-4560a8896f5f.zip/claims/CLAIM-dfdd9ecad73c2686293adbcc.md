# Rule details

- **Rule:**
  ```text
  Encoding objects must round-trip through pickle: both registry encodings and custom Encoding instances constructed from name/pat_str/mergeable_ranks/special_tokens must encode identically after pickle.loads(pickle.dumps(...)), including special tokens mapping to their assigned ids.
  ```
- **Applies to:**
  - `tests/test_pickle.py`
- **Condition:** When modifying the Encoding class, its constructor, or its serialization-relevant attributes.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_pickle.py exercises pickle round-trip of a registry encoding and a custom Encoding built from name/pat_str/mergeable_ranks/special_tokens, asserting encode equivalence including the special token id.
```

- **Sources:**
  - `tests/test_pickle.py`
