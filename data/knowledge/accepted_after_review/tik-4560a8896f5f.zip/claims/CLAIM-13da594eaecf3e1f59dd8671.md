# Rule details

- **Rule:**
  ```text
  Install the custom tiktoken extension with `pip install ./my_tiktoken_extension` to use custom encodings.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Then simply `pip install ./my_tiktoken_extension` and you should be able to use your

```

- **Sources:**
  - `README.md:129`

## Review evidence locations

- `README.md:129-130`
