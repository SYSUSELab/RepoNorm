# Rule details

- **Rule:** On Linux, cibuildwheel sets PATH to include $HOME/.cargo/bin.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
linux.environment = { PATH = "$PATH:$HOME/.cargo/bin" }

```

- **Sources:**
  - `pyproject.toml:26`

## Review evidence locations

- `pyproject.toml:25-26`
- `.github/workflows/build_wheels.yml:51-54`
