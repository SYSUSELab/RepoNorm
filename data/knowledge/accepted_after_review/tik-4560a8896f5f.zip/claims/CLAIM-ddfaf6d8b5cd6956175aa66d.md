# Rule details

- **Rule:**
  ```text
  Byte-level encoding tests must verify that decode_bytes(_encode_bytes(bytestring)) round-trips arbitrary bytes, including invalid-UTF-8 sequences, using hypothesis property tests with deadline disabled.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When adding or modifying byte-level encoding round-trip tests.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_encoding.py contains test_encode_bytes and test_hyp_encode_bytes asserting decode_bytes(_encode_bytes(bytestring)) == bytestring, including invalid-UTF-8 bytes and a hypothesis property test with deadline disabled, matching the byte-level round-trip convention.
```

- **Sources:**
  - `tests/test_encoding.py`
