# Rule details

- **Rule:** cibuildwheel installs pytest and hypothesis before running tests.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
before-test = "pip install pytest hypothesis"

```

- **Sources:**
  - `pyproject.toml:41`

## Review evidence locations

- `pyproject.toml:41-42`
- `tests/test_encoding.py:5-7`
