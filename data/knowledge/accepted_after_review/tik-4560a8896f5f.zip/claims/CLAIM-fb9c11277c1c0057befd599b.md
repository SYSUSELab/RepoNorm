# Rule details

- **Rule:** Do not use an editable install when installing the custom tiktoken extension.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
custom encodings! Make sure **not** to use an editable install.

```

- **Sources:**
  - `README.md:130`

## Review evidence locations

- `README.md:129-130`
- `tiktoken/registry.py:21-25`
