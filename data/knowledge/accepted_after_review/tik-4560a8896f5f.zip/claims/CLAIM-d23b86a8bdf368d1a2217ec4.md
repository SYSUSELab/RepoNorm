# Rule details

- **Rule:** scripts/benchmark.py must keep its dependency on the optional blobfile package alongside tiktoken, so the benchmark harness continues to import blobfile for its blob-file handling.
- **Applies to:**
  - `scripts/benchmark.py`
- **Condition:** When modifying scripts/benchmark.py imports or dependency handling, preserve the blobfile import alongside tiktoken.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
scripts/benchmark.py imports blobfile alongside tiktoken at module level, conforming to the rule that the benchmark harness keeps its optional blobfile dependency.
```

- **Sources:**
  - `scripts/benchmark.py`
