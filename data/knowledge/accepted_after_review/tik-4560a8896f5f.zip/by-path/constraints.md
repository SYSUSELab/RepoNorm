# Constraints for `.`

## Rule

- **Rule:**
  ```text
  cibuildwheel builds macOS wheels for the x86_64 and arm64 architectures.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09330361778550524b2bcb89.md)

## Rule

- **Rule:** The library target is named "tiktoken".
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1964c86c485658082d42d80f.md)

## Rule

- **Rule:** The crate declares a minimum supported Rust version of 1.57.0.
- **Applies to:**
  - `**/*.rs`
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1fed6dca8794f8d1da59e65c.md)

## Rule

- **Rule:** cibuildwheel builds wheels using the "build" frontend.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-26526b0ac36510164eaa8561.md)

## Rule

- **Rule:**
  ```text
  On macOS, cibuildwheel runs a before-all step that adds the aarch64-apple-darwin and x86_64-apple-darwin Rust targets.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-27409a1f5aaaafc2b1247962.md)

## Rule

- **Rule:** cibuildwheel runs tests with pytest against {project}/tests using --import-mode=append.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3a7974cf645040fdb9925087.md)

## Rule

- **Rule:**
  ```text
  cibuildwheel skips building wheels for the manylinux_i686, musllinux_i686, win32, and musllinux_aarch64 platforms.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-441b37fcb126ea4532ccbc5b.md)

## Rule

- **Rule:** The crate is built with Rust edition 2021.
- **Applies to:**
  - `**/*.rs`
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-509109c529bf9054b771db1a.md)

## Rule

- **Rule:** On Linux, cibuildwheel runs a before-all step that installs Rust via rustup with the minimal profile.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7f5dc5ae5f2dc5a0ddad1f6e.md)

## Rule

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.9 via requires-python = ">=3.9".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8412e9d3f9b891eb7918bb10.md)

## Rule

- **Rule:** When changing the set of special tokens, use a different encoding name, and the name should make the expected behavior clear.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-875dc7b49e7639a6851fa89c.md)

## Rule

- **Rule:** The library target is built as both a cdylib and an rlib.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a6518735f961f449e62e344b.md)

## Rule

- **Rule:**
  ```text
  Register Encoding objects with tiktoken using the tiktoken_ext plugin mechanism, which requires creating a namespace package under tiktoken_ext.
  ```
- **Applies to:**
  - `**`
- **Condition:**
  ```text
  when tiktoken.get_encoding needs to find the encoding
  ```
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-b5c4892c71907cf91b48cc7e.md)

## Rule

- **Rule:**
  ```text
  cibuildwheel skips tests for the *-macosx_arm64 wheel.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bf072377bda36c99a43f6d4b.md)

## Rule

- **Rule:** cibuildwheel installs pytest and hypothesis before running tests.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c8f05cdd82d247d04a3ec931.md)

## Rule

- **Rule:** On Linux, cibuildwheel sets PATH to include $HOME/.cargo/bin.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cef4c9e8beb40d2e05231cb5.md)

## Rule

- **Rule:**
  ```text
  On macOS, cibuildwheel sets MACOSX_DEPLOYMENT_TARGET to 10.12.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ecd6066452841e8eb0c9b1df.md)

## Rule

- **Rule:** Do not use an editable install when installing the custom tiktoken extension.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-fb9c11277c1c0057befd599b.md)
