# Constraints for `tiktoken_ext`

## Rule

- **Rule:**
  ```text
  When laying out a tiktoken extension project, omit the `tiktoken_ext/__init__.py` file.
  ```
- **Applies to:**
  - `tiktoken_ext/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-1812f4ccd30a237ff82300fe.md)

## Rule

- **Rule:**
  ```text
  A tiktoken extension module must contain a variable named ENCODING_CONSTRUCTORS, a dictionary mapping encoding names to zero-argument functions that return arguments passable to tiktoken.Encoding.
  ```
- **Applies to:**
  - `tiktoken_ext/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-1e6cd4c5479ffe2e67d7c6e9.md)
