# Constraints for `tiktoken_ext/openai_public.py`

## Rule

- **Rule:**
  ```text
  ENCODING_CONSTRUCTORS in tiktoken_ext/openai_public.py maps encoding names (gpt2, r50k_base, p50k_base, p50k_edit, cl100k_base, o200k_base) to their constructor functions; adding or renaming an encoding requires updating this mapping consistently with the constructor definitions.
  ```
- **Applies to:**
  - `tiktoken_ext/openai_public.py`
- **Condition:**
  ```text
  When adding, removing, or renaming an encoding constructor or its entry in ENCODING_CONSTRUCTORS in tiktoken_ext/openai_public.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-be772b9f99118f437541aed2.md)
