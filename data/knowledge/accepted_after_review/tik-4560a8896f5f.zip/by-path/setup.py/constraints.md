# Constraints for `setup.py`

## Rule

- **Rule:**
  ```text
  A tiktoken extension's setup.py should use find_namespace_packages(include=['tiktoken_ext*']) for its packages.
  ```
- **Applies to:**
  - `setup.py`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-db3eb2886847fcbf461ceb02.md)

## Rule

- **Rule:**
  ```text
  Keep the declared packages as ["tiktoken", "tiktoken_ext"], include py.typed as package_data for tiktoken, and set zip_safe=False in setup.py.
  ```
- **Applies to:**
  - `setup.py`
- **Condition:**
  ```text
  When modifying package declarations, package_data, or zip_safe settings in setup.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e8d8b56a25af5e5fbe1a9aaf.md)

## Rule

- **Rule:**
  ```text
  Keep the tiktoken._tiktoken Rust extension built through setuptools_rust with Binding.PyO3 and debug=False; the build must always use the release profile because editable installs and performance-sensitive Rust code depend on it.
  ```
- **Applies to:**
  - `setup.py`
- **Condition:**
  ```text
  When modifying the Rust extension build configuration in setup.py, such as changing the setuptools_rust binding, debug flag, or release-profile behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fc4234460155bebf343aac4e.md)
