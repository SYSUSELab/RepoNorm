# Constraints for `.github/workflows/build_wheels.yml`

## Rule

- **Rule:**
  ```text
  The join_artifacts job depends on build_wheels, build_wheels_aarch64, and build_sdist.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-02139cd5106aa7f6f762134c.md)

## Rule

- **Rule:**
  ```text
  The build_wheels job uses pypa/cibuildwheel@v2.22.0 with CIBW_BUILD set to cp${{ matrix.python-version}}-*.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0909c12d17ebaca110754617.md)

## Rule

- **Rule:**
  ```text
  The build_sdist job runs check-manifest -v after installing check-manifest.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-21fd53bcccfb02fecb49c606.md)

## Rule

- **Rule:**
  ```text
  The Build wheels workflow runs on push, pull_request, and workflow_dispatch events.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Condition:**
  ```text
  workflow predicate: [push, pull_request, workflow_dispatch]
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2ba2649feb1267750420691c.md)

## Rule

- **Rule:**
  ```text
  The build_wheels_aarch64 job builds wheels on ubuntu-24.04-arm with Python versions 39, 310, 311, 312, and 313.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44775ecd64d4e8a91564972e.md)

## Rule

- **Rule:**
  ```text
  The build_wheels_aarch64 job uses pypa/cibuildwheel@v2.22.0 with CIBW_ARCHS set to aarch64.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-57b7a144dbee0ca3bd21e3c1.md)

## Rule

- **Rule:**
  ```text
  The join_artifacts job merges artifacts matching pattern cibw-wheels-* into an artifact named cibw-wheels and deletes the merged artifacts.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6f237f9ae682e85c96609612.md)

## Rule

- **Rule:**
  ```text
  The build_sdist job runs on ubuntu-latest and installs Python 3.9 via actions/setup-python@v5.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8363c0f9da36ce8a27ab155e.md)

## Rule

- **Rule:**
  ```text
  The build_sdist job builds the sdist with python -m build --sdist after upgrading the build package.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a227d660302e23009b143c38.md)

## Rule

- **Rule:**
  ```text
  The build_wheels job builds wheels across ubuntu-latest, windows-latest, and macos-latest with Python versions 39, 310, 311, 312, and 313.
  ```
- **Applies to:**
  - `.github/workflows/build_wheels.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a77bc945d2ba58ef04cebd85.md)
