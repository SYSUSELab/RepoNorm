# Constraints for `tests/test_encoding.py`

## Rule

- **Rule:**
  ```text
  Special-token handling must respect disallowed_special and allowed_special parameters: disallowed special tokens raise ValueError, and allowed_special='all' combined with disallowed_special='all' still encodes special tokens.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When modifying or adding special-token handling tests or the encode special-token policy.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0167fedd67af4c132e249430.md)

## Rule

- **Rule:**
  ```text
  Tests that assert equivalence between encode_ordinary(text) and encode(text, disallowed_special=()) must preserve that equivalence for arbitrary text, since ordinary encoding is defined as the special-token-disallowed path.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:**
  ```text
  When modifying or adding property tests that compare encode_ordinary output with encode(..., disallowed_special=()) output.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-14c31ecbebaca5d9a2fd1e59.md)

## Rule

- **Rule:**
  ```text
  Encoding tests must assert exact token ids for known inputs (e.g., 'hello world' for gpt2 and cl100k_base, repeated digit runs for gpt2) and verify per-token round-trip encode_single_token(decode_single_token_bytes(token)) == token across the encoding's vocabulary.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When adding or modifying encoding correctness tests for token id stability or per-token round-trip.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29446dfb5d3d24fd8629fb13.md)

## Rule

- **Rule:** Encoding must handle surrogate pairs and lone surrogates consistently: surrogate-pair form encodes identically to the emoji, and a lone surrogate encodes the same as the replacement character.
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When modifying or adding surrogate handling tests or the encoding implementation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-30d17432315ee9909f221a91.md)

## Rule

- **Rule:** Encoding must produce exact token IDs for specific strings under each encoding, including byte-fallback cases and regex-split-dependent token boundaries.
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When modifying or adding exact tokenization tests or the encoding implementation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3afbb004120bb974c28ac75c.md)

## Rule

- **Rule:**
  ```text
  Byte-level encoding tests must verify that decode_bytes(_encode_bytes(bytestring)) round-trips arbitrary bytes, including invalid-UTF-8 sequences, using hypothesis property tests with deadline disabled.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When adding or modifying byte-level encoding round-trip tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ddfaf6d8b5cd6956175aa66d.md)

## Rule

- **Rule:** Encoding an empty string must return an empty token list.
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When modifying or adding empty-string encoding tests or the encoding implementation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df5417f35e451d643a9335a5.md)

## Rule

- **Rule:**
  ```text
  Batch encoding methods must remain element-wise equivalent to repeated single-item encoding: encode_batch([t]) == [encode(t)] and encode_ordinary_batch([t]) == [encode_ordinary(t)], with no cross-item state or padding effects.
  ```
- **Applies to:**
  - `tests/test_encoding.py`
- **Condition:** When modifying or adding batch encoding methods or their tests in the encoding test module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f3d298fda0eb4a044607480d.md)
