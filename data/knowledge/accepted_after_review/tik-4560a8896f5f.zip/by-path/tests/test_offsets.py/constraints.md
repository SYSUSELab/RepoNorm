# Constraints for `tests/test_offsets.py`

## Rule

- **Rule:**
  ```text
  Token offset tests must compute reference offsets by decoding the full token list with errors='strict' and measuring common prefix length against each prefix decoded with errors='ignore', using the shared _common_prefix_len helper.
  ```
- **Applies to:**
  - `tests/test_offsets.py`
- **Condition:** When adding or modifying token offset assertions in the test suite.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b3f716df4118e53e7b643ac9.md)

## Rule

- **Rule:**
  ```text
  decode_with_offsets must return character offsets into the decoded text that match the canonical reference offset implementation, including repeated offsets when a token spans partial characters.
  ```
- **Applies to:**
  - `tests/test_offsets.py`
- **Condition:**
  ```text
  When modifying or adding offset decoding tests or the decode_with_offsets implementation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ee750ac8e2dd66c5915b31d7.md)
