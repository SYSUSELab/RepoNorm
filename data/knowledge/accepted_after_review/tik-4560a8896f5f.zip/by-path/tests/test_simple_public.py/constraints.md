# Constraints for `tests/test_simple_public.py`

## Rule

- **Rule:**
  ```text
  encoding_for_model must map specific model names to their corresponding encoding names (e.g., gpt2->gpt2, text-davinci-003->p50k_base, text-davinci-edit-001->p50k_edit, gpt-3.5-turbo-0301->cl100k_base).
  ```
- **Applies to:**
  - `tests/test_simple_public.py`
- **Condition:**
  ```text
  When modifying or adding model-to-encoding mapping tests or the encoding_for_model implementation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0fb966d7a8d687b2a5b248c9.md)

## Rule

- **Rule:** The public package surface must be validated through subprocess execution, and importing tiktoken must not eagerly import optional dependencies such as blobfile into sys.modules.
- **Applies to:**
  - `tests/test_simple_public.py`
- **Condition:** When modifying package import-time behavior or adding optional dependencies to the tiktoken package.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e03e59afbb7a1e99795e3dde.md)
