# Constraints for `tests/test_pickle.py`

## Rule

- **Rule:**
  ```text
  Encoding objects must round-trip through pickle: both registry encodings and custom Encoding instances constructed from name/pat_str/mergeable_ranks/special_tokens must encode identically after pickle.loads(pickle.dumps(...)), including special tokens mapping to their assigned ids.
  ```
- **Applies to:**
  - `tests/test_pickle.py`
- **Condition:** When modifying the Encoding class, its constructor, or its serialization-relevant attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dfdd9ecad73c2686293adbcc.md)
