# Constraints for `Cargo.toml`

## Rule

- **Rule:** The bstr dependency is pinned to version 1.5.0.
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-12b692f674d8ea7f6eff2167.md)

## Rule

- **Rule:** The crate declares a minimum supported Rust version of 1.57.0.
- **Applies to:**
  - `**/*.rs`
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1fed6dca8794f8d1da59e65c.md)

## Rule

- **Rule:** The crate is built with Rust edition 2021.
- **Applies to:**
  - `**/*.rs`
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-509109c529bf9054b771db1a.md)

## Rule

- **Rule:**
  ```text
  The `python` feature enables the `pyo3` dependency.
  ```
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7dab78ec5cf26a81d36fec75.md)

## Rule

- **Rule:** The rustc-hash dependency is pinned to version 1.1.0.
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-806ea9516cf2b424f984efde.md)

## Rule

- **Rule:** The regex dependency is pinned to version 1.10.3.
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a846797a20628dc3e110c81a.md)

## Rule

- **Rule:** The pyo3 dependency is declared at version 0.22.2 with default features disabled and the "extension-module" and "macros" features enabled, and is optional.
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-dba260c306c47f64207f2772.md)

## Rule

- **Rule:**
  ```text
  The `default` feature set is empty, so no features are enabled by default.
  ```
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e5fdd6a782e0695378222537.md)

## Rule

- **Rule:** The fancy-regex dependency is pinned to version 0.13.0.
- **Applies to:**
  - `Cargo.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ec244b63b8868f56d332a259.md)
