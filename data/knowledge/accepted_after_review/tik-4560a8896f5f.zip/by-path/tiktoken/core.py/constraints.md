# Constraints for `tiktoken/core.py`

## Rule

- **Rule:**
  ```text
  Encoding.special_tokens_set must be a functools.cached_property returning set(self._special_tokens.keys()), so the special-token set is computed once per Encoding instance.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.special_tokens_set or changing how the special-token set is derived or cached.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-07b0de63a32f8f4c50a8da76.md)

## Rule

- **Rule:**
  ```text
  Encoding.encode_with_unstable must guarantee that text.encode().startswith(decode_bytes(stable_tokens)) and that for every completion sequence, decode_bytes(stable_tokens + seq).startswith(text.encode()).
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.encode_with_unstable or its stable/completion token computation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1261cb13abbb2a858d1785c5.md)

## Rule

- **Rule:**
  ```text
  Encoding.decode_bytes_batch must decode a batch of token sequences using a ThreadPoolExecutor with a default num_threads of 8.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.decode_bytes_batch's concurrency or default thread count.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-19ce06784434281a6ece20ed.md)

## Rule

- **Rule:**
  ```text
  Encoding.encode_batch must resolve allowed_special='all' to the encoding's special_tokens_set and disallowed_special='all' to special_tokens_set minus allowed_special, coerce disallowed_special to a frozenset, and encode in parallel with default num_threads=8.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_batch's special-token resolution or parallel encoding defaults.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2286ecfbdcf0fb215794bc5e.md)

## Rule

- **Rule:**
  ```text
  Encoding.__getstate__ must pickle registered encodings by name when self is the registry's canonical instance for that name, and otherwise serialize name, pat_str, mergeable_ranks, and special_tokens, so unpickling relies on registry identity for the compact form.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.__getstate__ or the registry identity used to decide the compact pickle form.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-234821ad3544e3ee89415dd9.md)

## Rule

- **Rule:**
  ```text
  Encoding.eot_token must resolve the end-of-text token by looking up the literal special token name "<|endoftext|>" in the encoding's special token map; encodings that do not register that key will raise rather than return a token.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.eot_token or constructing an Encoding whose special token map omits "<|endoftext|>".
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-281bae96a3e92ee13ef2ff39.md)

## Rule

- **Rule:**
  ```text
  Encoding.decode_batch must decode a list of token lists in parallel using a ThreadPoolExecutor with default num_threads=8 and pass the configurable errors policy through to decode.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.decode_batch or its threading/error-policy parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3cb0e6afd15009c806938f15.md)

## Rule

- **Rule:** Encoding.decode must keep errors='replace' as the default lossy behavior; callers needing exact byte roundtrips must pass errors='strict', so any change to the default or to the documented lossiness contract is a compatibility break.
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:** When modifying Encoding.decode's error-handling default or its documented roundtrip guarantees.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-474f5b1881dcb8a3c64dd939.md)

## Rule

- **Rule:**
  ```text
  Encoding.encode_ordinary_batch must encode a list of strings in parallel with default num_threads=8, ignoring special tokens, and remain equivalent to encode_batch(text, disallowed_special=()) but slightly faster.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_ordinary_batch's parallel encoding behavior or special-token handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-54cfaa149af1b8155fbbe39f.md)

## Rule

- **Rule:**
  ```text
  Encoding.encode_to_numpy must return a numpy uint32 array built via np.frombuffer over the core BPE buffer, avoiding a copy into a Python list, with numpy imported lazily inside the method.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode_to_numpy's return type or numpy import strategy.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-57b45a1fbdb8b1a6537caebc.md)

## Rule

- **Rule:**
  ```text
  _special_token_regex must remain memoized with lru_cache(maxsize=128) keyed on a frozenset of special tokens, so callers must pass a hashable frozenset and the compiled regex is reused across calls with the same token set.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying _special_token_regex or changing how special-token sets are passed to it.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-64acd7a6ea19b50f7e921716.md)

## Rule

- **Rule:**
  ```text
  Encoding.decode_with_offsets must currently raise on tokens that decode to invalid UTF-8 because it decodes with errors='strict'; this behavior may change to be more permissive in the future.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.decode_with_offsets's error handling for invalid UTF-8 tokens.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-672dde761fdfd689aa894583.md)

## Rule

- **Rule:**
  ```text
  Encoding.__repr__ must return '<Encoding {name!r}>'.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.__repr__ or the Encoding name attribute
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-69150f7e371c6eb0e16e8ca7.md)

## Rule

- **Rule:**
  ```text
  Encoding.decode_bytes must delegate to the core BPE and return raw bytes without performing UTF-8 decoding, as documented by the doctest decode_bytes([31373, 995]) == b'hello world'.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.decode_bytes or changing its return type or decoding behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6da729e492c1918624f3590c.md)

## Rule

- **Rule:**
  ```text
  Encoding.encode_with_unstable must return (stable_tokens, completions) where stable_tokens cover only a substring of the input, and the API must remain documented as unstable.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying encode_with_unstable or its return contract, preserve the partial-stable-token semantics and the unstable API designation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-827e906474643a2b724fa373.md)

## Rule

- **Rule:**
  ```text
  Encoding.n_vocab must remain a backwards-compatibility alias equal to max_token_value + 1; new code should use enc.max_token_value + 1 instead of relying on n_vocab.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding vocabulary-size or max-token-value computation, preserve n_vocab as max_token_value + 1 for backwards compatibility.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-84559a4933f8f9a5c03cebb8.md)

## Rule

- **Rule:**
  ```text
  Encoding.encode_to_numpy must normalize allowed_special="all" to the encoding's special_tokens_set and disallowed_special="all" to special_tokens_set minus allowed_special, raising via raise_disallowed_special_token when a disallowed special token appears in the text.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.encode_to_numpy or its special-token normalization
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8cab644af4df0ee9f4b303f9.md)

## Rule

- **Rule:**
  ```text
  Encoding.__setstate__ must restore a registered encoding by name via tiktoken.registry.get_encoding (copying its __dict__) when the pickled value is a string, otherwise re-initialize from the dict form, matching the __getstate__ optimization.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.__setstate__ or pickle handling, preserve the string-name registry lookup and dict-form re-initialization paths.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9b02c70edaa1cc87d2a08ece.md)

## Rule

- **Rule:**
  ```text
  raise_disallowed_special_token must raise ValueError with remediation guidance: pass allowed_special, set disallowed_special to special_tokens_set minus the token, or use disallowed_special=() to disable checks.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying raise_disallowed_special_token or its error message, preserve ValueError and the documented remediation options.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a7d421321383b8fa05a43d33.md)

## Rule

- **Rule:**
  ```text
  Encoding.encode_single_token must encode text or bytes corresponding to a single token, encode all special tokens, and raise KeyError when the token is not in the vocabulary.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.encode_single_token or its vocabulary lookup
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a8e66a85aeba244f01bc47b7.md)

## Rule

- **Rule:**
  ```text
  Encoding.is_special_token must assert the token is an int and return membership in _special_token_values, so special-token detection is based on the set of special token values rather than token text.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying is_special_token or special-token membership, preserve the int assertion and value-set-based detection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b9c827766f050461a5090c10.md)

## Rule

- **Rule:**
  ```text
  Encoding.decode_with_offsets must return (text, offsets) where each offset is the index into text of the first character containing bytes from that token, clamping to the first character containing the token's bytes when UTF-8 character boundaries do not align with token boundaries.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying decode_with_offsets or its offset computation, preserve the first-character-containing-token-bytes semantics and clamping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c1f21a1fe9440dc52e817e35.md)

## Rule

- **Rule:**
  ```text
  Encoding.encode_ordinary must remain equivalent to encode(text, disallowed_special=()) while ignoring special tokens, and must preserve the utf-16 surrogatepass/replace fallback on UnicodeEncodeError.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding.encode_ordinary or its special-token handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cadafad4ddc8f1e6e1c9b64c.md)

## Rule

- **Rule:**
  ```text
  Encoding.decode_single_token_bytes must decode all special tokens and raise KeyError when the token is not in the vocabulary.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying decode_single_token_bytes or the underlying token-to-bytes mapping, preserve special-token decoding and KeyError on unknown tokens.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d32a0494279c44fb86e89444.md)

## Rule

- **Rule:**
  ```text
  Encoding.__init__ must compute max_token_value as the max over mergeable_ranks and special_tokens values, and when explicit_n_vocab is provided assert len(mergeable_ranks)+len(special_tokens)==explicit_n_vocab and max_token_value==explicit_n_vocab-1.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.__init__ or vocabulary composition, preserve the explicit_n_vocab consistency assertions and max_token_value computation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d542bf54b9d106fa7b49a03d.md)

## Rule

- **Rule:**
  ```text
  Encoding._encode_single_piece must encode text corresponding to bytes without a regex split and must not encode any special tokens.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding._encode_single_piece's encoding behavior or special-token handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d7859b1197a20afefc155b71.md)

## Rule

- **Rule:**
  ```text
  Encoding._encode_only_native_bpe must perform regex splitting in Python by compiling self._pat_str and using regex.findall, then call the core BPE encode_single_piece per piece, serving as the pure-Python reference path distinct from the native encode.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  when modifying Encoding._encode_only_native_bpe or the pure-Python reference path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-de390bbc9b207624c7d977a0.md)

## Rule

- **Rule:**
  ```text
  Encoding.encode must default to disallowed_special='all' and raise on text matching a disallowed special token; allowed_special='all' treats all special-token text as special tokens, disallowed_special=() encodes them as natural text, and UnicodeEncodeError triggers a utf-16 surrogatepass/replace fallback.
  ```
- **Applies to:**
  - `tiktoken/core.py`
- **Condition:**
  ```text
  When modifying Encoding.encode or its special-token handling, preserve the default disallowed_special='all' behavior, allowed_special='all' semantics, disallowed_special=() behavior, and UnicodeEncodeError fallback.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f65d28f284675416a3202eb1.md)
