# Constraints for `tiktoken/model.py`

## Rule

- **Rule:**
  ```text
  encoding_name_for_model must first check exact MODEL_TO_ENCODING membership, then fall back to prefix matching against MODEL_PREFIX_TO_ENCODING, accepting that prefix matching can match non-existent models to avoid library updates per model release.
  ```
- **Applies to:**
  - `tiktoken/model.py`
- **Condition:**
  ```text
  when modifying encoding_name_for_model or the model-to-encoding lookup tables
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c11fa9ac98bc89dc1bbf80e.md)

## Rule

- **Rule:**
  ```text
  encoding_for_model must delegate to encoding_name_for_model and must raise KeyError for an unrecognized model name rather than returning a default encoding.
  ```
- **Applies to:**
  - `tiktoken/model.py`
- **Condition:**
  ```text
  When modifying encoding_for_model's model-name resolution or error behavior for unrecognized models.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ab9a6e5292d9c49599a7cddc.md)

## Rule

- **Rule:**
  ```text
  MODEL_PREFIX_TO_ENCODING and MODEL_TO_ENCODING must define the model-name-to-encoding mapping, including o1/o3 and gpt-4o prefixes to o200k_base, gpt-4/gpt-3.5-turbo to cl100k_base, deprecated text/code models to p50k_base or r50k_base, edit models to p50k_edit, and gpt2/gpt-2 to gpt2.
  ```
- **Applies to:**
  - `tiktoken/model.py`
- **Condition:**
  ```text
  When modifying the model-name-to-encoding mapping in MODEL_PREFIX_TO_ENCODING or MODEL_TO_ENCODING.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bf9677ca063882a022040a2a.md)
