# Constraints for `tiktoken/_educational.py`

## Rule

- **Rule:**
  ```text
  SimpleBytePairEncoding.from_tiktoken must accept either an encoding name string or an Encoding instance and construct the educational BPE from the encoding's _pat_str and _mergeable_ranks, bridging production and educational implementations.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying SimpleBytePairEncoding.from_tiktoken or its input handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0afe16422e534a9c40d801b8.md)

## Rule

- **Rule:**
  ```text
  SimpleBytePairEncoding.__init__ must store pat_str and mergeable_ranks, build a reverse _decoder mapping token bytes to token id, and compile the pattern with regex.compile.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying SimpleBytePairEncoding.__init__ or its decoder/pattern setup
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4b3dc1e93fa1af8b657ba0eb.md)

## Rule

- **Rule:**
  ```text
  bpe_train must repeatedly find the most common adjacent byte pair via collections.Counter, assign it the next token id (len(ranks)), merge it across all words, and loop until len(ranks) reaches vocab_size, with the visualise parameter controlling optional debug printing.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying bpe_train or its merge loop and vocab_size termination
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6ded60e59e6d3953335f0b32.md)

## Rule

- **Rule:**
  ```text
  tiktoken/_educational.py must remain an explicitly documented educational implementation of the byte pair encoding algorithm, distinct from the production Rust-backed core.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying tiktoken/_educational.py or its documented purpose
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8a2786ec2879aadababcbdd3.md)

## Rule

- **Rule:**
  ```text
  bpe_train must raise ValueError when vocab_size < 2**8, because the algorithm first seeds ranks with one token per byte value (range(2**8)) so all bytes can be encoded.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  When modifying bpe_train or changing the minimum vocabulary size or byte-seeding step.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9ecfd519e9508cb0ec4c025c.md)

## Rule

- **Rule:**
  ```text
  SimpleBytePairEncoding.train must be a staticmethod that runs bpe_train on the given data/vocab_size/pat_str and returns a new SimpleBytePairEncoding, providing a training entry point distinct from the production encodings.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:** When modifying SimpleBytePairEncoding.train's training entry point or return value.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d0feab4e61d697cd445bb220.md)

## Rule

- **Rule:**
  ```text
  SimpleBytePairEncoding.decode_bytes must concatenate per-token byte values from the decoder table and return bytes, preserving the byte-level decoding contract (e.g., decode_bytes([388, 372]) == b'hello world').
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:**
  ```text
  when modifying SimpleBytePairEncoding.decode_bytes or the decoder table
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f31a3f2c133c1e27040eae98.md)

## Rule

- **Rule:** SimpleBytePairEncoding.decode must decode bytes with errors="replace", so invalid UTF-8 bytes are replaced with the replacement character rather than raising, unlike the strict decoding used elsewhere.
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:** When modifying SimpleBytePairEncoding.decode or changing its error handling for invalid UTF-8.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f65ac15b6d6fefe9209836de.md)

## Rule

- **Rule:**
  ```text
  SimpleBytePairEncoding.encode must split text with the pattern regex, encode each word's UTF-8 bytes via bpe_encode, and accept a visualise parameter defaulting to 'colour' for the educational BPE path.
  ```
- **Applies to:**
  - `tiktoken/_educational.py`
- **Condition:** When modifying SimpleBytePairEncoding.encode's encoding behavior or visualise parameter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fc0d02326b76d23ca4015bc9.md)
