# Constraints for `tiktoken/__init__.py`

## Rule

- **Rule:**
  ```text
  tiktoken/__init__.py must declare the public API surface (Encoding, encoding_for_model, encoding_name_for_model, get_encoding, list_encoding_names) and set __version__ = '0.9.0'.
  ```
- **Applies to:**
  - `tiktoken/__init__.py`
- **Condition:**
  ```text
  When modifying the public API exports or version in tiktoken/__init__.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-02582c2c63b6bf15c6237df7.md)
