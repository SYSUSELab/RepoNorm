# Constraints for `tiktoken/registry.py`

## Rule

- **Rule:**
  ```text
  _find_constructors must import each available plugin module, require an ENCODING_CONSTRUCTORS attribute (raising ValueError if missing), reject duplicate encoding names across plugins, and reset ENCODING_CONSTRUCTORS to None on any exception so errors are raised idempotently.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  When modifying _find_constructors or changing plugin module validation, duplicate-name handling, or error reset behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-571b6c473cf1e795e600b0a4.md)

## Rule

- **Rule:**
  ```text
  get_encoding must validate the name is a string, return cached ENCODINGS entries, and under a lock lazily call _find_constructors; unknown names must raise ValueError including available plugin modules and tiktoken version.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  When modifying get_encoding's name validation, caching, lazy constructor lookup, or unknown-name error message.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7ef1fb6de1e77a1dc07b80c3.md)

## Rule

- **Rule:**
  ```text
  tiktoken/registry.py must guard the ENCODINGS dict and ENCODING_CONSTRUCTORS with a module-level threading.RLock, ensuring registry access is thread-safe.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  When modifying registry access to ENCODINGS or ENCODING_CONSTRUCTORS.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-87ed6381e4743ed4d629fb6b.md)

## Rule

- **Rule:**
  ```text
  _available_plugin_modules must be lru_cached and discover encoding constructors by iterating pkgutil.iter_modules over the tiktoken_ext namespace package, relying on the namespace-package pattern for fast iteration and correct editable-install behavior.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  When modifying _available_plugin_modules or changing how plugin modules are discovered or cached.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-effdbd640718146f435df7e6.md)

## Rule

- **Rule:**
  ```text
  list_encoding_names must acquire the module _lock, lazily call _find_constructors() when ENCODING_CONSTRUCTORS is None, and return list(ENCODING_CONSTRUCTORS), so constructor discovery is guarded by the registry lock.
  ```
- **Applies to:**
  - `tiktoken/registry.py`
- **Condition:**
  ```text
  when modifying list_encoding_names or the lazy constructor discovery path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f0b703686317425669af3e8d.md)
