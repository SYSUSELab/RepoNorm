# Constraints for `src`

## Rule

- **Rule:** Package data files are included in distributions.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-106f6385437aae68080ab832.md)

## Rule

- **Rule:**
  ```text
  Coverage path configuration sets source to the src directory and to */site-packages.
  ```
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-36127ab56b251febbfed5552.md)

## Rule

- **Rule:** The package root directory is src, so package sources live under src/.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cedfe4563e2ebd602ee2c3b4.md)

## Rule

- **Rule:** Package discovery for the distribution is configured to search under the src directory.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e5b58e9c6e71d5e28b5c5588.md)
