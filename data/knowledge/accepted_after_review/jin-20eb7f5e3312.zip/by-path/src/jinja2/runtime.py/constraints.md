# Constraints for `src/jinja2/runtime.py`

## Rule

- **Rule:** runtime.identity must return its argument unchanged, serving as a pass-through callable documented as useful for certain things in the environment.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When modifying runtime.identity or adding a new pass-through callable used in the environment.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-14ea05f4c49cfd380e045347.md)

## Rule

- **Rule:**
  ```text
  Macro.__call__ raises TypeError when a caller is passed both explicitly and via kwargs, when unknown kwargs are supplied, or when excess positional arguments are given, with error messages naming the specific conflict.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  when modifying Macro.__call__ argument validation or error handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-43edd754d61bb1194a1453b5.md)

## Rule

- **Rule:**
  ```text
  Macro._async_invoke wraps the awaited result in Markup when autoescape is enabled, mirroring the sync call path's escaping behavior.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  when modifying Macro._async_invoke or async macro result escaping
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-838ab99e1e977f65d77679cc.md)

## Rule

- **Rule:**
  ```text
  Macro.__init__ must resolve default_autoescape by calling environment.autoescape(None) when it is callable, otherwise using the boolean value, and store the result as _default_autoescape.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying Macro.__init__ or the default_autoescape resolution path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-863c550f657ec32be69a7322.md)

## Rule

- **Rule:** When modifying the async/sync dispatch layer, preserve the contract that async variants are selected by environment capability and that sync results are wrapped in Markup when autoescape is enabled.
- **Applies to:**
  - `src/jinja2/async_utils.py`
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  Changing macro invocation dispatch or the async_variant decorator's wrapping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b05e69ffe2e7d750bc6cec16.md)

## Rule

- **Rule:**
  ```text
  str_join must define the runtime's canonical string-join semantics: it converts each item to str and concatenates via concat, so iterable joining in templates follows this conversion-and-concatenation behavior.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying str_join or template string-joining behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bd9e8edf73e846e18124865f.md)

## Rule

- **Rule:**
  ```text
  Undefined._undefined_message must prioritize an explicit hint, then distinguish missing-object, non-string-name, and attribute cases to build the error message; custom undefined subclasses must preserve this precedence to keep messages consistent.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When modifying or subclassing undefined error-message construction in the runtime module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c2e5ec31a5bc4d03434131d1.md)

## Rule

- **Rule:**
  ```text
  ChainableUndefined must keep returning the undefined object itself for any attribute access so that chained attribute lookups on undefined values do not raise; do not make __getattr__ raise or return a non-undefined value.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying ChainableUndefined.__getattr__ or the undefined-value attribute-access path in runtime.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ccfe00d2d6f5654f540c62ed.md)

## Rule

- **Rule:**
  ```text
  __repr__ formats as '<ClassName {get_all()!r} of {name!r}>', tying the representation to the object's name and full contents.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  when modifying Context.__repr__ or context representation behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cda0d5555bfb85b755ea63c3.md)

## Rule

- **Rule:**
  ```text
  LoggingUndefined.__str__ must call _log_message(self) before delegating to super().__str__(), so stringifying an undefined value emits a log message as a side effect.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying LoggingUndefined.__str__ or the undefined logging side effect.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d6534d2b08a6e6820770a613.md)

## Rule

- **Rule:**
  ```text
  Undefined.__str__ must return an empty string so undefined values render as empty output rather than raising during string conversion.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying Undefined.__str__ or undefined-value rendering behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e5b6571cc5d144cfc85a5bb0.md)

## Rule

- **Rule:**
  ```text
  When modifying context creation, preserve that new_context with shared=True uses vars directly as the parent dict, copies the parent when locals are supplied with shared=True to avoid mutating the caller's dict, and skips locals whose value is missing.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  Changing new_context's shared-context handling, locals merging, or missing-value filtering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e7a035631c3319d412529ad6.md)

## Rule

- **Rule:**
  ```text
  Context.__contains__ must check membership in both the current vars and the parent context, so name lookup for containment traverses the parent chain.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  when modifying Context.__contains__ or the parent-chain name lookup behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fc5b876dc36409cca4fcedd4.md)

## Rule

- **Rule:**
  ```text
  When modifying Context dict-method proxies, preserve the use of functools.wraps(dict_method) and delegation to dict_method(self.get_all()) so the proxy preserves the wrapped method's metadata while operating on the flattened context.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when modifying Context dict-method proxy generation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fd085b0f7728d85f78570eaa.md)
