# Constraints for `src/jinja2/exceptions.py`

## Rule

- **Rule:** FilterArgumentError subclasses TemplateRuntimeError, so callers catching TemplateRuntimeError will also catch filter-argument errors; this is a compatibility boundary for exception handling.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** when modifying FilterArgumentError or TemplateRuntimeError inheritance
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1cd0166420b1c92d8656f33b.md)

## Rule

- **Rule:** When modifying the exception hierarchy, preserve that TemplateRuntimeError subclasses TemplateError and remains the generic runtime error Jinja may raise.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** Changing TemplateRuntimeError's base class or its role as the generic runtime error.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2c7a1bfaac41e9dd375dc318.md)

## Rule

- **Rule:**
  ```text
  The message property returns self.args[0] when args is non-empty and None otherwise, so exceptions without arguments expose a None message rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** when modifying exception message access behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3ec5961a32d911c9da0a994f.md)

## Rule

- **Rule:** UndefinedError must remain a subclass of TemplateRuntimeError so that contributors catching TemplateRuntimeError also catch undefined-operation failures; this hierarchy is a compatibility boundary for error handling.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** When modifying UndefinedError or the exception hierarchy in the exceptions module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4fcc5459e21bc22cee208033.md)

## Rule

- **Rule:**
  ```text
  TemplateError.__init__ must accept an optional message and forward it to super().__init__, so exceptions may be constructed without a message.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:**
  ```text
  when modifying TemplateError.__init__ or the optional-message exception construction contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-59705d77dcf3d574072ebc3d.md)

## Rule

- **Rule:** TemplateSyntaxError subclasses TemplateError and is the exception raised to signal a problem with the template.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** when modifying template syntax error handling or exception hierarchy
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8773ed432560060a33321252.md)

## Rule

- **Rule:**
  ```text
  TemplatesNotFound builds its default message by joining the names, using each Undefined name's _undefined_message, and passes names[-1] (or None when empty) as the first argument to the parent exception while storing the full list in self.templates.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:**
  ```text
  when modifying TemplatesNotFound.__init__ message construction or argument passing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ea8b7726e9ca56324a1c6509.md)

## Rule

- **Rule:** TemplateAssertionError must subclass TemplateSyntaxError and share its attributes, representing compile-time errors that are not syntax errors.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** when adding or modifying exception classes in jinja2.exceptions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ed25ecc017b8ff5dfb0abf14.md)
