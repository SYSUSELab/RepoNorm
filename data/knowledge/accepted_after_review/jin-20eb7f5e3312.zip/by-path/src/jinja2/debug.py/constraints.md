# Constraints for `src/jinja2/debug.py`

## Rule

- **Rule:**
  ```text
  fake_traceback must synthesize a traceback pointing at template source by compiling a raise statement at the template line number and rewriting the code object's co_name to a template location label; on Python <3.8 it must reconstruct CodeType manually because co_name replacement is unavailable.
  ```
- **Applies to:**
  - `src/jinja2/debug.py`
- **Condition:**
  ```text
  When modifying fake_traceback or template traceback synthesis, including Python-version compatibility handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-31d7a25d4a74d97cb80bca8f.md)

## Rule

- **Rule:**
  ```text
  rewrite_traceback_stack must be called inside an except block; it marks TemplateSyntaxError as translated, clears the old traceback, skips frames decorated with @internalcode, and maps template frames to source line numbers.
  ```
- **Applies to:**
  - `src/jinja2/debug.py`
- **Condition:**
  ```text
  when modifying rewrite_traceback_stack or traceback rewriting behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b2dcdbd676339f715e935ee7.md)
