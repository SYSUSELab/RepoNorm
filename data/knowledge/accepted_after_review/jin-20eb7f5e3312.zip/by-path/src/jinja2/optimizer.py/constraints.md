# Constraints for `src/jinja2/optimizer.py`

## Rule

- **Rule:**
  ```text
  generic_visit folds nodes.Expr nodes via as_const into Const.from_untrusted, catching nodes.Impossible to skip folding; only Expr nodes are folded because folding others causes later errors.
  ```
- **Applies to:**
  - `src/jinja2/optimizer.py`
- **Condition:**
  ```text
  when modifying optimizer constant folding or generic_visit behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c16f8d4889872c6bc3896a9.md)

## Rule

- **Rule:** When modifying the optimizer, preserve that Optimizer subclasses NodeTransformer and accepts an optional Environment stored as self.environment, so optimization is implemented as an AST node transformation pass.
- **Applies to:**
  - `src/jinja2/optimizer.py`
- **Condition:** Changing Optimizer's base class, constructor signature, or environment storage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2270b66ca2fc7299698c23a0.md)

## Rule

- **Rule:** The optimizer module documents a deliberate limitation: because the AST does not carry full scoping information, optimizations such as loop unrolling are not performed, since unrolled loops would have a different scope; a second syntax tree storing scoping rules would be required.
- **Applies to:**
  - `src/jinja2/optimizer.py`
- **Condition:** when modifying optimizer passes or considering scope-dependent optimizations
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8ce06867fe7bcb2e3ebc3b4c.md)
