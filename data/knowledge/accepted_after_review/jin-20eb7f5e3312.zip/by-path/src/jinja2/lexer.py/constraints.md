# Constraints for `src/jinja2/lexer.py`

## Rule

- **Rule:**
  ```text
  When adding or modifying a lexer rule, represent it as a _Rule NamedTuple whose pattern, tokens (string, tuple of strings, or tuple of Failure), and optional command fields follow the existing rule protocol.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** when adding or modifying a lexer rule in the lexer module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-05ac3c57d95b090598751fbd.md)

## Rule

- **Rule:**
  ```text
  TokenStream.next_if must perform a token test and return the next token only if it matches, otherwise None, without consuming input on failure.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  When modifying TokenStream.next_if or token-stream lookahead behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-21704c4e93313fe8b3508e8a.md)

## Rule

- **Rule:**
  ```text
  The lexer module defines operators and reverse_operators with an assertion that len(operators) == len(reverse_operators) ('operators dropped'), and builds operator_re by sorting operator keys by descending length so multi-character operators match before single-character ones.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when modifying lexer operator tables or operator_re construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-687390320271df6c7bfc2619.md)

## Rule

- **Rule:**
  ```text
  compile_rules must build regex rules for comment, block, and variable delimiters plus optional line-statement and line-comment prefixes, then sort them in reverse order by delimiter length so longer delimiters match before shorter ones.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when modifying compile_rules delimiter handling or rule ordering
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-69fe3920bb3d64438f8b672a.md)

## Rule

- **Rule:**
  ```text
  describe_token must return the raw token value for name tokens and otherwise delegate to _describe_token_type, so name tokens are described by their value rather than their type.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when modifying describe_token or token description behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6fcfb194d1157ec248287f09.md)

## Rule

- **Rule:**
  ```text
  _normalize_newlines replaces all newlines in strings and template data with the configured newline_sequence using newline_re, so lexer output depends on the environment's newline setting.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when modifying Lexer._normalize_newlines or newline handling in the lexer
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8563d948c05b4225f88f6b40.md)

## Rule

- **Rule:**
  ```text
  Token.test supports two expression forms: a bare token type compared by string equality, and 'token_type:token_value' compared by splitting on the first colon and matching both type and value; equality rather than identity is used because test_any is usually passed non-interned strings.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** when modifying Token.test or lexer token matching behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a4a1d3eec921dce66f904733.md)

## Rule

- **Rule:**
  ```text
  OptionalLStrip must remain a tuple subclass with __slots__ = () used to mark a lexer state point where lstrip may be applied; instances fail to create without the slots declaration.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When modifying OptionalLStrip or adding a new lexer state marker that must be instantiable.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a55a132d2f1201a90d8890c8.md)

## Rule

- **Rule:** Token must be a NamedTuple with fields lineno:int, type:str, value:str, fixing the lexer token shape consumed by the parser.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** when modifying the Token type or the lexer/parser token interface
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-de76611cac59e7a6c93a5ca1.md)

## Rule

- **Rule:**
  ```text
  TokenStream.__next__ returns the current token and advances by first draining the pushed-back deque, otherwise pulling from the underlying iterator unless the current token is EOF; StopIteration triggers close().
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when modifying TokenStream.__next__ or token stream advancement logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ebe1da0bac4f702ff13bdaa2.md)

## Rule

- **Rule:**
  ```text
  Lexer rule assembly must sort root tag rules by length so longer delimiters (e.g. `<%`) are matched before shorter ones, because `|` is ungreedy; and lstrip_blocks must be suppressed when non-whitespace precedes the newline via lstrip_unless_re.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when adding or reordering lexer tag rules or modifying lstrip_blocks handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fe4c813be55e160de16d986f.md)
