# Constraints for `src/jinja2/utils.py`

## Rule

- **Rule:**
  ```text
  pass_environment must mark a callable with jinja_pass_arg = _PassArg.environment, replacing the older environmentfunction/environmentfilter decorators as of 3.0.0.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  when modifying pass_environment or the environment-passing decorator contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c2b93632ac502f2aefa877d.md)

## Rule

- **Rule:** The cycle helper must raise RuntimeError when constructed with no items, enforcing that at least one item is provided.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when modifying the Cycler constructor or cycle helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1b552c6f0d6ec1267bfb6238.md)

## Rule

- **Rule:**
  ```text
  LRUCache is a MutableMapping intended for small capacities (below roughly 1000) and must not be relied on to scale; __copy__ is aliased to copy.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when modifying LRUCache capacity behavior, mapping protocol, or copy semantics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1d95f4e3d9d05035408f97da.md)

## Rule

- **Rule:**
  ```text
  is_undefined must remain an instance check against Undefined so custom filters and tests (e.g. a custom default filter) can detect undefined variables.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying is_undefined or adding custom filters/tests that must react to undefined variables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3c2f1b78967395e1553bb16f.md)

## Rule

- **Rule:** LRUCache.items must return entries most-recently-used first by reversing the internal queue snapshot, so changes to the cache queue ordering must preserve this reversed iteration order.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying LRUCache storage or iteration methods in the utils module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-42521e79e2a70a5f445685ac.md)

## Rule

- **Rule:**
  ```text
  select_autoescape must normalize enabled and disabled extensions by stripping leading dots and lowercasing them, operating case-insensitively for security reasons, with default_for_string controlling string templates and default controlling unmatched filenames.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying select_autoescape or autoescape extension matching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-567f7565c4de649da6fdef9f.md)

## Rule

- **Rule:** Cycler.next returns the current item and advances pos modulo the number of items, so iteration wraps around the item list.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when modifying Cycler.next or cycler iteration behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8b70c59d785b48c25f9ae6d6.md)

## Rule

- **Rule:**
  ```text
  LRUCache.__setstate__ must update the instance dict and then call _postinit, so unpickling re-runs post-initialization logic.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying LRUCache.__setstate__ or unpickling/post-initialization behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9d38ea4b0312adbc0a300236.md)

## Rule

- **Rule:**
  ```text
  LRUCache.__contains__ must check key membership in the underlying _mapping, defining containment semantics for the cache wrapper.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  when modifying LRUCache.__contains__ or the cache wrapper containment semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aec18691e40c16951b05f94f.md)

## Rule

- **Rule:** Namespace is a container holding arbitrary attributes, initializable from a dictionary or keyword arguments.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when modifying Namespace initialization or attribute storage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b056a06fbb9ee058a9e5e9ae.md)

## Rule

- **Rule:**
  ```text
  The attribute proxy __init__ must use *args/**kwargs with self extracted from args[0] and remaining args stored as a dict, so the proxy can forward arbitrary attribute access without colliding with the proxied object's own attributes.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying the attribute proxy initialization in the utils module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b25f35d6a9d8f7333694169f.md)

## Rule

- **Rule:**
  ```text
  Namespace.__getattribute__ must special-case only "_Namespace__attrs" and "__class__" to bypass the attrs mapping, raising AttributeError for missing names, preserving __class__ for async awaitable checks while keeping other lookups confined to the namespace attrs.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying Namespace attribute lookup in the utils module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b711c0d34d75ab1a1d95633e.md)

## Rule

- **Rule:**
  ```text
  When modifying the LRUCache, preserve that __iter__ yields items in reverse of the internal queue order.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  Changing LRUCache.__iter__'s iteration order or internal queue handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b7296dac21eee496d3c01682.md)

## Rule

- **Rule:**
  ```text
  LRUCache must implement __getnewargs__ returning (self.capacity,) so unpickling reconstructs the cache with its original capacity.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying LRUCache.__getnewargs__ or adding pickle support to cache classes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bd278394f8319c4a95668b35.md)

## Rule

- **Rule:**
  ```text
  open_if_exists must return None when the path is not a regular file and otherwise open it with the given mode (default 'rb'), defining the safe-open helper contract used by loaders.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  when modifying open_if_exists or loader code that relies on its safe-open contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c7bc9ab6cc400b5af0ea32dc.md)

## Rule

- **Rule:** LRUCache.setdefault must return the existing value if the key is present and only insert the default on KeyError, never overwriting existing entries.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying LRUCache.setdefault or cache insertion semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc87b09b832b7a15ef8dab32.md)

## Rule

- **Rule:** The Cycler.reset method must set self.pos = 0, defining the reset contract as returning to the first item.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when modifying Cycler.reset or the cycle helper's iteration state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ccd6a73460a98ae26d554a28.md)

## Rule

- **Rule:**
  ```text
  Cycler.current must return self.items[self.pos], i.e. the item that will be returned by the next call to next.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying Cycler.current or adding a new iterator property that must match the next-item semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e44ea74cacdd84a1ebe13ca5.md)
