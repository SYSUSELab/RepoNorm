# Constraints for `src/jinja2/parser.py`

## Rule

- **Rule:**
  ```text
  Parser.parse_expression must dispatch to parse_condexpr when with_condexpr is true and to parse_or otherwise, so callers can suppress conditional-expression parsing.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.parse_expression or adding a caller that relies on suppressing conditional-expression parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-03ba7d8d20620385e960b8b4.md)

## Rule

- **Rule:**
  ```text
  parse_signature must enforce that a non-default argument cannot follow a default argument, failing with "non-default argument follows default argument", and must set each parsed argument's context to "param".
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** When modifying signature parsing in the parser module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-07a83742e8b02224df14028e.md)

## Rule

- **Rule:**
  ```text
  When modifying Parser.parse_compare, preserve the chaining of comparison operators and in/notin operators into a single Compare node, returning the bare expression when no operators are present.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** when modifying comparison expression parsing in the parser
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0ff25b41f1343bcc02a9bbf6.md)

## Rule

- **Rule:**
  ```text
  parse_list must build a nodes.List from bracket-delimited expressions, allowing trailing commas and empty lists, and must record the opening bracket's line number.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** When modifying list parsing in the parser module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3108e02b534bbccac7e67bac.md)

## Rule

- **Rule:**
  ```text
  Parser.parse_math1 must handle additive operators (add/sub) at a precedence level below parse_concat, using _math_nodes to map token types to AST node classes and constructing each binary node with the left operand's starting lineno.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.parse_math1 or adding a new additive operator that must respect the existing precedence level.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3371939e8969d1471e27d476.md)

## Rule

- **Rule:**
  ```text
  Parser.free_identifier must increment a counter and construct InternalName nodes named fi<N> via object.__new__ plus Node.__init__, so generated internal names are sequential and bypass normal node construction.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.free_identifier or any code that depends on the naming or construction of generated internal identifiers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3ecdd22b0444d368df1636d9.md)

## Rule

- **Rule:**
  ```text
  fail_eof builds an end-token stack from the current parser state and optional end_tokens before delegating to _fail_ut_eof for end-of-template error reporting.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.fail_eof or end-of-template error reporting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-56eebd8868b6919dae8ff8c9.md)

## Rule

- **Rule:**
  ```text
  When modifying the parser's not handling, preserve that parse_not recursively consumes 'not' tokens so repeated 'not not x' nests Not nodes.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  Changing parse_not's recursion or Not node construction for chained negation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e24663f3c69ef95547465e7.md)

## Rule

- **Rule:**
  ```text
  When modifying Parser.parse_assign_target, preserve the enforcement that the parsed target must satisfy can_assign() or fail with a message naming the target node type, and that namespace targets are only parsed when with_namespace is set and the next token is a dot.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** when modifying assignment target parsing in the parser
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5f65f356dc1d947309c39cd0.md)

## Rule

- **Rule:**
  ```text
  Parser.parse_postfix must loop over dot/lbracket/lparen tokens so calls are accepted after both postfix expressions and filters/tests, serving as the shared extension point for chained attribute, subscript, and call syntax.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.parse_postfix or adding chained attribute, subscript, or call syntax
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-749f22dc0c34d18e1b48fd82.md)

## Rule

- **Rule:** Parser is the central parsing class passed to extensions, usable to parse expressions or statements.
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** when modifying Parser or the extension-facing parsing API
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-75af7e9246283b4f6db262d5.md)

## Rule

- **Rule:**
  ```text
  parse_with must build a nodes.With by repeatedly parsing assign targets (setting ctx to 'param') and values separated by commas until block_end, then parse the body up to 'name:endwith' with drop_needle=True.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** When modifying with-statement parsing in the parser module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-789bb441bf930fe51c245e89.md)

## Rule

- **Rule:**
  ```text
  Parser.fail_unknown_tag must delegate to _fail_ut_eof with the tag name and current end-token stack so unknown-tag errors remain human-readable and identify the offending tag.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.fail_unknown_tag or unknown-tag error reporting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7c7351b977f9028fc8a83dd2.md)

## Rule

- **Rule:**
  ```text
  Template test parsing in Parser.parse_test must accept a leading `not` negation, dotted test names, optional call arguments, and a bare-argument form, while explicitly rejecting chained `is` tests with a failure.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.parse_test or the grammar for `is` test expressions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9e4d48137094e2998724698f.md)

## Rule

- **Rule:**
  ```text
  Parser.is_tuple_end must treat variable_end, block_end, and rparen as tuple terminators and additionally accept caller-supplied extra_end_rules via test_any, defining tuple-end detection boundaries.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.is_tuple_end or adding a caller that supplies extra_end_rules.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a14b646275f6437555daa3bf.md)

## Rule

- **Rule:**
  ```text
  parse_filter supports dotted filter names by consuming consecutive dot-name tokens, and supports inline filter parsing via the start_inline flag without consuming a leading pipe token.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.parse_filter or filter-name parsing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a300d721caceae89162cbad8.md)

## Rule

- **Rule:**
  ```text
  Parser.parse_filter_block parses the filter with start_inline=True and then consumes statements until 'endfilter', so filter blocks support inline filter syntax followed by a body.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.parse_filter_block or filter block parsing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aada5e4868a6b66c790264d5.md)

## Rule

- **Rule:**
  ```text
  Parser.__init__ must build self.extensions by iterating environment.iter_extensions() and mapping each extension tag to extension.parse, so extension tags are registered per parser instance.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.__init__ or adding a new extension that registers a parse method under a tag.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bc96ad0dacb0c71f868c12a2.md)

## Rule

- **Rule:**
  ```text
  Parser.parse_primary must treat both lowercase and capitalized spellings as literals: true/True and false/False become Const booleans, none/None become Const None, and adjacent string tokens are concatenated into a single Const with the first token's lineno.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.parse_primary or template literal parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e2e2ed0312392bbf04450ecc.md)

## Rule

- **Rule:** A block marked required must be validated so that its body may contain only whitespace TemplateData nodes or comments; any other content must trigger a parse failure.
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.parse_block or the required-block validation logic in the parser.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ef41e1b70c733059c0f080b6.md)
