# Constraints for `src/jinja2/visitor.py`

## Rule

- **Rule:**
  ```text
  NodeVisitor.__call__ must remain an abstract/overridable dispatch entry point in the visitor protocol.
  ```
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:** When modifying NodeVisitor or adding visitor subclasses that rely on the dispatch entry point.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-577ba1cfe59a56403343d90c.md)

## Rule

- **Rule:**
  ```text
  When modifying NodeVisitor.generic_visit, preserve the recursive visitation of all child nodes when no explicit visitor method exists for a node type.
  ```
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:** when modifying the visitor fallback behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fdab2b7afd3171fe3514e19a.md)
