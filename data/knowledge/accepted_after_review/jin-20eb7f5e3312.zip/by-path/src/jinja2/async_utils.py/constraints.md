# Constraints for `src/jinja2/async_utils.py`

## Rule

- **Rule:**
  ```text
  When modifying auto_await, preserve that it returns common primitive types directly without calling inspect.isawaitable, avoiding awaitable-detection cost for primitives.
  ```
- **Applies to:**
  - `src/jinja2/async_utils.py`
- **Condition:**
  ```text
  Changing auto_await's primitive fast path or awaitable detection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e8938490b2f5c71897d1e38.md)

## Rule

- **Rule:** When modifying the async/sync dispatch layer, preserve the contract that async variants are selected by environment capability and that sync results are wrapped in Markup when autoescape is enabled.
- **Applies to:**
  - `src/jinja2/async_utils.py`
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  Changing macro invocation dispatch or the async_variant decorator's wrapping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b05e69ffe2e7d750bc6cec16.md)
