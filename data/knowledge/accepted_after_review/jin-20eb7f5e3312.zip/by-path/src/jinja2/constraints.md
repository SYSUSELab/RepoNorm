# Constraints for `src/jinja2`

## Rule

- **Rule:**
  ```text
  mypy is configured with strict_equality = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0010b3fbbe2d6f63847d72ca.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with show_error_codes = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0a79e6e034c0239a8b5fd875.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with warn_unused_configs = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-15aa290b85e258c986467655.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with local_partial_types = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-344529d0b4d0934aab05d813.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with python_version = 3.7.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3ef1f77cf86c10a82a7ca131.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with warn_redundant_casts = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7e805cd616202c1b3e7ac341.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with warn_unused_ignores = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7fa53a7dc06d583cfb59d9aa.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with warn_return_any = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b94a05937f7d9d731619cb7.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with no_implicit_reexport = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aa8aed86380a0e95b6b23eb6.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with disallow_untyped_defs = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d514d7d78620da976922a77a.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with disallow_subclassing_any = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d5165bfab69bea394a7f9643.md)

## Rule

- **Rule:** mypy is configured to check the files under src/jinja2.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d974357b7ecf799c8cee2a2c.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with no_implicit_optional = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e254350e865184d8f1164121.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with warn_unreachable = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ea4c030add94a1116e852647.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with disallow_untyped_calls = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f1977e8d48170a14fb92cc38.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with disallow_incomplete_defs = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f53b5689a1f013947a77770c.md)
