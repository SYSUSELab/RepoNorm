# Constraints for `src/jinja2/nodes.py`

## Rule

- **Rule:**
  ```text
  Binary, unary, and comparison operators are mapped to operator functions via _binop_to_func, _uaop_to_func, and _cmpop_to_func, with in/notin implemented as lambdas rather than operator module functions.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying operator mapping tables or operator function resolution
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-092443cb81347591231df3b7.md)

## Rule

- **Rule:** ImportedName must remain an Expr node with a single importname field whose access returns the imported name, and the compiler must optimize imports so they need not be assigned to local variables.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying ImportedName or the compiler's import optimization in the nodes module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0a8aba9875b236f3c07cf5bd.md)

## Rule

- **Rule:** When modifying the Template AST node, preserve its role as the outermost node passed to the compiler with fields=('body',) and body typed as a list of Node.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying the Template AST node definition or its compiler contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4c84ef02509d48ffbb59a25f.md)

## Rule

- **Rule:** MarkSafeIfAutoescape must remain an Expr node with a single 'expr' field that marks the wrapped expression as safe (Markup) only when autoescaping is active.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying MarkSafeIfAutoescape or the autoescape-conditional safety marking it implements.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a7a1ff1822e1edc8b0ad2e1c.md)

## Rule

- **Rule:**
  ```text
  get_eval_context requires that a node passed without an explicit EvalContext has an attached environment; otherwise it raises RuntimeError.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  when modifying get_eval_context or callers relying on implicit context from node.environment
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c8b9cdfd171c15597a2256c8.md)

## Rule

- **Rule:** Sub must be a BinExpr subclass whose operator is '-', mapping the subtraction AST node to its operator string.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying Sub or the subtraction AST node operator mapping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d1b90e33cddcde9a3aee2863.md)

## Rule

- **Rule:** Expr is an abstract base class for all expression nodes, so concrete expression node types must subclass it and Expr must not be instantiated directly.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when adding or modifying expression node types in the AST hierarchy
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d75decbb07520270141b9ce4.md)
