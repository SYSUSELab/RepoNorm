# Constraints for `src/jinja2/loaders.py`

## Rule

- **Rule:**
  ```text
  PackageLoader.get_source returns an up_to_date callable for directory packages based on file mtime, but returns None for zip packages, explicitly treating zip-loaded templates as always current because safely reloading the module on zip mtime change is not done.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  when modifying PackageLoader.get_source freshness or up_to_date behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2ffd5fe4a89f1f5858207baf.md)

## Rule

- **Rule:**
  ```text
  FileSystemLoader.__init__ must normalize searchpath by wrapping non-iterable or str inputs into a list and converting each entry via os.fspath, so a single string path and a sequence of paths are treated equivalently and PathLike objects are supported.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying FileSystemLoader.__init__ or any loader that accepts a searchpath argument.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-468288c5ba10090020e54b65.md)

## Rule

- **Rule:**
  ```text
  ChoiceLoader.list_templates must aggregate templates from all loaders into a set and return them sorted, deduplicating across loaders.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ChoiceLoader.list_templates or adding a new loader that participates in template aggregation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4ac39405fbffd35bd348f1e6.md)

## Rule

- **Rule:**
  ```text
  FileSystemLoader.list_templates must walk every configured searchpath with os.walk(followlinks=self.followlinks), normalize each discovered path to a forward-slash path relative to its searchpath, strip a leading './', deduplicate across searchpaths, and return the sorted result.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying FileSystemLoader.list_templates or the path-normalization/deduplication logic it uses to enumerate templates across searchpaths.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6015408ff6fe2a3bca7a1ed0.md)

## Rule

- **Rule:**
  ```text
  FileSystemLoader's up_to_date check must compare the file's current mtime to the cached mtime, so cache invalidation depends on mtime equality rather than content hashing.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying FileSystemLoader cache invalidation or up_to_date logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-675b6ba8b0254e98fcb88141.md)

## Rule

- **Rule:** PackageLoader supports only packages installed as directories or zip/egg files; PEP 420 namespace packages have limited support with the template directory assumed in one contributor, and zip files contributing to a namespace are unsupported. Since 3.0 it no longer depends on setuptools.
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** when modifying PackageLoader package discovery or template directory resolution
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-69e687bed39720b832a1207a.md)

## Rule

- **Rule:**
  ```text
  When modifying PackageLoader.list_templates, preserve normalization of directory and zip results to forward-slash relative paths, sorting before return, and raising TypeError when a zip import lacks the required _files metadata.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  when modifying PackageLoader.list_templates or its listing behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7b0fda93478a07a514015324.md)

## Rule

- **Rule:**
  ```text
  DictLoader.get_source must return (source, None, uptodate) where uptodate is a closure comparing the current mapping value to the captured source, and must raise TemplateNotFound when the template name is absent.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying DictLoader.get_source or its uptodate/TemplateNotFound behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c2dd799779805a501a9073b4.md)

## Rule

- **Rule:**
  ```text
  ModuleLoader.get_module_filename must derive the module file name from get_template_key(name) plus '.py', coupling module template keys to their generated Python filenames.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ModuleLoader.get_module_filename or module template key/filename generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c9e43765fa6cb46fec2cfe96.md)

## Rule

- **Rule:**
  ```text
  ChoiceLoader.get_source must try each loader in order and return the first successful source, swallowing TemplateNotFound from earlier loaders and raising TemplateNotFound(template) only if all loaders fail.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ChoiceLoader.get_source or the loader-fallback ordering and error-swallowing behavior it implements.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d713f1b441ea0b559ad4643a.md)

## Rule

- **Rule:**
  ```text
  DictLoader.list_templates returns sorted(self.mapping), so template listing order is deterministic and alphabetical.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  when modifying DictLoader.list_templates or template listing order
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ee313a1faf2639f70e580fa1.md)

## Rule

- **Rule:** ChoiceLoader must try each configured loader in order and fall back to the next when a template is not found, enabling user templates to override builtin templates from a different location.
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** When modifying ChoiceLoader or its ordered fallback behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ef82dcdf43a76d9751a40a53.md)
