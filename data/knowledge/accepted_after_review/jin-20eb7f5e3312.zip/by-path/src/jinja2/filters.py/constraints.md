# Constraints for `src/jinja2/filters.py`

## Rule

- **Rule:**
  ```text
  do_float must return the configured default (0.0 by default) when float() raises TypeError or ValueError, so conversion failures are silent rather than propagated.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_float or its default handling for failed numeric conversions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c8285f775995cc2da8851cf.md)

## Rule

- **Rule:**
  ```text
  When modifying sync_do_slice, preserve the distribution of remainder items to earlier slices and the appending of fill_with only to slices at or beyond the remainder count.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when modifying the slice filter implementation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0d2be8c60b46445f18424a76.md)

## Rule

- **Rule:**
  ```text
  do_reverse must reverse strings directly, use reversed() for reversible iterables, fall back to list reversal, and raise FilterArgumentError("argument must be iterable") rather than a bare TypeError when the value is not iterable.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_reverse or the iterable-reversal and error-handling behavior it implements.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-349c4b0d8385772d57bf2503.md)

## Rule

- **Rule:** The safe filter wraps the value in Markup, so it bypasses autoescaping by marking the value as safe.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when modifying the safe filter or autoescaping behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d7a9ab35b8075618de0d032.md)

## Rule

- **Rule:**
  ```text
  do_center must coerce its value through soft_str before centering so non-string inputs are stringified rather than raising, and the default width must remain 80.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_center or other string-centering filters in the filters module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5828ce329fc711d611384444.md)

## Rule

- **Rule:**
  ```text
  do_random catches IndexError from random.choice and returns context.environment.undefined with the message 'No random item, sequence was empty.', so empty sequences yield Undefined rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_random or random filter empty-sequence handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e46141b402802a84246ae1f.md)

## Rule

- **Rule:**
  ```text
  _prepare_attribute_parts must split a dotted string attribute into parts, convert all-digit segments to ints so 'a.0.b' addresses index 0, return an empty list for None, and wrap non-string attrs as a single-element list.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying _prepare_attribute_parts or the attribute-path parsing used by filters that accept dotted attribute strings.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-63e9f06abc2e9eb256e37616.md)

## Rule

- **Rule:**
  ```text
  HasHTML is declared as a te.Protocol used to detect objects with an __html__ method for HTML-safe filter output.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when modifying HasHTML or HTML-safe filter output detection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6b96dac7f0b2131a55a178a5.md)

## Rule

- **Rule:** When modifying the urlize filter, preserve validation of each extra scheme against a URI scheme regex with FilterArgumentError for invalid scheme prefixes, and the merging of nofollow, rel, and policy-based rel parts into a sorted rel attribute.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when modifying the urlize filter or its scheme validation and rel attribute handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6b9c76ea52590522692d03e0.md)

## Rule

- **Rule:**
  ```text
  async_select_or_reject must apply a prepared predicate over an async iterator and yield matching items, serving as the async counterpart of select/reject filter logic.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying async_select_or_reject or the async select/reject filter path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7da0b43699d4633ba71a70f5.md)

## Rule

- **Rule:**
  ```text
  do_wordcount must count words by applying _word_re.findall to soft_str(s) and returning the length, so non-string inputs are stringified rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_wordcount or other word-counting filters in the filters module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-83097a4c4ffd5d82fb9d5afb.md)

## Rule

- **Rule:**
  ```text
  sync_do_sum must support an attribute parameter that maps make_attrgetter over the iterable before summing, and a start parameter (default 0) passed as the initial value to sum.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying sync_do_sum or the sum filter's attribute/start parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8b7768df62a305c4086ce2df.md)

## Rule

- **Rule:**
  ```text
  do_trim strips leading and trailing characters from a value, defaulting to whitespace when chars is None, using soft_str conversion.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_trim or trim filter behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-911f25afbe9336a2bd30c482.md)

## Rule

- **Rule:**
  ```text
  When modifying the upper filter, preserve that do_upper coerces non-string values via soft_str before calling .upper() rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing do_upper's input coercion or error behavior for non-string values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9864899cd94360748c6c2dc0.md)

## Rule

- **Rule:**
  ```text
  When modifying filter argument validation, preserve that do_dictsort accepts only by='key' or by='value' and raises FilterArgumentError for any other value before sorting.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing do_dictsort's accepted by values or its error handling for invalid arguments.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a36046adf954e805a764dcfa.md)

## Rule

- **Rule:**
  ```text
  do_int must parse strings with the given base, otherwise call int(value); on TypeError/ValueError it falls back to int(float(value)) so values like "42.23" convert to 42, and returns the default if that also fails.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_int or the int filter's coercion behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a8ad4487cb9105841c86f89c.md)

## Rule

- **Rule:**
  ```text
  do_select must be defined as an async variant of sync_do_select via @async_variant, delegating to async_select_or_reject, so the async filter mirrors the sync select filter for async iterables.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_select or the async filter variants
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c1ca603856e4034e7db4c9ec.md)

## Rule

- **Rule:**
  ```text
  filters.do_pprint returns pformat(value), pretty-printing a variable for debugging.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_pprint or pretty-printing behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c8198959a8789fff0e82834e.md)

## Rule

- **Rule:**
  ```text
  do_striptags must check for __html__ and call it to obtain the HTML string before stripping tags, so objects implementing the HTML protocol are stripped based on their HTML representation rather than str().
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_striptags or its handling of objects implementing __html__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c9d858ecd1182849dff2eae4.md)

## Rule

- **Rule:**
  ```text
  When modifying the wordwrap filter, preserve that do_wordwrap splits input on existing newlines and wraps each line separately, joining with wrapstring (defaulting to environment.newline_sequence).
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing do_wordwrap's line splitting, per-line wrapping, or join separator behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cb562e678445777c3f0576ee.md)

## Rule

- **Rule:**
  ```text
  do_forceescape must call __html__() when present before escaping, so objects implementing the HTML protocol are escaped from their HTML representation and may be double-escaped.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_forceescape or the HTML-protocol handling it implements before escaping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d1732f94581f69044e9c03ef.md)

## Rule

- **Rule:**
  ```text
  do_map must accept both sync and async iterables, with keyword-only attribute and default parameters, as expressed by its typing overload.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_map's signature, overloads, or sync/async input handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f2fc980d44b237452e28a890.md)

## Rule

- **Rule:**
  ```text
  do_first is wrapped with @async_variant(sync_do_first) and must return environment.undefined('No first item, sequence was empty.') on StopAsyncIteration so empty sequences yield Undefined rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_first or its async variant behavior for empty sequences
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fc347ca9b195ea48db32a84f.md)
