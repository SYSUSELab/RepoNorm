# Constraints for `src/jinja2/bccache.py`

## Rule

- **Rule:**
  ```text
  When modifying BytecodeCache.get_source_checksum, preserve the computation of sha1 of the UTF-8 encoded source as a hex digest, which defines the cache key basis for bytecode caching.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying the source checksum computation for bytecode caching
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0183bf07703eff95178aea00.md)

## Rule

- **Rule:** BytecodeCache.clear is not used by Jinja itself but is expected to be implemented so applications can clear a particular environment's bytecode cache, defining an optional-but-expected extension method.
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying BytecodeCache.clear or the bytecode-cache clearing contract it defines.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-069ed89fa24880a36f4a75f7.md)

## Rule

- **Rule:** When modifying FileSystemBytecodeCache, preserve the platform-specific default cache directory selection: the user's temp directory on Windows and a per-user directory under the system temp directory on UNIX.
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying the default cache directory selection for FileSystemBytecodeCache
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2960ea8fd45ac298535cd4aa.md)

## Rule

- **Rule:**
  ```text
  bccache must define bc_version = 5 and bc_magic combining 'j2' with the pickled version and Python major/minor version, so cached bytecode is invalidated across Python version upgrades.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying bccache version constants or bytecode cache invalidation logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4c56088b57e660c0129f11f8.md)

## Rule

- **Rule:**
  ```text
  FileSystemBytecodeCache must keep the default filename pattern '__jinja2_%s.cache' with %s substituted by the cache key, so multiple caches can safely share one directory.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying FileSystemBytecodeCache filename construction or its default pattern.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4d1508f23330d99aef703ad2.md)

## Rule

- **Rule:**
  ```text
  When modifying the bytecode cache extension point, preserve that BytecodeCache subclasses must override load_bytecode and dump_bytecode, both receiving a Bucket.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  Changing BytecodeCache's documented extension contract or the Bucket interface passed to load_bytecode/dump_bytecode.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-53ac5ccca230a0a19c23d097.md)

## Rule

- **Rule:**
  ```text
  The default bytecode cache directory must be created with mode S_IRWXU and verified via lstat to be a directory owned by the current uid with exactly that mode; any mismatch must call _unsafe_dir(). On Windows the temp dir is used directly, and platforms without os.getuid must also trigger _unsafe_dir().
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying default cache directory creation or verification in the bytecode cache module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-837ec9c7e96aa32629a3b6e8.md)

## Rule

- **Rule:**
  ```text
  load_bytecode only opens and loads the cache file when os.path.exists is true, so a missing cache file is silently ignored rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying bytecode cache loading behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8b30528edc35f36efa9a2c9b.md)

## Rule

- **Rule:** When modifying Bucket or bytecode cache subclasses, preserve the internal checksum assigned by the bytecode cache that automatically rejects outdated cache material, so subclasses do not need to implement cache invalidation themselves.
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying Bucket or bytecode cache subclass invalidation behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8c01508edc7092b580d28227.md)

## Rule

- **Rule:**
  ```text
  Bucket.bytecode_from_string must load bytecode from bytes by wrapping the input in BytesIO and delegating to load_bytecode, defining the bytes-based bytecode loading entry point.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  When modifying Bucket.bytecode_from_string or adding a new bytecode loading entry point.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9e4291591921c15f42a5715b.md)

## Rule

- **Rule:**
  ```text
  FileSystemBytecodeCache must default its directory to _get_default_cache_dir() when none is given and use the pattern "__jinja2_%s.cache" by default.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  When modifying FileSystemBytecodeCache.__init__ or its default directory/pattern configuration.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b4e64e8e4e5c31a39af6a308.md)

## Rule

- **Rule:**
  ```text
  Bucket.load_bytecode must reset the cache when the magic header mismatches, when the stored checksum differs from self.checksum, or when marshal.load raises EOFError/ValueError/TypeError, making stale or corrupt bytecode safely reloadable.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  When modifying Bucket.load_bytecode or bytecode cache validation logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fc24aaa663fe4bb596b1b0f3.md)
