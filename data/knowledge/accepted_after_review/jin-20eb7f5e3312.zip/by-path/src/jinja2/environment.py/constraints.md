# Constraints for `src/jinja2/environment.py`

## Rule

- **Rule:**
  ```text
  Template._get_default_module_async must return a fresh module built from ctx.parent values when ctx has globals not present in self.globals, otherwise lazily create and cache self._module via make_module_async.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Template._get_default_module_async or async module caching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0197c2838251d742ed5c79d6.md)

## Rule

- **Rule:**
  ```text
  Environment.call_filter must delegate to _filter_test_common with is_filter=True and may return a coroutine when the environment is async and the filter supports async execution, so callers must await it if needed.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment.call_filter or the async filter invocation path that may return a coroutine.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-043be92ba9cc079624259d45.md)

## Rule

- **Rule:**
  ```text
  Template.debug_info must parse the internal _debug_info string by splitting on '&' and each entry on '=', returning a list of int pairs, and must return an empty list when no debug info is present.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Template.debug_info or the debug-info encoding/decoding format.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-05e1a6e54f7b474809c0abc9.md)

## Rule

- **Rule:**
  ```text
  Environment.make_globals must return a ChainMap of template-specific globals over environment globals so template-level global changes do not mutate environment globals; callers must not modify globals after a template is loaded.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Environment.make_globals or template global handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-09fe9ed5ec74ac247b60dae4.md)

## Rule

- **Rule:**
  ```text
  Environment._generate must remain an overridable internal hook that delegates to the module-level generate with defer_init and optimized=self.optimized, so subclasses can override code generation without changing the public API.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment._generate or subclassing Environment to customize code generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-15ac455667dbaa7b3ce472bf.md)

## Rule

- **Rule:**
  ```text
  Extension stream-filtering must preserve the protocol that Environment._tokenize applies each extension's filter_stream to the token stream and wraps any non-TokenStream return value in a TokenStream before continuing.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment._tokenize or adding an extension that overrides filter_stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2c65a7c0e006aea8b15f026d.md)

## Rule

- **Rule:**
  ```text
  When writing compiled template files into a zip archive, write_file must set ZipInfo.external_attr to 0o755 << 16 so archived files carry executable permission bits; the non-zip path writes UTF-8 encoded bytes to the target directory.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment.compile_templates.write_file or changing how compiled templates are packaged into zip archives.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-34e63504693125eb24558930.md)

## Rule

- **Rule:**
  ```text
  Environment.get_or_select_template must dispatch by input type: a string or Undefined goes to get_template, an existing Template is returned unchanged, and any other iterable goes to select_template, preserving the documented 2.3 caller contract.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying get_or_select_template or its callers that pass either a template name or a template object
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-54444601494fbca2a1bb785a.md)

## Rule

- **Rule:**
  ```text
  Template.render must detect an async environment and run render_async on an event loop, creating and closing a new loop only when no running loop exists.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when modifying Template.render or the async rendering bridge
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-55fafae20900edc8438c8509.md)

## Rule

- **Rule:** Environment instances may be modified only if they are not shared and no template has been loaded; modifications after the first template load lead to surprising effects and undefined behavior.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** When modifying Environment or documenting/altering post-load mutation behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6216de850bbe423bdf937242.md)

## Rule

- **Rule:**
  ```text
  make_module_async must be used instead of make_module for async execution because module creation can invoke template code; the module attribute is unavailable in async mode.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when creating a module from a template in an async execution context
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-647d4e3c52f352bbcebe578a.md)

## Rule

- **Rule:**
  ```text
  Template.generate and Template.generate_async must preserve the async/sync dispatch contract: when the environment is async-enabled, generate delegates to the async render path (asyncio.run(to_list())) and generate_async raises RuntimeError if the environment is not async-enabled; rendering exceptions must be routed through environment.handle_exception rather than propagated directly.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Template.generate, Template.generate_async, or the async rendering dispatch in the environment module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-65f0bf82a8d5770468452e56.md)

## Rule

- **Rule:**
  ```text
  Environment.handle_exception must delegate to debug.rewrite_traceback_stack and always raise, never returning normally; callers rely on it raising a rewritten exception.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment.handle_exception or its traceback-rewriting behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6e9c37b3258fbea6de7322e9.md)

## Rule

- **Rule:** Template instances are immutable: modifications to a template's attributes or environment after construction are unsupported, and direct construction shares an ephemeral Environment across templates created with the same arguments.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when modifying Template construction, attribute assignment, or environment sharing behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7c214d476766c134571861e4.md)

## Rule

- **Rule:**
  ```text
  Template.is_up_to_date must return True when the internal _uptodate callback is None, otherwise delegate to calling _uptodate(), so absence of a callback means the template is considered current.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Template.is_up_to_date or the _uptodate callback handling it implements.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-85e7860dc5ca5e148c8f0086.md)

## Rule

- **Rule:**
  ```text
  Environment.compile must accept source as str or nodes.Template with optional name and filename, raw literal False, and defer_init, returning CodeType; the overload constrains the raw=False typing path.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** When modifying the compile method signature or overloads in the environment module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8f888537ca814c233c0b17d7.md)

## Rule

- **Rule:**
  ```text
  TemplateModule.__html__ must return Markup(concat(self._body_stream)) so objects exposing __html__ are treated as already-safe HTML and their body stream is concatenated without escaping.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying TemplateModule.__html__ or any code path that treats __html__-exposing objects as safe HTML
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af4d20cd0e756a2f2942da26.md)

## Rule

- **Rule:**
  ```text
  Environment._compile must remain an overridable hook whose default delegates to the built-in compile(source, filename, 'exec'); subclasses and extensions that substitute a different compile method rely on this seam.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment compilation or adding a subclass that overrides _compile to substitute a different compile method.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b34ac32ed02b9e3d6f8bd037.md)

## Rule

- **Rule:**
  ```text
  Template.from_module_dict must be a classmethod that constructs a Template from a module dict and globals by delegating to _from_namespace, serving as the module loader's template-construction entry point.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Template.from_module_dict or the module loader's template construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bf5034bc393950c65e403cd7.md)

## Rule

- **Rule:**
  ```text
  load_extensions must accept either string import paths or Extension classes, import strings via import_string, and key the returned dict by each extension's identifier, instantiating with the environment.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when modifying extension loading, import path handling, or extension identifier keying
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c4e88cc00b33360b903696a4.md)

## Rule

- **Rule:**
  ```text
  Environment.select_template must preserve its documented compatibility boundaries: raise TemplatesNotFound for an empty names list, raise UndefinedError when names is Undefined, return Template objects unchanged, and since 3.0 update cached template globals rather than ignoring new values.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying select_template or its error handling and cached-globals update behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ca53048d413bbd3ab1fe97de.md)

## Rule

- **Rule:**
  ```text
  TemplateModule.__repr__ must produce a stable-per-instance identifier for unnamed templates: when __name__ is None it uses a memory-address-based identifier ('memory:{id:x}') instead of a name.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying TemplateModule.__repr__ or template naming/representation behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cb27636bd91f0578f7676c25.md)

## Rule

- **Rule:**
  ```text
  _from_namespace must build a Template via object.__new__(cls), pull name, __file__, blocks, root, and debug_info from the namespace, and write environment and __jinja_template__ back into the namespace.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Template._from_namespace or namespace-based template reconstruction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cf19283dabdcbe31dd2c5477.md)

## Rule

- **Rule:**
  ```text
  The async to_list helper collects generate_async output into a list, providing the async counterpart to synchronous template rendering.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Template.generate.to_list or async template rendering helpers
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d7b4df4d209b35065d1e9006.md)

## Rule

- **Rule:**
  ```text
  Environment.lexer must remain a property that returns get_lexer(self), so lexer construction is derived from the environment rather than stored directly.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** When modifying Environment.lexer or lexer construction behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dd751d3a775f5fc896b761e2.md)

## Rule

- **Rule:**
  ```text
  Environment._load_template must key the cache by (weakref.ref(self.loader), name); on a cache hit with auto_reload disabled or an up-to-date template it must update template.globals with the passed globals and return the cached template, otherwise load and store the template.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Environment._load_template or the template cache
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f1260d1652b98e6ee19a5fdc.md)

## Rule

- **Rule:**
  ```text
  Environment.add_extension must update the environment's extensions mapping via load_extensions so extensions can be registered after environment creation.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment.add_extension or the post-creation extension registration path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f1be17523229e5c3c58197b5.md)

## Rule

- **Rule:**
  ```text
  Filter and test dispatch must resolve the callable from the environment map, raise TemplateRuntimeError for unknown names, and inject context, eval_context, or environment as the first argument according to the callable's pass-arg marker.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment._filter_test_common or adding a new filter/test that relies on pass_context, pass_eval_context, or pass_environment.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ff5c554ca369e7e1f55730f9.md)
