# Constraints for `src/jinja2/sandbox.py`

## Rule

- **Rule:**
  ```text
  SandboxedEnvironment must set sandboxed=True and expose default_binop_table/default_unop_table plus intercepted_binops/intercepted_unops frozensets; only operators added to the intercepted sets may be delegated to call_binop/call_unop, and interception is documented as slower than native operators.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When modifying SandboxedEnvironment or adding operators to the intercepted binop/unop sets.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0eacf81037002b3ac47d982e.md)

## Rule

- **Rule:**
  ```text
  The @unsafe decorator must set the unsafe_callable attribute to True on the decorated function or method, which the sandbox inspects to deny calls.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying the @unsafe decorator or adding sandbox checks that rely on the unsafe_callable marker.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1fcfeee568d43ed76c464a7c.md)

## Rule

- **Rule:**
  ```text
  call_unop must dispatch intercepted unary operators through unop_table keyed by operator name, so customizing unary operator behavior requires overriding call_unop or the table entry.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When modifying unary operator interception in the sandbox module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-338c046bfb6d5c409d78c486.md)

## Rule

- **Rule:**
  ```text
  _mutable_spec enumerates mutable methods for MutableSet, MutableMapping, MutableSequence, and deque, defining which mutating operations the sandbox blocks.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  when modifying _mutable_spec or sandbox mutable method blocking
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5485c54fda9903f474bc445e.md)

## Rule

- **Rule:**
  ```text
  Sandboxed format_string routes str.format/format_map through a sandboxed formatter; when format_func.__name__ == "format_map" it enforces exactly one positional argument and no kwargs, raising TypeError otherwise, and preserves the original string type (e.g. Markup) on the result.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** when modifying sandboxed string formatting behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-60da3bfd24dd33ef85d2d10f.md)

## Rule

- **Rule:**
  ```text
  When modifying inspect_format_method, preserve the restriction that it returns the bound string only when the callable is a MethodType or BuiltinMethodType named 'format' or 'format_map' and its __self__ is a str; otherwise return None.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** when modifying format-method inspection in the sandbox
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-62280aaf6b6905f10d648779.md)

## Rule

- **Rule:**
  ```text
  SandboxedEnvironment.getitem falls back from item subscription to attribute access only for string arguments, and returns unsafe_undefined when the attribute is not safe.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** when modifying sandboxed item/attribute access behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-86a33cc78c12d3cd021ae787.md)

## Rule

- **Rule:** SandboxedEscapeFormatter must combine SandboxedFormatter and EscapeFormatter via multiple inheritance with no overrides, so its behavior is entirely the MRO composition of the two bases.
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When modifying SandboxedEscapeFormatter or sandbox formatter composition.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dc5eae42ecf59e1f278f7be7.md)

## Rule

- **Rule:**
  ```text
  ImmutableSandboxedEnvironment must behave like SandboxedEnvironment but forbid modifications to builtin mutable list, set, and dict objects via modifies_known_mutable.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When modifying sandbox immutability behavior in the sandbox module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eaf02bddf27d5153e2950cc9.md)

## Rule

- **Rule:**
  ```text
  When modifying sandboxed call handling, preserve that SandboxedEnvironment.call first checks for a format method and routes to format_string, otherwise verifies is_safe_callable and raises SecurityError.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** Changing sandboxed call dispatch, format-method routing, or safety verification.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ebc4dbe2548c9431530a4b9e.md)
