# Constraints for `src/jinja2/tests.py`

## Rule

- **Rule:**
  ```text
  test_boolean must return value is True or value is False, so only the exact bool singletons count as boolean, not truthy values.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  When modifying test_boolean or the boolean test semantics used by templates.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1eedd85be53da259df4584d3.md)

## Rule

- **Rule:**
  ```text
  test_defined returns not isinstance(value, Undefined), so definedness is determined by Undefined type membership rather than truthiness.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_defined or definedness checks
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3c0e3931c3ec4a16cd3c0533.md)

## Rule

- **Rule:**
  ```text
  tests.test_divisibleby returns value % num == 0, defining the divisibleby test semantics.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_divisibleby or divisibleby test semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e64b987cda0db2877a55c32.md)

## Rule

- **Rule:**
  ```text
  The `number` test must be defined as isinstance(value, Number), so it accepts any registered numbers.Number (including complex and Decimal), not just int/float.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  When modifying the `number` test or adding a new numeric test that must match the existing acceptance criteria.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-603a55430c63ec95b8a59464.md)

## Rule

- **Rule:**
  ```text
  test_integer must return True only for int instances that are not True and not False, explicitly excluding booleans from the integer test despite being int subclasses.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_integer or the boolean-exclusion behavior of the integer test
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9a522a0c9daf1f61607dae0f.md)

## Rule

- **Rule:** When modifying the sameas test, preserve the use of identity comparison (value is other) rather than equality.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** when modifying the sameas test implementation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a5e789b6561bf1fd8fdeff49.md)

## Rule

- **Rule:**
  ```text
  test_lower must coerce the value with str before calling islower(), so non-string values are stringified before the lowercase check.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_lower or the stringification behavior of the lowercase test
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a7ced2b43912a1785d553c34.md)

## Rule

- **Rule:**
  ```text
  test_odd returns value % 2 == 1, so negative odd integers (e.g. -3) evaluate as not odd under this implementation.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_odd or odd-number test semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d39cff91ebdf5f01328c6971.md)
