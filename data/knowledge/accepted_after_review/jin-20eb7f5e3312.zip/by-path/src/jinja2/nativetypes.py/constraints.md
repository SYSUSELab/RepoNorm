# Constraints for `src/jinja2/nativetypes.py`

## Rule

- **Rule:**
  ```text
  When modifying NativeTemplate.render_async, preserve the RuntimeError when the environment is not in async mode and the concatenation of async-rendered chunks via environment_class.concat with exceptions routed through handle_exception.
  ```
- **Applies to:**
  - `src/jinja2/nativetypes.py`
- **Condition:**
  ```text
  when modifying NativeTemplate.render_async or its async rendering behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-23a0b8ddb5c7e211943613ab.md)

## Rule

- **Rule:**
  ```text
  NativeTemplate binds NativeEnvironment as its environment_class, and NativeEnvironment binds NativeTemplate as its template_class at module import, so native rendering behavior is selected by the environment's template class rather than a separate render path.
  ```
- **Applies to:**
  - `src/jinja2/nativetypes.py`
- **Condition:** when modifying NativeTemplate or NativeEnvironment class bindings or native rendering selection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5bedc08ccc6f3dac819108df.md)
