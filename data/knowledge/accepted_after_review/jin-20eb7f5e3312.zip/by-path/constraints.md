# Constraints for `.`

## Rule

- **Rule:**
  ```text
  For the jinja2.defaults module, mypy's no_implicit_reexport check is disabled (set to False).
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-01c1b13e05f861c14a992c15.md)

## Rule

- **Rule:**
  ```text
  The Tests workflow runs on pull requests targeting the main branch and branches matching '*.x'.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-041b34b365f82d12719ff2ce.md)

## Rule

- **Rule:** Run the basic test suite with pytest.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-053c9c5fdae0b2d57e1d6dc6.md)

## Rule

- **Rule:** The tox testenv:style environment depends on the pre-commit package.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-06e8d0ac20650bed261471d3.md)

## Rule

- **Rule:** YAML, JSON, JavaScript, CSS, and HTML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-06f3a771a8b8ffcfd8aadd95.md)

## Rule

- **Rule:** The reorder-python-imports pre-commit hook runs with --application-directories src.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09fd98fa6b89c2d85784eb2b.md)

## Rule

- **Rule:** The pip-compile-multi-verify pre-commit hook is configured.
- **Applies to:**
  - `**/*.in`
  - `**/*.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0b8ce236e358cf7568dbfb68.md)

## Rule

- **Rule:** Use Black to format code; Black and other tools run automatically if pre-commit is installed.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-116583b34d6a45f8c17a37aa.md)

## Rule

- **Rule:**
  ```text
  Pull requests must link to the issue being addressed using ``fixes #123``.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1a7bf488820434ddf63b019f.md)

## Rule

- **Rule:** Read the Docs builds use Ubuntu 20.04 as the build OS.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1ba3c9477127f0f840e7d62e.md)

## Rule

- **Rule:**
  ```text
  Clone the main repository locally with `git clone https://github.com/pallets/jinja` and `cd jinja`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-342addb392664f67450f3f36.md)

## Rule

- **Rule:** Read the Docs installs the repository itself via pip from the current directory.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3503130396900f69e66037a8.md)

## Rule

- **Rule:**
  ```text
  Configure git with your username and email using `git config --global user.name 'your name'` and `git config --global user.email 'your email'`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-36826240ed72593568e7a900.md)

## Rule

- **Rule:** The tox testenv environment runs tests with pytest -v --tb=short --basetemp={envtmpdir} {posargs}.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-41a45f616301627f1c4685c8.md)

## Rule

- **Rule:** flake8 selects the B, E, F, W, B9, and ISC rule codes.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4b35c6b90cc144c1c44a24e2.md)

## Rule

- **Rule:** Files in the repository have a maximum line length of 88 characters.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4b44b1ad5c81a84596044a75.md)

## Rule

- **Rule:**
  ```text
  Open ``htmlcov/index.html`` in a browser to explore the coverage report.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-4ecc59fd6ccdc85ad02998b4.md)

## Rule

- **Rule:** Coverage measurement is configured to track branch coverage.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5c3fefa05d67fda8a6e95d75.md)

## Rule

- **Rule:**
  ```text
  Add your fork as a remote named "fork" with `git remote add fork https://github.com/{username}/jinja`, replacing `{username}` with your username.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-60a7e3e4638e2e3059875df3.md)

## Rule

- **Rule:** The pre-commit configuration enables the trailing-whitespace hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6774d237bc15edb7fc9011d5.md)

## Rule

- **Rule:**
  ```text
  For the mypy-markupsafe module, mypy's no_implicit_reexport option is set to False.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-70a7d88c3d3393acdb2b6994.md)

## Rule

- **Rule:**
  ```text
  The mypy cache step runs only when the matrix tox value is 'typing', caching ./.mypy_cache keyed by mypy, the matrix Python version, and the hash of setup.cfg.
  ```
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: matrix.tox == 'typing'
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-768016ef5f98cae3c65833db.md)

## Rule

- **Rule:**
  ```text
  The setup-python step uses the matrix Python version and caches pip dependencies based on requirements/*.txt.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-782888dfa0f20b7802853a35.md)

## Rule

- **Rule:**
  ```text
  Create a virtualenv with `python3 -m venv env` and activate it with `. env/bin/activate`; on Windows activation is `env\Scripts\activate`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-7b9032569e8d5fabd9a8083e.md)

## Rule

- **Rule:** Files in the repository are configured to trim trailing whitespace.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-80dfb5def178e436e9bc8468.md)

## Rule

- **Rule:** The pre-commit configuration enables the fix-byte-order-marker hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-84e36d72633e2268c49557e2.md)

## Rule

- **Rule:** The flake8 pre-commit hook declares the additional dependency flake8-bugbear.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-89fe9e5726507c739f744520.md)

## Rule

- **Rule:** Contributors submitting a feature addition or change branch off of the "main" branch.
- **Applies to:**
  - `**`
- **Condition:** when submitting a feature addition or change
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-8cf15280160c7fe1feab8b6d.md)

## Rule

- **Rule:** Read the Docs builds use Python 3.10.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-93ea673b63c1209e889d3fa3.md)

## Rule

- **Rule:** The tox testenv environment installs its dependencies from requirements/tests.txt.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9839e4c73674561a8bfe1953.md)

## Rule

- **Rule:** Files in the repository are configured to insert a final newline.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9df24b81a4801827d84d0113.md)

## Rule

- **Rule:** flake8 ignores E203, E501, E722, and W503.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a4cdf2dba99afcbd5315e4ab.md)

## Rule

- **Rule:** Code changes must include tests that cover them, and the test must fail without the patch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-aa0ac9c4a76bc8733ae98a1d.md)

## Rule

- **Rule:**
  ```text
  The reorder-python-imports pre-commit hook declares the additional dependency setuptools>60.9.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ad832052fba2c5e9bdb936bd.md)

## Rule

- **Rule:** The pre-commit configuration enables the end-of-file-fixer hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-af2575db3adc36ae5436ad44.md)

## Rule

- **Rule:** The tests job installs tox and runs the tox environment selected by the matrix's tox value.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-af49c8f0ff0ce48b323f4b10.md)

## Rule

- **Rule:** Contributors submitting a bug or documentation fix branch off of the latest ".x" branch.
- **Applies to:**
  - `**`
- **Condition:** when submitting a bug or documentation fix
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-b57a2196de3b0f3e02df13bc.md)

## Rule

- **Rule:**
  ```text
  The Tests workflow's push and pull_request triggers ignore changes to docs/**, *.md, and *.rst files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bc9e265e5f424bae92104287.md)

## Rule

- **Rule:** The tox default environment list consists of py3{11,10,9,8,7}, pypy3{8,7}, style, typing, and docs.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cca723fde6f193491e8225ce.md)

## Rule

- **Rule:** Files in the repository use LF line endings.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d0341147455206bb31562207.md)

## Rule

- **Rule:** Tox skips environments whose interpreter is missing.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d47d2a11c4aae139b1969e91.md)

## Rule

- **Rule:** The tox testenv:typing environment runs mypy as its command.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d74c996afe204ab298df37db.md)

## Rule

- **Rule:** The tests job's update pip step upgrades wheel, setuptools, and pip.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ddeeb3a2049691ea7c79d07b.md)

## Rule

- **Rule:**
  ```text
  The tox testenv:style environment sets skip_install to true.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-de7043724ca778c8b8a85953.md)

## Rule

- **Rule:** flake8 enforces a maximum line length of 80.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e06ab2a82b69f8e8da990be4.md)

## Rule

- **Rule:** Files in the repository use space indentation.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ee0c006dda37499252bcd555.md)

## Rule

- **Rule:**
  ```text
  The Tests workflow runs on pushes to the main branch and branches matching '*.x'.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f04681d158c44f269bd08435.md)

## Rule

- **Rule:** Add an entry in CHANGES.rst using the same style as other entries, and include .. versionchanged:: inline changelogs in relevant docstrings.
- **Applies to:**
  - `**/*.py`
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-f0ae02b75773e8a67e835e6f.md)

## Rule

- **Rule:**
  ```text
  Install the pre-commit hooks with `pre-commit install`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-f12c6844f0d15c027af495a9.md)

## Rule

- **Rule:** Read the Docs documentation builds fail on Sphinx warnings.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f6ae08097835eec91bc1ec12.md)

## Rule

- **Rule:** Read the Docs builds documentation with the dirhtml Sphinx builder.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fad66933d734b4ae134bbb40.md)

## Rule

- **Rule:** Files in the repository use UTF-8 charset.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fdd33609312cd73b308913eb.md)
