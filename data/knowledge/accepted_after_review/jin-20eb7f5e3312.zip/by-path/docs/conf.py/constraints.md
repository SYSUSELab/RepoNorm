# Constraints for `docs/conf.py`

## Rule

- **Rule:**
  ```text
  The docs build configuration must derive `release`/`version` from `pallets_sphinx_themes.get_version("Jinja2")`, set `html_title` to `f"Jinja Documentation ({version})"`, and embed the version in the LaTeX output filename.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:** When modifying the docs build configuration's version derivation, HTML title, or LaTeX output filename.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-564d67bfd73a8dd5caf1d1e0.md)
