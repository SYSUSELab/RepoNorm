# Constraints for `docs`

## Rule

- **Rule:** The docs tox environment builds HTML documentation with sphinx-build, treating warnings as errors (-W) and writing doctrees and HTML output under the environment temp directory.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-27ca6d121c90b463dcc56f78.md)

## Rule

- **Rule:**
  ```text
  The built documentation output is viewed by opening `_build/html/index.html` in a browser.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4bec65a1593e9699d14a3131.md)

## Rule

- **Rule:**
  ```text
  Running `make <target>` in docs/ invokes Sphinx via `$(SPHINXBUILD) -M <target> "$(SOURCEDIR)" "$(BUILDDIR)" $(SPHINXOPTS) $(O)`, forwarding the target name as the Sphinx builder.
  ```
- **Applies to:**
  - `docs/**`
- **Condition:** command target: %
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-79a1f58eb4b0950b0e85aa23.md)
