# Constraints for `docs/examples/inline_gettext_extension.py`

## Rule

- **Rule:** The documented inline gettext extension requires the i18n extension to be loaded and configured, establishing a cross-extension dependency contract for inline gettext blocks.
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:** When modifying the inline gettext extension's documented requirements or its interaction with the i18n extension.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b4546f41d032dc7272497b8c.md)

## Rule

- **Rule:** The documented inline gettext extension's stream filter must track parenthesis nesting to decide when to emit trans/endtrans block tokens around gettext expressions, handle escaped parentheses, and raise TemplateSyntaxError("unclosed gettext expression") when the stream ends with an unbalanced paren stack.
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:**
  ```text
  When modifying the inline gettext extension's filter_stream or its parenthesis/trans-block handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e54a74112f5d0f8f9140b80c.md)
