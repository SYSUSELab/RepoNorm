# Constraints for `docs/examples/cache_extension.py`

## Rule

- **Rule:**
  ```text
  The documented cache extension must build its cache key from `fragment_cache_prefix` plus the fragment name, return the cached value when present, and otherwise call `caller()` and store the result with the configured timeout.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** When modifying the cache extension's fragment caching helper or its key/timeout handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-72847e1b8240c18574cb87bf.md)

## Rule

- **Rule:**
  ```text
  The documented cache extension must call `super().__init__(environment)` and register `fragment_cache_prefix` and `fragment_cache` defaults via `environment.extend`.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** When modifying the cache extension's initialization or its environment defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8afe274747ccacaae3c3a699.md)

## Rule

- **Rule:**
  ```text
  The documented cache extension's tag parser must consume the tag name token for line numbers, parse an optional comma-separated timeout expression, parse the block body up to `endcache`, and return a CallBlock node invoking the extension helper.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** When modifying the cache extension's tag parser or its block/endcache handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a6b21800e32499dc48fb4cf3.md)
