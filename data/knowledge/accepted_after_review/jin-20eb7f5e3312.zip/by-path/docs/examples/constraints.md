# Constraints for `docs/examples`

## Rule

- **Rule:**
  ```text
  Custom Jinja extensions in docs/examples must register their template tags by declaring a `tags` set on the Extension subclass; the tag name in that set is the name the parser dispatches on.
  ```
- **Applies to:**
  - `docs/examples/*.py`
- **Condition:** When adding or renaming a template tag provided by a documented example extension.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dd8d1b1a7325866ff142dcb2.md)
