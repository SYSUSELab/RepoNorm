# Constraints for `tests/test_async.py`

## Rule

- **Rule:** Macro scoping tests must assert that macro definitions are scoped separately from loop variables so a loop variable and a macro with the same name do not collide.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying tests for macro and loop variable name collisions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-00f3f102a492bbb97642f58a.md)

## Rule

- **Rule:** Tests that exercise Jinja's async rendering with ChainableUndefined must assert that chained undefined access over an empty dict renders as an empty string rather than raising, because this defines the safe-chaining contract for async rendering.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying tests for async rendering with ChainableUndefined and chained undefined access
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0783c67f0c444dd95712b827.md)

## Rule

- **Rule:** Tests for recursive for-loops must verify that loop.depth starts at 1 and increments per recursion level, with rendered output encoding depth and item values.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** when modifying or extending async for-loop tests for recursive depth tracking
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-17dfaa27fcd1213e24f42f31.md)

## Rule

- **Rule:**
  ```text
  Async test fixtures must construct an Environment with enable_async=True and a DictLoader providing the shared module/header/o_printer templates and global 'bar'.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When adding or modifying async test fixtures in tests/test_async.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2054c8339be92a54ca64ffb8.md)

## Rule

- **Rule:**
  ```text
  Async template rendering must preserve incremental streaming semantics: Template.generate with enable_async=True returns an iterator whose first next() yields the first chunk and whose remaining chunks can be joined, rather than only producing full-render output.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying async template rendering or the async iteration protocol exercised by tests/test_async.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2d753814576d5b6b77b5a2bb.md)

## Rule

- **Rule:** Recursive loop tests must assert that loop.depth0 starts at 0 for the outermost recursive loop and increments per recursion level.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying tests for recursive loop depth tracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4d0db1b79ce51e594042609c.md)

## Rule

- **Rule:** Async loop scope tests must assert that a loop variable (item) is not visible after the for loop ends, rendering empty output when referenced outside the loop.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying the async loop scope test in the async test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-886ee0da092e4985298348aa.md)

## Rule

- **Rule:**
  ```text
  Async macro tests must assert that a macro containing an awaited async function call renders correctly under enable_async.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying or adding async macro await tests in tests/test_async.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a46e2b54ee3e12538ad38b1c.md)

## Rule

- **Rule:**
  ```text
  Async loop filter tests must assert that 'for item in range(10) if item is even' yields [0][2][4][6][8] and that loop.index inside the filtered loop is 1-based over the filtered sequence, producing [1:0][2:2][3:4][4:6][5:8].
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying the async loop filter test in the async test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a94293f6919a09b16b9f017e.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_async.py that exercise async rendering must assert that normal sync callables remain usable alongside async ones, rather than only checking that async rendering succeeds.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When adding or modifying an async rendering test in tests/test_async.py that mixes async and normal sync callables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c9e02daa957e6f517942a175.md)

## Rule

- **Rule:**
  ```text
  Async template rendering tests must preserve the expected output format for for-loop templates rendered with enable_async=True, where iterating [1,2,3] yields the concatenated string "[1][2][3]".
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying or extending async template rendering tests in tests/test_async.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f82c92b8d36b21a01a912db9.md)

## Rule

- **Rule:**
  ```text
  Tests for async getitem-after-call must preserve the contract that slicing works on the result of a function call in async mode (e.g., {{ add_each(a, 2)[1:] }} renders [3, 4]).
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying or adding tests for slicing the result of a function call in async mode.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fb27f82b3ce1709a84f60a53.md)
