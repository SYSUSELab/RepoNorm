# Constraints for `tests/test_tests.py`

## Rule

- **Rule:** Tests that exercise both compile-time assertion failures and runtime template errors must import TemplateAssertionError and TemplateRuntimeError from jinja2.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When modifying or adding tests in tests/test_tests.py that exercise compile-time assertion failures or runtime template errors.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-06d51c1a4ceba21259b0b888.md)

## Rule

- **Rule:**
  ```text
  The `in` test must preserve substring membership for strings, element membership for tuples/lists, and key membership for dicts, with mixed True/False results asserted in one render.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When modifying or extending the `in` operator test in tests/test_tests.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2a1d35bbb89952fb793b64e1.md)

## Rule

- **Rule:**
  ```text
  Tests for the `sameas` test must assert identity semantics: `foo is sameas false` is True only when foo is the False singleton, and integer 0 is not the same object as False.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When adding or modifying `sameas` identity tests in tests/test_tests.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5b91dd5cd68bc52b1b829c22.md)

## Rule

- **Rule:**
  ```text
  The `test` test must check whether a named test exists, returning truthy for known tests and falsy for unknown names without raising errors.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When modifying tests for the `test` test existence check.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-75ac67ff2eee6adfb57bac5e.md)

## Rule

- **Rule:** The is-tests must define precise type semantics: booleans are numbers but not integers, large ints are integers, strings are sequences and iterables but not mappings, and dicts are mappings and iterables, as asserted across the parametrized cases.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When adding or modifying the parametrized is-tests in the tests test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-864adae66272611d07af78ff.md)

## Rule

- **Rule:**
  ```text
  Referencing an undefined test name must raise TemplateAssertionError with a message matching "No test named '<name>'".
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying test-name resolution or the error raised for unknown tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a5a5c5b64dc0db8b65a74e92.md)

## Rule

- **Rule:** Tests that exercise Jinja's built-in test functions (defined, even, greaterthan) must assert the exact boolean result of the test, because these tests render Python booleans as the strings 'True'/'False' and the test contract is the boolean outcome, not a truthy/falsy coercion.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When adding or modifying assertions for built-in Jinja test functions in tests/test_tests.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc3c688347b207ea43f50056.md)

## Rule

- **Rule:**
  ```text
  Comparison test aliases must be asserted through the `is` test operator with parametrized op strings (e.g. 'eq 2') and expected booleans, covering eq/ne/lt/le/gt/ge aliases.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When adding or modifying comparison-alias tests in tests/test_tests.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ed47478d587ba0aabf60aec5.md)
