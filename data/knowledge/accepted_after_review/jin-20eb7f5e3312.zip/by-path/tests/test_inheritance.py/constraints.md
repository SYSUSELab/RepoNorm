# Constraints for `tests/test_inheritance.py`

## Rule

- **Rule:** Tests for scoped block inheritance must preserve the contract that a scoped block inside a for loop in a child template importing a macro with context can access the parent's variable.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:** When modifying or adding tests for scoped block inheritance with macro imports and context.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0b99fcc0e2358d74986b32a8.md)

## Rule

- **Rule:**
  ```text
  Block reuse tests must preserve that a block's rendered output is accessible through self both before and after its definition site, so calling self.foo() around a {% block foo %}42{% endblock %} yields '42|42|42'.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying or extending block reuse tests in tests/test_inheritance.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-10d25253c26b9ccfce22afd1.md)

## Rule

- **Rule:** Tests that exercise Jinja's macro scoping across template inheritance must assert that a macro defined in a child template is callable inside an overridden block, because this defines the macro-scoping contract for inheritance.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:** When adding or modifying tests for macro scoping across template inheritance
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6cf9c63c855c7cde7c3515c2.md)

## Rule

- **Rule:** A block marked required in a base template must be overridable by child templates, with each child rendering its own override content.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying required-block inheritance tests in tests/test_inheritance.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7f3110fcf183903cd3967650.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_inheritance.py that exercise template inheritance must assert the exact concatenated block content and override ordering across template levels, rather than only checking that rendering succeeds.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When adding or modifying an inheritance test in tests/test_inheritance.py that exercises multi-level block resolution or nested block overrides.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8379c8e66767829e2695d3ba.md)

## Rule

- **Rule:** Required blocks may only contain comments or whitespace; templates where a required block contains data, nested blocks, or if-statements must raise TemplateSyntaxError with message 'Required blocks can only contain comments or whitespace'.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:** When adding or modifying the invalid-required-block test in the inheritance test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9fec71725d868ea43c7656a4.md)

## Rule

- **Rule:**
  ```text
  Multi-level template inheritance with super() must resolve across nested blocks, rendering '--INTRO--|BEFORE|[(INNER)]|AFTER' for a three-level chain.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying multi-level inheritance super() tests in tests/test_inheritance.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f245833d5eeba6feca0099ac.md)

## Rule

- **Rule:** Tests for template inheritance must verify that blocks defined inside a false conditional are preserved and callable via self.x(), and that super() and block preservation work across inheritance.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:** when modifying or extending inheritance tests for block preservation or super() behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ff7bd492e336b309f955f96a.md)
