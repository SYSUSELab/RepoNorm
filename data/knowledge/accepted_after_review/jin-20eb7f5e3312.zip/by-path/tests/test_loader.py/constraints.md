# Constraints for `tests/test_loader.py`

## Rule

- **Rule:**
  ```text
  The compile_down test helper must preserve its convention of compiling templates into either a zip archive or a temp directory and loading them via ModuleLoader, returning the joined log.
  ```
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When modifying or extending the compile_down helper in tests/test_loader.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0723c43e682280ce2db9f446.md)

## Rule

- **Rule:** Tests for the FileSystemLoader must assert that the encoding parameter is honored, so the same template bytes render differently under iso-8859-1 versus utf-8.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:** When adding or modifying a test for FileSystemLoader encoding behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-08ef9f255a3b6ca0e275c50f.md)

## Rule

- **Rule:** Filesystem-loader test templates must be placed under tests/res/templates, resolved relative to the test file, so that TestFileSystemLoader can locate them via its searchpath.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:** When adding or modifying a test that uses TestFileSystemLoader or adds template fixtures for filesystem-loader tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-350a36f5f426adab3b750d4d.md)

## Rule

- **Rule:** Loader search paths must accept pathlib.Path entries, including mixed lists of Path and str, and must not normalize a root path to '.' or './' because those are invalid in zip paths.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:** When modifying loader search-path handling or PackageLoader root-path normalization in the loader test suite.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-43d9ed108682560fec76529a.md)

## Rule

- **Rule:**
  ```text
  Package loader tests must preserve the convention that the tests directory is importable: the package_dir_loader fixture prepends the test file's parent directory to sys.path before constructing PackageLoader("res").
  ```
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When modifying or extending package loader tests or the package_dir_loader fixture in tests/test_loader.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6c7056df1e8f424c05a18975.md)

## Rule

- **Rule:** Tests for the deflated zip loader must compile with zip='deflated' and then run the common loader test suite.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When adding or modifying deflated zip loader tests in tests/test_loader.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7c67a40a60d034a02a9d44db.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_loader.py that exercise loader behavior must assert the exact source tuple shape and path coercion semantics, including the (source, name, up_to_date) triple and acceptance of string search paths, rather than only checking that loading succeeds.
  ```
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When adding or modifying a loader test in tests/test_loader.py that exercises get_source return shape or search-path coercion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-848086a037544ac73ac7bf90.md)

## Rule

- **Rule:** Tests for the module loader must verify that after compiling and loading a template, the module is present in sys.modules and that dropping the environment and collecting garbage removes the module from sys.modules.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:** when modifying or extending module loader tests for weak reference or sys.modules lifecycle behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9277c71ff89284265874063e.md)

## Rule

- **Rule:** Tests for ModuleLoader path arguments must confirm that ModuleLoader accepts pathlib.Path objects as its path argument.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When modifying or adding ModuleLoader path-argument tests in tests/test_loader.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bba03f4a7876af014e2d679d.md)

## Rule

- **Rule:**
  ```text
  Tests for loader path-splitting behavior must import split_template_path from jinja2.loaders, treating it as part of the loader's tested public surface.
  ```
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When modifying or adding loader path-splitting tests in tests/test_loader.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cb33fe89d6dbc95cf7141389.md)
