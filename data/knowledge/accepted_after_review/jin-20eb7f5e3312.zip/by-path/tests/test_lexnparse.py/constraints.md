# Constraints for `tests/test_lexnparse.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise Jinja's whitespace-control modifiers must assert that the '+' modifier is a no-op when trim_blocks is False, because this defines the whitespace-control contract for the lexer/parser.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying tests for whitespace-control modifiers with trim_blocks disabled
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-067e2bdfcc98a5216cf619e1.md)

## Rule

- **Rule:**
  ```text
  Custom delimiter tests must assert that ERB-style delimiters with lstrip_blocks and trim_blocks strip comment and control lines while output lines retain leading indentation.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for custom ERB-style delimiters with whitespace control.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-06dd86879dcbfde419435aef.md)

## Rule

- **Rule:**
  ```text
  Whitespace-control tests must assert that raw blocks still honor {%- and -%} markers when lstrip_blocks and trim_blocks are enabled.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for whitespace control interaction with raw blocks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1216d55a8d67809eb00afcad.md)

## Rule

- **Rule:**
  ```text
  A parenthesized comparison inside arithmetic must render as a boolean coerced to int, e.g. {{ i * (j < 5) }} with i=2, j=3 yields '2'.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying parenthesized-comparison-in-arithmetic tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1560d56c280434ea7c86f4b5.md)

## Rule

- **Rule:**
  ```text
  Tests for compound comparison expressions must assert that Jinja evaluates them as chained comparisons, so `4 < 2 < 3` is False while `4 > 2 < 3` is True.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or adding compound comparison expression tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-20ebb336269b243f97b25a33.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_lexnparse.py that exercise lexer or parser behavior must assert the exact decoded or rendered value, including escape sequences, subscript indices, and trailing-newline handling, rather than only checking that parsing succeeds.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying a lexer or parser test in tests/test_lexnparse.py that exercises string escapes, subscript expressions, or trailing-newline handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-28252a2c2c59d486ddfae8a5.md)

## Rule

- **Rule:**
  ```text
  Whitespace-control tests must preserve raw-block whitespace behavior under trim_blocks and lstrip_blocks, and custom comment/block/variable delimiters must render correctly with those options.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying whitespace-control or custom-delimiter tests in the lexer/parser suite.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29e735c3f03be38814ba6f2b.md)

## Rule

- **Rule:**
  ```text
  Tests for raw whitespace control must assert that with lstrip_blocks=True and trim_blocks=False, the trailing dash in `{%- raw -%}` strips spaces and newlines up to the first data character.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying raw whitespace control tests in tests/test_lexnparse.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2e54444fd6293a0a808f231f.md)

## Rule

- **Rule:**
  ```text
  Tests for lstrip_blocks and trim_blocks must verify that with both options enabled, a block inside parentheses renders with trim_blocks removing the newline after the block tag while lstrip_blocks strips leading whitespace before block tags.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  when modifying or extending lexer/parser tests for lstrip_blocks or trim_blocks whitespace handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-37ecef41873ee4ff61f27cf8.md)

## Rule

- **Rule:**
  ```text
  Tests for custom delimiter configurations must verify that rendering preserves the indentation of inner content lines when lstrip_blocks and trim_blocks are enabled, rather than only checking that the delimiters are accepted.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying a test that configures custom block/variable/comment delimiters on the Environment.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3b8cdc203597c8727eefbdb9.md)

## Rule

- **Rule:** Lexer line-number reporting must remain stable across whitespace-stripping block tags: tokens following a {%- ... -%} block still report their original source line.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying lexer line-number tracking or whitespace-stripping block handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-467afa9cec336bcf5c0dae95.md)

## Rule

- **Rule:**
  ```text
  Whitespace-control tests must assert the exact rendered output for the specific combination of trim_blocks and lstrip_blocks under test, because each flag independently controls a different whitespace region (leading indentation vs. the newline after a block tag).
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying a test that exercises trim_blocks and/or lstrip_blocks rendering behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-48822eaafd0327ef237744d8.md)

## Rule

- **Rule:** Custom block/variable delimiters ('{%','%}','${','}') must be balanced correctly, with the template rendering dict literals per iteration as {'FOO': 0}{'FOO': 1}{'FOO': 2}.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying the custom-delimiter balancing test in the lexer/parser test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-605c9e1f41025465c6970c91.md)

## Rule

- **Rule:**
  ```text
  Template syntax tests must preserve operator precedence and undefined-handling semantics: `not` binds around the `in` test, short conditional expressions render empty when undefined, and attribute access on an undefined conditional result raises UndefinedError.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying lexer/parser tests for operator precedence or conditional-expression undefined handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6deacd179f14dd0cdf75ae30.md)

## Rule

- **Rule:** Tests that exercise template expression semantics must preserve the documented operator precedence where 'and' binds tighter than 'or', so grouped expressions like (true and false) or (false and true) and not false continue to evaluate to False.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending template expression parsing/grouping tests in tests/test_lexnparse.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-768496871d3670e35961b4e1.md)

## Rule

- **Rule:** The jinja2.lexer.operators mapping must stay consistent with lexer tokenization: tokenizing each operator (excluding bracket characters) must yield the expected token type.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying the lexer operators mapping or operator tokenization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7764e330126571b3f9d3c94c.md)

## Rule

- **Rule:** Rendering empty list, dict, and tuple literals must return their literal string forms unchanged.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying literal parsing or rendering of collection literals.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-810f01d968a25fad9e4ffd85.md)

## Rule

- **Rule:**
  ```text
  Whitespace-control tests must assert that with lstrip_blocks and trim_blocks disabled, explicit '-' whitespace control on if/for/endif tags renders without leading whitespace.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying tests for explicit '-' whitespace control with lstrip_blocks and trim_blocks disabled.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8a8e033e8ec7e22c7b807a18.md)

## Rule

- **Rule:**
  ```text
  Tests for lstrip_blocks behavior must assert that with lstrip_blocks=True and trim_blocks=False, nested if blocks strip leading whitespace from block tags while preserving the rendered text.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or adding lstrip_blocks whitespace-control tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9c1075a73cc9df390590b217.md)

## Rule

- **Rule:**
  ```text
  With trim_blocks=True and lstrip_blocks=True, nested if blocks must render to 'a b c ' with the trailing space preserved, demonstrating combined whitespace-trimming behavior for nested block tags.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying nested-block whitespace-trimming tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a2eb4fe206a13bbb8cba4997.md)

## Rule

- **Rule:**
  ```text
  Lexer/parser test helpers must provide an identity __getitem__ accessor so subscript-like template expressions can be tested without altering the argument.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying lexer/parser test helpers used for subscript-like template expressions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b3a44867678be0ef947dc450.md)

## Rule

- **Rule:**
  ```text
  Tests for token streams must use a class-level test_tokens list of Token instances as shared fixture data across test methods.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying or adding token stream tests that share fixture data across methods.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c45ec4763dd8054a0f92f537.md)

## Rule

- **Rule:**
  ```text
  With custom angle-bracket delimiters plus lstrip_blocks and trim_blocks, leading whitespace before a block tag must be stripped while trailing spaces after the block are preserved.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying the lstrip-blocks angle-bracket test in the lexer/parser test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c54702705ebb9a8a22d86043.md)

## Rule

- **Rule:**
  ```text
  Lexer tests must assert that newline_sequence normalizes all of \r, \r\n, and \n in template output to the configured sequence.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying tests for newline_sequence normalization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dd03db3ee08abacfb31c45d0.md)

## Rule

- **Rule:** Tests that exercise Jinja template parsing must keep accepting trailing commas in tuple, list, and dict literals and must not emit the trailing comma in rendered output.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending parser syntax tests for collection literals in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e5c28ec9ea845ed979801026.md)

## Rule

- **Rule:** Tests for TokenStream iteration must assert that iterating a TokenStream yields token types in order.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying TokenStream iteration tests in tests/test_lexnparse.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e6fb3e56134d77c987145f9f.md)

## Rule

- **Rule:**
  ```text
  Template attribute access must treat dot access and subscript access as equivalent for dict values: foo.bar and foo['bar'] both yield the same value.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying template attribute or subscript resolution behavior exercised by tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eeee03fc6ac81fe369b2a49d.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Jinja's identifier validity rules must assert that unicode letters are valid identifier starts, digits and hyphens are invalid, and certain unicode characters (\u1885, \u1886, \u2118, \u212e) are valid starts though not matched by \w, while \xb7 is only valid as a continue character, because this defines the lexer's identifier contract.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for Jinja identifier validity rules in the lexer
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f7887bbb5be2ee2318d52cd5.md)
