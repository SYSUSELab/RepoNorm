# Constraints for `tests/test_debug.py`

## Rule

- **Rule:**
  ```text
  Tests for Jinja debug local extraction must assert that get_template_locals collapses l_N_name keys to the highest-numbered non-missing value per name and drops missing entries.
  ```
- **Applies to:**
  - `tests/test_debug.py`
- **Condition:** when adding or modifying tests for Jinja debug local extraction behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3909f5639a0e85f4c33ce579.md)

## Rule

- **Rule:** Tests for TemplateSyntaxError pickling must preserve the contract that the unpickled error retains both its string representation and its name attribute.
- **Applies to:**
  - `tests/test_debug.py`
- **Condition:** When modifying or adding tests for TemplateSyntaxError pickling behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-94224530fc6c24baf44fd61f.md)

## Rule

- **Rule:** The debug test helper must assert that a formatted traceback matches an expected regex pattern, failing with the full traceback and expected pattern when no match is found.
- **Applies to:**
  - `tests/test_debug.py`
- **Condition:**
  ```text
  When modifying the traceback-matching debug test helper in tests/test_debug.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-95c7d698a8dc476dd80495ef.md)
