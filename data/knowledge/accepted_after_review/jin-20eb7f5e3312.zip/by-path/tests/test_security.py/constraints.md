# Constraints for `tests/test_security.py`

## Rule

- **Rule:**
  ```text
  In a SandboxedEnvironment, format_map with nested dict access (e.g. 'a{x.foo}b'.format_map({'x':{'foo': 42}})) must be permitted and render the nested value.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:**
  ```text
  When modifying sandbox attribute access or format_map handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6d17745285fc6a0c2eff2154.md)

## Rule

- **Rule:**
  ```text
  Sandbox operator restriction tests must preserve that disable_op raises TemplateRuntimeError('that operator so does not work') to verify sandbox operator restrictions.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:**
  ```text
  When modifying or extending sandbox operator restriction tests in tests/test_security.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7e5a54d35353d9e0d46de4ca.md)

## Rule

- **Rule:**
  ```text
  Sandbox security tests must assert that accessing dangerous attributes such as __subclasses__ through the attr filter raises SecurityError.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:**
  ```text
  When modifying or adding sandbox attribute-access security tests in tests/test_security.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d20a85845f1a6dd89e3f3d9b.md)
