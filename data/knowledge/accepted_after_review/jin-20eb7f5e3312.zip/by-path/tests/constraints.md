# Constraints for `tests`

## Rule

- **Rule:** Coverage source measurement is limited to the jinja2 and tests directories.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-578f759c4dddf5c253fcb3a5.md)

## Rule

- **Rule:** Pytest test discovery is restricted to the tests directory via testpaths = tests.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ba02e408344a7c0f86a6b30f.md)

## Rule

- **Rule:** Include tests when a patch adds or changes code, and ensure the test fails without the patch.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-c37780d4d1ca2d05a75f78fe.md)

## Rule

- **Rule:**
  ```text
  Pytest treats warnings as errors (filterwarnings = error), except the deprecation warning 'The loop argument' from asyncio.base_events, which is ignored.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c4a5bb18ae855a766afa7c42.md)
