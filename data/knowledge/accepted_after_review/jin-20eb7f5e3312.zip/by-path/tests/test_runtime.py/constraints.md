# Constraints for `tests/test_runtime.py`

## Rule

- **Rule:** LoopContext.length must equal the length of the underlying iterable, including when the iterable is empty; length is derived from the sequence rather than from iteration progress.
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:** When modifying LoopContext length computation or loop iteration state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5215d2ee13e6e5bba98f9fa3.md)

## Rule

- **Rule:** Runtime tests must preserve that LoopContext.length equals the length of the underlying iterable even when constructed from a reversed list.
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:**
  ```text
  When modifying or extending LoopContext tests in tests/test_runtime.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-92d568760e3ae685a8297ffd.md)

## Rule

- **Rule:** Tests for Jinja loop index variables must assert that index and revindex are 1-based for a single-iteration loop.
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:** when adding or modifying tests for Jinja loop index variables
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e1dd971ea829b5bf808bfb77.md)
