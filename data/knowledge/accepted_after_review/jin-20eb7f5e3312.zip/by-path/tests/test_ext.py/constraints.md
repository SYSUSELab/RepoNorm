# Constraints for `tests/test_ext.py`

## Rule

- **Rule:** Tests that exercise Jinja's autoescape scoping must assert that variables set inside an {% autoescape %} block are scoped to that block and that the outer value is restored after {% endautoescape %}, because this defines the scoping contract for the autoescape extension.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for the autoescape extension's variable scoping behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-09715e7aec02f52d27c1cfb1.md)

## Rule

- **Rule:** The do extension test must preserve that the do extension allows calling items.append inside a loop, rendering '0f, 1o, 2o' from loop.index0 concatenated with each character.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending the do extension test in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-103cc7439ead1d7f86d7427a.md)

## Rule

- **Rule:**
  ```text
  Extension tests must preserve that a StreamFilterExtension combined with a gettext global transforms 'Foo _(bar) Baz' into 'Foo BAR Baz', verifying extension preprocessing and gettext interaction.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending streamfilter extension tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-37099e0d20b02c0466849fdd.md)

## Rule

- **Rule:**
  ```text
  Tests for the i18n extension's babel_extract must keep extraction results as (lineno, funcname, args, comments) tuples, with npgettext's plural argument defaulting to None when absent, and trimmed trans blocks collapsing internal whitespace while untrimmed blocks preserve leading/trailing whitespace.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  when modifying or extending babel_extract extraction tests for pgettext/npgettext or trimmed trans blocks
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-442941c3d48174b1c980a7dd.md)

## Rule

- **Rule:** Tests for the extension API must verify that custom tags are registered by name via a tags set on the extension class.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** when modifying or extending extension API tests for custom tag registration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6003bf083c325ef4215f3720.md)

## Rule

- **Rule:**
  ```text
  A macro defined in a non-autoescape environment must not be escaped when called inside an autoescape block; the rendered output remains raw '<html>'.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying autoescape macro behavior tests in tests/test_ext.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6d3e742109008e86966b4f10.md)

## Rule

- **Rule:**
  ```text
  Newstyle gettext codegen tests must preserve that for a pluralized trans block with num=3, the compiled source passes num once for performance rather than duplicating it, matching the pattern "u?'%\(num\)s apple', u?'%\(num\)s apples', 3".
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending newstyle gettext codegen tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6d8d2807f084db54160e6e40.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_ext.py that exercise extension hooks must assert the exact rendered output produced by the extension, including preprocessor rewrites, stream-filter token interpolation, and pluralization call counts, rather than only checking that the extension loads.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When adding or modifying an extension test in tests/test_ext.py that exercises a preprocessor, stream filter, or internationalization extension hook.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8c21a62c0c84b81f42786795.md)

## Rule

- **Rule:** Tests for the ngettext helper must preserve the plural-selection contract: plural form when n != 1, singular otherwise, with LANGUAGE-based lookup and fallback to the original string.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or adding tests for the ngettext helper used in i18n extraction tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8d11f31290e7dd7b10cfb430.md)

## Rule

- **Rule:** Tests that exercise i18n extraction must keep the trimmed-option contract: whitespace inside gettext/trans messages is normalized and pluralize blocks emit (singular, plural, None) tuples.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or adding i18n extraction tests that pass the trimmed option to babel_extract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-91813129ba9f8bc1082c896f.md)

## Rule

- **Rule:** Tests for extension ordering must preserve the contract that Extension subclasses can declare a numeric priority attribute to control extension ordering.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or adding tests for extension ordering via the priority attribute.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a4370b144da18b9b8ec37e9d.md)

## Rule

- **Rule:** Tests for Jinja overlay extension scopes must assert that the overlay can read outer variables and set new variables while leaving outer variables unchanged, documenting scope isolation.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** when adding or modifying tests for Jinja overlay extension scope behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c514acdbf1c9685489fc8666.md)

## Rule

- **Rule:** Tests that exercise Jinja's extension rebinding must assert that after Environment.overlay(), each extension's .environment attribute points to its own environment, because this defines the extension-rebinding contract for environment overlays.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for extension rebinding after Environment.overlay()
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d38f042e220447627970a76f.md)

## Rule

- **Rule:**
  ```text
  Newstyle internationalization tests must preserve plural-form selection and translation for the German locale: rendering ngettext_long.html with apples=5 and LANGUAGE='de' yields '5 Äpfel'.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying newstyle i18n pluralization behavior or the TestNewstyleInternationalization test class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dad6411bfb1c673bbac5dd84.md)

## Rule

- **Rule:**
  ```text
  Tests for the stringformat.html template with newstyle_i18n_env must assert that new-style i18n formatting renders the expected localized output.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When adding or modifying new-style i18n stringformat tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dd6b0eb4be2216011fae8b15.md)

## Rule

- **Rule:**
  ```text
  Tests for the new-style i18n extension must exercise pluralization through the `{% trans %}`/`{% pluralize %}` block, where the pluralize variable name must match the `count` variable; a mismatch must raise TemplateAssertionError.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When adding or modifying new-style i18n pluralization tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dde843c3c34cc078e97ffc01.md)

## Rule

- **Rule:**
  ```text
  Extension tests must preserve that a context reference node used inside a for loop can access loop locals, with sandboxed, ext_attr, imported name, context reference, and the loop variable all visible in the rendered output.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending context reference node tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-de64767590a4832faba0c7da.md)

## Rule

- **Rule:**
  ```text
  Tests for extension context output must use the _dump helper format: sandboxed flag, ext_attr, imported_object, context.blocks, and context.get('test_var') serialized into a pipe-delimited string.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or adding tests that assert extension-context output format.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df1e7209d7ef53f209d6f814.md)

## Rule

- **Rule:**
  ```text
  The ExampleExtension test fixture must preserve its declared extension attributes: tags = {"test"}, ext_attr = 42, and context_reference_node_cls = nodes.ContextReference.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending the ExampleExtension fixture in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e46e30c33fefaf0492a3414f.md)

## Rule

- **Rule:** Autoescape scoping tests must assert that enabling autoescape changes macro output type to Markup while disabling it yields str, and that compiled raw source reflects escaping of literal template text.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for autoescape scope effects on macro output and compiled source.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eb2f7adf3bd72989e2658c89.md)

## Rule

- **Rule:** Test helpers for simulating context-aware lookups in extension tests must return value.get(ctx, value) for dicts and the value itself otherwise.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or adding context-aware lookup helpers in tests/test_ext.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f0e39f39c1476e29936ce6da.md)

## Rule

- **Rule:**
  ```text
  Tests for extension context-reference customization must assert that a custom context_reference_node_cls passes the template context, including set variables, through to the rendered output.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When adding or modifying a test for an extension that overrides context_reference_node_cls.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f3a4c400266f1bfca50a46e5.md)
