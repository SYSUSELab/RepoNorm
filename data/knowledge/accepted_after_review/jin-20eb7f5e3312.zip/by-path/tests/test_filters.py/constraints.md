# Constraints for `tests/test_filters.py`

## Rule

- **Rule:** Tests for Jinja autoescape and safe filter must assert that the safe filter bypasses HTML escaping while the same string without safe is escaped.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for Jinja autoescape and safe filter behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-39b4207e61139d17b778efcd.md)

## Rule

- **Rule:** Filter tests must assert that undefined variables in not-defined branches render the fallback while unknown filters raise TemplateRuntimeError with a 'No filter named' message.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying tests for undefined variables in nested if branches and unknown filter errors.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3c9c3ab0f293f23013a99ac7.md)

## Rule

- **Rule:** Round filter tests must preserve documented rounding behavior including explicit precision and rounding mode: 2.7 rounds to 3.0, 2.1 to 2.0, 2.1234 with precision 3 and floor to 2.123, and 2.1 with precision 0 and ceil to 3.0.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending round filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3eb15b017072f590111ccf1c.md)

## Rule

- **Rule:** The int filter must preserve its default keyword argument behavior: the default is returned when the value cannot be converted to an integer.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending int filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3f9bd01b6599a9ca28f4699f.md)

## Rule

- **Rule:** Tests for the min and max filters must assert that they accept an attribute= keyword and select the named attribute from each item.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When adding or modifying min/max filter attribute tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-46b59623ee1c794dd541a0e7.md)

## Rule

- **Rule:** The first filter must return the first element of an iterable, asserted as '0' for range(10).
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying the first-filter test in the filter test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-51cc44d408ebbdeff8a6dcc1.md)

## Rule

- **Rule:**
  ```text
  The `reverse` filter must reverse strings ('foobar'|reverse|join -> 'raboof') and lists ([1,2,3]|reverse|list -> [3, 2, 1]).
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the `reverse` filter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-52c99d4919bafde5c84b299c.md)

## Rule

- **Rule:** Tests for the selectattr filter must assert that a single attribute name tests truthiness of that attribute, and that chaining map(attribute=...) then join produces the expected joined string.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying a test for selectattr or map/join filter chaining.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-66684d88eb0391806778164b.md)

## Rule

- **Rule:** The urlize filter's target parameter must be rendered as an anchor target attribute while rel="noopener" is always added, so callers cannot opt out of rel=noopener via target.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the urlize target-parameter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-68b94bf7efcfd5d7b3c1a9aa.md)

## Rule

- **Rule:**
  ```text
  The `last` filter must return the final element of a list (e.g. rendering '9' for range(10)).
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the `last` filter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6eb0eede84bb992ad51911c4.md)

## Rule

- **Rule:**
  ```text
  Tests for filter inputs must use the __str__ helper that formats a value pair as '(value1,value2)' to make filter test inputs render deterministically.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying or adding filter tests that need deterministic rendering of value pairs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-79e5956bcbe583e134bbd20e.md)

## Rule

- **Rule:** Filter tests must assert that sum accepts an attribute name and aggregates that attribute across mapping items.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying tests for the sum filter's attribute-name form.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7a46712e93fd9f2b9a7d2399.md)

## Rule

- **Rule:** Tests for the map filter's attribute lookup with default must cover missing attributes and None values, including list defaults rendered as repr and empty-string defaults producing a trailing empty entry.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When adding or modifying map filter default tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-811317e6ab56ec825c3a7078.md)

## Rule

- **Rule:**
  ```text
  The `sort` filter must support comma-separated dotted/indexed attribute paths for multi-key sorting, e.g. sort(attribute='value1.0,value2.0').
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the multi-key sort attribute test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-86972dee0d60688d0d0b6f00.md)

## Rule

- **Rule:** Tests for Jinja filter chains must assert the combined result of chaining filters (e.g. map+sum) rather than individual filter outputs.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for Jinja filter chains
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9006bd9cc50476f3c454f66a.md)

## Rule

- **Rule:**
  ```text
  The tojson filter must escape <, >, &, and ' as unicode escapes when autoescape is enabled, and must honor env.policies['json.dumps_function'] and env.policies['json.dumps_kwargs'] to override the dumps callable and its keyword arguments.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying the tojson filter, JSON escaping, or json.dumps policy handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a9f4f90ecbd6e3bcf75b38ea.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_filters.py that exercise filter behavior must assert the exact rendered output string, including ordering, chunking, padding, and case-sensitivity semantics, rather than only checking that rendering succeeds.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When adding or modifying a filter test in tests/test_filters.py that exercises groupby, slice, min/max, or truncate behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c5ba857fdf586b937fa0cc7f.md)

## Rule

- **Rule:**
  ```text
  Filter chaining first|upper|escape must escape the uppercased first element, rendering '&lt;FOO&gt;'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying filter-chaining tests in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c73955b6676f7b065c84e5c1.md)

## Rule

- **Rule:** Tests for Jinja filter behavior must cover both the defined-value path and the undefined-value path, asserting that undefined inputs either raise TemplateRuntimeError or are tolerated (e.g. items yields empty list) according to the filter's contract.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for a Jinja filter's handling of undefined values
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d4e3025c16ac4503b46042cb.md)

## Rule

- **Rule:** Filter tests must assert that map(attribute='name') extracts the named attribute from each object and that join preserves input order, and that reject with a named test removes matching items while preserving the order of the remainder.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying filter behavior tests for map/join/reject in the filter test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d5fcafaced0c7c5b01ae1c5a.md)

## Rule

- **Rule:** Filter behavior must preserve documented semantics: abs returns 1 for both -1 and 1, sum defaults to start=0, and groupby accepts an integer attribute index for tuple grouping.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying filter implementations or the filter test surface in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d724a1233e3bed6facaec2e3.md)

## Rule

- **Rule:**
  ```text
  Filter tests must preserve programmatic filter invocation behavior, such as env.call_filter('sum', [1,2,3]) returning 6.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying filter tests that exercise programmatic filter invocation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d86339374dd7ad546c8e36c6.md)

## Rule

- **Rule:** Tests for the indent filter must pin how blank lines and trailing newlines are indented across combinations of indent(2, blank, newline) on multiline strings.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when modifying or extending indent filter tests for multiline templates with blank lines or trailing newlines
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f8baf983d8720b273c681ea9.md)

## Rule

- **Rule:** Filter tests must assert that rejectattr with a test name removes items whose named attribute passes the test.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying tests for rejectattr with a test name.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fa13bb714002e0f27f2ef520.md)
