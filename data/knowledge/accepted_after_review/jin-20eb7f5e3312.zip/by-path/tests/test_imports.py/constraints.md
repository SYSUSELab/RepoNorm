# Constraints for `tests/test_imports.py`

## Rule

- **Rule:** Tests for template module exports must assert that top-level macros and set variables are exposed as attributes while names starting with double underscore and macros defined inside a for loop are not exposed.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** When adding or modifying a test for template module attribute visibility.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-66c50ccc844dd2b6fe19327a.md)
