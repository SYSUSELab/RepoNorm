# Constraints for `tests/test_nativetypes.py`

## Rule

- **Rule:** Native-types tests must preserve undefined objects when rendering undefined variables in native mode, rather than converting them to strings.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When modifying native-types rendering tests for undefined variables.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-28a345272da764083dfea136.md)

## Rule

- **Rule:**
  ```text
  Tests for the `is defined` test in native mode must assert that a missing variable renders falsy.
  ```
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:**
  ```text
  When adding or modifying `is defined` native-mode tests in tests/test_nativetypes.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-40fa61cf5ec16eaa52a7a183.md)

## Rule

- **Rule:** Tests for native template types must verify that boolean expressions render to actual bool instances preserving Python bool identity and that dunder attribute access on constants returns the actual Python type rather than a string.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** when modifying or extending native template type tests for boolean rendering or dunder attribute access
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-447bd772eb0facf1885d3dca.md)

## Rule

- **Rule:** Native template tests must assert that NativeTemplate creates a template whose environment is a NativeEnvironment.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying tests for NativeTemplate environment defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6251531d9fc4b51ace544de3.md)

## Rule

- **Rule:** Native-type rendering must preserve Python types rather than coercing to str: indexing a macro-returned list yields a Python int (isinstance(result, int)).
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:**
  ```text
  When modifying native-type rendering or macro return-value handling exercised by tests/test_nativetypes.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-80f9cd071da9c1e15a48601e.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Jinja's nativetypes rendering must assert that rendering a dunder attribute like __class__ yields a native Python type instance, because this defines the nativetypes contract for attribute access.
  ```
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying tests for nativetypes rendering of dunder attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8a89bf9cfa7112f8e8911f34.md)

## Rule

- **Rule:** Native-type rendering tests must assert that rendering a template containing only a string literal expression yields a str result equal to the literal text.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:**
  ```text
  When modifying or adding native-type rendering tests in tests/test_nativetypes.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9ae73e97e4a60facc6948629.md)

## Rule

- **Rule:** Adding an undefined value in a native template must raise UndefinedError during rendering rather than producing a native result.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying the native-template undefined-value test in the native types test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cfed0d66c03b2c7f5936117c.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_nativetypes.py that exercise native type rendering must assert that interpolated variables produce native Python types, with bytes literals preserved as bytes and string values as strings, rather than only checking that rendering succeeds.
  ```
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:**
  ```text
  When adding or modifying a native type rendering test in tests/test_nativetypes.py that exercises tuple literals with interpolated variables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d7203f1a70f9b19c684be718.md)

## Rule

- **Rule:** In the native environment, rendering a for-loop over a list of ints with no separators must produce a native int result (e.g. 1234), not a string; native concatenation semantics are preserved for loop output.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When modifying native environment rendering or loop output concatenation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f01bbc9009a6e0be4d217406.md)
