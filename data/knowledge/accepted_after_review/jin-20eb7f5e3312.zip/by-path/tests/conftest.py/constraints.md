# Constraints for `tests/conftest.py`

## Rule

- **Rule:**
  ```text
  The package_loader fixture in tests/conftest.py must return a PackageLoader initialized with package 'res' and templates directory 'templates', because this defines the shared fixture contract for tests that load templates from a package.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  When adding or modifying the package_loader fixture in tests/conftest.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-55c05eea01f6baa9c9c53187.md)

## Rule

- **Rule:**
  ```text
  The dict_loader fixture must return a DictLoader mapping justdict.html to the literal string FOO, providing a stable in-memory template source for loader tests.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  When modifying the shared dict_loader fixture used by loader tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-922182610b2c10558983039a.md)
