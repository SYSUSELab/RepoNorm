# Constraints for `tests/test_idtracking.py`

## Rule

- **Rule:**
  ```text
  Symbol tracking must preserve the exact id-tracking naming and load-kind protocol: top-level refs map names to l_0_* identifiers with loads entries ('undefined', None) or ('resolve', name), and entering a for-loop scope produces l_1_foo with ('param', None).
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:**
  ```text
  When modifying symbol tracking or id-tracking output exercised by tests/test_idtracking.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-19625d8a67534efb070d2ee0.md)

## Rule

- **Rule:**
  ```text
  Tests for idtracking must exercise symbol tracking over node trees by importing nodes and symbols_for_node.
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:** When modifying or adding idtracking tests that exercise symbol tracking over node trees.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-210c4092fd0ddeb8d5b56ba2.md)
