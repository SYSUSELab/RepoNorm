# Constraints for `jinja2`

## Rule

- **Rule:** Coverage source measurement is limited to the jinja2 and tests directories.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-578f759c4dddf5c253fcb3a5.md)
