# Constraints for `CHANGES.rst`

## Rule

- **Rule:** Add an entry in CHANGES.rst using the same style as other entries, and include .. versionchanged:: inline changelogs in relevant docstrings.
- **Applies to:**
  - `**/*.py`
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-f0ae02b75773e8a67e835e6f.md)
