# Constraints for `.github/workflows/lock.yaml`

## Rule

- **Rule:**
  ```text
  The 'Lock threads' workflow runs on a daily schedule defined by the cron expression '0 0 * * *'.
  ```
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7835e9952bfb103c05569c8c.md)

## Rule

- **Rule:** The lock job runs on ubuntu-latest and uses the dessant/lock-threads@v3 action with github-token set to ${{ github.token }}, issue-inactive-days set to 14, and pr-inactive-days set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fad69759ad8cba65e755ecdb.md)
