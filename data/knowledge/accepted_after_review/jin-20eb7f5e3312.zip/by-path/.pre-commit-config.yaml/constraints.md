# Constraints for `.pre-commit-config.yaml`

## Rule

- **Rule:** Pre-commit autoupdate is scheduled monthly.
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-639cde7539a659e1c6e87df7.md)

## Rule

- **Rule:** Pre-commit autoupdate targets branch 3.0.x.
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d3c1020e21b46065c0024bbd.md)
