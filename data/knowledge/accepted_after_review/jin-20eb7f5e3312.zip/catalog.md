# Claim catalog

- [Rules 1–73](catalog/0001.md); scope preview: `src/jinja2/**`
- [Rules 74–145](catalog/0002.md); scope preview: `docs/**`
- [Rules 146–217](catalog/0003.md); scope preview: `src/jinja2/nativetypes.py`
- [Rules 218–288](catalog/0004.md); scope preview: `**`
- [Rules 289–363](catalog/0005.md); scope preview: `src/jinja2/nodes.py`
- [Rules 364–439](catalog/0006.md); scope preview: `src/jinja2/**`
- [Rules 440–453](catalog/0007.md); scope preview: `tests/test_async.py`
