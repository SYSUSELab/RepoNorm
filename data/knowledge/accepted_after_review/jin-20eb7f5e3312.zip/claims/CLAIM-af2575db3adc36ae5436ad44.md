# Rule details

- **Rule:** The pre-commit configuration enables the end-of-file-fixer hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: end-of-file-fixer

```

- **Sources:**
  - `.pre-commit-config.yaml:34`

## Review evidence locations

- `.pre-commit-config.yaml:34-34`
