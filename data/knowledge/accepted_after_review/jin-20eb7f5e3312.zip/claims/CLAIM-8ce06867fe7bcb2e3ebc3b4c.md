# Rule details

- **Rule:** The optimizer module documents a deliberate limitation: because the AST does not carry full scoping information, optimizations such as loop unrolling are not performed, since unrolled loops would have a different scope; a second syntax tree storing scoping rules would be required.
- **Applies to:**
  - `src/jinja2/optimizer.py`
- **Condition:** when modifying optimizer passes or considering scope-dependent optimizations
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/optimizer.py:1-8`
