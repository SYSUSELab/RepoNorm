# Rule details

- **Rule:** The tox default environment list consists of py3{11,10,9,8,7}, pypy3{8,7}, style, typing, and docs.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
envlist =
    py3{11,10,9,8,7},pypy3{8,7}
    style
    typing
    docs

```

- **Sources:**
  - `tox.ini:2-6`

## Review evidence locations

- `tox.ini:2-6`
