# Rule details

- **Rule:**
  ```text
  The ExampleExtension test fixture must preserve its declared extension attributes: tags = {"test"}, ext_attr = 42, and context_reference_node_cls = nodes.ContextReference.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending the ExampleExtension fixture in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:151-165`
