# Rule details

- **Rule:**
  ```text
  When modifying the bytecode cache extension point, preserve that BytecodeCache subclasses must override load_bytecode and dump_bytecode, both receiving a Bucket.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  Changing BytecodeCache's documented extension contract or the Bucket interface passed to load_bytecode/dump_bytecode.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
BytecodeCache docstring documents that subclasses override load_bytecode and dump_bytecode, both receiving a Bucket.
```

- **Sources:**
  - `src/jinja2/bccache.py:101-183`
