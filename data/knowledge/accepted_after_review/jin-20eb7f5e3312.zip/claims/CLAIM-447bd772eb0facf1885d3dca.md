# Rule details

- **Rule:** Tests for native template types must verify that boolean expressions render to actual bool instances preserving Python bool identity and that dunder attribute access on constants returns the actual Python type rather than a string.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** when modifying or extending native template type tests for boolean rendering or dunder attribute access
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_nativetypes.py:75-102`
