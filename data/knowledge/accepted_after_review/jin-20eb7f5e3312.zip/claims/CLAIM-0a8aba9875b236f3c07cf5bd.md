# Rule details

- **Rule:** ImportedName must remain an Expr node with a single importname field whose access returns the imported name, and the compiler must optimize imports so they need not be assigned to local variables.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying ImportedName or the compiler's import optimization in the nodes module.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:1052-1060`
