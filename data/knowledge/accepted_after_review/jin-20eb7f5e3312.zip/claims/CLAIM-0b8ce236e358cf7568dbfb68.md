# Rule details

- **Rule:** The pip-compile-multi-verify pre-commit hook is configured.
- **Applies to:**
  - `**/*.in`
  - `**/*.txt`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: pip-compile-multi-verify

```

- **Sources:**
  - `.pre-commit-config.yaml:28`

## Review evidence locations

- `.pre-commit-config.yaml:28-28`
