# Rule details

- **Rule:**
  ```text
  Token.test supports two expression forms: a bare token type compared by string equality, and 'token_type:token_value' compared by splitting on the first colon and matching both type and value; equality rather than identity is used because test_any is usually passed non-interned strings.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** when modifying Token.test or lexer token matching behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/lexer.py:267-288`
