# Rule details

- **Rule:** Filesystem-loader test templates must be placed under tests/res/templates, resolved relative to the test file, so that TestFileSystemLoader can locate them via its searchpath.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:** When adding or modifying a test that uses TestFileSystemLoader or adds template fixtures for filesystem-loader tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_caches_template_based_on_mtime uses TestFileSystemLoader's searchpath resolved from the test file, consistent with the convention that filesystem-loader templates live under tests/res/templates.
```

- **Sources:**
  - `tests/test_loader.py:149-159`

## Review evidence locations

- `tests/test_loader.py:120-135`
