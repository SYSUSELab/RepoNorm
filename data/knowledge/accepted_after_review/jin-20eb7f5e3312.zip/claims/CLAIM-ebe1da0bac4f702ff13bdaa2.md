# Rule details

- **Rule:**
  ```text
  TokenStream.__next__ returns the current token and advances by first draining the pushed-back deque, otherwise pulling from the underlying iterator unless the current token is EOF; StopIteration triggers close().
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when modifying TokenStream.__next__ or token stream advancement logic
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/lexer.py:378-399`
