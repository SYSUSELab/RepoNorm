# Rule details

- **Rule:** The pgettext helper in the extension must return the source string unchanged, acting as a default no-op translation function.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When modifying InternationalizationExtension._install_null.pgettext or adding a new null translation fallback.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The nested pgettext helper in InternationalizationExtension._install_null returns the source string unchanged, acting as a no-op translation.
```

- **Sources:**
  - `src/jinja2/ext.py:297-298`
