# Rule details

- **Rule:** Filter tests must assert that map(attribute='name') extracts the named attribute from each object and that join preserves input order, and that reject with a named test removes matching items while preserving the order of the remainder.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying filter behavior tests for map/join/reject in the filter test module
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:678-730`
