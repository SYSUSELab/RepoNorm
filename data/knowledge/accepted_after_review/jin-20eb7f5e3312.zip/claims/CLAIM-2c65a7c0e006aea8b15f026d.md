# Rule details

- **Rule:**
  ```text
  Extension stream-filtering must preserve the protocol that Environment._tokenize applies each extension's filter_stream to the token stream and wraps any non-TokenStream return value in a TokenStream before continuing.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment._tokenize or adding an extension that overrides filter_stream.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Environment._tokenize applies each extension's filter_stream to the stream and wraps non-TokenStream results in a TokenStream before returning, preserving the extension protocol.
```

- **Sources:**
  - `src/jinja2/environment.py:646-665`
