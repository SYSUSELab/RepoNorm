# Rule details

- **Rule:**
  ```text
  Tests for filter inputs must use the __str__ helper that formats a value pair as '(value1,value2)' to make filter test inputs render deterministically.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying or adding filter tests that need deterministic rendering of value pairs.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:22-28`
