# Rule details

- **Rule:**
  ```text
  ChainableUndefined must keep returning the undefined object itself for any attribute access so that chained attribute lookups on undefined values do not raise; do not make __getattr__ raise or return a non-undefined value.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying ChainableUndefined.__getattr__ or the undefined-value attribute-access path in runtime.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/runtime.py:961-985`
