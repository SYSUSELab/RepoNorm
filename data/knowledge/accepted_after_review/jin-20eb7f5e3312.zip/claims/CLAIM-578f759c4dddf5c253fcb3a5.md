# Rule details

- **Rule:** Coverage source measurement is limited to the jinja2 and tests directories.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
source =
    jinja2
    tests

```

- **Sources:**
  - `setup.cfg:55-57`
