# Rule details

- **Rule:**
  ```text
  When modifying Parser.parse_compare, preserve the chaining of comparison operators and in/notin operators into a single Compare node, returning the bare expression when no operators are present.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** when modifying comparison expression parsing in the parser
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/parser.py:561-582`
