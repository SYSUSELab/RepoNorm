# Rule details

- **Rule:**
  ```text
  Sandboxed format_string routes str.format/format_map through a sandboxed formatter; when format_func.__name__ == "format_map" it enforces exactly one positional argument and no kwargs, raising TypeError otherwise, and preserves the original string type (e.g. Markup) on the result.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** when modifying sandboxed string formatting behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/sandbox.py:348-375`
