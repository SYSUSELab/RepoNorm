# Rule details

- **Rule:** When modifying the async/sync dispatch layer, preserve the contract that async variants are selected by environment capability and that sync results are wrapped in Markup when autoescape is enabled.
- **Applies to:**
  - `src/jinja2/async_utils.py`
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  Changing macro invocation dispatch or the async_variant decorator's wrapping behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/async_utils.py:12-51`
- `src/jinja2/runtime.py:655-782`
