# Rule details

- **Rule:** Token must be a NamedTuple with fields lineno:int, type:str, value:str, fixing the lexer token shape consumed by the parser.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** when modifying the Token type or the lexer/parser token interface
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/lexer.py:267-270`
