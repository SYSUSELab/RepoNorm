# Rule details

- **Rule:** Code changes must include tests that cover them, and the test must fail without the patch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Include tests that cover any code changes you make. Make sure the
    test fails without your patch. Run the tests as described below.

```

- **Sources:**
  - `CONTRIBUTING.rst:159-160`

## Review evidence locations

- `CONTRIBUTING.rst:159-160`
