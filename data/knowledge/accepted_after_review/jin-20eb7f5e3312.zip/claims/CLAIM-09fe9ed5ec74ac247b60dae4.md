# Rule details

- **Rule:**
  ```text
  Environment.make_globals must return a ChainMap of template-specific globals over environment globals so template-level global changes do not mutate environment globals; callers must not modify globals after a template is loaded.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Environment.make_globals or template global handling
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Environment.make_globals returns ChainMap(d, self.globals), isolating template-specific globals over environment globals as the rule requires.
```

- **Sources:**
  - `src/jinja2/environment.py:1097-1117`
