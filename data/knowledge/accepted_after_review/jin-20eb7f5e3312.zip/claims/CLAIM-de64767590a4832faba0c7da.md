# Rule details

- **Rule:**
  ```text
  Extension tests must preserve that a context reference node used inside a for loop can access loop locals, with sandboxed, ext_attr, imported name, context reference, and the loop variable all visible in the rendered output.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending context reference node tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:266-271`
