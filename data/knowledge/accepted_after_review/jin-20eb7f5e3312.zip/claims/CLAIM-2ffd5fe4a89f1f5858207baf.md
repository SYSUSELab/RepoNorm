# Rule details

- **Rule:**
  ```text
  PackageLoader.get_source returns an up_to_date callable for directory packages based on file mtime, but returns None for zip packages, explicitly treating zip-loaded templates as always current because safely reloading the module on zip mtime change is not done.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  when modifying PackageLoader.get_source freshness or up_to_date behavior
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/loaders.py:326-357`
