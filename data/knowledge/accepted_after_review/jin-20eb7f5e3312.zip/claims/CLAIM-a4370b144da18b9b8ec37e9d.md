# Rule details

- **Rule:** Tests for extension ordering must preserve the contract that Extension subclasses can declare a numeric priority attribute to control extension ordering.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or adding tests for extension ordering via the priority attribute.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:295-305`
