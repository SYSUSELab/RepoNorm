# Rule details

- **Rule:**
  ```text
  Environment.handle_exception must delegate to debug.rewrite_traceback_stack and always raise, never returning normally; callers rely on it raising a rewritten exception.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment.handle_exception or its traceback-rewriting behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:920-926`
