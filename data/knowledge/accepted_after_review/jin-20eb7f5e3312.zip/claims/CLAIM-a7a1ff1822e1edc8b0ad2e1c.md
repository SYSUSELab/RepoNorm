# Rule details

- **Rule:** MarkSafeIfAutoescape must remain an Expr node with a single 'expr' field that marks the wrapped expression as safe (Markup) only when autoescaping is active.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying MarkSafeIfAutoescape or the autoescape-conditional safety marking it implements.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
MarkSafeIfAutoescape is defined as an Expr subclass with fields = ('expr',), preserving the single-field Expr structure for conditional safety marking.
```

- **Sources:**
  - `src/jinja2/nodes.py:1092-1111`
