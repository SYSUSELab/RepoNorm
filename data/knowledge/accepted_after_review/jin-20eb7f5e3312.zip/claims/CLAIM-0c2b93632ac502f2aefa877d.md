# Rule details

- **Rule:**
  ```text
  pass_environment must mark a callable with jinja_pass_arg = _PassArg.environment, replacing the older environmentfunction/environmentfilter decorators as of 3.0.0.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  when modifying pass_environment or the environment-passing decorator contract
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/utils.py:63-73`
