# Rule details

- **Rule:** Read the Docs documentation builds fail on Sphinx warnings.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  fail_on_warning: true

```

- **Sources:**
  - `.readthedocs.yaml:13`

## Review evidence locations

- `.readthedocs.yaml:13-13`
