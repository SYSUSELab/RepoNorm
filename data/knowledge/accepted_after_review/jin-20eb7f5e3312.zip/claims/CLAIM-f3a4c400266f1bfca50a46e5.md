# Rule details

- **Rule:**
  ```text
  Tests for extension context-reference customization must assert that a custom context_reference_node_cls passes the template context, including set variables, through to the rendered output.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When adding or modifying a test for an extension that overrides context_reference_node_cls.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:178-271`
