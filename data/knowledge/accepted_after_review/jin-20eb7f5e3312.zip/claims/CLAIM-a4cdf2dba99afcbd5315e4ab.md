# Rule details

- **Rule:** flake8 ignores E203, E501, E722, and W503.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
ignore =
    # slice notation whitespace, invalid
    E203
    # line length, handled by bugbear B950
    E501
    # bare except, handled by bugbear B001
    E722
    # bin op line break, invalid
    W503

```

- **Sources:**
  - `setup.cfg:72-80`
