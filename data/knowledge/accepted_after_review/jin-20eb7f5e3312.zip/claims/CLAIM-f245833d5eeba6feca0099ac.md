# Rule details

- **Rule:**
  ```text
  Multi-level template inheritance with super() must resolve across nested blocks, rendering '--INTRO--|BEFORE|[(INNER)]|AFTER' for a three-level chain.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying multi-level inheritance super() tests in tests/test_inheritance.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
TestInheritance.test_super asserts the three-level inheritance chain renders '--INTRO--|BEFORE|[(INNER)]|AFTER', pinning super() resolution across nested blocks.
```

- **Sources:**
  - `tests/test_inheritance.py:109-124`
