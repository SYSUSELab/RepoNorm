# Rule details

- **Rule:**
  ```text
  do_select must be defined as an async variant of sync_do_select via @async_variant, delegating to async_select_or_reject, so the async filter mirrors the sync select filter for async iterables.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_select or the async filter variants
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:1469-1507`
