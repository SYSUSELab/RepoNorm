# Rule details

- **Rule:** LoopContext.length must equal the length of the underlying iterable, including when the iterable is empty; length is derived from the sequence rather than from iteration progress.
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:** When modifying LoopContext length computation or loop iteration state.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_runtime.py:31-46`
