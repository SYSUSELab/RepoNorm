# Rule details

- **Rule:**
  ```text
  Async macro tests must assert that a macro containing an awaited async function call renders correctly under enable_async.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying or adding async macro await tests in tests/test_async.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async.py:57-70`
