# Rule details

- **Rule:**
  ```text
  Block reuse tests must preserve that a block's rendered output is accessible through self both before and after its definition site, so calling self.foo() around a {% block foo %}42{% endblock %} yields '42|42|42'.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying or extending block reuse tests in tests/test_inheritance.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_inheritance.py:129-133`
