# Rule details

- **Rule:**
  ```text
  Parser.__init__ must build self.extensions by iterating environment.iter_extensions() and mapping each extension tag to extension.parse, so extension tags are registered per parser instance.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.__init__ or adding a new extension that registers a parse method under a tag.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/parser.py:51-70`
