# Rule details

- **Rule:**
  ```text
  The documented cache extension must call `super().__init__(environment)` and register `fragment_cache_prefix` and `fragment_cache` defaults via `environment.extend`.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** When modifying the cache extension's initialization or its environment defaults.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The __init__ method body shows super().__init__(environment) followed by environment.extend registering fragment_cache_prefix and fragment_cache defaults, matching the rule.
```

- **Sources:**
  - `docs/examples/cache_extension.py:9-13`
