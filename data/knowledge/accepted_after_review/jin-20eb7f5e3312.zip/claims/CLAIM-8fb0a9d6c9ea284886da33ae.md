# Rule details

- **Rule:** The gettext helper must always apply % formatting to the translated string even when no variables are supplied, and must wrap the result in Markup when autoescape is active.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** when modifying the gettext helper's formatting or autoescape wrapping behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/ext.py:170-180`
