# Rule details

- **Rule:** TemplateAssertionError must subclass TemplateSyntaxError and share its attributes, representing compile-time errors that are not syntax errors.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** when adding or modifying exception classes in jinja2.exceptions
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/exceptions.py:139-144`
