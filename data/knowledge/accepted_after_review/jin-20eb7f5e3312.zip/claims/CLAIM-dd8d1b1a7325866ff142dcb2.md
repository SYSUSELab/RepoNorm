# Rule details

- **Rule:**
  ```text
  Custom Jinja extensions in docs/examples must register their template tags by declaring a `tags` set on the Extension subclass; the tag name in that set is the name the parser dispatches on.
  ```
- **Applies to:**
  - `docs/examples/*.py`
- **Condition:** When adding or renaming a template tag provided by a documented example extension.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/extensions.rst:329-348`
- `docs/examples/cache_extension.py:5-20`
