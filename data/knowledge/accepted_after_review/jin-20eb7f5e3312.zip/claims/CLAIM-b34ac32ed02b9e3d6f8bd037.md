# Rule details

- **Rule:**
  ```text
  Environment._compile must remain an overridable hook whose default delegates to the built-in compile(source, filename, 'exec'); subclasses and extensions that substitute a different compile method rely on this seam.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment compilation or adding a subclass that overrides _compile to substitute a different compile method.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:688-694`
