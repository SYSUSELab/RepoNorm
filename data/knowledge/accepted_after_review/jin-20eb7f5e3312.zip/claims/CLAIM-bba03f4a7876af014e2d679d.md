# Rule details

- **Rule:** Tests for ModuleLoader path arguments must confirm that ModuleLoader accepts pathlib.Path objects as its path argument.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When modifying or adding ModuleLoader path-argument tests in tests/test_loader.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_loader.py:275-282`
