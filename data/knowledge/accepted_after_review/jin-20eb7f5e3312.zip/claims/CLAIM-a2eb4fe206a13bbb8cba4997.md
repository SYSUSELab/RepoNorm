# Rule details

- **Rule:**
  ```text
  With trim_blocks=True and lstrip_blocks=True, nested if blocks must render to 'a b c ' with the trailing space preserved, demonstrating combined whitespace-trimming behavior for nested block tags.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying nested-block whitespace-trimming tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_trim_nested enables trim_blocks and lstrip_blocks and asserts nested if blocks render exactly to 'a b c ' with the trailing space preserved.
```

- **Sources:**
  - `tests/test_lexnparse.py:954-959`
