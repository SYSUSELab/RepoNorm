# Rule details

- **Rule:**
  ```text
  ChoiceLoader.list_templates must aggregate templates from all loaders into a set and return them sorted, deduplicating across loaders.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ChoiceLoader.list_templates or adding a new loader that participates in template aggregation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/loaders.py:568-572`
