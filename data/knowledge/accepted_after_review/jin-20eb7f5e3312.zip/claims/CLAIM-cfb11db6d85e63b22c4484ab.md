# Rule details

- **Rule:**
  ```text
  flake8 ignores F401 in src/jinja2/__init__.py.
  ```
- **Applies to:**
  - `src/jinja2/__init__.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
per-file-ignores =
    # __init__ exports names
    src/jinja2/__init__.py: F401

```

- **Sources:**
  - `setup.cfg:83-85`
