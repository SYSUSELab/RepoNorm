# Rule details

- **Rule:** Include tests when a patch adds or changes code, and ensure the test fails without the patch.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Include tests if your patch adds or changes code. Make sure the test
    fails without your patch.

```

- **Sources:**
  - `CONTRIBUTING.rst:57-58`

## Review evidence locations

- `CONTRIBUTING.rst:50-61`
