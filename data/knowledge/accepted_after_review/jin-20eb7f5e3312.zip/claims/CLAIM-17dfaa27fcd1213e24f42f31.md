# Rule details

- **Rule:** Tests for recursive for-loops must verify that loop.depth starts at 1 and increments per recursion level, with rendered output encoding depth and item values.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** when modifying or extending async for-loop tests for recursive depth tracking
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async.py:425-439`
