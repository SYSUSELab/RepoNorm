# Rule details

- **Rule:**
  ```text
  FileSystemLoader.list_templates must walk every configured searchpath with os.walk(followlinks=self.followlinks), normalize each discovered path to a forward-slash path relative to its searchpath, strip a leading './', deduplicate across searchpaths, and return the sorted result.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying FileSystemLoader.list_templates or the path-normalization/deduplication logic it uses to enumerate templates across searchpaths.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
FileSystemLoader.list_templates walks each searchpath with os.walk(followlinks=self.followlinks), normalizes to forward-slash relative paths, strips leading './', deduplicates via a set, and returns sorted output, satisfying the enumeration contract.
```

- **Sources:**
  - `src/jinja2/loaders.py:216-231`
