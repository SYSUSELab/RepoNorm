# Rule details

- **Rule:**
  ```text
  Tests in tests/test_lexnparse.py that exercise lexer or parser behavior must assert the exact decoded or rendered value, including escape sequences, subscript indices, and trailing-newline handling, rather than only checking that parsing succeeds.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying a lexer or parser test in tests/test_lexnparse.py that exercises string escapes, subscript expressions, or trailing-newline handling.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:93-134`
- `tests/test_lexnparse.py:333-335`
