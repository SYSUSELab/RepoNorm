# Rule details

- **Rule:**
  ```text
  Pytest treats warnings as errors (filterwarnings = error), except the deprecation warning 'The loop argument' from asyncio.base_events, which is ignored.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
filterwarnings =
    error
    # Python 3.9 raises a deprecation from internal asyncio code.
    ignore:The loop argument:DeprecationWarning:asyncio[.]base_events:542

```

- **Sources:**
  - `setup.cfg:48-51`

## Review evidence locations

- `setup.cfg:46-52`
