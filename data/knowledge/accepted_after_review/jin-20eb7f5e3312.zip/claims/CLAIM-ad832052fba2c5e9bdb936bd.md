# Rule details

- **Rule:**
  ```text
  The reorder-python-imports pre-commit hook declares the additional dependency setuptools>60.9.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        additional_dependencies: ["setuptools>60.9"]

```

- **Sources:**
  - `.pre-commit-config.yaml:15`

## Review evidence locations

- `.pre-commit-config.yaml:15-15`
