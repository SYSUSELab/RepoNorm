# Rule details

- **Rule:** Lexer line-number reporting must remain stable across whitespace-stripping block tags: tokens following a {%- ... -%} block still report their original source line.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying lexer line-number tracking or whitespace-stripping block handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:166-181`
