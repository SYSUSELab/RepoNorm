# Rule details

- **Rule:**
  ```text
  load_bytecode only opens and loads the cache file when os.path.exists is true, so a missing cache file is silently ignored rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying bytecode cache loading behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/bccache.py:262-268`
