# Rule details

- **Rule:**
  ```text
  parse_filter supports dotted filter names by consuming consecutive dot-name tokens, and supports inline filter parsing via the start_inline flag without consuming a leading pipe token.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.parse_filter or filter-name parsing
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/parser.py:918-939`
