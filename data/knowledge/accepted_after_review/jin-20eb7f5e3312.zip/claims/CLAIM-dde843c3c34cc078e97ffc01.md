# Rule details

- **Rule:**
  ```text
  Tests for the new-style i18n extension must exercise pluralization through the `{% trans %}`/`{% pluralize %}` block, where the pluralize variable name must match the `count` variable; a mismatch must raise TemplateAssertionError.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When adding or modifying new-style i18n pluralization tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:515-525`
