# Rule details

- **Rule:**
  ```text
  Whitespace-control tests must assert that raw blocks still honor {%- and -%} markers when lstrip_blocks and trim_blocks are enabled.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for whitespace control interaction with raw blocks.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:809-813`
