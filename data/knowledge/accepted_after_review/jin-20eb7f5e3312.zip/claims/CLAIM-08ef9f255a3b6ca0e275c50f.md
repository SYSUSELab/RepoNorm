# Rule details

- **Rule:** Tests for the FileSystemLoader must assert that the encoding parameter is honored, so the same template bytes render differently under iso-8859-1 versus utf-8.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:** When adding or modifying a test for FileSystemLoader encoding behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_loader.py:161-172`
