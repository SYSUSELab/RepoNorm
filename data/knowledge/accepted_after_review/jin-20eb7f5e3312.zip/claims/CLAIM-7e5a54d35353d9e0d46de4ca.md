# Rule details

- **Rule:**
  ```text
  Sandbox operator restriction tests must preserve that disable_op raises TemplateRuntimeError('that operator so does not work') to verify sandbox operator restrictions.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:**
  ```text
  When modifying or extending sandbox operator restriction tests in tests/test_security.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_security.py:99-125`
