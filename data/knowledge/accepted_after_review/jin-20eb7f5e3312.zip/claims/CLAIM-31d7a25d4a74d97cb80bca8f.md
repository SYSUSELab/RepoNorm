# Rule details

- **Rule:**
  ```text
  fake_traceback must synthesize a traceback pointing at template source by compiling a raise statement at the template line number and rewriting the code object's co_name to a template location label; on Python <3.8 it must reconstruct CodeType manually because co_name replacement is unavailable.
  ```
- **Applies to:**
  - `src/jinja2/debug.py`
- **Condition:**
  ```text
  When modifying fake_traceback or template traceback synthesis, including Python-version compatibility handling.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/debug.py:76-147`
