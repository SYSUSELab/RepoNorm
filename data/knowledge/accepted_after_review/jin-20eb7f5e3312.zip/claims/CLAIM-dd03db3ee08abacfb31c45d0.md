# Rule details

- **Rule:**
  ```text
  Lexer tests must assert that newline_sequence normalizes all of \r, \r\n, and \n in template output to the configured sequence.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying tests for newline_sequence normalization.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:115-120`
