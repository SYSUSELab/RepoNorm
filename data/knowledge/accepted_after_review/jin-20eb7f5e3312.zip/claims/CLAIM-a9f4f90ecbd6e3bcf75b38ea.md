# Rule details

- **Rule:**
  ```text
  The tojson filter must escape <, >, &, and ' as unicode escapes when autoescape is enabled, and must honor env.policies['json.dumps_function'] and env.policies['json.dumps_kwargs'] to override the dumps callable and its keyword arguments.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying the tojson filter, JSON escaping, or json.dumps policy handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:789-802`
