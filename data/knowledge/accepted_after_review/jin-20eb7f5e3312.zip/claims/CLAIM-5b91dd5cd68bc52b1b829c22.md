# Rule details

- **Rule:**
  ```text
  Tests for the `sameas` test must assert identity semantics: `foo is sameas false` is True only when foo is the False singleton, and integer 0 is not the same object as False.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When adding or modifying `sameas` identity tests in tests/test_tests.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_tests.py:158-160`
