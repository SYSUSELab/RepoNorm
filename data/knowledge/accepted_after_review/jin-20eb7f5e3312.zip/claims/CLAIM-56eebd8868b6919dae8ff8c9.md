# Rule details

- **Rule:**
  ```text
  fail_eof builds an end-token stack from the current parser state and optional end_tokens before delegating to _fail_ut_eof for end-of-template error reporting.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.fail_eof or end-of-template error reporting
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Parser.fail_eof builds an end-token stack from current parser state and optional end_tokens before delegating to _fail_ut_eof, preserving the delegation contract.
```

- **Sources:**
  - `src/jinja2/parser.py:137-146`
