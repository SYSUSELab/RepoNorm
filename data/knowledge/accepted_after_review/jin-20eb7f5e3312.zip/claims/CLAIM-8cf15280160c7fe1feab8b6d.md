# Rule details

- **Rule:** Contributors submitting a feature addition or change branch off of the "main" branch.
- **Applies to:**
  - `**`
- **Condition:** when submitting a feature addition or change
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    If you're submitting a feature addition or change, branch off of the
    "main" branch.

```

- **Sources:**
  - `CONTRIBUTING.rst:149-150`

## Review evidence locations

- `CONTRIBUTING.rst:149-150`
