# Rule details

- **Rule:**
  ```text
  Template syntax tests must preserve operator precedence and undefined-handling semantics: `not` binds around the `in` test, short conditional expressions render empty when undefined, and attribute access on an undefined conditional result raises UndefinedError.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying lexer/parser tests for operator precedence or conditional-expression undefined handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:444-453`
- `tests/test_lexnparse.py:525-528`
