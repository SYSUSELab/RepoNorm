# Rule details

- **Rule:** The first filter must return the first element of an iterable, asserted as '0' for range(10).
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying the first-filter test in the filter test module
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_first renders {{ foo|first }} over range(10) and asserts the output is '0', confirming the first filter returns the first element.
```

- **Sources:**
  - `tests/test_filters.py:138-141`
