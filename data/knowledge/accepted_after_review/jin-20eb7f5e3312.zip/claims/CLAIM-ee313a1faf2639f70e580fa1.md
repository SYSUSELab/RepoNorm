# Rule details

- **Rule:**
  ```text
  DictLoader.list_templates returns sorted(self.mapping), so template listing order is deterministic and alphabetical.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  when modifying DictLoader.list_templates or template listing order
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/loaders.py:395-416`
