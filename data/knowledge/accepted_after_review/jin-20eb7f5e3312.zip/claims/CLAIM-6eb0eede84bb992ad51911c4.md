# Rule details

- **Rule:**
  ```text
  The `last` filter must return the final element of a list (e.g. rendering '9' for range(10)).
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the `last` filter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test asserts the last filter returns the final element, rendering '9' for range(10), matching the rule.
```

- **Sources:**
  - `tests/test_filters.py:239-242`
