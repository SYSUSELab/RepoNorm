# Rule details

- **Rule:** Sub must be a BinExpr subclass whose operator is '-', mapping the subtraction AST node to its operator string.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying Sub or the subtraction AST node operator mapping
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Sub is defined as a BinExpr subclass with operator '-', matching the subtraction AST node operator mapping.
```

- **Sources:**
  - `src/jinja2/nodes.py:971-974`
