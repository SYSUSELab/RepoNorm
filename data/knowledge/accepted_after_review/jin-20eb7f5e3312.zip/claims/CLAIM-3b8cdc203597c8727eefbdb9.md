# Rule details

- **Rule:**
  ```text
  Tests for custom delimiter configurations must verify that rendering preserves the indentation of inner content lines when lstrip_blocks and trim_blocks are enabled, rather than only checking that the delimiters are accepted.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying a test that configures custom block/variable/comment delimiters on the Environment.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:854-866`
