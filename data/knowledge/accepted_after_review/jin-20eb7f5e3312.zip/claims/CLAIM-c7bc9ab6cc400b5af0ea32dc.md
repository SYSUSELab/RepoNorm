# Rule details

- **Rule:**
  ```text
  open_if_exists must return None when the path is not a regular file and otherwise open it with the given mode (default 'rb'), defining the safe-open helper contract used by loaders.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  when modifying open_if_exists or loader code that relies on its safe-open contract
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
open_if_exists returns None when os.path.isfile is false and otherwise opens the file with the given mode defaulting to 'rb', defining the safe-open contract.
```

- **Sources:**
  - `src/jinja2/utils.py:155-162`
