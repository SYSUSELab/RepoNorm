# Rule details

- **Rule:**
  ```text
  Custom delimiter tests must assert that ERB-style delimiters with lstrip_blocks and trim_blocks strip comment and control lines while output lines retain leading indentation.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for custom ERB-style delimiters with whitespace control.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:854-866`
