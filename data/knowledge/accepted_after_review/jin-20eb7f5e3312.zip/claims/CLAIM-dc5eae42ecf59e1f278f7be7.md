# Rule details

- **Rule:** SandboxedEscapeFormatter must combine SandboxedFormatter and EscapeFormatter via multiple inheritance with no overrides, so its behavior is entirely the MRO composition of the two bases.
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When modifying SandboxedEscapeFormatter or sandbox formatter composition.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/sandbox.py:409-428`
