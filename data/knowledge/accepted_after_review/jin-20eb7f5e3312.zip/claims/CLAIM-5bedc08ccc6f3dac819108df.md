# Rule details

- **Rule:**
  ```text
  NativeTemplate binds NativeEnvironment as its environment_class, and NativeEnvironment binds NativeTemplate as its template_class at module import, so native rendering behavior is selected by the environment's template class rather than a separate render path.
  ```
- **Applies to:**
  - `src/jinja2/nativetypes.py`
- **Condition:** when modifying NativeTemplate or NativeEnvironment class bindings or native rendering selection
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nativetypes.py:88-130`
