# Rule details

- **Rule:**
  ```text
  The @unsafe decorator must set the unsafe_callable attribute to True on the decorated function or method, which the sandbox inspects to deny calls.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying the @unsafe decorator or adding sandbox checks that rely on the unsafe_callable marker.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The unsafe decorator sets f.unsafe_callable = True on the decorated callable, matching the sandbox marker convention.
```

- **Sources:**
  - `src/jinja2/sandbox.py:112-122`
