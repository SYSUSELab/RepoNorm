# Rule details

- **Rule:**
  ```text
  Coverage path configuration sets source to the src directory and to */site-packages.
  ```
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
source =
    src
    */site-packages

```

- **Sources:**
  - `setup.cfg:60-62`

## Review evidence locations

- `setup.cfg:60-62`
