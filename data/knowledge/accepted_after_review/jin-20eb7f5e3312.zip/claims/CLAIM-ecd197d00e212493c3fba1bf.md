# Rule details

- **Rule:**
  ```text
  Install coverage with ``pip install coverage``, run tests under coverage with ``coverage run -m pytest``, and generate an HTML report with ``coverage html``.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    $ pip install coverage
    $ coverage run -m pytest
    $ coverage html

```

- **Sources:**
  - `CONTRIBUTING.rst:201-203`

## Review evidence locations

- `CONTRIBUTING.rst:201-203`
