# Rule details

- **Rule:** When modifying the Template AST node, preserve its role as the outermost node passed to the compiler with fields=('body',) and body typed as a list of Node.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying the Template AST node definition or its compiler contract
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:292-298`
