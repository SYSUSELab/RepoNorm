# Rule details

- **Rule:**
  ```text
  When modifying filter argument validation, preserve that do_dictsort accepts only by='key' or by='value' and raises FilterArgumentError for any other value before sorting.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing do_dictsort's accepted by values or its error handling for invalid arguments.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
do_dictsort accepts only by='key' or by='value', raising FilterArgumentError otherwise, then returns sorted(value.items(), key=sort_func, reverse=reverse).
```

- **Sources:**
  - `src/jinja2/filters.py:315-353`
