# Rule details

- **Rule:**
  ```text
  ImmutableSandboxedEnvironment must behave like SandboxedEnvironment but forbid modifications to builtin mutable list, set, and dict objects via modifies_known_mutable.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When modifying sandbox immutability behavior in the sandbox module.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/sandbox.py:396-406`
