# Rule details

- **Rule:** Tests for template module exports must assert that top-level macros and set variables are exposed as attributes while names starting with double underscore and macros defined inside a for loop are not exposed.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** When adding or modifying a test for template module attribute visibility.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_imports.py:79-93`
