# Rule details

- **Rule:** ChoiceLoader must try each configured loader in order and fall back to the next when a template is not found, enabling user templates to override builtin templates from a different location.
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** When modifying ChoiceLoader or its ordered fallback behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/loaders.py:527-566`
