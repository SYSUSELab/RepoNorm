# Rule details

- **Rule:**
  ```text
  Tests that exercise Jinja's whitespace-control modifiers must assert that the '+' modifier is a no-op when trim_blocks is False, because this defines the whitespace-control contract for the lexer/parser.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying tests for whitespace-control modifiers with trim_blocks disabled
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:936-952`
