# Rule details

- **Rule:**
  ```text
  make_module_async must be used instead of make_module for async execution because module creation can invoke template code; the module attribute is unavailable in async mode.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when creating a module from a template in an async execution context
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:1397-1411`
- `src/jinja2/environment.py:1426-1468`
