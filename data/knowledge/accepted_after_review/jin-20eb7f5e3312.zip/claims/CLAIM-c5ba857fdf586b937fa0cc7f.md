# Rule details

- **Rule:**
  ```text
  Tests in tests/test_filters.py that exercise filter behavior must assert the exact rendered output string, including ordering, chunking, padding, and case-sensitivity semantics, rather than only checking that rendering succeeds.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When adding or modifying a filter test in tests/test_filters.py that exercises groupby, slice, min/max, or truncate behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:65-79`
