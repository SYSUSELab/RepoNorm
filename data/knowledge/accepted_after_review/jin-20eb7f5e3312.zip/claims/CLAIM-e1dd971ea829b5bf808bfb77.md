# Rule details

- **Rule:** Tests for Jinja loop index variables must assert that index and revindex are 1-based for a single-iteration loop.
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:** when adding or modifying tests for Jinja loop index variables
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_loop_idx asserts the rendered output '[(len=1, revindex=1, index=1, val=10)]', confirming index and revindex are 1-based for a single-iteration loop.
```

- **Sources:**
  - `tests/test_runtime.py:17-21`

### Evidence 2 — current_observation

```text
test_loop_idx0 renders a single-iteration loop and asserts index0=0 and revindex0=0, confirming the 1-based index/revindex contract for a one-element loop.
```

- **Sources:**
  - `tests/test_runtime.py:24-28`

### Evidence 3 — current_observation

```text
Calc.__call__ is a helper method, not a test asserting loop index values; the packet's root r0 predicate requires a test asserting 1-based index/revindex, which this entity does not provide.
```

- **Sources:**
  - `tests/test_runtime.py:69-70`

## Review evidence locations

- `tests/test_runtime.py:17-28`
