# Rule details

- **Rule:** Autoescape scoping tests must assert that enabling autoescape changes macro output type to Markup while disabling it yields str, and that compiled raw source reflects escaping of literal template text.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for autoescape scope effects on macro output and compiled source.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:675-698`
