# Rule details

- **Rule:** Contributors submitting a bug or documentation fix branch off of the latest ".x" branch.
- **Applies to:**
  - `**`
- **Condition:** when submitting a bug or documentation fix
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Create a branch to identify the issue you would like to work on. If
    you're submitting a bug or documentation fix, branch off of the
    latest ".x" branch.

```

- **Sources:**
  - `CONTRIBUTING.rst:140-142`

## Review evidence locations

- `CONTRIBUTING.rst:140-142`
