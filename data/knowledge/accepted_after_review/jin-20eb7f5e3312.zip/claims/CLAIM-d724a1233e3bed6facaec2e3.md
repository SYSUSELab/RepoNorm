# Rule details

- **Rule:** Filter behavior must preserve documented semantics: abs returns 1 for both -1 and 1, sum defaults to start=0, and groupby accepts an integer attribute index for tuple grouping.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying filter implementations or the filter test surface in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:421-448`
- `tests/test_filters.py:577-584`
