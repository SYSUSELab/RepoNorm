# Rule details

- **Rule:**
  ```text
  Cycler.current must return self.items[self.pos], i.e. the item that will be returned by the next call to next.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying Cycler.current or adding a new iterator property that must match the next-item semantics.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Cycler.current returns self.items[self.pos], the item that will be returned by the next call to next, preserving the documented semantics.
```

- **Sources:**
  - `src/jinja2/utils.py:703-707`
