# Rule details

- **Rule:** flake8 enforces a maximum line length of 80.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
max-line-length = 80

```

- **Sources:**
  - `setup.cfg:82`
