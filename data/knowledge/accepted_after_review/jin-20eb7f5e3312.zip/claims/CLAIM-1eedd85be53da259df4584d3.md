# Rule details

- **Rule:**
  ```text
  test_boolean must return value is True or value is False, so only the exact bool singletons count as boolean, not truthy values.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  When modifying test_boolean or the boolean test semantics used by templates.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/tests.py:96-101`
