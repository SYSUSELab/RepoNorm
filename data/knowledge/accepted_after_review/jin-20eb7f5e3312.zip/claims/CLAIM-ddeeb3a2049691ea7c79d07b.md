# Rule details

- **Rule:** The tests job's update pip step upgrades wheel, setuptools, and pip.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: update pip
        run: |
          pip install -U wheel
          pip install -U setuptools
          python -m pip install -U pip

```

- **Sources:**
  - `.github/workflows/tests.yaml:43-47`

## Review evidence locations

- `.github/workflows/tests.yaml:43-47`
