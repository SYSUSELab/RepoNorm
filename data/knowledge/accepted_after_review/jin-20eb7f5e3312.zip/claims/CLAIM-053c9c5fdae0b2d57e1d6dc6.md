# Rule details

- **Rule:** Run the basic test suite with pytest.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Run the basic test suite with pytest.

.. code-block:: text

    $ pytest

```

- **Sources:**
  - `CONTRIBUTING.rst:176-180`

## Review evidence locations

- `CONTRIBUTING.rst:176-180`
