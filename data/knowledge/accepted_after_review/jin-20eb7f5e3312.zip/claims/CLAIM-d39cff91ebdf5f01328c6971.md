# Rule details

- **Rule:**
  ```text
  test_odd returns value % 2 == 1, so negative odd integers (e.g. -3) evaluate as not odd under this implementation.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_odd or odd-number test semantics
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_odd returns value % 2 == 1, preserving the documented odd-number semantics including negative odd integers evaluating as not odd.
```

- **Sources:**
  - `src/jinja2/tests.py:14-16`
