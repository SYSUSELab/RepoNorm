# Rule details

- **Rule:** The urlize filter's target parameter must be rendered as an anchor target attribute while rel="noopener" is always added, so callers cannot opt out of rel=noopener via target.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the urlize target-parameter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_urlize_target_parameter asserts the target parameter renders as an anchor target attribute while rel="noopener" is unconditionally added, matching the rule.
```

- **Sources:**
  - `tests/test_filters.py:383-391`
