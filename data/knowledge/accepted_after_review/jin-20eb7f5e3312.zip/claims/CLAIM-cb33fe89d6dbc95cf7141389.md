# Rule details

- **Rule:**
  ```text
  Tests for loader path-splitting behavior must import split_template_path from jinja2.loaders, treating it as part of the loader's tested public surface.
  ```
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When modifying or adding loader path-splitting tests in tests/test_loader.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_loader.py:19-19`
