# Rule details

- **Rule:**
  ```text
  __repr__ formats as '<ClassName {get_all()!r} of {name!r}>', tying the representation to the object's name and full contents.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  when modifying Context.__repr__ or context representation behavior
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/runtime.py:321-336`
