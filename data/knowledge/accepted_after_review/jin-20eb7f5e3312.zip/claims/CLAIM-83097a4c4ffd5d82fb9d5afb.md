# Rule details

- **Rule:**
  ```text
  do_wordcount must count words by applying _word_re.findall to soft_str(s) and returning the length, so non-string inputs are stringified rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_wordcount or other word-counting filters in the filters module.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:936-941`
