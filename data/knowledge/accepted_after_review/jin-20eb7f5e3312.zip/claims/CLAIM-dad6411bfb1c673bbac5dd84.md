# Rule details

- **Rule:**
  ```text
  Newstyle internationalization tests must preserve plural-form selection and translation for the German locale: rendering ngettext_long.html with apples=5 and LANGUAGE='de' yields '5 Äpfel'.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying newstyle i18n pluralization behavior or the TestNewstyleInternationalization test class.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:558-560`
