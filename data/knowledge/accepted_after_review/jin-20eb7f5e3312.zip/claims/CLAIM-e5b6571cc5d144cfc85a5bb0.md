# Rule details

- **Rule:**
  ```text
  Undefined.__str__ must return an empty string so undefined values render as empty output rather than raising during string conversion.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying Undefined.__str__ or undefined-value rendering behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/runtime.py:878-888`
