# Rule details

- **Rule:**
  ```text
  Referencing an undefined test name must raise TemplateAssertionError with a message matching "No test named '<name>'".
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying test-name resolution or the error raised for unknown tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_tests.py:213-215`
