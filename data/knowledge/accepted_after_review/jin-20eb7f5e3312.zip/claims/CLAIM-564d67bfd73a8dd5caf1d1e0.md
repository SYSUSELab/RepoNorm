# Rule details

- **Rule:**
  ```text
  The docs build configuration must derive `release`/`version` from `pallets_sphinx_themes.get_version("Jinja2")`, set `html_title` to `f"Jinja Documentation ({version})"`, and embed the version in the LaTeX output filename.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:** When modifying the docs build configuration's version derivation, HTML title, or LaTeX output filename.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
docs/conf.py derives release/version from pallets_sphinx_themes.get_version("Jinja2"), sets html_title to f"Jinja Documentation ({version})", and embeds the version in the LaTeX filename.
```

- **Sources:**
  - `docs/conf.py`
