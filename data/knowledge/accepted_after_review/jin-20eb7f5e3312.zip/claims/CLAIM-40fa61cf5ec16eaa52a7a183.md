# Rule details

- **Rule:**
  ```text
  Tests for the `is defined` test in native mode must assert that a missing variable renders falsy.
  ```
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:**
  ```text
  When adding or modifying `is defined` native-mode tests in tests/test_nativetypes.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_nativetypes.py:16-18`
