# Rule details

- **Rule:** When modifying the sameas test, preserve the use of identity comparison (value is other) rather than equality.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** when modifying the sameas test implementation
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/tests.py:179-189`
