# Rule details

- **Rule:** YAML, JSON, JavaScript, CSS, and HTML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
indent_size = 2

```

- **Sources:**
  - `.editorconfig:13`
