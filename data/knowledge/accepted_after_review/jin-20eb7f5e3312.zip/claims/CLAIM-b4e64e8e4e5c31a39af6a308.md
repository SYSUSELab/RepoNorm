# Rule details

- **Rule:**
  ```text
  FileSystemBytecodeCache must default its directory to _get_default_cache_dir() when none is given and use the pattern "__jinja2_%s.cache" by default.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  When modifying FileSystemBytecodeCache.__init__ or its default directory/pattern configuration.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/bccache.py:186-210`
