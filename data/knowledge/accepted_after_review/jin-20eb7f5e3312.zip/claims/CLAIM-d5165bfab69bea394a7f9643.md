# Rule details

- **Rule:**
  ```text
  mypy is configured with disallow_subclassing_any = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
disallow_subclassing_any = True

```

- **Sources:**
  - `setup.cfg:91`

## Review evidence locations

- `setup.cfg:91-91`
