# Rule details

- **Rule:**
  ```text
  Tests for lstrip_blocks and trim_blocks must verify that with both options enabled, a block inside parentheses renders with trim_blocks removing the newline after the block tag while lstrip_blocks strips leading whitespace before block tags.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  when modifying or extending lexer/parser tests for lstrip_blocks or trim_blocks whitespace handling
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:753-761`
