# Rule details

- **Rule:**
  ```text
  _from_namespace must build a Template via object.__new__(cls), pull name, __file__, blocks, root, and debug_info from the namespace, and write environment and __jinja_template__ back into the namespace.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Template._from_namespace or namespace-based template reconstruction
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:1231-1257`
