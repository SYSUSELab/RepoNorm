# Rule details

- **Rule:** Rendering empty list, dict, and tuple literals must return their literal string forms unchanged.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying literal parsing or rendering of collection literals.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:395-398`
