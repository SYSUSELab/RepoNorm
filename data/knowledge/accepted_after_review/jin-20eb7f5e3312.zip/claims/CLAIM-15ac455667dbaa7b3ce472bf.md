# Rule details

- **Rule:**
  ```text
  Environment._generate must remain an overridable internal hook that delegates to the module-level generate with defer_init and optimized=self.optimized, so subclasses can override code generation without changing the public API.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment._generate or subclassing Environment to customize code generation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:667-686`
