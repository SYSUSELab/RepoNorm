# Rule details

- **Rule:**
  ```text
  The `test` test must check whether a named test exists, returning truthy for known tests and falsy for unknown names without raising errors.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When modifying tests for the `test` test existence check.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_tests.py:231-233`
