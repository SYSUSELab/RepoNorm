# Rule details

- **Rule:**
  ```text
  TemplateModule.__html__ must return Markup(concat(self._body_stream)) so objects exposing __html__ are treated as already-safe HTML and their body stream is concatenated without escaping.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying TemplateModule.__html__ or any code path that treats __html__-exposing objects as safe HTML
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:1505-1535`
