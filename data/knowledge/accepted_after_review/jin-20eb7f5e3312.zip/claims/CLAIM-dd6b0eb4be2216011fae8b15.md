# Rule details

- **Rule:**
  ```text
  Tests for the stringformat.html template with newstyle_i18n_env must assert that new-style i18n formatting renders the expected localized output.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When adding or modifying new-style i18n stringformat tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:527-529`
