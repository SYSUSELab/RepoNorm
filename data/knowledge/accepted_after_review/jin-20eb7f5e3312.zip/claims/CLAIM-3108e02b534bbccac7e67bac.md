# Rule details

- **Rule:**
  ```text
  parse_list must build a nodes.List from bracket-delimited expressions, allowing trailing commas and empty lists, and must record the opening bracket's line number.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** When modifying list parsing in the parser module.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/parser.py:744-754`
