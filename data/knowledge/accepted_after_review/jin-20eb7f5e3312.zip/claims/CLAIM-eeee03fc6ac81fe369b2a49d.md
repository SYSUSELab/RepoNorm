# Rule details

- **Rule:**
  ```text
  Template attribute access must treat dot access and subscript access as equivalent for dict values: foo.bar and foo['bar'] both yield the same value.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying template attribute or subscript resolution behavior exercised by tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:329-331`
