# Rule details

- **Rule:**
  ```text
  Sandbox security tests must assert that accessing dangerous attributes such as __subclasses__ through the attr filter raises SecurityError.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:**
  ```text
  When modifying or adding sandbox attribute-access security tests in tests/test_security.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_security.py:94-97`
