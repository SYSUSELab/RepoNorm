# Rule details

- **Rule:** Package discovery uses setuptools' find: directive, so packages are auto-discovered rather than listed explicitly.
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
packages = find:

```

- **Sources:**
  - `setup.cfg:33`
