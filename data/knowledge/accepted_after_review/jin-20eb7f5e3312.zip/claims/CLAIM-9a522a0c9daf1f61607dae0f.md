# Rule details

- **Rule:**
  ```text
  test_integer must return True only for int instances that are not True and not False, explicitly excluding booleans from the integer test despite being int subclasses.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_integer or the boolean-exclusion behavior of the integer test
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/tests.py:120-126`
