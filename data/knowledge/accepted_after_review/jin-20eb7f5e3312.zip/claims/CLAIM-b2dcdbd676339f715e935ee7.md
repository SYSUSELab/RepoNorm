# Rule details

- **Rule:**
  ```text
  rewrite_traceback_stack must be called inside an except block; it marks TemplateSyntaxError as translated, clears the old traceback, skips frames decorated with @internalcode, and maps template frames to source line numbers.
  ```
- **Applies to:**
  - `src/jinja2/debug.py`
- **Condition:**
  ```text
  when modifying rewrite_traceback_stack or traceback rewriting behavior
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/debug.py:14-73`
