# Rule details

- **Rule:** Range collapsing for the identifier pattern must group sorted unique characters into sequential code-point ranges using itertools.groupby on ord(char) - index, yielding (start, end) pairs.
- **Applies to:**
  - `scripts/generate_identifier_pattern.py`
- **Condition:** When changing how the generator collapses character sets into ranges.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
collapse_ranges uses itertools.groupby(enumerate(data), lambda x: ord(x[1]) - x[0]) and yields (b[0][1], b[-1][1]) range pairs, exactly the ord-minus-index grouping rule.
```

- **Sources:**
  - `scripts/generate_identifier_pattern.py:26-34`
