# Rule details

- **Rule:**
  ```text
  Async filter tests must assert that a filter returning a list can be subscripted or sliced in the template when enable_async=True, preserving the expected rendered result.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying or adding async filter tests that exercise subscripting or slicing of filter results in templates.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async.py:647-652`
