# Rule details

- **Rule:**
  ```text
  NodeVisitor dispatch must resolve a handler named 'visit_' + node class name, fall back to generic_visit when no such handler exists, and route through get_visitor so subclasses can override dispatch resolution.
  ```
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:**
  ```text
  When adding or modifying node visitor dispatch, handler resolution, or the generic_visit fallback in the visitor module.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/visitor.py:16-47`
