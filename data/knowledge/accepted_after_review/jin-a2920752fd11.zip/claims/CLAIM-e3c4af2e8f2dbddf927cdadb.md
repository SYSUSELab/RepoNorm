# Rule details

- **Rule:**
  ```text
  mypy is configured with warn_unreachable = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
warn_unreachable = True

```

- **Sources:**
  - `setup.cfg:103`

## Review evidence locations

- `setup.cfg:99-103`
