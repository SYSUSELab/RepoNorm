# Rule details

- **Rule:**
  ```text
  BytecodeCache.dump_bytecode must remain an abstract method that subclasses override to write a bucket's bytecode back to the cache, and it must raise an exception rather than fail silently when unable to do so.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  When modifying BytecodeCache.dump_bytecode or its subclasses, keep it abstract and ensure failures raise an exception rather than failing silently.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/bccache.py:101-142`
