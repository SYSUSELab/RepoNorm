# Rule details

- **Rule:**
  ```text
  The filesystem_loader fixture must resolve the test file's parent directory and return a FileSystemLoader rooted at res/templates, establishing the repository convention for filesystem-based template tests.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** when adding or modifying filesystem-based template test fixtures or tests that load templates from disk
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/conftest.py:27-31`
