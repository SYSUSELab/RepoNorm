# Rule details

- **Rule:**
  ```text
  Indentation uses spaces (indent_style = space) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
indent_style = space

```

- **Sources:**
  - `.editorconfig:4`
