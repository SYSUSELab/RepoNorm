# Rule details

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_If, preserve the soft-frame branch isolation: compile the test and all branches using a soft frame so if/elif/else blocks share the same if_frame and branch bodies do not leak symbol changes into the outer frame.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing if/elif/else code generation or frame handling in the compiler.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
CodeGenerator.visit_If uses frame.soft() and shares the same if_frame across the test, elif branches, and else branch, preserving soft-frame branch isolation.
```

- **Sources:**
  - `src/jinja2/compiler.py:1296-1315`
