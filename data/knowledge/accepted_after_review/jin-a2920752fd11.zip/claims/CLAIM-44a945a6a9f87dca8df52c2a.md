# Rule details

- **Rule:**
  ```text
  Getitem nodes must expose fields (node, arg, ctx) and represent item access (subscript) rather than attribute access, and Getitem.as_const must only fold in load context, wrapping any environment.getitem failure as Impossible.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying the Getitem node class or its as_const method, preserve the (node, arg, ctx) field contract, the item-access semantics, and the load-context-only constant folding that fails closed.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:831-850`
