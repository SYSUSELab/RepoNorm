# Rule details

- **Rule:** Break is a Stmt subclass representing loop break; its presence in the node hierarchy means compiler/visitor code must handle Break nodes when processing loop bodies.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying loop body processing or visitor handling of Break nodes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:1141-1146`
