# Rule details

- **Rule:** The docs tox environment builds HTML documentation with sphinx-build using -W (warnings as errors), reading from docs and writing to {envtmpdir}/html with doctrees in {envtmpdir}/doctrees.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
commands = sphinx-build -W -b html -d {envtmpdir}/doctrees docs {envtmpdir}/html

```

- **Sources:**
  - `tox.ini:24`

## Review evidence locations

- `tox.ini:22-24`
