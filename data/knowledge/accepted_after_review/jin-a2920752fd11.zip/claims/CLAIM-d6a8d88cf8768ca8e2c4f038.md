# Rule details

- **Rule:**
  ```text
  mypy is configured with python_version = 3.7.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
python_version = 3.7

```

- **Sources:**
  - `setup.cfg:89`

## Review evidence locations

- `setup.cfg:87-90`
