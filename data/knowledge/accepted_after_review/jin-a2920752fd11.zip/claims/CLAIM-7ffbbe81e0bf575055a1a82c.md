# Rule details

- **Rule:**
  ```text
  For the jinja2.defaults module, mypy's no_implicit_reexport check is disabled (set to False).
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
no_implicit_reexport = False

```

- **Sources:**
  - `setup.cfg:106`

## Review evidence locations

- `setup.cfg:105-106`
