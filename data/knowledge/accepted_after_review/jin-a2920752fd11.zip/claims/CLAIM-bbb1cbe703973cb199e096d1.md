# Rule details

- **Rule:**
  ```text
  TokenStream.next_if performs a token test against the current token and returns the next token if it matches, otherwise returns None without consuming input.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When modifying token lookahead helpers or token stream consumption behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/lexer.py:365-372`
