# Rule details

- **Rule:**
  ```text
  Scoped eval-context modifiers must save the eval context, apply the modifier, visit the body, then revert both the frame eval_ctx and the emitted context.eval_ctx so scoped changes do not leak.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying scoped eval-context modifier code generation
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:1947-1957`
