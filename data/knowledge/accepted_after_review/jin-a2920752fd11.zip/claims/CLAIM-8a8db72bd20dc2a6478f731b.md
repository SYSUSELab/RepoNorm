# Rule details

- **Rule:**
  ```text
  Tests that assert on repr output of the PrivateStuff helper must depend on the literal string "PrivateStuff" returned by its __repr__, not the class name.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:** when adding or modifying tests that assert on repr output of the PrivateStuff helper
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_security.py:14-23`
