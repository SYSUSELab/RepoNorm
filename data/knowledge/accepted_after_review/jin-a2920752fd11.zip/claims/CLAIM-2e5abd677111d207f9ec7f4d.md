# Rule details

- **Rule:** Tests for for-else semantics must assert that the else body executes when the iterable is empty, including nested for-else constructs.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** when adding or modifying tests for for-else behavior with empty iterables
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_regression.py:320-326`
