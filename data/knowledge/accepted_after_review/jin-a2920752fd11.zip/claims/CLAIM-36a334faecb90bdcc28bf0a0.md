# Rule details

- **Rule:** A NativeTemplate constructed without an environment must receive a NativeEnvironment instance so that standalone use still yields native-type rendering behavior.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying tests for standalone NativeTemplate construction without an explicit environment.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_spontaneous_env constructs NativeTemplate without an environment and asserts its environment is a NativeEnvironment instance, matching the rule.
```

- **Sources:**
  - `tests/test_nativetypes.py:147-149`
