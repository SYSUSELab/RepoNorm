# Rule details

- **Rule:** Tests for set blocks under autoescape must assert that a filtered set block renders its captured content escaped.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:** When modifying or adding tests covering set blocks with filters under autoescape.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_core_tags.py:541-546`
