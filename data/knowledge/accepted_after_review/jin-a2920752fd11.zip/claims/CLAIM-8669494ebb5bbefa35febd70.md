# Rule details

- **Rule:**
  ```text
  When modifying symbol tracking, preserve the contract that visit_Block stops visiting at blocks so symbol tracking does not descend into block bodies.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** When changing or extending symbol tracking traversal of block nodes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/idtracking.py:232-247`
- `src/jinja2/idtracking.py:307-315`
