# Rule details

- **Rule:**
  ```text
  iter_fields yields (name, value) for fields filtered by exclude/only and silently skips fields raising AttributeError, so optional node fields are tolerated during traversal.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying node field traversal or adding optional node fields
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:145-165`
