# Rule details

- **Rule:**
  ```text
  When modifying Context.get, preserve the runtime API contract: return the provided default when the key is missing rather than raising, distinguishing it from __getitem__ which propagates KeyError.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing Context.get or its missing-key behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/runtime.py:198-208`
- `src/jinja2/runtime.py:324-331`
