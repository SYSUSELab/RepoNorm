# Rule details

- **Rule:**
  ```text
  mypy is configured with warn_unused_ignores = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
warn_unused_ignores = True

```

- **Sources:**
  - `setup.cfg:101`

## Review evidence locations

- `setup.cfg:87-103`
