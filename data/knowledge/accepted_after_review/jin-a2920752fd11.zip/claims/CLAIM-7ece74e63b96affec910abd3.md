# Rule details

- **Rule:** Const nodes must be Literal nodes with fields ('value',) and value typed as Any, and must only be used for constants with a safe representation where eval(repr(x)) == x is true.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying the Const node class or adding constant values, preserve the ('value',) field contract and the safe-representation requirement eval(repr(x)) == x.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:575-603`
