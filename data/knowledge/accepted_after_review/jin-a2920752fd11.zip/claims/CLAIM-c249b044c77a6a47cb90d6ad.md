# Rule details

- **Rule:** TokenStream.eos is defined as the negation of the stream's truthiness, so eos is true exactly when the stream is exhausted.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** when modifying TokenStream exhaustion checks or the eos property
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/lexer.py:340-346`
