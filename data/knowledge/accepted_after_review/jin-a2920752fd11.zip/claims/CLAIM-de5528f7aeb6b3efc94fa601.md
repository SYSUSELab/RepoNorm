# Rule details

- **Rule:**
  ```text
  Tests for the TokenStream must assert that truthiness is true while not at EOF and false once the current token is TOKEN_EOF, with eos being the inverse of bool(ts).
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** when adding or modifying tests for TokenStream truthiness and EOF behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/lexer.py:340-346`
- `tests/test_lexnparse.py:21-33`
