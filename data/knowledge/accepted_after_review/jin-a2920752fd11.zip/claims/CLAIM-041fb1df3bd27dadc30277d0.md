# Rule details

- **Rule:**
  ```text
  When modifying the Node base class, preserve the contract that Node declares fields as a tuple, attributes as ("lineno", "environment"), abstract = True, and __hash__ = object.__hash__, so nodes are hashable by identity and environment is attached automatically at the end of parsing.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When changing or extending the Node base class's field/attribute declarations or hashing behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:112-122`
- `src/jinja2/nodes.py:238-244`
