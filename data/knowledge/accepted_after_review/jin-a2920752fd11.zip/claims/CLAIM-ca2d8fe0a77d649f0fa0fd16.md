# Rule details

- **Rule:**
  ```text
  mypy is configured with no_implicit_optional = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
no_implicit_optional = True

```

- **Sources:**
  - `setup.cfg:95`

## Review evidence locations

- `setup.cfg:87-97`
