# Rule details

- **Rule:** Tests for the groupby filter must assert that the default parameter supplies a group key for items missing the grouping attribute, grouping those items under the default value.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying or adding tests covering the groupby filter's default parameter.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:607-620`
