# Rule details

- **Rule:**
  ```text
  For feature additions or changes, branch off "main" using `git fetch origin` followed by `git checkout -b your-branch-name origin/main`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        $ git fetch origin
        $ git checkout -b your-branch-name origin/main

```

- **Sources:**
  - `CONTRIBUTING.rst:154-155`

## Review evidence locations

- `CONTRIBUTING.rst:149-155`
