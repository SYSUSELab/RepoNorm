# Rule details

- **Rule:** The i18n extension must be configured with gettext/ngettext/pgettext/npgettext globals and support a trimmed-policy environment; do not change the extension's global registration or policy handling without updating the i18n test setup.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying the i18n extension's globals, policy handling, or environment configuration.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:118-141`
