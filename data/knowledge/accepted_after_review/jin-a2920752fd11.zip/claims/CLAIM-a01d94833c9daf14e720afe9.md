# Rule details

- **Rule:**
  ```text
  symbols_for_node assigns scoped names like l_0_foo and records loads as ('undefined', None), ('resolve', name), or ('param', None) depending on whether the name is assigned, resolved from outer scope, or a loop parameter.
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:** When modifying symbol tracking or id-tracking logic, preserve the scoped-name and load-classification conventions for assigned, resolved, and loop-parameter names.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_basics asserts scoped names like l_0_foo and load classifications ('undefined', None), ('resolve', name), ('param', None), matching the r12 symbol-tracking conventions.
```

- **Sources:**
  - `tests/test_idtracking.py:5-36`
