# Rule details

- **Rule:** Tests for async iteration in templates must preserve that generate() over an async iterable yields the first loop index immediately and that joining the remaining stream produces the expected concatenated output.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying or extending async iteration tests in tests/test_async.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async.py:104-110`
