# Rule details

- **Rule:** The pre-commit configuration enables the trailing-whitespace hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: trailing-whitespace

```

- **Sources:**
  - `.pre-commit-config.yaml:33`

## Review evidence locations

- `.pre-commit-config.yaml:29-34`
