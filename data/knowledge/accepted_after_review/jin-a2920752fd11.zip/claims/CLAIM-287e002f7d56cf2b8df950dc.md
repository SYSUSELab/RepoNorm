# Rule details

- **Rule:** The tox testenv installs test dependencies from requirements/tests.txt.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
deps = -r requirements/tests.txt

```

- **Sources:**
  - `tox.ini:10`

## Review evidence locations

- `tox.ini:9-11`
