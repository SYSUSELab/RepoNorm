# Rule details

- **Rule:**
  ```text
  Tests for sandboxed string formatting must assert that `str.format` field access to ordinary attributes is permitted while access to blocked attributes such as `__class__` is denied.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:**
  ```text
  When modifying or extending sandboxed string formatting tests in tests/test_security.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_security.py:128-137`
