# Rule details

- **Rule:**
  ```text
  When modifying the idtracking visitor, preserve visit_For's boundary behavior: the visitor stops at for blocks but still visits the iter expression as part of the outer scope.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  changing how FrameSymbolVisitor.visit_For handles for blocks and their iter expressions
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
FrameSymbolVisitor.visit_For visits node.iter and stops at for blocks, preserving the boundary behavior that the visitor stops at for blocks while visiting the iter expression in the outer scope.
```

- **Sources:**
  - `src/jinja2/idtracking.py:291-295`
