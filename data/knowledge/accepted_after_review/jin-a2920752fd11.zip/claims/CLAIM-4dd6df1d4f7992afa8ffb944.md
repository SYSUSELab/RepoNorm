# Rule details

- **Rule:**
  ```text
  Tests for block scoping must verify that a block-local set does not leak to the outer template scope, preserving pass_context global reads.
  ```
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:**
  ```text
  When adding or modifying tests for block-local variable scoping and pass_context globals.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_regression.py:659-675`
