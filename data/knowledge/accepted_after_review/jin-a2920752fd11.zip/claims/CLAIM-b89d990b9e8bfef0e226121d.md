# Rule details

- **Rule:**
  ```text
  Lexer rules are represented as a _Rule NamedTuple with pattern, tokens (string, tuple of strings, or tuple of Failure), and an optional command; the Failure token type encodes lexer error states within the same rule structure.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** when adding or modifying lexer rules or their token specifications
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/lexer.py:463-466`
- `src/jinja2/lexer.py:536-545`
