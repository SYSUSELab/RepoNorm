# Rule details

- **Rule:** The wordcount filter must propagate undefined access: with StrictUndefined, applying wordcount to an undefined variable raises UndefinedError rather than silently returning a value.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when modifying wordcount filter undefined-variable handling in the filter tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:404-411`
