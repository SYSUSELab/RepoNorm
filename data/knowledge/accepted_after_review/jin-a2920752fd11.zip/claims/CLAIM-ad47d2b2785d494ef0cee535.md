# Rule details

- **Rule:**
  ```text
  Install the pre-commit hooks with `pre-commit install`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Install the pre-commit hooks.

    .. code-block:: text

        $ pre-commit install

```

- **Sources:**
  - `CONTRIBUTING.rst:123-127`

## Review evidence locations

- `CONTRIBUTING.rst:123-127`
