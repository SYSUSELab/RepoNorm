# Rule details

- **Rule:** Tests for macro caller scoping must assert that a caller variable set outside a macro is not visible inside the macro.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:** When modifying or adding tests covering macro caller variable scoping.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_core_tags.py:409-416`
