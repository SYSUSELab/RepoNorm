# Rule details

- **Rule:**
  ```text
  When modifying TemplateData compilation, preserve the autoescape codegen contract: write repr of the constant when foldable; if folding raises Impossible, emit a runtime conditional choosing Markup or identity based on context.eval_ctx.autoescape, so autoescape is applied at runtime for non-constant data.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.visit_TemplateData or its constant-folding/autoescape emission.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:1636-1642`
