# Rule details

- **Rule:**
  ```text
  When modifying create_cache or its callers, preserve the size semantics: size 0 returns None, negative size returns an unbounded dict, and any other size returns an LRUCache(size).
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  Editing create_cache or code that depends on its size-based cache selection in src/jinja2/environment.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:80-90`
