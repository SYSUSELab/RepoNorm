# Rule details

- **Rule:** The workflow updates wheel, setuptools, and pip before running tests.
- **Applies to:**
  - `.github/workflows/tests.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: |
          pip install -U wheel
          pip install -U setuptools
          python -m pip install -U pip

```

- **Sources:**
  - `.github/workflows/tests.yaml:44-47`
