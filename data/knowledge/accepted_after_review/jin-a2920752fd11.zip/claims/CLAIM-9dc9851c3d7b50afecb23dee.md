# Rule details

- **Rule:**
  ```text
  mypy is configured with local_partial_types = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
local_partial_types = True

```

- **Sources:**
  - `setup.cfg:96`

## Review evidence locations

- `setup.cfg:87-97`
