# Rule details

- **Rule:** Tests for the i18n extension's trimmed policy must assert that surrounding whitespace inside trans blocks is stripped, in contrast to the default policy which preserves it.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or adding tests covering the i18n extension's trimmed policy for trans blocks.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:359-364`
