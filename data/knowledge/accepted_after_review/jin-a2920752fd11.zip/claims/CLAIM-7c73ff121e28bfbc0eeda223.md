# Rule details

- **Rule:**
  ```text
  When modifying multi-attribute getter construction, preserve the contract that make_multi_attrgetter splits a comma-separated attribute string, prepares each part, and returns a callable producing a list of extracted values, where dots access nested attributes and integer parts are looked up as integers.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When changing or extending how multi-attribute getters parse and extract attribute values.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:83-121`
- `src/jinja2/filters.py:124-131`
