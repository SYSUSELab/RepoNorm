# Rule details

- **Rule:**
  ```text
  When modifying NodeTransformer.generic_visit or its callers, preserve the in-place mutation protocol: list fields are rebuilt with visited nodes, None results are dropped, non-Node return values are extended into the list, and a None result for a single Node field deletes the attribute.
  ```
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:**
  ```text
  Editing NodeTransformer.generic_visit or code that relies on its mutation behavior in src/jinja2/visitor.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/visitor.py:61-81`
