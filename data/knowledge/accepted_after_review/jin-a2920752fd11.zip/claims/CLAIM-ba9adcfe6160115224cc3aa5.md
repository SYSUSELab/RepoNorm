# Rule details

- **Rule:** The compiler generate function must raise TypeError for non-Template nodes and return the generated source string only when no stream is provided; with a stream it returns None.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying the compiler generate entry point or its stream handling
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:101-122`
