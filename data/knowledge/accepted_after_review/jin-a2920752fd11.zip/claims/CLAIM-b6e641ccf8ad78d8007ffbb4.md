# Rule details

- **Rule:** The replace filter must escape replacement values under autoescape, and replacing into Markup must preserve markup escaping semantics.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** Modifying or adding tests for the replace filter's escaping behavior under autoescape.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:193-208`
- `tests/test_filters.py:647-657`
