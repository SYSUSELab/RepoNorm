# Rule details

- **Rule:** When a macro is invoked via a {% call %} block, the macro body must access the caller's rendered content through caller(), and the macro's own output must wrap that caller content rather than replacing it.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:** Modifying or adding tests for {% call %} block macro invocation behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_core_tags.py:393-399`
