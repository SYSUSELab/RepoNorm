# Rule details

- **Rule:**
  ```text
  The package requires Python >= 3.7 (python_requires = >= 3.7).
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
python_requires = >= 3.7

```

- **Sources:**
  - `setup.cfg:36`

## Review evidence locations

- `setup.cfg:32-36`
