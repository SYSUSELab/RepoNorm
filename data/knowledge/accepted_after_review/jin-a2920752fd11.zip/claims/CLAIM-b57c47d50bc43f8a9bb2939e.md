# Rule details

- **Rule:** Tests for the safe filter must assert that marking a string safe bypasses autoescaping, while the same string without safe is HTML-escaped.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying or adding tests covering the safe filter's interaction with autoescaping.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:663-668`
