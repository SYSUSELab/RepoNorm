# Rule details

- **Rule:**
  ```text
  When modifying the compiler's comparison-operator handling, preserve the operators mapping from Jinja operator names to Python operators (eq->==, ne->!=, gt->>, gteq->>=, lt-><, lteq-><=, in->in, notin->not in).
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing or extending how the compiler translates Jinja comparison operators into Python operators.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:31-40`
