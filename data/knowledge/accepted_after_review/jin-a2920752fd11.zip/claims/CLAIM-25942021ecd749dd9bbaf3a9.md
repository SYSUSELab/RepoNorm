# Rule details

- **Rule:** Keyword compilation emits 'key=' followed by the compiled value expression, so keyword arguments are rendered as name=value pairs.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying keyword argument compilation in the compiler.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:1863-1865`
