# Rule details

- **Rule:** Tests for native list concatenation must assert that adding two lists with + in a native environment returns an actual list containing the concatenated elements, preserving Python list semantics.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** when adding or modifying tests for native environment list concatenation
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_nativetypes.py:40-44`
