# Rule details

- **Rule:**
  ```text
  make_module_async must be used instead of make_module for asynchronous execution because module creation can invoke template code; in async mode the module attribute becomes unavailable.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** When adding or modifying asynchronous template module creation or the module attribute.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:1397-1411`
- `src/jinja2/environment.py:1454-1466`
