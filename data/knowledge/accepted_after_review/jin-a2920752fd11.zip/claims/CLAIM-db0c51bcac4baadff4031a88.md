# Rule details

- **Rule:**
  ```text
  TemplateExpression is the object returned by Environment.compile_expression, encapsulating expression-like access to a template; this is a public API contract contributors must preserve.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Environment.compile_expression or the TemplateExpression return type
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:760-803`
- `src/jinja2/environment.py:1545-1561`
