# Rule details

- **Rule:** The 'is' type tests must follow Python-like semantics: booleans are numbers but not integers/floats; strings are sequences and iterables but not mappings; dicts are sequences, mappings, and iterables; range is callable and iterable; large ints are integer and number but not float.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** when modifying 'is' type-test semantics in the test suite
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_tests.py:45-115`
