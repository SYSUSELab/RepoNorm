# Rule details

- **Rule:**
  ```text
  Tests for the `unique` filter must assert that duplicate removal preserves first-occurrence order, and that passing `true` makes the comparison case-sensitive so values differing only in case are both retained.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending `unique` filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:533-539`
