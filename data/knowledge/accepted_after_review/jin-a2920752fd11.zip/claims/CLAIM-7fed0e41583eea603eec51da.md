# Rule details

- **Rule:**
  ```text
  TokenStream.__next__ returns the previous current token and advances via a pushed deque or the underlying iterator, closing the stream on StopIteration; callers are directed to use built-in next rather than calling it directly.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When modifying TokenStream iteration or token advancement logic.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/lexer.py:378-399`
