# Rule details

- **Rule:** ExtensionAttribute node declares fields ('identifier','name') and is documented as constructed via Extension.attr, defining the extension-attribute AST contract.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying the ExtensionAttribute AST node or extension attribute construction.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:1039-1049`
