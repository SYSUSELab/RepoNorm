# Rule details

- **Rule:**
  ```text
  unsafe_undefined returns an Undefined carrying name, obj, and exc=SecurityError, so unsafe attribute access surfaces as a SecurityError-backed undefined rather than a plain undefined.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When modifying sandbox undefined handling or unsafe attribute access behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/sandbox.py:338-345`
