# Rule details

- **Rule:** Environment instances must remain picklable and, after a pickle round-trip, must still render templates identically; do not add unpicklable state (locks, open handles, generators, compiled closures) to Environment or its base classes.
- **Applies to:**
  - `tests/test_pickle.py`
- **Condition:** When modifying Environment construction, attributes, or base-class state that participates in pickling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_pickle.py:1-6`
