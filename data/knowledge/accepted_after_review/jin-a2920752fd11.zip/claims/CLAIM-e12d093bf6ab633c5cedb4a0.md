# Rule details

- **Rule:** When modifying TemplateStream.dump, preserve the API contract: accept a path string or file-like object; when given a path, default encoding to utf-8, open the file in binary mode, and close it afterward.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** Changing TemplateStream.dump or its path/file-like handling.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
TemplateStream.dump accepts a path string or file-like object, defaults encoding to utf-8 for paths, opens in binary mode, and closes the file in a finally block.
```

- **Sources:**
  - `src/jinja2/environment.py:1579-1614`
