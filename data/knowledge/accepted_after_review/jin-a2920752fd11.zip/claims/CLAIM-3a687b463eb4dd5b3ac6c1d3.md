# Rule details

- **Rule:** The lock job runs on ubuntu-latest and uses the dessant/lock-threads@v3 action with github-token set to ${{ github.token }}, issue-inactive-days set to 14, and pr-inactive-days set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    runs-on: ubuntu-latest

```

- **Sources:**
  - `.github/workflows/lock.yaml:9`

### Evidence 2 — explicit

```text
      - uses: dessant/lock-threads@v3
        with:
          github-token: ${{ github.token }}
          issue-inactive-days: 14
          pr-inactive-days: 14

```

- **Sources:**
  - `.github/workflows/lock.yaml:11-15`

## Review evidence locations

- `.github/workflows/lock.yaml:7-15`
