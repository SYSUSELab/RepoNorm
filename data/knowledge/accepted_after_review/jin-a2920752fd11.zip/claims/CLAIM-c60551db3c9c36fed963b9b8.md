# Rule details

- **Rule:**
  ```text
  Tests that exercise the async rendering path must keep enable_async=True and assert ordered chunk output from Template.generate(), because async generation yields rendered chunks in order rather than a single string.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  when modifying or adding async rendering tests in tests/test_async.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async.py:87-101`
