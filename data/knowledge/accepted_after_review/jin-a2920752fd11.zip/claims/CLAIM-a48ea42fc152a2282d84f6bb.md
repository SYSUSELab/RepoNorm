# Rule details

- **Rule:**
  ```text
  mypy is configured with show_error_codes = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
show_error_codes = True

```

- **Sources:**
  - `setup.cfg:90`

## Review evidence locations

- `setup.cfg:87-90`
