# Rule details

- **Rule:** The identifier-pattern generator must collapse sorted unique characters into consecutive code-point ranges using itertools.groupby keyed on ord(c)-index, yielding (start,end) tuples for each run.
- **Applies to:**
  - `scripts/generate_identifier_pattern.py`
- **Condition:** When changing how character sets are grouped into ranges for the generated pattern.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `scripts/generate_identifier_pattern.py:26-34`
