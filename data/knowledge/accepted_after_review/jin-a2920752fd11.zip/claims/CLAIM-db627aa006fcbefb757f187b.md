# Rule details

- **Rule:**
  ```text
  When modifying Macro._invoke, preserve the async/autoescape dispatch contract: dispatch to _async_invoke when the environment is async, otherwise call the function directly and wrap the result in Markup when autoescape is enabled.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  Changing Macro._invoke or its async/autoescape dispatch.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Macro._invoke dispatches to _async_invoke when the environment is async, otherwise calls self._func and wraps the result in Markup when autoescape is enabled, matching the dispatch contract.
```

- **Sources:**
  - `src/jinja2/runtime.py:773-782`
