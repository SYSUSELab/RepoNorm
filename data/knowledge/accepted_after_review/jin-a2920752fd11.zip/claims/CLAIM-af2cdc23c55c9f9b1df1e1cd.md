# Rule details

- **Rule:**
  ```text
  Overlay scopes are compiled as isolated frames: visit_OverlayScope derives a context, assigns vars from the node context, pushes a context reference, compiles the body in an isolated inner frame, then pops the context reference.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying OverlayScope compilation or the frame/context handling around overlay bodies.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:1920-1932`
