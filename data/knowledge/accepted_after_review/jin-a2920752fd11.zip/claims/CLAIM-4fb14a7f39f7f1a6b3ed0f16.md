# Rule details

- **Rule:** The i18n extension exposes pgettext(context, message) as part of its gettext-style API surface, indicating context-aware translation support.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** When modifying the i18n extension's translation API surface.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/ext.py:32-50`
- `src/jinja2/ext.py:329-337`
