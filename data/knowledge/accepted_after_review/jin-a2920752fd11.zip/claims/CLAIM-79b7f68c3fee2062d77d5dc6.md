# Rule details

- **Rule:**
  ```text
  When modifying UndeclaredNameVisitor.__init__ or its callers, preserve the invariant that undeclared names are tracked separately from declared names, with undeclared initialized as an empty set.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Editing UndeclaredNameVisitor.__init__ or code that relies on undeclared-name tracking in src/jinja2/compiler.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:271-287`
