# Rule details

- **Rule:** Tests for macro varargs must verify that extra positional arguments are exposed via the varargs variable and can be joined and rendered.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:** When adding or modifying tests for macro varargs handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_core_tags.py:385-391`
