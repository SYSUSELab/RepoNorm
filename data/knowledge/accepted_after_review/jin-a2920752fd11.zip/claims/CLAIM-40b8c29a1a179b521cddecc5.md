# Rule details

- **Rule:**
  ```text
  CodeGenerator.visit_Template must assert no root frame is allowed, emit imports of exported runtime names, detect extends to decide whether inheritance code is needed, reject duplicate block names, and generate root and block render functions with distinct frame handling.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying CodeGenerator.visit_Template, preserve the no-root-frame assertion, exported-name imports, extends-based inheritance decision, duplicate-block rejection, and distinct root/block frame handling.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
CodeGenerator.visit_Template asserts frame is None (no root frame allowed), emits imports of exported/async_exported runtime names, detects Extends to decide inheritance code, rejects duplicate block names via self.fail, and generates root and block render functions with distinct frame handling.
```

- **Sources:**
  - `src/jinja2/compiler.py:826-942`
