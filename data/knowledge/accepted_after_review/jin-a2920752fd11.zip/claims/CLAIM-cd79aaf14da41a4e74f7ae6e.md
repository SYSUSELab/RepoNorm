# Rule details

- **Rule:** The tox testenv:typing environment runs mypy as its command.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
commands = mypy

```

- **Sources:**
  - `tox.ini:20`

## Review evidence locations

- `tox.ini:18-20`
