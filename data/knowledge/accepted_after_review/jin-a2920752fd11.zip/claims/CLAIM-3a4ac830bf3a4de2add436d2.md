# Rule details

- **Rule:** Assign must declare fields ("target", "node"), fixing the AST field order and names for assignment nodes.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying the Assign AST node's field declarations or field order.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:448-453`
