# Rule details

- **Rule:**
  ```text
  ModuleLoader loads precompiled templates and sets has_source_access = False, so it cannot provide template source.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** When modifying ModuleLoader behavior or source-access capability flags on loaders.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/loaders.py:579-592`
