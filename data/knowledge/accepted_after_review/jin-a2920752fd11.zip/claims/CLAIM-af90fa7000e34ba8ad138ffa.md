# Rule details

- **Rule:** Regression tests for loop scoping and recursion must assert that loop.index values and recursive loop() compilation behave correctly when loops are nested inside call blocks or other loops.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** when adding or modifying regression tests that cover nested loops, call blocks, or recursive loop() compilation
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_regression.py:125-140`
- `tests/test_regression.py:252-278`
