# Rule details

- **Rule:** The indent filter's second argument controls indenting the first line and the third argument controls indenting blank lines; do not change these argument semantics.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying the indent filter's first/blank argument handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:784-800`
