# Rule details

- **Rule:**
  ```text
  The lock workflow runs on a daily schedule defined by the cron expression '0 0 * * *'.
  ```
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  schedule:
    - cron: '0 0 * * *'

```

- **Sources:**
  - `.github/workflows/lock.yaml:4-5`

## Review evidence locations

- `.github/workflows/lock.yaml:1-5`
