# Rule details

- **Rule:** Macro autoescape behavior is determined by the call site's autoescape state, not the environment in which the macro was defined; a macro defined under autoescape-disabled still renders escaped when invoked inside an {% autoescape true %} block.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** When modifying macro rendering or autoescape handling, preserve call-site autoescape semantics for macros defined under a different autoescape environment.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_macro_escaping defines a macro under an autoescape-disabled Environment and invokes it inside an {% autoescape true %} block, exercising call-site autoescape semantics for macros.
```

- **Sources:**
  - `tests/test_regression.py:365-369`

## Review evidence locations

- `tests/test_regression.py:625-657`
