# Rule details

- **Rule:** Package discovery uses find: so packages are auto-discovered rather than explicitly listed.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
packages = find:

```

- **Sources:**
  - `setup.cfg:33`

## Review evidence locations

- `setup.cfg:32-34`
