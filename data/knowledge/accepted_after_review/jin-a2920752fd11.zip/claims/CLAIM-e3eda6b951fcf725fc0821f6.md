# Rule details

- **Rule:** A cache extension must register its template tag by declaring tags = {"cache"} on the extension class.
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** when adding or modifying the fragment cache extension's template tag registration
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
FragmentCacheExtension declares tags = {"cache"}, registering the cache template tag as required.
```

- **Sources:**
  - `docs/examples/cache_extension.py:5-54`
