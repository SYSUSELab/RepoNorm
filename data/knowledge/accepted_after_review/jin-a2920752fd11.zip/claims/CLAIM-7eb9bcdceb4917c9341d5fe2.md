# Rule details

- **Rule:** When a name is undefined, an if-guarded test expression ({{ x is f }}) is not evaluated and renders empty; when x is defined, an unknown test name raises TemplateRuntimeError with message "No test named 'f'".
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying test-expression evaluation or undefined-name handling, preserve that if-guarded test expressions are not evaluated for undefined names and that unknown test names raise TemplateRuntimeError when the name is defined.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_name_undefined_in_if asserts empty rendering for an undefined name in an if-guarded test expression and TemplateRuntimeError with "No test named 'f'" when the name is defined, matching the undefined-name guard and unknown-test-name error behavior.
```

- **Sources:**
  - `tests/test_tests.py:218-223`
