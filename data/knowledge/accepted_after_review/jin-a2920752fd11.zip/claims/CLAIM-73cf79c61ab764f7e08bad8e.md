# Rule details

- **Rule:**
  ```text
  Tests for custom async filters must register them on env_async.filters and assert they are invoked for both static and dynamic arguments with expected rendered output.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** when adding or modifying tests for custom async filters
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async_filters.py:248-255`
