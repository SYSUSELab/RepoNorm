# Rule details

- **Rule:** Tests for the rejectattr filter must preserve that rejectattr("id", "odd") removes users with odd ids, leaving only the expected remaining entries after mapping and joining.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending rejectattr filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:795-806`
