# Rule details

- **Rule:**
  ```text
  NSRef assignment must target a Namespace: visit_NSRef emits a runtime isinstance check that raises TemplateRuntimeError when the target is not a Namespace, so changes to NSRef compilation must preserve this guard.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying NSRef compilation or the runtime target of namespace attribute assignment.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:1615-1627`
