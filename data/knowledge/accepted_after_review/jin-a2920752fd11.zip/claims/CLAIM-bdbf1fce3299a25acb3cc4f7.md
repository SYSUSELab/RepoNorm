# Rule details

- **Rule:** i18n pluralization tests must assert that npgettext.html renders the singular form for count 1 and the plural form for count 5 under a non-default LANGUAGE.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or adding i18n pluralization tests that render npgettext.html with varying counts.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:599-602`
