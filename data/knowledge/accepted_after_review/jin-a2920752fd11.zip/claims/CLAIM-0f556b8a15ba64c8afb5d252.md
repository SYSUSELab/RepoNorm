# Rule details

- **Rule:** The docs tox environment installs dependencies from requirements/docs.txt.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
deps = -r requirements/docs.txt

```

- **Sources:**
  - `tox.ini:23`

## Review evidence locations

- `tox.ini:22-24`
