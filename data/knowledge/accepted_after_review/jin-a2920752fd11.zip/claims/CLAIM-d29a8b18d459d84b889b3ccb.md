# Rule details

- **Rule:**
  ```text
  Node dumping emits 'nodes.<ClassName>(' followed by each field value; list fields are emitted as bracketed comma-separated dumps and non-Node values as repr, and nodes with no fields emit '()'.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying node dumping or the serialized representation of nodes
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:250-273`
