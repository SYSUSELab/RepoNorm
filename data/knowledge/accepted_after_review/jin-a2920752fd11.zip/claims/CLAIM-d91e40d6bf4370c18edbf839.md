# Rule details

- **Rule:** Tests for symbol tracking must assert that a variable assigned before an if-branch is recorded as undefined at the branch load site while the store remains tracked.
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:**
  ```text
  When modifying or extending symbol tracking tests in tests/test_idtracking.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_idtracking.py:236-258`
