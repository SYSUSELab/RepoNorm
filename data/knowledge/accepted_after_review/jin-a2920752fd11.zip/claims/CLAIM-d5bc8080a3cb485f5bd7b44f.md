# Rule details

- **Rule:** Tests for the int filter's default keyword must assert that non-numeric input returns the default value rather than raising.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  when adding or modifying int filter default tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:213-215`
