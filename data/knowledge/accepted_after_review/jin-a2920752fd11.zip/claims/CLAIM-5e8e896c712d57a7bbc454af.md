# Rule details

- **Rule:** TokenStream must be documented as an iterable yielding Tokens, but the parser must not iterate it; instead it calls next() to advance one token ahead, with the active token stored as current.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When modifying TokenStream or the parser's token consumption, preserve the next()-based one-token-ahead advancement with the active token stored as current rather than iterating the stream.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
TokenStream.__bool__ checks self._pushed and self.current.type, confirming the active token is stored as current rather than iterating the stream.
```

- **Sources:**
  - `src/jinja2/lexer.py:340-341`

### Evidence 2 — current_observation

```text
TokenStream.push appends to _pushed, consistent with the next()-based one-token-ahead advancement protocol where the active token is stored as current.
```

- **Sources:**
  - `src/jinja2/lexer.py:348-350`

## Review evidence locations

- `src/jinja2/lexer.py:317-338`
