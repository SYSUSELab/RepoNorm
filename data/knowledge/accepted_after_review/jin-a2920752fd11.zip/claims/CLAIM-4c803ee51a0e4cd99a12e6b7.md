# Rule details

- **Rule:** The string filter must render the same as str(x) for a list, documenting the string filter's output equivalence.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** Modifying or adding tests for the string filter's output equivalence with str().
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:294-297`
