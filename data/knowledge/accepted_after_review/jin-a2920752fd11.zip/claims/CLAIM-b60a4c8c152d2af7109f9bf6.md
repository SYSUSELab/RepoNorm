# Rule details

- **Rule:**
  ```text
  Default-filter tests must assert that missing|default('no') renders 'no', false|default('no') renders 'False', false|default('no', true) renders 'no', and given|default('no') renders 'yes'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying or adding default-filter tests that exercise the boolean flag semantics.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:44-49`
