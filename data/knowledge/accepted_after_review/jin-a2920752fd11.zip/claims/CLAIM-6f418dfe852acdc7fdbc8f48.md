# Rule details

- **Rule:**
  ```text
  mypy is configured with strict_equality = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
strict_equality = True

```

- **Sources:**
  - `setup.cfg:98`

## Review evidence locations

- `setup.cfg:87-101`
