# Rule details

- **Rule:** writeline must be defined as the combination of newline followed by write, establishing that line-oriented code generation emits a newline before the content.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying line-oriented code generation helpers such as writeline in the compiler.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:467-472`
