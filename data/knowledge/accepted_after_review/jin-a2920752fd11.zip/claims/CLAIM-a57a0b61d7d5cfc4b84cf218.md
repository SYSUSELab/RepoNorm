# Rule details

- **Rule:**
  ```text
  The async_func helper must be a coroutine returning 42, used as a minimal awaitable fixture in async tests.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** when modifying async test helpers or awaitable fixtures in the async tests
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
async_func is a nested coroutine returning 42, matching the minimal awaitable helper convention in tests/test_async.py.
```

- **Sources:**
  - `tests/test_async.py:47-48`
