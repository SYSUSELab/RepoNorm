# Rule details

- **Rule:**
  ```text
  When modifying undeclared-name analysis, preserve the contract that find_undeclared uses an UndeclaredNameVisitor and stops early on VisitorExit, returning the set of names accessed but not declared.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing or extending compile-time undeclared-name analysis in the compiler.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:142-154`
