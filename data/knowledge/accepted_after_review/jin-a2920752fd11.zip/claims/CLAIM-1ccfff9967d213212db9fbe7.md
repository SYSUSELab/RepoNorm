# Rule details

- **Rule:** Tests for undefined indexing must assert that indexing a non-subscriptable value raises UndefinedError at render time rather than a Python TypeError.
- **Applies to:**
  - `tests/test_api.py`
- **Condition:** When modifying or adding tests covering undefined behavior for invalid indexing.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_api.py:392-394`
