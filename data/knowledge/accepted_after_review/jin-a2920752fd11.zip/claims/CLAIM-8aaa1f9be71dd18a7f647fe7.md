# Rule details

- **Rule:** Tests that assert on undefined test names must pin the exact TemplateAssertionError message text (e.g. "No test named 'f'") so that error-message compatibility is preserved.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** when adding or modifying a test that asserts on an undefined test name error
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_tests.py:210-223`
