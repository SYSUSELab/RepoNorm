# Rule details

- **Rule:** Package discovery for the project is configured to search under the src directory.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
where = src

```

- **Sources:**
  - `setup.cfg:40`

## Review evidence locations

- `setup.cfg:32-40`
