# Rule details

- **Rule:** Tests for the eq/lessthan comparison operators must assert boolean equality results, including comparisons between variables and computed expressions, and must document subproperty access in comparison tests.
- **Applies to:**
  - `tests/test_regression.py`
  - `tests/test_tests.py`
- **Condition:** when adding or modifying tests for the eq, lessthan, or other comparison test operators
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_tests.py:121-135`
- `tests/test_tests.py:171-177`
- `tests/test_regression.py:539-548`
