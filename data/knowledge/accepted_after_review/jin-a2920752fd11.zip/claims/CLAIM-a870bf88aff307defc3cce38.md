# Rule details

- **Rule:**
  ```text
  Tests that exercise the sandbox's unary-operator interception must add the operator to intercepted_unops and assert that rendering raises TemplateRuntimeError, because overriding unop_table alone permits the operator while interception must still block it.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:** when adding or modifying sandbox unary-operator interception tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_security.py:113-125`
