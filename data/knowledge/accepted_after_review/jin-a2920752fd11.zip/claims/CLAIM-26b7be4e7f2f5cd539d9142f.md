# Rule details

- **Rule:** The map filter must apply a named filter to each element of an iterable and compose with downstream filters such as sum; do not change per-element application semantics.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying the map filter or its composition with other filters.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:688-695`
