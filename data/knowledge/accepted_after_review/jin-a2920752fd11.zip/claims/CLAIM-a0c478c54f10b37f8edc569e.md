# Rule details

- **Rule:** position returns 'line {node.lineno}' and appends ' in {self.name!r}' when self.name is not None, defining the human-readable node position format.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying node position formatting or error messages that include positions
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:706-711`
