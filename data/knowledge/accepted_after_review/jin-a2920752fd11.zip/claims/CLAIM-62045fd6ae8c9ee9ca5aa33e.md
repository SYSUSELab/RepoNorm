# Rule details

- **Rule:** Tests for undefined behavior must assert that a callable returning StopIteration renders as empty output while accessing an attribute on that result raises UndefinedError.
- **Applies to:**
  - `tests/test_api.py`
- **Condition:** When modifying or adding tests for undefined behavior around callables returning StopIteration.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_api.py:255-263`
