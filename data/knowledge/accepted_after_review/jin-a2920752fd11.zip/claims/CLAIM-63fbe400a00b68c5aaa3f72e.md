# Rule details

- **Rule:** blockvisit must catch CompilerExit so that block compilation can terminate early; contributors modifying block compilation must preserve this early-exit behavior.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying block compilation or the blockvisit method
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:293-297`
- `src/jinja2/compiler.py:442-451`
