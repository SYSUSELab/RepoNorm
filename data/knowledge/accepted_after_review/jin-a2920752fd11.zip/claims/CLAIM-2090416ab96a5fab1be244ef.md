# Rule details

- **Rule:**
  ```text
  find_load must check the current frame's loads first, then delegate to the parent frame, implementing lexical scope lookup.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** When modifying symbol lookup or lexical scope resolution in the idtracking module.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/idtracking.py:59-66`
