# Rule details

- **Rule:**
  ```text
  The reorder-python-imports pre-commit hook runs with --application-directories src and additional dependency setuptools>60.9.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: reorder-python-imports
        args: ["--application-directories", "src"]
        additional_dependencies: ["setuptools>60.9"]

```

- **Sources:**
  - `.pre-commit-config.yaml:13-15`

## Review evidence locations

- `.pre-commit-config.yaml:10-15`
