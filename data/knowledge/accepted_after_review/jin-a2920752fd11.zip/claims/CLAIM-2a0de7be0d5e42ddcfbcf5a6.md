# Rule details

- **Rule:** Native-type tests must assert that rendering multiple expressions does not preserve native types and instead returns the concatenated string representation.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When modifying or adding native-type tests that render multiple expressions in a single template.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_nativetypes.py:47-51`
