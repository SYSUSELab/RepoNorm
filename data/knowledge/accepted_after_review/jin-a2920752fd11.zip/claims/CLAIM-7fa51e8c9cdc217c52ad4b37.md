# Rule details

- **Rule:**
  ```text
  Extension test helpers must format sandboxed, ext_attr, imported_object, context.blocks, and context 'test_var' into a pipe-delimited string for extension test assertions.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** when adding or modifying extension test helpers that format extension state for assertions
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:151-175`
- `tests/test_ext.py:256-271`
