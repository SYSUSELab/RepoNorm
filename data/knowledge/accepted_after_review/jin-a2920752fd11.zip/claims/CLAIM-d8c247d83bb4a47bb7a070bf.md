# Rule details

- **Rule:**
  ```text
  DependencyFinderVisitor.visit_Test must record the test name into self.tests after generic_visit, so the compiler tracks which named tests are used in a template.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying DependencyFinderVisitor.visit_Test or the dependency-tracking logic, preserve recording the test name into self.tests after generic_visit.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:252-265`
