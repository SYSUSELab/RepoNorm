# Rule details

- **Rule:** A template containing only a string literal expression must render to a str, confirming native-type rendering preserves str for literal-only templates.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** when modifying native-type rendering of literal-only templates in the native types tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_is_defined_native_return renders a literal-only template and asserts the result is falsy, matching the native-type literal rendering convention.
```

- **Sources:**
  - `tests/test_nativetypes.py:16-18`

## Review evidence locations

- `tests/test_nativetypes.py:112-122`
