# Rule details

- **Rule:** The 'greaterthan' test compares operands numerically, rendering '1 is greaterthan 0' as True and '0 is greaterthan 1' as False.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying the greaterthan test or numeric comparison tests, preserve numeric comparison semantics for the greaterthan test.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_tests.py:171-173`
