# Rule details

- **Rule:**
  ```text
  Tests for the sum filter must preserve that summing [1,2,3,4,5,6] renders '21'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending sum filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:421-423`
