# Rule details

- **Rule:**
  ```text
  _min_or_max must return environment.undefined('No aggregated item, sequence was empty.') for empty input so min/max on empty sequences yield Undefined rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when modifying min/max filter aggregation or empty-sequence handling
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:445-462`
