# Rule details

- **Rule:**
  ```text
  do_int parses str with the given base, otherwise int(value); on TypeError/ValueError it falls back to int(float(value)) so that '42.23'|int yields 42, and returns the default only if that also fails.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When modifying the int filter conversion logic.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:944-963`
