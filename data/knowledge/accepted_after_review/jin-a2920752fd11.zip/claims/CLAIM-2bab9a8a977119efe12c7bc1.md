# Rule details

- **Rule:**
  ```text
  When modifying the gettext alias, preserve its pass_context behavior: it resolves and calls the gettext callable from the context, forwarding args and kwargs.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Changing the gettext alias or its context-based callable resolution.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/ext.py:163-167`
