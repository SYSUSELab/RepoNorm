# Rule details

- **Rule:**
  ```text
  args_as_const folds static args and kwargs and converts exceptions from dynamic args/kwargs into Impossible to signal non-constant expressions.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When changing constant folding of call arguments or the Impossible signaling path.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:716-734`
