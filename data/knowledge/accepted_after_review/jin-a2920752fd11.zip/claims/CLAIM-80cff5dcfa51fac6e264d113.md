# Rule details

- **Rule:** The black pre-commit hook is configured at rev 22.1.0.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    rev: 22.1.0
    hooks:
      - id: black

```

- **Sources:**
  - `.pre-commit-config.yaml:17-19`

## Review evidence locations

- `.pre-commit-config.yaml:16-19`
