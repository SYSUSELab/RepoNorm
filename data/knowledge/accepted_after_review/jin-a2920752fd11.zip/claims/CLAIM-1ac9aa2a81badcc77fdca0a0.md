# Rule details

- **Rule:** LoopContext.last must peek the next item and compare to missing, which advances the iterable early; contributors must preserve the documented itertools.groupby-style caveat and the groupby filter workaround.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when modifying LoopContext.last or loop iteration helpers
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/runtime.py:480-500`
