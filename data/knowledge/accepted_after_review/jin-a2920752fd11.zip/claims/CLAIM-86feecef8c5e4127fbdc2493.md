# Rule details

- **Rule:** Environment must honor custom block and variable delimiters; parsing and rendering must use the configured delimiters rather than the defaults.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying lexer/parser delimiter handling or Environment delimiter configuration.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/lexer.py:221-228`
- `tests/test_lexnparse.py:71-77`
- `tests/test_lexnparse.py:79-91`
