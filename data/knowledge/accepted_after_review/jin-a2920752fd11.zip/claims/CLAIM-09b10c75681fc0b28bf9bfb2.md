# Rule details

- **Rule:**
  ```text
  Tests for the escape filter must assert that <, >, &, and double quotes are escaped, with double quote rendered as the numeric entity &#34;.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the escape filter's character escaping
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:81-84`
