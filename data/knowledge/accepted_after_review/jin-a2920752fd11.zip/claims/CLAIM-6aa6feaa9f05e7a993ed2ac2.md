# Rule details

- **Rule:** When modifying the extension protocol, keep extensions exposing a tags set of tag names they handle, as ExprStmtExtension does with tags = {"do"} to register the do tag.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Changing the extension protocol or tag registration.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/ext.py:579-589`
