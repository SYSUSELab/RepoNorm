# Rule details

- **Rule:** Tests for async template imports must assert that imports default to without context: plain import and "without context" render without outer context, while "with context" renders with it, for both import and from-import forms.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** when adding or modifying tests for async template import context semantics
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_unoptimized_scopes asserts rendered output for a macro/include scenario, exercising import context semantics in tests/test_async.py.
```

- **Sources:**
  - `tests/test_async.py:263-275`

## Review evidence locations

- `tests/test_async.py:129-150`
