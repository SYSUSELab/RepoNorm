# Rule details

- **Rule:**
  ```text
  When modifying template construction from compiled code, preserve Template.from_code's namespace contract: execute compiled code in a namespace seeded with 'environment' and '__file__' set to code.co_filename, then construct via _from_namespace and assign _uptodate, including the optional uptodate callback assignment.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  Changing Template.from_code or template construction from compiled code.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:1200-1215`
