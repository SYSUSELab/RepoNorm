# Rule details

- **Rule:**
  ```text
  do_reverse must be declared with a typing.overload returning t.Iterable[V], indicating the filter is typed to preserve the element type of the input iterable.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When modifying the reverse filter's typing or overload declarations.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:1344-1351`
