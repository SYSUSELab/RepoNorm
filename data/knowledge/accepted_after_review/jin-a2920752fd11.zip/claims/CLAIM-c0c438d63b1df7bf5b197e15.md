# Rule details

- **Rule:**
  ```text
  ChoiceLoader.list_templates must aggregate templates from all loaders into a set and return them sorted, so duplicate template names across loaders are deduplicated and output order is deterministic.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ChoiceLoader.list_templates aggregation or template listing order.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/loaders.py:568-572`
