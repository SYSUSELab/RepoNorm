# Rule details

- **Rule:** TrackingCodeGenerator subclasses CodeGenerator and is documented as abusing the code generator for introspection, indicating meta.py reuses compiler machinery rather than a separate parser.
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:** when modifying meta introspection or TrackingCodeGenerator
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/meta.py:14-19`
