# Rule details

- **Rule:**
  ```text
  Tests for the join filter must preserve that a '|' separator over an async iterable renders '1|2|3', exercising both sync and async paths via the dual-iter helper.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:**
  ```text
  When modifying or extending async join-filter tests in tests/test_async_filters.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async_filters.py:117-121`
