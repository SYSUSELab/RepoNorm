# Rule details

- **Rule:** Tests for the finalize hook must assert that finalize is applied to the output value during rendering.
- **Applies to:**
  - `tests/test_api.py`
- **Condition:** When modifying or adding tests covering the Environment finalize hook.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_api.py:39-47`
