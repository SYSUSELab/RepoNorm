# Rule details

- **Rule:**
  ```text
  The built documentation output is viewed by opening `_build/html/index.html` in a browser.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Open ``_build/html/index.html`` in your browser to view the docs.

```

- **Sources:**
  - `CONTRIBUTING.rst:220`

## Review evidence locations

- `CONTRIBUTING.rst:210-220`
