# Rule details

- **Rule:**
  ```text
  When modifying FunctionLoader.__init__, preserve the load_func contract: store the supplied callable, which must accept a template name and return either a string or a (source, filename, uptodate) tuple.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When changing FunctionLoader initialization or the expected load_func signature/return shape.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
FunctionLoader.__init__ stores the supplied load_func callable, preserving the documented load_func contract.
```

- **Sources:**
  - `src/jinja2/loaders.py:437-448`
