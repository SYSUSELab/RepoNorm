# Rule details

- **Rule:**
  ```text
  Tests for the abs filter must assert that both -1|abs and 1|abs render as 1, confirming absolute value behavior for negative and positive inputs.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the abs filter
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:446-448`
