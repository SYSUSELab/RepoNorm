# Rule details

- **Rule:**
  ```text
  When modifying Symbols.__init__, preserve the nesting-level invariant: level is derived from parent.level + 1 when level is None and a parent exists, otherwise 0, and refs, loads, and stores containers are initialized.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  Changing Symbols.__init__ or its level derivation and container initialization.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Symbols.__init__ derives level from parent.level + 1 when level is None and parent exists, else 0, and initializes refs, loads, stores.
```

- **Sources:**
  - `src/jinja2/idtracking.py:31-44`
