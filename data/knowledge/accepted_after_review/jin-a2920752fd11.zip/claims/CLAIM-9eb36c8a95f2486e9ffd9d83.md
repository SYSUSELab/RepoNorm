# Rule details

- **Rule:**
  ```text
  A finalize function decorated with @pass_eval_context receives the EvalContext as its first argument, enabling access to eval_ctx.autoescape inside finalize.
  ```
- **Applies to:**
  - `tests/test_api.py`
- **Condition:**
  ```text
  When modifying finalize callback handling or the pass_eval_context decorator, preserve that the EvalContext is passed as the first argument to finalize.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_api.py:64-71`
