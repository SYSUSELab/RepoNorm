# Rule details

- **Rule:**
  ```text
  When modifying do_forceescape or its callers, preserve the behavior that objects implementing __html__ are coerced via __html__() before escaping, which can double-escape values that already provide HTML markup.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Editing do_forceescape or code that relies on its escaping behavior in src/jinja2/filters.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:136-141`
