# Rule details

- **Rule:** When modifying loop iteration behavior, keep nextitem returning Undefined during the last iteration and preserve the documented early-advance behavior that affects constructs such as groupby.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing LoopContext.nextitem or loop iteration semantics.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/runtime.py:480-524`
