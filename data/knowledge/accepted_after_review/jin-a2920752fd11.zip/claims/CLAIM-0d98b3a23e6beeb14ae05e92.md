# Rule details

- **Rule:** i18n extension tests must assert that rendering a child template with LANGUAGE='de' produces the translated title and body.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or adding i18n extension tests that render child templates with a non-default LANGUAGE.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:316-319`
