# Rule details

- **Rule:**
  ```text
  The runtime object's __repr__ must format as <ClassName 'context.name'>, using the context name in the representation.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When modifying the runtime object representation or its context-name formatting.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/runtime.py:123-131`
