# Rule details

- **Rule:**
  ```text
  When modifying the code generator's output-emission helpers, preserve the frame-buffer contract: start_write must emit 'yield ' when the frame has no buffer and '<buffer>.append(' otherwise, and literal writes must be wrapped by start_write/end_write via simple_write so frame bookkeeping stays consistent.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When changing or adding output-emission logic in the code generator (start_write, simple_write, or callers that emit literal output).
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:422-440`
