# Rule details

- **Rule:**
  ```text
  With lstrip_blocks=True and trim_blocks=False, block tags must consume surrounding whitespace without requiring a trailing newline; do not change whitespace consumption to depend on a trailing newline.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying lstrip_blocks/trim_blocks whitespace handling in the lexer.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:763-771`
