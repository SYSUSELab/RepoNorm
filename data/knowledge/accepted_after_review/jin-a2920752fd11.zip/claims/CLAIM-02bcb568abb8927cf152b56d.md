# Rule details

- **Rule:**
  ```text
  Push commits to your fork using `git push --set-upstream fork your-branch-name`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        $ git push --set-upstream fork your-branch-name

```

- **Sources:**
  - `CONTRIBUTING.rst:167`

## Review evidence locations

- `CONTRIBUTING.rst:161-167`
