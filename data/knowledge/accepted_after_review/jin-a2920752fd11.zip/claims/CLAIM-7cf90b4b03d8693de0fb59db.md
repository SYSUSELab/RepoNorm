# Rule details

- **Rule:**
  ```text
  An inline gettext extension must define regexes that match an optional backslash before `gettext(`/`_(` and before parentheses, so it handles escaped call syntax rather than only plain gettext calls.
  ```
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:** when defining or modifying the regex patterns used by the inline gettext extension
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/examples/inline_gettext_extension.py:9-10`
- `docs/examples/inline_gettext_extension.py:33-48`
