# Rule details

- **Rule:**
  ```text
  sync_do_selectattr must be a thin pass_context wrapper that delegates to select_or_reject with lambda x: x and True, so attribute selection semantics are centralized in select_or_reject rather than in the filter itself.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying attribute selection filters or the select_or_reject delegation pattern.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:1584-1611`
