# Rule details

- **Rule:**
  ```text
  The idtracking visitor stops visiting at Scope nodes, treating them as artificial scope boundaries for symbol tracking, and visit_Import calls generic_visit then stores node.target as a symbol.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** When modifying symbol tracking or scope boundary handling in the idtracking visitor.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/idtracking.py:273-275`
- `src/jinja2/idtracking.py:311-315`
