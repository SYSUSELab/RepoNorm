# Rule details

- **Rule:**
  ```text
  Install and update Jinja2 using pip with the command `pip install -U Jinja2`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Install and update using `pip`_:

.. code-block:: text

    $ pip install -U Jinja2

```

- **Sources:**
  - `README.rst:32-36`

## Review evidence locations

- `README.rst:30-36`
