# Rule details

- **Rule:** Tests that exercise the title filter must preserve its documented boundary and whitespace semantics: internal whitespace runs are kept, and hyphen, tab, parentheses, braces, brackets, and angle brackets act as word boundaries that capitalize the following letter while lowercasing the rest; non-string inputs are accepted via str conversion.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending title-filter test coverage in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:299-309`
- `tests/test_filters.py:299-319`
