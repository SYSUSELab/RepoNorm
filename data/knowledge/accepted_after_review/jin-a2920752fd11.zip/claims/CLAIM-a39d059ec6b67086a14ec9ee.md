# Rule details

- **Rule:**
  ```text
  When modifying the extension token-stream initializer, preserve that it stores tokens and comment_tags and initializes offset=0 and last_lineno=0 as the mutable cursor state used while parsing extension tokens.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Changing the extension token-stream initializer or its cursor state initialization.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_CommentFinder.__init__ stores tokens and comment_tags and initializes offset=0 and last_lineno=0, preserving the token-stream cursor state contract.
```

- **Sources:**
  - `src/jinja2/ext.py:730-736`
