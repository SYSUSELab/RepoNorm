# Rule details

- **Rule:**
  ```text
  Template.from_module_dict must remain a classmethod that constructs a Template from a module dict and globals by delegating to _from_namespace, as the documented entry point used by the module loader.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when modifying Template construction from compiled module dicts or the module loader path
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:1217-1229`
- `src/jinja2/loaders.py:647-652`
