# Rule details

- **Rule:** When modifying rejectattr, preserve the contract that it is the negation of selectattr: it keeps objects for which the named attribute test does not succeed, and with no test the attribute value is evaluated as a boolean.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When changing or extending the rejectattr filter's selection behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:1624-1645`
- `tests/test_filters.py:769-806`
