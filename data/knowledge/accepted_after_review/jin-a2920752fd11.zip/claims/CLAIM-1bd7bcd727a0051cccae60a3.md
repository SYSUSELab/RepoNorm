# Rule details

- **Rule:**
  ```text
  Tests for the `batch` filter must assert that `batch(n)` groups items into chunks of n with a final short chunk, and that `batch(n, fill)` pads the final chunk with the fill value.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending `batch` filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:65-71`
