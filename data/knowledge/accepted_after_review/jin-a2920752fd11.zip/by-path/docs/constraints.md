# Constraints for `docs`

## Rule

- **Rule:** The docs tox environment builds HTML documentation with sphinx-build using -W (warnings as errors), reading from docs and writing to {envtmpdir}/html with doctrees in {envtmpdir}/doctrees.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0caf23eae017b0211ca98ef8.md)

## Rule

- **Rule:**
  ```text
  The built documentation output is viewed by opening `_build/html/index.html` in a browser.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-24aaafe6adb2827fa146bcab.md)

## Rule

- **Rule:** Read the Docs documentation builds fail on Sphinx warnings.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-26fe1fdf097aa73b5603f7c9.md)

## Rule

- **Rule:**
  ```text
  Running `make <target>` in docs/ invokes Sphinx via `$(SPHINXBUILD) -M <target> "$(SOURCEDIR)" "$(BUILDDIR)" $(SPHINXOPTS) $(O)`, passing the target name as the Sphinx builder.
  ```
- **Applies to:**
  - `docs/**`
- **Condition:** command target: %
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-64ab7396f9896906d7500ce3.md)

## Rule

- **Rule:** Update any relevant docs pages and docstrings; docs pages and docstrings should be wrapped at 72 characters.
- **Applies to:**
  - `**/*.py`
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-ad48973dc36cc16e7d68b071.md)

## Rule

- **Rule:**
  ```text
  Running `make help` in docs/ invokes Sphinx with the `help` builder, passing SOURCEDIR, BUILDDIR, SPHINXOPTS, and O.
  ```
- **Applies to:**
  - `docs/**`
- **Condition:** command target: help
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c47590664020c9349ddc70da.md)

## Rule

- **Rule:** Read the Docs builds documentation with the dirhtml Sphinx builder.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f3288e1ac279243a6f220323.md)
