# Constraints for `docs/examples/cache_extension.py`

## Rule

- **Rule:**
  ```text
  A cache extension must call environment.extend with fragment_cache_prefix and fragment_cache defaults to add the documented environment attributes.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** when initializing the fragment cache extension and registering its environment attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-204d36961943dbf845fc2099.md)

## Rule

- **Rule:**
  ```text
  A fragment cache extension must key cache entries by environment.fragment_cache_prefix + name, return the cached value when present, and otherwise call caller() and store the result with the timeout via fragment_cache.add.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** when implementing or modifying the fragment cache extension's cache-support helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4b92b73ad829eef46feff94b.md)

## Rule

- **Rule:** A cache extension must register its template tag by declaring tags = {"cache"} on the extension class.
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** when adding or modifying the fragment cache extension's template tag registration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e3eda6b951fcf725fc0821f6.md)

## Rule

- **Rule:**
  ```text
  A custom tag extension must parse its tag by consuming the name token for lineno, parsing one expression as the cache key, optionally a second expression after a comma for timeout (defaulting to Const(None)), then parsing statements up to `endcache` with drop_needle=True and returning a CallBlock calling the extension helper.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** when implementing or modifying the parse method of a custom tag extension
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e71b2a3938986a17b888a857.md)
