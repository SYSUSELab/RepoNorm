# Constraints for `tests/test_filters.py`

## Rule

- **Rule:**
  ```text
  Tests for the escape filter must assert that <, >, &, and double quotes are escaped, with double quote rendered as the numeric entity &#34;.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the escape filter's character escaping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-09b10c75681fc0b28bf9bfb2.md)

## Rule

- **Rule:**
  ```text
  env.call_filter must invoke a named filter with positional arguments and return its result, so env.call_filter('sum', [1, 2, 3]) returns 6.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  Modifying or adding tests for env.call_filter invocation semantics.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1316f4bfa79c4b4d957480e5.md)

## Rule

- **Rule:**
  ```text
  Tests for the `batch` filter must assert that `batch(n)` groups items into chunks of n with a final short chunk, and that `batch(n, fill)` pads the final chunk with the fill value.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending `batch` filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1bd7bcd727a0051cccae60a3.md)

## Rule

- **Rule:** The map filter must apply a named filter to each element of an iterable and compose with downstream filters such as sum; do not change per-element application semantics.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying the map filter or its composition with other filters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-26b7be4e7f2f5cd539d9142f.md)

## Rule

- **Rule:** Tests for the groupby filter must assert that the default parameter supplies a group key for items missing the grouping attribute, grouping those items under the default value.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying or adding tests covering the groupby filter's default parameter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-34e51a0687eacab2ca9014c9.md)

## Rule

- **Rule:**
  ```text
  Tests for filter-tag pipelines must assert that chained filters apply in left-to-right order, e.g. upper|replace('FOO','foo') on 'foobar' yields 'fooBAR'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for chained filter tag ordering
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-454316b1dc4433120a45f7d1.md)

## Rule

- **Rule:** Tests for the filesizeformat filter must assert decimal units by default and binary units when passed true, with specific expected strings for each magnitude.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the filesizeformat filter's unit selection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4ab496504b4d8b7b9524dae9.md)

## Rule

- **Rule:** The string filter must render the same as str(x) for a list, documenting the string filter's output equivalence.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** Modifying or adding tests for the string filter's output equivalence with str().
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4c803ee51a0e4cd99a12e6b7.md)

## Rule

- **Rule:** Tests for the rejectattr filter must preserve that rejectattr("id", "odd") removes users with odd ids, leaving only the expected remaining entries after mapping and joining.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending rejectattr filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-51ef9b1e472f9af5bc98cc87.md)

## Rule

- **Rule:**
  ```text
  The format filter must apply printf-style % formatting with the supplied arguments, so '%s|%s'|format('a','b') yields 'a|b'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** Modifying or adding tests for the format filter's printf-style substitution behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-58eec6f06a896083315ec0e4.md)

## Rule

- **Rule:** The wordcount filter must propagate undefined access: with StrictUndefined, applying wordcount to an undefined variable raises UndefinedError rather than silently returning a value.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when modifying wordcount filter undefined-variable handling in the filter tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5aa4b5badcb5ace62aebac2a.md)

## Rule

- **Rule:** Tests for the sum filter must verify that an attribute-name argument sums that attribute across a sequence of mappings.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying tests for the sum filter's attribute-name argument.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6e85a9aa36a2100fea742d13.md)

## Rule

- **Rule:** Tests for the reject filter must pin the exact set of falsy values (None, False, 0) that are rejected, preserving the filter's truthiness semantics.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying tests for the reject filter's handling of falsy values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7443d5116ad3068b0ad97f54.md)

## Rule

- **Rule:** Tests covering the urlize filter must preserve HTML escaping of the URL in both the href attribute and the link text, and must preserve rel="noopener" on generated anchors.
- **Applies to:**
  - `tests/test_filters.py`
  - `tests/test_regression.py`
- **Condition:** When modifying or extending urlize-filter tests that assert escaping or anchor attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-74cf34df38209d14b74483c7.md)

## Rule

- **Rule:**
  ```text
  Tests for the abs filter must assert that both -1|abs and 1|abs render as 1, confirming absolute value behavior for negative and positive inputs.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the abs filter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-86ce45e42b0a38b7bb7d8b0f.md)

## Rule

- **Rule:** Tests for the sort filter must assert case-insensitive ordering of mixed-case strings, preserving the filter's case-insensitive sort semantics.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the sort filter's case handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-93d42055453837f23f67bade.md)

## Rule

- **Rule:**
  ```text
  Tests for the `int` filter must assert conversion of numeric strings to integers, fallback to 0 for non-numeric strings, truncation of decimal strings, and exact preservation of large numeric strings.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending `int` filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-98160976573165184fe922b1.md)

## Rule

- **Rule:** Tests for the items filter must assert that a dict input yields an ordered list of (key, value) tuples in insertion order.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  when adding or modifying items filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-989989b18e17d910109a5531.md)

## Rule

- **Rule:** The indent filter's second argument controls indenting the first line and the third argument controls indenting blank lines; do not change these argument semantics.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying the indent filter's first/blank argument handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9cabe4bc499d98fd101aa596.md)

## Rule

- **Rule:**
  ```text
  Tests for the `unique` filter must assert that duplicate removal preserves first-occurrence order, and that passing `true` makes the comparison case-sensitive so values differing only in case are both retained.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending `unique` filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9ccb2e41b4f49f552e60afbb.md)

## Rule

- **Rule:** Tests for the sort filter must assert that sorting mixed-case strings yields case-insensitive ordering, e.g. 'AbcD'.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the sort filter with mixed-case input
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a5f96135509e37d65f050f58.md)

## Rule

- **Rule:** Tests that exercise the title filter must preserve its documented boundary and whitespace semantics: internal whitespace runs are kept, and hyphen, tab, parentheses, braces, brackets, and angle brackets act as word boundaries that capitalize the following letter while lowercasing the rest; non-string inputs are accepted via str conversion.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending title-filter test coverage in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a63ecb02d73c709b9cd8634f.md)

## Rule

- **Rule:** Tests for the safe filter must assert that marking a string safe bypasses autoescaping, while the same string without safe is HTML-escaped.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying or adding tests covering the safe filter's interaction with autoescaping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b57c47d50bc43f8a9bb2939e.md)

## Rule

- **Rule:**
  ```text
  Default-filter tests must assert that missing|default('no') renders 'no', false|default('no') renders 'False', false|default('no', true) renders 'no', and given|default('no') renders 'yes'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying or adding default-filter tests that exercise the boolean flag semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b60a4c8c152d2af7109f9bf6.md)

## Rule

- **Rule:** The replace filter must escape replacement values under autoescape, and replacing into Markup must preserve markup escaping semantics.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** Modifying or adding tests for the replace filter's escaping behavior under autoescape.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b6e641ccf8ad78d8007ffbb4.md)

## Rule

- **Rule:**
  ```text
  Tests for the lower filter must assert that lowercasing string input renders 'FOO'|lower as 'foo'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  when modifying or adding lower filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c42f704ccb7be1790594e80b.md)

## Rule

- **Rule:** Tests for the urlize filter must assert that bare domains, http URLs, and email addresses are converted to anchor tags, with rel="noopener" added for http(s) links and mailto: for emails.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying or adding tests covering the urlize filter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c99f542392158c0d8abda516.md)

## Rule

- **Rule:**
  ```text
  Tests for the sum filter must preserve that summing [1,2,3,4,5,6] renders '21'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending sum filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d4cda8c818e5c73d504b23ff.md)

## Rule

- **Rule:** Tests for the int filter's default keyword must assert that non-numeric input returns the default value rather than raising.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  when adding or modifying int filter default tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d5bc8080a3cb485f5bd7b44f.md)

## Rule

- **Rule:** Tests for the pprint filter must assert that its output equals Python's pformat(data) for the given input, pinning the filter to Python's pprint formatting.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the pprint filter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d67f7555d67ac1443e9151b0.md)

## Rule

- **Rule:**
  ```text
  Tests for the min/max filters must preserve that default comparison is case-insensitive, case_sensitive=true reverses that, and empty sequences render as empty string.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending min/max filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df1d088a0922545d9365de05.md)

## Rule

- **Rule:**
  ```text
  wordwrap with width 20 preserves existing newlines in the input and wraps the long line, producing 'Hello!\nThis is Jinja saying\nsomething.' when newline_sequence is set to '\n'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the wordwrap filter or its newline handling, preserve existing newlines and wrap long lines according to the configured newline_sequence.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e7d01fd4be23c0e80d9bf774.md)

## Rule

- **Rule:**
  ```text
  `sort(attribute='value.0')` supports dotted attribute paths into nested/indexed values, sorting Magic objects by their first list element.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying the sort filter's attribute handling, preserve support for dotted attribute paths into nested/indexed values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eede567aa3f4d4923b174cff.md)

## Rule

- **Rule:**
  ```text
  Tests for the urlize filter's extra_schemes parameter must preserve that matching tel: and ftp: URLs render as anchors with rel="noopener".
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or extending urlize extra_schemes tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f433039c0e92eea931d1a940.md)

## Rule

- **Rule:** The reject filter with a test name must exclude items matching the test, preserving the remaining items in order.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when modifying reject filter test-name exclusion behavior in the filter tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fc7132022a04d214ce1835a4.md)
