# Constraints for `tests/test_async_filters.py`

## Rule

- **Rule:** Tests for async filters must define an async custom filter returning str(val), demonstrating that filters may be async coroutines in async environments.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** when adding or modifying tests for async filter support in async environments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-40527d2f075a5503b4a1d52b.md)

## Rule

- **Rule:**
  ```text
  Tests for the join filter must preserve that a '|' separator over an async iterable renders '1|2|3', exercising both sync and async paths via the dual-iter helper.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:**
  ```text
  When modifying or extending async join-filter tests in tests/test_async_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-42f0ce68c373f375a6bcb26c.md)

## Rule

- **Rule:**
  ```text
  Tests for custom async filters must register them on env_async.filters and assert they are invoked for both static and dynamic arguments with expected rendered output.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** when adding or modifying tests for custom async filters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-73cf79c61ab764f7e08bad8e.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise async template rendering must build the environment with enable_async=True (e.g. via the env_async fixture) rather than a synchronous Environment.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** when adding or modifying tests that render templates through async filters or async environments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-92c5c9b8338fbb0cc79719d3.md)

## Rule

- **Rule:** Custom async iterable filters registered on an Environment must apply uniformly to both async generators and plain lists; do not restrict async filter application to one iterable kind.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When modifying async filter application or iterable handling in async environments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9991467459bf82fa97bcfd10.md)

## Rule

- **Rule:**
  ```text
  test_groupby uses the mark_dualiter decorator to run the groupby filter over both sync and async iterables, asserting grouped output ordering and formatting.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:**
  ```text
  When modifying groupby filter tests or async filter coverage, preserve the mark_dualiter convention for running groupby over both sync and async iterables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ab9a66b794505fa55c5f5427.md)

## Rule

- **Rule:** The groupby filter with a dotted attribute path (e.g. 'date.year') must group articles by the resolved attribute and preserve the asserted grouped output ordering.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** when modifying groupby dotted-attribute-path grouping or output ordering in the async filter tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cae05885da5a5f1b16276816.md)

## Rule

- **Rule:**
  ```text
  Tests for the `map` filter with an `attribute` argument must assert that the filter works in async environments and joins the mapped attribute values with the given separator.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:**
  ```text
  When modifying or extending async `map` filter tests in tests/test_async_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e002d180c2b749a37ff24974.md)
