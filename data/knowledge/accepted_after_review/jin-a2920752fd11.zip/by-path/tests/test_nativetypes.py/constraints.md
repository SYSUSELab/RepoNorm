# Constraints for `tests/test_nativetypes.py`

## Rule

- **Rule:** Tests for native list concatenation must assert that adding two lists with + in a native environment returns an actual list containing the concatenated elements, preserving Python list semantics.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** when adding or modifying tests for native environment list concatenation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1186e2bc7327bd6b4eff17c3.md)

## Rule

- **Rule:** Native-type tests must assert that rendering multiple expressions does not preserve native types and instead returns the concatenated string representation.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When modifying or adding native-type tests that render multiple expressions in a single template.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2a0de7be0d5e42ddcfbcf5a6.md)

## Rule

- **Rule:** In native rendering, {{ missing is defined }} must render falsy, confirming undefined handling in native types.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** Modifying or adding tests for undefined handling in native rendering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-31cc61f6e1a2d633f8994e41.md)

## Rule

- **Rule:** A NativeTemplate constructed without an environment must receive a NativeEnvironment instance so that standalone use still yields native-type rendering behavior.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying tests for standalone NativeTemplate construction without an explicit environment.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-36a334faecb90bdcc28bf0a0.md)

## Rule

- **Rule:** Tests for native-type coercion must assert that the int filter yields an actual int instance rather than a string.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When modifying or adding tests covering native-type coercion of the int filter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-56c88505824c49cfed68be5e.md)

## Rule

- **Rule:** Tests for native type preservation must assert that loop rendering over ints returns an int and over strings returns a str, because native environment loop concatenation preserves the element type.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** when adding or modifying tests for native environment loop output types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ad5eed81d265791db8239299.md)

## Rule

- **Rule:**
  ```text
  Rendering a constant dunder expression such as true.__class__|string must produce a string, not a type object, and the result must match either the Python 2 or Python 3 bool repr form.
  ```
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When modifying native-type rendering or dunder expression handling, preserve that constant dunder expressions render as strings matching the bool repr form.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b392331dd0780eb04a9e4e91.md)

## Rule

- **Rule:** A template containing only a string literal expression must render to a str, confirming native-type rendering preserves str for literal-only templates.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** when modifying native-type rendering of literal-only templates in the native types tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c4dbf2b6b91df7916f3ed103.md)

## Rule

- **Rule:**
  ```text
  Tests for native types must verify that accessing dunder attributes like __class__ on a boolean renders a type object rather than a string, preserving native Python semantics.
  ```
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying tests for native-type rendering of dunder attribute access.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dad25a17a06aa610525515ba.md)

## Rule

- **Rule:** Tests for native type preservation must assert that rendering a single-element list through a for loop yields the element's native type (e.g., int 1) rather than a string.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:**
  ```text
  when modifying or adding native type preservation tests in tests/test_nativetypes.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f32f0998229e4df71f7af6ca.md)
