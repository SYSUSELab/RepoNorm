# Constraints for `tests/test_core_tags.py`

## Rule

- **Rule:**
  ```text
  Tests for the `if` tag must assert that an if/else with empty branches renders nothing.
  ```
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:**
  ```text
  When modifying or extending `if` tag tests in tests/test_core_tags.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-08e56c572d9b4cc7b5c16179.md)

## Rule

- **Rule:** Tests for set blocks under autoescape must assert that a filtered set block renders its captured content escaped.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:** When modifying or adding tests covering set blocks with filters under autoescape.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0be4ea07a738bca625f0bd53.md)

## Rule

- **Rule:** Tests for namespace attribute assignment must assert that assigning an attribute on a namespace created with a non-namespace object raises TemplateRuntimeError whose message contains 'non-namespace object'.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:** when adding or modifying tests for namespace attribute assignment errors
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-27e23d639470331f269a119b.md)

## Rule

- **Rule:** Tests for macro varargs must verify that extra positional arguments are exposed via the varargs variable and can be joined and rendered.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:** When adding or modifying tests for macro varargs handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-28ccf262aab02d4f48731b1a.md)

## Rule

- **Rule:** Tests for namespace attribute mutation inside macros must assert that a macro receiving a namespace can set an attribute and the caller observes the mutation.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:** When modifying or adding tests covering namespace attribute mutation inside macros.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3af46163824e51fc4bb48ce6.md)

## Rule

- **Rule:** Assigning to a namespace attribute via a block set ({% set ns.bar %}...{% endset %}) stores the rendered block content, retrievable as ns.bar.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:** When modifying namespace assignment or block set handling, preserve that block set to a namespace attribute stores the rendered block content.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3e1988b7556fe8d538a766fb.md)

## Rule

- **Rule:** Tests for macro argument defaults must assert that omitted macro parameters fill in with their declared defaults, rendering the expected concatenated output for zero through three positional arguments.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:**
  ```text
  when modifying or adding macro argument default tests in tests/test_core_tags.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5c5394eb1444e876ab7357cc.md)

## Rule

- **Rule:**
  ```text
  Tests for the `with` tag must assert that bindings inside the block do not mutate outer bindings after `endwith`, confirming `with` introduces a new scope.
  ```
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:**
  ```text
  when adding or modifying tests for the `with` tag's scoping behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6c0de9fb050a2c8d90052918.md)

## Rule

- **Rule:** When a macro is invoked via a {% call %} block, the macro body must access the caller's rendered content through caller(), and the macro's own output must wrap that caller content rather than replacing it.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:** Modifying or adding tests for {% call %} block macro invocation behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-97acc512be559f849a7ab7fa.md)

## Rule

- **Rule:** Tests for macro caller scoping must assert that a caller variable set outside a macro is not visible inside the macro.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:** When modifying or adding tests covering macro caller variable scoping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a0fa8d5ed33984f29f57a40e.md)

## Rule

- **Rule:** Tests for set blocks must assert both the rendered value and that the same value is accessible as an attribute on tmpl.module.
- **Applies to:**
  - `tests/test_core_tags.py`
- **Condition:**
  ```text
  when adding or modifying set block tests in tests/test_core_tags.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ecba4d42c2a5e2d0432c3e01.md)
