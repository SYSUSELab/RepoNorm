# Constraints for `tests/test_async.py`

## Rule

- **Rule:** Tests for async template imports must assert that imports default to without context: plain import and "without context" render without outer context, while "with context" renders with it, for both import and from-import forms.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** when adding or modifying tests for async template import context semantics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c2ec45014c0dda2a4aed26d.md)

## Rule

- **Rule:** Tests for include context propagation must preserve that include with and without an explicit 'with context' both see the caller's context, while 'without context' does not.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying or extending include-context tests in tests/test_async.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3ec08f121ec00443b4212b40.md)

## Rule

- **Rule:**
  ```text
  The native-list async test is driven through asyncio.run(_test()), establishing the repository convention of running async native rendering tests via asyncio.run.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When adding or modifying async native rendering tests, preserve the convention of driving them through asyncio.run(_test()).
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-415c224ba7598912a2fae2d0.md)

## Rule

- **Rule:**
  ```text
  Async rendering must be exercised by awaiting t.render_async() inside an async function, establishing the supported async rendering entry point.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** Modifying or adding tests for async template rendering entry points.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5228c515e01c481f7b4b5fa8.md)

## Rule

- **Rule:** Importing a template with globals must make those globals visible to the imported template; importing without globals must not leak caller globals into the imported template.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying template import handling or the propagation of globals into imported templates.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5a603c00683e8e88d7e4476c.md)

## Rule

- **Rule:**
  ```text
  The `TestAsyncIncludes` class in tests/test_async.py must group async include-related tests.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying or extending async include tests in tests/test_async.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-73a901e3cad20a5f4496964f.md)

## Rule

- **Rule:**
  ```text
  Tests for async expression evaluation must assert that async and normal call results combine in a single expression (e.g. "{{ async_func() + normal_func() }}" renders "65") with enable_async=True.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** when adding or modifying tests for async expression evaluation combining async and normal calls
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9425240a9daa796b26e175e4.md)

## Rule

- **Rule:**
  ```text
  The async_func helper must be a coroutine returning 42, used as a minimal awaitable fixture in async tests.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** when modifying async test helpers or awaitable fixtures in the async tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a57a0b61d7d5cfc4b84cf218.md)

## Rule

- **Rule:**
  ```text
  Async filter tests must assert that a filter returning a list can be subscripted or sliced in the template when enable_async=True, preserving the expected rendered result.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying or adding async filter tests that exercise subscripting or slicing of filter results in templates.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-af7239f23ffdef462c56ee19.md)

## Rule

- **Rule:**
  ```text
  With enable_async, slicing the result of a called global (e.g. add_each(a, 2)[1:]) must render correctly, confirming subscript-after-call support.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** when modifying async rendering of subscript-after-call expressions in the async tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b45c28d9ee20ec9406587c76.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the async rendering path must keep enable_async=True and assert ordered chunk output from Template.generate(), because async generation yields rendered chunks in order rather than a single string.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  when modifying or adding async rendering tests in tests/test_async.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c60551db3c9c36fed963b9b8.md)

## Rule

- **Rule:** Tests for async iteration in templates must preserve that generate() over an async iterable yields the first loop index immediately and that joining the remaining stream produces the expected concatenated output.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying or extending async iteration tests in tests/test_async.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc58af80a6af8bcdfd67db9a.md)
