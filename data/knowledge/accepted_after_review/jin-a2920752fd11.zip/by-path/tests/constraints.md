# Constraints for `tests`

## Rule

- **Rule:** Pytest test discovery is restricted to the tests directory via testpaths = tests.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ad836813cd6a1b4a85305ff5.md)

## Rule

- **Rule:** Coverage source measurement is limited to the jinja2 and tests directories.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d48095fc26cdaf1cf672d333.md)

## Rule

- **Rule:** Include tests when a patch adds or changes code, and make sure the test fails without the patch.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-e2384d49736679da944a2ab9.md)
