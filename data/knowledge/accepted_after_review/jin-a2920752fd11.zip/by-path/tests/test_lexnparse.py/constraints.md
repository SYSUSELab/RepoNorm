# Constraints for `tests/test_lexnparse.py`

## Rule

- **Rule:**
  ```text
  Tests for custom delimiters with whitespace control must configure an Environment with PHP-style delimiters ('<?', '?>', '<?=', '?>', '<!--', '-->') plus lstrip_blocks and trim_blocks, and assert the expected rendered output.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  when modifying or adding custom delimiter or whitespace-control tests in tests/test_lexnparse.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-04f0dae14791d79b69db860b.md)

## Rule

- **Rule:**
  ```text
  With lstrip_blocks=True and trim_blocks=False, block tags must consume surrounding whitespace without requiring a trailing newline; do not change whitespace consumption to depend on a trailing newline.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying lstrip_blocks/trim_blocks whitespace handling in the lexer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-175a77b6d06bcfb0e38a2b7c.md)

## Rule

- **Rule:**
  ```text
  With lstrip_blocks and trim_blocks enabled, the raw block's surrounding whitespace must be stripped so '{{x}}\n{%- raw %} {% endraw -%}\n{{ y }}' renders as '1 2'.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  Modifying or adding tests for lstrip_blocks/trim_blocks interaction with raw blocks.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-190fd4c63110784e7bdd1580.md)

## Rule

- **Rule:**
  ```text
  Tests for whitespace control must assert that {%- and -%} markers strip surrounding whitespace even when lstrip_blocks and trim_blocks are both disabled.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  when adding or modifying tests for whitespace-control markers with lstrip_blocks and trim_blocks disabled
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1f2b478f4bcb517206c52ff8.md)

## Rule

- **Rule:** Tests that exercise custom block/variable/comment delimiters must construct Environment with the custom delimiter tuple and assert the rendered output, because delimiter configurability is a supported Environment contract.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** when adding or modifying tests for custom delimiter rendering
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-40f98c62fd1a77110901f0e7.md)

## Rule

- **Rule:** Tests for configurable comment syntax must assert that comment blocks are stripped while surrounding loop output renders correctly, using the same Environment delimiter arguments.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** when adding or modifying tests for configurable comment syntax
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4789b3ffb69a143c7b2e2f76.md)

## Rule

- **Rule:**
  ```text
  Tests for TokenStream iteration must assert that tokens are yielded in order, e.g. block_begin then block_end for a simple token list.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** when adding or modifying tests for TokenStream iteration order
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-601207b8816e98fa400efd6f.md)

## Rule

- **Rule:**
  ```text
  Tests for custom comment delimiters must configure the Environment with the custom delimiters and lstrip_blocks/trim_blocks, then assert the exact rendered output documenting comment stripping and whitespace behavior.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  when adding or modifying custom comment delimiter tests in tests/test_lexnparse.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-608a2f892ae5e4d02854c9bb.md)

## Rule

- **Rule:** Environment must honor custom block and variable delimiters; parsing and rendering must use the configured delimiters rather than the defaults.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying lexer/parser delimiter handling or Environment delimiter configuration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-86feecef8c5e4127fbdc2493.md)

## Rule

- **Rule:**
  ```text
  Tests for whitespace control must assert that with lstrip_blocks enabled and trim_blocks disabled, leading newlines before a {% set %} tag are preserved, so lstrip_blocks does not strip newlines preceding a block tag.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  when adding or modifying tests for lstrip_blocks or trim_blocks whitespace control behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-966dbc118084204ff090f771.md)

## Rule

- **Rule:** Tests for the lexer operator table must iterate over jinja2.lexer.operators, skip bracket characters, tokenize each operator, and assert the token type matches the expected operator mapping.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** when adding or modifying tests that verify the lexer operator table contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a2b3deb46f4c8073641859d4.md)

## Rule

- **Rule:**
  ```text
  Tests for the trailing-newline lexer option must assert that keep_trailing_newline=False strips a single trailing newline and reduces multiple trailing newlines by one, while keep_trailing_newline=True preserves the template unchanged.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or adding tests covering the keep_trailing_newline lexer option.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c1b8a2eb0d07511400955978.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise custom block/variable/comment delimiters must verify that combining those delimiters with lstrip_blocks and trim_blocks still produces the expected concatenated render output.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying or adding tests for custom ERB-style delimiters or whitespace-control flags in the lexer/parser test module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c64b9d44a81c6169d1c26497.md)

## Rule

- **Rule:**
  ```text
  Tests for the TokenStream must assert that truthiness is true while not at EOF and false once the current token is TOKEN_EOF, with eos being the inverse of bool(ts).
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** when adding or modifying tests for TokenStream truthiness and EOF behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-de5528f7aeb6b3efc94fa601.md)

## Rule

- **Rule:**
  ```text
  Tests for lstrip_blocks must assert that leading whitespace before a block tag is stripped while trailing whitespace after the block is preserved when trim_blocks is False.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or adding lstrip_blocks whitespace-control tests in the lexer/parser test module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eed3531071a79f6c48f43b60.md)

## Rule

- **Rule:**
  ```text
  Whitespace-control tests must preserve the documented interaction between lstrip_blocks, trim_blocks, and the '+' modifier: lstrip_blocks strips leading whitespace before block tags while preserving inline output spacing, and the '+' modifier on a block tag suppresses that stripping for that tag.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or adding tests covering lstrip_blocks, trim_blocks, or the '+' block modifier in the lexer/parser test suite.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ef7db0d8fe1bb084c1801dd7.md)

## Rule

- **Rule:**
  ```text
  Tests for custom delimiters with lstrip_blocks and trim_blocks must verify whitespace handling under non-default delimiters.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying tests for custom delimiters combined with lstrip_blocks and trim_blocks.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fd28c43e2b8033134ab76f17.md)
