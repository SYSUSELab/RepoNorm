# Constraints for `tests/test_bytecode_cache.py`

## Rule

- **Rule:** Tests for the bytecode cache backend interface must use a mock cache whose set method accepts key, value, and optional timeout, storing them as attributes, matching the backend interface.
- **Applies to:**
  - `tests/test_bytecode_cache.py`
- **Condition:** when adding or modifying tests for the bytecode cache backend interface
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-887c64b87d1e36b3da6296fd.md)
