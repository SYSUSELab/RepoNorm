# Constraints for `tests/test_security.py`

## Rule

- **Rule:** Tests for sandboxed for-loop targets must assert that attribute-access targets such as item.attribute raise TemplateSyntaxError, preserving the sandbox restriction on attribute assignment in loop targets.
- **Applies to:**
  - `tests/test_security.py`
- **Condition:** when adding or modifying sandboxed for-loop target restriction tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0b05c6538c5c39f5d97f0c1a.md)

## Rule

- **Rule:**
  ```text
  Setting binop_table["+"] to disable_op allows normal rendering, but adding "+" to intercepted_binops causes TemplateRuntimeError, defining the sandbox operator interception contract.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:**
  ```text
  When modifying sandbox operator interception, preserve that disable_op in binop_table allows rendering while adding the operator to intercepted_binops raises TemplateRuntimeError.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-15ee014b16f49df554815aaf.md)

## Rule

- **Rule:** Tests for sandboxed macro output must verify that autoescape escapes macro output both when rendered and when accessed via the template module, including EvalContext calls.
- **Applies to:**
  - `tests/test_security.py`
- **Condition:** When adding or modifying tests for sandboxed macro output escaping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2019e21ae1e2d74272575bb8.md)

## Rule

- **Rule:**
  ```text
  Tests for sandboxed string formatting must assert that format_map on a safe string still escapes substituted values, so 'safe' does not disable escaping of format arguments.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:**
  ```text
  when adding or modifying tests for sandboxed string formatting or format_map escaping behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-336caa48f318e277817e6199.md)

## Rule

- **Rule:**
  ```text
  Tests that assert on repr output of the PrivateStuff helper must depend on the literal string "PrivateStuff" returned by its __repr__, not the class name.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:** when adding or modifying tests that assert on repr output of the PrivateStuff helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8a8db72bd20dc2a6478f731b.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the sandbox's unary-operator interception must add the operator to intercepted_unops and assert that rendering raises TemplateRuntimeError, because overriding unop_table alone permits the operator while interception must still block it.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:** when adding or modifying sandbox unary-operator interception tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a870bf88aff307defc3cce38.md)

## Rule

- **Rule:**
  ```text
  Tests for sandboxed string formatting must assert that `str.format` field access to ordinary attributes is permitted while access to blocked attributes such as `__class__` is denied.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:**
  ```text
  When modifying or extending sandboxed string formatting tests in tests/test_security.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b917e1d3b6b3c4bdab0f1081.md)

## Rule

- **Rule:** SandboxedEnvironment must block access to private and dunder attributes: dunder attribute access renders as empty string, and calling a blocked attribute raises SecurityError, while public attributes remain accessible.
- **Applies to:**
  - `tests/test_security.py`
- **Condition:**
  ```text
  when modifying sandbox attribute-access or format_map handling in the security tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d329cd4187b12748f174ff05.md)

## Rule

- **Rule:**
  ```text
  Tests for the sandboxed attr filter must preserve the invariant that accessing cls|attr('__subclasses__')() raises SecurityError, confirming attr is subject to sandbox attribute restrictions.
  ```
- **Applies to:**
  - `tests/test_security.py`
- **Condition:**
  ```text
  When modifying or extending sandbox attribute-restriction tests in tests/test_security.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e1c94c717e657764859f6cc7.md)
