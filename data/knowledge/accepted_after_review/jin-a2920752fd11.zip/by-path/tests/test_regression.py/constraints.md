# Constraints for `tests/test_regression.py`

## Rule

- **Rule:** Tests for loop variable reuse must assert that a for loop may iterate over an attribute of a variable with the same name as the loop target, with loop.index0 remaining available and recursive loops over the same expression working.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** When modifying or adding tests covering loop variable reuse in for loops.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-01c7e57bf716264a34aee825.md)

## Rule

- **Rule:** A macro defined inside a for loop must capture the loop variable by value at call time, so recursive macro calls on the loop variable produce the expected reversed sequences.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** Modifying or adding tests for macro scoping when defined inside a for loop.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-133ae351c4182432cdd75a33.md)

## Rule

- **Rule:** Tests for the eq/lessthan comparison operators must assert boolean equality results, including comparisons between variables and computed expressions, and must document subproperty access in comparison tests.
- **Applies to:**
  - `tests/test_regression.py`
  - `tests/test_tests.py`
- **Condition:** when adding or modifying tests for the eq, lessthan, or other comparison test operators
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1352ffc10e9c012f1e1d6bbc.md)

## Rule

- **Rule:** Regression tests for scoped loop variables must assert that scoped blocks inside loops see loop-scoped assignments while the outer variable remains unchanged after the loop, preserving scoped loop variable isolation.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** when adding or modifying regression tests for scoped loop variable isolation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1af3b99ce28026884981eb64.md)

## Rule

- **Rule:** Tests for for-else semantics must assert that the else body executes when the iterable is empty, including nested for-else constructs.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** when adding or modifying tests for for-else behavior with empty iterables
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2e5abd677111d207f9ec7f4d.md)

## Rule

- **Rule:** Tests for loop-else and scoped block semantics must assert that a for-loop over an empty sequence executes its {% else %} branch (including nested loops), and that a scoped block inside a with statement resolves the outer variable to the with-local value.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:**
  ```text
  when modifying or adding loop-else or scoped block regression tests in tests/test_regression.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2f7952c645ad2d1c06206529.md)

## Rule

- **Rule:**
  ```text
  Tests for the `pass_context` decorator must assert that the decorated callable receives the render context as its first argument.
  ```
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:**
  ```text
  When modifying or extending `pass_context` decorator tests in tests/test_regression.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2f9a2054d30ac5800c882034.md)

## Rule

- **Rule:** Macro autoescape behavior is determined by the call site's autoescape state, not the environment in which the macro was defined; a macro defined under autoescape-disabled still renders escaped when invoked inside an {% autoescape true %} block.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** When modifying macro rendering or autoescape handling, preserve call-site autoescape semantics for macros defined under a different autoescape environment.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-340e95d1dd7336febfca33d3.md)

## Rule

- **Rule:** Custom filters registered on an Environment must be callable with keyword arguments and receive them correctly; do not break keyword-argument folding in filter invocation.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** When modifying filter invocation or argument binding for custom filters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-36159475dd6bb5681e2c18ce.md)

## Rule

- **Rule:** Tests for template inheritance with a custom environment must assert that a child template extending a parent resolves the parent's variables from render kwargs.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:**
  ```text
  When modifying or extending template inheritance tests in tests/test_regression.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-441838c8524536142041d470.md)

## Rule

- **Rule:**
  ```text
  Tests for block scoping must verify that a block-local set does not leak to the outer template scope, preserving pass_context global reads.
  ```
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:**
  ```text
  When adding or modifying tests for block-local variable scoping and pass_context globals.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4dd6df1d4f7992afa8ffb944.md)

## Rule

- **Rule:** Tests for block-scoped set with extends must assert that a {% set x %}...{% endset %} block in a child template propagates its value to the parent's block when rendered.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** when adding or modifying tests for block-scoped set propagation across extends
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-650909cbbed842d81b709179.md)

## Rule

- **Rule:** Tests covering the urlize filter must preserve HTML escaping of the URL in both the href attribute and the link text, and must preserve rel="noopener" on generated anchors.
- **Applies to:**
  - `tests/test_filters.py`
  - `tests/test_regression.py`
- **Condition:** When modifying or extending urlize-filter tests that assert escaping or anchor attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-74cf34df38209d14b74483c7.md)

## Rule

- **Rule:** Regression tests for loop scoping and recursion must assert that loop.index values and recursive loop() compilation behave correctly when loops are nested inside call blocks or other loops.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** when adding or modifying regression tests that cover nested loops, call blocks, or recursive loop() compilation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-af90fa7000e34ba8ad138ffa.md)

## Rule

- **Rule:**
  ```text
  The pass_context decorator must inject the render context as the first argument, and pass_context-decorated functions must read context values via ctx.
  ```
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:**
  ```text
  when modifying pass_context-decorated functions or their context access in the regression tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c31148c04f30658601e04376.md)

## Rule

- **Rule:** Regression tests for template inclusion inside loops must assert that the included template re-renders per iteration with the current loop variable, producing concatenated output.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** when adding or modifying regression tests for template inclusion inside loops
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df1b1062274b7fa459966593.md)

## Rule

- **Rule:** Regression tests for caller scoping must assert that a macro invoked via {% call %} can pass extra positional arguments to the caller and that the caller body receives them.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:** When modifying or adding regression tests for {% call %} caller argument forwarding.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f9fbf107d5e635842d68201a.md)
