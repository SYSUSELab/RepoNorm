# Constraints for `tests/test_runtime.py`

## Rule

- **Rule:** Tests for lazy iterator handling in for-loops must assert that iteration does not advance groupby iterators early, preserving non-empty rendered group lists.
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:** when adding or modifying runtime tests for for-loop iteration over lazy iterators such as groupby
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-098ebc840a95f6b877e68161.md)

## Rule

- **Rule:** Tests for loop index variables must preserve 1-based index and revindex semantics, with len and index/revindex exposed for a one-element loop.
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:**
  ```text
  When modifying or extending loop index tests in tests/test_runtime.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2e299918af6f6360acb71e71.md)

## Rule

- **Rule:** Tests for LoopContext.length must assert that length equals len() of the underlying iterable even when constructed from a reversed list, so length is computed from the source sequence rather than from iteration state.
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:**
  ```text
  when modifying or adding LoopContext length tests in tests/test_runtime.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2e8f6ffca5901447251451e1.md)
