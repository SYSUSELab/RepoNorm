# Constraints for `tests/conftest.py`

## Rule

- **Rule:** The env fixture in tests/conftest.py must return a fresh Environment() instance, establishing the convention that tests receive a new environment per test.
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** when adding or modifying the env fixture in tests/conftest.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-067387bcdab409f527d5580e.md)

## Rule

- **Rule:**
  ```text
  The `prefix_loader` fixture in tests/conftest.py must compose a `PrefixLoader` mapping prefixes to the filesystem loader and the dict loader, providing a reusable convention for prefix-based loader tests.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  When modifying or extending the `prefix_loader` fixture in tests/conftest.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-872e2dc1539b6cd090ab7167.md)

## Rule

- **Rule:**
  ```text
  The filesystem_loader fixture must resolve the test file's parent directory and return a FileSystemLoader rooted at res/templates, establishing the repository convention for filesystem-based template tests.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** when adding or modifying filesystem-based template test fixtures or tests that load templates from disk
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-baaf2eeb0cee1aae4a6e5d0b.md)
