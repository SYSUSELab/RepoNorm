# Constraints for `tests/test_tests.py`

## Rule

- **Rule:** Tests for the eq/lessthan comparison operators must assert boolean equality results, including comparisons between variables and computed expressions, and must document subproperty access in comparison tests.
- **Applies to:**
  - `tests/test_regression.py`
  - `tests/test_tests.py`
- **Condition:** when adding or modifying tests for the eq, lessthan, or other comparison test operators
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1352ffc10e9c012f1e1d6bbc.md)

## Rule

- **Rule:** The 'greaterthan' test compares operands numerically, rendering '1 is greaterthan 0' as True and '0 is greaterthan 1' as False.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying the greaterthan test or numeric comparison tests, preserve numeric comparison semantics for the greaterthan test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7002cf2a93c93c7dbed6eb4e.md)

## Rule

- **Rule:** When a name is undefined, an if-guarded test expression ({{ x is f }}) is not evaluated and renders empty; when x is defined, an unknown test name raises TemplateRuntimeError with message "No test named 'f'".
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying test-expression evaluation or undefined-name handling, preserve that if-guarded test expressions are not evaluated for undefined names and that unknown test names raise TemplateRuntimeError when the name is defined.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7eb9bcdceb4917c9341d5fe2.md)

## Rule

- **Rule:** Tests for the even test must assert the boolean output for both even and odd inputs, pinning the exact rendered 'True'/'False' strings.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  when adding or modifying even test assertions in tests/test_tests.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8921757766234b3c6764ab61.md)

## Rule

- **Rule:** Tests that assert on undefined test names must pin the exact TemplateAssertionError message text (e.g. "No test named 'f'") so that error-message compatibility is preserved.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** when adding or modifying a test that asserts on an undefined test name error
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8aaa1f9be71dd18a7f647fe7.md)

## Rule

- **Rule:** The 'is' type tests must follow Python-like semantics: booleans are numbers but not integers/floats; strings are sequences and iterables but not mappings; dicts are sequences, mappings, and iterables; range is callable and iterable; large ints are integer and number but not float.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** when modifying 'is' type-test semantics in the test suite
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b6ecf112a136598dee7c80a8.md)

## Rule

- **Rule:** Tests for comparison aliases must parametrize all six aliases (eq, ne, lt, le, gt, ge) with true/false expectations and assert the rendered string equals str(expect), pinning the alias-to-operator mapping.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  when modifying or adding comparison alias tests in tests/test_tests.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f50fc92727ca04e167eb0dd3.md)
