# Constraints for `tests/test_api.py`

## Rule

- **Rule:** Tests for undefined indexing must assert that indexing a non-subscriptable value raises UndefinedError at render time rather than a Python TypeError.
- **Applies to:**
  - `tests/test_api.py`
- **Condition:** When modifying or adding tests covering undefined behavior for invalid indexing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1ccfff9967d213212db9fbe7.md)

## Rule

- **Rule:** Environment subclasses must be able to override the code generator to alter generated output; do not seal or bypass the code generator extension point.
- **Applies to:**
  - `tests/test_api.py`
- **Condition:** When modifying Environment code generation or the code generator extension point.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3be491ba6a441f3b0c648250.md)

## Rule

- **Rule:**
  ```text
  For a dict with key 'items', foo.items() and foo|attr('items')() both yield the dict items list, while foo['items'] yields the value 42, distinguishing attribute lookup from item lookup in both Environment and SandboxedEnvironment.
  ```
- **Applies to:**
  - `tests/test_api.py`
- **Condition:**
  ```text
  When modifying attribute or item lookup behavior, preserve the distinction between attribute lookup (foo.items()) and item lookup (foo['items']) for dicts with an 'items' key.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-454c42e7f9e243257581e71d.md)

## Rule

- **Rule:** Tests for the finalize hook must assert that finalize is applied to the output value during rendering.
- **Applies to:**
  - `tests/test_api.py`
- **Condition:** When modifying or adding tests covering the Environment finalize hook.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-508cc1826da59beaf2ccf36b.md)

## Rule

- **Rule:** Tests for undefined behavior must assert that a callable returning StopIteration renders as empty output while accessing an attribute on that result raises UndefinedError.
- **Applies to:**
  - `tests/test_api.py`
- **Condition:** When modifying or adding tests for undefined behavior around callables returning StopIteration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-62045fd6ae8c9ee9ca5aa33e.md)

## Rule

- **Rule:**
  ```text
  With finalize converting None to '', rendering '<{{ none }}>' must yield '<>', pinning finalize application to constant expressions.
  ```
- **Applies to:**
  - `tests/test_api.py`
- **Condition:** Modifying or adding tests for finalize application to constant expressions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6f12344d8b4e6676934c5108.md)

## Rule

- **Rule:**
  ```text
  A finalize callback decorated with pass_environment receives the environment and the value, and can use environment variable delimiters to format output.
  ```
- **Applies to:**
  - `tests/test_api.py`
- **Condition:**
  ```text
  When modifying finalize callback handling or the pass_environment decorator, preserve that the environment and value are passed to finalize.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-778d0a8f3552a46b6ae17a62.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise custom code generation must subclass Environment and override code_generator_class with a custom generator, because code_generator_class is a supported extension point.
  ```
- **Applies to:**
  - `tests/test_api.py`
- **Condition:** when adding or modifying tests for custom code generation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-916517b4ff77d6d2642f85e2.md)

## Rule

- **Rule:**
  ```text
  A finalize function decorated with @pass_eval_context receives the EvalContext as its first argument, enabling access to eval_ctx.autoescape inside finalize.
  ```
- **Applies to:**
  - `tests/test_api.py`
- **Condition:**
  ```text
  When modifying finalize callback handling or the pass_eval_context decorator, preserve that the EvalContext is passed as the first argument to finalize.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9eb36c8a95f2486e9ffd9d83.md)

## Rule

- **Rule:** Calling getattr on None through the environment must raise UndefinedError with the message "'None' has no attribute 'split'".
- **Applies to:**
  - `tests/test_api.py`
- **Condition:** Modifying or adding tests for attribute access on None raising UndefinedError.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b012208b8019ef6de87a915c.md)

## Rule

- **Rule:** When an Environment is configured with both finalize and autoescape=True, the finalize callable's return value must be escaped; do not bypass autoescaping for finalized output.
- **Applies to:**
  - `tests/test_api.py`
- **Condition:** When modifying finalize handling or autoescape interaction in Environment rendering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c388f9d5a7e21c412d279e25.md)
