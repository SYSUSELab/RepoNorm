# Constraints for `tests/test_ext.py`

## Rule

- **Rule:**
  ```text
  filter_stream must yield interpolated tokens for data tokens and pass all other tokens through unchanged, defining the extension's token-stream transformation contract.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  Modifying or adding tests for extension filter_stream token transformation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0020826830825a71de947088.md)

## Rule

- **Rule:**
  ```text
  The gettext helper must resolve the language from context 'LANGUAGE' defaulting to 'en', look up the string in the languages mapping, and pass the result through _get_with_context.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** when modifying the gettext helper's language resolution or lookup in the extension tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-00f356448275353fc2fc0cae.md)

## Rule

- **Rule:** i18n extension tests must assert that rendering a child template with LANGUAGE='de' produces the translated title and body.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or adding i18n extension tests that render child templates with a non-default LANGUAGE.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0d98b3a23e6beeb14ae05e92.md)

## Rule

- **Rule:** The ScopeExt scope tag must resolve variables in declaration order so later names can reference earlier ones, undefined names fall back to the render context, and explicit declarations override context values.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** when modifying ScopeExt scope-tag variable resolution in the extension tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1e037a6fb7308b254496ea9c.md)

## Rule

- **Rule:** Tests for the i18n extension's trimmed policy must assert that surrounding whitespace inside trans blocks is stripped, in contrast to the default policy which preserves it.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or adding tests covering the i18n extension's trimmed policy for trans blocks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-445a906d1afecec5674c3e03.md)

## Rule

- **Rule:**
  ```text
  Tests for i18n variable substitution must assert that `trans` blocks with variable interpolation render localized output for multiple template variants.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending i18n variable substitution tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5575dbec565961451413afcd.md)

## Rule

- **Rule:**
  ```text
  Tests for newstyle i18n pluralization must assert that `ngettext` renders the singular form for count 1 and the plural form for other counts under the target language.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending newstyle i18n pluralization tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5b10e03dd39fd77571ea17a8.md)

## Rule

- **Rule:** The i18n extension must be configured with gettext/ngettext/pgettext/npgettext globals and support a trimmed-policy environment; do not change the extension's global registration or policy handling without updating the i18n test setup.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying the i18n extension's globals, policy handling, or environment configuration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5dd1a0a0c06c8a614cd62e26.md)

## Rule

- **Rule:**
  ```text
  Extension test helpers must format sandboxed, ext_attr, imported_object, context.blocks, and context 'test_var' into a pipe-delimited string for extension test assertions.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** when adding or modifying extension test helpers that format extension state for assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7fa51e8c9cdc217c52ad4b37.md)

## Rule

- **Rule:**
  ```text
  Extension overlay scope parsing must build an OverlayScope node whose body is parsed until 'endoverlay' with drop_needle=True and whose context is set via a call_method('get_scope').
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or adding extension parse methods that implement overlay scope tags.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aca1334634481ef9edf9021b.md)

## Rule

- **Rule:** i18n pluralization tests must assert that npgettext.html renders the singular form for count 1 and the plural form for count 5 under a non-default LANGUAGE.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or adding i18n pluralization tests that render npgettext.html with varying counts.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bdbf1fce3299a25acb3cc4f7.md)

## Rule

- **Rule:**
  ```text
  Tests for the i18n extension must preserve the extraction tuple contract: babel_extract yields (lineno, funcname, message, comments) tuples, with gettext/trans producing 'gettext' entries and pluralize producing an 'ngettext' entry whose message is a (singular, plural, None) tuple.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  when modifying or adding i18n extraction tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cb059f5006b7964270a128eb.md)

## Rule

- **Rule:** Tests for the trimmed modifier must assert that a variable named 'trimmed' does not enable trimming, preserving surrounding whitespace in trans blocks.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  when adding or modifying trimmed modifier tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc3e5d6979462847748dbc9c.md)

## Rule

- **Rule:** Tests for plural-form selection must preserve that the plural template renders the singular form for count 1 and the plural form for count 2 under the active language.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending plural-form tests in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e15c7a54f311b8d217f2f73c.md)
