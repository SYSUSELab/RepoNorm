# Constraints for `tests/test_debug.py`

## Rule

- **Rule:** Tests for syntax-error tracebacks must assert the full rendered traceback text including the file/line frame and the TemplateSyntaxError message listing expected closing tags, tolerating PyPy leaving the original syntax error in the middle of compiler frames.
- **Applies to:**
  - `tests/test_debug.py`
- **Condition:** when adding or modifying tests that assert on rendered syntax-error tracebacks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6699f086408c4e73e53c823c.md)
