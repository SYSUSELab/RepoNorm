# Constraints for `tests/test_pickle.py`

## Rule

- **Rule:** Environment instances must remain picklable and, after a pickle round-trip, must still render templates identically; do not add unpicklable state (locks, open handles, generators, compiled closures) to Environment or its base classes.
- **Applies to:**
  - `tests/test_pickle.py`
- **Condition:** When modifying Environment construction, attributes, or base-class state that participates in pickling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d78268120c2e5ae0f5ed7c6c.md)
