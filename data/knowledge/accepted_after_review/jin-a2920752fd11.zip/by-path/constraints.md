# Constraints for `.`

## Rule

- **Rule:**
  ```text
  The package root directory is src (package_dir = = src).
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0773bf1511b0e3ad730d2c3d.md)

## Rule

- **Rule:**
  ```text
  For feature additions or changes, branch off "main" using `git fetch origin` followed by `git checkout -b your-branch-name origin/main`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-090cae4f22a260cb9492cfbd.md)

## Rule

- **Rule:** Do not use the issue tracker for support questions; the issue tracker is for bugs and feature requests in Jinja itself.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-0a424d5f293b8d48d5d1d45b.md)

## Rule

- **Rule:**
  ```text
  Indent size is 4 (indent_size = 4) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0f82da36c0b11a923f7a83f8.md)

## Rule

- **Rule:** The pre-commit configuration enables the fix-byte-order-marker hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-10f3bad89da0196fce3edfc0.md)

## Rule

- **Rule:** Use Black to format code; Black and other tools run automatically if pre-commit is installed using the instructions below.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1f647350267102d53890f09d.md)

## Rule

- **Rule:** The tox testenv installs test dependencies from requirements/tests.txt.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-287e002f7d56cf2b8df950dc.md)

## Rule

- **Rule:**
  ```text
  Coverage path configuration sets source to `src` and `*/site-packages`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28e466c62a4c511fb8232297.md)

## Rule

- **Rule:**
  ```text
  Add your fork as a remote named "fork" with `git remote add fork https://github.com/{username}/jinja`, replacing `{username}` with your username.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-3cebbcfded01ea6cdd810718.md)

## Rule

- **Rule:** For feature additions or changes, branch off the "main" branch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-3dc4304c17d2ba2a97018147.md)

## Rule

- **Rule:** flake8 enforces a maximum line length of 80.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-434ee96c05406f218a2f1314.md)

## Rule

- **Rule:**
  ```text
  Create a virtualenv with `python3 -m venv env` and activate it with `. env/bin/activate`; on Windows activation is `env\Scripts\activate`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-486f597143c375f72c7995c8.md)

## Rule

- **Rule:**
  ```text
  Clone the main repository locally with `git clone https://github.com/pallets/jinja` and `cd jinja`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-503ddc5ca0922cf1c7adf3af.md)

## Rule

- **Rule:**
  ```text
  For bug or documentation fixes, branch off the latest ".x" branch using `git fetch origin` followed by `git checkout -b your-branch-name origin/3.0.x`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-521a013850461f4a5725ff66.md)

## Rule

- **Rule:** Read the Docs builds use Ubuntu 20.04 as the build OS.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-53e9fee1286200f505482821.md)

## Rule

- **Rule:** Include tests that cover any code changes made, and make sure the test fails without the patch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-55a86070e9b0623cbb8101c5.md)

## Rule

- **Rule:**
  ```text
  Maximum line length is 88 characters (max_line_length = 88) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5762b659ad1cda420407c359.md)

## Rule

- **Rule:**
  ```text
  The reorder-python-imports pre-commit hook runs with --application-directories src and additional dependency setuptools>60.9.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-61661d130597dcafc17ba2ae.md)

## Rule

- **Rule:**
  ```text
  Trailing whitespace is trimmed (trim_trailing_whitespace = true) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6c93e77d25b1b36837c35126.md)

## Rule

- **Rule:** Read the Docs installs the repository itself via pip from the repository root path.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6d6c1571f997c922150f8652.md)

## Rule

- **Rule:** Create a branch to identify the issue being worked on; for bug or documentation fixes, branch off the latest ".x" branch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-71e96a548c1088d11778420c.md)

## Rule

- **Rule:**
  ```text
  Line endings use LF (end_of_line = lf) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-772f4ba987b1939af58e05b3.md)

## Rule

- **Rule:**
  ```text
  Run ``pytest`` using ``coverage`` and generate a report to find lines lacking test coverage.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-791420d8b378e8e674be3026.md)

## Rule

- **Rule:**
  ```text
  YAML, JSON, JavaScript, CSS, and HTML files use an indent size of 2 (indent_size = 2).
  ```
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-79769d3d7e586d171f691e00.md)

## Rule

- **Rule:** flake8 ignores E203, E501, E722, and W503.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7b6f826d81d69804ebd1c31f.md)

## Rule

- **Rule:**
  ```text
  For the jinja2.defaults module, mypy's no_implicit_reexport check is disabled (set to False).
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7ffbbe81e0bf575055a1a82c.md)

## Rule

- **Rule:**
  ```text
  Open ``htmlcov/index.html`` in a browser to explore the coverage report.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-808ae92d9041567980e98962.md)

## Rule

- **Rule:** The flake8 pre-commit hook runs with the flake8-bugbear additional dependency.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8c894825239ef79c9645e85f.md)

## Rule

- **Rule:**
  ```text
  The package requires Python >= 3.7 (python_requires = >= 3.7).
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-974e6679ae07ab77fb1fdfba.md)

## Rule

- **Rule:** Run the basic test suite with pytest.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-9f92fefe109c15c523bbf8c1.md)

## Rule

- **Rule:**
  ```text
  Character encoding is UTF-8 (charset = utf-8) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a0181e41d26c5c0d3013a49e.md)

## Rule

- **Rule:**
  ```text
  Install the pre-commit hooks with `pre-commit install`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-ad47d2b2785d494ef0cee535.md)

## Rule

- **Rule:** Update any relevant docs pages and docstrings; docs pages and docstrings should be wrapped at 72 characters.
- **Applies to:**
  - `**/*.py`
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-ad48973dc36cc16e7d68b071.md)

## Rule

- **Rule:** EditorConfig is the root configuration (root = true).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ad8f9786ee47994a8da4d722.md)

## Rule

- **Rule:**
  ```text
  Indentation uses spaces (indent_style = space) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aeaaaab4dc092724a8204200.md)

## Rule

- **Rule:** Package discovery uses find: so packages are auto-discovered rather than explicitly listed.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aeb9048a6ba5fea5612cb7c3.md)

## Rule

- **Rule:** Coverage measurement is configured to track branch coverage.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-afdb2d6da175e72203754cad.md)

## Rule

- **Rule:** The pre-commit configuration enables the trailing-whitespace hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b68e0c341286ecc8f561ab6b.md)

## Rule

- **Rule:**
  ```text
  The tox testenv:style environment sets skip_install to true.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b7613278091531b430091012.md)

## Rule

- **Rule:** CI runs the full test suite when a pull request is submitted.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-be0e1dffbdac765b5ca8e2c2.md)

## Rule

- **Rule:**
  ```text
  Package data is included in distributions (include_package_data = True).
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-beb8981480e04e501630c39b.md)

## Rule

- **Rule:**
  ```text
  Configure git with your username and email using `git config --global user.name 'your name'` and `git config --global user.email 'your email'`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-c10f02c7362508c3783ebbc1.md)

## Rule

- **Rule:** The tox testenv runs tests via pytest with verbose output, short tracebacks, and a basetemp set to the env tmpdir, forwarding posargs.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c252c92b4358221136f85d02.md)

## Rule

- **Rule:**
  ```text
  Pytest treats warnings as errors (filterwarnings = error), except the DeprecationWarning matching 'The loop argument' raised from asyncio.base_events, which is ignored.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c3b8e44f5ead25baad6ca592.md)

## Rule

- **Rule:**
  ```text
  Files end with a final newline (insert_final_newline = true) for files matched by the [*] section.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c94d140e6b13520059a8d1fc.md)

## Rule

- **Rule:** The pip-compile-multi-verify pre-commit hook is configured.
- **Applies to:**
  - `**/*.in`
  - `**/*.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc331d533dc5f29845a0271f.md)

## Rule

- **Rule:** The tox testenv:typing environment runs mypy as its command.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cd79aaf14da41a4e74f7ae6e.md)

## Rule

- **Rule:**
  ```text
  For the mypy-markupsafe module configuration, no_implicit_reexport is set to False.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d1564f2e6d4e27a474338e1d.md)

## Rule

- **Rule:**
  ```text
  The tox testenv:style environment depends on the `pre-commit` package.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d675095f4030c77b1c7b9a55.md)

## Rule

- **Rule:** The pre-commit configuration enables the end-of-file-fixer hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-da5005339ebe5d03790a46b6.md)

## Rule

- **Rule:** Add an entry in CHANGES.rst using the same style as other entries, and include .. versionchanged:: inline changelogs in relevant docstrings.
- **Applies to:**
  - `**/*.py`
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-e9533ec2a155fea7a48b5418.md)

## Rule

- **Rule:** Read the Docs builds use Python 3.10.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed2f314dc2d117fbe872eada.md)

## Rule

- **Rule:** flake8 selects the B, E, F, W, B9, and ISC rule codes.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f11d249d940b132cd1d09de5.md)
