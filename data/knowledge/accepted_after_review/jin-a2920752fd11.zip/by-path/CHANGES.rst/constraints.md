# Constraints for `CHANGES.rst`

## Rule

- **Rule:** Add an entry in CHANGES.rst using the same style as other entries, and include .. versionchanged:: inline changelogs in relevant docstrings.
- **Applies to:**
  - `**/*.py`
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-e9533ec2a155fea7a48b5418.md)
