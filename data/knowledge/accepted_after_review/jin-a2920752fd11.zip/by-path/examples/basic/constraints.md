# Constraints for `examples/basic`

## Rule

- **Rule:** Example scripts under examples/basic must remain runnable standalone demonstrations: each configures its own Environment (or loader) and renders a template inline rather than importing shared example helpers.
- **Applies to:**
  - `examples/basic/*.py`
- **Condition:** when adding or modifying a runnable example script under examples/basic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7507f4eb9e71722ef2257413.md)
