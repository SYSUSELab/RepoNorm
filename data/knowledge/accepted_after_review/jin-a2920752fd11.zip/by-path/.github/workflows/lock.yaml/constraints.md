# Constraints for `.github/workflows/lock.yaml`

## Rule

- **Rule:** The lock job runs on ubuntu-latest and uses the dessant/lock-threads@v3 action with github-token set to ${{ github.token }}, issue-inactive-days set to 14, and pr-inactive-days set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3a687b463eb4dd5b3ac6c1d3.md)

## Rule

- **Rule:**
  ```text
  The lock workflow runs on a daily schedule defined by the cron expression '0 0 * * *'.
  ```
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cb292e166325b949beabe5a1.md)
