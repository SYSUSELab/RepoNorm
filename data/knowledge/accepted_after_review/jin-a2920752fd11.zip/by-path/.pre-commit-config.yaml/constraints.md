# Constraints for `.pre-commit-config.yaml`

## Rule

- **Rule:** The pre-commit CI autoupdate branch is 3.0.x.
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-161b30c27b0292ac29bef22e.md)

## Rule

- **Rule:** The pre-commit CI autoupdate schedule is monthly.
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5615114fa213fc4cb7262dc6.md)
