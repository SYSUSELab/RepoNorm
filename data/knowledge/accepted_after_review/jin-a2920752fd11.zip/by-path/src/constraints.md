# Constraints for `src`

## Rule

- **Rule:** Package discovery for the project is configured to search under the src directory.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b4e5aa2a3fe53ce62be0b74c.md)
