# Constraints for `src/jinja2/sandbox.py`

## Rule

- **Rule:**
  ```text
  `modifies_known_mutable` returns True only when the attribute name is in the unsafe set for the matching type in `_mutable_spec`, and returns False for unsupported objects; doctests pin `clear`/`append` as unsafe and `keys`/`index`/`upper` as safe.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying the sandbox's mutable attribute safety checks or the `_mutable_spec` mapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2402ec60d67f1f52b24cf198.md)

## Rule

- **Rule:**
  ```text
  SandboxedEnvironment must expose default_binop_table and default_unop_table with intercepted_binops/intercepted_unops as frozensets empty by default; intercepted operators are delegated to call_binop/call_unop and are slower than native calls.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying SandboxedEnvironment operator interception, keep the default binop/unop tables and empty-by-default intercepted frozensets, and route intercepted operators through call_binop/call_unop.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-285b0f96ce0f14f7e550b49e.md)

## Rule

- **Rule:**
  ```text
  When modifying the sandbox's mutation protection, keep the blocked mutating methods driven by the explicit _mutable_spec enumeration for MutableSet, MutableMapping, MutableSequence, and deque rather than relying on implicit type checks.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** Changing sandbox mutation protection or the set of blocked mutating methods.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-431d484c5f03f7bec9621444.md)

## Rule

- **Rule:**
  ```text
  unsafe_undefined returns an Undefined carrying name, obj, and exc=SecurityError, so unsafe attribute access surfaces as a SecurityError-backed undefined rather than a plain undefined.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When modifying sandbox undefined handling or unsafe attribute access behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95de4a610b0fde39fe2b3ce4.md)

## Rule

- **Rule:**
  ```text
  Unsafe attribute sets must be defined per callable kind: generators block gi_frame/gi_code, coroutines block cr_frame/cr_code, and async generators block ag_code/ag_frame; these are the sandbox's attribute-denial protocol.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When modifying sandbox attribute denial for callable kinds or adding new unsafe attribute sets.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c00c804b482724591656fdb5.md)

## Rule

- **Rule:**
  ```text
  Sandbox range handling must enforce MAX_RANGE=100000 as the maximum number of items a range may produce; changes to range handling must preserve this hard limit.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** when modifying range handling or sandbox resource limits
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cf272632b8da16b26cb36d09.md)

## Rule

- **Rule:**
  ```text
  The @unsafe decorator must mark a callable by setting unsafe_callable=True and returning it, and is_safe_callable must treat a callable as unsafe when unsafe_callable=True or Django's alters_data=True, otherwise safe by default.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  when adding or modifying callable-safety marking or the is_safe_callable check
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d2af45581120c59e820f8dd6.md)

## Rule

- **Rule:**
  ```text
  SandboxedFormatter.get_field splits a format field name, resolves the first component via get_value, then walks remaining attribute/item accesses through the sandbox's getattr/getitem, so format field access is subject to sandbox restrictions.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When modifying sandboxed format field access or attribute/item resolution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dd8917db8f36f3970ce937e5.md)

## Rule

- **Rule:**
  ```text
  When modifying SandboxedEnvironment.getitem, preserve the fallback contract: string keys that fail item lookup fall back to attribute access, and the attribute is returned only when is_safe_attribute passes; otherwise unsafe_undefined is returned, and non-string or failed lookups return the default undefined.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** Changing sandboxed item/attribute lookup behavior in SandboxedEnvironment.getitem.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f063066551f74991c4708953.md)
