# Constraints for `src/jinja2/compiler.py`

## Rule

- **Rule:**
  ```text
  When modifying the autoescape code generation, preserve visit_MarkSafeIfAutoescape's conditional emission: select Markup when context.eval_ctx.autoescape is true and identity otherwise, so the same expression is marked safe only under autoescape.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  changing how visit_MarkSafeIfAutoescape emits the conditional Markup/identity call
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0403849c7ca683802a61dd4c.md)

## Rule

- **Rule:**
  ```text
  When modifying FilterBlock compilation, preserve the contract that it creates an inner frame, analyzes the node's symbols, buffers the body, then writes the filter result via visit_Filter on the inner frame before leaving it, so the filter applies to the buffered block output.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing or extending how FilterBlock nodes are compiled.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-076dd25f44bfd70773d54fd5.md)

## Rule

- **Rule:**
  ```text
  When modifying CodeGenerator.choose_async or its callers, preserve the rule that async code generation is selected solely from environment.is_async, making it a per-environment compile-time decision rather than per-template.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Editing CodeGenerator.choose_async or code that depends on async code generation selection in src/jinja2/compiler.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-194d382027b96c61fed274da.md)

## Rule

- **Rule:**
  ```text
  When modifying the compiler's context-reference tracking, preserve push_context_reference's stack operation: it appends a target string to _context_reference_stack.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  changing how push_context_reference records context references
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1c3b442580b28912562d2cdd.md)

## Rule

- **Rule:**
  ```text
  When modifying parameter-definition handling in the compiler, preserve the stack discipline: parameter definitions are maintained as a stack and pop_parameter_definitions removes the most recent set.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing how parameter definitions are pushed or popped during code generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1e5de810617306a67adabd73.md)

## Rule

- **Rule:** Keyword compilation emits 'key=' followed by the compiled value expression, so keyword arguments are rendered as name=value pairs.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying keyword argument compilation in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-25942021ecd749dd9bbaf3a9.md)

## Rule

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Import or its callers, preserve the rule that toplevel imports write to context.vars and the target is discarded from exported_vars unless the target name starts with underscore.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Editing CodeGenerator.visit_Import or code that depends on import export behavior in src/jinja2/compiler.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-27994109d93941044c29fc64.md)

## Rule

- **Rule:**
  ```text
  When a frame buffer is present, output must be emitted via buffer.append for a single body item or buffer.extend for multiple items, and runtime nodes must be wrapped with _output_child_pre/_output_child_post.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying output emission in the compiler, especially buffered output paths and runtime node wrapping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2b84ba1bfab590509c48c613.md)

## Rule

- **Rule:**
  ```text
  CodeGenerator.visit_Template must assert no root frame is allowed, emit imports of exported runtime names, detect extends to decide whether inheritance code is needed, reject duplicate block names, and generate root and block render functions with distinct frame handling.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying CodeGenerator.visit_Template, preserve the no-root-frame assertion, exported-name imports, extends-based inheritance decision, duplicate-block rejection, and distinct root/block frame handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-40b8c29a1a179b521cddecc5.md)

## Rule

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Block, preserve block codegen guards: skip emitting block-call code when a known extends exists at top level, otherwise guard block output with a parent_template check, and emit a runtime error for required blocks with no override.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing block code generation, extends handling, or required-block override behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-41220cc5199878c3bfd8e2e7.md)

## Rule

- **Rule:**
  ```text
  When modifying compiler dependency handling, keep pull_dependencies assigning temporary identifiers for used filters/tests and emitting runtime try/except KeyError lookups that define a stub raising TemplateRuntimeError('No filter/test named ... found.'), because If/CondExpr dependencies are checked at runtime rather than compile time since 3.0.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing pull_dependencies or runtime filter/test dependency resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-543427d4f920c36b2ddb57b3.md)

## Rule

- **Rule:**
  ```text
  _filter_test_common wraps filter/test calls in auto_await when the environment is async, and only fails at compile time for unknown filters/tests when the frame is not a soft frame (inside If or CondExpr).
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying filter/test compilation or auto_await wrapping in the compiler.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5c11fadedb321f84632f0342.md)

## Rule

- **Rule:**
  ```text
  CodeGenerator initializes optimizer only when optimized=True, and maintains import_aliases, blocks, tests, filters, debug_info, and context_reference_stack as per-instance registries; has_known_extends tracks root-level extends for child-template optimization.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying CodeGenerator initialization or per-instance compiler state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-611c9a145daeb340c196d051.md)

## Rule

- **Rule:**
  ```text
  Extends may only appear at top-level template scope; a second extends in the same template must raise TemplateRuntimeError('extended multiple times') unless compile-time known-extends handling exits the compiler, and a root-level extends must set has_known_extends so later codegen can simplify.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying CodeGenerator.visit_Extends or the extends handling in the compiler, preserve the top-level-only restriction, the duplicate-extends runtime error, and the has_known_extends bookkeeping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-63ad59281c29fa10893c7a71.md)

## Rule

- **Rule:** blockvisit must catch CompilerExit so that block compilation can terminate early; contributors modifying block compilation must preserve this early-exit behavior.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying block compilation or the blockvisit method
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-63fbe400a00b68c5aaa3f72e.md)

## Rule

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Dict, preserve the dict emission contract: emit a Python dict literal by visiting each key and value in order and joining with ', ', so dict node items must be visited pairwise to preserve ordering.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.visit_Dict or its key/value emission order.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-683dec6d3d66599915b9ced3.md)

## Rule

- **Rule:**
  ```text
  When modifying undeclared-name analysis, preserve the contract that find_undeclared uses an UndeclaredNameVisitor and stops early on VisitorExit, returning the set of names accessed but not declared.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing or extending compile-time undeclared-name analysis in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-73a426c6f51bcbbd90aedc24.md)

## Rule

- **Rule:**
  ```text
  When modifying UndeclaredNameVisitor.__init__ or its callers, preserve the invariant that undeclared names are tracked separately from declared names, with undeclared initialized as an empty set.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Editing UndeclaredNameVisitor.__init__ or code that relies on undeclared-name tracking in src/jinja2/compiler.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-79b7f68c3fee2062d77d5dc6.md)

## Rule

- **Rule:**
  ```text
  outdent decrements self._indentation by step, so indentation state is a simple counter that must be balanced with matching indent calls.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying code generation indentation or adding indent/outdent calls
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7d8c5905c74285dd7f8cf925.md)

## Rule

- **Rule:**
  ```text
  In visit_Filter, when the filter node is None (inside a filter block) the generated concat output is wrapped in Markup only when eval_ctx.autoescape is true; under volatile eval context the expression conditionally applies Markup based on context.eval_ctx.autoescape, otherwise it emits plain concat.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying filter block compilation or autoescape handling in visit_Filter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-81c1b8931ab6cb26c1d49287.md)

## Rule

- **Rule:**
  ```text
  CodeGenerator.visit_ExtensionAttribute must emit a direct subscript into environment.extensions keyed by the node identifier followed by attribute access, coupling extension attribute resolution to the runtime environment.extensions mapping rather than a generic getattr path.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying CodeGenerator.visit_ExtensionAttribute, keep the direct environment.extensions subscript keyed by the node identifier followed by attribute access.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-860d2f13f70ba54399f18c6c.md)

## Rule

- **Rule:**
  ```text
  enter_frame maps symbol load actions to emitted code: VAR_LOAD_PARAMETER is skipped, VAR_LOAD_RESOLVE emits a resolve call, VAR_LOAD_ALIAS emits an assignment, VAR_LOAD_UNDEFINED collects targets, and unknown actions raise NotImplementedError; collected undefined targets are emitted as missing.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying frame symbol load handling or adding new load actions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-87641580567e83e18d9b3e05.md)

## Rule

- **Rule:**
  ```text
  Scoped eval-context modifiers must save the eval context, apply the modifier, visit the body, then revert both the frame eval_ctx and the emitted context.eval_ctx so scoped changes do not leak.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying scoped eval-context modifier code generation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8b0a0cff854c2a13beaa8ec1.md)

## Rule

- **Rule:** When modifying constant code generation, keep float constants emitted via str(val) without repr quoting while all other constants use repr(val).
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing visit_Const or constant emission in the compiler.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-97a6554076b5d13c95ed4b37.md)

## Rule

- **Rule:** VisitorExit is a RuntimeError subclass used by UndeclaredNameVisitor to signal a stop, defining the internal exception protocol for visitor termination.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying visitor termination or the UndeclaredNameVisitor control flow.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a0203c84b9f37288a4d61f91.md)

## Rule

- **Rule:** position returns 'line {node.lineno}' and appends ' in {self.name!r}' when self.name is not None, defining the human-readable node position format.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying node position formatting or error messages that include positions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a0c478c54f10b37f8edc569e.md)

## Rule

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Include, preserve include compilation selection: use get_template for constant string templates, select_template for constant tuple/list templates, and get_or_select_template otherwise; ignore_missing wraps lookup in try/except TemplateNotFound, and with_context renders via root_render_func with a new context.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.visit_Include or its template lookup and rendering behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a9514d854155a64587cac113.md)

## Rule

- **Rule:** writeline must be defined as the combination of newline followed by write, establishing that line-oriented code generation emits a newline before the content.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying line-oriented code generation helpers such as writeline in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a9dbbf5873a81ff299f557dc.md)

## Rule

- **Rule:**
  ```text
  When modifying TemplateData compilation, preserve the autoescape codegen contract: write repr of the constant when foldable; if folding raises Impossible, emit a runtime conditional choosing Markup or identity based on context.eval_ctx.autoescape, so autoescape is applied at runtime for non-constant data.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.visit_TemplateData or its constant-folding/autoescape emission.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aaf4bd70d5a845b68afc9752.md)

## Rule

- **Rule:**
  ```text
  When modifying the compiler's comparison-operator handling, preserve the operators mapping from Jinja operator names to Python operators (eq->==, ne->!=, gt->>, gteq->>=, lt-><, lteq-><=, in->in, notin->not in).
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing or extending how the compiler translates Jinja comparison operators into Python operators.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae2eba84520cc626fde2b1fc.md)

## Rule

- **Rule:**
  ```text
  Overlay scopes are compiled as isolated frames: visit_OverlayScope derives a context, assigns vars from the node context, pushes a context reference, compiles the body in an isolated inner frame, then pops the context reference.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying OverlayScope compilation or the frame/context handling around overlay bodies.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af2cdc23c55c9f9b1df1e1cd.md)

## Rule

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_If, preserve the soft-frame branch isolation: compile the test and all branches using a soft frame so if/elif/else blocks share the same if_frame and branch bodies do not leak symbol changes into the outer frame.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing if/elif/else code generation or frame handling in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b29392f15d6d83f91ecd88cc.md)

## Rule

- **Rule:**
  ```text
  NSRef assignment must target a Namespace: visit_NSRef emits a runtime isinstance check that raises TemplateRuntimeError when the target is not a Namespace, so changes to NSRef compilation must preserve this guard.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying NSRef compilation or the runtime target of namespace attribute assignment.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b395df44e1ea912641cfded0.md)

## Rule

- **Rule:** The compiler generate function must raise TypeError for non-Template nodes and return the generated source string only when no stream is provided; with a stream it returns None.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying the compiler generate entry point or its stream handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ba9adcfe6160115224cc3aa5.md)

## Rule

- **Rule:**
  ```text
  When modifying the code generator's output-emission helpers, preserve the frame-buffer contract: start_write must emit 'yield ' when the frame has no buffer and '<buffer>.append(' otherwise, and literal writes must be wrapped by start_write/end_write via simple_write so frame bookkeeping stays consistent.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When changing or adding output-emission logic in the code generator (start_write, simple_write, or callers that emit literal output).
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c2e71bf01c5c9c03dcfc63f7.md)

## Rule

- **Rule:**
  ```text
  When modifying the BinExpr visitor, preserve the sandbox interception boundary: emit environment.call_binop(context, op, ...) when the environment is sandboxed and the operator is in intercepted_binops; otherwise emit a plain parenthesized binary expression.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing binary operator code generation or sandbox interception behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c7638ee40c7bf3270c7e2961.md)

## Rule

- **Rule:**
  ```text
  DependencyFinderVisitor.visit_Test must record the test name into self.tests after generic_visit, so the compiler tracks which named tests are used in a template.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying DependencyFinderVisitor.visit_Test or the dependency-tracking logic, preserve recording the test name into self.tests after generic_visit.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d8c247d83bb4a47bb7a070bf.md)

## Rule

- **Rule:** EnvironmentAttribute compilation emits a direct attribute access on the runtime 'environment' object using the node's name, so environment attributes are resolved at render time rather than inlined.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying EnvironmentAttribute compilation or environment attribute resolution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e1281e68c3fe0422f3e2b81f.md)

## Rule

- **Rule:**
  ```text
  When modifying the binop visitor generation, preserve _make_binop's factory contract: it returns a visitor callable for binary expression nodes, parameterized by operator, used to generate CodeGenerator binop visitors.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  changing how _make_binop generates binop visitors
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e4597e1367b51a3591907954.md)

## Rule

- **Rule:**
  ```text
  When modifying the default finalize behavior, preserve the contract that _default_finalize returns str(value) and is the fallback finalize, also applied to constants when the environment defines a finalize function.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator._default_finalize or the fallback finalize behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f243f34cd6ac05bac008d0d2.md)

## Rule

- **Rule:**
  ```text
  When modifying CodeGenerator.return_buffer_contents, preserve autoescape-aware buffer return: emit Markup(concat(buffer)) when autoescape is active, concat(buffer) otherwise, and a runtime branch on context.eval_ctx.autoescape when autoescape is volatile.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Changing CodeGenerator.return_buffer_contents or its autoescape-dependent buffer emission.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f2dba4dcd20734e497231e2f.md)

## Rule

- **Rule:** For non-async environments with no buffer, blocks must be invoked via yield from; otherwise generated code must iterate the block call and write each event, preserving the async block protocol.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying block code generation for async or buffered environments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f89c7427a738c0e9d08db299.md)
