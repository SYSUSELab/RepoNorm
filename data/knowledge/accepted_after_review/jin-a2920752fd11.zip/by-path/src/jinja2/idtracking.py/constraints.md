# Constraints for `src/jinja2/idtracking.py`

## Rule

- **Rule:**
  ```text
  find_load must check the current frame's loads first, then delegate to the parent frame, implementing lexical scope lookup.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** When modifying symbol lookup or lexical scope resolution in the idtracking module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2090416ab96a5fab1be244ef.md)

## Rule

- **Rule:**
  ```text
  When modifying Symbols.__init__, preserve the nesting-level invariant: level is derived from parent.level + 1 when level is None and a parent exists, otherwise 0, and refs, loads, and stores containers are initialized.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  Changing Symbols.__init__ or its level derivation and container initialization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-51f04bf3adc01a9b79b4eb88.md)

## Rule

- **Rule:**
  ```text
  When modifying the idtracking visitor, preserve visit_For's boundary behavior: the visitor stops at for blocks but still visits the iter expression as part of the outer scope.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  changing how FrameSymbolVisitor.visit_For handles for blocks and their iter expressions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5f57bd57bff7cc886f629cce.md)

## Rule

- **Rule:**
  ```text
  When modifying the idtracking load-kind vocabulary, preserve the four VAR_LOAD_* constants (param, resolve, alias, undefined) that classify how a variable is loaded.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  Changing the VAR_LOAD_* load-kind constants or their classification vocabulary.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-613ee772f91d36f01a3c9718.md)

## Rule

- **Rule:**
  ```text
  The idtracking visitor stops visiting at Scope nodes, treating them as artificial scope boundaries for symbol tracking, and visit_Import calls generic_visit then stores node.target as a symbol.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** When modifying symbol tracking or scope boundary handling in the idtracking visitor.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7442fac7bbcaadf5c70a5c41.md)

## Rule

- **Rule:**
  ```text
  When modifying symbol tracking, preserve the contract that visit_Block stops visiting at blocks so symbol tracking does not descend into block bodies.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** When changing or extending symbol tracking traversal of block nodes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8669494ebb5bbefa35febd70.md)

## Rule

- **Rule:**
  ```text
  Symbols.find_ref must return the local ref if present, otherwise delegate to self.parent.find_ref(name), and return None when no parent exists, defining the ref-resolution chain.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  When modifying Symbols.find_ref or the ref-resolution logic, preserve the local-first lookup, parent delegation, and None return when no parent exists.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b4e4d5774e2234842b60af96.md)

## Rule

- **Rule:**
  ```text
  When modifying store dumping, preserve the contract that dump_stores walks the Symbols parent chain and records the first-seen ref for each store name, so inner scopes shadow outer ones and names are emitted in sorted order per level.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** When changing or extending how stored symbols are dumped across scope levels.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e7bfd941ea61e993ae5efdeb.md)

## Rule

- **Rule:**
  ```text
  When modifying branch symbol resolution, preserve the contract that branch_update only rewrites loads for names not stored in every branch; if the name is not found in the parent scope it emits VAR_LOAD_RESOLVE, otherwise it aliases to the outer target via VAR_LOAD_ALIAS.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** When changing or extending how branch updates resolve loaded names across branches.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f2351afa05aa402d2d72f31a.md)
