# Constraints for `src/jinja2/visitor.py`

## Rule

- **Rule:** NodeTransformer replaces or removes nodes based on visitor return values: None removes the node, otherwise the return value replaces it, and returning the original node means no replacement.
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:** When modifying AST node transformation or visitor return value handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-284083fdbea40f5049f050ad.md)

## Rule

- **Rule:**
  ```text
  When modifying NodeTransformer.generic_visit or its callers, preserve the in-place mutation protocol: list fields are rebuilt with visited nodes, None results are dropped, non-Node return values are extended into the list, and a None result for a single Node field deletes the attribute.
  ```
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:**
  ```text
  Editing NodeTransformer.generic_visit or code that relies on its mutation behavior in src/jinja2/visitor.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-46561cccb6f0c443db764cbb.md)

## Rule

- **Rule:**
  ```text
  NodeVisitor dispatch must resolve a handler named 'visit_' + node class name, fall back to generic_visit when no such handler exists, and route through get_visitor so subclasses can override dispatch resolution.
  ```
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:**
  ```text
  When adding or modifying node visitor dispatch, handler resolution, or the generic_visit fallback in the visitor module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-638ba745bc25ba66d9a7cd8f.md)
