# Constraints for `src/jinja2/nodes.py`

## Rule

- **Rule:** MarkSafe must be an Expr node with a single expr field, used to wrap an expression as safe (Markup), and its field tuple defines the node's child structure for visitors and compilers.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying MarkSafe or adding safe-wrapping nodes, preserve the single expr field and the Expr subclass contract that defines the child structure for visitors and compilers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0134af8276a6f186925e2101.md)

## Rule

- **Rule:**
  ```text
  Getattr.as_const must only fold when the node context is 'load', resolve the attribute through the environment's getattr, and convert any exception into Impossible so constant folding never propagates runtime errors.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying constant folding for attribute access or the as_const implementation on AST nodes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-020c60b2e7101357036ff178.md)

## Rule

- **Rule:** Scope is an artificial statement node with a single body field; contributors adding or traversing scope nodes must preserve the body-only node protocol.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when adding or traversing Scope nodes in the AST
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0364815fdc4401edf56be195.md)

## Rule

- **Rule:**
  ```text
  When modifying the Node base class, preserve the contract that Node declares fields as a tuple, attributes as ("lineno", "environment"), abstract = True, and __hash__ = object.__hash__, so nodes are hashable by identity and environment is attached automatically at the end of parsing.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When changing or extending the Node base class's field/attribute declarations or hashing behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-041fb1df3bd27dadc30277d0.md)

## Rule

- **Rule:** UnaryExpr must be an abstract Expr subclass declaring fields=('node',) with a node: Expr attribute and an operator: str attribute, establishing the field/attribute contract for unary expression nodes.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying UnaryExpr or adding unary expression node subclasses, preserve the fields=('node',) contract and the node: Expr and operator: str attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0458be4d302baef354a39234.md)

## Rule

- **Rule:**
  ```text
  Node.set_ctx resets the ctx field on the node and all descendants via breadth-first traversal, returning self, and skips nodes lacking a ctx field.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying context propagation across a node tree or adding nodes with a ctx field.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-13a0932802595fbabdc1ba83.md)

## Rule

- **Rule:** When modifying the Block node schema, preserve the field tuple ('name', 'body', 'scoped', 'required'), including the 'required' field added in version 3.0.0, as a compatibility boundary for node consumers.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing the Block node fields or their compatibility contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2ac95c1bd92a0f28092b4632.md)

## Rule

- **Rule:** Assign must declare fields ("target", "node"), fixing the AST field order and names for assignment nodes.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying the Assign AST node's field declarations or field order.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3a4ac830bf3a4de2add436d2.md)

## Rule

- **Rule:**
  ```text
  Getitem nodes must expose fields (node, arg, ctx) and represent item access (subscript) rather than attribute access, and Getitem.as_const must only fold in load context, wrapping any environment.getitem failure as Impossible.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying the Getitem node class or its as_const method, preserve the (node, arg, ctx) field contract, the item-access semantics, and the load-context-only constant folding that fails closed.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44a945a6a9f87dca8df52c2a.md)

## Rule

- **Rule:** Conditional-expression constant folding must return expr1 when the test is constant-true, raise Impossible when there is no else branch, and otherwise return expr2.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying CondExpr.as_const or conditional-expression constant folding, preserve the constant-true/constant-false branching and the Impossible raise when no else branch exists.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5ec0dc41a8673582566be529.md)

## Rule

- **Rule:**
  ```text
  Test nodes must set _is_filter = False and share the same volatility/async/pass_context decorator handling as filters, so tests and filters are distinguished only by the _is_filter flag.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying the Test node class or the shared decorator-handling logic for tests and filters, preserve _is_filter = False and the shared volatility/async/pass_context handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-65683585ea6464332e7cb669.md)

## Rule

- **Rule:**
  ```text
  If is a statement node with fields test, body, elif_, and else_, where elif_ is a list of nested If nodes; contributors modifying conditional AST handling must preserve this field protocol.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying conditional AST node handling or the If node structure.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6644db7987ca2e137d3140f6.md)

## Rule

- **Rule:**
  ```text
  When modifying Node.find_all, preserve recursive descendant traversal: it yields descendants matching a node type or tuple of types, including nested matches.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  Changing Node.find_all or its recursive descendant matching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-671da297113aaeec584b0edc.md)

## Rule

- **Rule:** ExtensionAttribute node declares fields ('identifier','name') and is documented as constructed via Extension.attr, defining the extension-attribute AST contract.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying the ExtensionAttribute AST node or extension attribute construction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6ea686e651ae6bd8a652fae6.md)

## Rule

- **Rule:** AssignBlock must be a Stmt node with fields (target, filter, body), where filter is optional and body is a list of nodes, defining the AST shape for block assignment.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying the AssignBlock AST node's field declarations or optionality.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7da9c588ca06ae9753f00281.md)

## Rule

- **Rule:** Const nodes must be Literal nodes with fields ('value',) and value typed as Any, and must only be used for constants with a safe representation where eval(repr(x)) == x is true.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying the Const node class or adding constant values, preserve the ('value',) field contract and the safe-representation requirement eval(repr(x)) == x.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7ece74e63b96affec910abd3.md)

## Rule

- **Rule:**
  ```text
  Node.set_environment must mutate every node reachable via iter_child_nodes using an iterative deque traversal and return self, so environment assignment propagates through the whole subtree without recursion.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying environment propagation across AST subtrees or the set_environment traversal implementation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-899280dc1195ec4434236520.md)

## Rule

- **Rule:**
  ```text
  When modifying UnaryExpr.as_const or its callers, preserve the sandbox folding boundary: constant folding raises Impossible when the environment is sandboxed and the operator is in intercepted_unops, and other exceptions during folding are also converted to Impossible.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  Editing UnaryExpr.as_const or code that relies on constant folding behavior in src/jinja2/nodes.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a17636299f05820960c6f9f4.md)

## Rule

- **Rule:** When modifying FilterBlock, preserve the exact fields tuple ("body", "filter") and the typed body/filter attributes, since node traversal and code generation depend on this field ordering and naming.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** changing FilterBlock's declared fields or attribute types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a93da449a1501f5469c953c6.md)

## Rule

- **Rule:**
  ```text
  iter_fields yields (name, value) for fields filtered by exclude/only and silently skips fields raising AttributeError, so optional node fields are tolerated during traversal.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying node field traversal or adding optional node fields
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ac13e36bdc7b25c320aeff9b.md)

## Rule

- **Rule:**
  ```text
  Binary, unary, and comparison operators are mapped to Python operator functions via _binop_to_func, _uaop_to_func, and _cmpop_to_func, including 'in'/'notin' as lambdas; compiler/constant-folding behavior depends on these mappings.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying operator mapping or constant-folding behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b277892df0466c1af6dc76b2.md)

## Rule

- **Rule:** Break is a Stmt subclass representing loop break; its presence in the node hierarchy means compiler/visitor code must handle Break nodes when processing loop bodies.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying loop body processing or visitor handling of Break nodes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c91fe10cfdf14c0e6edfba95.md)

## Rule

- **Rule:**
  ```text
  Compare.as_const must fold chained comparisons by applying each operator in sequence, short-circuiting to False as soon as a comparison is false, and converting any exception during folding to Impossible.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying Compare.as_const constant folding, preserve sequential operator application, short-circuit to False on a false comparison, and exception-to-Impossible conversion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cec6cc240a2b0b93ca2d6199.md)

## Rule

- **Rule:**
  ```text
  Node dumping emits 'nodes.<ClassName>(' followed by each field value; list fields are emitted as bracketed comma-separated dumps and non-Node values as repr, and nodes with no fields emit '()'.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying node dumping or the serialized representation of nodes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d29a8b18d459d84b889b3ccb.md)

## Rule

- **Rule:**
  ```text
  args_as_const folds static args and kwargs and converts exceptions from dynamic args/kwargs into Impossible to signal non-constant expressions.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When changing constant folding of call arguments or the Impossible signaling path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d8fcdd10fb566f966ec3455f.md)

## Rule

- **Rule:** NodeType is a metaclass for nodes that handles field and attribute inheritance, automatically forwarding fields and attributes from parent classes to children.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when adding or modifying node classes or their field/attribute inheritance
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e5ada7b92da3d64077bd1e79.md)

## Rule

- **Rule:** When modifying the Neg AST node, preserve that it is a UnaryExpr subclass whose operator attribute is "-", defining negation code generation.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing the Neg node or its operator attribute.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e6cfd4e68dd86b95b3249f3e.md)

## Rule

- **Rule:**
  ```text
  When modifying jinja2.nodes, preserve the extension API protocol: NodeType.__new__ is replaced with a failing staticmethod and the helper is deleted, so creating custom Node subclasses via NodeType is intentionally blocked; extensions must use the provided node classes.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing NodeType or the node class creation mechanism.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fe13d1c5f178fa502dc6b334.md)
