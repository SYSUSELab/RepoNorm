# Constraints for `src/jinja2/meta.py`

## Rule

- **Rule:**
  ```text
  The meta module's writer implements `write` as a no-op ("Don't write."), so meta analysis collects referenced names without emitting output.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:** When modifying meta analysis output or the TrackingCodeGenerator writer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1eb701d9b19b87694e0324e0.md)

## Rule

- **Rule:** TrackingCodeGenerator subclasses CodeGenerator and is documented as abusing the code generator for introspection, indicating meta.py reuses compiler machinery rather than a separate parser.
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:** when modifying meta introspection or TrackingCodeGenerator
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-41ddc70575a921dd49b11afc.md)

## Rule

- **Rule:**
  ```text
  When modifying the undeclared-identifier analysis, preserve enter_frame's exclusion: a symbol is recorded as undeclared only when its load action is resolve and the parameter is not present in environment.globals.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:**
  ```text
  changing how enter_frame decides whether a symbol is undeclared
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-74a369e24bdc588d5c8610a6.md)
