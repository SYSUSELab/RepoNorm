# Constraints for `src/jinja2/loaders.py`

## Rule

- **Rule:** FunctionLoader's callable must return either a template source string, a (source, filename, uptodatefunc) tuple, or None when the template does not exist; uptodatefunc is used when autoreload is enabled.
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** When modifying FunctionLoader's callable contract or the accepted return shapes for template loading.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-14f7c60458a54e9c7cab2a02.md)

## Rule

- **Rule:** ChoiceLoader.load must iterate its loaders and return the first successful load, swallowing TemplateNotFound and raising TemplateNotFound(name) only if all loaders fail.
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** when modifying ChoiceLoader or adding loader fallback behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1589720cbd61859d5e5fab6b.md)

## Rule

- **Rule:**
  ```text
  ModuleLoader.get_module_filename must derive the module filename by appending '.py' to the template key, tying module file naming to the template key scheme.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ModuleLoader.get_module_filename, keep the '.py' suffix appended to the template key.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6fddd0803d050c0fad6865d8.md)

## Rule

- **Rule:**
  ```text
  When modifying the module loader, preserve the import handling contract: derive the module name from package_name and template key, import it, pop the entry from sys.modules after import so only the attribute on the stored module object is retained, and convert ImportError to TemplateNotFound.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** Changing ModuleLoader.load or its import/cleanup behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bf096ab6a27f1b2850968807.md)

## Rule

- **Rule:**
  ```text
  ChoiceLoader.list_templates must aggregate templates from all loaders into a set and return them sorted, so duplicate template names across loaders are deduplicated and output order is deterministic.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ChoiceLoader.list_templates aggregation or template listing order.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c0c438d63b1df7bf5b197e15.md)

## Rule

- **Rule:**
  ```text
  split_template_path rejects any segment containing os.path.sep, os.path.altsep, or equal to os.path.pardir by raising TemplateNotFound, and drops empty and '.' segments; this is the loader path-traversal guard.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** When modifying template path splitting or loader path-traversal protection.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c998648b48193bb9d5d4b197.md)

## Rule

- **Rule:**
  ```text
  ModuleLoader loads precompiled templates and sets has_source_access = False, so it cannot provide template source.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** When modifying ModuleLoader behavior or source-access capability flags on loaders.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-db41781e8c0d5de581c53cd9.md)

## Rule

- **Rule:**
  ```text
  When modifying FunctionLoader.__init__, preserve the load_func contract: store the supplied callable, which must accept a template name and return either a string or a (source, filename, uptodate) tuple.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When changing FunctionLoader initialization or the expected load_func signature/return shape.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e0f2e954b62411e4ff0bc49c.md)

## Rule

- **Rule:**
  ```text
  BaseLoader.list_templates must raise TypeError('this loader cannot iterate over all templates') rather than fail silently, establishing that loaders which cannot enumerate templates must raise TypeError.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying BaseLoader.list_templates or adding a loader that cannot enumerate templates, preserve the TypeError with the 'this loader cannot iterate over all templates' message rather than failing silently.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e877d925788c3fbbcaec7cdb.md)
