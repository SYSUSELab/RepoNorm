# Constraints for `src/jinja2/defaults.py`

## Rule

- **Rule:**
  ```text
  defaults.py defines the default lexer/parser delimiters, whitespace flags, DEFAULT_NAMESPACE globals, and DEFAULT_POLICIES including compiler.ascii_str, urlize.rel, truncate.leeway, and json.dumps_kwargs, which are the baseline values contributors must respect when changing defaults.
  ```
- **Applies to:**
  - `src/jinja2/defaults.py`
- **Condition:** When modifying default configuration values or policies.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ac87391360b160771d349395.md)
