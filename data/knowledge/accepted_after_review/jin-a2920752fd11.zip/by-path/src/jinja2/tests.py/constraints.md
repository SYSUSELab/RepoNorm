# Constraints for `src/jinja2/tests.py`

## Rule

- **Rule:**
  ```text
  The built-in tests registry maps operator aliases such as `==`/`eq`/`equalto`, `!=`/`ne`, `>`/`gt`/`greaterthan`, `>=`/`ge`, `<`/`lt`/`lessthan`, and `<=`/`le` to the same operator functions, and notes that the existing `number` test matches booleans.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** When modifying the built-in tests registry or operator alias mappings.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5f3481e07352e8959442b881.md)

## Rule

- **Rule:**
  ```text
  When modifying the number test, preserve test_number's use of isinstance(value, Number) so numeric test behavior follows the numbers.Number ABC rather than a concrete numeric type.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  changing the type check used by test_number
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-996d5b169aa44d33e48ab037.md)

## Rule

- **Rule:** When modifying the 'defined' test, preserve the contract that it returns not isinstance(value, Undefined), so any Undefined subclass instance is treated as undefined.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** When changing or extending the 'defined' test's undefined-value detection.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d0d9296b19168b7a8c166828.md)

## Rule

- **Rule:**
  ```text
  When modifying test_test, preserve the membership check against env.tests so templates can conditionally use optional tests by name.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  When changing the test_test function or the environment tests registry lookup.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fc3a4825135a23a2e0ada3fb.md)
