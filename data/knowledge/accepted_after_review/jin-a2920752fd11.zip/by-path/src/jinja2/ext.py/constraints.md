# Constraints for `src/jinja2/ext.py`

## Rule

- **Rule:**
  ```text
  When modifying the gettext alias, preserve its pass_context behavior: it resolves and calls the gettext callable from the context, forwarding args and kwargs.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Changing the gettext alias or its context-based callable resolution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2bab9a8a977119efe12c7bc1.md)

## Rule

- **Rule:** The i18n extension exposes pgettext(context, message) as part of its gettext-style API surface, indicating context-aware translation support.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** When modifying the i18n extension's translation API surface.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4fb14a7f39f7f1a6b3ed0f16.md)

## Rule

- **Rule:** When modifying the extension protocol, keep extensions exposing a tags set of tag names they handle, as ExprStmtExtension does with tags = {"do"} to register the do tag.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Changing the extension protocol or tag registration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6aa6feaa9f05e7a993ed2ac2.md)

## Rule

- **Rule:**
  ```text
  When modifying DebugExtension._render or its callers, preserve the debug output format: the result contains context, sorted filter names, and sorted test names, formatted with pprint.pformat(depth=3, compact=True).
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  Editing DebugExtension._render or code that relies on its output format in src/jinja2/ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7e76575f0b2e04e671b54148.md)

## Rule

- **Rule:**
  ```text
  When modifying _CommentFinder or its callers, preserve the forward-only comment association constraint: comments can only be found for gettext calls forwards, so once a comment for a later line is found, an earlier line's comment will not return a usable value.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  Editing _CommentFinder or code that relies on comment association order in src/jinja2/ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8d21a532b53a6182d40c8723.md)

## Rule

- **Rule:**
  ```text
  When modifying comment extraction, keep find_backwards scanning tokens in reverse between the current offset and the target offset, accepting only comment tokens whose first whitespace-separated prefix is in comment_tags, and always restoring self.offset to the requested offset in a finally block.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  Changing _CommentFinder.find_backwards or comment tag extraction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9466055c46db730b42513193.md)

## Rule

- **Rule:**
  ```text
  When modifying the extension token-stream initializer, preserve that it stores tokens and comment_tags and initializes offset=0 and last_lineno=0 as the mutable cursor state used while parsing extension tokens.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Changing the extension token-stream initializer or its cursor state initialization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a39d059ec6b67086a14ec9ee.md)

## Rule

- **Rule:**
  ```text
  extract_from_ast must yield (lineno, function, message) tuples; with babel_style=True non-string args and kwargs become None placeholders (single string collapses to a scalar, multiple to a tuple), while babel_style=False keeps only strings in a tuple and skips calls with no string argument.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When modifying extract_from_ast or the i18n extraction logic, preserve the (lineno, function, message) tuple shape and the babel_style-dependent handling of non-string args and kwargs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a928a8fa9ff69f2228772a70.md)

## Rule

- **Rule:**
  ```text
  When modifying the ngettext wrapper factory, preserve _make_new_ngettext's adaptation: it wraps a (str, str, int) -> str callable and returns an ngettext callable rather than calling the pluralization function directly.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  changing how _make_new_ngettext adapts pluralization callables
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ee120eba49e74750f69ecc76.md)
