# Constraints for `src/jinja2/filters.py`

## Rule

- **Rule:**
  ```text
  When case_sensitive is false, do_groupby must group by a lowercased key while recomputing the returned _GroupTuple key from the first value with a non-lowercasing attrgetter, preserving the original key casing.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_groupby's case-insensitive grouping path, keep the grouping key lowercased but the returned group key in its original casing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1802a41bd913b4cb48087d9c.md)

## Rule

- **Rule:**
  ```text
  When modifying the attribute filter, preserve _prepare_attribute_parts normalization: None yields an empty part list, string attributes are split on '.' with digit segments converted to int, and non-string attributes are wrapped as a single-element list.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** changing how dotted attribute paths are parsed or normalized in the attribute filter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-239c923dabe5819d88b8d958.md)

## Rule

- **Rule:**
  ```text
  do_wordwrap must wrap each line separately (splitting on existing newlines) because textwrap.wrap ignores existing newlines, and must default wrapstring to environment.newline_sequence.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_wordwrap, preserve per-line wrapping on existing newlines and the default wrapstring of environment.newline_sequence.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-39a44cb080e34d505234e69b.md)

## Rule

- **Rule:** The last filter must not be applied to generators and returns Undefined when the sequence is empty, so callers must materialize generators before applying it.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When modifying the last filter or its handling of generators and empty sequences.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-40514e15af438f97da126850.md)

## Rule

- **Rule:**
  ```text
  When modifying do_mark_safe, preserve the safety mechanism: the value is wrapped in Markup so autoescape-enabled environments do not escape it.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing do_mark_safe or its Markup wrapping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4204a58ae69803e6131a4840.md)

## Rule

- **Rule:**
  ```text
  do_int parses str with the given base, otherwise int(value); on TypeError/ValueError it falls back to int(float(value)) so that '42.23'|int yields 42, and returns the default only if that also fails.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When modifying the int filter conversion logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4caf73d3fcbda6b45c35df0e.md)

## Rule

- **Rule:**
  ```text
  When modifying the striptags filter, preserve the __html__ protocol check: do_striptags must consult __html__ on the value and use its result before stripping tags via Markup.striptags.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  changing how do_striptags handles objects implementing __html__
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4ff3e0e458ff4f2de359bfd7.md)

## Rule

- **Rule:**
  ```text
  sync_do_selectattr must be a thin pass_context wrapper that delegates to select_or_reject with lambda x: x and True, so attribute selection semantics are centralized in select_or_reject rather than in the filter itself.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying attribute selection filters or the select_or_reject delegation pattern.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-552d590f7ddbb11ed5db3a83.md)

## Rule

- **Rule:**
  ```text
  When modifying prepare_map, preserve the filter-argument protocol: accept either an 'attribute' keyword (with optional 'default') or a positional filter name; supplying extra keyword arguments alongside 'attribute' raises FilterArgumentError, and missing a filter argument raises FilterArgumentError('map requires a filter argument').
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing prepare_map or its argument validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-587eef8eb1c0e364f12cdc76.md)

## Rule

- **Rule:**
  ```text
  do_unique yields items in first-occurrence order and uses make_attrgetter with ignore_case postprocessing when case_sensitive is false, so uniqueness keys are case-folded by default.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When modifying the unique filter's ordering or case sensitivity behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-59d2026c7ff73617fa241142.md)

## Rule

- **Rule:**
  ```text
  do_reverse must be declared with a typing.overload returning t.Iterable[V], indicating the filter is typed to preserve the element type of the input iterable.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When modifying the reverse filter's typing or overload declarations.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7167fcef1df1f926b97f72e9.md)

## Rule

- **Rule:**
  ```text
  When modifying the async do_slice variant, preserve the requirement that it awaits auto_to_list(value) before delegating to the sync slicing implementation, so async iterables are materialized before slicing.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing the async do_slice variant or its materialization of async iterables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7a8365dd59665f94236ad22a.md)

## Rule

- **Rule:**
  ```text
  When modifying multi-attribute getter construction, preserve the contract that make_multi_attrgetter splits a comma-separated attribute string, prepares each part, and returns a callable producing a list of extracted values, where dots access nested attributes and integer parts are looked up as integers.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When changing or extending how multi-attribute getters parse and extract attribute values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7c73ff121e28bfbc0eeda223.md)

## Rule

- **Rule:** When modifying rejectattr, preserve the contract that it is the negation of selectattr: it keeps objects for which the named attribute test does not succeed, and with no test the attribute value is evaluated as a boolean.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When changing or extending the rejectattr filter's selection behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-82a8e7bdfb5d338c2241ec36.md)

## Rule

- **Rule:**
  ```text
  sync_do_sum and its async variant do_sum must share identical attribute/start semantics: when attribute is not None, map make_attrgetter over the iterable; return sum(iterable, start) so an empty sequence yields start.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying sync_do_sum or do_sum (e.g. changing attribute handling or the start default), keep the sync and async implementations semantically aligned.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-887a7cee57e3b3450214a032.md)

## Rule

- **Rule:**
  ```text
  When modifying the sort filter, preserve stable sorting and support for reverse, case_sensitive, and attribute (including comma-separated multi-attribute lists and dot notation), with make_multi_attrgetter applying ignore_case when not case-sensitive.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing do_sort or sort filter attribute handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8ce4dba47c6b12788875d889.md)

## Rule

- **Rule:**
  ```text
  do_rejectattr is an async variant of sync_do_rejectattr that delegates to async_select_or_reject with lambda x: not x and True, encoding the reject-vs-select distinction as a predicate inversion flag.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When modifying rejectattr/selectattr filters or their async variants.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a5238d119676ab2fdd7887ea.md)

## Rule

- **Rule:**
  ```text
  When modifying do_forceescape or its callers, preserve the behavior that objects implementing __html__ are coerced via __html__() before escaping, which can double-escape values that already provide HTML markup.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Editing do_forceescape or code that relies on its escaping behavior in src/jinja2/filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b8021c9e7fce49edfddbb115.md)

## Rule

- **Rule:**
  ```text
  When modifying the slice filter, preserve the partitioning contract that sync_do_slice splits a collection into the requested number of slices, distributing remainder items to earlier slices and appending fill_with to later slices when provided.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When changing or extending the slice filter's partitioning behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c31f3c3710375cee0db61276.md)

## Rule

- **Rule:**
  ```text
  do_items returns an empty iterator for Undefined input, raises TypeError for non-Mapping input, and otherwise yields value.items(), defining the items filter's compatibility behavior for undefined and non-mapping values.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When modifying the items filter or its handling of undefined and non-mapping inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c359913dbc272ac276b35f42.md)

## Rule

- **Rule:**
  ```text
  When modifying do_urlencode, preserve the two-mode quoting behavior: plain strings are quoted directly without quoting '/', while dicts or iterables of pairs are joined as a query string with both keys and values quoted for query-string use.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When changing the urlencode filter's handling of strings versus mappings/iterables of pairs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d564249bc3b92d5fa93c71e9.md)

## Rule

- **Rule:**
  ```text
  _min_or_max must return environment.undefined('No aggregated item, sequence was empty.') for empty input so min/max on empty sequences yield Undefined rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when modifying min/max filter aggregation or empty-sequence handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-df8fee586376a0e6e1f8d39a.md)

## Rule

- **Rule:**
  ```text
  When modifying the indent filter, preserve do_indent semantics: accept int or string width, preserve Markup types for indention and newline, do not indent blank lines unless blank=True, and only indent the first line when first=True.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  changing do_indent's width handling, blank-line behavior, or first-line-only behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e31417044e7bee0a30a745ef.md)

## Rule

- **Rule:**
  ```text
  When modifying do_map, preserve the dual sync/async input contract: the function must keep typing.overload declarations that accept either a synchronous iterable or an asynchronous iterable and return an iterable, so callers relying on either input form continue to type-check.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When changing the signature, overloads, or return typing of do_map.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f68727212a5e610028e70e27.md)

## Rule

- **Rule:** When modifying the HasHTML protocol, preserve its structural typing contract for HTML-like objects as declared inside filters.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** changing the HasHTML protocol declaration or its structural typing contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f99c9a3895a5e5e42b44841d.md)
