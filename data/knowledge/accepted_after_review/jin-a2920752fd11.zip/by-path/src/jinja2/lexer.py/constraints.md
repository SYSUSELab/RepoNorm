# Constraints for `src/jinja2/lexer.py`

## Rule

- **Rule:** When modifying TokenStreamIterator, preserve its termination contract: iteration continues until the eof token is reached.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** changing TokenStreamIterator's iteration termination logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-29d01ca64019d2f93313e7d2.md)

## Rule

- **Rule:**
  ```text
  When modifying TokenStreamIterator.__init__, preserve the stream attribute contract: store the TokenStream on self.stream so token iteration can rely on that attribute.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When changing TokenStreamIterator initialization or token iteration state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-47e568c853b408fa8da2e4e8.md)

## Rule

- **Rule:** Token type constants are interned strings, so token type comparisons may rely on identity rather than string equality; changes that replace interned token-type constants with non-interned strings would break identity-based comparisons.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When modifying token type constants or token type comparison logic in the lexer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-50664151d15a9a667e8b35cb.md)

## Rule

- **Rule:** TokenStream must be documented as an iterable yielding Tokens, but the parser must not iterate it; instead it calls next() to advance one token ahead, with the active token stored as current.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When modifying TokenStream or the parser's token consumption, preserve the next()-based one-token-ahead advancement with the active token stored as current rather than iterating the stream.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e8e896c712d57a7bbc454af.md)

## Rule

- **Rule:**
  ```text
  TokenStream.__next__ returns the previous current token and advances via a pushed deque or the underlying iterator, closing the stream on StopIteration; callers are directed to use built-in next rather than calling it directly.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When modifying TokenStream iteration or token advancement logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7fed0e41583eea603eec51da.md)

## Rule

- **Rule:**
  ```text
  When modifying TokenStream.__bool__ or code that tests a TokenStream for truthiness, preserve the semantics that truthiness reflects remaining unprocessed tokens: True if any tokens are pushed back or the current token is not TOKEN_EOF.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  Editing TokenStream.__bool__ or code that relies on TokenStream truthiness in src/jinja2/lexer.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8a70cab0a301c72e94133270.md)

## Rule

- **Rule:** When modifying the lexer's operator table, preserve the bijective mapping between operator strings and tokens; the module asserts uniqueness so any edit that maps two operator strings to the same token will fail at import time.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** Editing or extending the lexer operator table in src/jinja2/lexer.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a5670037fa45926f6d9c3c2b.md)

## Rule

- **Rule:**
  ```text
  Lexer rules are represented as a _Rule NamedTuple with pattern, tokens (string, tuple of strings, or tuple of Failure), and an optional command; the Failure token type encodes lexer error states within the same rule structure.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** when adding or modifying lexer rules or their token specifications
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b89d990b9e8bfef0e226121d.md)

## Rule

- **Rule:**
  ```text
  TokenStream.next_if performs a token test against the current token and returns the next token if it matches, otherwise returns None without consuming input.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When modifying token lookahead helpers or token stream consumption behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bbb1cbe703973cb199e096d1.md)

## Rule

- **Rule:** TokenStream.eos is defined as the negation of the stream's truthiness, so eos is true exactly when the stream is exhausted.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** when modifying TokenStream exhaustion checks or the eos property
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c249b044c77a6a47cb90d6ad.md)

## Rule

- **Rule:** When modifying the Token representation, preserve the NamedTuple fields lineno, type, and value, which form the stable token representation consumed by the parser and lexer.
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When changing the Token class definition or its field names/order.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ced48dffb484b031918690d1.md)
