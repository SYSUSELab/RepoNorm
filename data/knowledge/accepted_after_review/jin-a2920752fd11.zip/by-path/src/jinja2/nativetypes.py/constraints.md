# Constraints for `src/jinja2/nativetypes.py`

## Rule

- **Rule:**
  ```text
  NativeEnvironment extends Environment and sets code_generator_class to NativeCodeGenerator and concat to staticmethod(native_concat), defining how native-type rendering is wired into the environment.
  ```
- **Applies to:**
  - `src/jinja2/nativetypes.py`
- **Condition:** When modifying NativeEnvironment configuration or native-type rendering wiring.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a20732ab7179c3b4b0db115e.md)

## Rule

- **Rule:**
  ```text
  native_concat returns None for empty input, returns a single non-str node value directly, otherwise joins values as strings and attempts ast.literal_eval via parse(raw, mode="eval") to preserve leading spaces/tabs for Python 3.10+ compatibility, falling back to the raw string on ValueError, SyntaxError, or MemoryError.
  ```
- **Applies to:**
  - `src/jinja2/nativetypes.py`
- **Condition:**
  ```text
  when modifying native_concat or native template value concatenation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d53a0ca933c1156576874d33.md)
