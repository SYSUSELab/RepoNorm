# Constraints for `src/jinja2/bccache.py`

## Rule

- **Rule:**
  ```text
  When modifying _MemcachedClient.set or its callers, preserve the interface contract: the method accepts key, value, and optional timeout, and remains a stub for bytecode cache implementations.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  Editing _MemcachedClient.set or code that relies on its interface in src/jinja2/bccache.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2ff9d78570373553e077b140.md)

## Rule

- **Rule:**
  ```text
  MemcachedBytecodeCache accepts any client providing set(key, value[, timeout]) and get(key) returning None on miss; it does not support clearing (clear is a no-op), and ignore_memcache_errors was added in 2.7.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying or substituting the memcache client used by MemcachedBytecodeCache
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-492c6c1a64e251dccf4235e0.md)

## Rule

- **Rule:**
  ```text
  BytecodeCache.dump_bytecode must remain an abstract method that subclasses override to write a bucket's bytecode back to the cache, and it must raise an exception rather than fail silently when unable to do so.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  When modifying BytecodeCache.dump_bytecode or its subclasses, keep it abstract and ensure failures raise an exception rather than failing silently.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5f24dafaa42ca9cad8014b0a.md)

## Rule

- **Rule:** Bucket stores bytecode for one template and receives an internal checksum from the cache, which is used to automatically reject outdated cache material so individual bytecode cache subclasses need not handle cache invalidation.
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying bytecode cache storage or cache invalidation behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-939a17ad75f2c92457d6eec1.md)

## Rule

- **Rule:**
  ```text
  BytecodeCache.get_cache_key must compute a SHA-1 hex digest of the UTF-8 encoded template name, appending '|filename' when a filename is provided, defining the cache key format.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  When modifying BytecodeCache.get_cache_key, keep the SHA-1 hex digest of the UTF-8 encoded template name and the '|filename' suffix when a filename is provided.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b3faf0dc80e48a488956838b.md)

## Rule

- **Rule:**
  ```text
  When modifying Bucket.write_bytecode, preserve the on-disk bytecode format: raise TypeError('can't write empty bucket') when code is None, otherwise write bc_magic, pickle the checksum with protocol 2, and marshal the code.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When changing how bytecode buckets are serialized to disk or how empty buckets are handled.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-edf3d2177ea473b8d38e3611.md)

## Rule

- **Rule:**
  ```text
  When modifying the bytecode cache Bucket, preserve the construction protocol: __init__ stores environment, key, and checksum and then calls reset(), so subclasses that override reset() must remain compatible with being invoked during construction.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  Changing Bucket.__init__ or overriding reset() in a Bucket subclass.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-faeb1d9ea196ed6640ccff53.md)
