# Constraints for `src/jinja2`

## Rule

- **Rule:**
  ```text
  mypy is configured with warn_unused_configs = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2d3562fe997ee7800c8e44e4.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with warn_unused_ignores = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4ade39d510dbc3a4f095bc96.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with disallow_untyped_calls = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-527de683463d42de1024fad9.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with warn_redundant_casts = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-64c437d8be6b5805467100db.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with strict_equality = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6f418dfe852acdc7fdbc8f48.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with disallow_incomplete_defs = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9d2223aa2b4024180461dfe3.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with local_partial_types = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9dc9851c3d7b50afecb23dee.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with show_error_codes = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a48ea42fc152a2282d84f6bb.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with no_implicit_reexport = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bc81711c7c48c47dd8f46721.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with no_implicit_optional = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ca2d8fe0a77d649f0fa0fd16.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with warn_return_any = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d2fa663eee283300ad977e66.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with python_version = 3.7.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d6a8d88cf8768ca8e2c4f038.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with warn_unreachable = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e3c4af2e8f2dbddf927cdadb.md)

## Rule

- **Rule:** mypy is configured to check the files under src/jinja2.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eda4d85facea218b20faab1e.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with disallow_subclassing_any = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fa2fb9dc4df2c0e247c7249a.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with disallow_untyped_defs = True.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fa38c16c32e993d445a3a65a.md)
