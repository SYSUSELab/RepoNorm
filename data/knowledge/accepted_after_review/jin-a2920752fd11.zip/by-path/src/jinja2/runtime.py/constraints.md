# Constraints for `src/jinja2/runtime.py`

## Rule

- **Rule:** When modifying the Macro runtime wrapper, preserve its documented contract of wrapping a macro function as the runtime wrapper for macro callables.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing the Macro runtime wrapper or its wrapping contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-13cf307a21c3452c8f547d9a.md)

## Rule

- **Rule:** LoopContext.last must peek the next item and compare to missing, which advances the iterable early; contributors must preserve the documented itertools.groupby-style caveat and the groupby filter workaround.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when modifying LoopContext.last or loop iteration helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1ac9aa2a81badcc77fdca0a0.md)

## Rule

- **Rule:** When modifying LoopContext.previtem, preserve the first-iteration boundary: it returns an Undefined with the message "there is no previous item" during the first iteration and otherwise returns the previous item.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing LoopContext.previtem behavior or its first-iteration handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-213b36ce0785aea889c1b966.md)

## Rule

- **Rule:**
  ```text
  LoopContext._to_iterator must remain a static hook that simply returns iter(iterable), providing an override point for custom iteration behavior.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying LoopContext._to_iterator or the loop iteration logic, preserve the static hook that returns iter(iterable) as an override point.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3c35d604b6575ddf5139fc3b.md)

## Rule

- **Rule:**
  ```text
  When modifying Context.get, preserve the runtime API contract: return the provided default when the key is missing rather than raising, distinguishing it from __getitem__ which propagates KeyError.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing Context.get or its missing-key behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-48c38d6c3a410ab06a387dca.md)

## Rule

- **Rule:**
  ```text
  When modifying template context construction, preserve the shared-flag branching in new_context: a shared parent is the vars dict itself, a non-shared parent is a new dict merging globals and vars, and applying locals to a shared parent must first copy parent to avoid mutating the caller's dict.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  Changing new_context parent mapping construction or locals application.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-566bdaa95126872e7cb0e180.md)

## Rule

- **Rule:** When modifying loop iteration behavior, keep nextitem returning Undefined during the last iteration and preserve the documented early-advance behavior that affects constructs such as groupby.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing LoopContext.nextitem or loop iteration semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-64f1ce67e89dfe3caaa391cd.md)

## Rule

- **Rule:**
  ```text
  When modifying LoopContext.length, preserve the length semantics: return cached _length if set; otherwise try len(self._iterable), and on TypeError eagerly consume the iterator into a list, reset the iterator, and compute length as len(iterable) + index + (1 if _after is not missing else 0).
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When changing LoopContext.length or its interaction with loop state and generator iterables.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6863ad527cd8e0298929b065.md)

## Rule

- **Rule:**
  ```text
  When modifying Context.derived, preserve the derivation semantics: create a new independent context via new_context with the same environment/name and get_all(), copy eval_ctx, and copy blocks as lists, so derived contexts share blocks but are otherwise independent.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When changing Context.derived or how derived contexts share or copy state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9bdc3119727cabc770f8ef6f.md)

## Rule

- **Rule:**
  ```text
  The runtime object's __repr__ must format as <ClassName 'context.name'>, using the context name in the representation.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When modifying the runtime object representation or its context-name formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9dc5f9f5aa00dc0936976fe4.md)

## Rule

- **Rule:**
  ```text
  When modifying LoopContext, preserve the initialization contract: index0 starts at -1, _after, _current, _before, and _last_changed_value use a sentinel missing value, and _length defaults to None.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing LoopContext initialization or its sentinel/default values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa400ab17939edb6e323e777.md)

## Rule

- **Rule:** When modifying LoopContext, preserve the public index invariant: index is defined as index0 + 1, so index is 1-based while index0 remains 0-based.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** changing LoopContext.index or index0 definitions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ca7176c4d7182dd57917f576.md)

## Rule

- **Rule:**
  ```text
  When modifying Macro._invoke, preserve the async/autoescape dispatch contract: dispatch to _async_invoke when the environment is async, otherwise call the function directly and wrap the result in Markup when autoescape is enabled.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  Changing Macro._invoke or its async/autoescape dispatch.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-db627aa006fcbefb757f187b.md)
