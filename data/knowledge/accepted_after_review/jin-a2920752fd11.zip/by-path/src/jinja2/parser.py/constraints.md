# Constraints for `src/jinja2/parser.py`

## Rule

- **Rule:**
  ```text
  The parser defines _statement_keywords as a frozenset of the twelve statement keywords (for, if, block, extends, print, macro, include, from, import, set, with, autoescape) and _compare_operators as a frozenset of eq/ne/lt/lteq/gt/gteq, so adding a statement keyword or comparison alias requires updating these sets.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** When adding or modifying statement keywords or comparison operators in the parser.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0795c2d345c31b90518c7304.md)
