# Constraints for `src/jinja2/environment.py`

## Rule

- **Rule:** Template objects are immutable; modifications are unsupported, and templates created directly share an ephemeral Environment instance when given the same environment arguments.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** When modifying Template construction or environment sharing behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-07697c746599cc4ed8901b53.md)

## Rule

- **Rule:**
  ```text
  When modifying TemplateModule.__html__, preserve the contract that it returns Markup(concat(self._body_stream)), so the object's HTML representation is the concatenation of its body stream wrapped as Markup.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When changing or extending TemplateModule.__html__'s HTML representation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-10ec4c63b76454b2efc1646f.md)

## Rule

- **Rule:**
  ```text
  make_module_async must be used instead of make_module for asynchronous execution because module creation can invoke template code; in async mode the module attribute becomes unavailable.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** When adding or modifying asynchronous template module creation or the module attribute.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-258cfc142fbce23d3d3603b6.md)

## Rule

- **Rule:**
  ```text
  When modifying Template.render or its async bridging, preserve the behavior that an async environment runs render_async via asyncio and creates and closes a new event loop only when no running loop exists.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** Editing Template.render or its async bridging logic in src/jinja2/environment.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-53a83b993f14f7fb64f0a434.md)

## Rule

- **Rule:**
  ```text
  When modifying Template.new_context, preserve the contract that it delegates to the module-level new_context with the template's environment, name, blocks, vars, shared flag, globals, and locals, and that when shared is True the provided vars are passed without adding globals.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When changing or extending Template.new_context's delegation to the module-level new_context.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9569dd416b494b7a10cc828f.md)

## Rule

- **Rule:**
  ```text
  When modifying TemplateExpression.__call__ or its callers, preserve the behavior that the callable reads context.vars["result"] after consuming the root render function and converts Undefined to None only when _undefined_to_none is set; callers must handle Undefined results when that flag is disabled.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  Editing TemplateExpression.__call__ or code that depends on its Undefined handling in src/jinja2/environment.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-960afc3879b678631b6dd100.md)

## Rule

- **Rule:** Template.module exposes the template as a TemplateModule for imports and Python-level access to exported variables, but the attribute is not available when async mode is enabled.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** When modifying Template.module or async mode behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa8afe0b3a6388d9556146d9.md)

## Rule

- **Rule:**
  ```text
  get_spontaneous_environment is lru_cache(maxsize=10) keyed on cls and args, and marks the created environment with shared=True so spontaneous environments are reused rather than freshly constructed per template.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** When modifying spontaneous environment creation or caching behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b0a4a3699ac8f55d79960a05.md)

## Rule

- **Rule:**
  ```text
  Template.from_module_dict must remain a classmethod that constructs a Template from a module dict and globals by delegating to _from_namespace, as the documented entry point used by the module loader.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when modifying Template construction from compiled module dicts or the module loader path
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b5db76087513f61cffdb99f8.md)

## Rule

- **Rule:** When modifying TemplateModule, preserve its module-like API: exported names are attributes and converting the module to a string renders the template contents.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** changing TemplateModule's attribute export or string conversion behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-becc99568cb90a46fe10308b.md)

## Rule

- **Rule:**
  ```text
  When modifying template construction from compiled code, preserve Template.from_code's namespace contract: execute compiled code in a namespace seeded with 'environment' and '__file__' set to code.co_filename, then construct via _from_namespace and assign _uptodate, including the optional uptodate callback assignment.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  Changing Template.from_code or template construction from compiled code.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c388cdc874f4bdbed1a2556b.md)

## Rule

- **Rule:**
  ```text
  TemplateExpression is the object returned by Environment.compile_expression, encapsulating expression-like access to a template; this is a public API contract contributors must preserve.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Environment.compile_expression or the TemplateExpression return type
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-db0c51bcac4baadff4031a88.md)

## Rule

- **Rule:**
  ```text
  When modifying create_cache or its callers, preserve the size semantics: size 0 returns None, negative size returns an unbounded dict, and any other size returns an LRUCache(size).
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  Editing create_cache or code that depends on its size-based cache selection in src/jinja2/environment.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e019fd37bca162f7a8adfc65.md)

## Rule

- **Rule:** When modifying TemplateStream.dump, preserve the API contract: accept a path string or file-like object; when given a path, default encoding to utf-8, open the file in binary mode, and close it afterward.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** Changing TemplateStream.dump or its path/file-like handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e12d093bf6ab633c5cedb4a0.md)

## Rule

- **Rule:**
  ```text
  When modifying the default template class binding, preserve that Environment.template_class is assigned to Template at import time and remains user-overridable.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** Changing the default template class binding or its import-time assignment.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f71be49ed05751c3187ccb97.md)
