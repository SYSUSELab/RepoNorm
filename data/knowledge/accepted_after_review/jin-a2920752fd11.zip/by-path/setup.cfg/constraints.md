# Constraints for `setup.cfg`

## Rule

- **Rule:**
  ```text
  The babel.extractors entry point registers the jinja2 extractor as jinja2.ext:babel_extract[i18n].
  ```
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8f7a8501542d9b71616e99e1.md)
