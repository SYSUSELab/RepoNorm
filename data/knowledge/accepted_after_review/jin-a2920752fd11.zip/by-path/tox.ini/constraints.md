# Constraints for `tox.ini`

## Rule

- **Rule:** The tox envlist defines environments py311, py310, py39, py38, py37, pypy38, pypy37, style, typing, and docs.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-009b3b6f88866be1ab531e0d.md)

## Rule

- **Rule:** tox skips missing interpreters instead of failing when an interpreter is unavailable.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-24ce76a614d51f32e70ea63e.md)
