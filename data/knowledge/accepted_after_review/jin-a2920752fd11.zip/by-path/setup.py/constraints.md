# Constraints for `setup.py`

## Rule

- **Rule:**
  ```text
  Keep setup.py's install_requires and extras declarations consistent with the authoritative metadata in setup.cfg; setup.py entries exist only to feed GitHub's dependency graph and must not diverge from setup.cfg.
  ```
- **Applies to:**
  - `setup.py`
- **Condition:** When editing dependency declarations in setup.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-debc912f39400b889ba693d9.md)
