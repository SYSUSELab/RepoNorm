# Claim catalog

- [Rules 1–73](catalog/0001.md); scope preview: `tests/test_ext.py`
- [Rules 74–145](catalog/0002.md); scope preview: `src/jinja2/visitor.py`
- [Rules 146–217](catalog/0003.md); scope preview: `**`
- [Rules 218–288](catalog/0004.md); scope preview: `src/jinja2/filters.py`
- [Rules 289–360](catalog/0005.md); scope preview: `tests/test_lexnparse.py`
- [Rules 361–434](catalog/0006.md); scope preview: `tests/test_regression.py`
- [Rules 435–474](catalog/0007.md); scope preview: `src/jinja2/nodes.py`
