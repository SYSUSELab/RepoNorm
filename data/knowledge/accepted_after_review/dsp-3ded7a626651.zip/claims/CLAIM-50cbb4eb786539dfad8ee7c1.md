# Rule details

- **Rule:** When the CI build check fails, review changes and ensure the documentation builds correctly locally before pushing updates.
- **Applies to:**
  - `docs/**`
- **Condition:** CI build check fails
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
If the CI build check fails, please review your changes and ensure the documentation builds correctly locally before pushing updates.

```

- **Sources:**
  - `docs/README.md:65`

## Review evidence locations

- `docs/README.md:57-65`
