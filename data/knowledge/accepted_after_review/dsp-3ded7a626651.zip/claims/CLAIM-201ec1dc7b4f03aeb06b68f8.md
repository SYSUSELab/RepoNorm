# Rule details

- **Rule:**
  ```text
  GroundedProposer.propose_instruction_for_predictor must accept demo_candidates as optional (None or nested example lists) without changing its return type.
  ```
- **Applies to:**
  - `tests/propose/test_grounded_proposer.py`
- **Condition:**
  ```text
  When modifying propose_instruction_for_predictor or its test, keep demo_candidates optional and preserve the model-proposed instruction string return.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_propose_instruction_for_predictor parametrizes demo_candidates as None and nested example lists and asserts the returned instruction string.
```

- **Sources:**
  - `tests/propose/test_grounded_proposer.py:39-54`
