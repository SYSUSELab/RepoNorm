# Rule details

- **Rule:**
  ```text
  When changing API docs generation, preserve the recursive submodule documentation behavior: skip excluded modules, tolerate ImportError by printing and returning, skip non-module objects not in the API mapping, and only document objects not already in objects_processed before recursing into submodules.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying generate_md_docs_submodule or the recursive submodule documentation logic.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_docs.py:246-289`
