# Rule details

- **Rule:** PDF signature tests must declare a dspy.Image input field to carry PDF document inputs.
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** Modifying PDF signature tests or the field type used to carry PDF inputs.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/signatures/test_adapter_image.py:349-355`
