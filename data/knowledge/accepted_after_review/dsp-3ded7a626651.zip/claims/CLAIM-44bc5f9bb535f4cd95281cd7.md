# Rule details

- **Rule:**
  ```text
  The MCP test server must define an Account model whose profile field is a nested Profile model and account_id is a string, establishing the expected nested-object shape for MCP tool responses in tests.
  ```
- **Applies to:**
  - `tests/utils/resources/mcp_server.py`
- **Condition:** When modifying MCP test server models or nested-object response shapes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/resources/mcp_server.py:7-14`
- `tests/utils/resources/mcp_server.py:35-38`
