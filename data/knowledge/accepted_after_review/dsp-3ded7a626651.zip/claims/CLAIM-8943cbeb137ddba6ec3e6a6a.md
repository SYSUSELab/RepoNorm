# Rule details

- **Rule:**
  ```text
  The autouse configure_model fixture must read reliability_conf.yaml, configure dspy with the model's LM params and adapter, skip tests when no YAML config exists for the model, and store should_ignore_failure and model_name on the request node.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** When adding or modifying reliability tests that depend on model configuration or known-failing model handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/conftest.py:41-66`
