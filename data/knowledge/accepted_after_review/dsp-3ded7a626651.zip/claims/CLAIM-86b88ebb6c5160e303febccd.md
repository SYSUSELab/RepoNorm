# Rule details

- **Rule:**
  ```text
  The workflow builds the dspy-ai binary wheel by running `python3 -m build ./dspy/.internal_dspyai/`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Build a binary wheel (dspy-ai)
        run: python3 -m build ./dspy/.internal_dspyai/

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:119-120`
