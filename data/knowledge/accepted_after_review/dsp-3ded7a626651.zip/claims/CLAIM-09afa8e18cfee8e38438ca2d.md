# Rule details

- **Rule:**
  ```text
  When modifying parse_integer_answer in dspy/datasets/gsm8k.py, preserve the silent-fallback contract: take the last whitespace token containing a digit, strip decimals and non-digits, and return 0 on ValueError/IndexError instead of raising.
  ```
- **Applies to:**
  - `dspy/datasets/gsm8k.py`
- **Condition:**
  ```text
  When changing answer extraction or error handling in parse_integer_answer.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
parse_integer_answer selects the last whitespace token containing a digit, strips decimals and non-digits, and returns 0 on ValueError/IndexError, preserving the silent-fallback contract.
```

- **Sources:**
  - `dspy/datasets/gsm8k.py:62-76`
