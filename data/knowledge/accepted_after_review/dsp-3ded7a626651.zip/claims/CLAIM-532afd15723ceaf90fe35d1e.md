# Rule details

- **Rule:**
  ```text
  `DataLoader.from_rm` raises `ValueError` with distinct messages when the retrieval module lacks `get_objects` (`AttributeError`) versus when no retrieval module is configured, so callers can distinguish misconfiguration from unsupported RM.
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  When modifying `DataLoader.from_rm` error handling, preserve distinct `ValueError` messages for missing `get_objects` versus missing retrieval module.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/datasets/dataloader.py:121-136`
