# Rule details

- **Rule:**
  ```text
  When a contributor modifies gsm8k_metric, it must compare gold and pred answers by parsing integer answers from str(gold.answer) and str(pred.answer), so GSM8K evaluation depends on answer fields being integer-parseable strings.
  ```
- **Applies to:**
  - `dspy/datasets/gsm8k.py`
- **Condition:**
  ```text
  Modifying gsm8k_metric or adding a new GSM8K-style metric that parses numeric answers.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
gsm8k_metric parses integer answers from str(gold.answer) and str(pred.answer) for comparison, preserving the integer-parse contract.
```

- **Sources:**
  - `dspy/datasets/gsm8k.py:79-80`
