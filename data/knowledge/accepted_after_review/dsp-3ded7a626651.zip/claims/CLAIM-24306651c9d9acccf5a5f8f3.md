# Rule details

- **Rule:**
  ```text
  The tests/conftest.py pytest_collection_modifyitems hook must skip tests marked with any flag in SKIP_DEFAULT_FLAGS unless the corresponding --<flag> command-line option is provided, and must return early once any such option is present.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When adding or modifying default-skip flags or the collection-modification hook in the test suite conftest.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/conftest.py:43-51`
