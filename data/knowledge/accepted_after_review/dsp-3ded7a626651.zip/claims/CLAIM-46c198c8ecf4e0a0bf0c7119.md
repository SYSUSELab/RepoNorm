# Rule details

- **Rule:**
  ```text
  Typed signature annotations must preserve nested origins: List[Union[str, int]] yields a list origin with a Union arg, and Tuple[int, Optional[float], List[str]] yields a tuple origin with int, Union[float, None], and list[str] args.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When modifying typed signature annotation parsing or nested type origin handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/signatures/test_signature.py:305-325`
