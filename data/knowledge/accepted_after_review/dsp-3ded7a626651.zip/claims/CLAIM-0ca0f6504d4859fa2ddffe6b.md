# Rule details

- **Rule:**
  ```text
  The langchain tool conversion contract requires convert_langchain_tool to map a LangChain tool's name, description, args JSON schema (with required fields), arg_types (mapping to the Pydantic class), and arg_desc, and the converted tool's acall must return the expected value.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:**
  ```text
  When modifying convert_langchain_tool or the tests that assert its conversion contract for LangChain tools.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_langchain_tool.py:23-34`
