# Rule details

- **Rule:**
  ```text
  The docs-push workflow triggers on pull requests limited to changes under docs/**.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  pull_request:
    paths:
      - "docs/**"

```

- **Sources:**
  - `.github/workflows/docs-push.yml:9-11`

## Review evidence locations

- `.github/workflows/docs-push.yml:1-11`
