# Rule details

- **Rule:**
  ```text
  The workflow checks out the main branch by running `git fetch origin` and `git checkout main`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Checkout main branch
        run: |
          git fetch origin
          git checkout main

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:131-134`

## Review evidence locations

- `.github/workflows/build_and_release.yml:131-134`
