# Rule details

- **Rule:**
  ```text
  When tests fail after a tag is pushed, delete the tag locally with `git tag -d X.Y.Z`, fix the errors, and repeat the steps to recreate the tag locally and push to GitHub to restart the release process.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

````text
    git tag -d X.Y.Z # Delete locally
    ```
    * Fix the errors and then repeat the steps above to recreate the tag locally and push to GitHub to restart the process.

````

- **Sources:**
  - `dspy/.internal_dspyai/internals/release-checklist.md:13-15`

## Review evidence locations

- `dspy/.internal_dspyai/internals/release-checklist.md:13-15`
