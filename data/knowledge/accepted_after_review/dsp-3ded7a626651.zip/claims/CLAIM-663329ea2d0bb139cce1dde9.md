# Rule details

- **Rule:**
  ```text
  When modifying request_cache, preserve the default ignored_args_for_cache_key of ['api_key','api_base','base_url'] so connection-credential arguments are excluded from cache keys unless explicitly overridden.
  ```
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:**
  ```text
  when changing request_cache or the cache key argument exclusion defaults
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
request_cache defaults ignored_args_for_cache_key to ['api_key','api_base','base_url'], excluding connection-credential arguments from cache keys unless overridden.
```

- **Sources:**
  - `dspy/clients/cache.py:172-262`
