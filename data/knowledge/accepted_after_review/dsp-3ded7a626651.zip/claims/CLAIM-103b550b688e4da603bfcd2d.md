# Rule details

- **Rule:**
  ```text
  The Databricks retriever `Document` dataclass carries `page_content`, `metadata`, and a `type` field, defining the document shape returned by this retriever.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:**
  ```text
  When modifying the Databricks retriever's document model, preserve the `page_content`, `metadata`, and `type` fields.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The Databricks retriever Document dataclass defines page_content, metadata, and type fields, matching the document shape contract.
```

- **Sources:**
  - `dspy/retrievers/databricks_rm.py:16-26`
