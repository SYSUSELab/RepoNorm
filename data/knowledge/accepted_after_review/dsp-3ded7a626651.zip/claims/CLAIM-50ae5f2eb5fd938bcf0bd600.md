# Rule details

- **Rule:**
  ```text
  count_messages_with_image_url_pattern must match messages requiring type == "image_url" and a string url, and must return 0 on any exception so image-presence assertions tolerate malformed messages.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** Modifying the image-url message counting helper or its exception tolerance.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/signatures/test_adapter_image.py:40-66`
