# Rule details

- **Rule:**
  ```text
  `_encode_image_from_file` reads the file, guesses MIME type from the path via `mimetypes`, raises `ValueError` when the MIME type cannot be determined, and returns a `data:<mime>;base64,<data>` URI.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  When modifying image encoding from files, preserve the MIME-type guessing, the `ValueError` on undetermined MIME type, and the `data:<mime>;base64,<data>` URI format.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_encode_image_from_file reads the file, guesses MIME type via mimetypes, raises ValueError on undetermined MIME, and returns a base64 data URI.
```

- **Sources:**
  - `dspy/adapters/types/image.py:137-148`
