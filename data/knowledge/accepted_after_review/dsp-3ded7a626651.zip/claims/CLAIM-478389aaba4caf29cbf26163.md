# Rule details

- **Rule:**
  ```text
  TrainingJobDatabricks.status must return None when no finetuning_run is set and raise ImportError with an explicit 'pip install databricks_genai' message when the optional databricks.model_training import fails, preserving the optional-dependency contract.
  ```
- **Applies to:**
  - `dspy/clients/databricks.py`
- **Condition:**
  ```text
  When modifying TrainingJobDatabricks.status or the optional databricks.model_training dependency handling.
  ```
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/databricks.py:28-34`
