# Rule details

- **Rule:**
  ```text
  _fmt_exc must format a traceback with a default limit of 5 innermost frames and prefix a newline, defining the repository's traceback-summary convention for ReAct errors.
  ```
- **Applies to:**
  - `dspy/predict/react.py`
- **Condition:**
  ```text
  when modifying _fmt_exc or ReAct error formatting
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/predict/react.py:187-195`
