# Rule details

- **Rule:**
  ```text
  Running `python scripts/generate_api_summary.py` generates the API summary.
  ```
- **Applies to:**
  - `scripts/generate_api_summary.py`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
   python scripts/generate_api_summary.py

```

- **Sources:**
  - `docs/README.md:35`

## Review evidence locations

- `docs/README.md:35-35`
