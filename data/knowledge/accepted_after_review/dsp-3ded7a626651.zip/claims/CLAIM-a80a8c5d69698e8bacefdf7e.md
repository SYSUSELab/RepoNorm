# Rule details

- **Rule:**
  ```text
  When modifying dspy/__init__.py, preserve the top-level re-exports of adapter classes (Adapter, ChatAdapter, JSONAdapter, XMLAdapter, TwoStepAdapter) and types (Image, Audio, History, BaseType, Tool, ToolCalls), and keep the BootstrapRS alias to BootstrapFewShotWithRandomSearch and the cache alias to DSPY_CACHE.
  ```
- **Applies to:**
  - `dspy/__init__.py`
- **Condition:** Modifying the top-level dspy package exports or aliases.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
dspy/__init__.py re-exports Adapter, ChatAdapter, JSONAdapter, XMLAdapter, TwoStepAdapter, Image, Audio, History, BaseType, Tool, ToolCalls, and keeps BootstrapRS = BootstrapFewShotWithRandomSearch and cache = DSPY_CACHE, preserving the required exports and aliases.
```

- **Sources:**
  - `dspy/__init__.py`
