# Rule details

- **Rule:**
  ```text
  Run `mkdocs serve` to serve the documentation locally.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

````text
mkdocs serve
```

````

- **Sources:**
  - `docs/README.md:52-53`

## Review evidence locations

- `docs/README.md:52-53`
