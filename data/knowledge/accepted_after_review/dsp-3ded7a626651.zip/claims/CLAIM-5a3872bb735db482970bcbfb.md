# Rule details

- **Rule:**
  ```text
  When modifying CustomRulesInduction, preserve the dynamic __doc__ contract: __doc__ is set using num_rules to instruct extraction of a list of num_rules concise, non-redundant natural-language rules, with inputs examples_text and output natural_language_rules.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when changing CustomRulesInduction or its dynamic __doc__ construction
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
CustomRulesInduction sets __doc__ dynamically using num_rules to instruct extraction of a list of num_rules concise, non-redundant natural-language rules.
```

- **Sources:**
  - `dspy/teleprompt/infer_rules.py:132-139`
