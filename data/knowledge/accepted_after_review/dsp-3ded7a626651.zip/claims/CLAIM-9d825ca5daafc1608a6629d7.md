# Rule details

- **Rule:**
  ```text
  When changing API docs generation, preserve the mkdocstrings rendering convention: show_source, show_root_heading, heading_level 2, google docstring style, inherited_members true, and for classes an injected members list of public methods.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying generate_doc_page or the mkdocstrings block emission for generated API documentation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_docs.py:127-150`
