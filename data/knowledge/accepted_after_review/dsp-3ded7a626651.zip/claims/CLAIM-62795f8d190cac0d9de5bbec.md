# Rule details

- **Rule:**
  ```text
  Run `pre-commit run --files <file>...` to run pre-commit checks against specific files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  pre-commit run --files path/to/file1.py path/to/file2.py

```

- **Sources:**
  - `CONTRIBUTING.md:70`

## Review evidence locations

- `CONTRIBUTING.md:68-70`
