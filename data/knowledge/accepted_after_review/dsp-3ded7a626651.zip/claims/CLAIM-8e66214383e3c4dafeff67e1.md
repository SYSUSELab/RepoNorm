# Rule details

- **Rule:** The PyPI job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
        uses: actions/setup-python@v3
        with:
          python-version: "3.11"

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:80-82`
