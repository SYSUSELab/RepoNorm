# Rule details

- **Rule:**
  ```text
  _answer_match must return EM(prediction, answers) when frac >= 1.0 and otherwise F1(prediction, answers) >= frac, so the frac threshold selects between exact-match and F1-based matching.
  ```
- **Applies to:**
  - `dspy/evaluate/metrics.py`
- **Condition:**
  ```text
  when modifying _answer_match or the frac threshold behavior in dspy/evaluate/metrics.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/evaluate/metrics.py:18-25`
