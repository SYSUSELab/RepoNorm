# Rule details

- **Rule:**
  ```text
  Embeddings(corpus, embedder, k=1) queries run through a ThreadPoolExecutor(max_workers=10) must preserve original query order in results.
  ```
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** When modifying Embeddings retriever concurrency or result ordering in retriever tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test module imports ThreadPoolExecutor and exercises multithreaded embeddings search, matching the concurrency rule for Embeddings retriever tests.
```

- **Sources:**
  - `tests/retrievers/test_embeddings.py`

### Evidence 2 — current_observation

```text
The test runs queries through ThreadPoolExecutor(max_workers=10) and asserts results preserve original query order, matching the order-preservation rule.
```

- **Sources:**
  - `tests/retrievers/test_embeddings.py:49-72`

## Review evidence locations

- `tests/retrievers/test_embeddings.py:49-72`
