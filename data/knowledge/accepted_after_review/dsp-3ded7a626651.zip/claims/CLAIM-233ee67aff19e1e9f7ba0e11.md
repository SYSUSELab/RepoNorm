# Rule details

- **Rule:**
  ```text
  When modifying Provider.is_provider_model, preserve the default False return and the documented requirement that subclasses override it to enable model provider auto-discovery.
  ```
- **Applies to:**
  - `dspy/clients/provider.py`
- **Condition:**
  ```text
  when changing Provider.is_provider_model or provider auto-discovery behavior
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Provider.is_provider_model is a staticmethod returning False with a comment stating subclasses should check whether a model is supported for auto-discovery, matching the default-False plus override-required contract.
```

- **Sources:**
  - `dspy/clients/provider.py:80-83`
