# Rule details

- **Rule:**
  ```text
  DatabricksRM.__init__ must resolve token/endpoint/client id/secret from constructor args or DATABRICKS_TOKEN, DATABRICKS_HOST, DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET env vars; raise ValueError when databricks-sdk is absent and token or endpoint is missing; deduplicate columns with id and text column names; and when use_with_databricks_agent_framework is set, require mlflow and call mlflow.models.set_retriever_schema(primary_key='doc_id', text_column='page_content', doc_uri='doc_uri').
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:**
  ```text
  when modifying DatabricksRM.__init__ configuration or agent-framework integration
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/retrievers/databricks_rm.py:132-172`
