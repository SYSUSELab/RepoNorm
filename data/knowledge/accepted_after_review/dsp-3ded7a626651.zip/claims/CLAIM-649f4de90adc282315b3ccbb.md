# Rule details

- **Rule:**
  ```text
  pytest_generate_tests must parameterize the configure_model fixture over MODEL_LIST, pairing each model with a boolean indicating membership in the function's _known_failing_models attribute and using the model name as the test ID, so contributors marking known-failing reliability models must use _known_failing_models rather than ad hoc skips.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** When adding or modifying reliability model parameterization or marking a model as known-failing.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/conftest.py:28-38`
