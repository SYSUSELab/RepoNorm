# Rule details

- **Rule:**
  ```text
  When changing API docs generation, preserve the module-contents filtering rules: filter by __all__ when present, include submodules whose names start with the module name, include classes/routines whose __module__ starts with the module name, and exclude underscore-prefixed names.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying get_module_contents or the logic that enumerates module members for generated API docs.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_docs.py:98-114`
