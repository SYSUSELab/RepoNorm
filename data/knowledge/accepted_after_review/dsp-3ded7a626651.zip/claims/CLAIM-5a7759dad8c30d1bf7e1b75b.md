# Rule details

- **Rule:** Tool invocation must raise ValueError when a non-integer value is supplied for an int-typed argument.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** Modifying Tool argument type validation or the error raised for mismatched argument types.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_tool.py:194-197`
