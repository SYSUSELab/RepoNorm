# Rule details

- **Rule:**
  ```text
  The dspy-ai package declares a runtime dependency on dspy>=2.6.5.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
dependencies = ["dspy>=2.6.5"]  

```

- **Sources:**
  - `dspy/.internal_dspyai/pyproject.toml:14`
