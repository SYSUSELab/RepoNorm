# Rule details

- **Rule:**
  ```text
  pytest_configure must register each flag in SKIP_DEFAULT_FLAGS as a pytest marker via config.addinivalue_line, so contributors adding opt-out flags must add them to SKIP_DEFAULT_FLAGS rather than registering markers ad hoc.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When adding or modifying an opt-out pytest flag or marker in the test configuration.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
pytest_configure iterates SKIP_DEFAULT_FLAGS and calls config.addinivalue_line to register each flag as a pytest marker.
```

- **Sources:**
  - `tests/conftest.py:38-40`
