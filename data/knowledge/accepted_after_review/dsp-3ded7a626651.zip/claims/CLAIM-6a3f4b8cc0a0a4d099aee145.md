# Rule details

- **Rule:** The TestPyPI publish step uses the pypa/gh-action-pypi-publish action with repository-url set to https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
        uses: pypa/gh-action-pypi-publish@release/v1 # This requires a trusted publisher to be setup in pypi/testpypi
        with:
          repository-url: https://test.pypi.org/legacy/

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:61-63`
