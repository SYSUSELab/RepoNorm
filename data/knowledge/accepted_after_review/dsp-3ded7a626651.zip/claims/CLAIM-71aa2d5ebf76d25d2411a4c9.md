# Rule details

- **Rule:** When a signature is constructed from a dict of InputField/OutputField instances, fields without an explicit annotation must default to str.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** Modifying dict-based Signature construction or the default annotation applied to InputField/OutputField entries.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/signatures/test_signature.py:98-103`
