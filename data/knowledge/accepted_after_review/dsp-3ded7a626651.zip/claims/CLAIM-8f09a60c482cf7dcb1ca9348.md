# Rule details

- **Rule:**
  ```text
  Before publishing to PyPI, the workflow creates a test virtual environment with `python -m venv test_before_pypi`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Create test environment
        run: python -m venv test_before_pypi

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:97-98`

## Review evidence locations

- `.github/workflows/build_and_release.yml:96-103`
