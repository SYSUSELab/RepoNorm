# Rule details

- **Rule:** The pre-commit-checks workflow runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    runs-on: ubuntu-latest

```

- **Sources:**
  - `.github/workflows/precommits_check.yml:7`

## Review evidence locations

- `.github/workflows/precommits_check.yml:5-8`
