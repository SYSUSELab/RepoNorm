# Rule details

- **Rule:** If the test-intro-script test fails, the workflow fails and the maintainer needs to make a fix and delete and then recreate the tag.
- **Applies to:**
  - `**`
- **Condition:** the test-intro-script test fails
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
3. If this fails, the workflow fails and the maintainer needs to make a fix and delete and then recreate the tag.

```

- **Sources:**
  - `dspy/.internal_dspyai/internals/build-and-release.md:46`

## Review evidence locations

- `dspy/.internal_dspyai/internals/build-and-release.md:42-46`
