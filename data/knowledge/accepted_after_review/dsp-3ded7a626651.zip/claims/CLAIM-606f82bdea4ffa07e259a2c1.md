# Rule details

- **Rule:** Generated reliability programs are imported by temporarily prepending the program's directory to sys.path while loading the module via importlib spec, and sys.path is fully restored in a finally block even on exceptions.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying program module loading or sys.path manipulation for generated reliability programs
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:625-655`
