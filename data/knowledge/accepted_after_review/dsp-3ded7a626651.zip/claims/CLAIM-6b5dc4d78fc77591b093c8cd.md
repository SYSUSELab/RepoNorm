# Rule details

- **Rule:** The build-test job installs docs dependencies from docs/requirements.txt and builds the docs with mkdocs build.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: |
          cd docs
          pip install -r requirements.txt
          mkdocs build

```

- **Sources:**
  - `.github/workflows/docs-push.yml:25-28`

## Review evidence locations

- `.github/workflows/docs-push.yml:24-28`
