# Rule details

- **Rule:**
  ```text
  load_generated_cases must recursively walk a directory and treat a directory as a test case only when it contains both program.py and an inputs subdirectory, loading each .json input and deriving the case name from the enclosing directory, root basename, and input filename.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying load_generated_cases or the generated-case directory layout it consumes
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:265-304`
