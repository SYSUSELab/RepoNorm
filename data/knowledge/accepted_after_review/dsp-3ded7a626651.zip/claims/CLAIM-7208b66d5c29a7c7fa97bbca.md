# Rule details

- **Rule:**
  ```text
  find_data_errors_completion must require exactly the keys 'prompt' and 'completion' with both values being str, returning a descriptive error string otherwise.
  ```
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:**
  ```text
  When modifying find_data_errors_completion validation logic in dspy/clients/utils_finetune.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/utils_finetune.py:119-130`
