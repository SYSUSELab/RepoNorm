# Rule details

- **Rule:**
  ```text
  XMLAdapter.format_field_with_value must wrap each field value as '<field.name>\n<formatted>\n</field.name>' and join fields with blank lines, then strip the result, defining the XML adapter's field serialization format.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:** When modifying XMLAdapter field serialization or the XML wire format emitted for field values.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/adapters/xml_adapter.py:15-20`
