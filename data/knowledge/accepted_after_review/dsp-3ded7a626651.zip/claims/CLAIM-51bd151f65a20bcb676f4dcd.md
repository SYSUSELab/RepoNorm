# Rule details

- **Rule:**
  ```text
  When changing API docs generation, preserve the API_MAPPING grouping of public dspy symbols into categories (models, primitives, signatures, adapters, modules, tools, utils, evaluation, optimizers) that determines the generated API documentation structure.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Adding, removing, or recategorizing public dspy symbols in the generated API documentation.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_docs.py:9-83`
