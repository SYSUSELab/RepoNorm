# Rule details

- **Rule:**
  ```text
  When modifying InferRules.__init__, preserve the keyword-argument contract: it constructs RulesInductionProgram(num_rules, teacher_settings=...) and reads metric and max_errors from kwargs, so callers must pass metric/max_errors as keyword arguments rather than named parameters.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when changing InferRules.__init__ or its metric/max_errors parameter handling
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/teleprompt/infer_rules.py:13-22`
