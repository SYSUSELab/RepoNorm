# Rule details

- **Rule:**
  ```text
  When modifying with_callbacks, preserve the sync/async duality: the decorator must branch on inspect.iscoroutinefunction(fn) and return an async_wrapper for coroutine functions and a sync_wrapper otherwise, so wrapped methods keep their original awaitability.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:**
  ```text
  when changing the with_callbacks decorator or the wrappers it returns
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/utils/callback.py:290-293`
- `dspy/utils/callback.py:345-349`
