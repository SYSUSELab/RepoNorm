# Rule details

- **Rule:**
  ```text
  Version increments must advance the prerelease segment: increment_version parses the current version with PyPIVersion, reconstructs a semver.Version preserving pre-release components, and returns bump_prerelease() rather than bumping the patch or minor segment.
  ```
- **Applies to:**
  - `.github/workflows/build_utils/test_version.py`
- **Condition:**
  ```text
  When modifying increment_version or the version-bump logic it drives, preserve prerelease-advancing semantics instead of switching to patch/minor bumps.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `.github/workflows/build_utils/test_version.py:36-44`
