# Rule details

- **Rule:** The site icon uses material/pencil for edit.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        edit: material/pencil

```

- **Sources:**
  - `docs/mkdocs.yml:175`

## Review evidence locations

- `docs/mkdocs.yml:175-175`
