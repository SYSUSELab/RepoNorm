# Rule details

- **Rule:**
  ```text
  Reliability test JSON schemas are produced by calling signature.schema(), moving $defs into definitions, and recursively inlining $ref entries from #/$defs/ while preserving the __dspy_field_type marker, so the returned schema contains no $defs.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying JSON schema generation or $ref expansion for reliability tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:519-551`
