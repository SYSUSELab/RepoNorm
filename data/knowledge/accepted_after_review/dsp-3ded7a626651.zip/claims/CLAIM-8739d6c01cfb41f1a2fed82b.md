# Rule details

- **Rule:** Documentation changes should be pushed on a new branch and opened as a PR for review and approval before merging into main.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
2. **Push your new changes on a new branch**: Feel free to add or edit existing documentation and open a PR for your changes. Once your PR is reviewed and approved, the changes will be ready to merge into main. 

```

- **Sources:**
  - `docs/README.md:73`

## Review evidence locations

- `docs/README.md:73-73`
