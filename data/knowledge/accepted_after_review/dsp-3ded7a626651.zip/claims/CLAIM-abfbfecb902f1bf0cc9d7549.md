# Rule details

- **Rule:**
  ```text
  The request_cache decorator must return the cached value for identical prompt and model arguments and recompute when arguments differ, with cache.get invoked once per identical call.
  ```
- **Applies to:**
  - `tests/clients/test_cache.py`
- **Condition:**
  ```text
  Modifying request_cache decorator behavior or its cache-key argument handling.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/clients/test_cache.py:201-225`
