# Rule details

- **Rule:** Ruff's formatter is configured to indent with spaces (indent-style = "space").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
indent-style = "space"

```

- **Sources:**
  - `pyproject.toml:165`
