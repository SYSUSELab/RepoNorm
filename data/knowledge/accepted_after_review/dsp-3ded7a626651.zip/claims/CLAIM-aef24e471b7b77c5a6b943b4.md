# Rule details

- **Rule:**
  ```text
  `KNNFewShot` is implemented as a `Teleprompter` subclass, so KNN few-shot selection participates in the teleprompter abstraction.
  ```
- **Applies to:**
  - `dspy/teleprompt/knn_fewshot.py`
- **Condition:**
  ```text
  When modifying KNN few-shot selection, preserve its implementation as a `Teleprompter` subclass.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/teleprompt/knn_fewshot.py:1-20`
