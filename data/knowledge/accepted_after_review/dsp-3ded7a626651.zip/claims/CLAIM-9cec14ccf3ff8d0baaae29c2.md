# Rule details

- **Rule:**
  ```text
  The PyPI job updates the package name in ./dspy/__metadata__.py to dspy by replacing the line after the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: sed -i '/#replace_package_name_marker/{n;s/__name__ *= *"[^"]*"/__name__="dspy"/;}' ./dspy/__metadata__.py

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:93`
