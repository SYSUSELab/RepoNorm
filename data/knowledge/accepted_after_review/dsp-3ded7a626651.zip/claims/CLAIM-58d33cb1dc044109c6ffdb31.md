# Rule details

- **Rule:**
  ```text
  The workflow publishes the dspy-ai distribution to PyPI using `pypa/gh-action-pypi-publish@release/v1` with `attestations: false` and `packages-dir: ./dspy/.internal_dspyai/dist/`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/dist/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Publish distribution 📦 to PyPI (dspy-ai)
        uses: pypa/gh-action-pypi-publish@release/v1
        with:
          attestations: false
          packages-dir: ./dspy/.internal_dspyai/dist/

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:121-125`
