# Rule details

- **Rule:**
  ```text
  On `main`, create a git tag with pattern X.Y.Z where X, Y, and Z follow the semver pattern, then push the tag to the origin git repo (github).
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

````text
* [ ] On `main` Create a git tag with pattern X.Y.Z where X, Y, and Z follow the [semver pattern](https://semver.org/). Then push the tag to the origin git repo (github).
    * ```bash
      git tag X.Y.Z

````

- **Sources:**
  - `dspy/.internal_dspyai/internals/release-checklist.md:3-5`

## Review evidence locations

- `dspy/.internal_dspyai/internals/release-checklist.md:3-6`
