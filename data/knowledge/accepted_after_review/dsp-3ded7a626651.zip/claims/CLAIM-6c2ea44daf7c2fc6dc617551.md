# Rule details

- **Rule:**
  ```text
  When modifying COPRO.__init__, preserve the validation that raises ValueError when breadth <= 1, enforcing breadth greater than 1; other params (depth, init_temperature, track_stats) are stored without validation.
  ```
- **Applies to:**
  - `dspy/teleprompt/copro_optimizer.py`
- **Condition:**
  ```text
  Modifying COPRO.__init__ or its breadth validation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
COPRO.__init__ raises ValueError when breadth <= 1 and stores depth, init_temperature, and track_stats without validation, preserving the breadth validation rule.
```

- **Sources:**
  - `dspy/teleprompt/copro_optimizer.py:60-77`
