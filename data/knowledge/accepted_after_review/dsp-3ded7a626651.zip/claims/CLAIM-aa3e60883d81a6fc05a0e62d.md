# Rule details

- **Rule:**
  ```text
  Install the project in editable mode with the dev extra by running `pip install -e ".[dev]"`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
pip install -e ".[dev]"

```

- **Sources:**
  - `CONTRIBUTING.md:141`

## Review evidence locations

- `CONTRIBUTING.md:130-142`
