# Rule details

- **Rule:**
  ```text
  When changing API docs generation, preserve the filtering rules that determine which objects are documented: only root-level dspy objects in the API category mapping, only public submodules re-exported in dspy's __init__, and excluded_modules can suppress subtrees.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying generate_md_docs or the logic that selects which dspy objects and submodules are documented.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_docs.py:207-289`
