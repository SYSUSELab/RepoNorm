# Rule details

- **Rule:** The build-and-publish-test-pypi process updates the version placeholder in setup.py to the version obtained in the version-determination step.
- **Applies to:**
  - `setup.py`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
1. Updates the version placeholder in [setup.py](https://github.com/stanfordnlp/dspy/blob/main/setup.py) to the version obtained in step 1.

```

- **Sources:**
  - `dspy/.internal_dspyai/internals/build-and-release.md:34`

## Review evidence locations

- `dspy/.internal_dspyai/internals/build-and-release.md:29-35`
