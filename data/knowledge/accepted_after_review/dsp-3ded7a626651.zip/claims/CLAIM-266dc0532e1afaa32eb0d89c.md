# Rule details

- **Rule:**
  ```text
  `Embedder.acall` preprocesses inputs into batches, selects cached versus uncached embedding computation based on the caching flag, and postprocesses results back to single or batched form.
  ```
- **Applies to:**
  - `dspy/clients/embedding.py`
- **Condition:**
  ```text
  When modifying `Embedder.acall`, preserve the preprocess/batch/cache-selection/postprocess pipeline and single-vs-batched result shaping.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/embedding.py:137-145`
