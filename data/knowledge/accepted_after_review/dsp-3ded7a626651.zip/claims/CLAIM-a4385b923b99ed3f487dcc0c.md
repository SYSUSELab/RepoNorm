# Rule details

- **Rule:**
  ```text
  f1_score must use token multiset intersection for num_same; when both prediction and ground truth tokenize to zero tokens it must not return 1.0, and when num_same == 0 it must return 0.
  ```
- **Applies to:**
  - `dspy/dsp/utils/metrics.py`
- **Condition:**
  ```text
  When modifying f1_score tokenization or scoring logic in dspy/dsp/utils/metrics.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/dsp/utils/metrics.py:55-70`
