# Rule details

- **Rule:** When changing API docs generation, preserve the recursive empty-directory removal behavior: descend into children first and call rmdir only when the directory has no entries.
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying remove_empty_dirs or the cleanup logic that removes empty directories after docs generation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_docs.py:292-299`
