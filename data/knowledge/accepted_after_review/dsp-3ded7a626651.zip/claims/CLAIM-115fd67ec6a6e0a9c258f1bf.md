# Rule details

- **Rule:** Setuptools package discovery includes only the "dspy" package and its subpackages.
- **Applies to:**
  - `dspy/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
include = ["dspy", "dspy.*"]

```

- **Sources:**
  - `pyproject.toml:75`

## Review evidence locations

- `pyproject.toml:73-76`
