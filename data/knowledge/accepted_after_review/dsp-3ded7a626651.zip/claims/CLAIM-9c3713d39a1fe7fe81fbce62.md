# Rule details

- **Rule:**
  ```text
  train_test_split accepts train_size/test_size as either a float proportion in (0,1) or an int absolute count, raises ValueError for other types, and raises ValueError when train_end + test_end exceeds dataset size.
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  when modifying DataLoader.train_test_split or its size-argument validation
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/datasets/dataloader.py:152-191`
