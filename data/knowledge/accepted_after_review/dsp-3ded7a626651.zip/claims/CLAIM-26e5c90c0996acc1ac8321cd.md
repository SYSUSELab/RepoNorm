# Rule details

- **Rule:**
  ```text
  FeedbackBasedInstruction must remain a dspy.Signature with previous_instruction and feedback as InputFields and new_instruction as OutputField, and its docstring must constrain the generated instruction to no more than 3 paragraphs while retaining prior general guidelines.
  ```
- **Applies to:**
  - `dspy/teleprompt/avatar_optimizer.py`
- **Condition:** When modifying FeedbackBasedInstruction fields or its docstring constraints in the avatar optimizer.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/teleprompt/avatar_optimizer.py:52-72`
