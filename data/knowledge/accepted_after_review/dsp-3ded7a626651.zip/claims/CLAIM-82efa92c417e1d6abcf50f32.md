# Rule details

- **Rule:**
  ```text
  The check-yaml pre-commit hook runs with args ["--allow-multiple-documents", "--unsafe"].
  ```
- **Applies to:**
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: check-yaml
        args: ["--allow-multiple-documents", "--unsafe"]

```

- **Sources:**
  - `.pre-commit-config.yaml:22-23`

## Review evidence locations

- `.pre-commit-config.yaml:19-23`
