# Rule details

- **Rule:** Async tool invocations must remain concurrently executable: concurrent Tool.acall calls must complete within the pinned time budget and asyncio.gather must return results in task order.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying async tool invocation or concurrency behavior in the tool adapter tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_tool.py:349-366`
