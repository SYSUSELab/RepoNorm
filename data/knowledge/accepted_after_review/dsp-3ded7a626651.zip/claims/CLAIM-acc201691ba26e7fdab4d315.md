# Rule details

- **Rule:**
  ```text
  ChatAdapter.__call__ must fall back to JSONAdapter when the superclass call raises, except that ContextWindowExceededError and calls where self is already a JSONAdapter must re-raise the original exception.
  ```
- **Applies to:**
  - `dspy/adapters/chat_adapter.py`
- **Condition:**
  ```text
  When modifying ChatAdapter.__call__ or its exception handling around the superclass adapter call.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
ChatAdapter.__call__ catches exceptions from the superclass call and falls back to JSONAdapter, while re-raising ContextWindowExceededError and re-raising when self is already a JSONAdapter.
```

- **Sources:**
  - `dspy/adapters/chat_adapter.py:33-51`
