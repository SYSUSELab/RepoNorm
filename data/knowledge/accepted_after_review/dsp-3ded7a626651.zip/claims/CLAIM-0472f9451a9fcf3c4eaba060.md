# Rule details

- **Rule:**
  ```text
  _TestInputsGeneration must define inputs program_description, program_input, and program_output_signature (JSON Schema format) and output output_assertions: List[str], with the docstring instructing about 5 natural-language objective assertions and blank when accurate assertions are difficult.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _TestInputsGeneration or the assertion-generation signature.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:470-495`
