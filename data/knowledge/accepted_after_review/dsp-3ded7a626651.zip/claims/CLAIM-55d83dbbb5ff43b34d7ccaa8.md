# Rule details

- **Rule:**
  ```text
  Run `pre-commit run` to execute pre-commit checks.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

````text
  pre-commit run
  ```

````

- **Sources:**
  - `CONTRIBUTING.md:64-65`

## Review evidence locations

- `CONTRIBUTING.md:59-65`
