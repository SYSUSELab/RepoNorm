# Rule details

- **Rule:**
  ```text
  dspy.primitives.module must keep named_parameters intentionally different in behavior from named_sub_modules, preserving the deliberate compatibility boundary.
  ```
- **Applies to:**
  - `dspy/primitives/module.py`
- **Condition:**
  ```text
  When modifying named_parameters or named_sub_modules in dspy.primitives.module.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/primitives/module.py:7-13`
