# Rule details

- **Rule:** When changing API summary generation, preserve the deterministic nav ordering rule: submodule sections precede file entries (e.g., dspy.evaluate before dspy.ChainOfThought).
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:**
  ```text
  Modifying format_nav_section or the logic that orders generated API navigation entries.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_summary.py:34-49`
