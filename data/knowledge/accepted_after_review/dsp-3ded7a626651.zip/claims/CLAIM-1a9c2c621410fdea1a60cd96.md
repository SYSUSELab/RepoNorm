# Rule details

- **Rule:**
  ```text
  When a Signature is constructed from a string or dict, field annotations must be preserved exactly as declared, including typing generics such as List[str], Dict[str, int], and Tuple[int, float].
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** Modifying Signature construction from string or dict field declarations.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/signatures/test_signature.py:255-263`
- `tests/signatures/test_signature.py:328-340`
