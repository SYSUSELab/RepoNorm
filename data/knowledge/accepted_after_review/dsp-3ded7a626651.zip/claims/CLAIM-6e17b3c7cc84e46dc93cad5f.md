# Rule details

- **Rule:**
  ```text
  The reliability generation utilities require assertion-generation programs to be built via dspy.ChainOfThought over a _TestInputsGeneration signature, and the retry decorator must return a wrapper that forwards calls, establishing the code-generation and judging pipeline for reliability tests.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the reliability assertion-generation program construction or the retry decorator in the generation utilities.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:22-43`
- `tests/reliability/generate/utils.py:470-495`
