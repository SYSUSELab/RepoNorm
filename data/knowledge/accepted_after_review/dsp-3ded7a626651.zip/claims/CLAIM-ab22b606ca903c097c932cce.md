# Rule details

- **Rule:**
  ```text
  The build-and-publish-pypi job runs only when github.repository_owner equals 'stanfordnlp'.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Condition:**
  ```text
  workflow predicate: github.repository_owner == 'stanfordnlp'
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    if: github.repository_owner == 'stanfordnlp'

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:70`

## Review evidence locations

- `.github/workflows/build_and_release.yml:68-71`
