# Rule details

- **Rule:** The site icon uses fontawesome/brands/git-alt for repo.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        repo: fontawesome/brands/git-alt

```

- **Sources:**
  - `docs/mkdocs.yml:174`

## Review evidence locations

- `docs/mkdocs.yml:174-174`
