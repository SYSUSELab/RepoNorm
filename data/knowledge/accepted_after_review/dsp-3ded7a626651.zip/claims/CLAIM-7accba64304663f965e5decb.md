# Rule details

- **Rule:** The social plugin is enabled.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
plugins:
    - social

```

- **Sources:**
  - `docs/mkdocs.yml:183-184`
