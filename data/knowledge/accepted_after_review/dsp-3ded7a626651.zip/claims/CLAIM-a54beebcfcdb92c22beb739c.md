# Rule details

- **Rule:** The asyncify test helper must sleep for a given wait and return 42, used to exercise async wrapping of blocking calls.
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** When modifying the asyncify test helper that exercises async wrapping of blocking calls.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_asyncify.py:23-29`
