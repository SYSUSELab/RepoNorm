# Rule details

- **Rule:**
  ```text
  find_data_error_chat must accept a finetuning chat payload dict with exactly the key 'messages' whose value is a list, and must report the first offending message index.
  ```
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:**
  ```text
  when modifying finetuning chat data validation in find_data_error_chat
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/utils_finetune.py:135-149`
