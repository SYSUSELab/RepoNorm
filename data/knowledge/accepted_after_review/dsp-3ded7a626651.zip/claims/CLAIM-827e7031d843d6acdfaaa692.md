# Rule details

- **Rule:**
  ```text
  JSONAdapter must format a dspy.Image input as a user message content list of exactly three chunks ordered text, image_url, text, with the image_url chunk shaped as {'type':'image_url','image_url':{'url':...}}.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** when modifying JSONAdapter image formatting or multimodal message construction
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test body asserts exactly three user-message content chunks ordered text, image_url, text, and checks the image_url chunk shape, matching the JSONAdapter image-formatting rule.
```

- **Sources:**
  - `tests/adapters/test_json_adapter.py:224-246`
