# Rule details

- **Rule:**
  ```text
  The reliability test utilities require JudgeSignature to take program_input, program_output, and guidelines as InputFields and return a JudgeResponse OutputField, with the docstring instructing the judge to consider only the provided guidelines when determining correctness, and JUDGE_MODEL_NAME = 'judge' as the fixed model identifier.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When modifying the reliability judge signature, judge model identifier, or the utilities that build the judge program.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/utils.py:12-105`
