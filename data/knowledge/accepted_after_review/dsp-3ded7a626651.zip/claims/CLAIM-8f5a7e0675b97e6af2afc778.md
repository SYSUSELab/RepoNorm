# Rule details

- **Rule:** If the package is migrated to a new project, follow the steps to create a trusted publisher.
- **Applies to:**
  - `**`
- **Condition:** the package is migrated to a new project
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
The automation requires a [trusted publisher](https://docs.pypi.org/trusted-publishers/) to be set up on both the pypi and test-pypi packages. If the package is migrated to a new project, please follow the [steps](https://docs.pypi.org/trusted-publishers/adding-a-publisher/) to create a trusted publisher. If you have no releases on the new project, you may have to create a [pending trusted publisher](https://docs.pypi.org/trusted-publishers/creating-a-project-through-oidc/) to allow the first automated deployment. 
```

- **Sources:**
  - `dspy/.internal_dspyai/internals/release-checklist.md:25`

## Review evidence locations

- `dspy/.internal_dspyai/internals/release-checklist.md:23-25`
