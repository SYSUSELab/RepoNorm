# Rule details

- **Rule:** When a contributor modifies the HTML helper in dspy/evaluate/evaluate.py, it must remain a compatibility shim that returns the input string unchanged when IPython is unavailable.
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** Modifying the HTML helper or adding a new IPython-compatibility shim in the evaluate module.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/evaluate/evaluate.py:28-36`
