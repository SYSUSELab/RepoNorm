# Rule details

- **Rule:**
  ```text
  test_save_custom_model asserts that after model.save(tmp_path, save_program=True) and dspy.load(tmp_path), the loaded object is a CustomModel with the same number of predictors and each predictor's signature equal to the original; contributors modifying save/load must preserve this fidelity contract.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when modifying model save/load behavior or tests asserting round-trip fidelity
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_saving.py:21-35`
