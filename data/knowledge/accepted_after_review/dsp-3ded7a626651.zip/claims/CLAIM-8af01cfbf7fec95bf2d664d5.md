# Rule details

- **Rule:**
  ```text
  Tests that exercise dspy cache-key generation failures must assert that when litellm.completion raises RuntimeError, the LM call is not retried and mock_completion.call_count remains exactly 1.
  ```
- **Applies to:**
  - `tests/caching/test_litellm_cache.py`
- **Condition:** When modifying caching tests that cover cache-key generation failure paths.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The module contains test_lms_called_expected_number_of_times_for_cache_key_generation_failures, which asserts mock_completion.call_count == 1 after a RuntimeError, matching the no-retry-on-cache-key-failure rule.
```

- **Sources:**
  - `tests/caching/test_litellm_cache.py`
