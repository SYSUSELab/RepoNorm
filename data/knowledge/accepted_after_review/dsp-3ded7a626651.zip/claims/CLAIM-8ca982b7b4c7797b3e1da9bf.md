# Rule details

- **Rule:** The parallelizer test task raises ValueError('Intentional error') when item equals 3 and otherwise returns the item, defining the error-propagation case exercised by the parallelizer tests.
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** when modifying parallelizer error-propagation tests or their task fixtures
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_parallelizer.py:35-39`
