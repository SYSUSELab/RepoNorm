# Rule details

- **Rule:**
  ```text
  When changing how API docs are generated, preserve the exact HTML comment markers '<!-- START_API_REF -->' and '<!-- END_API_REF -->' used by read_existing_content to split generated content from pre-content and post-content.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Modifying the API docs generation or writing logic that reads or emits generated API reference content.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_docs.py:138-150`
- `docs/scripts/generate_api_docs.py:161-189`
