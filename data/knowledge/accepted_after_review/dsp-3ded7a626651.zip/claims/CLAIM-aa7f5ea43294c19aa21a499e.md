# Rule details

- **Rule:**
  ```text
  ParallelExecutor.execute must clear tqdm.tqdm._instances before wrapping and running the function in parallel; this global reset is an intentional side effect of each execution.
  ```
- **Applies to:**
  - `dspy/utils/parallelizer.py`
- **Condition:** When modifying ParallelExecutor.execute or its tqdm integration in dspy/utils/parallelizer.py.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/utils/parallelizer.py:40-46`
