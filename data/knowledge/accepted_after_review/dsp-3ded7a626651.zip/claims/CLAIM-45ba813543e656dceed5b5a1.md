# Rule details

- **Rule:** Create a release and add release notes, optionally using automatically generated release notes.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
* [ ] [Create a release](https://docs.github.com/en/repositories/releasing-projects-on-github/managing-releases-in-a-repository) 
* [ ] Add release notes. You can make use of [automatically generated release notes](https://docs.github.com/en/repositories/releasing-projects-on-github/automatically-generated-release-notes)

```

- **Sources:**
  - `dspy/.internal_dspyai/internals/release-checklist.md:17-18`

## Review evidence locations

- `dspy/.internal_dspyai/internals/release-checklist.md:17-18`
