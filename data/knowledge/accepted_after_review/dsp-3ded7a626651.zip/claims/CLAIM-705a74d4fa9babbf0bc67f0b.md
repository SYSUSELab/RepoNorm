# Rule details

- **Rule:** The chat LM must be queryable with both openai/ and azure/ model prefixes against the litellm test server, returning the expected response.
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:** When modifying chat LM query behavior or model-prefix handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/clients/test_lm.py:1-90`
