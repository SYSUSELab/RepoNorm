# Rule details

- **Rule:** When modifying ReinforceJob.cancel in dspy/clients/provider.py, preserve the abstract extension-point contract: the base implementation raises NotImplementedError and concrete providers are expected to override it.
- **Applies to:**
  - `dspy/clients/provider.py`
- **Condition:** When changing the base cancel method or adding concrete provider implementations.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/provider.py:38-69`
