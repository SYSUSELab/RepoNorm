# Rule details

- **Rule:**
  ```text
  When modifying the request cache decorator, preserve the sync wrapper's flow: compute the modified request via process_request, return the cached result when present, otherwise call the wrapped function and store the result with cache.put, honoring ignored_args_for_cache_key and the call-time enable_memory_cache flag that prevents indefinite cache growth.
  ```
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:** Modifying the request cache decorator's sync wrapper or its cache-key/put behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/cache.py:180-217`
- `dspy/clients/cache.py:219-237`
