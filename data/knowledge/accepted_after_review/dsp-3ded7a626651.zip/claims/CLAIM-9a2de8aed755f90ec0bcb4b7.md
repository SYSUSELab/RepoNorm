# Rule details

- **Rule:**
  ```text
  When modifying XMLAdapter.parse, preserve the strict output-field contract: extract only fields matching signature.output_fields, keep the first occurrence of each field, cast values via _parse_field_value, and raise AdapterParseError when parsed field keys do not exactly match the signature's output fields.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:** when changing XMLAdapter.parse or its output-field extraction and validation
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
XMLAdapter.parse filters to signature.output_fields, keeps first occurrences, casts via _parse_field_value, and raises AdapterParseError on key mismatch, matching the rule.
```

- **Sources:**
  - `dspy/adapters/xml_adapter.py:28-47`
