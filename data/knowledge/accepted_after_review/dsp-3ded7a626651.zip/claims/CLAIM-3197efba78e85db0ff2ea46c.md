# Rule details

- **Rule:**
  ```text
  The dspy package includes the JavaScript files matching primitives/*.js as package data.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
[tool.setuptools.package-data]
dspy = ["primitives/*.js"]

```

- **Sources:**
  - `pyproject.toml:78-79`
