# Rule details

- **Rule:** When changing API summary generation, preserve the mkdocs.yml rewriting convention: preserve pre-nav and post-theme sections and insert an 'API Reference' nav section with an api/index.md entry.
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:**
  ```text
  Modifying generate_api_summary.main or the logic that rewrites mkdocs.yml for API summary generation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_summary.py:108-128`
