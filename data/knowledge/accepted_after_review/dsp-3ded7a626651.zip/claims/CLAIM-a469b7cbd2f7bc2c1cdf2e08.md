# Rule details

- **Rule:** When changing API docs generation, preserve the non-destructive writing convention: existing pre/post content around generated API content is retained, and a '# {title}' header is injected only when no pre-content exists.
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying write_doc_file or the logic that writes generated API documentation pages.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_docs.py:192-204`
