# Rule details

- **Rule:**
  ```text
  UsageTracker._flatten_usage_entry must copy the usage entry and convert completion_tokens_details and prompt_tokens_details to plain dicts when present, defining the flattened usage record shape.
  ```
- **Applies to:**
  - `dspy/utils/usage_tracker.py`
- **Condition:**
  ```text
  When modifying UsageTracker._flatten_usage_entry normalization logic in dspy/utils/usage_tracker.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_flatten_usage_entry copies the entry via dict(usage_entry) and converts completion_tokens_details and prompt_tokens_details to plain dicts when present, defining the flattened record shape.
```

- **Sources:**
  - `dspy/utils/usage_tracker.py:23-30`
