# Rule details

- **Rule:**
  ```text
  The workflow publishes the dspy distribution to PyPI using `pypa/gh-action-pypi-publish@release/v1` with `attestations: false`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Publish distribution 📦 to PyPI (dspy)
        uses: pypa/gh-action-pypi-publish@release/v1
        with:
          attestations: false

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:107-110`

## Review evidence locations

- `.github/workflows/build_and_release.yml:107-110`
