# Claim catalog

- [Rules 1–72](catalog/0001.md); scope preview: `dspy/clients/provider.py`
- [Rules 73–145](catalog/0002.md); scope preview: `tests/teleprompt/test_ensemble.py`
- [Rules 146–218](catalog/0003.md); scope preview: `**`
- [Rules 219–292](catalog/0004.md); scope preview: `tests/clients/test_lm.py`
- [Rules 293–362](catalog/0005.md); scope preview: `build_utils/tests/intro.py`
- [Rules 363–431](catalog/0006.md); scope preview: `tests/teleprompt/test_ensemble.py`
- [Rules 432–502](catalog/0007.md); scope preview: `tests/reliability/generate/utils.py`
- [Rules 503–514](catalog/0008.md); scope preview: `**`
