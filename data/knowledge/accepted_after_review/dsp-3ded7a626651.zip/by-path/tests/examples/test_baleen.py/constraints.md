# Constraints for `tests/examples/test_baleen.py`

## Rule

- **Rule:**
  ```text
  gold_passages_retrieved must normalize gold and predicted context titles by splitting on ' | ' and taking the first segment, then return whether gold titles are a subset of found titles.
  ```
- **Applies to:**
  - `tests/examples/test_baleen.py`
- **Condition:** Modifying the retrieval evaluation metric or its title normalization and subset comparison.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4ab15ce235b71767814db7bc.md)

## Rule

- **Rule:** Tests that exercise dspy example modules must define the example as a subclass of dspy.Module, establishing the example as a dspy module.
- **Applies to:**
  - `tests/examples/test_baleen.py`
- **Condition:** When modifying example module tests that define dspy modules.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6dc386d77b907660c40782b6.md)
