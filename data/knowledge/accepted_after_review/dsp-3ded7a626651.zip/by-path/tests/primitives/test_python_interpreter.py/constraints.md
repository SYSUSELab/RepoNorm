# Constraints for `tests/primitives/test_python_interpreter.py`

## Rule

- **Rule:** PythonInterpreter.execute must wrap runtime errors such as ZeroDivisionError in InterpreterError with the original error name in the message.
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** Modifying PythonInterpreter.execute error handling or exception wrapping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a6c9ea13f158e326927164c5.md)

## Rule

- **Rule:**
  ```text
  PythonInterpreter must wrap a raised ValueError into InterpreterError with a message matching 'ValueError: [<token>]', preserving the exception-formatting contract.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** when modifying PythonInterpreter exception wrapping or its error-message formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-da9a97900bb6bfccb05a4482.md)
