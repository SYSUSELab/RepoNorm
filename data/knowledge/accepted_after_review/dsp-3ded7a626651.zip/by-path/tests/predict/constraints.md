# Constraints for `tests/predict`

## Rule

- **Rule:**
  ```text
  Run the predict tests with `uv run pytest tests/predict`.
  ```
- **Applies to:**
  - `tests/predict/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5f7d012b359dd61c99cf1459.md)

## Rule

- **Rule:**
  ```text
  The workflow tests the locally built wheel by activating the test environment, installing `dist/*.whl` with pytest and pytest-asyncio, running `pytest tests/metadata/test_metadata.py tests/predict`, then deactivating and removing the test environment.
  ```
- **Applies to:**
  - `tests/metadata/test_metadata.py`
  - `tests/predict/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a65944dfa00bb1688e89c024.md)

## Rule

- **Rule:**
  ```text
  Run `pytest tests/predict` to execute the predict tests.
  ```
- **Applies to:**
  - `tests/predict/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../../claims/CLAIM-ec176def3512ccc05454f9af.md)
