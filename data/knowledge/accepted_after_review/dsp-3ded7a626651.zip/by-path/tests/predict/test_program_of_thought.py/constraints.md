# Constraints for `tests/predict/test_program_of_thought.py`

## Rule

- **Rule:**
  ```text
  ProgramOfThought must clean up its Deno subprocess after execution so that pot.interpreter.deno_process is None once the program completes.
  ```
- **Applies to:**
  - `tests/predict/test_program_of_thought.py`
- **Condition:** when modifying ProgramOfThought interpreter lifecycle or Deno subprocess handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1d9d42824d990934cb11eb89.md)

## Rule

- **Rule:** Tests that exercise dspy multi-output signatures must declare a signature with an input list and described maximum/minimum outputs, illustrating multi-output signature usage.
- **Applies to:**
  - `tests/predict/test_program_of_thought.py`
- **Condition:** When modifying program-of-thought tests that cover multi-output signatures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d3a1ce319b4b4936d5d503d0.md)

## Rule

- **Rule:**
  ```text
  ProgramOfThought must raise RuntimeError matching 'Max hops reached. Failed to run ProgramOfThought: ZeroDivisionError:' after max_iters attempts when code generation persistently errors.
  ```
- **Applies to:**
  - `tests/predict/test_program_of_thought.py`
- **Condition:**
  ```text
  Modifying ProgramOfThought error handling or its max_iters retry behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d6987bc7d45ae0a6eb9f38f1.md)
