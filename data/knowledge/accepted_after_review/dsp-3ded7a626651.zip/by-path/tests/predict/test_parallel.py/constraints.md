# Constraints for `tests/predict/test_parallel.py`

## Rule

- **Rule:** Parallel execution must accept a list of (predictor, input) tuples including duplicate predictor entries.
- **Applies to:**
  - `tests/predict/test_parallel.py`
- **Condition:** Modifying parallel execution input handling or duplicate predictor entry support.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6c8266bf23f74906c460045e.md)

## Rule

- **Rule:**
  ```text
  Parallel prediction must accept a list of dspy.Example(input=input).with_inputs('input') instances as batch input to predictor.batch.
  ```
- **Applies to:**
  - `tests/predict/test_parallel.py`
- **Condition:** When modifying parallel prediction batch input construction or predictor.batch usage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c2002aac866d2662ab13f4a3.md)
