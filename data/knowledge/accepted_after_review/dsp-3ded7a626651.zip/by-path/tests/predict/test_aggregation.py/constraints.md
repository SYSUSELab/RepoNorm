# Constraints for `tests/predict/test_aggregation.py`

## Rule

- **Rule:** majority() must return the first completion when no answer reaches a majority (tie-breaking by first occurrence).
- **Applies to:**
  - `tests/predict/test_aggregation.py`
- **Condition:** when modifying majority aggregation or its tie-breaking behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-737c346e1543ec04f9c6fe25.md)
