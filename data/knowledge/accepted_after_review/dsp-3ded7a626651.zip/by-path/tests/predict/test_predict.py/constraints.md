# Constraints for `tests/predict/test_predict.py`

## Rule

- **Rule:**
  ```text
  Predict.load_state(dumped_state) must overwrite the target Predict's signature instructions with the dumped instance's instructions, so instructions are part of serialized state.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  when modifying Predict state serialization or load_state behavior for signature instructions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-13fbebc74b55c85621723b34.md)

## Rule

- **Rule:** Predict call path must return the LM output as result.output when invoked with an input.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** Modifying the basic Predict call path or its result.output contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8d417d9bcf36d80afd3d6aa2.md)

## Rule

- **Rule:**
  ```text
  Predict with dspy.History must produce exactly one LM call with four messages where history question/answer appear in messages[1]/[2] and the new question in messages[3], for both chat and json adapters.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** Modifying Predict handling of dspy.History or the message layout produced for chat and json adapters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b4e50d2601bb1efd7300ef74.md)

## Rule

- **Rule:**
  ```text
  With track_usage=True configured in dspy.settings, result.get_lm_usage() must report per-model token usage keyed by model name such as 'openai/gpt-4o-mini' with a 'total_tokens' field.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  Modifying LM usage tracking or the get_lm_usage result shape.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bed158d5200d87a81aaab377.md)

## Rule

- **Rule:**
  ```text
  Predict.load_state(state) must return a non-None instance whose demos equal the original's demos, supporting chaining.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  When modifying Predict.load_state return value or chaining behavior in predict tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c1071d84cd3cf2e296ce7b73.md)

## Rule

- **Rule:** A Signature may declare a dspy.History field as an InputField alongside str question/answer fields, and History is a supported signature input type.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying signature field declarations or History input support in prediction tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cb1d2361ad8568daa9fc5752.md)

## Rule

- **Rule:**
  ```text
  Per-result usage tracking under concurrency must report the model's total_tokens for each concurrent acall result.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  When modifying usage tracking or its test, preserve per-result total_tokens reporting for concurrent acall calls under track_usage.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cf66b18159d993dcceebb2d1.md)

## Rule

- **Rule:** Tests that exercise dspy.Predict must call it with keyword arguments matching the signature input fields; passing positional arguments is expected to raise ValueError with the message instructing keyword arguments.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** when modifying or adding tests that invoke dspy.Predict with arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f8667e1a8cdef74307c3d9c7.md)

## Rule

- **Rule:** Predict over a signature with datetime inputs and outputs must coerce ISO datetime strings returned by the LM into datetime objects.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying Predict output coercion or datetime field handling in prediction tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f91cdd6c18c3f1194879f94d.md)

## Rule

- **Rule:** Predict with a multi-output signature must return a result exposing each output field as an attribute (e.g., result.answer1, result.answer2).
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** Modifying Predict result construction or multi-output signature handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fc1ed7736ce4594ac25e42f1.md)
