# Constraints for `tests/evaluate/test_evaluate.py`

## Rule

- **Rule:**
  ```text
  Evaluate with a configured callback must fire start_call once with the program and end_call once with the score, pinning the evaluation callback lifecycle.
  ```
- **Applies to:**
  - `tests/evaluate/test_evaluate.py`
- **Condition:**
  ```text
  When modifying Evaluate callback behavior or its test, preserve one start_call with the program and one end_call with the score.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fa57e2374f857d8d7f898ecb.md)
