# Constraints for `tests/evaluate/test_metrics.py`

## Rule

- **Rule:**
  ```text
  answer_exact_match must return truthy when the example answer and prediction answer are equal strings.
  ```
- **Applies to:**
  - `tests/evaluate/test_metrics.py`
- **Condition:**
  ```text
  Modifying answer_exact_match string comparison semantics.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f184cd4a389c494e111f7365.md)
