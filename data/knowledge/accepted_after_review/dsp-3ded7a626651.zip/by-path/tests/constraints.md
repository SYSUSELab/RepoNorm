# Constraints for `tests`

## Rule

- **Rule:** Ruff linting/formatting applies to Python files under dspy/ and tests/ as included by the include setting.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0dcee3b53bd57970ff289f00.md)

## Rule

- **Rule:** Ruff targets Python 3.9 (py39).
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-2d6650935e929b1953204ac4.md)

## Rule

- **Rule:** Ruff uses an indent width of 4.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-74043d4617d605898fa09234.md)

## Rule

- **Rule:**
  ```text
  The test job runs extra tests via uv run -p .venv pytest tests/ -m extra --extra after syncing the test_extras extra.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7554fe9e5660ebaf1cb456a0.md)

## Rule

- **Rule:** Setuptools package discovery excludes the "tests" directory and its subpackages.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8b31f03cc40c5cf8956fb813.md)

## Rule

- **Rule:**
  ```text
  Ruff per-file ignores for tests/**/*.py disable S101, TID252, and ARG001.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-926e26e4c2626faf61975918.md)

## Rule

- **Rule:**
  ```text
  Tests expected to fail with certain models are marked using the `@known_failing_models` decorator, and such known failures are logged without affecting the overall test result.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-98a42165b9aba62d804f2774.md)

## Rule

- **Rule:** Ruff enforces a maximum line length of 120.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-9f0df2b307460032940ca8a0.md)

## Rule

- **Rule:** The test job runs pytest on the tests/ directory via uv run -p .venv pytest tests/.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-df71aa664d341e186bca9169.md)
