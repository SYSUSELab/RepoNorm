# Constraints for `tests/adapters/test_json_adapter.py`

## Rule

- **Rule:**
  ```text
  JSONAdapter must raise AdapterParseError on output-field mismatch, exposing adapter_name, signature, lm_response, and parsed_result attributes with parsed_result empty when no expected fields are found.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** Modifying JSONAdapter parse error handling or the AdapterParseError attribute contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0124f2ca50b87a42f47e4b8e.md)

## Rule

- **Rule:** JSONAdapter.format with tools must emit two messages, include ToolCalls.description in the system message, include tool names and argument type descriptions in the user message, and pass OpenAI-style function tool schemas to litellm.completion.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** Modifying JSONAdapter.format tool message construction or litellm.completion tool schema passing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-14649c59ca76f71e880006b9.md)

## Rule

- **Rule:**
  ```text
  JSONAdapter must format a dspy.Image input as a user message content list of exactly three chunks ordered text, image_url, text, with the image_url chunk shaped as {'type':'image_url','image_url':{'url':...}}.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** when modifying JSONAdapter image formatting or multimodal message construction
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-827e7031d843d6acdfaaa692.md)

## Rule

- **Rule:**
  ```text
  When a structured-output request fails, the JSON adapter must retry with a plain json_object response_format rather than reusing the Pydantic BaseModel response_format.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:**
  ```text
  Modifying the JSON adapter's structured-output retry path or its fallback response_format handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e8e7d2e2565ad29ec7853eb2.md)

## Rule

- **Rule:** Image-typed adapter tests must define a signature with an ImageWrapper input field and a str output field.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When adding or modifying an image-typed adapter test signature, include an ImageWrapper input field and a str output field.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ee106375a3083ed38b26ab84.md)
