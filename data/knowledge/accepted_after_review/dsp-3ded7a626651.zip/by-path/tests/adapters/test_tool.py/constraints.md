# Constraints for `tests/adapters/test_tool.py`

## Rule

- **Rule:**
  ```text
  dummy_function(x: int, y: str = 'hello') -> str is a documented test fixture with a default parameter, used to exercise tool signature handling.
  ```
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:**
  ```text
  When modifying tool signature handling tests or the dummy_function fixture.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0a01a503b59cdb7a92888c9d.md)

## Rule

- **Rule:**
  ```text
  Tests for the tool adapter must exercise deeply nested list-of-list pydantic model types as tool argument types via a dummy function taking list[list[DummyModel]].
  ```
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When adding or modifying tool adapter tests that cover nested pydantic model argument types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0e4bd481c977311c299a39a6.md)

## Rule

- **Rule:** Async tool invocations must remain concurrently executable: concurrent Tool.acall calls must complete within the pinned time budget and asyncio.gather must return results in task order.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying async tool invocation or concurrency behavior in the tool adapter tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2b4168b8d2aacc83f7b77a40.md)

## Rule

- **Rule:** Tool arguments typed as pydantic models must expose a JSON schema object with the model's properties, and acall must accept either a pydantic model instance or a dict.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying tool argument schema generation or acall input handling for pydantic-typed tools, preserve the JSON schema object shape and dual instance/dict acceptance.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-58f3a38178eac61dc9125d55.md)

## Rule

- **Rule:** Tool invocation must raise ValueError when a non-integer value is supplied for an int-typed argument.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** Modifying Tool argument type validation or the error raised for mismatched argument types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5a7759dad8c30d1bf7e1b75b.md)

## Rule

- **Rule:** Nested lists of dicts passed for pydantic-model-typed tool arguments must be coerced into nested lists of model instances.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying tool argument parsing for nested pydantic-typed arguments, preserve coercion of nested dict lists into nested model instance lists.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5f6612e93bed0b776c6207e1.md)

## Rule

- **Rule:** Tests that exercise DSPy tool construction from a function must assert that the tool name derives from the function name, description from the docstring, and args schema from the signature including type and default values.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** when adding or modifying tests that verify Tool construction from a Python function
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ca8af2ee2b01b57eee3115f3.md)

## Rule

- **Rule:** Tool.acall must filter kwargs to only those matching the wrapped function's signature, dropping extra keyword arguments (e.g. acall(x=1, y=2, z=3) returns only {'y':2,'z':3} for a function accepting y and z).
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** when modifying Tool.acall argument handling or async tool invocation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e7daa45bb8bc2366d2627177.md)
