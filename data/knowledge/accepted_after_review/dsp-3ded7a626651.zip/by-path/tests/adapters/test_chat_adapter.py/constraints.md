# Constraints for `tests/adapters/test_chat_adapter.py`

## Rule

- **Rule:**
  ```text
  ChatAdapter formatting with few-shot image examples must produce exactly 6 messages with image_url content blocks in user messages at indices 1, 3, and 5, and assistant messages containing the completed marker.
  ```
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** Modifying ChatAdapter message formatting for few-shot image examples or the completed marker placement.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6d28aab75b32365d36d7e43d.md)

## Rule

- **Rule:**
  ```text
  The chat adapter must format a signature with a two-message dspy.History into six messages, rendering history entries as [[ ## question ## ]]/[[ ## answer ## ]] blocks ending in [[ ## completed ## ]].
  ```
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** When modifying chat adapter message formatting or history rendering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bd9c1a9df76549b8ae2e1712.md)

## Rule

- **Rule:** ChatAdapter.acall must return the parsed adapter output list when awaited with a DummyLM.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** Modifying the async ChatAdapter call path or its return value contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eec49f657608791d951b8066.md)
