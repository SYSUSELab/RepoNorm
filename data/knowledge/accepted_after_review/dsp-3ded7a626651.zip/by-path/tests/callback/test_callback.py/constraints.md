# Constraints for `tests/callback/test_callback.py`

## Rule

- **Rule:** The LM end callback payload must expose handler, outputs, and exception keys so tests can assert the LM end event shape.
- **Applies to:**
  - `tests/callback/test_callback.py`
- **Condition:**
  ```text
  When modifying the on_lm_end handler or the LM end callback payload, preserve the handler/outputs/exception dict keys.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-033cfb32e61c24244a4b9b22.md)

## Rule

- **Rule:** Callbacks registered on a module must be invoked for both start and end events of a single forward call.
- **Applies to:**
  - `tests/callback/test_callback.py`
- **Condition:** Modifying callback invocation semantics or the number of callback invocations per forward call.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-40385ee0f6187e3cd8dc1c19.md)

## Rule

- **Rule:**
  ```text
  The callback test fixture must initialize parent_call_ids and call_ids lists to provide the state used to assert callback call-id relationships.
  ```
- **Applies to:**
  - `tests/callback/test_callback.py`
- **Condition:** When modifying callback test fixtures or call-id relationship assertions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9b575655cfedf04d4a950585.md)

## Rule

- **Rule:**
  ```text
  Tool-call callback ordering must follow on_module_start, on_tool_start, on_tool_end, on_tool_start, on_tool_end, on_module_end with exactly six callbacks for a two-tool invocation.
  ```
- **Applies to:**
  - `tests/callback/test_callback.py`
- **Condition:** When modifying tool-call callback emission or callback test expectations.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e393333e1135b4df31ea4e48.md)

## Rule

- **Rule:**
  ```text
  The on_lm_start callback must record the handler name, instance, and inputs, consistent with the callback recording convention.
  ```
- **Applies to:**
  - `tests/callback/test_callback.py`
- **Condition:**
  ```text
  Modifying the on_lm_start callback recording or its recorded fields.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ed0cc0d8f9ff082fd9b1a4c0.md)
