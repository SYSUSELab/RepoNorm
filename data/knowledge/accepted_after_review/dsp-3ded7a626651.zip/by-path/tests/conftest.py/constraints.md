# Constraints for `tests/conftest.py`

## Rule

- **Rule:**
  ```text
  The tests/conftest.py pytest_collection_modifyitems hook must skip tests marked with any flag in SKIP_DEFAULT_FLAGS unless the corresponding --<flag> command-line option is provided, and must return early once any such option is present.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When adding or modifying default-skip flags or the collection-modification hook in the test suite conftest.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-24306651c9d9acccf5a5f8f3.md)

## Rule

- **Rule:**
  ```text
  The anyio_backend fixture in conftest returns 'asyncio', so anyio-based async tests in this suite run on the asyncio backend; contributors adding async tests must not assume trio or other backends are exercised.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  when adding or modifying anyio-based async tests or the anyio_backend fixture
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-90146cb8171a22932bebe2b2.md)

## Rule

- **Rule:**
  ```text
  pytest_configure must register each flag in SKIP_DEFAULT_FLAGS as a pytest marker via config.addinivalue_line, so contributors adding opt-out flags must add them to SKIP_DEFAULT_FLAGS rather than registering markers ad hoc.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When adding or modifying an opt-out pytest flag or marker in the test configuration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-af1ea3c8b8b20edbdaf01e75.md)

## Rule

- **Rule:**
  ```text
  The autouse clear_settings fixture must reset dspy.settings to a deep copy of DEFAULT_CONFIG with inherit_config=False after every test, so tests must not rely on dspy settings persisting across test boundaries.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When writing or modifying tests that read or mutate dspy.settings and might otherwise depend on state from a previous test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c7562181cca5df56f8f305d7.md)
