# Constraints for `tests/teleprompt/test_copro_optimizer.py`

## Rule

- **Rule:** COPRO compile must return an optimized student that is not the same object as the input student, treating object identity change as the observable signal that optimization modified the program.
- **Applies to:**
  - `tests/teleprompt/test_copro_optimizer.py`
- **Condition:** Modifying COPRO compile optimization process or student program mutation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c3d2ea5716fed72f52f607fb.md)
