# Constraints for `tests/teleprompt/test_teleprompt.py`

## Rule

- **Rule:**
  ```text
  DummyTeleprompter.get_params() must return the constructor parameters as a dict, pinning the teleprompter parameter-introspection contract.
  ```
- **Applies to:**
  - `tests/teleprompt/test_teleprompt.py`
- **Condition:**
  ```text
  When modifying teleprompter parameter introspection or get_params behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c6fb50d6da0a3582758be58f.md)
