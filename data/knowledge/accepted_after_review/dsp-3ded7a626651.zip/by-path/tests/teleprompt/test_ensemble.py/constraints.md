# Constraints for `tests/teleprompt/test_ensemble.py`

## Rule

- **Rule:** Ensemble with a configured size must yield exactly that many outputs when compiled over more programs.
- **Applies to:**
  - `tests/teleprompt/test_ensemble.py`
- **Condition:** When modifying Ensemble size handling or its test, preserve that compile over more programs yields exactly size outputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-268ae7473a9b4c91e942c462.md)

## Rule

- **Rule:** Tests that exercise DSPy ensemble behavior must use a minimal dspy.Module subclass stand-in (e.g. MockProgram) rather than real programs, so ensemble logic is tested in isolation.
- **Applies to:**
  - `tests/teleprompt/test_ensemble.py`
- **Condition:** when adding or modifying ensemble tests that need a program stand-in
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a22791adaea9c65c71f40fcd.md)

## Rule

- **Rule:** Constructing Ensemble(deterministic=True) must raise AssertionError with a message about implementing example hashing, documenting that deterministic ensemble behavior is not yet implemented.
- **Applies to:**
  - `tests/teleprompt/test_ensemble.py`
- **Condition:** When modifying Ensemble deterministic behavior or example hashing in ensemble tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b56d3cc6278893ee1d9b6d77.md)
