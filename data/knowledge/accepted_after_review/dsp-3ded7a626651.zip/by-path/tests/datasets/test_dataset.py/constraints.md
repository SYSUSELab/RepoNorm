# Constraints for `tests/datasets/test_dataset.py`

## Rule

- **Rule:**
  ```text
  tests/datasets/test_dataset.py must define a CSV dummy_data string with content, question, and answer columns used as the dataset fixture.
  ```
- **Applies to:**
  - `tests/datasets/test_dataset.py`
- **Condition:**
  ```text
  When modifying dataset test fixtures or CSV dummy_data columns.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7e34db3747ef4abfe5394020.md)
