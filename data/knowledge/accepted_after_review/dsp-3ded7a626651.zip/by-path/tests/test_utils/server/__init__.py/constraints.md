# Constraints for `tests/test_utils/server/__init__.py`

## Rule

- **Rule:**
  ```text
  read_litellm_test_server_request_logs must read a LiteLLM server request-log jsonlines file and return one parsed dict per request, defining the log format used by DSPy integration tests.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** When modifying how integration tests read LiteLLM server request logs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2c8ee07cfadaf3fe398e5ea1.md)

## Rule

- **Rule:**
  ```text
  The test server package __init__ imports LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR from tests.test_utils.server.litellm_server, indicating the log-file path is configured through an environment variable shared across the test server utilities.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when modifying test server package exports or log-file path configuration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-66e553f916d67a668dea69b1.md)

## Rule

- **Rule:**
  ```text
  The test server helper allocates a free port by binding a socket to port 0 and reading getsockname, and _wait_for_port polls a TCP connection every 0.5 seconds until timeout, raising TimeoutError if the server never accepts; contributors modifying server test helpers must preserve this port-allocation and readiness contract.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when modifying test server port allocation or readiness polling helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-b0af98fcb33126fb7b0843c2.md)

## Rule

- **Rule:**
  ```text
  The litellm test server requires the LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR environment variable to be set; _append_request_to_log_file must raise ValueError when it is unset, and the litellm_test_server fixture must pass the request-log file path to the proxy subprocess via that env var.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
  - `tests/test_utils/server/litellm_server.py`
- **Condition:**
  ```text
  When modifying the litellm test server request-logging path or the litellm_test_server fixture that launches the proxy subprocess.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-f6e13730e17ffec30833f1cf.md)
