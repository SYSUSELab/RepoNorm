# Constraints for `tests/test_utils/server/litellm_server.py`

## Rule

- **Rule:** Tests that simulate LiteLLM provider failures must trigger the intended exception by embedding the corresponding status substring ('429', '504', '400', '401') in the first message content, because the test server maps those substrings to RateLimitError, Timeout, BadRequestError, and AuthenticationError respectively.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When adding or modifying a test that needs to simulate a specific LiteLLM provider failure.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-11cc881d706c875dc323c4d5.md)

## Rule

- **Rule:**
  ```text
  The test server's `astreaming` must yield a single GenericStreamingChunk with `is_finished=True` and `finish_reason='stop'`, encoding the payload as a JSON string in the `text` field.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When modifying the test server's streaming response shape.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-4ecb54a76be3d8f07d661543.md)

## Rule

- **Rule:**
  ```text
  The mock LLM server's _get_mock_llm_response calls _throw_exception_based_on_content_if_applicable before returning a litellm.completion with mock_response='Hi!' and fixed token usage, so tests can trigger exceptions by request content.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying the mock LLM server response behavior or content-based exception triggering
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-c78c8d08c95f97506f05eb17.md)

## Rule

- **Rule:**
  ```text
  The mock LiteLLM server's completion method must log every request via _append_request_to_log_file(kwargs) before returning a mock response, so tests can assert on persisted request payloads; contributors modifying the mock server must preserve this logging.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying the mock LiteLLM server's completion handling or request logging
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-d24ed657239ad602f6c0182e.md)

## Rule

- **Rule:**
  ```text
  The litellm test server requires the LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR environment variable to be set; _append_request_to_log_file must raise ValueError when it is unset, and the litellm_test_server fixture must pass the request-log file path to the proxy subprocess via that env var.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
  - `tests/test_utils/server/litellm_server.py`
- **Condition:**
  ```text
  When modifying the litellm test server request-logging path or the litellm_test_server fixture that launches the proxy subprocess.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-f6e13730e17ffec30833f1cf.md)
