# Constraints for `tests/test_utils/server/litellm_server_config.yaml`

## Rule

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model-2" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-007397d83d5b29a36480a469.md)

## Rule

- **Rule:**
  ```text
  The litellm test server config sets num_retries to 0.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-0d9e6fe6820362358e041db7.md)

## Rule

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-73751b598d3462641612b4df.md)
