# Constraints for `tests/retrievers/test_embeddings.py`

## Rule

- **Rule:** Tests that exercise Embeddings retrieval must assert that Embeddings(corpus, embedder, k=1) returns list-typed passages and indices of length 1, and that the top passage for a query matches the expected corpus entry.
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** when modifying or adding tests for Embeddings retrieval
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1b670b9fc424a14fef54e081.md)

## Rule

- **Rule:**
  ```text
  Embeddings(corpus, embedder, k=1) queries run through a ThreadPoolExecutor(max_workers=10) must preserve original query order in results.
  ```
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** When modifying Embeddings retriever concurrency or result ordering in retriever tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2b352cb53daa38dc79766add.md)
