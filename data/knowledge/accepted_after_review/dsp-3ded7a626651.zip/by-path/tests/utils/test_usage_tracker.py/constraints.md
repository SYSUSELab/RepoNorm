# Constraints for `tests/utils/test_usage_tracker.py`

## Rule

- **Rule:**
  ```text
  UsageTracker.add_usage must accumulate per-model usage entries as a list, preserving previously stored keys when a later add_usage call supplies different keys for the same model.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:**
  ```text
  When modifying UsageTracker.add_usage or get_total_tokens behavior exercised by the usage-tracker tests, per-model usage entries must be stored as a list under the model key, and get_total_tokens must return per-model totals matching the added entries; the merge-preserves-unseen-keys behavior is not established by the supplied evidence.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7f73b2911ce328ac49753f35.md)

## Rule

- **Rule:**
  ```text
  UsageTracker token aggregation must sum prompt_tokens, completion_tokens, total_tokens, and all nested prompt_tokens_details/completion_tokens_details subfields per model across multiple add_usage calls, while skipping None-valued detail entries and summing non-None detail dicts including nested keys like cached_tokens and reasoning_tokens.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:** When modifying UsageTracker aggregation or merge behavior for token usage entries.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a5b1c21756f24f18e9ac4782.md)

## Rule

- **Rule:**
  ```text
  The usage-tracker context-manager test must remain gated on the OPENAI_API_KEY environment variable so it is skipped without a live key.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:**
  ```text
  When modifying test_track_usage_context_manager or its skip/gating decorators.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc861a07755eedaed13be373.md)
