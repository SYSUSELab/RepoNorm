# Constraints for `tests/utils/test_asyncify.py`

## Rule

- **Rule:** The asyncify test helper must sleep for a given wait and return 42, used to exercise async wrapping of blocking calls.
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** When modifying the asyncify test helper that exercises async wrapping of blocking calls.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a54beebcfcdb92c22beb739c.md)

## Rule

- **Rule:**
  ```text
  The async limiter is a singleton whose capacity is adjusted by dspy.context(async_max_workers=...); context changes must mutate the existing AsyncLimiter instance's capacity rather than replacing the instance.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:**
  ```text
  when modifying get_limiter or the async_max_workers context handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc7bde3dd6b4d95ee890623e.md)

## Rule

- **Rule:**
  ```text
  The asyncify test must wrap a sync function with dspy.asyncify and await verify_asyncify with multiple concurrency/size parameter pairs, asserting asyncify preserves behavior under varying concurrency.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** When modifying asyncify behavior or its concurrency/size parameter coverage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d04428a0abb6847e92cf4446.md)
