# Constraints for `tests/utils/test_saving.py`

## Rule

- **Rule:**
  ```text
  test_save_custom_model asserts that after model.save(tmp_path, save_program=True) and dspy.load(tmp_path), the loaded object is a CustomModel with the same number of predictors and each predictor's signature equal to the original; contributors modifying save/load must preserve this fidelity contract.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when modifying model save/load behavior or tests asserting round-trip fidelity
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-39c42b58bba77ae7c9d6faa4.md)

## Rule

- **Rule:**
  ```text
  test_save_predict asserts that saving a dspy.Predict with save_program=True produces metadata.json and program.pkl, and that dspy.load restores a Predict with an equal signature, defining the on-disk save format contract.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when modifying program save/load behavior or on-disk save format
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4f87baf31c422211daae9738.md)

## Rule

- **Rule:** The test logging handler's emit appends record.getMessage() to self.messages, the convention used to capture emitted log messages for assertions in saving tests.
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when modifying log capture helpers or assertions in saving tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b25c7c2aabdf8723f9bdd30b.md)

## Rule

- **Rule:**
  ```text
  The save/load round-trip invariant requires that after compiled_predict.save(tmp_path, save_program=True) and dspy.load(tmp_path), the loaded predictor's demos and signature equal the compiled predictor's, and that loading a program saved under different python/dspy/cloudpickle versions logs exactly three warnings containing 'There is a mismatch of' while still loading the model with an equal signature.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** When modifying save/load behavior or the tests that assert round-trip equality and version-mismatch warning behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cbd90a987a4430a9b3488099.md)

## Rule

- **Rule:**
  ```text
  Tests for predict.save/load round-trips must assert that a loaded object is a dspy.Predict whose signature equals the original, including instructions set via with_instructions.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when adding or modifying a test that exercises predict.save and dspy.load for custom signatures
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d6f401e3734840c717958993.md)
