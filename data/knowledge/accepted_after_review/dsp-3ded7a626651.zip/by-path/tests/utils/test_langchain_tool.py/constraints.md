# Constraints for `tests/utils/test_langchain_tool.py`

## Rule

- **Rule:**
  ```text
  The langchain tool conversion contract requires convert_langchain_tool to map a LangChain tool's name, description, args JSON schema (with required fields), arg_types (mapping to the Pydantic class), and arg_desc, and the converted tool's acall must return the expected value.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:**
  ```text
  When modifying convert_langchain_tool or the tests that assert its conversion contract for LangChain tools.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0ca0f6504d4859fa2ddffe6b.md)

## Rule

- **Rule:**
  ```text
  Tests that require the optional langchain_core dependency must guard the module with importlib.util.find_spec('langchain_core') and call pytest.skip(allow_module_level=True) when it is absent, so the suite remains runnable without that optional package.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:**
  ```text
  when adding or modifying tests that import langchain_core or other optional third-party packages
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4bffa50037b0074b48dd62d3.md)
