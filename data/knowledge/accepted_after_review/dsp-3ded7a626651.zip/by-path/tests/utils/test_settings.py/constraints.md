# Constraints for `tests/utils/test_settings.py`

## Rule

- **Rule:**
  ```text
  `dspy.configure` must raise RuntimeError matching `dspy.settings.configure(...) cannot be called a second time from*` when called twice, while `dspy.context(...)` remains allowed.
  ```
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** When modifying settings configuration guards or tests for repeated configure calls.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-374fdd11818725fa9242cd2a.md)

## Rule

- **Rule:** dspy.context must temporarily override global settings (lm, callbacks) within the with-block and restore the prior configuration on exit, so nested or parallel configuration changes do not leak; contributors modifying context handling must preserve this isolation.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying dspy.context behavior or tests that assert settings isolation across nested or thread-parallel scopes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-49685b8b6df91a0b561468a6.md)

## Rule

- **Rule:** Tests that exercise dspy.Parallel must assert per-input context isolation: each parallel input runs under its own dspy context (its own configured LM), and the main thread's dspy.settings.lm is unchanged after parallel execution.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that runs dspy.Parallel with per-input LM configuration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-523445812b909a7dce92a829.md)

## Rule

- **Rule:** dspy.configure raises RuntimeError with message 'Cannot call dspy.configure in a child thread', enforcing that configuration is only allowed on the main thread.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying dspy.configure thread-safety behavior or related tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-82be47797af820a1a6308760.md)

## Rule

- **Rule:** dspy.configure must set dspy.settings.lm.model, install the provided adapter instance, and store the provided callbacks list; contributors changing configure must preserve these observable settings effects.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying dspy.configure or tests asserting its effects on settings.lm, adapter, and callbacks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f59522263f477775a064e18d.md)

## Rule

- **Rule:**
  ```text
  Tests exercising dspy.context(lm=..., trace=[]) with async forwards must assert that dspy.settings.lm.model matches the context lm.model and that len(dspy.settings.trace) == 1 after predict.acall, preserving context-scoped LM and trace isolation across awaits.
  ```
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** When adding or modifying tests for dspy.context LM and trace isolation across async awaits.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fd5afc549f1700cfdf14dfa9.md)
