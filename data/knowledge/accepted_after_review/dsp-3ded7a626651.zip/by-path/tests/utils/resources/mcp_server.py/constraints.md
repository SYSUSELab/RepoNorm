# Constraints for `tests/utils/resources/mcp_server.py`

## Rule

- **Rule:**
  ```text
  get_account_name must be registered as an MCP tool via the @mcp.tool() decorator and extract the name from an Account's profile, defining the tool's input schema and return value.
  ```
- **Applies to:**
  - `tests/utils/resources/mcp_server.py`
- **Condition:**
  ```text
  when modifying the MCP test server's tool registration or get_account_name behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-0c1cc353c66612fb874cccb5.md)

## Rule

- **Rule:**
  ```text
  The MCP test server must define an Account model whose profile field is a nested Profile model and account_id is a string, establishing the expected nested-object shape for MCP tool responses in tests.
  ```
- **Applies to:**
  - `tests/utils/resources/mcp_server.py`
- **Condition:** When modifying MCP test server models or nested-object response shapes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-44bc5f9bb535f4cd95281cd7.md)

## Rule

- **Rule:**
  ```text
  The MCP test server must define a wrong_tool that always raises ValueError, providing a fixture for testing error handling of failing MCP tools.
  ```
- **Applies to:**
  - `tests/utils/resources/mcp_server.py`
- **Condition:** when modifying or adding MCP test server tools for error-handling tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-54236012c900b42f6d9497ae.md)
