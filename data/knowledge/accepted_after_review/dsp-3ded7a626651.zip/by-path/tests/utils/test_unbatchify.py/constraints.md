# Constraints for `tests/utils/test_unbatchify.py`

## Rule

- **Rule:**
  ```text
  The unbatchify test harness submit method must enqueue (input_item, future) onto input_queue and return the Future, and the timeout test must assert that with max_batch_size=5 and max_wait_time=0.15 two submitted items are not processed before the wait elapses and are then flushed together in a single batch_fn call with [100,200] returning [101,201].
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** When adding or modifying unbatchify test harness submission or timeout-trigger tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2a1f227c66dd31837c0750a6.md)

## Rule

- **Rule:**
  ```text
  Unbatchify must not invoke batch_fn after a single submit, must invoke it exactly once when max_batch_size is reached, and must form a new batch for subsequent submits.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** When modifying Unbatchify batching behavior or its size-triggered flush logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95815b2f64418e740d58d139.md)
