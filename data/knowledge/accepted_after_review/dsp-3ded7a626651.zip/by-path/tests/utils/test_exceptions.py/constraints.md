# Constraints for `tests/utils/test_exceptions.py`

## Rule

- **Rule:** AdapterParseError message format must include adapter name, LM response, expected output fields, and actual parsed fields, as asserted exactly by tests.
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:** When modifying AdapterParseError message construction or the exception test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-20fd0363e9fbba468075c210.md)

## Rule

- **Rule:**
  ```text
  Tests/utils/test_exceptions.py must import AdapterParseError from dspy.utils.exceptions, establishing that module as the public location for adapter parse errors.
  ```
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:** When adding or modifying tests for adapter parse errors or their import surface.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ec861a937c0d4c561dd44f76.md)

## Rule

- **Rule:** AdapterParseError string formatting must include the adapter name, the LM response, and the list of expected output fields, and must append a custom message when one is supplied.
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:**
  ```text
  When modifying AdapterParseError construction or its __str__/message formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f0b96872d76c2668d060a561.md)
