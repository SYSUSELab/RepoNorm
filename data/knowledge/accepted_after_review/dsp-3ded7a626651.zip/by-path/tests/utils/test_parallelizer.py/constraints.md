# Constraints for `tests/utils/test_parallelizer.py`

## Rule

- **Rule:**
  ```text
  ParallelExecutor speed tests must assert that executing N tasks with num_threads=5 completes in less wall-clock time than the number of data items.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** when adding or modifying a test that validates ParallelExecutor throughput
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-253b83765119cb60731c29bc.md)

## Rule

- **Rule:**
  ```text
  ParallelExecutor with max_errors=1 must raise an exception matching 'Execution cancelled due to errors or interruption.' when errors exceed the limit, defining the cancellation error contract that tests and callers rely on.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** When modifying ParallelExecutor error handling or the cancellation error message.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-57b0a67862dd2fb05bf61897.md)

## Rule

- **Rule:** The parallelizer test task raises ValueError('Intentional error') when item equals 3 and otherwise returns the item, defining the error-propagation case exercised by the parallelizer tests.
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** when modifying parallelizer error-propagation tests or their task fixtures
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8ca982b7b4c7797b3e1da9bf.md)

## Rule

- **Rule:**
  ```text
  ParallelExecutor with max_errors must return results with None in the failed task's position rather than raising when failures are below the threshold, preserving input order; the parallelizer test task must raise ValueError for the designated failing item to exercise this propagation behavior.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** When adding or modifying parallelizer error-tolerance tests or the failing-task behavior they exercise.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-982be6534c599e3a2382f770.md)
