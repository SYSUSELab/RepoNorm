# Constraints for `tests/signatures/test_custom_types.py`

## Rule

- **Rule:**
  ```text
  When a Signature string references a custom type, the input field annotation must resolve to that custom type whether or not custom_types is explicitly supplied.
  ```
- **Applies to:**
  - `tests/signatures/test_custom_types.py`
- **Condition:**
  ```text
  Modifying Signature custom type resolution or the custom_types parameter handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1af5b42d9823f41e851013b1.md)

## Rule

- **Rule:** Custom signature types in tests must be modeled as pydantic BaseModel subclasses with the expected fields.
- **Applies to:**
  - `tests/signatures/test_custom_types.py`
- **Condition:** When adding a custom signature type to the custom types test, define it as a pydantic BaseModel subclass.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95231c68c4dc8882663179b7.md)
