# Constraints for `tests/signatures/test_signature.py`

## Rule

- **Rule:** Signature equality via sig1.equals(sig2) must treat signatures with different input/output names as unequal.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When modifying Signature equality or comparison behavior in signature tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a9315afc7e70560c37b8a5f.md)

## Rule

- **Rule:**
  ```text
  When a Signature is constructed from a string or dict, field annotations must be preserved exactly as declared, including typing generics such as List[str], Dict[str, int], and Tuple[int, float].
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** Modifying Signature construction from string or dict field declarations.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a9c2c621410fdea1a60cd96.md)

## Rule

- **Rule:**
  ```text
  Typed signature annotations must preserve nested origins: List[Union[str, int]] yields a list origin with a Union arg, and Tuple[int, Optional[float], List[str]] yields a tuple origin with int, Union[float, None], and list[str] args.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When modifying typed signature annotation parsing or nested type origin handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-46c198c8ecf4e0a0bf0c7119.md)

## Rule

- **Rule:**
  ```text
  A Signature created from a string like 'a, b -> c' must receive the default instructions 'Given the fields `a`, `b`, produce the fields `c`.'.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When modifying Signature string parsing or default instruction generation in signature tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-69385308134ad424b09d1cdb.md)

## Rule

- **Rule:** When a signature is constructed from a dict of InputField/OutputField instances, fields without an explicit annotation must default to str.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** Modifying dict-based Signature construction or the default annotation applied to InputField/OutputField entries.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-71aa2d5ebf76d25d2411a4c9.md)

## Rule

- **Rule:**
  ```text
  Field constraints declared on Signature fields must be surfaced in output_fields[name].json_schema_extra['constraints'] as human-readable strings such as 'minimum length: 5' and 'greater than or equal to: 5'.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:**
  ```text
  Modifying Signature field constraint serialization or json_schema_extra population.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a70e71a386ca65f861b7a587.md)

## Rule

- **Rule:**
  ```text
  Signature string parsing must treat comma-separated names before '->' as input fields and names after '->' as output fields.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** Modifying Signature string parsing or the arrow/comma field-splitting convention.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cbff5bcbb21b34592bcccf9c.md)

## Rule

- **Rule:**
  ```text
  infer_prefix must convert camelCase, snake_case, acronyms (URL, HTTP, HTTPS), and embedded digits into space-separated title-cased words (e.g. 'someAttributeName42IsCool' -> 'Some Attribute Name 42 Is Cool').
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:**
  ```text
  when modifying infer_prefix or its prefix-inference behavior for signature field names
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e75538d3f4f03e0647bc6fba.md)

## Rule

- **Rule:**
  ```text
  Signature.prepend and Signature.append must place new input fields at the first and last positions of input_fields respectively, and likewise place new output fields at the first and last positions of output_fields.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** when modifying Signature.prepend/append or field-ordering behavior for input and output fields
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f0785d5e795c812cd67ba324.md)

## Rule

- **Rule:** Signature field declaration order must be preserved in Signature.fields, including when fields mix InputField/OutputField annotations with plain annotations.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When modifying Signature field collection or annotation handling in signature tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f0e9977e98b9ac0789ddc547.md)

## Rule

- **Rule:** Tests for multiline instruction handling must configure a DummyLM with a fixed response and assert that dspy.Predict over the signature returns that output end-to-end.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When adding or modifying tests that verify multiline instruction handling through dspy.Predict
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fd9d9e4482f12b0ec3b5de5b.md)
