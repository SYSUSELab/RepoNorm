# Constraints for `tests/signatures/test_adapter_image.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise image encoding with download_images=True must assert that the produced data URI contains the expected MIME type and the ';base64,' marker, using substring matching to tolerate MIME parameters.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:**
  ```text
  when modifying or adding tests for image encoding with download_images
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-271794c6a8f360d216265d90.md)

## Rule

- **Rule:**
  ```text
  count_messages_with_image_url_pattern must match messages requiring type == "image_url" and a string url, and must return 0 on any exception so image-presence assertions tolerate malformed messages.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** Modifying the image-url message counting helper or its exception tolerance.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-50ae5f2eb5fd938bcf0bd600.md)

## Rule

- **Rule:** PDF signature tests must declare a dspy.Image input field to carry PDF document inputs.
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** Modifying PDF signature tests or the field type used to carry PDF inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-857e9c6cbed46006145bcfe4.md)

## Rule

- **Rule:** Tests that exercise dspy optional image fields must assert that passing image=None yields the expected output and that LM history contains zero messages with an image URL pattern, verifying optional images are omitted from requests.
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** When modifying tests for optional image fields in signatures or adapters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95a50210b12af8282dafb96a.md)

## Rule

- **Rule:**
  ```text
  Image input handling must accept dspy.Image inputs with and without download and produce exactly one image URL message, while PIL Image and encoded PIL image string inputs remain unsupported without dspy.from_PIL.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** Modifying image input format handling or dspy.Image message construction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae11353eb51046ce2fc4b229.md)

## Rule

- **Rule:**
  ```text
  dspy.Image.from_url with download=True on a PDF URL must produce a data URI containing 'data:application/pdf' and ';base64,', and using the image in a predictor must yield exactly one image-url message with application/pdf present.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:**
  ```text
  Modifying dspy.Image.from_url download handling for PDF URLs or the predictor message produced for such images.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e46baab11ed3d1cefae2658c.md)

## Rule

- **Rule:**
  ```text
  Image string representation must wrap image_url dicts between <<CUSTOM-TYPE-START-IDENTIFIER>> and <<CUSTOM-TYPE-END-IDENTIFIER>> markers, repr must be Image(url='...'), and PIL images must serialize with base64.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** Modifying Image serialization, repr, or PIL image encoding.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e50d041f28484b744b0fb621.md)
