# Constraints for `tests/reliability/generate/__main__.py`

## Rule

- **Rule:**
  ```text
  The reliability test generator CLI in tests/reliability/generate/__main__.py must expose required --dst_path and optional --num_inputs (default 1), --program_instructions, and --input_instructions, so contributors extending the generator must preserve this interface.
  ```
- **Applies to:**
  - `tests/reliability/generate/__main__.py`
- **Condition:** When adding or modifying the reliability test generator CLI arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-be1909154193e3fce116a76d.md)
