# Constraints for `tests/reliability/generate/utils.py`

## Rule

- **Rule:**
  ```text
  _TestInputsGeneration must define inputs program_description, program_input, and program_output_signature (JSON Schema format) and output output_assertions: List[str], with the docstring instructing about 5 natural-language objective assertions and blank when accurate assertions are difficult.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _TestInputsGeneration or the assertion-generation signature.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-0472f9451a9fcf3c4eaba060.md)

## Rule

- **Rule:**
  ```text
  Reliability generated-case execution must load the generated program, convert JSON input via _json_input_to_program_input, run under global DSPy configuration, and assert each output assertion through assert_program_output_correct.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying run_generated_case or the generated-case execution path in reliability tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-20586a1c979182dca4c5ef2e.md)

## Rule

- **Rule:**
  ```text
  _clean_schema must recursively strip __dspy_field_type and title keys from JSON schema properties, including nested dicts, so generated schemas omit DSPy-internal and title metadata.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _clean_schema or schema-cleaning behavior used by reliability tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-20cc42f31b8bfaa2ca35904a.md)

## Rule

- **Rule:**
  ```text
  load_generated_cases must recursively walk a directory and treat a directory as a test case only when it contains both program.py and an inputs subdirectory, loading each .json input and deriving the case name from the enclosing directory, root basename, and input filename.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying load_generated_cases or the generated-case directory layout it consumes
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-21d033c7be2b9fdb4f6ef201.md)

## Rule

- **Rule:**
  ```text
  Reliability-suite generated-program artifacts must expose a module-level `program` callable and a `ProgramInputs` type, and `load_generated_program` must resolve a directory to `program.py`, raise ValueError when the file is absent, and return that pair; generated test inputs must be validated against the program input schema before being written.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the reliability test-generation utilities that load or emit generated programs and their test inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2215e615593b420471d8bc4d.md)

## Rule

- **Rule:**
  ```text
  Reliability test JSON schemas are produced by calling signature.schema(), moving $defs into definitions, and recursively inlining $ref entries from #/$defs/ while preserving the __dspy_field_type marker, so the returned schema contains no $defs.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying JSON schema generation or $ref expansion for reliability tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2acabe7afbf87d02fa15230f.md)

## Rule

- **Rule:**
  ```text
  generate_test_program must retry up to 5 times with caching disabled and temperature=0.5, rename conflicting output fields, validate the generated program by loading it before copying to dst_path, and write a cleaned schema.json; contributors modifying generation must preserve these retry, validation, and cleanup steps.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying the reliability test-program generation pipeline or its retry and validation behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-303a8db5f8d883c8948e510c.md)

## Rule

- **Rule:** The reliability test utility that strips comments must remove only lines whose stripped form starts with '#', preserving inline trailing comments, and rewrite the file in place.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the reliability test utility that removes comments from generated files.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-321390807e374c62ecdd7564.md)

## Rule

- **Rule:**
  ```text
  Reliability test-input generation must use dspy.ChainOfThought over the _TestInputsGeneration signature.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _get_test_inputs_generation_program or the test-input generation program construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-45c9a806928a5e815266c079.md)

## Rule

- **Rule:** Generated reliability programs are imported by temporarily prepending the program's directory to sys.path while loading the module via importlib spec, and sys.path is fully restored in a finally block even on exceptions.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying program module loading or sys.path manipulation for generated reliability programs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-606f82bdea4ffa07e259a2c1.md)

## Rule

- **Rule:**
  ```text
  The reliability generation utilities require assertion-generation programs to be built via dspy.ChainOfThought over a _TestInputsGeneration signature, and the retry decorator must return a wrapper that forwards calls, establishing the code-generation and judging pipeline for reliability tests.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the reliability assertion-generation program construction or the retry decorator in the generation utilities.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-6e17b3c7cc84e46dc93cad5f.md)

## Rule

- **Rule:**
  ```text
  rename_conflicting_fields must append '_output' to any output property whose name collides with an input property and update the output schema's required list accordingly, so contributors adding schema fields must not introduce input/output name clashes without this renaming.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When adding or modifying input/output schema fields in the reliability test generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-93672ab99c615379fe5bf1ff.md)

## Rule

- **Rule:**
  ```text
  generate_test_inputs must be wrapped with @_retry(retries=5) and disable caching with temperature=0.5 so retries produce fresh inputs when generation fails.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying generate_test_inputs or its retry/caching behavior in reliability tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-9f1315da91a24439a1f974e5.md)

## Rule

- **Rule:**
  ```text
  _json_input_to_program_input must parse a JSON string, validate it against a pydantic input schema via model_validate, and return a dict built from program_input.__fields__ so keys follow the pydantic model's declared fields.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _json_input_to_program_input or JSON-to-program-input conversion in reliability tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-b0862cf62683d58e9d9126ba.md)

## Rule

- **Rule:**
  ```text
  _remove_line_from_file must rewrite the file keeping only lines whose stripped form differs from line_to_remove, so removal matches on stripped content and drops all matching lines.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying _remove_line_from_file or its callers
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-caa006b5747f4d1ee89b6263.md)

## Rule

- **Rule:**
  ```text
  Reliability test JSON output is serialized with 4-space indentation via _write_pretty_json, which writes to a path and returns None when a path is given, or returns the formatted string when no path is provided.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when writing or modifying JSON serialization helpers for reliability tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-d93433affe1f63185497293a.md)

## Rule

- **Rule:**
  ```text
  The reliability generator must randomly choose between dspy.ChainOfThought and dspy.Predict and build the signature by appending InputField/OutputField from ProgramInputs/ProgramOutputs model_fields.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the generated-program construction protocol in reliability tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-e585e7d96d0401771a7c1946.md)

## Rule

- **Rule:** The reliability test utility must build its program-generation program as dspy.ChainOfThought(ProgramGeneration), so contributors changing program generation must keep ChainOfThought over the ProgramGeneration signature.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying how reliability test programs are generated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-e793927773a722f9d700bfd0.md)

## Rule

- **Rule:**
  ```text
  generate_models must invoke datamodel-code-generator with enum_field_as_literal='one', field_constraints=True, use_annotated=False, then strip 'from __future__ import annotations' and generated comments to keep compatibility with built-in type hints.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying generate_models or the datamodel-code-generator invocation it performs
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-ea3282db51f0d9b6f60b0684.md)

## Rule

- **Rule:**
  ```text
  Reliability-suite JSON-schema handling must strip `desc`, `__dspy_field_type`, `title`, `prefix`, and `required` keys recursively from schema properties, and `ProgramGeneration` outputs must be valid JSON Schema strings without backticks or extra text.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying reliability-suite schema-cleaning or program-generation signature definitions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-eacbb954de320171f7ea4ed4.md)

## Rule

- **Rule:**
  ```text
  The reliability generate utils must expose a _retry(retries) decorator that retries the wrapped function a specified number of times before failing, and _split_schema must categorize JSON schema properties by the __dspy_field_type marker, sending "input" to inputs and "output" or missing to outputs, recursively splitting and merging nested properties into the parent's inputs/outputs.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When adding or modifying retry behavior or schema splitting in the reliability generate utilities.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-fcd518e13a430ff94e1b57a1.md)
