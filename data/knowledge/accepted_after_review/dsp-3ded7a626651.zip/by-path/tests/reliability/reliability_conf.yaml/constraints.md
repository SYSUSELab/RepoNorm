# Constraints for `tests/reliability/reliability_conf.yaml`

## Rule

- **Rule:** The reliability test configuration sets adapter to chat.
- **Applies to:**
  - `tests/reliability/reliability_conf.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-430484a74890aa525277a2cd.md)

## Rule

- **Rule:**
  ```text
  The reliability test configuration defines a model_list whose entries include model_name values judge, gpt-4o, gpt-4o-mini, gpt-4-turbo, gpt-o1, gpt-o1-mini, claude-3.5-sonnet, claude-3.5-haiku, gemini-1.5-pro, gemini-1.5-flash, llama-3.1-405b-instruct, llama-3.1-70b-instruct, llama-3.1-8b-instruct, llama-3.2-3b-instruct, and deepseek-r1.
  ```
- **Applies to:**
  - `tests/reliability/reliability_conf.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e29024b9d7cd8870baf77eb6.md)
