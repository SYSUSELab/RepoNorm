# Constraints for `tests/reliability/test_generated.py`

## Rule

- **Rule:**
  ```text
  Generated reliability cases are loaded relative to the test directory via _DIR_PATH computed from the test file location, using load_generated_cases and run_generated_case from tests.reliability.generate.utils; contributors moving or adding generated cases must keep them resolvable relative to the test file.
  ```
- **Applies to:**
  - `tests/reliability/test_generated.py`
- **Condition:** when adding, moving, or modifying generated reliability cases or the test harness that loads them
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8c6296c783e76abfe85377d9.md)
