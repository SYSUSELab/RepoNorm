# Constraints for `tests/reliability/utils.py`

## Rule

- **Rule:** The reliability judge program must define JudgeResponse as a pydantic BaseModel with a boolean correct field and a string justification field, and judge outputs must conform to that shape.
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When adding or modifying the reliability judge program or its expected output schema.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-15ca5ab153054589d91c7024.md)

## Rule

- **Rule:**
  ```text
  judge_dspy_configuration loads reliability_conf.yaml relative to the test module, raises ValueError when the judge model has no LiteLLM configuration, and applies the judge LM plus adapter via dspy.settings.context.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when modifying reliability test judge configuration or LiteLLM adapter setup
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-433e07b064d6670641d62520.md)

## Rule

- **Rule:** The reliability judge program must be dspy.Predict over JudgeSignature.
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  When modifying _get_judge_program or the reliability judge construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44d355ba105b702758af4985.md)

## Rule

- **Rule:**
  ```text
  The reliability test utilities require JudgeSignature to take program_input, program_output, and guidelines as InputFields and return a JudgeResponse OutputField, with the docstring instructing the judge to consider only the provided guidelines when determining correctness, and JUDGE_MODEL_NAME = 'judge' as the fixed model identifier.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When modifying the reliability judge signature, judge model identifier, or the utilities that build the judge program.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-619549f8fcaaa47e42701fbb.md)

## Rule

- **Rule:**
  ```text
  Reliability-suite grading must normalize `grading_guidelines` to a list and, under `judge_dspy_configuration`, assert each LLM-judge response is correct with the justification included in the failure message.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When modifying reliability-suite grading helpers that evaluate program outputs against guidelines.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6d01d5e435df5d444578a8f2.md)

## Rule

- **Rule:**
  ```text
  Reliability harness adapter selection must map reliability_conf.adapter case-insensitively to exactly ChatAdapter or JSONAdapter, and must raise ValueError naming the unknown adapter and reliability_conf.yaml for any other value.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When adding or modifying adapter resolution in the reliability harness or introducing a new adapter name.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c76d92a483d1bf5da5633431.md)

## Rule

- **Rule:**
  ```text
  The reliability test utility decorator must return a wrapper that forwards *args/**kwargs unchanged to the wrapped test function, preserving the original call signature for parameterized reliability tests.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When modifying the reliability test utility decorator that wraps parameterized reliability tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c9495d107adeb5c9efb66d54.md)

## Rule

- **Rule:**
  ```text
  parse_reliability_conf_yaml is lru_cache'd, requires each model_list entry to have a model_name, requires an adapter key, and wraps any failure in a ValueError naming the config file path; contributors changing reliability config parsing must preserve these validation and error-reporting behaviors.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  when modifying reliability config parsing or the YAML schema for model_list entries
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e0e25c043b37fa99fdc120b0.md)
