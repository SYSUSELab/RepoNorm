# Constraints for `tests/reliability/complex_types/generated/test_many_types_1/program.py`

## Rule

- **Rule:** Complex-types reliability programs must define a BaseSignature whose docstring describes the intended input/output domain of tuples, enums, datetimes, literals, and nested objects.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
- **Condition:** When adding or modifying a complex-types reliability program, define BaseSignature with a docstring covering the intended complex input/output domain.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-c07c6a25a40265534728cb8c.md)
