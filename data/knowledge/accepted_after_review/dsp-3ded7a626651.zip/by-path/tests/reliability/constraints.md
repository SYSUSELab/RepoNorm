# Constraints for `tests/reliability`

## Rule

- **Rule:**
  ```text
  Running `python -m tests.reliability.generate -d <dir> -p <program description> -i <input description>` from the DSPy repository root generates a test program and test inputs into the specified directory.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../claims/CLAIM-03fc0275050ed318aaeab809.md)

## Rule

- **Rule:**
  ```text
  Running `pytest .` in the tests/reliability directory executes all tests for the configured models and displays detailed results for each model configuration.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4bfa8205aaf97b05bef800b9.md)

## Rule

- **Rule:**
  ```text
  Ruff excludes dspy/__metadata__.py, dspy/retrieve/*.py, tests/reliability/*.py, and tests/retrieve/*.py from its checks.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `dspy/retrieve/*.py`
  - `tests/reliability/*.py`
  - `tests/retrieve/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b4a63c36333829d1765e1a4.md)

## Rule

- **Rule:**
  ```text
  All generated tests should be located in directories with the structure `tests/reliability/<test_type>/generated/<test_name>`, where `<test_type>` is the test type (e.g., `classification`, `complex_types`, `chat`) and `<test_name>` is a descriptive test name.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../claims/CLAIM-a148d9146e22eed83552d62a.md)

## Rule

- **Rule:**
  ```text
  Test DSPy programs and test inputs can be generated from text descriptions using the `tests.reliability.generate` CLI or the `tests.reliability.generate.generate_test_cases` API.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b3fef731206ef9be5abb52e6.md)

## Rule

- **Rule:**
  ```text
  Run a single generated reliability test by invoking pytest on test_generated.py with a -k expression matching the test name.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-baabd45532a390888a9fafd9.md)

## Rule

- **Rule:** Reliability tests mark expected failures for known challenging cases where a specific model might struggle, while actual (unexpected) DSPy reliability issues are flagged as failures.
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c1e4a1530db0b4e3f46d04a4.md)

## Rule

- **Rule:**
  ```text
  Reliability tests must declare known-failing models via the known_failing_models decorator, which attaches a _known_failing_models attribute to the wrapped test function; do not silently skip or xfail such cases outside this mechanism.
  ```
- **Applies to:**
  - `tests/reliability/**/*.py`
- **Condition:** when adding or modifying a reliability test that must tolerate a named model failing to meet the required standard
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d2334dbf0f5d5e5a0c1c0729.md)
