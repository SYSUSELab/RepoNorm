# Constraints for `tests/reliability/conftest.py`

## Rule

- **Rule:**
  ```text
  The pytest_runtest_makereport hookwrapper must convert failures to passed when the test item has should_ignore_failure set, providing a convention for ignoring known-failing model tests.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:**
  ```text
  When modifying the pytest_runtest_makereport hookwrapper or known-failing model test handling in reliability tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-30ff08e31e8e3024fab96382.md)

## Rule

- **Rule:**
  ```text
  The reliability conftest defines MODEL_LIST as the standard set of models used for periodic DSPy reliability testing, spanning OpenAI, Anthropic, Gemini, Llama, and DeepSeek models.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** when adding or modifying the set of models used for periodic reliability testing
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-35a744f2bb712436ad611174.md)

## Rule

- **Rule:**
  ```text
  pytest_generate_tests must parameterize the configure_model fixture over MODEL_LIST, pairing each model with a boolean indicating membership in the function's _known_failing_models attribute and using the model name as the test ID, so contributors marking known-failing reliability models must use _known_failing_models rather than ad hoc skips.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** When adding or modifying reliability model parameterization or marking a model as known-failing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-649f4de90adc282315b3ccbb.md)

## Rule

- **Rule:**
  ```text
  The autouse configure_model fixture must read reliability_conf.yaml, configure dspy with the model's LM params and adapter, skip tests when no YAML config exists for the model, and store should_ignore_failure and model_name on the request node.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** When adding or modifying reliability tests that depend on model configuration or known-failing model handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8943cbeb137ddba6ec3e6a6a.md)
