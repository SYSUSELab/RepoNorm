# Constraints for `tests/reliability/test_pydantic_models.py`

## Rule

- **Rule:**
  ```text
  The reliability ToolCalling signature constrains next_tool_name, response_status, and user_intent to fixed Literal sets, and tool-calling tests must assert predicted tool names fall within the declared literal set; contributors changing the tool-calling protocol must update both the signature literals and the tests together.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when modifying the reliability ToolCalling signature literals or tests asserting predicted tool names
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5b95f2899db43c1904680b6d.md)

## Rule

- **Rule:** Reliability tests must exercise structured output extraction from a Signature whose output field is typed as a Pydantic model (ExtractEntityFromDescriptionOutput).
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** When modifying the entity-extraction reliability test or its Pydantic-typed Signature.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-633472de3f709ae27bb0c0f1.md)

## Rule

- **Rule:**
  ```text
  Reliability tests must import assert_program_output_correct and known_failing_models from tests.reliability.utils, establishing a shared reliability-test helper module used across reliability tests.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  When modifying reliability test imports or shared helper usage in tests/reliability/test_pydantic_models.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-afe18e9d396acbe7c8158fa0.md)

## Rule

- **Rule:** The enum reliability test must ensure both dspy.Predict and dspy.ChainOfThought extract Color.BLUE from 'The sky is blue.' including the trailing-period variant.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  When modifying test_color_classification_using_enum or the enum extraction path it exercises.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b46857f6e6c7c7dbea5f85b0.md)

## Rule

- **Rule:**
  ```text
  Reliability structured-output tests must preserve the asserted Pydantic answer-model invariants: certainty within [0,1], at least two comments, and graded correctness of value and comments.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  When modifying test_qa_with_pydantic_answer_model or the Pydantic answer model it exercises.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cf6d36e09a50aadd9f150ba4.md)

## Rule

- **Rule:** The reliability test defines a QA signature whose output field is a Pydantic Answer model, exercising structured output validation with Pydantic models.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying reliability tests that exercise Pydantic structured output validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e509d58c1dbca178090953f7.md)
