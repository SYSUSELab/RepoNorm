# Constraints for `tests/clients/test_lm.py`

## Rule

- **Rule:**
  ```text
  The LM client must map reasoning models (openai/o1, o1-mini, o1-2023-01-01, o3, o3-mini-2023-01-01) to use max_completion_tokens instead of max_tokens, while non-reasoning models such as openai/gpt-4 and anthropic/claude-2 use max_tokens.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:** When modifying LM client token-parameter selection for reasoning versus non-reasoning models.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-49329b0a483d7db58f33a992.md)

## Rule

- **Rule:**
  ```text
  When logprobs are requested from the LM client, the returned prediction must include a structured logprobs object with content entries containing token, bytes, logprob, and top_logprobs fields, and the underlying litellm completion call must receive the logprobs parameter.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:** Modifying LM client logprobs request handling or response parsing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-55d29b101a37d76c9e7d8a62.md)

## Rule

- **Rule:** The chat LM must be queryable with both openai/ and azure/ model prefixes against the litellm test server, returning the expected response.
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:** When modifying chat LM query behavior or model-prefix handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-705a74d4fa9babbf0bc67f0b.md)

## Rule

- **Rule:**
  ```text
  dspy.LM.dump_state() must return the exact state dict including defaults cache=True, cache_in_memory=True, finetuning_model=None, and must preserve launch_kwargs/train_kwargs separately from top-level temperature.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:**
  ```text
  When modifying LM state serialization or dump_state output.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bfc0b1bc5ff0556ccf332fee.md)
