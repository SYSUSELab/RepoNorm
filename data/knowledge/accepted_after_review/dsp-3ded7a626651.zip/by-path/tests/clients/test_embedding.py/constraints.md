# Constraints for `tests/clients/test_embedding.py`

## Rule

- **Rule:** Tests that reconfigure the global dspy cache must save and restore the original cache to avoid cross-test contamination.
- **Applies to:**
  - `tests/clients/test_embedding.py`
- **Condition:** When adding or modifying a test fixture that changes the global dspy cache directory, save the original cache and restore it after the test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bcdf6b4aad6d60986bbf0c15.md)
