# Constraints for `tests/clients/test_inspect_global_history.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise inspect_history(n=...) must assert that only the last n history entries are shown, and must avoid stray stdout because stray printing is a known source of flakiness.
  ```
- **Applies to:**
  - `tests/clients/test_inspect_global_history.py`
- **Condition:**
  ```text
  when modifying or adding tests for inspect_history with an n argument
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-21e890acb0917a5dc8882dd0.md)

## Rule

- **Rule:**
  ```text
  GLOBAL_HISTORY must be a non-empty list of dict entries each containing a "messages" key after Predict calls, and tests must clear it via an autouse fixture before each test.
  ```
- **Applies to:**
  - `tests/clients/test_inspect_global_history.py`
- **Condition:**
  ```text
  Modifying GLOBAL_HISTORY recording or the per-test isolation fixture.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a2d94693d441d6e1a4d0b518.md)
