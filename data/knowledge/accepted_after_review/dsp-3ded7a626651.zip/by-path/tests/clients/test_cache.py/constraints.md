# Constraints for `tests/clients/test_cache.py`

## Rule

- **Rule:**
  ```text
  cache.cache_key must return a 64-character SHA-256 hex string and accept both Pydantic model instances and Pydantic model classes as request values.
  ```
- **Applies to:**
  - `tests/clients/test_cache.py`
- **Condition:**
  ```text
  Modifying cache_key hashing or its accepted request value types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-39109c94ce8806308a4ee035.md)

## Rule

- **Rule:**
  ```text
  The request_cache decorator must work on async functions: identical arguments hit the cache (get called once), while different arguments recompute the result.
  ```
- **Applies to:**
  - `tests/clients/test_cache.py`
- **Condition:**
  ```text
  When modifying request_cache decorator behavior for async functions in cache tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5a90b4e634d2a725a68b6889.md)

## Rule

- **Rule:**
  ```text
  The request_cache decorator must return the cached value for identical prompt and model arguments and recompute when arguments differ, with cache.get invoked once per identical call.
  ```
- **Applies to:**
  - `tests/clients/test_cache.py`
- **Condition:**
  ```text
  Modifying request_cache decorator behavior or its cache-key argument handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-abfbfecb902f1bf0cc9d7549.md)

## Rule

- **Rule:**
  ```text
  request_cache's ignored_args_for_cache_key must cause calls differing only in the ignored argument (e.g. model) to return the same cached result, while non-ignored differing args produce distinct results.
  ```
- **Applies to:**
  - `tests/clients/test_cache.py`
- **Condition:**
  ```text
  When modifying request_cache key construction or ignored-argument handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d840bb696d80a93d4b4c6e61.md)
