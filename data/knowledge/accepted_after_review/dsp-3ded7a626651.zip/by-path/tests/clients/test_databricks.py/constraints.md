# Constraints for `tests/clients/test_databricks.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise DSPy provider finetuning must set dspy.settings.experimental = True before calling the provider finetune method and assert the resulting finetuning_run status is populated.
  ```
- **Applies to:**
  - `tests/clients/test_databricks.py`
- **Condition:** when adding or modifying tests that verify DatabricksProvider.finetune behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-41d22d8b369433629c266354.md)
