# Constraints for `docs/scripts/generate_api_docs.py`

## Rule

- **Rule:**
  ```text
  When changing API docs generation, preserve the module-contents filtering rules: filter by __all__ when present, include submodules whose names start with the module name, include classes/routines whose __module__ starts with the module name, and exclude underscore-prefixed names.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying get_module_contents or the logic that enumerates module members for generated API docs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-264be22b0e5a8f33b8e464ab.md)

## Rule

- **Rule:**
  ```text
  When changing API docs generation, preserve the recursive submodule documentation behavior: skip excluded modules, tolerate ImportError by printing and returning, skip non-module objects not in the API mapping, and only document objects not already in objects_processed before recursing into submodules.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying generate_md_docs_submodule or the recursive submodule documentation logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2e9dcdb3462e474a76d2e0bc.md)

## Rule

- **Rule:**
  ```text
  When changing API docs generation, preserve the API_MAPPING grouping of public dspy symbols into categories (models, primitives, signatures, adapters, modules, tools, utils, evaluation, optimizers) that determines the generated API documentation structure.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Adding, removing, or recategorizing public dspy symbols in the generated API documentation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-51bd151f65a20bcb676f4dcd.md)

## Rule

- **Rule:**
  ```text
  When changing how API docs are generated, preserve the exact HTML comment markers '<!-- START_API_REF -->' and '<!-- END_API_REF -->' used by read_existing_content to split generated content from pre-content and post-content.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Modifying the API docs generation or writing logic that reads or emits generated API reference content.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-51edb8bca70084aa80e449ba.md)

## Rule

- **Rule:**
  ```text
  When changing API docs generation, preserve the filtering rules that determine which objects are documented: only root-level dspy objects in the API category mapping, only public submodules re-exported in dspy's __init__, and excluded_modules can suppress subtrees.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying generate_md_docs or the logic that selects which dspy objects and submodules are documented.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-62fd141a4cf55b597ae8da76.md)

## Rule

- **Rule:** When changing API docs generation, preserve the recursive empty-directory removal behavior: descend into children first and call rmdir only when the directory has no entries.
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying remove_empty_dirs or the cleanup logic that removes empty directories after docs generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7d4bbff6e56c1c4459efcb9f.md)

## Rule

- **Rule:**
  ```text
  When changing API docs generation, preserve the mkdocstrings rendering convention: show_source, show_root_heading, heading_level 2, google docstring style, inherited_members true, and for classes an injected members list of public methods.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying generate_doc_page or the mkdocstrings block emission for generated API documentation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9d825ca5daafc1608a6629d7.md)

## Rule

- **Rule:** When changing API docs generation, preserve the non-destructive writing convention: existing pre/post content around generated API content is retained, and a '# {title}' header is injected only when no pre-content exists.
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying write_doc_file or the logic that writes generated API documentation pages.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a469b7cbd2f7bc2c1cdf2e08.md)

## Rule

- **Rule:**
  ```text
  Method names included in generated API documentation must be routines that satisfy the should_document_method filter; get_public_methods is the single gate that decides which class members appear in the generated docs.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  When modifying the API documentation generator's method-selection logic or the should_document_method filter, preserve the invariant that only routines passing should_document_method are emitted as documented methods.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c49aee56ec9a11250ca3d789.md)

## Rule

- **Rule:** When changing API docs generation, preserve the exclusion of the 'dspy.dsp' module from generated API docs and the subsequent removal of empty directories.
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Modifying the docs generation entry point or the excluded-modules list.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f4cf182cf45f8c80cbedae4e.md)

## Rule

- **Rule:**
  ```text
  When changing API docs generation, preserve the method-inclusion rules: methods whose __module__ does not start with 'dspy' are excluded, and private/dunder names are excluded except __call__.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  Modifying should_document_method or the logic that decides which class methods appear in generated API docs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f5ba918b5493775531787cfa.md)
