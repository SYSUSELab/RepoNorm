# Constraints for `docs/scripts/generate_api_summary.py`

## Rule

- **Rule:** When changing API summary generation, preserve the mkdocs.yml rewriting convention: preserve pre-nav and post-theme sections and insert an 'API Reference' nav section with an api/index.md entry.
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:**
  ```text
  Modifying generate_api_summary.main or the logic that rewrites mkdocs.yml for API summary generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0a59ff7988bb8df5ab0bbb27.md)

## Rule

- **Rule:** When changing API summary generation, preserve the mkdocs.yml section-splitting convention: split at the nav: and theme: lines and strip the API Reference nav block, returning pre-nav, nav content, and post-theme sections.
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:**
  ```text
  Modifying read_mkdocs_sections or the logic that parses mkdocs.yml sections for API summary generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-491fd3c473335c1426b39ef4.md)

## Rule

- **Rule:** When changing API summary generation, preserve the deterministic nav ordering rule: submodule sections precede file entries (e.g., dspy.evaluate before dspy.ChainOfThought).
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:**
  ```text
  Modifying format_nav_section or the logic that orders generated API navigation entries.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6ba13b636b294fdcc0fdaab9.md)

## Rule

- **Rule:**
  ```text
  When adding or renaming a docs/api subdirectory, update the INDEX_NAME mapping in generate_api_summary.py so generate_api_nav can resolve the directory name; an unrecognized directory name raises KeyError.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:** Adding, renaming, or removing a subdirectory under docs/api that the API nav generator must resolve.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f56ef35fcb629d0dbae160a9.md)
