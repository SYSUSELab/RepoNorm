# Constraints for `docs`

## Rule

- **Rule:**
  ```text
  The docs-push workflow triggers on pull requests limited to changes under docs/**.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-08e8cb8fcf80b9c72349d6f2.md)

## Rule

- **Rule:** The MkDocs edit URI is configured as blob/main/docs/docs/.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1315662aa5d467685cdbed3d.md)

## Rule

- **Rule:** The build-test job sets up Node.js version 18.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-13ea1b54fc3b38475c254c0f.md)

## Rule

- **Rule:**
  ```text
  The build-test job runs only when the triggering event is a pull_request.
  ```
- **Applies to:**
  - `docs/**`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'pull_request'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-19f13e677b6e7086a518e493.md)

## Rule

- **Rule:** Contributors should pull the latest version of the live documentation site by cloning the dspy repo before making changes.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-2a106371dc4fec21993e63d2.md)

## Rule

- **Rule:**
  ```text
  Running `mkdocs build` generates a static build of the documentation site in the `site` directory.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-33af80cf4a33cea394f25297.md)

## Rule

- **Rule:** When the CI build check fails, review changes and ensure the documentation builds correctly locally before pushing updates.
- **Applies to:**
  - `docs/**`
- **Condition:** CI build check fails
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-50cbb4eb786539dfad8ee7c1.md)

## Rule

- **Rule:** The update-docs-subtree job checks out the repository with fetch-depth 0.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-552734514605d3389fc1bb15.md)

## Rule

- **Rule:**
  ```text
  Run `mkdocs serve` to serve the documentation locally.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5944c703900ac82fbde0dae3.md)

## Rule

- **Rule:** The build-test job installs docs dependencies from docs/requirements.txt and builds the docs with mkdocs build.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6b5dc4d78fc77591b093c8cd.md)

## Rule

- **Rule:** The update-docs-subtree job runs only when the triggering event is a push.
- **Applies to:**
  - `docs/**`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7e7a4a8396ee667779bad471.md)

## Rule

- **Rule:** Documentation changes should be pushed on a new branch and opened as a PR for review and approval before merging into main.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-8739d6c01cfb41f1a2fed82b.md)

## Rule

- **Rule:**
  ```text
  The update-docs-subtree job pushes the docs directory to the dspy-docs repository under the krypticmouse account on the master branch using the GH_PAT secret.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8782c4faf23e16f896375da4.md)

## Rule

- **Rule:**
  ```text
  Documentation changes should be made in the `dspy/docs` folder.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-95ca8a36e73f54dfe614638d.md)

## Rule

- **Rule:** The build-test job runs on ubuntu-latest.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d92660c51b2dbe011621d4eb.md)

## Rule

- **Rule:**
  ```text
  The docs-push workflow triggers on pushes to the main branch limited to changes under docs/**.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-db5401c56d284698ba0f8e5d.md)

## Rule

- **Rule:** If the documentation build fails, fix it before pushing.
- **Applies to:**
  - `docs/**`
- **Condition:** the build is failing
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-df476bdae65ca9aba187d135.md)

## Rule

- **Rule:** The MkDocs documentation source directory is configured as "docs/".
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f0ab7d73c9a133880bbb9de1.md)

## Rule

- **Rule:**
  ```text
  CI runs the `mkdocs build` command to verify the documentation builds successfully before merging changes.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-f0f5d5951fc11e859b824a74.md)
