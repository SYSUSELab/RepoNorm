# Constraints for `build_utils/tests/intro.py`

## Rule

- **Rule:**
  ```text
  The test-pypi release is used to run build_utils/tests/intro.py with the new release as an integration test.
  ```
- **Applies to:**
  - `build_utils/tests/intro.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-975139cd754058515bd8b23e.md)
