# Constraints for `.pre-commit-config.yaml`

## Rule

- **Rule:** Pre-commit hooks are configured to run at the pre-commit stage and install only the pre-commit hook type.
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d7b75fe65e87956ca3438579.md)
