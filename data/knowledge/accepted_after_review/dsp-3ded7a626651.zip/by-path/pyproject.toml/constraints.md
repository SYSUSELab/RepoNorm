# Constraints for `pyproject.toml`

## Rule

- **Rule:**
  ```text
  The dspy package includes the JavaScript files matching primitives/*.js as package data.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3197efba78e85db0ff2ea46c.md)

## Rule

- **Rule:** Package discovery for setuptools searches from the repository root directory (".").
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3ee4aa68d890321b2090fe5d.md)

## Rule

- **Rule:** The package name is updated by the workflow to allow the same files to be used to build both the pypi and test-pypi packages.
- **Applies to:**
  - `pyproject.toml`
  - `setup.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cea6d517dce457b347464bc4.md)

## Rule

- **Rule:**
  ```text
  The project declares requires-python = ">=3.9, <3.14".
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-eeec21db03e23e0a8e7cdca3.md)
