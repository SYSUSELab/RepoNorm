# Constraints for `.`

## Rule

- **Rule:** Set up the pre-commit hooks once after cloning the repository.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-0b6381bb63fa55f45fc79851.md)

## Rule

- **Rule:** Ruff's formatter is configured to indent with spaces (indent-style = "space").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0f82944dacd3a7ed8153ca2c.md)

## Rule

- **Rule:**
  ```text
  The workflow configures the git user as `actions@github.com` / `Github Actions`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1462009d5cec61490ea77967.md)

## Rule

- **Rule:** Python 3.9 or later is required for the DSPy development environment.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-15ad07f663a8fbfa838041d4.md)

## Rule

- **Rule:**
  ```text
  The workflow auto-commits changes to a branch named `release-${{ needs.extract-tag.outputs.version }}` with commit message `Update versions` using `stefanzweifel/git-auto-commit-action@v5`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-174880a569e1e030dffc7325.md)

## Rule

- **Rule:**
  ```text
  The release workflow builds a binary wheel by running `python3 -m build`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1c16c9a9e08d79de651f9880.md)

## Rule

- **Rule:**
  ```text
  The check-added-large-files pre-commit hook runs with args ["--maxkb=1024"].
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1d1c80d9a99db9ed0c05d555.md)

## Rule

- **Rule:** Ruff has no unfixable rules configured.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-226dd656e8ef389c2433db2c.md)

## Rule

- **Rule:** If unsure about formatting issues, commit changes and let the pre-commit hooks fix them automatically.
- **Applies to:**
  - `**`
- **Condition:** when unsure about formatting issues
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-25113a1494821a5903838dc4.md)

## Rule

- **Rule:** Ruff linting enables the rule sets E, W, F, I, C, B, UP, N, RUF, and Q.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-28a53889ac312fb0befa4e5e.md)

## Rule

- **Rule:** Pre-commit hooks are used to automatically check and fix common issues.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-2983abe812ad5c803dcafcd2.md)

## Rule

- **Rule:**
  ```text
  When tests fail after a tag is pushed, delete the tag locally with `git tag -d X.Y.Z`, fix the errors, and repeat the steps to recreate the tag locally and push to GitHub to restart the release process.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-2c2e3f5938bac7b218af2f28.md)

## Rule

- **Rule:** Pre-commit checks must be passing locally and remotely before a contribution is accepted.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-30d45af95480605b18496135.md)

## Rule

- **Rule:** Ruff's formatter is configured to not format code inside docstrings (docstring-code-format = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-31200a50a8da917971db74be.md)

## Rule

- **Rule:**
  ```text
  Coverage reporting excludes lines matching the configured exclude_lines patterns, including "pragma: no cover", "def __repr__", "if self.debug:", "raise AssertionError", "raise NotImplementedError", "if __name__ == '__main__':", "logger", "try", "except", the regex "^\s*self\.\w+(:\s*[^=]+)?\s*=.*$", and "continue".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-33329d0ff3cb63a5a2002039.md)

## Rule

- **Rule:** If the hooks make any changes, those changes must be staged and committed as well.
- **Applies to:**
  - `**`
- **Condition:** the hooks make changes
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-38514e2461c4b61f829d1a02.md)

## Rule

- **Rule:** The title of a pull request or merge request must correspond to the required format.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-4244dd680d835882f2765a58.md)

## Rule

- **Rule:** After installation, verify it by running some unit tests.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-4283d3b3962fc9c5f0c98ccf.md)

## Rule

- **Rule:** The hooks can also be run manually, including a mode that checks staged files only.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-45591e1f67da26a0ff921890.md)

## Rule

- **Rule:**
  ```text
  Clone the fork to the local development device with `git clone {url-to-your-fork}`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-4776c2b249742d913463f93e.md)

## Rule

- **Rule:**
  ```text
  Every Python command must be prefixed with `uv run`, because uv creates a Python virtual environment and `uv run` points the command to that environment.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-47dcb986331f9b3f5ce3d72e.md)

## Rule

- **Rule:** If the test-intro-script test fails, the workflow fails and the maintainer needs to make a fix and delete and then recreate the tag.
- **Applies to:**
  - `**`
- **Condition:** the test-intro-script test fails
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-4b93d6dcbceff145aeeef4cf.md)

## Rule

- **Rule:**
  ```text
  The workflow publishes the dspy distribution to PyPI using `pypa/gh-action-pypi-publish@release/v1` with `attestations: false`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4bd6c98f3703ca9da0a08c54.md)

## Rule

- **Rule:** Python code follows the Google Python Style Guide, and ruff is used for both linting and formatting.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-4e58c63b6bbb6f220fb67fc1.md)

## Rule

- **Rule:**
  ```text
  The workflow merges the release branch into main with `git merge --no-ff release-${{ needs.extract-tag.outputs.version }}` and pushes to main with `git push origin main`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-55a55af5d7708671d3e62b43.md)

## Rule

- **Rule:**
  ```text
  Run `pre-commit run` to execute pre-commit checks.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-55d83dbbb5ff43b34d7ccaa8.md)

## Rule

- **Rule:** Contributors open a pull request from their branch in their fork to the main branch of the DSPy repository once changes are ready.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-5602c71acc4b724b8231b920.md)

## Rule

- **Rule:**
  ```text
  Ruff per-file ignores for __init__.py disable F401.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-570e0f3f06a75f05547a5bb2.md)

## Rule

- **Rule:** The release automation requires a trusted publisher to be set up on both the pypi and test-pypi packages.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-58a4ceb9ec7a8adb61b8b7d4.md)

## Rule

- **Rule:** The pre-commit configuration enables the check-toml hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-61d3f9e15289e1c71b84b59e.md)

## Rule

- **Rule:**
  ```text
  Run `pre-commit run --files <file>...` to run pre-commit checks against specific files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-62795f8d190cac0d9de5bbec.md)

## Rule

- **Rule:**
  ```text
  Coverage omits __init__.py, test_*.py, tests/*.py, conftest.py, setup.py, and virtual environment directories (venv, virtualenv, .venv, .virtualenv, env, .env) from measurement.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6e92751a64b82d57d9016536.md)

## Rule

- **Rule:** The pre-commit configuration enables the check-merge-conflict hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-74ce4ac690110d57cea28f63.md)

## Rule

- **Rule:**
  ```text
  The check-yaml pre-commit hook runs with args ["--allow-multiple-documents", "--unsafe"].
  ```
- **Applies to:**
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-82efa92c417e1d6abcf50f32.md)

## Rule

- **Rule:** If there are no releases on the new project, a pending trusted publisher may have to be created to allow the first automated deployment.
- **Applies to:**
  - `**`
- **Condition:** there are no releases on the new project
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-86376320a152a1ed176960ef.md)

## Rule

- **Rule:** The pre-commit configuration enables the debug-statements hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8680a5dea40cb8035a0e69e9.md)

## Rule

- **Rule:**
  ```text
  Before publishing to PyPI, the workflow creates a test virtual environment with `python -m venv test_before_pypi`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8f09a60c482cf7dcb1ca9348.md)

## Rule

- **Rule:** If the package is migrated to a new project, follow the steps to create a trusted publisher.
- **Applies to:**
  - `**`
- **Condition:** the package is migrated to a new project
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-8f5a7e0675b97e6af2afc778.md)

## Rule

- **Rule:** After a pull request is approved, a team member performs the merge.
- **Applies to:**
  - `**`
- **Condition:** once the pull request is approved
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-966ab5775bf9dac44e906544.md)

## Rule

- **Rule:** Ruff's flake8-tidy-imports rule bans all relative imports.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9c92a61af393574b06cd43d4.md)

## Rule

- **Rule:** Setting up the DSPy development environment requires forking the DSPy repository and cloning it locally.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-a47b55d2e0b70fe53206327c.md)

## Rule

- **Rule:**
  ```text
  The workflow checks out the main branch by running `git fetch origin` and `git checkout main`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a5a1dcc78b9a3f0b7280beaa.md)

## Rule

- **Rule:** Ruff linting ignores rules B027, FBT003, C901, E501, UP006, UP035, RUF005, B904, F403, E721, UP031, and RUF022.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-acbfa2e899e9aa3cae10f19c.md)

## Rule

- **Rule:** Commit messages must follow the format {label}(dspy): {message}.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-ae969230cc7964fe704149c7.md)

## Rule

- **Rule:**
  ```text
  Ruff's isort lint rule treats the `dspy` package as first-party when classifying imports.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bb3fc10ab84600816d37729d.md)

## Rule

- **Rule:** Ruff's formatter is configured to not skip magic trailing commas (skip-magic-trailing-comma = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c76ee00180c1bf3310e1f174.md)

## Rule

- **Rule:** Pushing a semver tag by a repo maintainer triggers the GitHub action that extracts the tag as the version for the release.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cd4dc539eb6e7b7c9b202048.md)

## Rule

- **Rule:** Run unit tests to verify that the environment is set up successfully.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-d1c456ed68fe1d88b4029e94.md)

## Rule

- **Rule:**
  ```text
  Set up the development environment with conda by running `conda create -n dspy-dev python=3.11` followed by `conda activate dspy-dev`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-d6b4da8ab860c6494c2098e4.md)

## Rule

- **Rule:** For minor changes (simple bug fixes or documentation fixes), contributors may open a PR without prior discussion.
- **Applies to:**
  - `**`
- **Condition:** the change is a minor change such as a simple bug fix or documentation fix
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-da6fcc182ad82a1ae3a538ac.md)

## Rule

- **Rule:**
  ```text
  After installing the hook, stage and commit changes; running `git commit` automatically runs the pre-commit hook.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e14c0c1982e9e772ab56ccdc.md)

## Rule

- **Rule:** Ruff's formatter is configured to use double quotes for strings (quote-style = "double").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e7c321e14b1c08413a12bc63.md)

## Rule

- **Rule:** Ensure all pre-commit checks pass before creating a pull request.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-f1e0d84cc2ab49512632c9cd.md)

## Rule

- **Rule:** If a code change involves fixing a bug, contributors are asked to include a code snippet or notebook showing how to reproduce the broken behavior.
- **Applies to:**
  - `**`
- **Condition:** the code change involves fixing a bug
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-f20ec5c710b21021281940f9.md)

## Rule

- **Rule:** To make code changes, fork the repository and set up the local development environment following the instructions in the "Environment Setup" section.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-f39eb020896ab5900590ee3b.md)

## Rule

- **Rule:** Coverage measurement is configured to track branch coverage.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f6e0d1f3a8f2af18de4a67c8.md)

## Rule

- **Rule:**
  ```text
  Run `pre-commit install` to install the pre-commit hook.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-f9d1d04fd6b74eea44d2a978.md)

## Rule

- **Rule:** Ruff's formatter is configured to use automatic line-ending detection (line-ending = "auto").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fadbc0be2b7bdfec4fefc26d.md)

## Rule

- **Rule:** Pre-commit hooks run with Python 3.9 as the default language version.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fc9054b9221e19d10b35cebf.md)
