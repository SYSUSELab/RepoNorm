# Constraints for `dspy/propose/grounded_proposer.py`

## Rule

- **Rule:**
  ```text
  GroundedProposer.__init__ must degrade gracefully: on program source extraction failure it prints an error and sets program_aware=False; on dataset summary creation failure it prints an error and sets use_dataset_summary=False, so proposer construction never raises on these failures.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:**
  ```text
  When modifying GroundedProposer.__init__ error handling for program source extraction or dataset summary creation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0e91f8ea3d9cd3426e6cb910.md)
