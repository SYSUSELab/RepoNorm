# Constraints for `dspy/propose/utils.py`

## Rule

- **Rule:**
  ```text
  `strip_prefix` removes a leading optional prefix of up to five word-like tokens followed by a colon via regex, then strips surrounding double quotes from the result.
  ```
- **Applies to:**
  - `dspy/propose/utils.py`
- **Condition:**
  ```text
  When modifying `strip_prefix` or its callers, preserve the regex-based prefix removal (up to five word-like tokens plus colon) and the subsequent double-quote stripping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1c433e718fe90e4b08113092.md)

## Rule

- **Rule:**
  ```text
  Only trial logs containing a 'program_path' key are loaded; each is deep-copied from base_program and loaded from that path, so trials without program_path are silently skipped.
  ```
- **Applies to:**
  - `dspy/propose/utils.py`
- **Condition:**
  ```text
  when modifying trial log loading or the program_path handling in dspy/propose/utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f38f1a129745f2eec4c654e8.md)
