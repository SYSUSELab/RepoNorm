# Constraints for `dspy/utils/langchain_tool.py`

## Rule

- **Rule:**
  ```text
  langchain_tool must import BaseTool only under TYPE_CHECKING so LangChain remains an optional runtime dependency for this module.
  ```
- **Applies to:**
  - `dspy/utils/langchain_tool.py`
- **Condition:**
  ```text
  when modifying imports or LangChain integration in dspy/utils/langchain_tool.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-895c8cd68ffc48c4bc7ff7ac.md)
