# Constraints for `dspy/utils/parallelizer.py`

## Rule

- **Rule:**
  ```text
  ParallelExecutor.execute must clear tqdm.tqdm._instances before wrapping and running the function in parallel; this global reset is an intentional side effect of each execution.
  ```
- **Applies to:**
  - `dspy/utils/parallelizer.py`
- **Condition:** When modifying ParallelExecutor.execute or its tqdm integration in dspy/utils/parallelizer.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa7f5ea43294c19aa21a499e.md)

## Rule

- **Rule:**
  ```text
  ParallelExecutor must cancel remaining jobs only after the accumulated error count reaches max_errors, not on the first failure; error_count updates must stay under error_lock.
  ```
- **Applies to:**
  - `dspy/utils/parallelizer.py`
- **Condition:** When modifying ParallelExecutor error handling or cancellation logic in dspy/utils/parallelizer.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fdeb0c27efd548f05a990369.md)
