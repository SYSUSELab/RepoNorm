# Constraints for `dspy/utils/unbatchify.py`

## Rule

- **Rule:**
  ```text
  Unbatchify.__exit__ must delegate to self.close() so resource cleanup is guaranteed on context exit regardless of exception type.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:**
  ```text
  When modifying Unbatchify.__exit__ or its context-manager cleanup path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c6aa5cf4ec1bc79d80e15ec8.md)

## Rule

- **Rule:**
  ```text
  When Unbatchify is initialized, it must start a daemon worker thread with default max_batch_size=32 and max_wait_time=0.1s so the worker exits with the main program and batching is bounded by both size and wait time.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:**
  ```text
  Modifying Unbatchify.__init__ or adding a new batching utility that spawns a background worker.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f5a94b5e6356e013b21a9699.md)
