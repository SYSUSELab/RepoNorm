# Constraints for `dspy/utils/inspect_history.py`

## Rule

- **Rule:**
  ```text
  When a contributor modifies _green in dspy/utils/inspect_history.py, it must wrap text with ANSI escape codes (\x1b[32m ... \x1b[0m), lstrip the text, and append the given end string, preserving the repository's terminal-coloring convention for history output.
  ```
- **Applies to:**
  - `dspy/utils/inspect_history.py`
- **Condition:**
  ```text
  Modifying _green or adding a new terminal-coloring helper for history output.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8647efd1556a3d144bd8ae13.md)
