# Constraints for `dspy/utils/callback.py`

## Rule

- **Rule:**
  ```text
  When modifying with_callbacks, preserve the sync/async duality: the decorator must branch on inspect.iscoroutinefunction(fn) and return an async_wrapper for coroutine functions and a sync_wrapper otherwise, so wrapped methods keep their original awaitability.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:**
  ```text
  when changing the with_callbacks decorator or the wrappers it returns
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-469e013e7ac194f72d0d5cfe.md)

## Rule

- **Rule:**
  ```text
  BaseCallback.on_adapter_parse_end must remain a no-op handler invoked after an adapter's parse() method, receiving call_id, outputs (None if interrupted by exception), and exception.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:**
  ```text
  When modifying BaseCallback.on_adapter_parse_end or the adapter parse-end callback invocation contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7896f95d7dbb68b9c8b951a2.md)

## Rule

- **Rule:**
  ```text
  with_callbacks.sync_wrapper must set ACTIVE_CALL_ID to the new call_id only immediately before invoking fn (not before start callbacks), restore the parent_call_id in finally, and execute end callbacks with results/exception; this ordering is an explicit invariant for nested callback tracking.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:** when modifying callback wrapping or nested call tracking in dspy/utils/callback.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-873515c16cb2858c949ad25d.md)

## Rule

- **Rule:**
  ```text
  When modifying BaseCallback.on_adapter_format_end, preserve the callback contract: it receives call_id, optional outputs, and optional exception; outputs are None when the adapter's format() is interrupted by an exception, and call_id links the start/end handlers.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:**
  ```text
  Modifying BaseCallback.on_adapter_format_end or the adapter format callback protocol.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc298c6d0e27f11e076599e1.md)

## Rule

- **Rule:**
  ```text
  When modifying BaseCallback.on_adapter_format_start, preserve the callback pairing protocol: the call_id parameter is documented as usable to connect start/end handlers for adapter format events.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:**
  ```text
  when changing on_adapter_format_start or the adapter format callback pairing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-deea0c5d44fe09262ede618e.md)

## Rule

- **Rule:**
  ```text
  When modifying BaseCallback in dspy/utils/callback.py, preserve the callback registration contract: handlers fire before/after component execution and can be registered globally via dspy.settings.configure(callbacks=[...]) or locally per component (e.g. dspy.LM(..., callbacks=[...])), with local callbacks scoped to that instance.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:** When changing callback registration, scoping, or before/after execution hooks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ebf5f800b676f6d96cc8379e.md)
