# Constraints for `dspy/signatures/utils.py`

## Rule

- **Rule:**
  ```text
  `get_dspy_field_type` reads the `'__dspy_field_type'` key from a field's `json_schema_extra` and raises `ValueError` if it is absent, making that metadata key the required marker for input/output fields.
  ```
- **Applies to:**
  - `dspy/signatures/utils.py`
- **Condition:**
  ```text
  When modifying signature field typing, preserve the requirement that fields carry the `'__dspy_field_type'` key in `json_schema_extra`, raising `ValueError` when absent.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b46b39cec861528eed73927f.md)
