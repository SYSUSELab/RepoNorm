# Constraints for `dspy/retrievers/weaviate_rm.py`

## Rule

- **Rule:**
  ```text
  When modifying WeaviateRM in dspy/retrievers/weaviate_rm.py, preserve the retriever contract: it subclasses dspy.Retrieve and assumes a Weaviate collection populated with a 'content' payload field, with constructor args weaviate_collection_name, weaviate_client, k (default 3), and tenant_id.
  ```
- **Applies to:**
  - `dspy/retrievers/weaviate_rm.py`
- **Condition:** When changing WeaviateRM's constructor signature or its assumptions about the Weaviate collection payload.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-91e93e86246f2dea11cdc3e8.md)
