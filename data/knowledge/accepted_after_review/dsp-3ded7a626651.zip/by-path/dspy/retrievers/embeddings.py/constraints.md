# Constraints for `dspy/retrievers/embeddings.py`

## Rule

- **Rule:**
  ```text
  When modifying Embeddings._faiss_search, preserve the result shape: it returns only index.search(...)[1], i.e. the neighbor indices and not the distances.
  ```
- **Applies to:**
  - `dspy/retrievers/embeddings.py`
- **Condition:**
  ```text
  Modifying Embeddings._faiss_search or its return value.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b5fbddb79ab0f01533c03c2f.md)
