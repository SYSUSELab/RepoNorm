# Constraints for `dspy/retrievers/databricks_rm.py`

## Rule

- **Rule:**
  ```text
  The Databricks retriever `Document` dataclass carries `page_content`, `metadata`, and a `type` field, defining the document shape returned by this retriever.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:**
  ```text
  When modifying the Databricks retriever's document model, preserve the `page_content`, `metadata`, and `type` fields.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-103b550b688e4da603bfcd2d.md)

## Rule

- **Rule:**
  ```text
  DatabricksRM.__init__ must resolve token/endpoint/client id/secret from constructor args or DATABRICKS_TOKEN, DATABRICKS_HOST, DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET env vars; raise ValueError when databricks-sdk is absent and token or endpoint is missing; deduplicate columns with id and text column names; and when use_with_databricks_agent_framework is set, require mlflow and call mlflow.models.set_retriever_schema(primary_key='doc_id', text_column='page_content', doc_uri='doc_uri').
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:**
  ```text
  when modifying DatabricksRM.__init__ configuration or agent-framework integration
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4fc24e906f8579c1dfe24a1e.md)
