# Constraints for `dspy/teleprompt/teleprompt_optuna.py`

## Rule

- **Rule:**
  ```text
  When a contributor modifies the Optuna teleprompter constructor, it must default to max_bootstrapped_demos=4, max_labeled_demos=16, max_rounds=1, and num_candidate_programs=16, and derive min_num_samples=1 and max_num_samples=max_bootstrapped_demos.
  ```
- **Applies to:**
  - `dspy/teleprompt/teleprompt_optuna.py`
- **Condition:**
  ```text
  Modifying BootstrapFewShotWithOptuna.__init__ or adding a new Optuna-based teleprompter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e0a5076fd9d10f18c3c787d4.md)
