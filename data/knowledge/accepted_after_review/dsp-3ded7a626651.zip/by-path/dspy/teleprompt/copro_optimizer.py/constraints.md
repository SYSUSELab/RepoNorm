# Constraints for `dspy/teleprompt/copro_optimizer.py`

## Rule

- **Rule:**
  ```text
  Predictors passed to the COPRO optimizer must expose a `signature` attribute; `_get_signature` asserts its presence before returning it.
  ```
- **Applies to:**
  - `dspy/teleprompt/copro_optimizer.py`
- **Condition:**
  ```text
  When modifying COPRO's signature resolution or the predictor interface it consumes, preserve the requirement that the predictor exposes a `signature` attribute.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2869a605bfb3b853681c6300.md)

## Rule

- **Rule:**
  ```text
  When modifying COPRO.__init__, preserve the validation that raises ValueError when breadth <= 1, enforcing breadth greater than 1; other params (depth, init_temperature, track_stats) are stored without validation.
  ```
- **Applies to:**
  - `dspy/teleprompt/copro_optimizer.py`
- **Condition:**
  ```text
  Modifying COPRO.__init__ or its breadth validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6c2ea44daf7c2fc6dc617551.md)

## Rule

- **Rule:** COPRO.compile must deep-copy the student, seed candidates with the original instruction/prefix, reevaluate all candidates against updated other predictors when the module has multiple predictors, and sort and deduplicate candidates by score before selecting the best program.
- **Applies to:**
  - `dspy/teleprompt/copro_optimizer.py`
- **Condition:** When modifying COPRO.compile candidate seeding, multi-predictor reevaluation, or final candidate selection.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e8f4acd071c603e89d593843.md)
