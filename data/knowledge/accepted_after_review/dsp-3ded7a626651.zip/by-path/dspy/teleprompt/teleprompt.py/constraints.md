# Constraints for `dspy/teleprompt/teleprompt.py`

## Rule

- **Rule:**
  ```text
  dspy/teleprompt/teleprompt.py defines Teleprompter.__init__ that only passes, indicating a base class with no initialization behavior.
  ```
- **Applies to:**
  - `dspy/teleprompt/teleprompt.py`
- **Condition:**
  ```text
  when modifying Teleprompter.__init__ or teleprompter base initialization
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9e75c5c88357e558bdb4a322.md)

## Rule

- **Rule:**
  ```text
  Teleprompter.get_params must return self.__dict__, so teleprompter parameters are exposed directly from instance attributes and any change to instance attribute storage affects get_params output.
  ```
- **Applies to:**
  - `dspy/teleprompt/teleprompt.py`
- **Condition:**
  ```text
  when modifying Teleprompter.get_params or instance attribute storage in dspy/teleprompt/teleprompt.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e166ed09977672df33e9ced6.md)
