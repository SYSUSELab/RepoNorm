# Constraints for `dspy/teleprompt/grpo.py`

## Rule

- **Rule:**
  ```text
  When modifying recover_lm_cache in dspy/teleprompt/grpo.py, preserve the cache-recovery contract: restore each predictor's LM cache from the saved dict, and default cache to True when an LM is missing, with the documented expectation that this branch is not normally executed because LMs are modified in place.
  ```
- **Applies to:**
  - `dspy/teleprompt/grpo.py`
- **Condition:**
  ```text
  When changing cache restoration or missing-LM handling in recover_lm_cache.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-895bd3866793d8087208291e.md)

## Rule

- **Rule:**
  ```text
  When modifying GRPO.report_validation_metrics, preserve the mutually exclusive configuration: with a user valset, use_train_as_val must be False; without valset and with report_train_scores True, use_train_as_val must be True; with both absent, use_train_as_val must be False.
  ```
- **Applies to:**
  - `dspy/teleprompt/grpo.py`
- **Condition:**
  ```text
  when changing report_validation_metrics or the valset/use_train_as_val configuration handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f057d16fd32d32bcb193b8d9.md)
