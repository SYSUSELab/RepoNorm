# Constraints for `dspy/teleprompt/knn_fewshot.py`

## Rule

- **Rule:**
  ```text
  `KNNFewShot` is implemented as a `Teleprompter` subclass, so KNN few-shot selection participates in the teleprompter abstraction.
  ```
- **Applies to:**
  - `dspy/teleprompt/knn_fewshot.py`
- **Condition:**
  ```text
  When modifying KNN few-shot selection, preserve its implementation as a `Teleprompter` subclass.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aef24e471b7b77c5a6b943b4.md)

## Rule

- **Rule:**
  ```text
  When modifying KNNFewShot.__init__ in dspy/teleprompt/knn_fewshot.py, preserve the construction-time configuration split: store a KNN(k, trainset, vectorizer=vectorizer) instance and the few_shot_bootstrap_args, so KNN retrieval is configured at construction and bootstrap args are deferred to compile.
  ```
- **Applies to:**
  - `dspy/teleprompt/knn_fewshot.py`
- **Condition:**
  ```text
  When changing constructor arguments or deferred bootstrap handling in KNNFewShot.__init__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b1ecef8d248322031520a9c5.md)
