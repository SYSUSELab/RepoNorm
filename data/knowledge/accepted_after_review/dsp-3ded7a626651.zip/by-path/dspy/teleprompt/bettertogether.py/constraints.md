# Constraints for `dspy/teleprompt/bettertogether.py`

## Rule

- **Rule:**
  ```text
  When modifying BetterTogether._compile_weight_optimizer in dspy/teleprompt/bettertogether.py, preserve the post-compile train_kwargs remapping: capture original_lms before compiling, then remap weight_optimizer.train_kwargs from each original LM to the corresponding new LM, because train_kwargs were configured for the original LMs.
  ```
- **Applies to:**
  - `dspy/teleprompt/bettertogether.py`
- **Condition:**
  ```text
  When changing compilation flow or LM bookkeeping in _compile_weight_optimizer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-092c6a54bd94871073fd7944.md)

## Rule

- **Rule:**
  ```text
  BetterTogether.compile validates that every strategy token is 'p' or 'w' after lowercasing and splitting on STRAT_SEP, raising ValueError otherwise.
  ```
- **Applies to:**
  - `dspy/teleprompt/bettertogether.py`
- **Condition:** when modifying BetterTogether.compile or its strategy-string validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-33298e06f29bc89e54c479bc.md)

## Rule

- **Rule:**
  ```text
  BetterTogether._compile_prompt_optimizer must strip the 'hint' input from trainset examples before prompt optimization and restore each predictor's original lm after compiling, because BootstrapFewShotWithRandomSearch can reset predictor.lm attributes.
  ```
- **Applies to:**
  - `dspy/teleprompt/bettertogether.py`
- **Condition:**
  ```text
  When modifying BetterTogether._compile_prompt_optimizer or the prompt-optimizer compilation flow that mutates predictor.lm.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e72209b5ea093ec4819c0e1.md)

## Rule

- **Rule:**
  ```text
  When a contributor modifies BetterTogether._run_strategies, it must deep-copy the student before each strategy step and set _compiled=False so each candidate program is an independent uncompiled copy, recording the initial student under the empty-string strategy key.
  ```
- **Applies to:**
  - `dspy/teleprompt/bettertogether.py`
- **Condition:**
  ```text
  Modifying BetterTogether._run_strategies or adding a new strategy-execution loop that produces candidate programs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-85ce2ae25248bb8458351b7d.md)

## Rule

- **Rule:** BetterTogether.compile must make a shallow copy of the trainset before optimization so the original example order is preserved for callers relying on trainset ordering.
- **Applies to:**
  - `dspy/teleprompt/bettertogether.py`
- **Condition:** When modifying BetterTogether.compile trainset handling in dspy/teleprompt/bettertogether.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c0c51b4b3867240b46ab9d56.md)
