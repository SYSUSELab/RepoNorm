# Constraints for `dspy/teleprompt/mipro_optimizer_v2.py`

## Rule

- **Rule:**
  ```text
  mipro_optimizer_v2 must keep fixed constants for bootstrapped and labeled fewshot examples in context, a minimum minibatch size of 50, and AUTO_RUN_SETTINGS mapping light/medium/heavy to n and val_size values.
  ```
- **Applies to:**
  - `dspy/teleprompt/mipro_optimizer_v2.py`
- **Condition:**
  ```text
  When modifying mipro_optimizer_v2 constants for fewshot examples, minibatch size, or AUTO_RUN_SETTINGS.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cbdc60f8af677872558ec40b.md)
