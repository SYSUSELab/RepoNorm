# Constraints for `dspy/teleprompt/avatar_optimizer.py`

## Rule

- **Rule:**
  ```text
  FeedbackBasedInstruction must remain a dspy.Signature with previous_instruction and feedback as InputFields and new_instruction as OutputField, and its docstring must constrain the generated instruction to no more than 3 paragraphs while retaining prior general guidelines.
  ```
- **Applies to:**
  - `dspy/teleprompt/avatar_optimizer.py`
- **Condition:** When modifying FeedbackBasedInstruction fields or its docstring constraints in the avatar optimizer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-26e5c90c0996acc1ac8321cd.md)

## Rule

- **Rule:**
  ```text
  AvatarOptimizer.__init__ must assert metric is not None, default max_iters to 10, bounds to 0/1, and max_positive/negative_inputs to DEFAULT_MAX_EXAMPLES, and construct TypedPredictor(Comparator) and Predict(FeedbackBasedInstruction).
  ```
- **Applies to:**
  - `dspy/teleprompt/avatar_optimizer.py`
- **Condition:**
  ```text
  When modifying AvatarOptimizer.__init__ or its default parameter values and internal predictor construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-46c33cc4cef9d6b34e752459.md)

## Rule

- **Rule:**
  ```text
  AvatarOptimizer.compile must deep-copy the student, initialize best_score to -999 for 'max' or 999 for 'min', sample positive and negative inputs up to configured limits, and update the best actor's signature instructions only when the new score improves on best_score according to optimize_for.
  ```
- **Applies to:**
  - `dspy/teleprompt/avatar_optimizer.py`
- **Condition:** when modifying AvatarOptimizer.compile or its optimization loop
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-47b2e33a6bc8458e44b33b24.md)

## Rule

- **Rule:**
  ```text
  When a contributor modifies AvatarOptimizer.thread_safe_evaluator, it must run process_example over the devset with a ThreadPoolExecutor sized by num_threads or dspy.settings.num_threads, average scores over total_examples, and optionally return per-example results.
  ```
- **Applies to:**
  - `dspy/teleprompt/avatar_optimizer.py`
- **Condition:**
  ```text
  Modifying AvatarOptimizer.thread_safe_evaluator or adding a new parallel evaluation helper in the optimizer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ec7378b691f0fd3432460675.md)
