# Constraints for `dspy/teleprompt/infer_rules.py`

## Rule

- **Rule:**
  ```text
  InferRules must initialize a seeded RNG (random.Random(0)) and a ChainOfThought over CustomRulesInduction so rule induction is deterministic by default, with teacher_settings defaulting to an empty dict.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when modifying InferRules initialization or rule induction determinism in dspy/teleprompt/infer_rules.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2b0a36767f739e635459935f.md)

## Rule

- **Rule:**
  ```text
  `RulesInductionProgram.forward` copies the configured LM and overrides temperature with `self.rng.uniform(0.9, 1.0)` inside a `dspy.settings.context`, so rules induction deliberately samples at high temperature; contributors altering this must preserve the RNG-driven temperature range.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:** When modifying rules-induction sampling, preserve the RNG-driven temperature override in the range 0.9 to 1.0 within the settings context.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4088b597335b64fb8f3b8c54.md)

## Rule

- **Rule:**
  ```text
  When modifying InferRules.__init__, preserve the keyword-argument contract: it constructs RulesInductionProgram(num_rules, teacher_settings=...) and reads metric and max_errors from kwargs, so callers must pass metric/max_errors as keyword arguments rather than named parameters.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when changing InferRules.__init__ or its metric/max_errors parameter handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-548e08faeaf4e76bd17221e8.md)

## Rule

- **Rule:**
  ```text
  When modifying CustomRulesInduction, preserve the dynamic __doc__ contract: __doc__ is set using num_rules to instruct extraction of a list of num_rules concise, non-redundant natural-language rules, with inputs examples_text and output natural_language_rules.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when changing CustomRulesInduction or its dynamic __doc__ construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5a3872bb735db482970bcbfb.md)

## Rule

- **Rule:**
  ```text
  InferRules.evaluate_program must resolve effective_max_errors to self.max_errors when set, otherwise fall back to dspy.settings.max_errors, and run Evaluate with return_all_scores=True, returning only the score.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when modifying InferRules.evaluate_program or its error budget handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a8f15e2ebfd14396635c5352.md)

## Rule

- **Rule:**
  ```text
  InferRules.update_program_instructions must append natural-language rules to the predictor's existing signature instructions with the fixed 'Please adhere to the following rules when making your prediction:' prefix, so rule updates are additive rather than replacing instructions.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  When modifying InferRules.update_program_instructions or how rules are appended to predictor instructions.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bfadf202751fca696fd58174.md)

## Rule

- **Rule:** When a DSPy module is compiled, its predictor instructions must be reset to the originals before rule induction, and the candidate with the highest validation score is returned; when valset is None the trainset is split 50/50 into train/val.
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:** Modifying InferRules.compile or adding a new rule-induction optimizer that reuses predictor instructions across candidates.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dc27671d60d1f6f03d99f036.md)
