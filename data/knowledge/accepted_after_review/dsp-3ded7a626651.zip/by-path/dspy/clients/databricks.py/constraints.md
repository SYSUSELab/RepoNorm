# Constraints for `dspy/clients/databricks.py`

## Rule

- **Rule:**
  ```text
  deploy_finetuned_model polls the endpoint every 60 seconds up to deploy_timeout//60 retries using chat or completion calls depending on data_format, and raises ValueError if the endpoint is not ready within deploy_timeout seconds.
  ```
- **Applies to:**
  - `dspy/clients/databricks.py`
- **Condition:**
  ```text
  when modifying DatabricksProvider.deploy_finetuned_model or its timeout/retry behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f3272d96b03168151fdfcacf.md)
