# Constraints for `dspy/clients/base_lm.py`

## Rule

- **Rule:**
  ```text
  BaseLM._process_lm_response must collapse outputs to a list of plain strings only when every choice output has exactly the text key; presence of logprobs or tool_calls must keep dict outputs, so downstream consumers must handle both shapes.
  ```
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:** when modifying LM response processing or consuming its output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-27b531eac411c640df098037.md)

## Rule

- **Rule:**
  ```text
  When modifying BaseLM.update_global_history, preserve the bounded-history behavior: return early when settings.disable_history is set, and otherwise evict the oldest entry via pop(0) once GLOBAL_HISTORY reaches MAX_HISTORY_SIZE before appending.
  ```
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:**
  ```text
  when changing update_global_history or the global history size management
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-79e8acf1f5a6db5649329606.md)
