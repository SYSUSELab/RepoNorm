# Constraints for `dspy/clients/embedding.py`

## Rule

- **Rule:**
  ```text
  `Embedder._preprocess` normalizes a single string input into a list, rejects non-string inputs with `ValueError`, merges `default_kwargs` with call kwargs, splits inputs into `batch_size` chunks, and returns `is_single_input` so callers can unwrap single-input results.
  ```
- **Applies to:**
  - `dspy/clients/embedding.py`
- **Condition:**
  ```text
  When modifying embedding input preprocessing, preserve string normalization, non-string rejection, kwargs merging, batch splitting, and the `is_single_input` return contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0bdc6fcf33676f5a7106fd25.md)

## Rule

- **Rule:**
  ```text
  `Embedder.acall` preprocesses inputs into batches, selects cached versus uncached embedding computation based on the caching flag, and postprocesses results back to single or batched form.
  ```
- **Applies to:**
  - `dspy/clients/embedding.py`
- **Condition:**
  ```text
  When modifying `Embedder.acall`, preserve the preprocess/batch/cache-selection/postprocess pipeline and single-vs-batched result shaping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-266dc0532e1afaa32eb0d89c.md)

## Rule

- **Rule:**
  ```text
  The embedding client module routes embedding requests through the shared request cache by importing `request_cache` from `dspy.clients.cache`.
  ```
- **Applies to:**
  - `dspy/clients/embedding.py`
- **Condition:** When modifying embedding request handling, preserve routing through the shared request cache rather than bypassing it.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7310c8b5bffbe84c693a8367.md)
