# Constraints for `dspy/clients/cache.py`

## Rule

- **Rule:**
  ```text
  When modifying request_cache, preserve the default ignored_args_for_cache_key of ['api_key','api_base','base_url'] so connection-credential arguments are excluded from cache keys unless explicitly overridden.
  ```
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:**
  ```text
  when changing request_cache or the cache key argument exclusion defaults
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-663329ea2d0bb139cce1dde9.md)

## Rule

- **Rule:**
  ```text
  When modifying the request cache decorator, preserve the sync wrapper's flow: compute the modified request via process_request, return the cached result when present, otherwise call the wrapped function and store the result with cache.put, honoring ignored_args_for_cache_key and the call-time enable_memory_cache flag that prevents indefinite cache growth.
  ```
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:** Modifying the request cache decorator's sync wrapper or its cache-key/put behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7b1dd5d57d50bc363dcdffe1.md)
