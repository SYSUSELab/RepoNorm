# Constraints for `dspy/clients/utils_finetune.py`

## Rule

- **Rule:**
  ```text
  find_data_errors_completion must require exactly the keys 'prompt' and 'completion' with both values being str, returning a descriptive error string otherwise.
  ```
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:**
  ```text
  When modifying find_data_errors_completion validation logic in dspy/clients/utils_finetune.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7208b66d5c29a7c7fa97bbca.md)

## Rule

- **Rule:**
  ```text
  find_data_error_chat must accept a finetuning chat payload dict with exactly the key 'messages' whose value is a list, and must report the first offending message index.
  ```
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:**
  ```text
  when modifying finetuning chat data validation in find_data_error_chat
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8b4266e8bfbc5bf5995ff91c.md)

## Rule

- **Rule:**
  ```text
  When modifying write_lines in dspy/clients/utils_finetune.py, preserve the newline-delimited JSON serialization: each item is serialized with ujson.dumps followed by a newline, not as a single JSON array.
  ```
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:** When changing how finetune data files are written or serialized.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c691e9bc84c010def1da2f33.md)
