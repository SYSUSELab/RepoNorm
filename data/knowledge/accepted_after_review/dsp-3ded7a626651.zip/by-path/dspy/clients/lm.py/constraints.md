# Constraints for `dspy/clients/lm.py`

## Rule

- **Rule:**
  ```text
  When modifying litellm_text_completion in dspy/clients/lm.py, preserve the model-string and credential contract: parse 'provider/model' with provider defaulting to 'openai' when no slash is present, read API key/base from the request or {provider}_API_KEY/{provider}_API_BASE environment variables, and call litellm.text_completion with 'text-completion-openai/{model}' and exponential-backoff retry.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:**
  ```text
  When changing model-string parsing, credential resolution, or the litellm call in litellm_text_completion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6512166d027cc844ba01c48b.md)

## Rule

- **Rule:**
  ```text
  alitellm_text_completion must split the model string into provider/model, resolve api_key and api_base from the request or environment, join message contents into a prompt ending with "BEGIN RESPONSE:", and call litellm.atext_completion with exponential backoff retries.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:**
  ```text
  When modifying alitellm_text_completion request construction or retry logic in dspy/clients/lm.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e38df8227ca1306cf6b5d68d.md)
