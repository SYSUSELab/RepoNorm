# Constraints for `dspy/clients`

## Rule

- **Rule:** BaseLM subclasses that support async must override aforward and return a response in the OpenAI response format; the base implementation raises NotImplementedError.
- **Applies to:**
  - `dspy/clients/**/*.py`
- **Condition:** when adding or modifying a BaseLM subclass that provides asynchronous inference
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cb0eb60f4e4f1f657f023556.md)
