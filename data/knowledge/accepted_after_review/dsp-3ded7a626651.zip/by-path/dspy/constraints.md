# Constraints for `dspy`

## Rule

- **Rule:** Ruff linting/formatting applies to Python files under dspy/ and tests/ as included by the include setting.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0dcee3b53bd57970ff289f00.md)

## Rule

- **Rule:** Setuptools package discovery includes only the "dspy" package and its subpackages.
- **Applies to:**
  - `dspy/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-115fd67ec6a6e0a9c258f1bf.md)

## Rule

- **Rule:** Ruff targets Python 3.9 (py39).
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-2d6650935e929b1953204ac4.md)

## Rule

- **Rule:** Ruff uses an indent width of 4.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-74043d4617d605898fa09234.md)

## Rule

- **Rule:** Ruff enforces a maximum line length of 120.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-9f0df2b307460032940ca8a0.md)
