# Constraints for `dspy/predict/avatar/avatar.py`

## Rule

- **Rule:**
  ```text
  Avatar.forward must loop until tool_name == 'Finish' or max_iters is exhausted, append ActionOutput records for non-Finish tools, update the signature each iteration, and restore self.actor from actor_clone before returning a Prediction with actions.
  ```
- **Applies to:**
  - `dspy/predict/avatar/avatar.py`
- **Condition:** when modifying the Avatar forward loop or its actor restoration behavior in dspy/predict/avatar/avatar.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-9666296ac9c239e32600262c.md)
