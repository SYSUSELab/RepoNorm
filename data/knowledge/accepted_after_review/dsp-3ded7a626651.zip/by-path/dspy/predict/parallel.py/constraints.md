# Constraints for `dspy/predict/parallel.py`

## Rule

- **Rule:**
  ```text
  Parallel's constructor resolves num_threads from settings.num_threads when not provided, and resolves max_errors from settings.max_errors only when max_errors is None, so an explicit 0 is preserved rather than replaced by the setting.
  ```
- **Applies to:**
  - `dspy/predict/parallel.py`
- **Condition:**
  ```text
  when modifying Parallel.__init__ or its settings-based default resolution
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7daa9568a66b98021875a2b7.md)
