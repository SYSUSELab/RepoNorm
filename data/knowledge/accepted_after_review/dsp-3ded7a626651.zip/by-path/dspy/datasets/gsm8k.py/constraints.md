# Constraints for `dspy/datasets/gsm8k.py`

## Rule

- **Rule:**
  ```text
  When modifying parse_integer_answer in dspy/datasets/gsm8k.py, preserve the silent-fallback contract: take the last whitespace token containing a digit, strip decimals and non-digits, and return 0 on ValueError/IndexError instead of raising.
  ```
- **Applies to:**
  - `dspy/datasets/gsm8k.py`
- **Condition:**
  ```text
  When changing answer extraction or error handling in parse_integer_answer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-09afa8e18cfee8e38438ca2d.md)

## Rule

- **Rule:**
  ```text
  When a contributor modifies gsm8k_metric, it must compare gold and pred answers by parsing integer answers from str(gold.answer) and str(pred.answer), so GSM8K evaluation depends on answer fields being integer-parseable strings.
  ```
- **Applies to:**
  - `dspy/datasets/gsm8k.py`
- **Condition:**
  ```text
  Modifying gsm8k_metric or adding a new GSM8K-style metric that parses numeric answers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa70d14ed28cad9a2cdbbeba.md)
