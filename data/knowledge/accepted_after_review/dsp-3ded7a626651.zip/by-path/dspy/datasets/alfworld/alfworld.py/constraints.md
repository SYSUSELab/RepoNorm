# Constraints for `dspy/datasets/alfworld/alfworld.py`

## Rule

- **Rule:** dspy.datasets.alfworld.alfworld must import os, queue, and random as its standard-library dependencies.
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** When modifying imports in dspy.datasets.alfworld.alfworld.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-5eeb9a47b8b5658372a05599.md)
