# Constraints for `dspy/datasets/dataloader.py`

## Rule

- **Rule:** When modifying DataLoader.sample in dspy/datasets/dataloader.py, preserve the input-validation contract: raise ValueError when the dataset argument is not a list, so callers must pass a list of dspy.Example objects.
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:** When changing argument handling or validation in DataLoader.sample.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2ebb6ce60fdf1b4dd39eef43.md)

## Rule

- **Rule:**
  ```text
  DataLoader.from_parquet must default fields to all dataset features when none are supplied and always wrap each row in dspy.Example(...).with_inputs(*input_keys).
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  When modifying DataLoader.from_parquet field defaulting or row-to-Example conversion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-448e127eb232dba269b00fb3.md)

## Rule

- **Rule:**
  ```text
  `DataLoader.from_rm` raises `ValueError` with distinct messages when the retrieval module lacks `get_objects` (`AttributeError`) versus when no retrieval module is configured, so callers can distinguish misconfiguration from unsupported RM.
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  When modifying `DataLoader.from_rm` error handling, preserve distinct `ValueError` messages for missing `get_objects` versus missing retrieval module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-532afd15723ceaf90fe35d1e.md)

## Rule

- **Rule:**
  ```text
  train_test_split accepts train_size/test_size as either a float proportion in (0,1) or an int absolute count, raises ValueError for other types, and raises ValueError when train_end + test_end exceeds dataset size.
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  when modifying DataLoader.train_test_split or its size-argument validation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9c3713d39a1fe7fe81fbce62.md)
