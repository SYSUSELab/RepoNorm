# Constraints for `dspy/datasets/hotpotqa.py`

## Rule

- **Rule:** The loader shuffles official train examples with random.Random(0) and splits 75/25 into train and unofficial dev, making the split deterministic and reproducible.
- **Applies to:**
  - `dspy/datasets/hotpotqa.py`
- **Condition:** when modifying HotPotQA dataset loading or its train/dev split
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7244ce5b270f40ab63f73a22.md)

## Rule

- **Rule:**
  ```text
  The __main__ block of hotpotqa.py must construct HotPotQA with train_seed=1, train_size=16, eval_seed=2023, dev_size=1000, test_size=0 and print expected sample questions and split sizes (16 1000 0), documenting the deterministic dataset split behavior.
  ```
- **Applies to:**
  - `dspy/datasets/hotpotqa.py`
- **Condition:** when modifying the HotPotQA dataset smoke block or its deterministic split parameters in dspy/datasets/hotpotqa.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e265940f0f08925de635e7d2.md)
