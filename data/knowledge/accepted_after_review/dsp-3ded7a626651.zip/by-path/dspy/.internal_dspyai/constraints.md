# Constraints for `dspy/.internal_dspyai`

## Rule

- **Rule:**
  ```text
  The workflow builds the dspy-ai binary wheel by running `python3 -m build ./dspy/.internal_dspyai/`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-86b88ebb6c5160e303febccd.md)
