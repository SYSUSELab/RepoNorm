# Constraints for `dspy/.internal_dspyai/pyproject.toml`

## Rule

- **Rule:**
  ```text
  The dspy-ai package declares a runtime dependency on dspy>=2.6.5.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-255cd3d017a9d368fcdae665.md)

## Rule

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the package name in `./dspy/.internal_dspyai/pyproject.toml` to `dspy-ai` using a sed command keyed on the `#replace_package_name_marker`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-45d61da57a133cea00fe7e2b.md)

## Rule

- **Rule:**
  ```text
  For the dspy-ai release, the workflow sets the version in `./dspy/.internal_dspyai/pyproject.toml` to the extracted tag version using a sed command keyed on the `#replace_package_version_marker`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-805fea3376fdbe7a23c6da60.md)

## Rule

- **Rule:**
  ```text
  The dspy-ai package declares requires-python ">=3.9", so the package supports Python 3.9 and later.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9dd761919f131b448fd741d0.md)

## Rule

- **Rule:**
  ```text
  setuptools package discovery includes the packages matching "dsp.*", "dspy.*", "dsp", and "dspy".
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa88d3eb498a2072ecc143d0.md)

## Rule

- **Rule:**
  ```text
  For the dspy-ai release, the workflow updates the dspy dependency in `./dspy/.internal_dspyai/pyproject.toml` to the extracted tag version using a sed command keyed on the `#replace_dspy_version_marker`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d11769b639d7d53f92fc51c2.md)
