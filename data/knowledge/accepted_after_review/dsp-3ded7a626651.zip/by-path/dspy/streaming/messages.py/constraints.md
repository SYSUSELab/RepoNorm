# Constraints for `dspy/streaming/messages.py`

## Rule

- **Rule:**
  ```text
  When driving async streaming from synchronous code, run_async_in_new_loop must create a new event loop, set it, run stream.send(message) to completion, and close the loop in finally; contributors must not reuse an existing loop or skip cleanup.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  Modifying sync_send_to_stream or adding a new synchronous entry point that drives async streaming.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f66547149f0bd1ee737399e7.md)

## Rule

- **Rule:**
  ```text
  When modifying StatusStreamingCallback.on_module_end, preserve the early-return behavior: it returns without emitting a status message when settings.send_stream is None, so streaming status callbacks are silently skipped unless a stream is configured.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  Modifying StatusStreamingCallback.on_module_end or its stream-configuration guard.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ffd202c1e5c9397496720ac3.md)
