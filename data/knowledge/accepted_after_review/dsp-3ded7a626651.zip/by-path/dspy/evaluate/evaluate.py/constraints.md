# Constraints for `dspy/evaluate/evaluate.py`

## Rule

- **Rule:**
  ```text
  merge_dicts must disambiguate colliding keys by prefixing keys present in both d1 and d2 with 'example_' and keys present in both d2 and d1 with 'pred_', so overlapping example/prediction fields are preserved rather than overwritten.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:**
  ```text
  When modifying merge_dicts or evaluation result merging that combines example and prediction fields.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1af04179bee775d8900c682d.md)

## Rule

- **Rule:** When a contributor modifies the HTML helper in dspy/evaluate/evaluate.py, it must remain a compatibility shim that returns the input string unchanged when IPython is unavailable.
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** Modifying the HTML helper or adding a new IPython-compatibility shim in the evaluate module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-33666b00efdd272e0ec1e4de.md)

## Rule

- **Rule:** When modifying dspy/evaluate/evaluate.py, preserve the optional-IPython boundary: IPython.display HTML/display are imported inside a try/except ImportError, so contributors must not assume IPython is installed when using Evaluate.
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** When changing imports or display behavior in dspy/evaluate/evaluate.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d56b3b891529827f05a47584.md)
