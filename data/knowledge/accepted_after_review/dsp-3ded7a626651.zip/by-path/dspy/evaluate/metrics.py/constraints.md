# Constraints for `dspy/evaluate/metrics.py`

## Rule

- **Rule:**
  ```text
  _answer_match must return EM(prediction, answers) when frac >= 1.0 and otherwise F1(prediction, answers) >= frac, so the frac threshold selects between exact-match and F1-based matching.
  ```
- **Applies to:**
  - `dspy/evaluate/metrics.py`
- **Condition:**
  ```text
  when modifying _answer_match or the frac threshold behavior in dspy/evaluate/metrics.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-abaf137a6e69ba67d19eb141.md)
