# Constraints for `dspy/adapters`

## Rule

- **Rule:**
  ```text
  Concrete Adapter subclasses must implement format_field_description; the base Adapter declares it abstract by raising NotImplementedError, so a subclass that omits it will fail at call time rather than inherit usable behavior.
  ```
- **Applies to:**
  - `dspy/adapters/**/*.py`
- **Condition:** when adding or modifying a concrete Adapter subclass that formats field descriptions for the system message
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b8a25a8f5aa5ec59b3b8adce.md)
