# Constraints for `dspy/adapters/types/history.py`

## Rule

- **Rule:** dspy/adapters/types/history.py must build its history type on pydantic models, importing Any from typing and pydantic accordingly.
- **Applies to:**
  - `dspy/adapters/types/history.py`
- **Condition:** when modifying the history type definition or its dependencies in dspy/adapters/types/history.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-993a7c2c261e87538ec47573.md)
