# Constraints for `dspy/adapters/types/tool.py`

## Rule

- **Rule:**
  ```text
  When modifying Tool.from_langchain, preserve delegation to dspy.utils.langchain_tool.convert_langchain_tool and the documented async invocation support via acall for the resulting tool.
  ```
- **Applies to:**
  - `dspy/adapters/types/tool.py`
- **Condition:**
  ```text
  when changing Tool.from_langchain or the LangChain conversion path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2e47e6d40749b1cd27508235.md)

## Rule

- **Rule:**
  ```text
  tool.py defines _TYPE_MAPPING mapping JSON schema type names (string, integer, number, boolean, array, object) to Python types, and conditionally imports mcp and langchain BaseTool under TYPE_CHECKING.
  ```
- **Applies to:**
  - `dspy/adapters/types/tool.py`
- **Condition:** when modifying the JSON-schema-to-Python type mapping or optional tool dependencies in dspy/adapters/types/tool.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-7b57c9d59963d0cfc1cf6748.md)

## Rule

- **Rule:**
  ```text
  Tool.format_as_litellm_function_call must emit a litellm function schema with type 'function', the tool's name and desc, and parameters whose properties are self.args and whose required list is list(self.args.keys()), so every declared arg is required.
  ```
- **Applies to:**
  - `dspy/adapters/types/tool.py`
- **Condition:**
  ```text
  When modifying Tool.format_as_litellm_function_call or the Tool args schema that feeds litellm function-call emission.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-b095f1f3834d5f8cdd5175f5.md)

## Rule

- **Rule:**
  ```text
  Tool.from_mcp_tool must remain a classmethod that lazily imports dspy.utils.mcp.convert_mcp_tool and delegates conversion, preserving the MCP-to-DSPy Tool integration boundary.
  ```
- **Applies to:**
  - `dspy/adapters/types/tool.py`
- **Condition:**
  ```text
  When modifying Tool.from_mcp_tool or the MCP conversion entry point it delegates to.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-bbcfbcc14c25a5a585452254.md)

## Rule

- **Rule:**
  ```text
  When a contributor modifies Tool._parse_function, explicit self.name/self.desc/self.args/self.arg_types values must take precedence over inference from func.__name__/type(func).__name__ and func.__doc__.
  ```
- **Applies to:**
  - `dspy/adapters/types/tool.py`
- **Condition:**
  ```text
  Modifying Tool._parse_function or adding a new tool-schema inference path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-c70235fda5501130229c6f66.md)

## Rule

- **Rule:**
  ```text
  Tool.__init__ must treat user-specified name, desc, args, arg_types, and arg_desc as suppressing automatic inference for those values, and must pass arg_desc into _parse_function after super().__init__ so arg_desc participates in parsing separately from the args/arg_types schema.
  ```
- **Applies to:**
  - `dspy/adapters/types/tool.py`
- **Condition:** when modifying Tool construction or argument parsing in dspy/adapters/types/tool.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-de472d81e116b4ba061677c4.md)
