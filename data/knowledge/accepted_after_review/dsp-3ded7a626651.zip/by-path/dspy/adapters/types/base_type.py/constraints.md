# Constraints for `dspy/adapters/types/base_type.py`

## Rule

- **Rule:**
  ```text
  split_message_content_for_custom_types must fall back to a raw text content block when the custom-type block is not valid JSON, rather than raising, so malformed custom-type payloads degrade to text.
  ```
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:** When modifying custom-type content splitting or its handling of malformed JSON payloads.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-51b94c4697e55d58c15f3457.md)

## Rule

- **Rule:**
  ```text
  When modifying BaseType.serialize_model, preserve the list-valued format() wrapping: list outputs must be wrapped in CUSTOM_TYPE_START_IDENTIFIER/CUSTOM_TYPE_END_IDENTIFIER markers, while non-list formatted values are returned unchanged.
  ```
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:**
  ```text
  when changing BaseType.serialize_model or the format() output handling for custom types
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-fe1a2ba4b93a8178cf30a4d8.md)
