# Constraints for `dspy/adapters/base.py`

## Rule

- **Rule:**
  ```text
  Adapter.acall must preprocess the signature, format inputs with demos, await lm.acall(messages=inputs, **lm_kwargs), then postprocess outputs against the original signature, preserving this async pipeline order.
  ```
- **Applies to:**
  - `dspy/adapters/base.py`
- **Condition:** when modifying the async adapter call pipeline in Adapter.acall
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2eee20b828262e4700659369.md)

## Rule

- **Rule:**
  ```text
  When modifying Adapter._get_tool_call_output_field_name, preserve the selection rule: return the name of the first output field whose annotation is ToolCalls, or None if no such field exists.
  ```
- **Applies to:**
  - `dspy/adapters/base.py`
- **Condition:**
  ```text
  when changing _get_tool_call_output_field_name or tool-call output field detection
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-62089838044d1243966717bc.md)

## Rule

- **Rule:**
  ```text
  _get_tool_call_input_field_name scans signature.input_fields and returns the first field whose annotation is list[Tool] or Tool, returning None otherwise; this is the adapter's protocol for locating the tool-call input field.
  ```
- **Applies to:**
  - `dspy/adapters/base.py`
- **Condition:**
  ```text
  when modifying Adapter._get_tool_call_input_field_name or tool-call input field detection
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-82da17a27675abee69b2506f.md)

## Rule

- **Rule:**
  ```text
  When modifying Adapter.format_field_structure, preserve its role as a required override: the base declaration raises NotImplementedError so adapter subclasses must define the system-message field format.
  ```
- **Applies to:**
  - `dspy/adapters/base.py`
- **Condition:**
  ```text
  Modifying Adapter.format_field_structure or the adapter subclass contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af746150c62785e2b65b727e.md)
