# Constraints for `dspy/adapters/xml_adapter.py`

## Rule

- **Rule:**
  ```text
  XMLAdapter field parsing must wrap any parse_value failure in AdapterParseError carrying adapter_name, signature, lm_response, and a message with the field and raw value.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:** when modifying XMLAdapter field parsing or its error handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0864177c6645431ce1b62030.md)

## Rule

- **Rule:**
  ```text
  XMLAdapter.format_field_with_value must wrap each field value as '<field.name>\n<formatted>\n</field.name>' and join fields with blank lines, then strip the result, defining the XML adapter's field serialization format.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:** When modifying XMLAdapter field serialization or the XML wire format emitted for field values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-890bc0aee05ce44ded01d55d.md)

## Rule

- **Rule:**
  ```text
  When modifying XMLAdapter.parse, preserve the strict output-field contract: extract only fields matching signature.output_fields, keep the first occurrence of each field, cast values via _parse_field_value, and raise AdapterParseError when parsed field keys do not exactly match the signature's output fields.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:** when changing XMLAdapter.parse or its output-field extraction and validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9a2de8aed755f90ec0bcb4b7.md)
