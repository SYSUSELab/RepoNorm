# Constraints for `dspy/adapters/chat_adapter.py`

## Rule

- **Rule:**
  ```text
  ChatAdapter.format_field_structure must place input and output fields in separate sections using '[[ ## field_name ## ]]' markers and append a '[[ ## completed ## ]]' marker to terminate the output fields section.
  ```
- **Applies to:**
  - `dspy/adapters/chat_adapter.py`
- **Condition:**
  ```text
  When modifying ChatAdapter.format_field_structure or the chat adapter field-section formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-74ea8e6d8251fc4359ab7529.md)

## Rule

- **Rule:**
  ```text
  The chat adapter must parse field headers using the pattern re.compile(r"\[\[ ## (\w+) ## \]\]"), fixing the field-header wire format used when parsing chat adapter outputs.
  ```
- **Applies to:**
  - `dspy/adapters/chat_adapter.py`
- **Condition:** When modifying chat adapter output parsing or the field-header wire format it recognizes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8cd14332c050e6a06d481aa7.md)

## Rule

- **Rule:**
  ```text
  ChatAdapter finetuning data must be emitted as a dict whose only key is 'messages' holding a list of chat messages, and the assistant message must end with the literal '\n\n[[ ## completed ## ]]\n' marker.
  ```
- **Applies to:**
  - `dspy/adapters/chat_adapter.py`
- **Condition:**
  ```text
  when modifying ChatAdapter.format_finetune_data or format_assistant_message_content
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9444e28a593ca190e0258e26.md)

## Rule

- **Rule:**
  ```text
  ChatAdapter.__call__ must fall back to JSONAdapter when the superclass call raises, except that ContextWindowExceededError and calls where self is already a JSONAdapter must re-raise the original exception.
  ```
- **Applies to:**
  - `dspy/adapters/chat_adapter.py`
- **Condition:**
  ```text
  When modifying ChatAdapter.__call__ or its exception handling around the superclass adapter call.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-acc201691ba26e7fdab4d315.md)
