# Constraints for `dspy/dsp/utils/metrics.py`

## Rule

- **Rule:**
  ```text
  em_score must compare normalize_text(prediction) to normalize_text(ground_truth), so exact-match scoring is normalization-sensitive and any change to normalization affects em_score results.
  ```
- **Applies to:**
  - `dspy/dsp/utils/metrics.py`
- **Condition:**
  ```text
  when modifying em_score or the normalization applied to predictions and ground truths in dspy/dsp/utils/metrics.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-7e65479738bffd6c44183f9a.md)

## Rule

- **Rule:**
  ```text
  f1_score must use token multiset intersection for num_same; when both prediction and ground truth tokenize to zero tokens it must not return 1.0, and when num_same == 0 it must return 0.
  ```
- **Applies to:**
  - `dspy/dsp/utils/metrics.py`
- **Condition:**
  ```text
  When modifying f1_score tokenization or scoring logic in dspy/dsp/utils/metrics.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-a4385b923b99ed3f487dcc0c.md)
