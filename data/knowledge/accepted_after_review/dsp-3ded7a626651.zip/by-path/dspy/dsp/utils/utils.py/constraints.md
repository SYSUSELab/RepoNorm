# Constraints for `dspy/dsp/utils/utils.py`

## Rule

- **Rule:**
  ```text
  load_batch_backgrounds must return None when qid2backgrounds is None, and otherwise join background passages with ' [SEP] ', resolving integer ids via args.collection and string ids via args.collectionX.get(pid, '').
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:**
  ```text
  When modifying load_batch_backgrounds id resolution or passage joining.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-0a334d3a2672b44616ec18a8.md)

## Rule

- **Rule:**
  ```text
  `create_directory` prints a note and skips `makedirs` when the path already exists, otherwise prints a creating message and calls `os.makedirs`, making directory creation idempotent with user-visible messaging.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:**
  ```text
  When modifying directory creation, preserve idempotence: skip `makedirs` with a note when the path exists, otherwise create with a message.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-9ba2417b0d86998ff0646697.md)
