# Constraints for `dspy/primitives/module.py`

## Rule

- **Rule:**
  ```text
  When modifying BaseModule.reset_copy, preserve deep-copy semantics: the returned copy has its parameters reset via param.reset() while the original module's parameters remain untouched.
  ```
- **Applies to:**
  - `dspy/primitives/module.py`
- **Condition:**
  ```text
  Modifying BaseModule.reset_copy or its parameter-reset behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-114a5628549216854f156440.md)

## Rule

- **Rule:**
  ```text
  When a DSPy module is compiled (frozen), named_parameters must not recurse into its sub-modules; only uncompiled sub-modules are traversed, and Parameter values found directly in self.__dict__ are always yielded.
  ```
- **Applies to:**
  - `dspy/primitives/module.py`
- **Condition:**
  ```text
  Modifying BaseModule.named_parameters or adding a new module container that stores sub-modules in __dict__ or in list/tuple/dict attributes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-73b44de0162ce3ea7c61b421.md)

## Rule

- **Rule:**
  ```text
  dspy.primitives.module must keep named_parameters intentionally different in behavior from named_sub_modules, preserving the deliberate compatibility boundary.
  ```
- **Applies to:**
  - `dspy/primitives/module.py`
- **Condition:**
  ```text
  When modifying named_parameters or named_sub_modules in dspy.primitives.module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7738549e7ee3aef35bad77ed.md)
