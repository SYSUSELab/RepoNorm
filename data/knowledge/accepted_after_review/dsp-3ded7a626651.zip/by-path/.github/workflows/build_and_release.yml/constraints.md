# Constraints for `.github/workflows/build_and_release.yml`

## Rule

- **Rule:** The TestPyPI job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-037f1faaef6c35ed71b47d43.md)

## Rule

- **Rule:** The TestPyPI job installs dependencies with python3 -m pip install --upgrade setuptools wheel twine build semver packaging.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a6195a62ea93adb09e076d4.md)

## Rule

- **Rule:**
  ```text
  The PyPI job updates the version in ./dspy/__metadata__.py by replacing the line after the #replace_package_version_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-67e18ea84b63fa59a196ecab.md)

## Rule

- **Rule:** The TestPyPI publish step uses the pypa/gh-action-pypi-publish action with repository-url set to https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6a3f4b8cc0a0a4d099aee145.md)

## Rule

- **Rule:** The build-and-publish-test-pypi job needs the extract-tag job.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6b18e9188346392ed1ba3eb7.md)

## Rule

- **Rule:**
  ```text
  The PyPI job updates the version in pyproject.toml by replacing the line after the #replace_package_version_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-72579594cab58f426abf07e0.md)

## Rule

- **Rule:** The PyPI job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8e66214383e3c4dafeff67e1.md)

## Rule

- **Rule:**
  ```text
  The PyPI job updates the package name in ./dspy/__metadata__.py to dspy by replacing the line after the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9cec14ccf3ff8d0baaae29c2.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-pypi job runs only when github.repository_owner equals 'stanfordnlp'.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Condition:**
  ```text
  workflow predicate: github.repository_owner == 'stanfordnlp'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ab22b606ca903c097c932cce.md)

## Rule

- **Rule:**
  ```text
  The TestPyPI job updates the package name in pyproject.toml to dspy-ai-test by replacing the line after the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af6d16622d0eb88e89a21eeb.md)

## Rule

- **Rule:** The build-and-publish-pypi job needs both the extract-tag and build-and-publish-test-pypi jobs.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cdb7450eeaca6d63ee6a9ef6.md)

## Rule

- **Rule:**
  ```text
  The workflow triggers on pushes of tags matching "*".
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d34421b5ef3f6ba48a648df2.md)

## Rule

- **Rule:** The PyPI job installs dependencies with python3 -m pip install --upgrade setuptools wheel twine build.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ea0523deb12b4ddd01bcbe05.md)

## Rule

- **Rule:**
  ```text
  The PyPI job updates the package name in pyproject.toml to dspy by replacing the line after the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ed16041ba4f4891810dfa961.md)

## Rule

- **Rule:**
  ```text
  The TestPyPI job updates the version in pyproject.toml by replacing the line after the #replace_package_version_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f01c1665274faa3ffbbd26c4.md)

## Rule

- **Rule:** The TestPyPI job builds the distribution with python3 -m build.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f316cad2badd3fe328707cbf.md)
