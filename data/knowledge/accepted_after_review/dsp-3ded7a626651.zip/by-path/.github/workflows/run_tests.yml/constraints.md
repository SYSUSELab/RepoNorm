# Constraints for `.github/workflows/run_tests.yml`

## Rule

- **Rule:** The workflow runs on pull requests of types opened, synchronize, and reopened.
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-280e8074eb0f68167a71b727.md)

## Rule

- **Rule:** The workflow runs on pushes to the main branch.
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44935b42dcfa787ea6021f26.md)

## Rule

- **Rule:**
  ```text
  The build_package job builds the package with uv run -p .venv python -m build, installs the built wheel from dist/*.whl, and verifies with uv run -p .venv python -c "import dspy".
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-71c9137610174b89acf28e14.md)

## Rule

- **Rule:** The fix job runs ruff check with --fix-only --diff --exit-non-zero-on-fix, and on failure prints guidance to run pre-commit run --all-files and exits 1.
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7ab3615fc727f33d0badc544.md)

## Rule

- **Rule:**
  ```text
  The build_package job runs on Python versions 3.10, 3.11, 3.12, and 3.13.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8343e3b680ea9726a35125f9.md)

## Rule

- **Rule:** The test job runs on Python versions 3.10, 3.11, 3.12, and 3.13.
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aeee5c30c76023aa774b9693.md)
