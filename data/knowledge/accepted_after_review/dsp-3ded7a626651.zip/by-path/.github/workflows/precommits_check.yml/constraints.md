# Constraints for `.github/workflows/precommits_check.yml`

## Rule

- **Rule:** Pull request titles are checked against a regexp requiring a conventional-commit-style type prefix such as break, build, ci, docs, feat, fix, perf, refactor, style, test, ops, hotfix, release, maint, init, enh, or revert, followed by a parenthesized scope and a colon plus description.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-091b079f7ec930defa9e2453.md)

## Rule

- **Rule:** The pre-commit-checks workflow runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-30a2c6acd8986e1eabb39572.md)

## Rule

- **Rule:** The workflow obtains the list of changed files using jitterbit/get-changed-files and exposes it as the files step output.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a761c491358b633acaa37ed0.md)

## Rule

- **Rule:** The workflow sets up Python version 3.9 with pip caching.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b53048543bda4db9ccce1172.md)

## Rule

- **Rule:** The Pre-Commit Checks step runs pre-commit run -v --files on the changed files list.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ec7422a7b5d954bd98cf2931.md)
