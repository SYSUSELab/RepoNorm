# Constraints for `setup.py`

## Rule

- **Rule:** The package name is updated by the workflow to allow the same files to be used to build both the pypi and test-pypi packages.
- **Applies to:**
  - `pyproject.toml`
  - `setup.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cea6d517dce457b347464bc4.md)
