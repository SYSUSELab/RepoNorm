# Rule details

- **Rule:** Template rendering must support Jinja2 loops and conditionals, and whitespace control with '-%}' must trim the trailing newline while conditionals render only their body when true.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When modifying or adding template-rendering test cases that exercise Jinja2 control structures or whitespace-control syntax.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/templates.py:156-186`
- `tests/test_templates.py:141-179`
