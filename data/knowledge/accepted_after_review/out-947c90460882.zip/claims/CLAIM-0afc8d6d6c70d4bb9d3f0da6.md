# Rule details

- **Rule:** Tests for the Dottxt model must assert that streaming raises NotImplementedError with the message 'Dottxt does not support streaming'.
- **Applies to:**
  - `tests/models/test_dottxt.py`
- **Condition:** When adding or modifying a test that covers the Dottxt model's streaming behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_dottxt.py:125-131`
