# Rule details

- **Rule:**
  ```text
  When modifying the steerable generator's call path, preserve the reset of the logits processor before each `model.generate` call so stateful processors are reinitialized per generation.
  ```
- **Applies to:**
  - `outlines/generator.py`
- **Condition:** When changing the steerable generator's invocation of model.generate.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generator.py:279-299`
- `outlines/processors/base_logits_processor.py:48-54`
