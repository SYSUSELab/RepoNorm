# Rule details

- **Rule:**
  ```text
  is_union must return True for Union[int, str] and Optional[int], and False for list, a list literal, and Literal[int, str].
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when adding or modifying is_union predicate tests or implementation
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/utils.py:115-120`
- `tests/types/test_types_utils.py:267-272`
