# Rule details

- **Rule:**
  ```text
  Ollama's generate_batch must raise NotImplementedError because the ollama library does not support batch inference; do not implement batch generation for this backend.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:** when adding or modifying batch generation support for the Ollama backend
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/ollama.py:219-227`
