# Rule details

- **Rule:**
  ```text
  Chat.add_user_message must append a dict with role "user" and the given content to self.messages, preserving the message representation used by the Chat input type.
  ```
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:**
  ```text
  When modifying Chat.add_user_message or the Chat message representation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/inputs.py:157-166`
- `tests/test_inputs.py:145-158`
