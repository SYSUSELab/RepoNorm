# Rule details

- **Rule:** The OpenAI type adapter test module must define a nested dataclass Audio with a file string field to cover dataclass-based schema handling.
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when adding or modifying dataclass-based schema coverage in OpenAI type adapter tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_openai_type_adapter.py:111-117`
