# Rule details

- **Rule:**
  ```text
  outlines.inputs.Video must be a dataclass wrapping an arbitrary video value, intended to be passed alongside a text prompt in a list as model_input to video-capable models.
  ```
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying the Video input type or its usage in model inputs
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/inputs.py:40-54`
- `tests/test_inputs.py:61-64`
