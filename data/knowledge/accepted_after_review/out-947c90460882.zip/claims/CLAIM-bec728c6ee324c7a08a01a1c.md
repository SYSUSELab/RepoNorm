# Rule details

- **Rule:** Tests for application template rendering must assert that a missing variable raises jinja2.exceptions.UndefinedError, confirming StrictUndefined behavior.
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:**
  ```text
  When adding or modifying application template rendering tests in tests/test_applications.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/templates.py:180-186`
- `tests/test_applications.py:68-74`
