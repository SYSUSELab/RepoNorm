# Rule details

- **Rule:** Examples that constrain generation to a fixed vocabulary must define the choices as a str Enum (e.g. Armor, Weapon) and reference those enums from the Pydantic model, rather than using free-form strings.
- **Applies to:**
  - `examples/llamacpp_example.py`
- **Condition:** When editing the llamacpp example's constrained-choice fields or their enum definitions.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The llamacpp example defines Armor and Weapon as str Enums and references them as typed fields in the Character Pydantic model, satisfying the fixed-vocabulary enum rule.
```

- **Sources:**
  - `examples/llamacpp_example.py`
