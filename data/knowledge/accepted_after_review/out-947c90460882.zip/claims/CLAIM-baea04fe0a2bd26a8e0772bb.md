# Rule details

- **Rule:**
  ```text
  from_vllm must dispatch on the OpenAI client type: openai.OpenAI yields a synchronous VLLM, openai.AsyncOpenAI yields AsyncVLLM, and any other client type raises ValueError, so callers must pass one of those two client classes.
  ```
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:**
  ```text
  When modifying from_vllm or adding new client type support to the vLLM model integration.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/vllm.py:348-378`
