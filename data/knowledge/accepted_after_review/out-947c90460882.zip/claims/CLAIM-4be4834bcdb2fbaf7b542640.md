# Rule details

- **Rule:** Alternatives must remain a dataclass Term holding a list of Term objects, preserving the recursive term-container representation of alternatives in the DSL.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when modifying or adding term container types in outlines/types/dsl.py
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/dsl.py:431-445`
- `tests/types/test_dsl.py:99-106`
