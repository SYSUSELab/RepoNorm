# Rule details

- **Rule:** Tests for streaming model APIs must assert that model.stream returns a Generator whose first yielded item is a str.
- **Applies to:**
  - `tests/models/test_gemini.py`
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying a test for a model's streaming API
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_gemini.py:243-247`
