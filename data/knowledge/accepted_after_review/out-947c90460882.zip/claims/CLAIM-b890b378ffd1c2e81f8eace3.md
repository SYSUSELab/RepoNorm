# Rule details

- **Rule:** The Anthropic wrong-output-type test asserts that model.generate with a Foo(1) output type raises NotImplementedError matching 'is not available', documenting rejection of unsupported output types.
- **Applies to:**
  - `tests/models/test_anthropic.py`
- **Condition:** when modifying or extending Anthropic model.generate output type handling or its tests
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test deliberately passes Foo(1) inside pytest.raises(NotImplementedError, match='is not available'), confirming the expected rejection of unsupported output types.
```

- **Sources:**
  - `tests/models/test_anthropic.py:76-83`
