# Rule details

- **Rule:** For all files, trailing whitespace is trimmed.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
trim_trailing_whitespace = true

```

- **Sources:**
  - `.editorconfig:11`
