# Rule details

- **Rule:** Chat.extend must append a list of message dicts to self.messages, defining the mutation semantics for extending a chat conversation.
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying Chat.extend's message mutation behavior
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Chat.extend appends the provided list of message dicts to self.messages via self.messages.extend(messages), matching the Chat.extend mutation contract.
```

- **Sources:**
  - `outlines/inputs.py:124-133`
