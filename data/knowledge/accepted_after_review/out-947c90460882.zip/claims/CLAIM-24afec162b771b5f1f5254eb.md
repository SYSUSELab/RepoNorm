# Rule details

- **Rule:**
  ```text
  The transformers integration module's public API is exactly `Transformers`, `TransformersMultiModal`, and `from_transformers` via `__all__`; adding a new public symbol requires updating this list.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When adding, renaming, or removing a public symbol in the transformers integration module.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/transformers.py:14-23`
