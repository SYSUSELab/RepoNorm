# Rule details

- **Rule:** diff-cover uses ".." as the diff range notation.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
diff_range_notation = ".."

```

- **Sources:**
  - `pyproject.toml:202`

## Review evidence locations

- `pyproject.toml:200-202`
