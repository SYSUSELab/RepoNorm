# Rule details

- **Rule:**
  ```text
  TorchTensorAdapter.to_device must be implemented as tensor.to(device), relying on torch's native device transfer rather than custom logic.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/torch.py`
- **Condition:** when modifying the torch tensor adapter's device transfer behavior
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
TorchTensorAdapter.to_device is implemented as tensor.to(device), delegating to torch's native device transfer.
```

- **Sources:**
  - `outlines/processors/tensor_adapters/torch.py:38-39`
