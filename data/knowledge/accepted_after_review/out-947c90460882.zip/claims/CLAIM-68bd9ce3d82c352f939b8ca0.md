# Rule details

- **Rule:**
  ```text
  The BentoML example service must keep its DEFAULT_SCHEMA JSON schema in sync with the Character model: required fields name, age, armor, weapon, strength and $ref-based Armor/Weapon enum definitions must match the schema the service expects.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
- **Condition:**
  ```text
  When modifying the BentoML example's Character schema or its DEFAULT_SCHEMA JSON definition.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The BentoML example defines DEFAULT_SCHEMA with required fields name, age, armor, weapon, strength and $ref-based Armor/Weapon enum definitions, matching the Character schema contract.
```

- **Sources:**
  - `examples/bentoml/service.py`
