# Rule details

- **Rule:**
  ```text
  The SGLang model constructor must store the client and optional model_name and instantiate SGLangTypeAdapter.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:** when modifying the SGLang model constructor
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/sglang.py:92-104`
