# Rule details

- **Rule:**
  ```text
  Tests that exercise a real external server must gate on an environment variable (e.g. TGI_SERVER_URL) and fall back to mock clients with a warning when it is unset, registering mock responses only in the mock path.
  ```
- **Applies to:**
  - `tests/models/test_tgi.py`
- **Condition:** when adding or modifying a test that can run against a real external server or a mock
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_tgi.py:20-29`
- `tests/models/test_tgi.py:77-81`
