# Rule details

- **Rule:** Tests for the async Ollama model must await the coroutine returned by generate(...) and assert the awaited result is a str, reflecting that the async API returns a plain string rather than a parsed object.
- **Applies to:**
  - `tests/models/test_ollama.py`
- **Condition:** When adding or modifying a test that calls the async Ollama model's generate method.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_ollama.py:196-201`
