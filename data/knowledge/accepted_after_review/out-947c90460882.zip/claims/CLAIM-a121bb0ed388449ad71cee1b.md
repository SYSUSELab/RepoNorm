# Rule details

- **Rule:** The dev container enables the nvidia-cuda devcontainer feature with cudaVersion set to 12.4.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      "cudaVersion": "12.4"

```

- **Sources:**
  - `.devcontainer/devcontainer.json:15`

## Review evidence locations

- `.devcontainer/devcontainer.json:10-16`
