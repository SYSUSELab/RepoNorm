# Rule details

- **Rule:**
  ```text
  Tests that exercise the public Generator construction path must keep the model-required contract: constructing Generator(None, output_type) raises ValueError, and constructing Generator with a black-box async model plus a processor raises NotImplementedError on the synchronous path.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding tests around Generator construction, including the no-model and async-black-box-with-processor cases.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generator.py:346-357`
- `outlines/generator.py:388-405`
- `tests/test_generator.py:177-179`
- `tests/test_generator.py:220-222`
