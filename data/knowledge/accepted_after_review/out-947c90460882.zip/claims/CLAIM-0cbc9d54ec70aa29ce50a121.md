# Rule details

- **Rule:**
  ```text
  vllm_offline.generate_stream must raise NotImplementedError with the message 'Streaming is not available for the vLLM offline integration.'
  ```
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:** when modifying streaming support for the vLLM offline integration
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/vllm_offline.py:226-234`
