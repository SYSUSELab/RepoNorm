# Rule details

- **Rule:**
  ```text
  Run `asv continuous origin/main HEAD --config benchmarks/asv.conf.json` to benchmark the current HEAD against origin/main using the repository's asv configuration.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
asv continuous origin/main HEAD --config benchmarks/asv.conf.json

```

- **Sources:**
  - `docs/community/contribute.md:136`

## Review evidence locations

- `docs/community/contribute.md:132-137`
