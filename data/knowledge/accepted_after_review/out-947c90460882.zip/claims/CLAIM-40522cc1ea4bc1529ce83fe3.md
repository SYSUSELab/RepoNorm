# Rule details

- **Rule:** Commit messages must follow the referenced git commit message guidelines.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- [ ] **Commit messages** follow these [guidelines][git-guidelines];

```

- **Sources:**
  - `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:10`

## Review evidence locations

- `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:9-10`
- `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:21-23`
