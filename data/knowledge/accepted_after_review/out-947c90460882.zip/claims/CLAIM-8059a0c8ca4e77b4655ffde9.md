# Rule details

- **Rule:**
  ```text
  MLXLMTypeAdapter.format_str_input must register a str handler that returns the string unchanged, so plain string inputs pass through without wrapping.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:**
  ```text
  When modifying format_str_input or adding new input type handlers to the MLXLM type adapter.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/mlxlm.py:20-42`
