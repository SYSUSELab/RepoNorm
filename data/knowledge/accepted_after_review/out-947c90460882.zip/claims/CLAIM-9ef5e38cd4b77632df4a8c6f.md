# Rule details

- **Rule:**
  ```text
  Tests for model output type adapters must assert that format_output_type converts a Pydantic model into the expected schema representation.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:** when adding or modifying output type adapter tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_ollama_type_adapter.py:138-144`
