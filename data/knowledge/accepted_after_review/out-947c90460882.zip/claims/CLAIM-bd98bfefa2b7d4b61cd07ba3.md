# Rule details

- **Rule:**
  ```text
  The gen-files plugin runs the script scripts/gen_ref_pages.py.
  ```
- **Applies to:**
  - `scripts/gen_ref_pages.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
    - gen-files:
        scripts:
        - scripts/gen_ref_pages.py

```

- **Sources:**
  - `mkdocs.yml:110-112`
