# Rule details

- **Rule:** Tests that exercise multimodal chat input must construct a Chat with a system message and a user message containing text plus an Image, and assert the model returns a str, rather than testing text-only chat.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying a test for multimodal chat input
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_openai.py:130-139`
