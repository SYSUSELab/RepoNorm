# Rule details

- **Rule:**
  ```text
  get_country_flags must derive each flag from the Alpha2 enum member name by offsetting from the regional-indicator base codepoint ord('🇦'), so flag generation depends on two-letter uppercase ISO codes.
  ```
- **Applies to:**
  - `outlines/types/countries.py`
- **Condition:**
  ```text
  When modifying get_country_flags or the Alpha2 enum member naming.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/countries.py:8-19`
