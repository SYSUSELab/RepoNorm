# Rule details

- **Rule:** PRs must link to all relevant issues, discussions, and PRs.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- [ ] There are links to *all* the relevant issues, discussions and PRs;

```

- **Sources:**
  - `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:8`

## Review evidence locations

- `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:6-9`
