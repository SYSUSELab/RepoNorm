# Rule details

- **Rule:** Tests that exercise a model's async call contract must await the async model instance with a string prompt and assert the result is a str, rather than only testing the sync path.
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying a test for an async model's call contract
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_sglang.py:307-310`
