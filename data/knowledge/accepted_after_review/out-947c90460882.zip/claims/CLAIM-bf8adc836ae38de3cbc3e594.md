# Rule details

- **Rule:** Chat message inputs must be dicts carrying 'role' and 'content' keys, where role is one of user/assistant/system and content is a string or a list containing a string plus multimodal assets; string prompts are passed through unchanged rather than being wrapped into chat messages.
- **Applies to:**
  - `outlines/inputs.py`
  - `outlines/models/tgi.py`
- **Condition:** When changing how chat messages are validated or how string prompts are converted into model inputs.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Chat is the chat-message input type in outlines/inputs.py; its docstring and messages field establish the role/content dict shape with allowed roles and string-or-list content, and the class is the entity the rule governs.
```

- **Sources:**
  - `outlines/inputs.py:75-183`

### Evidence 2 — current_observation

```text
TGITypeAdapter.format_str_input is registered for str and returns the string unchanged, establishing that plain string prompts bypass chat-message wrapping.
```

- **Sources:**
  - `outlines/models/tgi.py:47-48`
