# Rule details

- **Rule:**
  ```text
  Model adapters must implement format_output_type so that black-box models produce a response_format argument while steerable models format the logits processor for the model's expected object type.
  ```
- **Applies to:**
  - `outlines/models/base.py`
  - `outlines/models/gemini.py`
- **Condition:**
  ```text
  when adding or modifying a model adapter's format_output_type implementation
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/base.py:41-60`
