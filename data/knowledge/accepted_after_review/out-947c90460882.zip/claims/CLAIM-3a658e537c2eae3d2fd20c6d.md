# Rule details

- **Rule:**
  ```text
  Tests for BlackBoxGenerator streaming must assert that stream returns a TypingGenerator whose next value is a str, and that awaiting AsyncBlackBoxGenerator with a string output type and max_tokens=10 returns a str.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:**
  ```text
  When adding or modifying BlackBoxGenerator streaming or async call tests in tests/test_generator.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generator.py:91-109`
- `outlines/generator.py:135-153`
- `tests/test_generator.py:141-161`
