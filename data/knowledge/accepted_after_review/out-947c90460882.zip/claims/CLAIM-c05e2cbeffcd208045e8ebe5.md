# Rule details

- **Rule:** TGITypeAdapter must subclass ModelTypeAdapter and serve as the type adapter for TGI and AsyncTGI models.
- **Applies to:**
  - `outlines/models/tgi.py`
- **Condition:** when modifying the TGI type adapter or its model associations
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/tgi.py:23-24`
- `outlines/models/tgi.py:98-107`
- `outlines/models/tgi.py:205-224`
