# Rule details

- **Rule:** For all files, indentation uses spaces.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
indent_style = space

```

- **Sources:**
  - `.editorconfig:7`

## Review evidence locations

- `.editorconfig:3-15`
