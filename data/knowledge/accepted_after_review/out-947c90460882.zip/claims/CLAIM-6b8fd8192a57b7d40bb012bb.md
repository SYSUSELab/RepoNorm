# Rule details

- **Rule:** Chat.append must append the provided message dict directly to self.messages, allowing arbitrary role/content dicts to be added to the chat.
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying or extending Chat.append or the chat message accumulation behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/inputs.py:113-122`
- `tests/test_inputs.py:94-99`
