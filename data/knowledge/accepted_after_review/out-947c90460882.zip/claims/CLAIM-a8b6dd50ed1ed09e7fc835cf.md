# Rule details

- **Rule:**
  ```text
  When modifying the Ollama format_input singledispatchmethod, preserve the base implementation raising TypeError stating only str, list, and Chat input types are available.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:**
  ```text
  When changing the base implementation or dispatch behavior of Ollama format_input.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/ollama.py:29-48`
