# Rule details

- **Rule:** The ruff pre-commit hook runs with --config=pyproject.toml.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    - id: ruff
      args: ["--config=pyproject.toml"]

```

- **Sources:**
  - `.pre-commit-config.yaml:19-20`

## Review evidence locations

- `.pre-commit-config.yaml:16-20`
