# Rule details

- **Rule:** Pytest treats warnings as errors by default (filterwarnings includes "error"), except for the explicitly ignored warning categories.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
filterwarnings = [
    "error",
    "ignore::pydantic.warnings.PydanticDeprecatedSince20",
    "ignore::FutureWarning:transformers.*",
    "ignore::FutureWarning:huggingface_hub.*",
    "ignore::UserWarning",
    "ignore::DeprecationWarning:pyairports.*",
    "ignore::DeprecationWarning:jax.*",
    "ignore::DeprecationWarning:flax.*",
]

```

- **Sources:**
  - `pyproject.toml:115-124`
