# Rule details

- **Rule:** LlamaCpp type adapter tests instantiate LlamaCppTypeAdapter directly as the adapter fixture, indicating the adapter is usable without a model instance.
- **Applies to:**
  - `tests/models/test_llamacpp_type_adapter.py`
- **Condition:** when modifying or extending LlamaCpp type adapter fixtures or their tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_llamacpp_type_adapter.py:13-15`
