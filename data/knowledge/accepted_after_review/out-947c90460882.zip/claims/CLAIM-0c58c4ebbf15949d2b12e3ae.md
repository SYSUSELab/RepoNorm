# Rule details

- **Rule:** The dev container enables the conda devcontainer feature.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
    "ghcr.io/devcontainers/features/conda:1": {},

```

- **Sources:**
  - `.devcontainer/devcontainer.json:11`
