# Rule details

- **Rule:** Read the Docs uses docs/source/conf.py as the Sphinx configuration file.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  configuration: docs/source/conf.py

```

- **Sources:**
  - `.readthedocs.yaml:14`

## Review evidence locations

- `.readthedocs.yaml:12-15`
