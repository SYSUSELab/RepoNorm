# Rule details

- **Rule:**
  ```text
  VLLMOffline.generate_batch must raise TypeError when any input is a Chat instance, keeping batch generation explicitly unsupported for Chat inputs.
  ```
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:**
  ```text
  when modifying VLLMOffline.generate_batch in outlines/models/vllm_offline.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/vllm_offline.py:183-217`
