# Rule details

- **Rule:**
  ```text
  Tests for model backends must preserve the documented availability guard: MLX tests set TEST_MODEL to the pinned model and guard availability via mx.metal.is_available() inside a try/except ImportError that sets HAS_MLX = False.
  ```
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying tests for a model backend that requires optional hardware or library availability
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_mlxlm.py:16-25`
