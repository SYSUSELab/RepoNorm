# Rule details

- **Rule:**
  ```text
  The TransformersTypeAdapter fixture overrides the tokenizer's chat_template with a custom role/content template, so chat formatting tests depend on this injected template.
  ```
- **Applies to:**
  - `tests/models/test_transformers_type_adapter.py`
- **Condition:** when modifying or extending TransformersTypeAdapter fixtures or chat formatting tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_transformers_type_adapter.py:17-24`
