# Rule details

- **Rule:**
  ```text
  Type-adapter input formatting must preserve the provider-specific message envelope: Anthropic text input becomes a single user message with the raw string as content, while OpenAI vision input becomes a user message with a text part plus an image_url part carrying a base64 data URI.
  ```
- **Applies to:**
  - `tests/models/test_anthopic_type_adapter.py`
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** When modifying or adding type-adapter input-formatting tests for text or vision inputs.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_openai_type_adapter.py:56-79`
- `tests/models/test_anthopic_type_adapter.py:30-33`
