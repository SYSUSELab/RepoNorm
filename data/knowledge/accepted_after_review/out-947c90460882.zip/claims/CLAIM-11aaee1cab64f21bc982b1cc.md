# Rule details

- **Rule:** The style job runs pre-commit via the pre-commit/action action.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    - uses: pre-commit/action@v3.0.0

```

- **Sources:**
  - `.github/workflows/tests.yml:18`

## Review evidence locations

- `.github/workflows/tests.yml:9-18`
