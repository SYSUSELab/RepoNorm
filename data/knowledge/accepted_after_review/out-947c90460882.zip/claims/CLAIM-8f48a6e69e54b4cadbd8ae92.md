# Rule details

- **Rule:**
  ```text
  Tests that exercise the public SteerableGenerator construction must preserve the processor-binding contract: SteerableGenerator.from_processor(model, processor) sets generator.logits_processor to the supplied processor and generator.model to the supplied model.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:**
  ```text
  When modifying or adding tests around SteerableGenerator.from_processor.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generator.py:259-277`
- `tests/test_generator.py:90-93`
