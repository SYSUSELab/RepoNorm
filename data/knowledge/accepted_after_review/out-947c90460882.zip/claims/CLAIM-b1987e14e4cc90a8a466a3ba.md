# Rule details

- **Rule:**
  ```text
  The transformers multiple-samples test must assert that a single call returns a string, while passing num_return_sequences=2 with do_sample=True returns a list of length 2, documenting the sampling-dependent return shape.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when changing the transformers multiple-samples test or its sampling-dependent return-shape assertions
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_transformers_multiple_samples asserts a single call returns a str and num_return_sequences=2 with do_sample=True returns a list of length 2.
```

- **Sources:**
  - `tests/models/test_transformers.py`
