# Rule details

- **Rule:**
  ```text
  Gemini type adapter's format_output_type for a TypedDict must return a dict with response_mime_type 'application/json' and response_schema set to the type itself, defining the Gemini structured-output mapping.
  ```
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
- **Condition:**
  ```text
  when modifying or extending Gemini type adapter format_output_type or its tests
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_gemini_type_adapter_output_typed_dict asserts format_output_type(User) returns response_mime_type 'application/json' and response_schema set to User, matching the Gemini structured-output mapping.
```

- **Sources:**
  - `tests/models/test_gemini_type_adapter.py:175-184`
