# Rule details

- **Rule:**
  ```text
  Tests that exercise schema preprocessing must verify that the ensure_ascii parameter controls whether non-ASCII characters are escaped (e.g. 'café' becomes 'caf\u00e9' when True and stays literal when False), rather than only testing the default.
  ```
- **Applies to:**
  - `tests/types/test_json_schema_union_types.py`
- **Condition:**
  ```text
  when adding or modifying a test for schema preprocessing with the ensure_ascii option
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/json_schema_utils.py:7-27`
- `outlines/types/json_schema_utils.py:48-56`
- `tests/types/test_json_schema_union_types.py:91-101`
