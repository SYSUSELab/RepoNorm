# Rule details

- **Rule:**
  ```text
  Application initialization tests must assert that a newly constructed Application stores the given template and output_type but leaves model and generator as None, documenting the expected unbound state before a model is attached.
  ```
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:** When modifying or adding tests for Application initialization state.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/applications.py:55-74`
- `tests/test_applications.py:28-36`
