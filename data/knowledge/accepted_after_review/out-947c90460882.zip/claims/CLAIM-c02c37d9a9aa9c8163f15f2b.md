# Rule details

- **Rule:** Tests that exercise a model backend requiring an API key must use a session-scoped fixture that constructs the client once and shares it across the session.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** When adding or modifying a model fixture for a backend that requires an API key.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The model fixture is session-scoped and constructs OpenAI(OpenAIClient(api_key=api_key), MODEL_NAME) once for sharing across the session.
```

- **Sources:**
  - `tests/models/test_openai.py:49-50`
