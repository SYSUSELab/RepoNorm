# Rule details

- **Rule:**
  ```text
  TensorAdapter subclasses must implement argsort_descending to return indices that sort the tensor in descending order along axis -1.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/**/*.py`
- **Condition:**
  ```text
  when adding or modifying a TensorAdapter subclass or its argsort_descending implementation
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/processors/tensor_adapters/base.py:238-256`
- `tests/processors/test_tensor_adapters.py:267-276`
