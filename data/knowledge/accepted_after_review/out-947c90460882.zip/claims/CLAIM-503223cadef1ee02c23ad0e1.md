# Rule details

- **Rule:**
  ```text
  Test collection must skip any test whose nodeid contains test_integration_vllm on non-Linux platforms, since vLLM only supports Linux (including WSL).
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When modifying or adding pytest collection hooks that gate platform-specific tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/conftest.py:6-17`
