# Rule details

- **Rule:**
  ```text
  OllamaTypeAdapter.format_output_type must raise TypeError for Regex and CFG output types, return None for None, convert JsonSchema/dataclass/TypedDict/Pydantic/genson schemas to JSON schema, and raise TypeError for unsupported types, defining Ollama's structured-output support boundary.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:**
  ```text
  When modifying format_output_type or adding new output type support to the Ollama backend.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/ollama.py:110-160`
