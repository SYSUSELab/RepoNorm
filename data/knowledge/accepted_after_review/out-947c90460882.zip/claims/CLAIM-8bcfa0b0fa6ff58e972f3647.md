# Rule details

- **Rule:** Tests that exercise the public Chat input must preserve the append contract: appending a message dict increases messages length to 1 and stores the exact message dict.
- **Applies to:**
  - `tests/test_inputs.py`
- **Condition:** When modifying or adding tests around Chat message appending.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/inputs.py:113-122`
- `tests/test_inputs.py:94-99`
