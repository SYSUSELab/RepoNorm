# Rule details

- **Rule:** The conda environment pins python==3.10.0.
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
dependencies:
  - python==3.10.0

```

- **Sources:**
  - `environment.yml:10-11`
