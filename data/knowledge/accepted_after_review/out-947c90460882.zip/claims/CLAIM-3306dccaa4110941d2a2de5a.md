# Rule details

- **Rule:**
  ```text
  Backend tests must import the private _get_backend alongside the public get_json_schema_logits_processor, get_regex_logits_processor, and get_cfg_logits_processor, exercising backend selection through the private helper.
  ```
- **Applies to:**
  - `tests/backends/test_backends.py`
- **Condition:**
  ```text
  When adding or modifying backend selection tests in tests/backends/test_backends.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/backends/test_backends.py:5-10`
