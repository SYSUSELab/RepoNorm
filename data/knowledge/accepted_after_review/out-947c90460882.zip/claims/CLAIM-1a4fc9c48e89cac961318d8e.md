# Rule details

- **Rule:** When adding or modifying a model backend's output-type handling, preserve the distinction that steerable backends compile the output type into logits processors while black-box backends pass the output type directly to the model without compilation.
- **Applies to:**
  - `outlines/generator.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/vllm.py`
- **Condition:** When changing how a generator or model backend converts an output type into generation constraints.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generator.py:28-49`
- `outlines/generator.py:197-257`
- `tests/test_generator.py:187-217`
