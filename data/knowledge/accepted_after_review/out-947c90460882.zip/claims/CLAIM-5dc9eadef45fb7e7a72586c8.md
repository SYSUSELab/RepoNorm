# Rule details

- **Rule:**
  ```text
  The dottxt type adapter test fixture must supply a JSON schema object requiring user_id and name.
  ```
- **Applies to:**
  - `tests/models/test_dottxt_type_adapter.py`
- **Condition:** When adding or modifying the JSON schema fixture used by dottxt type adapter tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_dottxt_type_adapter.py:21-31`
