# Rule details

- **Rule:**
  ```text
  Tests for tokenizer token-to-string conversion must cover the llama-specific byte-token handling (e.g. '<0x20>' converting to a space) in addition to regular token conversion.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:**
  ```text
  When adding or modifying tokenizer convert_token_to_string tests.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_transformers_tokenizer.py:89-101`
