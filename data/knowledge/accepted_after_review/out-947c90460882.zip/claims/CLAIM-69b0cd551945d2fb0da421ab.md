# Rule details

- **Rule:**
  ```text
  Dottxt format_input accepts only str inputs and raises TypeError for any other type, so contributors must not pass non-string model inputs to this adapter.
  ```
- **Applies to:**
  - `outlines/models/dottxt.py`
- **Condition:**
  ```text
  When modifying Dottxt format_input or adding input handling to the Dottxt adapter.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
DottxtTypeAdapter.format_input returns the input when it is a str and otherwise raises TypeError, matching the str-only contract.
```

- **Sources:**
  - `outlines/models/dottxt.py:26-45`
