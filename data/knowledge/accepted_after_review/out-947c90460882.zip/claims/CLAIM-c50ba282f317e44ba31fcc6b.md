# Rule details

- **Rule:**
  ```text
  `get_regex_logits_processor` must map backend names to processor classes: "outlines_core" to OutlinesCoreLogitsProcessor, "llguidance" to LLGuidanceLogitsProcessor, and "xgrammar" to XGrammarLogitsProcessor.
  ```
- **Applies to:**
  - `tests/backends/test_backends.py`
- **Condition:**
  ```text
  when changing backend-name-to-processor-class dispatch in get_regex_logits_processor
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/backends/test_backends.py:97-105`
