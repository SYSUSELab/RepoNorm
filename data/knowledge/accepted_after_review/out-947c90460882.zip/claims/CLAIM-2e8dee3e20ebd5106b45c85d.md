# Rule details

- **Rule:** The DSL exactly() method must remain a fluent combinator returning a QuantifyExact wrapping the receiver, so callers can chain quantification onto an existing type expression.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when modifying or adding fluent combinator methods on DSL Term types in outlines/types/dsl.py
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/dsl.py:184-188`
- `outlines/types/dsl.py:564-567`
