# Rule details

- **Rule:**
  ```text
  Tests that exercise a real model backend must construct the model through the public client-plus-model-name entry point (e.g. Ollama(Client(), MODEL_NAME), AsyncOllama(AsyncClient(), MODEL_NAME), from_sglang(OpenAI(...))), and must not substitute a mock server when the test's purpose is to exercise real initialization.
  ```
- **Applies to:**
  - `tests/models/test_ollama.py`
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying a test that constructs a real model backend client
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_ollama.py:19-36`
- `tests/models/test_sglang.py:198-229`
