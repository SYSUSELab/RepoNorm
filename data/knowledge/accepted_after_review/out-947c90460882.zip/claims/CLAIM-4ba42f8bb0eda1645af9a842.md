# Rule details

- **Rule:**
  ```text
  The SGLang type adapter's format_input for a plain string prompt must produce a single user-role message with the string as content, establishing the minimal text-input normalization contract.
  ```
- **Applies to:**
  - `tests/models/test_sglang_type_adapter.py`
- **Condition:**
  ```text
  when changing SGLang type adapter format_input handling of plain string prompts
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test module asserts that format_input for a plain string prompt produces a single user-role message with the string as content, matching the user-message normalization contract.
```

- **Sources:**
  - `tests/models/test_sglang_type_adapter.py`
