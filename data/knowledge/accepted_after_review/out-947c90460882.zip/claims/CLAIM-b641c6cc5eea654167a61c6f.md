# Rule details

- **Rule:** Optional is a dataclass Term wrapping a single Term, indicating the DSL represents optionality as a recursive term container.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when modifying the Optional term in the DSL
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/dsl.py:417-428`
