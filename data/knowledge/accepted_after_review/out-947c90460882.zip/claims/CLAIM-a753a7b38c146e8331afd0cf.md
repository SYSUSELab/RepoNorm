# Rule details

- **Rule:**
  ```text
  get_llama_tokenizer_types must return LlamaTokenizer, LlamaTokenizerFast, CodeLlamaTokenizer, CodeLlamaTokenizerFast in that exact order.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** when adding or modifying tokenizer type list tests or implementation
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_transformers_tokenizer.py:46-51`
