# Rule details

- **Rule:** Coverage reports file paths relative to the repository root.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
relative_files = true

```

- **Sources:**
  - `pyproject.toml:190`

## Review evidence locations

- `pyproject.toml:175-190`
