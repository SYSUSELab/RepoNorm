# Rule details

- **Rule:**
  ```text
  When modifying the MLX generate path, preserve the lazy import of `mlx_lm.generate` and the delegation of output-type handling to the type adapter via `logits_processors=self.type_adapter.format_output_type(output_type)`.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:** When changing how the MLX generate path imports or delegates output-type handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/mlxlm.py:97-129`
