# Rule details

- **Rule:**
  ```text
  SGLangTypeAdapter.format_input must delegate to OpenAITypeAdapter().format_input(model_input) so that sglang input formatting stays aligned with the OpenAI adapter.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:**
  ```text
  when modifying SGLang input formatting or the OpenAI type adapter's format_input contract
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/sglang.py:28-45`
