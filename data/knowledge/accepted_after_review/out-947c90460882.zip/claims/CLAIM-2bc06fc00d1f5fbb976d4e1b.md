# Rule details

- **Rule:** Merging is blocked unless benchmarks are run for the latest commit.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- Merging is blocked unless benchmarks are run for the latest commit.

```

- **Sources:**
  - `docs/community/contribute.md:142`

## Review evidence locations

- `docs/community/contribute.md:139-144`
