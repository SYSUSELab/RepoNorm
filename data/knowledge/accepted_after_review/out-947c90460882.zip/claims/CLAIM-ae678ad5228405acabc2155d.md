# Rule details

- **Rule:**
  ```text
  get_schema_pydantic must dispatch on type(BaseModel) and branch on the presence of model_json_schema: Pydantic v2 models use the "$defs" key while older models fall back to "definitions" via model.schema(); the fallback branch is marked pragma: no cover, so contributors should not expect coverage for the legacy path.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  When modifying get_schema_pydantic or adding Pydantic version compatibility handling in the templates module.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/templates.py:272-298`
