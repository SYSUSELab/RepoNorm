# Rule details

- **Rule:**
  ```text
  The backends package must define CFG_DEFAULT_BACKEND as 'llguidance' while JSON_SCHEMA_DEFAULT_BACKEND and REGEX_DEFAULT_BACKEND are 'outlines_core'.
  ```
- **Applies to:**
  - `outlines/backends/__init__.py`
- **Condition:** when modifying default backend selection constants in the backends package
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The backends module defines CFG_DEFAULT_BACKEND = 'llguidance' and JSON_SCHEMA_DEFAULT_BACKEND and REGEX_DEFAULT_BACKEND = 'outlines_core', matching the backend default contract.
```

- **Sources:**
  - `outlines/backends/__init__.py`
