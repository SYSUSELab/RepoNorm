# Rule details

- **Rule:**
  ```text
  JAX tensor adapter's get_device must return None, encoding that JAX tensors have no device reported through this adapter interface.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/jax.py`
- **Condition:**
  ```text
  when implementing or modifying get_device in the JAX tensor adapter
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/processors/tensor_adapters/jax.py:35-39`
