# Rule details

- **Rule:**
  ```text
  LlamaCpp.generate must branch on formatted prompt type: str uses self.model with logits_processor, list uses create_chat_completion, and self.model.reset() is called before returning the result.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** when modifying LlamaCpp.generate's prompt-type branching or model reset behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/llamacpp.py:247-266`
