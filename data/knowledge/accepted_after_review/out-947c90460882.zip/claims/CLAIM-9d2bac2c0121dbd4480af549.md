# Rule details

- **Rule:**
  ```text
  The project declares a supported Python version range of >=3.9,<3.13.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
requires-python = ">=3.9,<3.13"

```

- **Sources:**
  - `pyproject.toml:9`
