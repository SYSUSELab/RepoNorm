# Rule details

- **Rule:**
  ```text
  Tests for type adapters must preserve the documented structured-output contract: OpenAI dataclass output formatting yields a response_format with json_schema.strict True and the expected schema, and the dottxt adapter imports TypedDict from typing on Python 3.12+ and typing_extensions otherwise.
  ```
- **Applies to:**
  - `tests/models/test_dottxt_type_adapter.py`
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when adding or modifying tests for type adapter structured-output formatting or version-dependent typing imports
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_openai_type_adapter.py:167-176`
- `tests/models/test_dottxt_type_adapter.py:15-18`
