# Rule details

- **Rule:**
  ```text
  Run `mkdocs serve` to view the documentation locally, with the served site updating on each change.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

````text
mkdocs serve
```

By following the instruction you will be able to view the documentation locally.
It will be updated every time you make a change.

````

- **Sources:**
  - `docs/community/contribute.md:157-161`

## Review evidence locations

- `docs/community/contribute.md:154-161`
