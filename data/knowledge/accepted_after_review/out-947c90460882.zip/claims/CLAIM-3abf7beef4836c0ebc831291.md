# Rule details

- **Rule:**
  ```text
  `is_typing_dict` must return True for parameterized typing dicts such as dict[str, int] and Dict[int, str], but False for the bare dict type and for a plain dict instance.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when changing is_typing_dict classification of parameterized versus bare dict types
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/utils.py:99-104`
- `tests/types/test_types_utils.py:244-248`
