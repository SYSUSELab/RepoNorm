# Rule details

- **Rule:** When modifying Python-type-to-DSL-term conversion, preserve the recursion depth limit of 10 and the RecursionError with a message about recursive type definitions to protect against infinite recursion.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When changing how recursive Python types are converted to DSL terms.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/dsl.py:597-617`
- `tests/types/test_dsl.py:484-486`
