# Rule details

- **Rule:** The mypy pre-commit hook runs with the --allow-redefinition argument.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    - id: mypy
      args: [--allow-redefinition]

```

- **Sources:**
  - `.pre-commit-config.yaml:12-13`

## Review evidence locations

- `.pre-commit-config.yaml:9-15`
