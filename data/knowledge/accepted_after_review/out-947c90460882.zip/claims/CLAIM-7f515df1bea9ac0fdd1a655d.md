# Rule details

- **Rule:**
  ```text
  The transformers model's format_chat_input handler must call tokenizer.apply_chat_template with tokenize=False and add_generation_prompt=True.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying chat input formatting for the transformers model
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/transformers.py:165-171`
