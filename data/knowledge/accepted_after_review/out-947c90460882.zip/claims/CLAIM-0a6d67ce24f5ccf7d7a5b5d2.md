# Rule details

- **Rule:** The sync vLLM model's n sampling parameter must return a list of exactly n string samples.
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when changing sync vLLM sampling or its n-parameter handling
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_vllm_sync_multiple_samples asserts that n=2 returns a list of exactly two string samples, matching the sync vLLM multi-sample contract.
```

- **Sources:**
  - `tests/models/test_vllm.py`
