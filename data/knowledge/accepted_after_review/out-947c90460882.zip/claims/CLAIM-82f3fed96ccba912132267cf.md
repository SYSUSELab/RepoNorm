# Rule details

- **Rule:**
  ```text
  The vLLM sync vision test must pass a list of a text prompt and an image_input to the model and assert a string result, documenting the multimodal input convention for vLLM.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** When adding or modifying a test for vLLM multimodal (vision) input.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_vllm.py:247-249`
