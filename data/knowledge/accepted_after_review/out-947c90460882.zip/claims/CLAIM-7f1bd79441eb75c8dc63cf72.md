# Rule details

- **Rule:**
  ```text
  Tests for the transformer tokenizer must assert that __getstate__ includes a 'tokenizer' key and that __setstate__ restores an instance equal to the original, preserving the pickling round-trip contract.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** When adding or modifying a test that covers transformer tokenizer pickling or state serialization.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_transformers_tokenizer.py:134-142`
