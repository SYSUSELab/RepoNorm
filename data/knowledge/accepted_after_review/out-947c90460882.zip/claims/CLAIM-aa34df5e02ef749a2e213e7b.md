# Rule details

- **Rule:** When modifying the TGI async generate path, preserve the documented compatibility boundary that all output types except CFG are supported, provided the server backend supports them.
- **Applies to:**
  - `outlines/models/tgi.py`
- **Condition:** When changing output-type handling in the TGI async generate path.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/tgi.py:226-241`
