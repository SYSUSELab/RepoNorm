# Rule details

- **Rule:**
  ```text
  cache_disabled must disable caching only within its context scope: calls inside the scope bypass the cache while calls before and after use it.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:**
  ```text
  When modifying or adding tests for cache_disabled context-scoped behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/caching.py:186-195`
- `tests/test_cache.py:173-200`
