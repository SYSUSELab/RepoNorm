# Rule details

- **Rule:**
  ```text
  Type adapter tests must assert that format_output_type passes the provided schema through unchanged for dataclass output types.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:** When adding or modifying type adapter tests for dataclass output types.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_ollama_type_adapter_output_dataclass calls adapter.format_output_type(User) and asserts result == schema, confirming the schema passes through unchanged for a dataclass output type.
```

- **Sources:**
  - `tests/models/test_ollama_type_adapter.py:119-126`
