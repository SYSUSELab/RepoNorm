# Rule details

- **Rule:**
  ```text
  Tests for pydantic model schema generation must define a model with an Annotated str field constrained by Field(max_length=2) to exercise length-constrained string schema generation.
  ```
- **Applies to:**
  - `tests/models/test_ollama.py`
- **Condition:** when adding or modifying tests that exercise length-constrained string schema generation
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_ollama_stream_json defines a pydantic model with Annotated[str, Field(max_length=2)], matching the length-constrained schema test convention.
```

- **Sources:**
  - `tests/models/test_ollama.py`

## Review evidence locations

- `tests/models/test_ollama.py:154-162`
