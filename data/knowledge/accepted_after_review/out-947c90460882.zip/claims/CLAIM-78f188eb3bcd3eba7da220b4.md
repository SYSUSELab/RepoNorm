# Rule details

- **Rule:**
  ```text
  Coverage reporting is configured to show missing lines (show_missing = true).
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
show_missing = true

```

- **Sources:**
  - `pyproject.toml:193`

## Review evidence locations

- `pyproject.toml:192-193`
