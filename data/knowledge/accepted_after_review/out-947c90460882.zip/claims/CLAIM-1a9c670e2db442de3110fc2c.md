# Rule details

- **Rule:**
  ```text
  The Transformers type adapter must wrap a logits processor into a LogitsProcessorList preserving `index` and `tensor_library_name`, and must map a None output type to None.
  ```
- **Applies to:**
  - `tests/models/test_transformers_type_adapter.py`
- **Condition:** When adding or modifying a test for the Transformers type adapter's logits processor wrapping.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_transformers_type_adapter.py:64-73`
