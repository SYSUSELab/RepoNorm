# Rule details

- **Rule:**
  ```text
  Cache keys must be tied to the Outlines version: changing a cached function's return signature without a version bump reuses the stale cache and raises ValueError, while bumping outlines._version.__version__ invalidates the old cache so the new signature works.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** When modifying or adding tests for cache invalidation tied to the Outlines version.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/caching.py:71-83`
- `tests/test_cache.py:128-170`
