# Rule details

- **Rule:**
  ```text
  TensorAdapter.to_scalar must raise RuntimeError for multi-element tensors under torch but ValueError under other frameworks, and return a float for single-element tensors.
  ```
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:**
  ```text
  when adding or modifying tensor adapter to_scalar behavior or tests
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/processors/test_tensor_adapters.py:153-167`
