# Rule details

- **Rule:**
  ```text
  OpenAITypeAdapter.format_json_output_type must force additionalProperties to False via set_additional_properties_false_json_schema before emitting response_format, because OpenAI requires additionalProperties to be False for strict json_schema output.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  when modifying OpenAITypeAdapter.format_json_output_type in outlines/models/openai.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/openai.py:194-211`
