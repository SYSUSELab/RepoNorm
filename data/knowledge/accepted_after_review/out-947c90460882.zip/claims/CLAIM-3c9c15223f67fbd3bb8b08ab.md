# Rule details

- **Rule:**
  ```text
  The outlines package includes py.typed and grammars/*.lark files as package data.
  ```
- **Applies to:**
  - `outlines/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
"outlines" = ["py.typed", "grammars/*.lark"]

```

- **Sources:**
  - `pyproject.toml:108`

## Review evidence locations

- `pyproject.toml:104-108`
