# Rule details

- **Rule:** Chat.extend must append messages in order such that chat.messages equals the input list, establishing list-equality semantics for message extension.
- **Applies to:**
  - `tests/test_inputs.py`
- **Condition:** When modifying or adding tests for Chat.extend message ordering and list-equality behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/inputs.py:124-133`
- `tests/test_inputs.py:101-109`
