# Rule details

- **Rule:**
  ```text
  Model type adapters must expose a singledispatch `format_input` whose base implementation raises NotImplementedError; only registered input types (e.g. str) are accepted, so adding a new input type requires registering a handler rather than relying on the base method.
  ```
- **Applies to:**
  - `outlines/models/tgi.py`
  - `outlines/models/vllm_offline.py`
- **Condition:**
  ```text
  When adding or modifying a model type adapter's `format_input` dispatch, or introducing a new accepted input type for a model backend.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
TGITypeAdapter.format_input is the singledispatch base implementation that raises NotImplementedError for unregistered input types, matching the rule.
```

- **Sources:**
  - `outlines/models/tgi.py:27-44`

### Evidence 2 — current_observation

```text
TGITypeAdapter.format_str_input is a registered str handler that returns the input unchanged, matching the registered-passthrough part of the format_input dispatch rule.
```

- **Sources:**
  - `outlines/models/tgi.py:47-48`

### Evidence 3 — current_observation

```text
VLLMOfflineTypeAdapter.format_input is a singledispatchmethod whose base raises TypeError for unsupported input types, matching the rule.
```

- **Sources:**
  - `outlines/models/vllm_offline.py:23-36`

### Evidence 4 — current_observation

```text
VLLMOfflineTypeAdapter.format_input_str is registered via @format_input.register(str) and returns model_input unchanged, implementing the registered str passthrough handler.
```

- **Sources:**
  - `outlines/models/vllm_offline.py:39-43`

## Review evidence locations

- `outlines/models/tgi.py:23-48`
