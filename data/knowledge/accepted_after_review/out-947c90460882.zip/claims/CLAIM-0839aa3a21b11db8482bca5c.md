# Rule details

- **Rule:**
  ```text
  Tests for the OpenAI type adapter's JSON schema formatting must assert that the produced dict sets response_format.json_schema.strict to True and preserves the schema.
  ```
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** When adding or modifying a test for the OpenAI type adapter's JSON schema string formatting.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_openai_type_adapter.py:167-176`
