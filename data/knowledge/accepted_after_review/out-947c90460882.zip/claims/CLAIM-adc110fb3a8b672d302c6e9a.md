# Rule details

- **Rule:**
  ```text
  When modifying template string construction, preserve the cleaning sequence: apply `inspect.cleandoc`, re-add a trailing newline if the original content ended with a blank line, and collapse whitespace except after newlines to avoid introducing whitespace after backslash line continuations.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:** When changing how template strings are normalized or cleaned before use.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/templates.py:125-144`
- `tests/test_templates.py:84-125`
