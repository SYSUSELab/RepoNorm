# Rule details

- **Rule:**
  ```text
  TensorFlowTensorAdapter.full_like must use tf.fill(tf.shape(tensor), fill_value) to produce a tensor of the same shape filled with the value.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/tensorflow.py`
- **Condition:**
  ```text
  When modifying full_like or adding tensor operations to the TensorFlow tensor adapter.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/processors/tensor_adapters/tensorflow.py:29-30`
- `tests/processors/test_tensor_adapters.py:170-177`
