# Rule details

- **Rule:**
  ```text
  SteerableGenerator.from_processor must bypass __init__ via cls.__new__ and set only model and logits_processor, so subclasses relying on additional initialization state must override this classmethod.
  ```
- **Applies to:**
  - `outlines/generator.py`
- **Condition:**
  ```text
  when modifying or subclassing SteerableGenerator.from_processor in outlines/generator.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generator.py:197-213`
- `outlines/generator.py:259-277`
- `tests/test_generator.py:90-93`
