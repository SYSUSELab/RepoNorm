# Rule details

- **Rule:** VLLM.generate must raise ValueError if any response message has a refusal, and return a single content string or a list of contents depending on the number of choices.
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** when modifying the VLLM generate method's response handling
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/vllm.py:118-137`
