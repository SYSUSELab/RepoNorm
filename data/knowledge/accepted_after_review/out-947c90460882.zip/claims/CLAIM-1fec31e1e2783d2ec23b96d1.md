# Rule details

- **Rule:** Tests for vision structured output must pass a prompt plus an Image and a pydantic type, asserting the result is a string whose parsed JSON contains the expected field.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying a test for vision structured output
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_gemini.py:123-130`
