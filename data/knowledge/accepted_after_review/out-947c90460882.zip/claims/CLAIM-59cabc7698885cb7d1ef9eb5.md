# Rule details

- **Rule:** Tests for tokenizer fixtures must define a fixture that constructs the tokenizer from a no-HF-tokenizer model fixture to exercise the no-HF-tokenizer code path.
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when adding or modifying tokenizer fixtures that need to exercise the no-HF-tokenizer code path
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The tokenizer_no_hf_tokenizer fixture constructs the tokenizer from the model_no_hf_tokenizer fixture, exercising the no-HF-tokenizer code path.
```

- **Sources:**
  - `tests/models/test_llamacpp_tokenizer.py`
