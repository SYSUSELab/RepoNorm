# Rule details

- **Rule:**
  ```text
  Examples that load prompt or template files via relative paths (e.g. Template.from_file("prompts/...")) must be run from their own example directory; contributors changing such examples should preserve or document the working-directory requirement rather than silently switching to absolute paths.
  ```
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When modifying an example that loads prompt/template files through relative paths.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The example loads prompt templates via relative paths (Template.from_file("prompts/...")) and its docstring/comment establishes it is run from the example directory, preserving the working-directory requirement.
```

- **Sources:**
  - `examples/babyagi.py`
