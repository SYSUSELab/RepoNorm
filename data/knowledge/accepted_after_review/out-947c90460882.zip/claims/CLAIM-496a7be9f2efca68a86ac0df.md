# Rule details

- **Rule:** Tests that document a backend's unsupported feature or output type must assert the specific exception type and message fragment (e.g. NotImplementedError matching 'Streaming is not implemented', NotImplementedError matching 'is not available with Anthropic', TypeError matching 'is not available with Anthropic'), and must not silently skip or weaken the assertion.
- **Applies to:**
  - `tests/models/test_anthopic_type_adapter.py`
  - `tests/models/test_transformers.py`
- **Condition:** when adding or modifying a test that documents an unsupported backend feature or output type
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_anthopic_type_adapter.py:90-118`
- `tests/models/test_transformers.py:245-247`
