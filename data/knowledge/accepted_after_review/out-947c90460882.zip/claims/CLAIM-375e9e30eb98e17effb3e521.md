# Rule details

- **Rule:** The dev container enables the rust devcontainer feature.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
    "ghcr.io/devcontainers/features/rust:1": {}

```

- **Sources:**
  - `.devcontainer/devcontainer.json:17`
