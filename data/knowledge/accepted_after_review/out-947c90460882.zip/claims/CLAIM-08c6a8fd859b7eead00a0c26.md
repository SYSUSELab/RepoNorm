# Rule details

- **Rule:**
  ```text
  Template.from_file must build the template via build_template_from_file and document that Jinja includes and inheritance cannot reference files outside the folder or subfolders of the given file.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  when modifying Template.from_file or the template loading path that resolves Jinja includes and inheritance
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/templates.py:97-122`
- `outlines/templates.py:147-153`
