# Rule details

- **Rule:** Tests that exercise a backend's structured-output warning must assert the specific UserWarning message fragment (e.g. 'SGLang grammar-based structured outputs expects an EBNF') and that the result is a valid constrained value, rather than ignoring the warning.
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying a test that exercises a backend's structured-output warning
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_sglang.py:297-304`
