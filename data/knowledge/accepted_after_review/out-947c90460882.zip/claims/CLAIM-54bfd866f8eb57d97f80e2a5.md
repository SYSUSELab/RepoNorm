# Rule details

- **Rule:** Changes must be covered by tests.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- [ ] There are tests covering the changes;

```

- **Sources:**
  - `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:15`

## Review evidence locations

- `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:14-16`
