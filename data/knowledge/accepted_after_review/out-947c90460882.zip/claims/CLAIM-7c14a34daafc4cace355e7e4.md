# Rule details

- **Rule:** The coverage file is set to .coverage.${{ steps.matrix-id.outputs.id }} for the test run.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      env:
        COVERAGE_FILE: .coverage.${{ steps.matrix-id.outputs.id }}

```

- **Sources:**
  - `.github/workflows/tests_nightly.yml:51-52`

## Review evidence locations

- `.github/workflows/tests_nightly.yml:39-52`
