# Rule details

- **Rule:**
  ```text
  is_callable must return callable(value) and not isinstance(value, type), deliberately excluding classes from being treated as callable for this predicate.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  when modifying the is_callable type predicate
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/utils.py:143-148`
- `tests/types/test_types_utils.py:351-358`
