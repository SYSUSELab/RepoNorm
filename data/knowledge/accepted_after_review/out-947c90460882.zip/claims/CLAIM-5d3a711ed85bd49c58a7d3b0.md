# Rule details

- **Rule:** Tests that exercise model generation through a constrained output type must assert the returned value is a member of the declared constraint set, not merely that generation succeeds.
- **Applies to:**
  - `tests/models/test_gemini.py`
  - `tests/models/test_transformers.py`
  - `tests/models/test_vllm_offline.py`
- **Condition:** When adding or modifying a test that calls model.generate with a constrained output type (choice/enum or multiple sampled sequences).
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_gemini.py:196-218`
