# Rule details

- **Rule:** The workflow runs asv continuous comparing upstream/main to HEAD with --no-stats --interleave-rounds -a repeat=3, tolerating errors.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      run: |
        # prepare main branch for comparison
        git remote add upstream https://github.com/${{ github.repository }}.git
        git fetch upstream main

        # Run benchmarks, allow errors, they will be caught in the next step
        asv continuous upstream/main HEAD \
            --no-stats --interleave-rounds -a repeat=3 || true

```

- **Sources:**
  - `.github/workflows/asv_benchmark_pr.yml:53-60`
