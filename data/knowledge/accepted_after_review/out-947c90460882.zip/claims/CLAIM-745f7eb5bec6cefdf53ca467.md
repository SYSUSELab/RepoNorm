# Rule details

- **Rule:**
  ```text
  `get_schema` must raise `NotImplementedError` for unsupported input types (e.g., int), return a pretty-printed JSON string for a dict schema, and return a JSON string for a Pydantic class schema.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When modifying `get_schema` or the schema extraction path used by template rendering.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/templates.py:272-298`
- `tests/test_templates.py:363-372`
