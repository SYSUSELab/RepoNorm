# Constraints for `scripts/gen_ref_pages.py`

## Rule

- **Rule:**
  ```text
  scripts/gen_ref_pages.py must generate API reference pages by walking outlines/*.py, skipping files listed in EXCLUDED_FILES, mapping __init__ to index.md, and emitting mkdocstrings '::: outlines.<ident>' directives plus a SUMMARY.md nav entry.
  ```
- **Applies to:**
  - `scripts/gen_ref_pages.py`
- **Condition:** when modifying the API reference page generator or adding/removing outlines modules that should appear in generated docs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-afc523d524d115c6e6055568.md)

## Rule

- **Rule:**
  ```text
  The gen-files plugin runs the script scripts/gen_ref_pages.py.
  ```
- **Applies to:**
  - `scripts/gen_ref_pages.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bd98bfefa2b7d4b61cd07ba3.md)
