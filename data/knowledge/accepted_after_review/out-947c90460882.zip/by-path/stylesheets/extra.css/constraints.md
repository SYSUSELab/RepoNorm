# Constraints for `stylesheets/extra.css`

## Rule

- **Rule:** The MkDocs site includes the extra stylesheet stylesheets/extra.css.
- **Applies to:**
  - `stylesheets/extra.css`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-800031d4c0ad40d957abe47c.md)
