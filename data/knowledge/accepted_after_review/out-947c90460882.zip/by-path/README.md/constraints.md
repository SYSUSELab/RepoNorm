# Constraints for `README.md`

## Rule

- **Rule:** The project readme content type is declared as text/markdown.
- **Applies to:**
  - `README.md`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7bdb1aca10008ea741b77497.md)

## Rule

- **Rule:** The project readme file is declared as README.md.
- **Applies to:**
  - `README.md`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8e6d902fc5184d02251b79f7.md)
