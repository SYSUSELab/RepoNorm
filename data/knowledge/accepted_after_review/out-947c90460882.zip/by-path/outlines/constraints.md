# Constraints for `outlines`

## Rule

- **Rule:**
  ```text
  The outlines package includes py.typed and grammars/*.lark files as package data.
  ```
- **Applies to:**
  - `outlines/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3c9c15223f67fbd3bb8b08ab.md)
