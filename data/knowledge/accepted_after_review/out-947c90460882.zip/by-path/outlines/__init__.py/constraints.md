# Constraints for `outlines/__init__.py`

## Rule

- **Rule:**
  ```text
  outlines/__init__.py must export a curated __all__ combining cache helpers, Application, Generator, type constructors (regex, json_schema, cfg), Template, grammars, and a model_list of from_* factory names; from_vllm_offline is imported but absent from model_list and must not be re-exported via __all__.
  ```
- **Applies to:**
  - `outlines/__init__.py`
- **Condition:**
  ```text
  When modifying the public API surface or __all__ in outlines/__init__.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-79e726af48006f71f56e67e3.md)
