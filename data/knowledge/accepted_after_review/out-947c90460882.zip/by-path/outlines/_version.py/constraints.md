# Constraints for `outlines/_version.py`

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a3d4630cf0aebda7015f40de.md)

## Rule

- **Rule:**
  ```text
  setuptools_scm writes the generated version file to outlines/_version.py.
  ```
- **Applies to:**
  - `outlines/_version.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a8c7facf8c168b030b6fd32e.md)
