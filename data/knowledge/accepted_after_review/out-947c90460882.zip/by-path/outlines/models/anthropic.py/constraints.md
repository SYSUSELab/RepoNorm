# Constraints for `outlines/models/anthropic.py`

## Rule

- **Rule:**
  ```text
  Anthropic's format_output_type must return {} for None and raise NotImplementedError for any non-None output type, because structured output types are unavailable with Anthropic.
  ```
- **Applies to:**
  - `outlines/models/anthropic.py`
- **Condition:** when adding or modifying output-type handling for the Anthropic backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-22d13f11c0407e0ef707d52c.md)

## Rule

- **Rule:**
  ```text
  Model generate_batch methods must raise NotImplementedError with a backend-specific message when batch generation is unsupported, rather than silently degrading or returning partial results.
  ```
- **Applies to:**
  - `outlines/models/anthropic.py`
  - `outlines/models/sglang.py`
- **Condition:**
  ```text
  when adding or modifying a model backend's generate_batch method for a backend that does not support batch generation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-68225a7e3e09e78424fa37c3.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3d4630cf0aebda7015f40de.md)

## Rule

- **Rule:**
  ```text
  The Anthropic model must register a format_input handler for list inputs that wraps the list in a single user message via _create_message.
  ```
- **Applies to:**
  - `outlines/models/anthropic.py`
- **Condition:** when modifying or extending the Anthropic model's input formatting for list inputs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-deb09ebfee216601e1bca06b.md)
