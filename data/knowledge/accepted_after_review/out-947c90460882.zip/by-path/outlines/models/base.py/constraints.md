# Constraints for `outlines/models/base.py`

## Rule

- **Rule:**
  ```text
  AsyncModel.__call__ must construct a Generator with the model, output type, and backend, then await it, making model(prompt, Foo) equivalent to awaiting Generator(model, Foo)(prompt).
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** when modifying the async model call path or the Generator construction contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1fcd5b6af02be9f9e08e8f1b.md)

## Rule

- **Rule:**
  ```text
  Model.batch must remain equivalent to constructing Generator(self, output_type, backend) and calling batch on it, so batch behavior and backend handling stay consistent with the Generator path.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** When modifying Model.batch or the Generator construction it delegates to.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2d0a7656968c7e51e1913a62.md)

## Rule

- **Rule:**
  ```text
  `outlines/models/base.py` is the shared base-class module for all models and model type adapters, importing `ABC`, `abstractmethod`, and async/sync iterator types; new model or adapter base classes belong here.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** When adding or modifying shared model or model-type-adapter base classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7784c72d98412a39836c7b08.md)

## Rule

- **Rule:**
  ```text
  Model adapters must implement format_output_type so that black-box models produce a response_format argument while steerable models format the logits processor for the model's expected object type.
  ```
- **Applies to:**
  - `outlines/models/base.py`
  - `outlines/models/gemini.py`
- **Condition:**
  ```text
  when adding or modifying a model adapter's format_output_type implementation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7a683dc73a9f90a1fef24aa7.md)

## Rule

- **Rule:**
  ```text
  AsyncModel.generate must keep output_type semantics: a logits processor for steerable models and a type (Json, Enum, etc.) for black-box models, and must remain documented as not intended for direct end-user use.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:**
  ```text
  When changing the abstract async generate signature, its output_type handling, or its documentation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-903f97a474fc6149b5a568f5.md)

## Rule

- **Rule:**
  ```text
  Model.__call__ must construct a Generator with the given output_type and backend and invoke it, so model(prompt, Foo) is equivalent to Generator(model, Foo)(prompt); the backend argument is only used for steerable models when output_type is provided.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:**
  ```text
  When modifying Model.__call__ or adding a new model subclass that overrides call semantics.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-920e48042b244a8fa01c6111.md)

## Rule

- **Rule:**
  ```text
  The base Model ABC declares type_adapter: ModelTypeAdapter and tensor_library_name: str as class-level attributes; subclasses must define type_adapter, and steerable models must additionally define tensor_library_name.
  ```
- **Applies to:**
  - `outlines/models/base.py`
- **Condition:** When adding a new Model subclass or modifying the base Model ABC's required attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d175cfdd66e6cdeea189be42.md)
