# Constraints for `outlines/models/transformers.py`

## Rule

- **Rule:**
  ```text
  TransformerTokenizer.encode must force padding=True and return_tensors='pt' and return input_ids and attention_mask, so callers receive padded PyTorch tensors regardless of kwargs.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying tokenizer encoding for the transformers model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-008816f1c670f4e78d69ea5a.md)

## Rule

- **Rule:**
  ```text
  `get_llama_tokenizer_types` must tolerate missing Llama-family tokenizer classes by substituting dummy classes on ImportError and returning the tuple, preserving compatibility across transformers versions.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying tokenizer type resolution or upgrading the transformers dependency for Llama-family tokenizers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-013b124a52ad34e62b452f7f.md)

## Rule

- **Rule:**
  ```text
  The transformers integration module's public API is exactly `Transformers`, `TransformersMultiModal`, and `from_transformers` via `__all__`; adding a new public symbol requires updating this list.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When adding, renaming, or removing a public symbol in the transformers integration module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-24afec162b771b5f1f5254eb.md)

## Rule

- **Rule:**
  ```text
  `TransformerTokenizer.__setstate__` must reinitialize from `state['tokenizer']`, so pickled instances must carry the tokenizer under that key.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When changing the pickling/unpickling state format of the transformers tokenizer wrapper.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d37b295499bbb5cf601c71b.md)

## Rule

- **Rule:** Transformers is a thin wrapper converting user-specified input/output types into arguments for the transformers model and tokenizer, defining its adapter responsibility.
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying the Transformers class or adding new model/tokenizer argument handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4f7f4bc1073ba733ec29a450.md)

## Rule

- **Rule:**
  ```text
  TransformerTokenizer.__eq__ compares model_name and kwargs when both attributes exist, otherwise falls back to comparing tokenizer; returns NotImplemented for unrelated types.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying TransformerTokenizer.__eq__ or adding equality semantics to tokenizer wrappers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-629ddae584e1819d8e1d9d37.md)

## Rule

- **Rule:**
  ```text
  The transformers model's format_chat_input handler must call tokenizer.apply_chat_template with tokenize=False and add_generation_prompt=True.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying chat input formatting for the transformers model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7f515df1bea9ac0fdd1a655d.md)

## Rule

- **Rule:**
  ```text
  `TransformersMultiModalTypeAdapter` must be declared as a `ModelTypeAdapter` for the `TransformersMultiModal` model, so multimodal adapter registration must target that model.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When adding or modifying the multimodal transformers type adapter registration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8a9b5314fe420c0f73d94318.md)

## Rule

- **Rule:**
  ```text
  When modifying the Transformers multimodal list input formatting, preserve the mapping of `Image` assets to `{"text": prompt, "images": [...]}`, `Audio` to `{"text": prompt, "audio": [...]}`, and `Video` to `{"text": prompt, "videos": [...]}`, raising `ValueError` for unsupported asset types.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When changing how multimodal list inputs are formatted for Transformers models.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a11e540672a985dd75cd457e.md)

## Rule

- **Rule:** TransformerTokenizer must represent a tokenizer for transformers-library models, defining its adapter responsibility.
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying TransformerTokenizer or its adapter responsibility.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b37724600419de79bf320033.md)

## Rule

- **Rule:**
  ```text
  Model factory functions (from_llamacpp, from_gemini, from_transformers) must accept the native client/tokenizer object and return the corresponding Outlines model wrapper, preserving the public conversion entry point contract.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
  - `outlines/models/llamacpp.py`
  - `outlines/models/transformers.py`
- **Condition:** when adding or modifying a model factory conversion function that wraps a native client or tokenizer into an Outlines model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bb5f58827bc6ded49bf08e2a.md)

## Rule

- **Rule:**
  ```text
  convert_token_to_string prepends a space for Llama tokenizers when the token starts with SPIECE_UNDERLINE or equals <0x20>, a hack to compensate for missing spaces in HF Llama tokenizers.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying convert_token_to_string or adding tokenizer-specific string conversion workarounds.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bb87b1fc0ad9be832eebd69e.md)

## Rule

- **Rule:**
  ```text
  The transformers model's format_str_input handler for str must return the string unchanged, so plain string inputs pass through without transformation.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying string input formatting for the transformers model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cbcba5cfce6b11256f0bb760.md)

## Rule

- **Rule:**
  ```text
  Transformers.generate_batch must reshape generated_ids to (num_inputs, num_return_sequences, -1) when num_return_sequences > 1, so batch output nesting depends on that inference kwarg.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying generate_batch or changing how batch outputs are shaped in the Transformers model wrapper.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e3e64391032e69fbf7ffa622.md)

## Rule

- **Rule:** outlines.models.transformers must define a stub class CodeLlamaTokenizerFast with a pass body and a type: ignore comment, a compatibility shim for environments where that transformers tokenizer class is unavailable.
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying tokenizer type resolution in outlines/models/transformers.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e82c9548d7468e8f0507b584.md)

## Rule

- **Rule:**
  ```text
  TransformersMultiModal._prepare_model_inputs must format each item when is_batch, merge prompt dicts by appending 'text' values and extending other keys, then call self.processor with padding=True and return_tensors='pt' moved to the model device, returning merged_prompts['text'] and inputs.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying TransformersMultiModal._prepare_model_inputs in outlines/models/transformers.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e9c4d1adb805e694517d70d6.md)

## Rule

- **Rule:**
  ```text
  TransformerTokenizer.decode must use tokenizer.batch_decode with skip_special_tokens=True, stripping special tokens from decoded output.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying the Transformers tokenizer decode method or relying on raw token text in decoded output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f9e64f06dee1c01a3996f3be.md)
