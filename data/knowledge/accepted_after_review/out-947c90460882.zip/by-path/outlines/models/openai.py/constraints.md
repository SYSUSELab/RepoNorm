# Constraints for `outlines/models/openai.py`

## Rule

- **Rule:**
  ```text
  outlines/models/openai.py must export only OpenAI and from_openai via __all__ and must import set_additional_properties_false_json_schema from outlines.models.utils, indicating a shared schema-normalization helper used across OpenAI-compatible models.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:** when modifying the public exports or schema-normalization imports of the OpenAI model module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-696fb6d36c99f7d81040f8b2.md)

## Rule

- **Rule:**
  ```text
  Each model backend's type adapter must define format_output_type with an explicit supported-output-type boundary: unsupported output types must raise TypeError (or NotImplementedError for CFG-based structured outputs) rather than silently degrading, and supported types must be routed to the backend's native mechanism (e.g. grammar.type=json for JsonSchema, grammar.type=regex via to_regex for other terms).
  ```
- **Applies to:**
  - `outlines/models/openai.py`
  - `outlines/models/tgi.py`
- **Condition:**
  ```text
  When adding or modifying a model backend's format_output_type to accept a new output type or change how an existing output type is serialized.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-998f7439eaa78261c7606840.md)

## Rule

- **Rule:**
  ```text
  OpenAITypeAdapter.format_json_output_type must force additionalProperties to False via set_additional_properties_false_json_schema before emitting response_format, because OpenAI requires additionalProperties to be False for strict json_schema output.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  when modifying OpenAITypeAdapter.format_json_output_type in outlines/models/openai.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a23c662bf5bb37bafaa88873.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3d4630cf0aebda7015f40de.md)
