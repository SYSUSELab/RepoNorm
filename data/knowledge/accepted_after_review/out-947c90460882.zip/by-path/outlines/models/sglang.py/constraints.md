# Constraints for `outlines/models/sglang.py`

## Rule

- **Rule:**
  ```text
  The SGLang model constructor must store the client and optional model_name and instantiate SGLangTypeAdapter.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:** when modifying the SGLang model constructor
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-40bab57e99e8f94c9e206d1c.md)

## Rule

- **Rule:**
  ```text
  SGLangTypeAdapter.format_input must delegate to OpenAITypeAdapter().format_input(model_input) so that sglang input formatting stays aligned with the OpenAI adapter.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:**
  ```text
  when modifying SGLang input formatting or the OpenAI type adapter's format_input contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-47fe38ba83ccfd08a9e6005d.md)

## Rule

- **Rule:**
  ```text
  Model generate_batch methods must raise NotImplementedError with a backend-specific message when batch generation is unsupported, rather than silently degrading or returning partial results.
  ```
- **Applies to:**
  - `outlines/models/anthropic.py`
  - `outlines/models/sglang.py`
- **Condition:**
  ```text
  when adding or modifying a model backend's generate_batch method for a backend that does not support batch generation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-68225a7e3e09e78424fa37c3.md)

## Rule

- **Rule:**
  ```text
  `SGLang` must remain a thin wrapper around the `openai.OpenAI` client, converting user-specified input/output types into OpenAI client arguments rather than implementing its own transport.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:** When modifying the SGLang model wrapper's request construction or client usage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-81baf95f5232d79cc584c49e.md)

## Rule

- **Rule:**
  ```text
  from_sglang must dispatch on client type: openai.OpenAI yields SGLang, openai.AsyncOpenAI yields AsyncSGLang, and any other client type raises ValueError.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:**
  ```text
  when modifying from_sglang's client-type dispatch or adding new client types
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a009306d2a2df261614dee58.md)

## Rule

- **Rule:**
  ```text
  The SGLang backend must not support batch inference; generate_batch must raise NotImplementedError with the message "SGLang does not support batch inference."
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:** when modifying or extending the SGLang model backend's batch generation capability
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae5f4369e434c099875fc87a.md)

## Rule

- **Rule:** SGLang.generate must build client args, call chat.completions.create, raise ValueError when any returned message has a refusal, and return a single string for one choice or a list of strings for multiple choices.
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:** when modifying the SGLang generate method's request construction, refusal handling, or return shape
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fee9055349df2960a44c8e57.md)
