# Constraints for `outlines/models/gemini.py`

## Rule

- **Rule:**
  ```text
  Gemini.format_input must accept only str, list, and Chat (prompt plus images); the base singledispatchmethod implementation raises TypeError stating these are the only available input types.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
- **Condition:**
  ```text
  when adding or modifying accepted input types for Gemini.format_input
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6280b608e784670ab9dbe868.md)

## Rule

- **Rule:**
  ```text
  Model adapters must implement format_output_type so that black-box models produce a response_format argument while steerable models format the logits processor for the model's expected object type.
  ```
- **Applies to:**
  - `outlines/models/base.py`
  - `outlines/models/gemini.py`
- **Condition:**
  ```text
  when adding or modifying a model adapter's format_output_type implementation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7a683dc73a9f90a1fef24aa7.md)

## Rule

- **Rule:**
  ```text
  _create_img_part must build a Gemini message part as {'inline_data': {'mime_type': image.image_format, 'data': image.image_str}}.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
- **Condition:** when modifying image part construction for the Gemini backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-98f7cef7926865847428ac88.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3d4630cf0aebda7015f40de.md)

## Rule

- **Rule:**
  ```text
  Gemini.generate_batch must raise NotImplementedError with the message "Gemini does not support batch generation.", keeping batch generation explicitly unsupported for Gemini.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
- **Condition:**
  ```text
  When modifying Gemini.generate_batch or adding batch support to Gemini.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b097c37827b94c955faf0df2.md)

## Rule

- **Rule:**
  ```text
  Model factory functions (from_llamacpp, from_gemini, from_transformers) must accept the native client/tokenizer object and return the corresponding Outlines model wrapper, preserving the public conversion entry point contract.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
  - `outlines/models/llamacpp.py`
  - `outlines/models/transformers.py`
- **Condition:** when adding or modifying a model factory conversion function that wraps a native client or tokenizer into an Outlines model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bb5f58827bc6ded49bf08e2a.md)

## Rule

- **Rule:**
  ```text
  Gemini.generate must format input and output type through the type adapter, call client.models.generate_content with model name defaulting to self.model_name, and merge generation_config with inference kwargs.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
- **Condition:**
  ```text
  when modifying Gemini.generate's request construction or generation_config merging
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dc34e8743fe4d10e2da4faff.md)
