# Constraints for `outlines/models/ollama.py`

## Rule

- **Rule:**
  ```text
  When modifying the Ollama model module, preserve the TYPE_CHECKING-only import of `ollama.Client` and `ollama.AsyncClient` so the ollama package is not required at runtime for type imports.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:** When changing imports or type annotations in the Ollama model module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-41f33a8a8311628d44620caa.md)

## Rule

- **Rule:**
  ```text
  OllamaTypeAdapter.format_output_type must raise TypeError for Regex and CFG output types, return None for None, convert JsonSchema/dataclass/TypedDict/Pydantic/genson schemas to JSON schema, and raise TypeError for unsupported types, defining Ollama's structured-output support boundary.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:**
  ```text
  When modifying format_output_type or adding new output type support to the Ollama backend.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4a0a465cdd266ddb4458bca3.md)

## Rule

- **Rule:**
  ```text
  When modifying the Ollama format_input singledispatchmethod, preserve the base implementation raising TypeError stating only str, list, and Chat input types are available.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:**
  ```text
  When changing the base implementation or dispatch behavior of Ollama format_input.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a8b6dd50ed1ed09e7fc835cf.md)

## Rule

- **Rule:**
  ```text
  Ollama's generate_batch must raise NotImplementedError because the ollama library does not support batch inference; do not implement batch generation for this backend.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:** when adding or modifying batch generation support for the Ollama backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c14db00eccca05c24120110a.md)

## Rule

- **Rule:**
  ```text
  Ollama's format_input handler for str inputs must return a single user message list via _create_message, defining the prompt-only message construction protocol.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:** when adding or modifying input formatting for the Ollama backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e09db64c07373be67f6214e8.md)

## Rule

- **Rule:**
  ```text
  AsyncOllama.__init__ must store the client and optional model_name and instantiate an OllamaTypeAdapter, so the adapter is created per model instance.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:**
  ```text
  when modifying AsyncOllama.__init__ in outlines/models/ollama.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f3affbe3914ba142e2c4cbe7.md)
