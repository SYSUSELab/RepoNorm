# Constraints for `outlines/models/vllm.py`

## Rule

- **Rule:**
  ```text
  VLLM._build_client_args must format input and output type via the type adapter, merge output_type_args into any caller-supplied extra_body, inject self.model_name as the model when not already provided, and only include extra_body in the returned client args when non-empty.
  ```
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** when modifying how VLLM builds client arguments for generation requests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0199704f0de64df3aae92788.md)

## Rule

- **Rule:** When adding or modifying a model backend's output-type handling, preserve the distinction that steerable backends compile the output type into logits processors while black-box backends pass the output type directly to the model without compilation.
- **Applies to:**
  - `outlines/generator.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/vllm.py`
- **Condition:** When changing how a generator or model backend converts an output type into generation constraints.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a4fc9c48e89cac961318d8e.md)

## Rule

- **Rule:**
  ```text
  VLLM.generate_stream must build client args and yield delta content chunks from the streaming chat completion, skipping chunks without content.
  ```
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:**
  ```text
  when modifying the VLLM generate_stream method's chunk handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3fc332e762a34c404f7cc245.md)

## Rule

- **Rule:** VLLM.generate must raise ValueError if any response message has a refusal, and return a single content string or a list of contents depending on the number of choices.
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** when modifying the VLLM generate method's response handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-40d5e2a3c31f93db9ee6e805.md)

## Rule

- **Rule:**
  ```text
  When modifying the VLLM type adapter, preserve the mapping of CFG terms to `guided_grammar`, JsonSchema terms to `guided_json` (with optional `whitespace_pattern`), other terms to `guided_regex` via `to_regex`, and None to an empty dict.
  ```
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** When changing how VLLM output types are translated into guided decoding parameters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-89972155c8d0d8a9ac197939.md)

## Rule

- **Rule:**
  ```text
  from_vllm must dispatch on the OpenAI client type: openai.OpenAI yields a synchronous VLLM, openai.AsyncOpenAI yields AsyncVLLM, and any other client type raises ValueError, so callers must pass one of those two client classes.
  ```
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:**
  ```text
  When modifying from_vllm or adding new client type support to the vLLM model integration.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-baea04fe0a2bd26a8e0772bb.md)
