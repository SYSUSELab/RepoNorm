# Constraints for `outlines/models/llamacpp.py`

## Rule

- **Rule:**
  ```text
  Model factory functions (from_llamacpp, from_gemini, from_transformers) must accept the native client/tokenizer object and return the corresponding Outlines model wrapper, preserving the public conversion entry point contract.
  ```
- **Applies to:**
  - `outlines/models/gemini.py`
  - `outlines/models/llamacpp.py`
  - `outlines/models/transformers.py`
- **Condition:** when adding or modifying a model factory conversion function that wraps a native client or tokenizer into an Outlines model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bb5f58827bc6ded49bf08e2a.md)

## Rule

- **Rule:**
  ```text
  LlamaCpp.generate must branch on formatted prompt type: str uses self.model with logits_processor, list uses create_chat_completion, and self.model.reset() is called before returning the result.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** when modifying LlamaCpp.generate's prompt-type branching or model reset behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c5442d5fbcb4c7f44033a2df.md)
