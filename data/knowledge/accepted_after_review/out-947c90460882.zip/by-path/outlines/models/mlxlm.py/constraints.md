# Constraints for `outlines/models/mlxlm.py`

## Rule

- **Rule:** When adding or modifying a model backend's output-type handling, preserve the distinction that steerable backends compile the output type into logits processors while black-box backends pass the output type directly to the model without compilation.
- **Applies to:**
  - `outlines/generator.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/vllm.py`
- **Condition:** When changing how a generator or model backend converts an output type into generation constraints.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a4fc9c48e89cac961318d8e.md)

## Rule

- **Rule:**
  ```text
  MLXLM must keep two tokenizer attributes: mlx_tokenizer is the raw tokenizer passed to mlx-lm's generate, while tokenizer is a TransformerTokenizer wrapper used by the logits processor; contributors changing tokenizer handling must preserve both roles.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:** When modifying tokenizer handling or initialization in the MLXLM model wrapper.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-29a9be461b1482d643f9a5ec.md)

## Rule

- **Rule:**
  ```text
  MLXLMTypeAdapter.format_str_input must register a str handler that returns the string unchanged, so plain string inputs pass through without wrapping.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:**
  ```text
  When modifying format_str_input or adding new input type handlers to the MLXLM type adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8059a0c8ca4e77b4655ffde9.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3d4630cf0aebda7015f40de.md)

## Rule

- **Rule:**
  ```text
  MLX LM generate_batch always raises NotImplementedError because the mlx_lm library does not support batch inference.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:**
  ```text
  When modifying MLXLM.generate_batch or adding batch inference support to the MLX LM backend.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b5ea40cc0d4e664bdc155e0c.md)

## Rule

- **Rule:**
  ```text
  When modifying the MLX generate path, preserve the lazy import of `mlx_lm.generate` and the delegation of output-type handling to the type adapter via `logits_processors=self.type_adapter.format_output_type(output_type)`.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:** When changing how the MLX generate path imports or delegates output-type handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c35e96bbc4fda03246d111cb.md)

## Rule

- **Rule:**
  ```text
  MLXLM must set tensor_library_name = "mlx", matching the tensor adapter registry key required by the base Model contract for steerable models.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:**
  ```text
  when adding or modifying a model class that declares a tensor_library_name for steerable model support
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d5269976f155b843043e94b6.md)
