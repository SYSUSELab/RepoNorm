# Constraints for `outlines/models/vllm_offline.py`

## Rule

- **Rule:**
  ```text
  vllm_offline.generate_stream must raise NotImplementedError with the message 'Streaming is not available for the vLLM offline integration.'
  ```
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:** when modifying streaming support for the vLLM offline integration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0cbc9d54ec70aa29ce50a121.md)

## Rule

- **Rule:** VLLMOffline must remain a thin wrapper around vllm.LLM whose role is converting user-specified input and output types into arguments for vllm.LLM.
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:** When modifying VLLMOffline or its conversion of input/output types into vllm.LLM arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-43b466cb2d1903947ea421ab.md)

## Rule

- **Rule:**
  ```text
  VLLMOffline.generate_batch must raise TypeError when any input is a Chat instance, keeping batch generation explicitly unsupported for Chat inputs.
  ```
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:**
  ```text
  when modifying VLLMOffline.generate_batch in outlines/models/vllm_offline.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-88e0a40f53ce9bdda6a600bd.md)

## Rule

- **Rule:**
  ```text
  VLLMOffline.__init__ must store the passed vllm.LLM instance and construct a VLLMOfflineTypeAdapter, establishing the adapter wiring required for offline vLLM models.
  ```
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:** When modifying VLLMOffline initialization or adapter wiring for offline vLLM models.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-88f46afe63879498731b3dcc.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3d4630cf0aebda7015f40de.md)

## Rule

- **Rule:**
  ```text
  Model type adapters must expose a singledispatch `format_input` whose base implementation raises NotImplementedError; only registered input types (e.g. str) are accepted, so adding a new input type requires registering a handler rather than relying on the base method.
  ```
- **Applies to:**
  - `outlines/models/tgi.py`
  - `outlines/models/vllm_offline.py`
- **Condition:**
  ```text
  When adding or modifying a model type adapter's `format_input` dispatch, or introducing a new accepted input type for a model backend.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-abdafaf690f3d3abf1cffec2.md)

## Rule

- **Rule:**
  ```text
  VLLMOffline.format_input is a singledispatchmethod whose base implementation raises TypeError stating that only str and Chat inputs are available with VLLM offline; unsupported input types must fail with that message.
  ```
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:** when adding or modifying input-type handling for the VLLM offline backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c1e6300979659c7238448f24.md)
