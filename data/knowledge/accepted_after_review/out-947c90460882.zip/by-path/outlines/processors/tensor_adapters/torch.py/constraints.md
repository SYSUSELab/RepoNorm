# Constraints for `outlines/processors/tensor_adapters/torch.py`

## Rule

- **Rule:**
  ```text
  TorchTensorAdapter.to_device must be implemented as tensor.to(device), relying on torch's native device transfer rather than custom logic.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/torch.py`
- **Condition:** when modifying the torch tensor adapter's device transfer behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-4f1ad9fa406bd1b3071c69f7.md)

## Rule

- **Rule:**
  ```text
  Torch tensor adapter __init__ imports torch and stores it on self, indicating lazy framework import as the adapter initialization convention.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/torch.py`
- **Condition:** When adding or modifying tensor adapter initialization that must lazily import a framework.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-ce2f2baf8283bfa3a4f9ed0b.md)
