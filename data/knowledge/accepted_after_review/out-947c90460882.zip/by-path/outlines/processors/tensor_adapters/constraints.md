# Constraints for `outlines/processors/tensor_adapters`

## Rule

- **Rule:**
  ```text
  When adding or modifying a tensor adapter's initialization, import the framework lazily inside __init__ and store it as an attribute (e.g. self.jax) so the framework is not required at module import time.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/**/*.py`
- **Condition:**
  ```text
  when adding or changing a tensor adapter's __init__ or its framework import
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a8a0ca08c374ad39094ee374.md)

## Rule

- **Rule:**
  ```text
  TensorAdapter subclasses must implement argsort_descending to return indices that sort the tensor in descending order along axis -1.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/**/*.py`
- **Condition:**
  ```text
  when adding or modifying a TensorAdapter subclass or its argsort_descending implementation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b2beed26055c12bdae9606ed.md)

## Rule

- **Rule:** When adding or modifying a tensor adapter's conversion methods, delegate to the underlying framework's native conversion (e.g. tensor.tolist(), tensor.item(), tensor.numpy().item()) rather than reimplementing element-wise conversion, and use framework-specific APIs such as TensorFlow's argsort(direction='DESCENDING') and squeeze(axis=0) where the adapter's batch convention requires them.
- **Applies to:**
  - `outlines/processors/tensor_adapters/**/*.py`
- **Condition:**
  ```text
  when adding or changing a tensor adapter's to_list, to_scalar, argsort_descending, or squeeze implementations
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d42fc41438c0ff9c259970ef.md)

## Rule

- **Rule:**
  ```text
  Tensor adapter implementations must keep full_like and concatenate able to accept torch tensors until outlines-core is updated to receive plain arrays, and must implement the abstract to_list method converting TensorType to list.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/**/*.py`
- **Condition:**
  ```text
  when modifying or adding a tensor adapter implementation under outlines/processors/tensor_adapters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d7c579162eac02490d1031a5.md)
