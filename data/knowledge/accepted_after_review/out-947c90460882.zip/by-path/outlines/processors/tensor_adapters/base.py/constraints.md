# Constraints for `outlines/processors/tensor_adapters/base.py`

## Rule

- **Rule:**
  ```text
  TensorAdapter.full_like must accept a torch tensor regardless of the underlying library, an explicit cross-library invariant for tensor adapter implementations.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/base.py`
- **Condition:**
  ```text
  when implementing or modifying full_like in a tensor adapter
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-5c962de9f2c6ab94a633f617.md)

## Rule

- **Rule:**
  ```text
  TensorAdapter.to_device must move a tensor to a named device and return the moved tensor, defining the required device-transfer contract for tensor adapter implementations.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/base.py`
- **Condition:**
  ```text
  when implementing or modifying a TensorAdapter subclass's to_device method
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-f8983995f0aaef05965c43c4.md)
