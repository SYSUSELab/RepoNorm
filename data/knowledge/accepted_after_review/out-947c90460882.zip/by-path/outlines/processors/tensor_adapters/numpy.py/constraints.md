# Constraints for `outlines/processors/tensor_adapters/numpy.py`

## Rule

- **Rule:**
  ```text
  When modifying the numpy tensor adapter, preserve the descending argsort implementation that negates the tensor before calling `numpy.argsort`, achieving descending order via ascending argsort of negated values.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/numpy.py`
- **Condition:** When changing how descending ordering is computed in the numpy tensor adapter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2b1e5f4d40313bda5559e388.md)

## Rule

- **Rule:**
  ```text
  NumpyTensorAdapter must declare library_name = "numpy", the key used to register and look up the adapter in the tensor_adapters mapping consumed by BaseLogitsProcessor.__init__.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/numpy.py`
- **Condition:**
  ```text
  when adding or modifying a tensor adapter's library_name registration key
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2e8567480c144faac386073e.md)

## Rule

- **Rule:**
  ```text
  NumPy tensor adapter's to_list must delegate to tensor.tolist(), a convention shared across tensor adapters.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/numpy.py`
- **Condition:**
  ```text
  when implementing or modifying to_list in a tensor adapter
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-865f765f167c022c836a6754.md)
