# Constraints for `outlines/processors/tensor_adapters/jax.py`

## Rule

- **Rule:**
  ```text
  JAX tensor adapter's get_device must return None, encoding that JAX tensors have no device reported through this adapter interface.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/jax.py`
- **Condition:**
  ```text
  when implementing or modifying get_device in the JAX tensor adapter
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-ae52f027c02bd7edb25dd6ee.md)
