# Constraints for `outlines/processors/tensor_adapters/tensorflow.py`

## Rule

- **Rule:**
  ```text
  TensorFlowTensorAdapter.full_like must use tf.fill(tf.shape(tensor), fill_value) to produce a tensor of the same shape filled with the value.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/tensorflow.py`
- **Condition:**
  ```text
  When modifying full_like or adding tensor operations to the TensorFlow tensor adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-0ba4fea07daa683d07f8b55d.md)

## Rule

- **Rule:**
  ```text
  TensorFlow tensor adapter must implement unsqueeze via tf.expand_dims(tensor, axis=0), fixing the added dimension at axis 0.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/tensorflow.py`
- **Condition:** When modifying TensorFlowTensorAdapter.unsqueeze or its dimension handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2b4135e9122d2800d3c2b824.md)

## Rule

- **Rule:**
  ```text
  The tensorflow tensor adapter's `to_list` must convert via `tensor.numpy().tolist()`, requiring eager tensor semantics for the tensorflow backend.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/tensorflow.py`
- **Condition:** When modifying tensor-to-list conversion for the tensorflow backend.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-3caf1f3f8250e0c29faa13d4.md)

## Rule

- **Rule:**
  ```text
  TensorFlow tensor adapter must import tensorflow lazily inside __init__ and store it on self.tf, so TensorFlow is loaded at adapter construction time rather than module import.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/tensorflow.py`
- **Condition:**
  ```text
  When modifying TensorFlowTensorAdapter.__init__ or its tensorflow import.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-979c35d3e377c3ba81c75d62.md)
