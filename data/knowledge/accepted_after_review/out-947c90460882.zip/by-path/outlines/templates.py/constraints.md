# Constraints for `outlines/templates.py`

## Rule

- **Rule:**
  ```text
  Template.from_file must build the template via build_template_from_file and document that Jinja includes and inheritance cannot reference files outside the folder or subfolders of the given file.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  when modifying Template.from_file or the template loading path that resolves Jinja includes and inheritance
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-08c6a8fd859b7eead00a0c26.md)

## Rule

- **Rule:** The args template filter must require a callable and raise TypeError otherwise; it returns a comma-joined string of inspect.signature parameters including annotations and defaults.
- **Applies to:**
  - `outlines/templates.py`
- **Condition:** when modifying the args template filter's callable validation or signature formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4435020abe1075a26b15de89.md)

## Rule

- **Rule:** When adding or modifying the Template callable, render the underlying template with the supplied keyword arguments and return the rendered result as a Python string.
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  when adding or changing Template.__call__ or its rendering behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a5151f1f990e51b777a139c6.md)

## Rule

- **Rule:**
  ```text
  When modifying template string construction, preserve the cleaning sequence: apply `inspect.cleandoc`, re-add a trailing newline if the original content ended with a blank line, and collapse whitespace except after newlines to avoid introducing whitespace after backslash line continuations.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:** When changing how template strings are normalized or cleaned before use.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-adc110fb3a8b672d302c6e9a.md)

## Rule

- **Rule:**
  ```text
  get_schema_pydantic must dispatch on type(BaseModel) and branch on the presence of model_json_schema: Pydantic v2 models use the "$defs" key while older models fall back to "definitions" via model.schema(); the fallback branch is marked pragma: no cover, so contributors should not expect coverage for the legacy path.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  When modifying get_schema_pydantic or adding Pydantic version compatibility handling in the templates module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ae678ad5228405acabc2155d.md)

## Rule

- **Rule:**
  ```text
  parse_pydantic_schema must recursively resolve $ref entries against definitions and fall back to '<name>' placeholders for properties without description or $ref.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:** when modifying pydantic schema parsing or template schema flattening
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c6bd81054d60d58789713162.md)

## Rule

- **Rule:**
  ```text
  The template `name` filter requires a callable and raises TypeError otherwise; for callables lacking `__name__` it falls back to the type name, so contributors must not assume every callable has `__name__`.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  When modifying the template `name` filter or relying on `__name__` of callables passed to templates.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e0e24947b7ae9db76916b4fa.md)

## Rule

- **Rule:**
  ```text
  Template.from_string must build a template from Jinja string content and optional filters by delegating to build_template_from_string, returning a Template instance.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  when modifying or extending Template.from_string or the string-based template construction path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e616ddac093a6d9ff1cb9f6c.md)
