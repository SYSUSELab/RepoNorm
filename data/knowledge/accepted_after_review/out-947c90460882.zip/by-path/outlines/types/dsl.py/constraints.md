# Constraints for `outlines/types/dsl.py`

## Rule

- **Rule:** DSL helper functions and Term methods must accept both Term instances and raw strings, coercing strings into String terms before wrapping or combining them.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when adding or modifying DSL helper functions or Term operator methods that accept term-like arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-02b7165f27024950b612163f.md)

## Rule

- **Rule:** The regex function must return a Regex instance wrapping the provided pattern string, serving as the public DSL entry point for regex-constrained generation.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when modifying the regex DSL entry point or its return type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-10eb8c006a1b66701f7d53e4.md)

## Rule

- **Rule:** When modifying Python-type-to-DSL-term conversion, preserve the recursion depth limit of 10 and the RecursionError with a message about recursive type definitions to protect against infinite recursion.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When changing how recursive Python types are converted to DSL terms.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-13702c1367c1abb46f5daeba.md)

## Rule

- **Rule:**
  ```text
  `Sequence.__repr__` must render as `Sequence(terms=...)` using repr of its terms, defining the stable debug/string representation for this DSL node.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  When changing the string/debug representation of the `Sequence` DSL node.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-154f811d5f64f7fe7428bf10.md)

## Rule

- **Rule:**
  ```text
  python_types_to_terms must map native dict to CFG(grammars.json), dataclasses/TypedDict/Pydantic models to JsonSchema via TypeAdapter.json_schema(), genson schema builders to JsonSchema via to_json(), enums to Alternatives, and raise TypeError pointing to the GitHub issues URL for unsupported types; _handle_literal must map each Literal argument through python_types_to_terms and wrap them in Alternatives.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  When modifying python_types_to_terms or _handle_literal in the DSL type conversion module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-162cf1056f5fabb84351f797.md)

## Rule

- **Rule:** Regex is a dataclass subclass of Term whose only field is a string pattern, so regex-based types are represented as a Term carrying the raw pattern string.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When adding or modifying DSL Term subclasses that represent regex-based output types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2063c32a5a4281ae9e6f98eb.md)

## Rule

- **Rule:** The DSL exactly() method must remain a fluent combinator returning a QuantifyExact wrapping the receiver, so callers can chain quantification onto an existing type expression.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when modifying or adding fluent combinator methods on DSL Term types in outlines/types/dsl.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2e8dee3e20ebd5106b45c85d.md)

## Rule

- **Rule:**
  ```text
  String._display_node must render as String('<value>'), preserving the DSL display format for string terms.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  When modifying String._display_node or the DSL display representation of string terms.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3e956c6f752d9a952031ae1e.md)

## Rule

- **Rule:** JsonSchema must continue to accept a dictionary, string, Pydantic model, typed dict, dataclass, or genSON schema builder as its schema source.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When changing JsonSchema construction or its accepted schema source types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4398639ee478319447a0f057.md)

## Rule

- **Rule:** Alternatives must remain a dataclass Term holding a list of Term objects, preserving the recursive term-container representation of alternatives in the DSL.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when modifying or adding term container types in outlines/types/dsl.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4be4834bcdb2fbaf7b542640.md)

## Rule

- **Rule:**
  ```text
  QuantifyMaximum must be a dataclass subclass of Term with a term: Term field and a max_count: int field, following the DSL term dataclass pattern.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When adding or modifying DSL term dataclasses in the types/dsl module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4c59a4296ff86a6ae1575121.md)

## Rule

- **Rule:**
  ```text
  DSL Term types must implement __get_pydantic_json_schema__ returning a string schema with a regex pattern, and __get_validator__ returning a validate callable, so they participate in pydantic validation and JSON schema generation.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when modifying or adding DSL Term types in outlines/types/dsl.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-577bcfc0654b232b06a07e22.md)

## Rule

- **Rule:** Term.matches must compile the term's regex and use fullmatch so that matching requires the entire value to be consumed by the pattern.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when modifying Term.matches or any DSL matching logic that validates values against a term pattern
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a9d65a90b4f95c3857b77fa1.md)

## Rule

- **Rule:** Optional is a dataclass Term wrapping a single Term, indicating the DSL represents optionality as a recursive term container.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when modifying the Optional term in the DSL
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b641c6cc5eea654167a61c6f.md)

## Rule

- **Rule:**
  ```text
  JsonSchema.from_file must read a .json file and construct a JsonSchema from the parsed schema, defining the file-based schema construction API.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  when modifying JsonSchema.from_file's file reading or schema construction behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c01b3120d19394ad7ada6218.md)

## Rule

- **Rule:**
  ```text
  `at_least(count, term)` must coerce a string `term` into `String(term)` and return `QuantifyMinimum(term, count)`, so string arguments are accepted and normalized.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  When modifying `at_least` or the DSL term coercion rules for quantified constraints.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e265d6ee720c9af2477a23ad.md)

## Rule

- **Rule:**
  ```text
  Optional DSL node's _display_node must return 'Optional(?)', defining its display representation.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying the Optional DSL node's display representation or adding new DSL nodes with display methods.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f7805da61d18211d3ee06f92.md)
