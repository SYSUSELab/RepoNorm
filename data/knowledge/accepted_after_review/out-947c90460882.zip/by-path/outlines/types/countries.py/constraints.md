# Constraints for `outlines/types/countries.py`

## Rule

- **Rule:**
  ```text
  get_country_flags must derive each flag from the Alpha2 enum member name by offsetting from the regional-indicator base codepoint ord('🇦'), so flag generation depends on two-letter uppercase ISO codes.
  ```
- **Applies to:**
  - `outlines/types/countries.py`
- **Condition:**
  ```text
  When modifying get_country_flags or the Alpha2 enum member naming.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-02acf28a713ebe529b410ab5.md)
