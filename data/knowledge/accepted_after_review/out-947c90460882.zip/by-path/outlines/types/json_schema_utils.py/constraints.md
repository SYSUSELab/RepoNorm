# Constraints for `outlines/types/json_schema_utils.py`

## Rule

- **Rule:**
  ```text
  When adding or modifying preprocess_schema_for_union_types, keep it as a temporary workaround for outlines-core lacking JSON schema type arrays by converting ["string","null"] to anyOf, and return invalid JSON strings unchanged to preserve error behavior.
  ```
- **Applies to:**
  - `outlines/types/json_schema_utils.py`
- **Condition:**
  ```text
  when adding or changing preprocess_schema_for_union_types or its handling of union-type schemas
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e25036a3586891723290c083.md)
