# Constraints for `outlines/types/utils.py`

## Rule

- **Rule:**
  ```text
  Type-detection helpers in outlines/types/utils.py must recognize string-like values across str, get_origin(value) is str, Annotated[str, ...], and NewType wrappers, and must follow the shared is_* convention of checking both the type and its origin.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  when modifying or adding is_* type-detection helpers in outlines/types/utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-330aecf9d169ffa3f8082018.md)

## Rule

- **Rule:**
  ```text
  is_pydantic_model must return False for generic types with a non-None origin, and otherwise True only for classes that subclass BaseModel; the origin check exists because generic types cannot be used with issubclass on Python versions below 3.11.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  When modifying is_pydantic_model or adding type-detection utilities that must handle generic types across Python versions.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-39bbcbcb281a8f878e7b8091.md)

## Rule

- **Rule:**
  ```text
  is_datetime must return True both for the datetime.datetime class itself and for typing constructs whose origin is datetime.datetime, handling bare classes and parameterized generics.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  when modifying the is_datetime type predicate
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e569ca070cf5dc1f7c69628.md)

## Rule

- **Rule:**
  ```text
  is_callable must return callable(value) and not isinstance(value, type), deliberately excluding classes from being treated as callable for this predicate.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  when modifying the is_callable type predicate
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7840d17f46b4bcc356dbbeab.md)

## Rule

- **Rule:**
  ```text
  outlines/types/utils.py must import _TypedDictMeta from typing on Python 3.12+ and from typing_extensions otherwise, preserving this compatibility boundary when touching TypedDict handling.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:** when modifying TypedDict handling or imports in outlines/types/utils.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d929f0056fed1774f43cdb85.md)
