# Constraints for `outlines/backends/base.py`

## Rule

- **Rule:**
  ```text
  BaseBackend.get_json_schema_logits_processor must be an abstract method taking a JSON schema string and returning a LogitsProcessorType, defining the required interface for backend implementations.
  ```
- **Applies to:**
  - `outlines/backends/base.py`
- **Condition:**
  ```text
  when implementing or modifying a backend's get_json_schema_logits_processor method
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-71ea06810362ced798b1d7d5.md)

## Rule

- **Rule:**
  ```text
  Backend classes must implement logits processor creation from JSON schema, regex, or CFG, and the XGrammar backend must compile JSON schema via grammar_compiler.compile_json_schema and wrap it in XGrammarLogitsProcessor.
  ```
- **Applies to:**
  - `outlines/backends/base.py`
  - `outlines/backends/xgrammar.py`
- **Condition:** when adding or modifying a backend that creates logits processors from structured constraints
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-92161124f45703aac8ba0aad.md)
