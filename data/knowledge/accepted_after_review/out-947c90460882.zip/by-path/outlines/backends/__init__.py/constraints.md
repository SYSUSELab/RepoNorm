# Constraints for `outlines/backends/__init__.py`

## Rule

- **Rule:**
  ```text
  The backends package must define CFG_DEFAULT_BACKEND as 'llguidance' while JSON_SCHEMA_DEFAULT_BACKEND and REGEX_DEFAULT_BACKEND are 'outlines_core'.
  ```
- **Applies to:**
  - `outlines/backends/__init__.py`
- **Condition:** when modifying default backend selection constants in the backends package
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-19bdbebee6e1391705d11cc7.md)
