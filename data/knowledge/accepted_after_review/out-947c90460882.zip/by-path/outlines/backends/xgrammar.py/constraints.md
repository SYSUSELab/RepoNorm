# Constraints for `outlines/backends/xgrammar.py`

## Rule

- **Rule:**
  ```text
  XGrammarLogitsProcessor.reset() must set self.xgrammar_logits_processor to None, clearing the processor rather than reinitializing it.
  ```
- **Applies to:**
  - `outlines/backends/xgrammar.py`
- **Condition:** when modifying the reset behavior of a logits processor that holds a compiled grammar state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-475d17dfa7265546f77ce5eb.md)

## Rule

- **Rule:**
  ```text
  xgrammar process_logits must lazily construct the xgrammar LogitsProcessor from the compiled grammar on first call and then delegate to it, preserving the lazy initialization pattern for the backend.
  ```
- **Applies to:**
  - `outlines/backends/xgrammar.py`
- **Condition:**
  ```text
  When modifying XGrammarLogitsProcessor.process_logits or its logits processor initialization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e49876a3636cba5fe8f050c.md)

## Rule

- **Rule:**
  ```text
  Backend classes must implement logits processor creation from JSON schema, regex, or CFG, and the XGrammar backend must compile JSON schema via grammar_compiler.compile_json_schema and wrap it in XGrammarLogitsProcessor.
  ```
- **Applies to:**
  - `outlines/backends/base.py`
  - `outlines/backends/xgrammar.py`
- **Condition:** when adding or modifying a backend that creates logits processors from structured constraints
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-92161124f45703aac8ba0aad.md)
