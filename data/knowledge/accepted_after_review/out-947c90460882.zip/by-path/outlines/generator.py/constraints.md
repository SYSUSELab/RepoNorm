# Constraints for `outlines/generator.py`

## Rule

- **Rule:**
  ```text
  SteerableGenerator.from_processor must bypass __init__ via cls.__new__ and set only model and logits_processor, so subclasses relying on additional initialization state must override this classmethod.
  ```
- **Applies to:**
  - `outlines/generator.py`
- **Condition:**
  ```text
  when modifying or subclassing SteerableGenerator.from_processor in outlines/generator.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-158fccab18d1ca5f1d8e0ff5.md)

## Rule

- **Rule:** When adding or modifying a model backend's output-type handling, preserve the distinction that steerable backends compile the output type into logits processors while black-box backends pass the output type directly to the model without compilation.
- **Applies to:**
  - `outlines/generator.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/vllm.py`
- **Condition:** When changing how a generator or model backend converts an output type into generation constraints.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1a4fc9c48e89cac961318d8e.md)

## Rule

- **Rule:**
  ```text
  When modifying the steerable generator's call path, preserve the reset of the logits processor before each `model.generate` call so stateful processors are reinitialized per generation.
  ```
- **Applies to:**
  - `outlines/generator.py`
- **Condition:** When changing the steerable generator's invocation of model.generate.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2d7dbf986df7d919e381c4d8.md)
