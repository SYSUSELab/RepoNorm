# Constraints for `outlines/inputs.py`

## Rule

- **Rule:**
  ```text
  Audio must be a dataclass holding an audio: Any field, documented to be passed alongside a text prompt in a list as model_input for audio-capable multimodal models.
  ```
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying the Audio dataclass or its multimodal input usage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0ccaf4ac8cf07fcff2e5c30c.md)

## Rule

- **Rule:**
  ```text
  Chat.add_user_message must append a dict with role "user" and the given content to self.messages, preserving the message representation used by the Chat input type.
  ```
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:**
  ```text
  When modifying Chat.add_user_message or the Chat message representation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-55ceb5362f2005fe0c78d4fa.md)

## Rule

- **Rule:** Chat.append must append the provided message dict directly to self.messages, allowing arbitrary role/content dicts to be added to the chat.
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying or extending Chat.append or the chat message accumulation behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6b8fd8192a57b7d40bb012bb.md)

## Rule

- **Rule:** Chat.extend must append a list of message dicts to self.messages, defining the mutation semantics for extending a chat conversation.
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying Chat.extend's message mutation behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-97ea33a189f84b0db1c1cdde.md)

## Rule

- **Rule:**
  ```text
  outlines.inputs.Video must be a dataclass wrapping an arbitrary video value, intended to be passed alongside a text prompt in a list as model_input to video-capable models.
  ```
- **Applies to:**
  - `outlines/inputs.py`
- **Condition:** when modifying the Video input type or its usage in model inputs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bbdd91fb337ad72e837924d8.md)

## Rule

- **Rule:** Chat message inputs must be dicts carrying 'role' and 'content' keys, where role is one of user/assistant/system and content is a string or a list containing a string plus multimodal assets; string prompts are passed through unchanged rather than being wrapped into chat messages.
- **Applies to:**
  - `outlines/inputs.py`
  - `outlines/models/tgi.py`
- **Condition:** When changing how chat messages are validated or how string prompts are converted into model inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bf8adc836ae38de3cbc3e594.md)
