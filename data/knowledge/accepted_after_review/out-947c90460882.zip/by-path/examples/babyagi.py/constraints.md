# Constraints for `examples/babyagi.py`

## Rule

- **Rule:**
  ```text
  The BabyAGI example's one_cycle must not reuse the loop variable `task` for newly created tasks while also referencing the popped task via a different name (first_task); contributors fixing or extending this example should resolve the shadowing so the popped task's task_name is used consistently.
  ```
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:**
  ```text
  When modifying the BabyAGI example's one_cycle task-creation loop or its variable naming.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0e3de5e758e71e8839e913e9.md)

## Rule

- **Rule:** Examples that parse structured model output must implement the parsing convention explicitly (e.g. splitting lines and keeping only lines containing a period, taking text after the first period) rather than relying on the model to return clean structured text.
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When adding or modifying an example that parses structured model output into discrete items.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-21980cad68b287fc13e014c0.md)

## Rule

- **Rule:**
  ```text
  Examples that load prompt or template files via relative paths (e.g. Template.from_file("prompts/...")) must be run from their own example directory; contributors changing such examples should preserve or document the working-directory requirement rather than silently switching to absolute paths.
  ```
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When modifying an example that loads prompt/template files through relative paths.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b721db90a9dc7d3cdc4d6803.md)
