# Constraints for `examples/beam-cloud/app.py`

## Rule

- **Rule:**
  ```text
  Examples that load a HuggingFace causal LM through outlines.models.from_transformers must pass matching AutoModelForCausalLM and AutoTokenizer instances for the same model identifier.
  ```
- **Applies to:**
  - `examples/beam-cloud/app.py`
  - `examples/modal_example.py`
- **Condition:**
  ```text
  When adding or modifying an example that constructs an Outlines model via from_transformers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-749f751983e6ac300b005fbe.md)

## Rule

- **Rule:**
  ```text
  Serverless examples must load the model once in the endpoint's on_start hook and retrieve it via context.on_start_value, constructing the Generator per request rather than reloading the model on each invocation.
  ```
- **Applies to:**
  - `examples/beam-cloud/app.py`
- **Condition:** When modifying the Beam Cloud example's model loading or request handler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d8b2d12d22ea8465ef9f99b0.md)
