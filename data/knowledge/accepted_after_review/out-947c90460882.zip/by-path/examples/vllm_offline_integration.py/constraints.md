# Constraints for `examples/vllm_offline_integration.py`

## Rule

- **Rule:** Examples that define a structured output schema must use a pydantic model with typed string fields as the schema passed to the generation pipeline.
- **Applies to:**
  - `examples/vllm_offline_integration.py`
- **Condition:** When adding or modifying an example that defines a structured output schema for generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8376d86e5f2782c9e640164a.md)
