# Constraints for `examples/react.py`

## Rule

- **Rule:**
  ```text
  The react example's search_wikipedia helper must build a MediaWiki API URL with format=json and return only the first two sentences of the page extract joined by periods; contributors changing the helper should preserve this truncation behavior.
  ```
- **Applies to:**
  - `examples/react.py`
- **Condition:** When modifying the react example's Wikipedia search helper or its result formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ced30761d39485316350a34b.md)
