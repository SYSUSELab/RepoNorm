# Constraints for `examples/bentoml/service.py`

## Rule

- **Rule:**
  ```text
  The BentoML example service must keep its DEFAULT_SCHEMA JSON schema in sync with the Character model: required fields name, age, armor, weapon, strength and $ref-based Armor/Weapon enum definitions must match the schema the service expects.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
- **Condition:**
  ```text
  When modifying the BentoML example's Character schema or its DEFAULT_SCHEMA JSON definition.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-68bd9ce3d82c352f939b8ca0.md)

## Rule

- **Rule:**
  ```text
  Examples that constrain generation with a JSON schema must pass the schema through outlines.json_schema(...) when constructing the generator or processor, rather than embedding schema constraints in the prompt alone.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
  - `examples/cerebrium/main.py`
  - `examples/pick_odd_one_out.py`
- **Condition:** When adding or modifying an example that constrains model output to a JSON schema.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b386c81ae0bda0895ba434d7.md)
