# Constraints for `.github/workflows/build_documentation.yml`

## Rule

- **Rule:**
  ```text
  The documentation build workflow runs on pull requests targeting the main branch and can also be triggered manually via workflow_dispatch.
  ```
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: pull_request: branches: [main] workflow_dispatch:
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-58975a21266b4b16e1e19342.md)

## Rule

- **Rule:** The documentation build job runs on ubuntu-latest and builds the documentation by installing requirements-doc.txt with pip and running mkdocs build.
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-903fa9f5ee1e86e9386924e4.md)

## Rule

- **Rule:** The documentation build workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eab19b4a6b6f7d4638a6119e.md)
