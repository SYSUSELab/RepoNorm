# Constraints for `.github/workflows/publish_documentation.yml`

## Rule

- **Rule:** The workflow checks out the repository with fetch-depth 0 and sets up Python version 3.x.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1522a03ff5493dd155bf9837.md)

## Rule

- **Rule:** When the event is a release, the workflow deploys the tag as the latest alias and sets latest as the default version using mike.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'release'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1ace280d84471390aacdaf90.md)

## Rule

- **Rule:** The workflow installs documentation dependencies from requirements-doc.txt and builds the docs with mkdocs build.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d162945b42cbf7939a5dc92.md)

## Rule

- **Rule:** The deploy job runs on ubuntu-latest and grants contents: write permission.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-64311b06200f2d2824a1177b.md)

## Rule

- **Rule:**
  ```text
  The documentation publishing workflow runs on workflow_dispatch, on pushes to the main branch, and on release events of type created.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: workflow_dispatch: push: branches: - main release: types: - created
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cb63947d508c905d7ffeeb60.md)

## Rule

- **Rule:** When the event is a push, the workflow deploys the branch as the unstable alias using mike.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f2080984b9d4d39c192bfb29.md)
