# Constraints for `.github/workflows/release_pypi.yaml`

## Rule

- **Rule:**
  ```text
  The release workflow checks that the package version matches the release name by grepping for "^Version: ${GITHUB_REF:10}$" in outlines.egg-info/PKG-INFO.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-535917fda7b0f3950f1e29fa.md)

## Rule

- **Rule:**
  ```text
  The release workflow publishes to PyPI using pypa/gh-action-pypi-publish with user __token__ and password from the PYPI_TOKEN secret.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-56d2890b6a15613ebbbc1845.md)

## Rule

- **Rule:** The release workflow triggers on release events of type created.
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Condition:** workflow predicate: release: types: - created
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cbec6a63a8fe421f342f56a9.md)

## Rule

- **Rule:** The release job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d27666b7fee8948810410917.md)

## Rule

- **Rule:**
  ```text
  The release workflow builds the SDist and wheel by running ./.github/scripts/build_sdist_and_wheel.sh.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dd725eedbef4191dff50eb5d.md)

## Rule

- **Rule:** The release workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e96125d8ab2429720fa0fea3.md)
