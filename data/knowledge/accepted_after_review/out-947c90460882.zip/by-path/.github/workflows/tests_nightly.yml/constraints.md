# Constraints for `.github/workflows/tests_nightly.yml`

## Rule

- **Rule:** The tests job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1943453b6537ce343be5c5a5.md)

## Rule

- **Rule:** The tests job matrix uses Python version "3.10".
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-62f3dfd89b6204491ee69302.md)

## Rule

- **Rule:**
  ```text
  The tests job provides OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, and DOTTXT_API_KEY from repository secrets as environment variables.
  ```
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6434f6193cb82293825eefdf.md)

## Rule

- **Rule:** The workflow installs Ollama and pulls the tinyllama model.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-657003d7e793ef8852ab6337.md)

## Rule

- **Rule:** The coverage file is set to .coverage.${{ steps.matrix-id.outputs.id }} for the test run.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7c14a34daafc4cace355e7e4.md)

## Rule

- **Rule:**
  ```text
  The Nightly Tests workflow runs on a schedule with cron "0 6 * * *".
  ```
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Condition:**
  ```text
  workflow predicate: schedule: - cron: "0 6 * * *"
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dd5e57b1016fbcc8e16d6bd3.md)

## Rule

- **Rule:** The tests job sets fail-fast to false.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ef04ff96076b823155e44302.md)

## Rule

- **Rule:** The test environment is set up by upgrading pip, installing uv, creating a uv venv, and installing the package editable with the test extra.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-faf4114f05545a2094d54087.md)
