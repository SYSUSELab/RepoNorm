# Constraints for `.github/workflows/asv_benchmark_pr.yml`

## Rule

- **Rule:** The workflow runs asv compare with --factor=1.1 --no-stats --split upstream/main HEAD and fails the step if the output contains 'Benchmarks that have got worse'.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-28e64d1c488af19b18a89eae.md)

## Rule

- **Rule:**
  ```text
  The workflow uses Python version 3.10 via the PYTHON_VERSION environment variable.
  ```
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3cc3e01545e69b165c4d38eb.md)

## Rule

- **Rule:** The workflow runs asv continuous comparing upstream/main to HEAD with --no-stats --interleave-rounds -a repeat=3, tolerating errors.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7a78fa96a9339420d1eba6cf.md)

## Rule

- **Rule:** The workflow installs asv, virtualenv, and lf-asv-formatter as dependencies.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-81b03cd8051cea8dc1d3cb33.md)

## Rule

- **Rule:** The benchmark-pr job runs only when the pull request has the 'run-benchmarks' label or the ref is refs/heads/main.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Condition:**
  ```text
  workflow predicate: ${{ contains(github.event.pull_request.labels.*.name, 'run-benchmarks') || github.ref == 'refs/heads/main' }}
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ec3f8988297d0e114de50f4f.md)

## Rule

- **Rule:**
  ```text
  The Benchmark PR workflow runs on push, pull_request (types synchronize and labeled), and workflow_dispatch events.
  ```
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Condition:**
  ```text
  workflow predicate: push: pull_request: types: [synchronize, labeled] workflow_dispatch:
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ef7480c0403c9a668d3e5b29.md)
