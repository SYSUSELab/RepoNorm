# Constraints for `docs`

## Rule

- **Rule:** Read the Docs uses docs/source/conf.py as the Sphinx configuration file.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0cc1e49efc7daa4acdaf4c70.md)

## Rule

- **Rule:**
  ```text
  Run `mkdocs serve` to view the documentation locally, with the served site updating on each change.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-6d511bac111d3cf0a0acf453.md)

## Rule

- **Rule:** Read the Docs builds documentation with the html builder.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-71d524e57933a81cc620d0e9.md)

## Rule

- **Rule:** Read the Docs treats Sphinx warnings as build failures.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-dff3dd164efa16853031af62.md)

## Rule

- **Rule:** The redirects plugin maps welcome.md to index.md.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ecabb885a670200b351c08f1.md)

## Rule

- **Rule:** The MkDocs documentation source directory is configured as docs.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f4d3d81912ceb51e1bc64867.md)
