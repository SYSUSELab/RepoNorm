# Constraints for `pyproject.toml`

## Rule

- **Rule:** The project version is declared as dynamic rather than a static value.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-33bec29ab8660a2bb7013c8a.md)
