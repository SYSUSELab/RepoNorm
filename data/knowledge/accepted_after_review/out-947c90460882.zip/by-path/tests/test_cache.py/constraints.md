# Constraints for `tests/test_cache.py`

## Rule

- **Rule:**
  ```text
  The test_cache fixture must set OUTLINES_CACHE_DIR to a temporary directory and assert that outlines.get_cache().directory equals that tempdir, establishing OUTLINES_CACHE_DIR as the environment variable controlling cache location.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:**
  ```text
  When adding or modifying the test_cache fixture or cache directory tests in tests/test_cache.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1de3081c37cd2eb76887b248.md)

## Rule

- **Rule:**
  ```text
  cache_disabled must disable caching only within its context scope: calls inside the scope bypass the cache while calls before and after use it.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:**
  ```text
  When modifying or adding tests for cache_disabled context-scoped behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4d44e7fbb8c36cca09d840af.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the public cache API must preserve the observable memoization contract: repeated calls to a cached function do not grow the store, outlines.clear_cache() causes the next call to grow the store by exactly one, and outlines.disable_cache() causes repeated calls to grow the store each time.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:**
  ```text
  When modifying or adding tests around outlines cache behavior, including clear_cache and disable_cache.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4e7fa3f26999a7119c684d8a.md)

## Rule

- **Rule:**
  ```text
  Cache keys must be tied to the Outlines version: changing a cached function's return signature without a version bump reuses the stale cache and raises ValueError, while bumping outlines._version.__version__ invalidates the old cache so the new signature works.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** When modifying or adding tests for cache invalidation tied to the Outlines version.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4fbabcf3a4a9fe0e32b189f3.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the public cache version-upgrade path must preserve the restart simulation convention: simulate a process restart by clearing only the in-memory lru_cache wrapper around the diskcache, leaving the diskcache itself intact.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** When modifying or adding tests around cache version upgrade and restart simulation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ccfbc89392e5e4d328ab79ba.md)

## Rule

- **Rule:**
  ```text
  outlines.get_cache() must return a diskcache.Cache, and repeated calls with the same argument must not increase the cache store size while a new argument does.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** When modifying or adding cache tests that assert the caching contract for repeated inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cf601a350ce858101b0a0bd1.md)

## Rule

- **Rule:**
  ```text
  The `refresh_environment` fixture must delete all `sys.modules` entries containing 'outlines' and unset `OUTLINES_CACHE_DIR` because the cache is held in a module variable, ensuring test isolation for cache-dependent tests.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:**
  ```text
  When modifying cache tests or the `refresh_environment` fixture.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f166bb8550924cb0ae03760a.md)
