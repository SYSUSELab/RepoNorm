# Constraints for `tests/backends/test_xgrammar.py`

## Rule

- **Rule:**
  ```text
  The xgrammar backend test fixture must construct a transformers model through outlines.from_transformers using the small model erwanf/gpt2-mini for both model and tokenizer.
  ```
- **Applies to:**
  - `tests/backends/test_xgrammar.py`
- **Condition:** when adding or modifying the xgrammar backend test fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-abef0746e5737f930390888f.md)

## Rule

- **Rule:** Tests for a backend's logits processors must assert both the processor class identity and that generated output conforms to each constraint kind (JSON schema, regex, CFG).
- **Applies to:**
  - `tests/backends/test_xgrammar.py`
- **Condition:** When adding or modifying backend logits-processor tests that cover multiple constraint kinds.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cf5fdac21f2d235d9cf67143.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise a backend requiring a pinned model must load that model via the backend's loader and wrap it with the corresponding outlines adapter (e.g. mlx_lm.load then outlines.from_mlxlm), rather than using a generic or unpinned model.
  ```
- **Applies to:**
  - `tests/backends/test_xgrammar.py`
- **Condition:** when adding or modifying a test fixture that loads a model for a specific backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eaf766eb6a2508c316ad12e9.md)

## Rule

- **Rule:**
  ```text
  Optional MLX availability in backend tests must be guarded by HAS_MLX, while llama_cpp, transformers, and xgrammar GrammarCompiler imports remain unconditional.
  ```
- **Applies to:**
  - `tests/backends/test_xgrammar.py`
- **Condition:** When adding or modifying imports in XGrammar backend tests that depend on optional MLX.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f533ace1a01f977e97ea0b26.md)
