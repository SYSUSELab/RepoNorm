# Constraints for `tests/backends/test_backends.py`

## Rule

- **Rule:**
  ```text
  Backend tests must import the private _get_backend alongside the public get_json_schema_logits_processor, get_regex_logits_processor, and get_cfg_logits_processor, exercising backend selection through the private helper.
  ```
- **Applies to:**
  - `tests/backends/test_backends.py`
- **Condition:**
  ```text
  When adding or modifying backend selection tests in tests/backends/test_backends.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3306dccaa4110941d2a2de5a.md)

## Rule

- **Rule:**
  ```text
  Tests for backend utilities must preserve the documented stable regex fixture: the regex fixture returns the literal pattern r"[0-9]{3}" used across backend tests.
  ```
- **Applies to:**
  - `tests/backends/test_backends.py`
- **Condition:** when adding or modifying backend tests that use the shared regex fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7bb3852723fec27d62f484bb.md)

## Rule

- **Rule:**
  ```text
  `get_regex_logits_processor` must map backend names to processor classes: "outlines_core" to OutlinesCoreLogitsProcessor, "llguidance" to LLGuidanceLogitsProcessor, and "xgrammar" to XGrammarLogitsProcessor.
  ```
- **Applies to:**
  - `tests/backends/test_backends.py`
- **Condition:**
  ```text
  when changing backend-name-to-processor-class dispatch in get_regex_logits_processor
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c50ba282f317e44ba31fcc6b.md)

## Rule

- **Rule:** Tests for the backend selector must assert that each supported backend name maps to its specific backend class and that an unknown name raises ValueError with a message matching 'not supported'.
- **Applies to:**
  - `tests/backends/test_backends.py`
- **Condition:** When adding or modifying a test for the backend selection helper that maps backend names to backend classes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cff2eaaddf4954a8df0883e2.md)
