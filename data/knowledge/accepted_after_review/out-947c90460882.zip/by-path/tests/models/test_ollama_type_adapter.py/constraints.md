# Constraints for `tests/models/test_ollama_type_adapter.py`

## Rule

- **Rule:**
  ```text
  The Ollama type adapter's format_input must convert a plain text prompt into a single-element list containing a user-role message dict with the text as content.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:**
  ```text
  when modifying or extending Ollama type adapter format_input or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-063d5804c48254a23951bd39.md)

## Rule

- **Rule:**
  ```text
  The Ollama type adapter must format a genson SchemaBuilder with mixed integer/string values into a JSON schema whose type is ["integer", "string"] and whose required list is ["hi"].
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:** when changing Ollama type adapter schema formatting for genson SchemaBuilder inputs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-070f7d713939571af3173289.md)

## Rule

- **Rule:**
  ```text
  Type adapter tests must assert that format_output_type passes the provided schema through unchanged for dataclass output types.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:** When adding or modifying type adapter tests for dataclass output types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4ae00eeab0740c66ee5aaf9f.md)

## Rule

- **Rule:** Tests for model backends must preserve the documented multimodal message shape: Ollama vision formatting yields a single user message with text content and an image list, and vLLM async vision chat accepts system/user-with-image/assistant messages and returns a string.
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
  - `tests/models/test_vllm.py`
- **Condition:** when adding or modifying tests for multimodal or vision message formatting in a model backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4bb667c41f71bc28b1f04207.md)

## Rule

- **Rule:**
  ```text
  Tests for the Ollama type adapter's format_output_type must assert the exact expected schema fixture for a TypedDict output type.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:**
  ```text
  When adding or modifying a test for the Ollama type adapter's format_output_type with a TypedDict.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6390dfbf2e42755481e887b4.md)

## Rule

- **Rule:**
  ```text
  Tests for model output type adapters must assert that format_output_type converts a Pydantic model into the expected schema representation.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:** when adding or modifying output type adapter tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9ef5e38cd4b77632df4a8c6f.md)

## Rule

- **Rule:** Tests for structured-output backends must assert that generation with a schema/regex constraint returns a str matching the constraint, and must reject unsupported output types with TypeError.
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
  - `tests/models/test_sglang.py`
  - `tests/models/test_transformers.py`
  - `tests/models/test_vllm.py`
- **Condition:** when adding or modifying tests for a model backend's structured-output or constrained-decoding support
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d80643a228790e789ebbde9c.md)

## Rule

- **Rule:**
  ```text
  The Ollama type adapter's format_output_type must round-trip a JSON schema string back to the original schema object, defining the adapter's schema normalization contract.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:**
  ```text
  when modifying or extending Ollama type adapter format_output_type or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ee5e08cd4df3004000fa4f97.md)
