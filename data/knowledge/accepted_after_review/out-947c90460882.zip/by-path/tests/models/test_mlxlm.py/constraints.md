# Constraints for `tests/models/test_mlxlm.py`

## Rule

- **Rule:** MLXLM batch inference is explicitly unsupported: model.batch(...) must raise NotImplementedError matching "does not support", and the test is skipped unless MLX is available.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** When modifying MLXLM batch behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-18f36a411e52c0e1b9c046f4.md)

## Rule

- **Rule:**
  ```text
  MLX tests must be gated by pytest.mark.skipif(not HAS_MLX, reason='MLX tests require Apple Silicon') and choice tests must assert the model output is one of the allowed choices.
  ```
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying MLX model tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-226612617b6b5cc1a8c6007f.md)

## Rule

- **Rule:** MLXLM model calls must reject unknown inference keyword arguments by raising TypeError, so passing an unsupported kwarg such as foo='bar' is an error rather than being silently ignored.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when changing MLXLM model call handling of inference keyword arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7b2007fc9cc946dc827c1f60.md)

## Rule

- **Rule:** The MLX model wrapper's generate must return a str, establishing the basic return-type contract for the MLX model wrapper.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when changing the MLX model wrapper generate return type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9f1c7008df65e8433c7317b1.md)

## Rule

- **Rule:**
  ```text
  Tests for model backends must preserve the documented availability guard: MLX tests set TEST_MODEL to the pinned model and guard availability via mx.metal.is_available() inside a try/except ImportError that sets HAS_MLX = False.
  ```
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying tests for a model backend that requires optional hardware or library availability
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c0686b474dc091ade7d58eac.md)

## Rule

- **Rule:**
  ```text
  The mlxlm test model fixture must be session-scoped, load TEST_MODEL via mlx_lm.load, and wrap it with outlines.from_mlxlm(model, tokenizer).
  ```
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when changing how mlxlm models are constructed in tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c2341274416299f5b3e654e6.md)

## Rule

- **Rule:** Tests for the MLX LM backend must be skipped unless Apple Silicon MLX is available, and must assert the generated result is a string matching the requested regex pattern.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** When adding or modifying a test for the MLX LM backend's regex-constrained generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d9def3bee3152f66a3731cde.md)
