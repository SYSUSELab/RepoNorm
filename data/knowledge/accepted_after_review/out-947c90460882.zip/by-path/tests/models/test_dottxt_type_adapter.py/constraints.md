# Constraints for `tests/models/test_dottxt_type_adapter.py`

## Rule

- **Rule:**
  ```text
  The Dottxt type adapter's format_input must return a plain string prompt unchanged.
  ```
- **Applies to:**
  - `tests/models/test_dottxt_type_adapter.py`
- **Condition:** when changing Dottxt type adapter input formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-258558c067907f8b2b669c80.md)

## Rule

- **Rule:**
  ```text
  The dottxt type adapter's format_output_type must raise TypeError for None, str, int, Regex, and CFG inputs, with distinct messages including that Regex- and CFG-based structured outputs will soon be supported.
  ```
- **Applies to:**
  - `tests/models/test_dottxt_type_adapter.py`
- **Condition:**
  ```text
  When adding or modifying a test for dottxt format_output_type rejection of unsupported output types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4f4bbe147c2be3622d1c8529.md)

## Rule

- **Rule:**
  ```text
  The dottxt type adapter test fixture must supply a JSON schema object requiring user_id and name.
  ```
- **Applies to:**
  - `tests/models/test_dottxt_type_adapter.py`
- **Condition:** When adding or modifying the JSON schema fixture used by dottxt type adapter tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5dc9eadef45fb7e7a72586c8.md)

## Rule

- **Rule:**
  ```text
  Tests for type adapters must preserve the documented structured-output contract: OpenAI dataclass output formatting yields a response_format with json_schema.strict True and the expected schema, and the dottxt adapter imports TypedDict from typing on Python 3.12+ and typing_extensions otherwise.
  ```
- **Applies to:**
  - `tests/models/test_dottxt_type_adapter.py`
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when adding or modifying tests for type adapter structured-output formatting or version-dependent typing imports
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7cb30b2869da2fd6dedd5e7a.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise a type adapter's output format must assert the exact serialization (e.g. format_output_type for a TypedDict returns json.dumps(schema)), rather than only checking the type or presence of output.
  ```
- **Applies to:**
  - `tests/models/test_dottxt_type_adapter.py`
- **Condition:** when adding or modifying a test for a type adapter's output format
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b3ff275154d4657c76a001f8.md)

## Rule

- **Rule:** The Dottxt type adapter test module must construct a fresh DottxtTypeAdapter instance per test via an adapter fixture.
- **Applies to:**
  - `tests/models/test_dottxt_type_adapter.py`
- **Condition:** when adding or modifying Dottxt type adapter tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b598f1238f2033cc96be89c7.md)
