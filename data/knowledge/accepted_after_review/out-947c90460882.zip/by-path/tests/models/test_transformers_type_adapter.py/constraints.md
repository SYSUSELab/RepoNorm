# Constraints for `tests/models/test_transformers_type_adapter.py`

## Rule

- **Rule:**
  ```text
  The Transformers type adapter must wrap a logits processor into a LogitsProcessorList preserving `index` and `tensor_library_name`, and must map a None output type to None.
  ```
- **Applies to:**
  - `tests/models/test_transformers_type_adapter.py`
- **Condition:** When adding or modifying a test for the Transformers type adapter's logits processor wrapping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a9c670e2db442de3110fc2c.md)

## Rule

- **Rule:**
  ```text
  The TransformersTypeAdapter fixture overrides the tokenizer's chat_template with a custom role/content template, so chat formatting tests depend on this injected template.
  ```
- **Applies to:**
  - `tests/models/test_transformers_type_adapter.py`
- **Condition:** when modifying or extending TransformersTypeAdapter fixtures or chat formatting tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-917d3ae4872a2ea8afb514bf.md)
