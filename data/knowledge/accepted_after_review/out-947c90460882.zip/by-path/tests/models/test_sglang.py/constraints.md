# Constraints for `tests/models/test_sglang.py`

## Rule

- **Rule:**
  ```text
  Tests for backend selection must use the SGLANG_SERVER_URL environment variable to choose between a real server and a mock client, warning and defaulting to the mock client when unset, and defaulting the model name via SGLANG_MODEL_NAME.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying tests that need to select between a real SGLang server and a mock client
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3464fe52e7de5195a6e43c40.md)

## Rule

- **Rule:** AsyncSGLang.stream must return an AsyncGenerator yielding str chunks, and the model name may be supplied per-call via the model keyword argument rather than only at construction.
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** When modifying AsyncSGLang streaming behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3bce8015c67f197137006548.md)

## Rule

- **Rule:** Tests that exercise a backend's structured-output warning must assert the specific UserWarning message fragment (e.g. 'SGLang grammar-based structured outputs expects an EBNF') and that the result is a valid constrained value, rather than ignoring the warning.
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying a test that exercises a backend's structured-output warning
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-53ecda3d5559d10997daf9b4.md)

## Rule

- **Rule:** Tests that exercise a model's async call contract must await the async model instance with a string prompt and assert the result is a str, rather than only testing the sync path.
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying a test for an async model's call contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5f6b26a251d38caac6ad7cf7.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise a real model backend must construct the model through the public client-plus-model-name entry point (e.g. Ollama(Client(), MODEL_NAME), AsyncOllama(AsyncClient(), MODEL_NAME), from_sglang(OpenAI(...))), and must not substitute a mock server when the test's purpose is to exercise real initialization.
  ```
- **Applies to:**
  - `tests/models/test_ollama.py`
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying a test that constructs a real model backend client
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-821d0fadab6231e29cab9657.md)

## Rule

- **Rule:** Tests that exercise a real SGLang server must select the llguidance grammar backend (--grammar-backend llguidance); the outlines backend cannot handle EBNF grammars and the xgrammar backend is slow and buggy.
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying SGLang tests that run against a live SGLang server
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b38295464265a57a00785c30.md)

## Rule

- **Rule:** Tests for structured-output backends must assert that generation with a schema/regex constraint returns a str matching the constraint, and must reject unsupported output types with TypeError.
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
  - `tests/models/test_sglang.py`
  - `tests/models/test_transformers.py`
  - `tests/models/test_vllm.py`
- **Condition:** when adding or modifying tests for a model backend's structured-output or constrained-decoding support
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d80643a228790e789ebbde9c.md)

## Rule

- **Rule:** Multimodal chat tests must pass a Chat whose user message content is a list of text and Image, and assert the result is a str.
- **Applies to:**
  - `tests/models/test_anthropic.py`
  - `tests/models/test_ollama.py`
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying multimodal chat or vision tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f71167061cfd7adbb6679105.md)
