# Constraints for `tests/models/test_vllm.py`

## Rule

- **Rule:** The sync vLLM model's n sampling parameter must return a list of exactly n string samples.
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when changing sync vLLM sampling or its n-parameter handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0a6d67ce24f5ccf7d7a5b5d2.md)

## Rule

- **Rule:**
  ```text
  `test_vllm_sync_cfg` must assert that generating with CFG(YES_NO_GRAMMAR) yields a string restricted to ["yes", "no"], verifying CFG-constrained decoding on the vLLM backend.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when changing the vLLM CFG-constrained decoding test
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1604e60297bcb27994ff5c8f.md)

## Rule

- **Rule:**
  ```text
  The vLLM async_model_no_model_name fixture constructs AsyncVLLM from the shared async_openai_client.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when modifying or extending vLLM async model fixtures or their tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-161349bbd84939da9667129e.md)

## Rule

- **Rule:** Sync vLLM regex generation must return a string matching the requested regex, mirroring the async variant.
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** When modifying sync vLLM regex generation or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2f8bac4565bf509540068ec6.md)

## Rule

- **Rule:** Tests for model backends must preserve the documented multimodal message shape: Ollama vision formatting yields a single user message with text content and an image list, and vLLM async vision chat accepts system/user-with-image/assistant messages and returns a string.
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
  - `tests/models/test_vllm.py`
- **Condition:** when adding or modifying tests for multimodal or vision message formatting in a model backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4bb667c41f71bc28b1f04207.md)

## Rule

- **Rule:**
  ```text
  The vLLM sync vision test must pass a list of a text prompt and an image_input to the model and assert a string result, documenting the multimodal input convention for vLLM.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** When adding or modifying a test for vLLM multimodal (vision) input.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-82f3fed96ccba912132267cf.md)

## Rule

- **Rule:** Tests for structured-output backends must assert that generation with a schema/regex constraint returns a str matching the constraint, and must reject unsupported output types with TypeError.
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
  - `tests/models/test_sglang.py`
  - `tests/models/test_transformers.py`
  - `tests/models/test_vllm.py`
- **Condition:** when adding or modifying tests for a model backend's structured-output or constrained-decoding support
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d80643a228790e789ebbde9c.md)

## Rule

- **Rule:** The vLLM async streaming test asserts stream() returns an AsyncGenerator and that iterating yields str chunks, breaking after the first chunk to avoid consuming the full stream.
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when modifying or extending vLLM async streaming behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d9213f43721900bc60d1674f.md)

## Rule

- **Rule:**
  ```text
  from_vllm must dispatch on client type: OpenAI yields VLLM, AsyncOpenAI yields AsyncVLLM, and any other client type raises ValueError matching "Unsupported client type".
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:**
  ```text
  When modifying from_vllm client-type dispatch or its tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f7afefba9e0cfc77703e0b17.md)
