# Constraints for `tests/models/test_dottxt.py`

## Rule

- **Rule:** Tests for the Dottxt model must assert that streaming raises NotImplementedError with the message 'Dottxt does not support streaming'.
- **Applies to:**
  - `tests/models/test_dottxt.py`
- **Condition:** When adding or modifying a test that covers the Dottxt model's streaming behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0afc8d6d6c70d4bb9d3f0da6.md)
