# Constraints for `tests/models/test_anthopic_type_adapter.py`

## Rule

- **Rule:** Tests that document a backend's unsupported feature or output type must assert the specific exception type and message fragment (e.g. NotImplementedError matching 'Streaming is not implemented', NotImplementedError matching 'is not available with Anthropic', TypeError matching 'is not available with Anthropic'), and must not silently skip or weaken the assertion.
- **Applies to:**
  - `tests/models/test_anthopic_type_adapter.py`
  - `tests/models/test_transformers.py`
- **Condition:** when adding or modifying a test that documents an unsupported backend feature or output type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-496a7be9f2efca68a86ac0df.md)

## Rule

- **Rule:**
  ```text
  Type-adapter input formatting must preserve the provider-specific message envelope: Anthropic text input becomes a single user message with the raw string as content, while OpenAI vision input becomes a user message with a text part plus an image_url part carrying a base64 data URI.
  ```
- **Applies to:**
  - `tests/models/test_anthopic_type_adapter.py`
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** When modifying or adding type-adapter input-formatting tests for text or vision inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6ec4e759c3599ff7dec6cbcb.md)

## Rule

- **Rule:**
  ```text
  The anthropic type adapter test defines an `image` fixture that builds a 1x1 white RGB PIL image, saves it as PNG in a `BytesIO` buffer, and reopens it, mirroring the image fixture convention used elsewhere in the test suite.
  ```
- **Applies to:**
  - `tests/models/test_anthopic_type_adapter.py`
- **Condition:** when modifying or extending image fixtures in type adapter tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7352c3ae75c172691a32ed5d.md)

## Rule

- **Rule:** Tests that exercise an adapter's input validation must assert the specific error type and message fragment for each invalid input category (e.g. TypeError matching 'is not available with Anthropic' for Audio, ValueError matching 'All assets provided must be of type Image' for mixed content, ValueError matching 'The content must be a string or a list' for dict content), rather than a generic exception.
- **Applies to:**
  - `tests/models/test_anthopic_type_adapter.py`
- **Condition:** when adding or modifying a test for an adapter's input validation errors
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-97017ac32672fcdd0435e7be.md)
