# Constraints for `tests/models/test_tgi.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise a real external server must gate on an environment variable (e.g. TGI_SERVER_URL) and fall back to mock clients with a warning when it is unset, registering mock responses only in the mock path.
  ```
- **Applies to:**
  - `tests/models/test_tgi.py`
- **Condition:** when adding or modifying a test that can run against a real external server or a mock
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2fe8599fdb8e388e6bda5564.md)

## Rule

- **Rule:**
  ```text
  Async model tests must await the model call and assert the result is a str; async streaming tests must treat the stream as an async generator whose first __anext__ yields a str.
  ```
- **Applies to:**
  - `tests/models/test_ollama.py`
  - `tests/models/test_tgi.py`
- **Condition:** when adding or modifying async model invocation or streaming tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5601f89974c778ab7457e731.md)

## Rule

- **Rule:** Tests for backends that intentionally do not support batch must assert NotImplementedError with a message matching 'does not support'.
- **Applies to:**
  - `tests/models/test_tgi.py`
- **Condition:** when adding or modifying a test for a backend that intentionally does not implement batch
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c7064c6cf97acc8837694719.md)
