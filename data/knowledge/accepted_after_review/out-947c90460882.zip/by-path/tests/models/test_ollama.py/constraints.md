# Constraints for `tests/models/test_ollama.py`

## Rule

- **Rule:**
  ```text
  Tests for pydantic model schema generation must define a model with an Annotated str field constrained by Field(max_length=2) to exercise length-constrained string schema generation.
  ```
- **Applies to:**
  - `tests/models/test_ollama.py`
- **Condition:** when adding or modifying tests that exercise length-constrained string schema generation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0858600d0b0d77daabc2f55d.md)

## Rule

- **Rule:** Tests that exercise image inputs must use a session-scoped fixture that creates a minimal in-memory image (e.g. 1x1 white RGB PNG) rather than loading from disk.
- **Applies to:**
  - `tests/models/test_ollama.py`
- **Condition:** When adding or modifying a fixture that provides an image input for model tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2f307f02b2088ad3174f72f8.md)

## Rule

- **Rule:** Ollama chat must accept a Chat with a system message and a user message containing text plus an Image, and return a str.
- **Applies to:**
  - `tests/models/test_ollama.py`
- **Condition:** When modifying Ollama chat handling or its tests for multimodal messages.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4a97db1a80d105adc642e139.md)

## Rule

- **Rule:**
  ```text
  Async model tests must await the model call and assert the result is a str; async streaming tests must treat the stream as an async generator whose first __anext__ yields a str.
  ```
- **Applies to:**
  - `tests/models/test_ollama.py`
  - `tests/models/test_tgi.py`
- **Condition:** when adding or modifying async model invocation or streaming tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5601f89974c778ab7457e731.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise a real model backend must construct the model through the public client-plus-model-name entry point (e.g. Ollama(Client(), MODEL_NAME), AsyncOllama(AsyncClient(), MODEL_NAME), from_sglang(OpenAI(...))), and must not substitute a mock server when the test's purpose is to exercise real initialization.
  ```
- **Applies to:**
  - `tests/models/test_ollama.py`
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying a test that constructs a real model backend client
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-821d0fadab6231e29cab9657.md)

## Rule

- **Rule:** The Ollama model's stream method must return a generator whose first yielded item is a str.
- **Applies to:**
  - `tests/models/test_ollama.py`
- **Condition:** when changing the Ollama model's stream method or its yielded item types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a44c653fb75d49a984812862.md)

## Rule

- **Rule:** The ollama test must define a local Foo(Enum) with members bar = 'Bar' and foor = 'Foo' as a sample enum output type.
- **Applies to:**
  - `tests/models/test_ollama.py`
- **Condition:** When adding or modifying a test that needs a sample enum output type for the ollama backend.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-acb9b46364fe3837f041a31a.md)

## Rule

- **Rule:** Tests for the async Ollama model must await the coroutine returned by generate(...) and assert the awaited result is a str, reflecting that the async API returns a plain string rather than a parsed object.
- **Applies to:**
  - `tests/models/test_ollama.py`
- **Condition:** When adding or modifying a test that calls the async Ollama model's generate method.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bc1c2abb759731e7e6f8e994.md)

## Rule

- **Rule:** Tests that exercise model backends must assert the documented error contract for unsupported inputs: vLLM offline streaming raises NotImplementedError, Ollama rejects non-message dict inputs with TypeError and mixed asset lists with ValueError, and Anthropic rejects unsupported inference keyword arguments with TypeError.
- **Applies to:**
  - `tests/models/test_anthropic.py`
  - `tests/models/test_ollama.py`
  - `tests/models/test_vllm_offline.py`
- **Condition:** when adding or modifying tests for a model backend's rejection of unsupported inputs or parameters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d2b5de3e3f0d15f4bd57bbb9.md)

## Rule

- **Rule:** Multimodal chat tests must pass a Chat whose user message content is a list of text and Image, and assert the result is a str.
- **Applies to:**
  - `tests/models/test_anthropic.py`
  - `tests/models/test_ollama.py`
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying multimodal chat or vision tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f71167061cfd7adbb6679105.md)
