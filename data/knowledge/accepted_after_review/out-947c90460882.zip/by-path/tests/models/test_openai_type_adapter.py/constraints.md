# Constraints for `tests/models/test_openai_type_adapter.py`

## Rule

- **Rule:**
  ```text
  Tests for the OpenAI type adapter's JSON schema formatting must assert that the produced dict sets response_format.json_schema.strict to True and preserves the schema.
  ```
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** When adding or modifying a test for the OpenAI type adapter's JSON schema string formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0839aa3a21b11db8482bca5c.md)

## Rule

- **Rule:**
  ```text
  Type-adapter input formatting must preserve the provider-specific message envelope: Anthropic text input becomes a single user message with the raw string as content, while OpenAI vision input becomes a user message with a text part plus an image_url part carrying a base64 data URI.
  ```
- **Applies to:**
  - `tests/models/test_anthopic_type_adapter.py`
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** When modifying or adding type-adapter input-formatting tests for text or vision inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6ec4e759c3599ff7dec6cbcb.md)

## Rule

- **Rule:**
  ```text
  Tests for type adapters must preserve the documented structured-output contract: OpenAI dataclass output formatting yields a response_format with json_schema.strict True and the expected schema, and the dottxt adapter imports TypedDict from typing on Python 3.12+ and typing_extensions otherwise.
  ```
- **Applies to:**
  - `tests/models/test_dottxt_type_adapter.py`
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when adding or modifying tests for type adapter structured-output formatting or version-dependent typing imports
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7cb30b2869da2fd6dedd5e7a.md)

## Rule

- **Rule:** Tests for the OpenAI type adapter must define a minimal pydantic model with a single str field to exercise adapter assertions.
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when adding or modifying tests for the OpenAI type adapter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8317af84794d07e831a7e7c9.md)

## Rule

- **Rule:** OpenAI type adapter must convert Genson SchemaBuilder schemas into strict JSON schemas with additionalProperties false and union types for mixed values.
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when changing Genson SchemaBuilder schema conversion in the OpenAI type adapter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-87d7e21c2007a65ae7d246c5.md)

## Rule

- **Rule:** The OpenAI type adapter test module must define a nested dataclass Audio with a file string field to cover dataclass-based schema handling.
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when adding or modifying dataclass-based schema coverage in OpenAI type adapter tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a113e22b337b4dc746be61bf.md)

## Rule

- **Rule:**
  ```text
  The OpenAI adapter must reject str, int, Literal[1, 2], list[Foo], regex, and CFG output types with specific TypeError messages, documenting the set of unsupported output types for the OpenAI backend.
  ```
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when changing OpenAI type adapter output-type validation or its unsupported-type error messages
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bcbe5961c7cd8886891c70b0.md)

## Rule

- **Rule:**
  ```text
  OpenAI type adapter JSON mode must map dict output types to the request payload {"response_format": {"type": "json_object"}}.
  ```
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when changing how the OpenAI type adapter maps output types to request payloads
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c3e51ef54833f0f2e73d45d9.md)
