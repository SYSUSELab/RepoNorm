# Constraints for `tests/models/test_openai.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise a model backend's structured-output generation must be marked with the `api_call` pytest marker so they can be selected or deselected as network-dependent tests.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** When adding or modifying a test that calls a live model backend to generate structured output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4136c7716d332e799f12c1f9.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise live provider APIs must be marked with @pytest.mark.api_call so they can be deselected in offline CI runs.
  ```
- **Applies to:**
  - `tests/models/test_anthropic.py`
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying a test that performs a live provider API call
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44b46315f7751e2813983731.md)

## Rule

- **Rule:**
  ```text
  Tests for model backends must preserve the documented multi-sample generation contract: OpenAI generate with n=2 returns a list of length 2 containing two strings, and such tests must carry the api_call marker.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying tests for multi-sample generation in a model backend
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4987ba5f682984de0d82bcb5.md)

## Rule

- **Rule:** Tests that exercise multimodal chat input must construct a Chat with a system message and a user message containing text plus an Image, and assert the model returns a str, rather than testing text-only chat.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying a test for multimodal chat input
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5c88fe5bcf58ee31eddd9ea5.md)

## Rule

- **Rule:** Tests for model backends must assert that unsupported output types raise TypeError with a message matching 'is not available', and that mixed asset lists raise ValueError with a message matching 'All assets provided must be of type Image'.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying tests for backend rejection of unsupported output types or invalid asset lists
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7a040a4311d63850904f3f17.md)

## Rule

- **Rule:** Tests that exercise a model backend's unsupported-output-type or unsupported-schema failure path must assert the specific TypeError message the backend raises (e.g. 'OpenAI does not support your schema', Gemini's unsupported-type TypeErrors), not merely that some error occurred.
- **Applies to:**
  - `tests/models/test_gemini_type_adapter.py`
  - `tests/models/test_openai.py`
- **Condition:** When adding or modifying a test that covers a model backend rejecting an unsupported output type or schema.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9879579a6bd57b40fecc486c.md)

## Rule

- **Rule:** Tests for streaming model APIs must assert that model.stream returns a Generator whose first yielded item is a str.
- **Applies to:**
  - `tests/models/test_gemini.py`
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying a test for a model's streaming API
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a020aa25fe523ced22dca25c.md)

## Rule

- **Rule:** Tests that exercise a model backend requiring an API key must use a session-scoped fixture that constructs the client once and shares it across the session.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** When adding or modifying a model fixture for a backend that requires an API key.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c02c37d9a9aa9c8163f15f2b.md)

## Rule

- **Rule:** Tests for the OpenAI model's Pydantic schema refusal path must assert that generation raises TypeError matching 'OpenAI does not support your schema'.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** When adding or modifying a test that covers the OpenAI model rejecting a Pydantic schema that triggers refusal.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e8c88688877c5ca882ede146.md)

## Rule

- **Rule:** OpenAI simple pydantic generation must return a string whose JSON parse contains the model's field name, verifying structured output for pydantic types.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when changing OpenAI pydantic structured-output handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ff0a2747724292588d3ce367.md)
