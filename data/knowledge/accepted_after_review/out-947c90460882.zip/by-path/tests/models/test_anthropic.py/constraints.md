# Constraints for `tests/models/test_anthropic.py`

## Rule

- **Rule:**
  ```text
  Tests for model backends must preserve the documented client initialization contract: from_anthropic accepts an optional model name that sets model.model_name when provided and leaves it None when omitted, while model.client is always the passed client.
  ```
- **Applies to:**
  - `tests/models/test_anthropic.py`
- **Condition:** when adding or modifying tests for model backend client initialization
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-32f515af4f3c04ffb246d16b.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise live provider APIs must be marked with @pytest.mark.api_call so they can be deselected in offline CI runs.
  ```
- **Applies to:**
  - `tests/models/test_anthropic.py`
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying a test that performs a live provider API call
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44b46315f7751e2813983731.md)

## Rule

- **Rule:** The Anthropic wrong-output-type test asserts that model.generate with a Foo(1) output type raises NotImplementedError matching 'is not available', documenting rejection of unsupported output types.
- **Applies to:**
  - `tests/models/test_anthropic.py`
- **Condition:** when modifying or extending Anthropic model.generate output type handling or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b890b378ffd1c2e81f8eace3.md)

## Rule

- **Rule:** Tests that exercise model backends must assert the documented error contract for unsupported inputs: vLLM offline streaming raises NotImplementedError, Ollama rejects non-message dict inputs with TypeError and mixed asset lists with ValueError, and Anthropic rejects unsupported inference keyword arguments with TypeError.
- **Applies to:**
  - `tests/models/test_anthropic.py`
  - `tests/models/test_ollama.py`
  - `tests/models/test_vllm_offline.py`
- **Condition:** when adding or modifying tests for a model backend's rejection of unsupported inputs or parameters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d2b5de3e3f0d15f4bd57bbb9.md)

## Rule

- **Rule:** Multimodal chat tests must pass a Chat whose user message content is a list of text and Image, and assert the result is a str.
- **Applies to:**
  - `tests/models/test_anthropic.py`
  - `tests/models/test_ollama.py`
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying multimodal chat or vision tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f71167061cfd7adbb6679105.md)
