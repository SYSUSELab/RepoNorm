# Constraints for `tests/models/test_transformers_tokenizer.py`

## Rule

- **Rule:**
  ```text
  Tests for tokenizer token-to-string conversion must cover the llama-specific byte-token handling (e.g. '<0x20>' converting to a space) in addition to regular token conversion.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:**
  ```text
  When adding or modifying tokenizer convert_token_to_string tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0d86ec6fd8c908ec8d0515cc.md)

## Rule

- **Rule:**
  ```text
  Tests for the transformer tokenizer must assert that __getstate__ includes a 'tokenizer' key and that __setstate__ restores an instance equal to the original, preserving the pickling round-trip contract.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** When adding or modifying a test that covers transformer tokenizer pickling or state serialization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7f1bd79441eb75c8dc63cf72.md)

## Rule

- **Rule:** Tests for tokenizer wrappers must assert hash/equality semantics: hash returns an int, equivalent tokenizers hash equal, and tokenizers with different configurations hash differently.
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** when adding or modifying tests for tokenizer wrapper hash or equality behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-90ee256ccbc1f923cdaf85e9.md)

## Rule

- **Rule:**
  ```text
  get_llama_tokenizer_types must return LlamaTokenizer, LlamaTokenizerFast, CodeLlamaTokenizer, CodeLlamaTokenizerFast in that exact order.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** when adding or modifying tokenizer type list tests or implementation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a753a7b38c146e8331afd0cf.md)

## Rule

- **Rule:**
  ```text
  The Transformers tokenizer fixture must load AutoTokenizer.from_pretrained(TEST_MODEL), establishing a reusable tokenizer fixture pattern.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** When adding or modifying the tokenizer fixture used by Transformers tokenizer tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d2a4553a8ffb7bd7f35c3810.md)
