# Constraints for `tests/models/test_gemini.py`

## Rule

- **Rule:** Tests that document a known backend compatibility limitation must mark the test with xfail and a reason string explaining the limitation, rather than deleting the test or asserting success.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying a test that documents a known backend SDK compatibility limitation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-15f6433d63412f48b91f6e33.md)

## Rule

- **Rule:** Tests for vision structured output must pass a prompt plus an Image and a pydantic type, asserting the result is a string whose parsed JSON contains the expected field.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying a test for vision structured output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1fec31e1e2783d2ec23b96d1.md)

## Rule

- **Rule:** Tests for the Gemini model's choice generation must assert that generating with a Literal type returns a string equal to one of the allowed choices.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** When adding or modifying a test for the Gemini model's choice or Literal generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-38a292213a5b3a02b4bf244d.md)

## Rule

- **Rule:** Tests that exercise model generation through a constrained output type must assert the returned value is a member of the declared constraint set, not merely that generation succeeds.
- **Applies to:**
  - `tests/models/test_gemini.py`
  - `tests/models/test_transformers.py`
  - `tests/models/test_vllm_offline.py`
- **Condition:** When adding or modifying a test that calls model.generate with a constrained output type (choice/enum or multiple sampled sequences).
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5d3a711ed85bd49c58a7d3b0.md)

## Rule

- **Rule:** The Gemini backend must reject mixed asset lists containing non-Image assets with a ValueError stating 'All assets provided must be of type Image', so multimodal inputs must be homogeneous.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** When adding or modifying a test for Gemini multimodal input validation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-66f70b5c2f3e6cc333bc3949.md)

## Rule

- **Rule:** Tests for dataclass-typed generation must assert that model.generate returns a str whose JSON content contains the expected field.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying tests for dataclass-typed generation output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6beaf1eb3722dd8a0c09714c.md)

## Rule

- **Rule:** Tests for streaming model APIs must assert that model.stream returns a Generator whose first yielded item is a str.
- **Applies to:**
  - `tests/models/test_gemini.py`
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying a test for a model's streaming API
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a020aa25fe523ced22dca25c.md)

## Rule

- **Rule:**
  ```text
  The Gemini init-from-client test asserts that outlines.from_gemini with a client and no model name yields a Gemini with model_name None, while passing MODEL_NAME sets model_name accordingly, documenting optional model-name behavior.
  ```
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when modifying or extending Gemini initialization from client or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c22e17743ede01d605d5b4c9.md)

## Rule

- **Rule:** Tests for choice-constrained generation must assert that generating with a list of choices returns a string equal to one of the choice values, and that list choices are intentionally unsupported (xfail) where semantically incorrect.
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying tests for choice-constrained generation with list choices
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ca456058eb760cdef88a2022.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Gemini list-of-pydantic generation must be marked @pytest.mark.api_call and assert the returned JSON list's first element is a dict containing the expected key.
  ```
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** When adding or modifying Gemini tests that exercise list-of-pydantic generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e2d46cc495155d08345577c1.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise a backend's choice-constrained generation must be marked with @pytest.mark.api_call and assert the returned value is one of the provided choices.
  ```
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** when adding or modifying tests that make real API calls for choice-constrained generation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f6055ca30dfb0cb44d987854.md)

## Rule

- **Rule:**
  ```text
  Gemini typed-dict generation tests must be marked @pytest.mark.api_call and assert that model.generate("foo?", Foo) returns a str whose json.loads result contains the key "bar".
  ```
- **Applies to:**
  - `tests/models/test_gemini.py`
- **Condition:** When adding or modifying Gemini typed-dict generation tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fcb47b81632f6f41df23cc46.md)
