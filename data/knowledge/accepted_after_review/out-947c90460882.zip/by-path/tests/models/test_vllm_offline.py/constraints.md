# Constraints for `tests/models/test_vllm_offline.py`

## Rule

- **Rule:**
  ```text
  vLLM offline batch tests must assert that sampling_params n=2 returns a list of two lists, and that batching Chat inputs raises TypeError with 'Batch generation is not available'.
  ```
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** when adding or modifying vLLM offline batch tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-50450246a2a274fbd98426be.md)

## Rule

- **Rule:** Tests that exercise model generation through a constrained output type must assert the returned value is a member of the declared constraint set, not merely that generation succeeds.
- **Applies to:**
  - `tests/models/test_gemini.py`
  - `tests/models/test_transformers.py`
  - `tests/models/test_vllm_offline.py`
- **Condition:** When adding or modifying a test that calls model.generate with a constrained output type (choice/enum or multiple sampled sequences).
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5d3a711ed85bd49c58a7d3b0.md)

## Rule

- **Rule:** Tests that exercise the offline vLLM model's generate must assert the return type (plain string for a simple prompt) as the basic generation contract.
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** When adding or modifying tests for the offline vLLM model's generate method.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9f65684e0b8aeea88b00e0b3.md)

## Rule

- **Rule:** Passing an unknown inference keyword to the vLLM model must raise TypeError, enforcing strict inference-kwarg validation.
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** when changing vLLM model inference-kwarg handling or adding new accepted keywords
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a5583452c1b48705dcbf0585.md)

## Rule

- **Rule:** Tests that exercise model backends must assert the documented error contract for unsupported inputs: vLLM offline streaming raises NotImplementedError, Ollama rejects non-message dict inputs with TypeError and mixed asset lists with ValueError, and Anthropic rejects unsupported inference keyword arguments with TypeError.
- **Applies to:**
  - `tests/models/test_anthropic.py`
  - `tests/models/test_ollama.py`
  - `tests/models/test_vllm_offline.py`
- **Condition:** when adding or modifying tests for a model backend's rejection of unsupported inputs or parameters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d2b5de3e3f0d15f4bd57bbb9.md)
