# Constraints for `tests/models/test_transformers.py`

## Rule

- **Rule:**
  ```text
  Tests that verify a model wrapper's tensor backend must assert the concrete adapter types and tensor_library_name (e.g. 'jax' for Flax models).
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:**
  ```text
  When adding or modifying tests that instantiate a model via from_transformers and verify its backend.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-35e8dc270733195de6a8c541.md)

## Rule

- **Rule:** Tests that document a backend's unsupported feature or output type must assert the specific exception type and message fragment (e.g. NotImplementedError matching 'Streaming is not implemented', NotImplementedError matching 'is not available with Anthropic', TypeError matching 'is not available with Anthropic'), and must not silently skip or weaken the assertion.
- **Applies to:**
  - `tests/models/test_anthopic_type_adapter.py`
  - `tests/models/test_transformers.py`
- **Condition:** when adding or modifying a test that documents an unsupported backend feature or output type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-496a7be9f2efca68a86ac0df.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the type adapter's tokenizer for chat-template setup must assign the chat_template on model.type_adapter.tokenizer, relying on the adapter exposing the tokenizer.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** When adding or modifying a model fixture that configures a chat template for a Transformers model.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5104bc9d57c5e87a219ce584.md)

## Rule

- **Rule:** Tests for model instantiation must assert that invalid output types (e.g. plain Python types like int) raise ValueError at instantiation time.
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when adding or modifying tests for model instantiation with invalid output types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5ca6f58ddf9285485ce8a9b2.md)

## Rule

- **Rule:** Tests that exercise model generation through a constrained output type must assert the returned value is a member of the declared constraint set, not merely that generation succeeds.
- **Applies to:**
  - `tests/models/test_gemini.py`
  - `tests/models/test_transformers.py`
  - `tests/models/test_vllm_offline.py`
- **Condition:** When adding or modifying a test that calls model.generate with a constrained output type (choice/enum or multiple sampled sequences).
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5d3a711ed85bd49c58a7d3b0.md)

## Rule

- **Rule:**
  ```text
  The Transformers model_bart fixture must build a model via outlines.from_transformers using a BartForConditionalGeneration and its matching BartTokenizer loaded from TEST_MODEL_BART.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** When adding or modifying the BART model fixture used by Transformers backend tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-60c247cf2f95f12db4e46b00.md)

## Rule

- **Rule:**
  ```text
  Tests for batch generation must assert that TransformersModel.batch returns a flat list of one string per prompt when num_return_sequences is 1, and a list of lists when num_return_sequences is greater than 1.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:**
  ```text
  when adding or modifying a test for batch generation with varying num_return_sequences
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-969f99ddfff159b6f191e600.md)

## Rule

- **Rule:**
  ```text
  The transformers multiple-samples test must assert that a single call returns a string, while passing num_return_sequences=2 with do_sample=True returns a list of length 2, documenting the sampling-dependent return shape.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when changing the transformers multiple-samples test or its sampling-dependent return-shape assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b1987e14e4cc90a8a466a3ba.md)

## Rule

- **Rule:** Tests for structured-output backends must assert that generation with a schema/regex constraint returns a str matching the constraint, and must reject unsupported output types with TypeError.
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
  - `tests/models/test_sglang.py`
  - `tests/models/test_transformers.py`
  - `tests/models/test_vllm.py`
- **Condition:** when adding or modifying tests for a model backend's structured-output or constrained-decoding support
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d80643a228790e789ebbde9c.md)
