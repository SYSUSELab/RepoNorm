# Constraints for `tests/models/test_llamacpp_type_adapter.py`

## Rule

- **Rule:** LlamaCpp type adapter tests instantiate LlamaCppTypeAdapter directly as the adapter fixture, indicating the adapter is usable without a model instance.
- **Applies to:**
  - `tests/models/test_llamacpp_type_adapter.py`
- **Condition:** when modifying or extending LlamaCpp type adapter fixtures or their tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aea0bf53e3571629aaa4a0c8.md)

## Rule

- **Rule:**
  ```text
  The LlamaCpp type adapter's format_input must accept strings unchanged and convert Chat messages to their message list, but must raise NotImplementedError for non-string/non-Chat inputs and ValueError with the message "LlamaCpp does not support multi-modal messages." for multi-modal Chat content.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_type_adapter.py`
- **Condition:**
  ```text
  when modifying or extending LlamaCpp type adapter format_input or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c883a9f3097216b8b7b1bebb.md)
