# Constraints for `tests/test_applications.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise the public Application protocol must preserve the callable contract: Application is constructed with (template, output_type) and invoked as application(model, input_dict, **inference_kwargs), with extra inference kwargs forwarded to the model.
  ```
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:** When modifying or adding tests around Application construction and invocation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b3b0b1681598f07b0a7a65b.md)

## Rule

- **Rule:**
  ```text
  Application initialization tests must assert that a newly constructed Application stores the given template and output_type but leaves model and generator as None, documenting the expected unbound state before a model is attached.
  ```
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:** When modifying or adding tests for Application initialization state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-be8cdfc13faddf7a857cb9a9.md)

## Rule

- **Rule:** Tests for application template rendering must assert that a missing variable raises jinja2.exceptions.UndefinedError, confirming StrictUndefined behavior.
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:**
  ```text
  When adding or modifying application template rendering tests in tests/test_applications.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bec728c6ee324c7a08a01a1c.md)

## Rule

- **Rule:**
  ```text
  Calling the same `Application` with the same model must preserve `application.model` and `application.generator` across calls, but calling with another model must update both to the new model's values.
  ```
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:**
  ```text
  When modifying `Application` model/generator caching or reuse logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ecae3465a6bc61d1c19b8f9a.md)
