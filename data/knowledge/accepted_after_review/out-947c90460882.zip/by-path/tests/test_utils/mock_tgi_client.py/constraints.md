# Constraints for `tests/test_utils/mock_tgi_client.py`

## Rule

- **Rule:**
  ```text
  Mock TGI client _create must hash kwargs into a request key, raise ValueError when no mock response is registered, and return an iterator when stream=True.
  ```
- **Applies to:**
  - `tests/test_utils/mock_tgi_client.py`
- **Condition:** when adding or modifying the mock TGI client's request/response matching behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-69b2bae9b5cb6d5fff16a810.md)

## Rule

- **Rule:**
  ```text
  Tests for backend utilities must preserve the documented mock response matching: the mock TGI client keys stored mock responses by hash_dict(kwargs) so request matching depends on deterministic hashing of the kwargs dict rather than object identity.
  ```
- **Applies to:**
  - `tests/test_utils/mock_tgi_client.py`
- **Condition:** when adding or modifying mock response storage or request matching in backend test utilities
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-70750349062afad7e97b81b5.md)

## Rule

- **Rule:**
  ```text
  The mock TGI client's add_mock_responses must key canned responses by hash_dict(kwargs) of the request kwargs so mock responses are matched by hashed request arguments.
  ```
- **Applies to:**
  - `tests/test_utils/mock_tgi_client.py`
- **Condition:** When adding or modifying the mock TGI client's response registration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9c3027fafd6be63e997d7462.md)

## Rule

- **Rule:**
  ```text
  Tests for the mock TGI client must configure text_generation as a MagicMock with a side_effect callable and store canned responses in a _mock_responses dict, establishing the mock's request/response protocol.
  ```
- **Applies to:**
  - `tests/test_utils/mock_tgi_client.py`
- **Condition:** When adding or modifying the mock TGI client used by TGI tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fbd3f7744a06ca45776d7b1e.md)
