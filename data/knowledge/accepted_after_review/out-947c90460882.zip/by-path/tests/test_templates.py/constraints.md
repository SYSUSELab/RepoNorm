# Constraints for `tests/test_templates.py`

## Rule

- **Rule:**
  ```text
  `Template.from_file` must support `extends`, `include`, and `block` composition so that a prompt extending a base template and including an examples partial renders the expected multi-line Q/A text.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When modifying template file loading or the extends/include/block composition logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3c341e9c08c5360d378d7635.md)

## Rule

- **Rule:**
  ```text
  `get_schema` must raise `NotImplementedError` for unsupported input types (e.g., int), return a pretty-printed JSON string for a dict schema, and return a JSON string for a Pydantic class schema.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When modifying `get_schema` or the schema extraction path used by template rendering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-745f7eb5bec6cefdf53ca467.md)

## Rule

- **Rule:**
  ```text
  Template tests must define custom_filter as a plain callable taking a string and returning its uppercase form, establishing that custom filters are plain callables.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When modifying or adding template tests that define custom filters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7ae3b9c256b5d2c6019efbdd.md)

## Rule

- **Rule:**
  ```text
  `get_fn_name` must raise `TypeError` for non-callable input, return the function's `__name__` for named functions, return `"<lambda>"` for lambdas, and return the class name for callable class instances.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When modifying `get_fn_name` or the function-name resolution used by template rendering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-838355b3d2594525d84315f2.md)

## Rule

- **Rule:**
  ```text
  Tests for Vision image validation must assert that an image without a format raises TypeError matching 'Could not read the format', and the call must be wrapped in pytest.deprecated_call to exercise the deprecation path.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When adding or modifying Vision image format validation tests in tests/test_templates.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-928495ad8e89351a1bd65479.md)

## Rule

- **Rule:**
  ```text
  Vision initialization must emit a deprecation warning and produce a two-element list with prompt and encoded Image, including base64 image_str and image/png format.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When modifying or adding vision initialization tests that assert deprecation warning and encoded image output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-94b07d1492bab5cc0678e389.md)

## Rule

- **Rule:** Template rendering must support Jinja2 loops and conditionals, and whitespace control with '-%}' must trim the trailing newline while conditionals render only their body when true.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When modifying or adding template-rendering test cases that exercise Jinja2 control structures or whitespace-control syntax.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-95468af4949cad5ebf4aa962.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the public template signature helpers must preserve the error and formatting contract: get_fn_args and get_fn_signature raise TypeError for non-callables, and return parameter strings including defaults and annotations such as 'x, y=2' and 'x: int, y: str'.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When modifying or adding tests around get_fn_args or get_fn_signature.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9b0ab94caf8377f926153cf4.md)

## Rule

- **Rule:**
  ```text
  Tests for get_fn_description and get_fn_source must assert that non-callable inputs raise TypeError, and that callables return the docstring text (empty string when absent) or the exact source text including the docstring.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When adding or modifying tests for get_fn_description or get_fn_source in tests/test_templates.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ad5338a385b613d85674abe6.md)

## Rule

- **Rule:** Template rendering must strip leading and trailing blank lines, dedent common indentation while preserving relative indentation of nested lines, and preserve a trailing newline when the template ends with a blank line.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When modifying or adding template-rendering test cases that assert on rendered output whitespace.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c7432b6e0f579bf326779cb5.md)

## Rule

- **Rule:** Template rendering must collapse backslash-escaped line continuations into single spaces while preserving indentation on subsequent lines.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When modifying or adding template-rendering test cases that exercise backslash-escaped line continuations.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e0779ee6a2fb0b47b1f04910.md)

## Rule

- **Rule:**
  ```text
  `build_template_from_string` must strip trailing blank lines from the template body so that a template with extra linebreaks after content renders without preserving those extra newlines.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When modifying template string parsing or the `build_template_from_string` helper.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f27c47ebfb15470d81e572df.md)

## Rule

- **Rule:**
  ```text
  Template rendering filters must preserve their documented output contracts: the `source` filter returns the exact function source text, the `schema` filter returns pretty-printed JSON, and `name`, `description`, `signature`, and `args` return the corresponding function metadata; custom filters registered on the template environment must also be applied.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When modifying or extending the template filter set or the `render`/filter dispatch logic exercised by template tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f31b989e82bd6ac3dc028ed5.md)
