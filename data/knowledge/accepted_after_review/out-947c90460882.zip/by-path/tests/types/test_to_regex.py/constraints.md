# Constraints for `tests/types/test_to_regex.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise regex conversion must verify that alternation within a Sequence is grouped (e.g. Regex('dog|cat') followed by String('fish') produces '(dog|cat)fish'), rather than emitting ungrouped alternation.
  ```
- **Applies to:**
  - `tests/types/test_to_regex.py`
- **Condition:** when adding or modifying a test for regex conversion of sequences containing alternation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1fb9db35419954883415420a.md)

## Rule

- **Rule:**
  ```text
  to_regex must produce the exact regex string for each DSL term (String, Regex, JsonSchema, Choice, Optional, KleeneStar, KleenePlus, QuantifyExact/Minimum/Maximum/Between), matches() must behave accordingly, and a bare Term must raise TypeError with 'Cannot convert'.
  ```
- **Applies to:**
  - `tests/types/test_to_regex.py`
- **Condition:**
  ```text
  When modifying to_regex DSL term handling or its tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c896b28bc7b2a16b7085c0d7.md)
