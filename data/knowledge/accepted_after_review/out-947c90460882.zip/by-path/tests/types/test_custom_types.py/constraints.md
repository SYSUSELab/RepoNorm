# Constraints for `tests/types/test_custom_types.py`

## Rule

- **Rule:**
  ```text
  Tests for custom type regex generation must assert that the Pydantic JSON-schema pattern and to_regex(custom_type) produce fullmatch results agreeing with the expected should_match flag for each custom type.
  ```
- **Applies to:**
  - `tests/types/test_custom_types.py`
- **Condition:** When adding or modifying a test for a custom type's regex or JSON-schema pattern generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3a27d0aa6282ab603a844885.md)
