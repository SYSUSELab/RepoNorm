# Constraints for `tests/types/test_types_utils.py`

## Rule

- **Rule:**
  ```text
  `is_typing_dict` must return True for parameterized typing dicts such as dict[str, int] and Dict[int, str], but False for the bare dict type and for a plain dict instance.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when changing is_typing_dict classification of parameterized versus bare dict types
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3abf7beef4836c0ebc831291.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the is_bool type utility must assert recognition of bool, Annotated[bool,...], and NewType over bool, while rejecting int, bool instances, Annotated[int,...], and NewType over int.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for the is_bool type utility.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-539b373ccd5c81ba5cf17164.md)

## Rule

- **Rule:**
  ```text
  `is_callable` must return True for functions and lambdas but False for `dict`, classes, dataclasses, TypedDicts, and pydantic models, defining the callable-detection boundary used by type dispatch.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when modifying or extending is_callable type classification or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-648c421af81b729bee026cd2.md)

## Rule

- **Rule:**
  ```text
  is_datetime must return true only for datetime.datetime, and false for datetime.date, datetime.time, and a datetime instance, defining the exact type-classification boundary.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when modifying or extending is_datetime type classification or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6932079f93de062c96c3d82c.md)

## Rule

- **Rule:**
  ```text
  is_dataclass must return true only for a dataclass type, and false for a dataclass instance, dict, plain class, TypedDict, and Pydantic model.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  When modifying is_dataclass or its tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8ed4b1d02b769a4023fcd302.md)

## Rule

- **Rule:**
  ```text
  The get_enum_from_choice utility must build an enum from a Choice mixing strings and an enum member, preserving member values and exposing the enum member under a SampleEnum.A attribute name.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  When adding or modifying a test for get_enum_from_choice conversion behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a928f37c3417d93cebad9535.md)

## Rule

- **Rule:**
  ```text
  is_union must return True for Union[int, str] and Optional[int], and False for list, a list literal, and Literal[int, str].
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when adding or modifying is_union predicate tests or implementation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b4c99c7ad0f096fa1af9acba.md)

## Rule

- **Rule:**
  ```text
  The get_schema_from_signature utility must produce a schema with type 'object' and properties ordered ['foo', 'bar'] where foo is string and bar is an array of integer, and must raise ValueError for a function missing type annotations.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  When adding or modifying a test for get_schema_from_signature conversion behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c884a0fba4047603d956d7b7.md)

## Rule

- **Rule:**
  ```text
  Tests for type utilities must preserve the documented predicate behavior: is_typing_tuple returns true for tuple[int, str] and Tuple[int, str] and false for bare tuple, empty tuple literal, and list, and fixtures must include callables lacking type annotations.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:** when adding or modifying tests for type utility predicates or their fixtures
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ed301faa013033bc971cc118.md)

## Rule

- **Rule:**
  ```text
  is_pydantic_model must return true only for a Pydantic model class, and false for a Pydantic model instance, dict, plain class, dataclass, and TypedDict.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  When modifying is_pydantic_model or its tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fdf4a1ee658861777b648e08.md)
