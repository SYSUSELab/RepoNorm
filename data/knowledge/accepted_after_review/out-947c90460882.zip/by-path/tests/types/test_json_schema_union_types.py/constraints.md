# Constraints for `tests/types/test_json_schema_union_types.py`

## Rule

- **Rule:**
  ```text
  preprocess_schema_for_union_types must convert an array item with type ["string", "number", "null"] into an anyOf list of three single-type schemas, preserving each type as a separate entry.
  ```
- **Applies to:**
  - `tests/types/test_json_schema_union_types.py`
- **Condition:** When modifying union-type schema preprocessing or its tests for array items with multiple types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4f73b4554a6230040403b049.md)

## Rule

- **Rule:** Tests for JSON schema union types must assert that a type array with constraints becomes anyOf with constraints attached only to the matching branch.
- **Applies to:**
  - `tests/types/test_json_schema_union_types.py`
- **Condition:** When adding or modifying a test for JSON schema generation from union types with constraints.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9402aa215648fc5393d1aff4.md)

## Rule

- **Rule:**
  ```text
  `preprocess_schema_for_union_types` must convert type arrays into anyOf at every nesting level, including inside array items and nested object properties, and preserve the number of union members as anyOf length.
  ```
- **Applies to:**
  - `tests/types/test_json_schema_union_types.py`
- **Condition:**
  ```text
  when changing preprocess_schema_for_union_types handling of nested type arrays
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a1675ff493fd07c772330b34.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise schema preprocessing must verify that the ensure_ascii parameter controls whether non-ASCII characters are escaped (e.g. 'café' becomes 'caf\u00e9' when True and stays literal when False), rather than only testing the default.
  ```
- **Applies to:**
  - `tests/types/test_json_schema_union_types.py`
- **Condition:**
  ```text
  when adding or modifying a test for schema preprocessing with the ensure_ascii option
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a2be752e543cc9e6e836e4a5.md)

## Rule

- **Rule:** The TestJsonSchemaUnionTypes class must group test cases for JSON schemas with union types, treating union-type schema handling as a distinct tested concern.
- **Applies to:**
  - `tests/types/test_json_schema_union_types.py`
- **Condition:** When adding or modifying tests for JSON schema union-type handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b7f2a2b27e480e96fbedb873.md)
