# Constraints for `tests`

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files and directories: outlines/_version.py, outlines/models/anthropic.py, outlines/models/dottxt.py, outlines/models/gemini.py, outlines/models/mlxlm.py, outlines/models/openai.py, outlines/models/vllm_offline.py, outlines/processors/tensor_adapters/mlx.py, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a3d4630cf0aebda7015f40de.md)

## Rule

- **Rule:**
  ```text
  Tests are run with uv run pytest -x --cov=outlines -m 'api_call' --ignore=tests/models/test_dottxt.py.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-af0c4a33f75299f4c58992ca.md)

## Rule

- **Rule:**
  ```text
  Pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-dc0a48620c39e0c0691d12bd.md)
