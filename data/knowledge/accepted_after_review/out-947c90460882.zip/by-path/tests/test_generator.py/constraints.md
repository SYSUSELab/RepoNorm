# Constraints for `tests/test_generator.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise the public Generator construction path must keep the model-required contract: constructing Generator(None, output_type) raises ValueError, and constructing Generator with a black-box async model plus a processor raises NotImplementedError on the synchronous path.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding tests around Generator construction, including the no-model and async-black-box-with-processor cases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-00c08b5d36ad9e5e3745dd1e.md)

## Rule

- **Rule:**
  ```text
  SteerableGenerator initialization with a CFG output type must store the model and install an OutlinesLogitsProcessor as its logits_processor.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding generator tests that assert processor installation for CFG-constrained steerable generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-04428eaf87edbd583497aa02.md)

## Rule

- **Rule:**
  ```text
  AsyncBlackBoxGenerator must store the provided model and output_type directly, so its output_type attribute equals the Literal type passed at construction.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding tests for AsyncBlackBoxGenerator construction and attribute storage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-14a930bea72848fb29414859.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the public async black-box generator selection must preserve the output-type contract: Generator(black_box_async_model, Literal[...]) is an AsyncBlackBoxGenerator with .model set to the model and .output_type set to the Literal.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding tests around async black-box generator selection.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-28d1e20244414dec1f11c906.md)

## Rule

- **Rule:**
  ```text
  Tests for BlackBoxGenerator streaming must assert that stream returns a TypingGenerator whose next value is a str, and that awaiting AsyncBlackBoxGenerator with a string output type and max_tokens=10 returns a str.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:**
  ```text
  When adding or modifying BlackBoxGenerator streaming or async call tests in tests/test_generator.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3a658e537c2eae3d2fd20c6d.md)

## Rule

- **Rule:**
  ```text
  The generator test module must build MockAsyncOpenAIClient/MockOpenAIClient from tests.test_utils.mock_openai_client and register paired mock responses (non-streaming and streaming with stream: True) keyed by request payload including extra_body.guided_regex, to test black-box generators without network calls.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding generator tests that use mock OpenAI clients.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3f0b4fe8539d7ddf0ef15fbe.md)

## Rule

- **Rule:**
  ```text
  SteerableGenerator must be constructible with a model and a Literal type, and calling it with max_new_tokens must return a str.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding generator tests that exercise the SteerableGenerator call contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4d90d1acb4c53f226235db66.md)

## Rule

- **Rule:** Constructing Generator with a black-box sync model and a processor must raise NotImplementedError, defining that processors are unsupported for black-box models.
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding tests for Generator construction with black-box models and processors.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5c646b774f7297a8d29f4d2d.md)

## Rule

- **Rule:** SteerableGenerator must validate output type at construction time, raising ValueError for invalid output types rather than deferring validation to generation time.
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding tests for SteerableGenerator construction and output-type validation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6bee18b18237f39f148b0089.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the public SteerableGenerator construction must preserve the processor-binding contract: SteerableGenerator.from_processor(model, processor) sets generator.logits_processor to the supplied processor and generator.model to the supplied model.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:**
  ```text
  When modifying or adding tests around SteerableGenerator.from_processor.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8f48a6e69e54b4cadbd8ae92.md)

## Rule

- **Rule:** A Generator constructed with a steerable model and a Literal output type must be a SteerableGenerator with an OutlinesLogitsProcessor.
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding generator tests that assert type selection for steerable models with Literal output types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cab3bb75de7dceae5e9d9ec5.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the public black-box generator call must preserve the return contract: calling BlackBoxGenerator with a prompt and max_tokens=10 returns a string.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or adding tests around BlackBoxGenerator invocation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f680acfc6dc5d4097bc78c47.md)
