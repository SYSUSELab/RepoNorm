# Constraints for `tests/test_inputs.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise the public Image input must preserve the encoding contract: initialization preserves the PIL image, sets image_format to image/png or image/jpeg based on source format, and sets image_str to base64 of the encoded bytes.
  ```
- **Applies to:**
  - `tests/test_inputs.py`
- **Condition:** When modifying or adding tests around Image input initialization and encoding.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-01c62983d5062f3d3326d1bd.md)

## Rule

- **Rule:** Chat.extend must append messages in order such that chat.messages equals the input list, establishing list-equality semantics for message extension.
- **Applies to:**
  - `tests/test_inputs.py`
- **Condition:** When modifying or adding tests for Chat.extend message ordering and list-equality behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1f12b82fde0dd79f68e9dcd2.md)

## Rule

- **Rule:**
  ```text
  `Image` initialization must raise `TypeError` matching 'Could not read the format of the image' when the image has no format or an empty string format.
  ```
- **Applies to:**
  - `tests/test_inputs.py`
- **Condition:**
  ```text
  When modifying `Image` initialization or image format validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-20782560765a1fa58c8c755f.md)

## Rule

- **Rule:**
  ```text
  Chat message-append helpers (add_user_message, add_system_message, add_assistant_message) must accept either a plain string or a list of content items and append exactly one message with the corresponding role, preserving the supplied content unchanged.
  ```
- **Applies to:**
  - `tests/test_inputs.py`
- **Condition:**
  ```text
  When modifying or adding tests for Chat.add_user_message, Chat.add_system_message, or Chat.add_assistant_message content handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-26eb79a05005967838a1f253.md)

## Rule

- **Rule:**
  ```text
  `Chat.pop()` must remove and return the last message, leaving earlier messages intact, and must raise `IndexError` when called on an empty Chat.
  ```
- **Applies to:**
  - `tests/test_inputs.py`
- **Condition:**
  ```text
  When modifying `Chat.pop` or the Chat message list behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-700b8911791fde06f50ca2cb.md)

## Rule

- **Rule:**
  ```text
  Tests for Chat initialization must assert that an empty Chat has messages == [] and str(chat) == "", while a Chat with messages preserves the list and renders str(chat) as newline-joined role/content dicts and repr(chat) as "Chat(messages=[...])".
  ```
- **Applies to:**
  - `tests/test_inputs.py`
- **Condition:**
  ```text
  When adding or modifying Chat initialization tests in tests/test_inputs.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7713f556786108249bc5b4da.md)

## Rule

- **Rule:** Tests that exercise the public Chat input must preserve the append contract: appending a message dict increases messages length to 1 and stores the exact message dict.
- **Applies to:**
  - `tests/test_inputs.py`
- **Condition:** When modifying or adding tests around Chat message appending.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8bcfa0b0fa6ff58e972f3647.md)

## Rule

- **Rule:** Video input wrapper must store the provided video value unchanged.
- **Applies to:**
  - `tests/test_inputs.py`
- **Condition:** When modifying or adding input tests that assert video wrapper storage behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f8d8905c5aaed74973d630ea.md)
