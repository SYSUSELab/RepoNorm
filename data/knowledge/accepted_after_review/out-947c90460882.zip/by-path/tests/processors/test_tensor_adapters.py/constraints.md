# Constraints for `tests/processors/test_tensor_adapters.py`

## Rule

- **Rule:**
  ```text
  TensorAdapter.to_scalar must raise RuntimeError for multi-element tensors under torch but ValueError under other frameworks, and return a float for single-element tensors.
  ```
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:**
  ```text
  when adding or modifying tensor adapter to_scalar behavior or tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a6ef3a44f4a9f2e473f80d1.md)

## Rule

- **Rule:** Tensor adapter shape() must return a sequence whose length and entries match the tensor rank and dimensions for 1d, 2d, and 3d tensors across all supported frameworks.
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:** when modifying or extending tensor adapter shape behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-38e227f75a2e7426221dfd05.md)

## Rule

- **Rule:**
  ```text
  Tensor adapter to_list must convert 1d, 2d, and 3d tensors into nested Python lists preserving each dimension's length across all supported frameworks.
  ```
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:**
  ```text
  when modifying or extending tensor adapter to_list behavior or its tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a2fd31442487a6107c8433dd.md)

## Rule

- **Rule:** Tensor adapter squeeze must remove only leading singleton dimensions: a (1,) tensor becomes a scalar with no len, while (1,2) and (1,2,3) become (2,) and (2,3) respectively, consistently across all supported frameworks.
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:** When modifying tensor adapter squeeze behavior or its cross-framework tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa1a53505d099322ce16bfd4.md)
