# Constraints for `tests/conftest.py`

## Rule

- **Rule:**
  ```text
  Test collection must skip any test whose nodeid contains test_integration_vllm on non-Linux platforms, since vLLM only supports Linux (including WSL).
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When modifying or adding pytest collection hooks that gate platform-specific tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-503223cadef1ee02c23ad0e1.md)
