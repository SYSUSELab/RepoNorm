# Constraints for `benchmarks`

## Rule

- **Rule:** Uncommitted code is not benchmarked; changes must be committed before benchmarking.
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-77fe7b28315c2a079ece954c.md)

## Rule

- **Rule:**
  ```text
  Run a single ASV benchmark with `asv run --config benchmarks/asv.conf.json -b bench_json_schema.JsonSchemaBenchmark.time_json_schema_to_fsm`.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8f193dc774a3a1f6cef6d698.md)

## Rule

- **Rule:**
  ```text
  Run benchmarks with `asv run --config benchmarks/asv.conf.json`.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a3ed2907bd48e807a5e4c350.md)

## Rule

- **Rule:**
  ```text
  Run `asv continuous origin/main HEAD --config benchmarks/asv.conf.json` to benchmark the current HEAD against origin/main using the repository's asv configuration.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-aac5b22be6b9a1a53a91ebb6.md)

## Rule

- **Rule:**
  ```text
  Run the JSON Schema benchmark with `asv run --config benchmarks/asv.conf.json --profile -b bench_json_schema.JsonSchemaBenchmark.time_json_schema_to_fsm`.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d4c7c4dc90ccfa1f846330c1.md)

## Rule

- **Rule:**
  ```text
  On a device with CUDA, the benchmark command must add the argument `--launch-method spawn`.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Condition:** on a device with cuda
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-debd6c83825ba2ee52ea1af0.md)
