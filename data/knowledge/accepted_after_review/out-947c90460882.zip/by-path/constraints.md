# Constraints for `.`

## Rule

- **Rule:** PRs must include a high-level description of the changes.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-00cf498b074fa413430d8f2c.md)

## Rule

- **Rule:** docformatter is configured with style = "numpy".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-03bdb8e15095bd42170c3803.md)

## Rule

- **Rule:** For all files, charset is utf-8.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-03c96832a1aba6566d6dd59b.md)

## Rule

- **Rule:** mypy enables the incomplete feature "Unpack".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c6643355add2dda0a1e617b.md)

## Rule

- **Rule:** The style job runs pre-commit via the pre-commit/action action.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-11aaee1cab64f21bc982b1cc.md)

## Rule

- **Rule:** Contributors using the VSCode DevContainer workflow must open the Outlines repository in VSCode and reopen it in the container when prompted.
- **Applies to:**
  - `**`
- **Condition:** when using the VSCode DevContainer workflow
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-129f15060b79e44208e049bd.md)

## Rule

- **Rule:** For YAML files, indent size is 2.
- **Applies to:**
  - `**/*.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-157977bc67a4b6df2f2f61b4.md)

## Rule

- **Rule:** The Tests workflow runs on pull requests targeting the main and v1.0 branches.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-181ba92aa706bf4b573be898.md)

## Rule

- **Rule:** Read the Docs builds this project with Python 3.8.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-182cc5cb533c1e173cb08ddd.md)

## Rule

- **Rule:**
  ```text
  Coverage excludes lines matching "pragma: no cover", "if TYPE_CHECKING:", and "\\.\\.\\." from coverage reporting.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-195626cd8ba4ad56e723d48c.md)

## Rule

- **Rule:** For all files, trailing whitespace is trimmed.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-19a630f6deb6dd56c8d1692d.md)

## Rule

- **Rule:** Contributors using the VSCode DevContainer workflow must install the Dev Containers extension in VSCode.
- **Applies to:**
  - `**`
- **Condition:** when using the VSCode DevContainer workflow
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1e7db36792851bd708d57119.md)

## Rule

- **Rule:** Documentation must be up-to-date.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1e98e3c67987f910408ba190.md)

## Rule

- **Rule:** Pytest treats warnings as errors by default (filterwarnings includes "error"), except for the explicitly ignored warning categories.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-218eda82d8f12d1ecf586b5f.md)

## Rule

- **Rule:**
  ```text
  When using uv, create a new virtual environment by running `uv venv` and activate it with `source .venv/bin/activate`.
  ```
- **Applies to:**
  - `**`
- **Condition:** when using uv
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-289f06e61d161cd0cd3672dc.md)

## Rule

- **Rule:** When adding a new feature, there must be an existing issue discussing it.
- **Applies to:**
  - `**`
- **Condition:** when the PR adds a new feature
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-29be72898d5cf8965c05d460.md)

## Rule

- **Rule:** Merging is blocked unless benchmarks are run for the latest commit.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-2bc06fc00d1f5fbb976d4e1b.md)

## Rule

- **Rule:** diff-cover uses ".." as the diff range notation.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2caabede7de655358d9bbb7e.md)

## Rule

- **Rule:** Coverage reports file paths relative to the repository root.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-315d73fded5c514ffeaa5ecc.md)

## Rule

- **Rule:** There must be one commit per logical change.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-3b98060eb7e873420517c777.md)

## Rule

- **Rule:** Code must respect the current naming conventions.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-3e8fb5abec627497482a9847.md)

## Rule

- **Rule:**
  ```text
  Run `pre-commit install` to install the pre-commit hooks.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-40079cf2ff13a31f3f411a73.md)

## Rule

- **Rule:** Commit messages must follow the referenced git commit message guidelines.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-40522cc1ea4bc1529ce83fe3.md)

## Rule

- **Rule:** Outlines provides optional dependencies for different supported backends, installable via pip extras.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4ce242771e3cc9b036ba902a.md)

## Rule

- **Rule:**
  ```text
  Create the development environment with `conda env create -f environment.yml`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-4dd5930756bda489d02dfa6e.md)

## Rule

- **Rule:** Docstrings must follow the numpy style guide.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-51e7bd3d23c3ab0047db0384.md)

## Rule

- **Rule:** PR titles must be understandable on their own, conveying what the PR does from the title only.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-52c63db1251321cbf97a1e33.md)

## Rule

- **Rule:** Ruff linting ignores rules E731 and F401.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-54642018886bee1825a09a56.md)

## Rule

- **Rule:** Changes must be covered by tests.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-54bfd866f8eb57d97f80e2a5.md)

## Rule

- **Rule:** The mkdocstrings plugin is configured with the Python handler using numpy docstring style.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-54fe420c8328920b81c6e8cb.md)

## Rule

- **Rule:** The coverage job depends on the tests job.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-550a5a232606f2396736ae3d.md)

## Rule

- **Rule:** pre-commit must be installed and configured locally, and run before opening the PR.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-56b4d190a471065ae80db186.md)

## Rule

- **Rule:**
  ```text
  The tests job installs the project in editable mode with the test extra using uv pip install -e .[test].
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-64a251e678f178b11b724abc.md)

## Rule

- **Rule:** PRs must link to all relevant issues, discussions, and PRs.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-6eef4c92f46d3b8804b3a23c.md)

## Rule

- **Rule:** For all files, a final newline is inserted.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-734fbaef6626b932be86d820.md)

## Rule

- **Rule:**
  ```text
  Package discovery for setuptools includes only packages matching the pattern "outlines*".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-76d43421fe939ff6a5265bd2.md)

## Rule

- **Rule:** For all files, indentation uses spaces.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7859c829532dfcbef7b89fdd.md)

## Rule

- **Rule:** New feature contributions should be preceded by starting a new discussion or chatting with the maintainers beforehand.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-789d133853895ec6bd844670.md)

## Rule

- **Rule:**
  ```text
  Coverage reporting is configured to show missing lines (show_missing = true).
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-78f188eb3bcd3eba7da220b4.md)

## Rule

- **Rule:** Benchmarks fail if performance degrades by more than 10% for any individual benchmark.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-816433958cf5db93910a465d.md)

## Rule

- **Rule:** The mypy pre-commit hook runs with the --allow-redefinition argument.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8b2dc79e4b7cdb4e2f82ad61.md)

## Rule

- **Rule:** Open a pull request on GitHub after pushing the branch; subsequent changes made on the branch update the pull request.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-8b538c5e39323b6538049b2c.md)

## Rule

- **Rule:** Contributors are encouraged to open a Draft PR when work is still in progress but feedback from other contributors is desired.
- **Applies to:**
  - `**`
- **Condition:** when work is still in progress but feedback from other contributors is desired
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-8d419f0cae81e43864c981bc.md)

## Rule

- **Rule:** Flake8 ignores error codes E203, E231, E501, E741, W503, W504, C901, and E731.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8f57d3e8c4f7044df40cb759.md)

## Rule

- **Rule:** For all files, line endings use LF.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-942f40350ad8cdf0581148fb.md)

## Rule

- **Rule:** diff-cover compares coverage against the origin/main branch.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9ab79b9475342a021de354ba.md)

## Rule

- **Rule:** Coverage is collected with branch coverage enabled.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9c65cf00dd0a411094570a2a.md)

## Rule

- **Rule:**
  ```text
  The project declares a supported Python version range of >=3.9,<3.13.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9d2bac2c0121dbd4480af549.md)

## Rule

- **Rule:** The mypy pre-commit hook installs types-tqdm and types-Pillow as additional dependencies.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a11e60307b67c367b70bf033.md)

## Rule

- **Rule:** Contributors set up the repository by forking it on GitHub and cloning the fork locally.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-a27da82420bf8b1e663df369.md)

## Rule

- **Rule:** The ruff pre-commit hook runs with --config=pyproject.toml.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aed4af75541a581d8dc19cfe.md)

## Rule

- **Rule:** Outlines uses asv for automated benchmark testing, and benchmarks run automatically before pull requests are merged to prevent performance degradation.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b0e75d9665d2b9155ed862e2.md)

## Rule

- **Rule:**
  ```text
  Flake8 ignores F401 and F403 in __init__.py files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b3c1f3cfe60f36feaccd3054.md)

## Rule

- **Rule:** Flake8 selects the C, E, F, and W error code categories.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bdd64d9ee7c784dd1d4d4a98.md)

## Rule

- **Rule:** The coverage job fails the build when diff-cover reports coverage below 100% against the comparison branch.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c03ba8c6ce69929d3924524c.md)

## Rule

- **Rule:** Read the Docs installs the project via pip from the repository root path with the rtd extra requirements.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cdae2bcd072afea72917376f.md)

## Rule

- **Rule:** The issue tracker is only intended for actionable items; when in doubt, open a discussion or talk to the maintainers instead.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-d304fdf5ecd9c35d0a17cf78.md)

## Rule

- **Rule:** docformatter is configured with in-place = true.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d57d9cf2a594b5deeade07c3.md)

## Rule

- **Rule:** The mkdocstrings Python handler is configured to show submodules.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d5ba6c6bb3832c1a778baabf.md)

## Rule

- **Rule:** The branch must be rebased on the latest main commit.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-d6881e5ea9dd49b482e6a939.md)

## Rule

- **Rule:** EditorConfig is rooted at this file (root = true), so this file is the top-most EditorConfig file.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d91b8e9a7a01b5241969d7fd.md)

## Rule

- **Rule:** Contributors using the VSCode DevContainer workflow must run the normal setup steps inside the container.
- **Applies to:**
  - `**`
- **Condition:** when using the vscode devcontainer workflow
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-d92b153e5a32def7bafcf91d.md)

## Rule

- **Rule:**
  ```text
  The tests job uploads coverage data files matching .coverage.* as an artifact named coverage-data.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-da51ba5a58c7529c5f784dbd.md)

## Rule

- **Rule:**
  ```text
  Contributors using venv create the virtual environment with `python -m venv .venv`.
  ```
- **Applies to:**
  - `**`
- **Condition:** when using venv
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dcb03881c05dafba61d113c1.md)

## Rule

- **Rule:**
  ```text
  The build-wheel job builds the SDist and wheel by running ./.github/scripts/build_sdist_and_wheel.sh.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e24deaef51c0037d57ea430d.md)

## Rule

- **Rule:**
  ```text
  The tests job runs pytest under coverage with branch coverage and parallel mode, excluding tests marked api_call.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e595797e4dfa08412030d619.md)

## Rule

- **Rule:** Contributors using the VSCode DevContainer workflow must ensure the Docker daemon is running before proceeding.
- **Applies to:**
  - `**`
- **Condition:** when using the vscode devcontainer workflow
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-e9183ee23d95398609ea6a9e.md)

## Rule

- **Rule:** Flake8 enforces a maximum line length of 88 characters.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f6b6436362339df387eae03e.md)

## Rule

- **Rule:** The Tests workflow runs on pushes to the main branch.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ffadee4d1051f26b6ddb80c5.md)
