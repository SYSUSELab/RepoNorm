# Constraints for `environment.yml`

## Rule

- **Rule:**
  ```text
  The conda environment installs the project itself in editable mode with the test extra via pip (`-e ".[test]"`).
  ```
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4af24d73349813b80a5ee846.md)

## Rule

- **Rule:** The conda environment pins python==3.10.0.
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7fb6a375de9ab9c4121babb4.md)

## Rule

- **Rule:** The conda environment is named dottxt-ai.
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b30695c4279426d7882c025d.md)
