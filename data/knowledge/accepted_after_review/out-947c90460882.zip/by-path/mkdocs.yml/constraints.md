# Constraints for `mkdocs.yml`

## Rule

- **Rule:** The git-revision-date-localized plugin enables creation date and uses the timeago type.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-328724e12605a8d4ddc9742a.md)

## Rule

- **Rule:** The git-committers plugin is configured for repository dottxt-ai/outlines on branch main.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-eb7582ab877914ced6741eb2.md)

## Rule

- **Rule:** The MkDocs site uses the material theme.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-edc13f5428258ac6970dfd5e.md)
