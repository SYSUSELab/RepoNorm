# Claim catalog

- [Rules 1–76](catalog/0001.md); scope preview: `outlines/models/transformers.py`
- [Rules 77–150](catalog/0002.md); scope preview: `outlines/models/mlxlm.py`
- [Rules 151–226](catalog/0003.md); scope preview: `outlines/processors/tensor_adapters/torch.py`
- [Rules 227–299](catalog/0004.md); scope preview: `outlines/__init__.py`
- [Rules 300–369](catalog/0005.md); scope preview: `tests/models/test_vllm_offline.py`
- [Rules 370–442](catalog/0006.md); scope preview: `outlines/inputs.py`
- [Rules 443–494](catalog/0007.md); scope preview: `**`
