# Constraints for `examples/cerebrium/main.py`

## Rule

- **Rule:**
  ```text
  Example scripts that demonstrate structured generation in a deployment service must construct the generator with outlines.json_schema(json_schema) and call it with the prompt, returning the generated result.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
  - `examples/cerebrium/main.py`
- **Condition:** When adding or modifying a deployment example that demonstrates structured generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-36c7198011fb92adf9b269df.md)

## Rule

- **Rule:** Example scripts that demonstrate structured generation with a Mistral model must format the prompt using the Mistral instruction template before passing it to the generator.
- **Applies to:**
  - `examples/cerebrium/main.py`
- **Condition:** When adding or modifying an example that uses a Mistral model for structured generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-57ffb0d9b2e9dddea3d3b7d9.md)
