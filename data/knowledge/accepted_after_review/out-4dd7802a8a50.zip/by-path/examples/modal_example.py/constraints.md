# Constraints for `examples/modal_example.py`

## Rule

- **Rule:** Example scripts that demonstrate remote execution must expose a local entrypoint that invokes the remote function with a default prompt, documenting the expected remote-call pattern.
- **Applies to:**
  - `examples/modal_example.py`
- **Condition:** When adding or modifying the Modal remote-execution example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-037328730568bbb75f93e3ee.md)

## Rule

- **Rule:**
  ```text
  When modifying the Modal example's `generate` function, keep the remote-deployment call pattern: decorate with `@app.function(image=outlines_image, gpu="A100-40GB")` and construct the model inside the function via `outlines.from_transformers` with keyword `tokenizer` and `model` arguments.
  ```
- **Applies to:**
  - `examples/modal_example.py`
- **Condition:** When editing the Modal example's function decoration or model construction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2faf6ac482ac2e66919b07f3.md)

## Rule

- **Rule:** Example scripts must pin external model and dependency versions explicitly (e.g. a fixed model id such as 'mistralai/Mistral-7B-Instruct-v0.2' and pinned package versions in the image build) rather than relying on floating defaults.
- **Applies to:**
  - `examples/modal_example.py`
- **Condition:** When adding or modifying an example that loads a model or installs dependencies in a container image.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-435b710719489c9f235b3686.md)
