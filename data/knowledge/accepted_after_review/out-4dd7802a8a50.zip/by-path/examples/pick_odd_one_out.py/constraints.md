# Constraints for `examples/pick_odd_one_out.py`

## Rule

- **Rule:** Example scripts that demonstrate structured generation with a JSON schema enum output type must call json.loads on the raw generator result to obtain the structured value.
- **Applies to:**
  - `examples/pick_odd_one_out.py`
- **Condition:** When adding or modifying the odd-one-out example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fab37d4821a0563af9a39f20.md)
