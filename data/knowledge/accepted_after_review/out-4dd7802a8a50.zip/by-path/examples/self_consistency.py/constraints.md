# Constraints for `examples/self_consistency.py`

## Rule

- **Rule:** When modifying the self-consistency example, keep the majority-vote aggregation pattern: generate n=10 answers, extract the last integer from each via regex, and report the most frequent answer with a consensus percentage.
- **Applies to:**
  - `examples/self_consistency.py`
- **Condition:** When editing the self-consistency example's sampling count or aggregation logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-49fbcd279ea603c3060e4bef.md)
