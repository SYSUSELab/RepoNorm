# Constraints for `examples/beam-cloud/app.py`

## Rule

- **Rule:**
  ```text
  When modifying the beam-cloud example, preserve the deployment convention that outlines is imported only when `env.is_remote()` is true and models are pre-loaded at container start; do not move heavy imports to unconditional module scope.
  ```
- **Applies to:**
  - `examples/beam-cloud/app.py`
- **Condition:** When editing the beam-cloud example's imports or container-start model loading.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-39bdf84e2ad548d99e1fe462.md)

## Rule

- **Rule:**
  ```text
  When modifying the Beam endpoint example, keep the declared serverless deployment shape: `gpu="A10G"`, `cpu=1`, `memory="16Gi"`, an image adding `outlines`, `torch`, `transformers`, and `accelerate`, model caching via `context.on_start_value`, and generation with `Literal["Positive", "Negative"]`.
  ```
- **Applies to:**
  - `examples/beam-cloud/app.py`
- **Condition:** When editing the Beam endpoint example's deployment resources, image, model caching, or generation signature.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-50bd45866b50ea3f9006382d.md)
