# Constraints for `examples/meta_prompting.py`

## Rule

- **Rule:**
  ```text
  The meta-prompting example's `__main__` block must parse a `--model` argument defaulting to `gpt-4o-mini` and run the named example functions against fixed questions, documenting the expected invocation pattern.
  ```
- **Applies to:**
  - `examples/meta_prompting.py`
- **Condition:** When modifying the meta-prompting example's command-line entrypoint or example invocation list.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a8d73838a8710f5335df885e.md)
