# Constraints for `examples/bentoml/import_model.py`

## Rule

- **Rule:** Example scripts that demonstrate BentoML model packaging must import a HuggingFace model and tokenizer and save both into a BentoML model reference path, establishing the expected artifact layout.
- **Applies to:**
  - `examples/bentoml/import_model.py`
- **Condition:** When adding or modifying the BentoML model import example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0eda97d2281ab47aacb84f94.md)
