# Constraints for `examples/cfg.py`

## Rule

- **Rule:**
  ```text
  When modifying the cfg example's validation loop, keep the pattern of iterating over the nlamb, calc, dyck, and json grammars, generating a batch of 10 sequences per grammar, and validating each by parsing with `generator.logits_processor.guide.parser`, treating parse failure or context-window overflow as FAILURE.
  ```
- **Applies to:**
  - `examples/cfg.py`
- **Condition:** When editing the cfg example's grammar iteration or validation logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-463809da3665e742d34fbbe6.md)
