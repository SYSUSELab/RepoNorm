# Constraints for `examples`

## Rule

- **Rule:** The mypy pre-commit hook excludes files under the examples/ directory.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3dc5cbe1b4a1c237ddca3c41.md)

## Rule

- **Rule:**
  ```text
  Example scripts that build a model from a local framework must use the corresponding outlines.from_<framework> constructor (e.g. outlines.from_transformers, outlines.from_llamacpp) with the framework's model/tokenizer objects, rather than instantiating the model wrapper directly.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that loads a model from a supported local framework.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4d0e47b8dbabd2da6d4b970c.md)

## Rule

- **Rule:** mypy excludes the "examples" directory from type checking.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c9575dbc0b45d7eb1f5745da.md)

## Rule

- **Rule:**
  ```text
  Example scripts that demonstrate structured generation with a JSON schema must define the schema with $ref definitions for nested enums (e.g. Armor, Weapon) and pass it through outlines.json_schema, exercising $ref resolution.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that demonstrates structured generation with a JSON schema containing nested definitions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e5ae041d9d9f89fec837d345.md)
