# Constraints for `examples/dating_profile.py`

## Rule

- **Rule:**
  ```text
  When modifying the dating profile example, keep the `Example` dataclass wrapper around `DatingProfile` with a `description` field, and keep the generation call using `Template.from_file("prompts/dating_profile.txt")` with `outlines.json_schema(DatingProfile)` and `max_tokens=500`.
  ```
- **Applies to:**
  - `examples/dating_profile.py`
- **Condition:** When editing the dating profile example's example structure or generation call.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2c0ad75b6617f07383e6944a.md)

## Rule

- **Rule:**
  ```text
  When modifying the dating profile example's `DatingProfile` model, preserve the documented performance caveat that length constraints on strings via `constr` dramatically increase generation time, and keep the `conlist` usage for interests with its mypy ignore.
  ```
- **Applies to:**
  - `examples/dating_profile.py`
- **Condition:** When editing the DatingProfile model's field constraints or interests field.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f0f12e3e0d4cf9102baeab03.md)
