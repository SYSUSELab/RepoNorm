# Constraints for `examples/llamacpp_example.py`

## Rule

- **Rule:**
  ```text
  Example scripts that define constrained-generation enums must declare them as `str`-based `Enum` classes (e.g. `Armor`, `Weapon`) and reference those enums from the structured output schema rather than using bare string literals.
  ```
- **Applies to:**
  - `examples/llamacpp_example.py`
  - `examples/llamacpp_processor.py`
- **Condition:** When adding or editing enum-constrained generation examples or their structured output schemas.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-762c61505b72a4e5444d36f5.md)
