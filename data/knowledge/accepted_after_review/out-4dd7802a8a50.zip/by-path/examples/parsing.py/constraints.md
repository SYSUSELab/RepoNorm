# Constraints for `examples/parsing.py`

## Rule

- **Rule:**
  ```text
  When modifying `ParserLogitsProcessor.__call__` in the parsing example, preserve the invalid-token handling that catches `EOFError`, `UnexpectedToken`, `UnexpectedCharacters`, and `DedentError` as invalid-token signals; do not narrow the caught exception set without equivalent invalid-token coverage.
  ```
- **Applies to:**
  - `examples/parsing.py`
- **Condition:** When editing the parser logits processor's token-masking loop or its exception handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-77cb1890dc17e56fee3ab25b.md)

## Rule

- **Rule:** The parsing example must initialize parser state by parsing an empty string and maintain a states stack plus token sequence/index for incremental parser-state tracking.
- **Applies to:**
  - `examples/parsing.py`
- **Condition:** When modifying the parsing example's parser-state initialization or incremental tracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dc91bdeb3585bc076444c0ae.md)

## Rule

- **Rule:**
  ```text
  When modifying the parser-masking example, keep the end-to-end integration: load `PartialLark` from the `tests` package with `partial_python.lark` and `PartialPythonIndenter` using `start="file_input"`, then generate with a `LogitsProcessorList` containing `ParserLogitsProcessor(parser)` and `renormalize_logits=True`.
  ```
- **Applies to:**
  - `examples/parsing.py`
- **Condition:** When editing the parser-based masking example's parser loading or generation call.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eb8679c909854719c9b2d9c8.md)
