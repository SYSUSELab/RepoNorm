# Constraints for `docs/index.md`

## Rule

- **Rule:** The documentation site navigation includes the Home page mapped to index.md.
- **Applies to:**
  - `docs/index.md`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e5408649211ce1af0dbcea02.md)
