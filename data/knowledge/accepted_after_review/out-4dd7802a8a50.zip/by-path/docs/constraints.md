# Constraints for `docs`

## Rule

- **Rule:** Read the Docs treats Sphinx warnings as build failures.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0de65fd5401d8e688274e3df.md)

## Rule

- **Rule:** Read the Docs builds documentation with the html builder.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1d116b2408b5f260e32c6aa1.md)

## Rule

- **Rule:** The MkDocs documentation source directory is configured as docs.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c65c4507b1fb684f965c99a8.md)

## Rule

- **Rule:**
  ```text
  Running `mkdocs serve` serves the documentation locally and updates it on every change.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f06622148d76a581c8c7cc5a.md)
