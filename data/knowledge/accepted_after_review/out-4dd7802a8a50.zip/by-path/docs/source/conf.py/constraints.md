# Constraints for `docs/source/conf.py`

## Rule

- **Rule:** Read the Docs uses docs/source/conf.py as the Sphinx configuration file.
- **Applies to:**
  - `docs/source/conf.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc5588cc58d95701a27971f3.md)
