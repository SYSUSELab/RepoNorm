# Constraints for `docs/examples`

## Rule

- **Rule:** Extraction example output models must declare nullable datetime fields with a default of None rather than requiring a value, so partial or missing timestamps remain representable.
- **Applies to:**
  - `docs/examples/**/*.py`
- **Condition:** When defining or modifying a structured output model in an extraction example that includes datetime fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-57d90dafb67281b7c36b3043.md)

## Rule

- **Rule:**
  ```text
  Extraction examples must construct the prompt via Template.from_string with the documented variable names and pass the model and output schema to Generator, so the example stays runnable and consistent with the library API.
  ```
- **Applies to:**
  - `docs/examples/**/*.py`
- **Condition:** When adding or modifying an extraction example that loads a model and produces structured output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cccc6f18023891069744ab4a.md)
