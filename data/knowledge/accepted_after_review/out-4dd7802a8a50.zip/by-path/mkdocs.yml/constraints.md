# Constraints for `mkdocs.yml`

## Rule

- **Rule:** The MkDocs site uses the material theme.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-59712acd6a0de51294107b16.md)
