# Constraints for `normalai/_version.py`

## Rule

- **Rule:**
  ```text
  Flake8 excludes normalai/_version.py from linting.
  ```
- **Applies to:**
  - `normalai/_version.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ca11d6e0f0f6f57bc1b1471a.md)
