# Constraints for `outlines/models/anthropic.py`

## Rule

- **Rule:**
  ```text
  Anthropic generation must not support structured output: passing a non-None output_type must raise NotImplementedError, and the return value must be the first content block's text.
  ```
- **Applies to:**
  - `outlines/models/anthropic.py`
- **Condition:** When modifying Anthropic.generate or adding structured-output handling to the Anthropic model adapter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-679c0f25e674f64f6ad74c1e.md)

## Rule

- **Rule:**
  ```text
  When a model provider's format_input receives an input type it does not support, it must raise TypeError rather than silently coercing or passing the object through; adding a new input modality requires extending the provider's dispatch.
  ```
- **Applies to:**
  - `outlines/models/anthropic.py`
- **Condition:**
  ```text
  when modifying or extending a model provider's format_input dispatch to accept additional input types
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-720e8fd71412f555ba0f1993.md)

## Rule

- **Rule:**
  ```text
  format_vision_model_input must build an Anthropic messages payload with a user message containing an image source using base64, media_type from model_input.image_format, data from model_input.image_str, followed by a text block with model_input.prompt.
  ```
- **Applies to:**
  - `outlines/models/anthropic.py`
- **Condition:** When modifying the Anthropic vision model input formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7d13428f0cbac9e76b1eddd7.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files that require a GPU or Apple Silicon, the listed models that make API calls, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `outlines/v0_legacy/models/anthropic.py`
  - `outlines/v0_legacy/models/dottxt.py`
  - `outlines/v0_legacy/models/exllamav2.py`
  - `outlines/v0_legacy/models/gemini.py`
  - `outlines/v0_legacy/models/mlxlm.py`
  - `outlines/v0_legacy/models/openai.py`
  - `outlines/v0_legacy/models/vllm_offline.py`
  - `tests/*`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eead5ea0355919bc2b1ae59a.md)
