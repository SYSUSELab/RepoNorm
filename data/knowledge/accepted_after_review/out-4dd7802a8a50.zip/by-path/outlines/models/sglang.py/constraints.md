# Constraints for `outlines/models/sglang.py`

## Rule

- **Rule:**
  ```text
  When modifying AsyncSGLang.generate_stream, preserve the streaming protocol: build client args via _build_client_args, call chat.completions.create with stream=True, and yield only chunk.choices[0].delta.content when present, skipping chunks without choices or content.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:**
  ```text
  changing the streaming loop or chunk handling in AsyncSGLang.generate_stream
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-29d94343d49e3e32f8fea57b.md)

## Rule

- **Rule:**
  ```text
  SGLang.generate_stream must build client args from model_input/output_type/inference_kwargs, request stream=True, and yield only chunks whose first choice delta content is not None, skipping empty deltas.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:** When modifying SGLang streaming request construction or chunk filtering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-757b13fc0b9ed54e2d32cf40.md)
