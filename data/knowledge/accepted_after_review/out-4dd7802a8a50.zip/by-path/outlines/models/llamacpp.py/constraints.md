# Constraints for `outlines/models/llamacpp.py`

## Rule

- **Rule:**
  ```text
  When modifying convert_token_to_string, preserve the compatibility boundary: HuggingFace SentencePiece underline handling is applied only when _hf_tokenizer is present; otherwise the token is returned unchanged, so llama.cpp tokenization behavior differs depending on whether an HF tokenizer was supplied.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  changing convert_token_to_string or the handling of _hf_tokenizer presence
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4bc525f4f1ade3583e94288e.md)

## Rule

- **Rule:**
  ```text
  The llama-cpp-python integration must import Llama and LogitsProcessorList only under TYPE_CHECKING and export LlamaCpp and from_llamacpp, keeping llama_cpp an optional runtime dependency not imported at module load.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** When modifying the llama-cpp-python integration's imports or exports.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-656ee6e0ce3a2f013500ca69.md)

## Rule

- **Rule:**
  ```text
  LlamaCppTokenizer equality must be state-based: __eq__ returns False for non-LlamaCppTokenizer operands and otherwise compares __getstate__() dictionaries, so two tokenizers are equal exactly when their serialized state matches.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** When modifying LlamaCppTokenizer equality, state serialization, or adding fields that affect tokenizer identity.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-71e287365d9e0eca75e5252f.md)

## Rule

- **Rule:**
  ```text
  LlamaCppTypeAdapter must prepare arguments to llama-cpp-python's Llama.__call__ as the string prompt plus a LogitsProcessorList, preserving the adapter's argument-shaping contract.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  When modifying LlamaCppTypeAdapter or its argument preparation for Llama.__call__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9a754cd462f9b5fc6d819389.md)

## Rule

- **Rule:**
  ```text
  When changing the fields returned by LlamaCppTokenizer.__getstate__, keep the tuple stable because outlines.caching uses it as a cache key; altering the fields changes cache key stability.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  Modifying the pickling state fields returned by LlamaCppTokenizer.__getstate__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eb9efbad45d04fafc2d07178.md)
