# Constraints for `outlines/models/vllm_offline.py`

## Rule

- **Rule:**
  ```text
  from_vllm_offline must wrap a vllm.LLM instance into a VLLMOffline model, defining the supported construction path for offline vllm usage.
  ```
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:** when modifying the offline vllm construction path or adding offline vllm model support
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7b6f68aedd60c3455e30e091.md)

## Rule

- **Rule:**
  ```text
  When modifying load_lora, preserve the deprecation contract: it is deprecated since v1.0.0, warns that support will be removed in v1.1.0, and directs users to pass lora_request when calling the model or generator.
  ```
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:**
  ```text
  changing or removing the load_lora method or its deprecation warning
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b38f0b310032e1d0e8c17e7e.md)

## Rule

- **Rule:**
  ```text
  VLLMOffline.__init__ must store the vllm.LLM instance, create a VLLMOfflineTypeAdapter, and initialize lora_request to None.
  ```
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:**
  ```text
  When modifying VLLMOffline.__init__ or adding initialization state to the vLLM offline adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-db4825d6d375a95fd54655f4.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files that require a GPU or Apple Silicon, the listed models that make API calls, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `outlines/v0_legacy/models/anthropic.py`
  - `outlines/v0_legacy/models/dottxt.py`
  - `outlines/v0_legacy/models/exllamav2.py`
  - `outlines/v0_legacy/models/gemini.py`
  - `outlines/v0_legacy/models/mlxlm.py`
  - `outlines/v0_legacy/models/openai.py`
  - `outlines/v0_legacy/models/vllm_offline.py`
  - `tests/*`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eead5ea0355919bc2b1ae59a.md)
