# Constraints for `outlines/models/vllm.py`

## Rule

- **Rule:** The vLLM generate method must raise ValueError when any returned message carries a non-None refusal, and must return a single string for one choice or a list of strings for multiple choices.
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** when modifying vLLM response handling or the shape of generate's return value
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6a16bffffd3c483ba0143216.md)

## Rule

- **Rule:** The OpenAI and AsyncVLLM model wrappers must remain thin wrappers around the openai.OpenAI client whose purpose is converting user-specified input and output types into client arguments, rather than implementing generation logic themselves.
- **Applies to:**
  - `outlines/models/openai.py`
  - `outlines/models/vllm.py`
- **Condition:** When modifying the OpenAI or AsyncVLLM model wrappers' responsibilities or client interaction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-74459009088dc3b7fdd4825f.md)
