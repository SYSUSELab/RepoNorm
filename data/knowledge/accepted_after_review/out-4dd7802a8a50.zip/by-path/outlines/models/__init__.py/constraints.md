# Constraints for `outlines/models/__init__.py`

## Rule

- **Rule:** The models package must group model implementations into submodules by provider rather than by theme, and routing functions are used everywhere else in the codebase; the SteerableModel, BlackBoxModel, and AsyncBlackBoxModel unions partition providers by capability.
- **Applies to:**
  - `outlines/models/__init__.py`
- **Condition:** when adding or reorganizing model provider modules or the capability unions in the models package
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ce2f2bc26d127a53424e3969.md)
