# Constraints for `outlines/models/transformers.py`

## Rule

- **Rule:**
  ```text
  When changing format_input, preserve the singledispatchmethod contract that unsupported input types raise NotImplementedError guiding callers to pass a dict with at least a 'text' key plus processor-specific keys.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  Modifying format_input's handling of unsupported input types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-000376ca9c1e76970ebc7881.md)

## Rule

- **Rule:**
  ```text
  The transformers tokenizer's __getstate__ must return only {'tokenizer': self.tokenizer}, intentionally excluding other model state from pickling.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying the transformers tokenizer's pickling or serialization state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-184b37d555dc580672017f05.md)

## Rule

- **Rule:**
  ```text
  The transformers logits-processor handoff must wrap a provided OutlinesLogitsProcessor in a transformers LogitsProcessorList and return None when no output_type is given.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying the transformers adapter's format_output_type handoff to the logits processor
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-23cbad72d0ef3f0d92871bc0.md)

## Rule

- **Rule:**
  ```text
  The TransformerTokenizer.convert_token_to_string must prepend a space for Llama tokenizers when the token starts with SPIECE_UNDERLINE or equals "<0x20>", as a documented workaround for missing spaces in HF Llama tokenizers.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying token-to-string conversion for Llama-family tokenizers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3051cdbc99a5cd5f7f5fcc8d.md)

## Rule

- **Rule:**
  ```text
  _generate_output_seq must slice decoder-only output_ids to drop the prompt prefix while keeping encoder-decoder output_ids whole, and reshape to (batch_size, num_samples, -1) when num_return_sequences > 1 with list prompts.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying _generate_output_seq or output-shaping logic in the transformers model adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-65e056fb96e0549ce6cc2c88.md)

## Rule

- **Rule:**
  ```text
  The transformers model's _prepare_model_inputs must format input via the type adapter, encode prompts into input_ids and attention_mask, and move both tensors to self.model.device before returning them alongside the prompts.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying transformers model input preparation or device placement.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7a18f13205b209040e223e11.md)

## Rule

- **Rule:** TransformerTokenizer must represent a tokenizer for models in the transformers library, defining its scope within the models module.
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying TransformerTokenizer or its documented scope within the models module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9cd0cfb731c1fc341653957b.md)

## Rule

- **Rule:**
  ```text
  TransformerTokenizer.__setstate__ must reinitialize via self.__init__(state["tokenizer"]), so serialized state must contain a tokenizer key for unpickling to succeed.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying TransformerTokenizer serialization, __getstate__, or __setstate__, or changing the tokenizer field.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a91b4271704607428d029c90.md)

## Rule

- **Rule:** Transformers generate must squeeze the batch dimension only when the original prompt was a single str, so single-string inputs yield 1D output while list inputs retain batch shape.
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying transformers generate output shaping or prompt handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b387d28ce4b77b38e21068c1.md)

## Rule

- **Rule:** The registered dict input formatter must raise ValueError when the input dict lacks a 'text' key, enforcing that multimodal dict inputs include 'text'.
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying or adding a dict input formatter for multimodal inputs in the transformers model adapter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f12276866d674e8e354fd1bf.md)
