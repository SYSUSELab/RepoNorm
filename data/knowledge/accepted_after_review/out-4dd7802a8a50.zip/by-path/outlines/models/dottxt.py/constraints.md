# Constraints for `outlines/models/dottxt.py`

## Rule

- **Rule:**
  ```text
  Dottxt.generate_stream must raise NotImplementedError stating that Dottxt does not support streaming and directing callers to regular generation; it must not silently return a non-streaming result or an empty stream.
  ```
- **Applies to:**
  - `outlines/models/dottxt.py`
- **Condition:** When modifying Dottxt streaming support or adding streaming behavior to the Dottxt model.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-16b8818df99dd459a1d2306c.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files that require a GPU or Apple Silicon, the listed models that make API calls, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `outlines/v0_legacy/models/anthropic.py`
  - `outlines/v0_legacy/models/dottxt.py`
  - `outlines/v0_legacy/models/exllamav2.py`
  - `outlines/v0_legacy/models/gemini.py`
  - `outlines/v0_legacy/models/mlxlm.py`
  - `outlines/v0_legacy/models/openai.py`
  - `outlines/v0_legacy/models/vllm_offline.py`
  - `tests/*`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eead5ea0355919bc2b1ae59a.md)
