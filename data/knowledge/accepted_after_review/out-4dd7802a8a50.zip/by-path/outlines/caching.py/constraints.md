# Constraints for `outlines/caching.py`

## Rule

- **Rule:**
  ```text
  The cache decorator must accept expire, typed, and ignore parameters, build its cache key from a key_function if provided or from the decorated function's arguments otherwise, and be based on diskcache's memoize.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:** When modifying the cache decorator or adding caching behavior in outlines/caching.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-614566defeeee63f91c194a7.md)

## Rule

- **Rule:**
  ```text
  The caching wrapper must bypass the cache entirely when _caching_enabled is false; otherwise it must use the ENOVAL sentinel to distinguish cache misses before computing and storing the result with retry=True.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:** when modifying the caching decorator's wrapper, cache-key derivation, or miss-handling logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fb6925a6ec503de5aaea9379.md)
