# Constraints for `outlines/v0_legacy/base.py`

## Rule

- **Rule:**
  ```text
  Changes to the legacy vectorize helpers must preserve the arity contract: call_with_signature raises TypeError on positional/keyword argument count mismatch with input core dims and ValueError when the function's output count differs from declared output core dims, while call_no_signature must keep async coroutine functions on the concurrent vectorize_call_coroutine path and sync functions on the sequential vectorize_call loop.
  ```
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:**
  ```text
  When modifying vectorize.call_with_signature or vectorize.call_no_signature in outlines/v0_legacy/base.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-01d46bd026fd80167e12ce76.md)

## Rule

- **Rule:**
  ```text
  The legacy vectorize_call_coroutine must create a new asyncio event loop, run create_and_gather_tasks to completion, and close the loop in a finally block, so coroutine vectorization owns and always disposes its event loop.
  ```
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:**
  ```text
  When modifying vectorize.vectorize_call_coroutine, preserve the create-run-close lifecycle with loop closure in a finally block.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0afb48014a1f9a5f8a415e68.md)

## Rule

- **Rule:**
  ```text
  The v0_legacy vectorize wrapper must preserve coroutine detection and metadata (inspect.iscoroutinefunction + functools.update_wrapper) so call_thunk can dispatch sync vs async execution, and call_thunk must create and close a new event loop for coroutine thunks.
  ```
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:**
  ```text
  When modifying the v0_legacy vectorize wrapper or call_thunk dispatch logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0d00c82e69708b20cc84f673.md)

## Rule

- **Rule:**
  ```text
  The legacy vectorize class must behave like numpy.vectorize for Python functions (executed in a for loop) but execute coroutines concurrently, with code adapted from numpy.lib.function_base.
  ```
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:** When modifying the legacy vectorize class or its handling of Python functions vs coroutines.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-252fc3bbfb4bc0a328e3c688.md)

## Rule

- **Rule:** The legacy v0 vectorize helper treats all inputs and outputs as scalars (core dimension zero) when no signature is given: it broadcasts args/kwargs to a common shape, applies the function elementwise, reshapes results to the broadcast shape, and squeezes; a single output is returned unwrapped while multiple outputs are returned as a tuple.
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:**
  ```text
  When modifying the legacy v0 vectorize helper or its call_no_signature path, preserve the scalar-core-dimension broadcasting, elementwise application, reshape/squeeze, and single-vs-tuple output unwrapping behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a82c0b8de6d729231eb488a8.md)

## Rule

- **Rule:**
  ```text
  The v0_legacy setup_numpy helper must import numpy in a try block and select private numpy helpers (_calculate_shapes, _parse_gufunc_signature, _parse_input_dimensions, _update_dim_sizes) from numpy.lib._function_base_impl for numpy major version >= 2 versus numpy.lib.function_base otherwise.
  ```
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:**
  ```text
  When modifying the v0_legacy setup_numpy helper or its numpy private-helper imports.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c103bfa1e6b0607b76ff70c4.md)

## Rule

- **Rule:**
  ```text
  The v0_legacy vectorize call protocol must raise ImportError when NumPy is unavailable and dispatch to call_thunk, call_with_signature, or call_no_signature based on arguments and signature presence.
  ```
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:**
  ```text
  When modifying the v0_legacy vectorize __call__ dispatch or its NumPy availability guard.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e04bcc6ffcbdb6b2a90ec2b0.md)

## Rule

- **Rule:**
  ```text
  setup_numpy must set all numpy-related attributes to None when numpy is unavailable, so callers must tolerate a fully unset numpy state rather than expecting an exception.
  ```
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:**
  ```text
  When modifying setup_numpy or any caller that depends on numpy-related attributes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e349bd4a911b11da16eb3edf.md)

## Rule

- **Rule:**
  ```text
  Changes to the legacy base module must preserve the conditional nest_asyncio behavior: nest_asyncio is applied only when builtins has __IPYTHON__, and a missing nest_asyncio prints a warning instead of failing.
  ```
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:**
  ```text
  When modifying the module-level nest_asyncio handling in outlines/v0_legacy/base.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ff7da6264d652d64202efce0.md)
