# Constraints for `outlines/v0_legacy/models/mlxlm.py`

## Rule

- **Rule:**
  ```text
  Legacy v0 model parameter adapters must raise NotImplementedError for unsupported sampling options (stop_at, seed, beam_search sampler, num_samples != 1, top_k) and must emit DeprecationWarning when translating deprecated parameters such as top_p/temperature.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/mlxlm.py`
- **Condition:**
  ```text
  When modifying mlxlm_params_adapter or adding parameter translation for the legacy MLX-LM backend, preserve the NotImplementedError guards for unsupported options and the DeprecationWarning on deprecated parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-4ed154e608468f3ac6c8fc41.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files that require a GPU or Apple Silicon, the listed models that make API calls, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `outlines/v0_legacy/models/anthropic.py`
  - `outlines/v0_legacy/models/dottxt.py`
  - `outlines/v0_legacy/models/exllamav2.py`
  - `outlines/v0_legacy/models/gemini.py`
  - `outlines/v0_legacy/models/mlxlm.py`
  - `outlines/v0_legacy/models/openai.py`
  - `outlines/v0_legacy/models/vllm_offline.py`
  - `tests/*`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-eead5ea0355919bc2b1ae59a.md)
