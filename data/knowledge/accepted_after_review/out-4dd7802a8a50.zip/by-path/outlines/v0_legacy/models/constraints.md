# Constraints for `outlines/v0_legacy/models`

## Rule

- **Rule:**
  ```text
  Legacy v0 model modules under outlines/v0_legacy/models/ exist only for v0 backward compatibility and must not be used as examples for new code; new model integrations belong in the v1 API.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/**/*.py`
- **Condition:**
  ```text
  When adding or modifying a model integration module under outlines/v0_legacy/models/, treat the module as frozen legacy surface rather than a template for new code.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7da011523663f56a48caf876.md)
