# Constraints for `outlines/v0_legacy/models/__init__.py`

## Rule

- **Rule:**
  ```text
  Changes to the legacy v0_legacy public surface must preserve the existing re-exported names and aliases (models __init__ __all__ constructors/classes; samplers greedy/multinomial/beam_search aliases) so downstream imports of the legacy API keep resolving.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/__init__.py`
  - `outlines/v0_legacy/samplers.py`
- **Condition:**
  ```text
  When modifying or removing names in the legacy v0_legacy models package __init__ or the samplers module aliases.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-3edb71478ae7e0603b725023.md)
