# Constraints for `outlines/v0_legacy/models/exllamav2.py`

## Rule

- **Rule:**
  ```text
  ExLlamaV2Model.reformat_output must normalize exllamav2 outputs to outlines conventions: collapse single-element lists and regroup flat lists into per-sample sublists when num_samples > 1, asserting divisibility.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying ExLlamaV2Model.reformat_output or any code that consumes its normalized output shape.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-1e478436a0db1a838fac655e.md)

## Rule

- **Rule:**
  ```text
  Changes to the legacy exllamav2 generate path must preserve the per-prompt token-limit invariant: max_new_tokens is passed as min(exllamav2_params["max_new_tokens"]) so no prompt exceeds the model's max sequence length.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying ExLlamaV2Model.generate in outlines/v0_legacy/models/exllamav2.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2f50dfcc05d0a32d95b90b2f.md)

## Rule

- **Rule:**
  ```text
  The legacy ExLlamaV2 generate_stream must enqueue each prompt in a batch as a separate ExLlamaV2DynamicJob with a shared seed incremented per prompt when not None, and must map job serials back to original prompt indices via an order dict.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying ExLlamaV2Model.generate_stream for batched streaming, preserve per-prompt seed incrementing and the serial-to-original-index mapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-70a174a3c5f75f5c7ed8ebc9.md)

## Rule

- **Rule:**
  ```text
  The v0_legacy ExLlamaV2 model must raise NotImplementedError from its stream method, and its ExllamaV2Params TypedDict must remain total=False with the optional keys stop_conditions, seed, gen_settings, and max_new_tokens.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying the v0_legacy ExLlamaV2 model's stream method or its ExllamaV2Params parameter surface.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-cacb9161de54c935a18bab17.md)

## Rule

- **Rule:**
  ```text
  The exllamav2 tokenizer wrapper must expose vocabulary from get_piece_to_id_dict(), special_tokens from extended_piece_to_id, and eos_token_id from the underlying tokenizer, and its decode must call decode_special_tokens=False and normalize a single str result into a one-element list so callers always receive List[str].
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:** When modifying the exllamav2 tokenizer wrapper's attribute derivation or its decode return contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-e5aa63bd27c2935dfcd1fb79.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files that require a GPU or Apple Silicon, the listed models that make API calls, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `outlines/v0_legacy/models/anthropic.py`
  - `outlines/v0_legacy/models/dottxt.py`
  - `outlines/v0_legacy/models/exllamav2.py`
  - `outlines/v0_legacy/models/gemini.py`
  - `outlines/v0_legacy/models/mlxlm.py`
  - `outlines/v0_legacy/models/openai.py`
  - `outlines/v0_legacy/models/vllm_offline.py`
  - `tests/*`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-eead5ea0355919bc2b1ae59a.md)

## Rule

- **Rule:**
  ```text
  The legacy ExLlamaV2 tokenizer's convert_token_to_string must return the token unchanged, performing no token-to-string conversion for this backend.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying OutlinesExLlamaV2Tokenizer.convert_token_to_string, preserve the identity behavior rather than adding conversion logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-f86abda96c59905a7f824103.md)
