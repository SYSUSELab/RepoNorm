# Constraints for `outlines/v0_legacy/models/transformers_vision.py`

## Rule

- **Rule:**
  ```text
  Changes to the legacy TransformersVision._prepare_model_inputs must preserve formatting input via the type adapter, running the processor with padding=True and return_tensors="pt", moving results to the model device, and returning the original model_input["text"] alongside processed inputs.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers_vision.py`
- **Condition:**
  ```text
  When modifying TransformersVision._prepare_model_inputs or its processor invocation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-1775f32eefea8c63f3ba9f71.md)

## Rule

- **Rule:**
  ```text
  Changes to the legacy Transformers vision model constructor must preserve its in-place processor mutation: it forces padding_side = "left" and pad_token = "[PAD]" on the supplied processor before calling the base initializer, so callers must expect their processor object to be modified.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers_vision.py`
- **Condition:**
  ```text
  When modifying TransformersVision.__init__ in outlines/v0_legacy/models/transformers_vision.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-98e0ba77eaa2415a5fe58dd6.md)

## Rule

- **Rule:**
  ```text
  The v0_legacy transformers_vision entry point is deprecated as of v1.0.0 with removal planned in v1.1.0, and its warning must direct users to instantiate TransformersMultiModal via outlines.from_transformers.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers_vision.py`
- **Condition:**
  ```text
  When modifying the v0_legacy transformers_vision entry point or its deprecation warning.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-dcc6323a8ce866280691d1b7.md)
