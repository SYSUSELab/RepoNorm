# Constraints for `outlines/v0_legacy/models/transformers.py`

## Rule

- **Rule:**
  ```text
  Tokenizer loading in the legacy transformers factory must default padding_side to "left" via setdefault, preserving the repository convention while allowing caller override.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers.py`
- **Condition:** When modifying the legacy transformers tokenizer loading factory or its padding defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-1305e9814adab06e58b13bd6.md)

## Rule

- **Rule:**
  ```text
  The legacy mamba function must emit a DeprecationWarning stating it is deprecated from v1.0.0 and will be removed in v1.1.0, direct users to outlines.from_transformers, and suppress the inner transformers deprecation warning via warnings.catch_warnings() before delegating to transformers.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers.py`
- **Condition:**
  ```text
  When modifying the legacy mamba function, preserve the deprecation warning text, the migration pointer to outlines.from_transformers, and the suppression of the inner transformers warning.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-551c5d1368bd67bde5a47009.md)

## Rule

- **Rule:**
  ```text
  The legacy transformers function must let an explicit device argument override any device_map entry in model_kwargs, so callers passing both should expect device to win.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers.py`
- **Condition:**
  ```text
  When modifying the legacy transformers function's device handling, preserve the precedence of the explicit device argument over model_kwargs device_map.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-95d1b18abca15660ab13f157.md)
