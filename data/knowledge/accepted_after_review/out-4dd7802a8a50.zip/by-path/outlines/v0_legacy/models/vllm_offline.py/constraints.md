# Constraints for `outlines/v0_legacy/models/vllm_offline.py`

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files that require a GPU or Apple Silicon, the listed models that make API calls, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `outlines/v0_legacy/models/anthropic.py`
  - `outlines/v0_legacy/models/dottxt.py`
  - `outlines/v0_legacy/models/exllamav2.py`
  - `outlines/v0_legacy/models/gemini.py`
  - `outlines/v0_legacy/models/mlxlm.py`
  - `outlines/v0_legacy/models/openai.py`
  - `outlines/v0_legacy/models/vllm_offline.py`
  - `tests/*`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-eead5ea0355919bc2b1ae59a.md)

## Rule

- **Rule:**
  ```text
  The vllm_offline_params_adapter must map legacy generation/sampling params onto vLLM SamplingParams by only overriding defaults (top_p when currently 1.0, top_k when -1, temperature when 1.0, n/best_of when n==1) and must set repetition_penalty=0 when top_k==1.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/vllm_offline.py`
- **Condition:**
  ```text
  When modifying vllm_offline_params_adapter or the legacy-to-vLLM SamplingParams mapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-f63d877f4afca857e8222762.md)
