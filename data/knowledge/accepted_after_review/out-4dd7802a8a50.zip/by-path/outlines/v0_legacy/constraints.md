# Constraints for `outlines/v0_legacy`

## Rule

- **Rule:**
  ```text
  Code under outlines/v0_legacy/ is a frozen backward-compatibility surface: new code must not be modeled on it, and changes there must preserve v0 behavior rather than modernize it.
  ```
- **Applies to:**
  - `outlines/v0_legacy/**/*.py`
- **Condition:**
  ```text
  When modifying or adding code under the v0_legacy package, including using it as a template for new implementations.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-19cdd23e9cdcb44ba2bec396.md)

## Rule

- **Rule:**
  ```text
  Legacy v0 modules under outlines/v0_legacy are kept only for backward compatibility; new code must not be modeled on them, and changes to them must preserve the existing v0 surface rather than modernize it.
  ```
- **Applies to:**
  - `outlines/v0_legacy/**/*.py`
- **Condition:**
  ```text
  When modifying or adding code under outlines/v0_legacy, including using it as a template for new functionality.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5654c347152856e584bf5ac2.md)
