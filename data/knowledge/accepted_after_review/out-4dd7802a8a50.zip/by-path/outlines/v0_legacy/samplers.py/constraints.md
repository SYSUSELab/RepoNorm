# Constraints for `outlines/v0_legacy/samplers.py`

## Rule

- **Rule:**
  ```text
  Changes to the legacy v0_legacy public surface must preserve the existing re-exported names and aliases (models __init__ __all__ constructors/classes; samplers greedy/multinomial/beam_search aliases) so downstream imports of the legacy API keep resolving.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/__init__.py`
  - `outlines/v0_legacy/samplers.py`
- **Condition:**
  ```text
  When modifying or removing names in the legacy v0_legacy models package __init__ or the samplers module aliases.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3edb71478ae7e0603b725023.md)

## Rule

- **Rule:**
  ```text
  The v0_legacy Sampler base class must declare sampling_params as an abstract property returning SamplingParameters, defining the interface legacy samplers must implement.
  ```
- **Applies to:**
  - `outlines/v0_legacy/samplers.py`
- **Condition:**
  ```text
  When modifying the v0_legacy Sampler base class or adding a new legacy sampler subclass.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6f84862bf295ad16b4d62939.md)

## Rule

- **Rule:**
  ```text
  The legacy beam search sampler must keep samples equal to the number of beams and its sampling_params must return SamplingParameters("beam_search", self.samples, None, None, 1.0), fixing temperature at 1.0 and leaving top_p/top_k unset.
  ```
- **Applies to:**
  - `outlines/v0_legacy/samplers.py`
- **Condition:**
  ```text
  When modifying BeamSearchSampler or its sampling_params property, preserve the samples-equals-beams invariant and the fixed temperature 1.0 with unset top_p/top_k.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-840eaea63d25628ab2715e9d.md)

## Rule

- **Rule:** The legacy Sampler Protocol must document that outlines delegates the generation loop to models so samplers only define sampling parameters passed to the model, and must require a samples: int attribute.
- **Applies to:**
  - `outlines/v0_legacy/samplers.py`
- **Condition:** When modifying the legacy Sampler Protocol or its required attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-90d158b3cbb8dd15160649fa.md)

## Rule

- **Rule:**
  ```text
  The legacy v0 sampler classes expose the beam/sample count through the samples attribute (default 1, with BeamSearchSampler.__init__ taking beams: int = 1 and storing it as self.samples), and GreedySampler.sampling_params must return SamplingParameters("greedy", self.samples, None, None, 0.0).
  ```
- **Applies to:**
  - `outlines/v0_legacy/samplers.py`
- **Condition:**
  ```text
  When modifying legacy v0 sampler classes or their sampling_params construction, preserve the samples attribute semantics (default 1, beam count exposed as samples) and the exact greedy SamplingParameters tuple.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a5e950e2121a6f128e735c1a.md)
