# Constraints for `outlines/v0_legacy/function.py`

## Rule

- **Rule:** The legacy v0 Function dataclass encapsulates a prompt template, schema, model name, and an optional GeneratorV0Adapter, defining the v0 function contract.
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:** When modifying the legacy v0 Function dataclass, preserve its fields for prompt template, schema, model name, and optional GeneratorV0Adapter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c119b8ed846c0786590d40a.md)

## Rule

- **Rule:**
  ```text
  Changes to the legacy v0_legacy compatibility surface must keep it separate from the current API: the v0_legacy function module imports from outlines.v0_legacy and outlines.v0_legacy.models.transformers, preserving the legacy API as a distinct compatibility surface.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying imports or module structure of the legacy v0_legacy function module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-35358971bc265b46cedd5b6a.md)

## Rule

- **Rule:**
  ```text
  Changes to the legacy download_from_github function must preserve its path validation: require a {USERNAME}/{REPO_NAME}/{PATH_TO_FILE} path with at least three segments, reject paths ending in .py, map HTTP 404 to ValueError, and otherwise call raise_for_status.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying the legacy download_from_github function or its path/HTTP error handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8b18d2884c3f122fd8087a8a.md)

## Rule

- **Rule:**
  ```text
  The legacy Function dataclass __post_init__ must call function_warning() so that use of the legacy function API emits a deprecation warning.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying the legacy Function dataclass initialization, preserve the function_warning() call that signals deprecation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9ddf82290bfffbc3b3aa7142.md)

## Rule

- **Rule:**
  ```text
  The legacy extract_function_from_file must execute downloaded file content via exec and validate that the named attribute is an instance of outlines.Function, raising AttributeError or TypeError otherwise.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying extract_function_from_file or its validation of downloaded function content.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ab3f78811fdd9a1a50d5ecd6.md)

## Rule

- **Rule:**
  ```text
  The legacy Function.__call__ must not support batching, must lazily initialize the generator, must render the prompt template with args/kwargs, and must suppress DeprecationWarning around generator initialization and invocation.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying the legacy Function.__call__ path or its generator initialization/invocation behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bd8c8a280464d1adb9412fca.md)

## Rule

- **Rule:**
  ```text
  The v0_legacy Function.from_github classmethod must emit a function_warning, download program content from GitHub, and extract the named function (default "fn") as the legacy remote-function loading path.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying the v0_legacy Function.from_github remote-function loading path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e2029d1aa37aa4193ba07427.md)
