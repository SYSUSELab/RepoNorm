# Constraints for `outlines/v0_legacy/generate/api.py`

## Rule

- **Rule:**
  ```text
  The v0_legacy generate API must keep merging prompts and media via merge_prompts_and_media before delegating to the underlying generator, so multimodal inputs are combined before generation.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:**
  ```text
  When changing the v0_legacy generate adapter __call__ path or its multimodal prompt handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-292530db22a083d58cf0db62.md)

## Rule

- **Rule:**
  ```text
  Changes to the legacy GeneratorVisionV0Adapter.stream must preserve merging of prompts and media via merge_prompts_and_media before delegating to the parent stream, so vision streaming requires paired prompt/media inputs.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:** When modifying GeneratorVisionV0Adapter.stream or its input handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2fe7b892672f02d7e8b65cdb.md)

## Rule

- **Rule:** GeneratorV0Adapter is the bridge between legacy v0 generate functions and the current Generator object: legacy functions return this adapter, which stores a current Generator and delegates calls to it; its constructor must reject models that are not V0GeneratorModel with ValueError.
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:** When modifying GeneratorV0Adapter or the legacy generate functions that return it, preserve the adapter's role as a delegating wrapper around a current Generator and the ValueError guard rejecting non-V0GeneratorModel inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-35d1eb879c2fb71422ef0dd1.md)

## Rule

- **Rule:**
  ```text
  The legacy generate API __call__ must mirror input shape in its return: a list of sequences is formatted individually per sequence, while a single sequence is formatted directly.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:**
  ```text
  When modifying GeneratorV0Adapter.__call__ or its result formatting, preserve the list-versus-single return shape mirroring the input.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-54c44d7986ee8028d68ad754.md)

## Rule

- **Rule:**
  ```text
  Changes to the legacy generation adapter must preserve the model-specific parameter adapter dispatch: create_inference_params selects an adapter via isinstance checks over LlamaCpp, VLLMOffline, Transformers, ExLlamaV2Model, and MLXLM, and GeneratorV0Adapter.stream must continue to build inference params through create_inference_params before forwarding prompts.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:**
  ```text
  When adding a new model backend or modifying GeneratorV0Adapter.create_inference_params or GeneratorV0Adapter.stream in outlines/v0_legacy/generate/api.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-6380d9be2edce7bfe2834e9f.md)

## Rule

- **Rule:** The legacy generate API must enumerate V0GeneratorModel as a Union of ExLlamaV2Model, LlamaCpp, MLXLM, Transformers, TransformersVision, and VLLMOffline, defining the model backends the v0 compatibility layer supports.
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:** When modifying V0GeneratorModel or the set of model backends supported by the v0 compatibility layer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-9cf5f8081f75a446bcd7d5e3.md)
