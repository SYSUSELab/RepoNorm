# Constraints for `outlines/fsm/parsing.py`

## Rule

- **Rule:** PartialParsingFrontend must not reintroduce the commented-out state-transition-map approach, which is documented as 'very wasteful' by a TODO.
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** when modifying PartialParsingFrontend's state-transition handling or considering the commented-out state-transition-map approach
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-01e00617d390b8550440c399.md)

## Rule

- **Rule:**
  ```text
  PartialLexerThread.__repr__ must include both the lexer and state representations, providing a stable debug string format for parser state.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying PartialLexerThread.__repr__ or the debug string format for parser state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1b84d0a0aafb0dc4b0813e44.md)

## Rule

- **Rule:**
  ```text
  _compute_termset_fsm_info must group parser states by the ordered tuple of terminal names from each contextual lexer scanner, store each termset's scanner FSM and fsms_to_trans_finals, and record the frozenset of parse states using each termset.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying _compute_termset_fsm_info or termset grouping logic in outlines/fsm/parsing.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4f19a960a4afe51513ddc9d0.md)

## Rule

- **Rule:**
  ```text
  get_sub_fsms_from_seq must yield, for each sub-FSM whose transitions contain the state sequence's transitions, a tuple of the FSM index, whether another transition is possible from the last state, and whether the sequence ends in a final state.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying get_sub_fsms_from_seq or sub-FSM matching logic in outlines/fsm/parsing.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5cb975eecfb820dff4b8e510.md)

## Rule

- **Rule:** PartialScanner must be implemented as a Scanner specialization in outlines/fsm/parsing.py rather than as a separate parser type.
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** when modifying partial-parse scanning or adding scanner behavior in the fsm parsing module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-88246d170310bb7b4f5d77bf.md)

## Rule

- **Rule:**
  ```text
  get_terminals_info must walk sub-FSMs from an FSM state sequence and return both all terminal infos and the subset whose sub-FSM is in a final state, with PartialTerminalInfo carrying index, terminal name, fsm_reads_more, and in_final.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying get_terminals_info or terminal info extraction in outlines/fsm/parsing.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9bb15985fd7f4009eeaf4e3b.md)

## Rule

- **Rule:** PartialBasicLexer must subclass BasicLexer, establishing the partial-parsing lexer extension point used by the FSM parsing module.
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When modifying PartialBasicLexer or the partial-parsing lexer extension point in the FSM parsing module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e7d37c06c24dc874e416a5be.md)

## Rule

- **Rule:**
  ```text
  PartialLark must override __serialize_fields__ to include parser, rules, options, deterministic, and use_value_stack, defining the fields persisted when serializing the partial parser.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When modifying the serialization fields of the partial parser.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f482db3e0fd84a3159329918.md)
