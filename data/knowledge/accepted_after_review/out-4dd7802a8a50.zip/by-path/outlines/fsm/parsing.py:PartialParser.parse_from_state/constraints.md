# Constraints for `outlines/fsm/parsing.py:PartialParser.parse_from_state`

## Rule

- **Rule:**
  ```text
  parse_from_state must catch UnexpectedInput and attach an InteractiveParser to the exception before re-raising, and on other exceptions optionally dump the state stack when self.debug is set, defining the parser's error-reporting protocol.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py:PartialParser.parse_from_state`
- **Condition:**
  ```text
  when modifying parse_from_state error handling or the parser's error-reporting behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-11482119ebc05d41a927b4bd.md)
