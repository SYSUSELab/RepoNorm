# Constraints for `outlines/processors/base_logits_processor.py`

## Rule

- **Rule:**
  ```text
  The base logits processor must assert that the leading dimensions of logits and input_ids match before processing, enforcing a shape-consistency invariant across tensor adapters.
  ```
- **Applies to:**
  - `outlines/processors/base_logits_processor.py`
- **Condition:**
  ```text
  When modifying the base logits processor's __call__ or its shape handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-472f120c2a7b936d1d87fbf1.md)
