# Constraints for `outlines/processors/structured.py`

## Rule

- **Rule:**
  ```text
  When changing CFGLogitsProcessor.__init__, keep building a CFGGuide from the CFG string and tokenizer and passing it to the GuideLogitsProcessor superclass with the tensor library name.
  ```
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:**
  ```text
  Modifying CFGLogitsProcessor.__init__ guide construction or superclass initialization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7a367ba266827e8cd761eeb2.md)
