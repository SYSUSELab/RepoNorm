# Constraints for `outlines/processors/guide.py`

## Rule

- **Rule:** The Guide class must extend CoreGuide and support emitting Write instructions that let the model append a token sequence instead of generating it, as an extension point beyond plain DFA regex guides.
- **Applies to:**
  - `outlines/processors/guide.py`
- **Condition:** When modifying the Guide class's instruction emission or its relationship to CoreGuide.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-20541ce92d0195fe53fb166a.md)

## Rule

- **Rule:**
  ```text
  When modifying guide.py, preserve the compatibility boundary: Guide, RegexGuide, Generate, Write, and create_states_mapping are imported from outlines_core.fsm.guide, with create_states_mapping uncached; outlines_core is the source of FSM guide primitives.
  ```
- **Applies to:**
  - `outlines/processors/guide.py`
- **Condition:**
  ```text
  changing imports or re-exports in guide.py that affect the outlines_core.fsm.guide compatibility boundary
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-348453f5b989807395e92459.md)
