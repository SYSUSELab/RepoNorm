# Constraints for `outlines/processors/tensor_adapters/torch.py`

## Rule

- **Rule:** The torch tensor adapter's unsqueeze must add a leading dimension via tensor.unsqueeze(0).
- **Applies to:**
  - `outlines/processors/tensor_adapters/torch.py`
- **Condition:** when modifying the torch tensor adapter's unsqueeze dimension handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-323be896fc0a2a1f5223383d.md)

## Rule

- **Rule:**
  ```text
  Torch tensor adapters must import torch lazily inside __init__ and store it on the instance, avoiding a module-level torch import.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/torch.py`
- **Condition:**
  ```text
  When modifying or adding a torch tensor adapter in outlines/processors/tensor_adapters/torch.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-47cb42472dc3ce148e7cb5a2.md)
