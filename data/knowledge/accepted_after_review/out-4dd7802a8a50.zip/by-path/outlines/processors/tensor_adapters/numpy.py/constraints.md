# Constraints for `outlines/processors/tensor_adapters/numpy.py`

## Rule

- **Rule:**
  ```text
  The numpy tensor adapter's to_list must delegate to the tensor's native tolist() without additional reshaping.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/numpy.py`
- **Condition:** When modifying the numpy tensor adapter's list conversion behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-075f8c369e4914d5bde21fd3.md)

## Rule

- **Rule:** NumpyTensorAdapter.concatenate must delegate to numpy.concatenate with axis=0, fixing concatenation along the first axis for this adapter.
- **Applies to:**
  - `outlines/processors/tensor_adapters/numpy.py`
- **Condition:** When modifying NumpyTensorAdapter.concatenate or changing the concatenation axis for the numpy adapter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-4007db9f4c825b5d73e7b47f.md)

## Rule

- **Rule:** Backend tensor adapters must subclass the shared TensorAdapter base imported from the base tensor adapter module rather than defining an independent adapter type.
- **Applies to:**
  - `outlines/processors/tensor_adapters/numpy.py`
- **Condition:**
  ```text
  when adding or modifying a backend tensor adapter module under tensor_adapters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-761abf90d6eef4af28ccde23.md)
