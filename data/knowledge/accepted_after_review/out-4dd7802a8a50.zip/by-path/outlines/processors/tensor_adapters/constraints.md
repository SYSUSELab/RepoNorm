# Constraints for `outlines/processors/tensor_adapters`

## Rule

- **Rule:**
  ```text
  Tensor adapter implementations must provide boolean_ones_like returning a boolean-dtype tensor of ones (e.g., torch.ones_like with dtype=torch.bool), not a default-dtype tensor.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/**/*.py`
- **Condition:**
  ```text
  When adding or modifying a tensor adapter's boolean_ones_like method.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6748cd2bb3a8fbe5b99623d4.md)

## Rule

- **Rule:**
  ```text
  Tensor adapter implementations must provide argsort_descending with backend-appropriate descending-sort semantics (e.g., negating the tensor before numpy.argsort, or using tf.argsort with direction='DESCENDING'), not a plain ascending sort.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/**/*.py`
- **Condition:**
  ```text
  When adding or modifying a tensor adapter's argsort_descending method.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c5b2d6284db9ad92d74489da.md)
