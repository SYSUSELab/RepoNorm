# Constraints for `outlines/templates.py`

## Rule

- **Rule:**
  ```text
  The get_fn_args template filter must raise TypeError with 'The `args` filter only applies to callables.' when given a non-callable, and otherwise build a comma-joined string of inspect.signature parameter strings.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  When modifying the get_fn_args template filter's validation or formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0f1bbb9348c5746d04cf250f.md)

## Rule

- **Rule:**
  ```text
  When modifying parse_pydantic_schema, preserve recursive $ref resolution: nested $ref entries are resolved by splitting the ref string on '/' and indexing definitions[refs[2]], using the property description when present and falling back to '<name>' otherwise.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  changing how parse_pydantic_schema resolves nested Pydantic model schemas or $ref entries
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-381b4996ed898b2c9d33f1fc.md)

## Rule

- **Rule:**
  ```text
  When changing get_fn_source, preserve the contract that non-callables raise TypeError and that source extraction starts at the first def, since callers rely on this source-filter behavior.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  Modifying get_fn_source's handling of non-callables or its source extraction starting point.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-84f3eecae97287342d960c44.md)

## Rule

- **Rule:**
  ```text
  When adding a schema renderer, register it with functools.singledispatch on get_schema; the default implementation must continue to raise NotImplementedError naming the unsupported type.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  Adding or modifying a schema renderer registered on get_schema.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-893c2dcd788c3cc7d680ff9f.md)

## Rule

- **Rule:**
  ```text
  The Vision template's __post_init__ must raise TypeError when the image has no format, then save the image to a BytesIO buffer and store base64-encoded bytes plus image_format as image/{format.lower()}, so image inputs carry a readable format and are transmitted as base64 with a normalized MIME type.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:** When modifying the Vision template's post-init image handling or serialization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a7fbbef55b9cb776191d2f34.md)

## Rule

- **Rule:**
  ```text
  Template.from_string must build a template via build_template_from_string(content, filters) and pass None as the second constructor argument, defining the string-based template construction path.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  When modifying Template.from_string or the string-based template construction path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b63c9fdb5a17c8c953f7acdc.md)
