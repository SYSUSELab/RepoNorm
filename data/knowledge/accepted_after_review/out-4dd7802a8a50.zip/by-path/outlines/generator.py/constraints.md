# Constraints for `outlines/generator.py`

## Rule

- **Rule:** Generator construction must dispatch on the model type: SteerableModel produces a SteerableGenerator, AsyncBlackBoxModel produces an AsyncBlackBoxGenerator, BlackBoxModel produces a BlackBoxGenerator, and any other model type must raise ValueError rather than silently falling back to a default generator.
- **Applies to:**
  - `outlines/generator.py`
- **Condition:** When adding or modifying model-type dispatch in Generator construction, including new model classes or new generator implementations.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-684ae927dc097aebc5f62953.md)

## Rule

- **Rule:**
  ```text
  When changing SteerableGenerator.__init__ output-type dispatch, keep the mapping: CFG terms to CFGLogitsProcessor, FSM terms to RegexGuide.from_interegular_fsm with GuideLogitsProcessor, other terms via to_regex to RegexLogitsProcessor, and None to no logits processor.
  ```
- **Applies to:**
  - `outlines/generator.py`
- **Condition:**
  ```text
  Modifying SteerableGenerator.__init__ output-type-to-processor selection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fe4ef2dd0d6421008c329171.md)
