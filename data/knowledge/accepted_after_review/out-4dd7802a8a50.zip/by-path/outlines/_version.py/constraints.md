# Constraints for `outlines/_version.py`

## Rule

- **Rule:**
  ```text
  setuptools_scm writes the generated version file to outlines/_version.py.
  ```
- **Applies to:**
  - `outlines/_version.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-123ceee18fc612051ebb8cf4.md)

## Rule

- **Rule:**
  ```text
  Coverage measurement omits the listed files that require a GPU or Apple Silicon, the listed models that make API calls, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `outlines/v0_legacy/models/anthropic.py`
  - `outlines/v0_legacy/models/dottxt.py`
  - `outlines/v0_legacy/models/exllamav2.py`
  - `outlines/v0_legacy/models/gemini.py`
  - `outlines/v0_legacy/models/mlxlm.py`
  - `outlines/v0_legacy/models/openai.py`
  - `outlines/v0_legacy/models/vllm_offline.py`
  - `tests/*`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eead5ea0355919bc2b1ae59a.md)
