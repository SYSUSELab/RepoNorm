# Constraints for `outlines`

## Rule

- **Rule:** The "outlines" package includes the py.typed marker file as package data.
- **Applies to:**
  - `outlines/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8edbef9aee3becf408992b1d.md)
