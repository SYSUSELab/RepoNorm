# Constraints for `outlines/types/dsl.py`

## Rule

- **Rule:**
  ```text
  _handle_union must special-case Optional[T] (two args including None) into an Alternatives of the inner type and String("None"), defining how optional Python types map to DSL terms.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when modifying how union or optional Python types are translated into DSL terms
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4fc04d0eb9a7316d5d6e05f5.md)

## Rule

- **Rule:** The FSM Term dataclass must require its fsm field to be an instance of interegular.fsm.FSM, constraining accepted types for FSM-based output types.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying the FSM Term dataclass or adding FSM-based output types in outlines/types/dsl.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5ecff7d300fd027b5cf16fe0.md)

## Rule

- **Rule:** CFG must be a dataclass Term subclass whose only field is a string definition, establishing the canonical representation of context-free grammar output types.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying CFG or the canonical representation of context-free grammar output types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8a35d5b3e2147c718e901291.md)

## Rule

- **Rule:**
  ```text
  FSM.__repr__ must return 'FSM(fsm=<inner repr>)' and CFG.__repr__ must return "CFG(definition='{self.definition}')", fixing the debug representation format for these DSL nodes.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying the debug representation of FSM or CFG DSL nodes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8cb8d9f9b818d3baac351dc6.md)

## Rule

- **Rule:** QuantifyExact must be a dataclass Term carrying a nested term and an integer count, establishing the exact-repetition DSL node shape.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying QuantifyExact or the exact-repetition DSL node shape.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8e39c5157ab9b514c07735d3.md)

## Rule

- **Rule:**
  ```text
  DSL Term display must use stable node labels: FSM._display_node returns 'FSM(<fsm repr>)' and KleeneStar._display_node returns the literal 'KleeneStar(*)', so ASCII tree rendering depends on these fixed labels.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  When modifying _display_node implementations or ASCII tree rendering for DSL terms.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a265c43b66777ca1d6e71e0b.md)

## Rule

- **Rule:**
  ```text
  The Sequence DSL node's __repr__ must return the exact format 'Sequence(terms=...)' containing the repr of its terms list, preserving the debug representation contract for this DSL node.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  When modifying or adding a DSL node class in outlines/types/dsl.py that defines __repr__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a7784f073327a0956430e830.md)

## Rule

- **Rule:**
  ```text
  Single-term wrapper _display_children must delegate to the wrapped term's display_ascii_tree with is_last forced to True, so the wrapped term is always rendered as the last child.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  When modifying _display_children for single-term wrapper DSL nodes or changing child rendering order.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae67693c659fde3a7a33be6f.md)

## Rule

- **Rule:**
  ```text
  _get_enum_members must collect both regular enum member values and non-dunder function members from the enum class dict, explicitly skipping _generate_next_value_ because it causes issues.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying enum member collection in the DSL type handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ee225b6213384cf822b8bce2.md)
