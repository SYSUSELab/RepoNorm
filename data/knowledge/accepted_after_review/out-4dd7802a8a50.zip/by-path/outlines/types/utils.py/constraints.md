# Constraints for `outlines/types/utils.py`

## Rule

- **Rule:**
  ```text
  is_float must recognize a value as float when it is float, when its origin is float, when it is Annotated with float as the first argument, or when it has a __supertype__ attribute equal to float, covering NewType-style wrappers.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  When modifying is_float or adding float type detection in outlines/types/utils.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-08d3cf78bc97134de77482b1.md)

## Rule

- **Rule:**
  ```text
  Type-dispatch helpers in outlines.types.utils must keep their documented detection semantics: is_callable excludes class objects, is_union matches only typing.Union origins (not PEP 604 X | Y), is_pydantic_model returns False for generic origins as a pre-3.11 guard, is_str accepts str, str-origin generics, Annotated[str, ...], and NewType-like __supertype__ str, and is_typing_dict matches dict origins.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:** When modifying or extending the type-detection helpers used by the type dispatch layer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7ef0af02b2fa4bbffd5845e5.md)

## Rule

- **Rule:**
  ```text
  The is_literal predicate must identify a value as a Literal by checking get_origin(value) is Literal.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:** when modifying the repository's Literal-detection predicate used by type handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-83ce3ad84e3daa2b0c2942f9.md)

## Rule

- **Rule:**
  ```text
  When modifying TypedDict handling in outlines/types/utils.py, preserve the version compatibility boundary: import _TypedDictMeta from typing on Python >= 3.12 and from typing_extensions otherwise.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  changing the import of _TypedDictMeta or TypedDict handling in outlines/types/utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8d5efa0dd7d9d36054bd07bd.md)
