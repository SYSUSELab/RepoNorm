# Constraints for `outlines/applications.py`

## Rule

- **Rule:**
  ```text
  Application.__call__ must cache its Generator and rebuild it only when the supplied model differs from the stored model, so repeated calls with the same model reuse the existing generator.
  ```
- **Applies to:**
  - `outlines/applications.py`
- **Condition:**
  ```text
  When modifying Application.__call__ generator lifecycle, model comparison, or caching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0840e9bbc009fe7d910c6b36.md)
