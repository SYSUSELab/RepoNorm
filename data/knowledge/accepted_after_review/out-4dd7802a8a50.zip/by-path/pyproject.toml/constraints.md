# Constraints for `pyproject.toml`

## Rule

- **Rule:**
  ```text
  The project version is dynamically determined rather than statically declared, as declared by dynamic = ["version"].
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-722778490fcbc51ba2e37ed9.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with an override that applies ignore_missing_imports = true to the listed modules, suppressing missing-import errors for those modules.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bd6290b332ccbe3e964b4831.md)
