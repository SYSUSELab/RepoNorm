# Constraints for `tests/test_applications.py`

## Rule

- **Rule:**
  ```text
  The session-scoped model fixtures in tests/test_applications.py must construct a transformers-backed model via from_transformers using gpt2 AutoModelForCausalLM and AutoTokenizer.
  ```
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:**
  ```text
  When modifying or adding session-scoped model fixtures in tests/test_applications.py that construct transformers-backed models.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-11bcd17779176495ae3c00d9.md)

## Rule

- **Rule:**
  ```text
  Application initialization must leave model and generator as None while storing the template and output_type, defining the pre-binding state of an Application.
  ```
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:** when modifying Application initialization or its stored attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2ab1993c2de3461ddab75368.md)

## Rule

- **Rule:**
  ```text
  The application template call test must assert that Application is callable with a model, a template variable mapping, and max_new_tokens, returning a str.
  ```
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:** When modifying or extending the application template call test, particularly the invocation signature and return type of Application.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-53153dfc2d32720b6262e3b5.md)

## Rule

- **Rule:**
  ```text
  Application invocation with a model and template must return a str when output_type is None; tests must pin this default return-type behavior.
  ```
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:** when modifying Application callable tests or the default output-type return behavior they exercise
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5a02c848368e3f4909bce43c.md)

## Rule

- **Rule:** Application invocation with a None model must raise ValueError, and template rendering that references a variable absent from the provided values must raise jinja2.exceptions.UndefinedError; tests must assert these failure modes rather than silently substituting defaults.
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:** when modifying Application invocation tests or the missing-model / missing-template-variable failure paths they exercise
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-912dceb77031ccf12f971620.md)

## Rule

- **Rule:** Tests that exercise Application generator reuse must assert that calling Application twice with the same model reuses the same generator and model instances, while a different model replaces both.
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:** when adding or modifying a test that exercises Application generator reuse across model instances
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b723a75e3e0a348e8b04c2cf.md)
