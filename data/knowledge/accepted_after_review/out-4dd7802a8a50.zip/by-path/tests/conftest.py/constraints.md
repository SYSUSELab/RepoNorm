# Constraints for `tests/conftest.py`

## Rule

- **Rule:**
  ```text
  pytest_collection_modifyitems must skip any test whose nodeid contains 'test_integration_vllm' when the platform is not Linux, printing a warning that vLLM only supports Linux (including WSL); this establishes a repository-wide platform gating convention for vLLM integration tests.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** when adding or modifying vLLM integration tests or the collection hook
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f72379d4e68db3bbeb2ecf41.md)
