# Constraints for `tests/test_templates.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise the outlines.prompt decorator's source filter must use the {{fn|source}} Jinja filter inside the docstring template to render the function source.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when adding or modifying a test that renders function source through the outlines.prompt decorator
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-032799723749ca68607482c1.md)

## Rule

- **Rule:** Template tests must define an outlines.prompt function whose template uses the name and signature filters on a function argument, documenting the template filter protocol for function metadata.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When adding or modifying template tests that exercise the name and signature filters on function arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1ca7d53c58cd824fe2acfcd7.md)

## Rule

- **Rule:** Vision construction must raise TypeError matching 'Could not read the format' when given a PIL image lacking format metadata; this error behavior must be preserved when changing Vision input validation.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When modifying Vision construction or its image-format validation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-36e2362e775921c1a1b15ff5.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the outlines.prompt decorator's schema filter must use the {{model | schema}} Jinja filter inside the docstring template to render the model schema.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when adding or modifying a test that renders a model schema through the outlines.prompt decorator
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3f487efdf79b374252ac763c.md)

## Rule

- **Rule:** Tests that exercise the outlines.prompt decorator's filters mapping must register custom Jinja filters via the filters keyword argument and apply them in the docstring template.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when adding or modifying a test that registers custom Jinja filters for the outlines.prompt decorator
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-42f9896dc5df17a3b5b97d8f.md)

## Rule

- **Rule:**
  ```text
  build_template_from_string must normalize extra trailing linebreaks so that a template with multiple blank lines renders to a single trailing newline.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When modifying build_template_from_string or its tests regarding trailing whitespace normalization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4b4a3c7112c243560398d4e5.md)

## Rule

- **Rule:**
  ```text
  The deprecated source_ppt prompt rendering must be exercised under pytest.deprecated_call(), and Pydantic models must be rendered as JSON with field descriptions as values and nested models preserved.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When modifying or extending tests for the deprecated source_ppt prompt rendering, particularly the legacy Pydantic model serialization format.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4c2a6e9d457cf44300ac4885.md)

## Rule

- **Rule:**
  ```text
  Template prompt tests must use pytest.deprecated_call() and assert the template signature exposes a variable parameter, with positional and keyword invocation both rendering the expected output; additional filters must apply to both positional and keyword calls.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when modifying Template prompt tests or the deprecated-call and signature-exposure behavior they exercise
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-52c9dc932d652646066b289e.md)

## Rule

- **Rule:** Tests that exercise Jinja rendering must assert exact whitespace behavior, including that -%} trims the trailing newline and that conditionals render to the documented exact strings.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when adding or modifying a test that asserts Jinja rendering output with whitespace control
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5d303456b37e9f95e10d06e9.md)

## Rule

- **Rule:**
  ```text
  Tests for get_fn_description must assert TypeError for non-function input, return the docstring for documented functions, and return an empty string when no docstring exists.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  when adding or modifying tests for get_fn_description behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-62978f9d74818c3826fcf71a.md)

## Rule

- **Rule:**
  ```text
  The template source filter must raise TypeError matching "The `source` filter only applies to callables." for non-callables and return the exact source text of a callable; tests must pin both the rejection and the exact-source behavior.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  when modifying get_fn_source tests or the source-filter callable-only behavior they exercise
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-79716ce9ab10d81d08741e1f.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the outlines.prompt decorator with a dict response must expect a pytest.deprecated_call() and pretty-printed JSON with two-space indentation and preserved empty string values.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when adding or modifying a test that renders a dict response through the outlines.prompt decorator
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8107cb4aee30b5479eb82ce7.md)

## Rule

- **Rule:**
  ```text
  Template tests must define a with_all function covering positional, annotated, defaulted, and mutable-default parameters to exercise template rendering across varied parameter kinds.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When adding or modifying template rendering tests that need to cover varied function parameter kinds.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8188a1235887c7a41020471f.md)

## Rule

- **Rule:** Tests that exercise prompt-template rendering must keep the Jinja inheritance/include fixture convention: a base template with a content block, an include template iterating over examples, and a prompt template that extends the base and includes the include file.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When adding or modifying prompt-template rendering tests that rely on template inheritance or includes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8e5a4908d76bd21f19318675.md)

## Rule

- **Rule:** Deprecated prompt templates must expose a signature whose parameters reflect template variables, and calling the template must support positional and keyword arguments for those variables.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when modifying deprecated prompt template signature or call argument handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-937d4b80292387973eab97a6.md)

## Rule

- **Rule:**
  ```text
  Tests for args_prompt must assert exact formatting of function arguments including annotations and defaults, and must wrap the assertions in pytest.deprecated_call() to pin the deprecation status of args_prompt.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  when adding or modifying tests for args_prompt formatting or deprecation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9dcfc1dd4454d867fe2fbc08.md)

## Rule

- **Rule:** Tests that exercise the outlines.prompt decorator must keep the decorated function's docstring as the Jinja template body, since the decorator renders the docstring rather than a separate template argument.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when adding or modifying a test that uses the outlines.prompt decorator to render a template
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9e45bf6889f9a22a7a7e1458.md)

## Rule

- **Rule:**
  ```text
  Template.from_file must yield a template with signature None, and rendering it with examples and a question must produce the exact expected multi-line prompt text; this file-template rendering format must be preserved when changing Template.from_file or prompt rendering.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When modifying Template.from_file or the prompt rendering format for file-based templates.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c2a99e5daddd04e02b0ed809.md)

## Rule

- **Rule:** Tests that exercise the outlines.prompt decorator with nested Pydantic response models must define a field whose type is another BaseModel to exercise nested structured output rendering.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when adding or modifying a test that renders a nested Pydantic response model through the outlines.prompt decorator
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c81bb410d25f80a258bc4246.md)

## Rule

- **Rule:**
  ```text
  Template.from_string on a plain string must produce a template whose signature is None and which renders {{ name }} substitutions when called with keyword arguments.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  when modifying Template.from_string or template rendering of plain strings
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cd33f7a335297063b25bd228.md)

## Rule

- **Rule:** A backslash line-continuation in a template must join lines with a single space and strip leading indentation, while a line break without a backslash must preserve the newline and the following line's indentation.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when modifying template rendering of line continuations or line breaks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e5a6489f475f63c575bf19be.md)

## Rule

- **Rule:**
  ```text
  Tests for the deprecated prompt-rendering helpers must wrap calls in pytest.deprecated_call() and assert the exact rendered strings, preserving both the deprecation status and output format.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When adding or modifying tests for prompt-rendering helpers that are deprecated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e5d0a9eaf3ff64f12b55c4ce.md)

## Rule

- **Rule:**
  ```text
  get_schema must raise NotImplementedError for unsupported input, serialize a dict schema to a pretty-printed JSON string, and serialize a Pydantic class to its JSON schema string.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  when modifying get_schema input handling or serialization behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eb2e7f3af6382c6615c699fd.md)

## Rule

- **Rule:**
  ```text
  Tests for get_fn_args must assert TypeError for non-callable input and the exact signature-string format: 'x, y=2' for a plain function and 'x: int, y: str' for an annotated one.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  when adding or modifying tests for get_fn_args signature formatting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f50fbd13655158f0cde1dd87.md)
