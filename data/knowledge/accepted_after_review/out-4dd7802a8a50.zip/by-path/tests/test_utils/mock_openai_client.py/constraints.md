# Constraints for `tests/test_utils/mock_openai_client.py`

## Rule

- **Rule:** The MockStreamingChunk test helper must initialize choices to an empty list when content is None and otherwise build a single MagicMock choice whose delta.content is the supplied content, preserving the mock streaming chunk shape used by OpenAI streaming tests.
- **Applies to:**
  - `tests/test_utils/mock_openai_client.py`
- **Condition:** when modifying MockStreamingChunk or the OpenAI streaming test helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8bf9ad8bd716eff8f2158748.md)
