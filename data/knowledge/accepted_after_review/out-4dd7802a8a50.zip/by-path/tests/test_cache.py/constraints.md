# Constraints for `tests/test_cache.py`

## Rule

- **Rule:**
  ```text
  cache_disabled must disable caching only within its context scope: cached calls inside the scope re-execute the function, and cached behavior resumes after exiting the scope; this scoped cache-disable semantics must be preserved when changing cache_disabled or the caching decorator.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:**
  ```text
  When modifying cache_disabled or the caching decorator's scope handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0914ccf2ac06bd7ee7576154.md)

## Rule

- **Rule:**
  ```text
  The cache test fixture must set OUTLINES_CACHE_DIR to a temporary directory and assert the cache directory matches it, establishing the environment-variable-based cache configuration convention.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:**
  ```text
  when modifying cache tests or the OUTLINES_CACHE_DIR environment-variable configuration they exercise
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1d57a78c26c72f374812b820.md)

## Rule

- **Rule:**
  ```text
  Tests that simulate a process restart for cache testing must clear only the in-memory lru_cache that returns the diskcache, deliberately not clearing the diskcache itself.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** when adding or modifying a test that simulates a process restart for cache testing
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-478a3c85e3ba50a724ca327c.md)

## Rule

- **Rule:**
  ```text
  Cache clearing tests must assert that repeated calls to a cached function do not grow the store, but after outlines.clear_cache() the next call increases the store size by one, defining the observable cache-clearing behavior.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** when adding or modifying tests for cache clearing behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8053064331ba07859b50dafc.md)

## Rule

- **Rule:**
  ```text
  Cache tests must apply the @test_cache decorator to a function that appends to a shared store list so that caching behavior is verified by observing side-effect counts.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** When adding or modifying cache tests that verify caching via side-effect counts.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a47184336d5ef5280f1e3e2f.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the outlines cache must reset the module-level cache state before running: delete all 'outlines' entries from sys.modules and unset OUTLINES_CACHE_DIR, because the cache is held in a module variable that persists across tests.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** when adding or modifying cache-related tests that depend on a clean cache state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b15f31fd2db185ecd4e8abc9.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise outlines.get_cache() must assert that repeated calls with the same argument do not grow the store while a new argument does.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:**
  ```text
  when adding or modifying a test that exercises outlines.get_cache() caching behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-da046b60e54ca7777f095c24.md)

## Rule

- **Rule:**
  ```text
  Cache invalidation tests must assert that without a version bump the stale cached signature is reused (raising ValueError), while bumping outlines._version.__version__ invalidates the cache and the new signature works.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** when adding or modifying cache invalidation tests related to version bumps
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f57ce168b8cbb9c980870f4d.md)
