# Constraints for `tests/types/test_dsl.py`

## Rule

- **Rule:**
  ```text
  The DSL test module must conditionally import TypedDict from typing on Python 3.12+ and from typing_extensions otherwise, reflecting a supported Python-version compatibility boundary.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** When modifying or extending the DSL test module's imports.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3daabf9411bca0d75512712d.md)

## Rule

- **Rule:**
  ```text
  The CFG type must strip the definition, expose `_display_node` as `CFG('<definition>')`, `__repr__` as `CFG(definition='<definition>')`, and implement value-based equality against other CFG instances but not strings.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** when adding or modifying CFG display or equality tests in the DSL type tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6acb5319946960b41636668f.md)

## Rule

- **Rule:**
  ```text
  The DSL test module must define a nested `PydanticModel` with fields `a: int` and `b: str`, providing a concrete Pydantic model used to exercise DSL handling of Pydantic types.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** when adding or modifying DSL tests that exercise Pydantic type handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9a78b6649e342313893b8075.md)

## Rule

- **Rule:**
  ```text
  The types.fsm wrapper must preserve identity via fsm.fsm == interegular_fsm and format _display_node/__repr__ as FSM(<repr>) and FSM(fsm=<repr>).
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** when adding or modifying a test for the types.fsm wrapper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bd42a1d6b32580cbd6545794.md)

## Rule

- **Rule:**
  ```text
  Every DSL term type (String, Regex, JsonSchema, KleeneStar/Plus, Optional, Alternatives, Sequence, and Quantify variants) must have a stable repr and a display_ascii_tree rendering with specific box-drawing output, and QuantifyBetween must reject max_count < min_count with a ValueError.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** When modifying or extending DSL term repr, tree rendering, or QuantifyBetween validation tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bec59a09f2e2b29b0d883591.md)

## Rule

- **Rule:** DSL term operators must normalize operands: adding a string wraps it in String, and reflected add/or place the other operand first, defining the expected Sequence/Alternatives construction order.
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** When modifying or extending DSL term operator tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c94afd7ae7af88d75700b049.md)

## Rule

- **Rule:**
  ```text
  Tests for the DSL must assert that both the method form `a.zero_or_more()` and the free function `zero_or_more("a")` produce a `KleeneStar`, and that the free-function result's term is a `String`, pinning the equivalence of the two DSL entry points.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** When modifying or extending DSL tests under tests/types/.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e1edfa235580614365e90f9f.md)

## Rule

- **Rule:**
  ```text
  The DSL display contract requires Term()._display_node to raise NotImplementedError and pins the ASCII tree rendering of a String term to '└── String('a')\n'; tests assert this formatting behavior.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:**
  ```text
  when modifying or adding DSL display tests that assert the ASCII tree rendering or the base _display_node behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f9ef4fdfd3f77598090a37b7.md)
