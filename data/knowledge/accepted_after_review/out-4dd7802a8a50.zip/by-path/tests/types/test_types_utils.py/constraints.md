# Constraints for `tests/types/test_types_utils.py`

## Rule

- **Rule:**
  ```text
  Tests for the is_typing_list predicate must assert true for list[int] and List[int] and false for bare list, [], and dict, pinning the predicate's accepted and rejected inputs.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  When adding or modifying a test for the is_typing_list predicate.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-15636c08876361eefe869745.md)

## Rule

- **Rule:**
  ```text
  The is_date type-checking contract requires that datetime.date is a date while datetime.datetime, datetime.time, and a datetime.date instance are not; tests assert this behavior.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when modifying or adding tests for the is_date type-checking utility
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-32b38f52b6b5877402262816.md)

## Rule

- **Rule:**
  ```text
  The sample_schema_builder fixture must build a SchemaBuilder with an empty object schema and then add two objects sharing the key 'hi' with different value types, exercising schema inference across heterogeneous values.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when modifying the sample_schema_builder fixture or adding schema inference tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b36d1cbed204908a9eeb1314.md)

## Rule

- **Rule:**
  ```text
  Tests for the is_time predicate must assert that it is true only for datetime.time and false for datetime.datetime, datetime.date, and a datetime.time instance, pinning that the predicate matches the class exactly and rejects instances.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  When adding or modifying a test for the is_time predicate.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cd6b129d5d07aa392d701711.md)

## Rule

- **Rule:**
  ```text
  Tests for type predicate semantics must assert that `is_str` returns True for `str`, `Annotated[str, ...]`, and `NewType("UserId", str)`, but False for `int`, plain string values, `List[str]`, `Dict[str, str]`, and `NewType` over `int`.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:** When modifying or extending type predicate tests under tests/types/.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fada48bc5e47ddc11f49abf9.md)
