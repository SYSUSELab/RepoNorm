# Constraints for `tests/v0_legacy/generate/test_json_legacy.py`

## Rule

- **Rule:**
  ```text
  The legacy json generation test module must define a JSON_SCHEMA_STRING constant describing an object with a required string `foo` property, and reuse it as the canonical schema fixture across legacy json generation tests.
  ```
- **Applies to:**
  - `tests/v0_legacy/generate/test_json_legacy.py`
- **Condition:** when adding or modifying legacy json generation tests that need a JSON schema fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-a8f6f62d7f289ab50b7cebbf.md)

## Rule

- **Rule:** The legacy json test must assert that calling json with a greedy sampler on an OpenAI model raises NotImplementedError stating the OpenAI API only supports the multinomial sampler, while emitting the json deprecation warning.
- **Applies to:**
  - `tests/v0_legacy/generate/test_json_legacy.py`
- **Condition:** When modifying or extending the legacy json OpenAI wrong sampler test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-d01f6e40edf02e890e9b6aa2.md)
