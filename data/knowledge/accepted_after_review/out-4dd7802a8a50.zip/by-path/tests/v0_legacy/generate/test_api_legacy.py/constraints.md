# Constraints for `tests/v0_legacy/generate/test_api_legacy.py`

## Rule

- **Rule:** Tests that exercise a model adapter's streaming entry point for a vision (v0) adapter must expect NotImplementedError with the message 'Streaming is not implemented for Transformers models'; do not add streaming support expectations for vision adapters without changing that contract.
- **Applies to:**
  - `tests/v0_legacy/generate/test_api_legacy.py`
- **Condition:** When modifying or extending the legacy v0 vision adapter streaming test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2f87e2fe817d40b44ac8c78b.md)

## Rule

- **Rule:** The v0 adapter call contract requires that calling the adapter with a string returns a string, calling with a list returns a list of strings, and stream returns a Generator; tests assert this behavior.
- **Applies to:**
  - `tests/v0_legacy/generate/test_api_legacy.py`
- **Condition:** when modifying or adding v0 legacy adapter tests that assert the return types for string, list, and stream calls
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-e5374bc5ea94e4b8a04517ca.md)
