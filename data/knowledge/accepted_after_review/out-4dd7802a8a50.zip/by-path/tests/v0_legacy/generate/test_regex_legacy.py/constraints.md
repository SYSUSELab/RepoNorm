# Constraints for `tests/v0_legacy/generate/test_regex_legacy.py`

## Rule

- **Rule:** Tests that exercise the v0-to-v1 adapter bridge must import both the v1 generator classes (SteerableGenerator/Generator) and the v0 adapter classes (GeneratorV0Adapter, GeneratorVisionV0Adapter) from the legacy module, so the bridge is exercised end-to-end rather than only one side.
- **Applies to:**
  - `tests/v0_legacy/generate/test_regex_legacy.py`
- **Condition:** when adding or modifying legacy v0 generation tests that cover the adapter bridge
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-67545561517c0c8bbb53a32d.md)
