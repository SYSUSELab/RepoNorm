# Constraints for `tests/v0_legacy/test_function_legacy.py`

## Rule

- **Rule:**
  ```text
  Tests for the legacy Function class must assert that Function.from_github emits a DeprecationWarning matching "The `Function` class is deprecated" and that the returned object's type is outlines.v0_legacy.function.Function, pinning the legacy module path.
  ```
- **Applies to:**
  - `tests/v0_legacy/test_function_legacy.py`
- **Condition:** When adding or modifying a test for the deprecated legacy Function class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4bc1360eda37998b44ea730f.md)
