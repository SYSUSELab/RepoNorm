# Constraints for `tests/v0_legacy/models/test_llamacpp_legacy.py`

## Rule

- **Rule:**
  ```text
  Tests for the llamacpp legacy params adapter must assert that llamacpp_params_adapter defaults min_p to 0.0 and repeat_penalty to 1.0, that explicit overrides in the third argument win, and that a stream key passed in the override dict is not retained on the result.
  ```
- **Applies to:**
  - `tests/v0_legacy/models/test_llamacpp_legacy.py`
- **Condition:** When adding or modifying a test for the llamacpp legacy params adapter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-36ecbea23b03828e9132b328.md)

## Rule

- **Rule:**
  ```text
  The llamacpp_params_adapter must map None stop/seed to absent values and None max_tokens to -1, while passing explicit values through unchanged.
  ```
- **Applies to:**
  - `tests/v0_legacy/models/test_llamacpp_legacy.py`
- **Condition:**
  ```text
  when modifying llamacpp_params_adapter or the tests that pin its None-handling defaults
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-622ea1dc7aa198752d7d9f0e.md)
