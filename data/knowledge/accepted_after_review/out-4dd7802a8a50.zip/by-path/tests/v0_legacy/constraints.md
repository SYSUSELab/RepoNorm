# Constraints for `tests/v0_legacy`

## Rule

- **Rule:**
  ```text
  Tests that exercise legacy v0 model entry points (models.openai, models.llamacpp, models.transformers_vision) must assert the call emits a DeprecationWarning whose message matches the pinned deprecation text for that entry point.
  ```
- **Applies to:**
  - `tests/v0_legacy/**/*.py`
- **Condition:** when adding or modifying a test that invokes a legacy v0 model entry point
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-812f76d681e00db81d7fddd9.md)
