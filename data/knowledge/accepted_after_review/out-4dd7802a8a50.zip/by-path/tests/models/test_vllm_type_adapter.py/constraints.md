# Constraints for `tests/models/test_vllm_type_adapter.py`

## Rule

- **Rule:** Type adapters must reject unsupported input types by raising TypeError with a message matching 'The input type'; tests assert this rejection contract for the vLLM adapter.
- **Applies to:**
  - `tests/models/test_vllm_type_adapter.py`
- **Condition:** when modifying or adding type adapter tests that pass an unsupported input type and assert the raised error
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d26b29083fa83808a6ed84e5.md)
