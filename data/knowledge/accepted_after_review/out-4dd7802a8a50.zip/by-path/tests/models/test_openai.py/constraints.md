# Constraints for `tests/models/test_openai.py`

## Rule

- **Rule:**
  ```text
  The OpenAI simple JSON schema test must be marked api_call and assert that generating with a json_schema output type returns a string whose parsed JSON contains the expected field.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying OpenAI simple JSON schema generation tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1106283a1c368f8979d42264.md)

## Rule

- **Rule:**
  ```text
  The session-scoped `image` fixture in OpenAI vision tests must build a 1x1 white RGB image, save it to an in-memory PNG buffer, seek to 0, and reopen it with PIL so the returned image carries a PNG format attribute.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying OpenAI vision tests that need a format-bearing image fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6c6a12fc317e2bc4f18bdc2b.md)

## Rule

- **Rule:** Tests for OpenAI model.generate with an unsupported output type must assert TypeError matching 'is not available', defining the error contract for unsupported output types.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** When modifying or extending the OpenAI unsupported output type test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a402362c4e01c81a39668cf2.md)

## Rule

- **Rule:**
  ```text
  The OpenAI model fixture is session-scoped and constructed from an api_key fixture and MODEL_NAME, meaning the client is shared across tests in the session.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when modifying or adding the OpenAI model fixture or tests that depend on its session scope
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f8c6d4d7ce75afed47f55e23.md)
