# Constraints for `tests/models/test_transformers_type_adapter.py`

## Rule

- **Rule:**
  ```text
  The transformers type adapter test module must import `TransformersTypeAdapter` from `outlines.models.transformers` and `RegexLogitsProcessor` from `outlines.processors.structured`, anchoring the expected module locations for these classes.
  ```
- **Applies to:**
  - `tests/models/test_transformers_type_adapter.py`
- **Condition:** When modifying or extending the transformers type adapter test module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9171be61ff278f4013966bd4.md)
