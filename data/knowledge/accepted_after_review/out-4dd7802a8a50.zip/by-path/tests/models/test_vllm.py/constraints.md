# Constraints for `tests/models/test_vllm.py`

## Rule

- **Rule:**
  ```text
  The VLLM wrapper must support construction without an explicit model name; tests construct VLLM from an openai_client without a model name.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when modifying or adding VLLM wrapper tests that construct the wrapper without a model name
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-535faa6fe8c311cfe00ffb2b.md)

## Rule

- **Rule:**
  ```text
  Async model wrappers must return a plain string for a single prompt and a list of strings of length n when n>1; tests assert this return contract for vLLM and SGLang async models.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
  - `tests/models/test_vllm.py`
- **Condition:**
  ```text
  when modifying or adding async model call tests that assert the return type of awaiting a model with a single prompt or with n>1
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6fcdc8bf483c2ab3064dc5cf.md)

## Rule

- **Rule:** The vLLM vision test image fixture must build a 256x256 RGB white PNG in memory and reopen it from the BytesIO buffer, supplying vision inputs without on-disk assets.
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when modifying the vLLM vision test image fixture or adding vision inputs to vLLM tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-907ab6aaab6642eb075ccbf0.md)

## Rule

- **Rule:**
  ```text
  The async vLLM test must assert that generating with a CFG(YES_NO_GRAMMAR) constraint and max_tokens=10 returns a string restricted to exactly 'yes' or 'no', establishing the expected constrained-output behavior for the async vLLM model.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** When modifying or extending the async vLLM CFG generation test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-da0936af72a5c275cd32d50b.md)
