# Constraints for `tests/models/test_llamacpp.py`

## Rule

- **Rule:** Tests for LlamaCpp streaming choice must assert that the first streamed token is one of the allowed Literal values, preserving constrained streaming output membership.
- **Applies to:**
  - `tests/models/test_llamacpp.py`
- **Condition:** When modifying or extending the LlamaCpp streaming choice test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0cdc11c95afe77d1238ec602.md)

## Rule

- **Rule:** The llama.cpp streaming test must assert that the first chunk yielded by model.stream("foo?", Foo) is exactly "{", pinning incremental JSON streaming behavior.
- **Applies to:**
  - `tests/models/test_llamacpp.py`
- **Condition:** when adding or modifying a llama.cpp streaming test
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-707d130f270c46c5824ff86e.md)

## Rule

- **Rule:** Tests for a backend's regex-constrained generation must construct the backend's RegexLogitsProcessor from a Regex pattern plus the model tokenizer and tensor library name, then pass it to model.generate, rather than using a generic or differently parameterized processor.
- **Applies to:**
  - `tests/models/test_llamacpp.py`
- **Condition:** When adding or modifying a test that exercises regex-constrained generation for the llamacpp backend.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c95700993caddf0d6e00b43c.md)

## Rule

- **Rule:**
  ```text
  The llama.cpp stop behavior requires that generating with stop='a' and max_tokens=100 produces a result not containing 'a', verifying that the stop string is excluded from output.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp.py`
- **Condition:** when modifying or adding llama.cpp tests that assert stop string exclusion from generated output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cd66374a8a23668d3b43fd17.md)

## Rule

- **Rule:**
  ```text
  The llama.cpp load test must assert that from_llamacpp returns a LlamaCpp whose .model is a Llama, .tokenizer is a LlamaCppTokenizer, .type_adapter is a LlamaCppTypeAdapter, and tensor_library_name is "numpy", pinning the expected wrapper composition.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp.py`
- **Condition:**
  ```text
  when adding or modifying a test that loads a llama.cpp model via from_llamacpp
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d775d7b3e2d702fbf5229dc9.md)
