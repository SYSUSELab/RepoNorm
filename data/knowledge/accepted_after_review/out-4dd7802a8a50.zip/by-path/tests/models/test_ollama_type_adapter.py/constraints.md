# Constraints for `tests/models/test_ollama_type_adapter.py`

## Rule

- **Rule:**
  ```text
  The Ollama type adapter test must assert that format_output_type(User) returns the expected schema for a Pydantic model, establishing Pydantic models as a supported output-type contract for this adapter.
  ```
- **Applies to:**
  - `tests/models/test_ollama_type_adapter.py`
- **Condition:** when adding or modifying Ollama type adapter tests that verify Pydantic output-type formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-583f92565f1090886019c2c4.md)
