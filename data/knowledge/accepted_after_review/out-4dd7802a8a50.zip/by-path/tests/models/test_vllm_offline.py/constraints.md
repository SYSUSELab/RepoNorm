# Constraints for `tests/models/test_vllm_offline.py`

## Rule

- **Rule:** Tests for structured JSON output must assert that the generated result contains the required properties of the pydantic output type (for example the "name" field for a Character type), not merely that generation succeeds.
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** When adding or modifying a test that verifies structured JSON output for a pydantic output type.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4bb1ea103610df033b8bf7d5.md)

## Rule

- **Rule:** The vllm offline tests define a Character pydantic model with a single name: str field, the minimal structured output used in those tests.
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** when modifying or adding the Character pydantic model or tests that depend on it
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7aecc92a81f5c12068c8ad62.md)

## Rule

- **Rule:**
  ```text
  Tests for the vLLM offline model must assert that calling the model with a plain string prompt returns a `str`, documenting the basic call contract for the offline vLLM model.
  ```
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** When modifying or extending vLLM offline model tests under tests/models/.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-acab5e692681ecd4a5c277e8.md)
