# Constraints for `tests/models/test_tgi.py`

## Rule

- **Rule:**
  ```text
  The TGI test module must select a real InferenceClient/AsyncInferenceClient when TGI_SERVER_URL is set, otherwise warn and fall back to MockTGIInferenceClient/MockAsyncTGIInferenceClient, and only register mock_responses on the mock clients when no server URL is provided.
  ```
- **Applies to:**
  - `tests/models/test_tgi.py`
- **Condition:** When modifying or extending the TGI test module's client selection and mock setup.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0eef4ff804618f7ef90640db.md)

## Rule

- **Rule:** Async TGI regex tests must assert the generated result is a string matching the supplied regex pattern, verifying constrained generation output shape.
- **Applies to:**
  - `tests/models/test_tgi.py`
- **Condition:** when adding or modifying an async TGI regex test
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f6c1e504ffda2d456cc7184c.md)
