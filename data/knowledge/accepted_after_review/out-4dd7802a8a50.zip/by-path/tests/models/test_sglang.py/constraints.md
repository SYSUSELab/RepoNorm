# Constraints for `tests/models/test_sglang.py`

## Rule

- **Rule:**
  ```text
  Async SGLang CFG tests must assert that generating with CFG(EBNF_YES_NO_GRAMMAR) and max_tokens=10 returns a string restricted to "yes" or "no", pinning grammar-constrained output behavior.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying an async SGLang CFG test
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-09d8b7de6da7b3eb1f369aa2.md)

## Rule

- **Rule:**
  ```text
  The SGLang test module must provide a `sync_model` fixture that constructs `SGLang(openai_client, model_name=sglang_model_name)` as the shared client/model setup for SGLang tests.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** When modifying or extending SGLang test fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-593e399f822fd9dd9604a846.md)

## Rule

- **Rule:**
  ```text
  Async model wrappers must return a plain string for a single prompt and a list of strings of length n when n>1; tests assert this return contract for vLLM and SGLang async models.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
  - `tests/models/test_vllm.py`
- **Condition:**
  ```text
  when modifying or adding async model call tests that assert the return type of awaiting a model with a single prompt or with n>1
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6fcdc8bf483c2ab3064dc5cf.md)

## Rule

- **Rule:**
  ```text
  The SGLang sync streaming test must assert that stream() returns a Generator and that next(result) is a str, and must pass model=sglang_model_name explicitly when the fixture has no model name.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying SGLang sync streaming tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8f330f272085b71b82f7c8d9.md)

## Rule

- **Rule:**
  ```text
  Async tests for the SGLang model must be marked `@pytest.mark.asyncio` and must assert that awaiting the async model with `n=2` returns a list of length 2 of `str` elements.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** When modifying or extending async SGLang model tests under tests/models/.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a90d0fd4e6b523bbc24459de.md)
