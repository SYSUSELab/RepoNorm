# Constraints for `tests/models/test_llamacpp_tokenizer.py`

## Rule

- **Rule:**
  ```text
  The llama.cpp tokenizer test must assert that `__setstate__` raises `NotImplementedError`, documenting that pickling/state restoration is unsupported for this tokenizer.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when adding or modifying llama.cpp tokenizer tests that cover state restoration or pickling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-94f3d238b49c1afd97e099ce.md)

## Rule

- **Rule:**
  ```text
  The llama.cpp tokenizer __getstate__ test must assert the state is a 5-tuple with element types (dict, int, str, int, list), pinning the pickling/serialization shape of LlamaCppTokenizer.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when adding or modifying a test for LlamaCppTokenizer serialization
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e38492e03248f50a75db3824.md)

## Rule

- **Rule:**
  ```text
  Tests for LlamaCppTokenizer.encode must assert that list (batch) inputs raise NotImplementedError while single-string inputs return token_ids and attention_mask of equal length, documenting the batch-unsupported boundary.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when modifying LlamaCppTokenizer.encode or the tests that pin its batch behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e4453aeca699961dc8a7462f.md)
