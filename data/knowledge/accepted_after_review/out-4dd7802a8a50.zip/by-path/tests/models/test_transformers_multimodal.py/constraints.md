# Constraints for `tests/models/test_transformers_multimodal.py`

## Rule

- **Rule:**
  ```text
  The multimodal vision choice test must call the model with a dict containing text with an <image> placeholder and an images entry plus a Foo output type, asserting the result is a string restricted to the allowed choices cat or dog.
  ```
- **Applies to:**
  - `tests/models/test_transformers_multimodal.py`
- **Condition:** when adding or modifying a multimodal vision choice test
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2f2fd22737dea2bb803eb34e.md)

## Rule

- **Rule:**
  ```text
  The transformers vision model must return a list of length 2 for num_return_sequences=2 with num_beams=2, a list of length 2 for batched text/image inputs, and nested lists of length 2 when both batching and num_return_sequences=2 are combined.
  ```
- **Applies to:**
  - `tests/models/test_transformers_multimodal.py`
- **Condition:**
  ```text
  when adding or modifying a test for transformers vision model batching or num_return_sequences
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-63fede2b602fe2549419363a.md)

## Rule

- **Rule:**
  ```text
  Multimodal transformers tests must accept a list of images paired with matching <image> placeholders and assert a str result, preserving multi-image handling.
  ```
- **Applies to:**
  - `tests/models/test_transformers_multimodal.py`
- **Condition:** when adding or modifying a multimodal transformers test that passes multiple images
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e588a7e83182d06d6872fabb.md)
