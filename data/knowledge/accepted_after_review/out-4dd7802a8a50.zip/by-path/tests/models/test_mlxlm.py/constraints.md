# Constraints for `tests/models/test_mlxlm.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise MLX-backed models must be gated with pytest.mark.skipif(not HAS_MLX, ...) so they are skipped on non-Apple-Silicon platforms.
  ```
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying a test that exercises an MLX-backed model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a805a65b315cedbb4eb399f3.md)

## Rule

- **Rule:**
  ```text
  Tests for the MLX backend must be gated with @pytest.mark.skipif(not HAS_MLX, reason="MLX tests require Apple Silicon") and assert that model.generate returns a str, establishing the platform-gating convention for MLX tests.
  ```
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** When adding or modifying a test that exercises the MLX backend.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c9d5c287c52819b1ed7585fe.md)
