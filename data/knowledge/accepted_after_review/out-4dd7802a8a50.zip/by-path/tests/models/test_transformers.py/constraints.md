# Constraints for `tests/models/test_transformers.py`

## Rule

- **Rule:** The transformers JSON test must assert that generating with a Pydantic Character model yields a result containing the 'name' field, verifying structured JSON output includes declared fields.
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** When modifying or extending the transformers JSON structured output test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95895d15803fb3b53db4b33d.md)

## Rule

- **Rule:**
  ```text
  Tests calling transformers models (including model_bart) with a prompt must assert the synchronous call returns a str.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when adding or modifying a test that calls a transformers model with a prompt
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ab3d28291c56ade27c238ea5.md)

## Rule

- **Rule:**
  ```text
  The model fixture loads a real transformers causal LM and tokenizer via from_pretrained and wraps them with outlines.from_transformers, so these tests depend on the TEST_MODEL artifact being available.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when modifying or adding the model fixture or tests that depend on a real transformers model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dee46c99c6228569f5c7291d.md)
