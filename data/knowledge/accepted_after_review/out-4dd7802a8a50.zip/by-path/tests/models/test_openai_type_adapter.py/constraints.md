# Constraints for `tests/models/test_openai_type_adapter.py`

## Rule

- **Rule:**
  ```text
  Tests for the OpenAI type adapter must assert that passing an unsupported input type such as `Audio` raises `TypeError` with a message matching "The input type", defining the adapter's rejection contract for unsupported input types.
  ```
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** When modifying or extending OpenAI type adapter tests under tests/models/.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-108c4da80d1af3f961bd9577.md)

## Rule

- **Rule:**
  ```text
  The OpenAI type adapter test must assert that formatting a Pydantic model produces a dict with response_format.json_schema.strict == True and a schema equal to the expected schema, defining the OpenAI structured-output contract.
  ```
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when adding or modifying OpenAI type adapter tests that verify structured-output formatting of Pydantic models
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-521dd34da920e2f1e04e72d0.md)

## Rule

- **Rule:**
  ```text
  The OpenAI type adapter's format_input for a plain text prompt must return a dict with exactly one message whose role is 'user' and whose content equals the prompt; tests assert this formatting contract.
  ```
- **Applies to:**
  - `tests/models/test_openai_type_adapter.py`
- **Condition:** when modifying or adding OpenAI type adapter tests that assert the formatted message structure for a plain text prompt
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dab35a93e76e26f2efb7657f.md)
