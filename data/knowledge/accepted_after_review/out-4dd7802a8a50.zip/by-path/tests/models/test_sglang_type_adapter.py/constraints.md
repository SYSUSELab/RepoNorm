# Constraints for `tests/models/test_sglang_type_adapter.py`

## Rule

- **Rule:**
  ```text
  The SGLang type adapter test must pin the text input format as a dict with a single `messages` entry whose role is "user" and content equals the prompt.
  ```
- **Applies to:**
  - `tests/models/test_sglang_type_adapter.py`
- **Condition:** when adding or modifying SGLang type adapter tests that verify text input formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2797c6b27717dd885c7e7ab4.md)

## Rule

- **Rule:**
  ```text
  The SGLang type-adapter test must assert that formatting a Vision("hello", image) message yields a single user message whose content has a text part with "hello" and an image_url part with URL data:image/png;base64,{image_str}, pinning the multimodal message format.
  ```
- **Applies to:**
  - `tests/models/test_sglang_type_adapter.py`
- **Condition:** when adding or modifying a test for SGLang vision input formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dd7d4c5d083859f1537ac499.md)
