# Constraints for `tests/models/test_tokenizer.py`

## Rule

- **Rule:** The tokenizer test module must import Tokenizer from outlines.models.tokenizer, testing the tokenizer abstraction directly from that module path.
- **Applies to:**
  - `tests/models/test_tokenizer.py`
- **Condition:** when adding or modifying imports in the tokenizer test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7f24647b3b5a738a044fccb0.md)
