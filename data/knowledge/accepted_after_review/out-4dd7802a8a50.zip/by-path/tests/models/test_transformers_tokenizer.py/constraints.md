# Constraints for `tests/models/test_transformers_tokenizer.py`

## Rule

- **Rule:**
  ```text
  The transformer_tokenizer_seq2seq fixture must wrap a seq2seq tokenizer in TransformerTokenizer, indicating seq2seq tokenizers are a supported input to TransformerTokenizer.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:**
  ```text
  when adding or modifying the transformer_tokenizer_seq2seq fixture
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2c9768017560a280d4d84fb9.md)

## Rule

- **Rule:**
  ```text
  The tokenizer_seq2seq fixture must construct its tokenizer via transformers.AutoTokenizer.from_pretrained using the module-level TEST_MODEL_SEQ2SEQ constant rather than a hard-coded model name.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:**
  ```text
  when modifying the tokenizer_seq2seq fixture or adding seq2seq tokenizer tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4df85e330c0deca54e3eaa23.md)

## Rule

- **Rule:** The transformer tokenizer test must assert that TransformerTokenizer.decode returns a list of strings, and that decoding the encoding of "Hello, world!" yields a first element containing that text.
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** when adding or modifying transformer tokenizer decode tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-93d6663c5b875a20978121c4.md)

## Rule

- **Rule:**
  ```text
  Tests for TransformerTokenizer must pin the equality and hash contract: __eq__ returns NotImplemented for non-tokenizer objects and compares model_name and kwargs, and hash is an int that is equal for tokenizers built from the same configuration and different for a seq2seq tokenizer.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** when modifying TransformerTokenizer equality or hash behavior, or the tests that pin it
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e74a5bd002e7d0e5782784f1.md)
