# Constraints for `tests/models/test_vllm_offline_type_adapter.py`

## Rule

- **Rule:**
  ```text
  Tests for a backend's output-type adapter must assert the exact request-payload mapping for each supported output type (None to empty payload, CFG to grammar string, JsonSchema to parsed json object, JsonSchema with whitespace to json plus whitespace_pattern, Regex to regex string) rather than only checking that generation returns a value.
  ```
- **Applies to:**
  - `tests/models/test_vllm_offline_type_adapter.py`
- **Condition:** When adding or modifying a test that verifies a backend type adapter's output-type to request-payload mapping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c17b08dcbfc6e88577fc932.md)
