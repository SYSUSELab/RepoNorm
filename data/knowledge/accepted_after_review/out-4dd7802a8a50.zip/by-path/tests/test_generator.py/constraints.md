# Constraints for `tests/test_generator.py`

## Rule

- **Rule:** Generator tests must assert that constructing a Generator with an async black-box model and a Literal output type yields an AsyncBlackBoxGenerator preserving the model and output type.
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When adding or modifying tests for async generator dispatch with a Literal output type.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-04646b9d767e2043b10482e5.md)

## Rule

- **Rule:** BlackBoxGenerator must reject FSM-constrained output types with NotImplementedError, and Generator construction with a black-box async model plus a processor must raise NotImplementedError; tests must document these unsupported combinations.
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** when modifying black-box generator tests or the unsupported FSM / async-processor rejection behavior they exercise
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-080b54e368b3cec620a2b299.md)

## Rule

- **Rule:**
  ```text
  The module-scoped black_box_async_model fixture must construct AsyncVLLM from an async OpenAI client and MODEL_NAME, pinning the async vLLM test wiring.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:**
  ```text
  when adding or modifying the async vLLM test fixture in tests/test_generator.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1dc9250091e174e21bf747eb.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the async black-box generator must mark the test with @pytest.mark.asyncio and await AsyncBlackBoxGenerator(black_box_async_model, str)(...) asserting the result is a str.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** when adding or modifying a test that calls the async black-box generator
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-25ec90b591d68124a3857d66.md)

## Rule

- **Rule:**
  ```text
  Tests for AsyncBlackBoxGenerator initialization must assert that the constructor stores the model and output_type attributes exactly as passed.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** when adding or modifying AsyncBlackBoxGenerator initialization tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2b2a02cc831210e21bf16437.md)

## Rule

- **Rule:** The async black-box generator stream must yield string chunks as an AsyncGenerator; this async streaming interface contract must be preserved when changing async black-box generator streaming behavior.
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying the async black-box generator stream implementation or its test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6ca0eb8b5ca3953fa783391b.md)

## Rule

- **Rule:**
  ```text
  SteerableGenerator construction must raise ValueError when given an invalid output type, and Generator(steerable_model, Literal[...]) must produce a SteerableGenerator whose model is the supplied model and whose logits_processor is an OutlinesLogitsProcessor; these steerable-generator construction contracts must be preserved when changing steerable generator initialization.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying SteerableGenerator initialization or the Generator factory behavior for steerable models.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-86cfa029e64ad6e500ba8855.md)

## Rule

- **Rule:**
  ```text
  BlackBoxGenerator initialization must store the provided model and output_type unchanged, pinning the constructor's attribute contract.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** when modifying BlackBoxGenerator constructor or its stored attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-acdb9447bcaff2b77b044c8b.md)

## Rule

- **Rule:**
  ```text
  SteerableGenerator.from_processor must set both logits_processor and model on the resulting generator, and must raise TypeError when given a non-processor output type such as Literal["foo", "bar"]; tests must pin both the construction contract and the rejection of non-processor output types.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:**
  ```text
  when modifying SteerableGenerator.from_processor tests or the processor-acceptance and output-type validation behavior they exercise
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b16bcaef1b98ab21507ba040.md)

## Rule

- **Rule:** Generator construction must reject a missing model by raising ValueError, and must reject a black-box sync model combined with a logits processor by raising NotImplementedError; these input-validation boundaries must be preserved when changing Generator's constructor or its supported model/processor combinations.
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying Generator construction or the set of supported model/processor combinations in the generator tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bcc28c8a9e9734f5a44eb050.md)

## Rule

- **Rule:**
  ```text
  SteerableGenerator call must return a string when invoked with a Literal output type and max_new_tokens, verifying the callable interface returns text.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** when modifying SteerableGenerator callable interface or its return type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bf24f95497fba3de6c7bb97e.md)

## Rule

- **Rule:** The generator init test must assert that passing both a Literal output type and an explicit processor raises ValueError, and that initializing AsyncBlackBoxGenerator with an FSM output type raises NotImplementedError.
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying or extending generator initialization tests, particularly validation of mutually exclusive output type and processor arguments, or unsupported output types for async black-box generators.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e7187be4f441d9c4d70b7038.md)

## Rule

- **Rule:**
  ```text
  Tests for SteerableGenerator initialization must assert that the generator stores the model unchanged and installs an OutlinesLogitsProcessor as logits_processor, including for CFG and Literal output types.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** when adding or modifying SteerableGenerator initialization tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eac11cbb386a010df6c666fc.md)

## Rule

- **Rule:**
  ```text
  Tests for black-box generators must drive them through MockOpenAIClient or MockAsyncOpenAIClient with preloaded mock_responses keyed by request dicts (including extra_body guided_regex and stream flags) rather than making real API calls.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** when adding or modifying a test that exercises black-box generator behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f43e0c13dd37b2fec116c36b.md)

## Rule

- **Rule:**
  ```text
  Black-box generators must remain directly callable with a prompt and max_tokens keyword argument and return a plain str; tests pin this callable-generator interface.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** when modifying or adding tests for black-box generator call behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f5d599c29cc23117b0fbfb9d.md)

## Rule

- **Rule:** The black-box generator stream test must assert that generator.stream(...) returns a TypingGenerator and that next(result) yields a str, defining the streaming return contract.
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** when modifying black-box generator streaming behavior or its return type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fc2b9a5f069850958aadf225.md)
