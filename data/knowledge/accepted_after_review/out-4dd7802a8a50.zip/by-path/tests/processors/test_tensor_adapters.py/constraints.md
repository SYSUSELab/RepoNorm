# Constraints for `tests/processors/test_tensor_adapters.py`

## Rule

- **Rule:**
  ```text
  The tensor adapter boolean_ones_like test must be parametrized over `frameworks` and assert the result has the same shape as the input and that every element is truthy, defining the cross-framework boolean ones contract.
  ```
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:**
  ```text
  When modifying or extending the tensor adapter boolean_ones_like test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6bde755fed70d52cbcb54e9f.md)

## Rule

- **Rule:** The tensor adapter unsqueeze contract requires that unsqueezing a 1-D tensor of shape (2,) yields (1, 2) and a 2-D tensor of shape (2, 3) yields (1, 2, 3), defining leading-dimension insertion behavior across frameworks.
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:** when modifying or adding tensor adapter tests that assert the shape after unsqueeze
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eb4969a7e744143866c826d3.md)

## Rule

- **Rule:**
  ```text
  Tests for the tensor adapter protocol must assert that `full_like(tensor, value)` preserves the input shape and fills every element with the supplied value, and that `to_scalar` returns a float for single-element tensors while raising RuntimeError for torch and ValueError for other frameworks on multi-element tensors.
  ```
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:** When modifying or extending tensor adapter protocol tests under tests/processors/.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ef75d1d23ae2725a6d3f9732.md)
