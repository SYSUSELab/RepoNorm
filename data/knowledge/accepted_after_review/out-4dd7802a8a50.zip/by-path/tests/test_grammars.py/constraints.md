# Constraints for `tests/test_grammars.py`

## Rule

- **Rule:** Grammar tests must use a MockTokenizer with a fixed vocabulary mapping tokens to ids and an eos token id, providing a minimal deterministic tokenizer for grammar/guide tests.
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:** when adding or modifying grammar or guide tests that need a tokenizer
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-372e624f460bf21419fa2a59.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the grammar test's MockTokenizer must implement decode by mapping token ids back to tokens through an inverse_vocabulary lookup.
  ```
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:**
  ```text
  when adding or modifying the MockTokenizer decode method in tests/test_grammars.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-afd711a1ea4c5582b8e4da63.md)
