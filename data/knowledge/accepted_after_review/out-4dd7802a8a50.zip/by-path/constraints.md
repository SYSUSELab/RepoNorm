# Constraints for `.`

## Rule

- **Rule:** For all files, indentation uses spaces.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09e5f32bce4edbe179aed79b.md)

## Rule

- **Rule:**
  ```text
  For pull_request events the coverage comparison branch is set to origin/<base_ref>; for other events it is set to the event's before commit.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0b9fc19a47e08142e576c282.md)

## Rule

- **Rule:** Contributors using the VSCode DevContainer workflow must open the Outlines repository in VSCode and reopen it in the container when prompted.
- **Applies to:**
  - `**`
- **Condition:** when using the VSCode DevContainer workflow
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-0c49c78f9b42cb6eb07762ea.md)

## Rule

- **Rule:**
  ```text
  Create the development environment with `conda env create -f environment.yml`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-0ddffbd9b7b48fc4b0430e3b.md)

## Rule

- **Rule:** There must be one commit per logical change.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1091ad8a0a25b261e110515a.md)

## Rule

- **Rule:** The coverage job downloads the coverage-data artifact.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1939e793b9f0e2c8af089579.md)

## Rule

- **Rule:** The Tests workflow runs on pushes to the main branch.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-19d6c3aeb99136006ccf69fc.md)

## Rule

- **Rule:**
  ```text
  The coverage job installs coverage[toml]>=5.1 and diff-cover.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-19e4579b6a10a26cb4af8139.md)

## Rule

- **Rule:** The tests job installs Ollama and pulls the tinyllama model.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1e74ed1d8215c01cec5fd12f.md)

## Rule

- **Rule:** Contributors using the VSCode DevContainer workflow must run the normal setup steps.
- **Applies to:**
  - `**`
- **Condition:** when using the vscode devcontainer workflow
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1f7c190e795cdad48fc41f99.md)

## Rule

- **Rule:** For all files, line endings use LF.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1f810053009293fef7d44798.md)

## Rule

- **Rule:** EditorConfig is rooted at this file (root = true), so this file is the top-most EditorConfig configuration.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-203b41f4e1d980128dcea7a5.md)

## Rule

- **Rule:** docformatter is configured with style = "numpy".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-22da1eff6fbe00c76687285e.md)

## Rule

- **Rule:** Benchmarks are run automatically before pull requests are merged to prevent performance degradation.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2783706dd74a2ae436e95200.md)

## Rule

- **Rule:**
  ```text
  pytest is configured to turn warnings into errors ("error" first in filterwarnings), with specific ignore entries for pydantic PydanticDeprecatedSince20, FutureWarning from transformers.* and huggingface_hub.*, UserWarning, and DeprecationWarning from pyairports.*, jax.*, and flax.*.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28042109cb709506f3e01753.md)

## Rule

- **Rule:** Flake8 ignores error codes E203, E231, E501, E741, W503, W504, C901, and E731.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28b3a6aabd821a51f9c84ee4.md)

## Rule

- **Rule:** For all files, a final newline is inserted.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28b762ae997fb1fac293857d.md)

## Rule

- **Rule:**
  ```text
  When using uv, create a new virtual environment by running `uv venv` and then `source .venv/bin/activate`.
  ```
- **Applies to:**
  - `**`
- **Condition:** when using uv
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-2cb29dea580a224e7a4b299c.md)

## Rule

- **Rule:** mypy enables the incomplete feature "Unpack".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-32a30afbd685ea54e4e8d602.md)

## Rule

- **Rule:** The Tests workflow runs on pull requests targeting the main and v1.0 branches.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-39f0b2fee4d46200a400d862.md)

## Rule

- **Rule:** Ruff lint ignores the E731 and F401 rules.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-3a7093ad62eb23a72bc92c98.md)

## Rule

- **Rule:** The coverage job combines coverage data, generates HTML and XML reports, and runs diff-cover against the comparison branch with --fail-under=100, failing the step if coverage is below 100%.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3b7fc8a4bbaef59c8dae3eea.md)

## Rule

- **Rule:**
  ```text
  Coverage reporting is configured with show_missing = true, so missing lines are shown in coverage reports.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3e73189d4bb8fbeaf10be060.md)

## Rule

- **Rule:** The coverage job depends on the tests job and runs on ubuntu-latest.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-41e377457802565fa2004109.md)

## Rule

- **Rule:** PRs must link to all relevant issues, discussions, and PRs.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-47843244ed537947205d25e1.md)

## Rule

- **Rule:** pre-commit must be installed and configured locally, and run before opening the PR.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-53bacace6779aab5e84a531a.md)

## Rule

- **Rule:** Coverage is collected with branch coverage enabled.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-54ee2362cd4d11d663871775.md)

## Rule

- **Rule:** The mypy pre-commit hook runs with the --allow-redefinition argument.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-58901a81937f6a5d19a94265.md)

## Rule

- **Rule:**
  ```text
  Run the test suite with `pytest`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-595b223ed55737df2a0a84b2.md)

## Rule

- **Rule:**
  ```text
  The tests job runs pytest with -x, coverage over the outlines package, and excludes tests marked api_call.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-59b49aea7dd00a0bef03f9de.md)

## Rule

- **Rule:**
  ```text
  The project declares a supported Python version range of >=3.9,<3.13 via requires-python.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5cec4ad4de4dddd52e29f96e.md)

## Rule

- **Rule:** Coverage reports use relative file paths.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5cf95a90b4eabc972cb4e0f0.md)

## Rule

- **Rule:** The branch must be rebased on the latest main commit.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-5d4033821f545854829ef0d9.md)

## Rule

- **Rule:** Code must respect the current naming conventions.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-64ab3b3b9c3106f2eb87ba6e.md)

## Rule

- **Rule:** Documentation must be up-to-date.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-6b06f9cf71dee7943464102f.md)

## Rule

- **Rule:** docformatter is configured with in-place = true.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6d2e0a0c995f4b4e9a1fbbce.md)

## Rule

- **Rule:** Contributors may consider opening a Draft PR when work is still in progress but feedback from other contributors is desired.
- **Applies to:**
  - `**`
- **Condition:** when work is still in progress but feedback from other contributors is desired
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-6d94ca7fd1dc3fbd7b1f311a.md)

## Rule

- **Rule:** Contributors may open a draft PR before the contribution is ready, especially when they have questions or need feedback.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-7347e80c2b5345f4b11369b2.md)

## Rule

- **Rule:** The documentation build uses the mkdocstrings plugin with the python handler and numpy docstring style.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7728e0b0b35c8fdf6bf4e290.md)

## Rule

- **Rule:**
  ```text
  The "Benchmark PR" workflow runs when it is manually dispatched, or if the `run_benchmarks` label is added to the PR they run for every commit.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7c53bbfaf48670167b6d8a47.md)

## Rule

- **Rule:** Merging is blocked unless benchmarks are run for the latest commit.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-7e8b6a7551156b25b23a1fd6.md)

## Rule

- **Rule:** Run the code style checks.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-8007420ec9b12c0f06e35b4e.md)

## Rule

- **Rule:** Flake8 enforces a maximum line length of 88 characters.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-84acc8fcdeab7f3ccfb683b2.md)

## Rule

- **Rule:** Read the Docs builds use Python 3.8.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-86eea77c41a579a18132a74a.md)

## Rule

- **Rule:** New feature contributions should be preceded by starting a new discussion or chatting with the maintainers beforehand.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-8732c95b7c5887c028cec12c.md)

## Rule

- **Rule:** The benchmark test suite can be run locally with a command.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-88a9cb6ce4108e3bf61dde1c.md)

## Rule

- **Rule:** Open a pull request on GitHub after pushing the branch; subsequent changes made on the branch update the pull request.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-8b665f832bd4bc9c07dbf156.md)

## Rule

- **Rule:** The issue tracker is only intended for actionable items; when in doubt, open a discussion or talk to the maintainers instead.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-8dc09a6ce8f137450ce88b12.md)

## Rule

- **Rule:** The tests job sets up the test environment by upgrading pip, installing uv, creating a uv venv, and installing the package editable with the test extra.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-92b6686d8bbbbfb7f1493764.md)

## Rule

- **Rule:**
  ```text
  diff_cover is configured with compare_branch = "origin/main".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-948716d605f1d47a08b9ca2b.md)

## Rule

- **Rule:** Contributors using the VSCode DevContainer workflow must ensure the Docker daemon is running before proceeding.
- **Applies to:**
  - `**`
- **Condition:** when using the vscode devcontainer workflow
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-95f83da36cf9b417b46417d6.md)

## Rule

- **Rule:** PR titles must be understandable on their own, conveying what the PR does from the title only.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-96013a9377e36059f4e18046.md)

## Rule

- **Rule:**
  ```text
  Flake8 ignores F401 and F403 in __init__.py files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-96de3480249351958a08f254.md)

## Rule

- **Rule:** The coverage job sets up Python 3.11 with pip caching.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a5f91d133fd8c852b06974b9.md)

## Rule

- **Rule:** For all files, character set is UTF-8.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a625d1d158531b8232581a04.md)

## Rule

- **Rule:**
  ```text
  The build-wheel job runs on ubuntu-latest and builds the SDist and wheel by running ./.github/scripts/build_sdist_and_wheel.sh.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a8349fd6101109d42b6173c5.md)

## Rule

- **Rule:** Flake8 selects the C, E, F, and W error code groups.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a98500570012b214ea7317da.md)

## Rule

- **Rule:** The coverage job fetches the comparison branch from origin with --no-tags and --prune.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a98b48ecfea3f43ee02c6050.md)

## Rule

- **Rule:** Benchmarks fail if performance degrades by more than 10% for any individual benchmark.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-aa68e6064c3dbb625a80b0c1.md)

## Rule

- **Rule:** PRs must include a high-level description of the changes.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-ae08f1887e9ffa0fcca8b139.md)

## Rule

- **Rule:** For YAML files, indent size is 2.
- **Applies to:**
  - `**/*.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b392228d4eb3f93ac8ad3b64.md)

## Rule

- **Rule:** Commit messages must follow the referenced git commit message guidelines.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-ba4c89392ad619cbc690e672.md)

## Rule

- **Rule:** The mypy pre-commit hook installs types-tqdm and types-Pillow as additional dependencies.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c0aa1fa7a38de0df11cf1c38.md)

## Rule

- **Rule:** The coverage job checks out the repository with fetch-depth 0.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c1ab593ed3856311e2adbc8e.md)

## Rule

- **Rule:** When adding a new feature, there must be an existing issue discussing it.
- **Applies to:**
  - `**`
- **Condition:** when the PR adds a new feature
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-c2ce020838cb246e854f6e7b.md)

## Rule

- **Rule:** The setuptools package configuration declares the single package "outlines" for packaging.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c7546b64b991ae7768a7635c.md)

## Rule

- **Rule:** Read the Docs installs the project from the repository root via pip with the rtd extra requirements.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c759ea903dbeedc65796da9a.md)

## Rule

- **Rule:** The ruff pre-commit hook runs with --config=pyproject.toml.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d27e8784d119ec3d74ac6de9.md)

## Rule

- **Rule:** Contributors using the VSCode DevContainer workflow must install the Dev Containers extension in VSCode.
- **Applies to:**
  - `**`
- **Condition:** when using the VSCode DevContainer workflow
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-d2a2f9c2fee35cdc4d291a05.md)

## Rule

- **Rule:**
  ```text
  The tests job uploads coverage data artifacts matching .coverage.*, ignoring missing files and including hidden files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dce384cbda35ba51bba2466e.md)

## Rule

- **Rule:**
  ```text
  diff_cover is configured with diff_range_notation = "..".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dfdf084ef96698b88fe16d3b.md)

## Rule

- **Rule:**
  ```text
  Coverage excludes lines matching "pragma: no cover", "if TYPE_CHECKING:", and "\\.\\.\\." from coverage measurement.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e0578452b76f2d5f764c7b99.md)

## Rule

- **Rule:** The tests job runs on ubuntu-latest with a Python version matrix of 3.10.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e44aca067b399f91690ebd5c.md)

## Rule

- **Rule:** Docstrings must follow the numpy style guide.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-e5c8b13584ad69b28b29ea57.md)

## Rule

- **Rule:** The coverage job uploads the htmlcov directory as the html-report artifact only when the job has failed.
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: ${{ failure() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e64684742e8cae00ed3726d3.md)

## Rule

- **Rule:** For all files, trailing whitespace is trimmed.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e8ae57cb96ec6d370fc12f41.md)

## Rule

- **Rule:**
  ```text
  Contributors using venv can create a virtual environment with `python -m venv .venv`.
  ```
- **Applies to:**
  - `**`
- **Condition:** when using venv
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f53f9bbd8b7ebfbdd8220c0d.md)

## Rule

- **Rule:** Changes must be covered by tests.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-f977b57de45d4dcfe29dfae9.md)
