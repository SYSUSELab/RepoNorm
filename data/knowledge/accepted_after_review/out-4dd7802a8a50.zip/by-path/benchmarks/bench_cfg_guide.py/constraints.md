# Constraints for `benchmarks/bench_cfg_guide.py`

## Rule

- **Rule:**
  ```text
  Benchmark setup must build the CFG guide from a named grammar in the shared benched_grammars mapping with a tiny tokenizer, establishing a prebuilt guide reused by measurement methods.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:** when adding or modifying CFG guide benchmark setup that constructs the guide under test
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0ba42394e3ac00177b0fdaa3.md)

## Rule

- **Rule:**
  ```text
  Benchmark methods that measure construction or run cost of guides/processors must be decorated with cache_disabled() so caching does not mask the measured cost.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** when adding or modifying a benchmark method that times or measures memory of guide/processor construction or execution
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4790f226366f7bb5558baaa5.md)

## Rule

- **Rule:** CFG guide benchmarks must use a fixed deterministic seed (42) and a fixed grammar set mapping "json" and "arithmetic" to outlines.grammars entries.
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:** When adding or modifying CFG guide benchmark grammars or random seeding.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5eba56e1206ee5ca0cd72156.md)

## Rule

- **Rule:**
  ```text
  Benchmark methods that measure guide or FSM construction must disable the caching layer (e.g. via @cache_disabled()) so the measurement reflects uncached construction cost.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark method that constructs a RegexGuide or builds an FSM from a schema/regex.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6c0c1278ce36c637bf73bf7a.md)

## Rule

- **Rule:** CFG guide benchmarks must use a tiny random GPT-2 tokenizer with 1000 vocabulary tokens for guide construction.
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:** When adding or modifying the tokenizer fixture used by CFG guide benchmarks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cd17311feb7c51ae508cd9d3.md)
