# Constraints for `benchmarks/bench_regex_guide.py`

## Rule

- **Rule:**
  ```text
  Benchmark methods that measure construction or run cost of guides/processors must be decorated with cache_disabled() so caching does not mask the measured cost.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** when adding or modifying a benchmark method that times or measures memory of guide/processor construction or execution
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4790f226366f7bb5558baaa5.md)

## Rule

- **Rule:**
  ```text
  Benchmark methods that measure guide or FSM construction must disable the caching layer (e.g. via @cache_disabled()) so the measurement reflects uncached construction cost.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark method that constructs a RegexGuide or builds an FSM from a schema/regex.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6c0c1278ce36c637bf73bf7a.md)
