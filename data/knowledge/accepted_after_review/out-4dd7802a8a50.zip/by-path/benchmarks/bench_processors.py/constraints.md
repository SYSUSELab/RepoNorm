# Constraints for `benchmarks/bench_processors.py`

## Rule

- **Rule:** Benchmarks that exercise optional backends (mlx, jax) must guard imports with try/except ImportError and expose an availability predicate, so the benchmark tolerates missing backends instead of failing at import time.
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** when adding or modifying benchmark code that imports an optional backend such as mlx or jax
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-11d5231ffd25089457542f71.md)

## Rule

- **Rule:**
  ```text
  Mock processor inputs must be generated per array library with logits shaped (4, num_tokens) and input ids shaped (4, 2048), deriving the torch device from the library name suffix (defaulting to cpu) and raising ValueError for unrecognized libraries.
  ```
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying mock input generation for a new or existing array library in the processor benchmark.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1ae36cc9f4db442cfa9516aa.md)

## Rule

- **Rule:**
  ```text
  Benchmark methods that measure processor cost must invoke the logits processor directly on precomputed input_ids and logits, avoiding model inference, so the measurement isolates processor overhead.
  ```
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** when adding or modifying a benchmark method that measures logits processor cost
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b5d735f2dbae37c720bac500.md)

## Rule

- **Rule:**
  ```text
  The processor benchmark passthrough timing method must call self.logits_processor(self.input_ids, self.logits) to define the passthrough timing harness.
  ```
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying the passthrough timing method of the logits-processor benchmark.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c3080ca6212a1d9eec045232.md)
