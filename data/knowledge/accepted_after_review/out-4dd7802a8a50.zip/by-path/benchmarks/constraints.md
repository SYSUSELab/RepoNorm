# Constraints for `benchmarks`

## Rule

- **Rule:**
  ```text
  Run the JSON Schema benchmark with `asv run --config benchmarks/asv.conf.json --profile -b bench_json_schema.JsonSchemaBenchmark.time_json_schema_to_fsm`.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-049555d4cc6c5183c631c5b0.md)

## Rule

- **Rule:**
  ```text
  Run benchmarks with `asv run --config benchmarks/asv.conf.json`.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3b75c66be38441532ff4aad4.md)

## Rule

- **Rule:**
  ```text
  Run `asv continuous origin/main HEAD --config benchmarks/asv.conf.json` to run continuous benchmarks comparing origin/main against HEAD using the benchmarks/asv.conf.json configuration.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6c3e0da46461f491287e4712.md)

## Rule

- **Rule:**
  ```text
  Run the JSON schema benchmark with `asv run --config benchmarks/asv.conf.json -b bench_json_schema.JsonSchemaBenchmark.time_json_schema_to_fsm`.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8b4451df813a2c126caa8ce8.md)

## Rule

- **Rule:**
  ```text
  On a device with CUDA, the `--launch-method spawn` argument must be added when running benchmarks.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Condition:** on a device with cuda
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-8be81f682e267159a29eb3d7.md)

## Rule

- **Rule:** Uncommitted code is not benchmarked; changes must be committed before benchmarking.
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-920173aca44ce23e2b0b57b3.md)
