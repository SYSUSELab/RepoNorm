# Constraints for `benchmarks/bench_json_schema.py`

## Rule

- **Rule:**
  ```text
  Benchmark methods that measure guide or FSM construction must disable the caching layer (e.g. via @cache_disabled()) so the measurement reflects uncached construction cost.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark method that constructs a RegexGuide or builds an FSM from a schema/regex.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6c0c1278ce36c637bf73bf7a.md)

## Rule

- **Rule:**
  ```text
  The JSON schema benchmark setup must initialize the tokenizer via setup_tokenizer() and select the schema from the schemas mapping by name.
  ```
- **Applies to:**
  - `benchmarks/bench_json_schema.py`
- **Condition:** When adding or modifying the setup of the JSON schema benchmark.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-871fe8f09a2e49c5cac94fe9.md)

## Rule

- **Rule:** The JSON-schema benchmark must exercise both schema reference dialects by defining a simple schema using $defs/$ref and a complex draft-04 schema using definitions/$ref.
- **Applies to:**
  - `benchmarks/bench_json_schema.py`
- **Condition:** when adding or modifying the schemas mapping in the JSON-schema benchmark
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-be2d73f0ad766f64372a008c.md)
