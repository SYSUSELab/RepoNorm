# Constraints for `.github/workflows/tests_nightly.yml`

## Rule

- **Rule:** On failure, the workflow sends a Slack notification using 8398a7/action-slack@v3 with the job status and commit, author, and ref fields.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Condition:** workflow predicate: failure()
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-072b7c6d4dee40f42ce4eabe.md)

## Rule

- **Rule:** The tests job matrix uses Python version "3.10".
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c57c5a8e17092324047a06b.md)

## Rule

- **Rule:**
  ```text
  The tests job provides OPENAI_API_KEY, ANTHROPIC_API_KEY, GEMINI_API_KEY, and DOTTXT_API_KEY environment variables sourced from repository secrets.
  ```
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1322d764e18227f1697db44a.md)

## Rule

- **Rule:**
  ```text
  The coverage file is set to `.coverage.${{ steps.matrix-id.outputs.id }}` for the test run.
  ```
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3a64c44d4199080f2b70fc8f.md)

## Rule

- **Rule:** The tests job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6ba3590d80e7473061a17c06.md)

## Rule

- **Rule:** The test environment is set up by upgrading pip, installing uv, creating a uv venv, and installing the package in editable mode with the test extra.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9955fd1044f9e17b67b409c5.md)

## Rule

- **Rule:**
  ```text
  Tests are run with `uv run pytest -x --cov=outlines`.
  ```
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bbf738bc6c074a2a320bf36a.md)

## Rule

- **Rule:** The tests job sets fail-fast to false in its strategy.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e237a5c603e87ad001400c32.md)

## Rule

- **Rule:** The workflow installs Ollama by running the install script, checking the version, and pulling the tinyllama model.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e78d68dcb12668e0d8ca91a2.md)

## Rule

- **Rule:**
  ```text
  The Nightly Tests workflow runs on a daily schedule defined by the cron expression "0 6 * * *".
  ```
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Condition:**
  ```text
  workflow predicate: schedule: - cron: "0 6 * * *"
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eb0afabdce46bda0bebfbd84.md)
