# Constraints for `.github/workflows/asv_benchmark_pr.yml`

## Rule

- **Rule:** The workflow runs asv compare with --factor=1.1 --no-stats --split upstream/main HEAD and fails the step if the output contains 'Benchmarks that have got worse'.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1d3060ebf3b4dfdb59871be4.md)

## Rule

- **Rule:** The benchmark-pr job runs only when the pull request has the 'run-benchmarks' label or the ref is refs/heads/main.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Condition:**
  ```text
  workflow predicate: ${{ contains(github.event.pull_request.labels.*.name, 'run-benchmarks') || github.ref == 'refs/heads/main' }}
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-22747b5e0fab8071a8eebb95.md)

## Rule

- **Rule:**
  ```text
  The Benchmark PR workflow runs on push, pull_request (types synchronize and labeled), and workflow_dispatch events.
  ```
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Condition:**
  ```text
  workflow predicate: push: pull_request: types: [synchronize, labeled] workflow_dispatch:
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2f8952fe4e9f72a4fd4707c9.md)

## Rule

- **Rule:** The workflow runs asv continuous comparing upstream/main to HEAD with --no-stats --interleave-rounds -a repeat=3, tolerating errors.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-91c0fd0bd91874aa837dd690.md)

## Rule

- **Rule:**
  ```text
  The workflow uses Python version 3.10 via the PYTHON_VERSION environment variable.
  ```
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a6edded01359df882cd70647.md)

## Rule

- **Rule:** The workflow installs asv, virtualenv, and lf-asv-formatter as dependencies.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d3eec24436358cbcb281e794.md)
