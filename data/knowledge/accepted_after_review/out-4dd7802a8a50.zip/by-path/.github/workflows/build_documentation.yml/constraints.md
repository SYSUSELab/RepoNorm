# Constraints for `.github/workflows/build_documentation.yml`

## Rule

- **Rule:** The documentation build job runs on ubuntu-latest and sets up Python 3.10.
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-68777781f1b2a589d44707cb.md)

## Rule

- **Rule:**
  ```text
  The Build the documentation workflow runs on pull requests targeting the main branch and on manual workflow_dispatch.
  ```
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c489cbccedb9eb4bbcf9d110.md)

## Rule

- **Rule:**
  ```text
  The documentation build step installs requirements-doc.txt via pip and runs mkdocs build, with GOOGLE_ANALYTICS_KEY supplied from the GOOGLE_ANALYTICS_KEY secret.
  ```
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e11cd27d5030b9dd1a3ba4d4.md)
