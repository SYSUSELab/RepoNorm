# Constraints for `.github/workflows/publish_documentation.yml`

## Rule

- **Rule:**
  ```text
  The publish_documentation workflow runs on workflow_dispatch, on pushes to the main branch, and on release events of type created.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: workflow_dispatch: push: branches: - main release: types: - created
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1c4cbdb00191b772187cef02.md)

## Rule

- **Rule:** The workflow sets up Python using actions/setup-python@v4 with python-version 3.x.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-49f8d8dd3d03dba64ebb900e.md)

## Rule

- **Rule:** The deploy job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6100fde14680245af321bf21.md)

## Rule

- **Rule:**
  ```text
  When the event is a release, the workflow runs mike deploy --push --update-aliases ${{ github.ref_name }} latest and mike set-default --push latest, with GOOGLE_ANALYTICS_KEY set from secrets.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'release'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-66df36327254f2fc35b9eff1.md)

## Rule

- **Rule:** The workflow grants contents: write permission.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-67e2fb153fa07b68cd5daf89.md)

## Rule

- **Rule:**
  ```text
  When the event is a push, the workflow runs mike deploy --push --update-aliases ${{ github.ref_name }} unstable, with GOOGLE_ANALYTICS_KEY set from secrets.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-866ff7fbd6528a500ecaf4bb.md)

## Rule

- **Rule:** The workflow installs documentation dependencies with pip install -r requirements-doc.txt and builds the documentation with mkdocs build.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8d5d08abe81f10e2c88e7786.md)

## Rule

- **Rule:** The workflow checks out the repository with actions/checkout@v4 using fetch-depth: 0.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ad74ed40b50f1afe825e06ca.md)

## Rule

- **Rule:**
  ```text
  The workflow caches the .cache path using actions/cache@v3 with key mkdocs-material-${{ env.cache_id }} and restore-keys mkdocs-material-.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b1ae5e76cf1515d825c6d87a.md)

## Rule

- **Rule:** The workflow configures git user.name and user.email from the github.actor before publishing.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc214b2c6b4f76eae93004b4.md)
