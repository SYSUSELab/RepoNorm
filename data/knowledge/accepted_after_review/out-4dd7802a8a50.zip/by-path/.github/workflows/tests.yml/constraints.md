# Constraints for `.github/workflows/tests.yml`

## Rule

- **Rule:** The style job runs pre-commit/action@v3.0.0 on ubuntu-latest with Python 3.10.
- **Applies to:**
  - `.github/workflows/tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95b9efee8bdf61eb1ebd7da0.md)
