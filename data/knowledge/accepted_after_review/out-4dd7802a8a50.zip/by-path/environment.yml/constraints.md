# Constraints for `environment.yml`

## Rule

- **Rule:**
  ```text
  The environment installs the local project in editable mode with its test extras via pip (-e ".[test]").
  ```
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0546bd20f185ba96d4684b2f.md)

## Rule

- **Rule:** The conda environment is named dottxt-ai.
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5df8caab9d60eef0a9e5808d.md)
