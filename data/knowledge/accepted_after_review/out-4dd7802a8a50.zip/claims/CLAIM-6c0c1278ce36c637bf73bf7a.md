# Rule details

- **Rule:**
  ```text
  Benchmark methods that measure guide or FSM construction must disable the caching layer (e.g. via @cache_disabled()) so the measurement reflects uncached construction cost.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark method that constructs a RegexGuide or builds an FSM from a schema/regex.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `benchmarks/bench_cfg_guide.py:50-52`
- `benchmarks/bench_json_schema.py:74-77`
- `benchmarks/bench_regex_guide.py:26-28`
