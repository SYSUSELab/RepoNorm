# Rule details

- **Rule:** Benchmarks fail if performance degrades by more than 10% for any individual benchmark.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- Benchmarks fail if performance degrades by more than 10% for any individual benchmark.

```

- **Sources:**
  - `docs/community/contribute.md:143`

## Review evidence locations

- `docs/community/contribute.md:139-144`
