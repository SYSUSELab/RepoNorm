# Rule details

- **Rule:** Tests that exercise a model adapter's streaming entry point for a vision (v0) adapter must expect NotImplementedError with the message 'Streaming is not implemented for Transformers models'; do not add streaming support expectations for vision adapters without changing that contract.
- **Applies to:**
  - `tests/v0_legacy/generate/test_api_legacy.py`
- **Condition:** When modifying or extending the legacy v0 vision adapter streaming test.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test asserts that calling stream on the vision v0 adapter raises NotImplementedError with the Transformers streaming message, matching the streaming limitation contract.
```

- **Sources:**
  - `tests/v0_legacy/generate/test_api_legacy.py:174-186`
