# Rule details

- **Rule:**
  ```text
  When modifying `prioritize_tasks_fmt` in the babyagi example, preserve the numbered-line parsing contract: split on the first '.', require exactly two parts, cast the prefix to int, and silently drop lines without a period.
  ```
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When editing the babyagi task-prioritization parsing function.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/babyagi.py:38-49`
