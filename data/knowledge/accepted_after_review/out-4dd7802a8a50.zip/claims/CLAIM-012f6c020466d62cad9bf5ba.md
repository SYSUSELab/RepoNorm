# Rule details

- **Rule:**
  ```text
  Run `pre-commit run --all-files` to execute pre-commit hooks across all files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
pre-commit run --all-files

```

- **Sources:**
  - `docs/community/contribute.md:102`

## Review evidence locations

- `docs/community/contribute.md:91-103`
