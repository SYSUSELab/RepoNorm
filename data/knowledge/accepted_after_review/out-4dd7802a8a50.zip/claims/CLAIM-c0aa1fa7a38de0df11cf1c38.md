# Rule details

- **Rule:** The mypy pre-commit hook installs types-tqdm and types-Pillow as additional dependencies.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      additional_dependencies: [types-tqdm, types-Pillow]

```

- **Sources:**
  - `.pre-commit-config.yaml:15`

## Review evidence locations

- `.pre-commit-config.yaml:9-15`
