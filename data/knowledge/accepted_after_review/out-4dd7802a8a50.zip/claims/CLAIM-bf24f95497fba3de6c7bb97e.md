# Rule details

- **Rule:**
  ```text
  SteerableGenerator call must return a string when invoked with a Literal output type and max_new_tokens, verifying the callable interface returns text.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** when modifying SteerableGenerator callable interface or its return type
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generator.py:251-269`
- `tests/test_generator.py:134-137`
