# Rule details

- **Rule:**
  ```text
  Install dependencies in editable mode with test extras via `pip install -e ".[test]"`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
pip install -e ".[test]"

```

- **Sources:**
  - `docs/community/contribute.md:52`

## Review evidence locations

- `docs/community/contribute.md:49-54`
