# Rule details

- **Rule:**
  ```text
  Changes to the legacy generation adapter must preserve the model-specific parameter adapter dispatch: create_inference_params selects an adapter via isinstance checks over LlamaCpp, VLLMOffline, Transformers, ExLlamaV2Model, and MLXLM, and GeneratorV0Adapter.stream must continue to build inference params through create_inference_params before forwarding prompts.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:**
  ```text
  When adding a new model backend or modifying GeneratorV0Adapter.create_inference_params or GeneratorV0Adapter.stream in outlines/v0_legacy/generate/api.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/generate/api.py:53-81`
- `outlines/v0_legacy/generate/api.py:83-115`
