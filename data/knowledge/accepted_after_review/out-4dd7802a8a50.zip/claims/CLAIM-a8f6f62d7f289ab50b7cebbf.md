# Rule details

- **Rule:**
  ```text
  The legacy json generation test module must define a JSON_SCHEMA_STRING constant describing an object with a required string `foo` property, and reuse it as the canonical schema fixture across legacy json generation tests.
  ```
- **Applies to:**
  - `tests/v0_legacy/generate/test_json_legacy.py`
- **Condition:** when adding or modifying legacy json generation tests that need a JSON schema fixture
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The legacy json generation test module defines a module-level JSON_SCHEMA_STRING constant for an object with a required string foo property and reuses it across tests.
```

- **Sources:**
  - `tests/v0_legacy/generate/test_json_legacy.py`
