# Rule details

- **Rule:**
  ```text
  _handle_union must special-case Optional[T] (two args including None) into an Alternatives of the inner type and String("None"), defining how optional Python types map to DSL terms.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** when modifying how union or optional Python types are translated into DSL terms
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/dsl.py:718-730`
