# Rule details

- **Rule:**
  ```text
  The TransformerTokenizer.convert_token_to_string must prepend a space for Llama tokenizers when the token starts with SPIECE_UNDERLINE or equals "<0x20>", as a documented workaround for missing spaces in HF Llama tokenizers.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying token-to-string conversion for Llama-family tokenizers.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/transformers.py:96-106`
