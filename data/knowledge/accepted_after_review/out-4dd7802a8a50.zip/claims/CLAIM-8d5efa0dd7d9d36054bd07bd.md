# Rule details

- **Rule:**
  ```text
  When modifying TypedDict handling in outlines/types/utils.py, preserve the version compatibility boundary: import _TypedDictMeta from typing on Python >= 3.12 and from typing_extensions otherwise.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  changing the import of _TypedDictMeta or TypedDict handling in outlines/types/utils.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/utils.py:27-30`
