# Rule details

- **Rule:**
  ```text
  Changes to the legacy Transformers vision model constructor must preserve its in-place processor mutation: it forces padding_side = "left" and pad_token = "[PAD]" on the supplied processor before calling the base initializer, so callers must expect their processor object to be modified.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers_vision.py`
- **Condition:**
  ```text
  When modifying TransformersVision.__init__ in outlines/v0_legacy/models/transformers_vision.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/models/transformers_vision.py:13-21`
