# Rule details

- **Rule:**
  ```text
  The legacy format test must assert that calling format(model, int) emits a DeprecationWarning matching "The `format` function is deprecated" and returns a GeneratorVisionV0Adapter with a SteerableGenerator and RegexLogitsProcessor.
  ```
- **Applies to:**
  - `tests/v0_legacy/generate/test_format_legacy.py`
- **Condition:** when adding or modifying a legacy format deprecation test
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/v0_legacy/generate/test_format_legacy.py:59-75`
