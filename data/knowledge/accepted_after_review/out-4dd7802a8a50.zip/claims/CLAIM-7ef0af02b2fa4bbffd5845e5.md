# Rule details

- **Rule:**
  ```text
  Type-dispatch helpers in outlines.types.utils must keep their documented detection semantics: is_callable excludes class objects, is_union matches only typing.Union origins (not PEP 604 X | Y), is_pydantic_model returns False for generic origins as a pre-3.11 guard, is_str accepts str, str-origin generics, Annotated[str, ...], and NewType-like __supertype__ str, and is_typing_dict matches dict origins.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:** When modifying or extending the type-detection helpers used by the type dispatch layer.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/utils.py:62-68`
- `outlines/types/utils.py:104-121`
- `outlines/types/utils.py:132-149`
