# Rule details

- **Rule:**
  ```text
  The multimodal vision choice test must call the model with a dict containing text with an <image> placeholder and an images entry plus a Foo output type, asserting the result is a string restricted to the allowed choices cat or dog.
  ```
- **Applies to:**
  - `tests/models/test_transformers_multimodal.py`
- **Condition:** when adding or modifying a multimodal vision choice test
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_transformers_multimodal.py:143-154`
