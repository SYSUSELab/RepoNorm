# Rule details

- **Rule:**
  ```text
  Mock processor inputs must be generated per array library with logits shaped (4, num_tokens) and input ids shaped (4, 2048), deriving the torch device from the library name suffix (defaulting to cpu) and raising ValueError for unrecognized libraries.
  ```
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** When adding or modifying mock input generation for a new or existing array library in the processor benchmark.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `benchmarks/bench_processors.py:35-67`
