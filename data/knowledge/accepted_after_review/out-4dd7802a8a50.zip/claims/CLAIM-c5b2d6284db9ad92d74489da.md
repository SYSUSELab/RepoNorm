# Rule details

- **Rule:**
  ```text
  Tensor adapter implementations must provide argsort_descending with backend-appropriate descending-sort semantics (e.g., negating the tensor before numpy.argsort, or using tf.argsort with direction='DESCENDING'), not a plain ascending sort.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/**/*.py`
- **Condition:**
  ```text
  When adding or modifying a tensor adapter's argsort_descending method.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/processors/test_tensor_adapters.py:267-276`
- `outlines/processors/tensor_adapters/numpy.py:49-50`
