# Rule details

- **Rule:**
  ```text
  When modifying `ParserLogitsProcessor.__call__` in the parsing example, preserve the invalid-token handling that catches `EOFError`, `UnexpectedToken`, `UnexpectedCharacters`, and `DedentError` as invalid-token signals; do not narrow the caught exception set without equivalent invalid-token coverage.
  ```
- **Applies to:**
  - `examples/parsing.py`
- **Condition:** When editing the parser logits processor's token-masking loop or its exception handling.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
ParserLogitsProcessor.__call__ masks next tokens by re-parsing the vocabulary per step and catches EOFError, UnexpectedToken, UnexpectedCharacters, and DedentError as invalid-token signals, matching the rule.
```

- **Sources:**
  - `examples/parsing.py:49-90`
