# Rule details

- **Rule:**
  ```text
  Template.from_string must build a template via build_template_from_string(content, filters) and pass None as the second constructor argument, defining the string-based template construction path.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  When modifying Template.from_string or the string-based template construction path.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/templates.py:80-96`
