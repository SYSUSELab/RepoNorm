# Rule details

- **Rule:** pre-commit must be installed and configured locally, and run before opening the PR.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- [ ] `pre-commit` is installed and configured on your machine, and you ran it before opening the PR;

```

- **Sources:**
  - `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:14`

## Review evidence locations

- `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:12-15`
