# Rule details

- **Rule:** Legacy v0 generate functions (choice, format, regex) must emit a DeprecationWarning stating removal in v1.1.0 and directing users to the current Generator API; format and regex must raise NotImplementedError for OpenAI models, and regex must return GeneratorVisionV0Adapter for TransformersVision models and GeneratorV0Adapter otherwise.
- **Applies to:**
  - `outlines/v0_legacy/generate/**/*.py`
- **Condition:**
  ```text
  When modifying or adding a legacy v0 generate function under outlines/v0_legacy/generate, preserve the v1.1.0 removal DeprecationWarning, the Generator migration guidance, and the model-type-specific NotImplementedError or adapter return behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/generate/choice.py:19-68`
- `outlines/v0_legacy/generate/format.py:15-70`
- `outlines/v0_legacy/generate/regex.py:13-67`
