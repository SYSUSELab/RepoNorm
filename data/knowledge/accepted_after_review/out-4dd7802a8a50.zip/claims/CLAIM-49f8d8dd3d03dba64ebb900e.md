# Rule details

- **Rule:** The workflow sets up Python using actions/setup-python@v4 with python-version 3.x.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: actions/setup-python@v4
        with:
          python-version: 3.x

```

- **Sources:**
  - `.github/workflows/publish_documentation.yml:22-24`
