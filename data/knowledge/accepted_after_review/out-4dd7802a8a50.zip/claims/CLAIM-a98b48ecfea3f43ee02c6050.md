# Rule details

- **Rule:** The coverage job fetches the comparison branch from origin with --no-tags and --prune.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: |
          git fetch --no-tags --prune origin ${COMPARE_BRANCH#origin/}

```

- **Sources:**
  - `.github/workflows/tests.yml:105-106`

## Review evidence locations

- `.github/workflows/tests.yml:90-106`
