# Rule details

- **Rule:** mypy enables the incomplete feature "Unpack".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
enable_incomplete_feature = ["Unpack"]

```

- **Sources:**
  - `pyproject.toml:127`

## Review evidence locations

- `pyproject.toml:125-127`
