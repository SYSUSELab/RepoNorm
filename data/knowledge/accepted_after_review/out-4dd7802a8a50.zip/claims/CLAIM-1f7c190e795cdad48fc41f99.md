# Rule details

- **Rule:** Contributors using the VSCode DevContainer workflow must run the normal setup steps.
- **Applies to:**
  - `**`
- **Condition:** when using the vscode devcontainer workflow
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
4. Run the normal setup steps. Your environment will not complain about missing system dependencies!

```

- **Sources:**
  - `docs/community/contribute.md:80`

## Review evidence locations

- `docs/community/contribute.md:75-80`
