# Rule details

- **Rule:**
  ```text
  The legacy extract_function_from_file must execute downloaded file content via exec and validate that the named attribute is an instance of outlines.Function, raising AttributeError or TypeError otherwise.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying extract_function_from_file or its validation of downloaded function content.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/function.py:147-168`
