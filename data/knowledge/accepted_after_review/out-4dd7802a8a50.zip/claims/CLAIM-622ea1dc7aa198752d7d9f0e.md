# Rule details

- **Rule:**
  ```text
  The llamacpp_params_adapter must map None stop/seed to absent values and None max_tokens to -1, while passing explicit values through unchanged.
  ```
- **Applies to:**
  - `tests/v0_legacy/models/test_llamacpp_legacy.py`
- **Condition:**
  ```text
  when modifying llamacpp_params_adapter or the tests that pin its None-handling defaults
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/v0_legacy/models/test_llamacpp_legacy.py:48-65`
