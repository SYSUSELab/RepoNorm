# Rule details

- **Rule:** The MockStreamingChunk test helper must initialize choices to an empty list when content is None and otherwise build a single MagicMock choice whose delta.content is the supplied content, preserving the mock streaming chunk shape used by OpenAI streaming tests.
- **Applies to:**
  - `tests/test_utils/mock_openai_client.py`
- **Condition:** when modifying MockStreamingChunk or the OpenAI streaming test helpers
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
MockStreamingChunk sets choices to an empty list when content is None and otherwise builds a single MagicMock choice whose delta.content is the supplied content.
```

- **Sources:**
  - `tests/test_utils/mock_openai_client.py`
