# Rule details

- **Rule:**
  ```text
  Tests for args_prompt must assert exact formatting of function arguments including annotations and defaults, and must wrap the assertions in pytest.deprecated_call() to pin the deprecation status of args_prompt.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  when adding or modifying tests for args_prompt formatting or deprecation
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_templates.py:344-403`
