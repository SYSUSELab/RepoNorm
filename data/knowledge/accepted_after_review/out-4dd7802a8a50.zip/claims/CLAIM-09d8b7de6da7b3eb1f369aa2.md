# Rule details

- **Rule:**
  ```text
  Async SGLang CFG tests must assert that generating with CFG(EBNF_YES_NO_GRAMMAR) and max_tokens=10 returns a string restricted to "yes" or "no", pinning grammar-constrained output behavior.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** when adding or modifying an async SGLang CFG test
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_sglang.py:19-22`
- `tests/models/test_sglang.py:268-272`
