# Rule details

- **Rule:**
  ```text
  The tests job runs pytest with -x, coverage over the outlines package, and excludes tests marked api_call.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      run: |
        uv run pytest -x --cov=outlines -m 'not api_call'

```

- **Sources:**
  - `.github/workflows/tests.yml:53-54`
