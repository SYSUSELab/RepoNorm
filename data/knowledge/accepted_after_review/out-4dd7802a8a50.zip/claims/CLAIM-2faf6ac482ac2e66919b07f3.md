# Rule details

- **Rule:**
  ```text
  When modifying the Modal example's `generate` function, keep the remote-deployment call pattern: decorate with `@app.function(image=outlines_image, gpu="A100-40GB")` and construct the model inside the function via `outlines.from_transformers` with keyword `tokenizer` and `model` arguments.
  ```
- **Applies to:**
  - `examples/modal_example.py`
- **Condition:** When editing the Modal example's function decoration or model construction.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The generate function in examples/modal_example.py is decorated with @app.function(image=outlines_image, gpu="A100-40GB") and constructs the model inside via outlines.from_transformers with keyword tokenizer and model arguments.
```

- **Sources:**
  - `examples/modal_example.py:64-81`
