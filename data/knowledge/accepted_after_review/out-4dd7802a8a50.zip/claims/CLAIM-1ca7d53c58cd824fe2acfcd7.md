# Rule details

- **Rule:** Template tests must define an outlines.prompt function whose template uses the name and signature filters on a function argument, documenting the template filter protocol for function metadata.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** When adding or modifying template tests that exercise the name and signature filters on function arguments.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_templates.py:240-279`
