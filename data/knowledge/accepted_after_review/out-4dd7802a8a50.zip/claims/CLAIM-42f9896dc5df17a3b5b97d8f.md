# Rule details

- **Rule:** Tests that exercise the outlines.prompt decorator's filters mapping must register custom Jinja filters via the filters keyword argument and apply them in the docstring template.
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when adding or modifying a test that registers custom Jinja filters for the outlines.prompt decorator
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_templates.py:406-422`
