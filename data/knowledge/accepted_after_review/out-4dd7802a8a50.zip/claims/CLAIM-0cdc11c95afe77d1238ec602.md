# Rule details

- **Rule:** Tests for LlamaCpp streaming choice must assert that the first streamed token is one of the allowed Literal values, preserving constrained streaming output membership.
- **Applies to:**
  - `tests/models/test_llamacpp.py`
- **Condition:** When modifying or extending the LlamaCpp streaming choice test.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test streams with a Foo choice type and asserts the first streamed token is in the allowed Literal values ("B", "F").
```

- **Sources:**
  - `tests/models/test_llamacpp.py:118-126`
