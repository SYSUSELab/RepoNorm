# Rule details

- **Rule:** docformatter is configured with in-place = true.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
in-place = true

```

- **Sources:**
  - `pyproject.toml:212`

## Review evidence locations

- `pyproject.toml:210-212`
