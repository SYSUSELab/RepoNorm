# Rule details

- **Rule:**
  ```text
  Mock TGI client responses must be stored keyed by hash_dict(kwargs) so that mock lookup depends on hashing the request kwargs; contributors adding mocks must ensure kwargs hash consistently with lookup.
  ```
- **Applies to:**
  - `tests/test_utils/mock_tgi_client.py`
- **Condition:** When adding or modifying mock response registration or lookup in the mock TGI client.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils/mock_tgi_client.py:7-31`
- `tests/test_utils/mock_tgi_client.py:34-58`
