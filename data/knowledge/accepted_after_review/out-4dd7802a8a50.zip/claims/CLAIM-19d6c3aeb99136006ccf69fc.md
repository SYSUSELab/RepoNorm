# Rule details

- **Rule:** The Tests workflow runs on pushes to the main branch.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  push:
    branches: [main]

```

- **Sources:**
  - `.github/workflows/tests.yml:6-7`

## Review evidence locations

- `.github/workflows/tests.yml:1-7`
