# Rule details

- **Rule:** GeneratorV0Adapter is the bridge between legacy v0 generate functions and the current Generator object: legacy functions return this adapter, which stores a current Generator and delegates calls to it; its constructor must reject models that are not V0GeneratorModel with ValueError.
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:** When modifying GeneratorV0Adapter or the legacy generate functions that return it, preserve the adapter's role as a delegating wrapper around a current Generator and the ValueError guard rejecting non-V0GeneratorModel inputs.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/generate/api.py:21-48`
- `outlines/v0_legacy/generate/api.py:83-100`
