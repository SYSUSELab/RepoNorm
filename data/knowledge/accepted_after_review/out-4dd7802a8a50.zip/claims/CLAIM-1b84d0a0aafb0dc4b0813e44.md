# Rule details

- **Rule:**
  ```text
  PartialLexerThread.__repr__ must include both the lexer and state representations, providing a stable debug string format for parser state.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying PartialLexerThread.__repr__ or the debug string format for parser state.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/fsm/parsing.py:155-160`
