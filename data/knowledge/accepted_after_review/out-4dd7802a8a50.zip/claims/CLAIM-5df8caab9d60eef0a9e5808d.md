# Rule details

- **Rule:** The conda environment is named dottxt-ai.
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
name: dottxt-ai

```

- **Sources:**
  - `environment.yml:6`

## Review evidence locations

- `environment.yml:1-6`
