# Rule details

- **Rule:** When adding a new tensor backend adapter, register it in the tensor adapter registry dict and extend the adapter Union type so both the runtime lookup and the static type cover the new backend.
- **Applies to:**
  - `outlines/processors/tensor_adapters/__init__.py`
- **Condition:** Adding or renaming a tensor backend adapter in the tensor adapter registry.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The tensor adapter registry dict maps each backend name to its adapter class and the adapter Union type covers the same set of adapters.
```

- **Sources:**
  - `outlines/processors/tensor_adapters/__init__.py`
