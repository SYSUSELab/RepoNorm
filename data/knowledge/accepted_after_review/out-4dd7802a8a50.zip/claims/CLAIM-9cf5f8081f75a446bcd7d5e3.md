# Rule details

- **Rule:** The legacy generate API must enumerate V0GeneratorModel as a Union of ExLlamaV2Model, LlamaCpp, MLXLM, Transformers, TransformersVision, and VLLMOffline, defining the model backends the v0 compatibility layer supports.
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:** When modifying V0GeneratorModel or the set of model backends supported by the v0 compatibility layer.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/generate/api.py:14-28`
