# Rule details

- **Rule:**
  ```text
  The session-scoped `image` fixture in OpenAI vision tests must build a 1x1 white RGB image, save it to an in-memory PNG buffer, seek to 0, and reopen it with PIL so the returned image carries a PNG format attribute.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying OpenAI vision tests that need a format-bearing image fixture
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_openai.py:33-45`
