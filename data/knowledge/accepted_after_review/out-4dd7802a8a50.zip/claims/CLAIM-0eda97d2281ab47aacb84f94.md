# Rule details

- **Rule:** Example scripts that demonstrate BentoML model packaging must import a HuggingFace model and tokenizer and save both into a BentoML model reference path, establishing the expected artifact layout.
- **Applies to:**
  - `examples/bentoml/import_model.py`
- **Condition:** When adding or modifying the BentoML model import example.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/bentoml/import_model.py:7-20`
