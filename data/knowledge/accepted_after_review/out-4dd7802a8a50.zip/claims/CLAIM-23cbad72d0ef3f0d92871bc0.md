# Rule details

- **Rule:**
  ```text
  The transformers logits-processor handoff must wrap a provided OutlinesLogitsProcessor in a transformers LogitsProcessorList and return None when no output_type is given.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying the transformers adapter's format_output_type handoff to the logits processor
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/transformers.py:162-183`
