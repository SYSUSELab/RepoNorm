# Rule details

- **Rule:**
  ```text
  Tests that exercise the legacy v0 generation API must import adapters from `outlines.v0_legacy.generate.api` and must assert the documented legacy deprecation behavior: calling the legacy `text` function emits a `DeprecationWarning` matching "The `text` function is deprecated" and returns the underlying model instance unchanged.
  ```
- **Applies to:**
  - `tests/v0_legacy/generate/test_text_legacy.py`
- **Condition:**
  ```text
  When modifying or extending legacy v0 generation tests under tests/v0_legacy/generate/.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/v0_legacy/generate/test_text_legacy.py:6-12`
- `tests/v0_legacy/generate/test_text_legacy.py:45-52`
