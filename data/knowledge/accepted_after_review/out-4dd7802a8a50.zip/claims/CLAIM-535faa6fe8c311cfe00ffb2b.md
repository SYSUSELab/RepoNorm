# Rule details

- **Rule:**
  ```text
  The VLLM wrapper must support construction without an explicit model name; tests construct VLLM from an openai_client without a model name.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when modifying or adding VLLM wrapper tests that construct the wrapper without a model name
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_vllm.py:140-157`
