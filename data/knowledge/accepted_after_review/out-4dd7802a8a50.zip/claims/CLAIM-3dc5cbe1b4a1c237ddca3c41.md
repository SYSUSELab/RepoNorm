# Rule details

- **Rule:** The mypy pre-commit hook excludes files under the examples/ directory.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      exclude: ^examples/

```

- **Sources:**
  - `.pre-commit-config.yaml:14`
