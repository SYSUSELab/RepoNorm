# Rule details

- **Rule:** The vllm offline tests define a Character pydantic model with a single name: str field, the minimal structured output used in those tests.
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** when modifying or adding the Character pydantic model or tests that depend on it
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_vllm_offline.py:70-75`
