# Rule details

- **Rule:**
  ```text
  Changes to the legacy TransformersVision._prepare_model_inputs must preserve formatting input via the type adapter, running the processor with padding=True and return_tensors="pt", moving results to the model device, and returning the original model_input["text"] alongside processed inputs.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers_vision.py`
- **Condition:**
  ```text
  When modifying TransformersVision._prepare_model_inputs or its processor invocation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The file contains TransformersVision._prepare_model_inputs, whose body formats input via the type adapter, calls the processor with padding=True and return_tensors="pt", moves results to the model device, and returns model_input["text"] alongside the processed inputs.
```

- **Sources:**
  - `outlines/v0_legacy/models/transformers_vision.py`
