# Rule details

- **Rule:**
  ```text
  BlackBoxGenerator initialization must store the provided model and output_type unchanged, pinning the constructor's attribute contract.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** when modifying BlackBoxGenerator constructor or its stored attributes
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generator.py:38-50`
- `tests/test_generator.py:151-154`
