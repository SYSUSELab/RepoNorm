# Rule details

- **Rule:** Tests that exercise Application generator reuse must assert that calling Application twice with the same model reuses the same generator and model instances, while a different model replaces both.
- **Applies to:**
  - `tests/test_applications.py`
- **Condition:** when adding or modifying a test that exercises Application generator reuse across model instances
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/applications.py:96-107`
- `tests/test_applications.py:77-93`
