# Rule details

- **Rule:** CFG guide benchmarks must use a fixed deterministic seed (42) and a fixed grammar set mapping "json" and "arithmetic" to outlines.grammars entries.
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:** When adding or modifying CFG guide benchmark grammars or random seeding.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `benchmarks/bench_cfg_guide.py:1-23`
