# Rule details

- **Rule:**
  ```text
  Template.from_file must yield a template with signature None, and rendering it with examples and a question must produce the exact expected multi-line prompt text; this file-template rendering format must be preserved when changing Template.from_file or prompt rendering.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:**
  ```text
  When modifying Template.from_file or the prompt rendering format for file-based templates.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_templates.py:466-487`
