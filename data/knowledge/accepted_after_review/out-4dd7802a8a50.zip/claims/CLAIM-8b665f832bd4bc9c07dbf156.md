# Rule details

- **Rule:** Open a pull request on GitHub after pushing the branch; subsequent changes made on the branch update the pull request.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Then you can [open a pull request][pull-requests] on GitHub. It should prompt you to do so. Every subsequent change that you make on your branch will update the pull request.

```

- **Sources:**
  - `docs/community/contribute.md:174`

## Review evidence locations

- `docs/community/contribute.md:163-176`
