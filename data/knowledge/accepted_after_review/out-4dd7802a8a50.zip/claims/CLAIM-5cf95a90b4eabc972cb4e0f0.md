# Rule details

- **Rule:** Coverage reports use relative file paths.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
relative_files = true

```

- **Sources:**
  - `pyproject.toml:196`

## Review evidence locations

- `pyproject.toml:195-196`
