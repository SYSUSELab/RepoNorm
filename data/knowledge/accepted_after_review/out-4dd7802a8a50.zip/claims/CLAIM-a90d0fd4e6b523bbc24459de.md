# Rule details

- **Rule:**
  ```text
  Async tests for the SGLang model must be marked `@pytest.mark.asyncio` and must assert that awaiting the async model with `n=2` returns a list of length 2 of `str` elements.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** When modifying or extending async SGLang model tests under tests/models/.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_sglang.py:241-247`
