# Rule details

- **Rule:** The benchmark test suite can be run locally with a command.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

````text
You can run the benchmark test suite locally with the following command:

```shell

````

- **Sources:**
  - `docs/community/contribute.md:109-111`

## Review evidence locations

- `docs/community/contribute.md:105-113`
