# Rule details

- **Rule:**
  ```text
  When using uv, create a new virtual environment by running `uv venv` and then `source .venv/bin/activate`.
  ```
- **Applies to:**
  - `**`
- **Condition:** when using uv
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

````text
*If you are using `uv`*:

```shell
uv venv
source .venv/bin/activate

````

- **Sources:**
  - `docs/community/contribute.md:28-32`

## Review evidence locations

- `docs/community/contribute.md:26-34`
