# Rule details

- **Rule:**
  ```text
  The workflow caches the .cache path using actions/cache@v3 with key mkdocs-material-${{ env.cache_id }} and restore-keys mkdocs-material-.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: actions/cache@v3
        with:
          key: mkdocs-material-${{ env.cache_id }}
          path: .cache
          restore-keys: |
            mkdocs-material-

```

- **Sources:**
  - `.github/workflows/publish_documentation.yml:26-31`
