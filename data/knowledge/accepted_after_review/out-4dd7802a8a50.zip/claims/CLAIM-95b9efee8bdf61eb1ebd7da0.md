# Rule details

- **Rule:** The style job runs pre-commit/action@v3.0.0 on ubuntu-latest with Python 3.10.
- **Applies to:**
  - `.github/workflows/tests.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        python-version: "3.10"

```

- **Sources:**
  - `.github/workflows/tests.yml:17`

### Evidence 2 — explicit

```text
    - uses: pre-commit/action@v3.0.0

```

- **Sources:**
  - `.github/workflows/tests.yml:18`

## Review evidence locations

- `.github/workflows/tests.yml:9-18`
