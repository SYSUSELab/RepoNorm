# Rule details

- **Rule:**
  ```text
  Async model wrappers must return a plain string for a single prompt and a list of strings of length n when n>1; tests assert this return contract for vLLM and SGLang async models.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
  - `tests/models/test_vllm.py`
- **Condition:**
  ```text
  when modifying or adding async model call tests that assert the return type of awaiting a model with a single prompt or with n>1
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_vllm.py:255-285`
- `tests/models/test_sglang.py:223-247`
