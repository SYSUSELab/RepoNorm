# Rule details

- **Rule:**
  ```text
  Run the JSON schema benchmark with `asv run --config benchmarks/asv.conf.json -b bench_json_schema.JsonSchemaBenchmark.time_json_schema_to_fsm`.
  ```
- **Applies to:**
  - `benchmarks/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
asv run --config benchmarks/asv.conf.json -b bench_json_schema.JsonSchemaBenchmark.time_json_schema_to_fsm

```

- **Sources:**
  - `docs/community/contribute.md:123`

## Review evidence locations

- `docs/community/contribute.md:120-124`
