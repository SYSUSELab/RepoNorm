# Rule details

- **Rule:**
  ```text
  Tests that exercise the outlines cache must reset the module-level cache state before running: delete all 'outlines' entries from sys.modules and unset OUTLINES_CACHE_DIR, because the cache is held in a module variable that persists across tests.
  ```
- **Applies to:**
  - `tests/test_cache.py`
- **Condition:** when adding or modifying cache-related tests that depend on a clean cache state
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_cache.py:19-37`
- `tests/test_cache.py:40-50`
