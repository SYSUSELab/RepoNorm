# Rule details

- **Rule:**
  ```text
  SteerableGenerator.from_processor must set both logits_processor and model on the resulting generator, and must raise TypeError when given a non-processor output type such as Literal["foo", "bar"]; tests must pin both the construction contract and the rejection of non-processor output types.
  ```
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:**
  ```text
  when modifying SteerableGenerator.from_processor tests or the processor-acceptance and output-type validation behavior they exercise
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generator.py:226-249`
- `tests/test_generator.py:97-105`
