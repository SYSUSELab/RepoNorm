# Rule details

- **Rule:** Example scripts that demonstrate structured generation with a Mistral model must format the prompt using the Mistral instruction template before passing it to the generator.
- **Applies to:**
  - `examples/cerebrium/main.py`
- **Condition:** When adding or modifying an example that uses a Mistral model for structured generation.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The example uses a Mistral model and formats the prompt with the Mistral instruction template "<s>[INST]...[/INST]" before passing it to the generator.
```

- **Sources:**
  - `examples/cerebrium/main.py`
