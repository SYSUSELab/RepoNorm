# Rule details

- **Rule:**
  ```text
  The workflow uses Python version 3.10 via the PYTHON_VERSION environment variable.
  ```
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  PYTHON_VERSION: "3.10"

```

- **Sources:**
  - `.github/workflows/asv_benchmark_pr.yml:9`

## Review evidence locations

- `.github/workflows/asv_benchmark_pr.yml:8-10`
- `.github/workflows/asv_benchmark_pr.yml:39-42`
