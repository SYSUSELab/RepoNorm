# Rule details

- **Rule:**
  ```text
  Benchmark methods that measure processor cost must invoke the logits processor directly on precomputed input_ids and logits, avoiding model inference, so the measurement isolates processor overhead.
  ```
- **Applies to:**
  - `benchmarks/bench_processors.py`
- **Condition:** when adding or modifying a benchmark method that measures logits processor cost
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `benchmarks/bench_processors.py:93-99`
- `benchmarks/bench_processors.py:121-131`
