# Rule details

- **Rule:** The dev container enables the nvidia-cuda devcontainer feature with installToolkit set to true.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      "installToolkit": true,

```

- **Sources:**
  - `.devcontainer/devcontainer.json:14`

## Review evidence locations

- `.devcontainer/devcontainer.json:10-16`
