# Rule details

- **Rule:**
  ```text
  SGLang.generate_stream must build client args from model_input/output_type/inference_kwargs, request stream=True, and yield only chunks whose first choice delta content is not None, skipping empty deltas.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:** When modifying SGLang streaming request construction or chunk filtering.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/sglang.py:150-185`
