# Rule details

- **Rule:** PRs must include a high-level description of the changes.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- [ ] There is a high-level description of the changes;

```

- **Sources:**
  - `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:6`

## Review evidence locations

- `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:3-7`
