# Rule details

- **Rule:**
  ```text
  The legacy vectorize class must behave like numpy.vectorize for Python functions (executed in a for loop) but execute coroutines concurrently, with code adapted from numpy.lib.function_base.
  ```
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:** When modifying the legacy vectorize class or its handling of Python functions vs coroutines.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/base.py:21-33`
- `outlines/v0_legacy/base.py:239-296`
