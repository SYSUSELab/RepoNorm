# Rule details

- **Rule:** Tests for structured JSON output must assert that the generated result contains the required properties of the pydantic output type (for example the "name" field for a Character type), not merely that generation succeeds.
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** When adding or modifying a test that verifies structured JSON output for a pydantic output type.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_vllm_offline.py:70-75`
