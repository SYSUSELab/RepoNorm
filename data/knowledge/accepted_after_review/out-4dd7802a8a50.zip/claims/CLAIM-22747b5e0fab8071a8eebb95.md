# Rule details

- **Rule:** The benchmark-pr job runs only when the pull request has the 'run-benchmarks' label or the ref is refs/heads/main.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Condition:**
  ```text
  workflow predicate: ${{ contains(github.event.pull_request.labels.*.name, 'run-benchmarks') || github.ref == 'refs/heads/main' }}
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    if: ${{ contains(github.event.pull_request.labels.*.name, 'run-benchmarks') || github.ref == 'refs/heads/main' }}

```

- **Sources:**
  - `.github/workflows/asv_benchmark_pr.yml:26`

## Review evidence locations

- `.github/workflows/asv_benchmark_pr.yml:23-30`
