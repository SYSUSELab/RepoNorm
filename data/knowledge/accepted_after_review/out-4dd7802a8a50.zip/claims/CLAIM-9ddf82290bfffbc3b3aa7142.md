# Rule details

- **Rule:**
  ```text
  The legacy Function dataclass __post_init__ must call function_warning() so that use of the legacy function API emits a deprecation warning.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying the legacy Function dataclass initialization, preserve the function_warning() call that signals deprecation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/function.py:56-72`
