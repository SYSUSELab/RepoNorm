# Rule details

- **Rule:** The tests job installs Ollama and pulls the tinyllama model.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      run: |
        curl -fsSL https://ollama.com/install.sh | sh
        ollama --version
        ollama pull tinyllama

```

- **Sources:**
  - `.github/workflows/tests.yml:33-36`
