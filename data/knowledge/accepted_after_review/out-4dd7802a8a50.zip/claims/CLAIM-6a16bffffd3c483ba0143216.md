# Rule details

- **Rule:** The vLLM generate method must raise ValueError when any returned message carries a non-None refusal, and must return a single string for one choice or a list of strings for multiple choices.
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** when modifying vLLM response handling or the shape of generate's return value
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/vllm.py:124-137`
