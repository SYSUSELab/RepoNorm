# Rule details

- **Rule:**
  ```text
  Tests that exercise MLX-backed models must be gated with pytest.mark.skipif(not HAS_MLX, ...) so they are skipped on non-Apple-Silicon platforms.
  ```
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying a test that exercises an MLX-backed model
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_mlxlm.py:16-28`
- `tests/models/test_mlxlm.py:47-74`
- `tests/models/test_mlxlm.py:80-114`
