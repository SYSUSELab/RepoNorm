# Rule details

- **Rule:** The async black-box generator stream must yield string chunks as an AsyncGenerator; this async streaming interface contract must be preserved when changing async black-box generator streaming behavior.
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying the async black-box generator stream implementation or its test.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_generator.py:197-204`
