# Rule details

- **Rule:** The coverage job checks out the repository with fetch-depth 0.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: actions/checkout@v3
        with:
          fetch-depth: 0

```

- **Sources:**
  - `.github/workflows/tests.yml:73-75`

## Review evidence locations

- `.github/workflows/tests.yml:67-75`
