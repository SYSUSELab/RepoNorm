# Rule details

- **Rule:**
  ```text
  The llama.cpp tokenizer test must assert that `__setstate__` raises `NotImplementedError`, documenting that pickling/state restoration is unsupported for this tokenizer.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when adding or modifying llama.cpp tokenizer tests that cover state restoration or pickling
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/llamacpp.py:115-126`
- `tests/models/test_llamacpp_tokenizer.py:131-133`
