# Rule details

- **Rule:** docformatter is configured with style = "numpy".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
style = "numpy"

```

- **Sources:**
  - `pyproject.toml:211`

## Review evidence locations

- `pyproject.toml:210-212`
