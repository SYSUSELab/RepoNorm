# Rule details

- **Rule:**
  ```text
  Example scripts that demonstrate llama.cpp structured generation must construct JSONLogitsProcessor with an explicit tensor_library_name argument and pass it through a LogitsProcessorList to llama.create_completion.
  ```
- **Applies to:**
  - `examples/llamacpp_processor.py`
- **Condition:** When adding or modifying the llama.cpp structured-generation example.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/llamacpp_processor.py:33-48`
