# Rule details

- **Rule:** The dev container declares GPU host requirements as optional.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
    "gpu": "optional"

```

- **Sources:**
  - `.devcontainer/devcontainer.json:8`
