# Rule details

- **Rule:**
  ```text
  The legacy generate package must re-export exactly cfg, choice, format, fsm, json, regex, and text and declare exactly those names in __all__, fixing the legacy generation API surface.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/__init__.py`
- **Condition:**
  ```text
  When modifying the legacy generate package's public exports, preserve the exact set of re-exported names and the matching __all__ declaration.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/generate/__init__.py:1-17`
