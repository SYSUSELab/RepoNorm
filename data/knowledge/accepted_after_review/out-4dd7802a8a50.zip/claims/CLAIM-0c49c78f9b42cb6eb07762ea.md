# Rule details

- **Rule:** Contributors using the VSCode DevContainer workflow must open the Outlines repository in VSCode and reopen it in the container when prompted.
- **Applies to:**
  - `**`
- **Condition:** when using the VSCode DevContainer workflow
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
3. Open the Outlines repository in VSCode. When prompted, **Reopen in Container** (or press `F1` and select "Remote-Containers: Reopen in Container").

```

- **Sources:**
  - `docs/community/contribute.md:79`

## Review evidence locations

- `docs/community/contribute.md:71-80`
