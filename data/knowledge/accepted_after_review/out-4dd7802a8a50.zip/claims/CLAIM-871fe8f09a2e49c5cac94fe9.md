# Rule details

- **Rule:**
  ```text
  The JSON schema benchmark setup must initialize the tokenizer via setup_tokenizer() and select the schema from the schemas mapping by name.
  ```
- **Applies to:**
  - `benchmarks/bench_json_schema.py`
- **Condition:** When adding or modifying the setup of the JSON schema benchmark.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `benchmarks/bench_json_schema.py:64-72`
