# Rule details

- **Rule:**
  ```text
  The legacy ExLlamaV2 generate_stream must enqueue each prompt in a batch as a separate ExLlamaV2DynamicJob with a shared seed incremented per prompt when not None, and must map job serials back to original prompt indices via an order dict.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying ExLlamaV2Model.generate_stream for batched streaming, preserve per-prompt seed incrementing and the serial-to-original-index mapping.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
ExLlamaV2Model.generate_stream enqueues each prompt as a separate ExLlamaV2DynamicJob with a shared seed incremented per prompt when not None, and maps job serials back to original prompt indices via the order dict.
```

- **Sources:**
  - `outlines/v0_legacy/models/exllamav2.py:226-284`
