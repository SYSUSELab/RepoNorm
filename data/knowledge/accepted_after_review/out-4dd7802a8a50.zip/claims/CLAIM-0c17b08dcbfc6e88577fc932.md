# Rule details

- **Rule:**
  ```text
  Tests for a backend's output-type adapter must assert the exact request-payload mapping for each supported output type (None to empty payload, CFG to grammar string, JsonSchema to parsed json object, JsonSchema with whitespace to json plus whitespace_pattern, Regex to regex string) rather than only checking that generation returns a value.
  ```
- **Applies to:**
  - `tests/models/test_vllm_offline_type_adapter.py`
- **Condition:** When adding or modifying a test that verifies a backend type adapter's output-type to request-payload mapping.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/models/vllm_offline.py:44-76`
- `tests/models/test_vllm_offline_type_adapter.py:64-84`
