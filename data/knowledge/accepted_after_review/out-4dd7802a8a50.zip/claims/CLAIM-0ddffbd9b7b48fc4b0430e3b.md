# Rule details

- **Rule:**
  ```text
  Create the development environment with `conda env create -f environment.yml`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
conda env create -f environment.yml

```

- **Sources:**
  - `docs/community/contribute.md:46`

## Review evidence locations

- `docs/community/contribute.md:43-47`
