# Rule details

- **Rule:** The coverage job combines coverage data, generates HTML and XML reports, and runs diff-cover against the comparison branch with --fail-under=100, failing the step if coverage is below 100%.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: |
          python -m coverage combine
          python -m coverage html --skip-covered --skip-empty
          python -m coverage xml
          diff-cover coverage.xml --compare-branch=$COMPARE_BRANCH --markdown-report=coverage.md --fail-under=100 || (cat coverage.md >> $GITHUB_STEP_SUMMARY && exit 1)

```

- **Sources:**
  - `.github/workflows/tests.yml:109-113`

## Review evidence locations

- `.github/workflows/tests.yml:108-113`
