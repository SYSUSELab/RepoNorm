# Rule details

- **Rule:**
  ```text
  Tests for the vLLM offline model must assert that calling the model with a plain string prompt returns a `str`, documenting the basic call contract for the offline vLLM model.
  ```
- **Applies to:**
  - `tests/models/test_vllm_offline.py`
- **Condition:** When modifying or extending vLLM offline model tests under tests/models/.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_vllm_offline.py:43-50`
