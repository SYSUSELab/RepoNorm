# Rule details

- **Rule:**
  ```text
  get_sub_fsms_from_seq must yield, for each sub-FSM whose transitions contain the state sequence's transitions, a tuple of the FSM index, whether another transition is possible from the last state, and whether the sequence ends in a final state.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying get_sub_fsms_from_seq or sub-FSM matching logic in outlines/fsm/parsing.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/fsm/parsing.py:1053-1091`
