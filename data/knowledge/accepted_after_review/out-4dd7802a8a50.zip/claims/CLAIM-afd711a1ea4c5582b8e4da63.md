# Rule details

- **Rule:**
  ```text
  Tests that exercise the grammar test's MockTokenizer must implement decode by mapping token ids back to tokens through an inverse_vocabulary lookup.
  ```
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:**
  ```text
  when adding or modifying the MockTokenizer decode method in tests/test_grammars.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_grammars.py:9-23`
