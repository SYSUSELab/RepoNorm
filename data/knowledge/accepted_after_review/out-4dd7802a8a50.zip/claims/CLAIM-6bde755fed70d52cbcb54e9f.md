# Rule details

- **Rule:**
  ```text
  The tensor adapter boolean_ones_like test must be parametrized over `frameworks` and assert the result has the same shape as the input and that every element is truthy, defining the cross-framework boolean ones contract.
  ```
- **Applies to:**
  - `tests/processors/test_tensor_adapters.py`
- **Condition:**
  ```text
  When modifying or extending the tensor adapter boolean_ones_like test.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/processors/test_tensor_adapters.py:227-235`
