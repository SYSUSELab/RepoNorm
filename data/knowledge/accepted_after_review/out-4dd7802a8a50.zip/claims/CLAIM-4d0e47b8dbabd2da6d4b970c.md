# Rule details

- **Rule:**
  ```text
  Example scripts that build a model from a local framework must use the corresponding outlines.from_<framework> constructor (e.g. outlines.from_transformers, outlines.from_llamacpp) with the framework's model/tokenizer objects, rather than instantiating the model wrapper directly.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example that loads a model from a supported local framework.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/llamacpp_example.py:31-35`
- `examples/dating_profile.py:86-94`
