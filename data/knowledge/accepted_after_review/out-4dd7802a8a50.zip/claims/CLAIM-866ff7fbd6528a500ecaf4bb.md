# Rule details

- **Rule:**
  ```text
  When the event is a push, the workflow runs mike deploy --push --update-aliases ${{ github.ref_name }} unstable, with GOOGLE_ANALYTICS_KEY set from secrets.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push'
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
        if: github.event_name == 'push'
        run: |
          mike deploy --push --update-aliases ${{ github.ref_name }} unstable

```

- **Sources:**
  - `.github/workflows/publish_documentation.yml:51-53`
