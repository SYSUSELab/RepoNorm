# Rule details

- **Rule:**
  ```text
  The is_literal predicate must identify a value as a Literal by checking get_origin(value) is Literal.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:** when modifying the repository's Literal-detection predicate used by type handling
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/utils.py:120-121`
