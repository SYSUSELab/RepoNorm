# Rule details

- **Rule:**
  ```text
  Benchmark setup must build the CFG guide from a named grammar in the shared benched_grammars mapping with a tiny tokenizer, establishing a prebuilt guide reused by measurement methods.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:** when adding or modifying CFG guide benchmark setup that constructs the guide under test
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `benchmarks/bench_cfg_guide.py:13-33`
- `benchmarks/bench_cfg_guide.py:54-64`
