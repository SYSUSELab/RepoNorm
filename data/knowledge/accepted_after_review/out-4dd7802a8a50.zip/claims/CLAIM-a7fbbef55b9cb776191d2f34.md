# Rule details

- **Rule:**
  ```text
  The Vision template's __post_init__ must raise TypeError when the image has no format, then save the image to a BytesIO buffer and store base64-encoded bytes plus image_format as image/{format.lower()}, so image inputs carry a readable format and are transmitted as base64 with a normalized MIME type.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:** When modifying the Vision template's post-init image handling or serialization.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/templates.py:21-50`
