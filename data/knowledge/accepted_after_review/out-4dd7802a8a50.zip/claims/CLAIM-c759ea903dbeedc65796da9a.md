# Rule details

- **Rule:** Read the Docs installs the project from the repository root via pip with the rtd extra requirements.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - method: pip
        path: .
        extra_requirements:
          - rtd

```

- **Sources:**
  - `.readthedocs.yaml:6-9`

## Review evidence locations

- `.readthedocs.yaml:3-10`
