# Rule details

- **Rule:** The documentation build uses the mkdocstrings plugin with the python handler and numpy docstring style.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    - mkdocstrings:
          update_features_models_documentation default_handler: python
          handlers:
              python:
                  options:
                      docstring_style: numpy

```

- **Sources:**
  - `mkdocs.yml:87-92`

## Review evidence locations

- `mkdocs.yml:85-93`
