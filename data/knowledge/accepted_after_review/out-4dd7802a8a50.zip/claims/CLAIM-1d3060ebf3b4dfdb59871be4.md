# Rule details

- **Rule:** The workflow runs asv compare with --factor=1.1 --no-stats --split upstream/main HEAD and fails the step if the output contains 'Benchmarks that have got worse'.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      run: |
        asv compare --factor=1.1 --no-stats --split upstream/main HEAD | tee ${{ env.BENCHMARKS_OUTPUT }}
        if grep -q "Benchmarks that have got worse" "${{ env.BENCHMARKS_OUTPUT }}"; then
          echo "Performance degradation detected!"
          exit 1
        fi

```

- **Sources:**
  - `.github/workflows/asv_benchmark_pr.yml:63-68`

## Review evidence locations

- `.github/workflows/asv_benchmark_pr.yml:62-68`
