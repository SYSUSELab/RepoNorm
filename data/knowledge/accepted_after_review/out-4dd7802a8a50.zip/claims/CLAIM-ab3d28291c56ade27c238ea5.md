# Rule details

- **Rule:**
  ```text
  Tests calling transformers models (including model_bart) with a prompt must assert the synchronous call returns a str.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when adding or modifying a test that calls a transformers model with a prompt
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/models/test_transformers.py:100-110`
