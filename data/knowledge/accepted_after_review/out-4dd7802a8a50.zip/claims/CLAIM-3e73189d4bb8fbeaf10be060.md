# Rule details

- **Rule:**
  ```text
  Coverage reporting is configured with show_missing = true, so missing lines are shown in coverage reports.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
show_missing = true

```

- **Sources:**
  - `pyproject.toml:199`

## Review evidence locations

- `pyproject.toml:198-204`
