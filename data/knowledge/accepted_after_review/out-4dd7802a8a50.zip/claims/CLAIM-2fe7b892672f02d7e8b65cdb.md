# Rule details

- **Rule:**
  ```text
  Changes to the legacy GeneratorVisionV0Adapter.stream must preserve merging of prompts and media via merge_prompts_and_media before delegating to the parent stream, so vision streaming requires paired prompt/media inputs.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:** When modifying GeneratorVisionV0Adapter.stream or its input handling.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
GeneratorVisionV0Adapter.stream calls merge_prompts_and_media(prompts, media) before delegating to the parent stream, preserving the vision streaming merge contract.
```

- **Sources:**
  - `outlines/v0_legacy/generate/api.py`
