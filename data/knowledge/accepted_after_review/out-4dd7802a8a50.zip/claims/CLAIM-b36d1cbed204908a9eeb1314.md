# Rule details

- **Rule:**
  ```text
  The sample_schema_builder fixture must build a SchemaBuilder with an empty object schema and then add two objects sharing the key 'hi' with different value types, exercising schema inference across heterogeneous values.
  ```
- **Applies to:**
  - `tests/types/test_types_utils.py`
- **Condition:**
  ```text
  when modifying the sample_schema_builder fixture or adding schema inference tests
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/types/test_types_utils.py:125-131`
