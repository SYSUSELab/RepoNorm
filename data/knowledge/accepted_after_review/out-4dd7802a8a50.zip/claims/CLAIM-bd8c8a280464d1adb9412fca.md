# Rule details

- **Rule:**
  ```text
  The legacy Function.__call__ must not support batching, must lazily initialize the generator, must render the prompt template with args/kwargs, and must suppress DeprecationWarning around generator initialization and invocation.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying the legacy Function.__call__ path or its generator initialization/invocation behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/function.py:88-114`
