# Rule details

- **Rule:**
  ```text
  Single-term wrapper _display_children must delegate to the wrapped term's display_ascii_tree with is_last forced to True, so the wrapped term is always rendered as the last child.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  When modifying _display_children for single-term wrapper DSL nodes or changing child rendering order.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/types/dsl.py:395-431`
- `outlines/types/dsl.py:471-536`
