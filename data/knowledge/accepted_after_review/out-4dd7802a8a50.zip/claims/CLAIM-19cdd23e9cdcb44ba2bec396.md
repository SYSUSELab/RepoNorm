# Rule details

- **Rule:**
  ```text
  Code under outlines/v0_legacy/ is a frozen backward-compatibility surface: new code must not be modeled on it, and changes there must preserve v0 behavior rather than modernize it.
  ```
- **Applies to:**
  - `outlines/v0_legacy/**/*.py`
- **Condition:**
  ```text
  When modifying or adding code under the v0_legacy package, including using it as a template for new implementations.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/generate/api.py:1-2`
- `outlines/v0_legacy/models/openai.py:1-2`
