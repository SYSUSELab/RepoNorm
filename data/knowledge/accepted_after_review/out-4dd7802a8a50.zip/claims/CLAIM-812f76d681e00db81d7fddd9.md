# Rule details

- **Rule:**
  ```text
  Tests that exercise legacy v0 model entry points (models.openai, models.llamacpp, models.transformers_vision) must assert the call emits a DeprecationWarning whose message matches the pinned deprecation text for that entry point.
  ```
- **Applies to:**
  - `tests/v0_legacy/**/*.py`
- **Condition:** when adding or modifying a test that invokes a legacy v0 model entry point
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/v0_legacy/models/test_openai_legacy.py:21-27`
- `tests/v0_legacy/models/test_llamacpp_legacy.py:14-22`
- `tests/v0_legacy/models/test_transformers_vision_legacy.py:24-30`
