# Rule details

- **Rule:**
  ```text
  Install documentation dependencies by running `pip install -r requirements-doc.txt`.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
pip install -r requirements-doc.txt

```

- **Sources:**
  - `docs/community/contribute.md:151`

## Review evidence locations

- `docs/community/contribute.md:146-152`
