# Rule details

- **Rule:**
  ```text
  Changes to the legacy exllamav2 generate path must preserve the per-prompt token-limit invariant: max_new_tokens is passed as min(exllamav2_params["max_new_tokens"]) so no prompt exceeds the model's max sequence length.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying ExLlamaV2Model.generate in outlines/v0_legacy/models/exllamav2.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/v0_legacy/models/exllamav2.py:195-222`
