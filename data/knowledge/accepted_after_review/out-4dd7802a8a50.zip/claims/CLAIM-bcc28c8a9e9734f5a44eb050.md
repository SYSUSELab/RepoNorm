# Rule details

- **Rule:** Generator construction must reject a missing model by raising ValueError, and must reject a black-box sync model combined with a logits processor by raising NotImplementedError; these input-validation boundaries must be preserved when changing Generator's constructor or its supported model/processor combinations.
- **Applies to:**
  - `tests/test_generator.py`
- **Condition:** When modifying Generator construction or the set of supported model/processor combinations in the generator tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/generator.py:329-347`
- `tests/test_generator.py:210-212`
- `tests/test_generator.py:234-243`
