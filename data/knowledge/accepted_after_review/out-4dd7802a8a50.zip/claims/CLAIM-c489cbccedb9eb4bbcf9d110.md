# Rule details

- **Rule:**
  ```text
  The Build the documentation workflow runs on pull requests targeting the main branch and on manual workflow_dispatch.
  ```
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  pull_request:
    branches: [main]
  workflow_dispatch:

```

- **Sources:**
  - `.github/workflows/build_documentation.yml:4-6`

## Review evidence locations

- `.github/workflows/build_documentation.yml:1-6`
