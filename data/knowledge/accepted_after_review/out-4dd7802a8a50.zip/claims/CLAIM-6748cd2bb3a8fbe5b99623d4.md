# Rule details

- **Rule:**
  ```text
  Tensor adapter implementations must provide boolean_ones_like returning a boolean-dtype tensor of ones (e.g., torch.ones_like with dtype=torch.bool), not a default-dtype tensor.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/**/*.py`
- **Condition:**
  ```text
  When adding or modifying a tensor adapter's boolean_ones_like method.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `outlines/processors/tensor_adapters/base.py:197-204`
- `outlines/processors/tensor_adapters/torch.py:41-42`
- `outlines/processors/tensor_adapters/numpy.py:41-42`
