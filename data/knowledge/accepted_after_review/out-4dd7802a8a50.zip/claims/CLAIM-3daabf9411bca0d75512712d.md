# Rule details

- **Rule:**
  ```text
  The DSL test module must conditionally import TypedDict from typing on Python 3.12+ and from typing_extensions otherwise, reflecting a supported Python-version compatibility boundary.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** When modifying or extending the DSL test module's imports.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/types/test_dsl.py:60-63`
