# Rule details

- **Rule:** Code must respect the current naming conventions.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
- [ ] The code respects the current **naming conventions**;

```

- **Sources:**
  - `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:12`

## Review evidence locations

- `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:10-13`
