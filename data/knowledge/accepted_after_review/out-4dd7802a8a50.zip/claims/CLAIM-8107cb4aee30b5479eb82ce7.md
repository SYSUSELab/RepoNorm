# Rule details

- **Rule:**
  ```text
  Tests that exercise the outlines.prompt decorator with a dict response must expect a pytest.deprecated_call() and pretty-printed JSON with two-space indentation and preserved empty string values.
  ```
- **Applies to:**
  - `tests/test_templates.py`
- **Condition:** when adding or modifying a test that renders a dict response through the outlines.prompt decorator
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_templates.py:331-341`
