# Claim catalog

- [Rules 1–75](catalog/0001.md); scope preview: `outlines/models/transformers.py`
- [Rules 76–143](catalog/0002.md); scope preview: `outlines/v0_legacy/generate/__init__.py`
- [Rules 144–215](catalog/0003.md); scope preview: `examples/beam-cloud/app.py`
- [Rules 216–290](catalog/0004.md); scope preview: `examples/parsing.py`
- [Rules 291–365](catalog/0005.md); scope preview: `outlines/v0_legacy/function.py`
- [Rules 366–436](catalog/0006.md); scope preview: `outlines/models/openai.py`
- [Rules 437–462](catalog/0007.md); scope preview: `tests/processors/test_tensor_adapters.py`
