# Claim catalog

- [Rules 1–74](catalog/0001.md); scope preview: `src/jinja2/environment.py`
- [Rules 75–147](catalog/0002.md); scope preview: `src/jinja2/compiler.py`
- [Rules 148–219](catalog/0003.md); scope preview: `tests/test_lexnparse.py`
- [Rules 220–288](catalog/0004.md); scope preview: `src/jinja2/compiler.py`
- [Rules 289–362](catalog/0005.md); scope preview: `tests/test_ext.py`
- [Rules 363–439](catalog/0006.md); scope preview: `src/jinja2/compiler.py`
- [Rules 440–450](catalog/0007.md); scope preview: `**/*.py`
