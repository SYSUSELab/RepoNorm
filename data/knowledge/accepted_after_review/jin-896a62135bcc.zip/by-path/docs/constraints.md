# Constraints for `docs`

## Rule

- **Rule:** Read the Docs documentation builds use the dirhtml Sphinx builder.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-22e491199cbca240ed6ef5b0.md)

## Rule

- **Rule:** Update any relevant docs pages and docstrings; docs pages and docstrings should be wrapped at 72 characters.
- **Applies to:**
  - `**/*.py`
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-501c955b993f7b36fd40e0d1.md)

## Rule

- **Rule:** Read the Docs documentation builds fail on Sphinx warnings.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7fc1fac00c49e4b28720008d.md)

## Rule

- **Rule:** The docs tox environment builds HTML documentation with sphinx-build using -W (warnings as errors) and doctrees/output directories under the environment temp dir.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8b7cefe3d0dcf40145ac8db6.md)

## Rule

- **Rule:**
  ```text
  The built documentation output is viewed by opening `_build/html/index.html` in a browser.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a41c5792d4733b34b74b4647.md)

## Rule

- **Rule:**
  ```text
  Running `make <target>` in docs/ invokes Sphinx via `$(SPHINXBUILD) -M <target> "$(SOURCEDIR)" "$(BUILDDIR)" $(SPHINXOPTS) $(O)`, forwarding the target name as the Sphinx builder.
  ```
- **Applies to:**
  - `docs/**`
- **Condition:** command target: %
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e5089bae3cbb748a2fe81174.md)
