# Constraints for `docs/examples/cache_extension.py`

## Rule

- **Rule:**
  ```text
  Extension helper methods that implement caching must build the cache key from `environment.fragment_cache_prefix` plus the block name, return cached values when present, and otherwise call the caller and store the result with the supplied timeout.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** When modifying the cache extension's helper, preserve the prefix-plus-name key construction, the cache-hit short circuit, and the store-with-timeout behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1192b513fdbe8c188fec4552.md)

## Rule

- **Rule:**
  ```text
  Extension examples must import their extension-authoring surface from `jinja2` (e.g., `nodes`, `Extension`) and may import lexer utilities such as `count_newlines` and `Token` from `jinja2.lexer`.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
  - `docs/examples/inline_gettext_extension.py`
- **Condition:**
  ```text
  When adding or modifying an extension example, import the extension-authoring surface from `jinja2` and lexer utilities from `jinja2.lexer` rather than reimplementing them.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8614cb7ef205d361114b5c4d.md)

## Rule

- **Rule:**
  ```text
  Extension classes must declare a `tags` set naming the block tag(s) they handle, and the tag name must match the block name used in templates and in the extension's own parse/end-tag handling.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:**
  ```text
  When adding or renaming a block tag handled by an extension example, update the `tags` declaration and the corresponding parse/end-tag names consistently.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c35a8bb1747f307c7eceb07e.md)
