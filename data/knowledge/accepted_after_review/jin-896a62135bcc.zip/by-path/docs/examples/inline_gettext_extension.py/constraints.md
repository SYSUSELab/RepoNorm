# Constraints for `docs/examples/inline_gettext_extension.py`

## Rule

- **Rule:**
  ```text
  Inline gettext extension filters must track parenthesis depth to decide when to emit `trans`/`endtrans` block tokens and must raise `TemplateSyntaxError` for an unclosed gettext expression.
  ```
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:**
  ```text
  When modifying the inline gettext extension's stream filter, preserve the parenthesis-depth tracking that gates `trans`/`endtrans` emission and the error raised for unclosed expressions.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-14731ce304dbe411a5db4d30.md)

## Rule

- **Rule:**
  ```text
  Extension examples must import their extension-authoring surface from `jinja2` (e.g., `nodes`, `Extension`) and may import lexer utilities such as `count_newlines` and `Token` from `jinja2.lexer`.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
  - `docs/examples/inline_gettext_extension.py`
- **Condition:**
  ```text
  When adding or modifying an extension example, import the extension-authoring surface from `jinja2` and lexer utilities from `jinja2.lexer` rather than reimplementing them.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8614cb7ef205d361114b5c4d.md)

## Rule

- **Rule:**
  ```text
  Inline gettext extension classes must declare a dependency on the i18n extension being loaded and configured, and must implement inline gettext blocks of the form `_(text)`.
  ```
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:**
  ```text
  When modifying the inline gettext extension, preserve the i18n extension dependency and the `_(text)` block form.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9faa43d25509cfc10f866ba6.md)
