# Constraints for `.`

## Rule

- **Rule:**
  ```text
  Run `coverage html` to generate an HTML coverage report.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-01b0b37c3e5e1bcfa61fa0b3.md)

## Rule

- **Rule:** The tox envlist includes py3{11,10,9,8,7}, pypy3{8,7}, style, typing, and docs environments.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-01c7a567ce712e5a9a38a6f2.md)

## Rule

- **Rule:**
  ```text
  Run `coverage run -m pytest` to execute the test suite under coverage.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-0456ffbb92d3c65a374bc62d.md)

## Rule

- **Rule:**
  ```text
  The tox testenv:style environment depends on the `pre-commit` package.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-116bd71c383f6f919ebe9bc9.md)

## Rule

- **Rule:** The typing tox test environment runs mypy as its command.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-117342ced025eb236ea77d04.md)

## Rule

- **Rule:**
  ```text
  YAML, JSON, JavaScript, CSS, and HTML files use an indent size of 2 (indent_size = 2).
  ```
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1178cf6006b877bbb81e3290.md)

## Rule

- **Rule:** The pre-commit-hooks repository configures the trailing-whitespace hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1af31f664f1f2ca4f59286a0.md)

## Rule

- **Rule:** The flake8 hook runs with the flake8-bugbear additional dependency.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-236f1c67a8335b73523c6780.md)

## Rule

- **Rule:** Add an entry in CHANGES.rst using the same style as other entries, and include .. versionchanged:: inline changelogs in relevant docstrings.
- **Applies to:**
  - `**/*.py`
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-255ec0bd9f994a8fea202ed8.md)

## Rule

- **Rule:** Use Black to format code; Black and other tools run automatically if pre-commit is installed using the instructions below.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-2b877fc4fa4db9242c506ede.md)

## Rule

- **Rule:** Coverage measurement is configured to run with branch coverage enabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2fdf58520daf4fb125c280a4.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with no_implicit_reexport disabled for the jinja2.defaults module.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-38c53fa6873d4a70827b5296.md)

## Rule

- **Rule:** Tox skips missing interpreters.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-44c4f346c46b9185963050fa.md)

## Rule

- **Rule:** Configure git with your username and email using the global git config commands.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-4d2c99004d3da8ce77399634.md)

## Rule

- **Rule:** The tests job upgrades wheel, setuptools, and pip before running tests.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4dce26c15b3886ea4203ec34.md)

## Rule

- **Rule:** Update any relevant docs pages and docstrings; docs pages and docstrings should be wrapped at 72 characters.
- **Applies to:**
  - `**/*.py`
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-501c955b993f7b36fd40e0d1.md)

## Rule

- **Rule:** Character encoding is UTF-8 (charset = utf-8).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-51efa533f916c4d3e1c2b2b6.md)

## Rule

- **Rule:**
  ```text
  The Tests workflow runs on pushes to the main branch and branches matching '*.x', ignoring changes under docs/** and to *.md and *.rst files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5224089e949b4bbacb08e6cc.md)

## Rule

- **Rule:** Include tests that cover any code changes made, and ensure the test fails without the patch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-5a6c1eeb12dab9564541a509.md)

## Rule

- **Rule:** Do not use the issue tracker for support questions; the issue tracker is for bugs and feature requests in Jinja itself.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-60e2c8b6fb3d5dcd785c56e5.md)

## Rule

- **Rule:** flake8 selects the B, E, F, W, B9, and ISC rule codes.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-63a43db715c8e87e43bae035.md)

## Rule

- **Rule:**
  ```text
  Create a virtualenv with python3 -m venv env and activate it; on Windows activation uses env\Scripts\activate.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-66644b34f2c6acb9e231125f.md)

## Rule

- **Rule:**
  ```text
  Line endings use LF (end_of_line = lf).
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6912d082b1cd1dd812ad613d.md)

## Rule

- **Rule:** The reorder-python-imports hook runs with --application-directories src.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6ec98e07f9c7ac0229eef253.md)

## Rule

- **Rule:** Run the basic test suite with pytest.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-757e433b7cf7a97b345de9ce.md)

## Rule

- **Rule:**
  ```text
  The tests job caches ./.mypy_cache keyed on the matrix Python version and setup.cfg hash, only when the matrix tox value is 'typing'.
  ```
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: matrix.tox == 'typing'
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-78dac82e473bd41e662020e1.md)

## Rule

- **Rule:** The pre-commit-hooks repository configures the fix-byte-order-marker hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8a54ffa62014963a4baf17cc.md)

## Rule

- **Rule:** Add your fork as a remote named "fork" using git remote add fork with your username.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-9851a7641c8cbc08573d8472.md)

## Rule

- **Rule:**
  ```text
  The tox testenv:style environment sets skip_install to true.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9d8d3172596604dffb017a80.md)

## Rule

- **Rule:**
  ```text
  Files end with a final newline (insert_final_newline = true).
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a6696680a5974ff13b2cec1e.md)

## Rule

- **Rule:** Install the pre-commit hooks with pre-commit install.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-a8bd808f59f1628927698402.md)

## Rule

- **Rule:** CI runs the full test suite when a pull request is submitted.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-b951dc901d18726851c50a0a.md)

## Rule

- **Rule:**
  ```text
  Open `htmlcov/index.html` in a browser to explore the generated coverage report.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-c1f29b5bdab7d519ff94d7b6.md)

## Rule

- **Rule:**
  ```text
  The tests job caches the pip cache directory keyed on the runner OS, matrix Python version, setup.py hash, and requirements/*.txt hashes.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c454515e51e9e5c941282da1.md)

## Rule

- **Rule:** The tests job runs across a matrix including Linux, Windows, and Mac on Python 3.10 (tox py310), 3.11-dev (tox py311), 3.9 (tox py39), 3.8 (tox py38), 3.7 (tox py37), PyPy 3.7 (tox pypy37), and a Typing environment on Python 3.10 (tox typing).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c80d6c78c27bbf85fd839f66.md)

## Rule

- **Rule:**
  ```text
  Trailing whitespace is trimmed (trim_trailing_whitespace = true).
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cb5acc7241f81490625c453c.md)

## Rule

- **Rule:**
  ```text
  Indentation uses spaces (indent_style = space).
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d397d92cddda37693ffa312e.md)

## Rule

- **Rule:** EditorConfig is the root configuration (root = true).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d51fd2114335f9f260f58240.md)

## Rule

- **Rule:** The pre-commit-hooks repository configures the end-of-file-fixer hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d5c03316cf66874382d67921.md)

## Rule

- **Rule:**
  ```text
  The Tests workflow runs on pull requests targeting the main branch and branches matching '*.x', ignoring changes under docs/** and to *.md and *.rst files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d81012c8cbf4c86c0458368d.md)

## Rule

- **Rule:** Clone the main Jinja repository locally and change into the jinja directory.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-dd978ff4046dfe08c620bea4.md)

## Rule

- **Rule:** The tests job installs the matrix Python version via actions/setup-python.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-de7725d3a6f9e2e48c15c27d.md)

## Rule

- **Rule:** flake8 ignores E203, E501, E722, and W503.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df7629e2120d0e44306b88d5.md)

## Rule

- **Rule:** flake8 max-line-length is 80.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e309f31b41d9158f2c422f92.md)

## Rule

- **Rule:** The tox testenv runs tests via pytest with verbose output, short tracebacks, and a basetemp set to the env tmpdir, forwarding posargs.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e520f8c099ad52c112f1f226.md)

## Rule

- **Rule:** Read the Docs documentation builds install the repository itself via pip from the repository root.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eed796da60dd784ba067d9d9.md)

## Rule

- **Rule:** For feature additions or changes, branch off the "main" branch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-f67325a4168b52bd7c2a733f.md)

## Rule

- **Rule:**
  ```text
  For the mypy-markupsafe module, no_implicit_reexport is disabled (False), so implicit re-exports are permitted.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fb07f1e84e6fbe904abcddb3.md)

## Rule

- **Rule:** The tests job installs tox and runs the tox environment named by the matrix tox value.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fd89df29cb3086b3472d5382.md)

## Rule

- **Rule:** Create a branch to identify the issue being worked on; for bug or documentation fixes, branch off the latest ".x" branch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-fd8f833b0b04b577dd1e3acc.md)
