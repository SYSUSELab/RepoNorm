# Constraints for `requirements/tests.txt`

## Rule

- **Rule:** The tox testenv installs test dependencies from requirements/tests.txt.
- **Applies to:**
  - `requirements/tests.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2fa17c7eee554bdd0cbab7cd.md)
