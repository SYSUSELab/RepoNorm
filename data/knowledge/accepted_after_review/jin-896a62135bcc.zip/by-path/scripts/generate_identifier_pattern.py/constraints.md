# Constraints for `scripts/generate_identifier_pattern.py`

## Rule

- **Rule:**
  ```text
  Changes to the identifier-pattern generator must preserve the range-compression convention: collapse_ranges groups a sorted unique character list by the difference between code point and index, yielding (first, last) pairs for each sequential run, and build_pattern must collapse single-character and adjacent two-character runs into literal characters rather than emitting redundant 'a-b' ranges.
  ```
- **Applies to:**
  - `scripts/generate_identifier_pattern.py`
- **Condition:** When modifying the range-compression or pattern-emission logic in the identifier-pattern generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3686dfba570c4a40039f0fc8.md)

## Rule

- **Rule:**
  ```text
  Changes to the identifier-pattern generator must preserve the generated-artifact convention: main() builds a regex pattern and writes it to src/jinja2/_identifier.py with a generated-by header, so the identifier pattern file is machine-generated and should not be hand-edited.
  ```
- **Applies to:**
  - `scripts/generate_identifier_pattern.py`
  - `src/jinja2/_identifier.py`
- **Condition:**
  ```text
  When modifying the identifier pattern or the generator that produces src/jinja2/_identifier.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6b1b3a0fdd31c263fdf65f0e.md)

## Rule

- **Rule:**
  ```text
  Changes to the identifier-pattern generator must preserve the character-classification convention: get_characters yields Unicode characters that are valid as identifier continue characters but are not matched by the regex \w, relying on str.isidentifier for validation.
  ```
- **Applies to:**
  - `scripts/generate_identifier_pattern.py`
- **Condition:** When modifying the character-selection logic that determines which Unicode characters are included in the generated identifier pattern.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d3d093528c10f6d8a60a6582.md)
