# Constraints for `src`

## Rule

- **Rule:** The package root directory is src, so importable packages live under src/.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4f55a4cd0bb8a81f965bf170.md)

## Rule

- **Rule:** Package discovery for the project is configured to search under the src directory.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f5ff2a0d6368e7a5147868bc.md)
