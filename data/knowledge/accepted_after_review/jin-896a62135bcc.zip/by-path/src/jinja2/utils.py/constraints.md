# Constraints for `src/jinja2/utils.py`

## Rule

- **Rule:** When modifying the LRUCache, preserve that clear acquires the write lock before clearing both the mapping and the queue, so cache clearing is synchronized with concurrent access.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when changing LRUCache.clear or its locking behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3853e9e1ad81cda3e419b43e.md)

## Rule

- **Rule:**
  ```text
  The is_undefined helper must perform a lazy import of Undefined from .runtime and return isinstance(obj, Undefined), providing a stable public API for custom filters and tests to detect undefined values without importing runtime directly.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  when modifying or extending the is_undefined helper or adding similar undefined-detection utilities
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-47f515cc4ee1540c85573d88.md)

## Rule

- **Rule:**
  ```text
  open_if_exists must return None when the path is not a regular file, otherwise open the file with the given mode (default 'rb').
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** Modifying file-opening utility behavior or its non-regular-file handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4e40cf69cf3c55f604257069.md)

## Rule

- **Rule:**
  ```text
  `Cycler.current` must remain a lookahead: it returns `self.items[self.pos]`, the item the next `next()` call will yield, not the last-consumed item.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying Cycler iteration state or the `current` property, preserve the lookahead semantics rather than redefining `current` as the last-consumed item.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9dfc356e07e647bd91340298.md)

## Rule

- **Rule:**
  ```text
  LRUCache.__reversed__ must iterate keys oldest-first, implemented by iterating a tuple snapshot of the internal queue.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  Modifying LRUCache.__reversed__ or the internal queue iteration order.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ad69af205b9ddbc4bdb94bd2.md)

## Rule

- **Rule:**
  ```text
  Cycler must cycle through positional items one at a time and restart at the end, be exposed as `cycler` in templates, and alias `__next__ = next` so it supports both next() and iteration protocols.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying the Cycler class or its template exposure as `cycler`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b2a69f579d977adcca204909.md)

## Rule

- **Rule:**
  ```text
  LRUCache.__getstate__ must serialize capacity, _mapping, and _queue, defining the pickling protocol for the cache.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying LRUCache serialization or adding state to the cache.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ba3f47cc46a48d65a0d06966.md)

## Rule

- **Rule:**
  ```text
  `LRUCache.setdefault` must return the existing value if the key is present, otherwise store and return the default, matching `dict.setdefault` semantics.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying `LRUCache.setdefault` or its callers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f711866ccb8a36e7baddfd52.md)
