# Constraints for `src/jinja2/tests.py`

## Rule

- **Rule:** When implementing undefined detection, use isinstance(value, Undefined) rather than a sentinel value.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  Modifying test_undefined or adding undefined-detection logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2abdebfdad741137467ae8fb.md)

## Rule

- **Rule:** Template tests that classify values must use the abstract base classes from the standard library (abc.Mapping for mapping tests, numbers.Number for number tests) rather than concrete builtin types, so that any conforming implementation is recognized.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** when adding or modifying a value-classification test in the template test registry
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4ec6e6d01517fa86c57c1128.md)

## Rule

- **Rule:** The sameas template test must use identity comparison (value is other) rather than equality, so that it correctly distinguishes the False singleton and other identity-sensitive values.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** when modifying or adding the sameas test in the template test registry
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-740d5b4cb0c3bd35cc4ff838.md)

## Rule

- **Rule:**
  ```text
  When modifying `test_even`, preserve the definition of evenness as value modulo 2 equals zero for integer values.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  When changing the `even` test or its integer parity semantics.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-92984e8d75de4ccf08f027b2.md)

## Rule

- **Rule:**
  ```text
  test_integer must return True only for int instances that are not True or False, explicitly excluding booleans despite being int subclasses.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** Modifying the integer test or its boolean exclusion behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a0b88d9f00df92b693052163.md)

## Rule

- **Rule:** The float test must use isinstance(value, float) as its exact type check.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** When modifying or adding built-in test functions in jinja2.tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae2a44c5f743a425a18ed2ce.md)

## Rule

- **Rule:**
  ```text
  When modifying the built-in test functions in jinja2.tests, preserve the semantics: test_divisibleby returns value % num == 0, test_escaped returns True based on hasattr(value, '__html__'), and test_defined returns true unless the value is an instance of Undefined.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** When changing built-in test function semantics in jinja2.tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ba65cf6826d1f096a9d08d45.md)

## Rule

- **Rule:** The string test predicate must return true only for str instances, defining the exact type boundary used by the string test in templates.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  Modifying test_string or the string test predicate semantics.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c6a35953cb26adcb86135531.md)

## Rule

- **Rule:** The false test must use identity comparison (value is False) so only the singleton False passes, not other falsy values.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** When modifying or adding built-in test functions in jinja2.tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eca52842d6af5d3176578abe.md)
