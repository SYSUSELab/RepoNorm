# Constraints for `src/jinja2/async_utils.py`

## Rule

- **Rule:**
  ```text
  async_variant must be a decorator factory that returns a decorator, the mechanism used to derive async variants of sync functions in async_utils.
  ```
- **Applies to:**
  - `src/jinja2/async_utils.py`
- **Condition:** Modifying async variant derivation or the decorator factory mechanism.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2a37fb62bcaf5c3311e17506.md)

## Rule

- **Rule:**
  ```text
  async_utils must define a fixed set of common primitive types used to decide whether a value can be treated as a native async primitive; contributors adding new primitive-like types must update this set.
  ```
- **Applies to:**
  - `src/jinja2/async_utils.py`
- **Condition:** When adding a new primitive-like type that should be treated as a native async primitive.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2c0797b7e22e0d4ee9f19b22.md)

## Rule

- **Rule:**
  ```text
  When adding an async variant of a sync filter or test, register it via the async_variant decorator so the wrapper carries jinja_async_variant=True and mirrors the sync behavior.
  ```
- **Applies to:**
  - `src/jinja2/async_utils.py`
  - `src/jinja2/filters.py`
- **Condition:** Adding or modifying an async filter/test variant that mirrors a sync counterpart.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-557e88d529edd6acf30755b8.md)

## Rule

- **Rule:**
  ```text
  When modifying the async_utils wrapper, preserve the use of is_async(args) to choose async_func or normal_func and the stripping of the first argument when need_eval_context is set.
  ```
- **Applies to:**
  - `src/jinja2/async_utils.py`
- **Condition:**
  ```text
  When changing the async_utils wrapper's dispatch logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b07935dfe8795e9b19f61930.md)

## Rule

- **Rule:**
  ```text
  When modifying `auto_aiter`, preserve the dual sync/async iteration contract: yield from an async iterable when `__aiter__` is present, otherwise fall back to iterating a sync iterable.
  ```
- **Applies to:**
  - `src/jinja2/async_utils.py`
- **Condition:** When changing async iteration helpers or the fallback between async and sync iterables.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e17f02102962d92a316b2d4c.md)

## Rule

- **Rule:**
  ```text
  auto_await must short-circuit for values whose exact type is in _common_primitives to avoid an isawaitable call, then await only if inspect.isawaitable is true, otherwise return the value unchanged.
  ```
- **Applies to:**
  - `src/jinja2/async_utils.py`
- **Condition:**
  ```text
  When modifying auto_await or async value handling in async_utils.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f3605f0f2e931dba3d12839f.md)
