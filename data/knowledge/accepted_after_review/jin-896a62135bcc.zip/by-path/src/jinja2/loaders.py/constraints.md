# Constraints for `src/jinja2/loaders.py`

## Rule

- **Rule:** When a template is not found by one loader, the next loader in the chain must be tried, so user-provided loaders can override builtin templates from another location.
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** Modifying loader lookup or fallback behavior in the loader chain.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-280912ce05b4685a5a252098.md)

## Rule

- **Rule:**
  ```text
  ModuleLoader.__init__ must accept a single path or an iterable of paths, treat a bare str as a single path rather than iterating it character-wise, and normalize each path with os.fspath before assigning to the fake module's __path__.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  when changing ModuleLoader.__init__ or its path normalization and __path__ assignment
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-54b7067d3b25df1c9b4933d1.md)

## Rule

- **Rule:** The ModuleLoader.load method must import the generated module, remove it from sys.modules so only the attribute on the stored module object remains, and raise TemplateNotFound on ImportError.
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** when modifying ModuleLoader.load or adding similar module-based loaders
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b577a481a87bb04ebc986799.md)

## Rule

- **Rule:**
  ```text
  ModuleLoader must load templates from precompiled templates and set has_source_access = False, so it cannot provide template source.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** Modifying ModuleLoader or its source-access capability.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e674123ee5a9e862821f34a8.md)

## Rule

- **Rule:**
  ```text
  When modifying ModuleLoader.get_template_key, preserve the cache key derivation as 'tmpl_' plus the SHA-1 hex digest of the UTF-8 encoded template name.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When changing template cache key derivation in ModuleLoader.get_template_key.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fc4274aba7900cd8b0fb1d31.md)
