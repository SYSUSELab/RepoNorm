# Constraints for `src/jinja2/idtracking.py`

## Rule

- **Rule:**
  ```text
  When modifying FrameSymbolVisitor.visit_Name, preserve the context-based dispatch: store_as_param or ctx == "param" declares a parameter, ctx == "store" stores, and ctx == "load" loads.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** when changing name handling in symbol tracking visitors
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-26fe90fc154d69f553738e5b.md)

## Rule

- **Rule:**
  ```text
  The FrameSymbolVisitor.visit_For method must handle body/else/test branches by visiting the loop target as a parameter in body and test, visiting node.else_ in else, and raising RuntimeError('Unknown for branch') for unknown branches.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  when modifying FrameSymbolVisitor.visit_For or adding similar branch-handling visitors
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4fd17b5796839e86d95b1405.md)

## Rule

- **Rule:**
  ```text
  RootVisitor.visit_With must visit each target and then each child in the with body, defining how with-statement symbols are tracked.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  When modifying RootVisitor.visit_With or with-statement symbol tracking.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-54e21b6c9b0d38ba09e06015.md)

## Rule

- **Rule:**
  ```text
  When classifying how a symbol is loaded, use the VAR_LOAD_* constants (param, resolve, alias, undefined) as the resolution protocol.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** Modifying symbol load classification or adding new load kinds in idtracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7c7fce0dabc61ad6150bab0f.md)

## Rule

- **Rule:**
  ```text
  RootVisitor.visit_OverlayScope must visit only the body children, not the context expression, so symbols introduced by the overlay context are not tracked as defined names.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  When modifying RootVisitor.visit_OverlayScope or overlay-scope symbol tracking.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a7d28af8abf776c9446d7bf5.md)

## Rule

- **Rule:**
  ```text
  visit_NSRef must load the referenced name into the symbol tracking state so namespace references participate in symbol resolution like other name loads.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  Modifying FrameSymbolVisitor.visit_NSRef or the symbol-tracking load logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b42e1b4c3730964d01240d08.md)

## Rule

- **Rule:**
  ```text
  The FrameSymbolVisitor.visit_Macro method must record a macro's name via symbols.store, so that macro names participate in the same symbol table as other assignments.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  when modifying FrameSymbolVisitor.visit_Macro or adding similar symbol-recording visitors
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-be8ac65fc584fe6ed11871a3.md)

## Rule

- **Rule:**
  ```text
  RootVisitor must alias visit_Template, visit_Block, visit_Macro, visit_FilterBlock, visit_Scope, visit_If, and visit_ScopedEvalContextModifier to _simple_visit so these node types share one traversal behavior.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** When modifying RootVisitor or adding/removing simple-visit node aliases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e8b9c689918d37151eff005c.md)

## Rule

- **Rule:**
  ```text
  `RootVisitor._simple_visit` must recursively visit each child node through `sym_visitor`, establishing the traversal convention for symbol tracking.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  When modifying `RootVisitor._simple_visit` or symbol-tracking traversal, preserve recursive child visitation through `sym_visitor`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ed41eb7d5176179557b5f64e.md)
