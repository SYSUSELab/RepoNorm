# Constraints for `src/jinja2/parser.py`

## Rule

- **Rule:**
  ```text
  The parser must define _statement_keywords and _compare_operators as frozensets of keyword names and map math operator names to node classes via _math_nodes, so that keyword sets are immutable and operator-to-node mapping is centralized.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** when modifying parser keyword sets or operator-to-node mappings
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0af17217212d505d90f4ef0a.md)

## Rule

- **Rule:** Parser.fail must raise the given exception type (default TemplateSyntaxError) with the message, an explicit or current-stream line number, and the parser's name and filename, centralizing syntax error context.
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** When modifying Parser.fail or adding parser error reporting paths.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-178e90527d1ba3f2eb0b5c91.md)

## Rule

- **Rule:**
  ```text
  Parser.subparse must push end_tokens onto self._end_token_stack and pop it in a finally block, returning early when the current token matches an end token, so nested parsing restores the end-token stack even on exceptions.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.subparse or any code that pushes/pops self._end_token_stack during nested template parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2978971293c63f3bf2e83d25.md)

## Rule

- **Rule:**
  ```text
  When modifying Parser.parse_block, preserve the rejection of hyphens in block names with a targeted error, support for the 'scoped' and 'required' modifiers, and the requirement that required blocks contain only whitespace or comments (TemplateData nodes whose data isspace).
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When changing block parsing logic in Parser.parse_block.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3b040173e84d533795b5ef03.md)

## Rule

- **Rule:** Parser.parse must build a Template node from subparse with lineno=1 and set the environment on the result, defining the top-level parse contract.
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** When modifying the top-level parse entry point or Template node construction in the parser.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-476e2213e9cef19a03bcb78b.md)

## Rule

- **Rule:**
  ```text
  When modifying the parser's unary expression handling, preserve that unary minus/plus recursion passes with_filter=False so filters are not applied to the operand of a unary operator; filters apply only at the outer level when with_filter is true.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** when changing unary operator parsing or filter application in expressions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6574fc82cbd30bf253ad4f93.md)

## Rule

- **Rule:**
  ```text
  parse_with must parse a comma-separated list of assignment targets and expressions until block_end, set each target context to param, and require an endwith block.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** Modifying the {% with %} grammar or target context handling in the parser.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8de9556a1c775e4f177dd73b.md)

## Rule

- **Rule:**
  ```text
  `Parser` must remain the central parsing class passed to extensions and usable for parsing expressions or statements, serving as the documented extension point for parser-level customization.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying `Parser` or extension integration, preserve its role as the central parsing class passed to extensions and usable for parsing expressions or statements.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9bec1d2795dafd8a62068117.md)
