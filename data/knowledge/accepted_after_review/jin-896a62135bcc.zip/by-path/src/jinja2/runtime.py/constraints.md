# Constraints for `src/jinja2/runtime.py`

## Rule

- **Rule:**
  ```text
  The AsyncLoopContext class must subclass LoopContext and declare _iterator as an AsyncIterator, establishing the async iteration variant of loop context.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when modifying AsyncLoopContext or adding async iteration variants
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2b12fc074c4d5b95deb2d16a.md)

## Rule

- **Rule:** When modifying the async loop context, preserve that the last property is true when peeking the next item returns the missing sentinel, meaning the current iteration is the final one.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when changing async loop iteration state or the last property
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-444b98a8017d50f6b4568868.md)

## Rule

- **Rule:**
  ```text
  When modifying DebugUndefined.__str__, preserve that it produces a diagnostic message based on the undefined hint, the missing name, or the object type and name, wrapped as {{ message }}, so printed undefined values expose the reason for the failure.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when changing DebugUndefined string rendering or undefined diagnostics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5511db28de0c584e1597e834.md)

## Rule

- **Rule:**
  ```text
  When modifying runtime helpers, `identity` must continue to return its argument unchanged, as it is documented as useful for certain environment configuration points.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing the identity runtime helper or its use as an environment configuration point.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5a004f94bf29135f8b8b1565.md)

## Rule

- **Rule:**
  ```text
  Async loop context consumers must treat `nextitem` as returning an Undefined instance (message "there is no next item") when the peeked value is the `missing` sentinel, rather than expecting a raised error.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying or consuming the async loop context's `nextitem` property or its callers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-72bab24c07c2859d7ff65c68.md)

## Rule

- **Rule:**
  ```text
  runtime.py must define exported and async_exported name lists for the template runtime, and must delete __slots__ from Undefined and its subclasses after the metaclass is applied because the slots contain wrong data for subclasses.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When modifying runtime exports or the Undefined class hierarchy and its slots.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-73cd9ec4c02079236d1a4e04.md)

## Rule

- **Rule:**
  ```text
  AsyncLoopContext._to_iterator must convert any iterable or async iterable into an async iterator via auto_aiter, providing a uniform async iteration entry point.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying AsyncLoopContext._to_iterator or async iteration entry points.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-755af4f5e83eb11de59e0c07.md)

## Rule

- **Rule:** DebugUndefined must render its name as the original template expression when printed, but still raise UndefinedError on arithmetic.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Modifying DebugUndefined rendering or arithmetic error behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-75b0b52e9355c73649801293.md)

## Rule

- **Rule:**
  ```text
  When modifying the runtime loop-rendering interface, `LoopRenderFunc` must remain declared as a `te.Protocol` defining the callable interface for loop rendering used by the runtime.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing the runtime loop-rendering callable interface or its Protocol declaration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7b5a5f845d8ec3301fdcae5a.md)

## Rule

- **Rule:** The async call path must concatenate the async generator output from the current stack frame and wrap the result in Markup only when the evaluation context has autoescape enabled; otherwise it returns the raw string.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  when changing BlockReference._async_call or the async rendering concatenation and autoescape wrapping
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-baa930df6d856630af80e413.md)

## Rule

- **Rule:** When implementing ChainableUndefined attribute access, return self for any attribute so attribute chains on undefined values resolve to the same undefined object.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  Modifying ChainableUndefined.__getattr__ or adding chainable undefined behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e8e3350071fa1e774693fba4.md)

## Rule

- **Rule:** BlockReference.super must return an Undefined named 'super' with a 'there is no parent block called ...' message when depth+1 exceeds the stack, otherwise a BlockReference at depth+1, so super degrades to Undefined at the top block.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when changing BlockReference.super or the parent-block resolution stack behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f07be520b0cd722c986d4da6.md)
