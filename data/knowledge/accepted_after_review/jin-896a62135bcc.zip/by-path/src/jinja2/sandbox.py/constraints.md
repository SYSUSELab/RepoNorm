# Constraints for `src/jinja2/sandbox.py`

## Rule

- **Rule:**
  ```text
  When modifying `modifies_known_mutable`, preserve the conservative detection: return `True` only when the attribute is in the unsafe set for a matching builtin mutable type, and return `False` for unsupported objects such as strings.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When changing sandbox mutable-attribute detection or the unsafe attribute sets.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2d732b76bfafe15689e08bfd.md)

## Rule

- **Rule:**
  ```text
  ImmutableSandboxedEnvironment must behave exactly like SandboxedEnvironment except it forbids modifications to builtin mutable list, set, and dict via modifies_known_mutable; this is an API compatibility boundary for sandboxed environments.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying ImmutableSandboxedEnvironment or its modifies_known_mutable behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7d3777c60dd4ee931a2f01bf.md)

## Rule

- **Rule:**
  ```text
  SandboxedEnvironment.format_string must route formatting through SandboxedFormatter (or SandboxedEscapeFormatter for Markup), require exactly one positional argument and no kwargs for format_map, and return type(s)(rv) to preserve the input string type.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying format_string or adding sandboxed string formatting behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-91245afa2e28b0a12ef99d5e.md)

## Rule

- **Rule:** Sandboxed attribute access must raise a SecurityError via an undefined object whose message names the attribute and object type, preserving the sandbox's unsafe-attribute error contract.
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  Modifying sandbox attribute access or the unsafe_undefined error path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3d187187973709b29c0d0c0.md)

## Rule

- **Rule:**
  ```text
  `unsafe` must set `f.unsafe_callable = True` on the decorated function and return it, marking callables as unsafe for sandbox checks.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying the `unsafe` decorator or sandbox callable checks, preserve setting `f.unsafe_callable = True` and returning the function.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cbbf6d6b2dfe2aa40c0db403.md)

## Rule

- **Rule:**
  ```text
  `SandboxedEnvironment.is_safe_attribute` must return False for attributes starting with underscore or internal attributes, defining the default sandbox attribute-access policy.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying `SandboxedEnvironment.is_safe_attribute` or sandbox attribute policy, preserve the False result for underscore-prefixed and internal attributes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d7d114b0d95923fd2461b162.md)
