# Constraints for `src/jinja2/meta.py`

## Rule

- **Rule:**
  ```text
  `meta.py` must define `_ref_types` as the tuple (Extends, FromImport, Import, Include) and `_RefType` as the matching Union, establishing the canonical set of reference node types used for template introspection.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:**
  ```text
  When modifying `meta.py` reference-node handling, preserve `_ref_types` as the canonical tuple (Extends, FromImport, Import, Include) and `_RefType` as its matching Union.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-469dccf3648e3726ad5e4263.md)

## Rule

- **Rule:**
  ```text
  `find_referenced_templates` must yield `None` for any dynamic template expression (including non-const tuple/list items and unknown dynamic forms) while yielding string constants for hardcoded extends/include/import names.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:**
  ```text
  When modifying `find_referenced_templates` or the reference-node handling, preserve the None-for-dynamic / string-for-constant yield contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-adbf78c4161d3b11718cec5b.md)
