# Constraints for `src/jinja2/filters.py`

## Rule

- **Rule:**
  ```text
  When modifying the `do_center` filter, its value must continue to be coerced with `soft_str` before centering, so non-string values are safely converted rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing the do_center filter's input handling or coercion behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-07d71e5aea3d24a9c038218d.md)

## Rule

- **Rule:**
  ```text
  do_trim must strip leading and trailing characters from the value, defaulting to whitespace when chars is None, and coerce the input via soft_str before stripping.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** Modifying the trim filter or its input coercion behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1d07075205bcc502114cb9c6.md)

## Rule

- **Rule:** The last filter must not be applied to generators: callers must convert to a list first, an empty sequence yields Undefined rather than raising, and there is intentionally no async variant of last because it may be unsafe in async mode.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When modifying or adding filters, especially last, or when deciding whether a filter needs an async variant.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-478b41be9ba2bbf8a08ef851.md)

## Rule

- **Rule:** When marking a value unsafe, coerce it to str rather than wrapping it, so the returned value is a plain string.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Modifying do_mark_unsafe or adding a similar unsafe-marking filter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5417b76116866abac1ec355c.md)

## Rule

- **Rule:**
  ```text
  When adding an async variant of a sync filter or test, register it via the async_variant decorator so the wrapper carries jinja_async_variant=True and mirrors the sync behavior.
  ```
- **Applies to:**
  - `src/jinja2/async_utils.py`
  - `src/jinja2/filters.py`
- **Condition:** Adding or modifying an async filter/test variant that mirrors a sync counterpart.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-557e88d529edd6acf30755b8.md)

## Rule

- **Rule:**
  ```text
  do_reverse must keep its typing.overload declarations consistent with the implementation, including the str case, so typed callers see the correct return types.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_reverse or its typing.overload declarations.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-57ebfb151546765de3b24818.md)

## Rule

- **Rule:**
  ```text
  The async rejectattr filter must delegate to async_select_or_reject with a negated predicate, preserving sync/async filter parity.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** Modifying the async rejectattr filter or its relationship to the sync variant.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-58e3ef0158b9db4565842336.md)

## Rule

- **Rule:**
  ```text
  `prepare_map` must accept either an `attribute` keyword (with optional `default`) or a positional filter name, and must raise `FilterArgumentError` for unexpected keyword arguments or a missing filter argument.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying `prepare_map` argument handling or its callers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-614822a918db64d0810ffd3d.md)

## Rule

- **Rule:** The reverse filter must reverse strings directly, use reversed() for reversible iterables, fall back to materializing a list for non-reversible iterables, and raise FilterArgumentError when the value is not iterable.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** Modifying the reverse filter or its iterable-handling behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6537664417c101fd5d7f7732.md)

## Rule

- **Rule:**
  ```text
  When modifying `do_sort`, preserve stable sorting and support for a comma-separated attribute list such as 'age,name' (added in 2.11.0), enabling chained sorts on multiple attributes.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When changing the `sort` filter's attribute handling or ordering behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6b0575de41133285ae3f46c5.md)

## Rule

- **Rule:**
  ```text
  When modifying async filter variants, `do_sum` must remain registered as the async variant of `sync_do_sum` and accumulate over `auto_aiter(iterable)`, so async sum supports both async and sync iterables through the shared async_variant protocol.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing the async sum filter or the async_variant registration protocol for filters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8e93cbde9b5b4c97c3d75cfd.md)

## Rule

- **Rule:**
  ```text
  When modifying the mark_safe filter or its compiler counterpart, preserve the invariant that mark_safe returns a Markup instance (and MarkSafe nodes compile to an explicit Markup construction) so autoescaping is bypassed.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when changing mark_safe filter behavior or MarkSafe node compilation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8fab3120fbfc53bd21297e02.md)

## Rule

- **Rule:**
  ```text
  `do_unique` must yield items in first-occurrence order, keyed by a set of attribute keys; `case_sensitive=False` applies ignore_case postprocessing and `attribute` selects the key via make_attrgetter.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying `do_unique` or its key/ordering logic, preserve first-occurrence ordering and the case_sensitive/attribute key-selection contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-94c0140f0de2bd78f85584fc.md)

## Rule

- **Rule:**
  ```text
  The slice filter must divide a sequence into the requested number of slices, distribute remainder items to the earliest slices, and append fill_with only to slices beyond the remainder count.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when changing sync_do_slice or the slice filter's distribution and fill_with behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95c1bf8e7d273c23a4586171.md)

## Rule

- **Rule:**
  ```text
  The `min` filter must default `case_sensitive` to False and support an `attribute` parameter, delegating to `_min_or_max` for the public signature and default comparison behavior.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying the `min` filter signature, defaults, or its delegation to `_min_or_max`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9fed7c5d68b055a07139330a.md)

## Rule

- **Rule:**
  ```text
  do_indent must accept width as either an int or a string, preserve Markup types for indentation and newline, and by default not indent the first line or blank lines; the blank and first parameters change that behavior.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when changing do_indent or its width/blank/first parameter handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a1458f33e4649943d2aec14a.md)

## Rule

- **Rule:**
  ```text
  When modifying `do_capitalize`, preserve the coercion of the input via `soft_str` before capitalizing, so non-string values are converted to strings first.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When changing the `capitalize` filter or its input handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a6cc1960e932ed5319be600e.md)

## Rule

- **Rule:**
  ```text
  async_select_or_reject must only build the predicate when value is truthy and yield items from auto_aiter(value) that pass the predicate, mirroring the sync select/reject behavior for async iterables.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying async_select_or_reject or async select/reject filter behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af9e3a478c31257782fa5832.md)

## Rule

- **Rule:** When a sequence is empty, the first filter must return environment.undefined("No first item, sequence was empty.") rather than raising StopIteration.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** Modifying the first filter or its handling of empty sequences.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-baaf053a12eab28df3423c3c.md)

## Rule

- **Rule:**
  ```text
  When modifying do_filesizeformat, preserve that it uses base 1000 by default and base 1024 when binary=True, returns "1 Byte" for exactly one byte, formats values below the base as integer "Bytes", and extends the prefix list through YiB/YB.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when changing filesizeformat base selection, byte formatting, or prefix list
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c5039c7d30deaa169762f2ed.md)

## Rule

- **Rule:**
  ```text
  do_tojson must be decorated with pass_eval_context and return Markup via htmlsafe_json_dumps, using eval_ctx.environment.policies["json.dumps_function"] and json.dumps_kwargs; output is safe for HTML and <script> tags but not for double-quoted HTML attributes, where |forceescape should be used.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_tojson or its HTML-safety contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ce511a0ab0c9bcc96baf4c17.md)

## Rule

- **Rule:**
  ```text
  `do_groupby` must be registered as an async_variant of `sync_do_groupby` and await `auto_to_list` on both the input and each group's values, sorting by the attribute expression before grouping, so async groupby preserves the sync grouping contract over async iterables.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying `do_groupby` or its async registration, preserve the async_variant registration, auto_to_list awaiting on input and group values, and attribute-expression sorting before grouping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d6c5c618707d0ae1144db966.md)

## Rule

- **Rule:**
  ```text
  `do_float` must return `float(value)` and fall back to the default (0.0) on TypeError or ValueError, with no string-prefix or base handling.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying `do_float` or its error handling, preserve the float(value) conversion and TypeError/ValueError fallback to the default without adding prefix/base parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dd857ae14aebb2e1a38f9f8d.md)

## Rule

- **Rule:**
  ```text
  The sync_do_groupby filter must sort the input by the attribute getter before grouping, so that unlike itertools.groupby only one group per unique value is produced; it must support dot-notation attributes and a default value for missing attributes, and yield namedtuples of (grouper, list).
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying sync_do_groupby or adding similar grouping filters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ffa90003bd0dca695f724456.md)
