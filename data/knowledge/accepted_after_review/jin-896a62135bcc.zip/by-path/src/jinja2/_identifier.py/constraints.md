# Constraints for `src/jinja2/_identifier.py`

## Rule

- **Rule:**
  ```text
  Changes to the identifier-pattern generator must preserve the generated-artifact convention: main() builds a regex pattern and writes it to src/jinja2/_identifier.py with a generated-by header, so the identifier pattern file is machine-generated and should not be hand-edited.
  ```
- **Applies to:**
  - `scripts/generate_identifier_pattern.py`
  - `src/jinja2/_identifier.py`
- **Condition:**
  ```text
  When modifying the identifier pattern or the generator that produces src/jinja2/_identifier.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6b1b3a0fdd31c263fdf65f0e.md)
