# Constraints for `src/jinja2/bccache.py`

## Rule

- **Rule:**
  ```text
  MemcachedBytecodeCache must document and rely on a minimal client interface of set(key, value[, timeout]) and get(key) returning None on miss; the Django cache interface is incompatible because it cannot store binary data.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying MemcachedBytecodeCache or its client interface expectations.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2450bcd2d0177c9fbb08c02e.md)

## Rule

- **Rule:**
  ```text
  `Bucket.load_bytecode` must validate the magic header, then the checksum, then attempt `marshal.load`; any mismatch or (EOFError, ValueError, TypeError) must trigger `reset()` and return without setting code, discarding stale or corrupt bytecode.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  When modifying `Bucket.load_bytecode` or its validation order, preserve the magic-then-checksum-then-marshal sequence and the reset-and-return-without-code behavior on mismatch or (EOFError, ValueError, TypeError).
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7a72b223736d56e6099b4e09.md)

## Rule

- **Rule:**
  ```text
  `MemcachedBytecodeCache.load_bytecode` must swallow memcache client exceptions only when `ignore_memcache_errors` is true; otherwise it re-raises, and on success it loads bytecode from the retrieved value.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  When modifying `MemcachedBytecodeCache.load_bytecode` or its error handling, preserve the ignore_memcache_errors-gated swallowing and re-raise behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9a70e979517693705499f944.md)
