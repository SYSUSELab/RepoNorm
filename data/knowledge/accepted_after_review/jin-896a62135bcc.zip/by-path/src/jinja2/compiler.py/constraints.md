# Constraints for `src/jinja2/compiler.py`

## Rule

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Template, preserve the inheritance codegen: yield from parent_template.root_render_func(context) in sync mode and async for with yield event in async mode, gated on parent_template not being None when extends is not statically known.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When changing template inheritance code generation in CodeGenerator.visit_Template.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-02f81ba8b17aafeb757232a2.md)

## Rule

- **Rule:**
  ```text
  Code emission decisions between async and sync variants must be centralized through `choose_async`, which returns the async value when the environment is async and the sync value otherwise.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When adding or modifying code paths that emit async versus sync variants in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-182078311befd4b7b7e6a1c7.md)

## Rule

- **Rule:**
  ```text
  When creating a soft frame for if-statements or conditional expressions, return a copy sharing resources with rootlevel=False and soft_frame=True, and do not modify soft frames standalone.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Modifying Frame.soft or adding soft-frame usage for conditionals.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-24117a4359e23d01eb197586.md)

## Rule

- **Rule:** When modifying the compiler's output-child emission, preserve the eval-context-dependent escaping selection: volatile contexts must use a runtime autoescape check, autoescape contexts must use escape(), and other contexts must use str(), with finalize source prepended when present.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when changing how output children are compiled or how escaping/finalize is selected
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-278eae334aa93a488ed81cf2.md)

## Rule

- **Rule:**
  ```text
  `CodeGenerator.optimized` must report whether an optimizer is configured, so optimization is enabled by the presence of an optimizer instance.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying `CodeGenerator.optimized` or optimizer configuration, preserve the property's dependence on the presence of an optimizer instance.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2cb89f8b1e546fcb20c6f43f.md)

## Rule

- **Rule:**
  ```text
  CodeGenerator.signature must detect Python-keyword kwarg names and switch to a dict-literal call form, merging extra_kwargs and dyn_kwargs so generated calls remain valid Python.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when changing CodeGenerator.signature or the kwargs-merging logic that emits generated call arguments
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-37129ee82e88fc7f2013b8c8.md)

## Rule

- **Rule:**
  ```text
  Assignment-tracking code must only be emitted when the frame is a block frame, loop frame, or toplevel and there are tracked vars; single-name assignments write directly to _loop_vars, _block_vars, or context.vars, while multiple names use .update({...}).
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Modifying CodeGenerator.pop_assign_tracking or the assignment-tracking emission logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3752daaf675aa02c2b742855.md)

## Rule

- **Rule:** Compiler errors must be raised via CodeGenerator.fail as TemplateAssertionError carrying the message, line number, template name, and filename so source location metadata is preserved.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When adding or modifying compiler error reporting in the code generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3cbaf6985c39d80057f11b94.md)

## Rule

- **Rule:**
  ```text
  When modifying the compiler's import emission, preserve that _import_common emits make_module or make_module_async depending on async mode, passes with_context plus the dumped local context, and emits _get_default_module(_async) when no context is given.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when changing how imports with or without context are compiled
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-45daf9d0b9e06eccfa859056.md)

## Rule

- **Rule:**
  ```text
  visit_TemplateData must attempt constant folding via node.as_const and, when Impossible is raised, fall back to a runtime expression that applies Markup only if autoescape is enabled, preserving escaping semantics for non-constant template data.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Modifying CodeGenerator.visit_TemplateData or the constant-folding fallback for template data.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4f18884440157cac1b3f81e6.md)

## Rule

- **Rule:**
  ```text
  When modifying `visit_AssignBlock` in the compiler, preserve the behavior of disabling output checks for the block frame so set blocks can be used at top level in extended templates, and wrapping the captured buffer with `Markup` or identity based on autoescape.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing code generation for assignment blocks or set blocks in extended templates.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5138ce43b5ddb4d592a4edd4.md)

## Rule

- **Rule:**
  ```text
  The compiler's `new_func` wrapper must run the optimizer only when `self.optimizer` is not None and the frame's `eval_ctx` is not volatile, and must re-visit the optimized node only if it differs from the original.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying the optimizer invocation wrapper or its guards in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-52127d215d2f6fb7921fc0b1.md)

## Rule

- **Rule:**
  ```text
  When modifying CodeGenerator operator visitors, preserve the table-driven generation via _make_binop/_make_unop factory assignments rather than hand-written per-operator visitors.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When adding or changing binary/unary operator code generation in CodeGenerator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-54700dfd33a068d882fc7eed.md)

## Rule

- **Rule:**
  ```text
  When modifying compiler visitor traversal, `VisitorExit` must remain a `RuntimeError` subclass used by `UndeclaredNameVisitor` to signal an early stop, so traversal control flow continues to rely on this exception.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Changing compiler visitor traversal or the early-stop mechanism used by UndeclaredNameVisitor.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5818f9d593b6cc9314bfae09.md)

## Rule

- **Rule:**
  ```text
  When modifying the compiler's call-expression code generation, preserve the single shared path that emits `await auto_await(...)` under an async environment and dispatches through `environment.call(context, ...)` when sandboxed versus `context.call(...)` otherwise; do not fork async and sandboxed call handling into separate code paths.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing how call expressions are compiled, including async or sandboxed call handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5ade34da29b2541806e38336.md)

## Rule

- **Rule:**
  ```text
  Macro code generation must emit a Macro(...) call whose argument tuple is built from macro_ref.node.args, appending a trailing comma for a single argument, and pass accesses_kwargs, accesses_varargs, accesses_caller, and context.eval_ctx.autoescape.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying CodeGenerator.macro_def or macro code generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5c2cbebb1bbfaea07f41c0e4.md)

## Rule

- **Rule:**
  ```text
  The CodeGenerator.visit_Template method must assert no root frame is passed, import exported runtime names (adding async_exported when environment.is_async), and fail compilation when a block name is defined twice.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  when modifying CodeGenerator.visit_Template or adding template compilation entry points
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5cd83989cc7291f300a4c12f.md)

## Rule

- **Rule:**
  ```text
  The compiler's `operators` mapping must map Jinja operator names (`eq`, `ne`, `gt`, `gteq`, `lt`, `lteq`, `in`, `notin`) to Python operator strings, driving code generation for comparison and membership expressions.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying the compiler's operator mapping or code generation for comparison and membership expressions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5fbd58762ef4e5063c3e9380.md)

## Rule

- **Rule:** The CodeGenerator.writeline method must pair a newline with the written text by calling newline(node, extra) followed by write(x), so that line-oriented code emission always maintains line structure.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when modifying CodeGenerator.writeline or adding line-oriented emission helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-608988e3dc05d5079a2b0300.md)

## Rule

- **Rule:**
  ```text
  The CodeGenerator._output_const_repr method must concatenate a group of constant values and return repr(concat(group)) for writing to the generated module source.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  when modifying CodeGenerator._output_const_repr or adding constant-output helpers
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-67635ca77e48d82b2f6111b1.md)

## Rule

- **Rule:**
  ```text
  macro_body must reject an explicitly listed 'caller' argument without a default, and must declare kwargs/varargs parameters only when undeclared in the body and not already explicit parameters.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Modifying macro argument compilation or the caller/kwargs/varargs handling in the code generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7735d6aa3e8de3e0ae98e3a2.md)

## Rule

- **Rule:** Frame.inner must return a new Frame at symbols.level + 1 when isolated, otherwise a child Frame sharing the current frame, defining symbol scoping for nested frames.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying Frame.inner or nested frame symbol scoping in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7e8d3a7952c06523d71f1475.md)

## Rule

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_FromImport, preserve the getattr lookup with a missing sentinel, assignment of undefined with a message when a name is absent, and updates to context.vars or exported_vars depending on top-level aliases and underscore prefixes.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When changing import code generation in CodeGenerator.visit_FromImport.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-81a301b14486959f50941a73.md)

## Rule

- **Rule:** When analyzing a scope node, create an inner frame, analyze symbols for the scope, enter the frame, visit the body, and leave the frame so scope-local symbol analysis is isolated from the enclosing frame.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Modifying visit_Scope or adding scope-handling logic in the compiler.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-831b9fbd2f21241987d10535.md)

## Rule

- **Rule:**
  ```text
  When modifying the mark_safe filter or its compiler counterpart, preserve the invariant that mark_safe returns a Markup instance (and MarkSafe nodes compile to an explicit Markup construction) so autoescaping is bypassed.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when changing mark_safe filter behavior or MarkSafe node compilation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8fab3120fbfc53bd21297e02.md)

## Rule

- **Rule:** When a template uses {% set %} with a non-constant value, the compiler must mark the eval context volatile so the generated code re-evaluates the context at runtime; constant values may be folded at compile time.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Modifying EvalContextModifier compilation or eval-context constant folding in the code generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-91cd910bbd751c2beff54dd3.md)

## Rule

- **Rule:**
  ```text
  pop_assign_tracking must add only public (non-underscore-prefixed) names to context.exported_vars, using add for a single name and update for multiple names.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Modifying assignment tracking or exported variable collection in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae48ae6e8404c17be7fe4efa.md)

## Rule

- **Rule:**
  ```text
  CodeGenerator.write must defer newlines and indentation until the next write: emit pending newlines, update code_lineno, record debug info, then write indentation before the actual string, so generated code line numbers track emitted newlines.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying CodeGenerator.write or generated-code line-number tracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b5decf38f5227a3d2c935b4a.md)

## Rule

- **Rule:**
  ```text
  UndeclaredNameVisitor.visit_Block must stop block visiting and not recurse into block body nodes.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying UndeclaredNameVisitor.visit_Block or block-body traversal in the compiler.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bc8b38d6ff8685c1638b35cc.md)

## Rule

- **Rule:**
  ```text
  optimizeconst must wrap compiler visitor methods via update_wrapper to optimize constant folding, and contributors adding constant-folding behavior should apply it consistently.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When adding or modifying constant-folding behavior in compiler visitor methods.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cd3282727869ab0d7140f9c2.md)

## Rule

- **Rule:**
  ```text
  When modifying compiler output emission, `_output_child_post` must write the closing parenthesis and, when `finalize.src` is not None, write an additional closing parenthesis so finalized output expressions remain wrapped in extra parentheses.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Changing how the compiler emits closing parentheses for child expressions, especially finalized ones.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ce1e8034ddeb6522aa079b11.md)

## Rule

- **Rule:** Tuple code generation must always emit a trailing comma for single-element tuples and a plain closing parenthesis otherwise, preserving valid Python tuple syntax in generated code.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  when changing CodeGenerator.visit_Tuple or tuple literal emission in generated code
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f6c30cfaf53f53bef40dd45b.md)

## Rule

- **Rule:**
  ```text
  When modifying `visit_Continue`, preserve the mapping from a `Continue` AST node to a generated 'continue' statement line.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When changing code generation for `Continue` nodes or loop control statements.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f90cff74d66d65bee53ad16a.md)
