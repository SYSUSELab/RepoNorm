# Constraints for `src/jinja2/optimizer.py`

## Rule

- **Rule:** The optimizer must not perform optimizations such as loop unrolling because the AST lacks full scoping information; a second syntax tree storing scoping rules would be required.
- **Applies to:**
  - `src/jinja2/optimizer.py`
- **Condition:** When modifying the optimizer or considering scoping-dependent optimizations, preserve the limitation that loop unrolling and similar optimizations require a second syntax tree with scoping rules.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2c3403feda11f5658faf8cb0.md)
