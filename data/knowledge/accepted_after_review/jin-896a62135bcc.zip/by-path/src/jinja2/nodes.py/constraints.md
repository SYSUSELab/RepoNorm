# Constraints for `src/jinja2/nodes.py`

## Rule

- **Rule:** The Dict literal node must represent dict literals and require its items field to be a list of Pair nodes.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying the Dict node definition or its items field contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-095538d388bf5c0776510d4b.md)

## Rule

- **Rule:**
  ```text
  Tuple.can_assign must return True only if every item can be assigned, making assignment validity conjunctive across all items.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  Modifying Tuple.can_assign or assignment-validity logic for tuple/list nodes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0d585fe3fc040df244ec213f.md)

## Rule

- **Rule:** The UnaryExpr class must be an abstract Expr base class with fields = ("node",), a node: Expr child, and an operator: str, so that unary expression subclasses supply these fields.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying UnaryExpr or adding unary expression subclasses
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-13847972bd17f3f5dfe02cd9.md)

## Rule

- **Rule:** OverlayScope must remain an extension-facing Stmt node with fields (context, body); context must evaluate to a dictionary and is used to inject arbitrary variables into a sub-scope.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying the OverlayScope node definition or its context/body fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1ac8052007135593df916058.md)

## Rule

- **Rule:**
  ```text
  `Node.as_const` must raise `Impossible` by default, so subclasses that support constant evaluation must override it; callers may pass an `EvalContext` or rely on a default context requiring an attached environment.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When adding or modifying constant-evaluation support on AST node subclasses.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1ebf4acc438cc99cf2d49a9c.md)

## Rule

- **Rule:** Statement node types must be defined as subclasses of Stmt (e.g., Continue is a Stmt node representing loop continuation).
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Adding new statement node types to the nodes module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-246725ed3ed803bf07bd417d.md)

## Rule

- **Rule:**
  ```text
  Node.can_assign must default to False so that nodes are non-assignable unless they explicitly override it; assignment targets must opt in.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  Modifying Expr.can_assign or adding new node types that may be assignment targets.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-28d4b6bb69ddec9e1c7c0d32.md)

## Rule

- **Rule:** When modifying node classes in jinja2.nodes, preserve the convention that node classes declare their child fields explicitly via a fields tuple (e.g., Scope declares fields = ("body",) with body typed as a list of Node).
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when adding or changing node classes and their child fields
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2ba817249c0112836228a504.md)

## Rule

- **Rule:** EvalContext is an extension point: it holds evaluation-time information and explicitly allows extensions to attach custom attributes.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying EvalContext or its attribute surface used by extensions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-35b4e0c31edb8068536cde74.md)

## Rule

- **Rule:** The Sub node must remain a BinExpr subclass whose operator attribute is '-', defining the subtraction operator mapping.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying the Sub node or binary operator mappings.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4aace85a0df28b0649c06c81.md)

## Rule

- **Rule:**
  ```text
  When defining a binary operator AST node, set the operator attribute to the exact operator string (e.g. '**' for Pow) so the node maps to the correct operator.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Adding or modifying a binary operator AST node class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-507c3d8959bf878ac19fc859.md)

## Rule

- **Rule:**
  ```text
  When modifying `EnvironmentAttribute`, preserve it as an `Expr` node with a single 'name' field, intended for extensions to load an attribute from the environment object.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When changing the `EnvironmentAttribute` node or extension-facing environment attribute loading.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5736a388484ed575f24f2ee7.md)

## Rule

- **Rule:** The Compare node must declare fields ("expr", "ops") and type ops as a list of Operand, defining the AST shape for comparison expressions.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying the Compare AST node schema or its ops typing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5b7b47c5ec6708cb23a1afea.md)

## Rule

- **Rule:**
  ```text
  When modifying the AST node definitions, `CondExpr` must keep its field contract: fields `test`, `expr1`, and optional `expr2`, modeling `foo if bar else baz`.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing the CondExpr AST node's fields or their optionality.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5c145e0f55f10fdf73e75c54.md)

## Rule

- **Rule:**
  ```text
  NodeType.__new__ must remain replaced with _failing_new and the helper deleted, enforcing that nobody creates custom node types at runtime.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying NodeType or adding new node type creation paths.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-673c7111dc610327321f5744.md)

## Rule

- **Rule:**
  ```text
  `EvalContext.revert` must clear `self.__dict__` and update it with the old mapping to restore a node's prior attribute state.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying `EvalContext.revert` or code that relies on restoring prior node attribute state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-71659cb287d8af070f595625.md)

## Rule

- **Rule:** DerivedContextReference must behave exactly like ContextReference but include local variables such as those from a for loop.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying or adding context-reference AST nodes in jinja2.nodes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-734885278ee295c85121abd0.md)

## Rule

- **Rule:** Break must remain a Stmt node representing a loop break, preserving its node kind and parent relationship for parser and compiler consumers.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying Break or loop-control node definitions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-819288a41c0388f7da64da02.md)

## Rule

- **Rule:**
  ```text
  When modifying the AST node definitions, `FilterBlock` must keep its field contract: fields tuple `("body", "filter")` with `body` a list of Node and `filter` a Filter node.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing the FilterBlock AST node's fields or their typing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8dc23b69ac0ed7d225f8c02b.md)

## Rule

- **Rule:**
  ```text
  When modifying the AST node definitions, `For` must keep its field contract: fields `target`, `iter`, `body`, `else_`, `test`, and `recursive`, with `else_` an empty list when no else node exists and `test` None for unfiltered loops.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing the For AST node's fields or their default/empty conventions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9ec00059b5984bc946a5f164.md)

## Rule

- **Rule:** The With node must declare fields targets, values, and body, replacing the older Scope-based implementation.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying or adding AST node classes in jinja2.nodes, especially With.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bdb3df2d8a381429db7c9b3c.md)

## Rule

- **Rule:**
  ```text
  When modifying `Concat.as_const`, preserve constant evaluation of a node list as string concatenation of `str(x.as_const(eval_ctx))` for child nodes.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When changing constant evaluation for concatenation nodes or node lists.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c01e2ffad3b5c7f53c4416f0.md)

## Rule

- **Rule:**
  ```text
  Tuple.as_const must recursively evaluate each item with the resolved eval context and return a tuple, so constant folding of tuple literals depends on each element's as_const.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  Modifying Tuple.as_const or constant folding of tuple literals.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d6d07e2553902fa3e6b45c12.md)

## Rule

- **Rule:** AssignBlock must be a Stmt node with fields ("target", "filter", "body"), where filter is optional, representing block assignment with an optional filter.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying the AssignBlock AST node schema or its optional filter field.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d9eb9552ea6e17d9d867ac5b.md)

## Rule

- **Rule:**
  ```text
  The Slice.as_const method must build a Python slice from const-evaluated start, stop, and step, so that slice bounds in templates are evaluated through the node constant machinery.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  when modifying Slice.as_const or adding similar constant-evaluation methods
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e03f487829b52dc771ed8505.md)

## Rule

- **Rule:** Stmt must be the abstract base node for all statement nodes, so concrete statement node types must inherit from it.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Adding or modifying statement node types in the AST hierarchy.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ed58e48addb00ceeae630340.md)

## Rule

- **Rule:**
  ```text
  The Include AST node must declare fields template, with_context, and ignore_missing.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying or adding AST node classes in jinja2.nodes, especially Include.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-edaa53c14d48195da3dd9189.md)

## Rule

- **Rule:** When modifying TemplateData, preserve that it is a Literal node with a single data field holding a constant template string.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when changing TemplateData node definition or its data field
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ee24ff2f200c272278f3284f.md)
