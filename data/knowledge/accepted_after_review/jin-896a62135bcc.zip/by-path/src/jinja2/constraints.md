# Constraints for `src/jinja2`

## Rule

- **Rule:** mypy is configured to disallow untyped function definitions.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0223fce7901c6622aa892dbc.md)

## Rule

- **Rule:** mypy is configured to warn when returning a value of type Any.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-09f84d943ee39f82aeb9de42.md)

## Rule

- **Rule:** mypy is configured to disallow subclassing Any.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-31bc667a181fc3ef361525e2.md)

## Rule

- **Rule:** mypy is configured to enable local partial types.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-34e2a3e299086caaeeafd9be.md)

## Rule

- **Rule:** mypy is configured to disallow implicit Optional.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4da224a47e4fe085e24814e7.md)

## Rule

- **Rule:** mypy is configured to warn about unused configuration options.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5663b76b8861766fda9048fc.md)

## Rule

- **Rule:** mypy is configured to show error codes.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7b486c5ac67f732e69e169c4.md)

## Rule

- **Rule:** mypy is configured to disallow implicit re-export.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9946b04f1e188f446dbd2cfd.md)

## Rule

- **Rule:** mypy is configured to disallow incomplete function definitions.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ad0827d7944e563174155abe.md)

## Rule

- **Rule:** mypy is configured to warn about unreachable code.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b784a3a6a311b75dc1c879e7.md)

## Rule

- **Rule:**
  ```text
  mypy is configured with python_version 3.7.
  ```
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d0bb27db9426e16c678a7174.md)

## Rule

- **Rule:** mypy is configured to warn about redundant casts.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d177bff4a3ca93e15acbafda.md)

## Rule

- **Rule:** mypy is configured to disallow calls to untyped functions.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e4815e658d4365a5761949fc.md)

## Rule

- **Rule:** mypy is configured to warn about unused type ignores.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e55a62403c350eeb21382e73.md)

## Rule

- **Rule:** mypy is configured to check the files under src/jinja2.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f2d73a9c78868e473072bcff.md)

## Rule

- **Rule:** mypy is configured to enable strict equality checks.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f84bd1d287219da1351941d6.md)
