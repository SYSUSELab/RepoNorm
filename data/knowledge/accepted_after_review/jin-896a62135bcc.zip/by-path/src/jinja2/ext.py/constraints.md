# Constraints for `src/jinja2/ext.py`

## Rule

- **Rule:**
  ```text
  The extension base __init__ must store the Environment instance on self.environment as the standard extension access point.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Modifying extension initialization or environment access in extensions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-103dd7ada6c8353227930676.md)

## Rule

- **Rule:** LoopControlExtension.parse must consume the next token and return nodes.Break when the token value is 'break', otherwise nodes.Continue, dispatching on the token value.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** When modifying LoopControlExtension.parse or break/continue extension parsing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1ac3ba2530212f5d4be7b433.md)

## Rule

- **Rule:**
  ```text
  When modifying `_trim_whitespace` in the i18n extension, preserve the normalization that strips the string and collapses internal whitespace runs to a single space via the module-level `_ws_re` pattern.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** When changing whitespace normalization used by the i18n extension.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-262846ea9d1331d1276027cb.md)

## Rule

- **Rule:** Extension classes must declare their registered template tag names via a tags attribute (e.g., LoopControlExtension declares break and continue; ExprStmtExtension declares do).
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Adding or modifying an Extension subclass that registers template tags.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5245e25a0e079bf7f191b2ce.md)

## Rule

- **Rule:**
  ```text
  When modifying the i18n extension's installation, preserve the preference for `ugettext`/`ungettext` over `gettext`/`ngettext` when present, falling back to the standard names, to retain older Python gettext compatibility.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** When changing how the i18n extension installs or resolves gettext callables.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7becfb58472354764410afa3.md)

## Rule

- **Rule:**
  ```text
  When modifying `_gettext_alias`, preserve it as a pass-context function that resolves and calls the context's 'gettext' callable, providing the `_` alias used in templates.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When changing the `_` gettext alias or its context resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7ee06af848e6e1b5c269e14b.md)

## Rule

- **Rule:**
  ```text
  When modifying the i18n extension, `InternationalizationExtension.__init__` must install `_` as a global and extend the environment with `install_gettext_translations`, `install_null_translations`, `install_gettext_callables`, `uninstall_gettext_translations`, `extract_translations`, and `newstyle_gettext=False`, preserving the extension's public environment API surface.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Changing the i18n extension's initialization or its environment API surface.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9f249113a7d6b8bcdede401f.md)

## Rule

- **Rule:**
  ```text
  When modifying InternationalizationExtension._make_node, preserve the distinction between newstyle gettext (variables as keyword arguments, skipping 'num' when num_called_num) and old style (MarkSafeIfAutoescape wrapping with dict modulo substitution).
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When changing i18n node generation in InternationalizationExtension._make_node.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bb3169caee50e4e26fc36d58.md)

## Rule

- **Rule:**
  ```text
  `_parse_block` must enforce that a translatable section contains at most one pluralize section, forbid control structures inside translatable sections, and fail on unclosed translation blocks with explicit messages.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When modifying `_parse_block` or the i18n extension's block parsing rules.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-beba3c1313156a9ca3e9df43.md)

## Rule

- **Rule:** Extension.preprocess is the pre-lexing hook that receives source, name, and optional filename and must return the preprocessed source, defaulting to identity.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** when changing Extension.preprocess or the pre-lexing extension hook contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c14aaab969198db1d69752bf.md)

## Rule

- **Rule:**
  ```text
  When modifying `getbool` in the babel extraction helper, preserve the exact true-string set: the lowercased option value is true only for '1', 'on', 'yes', and 'true', defaulting to `str(default)` when the key is absent.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** When changing boolean option parsing for babel extraction or similar extension options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c620ff09b1d6437ae1414698.md)
