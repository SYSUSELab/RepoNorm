# Constraints for `src/jinja2/exceptions.py`

## Rule

- **Rule:**
  ```text
  TemplatesNotFound must build its message from the names sequence using each Undefined name's _undefined_message joined by commas, store the names list on self.templates, and pass the last name to the base exception.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** Modifying TemplatesNotFound construction or its message/attribute contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d707e53802cbb794de37a0a.md)

## Rule

- **Rule:**
  ```text
  When modifying jinja2.exceptions, preserve that Undefined is imported only under TYPE_CHECKING, so runtime code in this module must not depend on the runtime Undefined object.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** when adding runtime code to jinja2.exceptions that references Undefined
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-599d440333c66e747b86e276.md)

## Rule

- **Rule:** When adding a filter-argument error, subclass TemplateRuntimeError so callers catching TemplateRuntimeError also catch filter-argument misuse.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** Adding or modifying a filter-argument exception class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-87f491da31861b51a9589ee9.md)

## Rule

- **Rule:** The SecurityError exception must subclass TemplateRuntimeError and be raised when a template attempts an insecure operation while the sandbox is enabled.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** when modifying SecurityError or adding sandbox-related exceptions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ac1b576ea2f336fe7dbe3ad4.md)

## Rule

- **Rule:**
  ```text
  TemplateSyntaxError.__init__ must store lineno, name, filename, initialize source to None, and set translated = False, which debug.translate_syntax_error flips to True when it rewrites the traceback.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:**
  ```text
  When modifying TemplateSyntaxError.__init__ or debug.translate_syntax_error.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fb9ce14250be0f33ceaca0f8.md)
