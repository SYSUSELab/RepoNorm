# Constraints for `src/jinja2/debug.py`

## Rule

- **Rule:**
  ```text
  fake_traceback must synthesize a traceback pointing at template source by compiling a raise statement at the template line, replacing co_name with "top-level template code" for root or "block <name>" for block_ functions, and using version-conditional code replacement for Python 3.8+.
  ```
- **Applies to:**
  - `src/jinja2/debug.py`
- **Condition:**
  ```text
  When modifying fake_traceback or template traceback synthesis.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ede5a3dc6e0c81f1ced1279b.md)
