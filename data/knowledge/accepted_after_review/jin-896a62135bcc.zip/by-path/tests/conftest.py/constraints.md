# Constraints for `tests/conftest.py`

## Rule

- **Rule:** The env fixture in tests/conftest.py must return a fresh Environment() per test, ensuring isolated default environments.
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When adding or modifying the env fixture in tests/conftest.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6c6215013f9bcbece00639f1.md)
