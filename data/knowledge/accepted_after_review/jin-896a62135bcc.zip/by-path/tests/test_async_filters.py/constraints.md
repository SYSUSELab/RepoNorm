# Constraints for `tests/test_async_filters.py`

## Rule

- **Rule:**
  ```text
  The async filter tests must build user data as a namedtuple with fields `name` and `is_active`, including both active and inactive users, so filter behavior can be asserted against a stable mixed dataset.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When modifying or extending async filter test fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3ceae9326d7751b8ceffc550.md)

## Rule

- **Rule:** groupby('date.year') on async articles must group by nested attribute and render year groups in order, including a trailing empty segment.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** when modifying async groupby multidot tests or the nested-attribute grouping contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-45bc6beaec88b910651fa7a4.md)

## Rule

- **Rule:**
  ```text
  Tests for custom async filters must assert that filters registered on env_async.filters are applied to both static and dynamic values, with the rendered output preserving the filter results.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** when adding or modifying tests for custom async filters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4c01fc10d19bc9dae99f5900.md)

## Rule

- **Rule:** When modifying the select filter, preserve that without a test it keeps only truthy values.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** Changing the select filter's default truthiness behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-67d7ee35a8b8a123c09cd11e.md)

## Rule

- **Rule:** Tests for the join filter with an attribute argument must assert that the named attribute of each item is rendered and joined, e.g. usernames joined as 'foo, bar'.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** when adding or modifying tests for the join filter with an attribute argument
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-78338f815a60f67be8cb7fc4.md)

## Rule

- **Rule:** Tests for groupby must assert grouping by a tuple index and preservation of per-group ordering.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When adding or modifying tests for groupby with tuple index arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9624a5bdf7850fa39c1c685a.md)

## Rule

- **Rule:** Tests for the reject filter must assert that falsy values (None, False, 0) are retained when no test argument is supplied, so that joining such values preserves them in the output.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** when adding or modifying tests for the reject filter's behavior without a test argument
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-97554ddc364287b969e41630.md)

## Rule

- **Rule:** Tests for the map filter in async environments must assert that applying map to None yields an empty list rather than raising, treating None as an empty iterable.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When adding or modifying tests for the map filter with None or empty input in async environments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c1acf32b250ed6ebc8dd4dc3.md)

## Rule

- **Rule:** Tests that exercise slice filtering must assert the exact chunking and fill behavior, including the number of slices and the fill value used for the last slice.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:**
  ```text
  When modifying slice filter chunking or fill behavior in tests/test_async_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e4c5ebc4de5c2af303b9c099.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Jinja filter behavior must preserve the documented filter semantics: `sum` accepts a string attribute argument (including dotted paths like 'real.value') and sums that attribute across items; `groupby` accepts dotted attribute paths like 'date.year'; `rejectattr` combined with `map(attribute=...)` and `join` filters by attribute; and `indent` preserves behavior when the input is a Markup instance.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
  - `tests/test_filters.py`
- **Condition:** When modifying or adding tests for the sum, groupby, rejectattr, or indent filters, including their attribute-path and Markup-input variants.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f5078073bb74ad8bcc47fe5b.md)
