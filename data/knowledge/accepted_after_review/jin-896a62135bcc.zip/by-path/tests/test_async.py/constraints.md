# Constraints for `tests/test_async.py`

## Rule

- **Rule:**
  ```text
  Async template for-loop tests must verify that iterating reversed([3, 2, 1]) with loop.last produces '1,2,3', covering reversed iteration and loop.last in async templates.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying or adding async template tests for reversed iteration and loop.last behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1aa67582f15f685880c35cc2.md)

## Rule

- **Rule:** Template include directives must raise TemplateNotFound when the referenced template is missing, unless the directive carries the 'ignore missing' modifier, in which case rendering must produce an empty string.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying or adding tests for include directives that reference missing templates, including the 'ignore missing' modifier with or without context.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2140befd3c1157978ce433db.md)

## Rule

- **Rule:**
  ```text
  Async template rendering must support awaiting async callables passed as context variables, and render_async must accept both async and normal callables in the same context.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  when modifying async rendering tests or the render_async context-callable contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-267963fc77479e19f1e26653.md)

## Rule

- **Rule:** Tests for loop.depth and recursive loops must assert exact rendered output for nested recursive loop structures.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying tests for loop.depth or recursive loop rendering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2aecd410b7771f9c2a464453.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise async rendering with a synchronous helper must preserve the documented behavior: a plain synchronous helper (e.g., `normal_func` returning 23) can be used as a non-async callable within async test scenarios.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying or adding tests that use synchronous helpers within async rendering scenarios.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3a7d0a07b01f09f0d05b2fe1.md)

## Rule

- **Rule:** Template include resolution must preserve the error contract: when an include list has no matching template and no 'ignore missing', rendering raises TemplatesNotFound whose .templates attribute lists all attempted names and whose .name is the last attempted name; with 'ignore missing' the render yields an empty string.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying include resolution error handling or the TestAsyncIncludes.test_choice_includes test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-773a9206f872a80c76939b0f.md)

## Rule

- **Rule:** For-loop else semantics in async rendering must match Python: a for loop over an empty sequence executes the else branch.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** when modifying async for-loop else-branch tests or the async for/else rendering contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9a202fe270c6adf7096050af.md)

## Rule

- **Rule:**
  ```text
  Iterating over `none` in an async for loop must raise TypeError during render, establishing that non-iterable values are rejected rather than silently skipped.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying or extending async for-loop error handling tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9d8491556dda070d90dc4923.md)

## Rule

- **Rule:**
  ```text
  The test_scoping_bug test must assert that a for-loop variable and a later macro parameter with the same name do not collide, rendering '...1......2...' for foo=(1,).
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying or adding tests for macro and loop variable scoping interactions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a007d5515291ec6d1ca12c8b.md)

## Rule

- **Rule:** Tests for recursive loop semantics must assert that loop.previtem/loop.nextitem are undefined at the boundaries of a recursive loop, rendering the fallback value when the neighbor is not defined.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying tests for recursive loop neighbor variables.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ad77aef424031e9f5fbc1db3.md)

## Rule

- **Rule:** The scoped special variable loop.first inside nested for loops must reflect the innermost loop, producing the documented nested output.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying loop scoping or special loop variables in async templates.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ad7f8ee9beb1cb06262bf2e2.md)

## Rule

- **Rule:**
  ```text
  Tests for template import globals override must assert that an imported module sees the overridden global value passed to from_string rather than a locally set value.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying tests for template import globals override behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-afcec8ed41098af2fdf2c8da.md)

## Rule

- **Rule:** A test exercises chainable undefined async iteration, running an async test via asyncio.run.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying async undefined iteration behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b8d89ffe4c38ae7b9ace480c.md)

## Rule

- **Rule:** Tests for loop.cycle must assert that both positional arguments and unpacked sequences cycle through the provided values in order.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying tests for loop.cycle with positional or unpacked sequence arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d87bf34b6812cbb0edbaec27.md)

## Rule

- **Rule:** Async template syntax must preserve from-import trailing comma tolerance and keyword-like imported names, including the ambiguous 'bar, with with context' form.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying async from-import parsing or the TestAsyncImports.test_trailing_comma test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e48e167653070916a5e16674.md)

## Rule

- **Rule:** Tests for Jinja2 async rendering must assert that async block self-references and macro closures render correctly, preserving async-specific rendering semantics.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying or adding tests for async template rendering, block self-reference, or macro scoping in tests/test_async.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f832c752c8f7409a2afa914a.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise async template generation must preserve the documented async generation semantics: `Template.generate` with `enable_async=True` yields rendered chunks that can be collected into a list, producing the expected per-item output.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:**
  ```text
  When modifying or adding tests for async template generation via `Template.generate` with `enable_async=True`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ff2e34a314cea2ebe9dd54c7.md)
