# Constraints for `tests/test_compile.py`

## Rule

- **Rule:**
  ```text
  The test_compile.py module must import Environment from jinja2.environment and DictLoader from jinja2.loaders, exercising compilation through those public entry points.
  ```
- **Applies to:**
  - `tests/test_compile.py`
- **Condition:** When modifying or adding compilation tests that use Environment and DictLoader public entry points.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ee15036d7b4c04ef7cf59d84.md)
