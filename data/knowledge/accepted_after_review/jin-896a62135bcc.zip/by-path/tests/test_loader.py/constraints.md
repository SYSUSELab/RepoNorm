# Constraints for `tests/test_loader.py`

## Rule

- **Rule:** Tests for the prefix loader with stored (uncompressed) zip compilation must exercise the loader and then run the common loader assertions.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:** when adding or modifying tests for the prefix loader with stored zip compilation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5a1e8446e2d2fc76b32b1f10.md)

## Rule

- **Rule:**
  ```text
  Tests for PackageLoader must verify PEP 451 import hook compatibility and restore sys.meta_path in a finally block.
  ```
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:** When adding or modifying tests for PackageLoader with custom import hooks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7342e6cc7e0a548ac8ef1500.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_loader.py that pin PackageLoader.get_source must preserve that it returns source content, a name ending with the split template path, and an up_to_date callable that returns truthy, covering both nested (foo/test.html) and top-level (test.html) package templates.
  ```
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When modifying or extending PackageLoader.get_source tests in tests/test_loader.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-99926a5ba5c82d5ea7ef16b3.md)

## Rule

- **Rule:** Tests for FileSystemLoader must assert that searchpath accepts a list mixing plain strings and pathlib paths and resolves templates from it.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:** When adding or modifying tests for FileSystemLoader searchpath argument types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c2770952184d7061e3f0e34d.md)

## Rule

- **Rule:** FileSystemLoader must accept a pathlib-style searchpath and work with the common loader test helper.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:** When modifying FileSystemLoader searchpath handling or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f3f82a5ced69f1fd688ca4e6.md)

## Rule

- **Rule:** Tests for ChoiceLoader must verify that a template name present in a later loader is still found when an earlier loader cannot resolve it, exercising the ordered fallback.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When adding or modifying ChoiceLoader tests in tests/test_loader.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f4e1d0615ca31c8352e43ccb.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_loader.py that pin ModuleLoader path handling must preserve that ModuleLoader accepts a list mixing pathlib.Path and string paths, as asserted by constructing it with [Path(mod_path), '/tmp/templates'].
  ```
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When modifying or extending ModuleLoader path-handling tests in tests/test_loader.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f8d246acc4bd89ae81ca82e1.md)
