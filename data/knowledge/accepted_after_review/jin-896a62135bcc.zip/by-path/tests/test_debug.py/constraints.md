# Constraints for `tests/test_debug.py`

## Rule

- **Rule:**
  ```text
  The fs_env fixture must wrap a filesystem_loader in an Environment so debug tests operate against a filesystem-backed loader.
  ```
- **Applies to:**
  - `tests/test_debug.py`
- **Condition:**
  ```text
  When modifying or adding debug tests that require a filesystem-backed loader via the fs_env fixture.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-32b793dd0f10e9e3fb91ca0f.md)

## Rule

- **Rule:** Tests that exercise debug error reporting must assert that TemplateSyntaxError raised from an included file carries a non-None source attribute, preserving source-location reporting for include-time syntax errors.
- **Applies to:**
  - `tests/test_debug.py`
- **Condition:**
  ```text
  When modifying include-time syntax error handling or source-location reporting in tests/test_debug.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3e82b57b3b4611f928cb10b8.md)
