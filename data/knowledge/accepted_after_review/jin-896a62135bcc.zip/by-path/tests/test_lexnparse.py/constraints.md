# Constraints for `tests/test_lexnparse.py`

## Rule

- **Rule:**
  ```text
  Tests in tests/test_lexnparse.py that pin parser balancing must preserve the behavior that a dict literal followed by attribute access, e.g. {{ {'foo':'bar'}.foo }}, renders 'bar', covering brace balancing and attribute access.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending parser balancing tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0163d92475e7f7bf5fe8f0ca.md)

## Rule

- **Rule:**
  ```text
  Tests for the lexer/parser must cover custom delimiter configurations: comment/block delimiters can be overridden (e.g. '<!--','-->','{','}') and ERB-style delimiters ('<%','%>','<%=','%>','<%#','%>') including comment blocks and whitespace-trimming variants render correctly.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying lexer/parser tests for delimiter handling, including custom comment/block delimiters and ERB-style syntax.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-05eaa4b4a266605f791107a7.md)

## Rule

- **Rule:** Template expression evaluation must preserve operator semantics: floor division yields int, true division yields float, and modulo yields int (3//2=1, 3/2=1.5, 3%2=1).
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying template expression operator evaluation or the TestSyntax.test_div test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0b4d79496b182bf5fb8b0730.md)

## Rule

- **Rule:**
  ```text
  A `{% set %}` inside a for loop must not leak to the outer scope; after the loop, the outer variable retains its original value.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending tests for `{% set %}` scoping inside for loops.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-180f28aa3fcc0a7f05449fba.md)

## Rule

- **Rule:** Tests for reserved constant names must assert that assigning to true or none in {% set %} or {% for %} raises TemplateSyntaxError.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for reserved constant name assignment in template syntax.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1872f388bd8b5c07b4506405.md)

## Rule

- **Rule:**
  ```text
  Jinja expression evaluation must preserve Python operator precedence for arithmetic operators, so `2 * 3 + 4 % 2 + 1 - 2` evaluates to 5.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying or extending Jinja expression parsing/evaluation tests for arithmetic operator precedence.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29361e007e536ec983a2c259.md)

## Rule

- **Rule:** Tests for unary operators must assert that unary plus and minus are evaluated at render time, producing the numeric value without the sign for plus and with the sign for minus.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** when adding or modifying tests for unary operator rendering
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2ab5ed228d735e18ab9181fb.md)

## Rule

- **Rule:**
  ```text
  With trim_blocks=True and lstrip_blocks=False, block tags must be trimmed such that a template containing an if/endif block renders to eight spaces, preserving the exact whitespace behavior of block trimming.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or adding tests for block trimming whitespace behavior with trim_blocks and lstrip_blocks settings.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3a0d5b0a8c5aa33894cf4272.md)

## Rule

- **Rule:**
  ```text
  When modifying the '+' modifier handling, preserve that it is a no-op when trim_blocks=False for {% if %}, comments, and raw blocks, neither erroring nor altering output.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  Changing '+' modifier behavior when trim_blocks is False.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5979a73a7716ecf1cf870bf7.md)

## Rule

- **Rule:**
  ```text
  Tests for test-expression grammar must assert that chained tests such as `foo is string is sequence` raise TemplateSyntaxError, while disjunctions such as `42 is string or 42 is number` render True.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** when adding or modifying tests for test-expression grammar and chaining restrictions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5b86137774e7b5f9ca77c849.md)

## Rule

- **Rule:**
  ```text
  With `lstrip_blocks` enabled and `trim_blocks` disabled, the trailing dash on `{%- raw -%}` strips whitespace and newlines up to the first data character, and the trailing dash on `{%- endraw -%}` strips following whitespace.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending raw-block whitespace handling tests under lstrip_blocks/trim_blocks settings.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5e6736fe274edd55c9f773bb.md)

## Rule

- **Rule:** Template lexer configuration must preserve custom delimiter support: Environment accepts custom block, variable, comment, and line-statement delimiters, and a line-statement prefix such as '##' can be configured to consume the rest of a line.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying custom delimiter configuration or the TestParser.test_line_syntax test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-795a53528496b075469aa1dc.md)

## Rule

- **Rule:** Raw blocks do not process inner text, so a start tag cannot ignore trim; using {% raw +%} must raise TemplateSyntaxError, documenting a parser boundary for raw block trimming.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying raw block parsing or trim-related syntax handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7a3144837f72c0137712de76.md)

## Rule

- **Rule:**
  ```text
  Template expression evaluation must preserve slicing semantics: list slicing and reverse slicing render as '[1, 2, 3]' and '[3, 2, 1]'.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying template expression slicing or the TestSyntax.test_slicing test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-82eacf0fd4b96edd8bbff477.md)

## Rule

- **Rule:**
  ```text
  String literals in templates must support escape sequences including \0, \u2668, \xe4, \t, \r, \n, and named escapes like \N{HOT SPRINGS}, rendering to the corresponding characters.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying or adding tests for template string literal escape handling in the lexer or parser.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8c5a3a14dae4d9a29995145c.md)

## Rule

- **Rule:** Tests for comment parsing must verify that comments (including multi-line comments at the start of a template) are stripped from output and do not affect subsequent parsing, such as a macro defined after a comment rendering normally.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for comment handling in templates.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8f43c5fd096b7aa7cdbe557a.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_lexnparse.py that pin operator semantics must preserve that 'in' and 'not in' operators render as 'True' and 'False' for expressions like '{{ 1 in [1, 2, 3] }}|{{ 1 not in [1, 2, 3] }}'.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending operator-semantics tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-97c64e317f2e7f966ed27ab8.md)

## Rule

- **Rule:** Tests for tuple literal and tuple-unpacking loop target syntax must cover trailing-comma forms such as {{ (1, 2,) }}, {{ 1, }}, and {% for x in foo, %}.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for tuple expression syntax in templates.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a027593a9f90bf68da1ec4f5.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_lexnparse.py that pin lexer/parser behavior must preserve the exact accepted identifier grammar: unicode letters (e.g. 'föö', 'き') are valid identifier starts, digits and '-' cannot start or continue an identifier, emoji are invalid, and characters not matched by \w such as \u1885 and \u2118 are valid starts while \xb7 is valid only as a continuation.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending the parametrized identifier-name test in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a84e15a664929ef9c7064109.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_lexnparse.py that pin TokenStream protocol must preserve that bool(ts) is true while not at EOF and false at EOF, while ts.eos is the inverse, defining the stream truthiness/end-of-stream protocol.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending TokenStream protocol tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b0fcc05f533cfdb2a6f2d485.md)

## Rule

- **Rule:** The pprint filter output must match Python's pformat for both ASCII and non-ASCII strings, pinning the filter's formatting behavior.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying the pprint filter or its tests, including byte-fallback handling for non-ASCII input.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c618b27afa06a121ad079add.md)

## Rule

- **Rule:** Tests that pin lexer/parser behavior must keep asserting the exact token or AST shape (e.g. operator token types, unary-minus vs filter precedence, boolean rendering, concat stringification) rather than only that parsing succeeds.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying lexer operator tables, parser precedence, or expression rendering in tests/test_lexnparse.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ca9383b804c9ab797a84b590.md)

## Rule

- **Rule:**
  ```text
  Tests for tuple literal rendering must assert Python tuple syntax, including the trailing comma for single-element tuples: '()|(1,)|(1, 2)'.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for tuple literal rendering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d7a8df7a8fb9d5a724bf81a3.md)

## Rule

- **Rule:**
  ```text
  Tests for filter precedence must assert that filters bind tighter than the + operator, so 'foo'|upper + 'bar'|upper renders as FOOBAR.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for filter precedence relative to operators.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d9d2c70bd56e3af2f81c1992.md)

## Rule

- **Rule:**
  ```text
  Template subscript expressions must support negative indexing, so foo[0] and foo[-1] render as 0|2 for [0, 1, 2].
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying or adding tests for template subscript expression indexing behavior, including negative indices.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f02acc5450d4ac6c1f892c07.md)

## Rule

- **Rule:**
  ```text
  Tests for whitespace control with trim_blocks and lstrip_blocks enabled must assert that a comment followed by blank lines preserves leading spaces and newlines in the rendered output.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  when adding or modifying tests for comment handling under trim_blocks and lstrip_blocks
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f512e8def8f4dfda5e8dd333.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise whitespace control must assert the exact rendered output for trim_blocks and lstrip_blocks interactions, including the single-newline result for an if block using '+' on the start tag.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying trim_blocks or lstrip_blocks whitespace control in tests/test_lexnparse.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fd32587427628986f6c6504b.md)

## Rule

- **Rule:**
  ```text
  When modifying whitespace-trimming behavior, preserve that with trim_blocks and lstrip_blocks enabled, nested if blocks using the '+%}' modifier produce output with no leading indentation.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  Changing trim_blocks/lstrip_blocks handling or the '+%}' modifier for nested blocks.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fe3a582a4984d28204a6d0d0.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise whitespace-control options (trim_blocks, lstrip_blocks) must assert the exact rendered output, including preserved trailing spaces and newline counts, rather than only checking that rendering succeeds.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When adding or modifying tests for trim_blocks/lstrip_blocks whitespace control, including custom delimiters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fe910024da9128647647dab7.md)
