# Constraints for `tests/test_tests.py`

## Rule

- **Rule:** The lower test must render True for 'foo' and False for 'FOO', pinning the lower filter's case-sensitivity behavior.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying the lower filter or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1f6e1ff26f230af903e4611e.md)

## Rule

- **Rule:**
  ```text
  Tests for the built-in is test must assert that env.call_test("test", "number") is true and env.call_test("test", "bad-name") is false, pinning the name validation behavior.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** when adding or modifying tests for the built-in is test's name validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-233299dbef473e9e9ba8341d.md)

## Rule

- **Rule:** The escaped test must return True only for Markup instances and False for plain strings, even when autoescape is enabled, distinguishing already-safe markup from raw strings.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying the escaped test or the Markup/autoescape distinction it verifies.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2d7680f24fbc8e1dcc5e3b73.md)

## Rule

- **Rule:** Jinja test semantics must treat booleans as numbers but not integers, large ints as integers but not floats, and only callables as callable, with specific truth values for strings, sequences, mappings, and iterables.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying or extending parametrized Jinja test-type semantics assertions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-32a511472bee2bafb04f854b.md)

## Rule

- **Rule:** Template rendering must preserve lazy test-name resolution: an undefined name in an if-defined guard renders empty without error, but rendering with the name defined raises TemplateRuntimeError 'No test named f'.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When modifying test-name resolution or the test_name_undefined_in_if test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-88f42e8867d123cf0d1ac0a0.md)

## Rule

- **Rule:** Tests for comparison operator aliases must parametrize eq/ne/lt/le/gt/ge against expected booleans, covering both true and false cases.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When adding or modifying comparison operator alias tests in tests/test_tests.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-99387a7666d8e9fec6836d39.md)

## Rule

- **Rule:**
  ```text
  The `even` Jinja test must return True for even integers and False for odd integers.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When modifying or extending the `even` Jinja test or its assertions.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-de62de7e956f8f77c99b8e40.md)
