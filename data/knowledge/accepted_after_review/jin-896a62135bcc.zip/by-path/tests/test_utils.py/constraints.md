# Constraints for `tests/test_utils.py`

## Rule

- **Rule:**
  ```text
  LRUCache.clear must reset the cache so __getstate__ returns capacity, an empty _mapping, and an empty deque _queue.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when modifying LRUCache clear tests or the clear/__getstate__ state contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4cb98224bf806e572a1dfd7b.md)

## Rule

- **Rule:**
  ```text
  Tests for the LRUCache utility must be grouped under a dedicated TestLRUCache class in tests/test_utils.py, providing focused coverage of LRUCache behavior.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for the LRUCache utility.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5cf8f4c6f79acdabdce82335.md)

## Rule

- **Rule:** Tests for the lorem ipsum filter's max parameter must assert that generated non-HTML output contains fewer than max-1 spaces when n=1, bounding word count relative to max.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for the lorem ipsum filter's max parameter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-70a3dd86617599c322025341.md)

## Rule

- **Rule:** When modifying LRUCache iteration, preserve that iteration order is most-recently-used first: items() returns most-recently-used first and reversed() yields least-recently-used first.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** Changing LRUCache access ordering or iteration methods.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-83845d4cfa789ba42cdc7522.md)

## Rule

- **Rule:**
  ```text
  The select_autoescape function must match extensions case-insensitively and normalize leading dots, enabling autoescape for 'foo.html' and 'FOO.HTML', disabling it for 'foo.txt' and 'FOO.TXT', using the default for unknown extensions, and using default_for_string for None.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When modifying or adding tests for select_autoescape extension matching and default behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-91cc2b8b8dda86171ae0e6ca.md)

## Rule

- **Rule:**
  ```text
  Template rendering must preserve urlize target escaping: the target attribute value is escaped ('<script>' becomes '&lt;script&gt;') while the href URL remains intact.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying urlize target escaping or the TestEscapeUrlizeTarget test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b60b24df1869638a11f78bf9.md)

## Rule

- **Rule:** Tests for LRUCache must assert that values() on an empty cache returns an empty list.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for LRUCache values() behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e404d6eaa6fda60f30c4a3c8.md)
