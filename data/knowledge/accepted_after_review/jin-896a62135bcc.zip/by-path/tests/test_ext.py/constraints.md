# Constraints for `tests/test_ext.py`

## Rule

- **Rule:**
  ```text
  Tests for babel extraction must assert that babel_extract yields (lineno, funcname, message, comments) tuples, with trans/pluralize blocks extracted as ngettext with a (singular, plural, None) tuple and gettext calls mapped to the gettext keyword.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for babel extraction output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-270c0fdea0b74e1c6f22ac7d.md)

## Rule

- **Rule:**
  ```text
  A get_user_count function passed to the template must be called exactly once during rendering of a pluralized i18n message.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** when modifying i18n plural translation tests or the plural function call-count contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4c6fc62b77fad35ea4628bca.md)

## Rule

- **Rule:**
  ```text
  The `test_num_used_twice` test must assert that a pluralized trans block referencing the count variable twice renders the correct German plural form.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or extending internationalization pluralization tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5bdc9cfedf2eee9ca56fefa4.md)

## Rule

- **Rule:** Template rendering must preserve autoescape scoping: a value inside an {% autoescape %} block is escaped, while the same value outside the block renders unescaped.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying autoescape block handling or the TestAutoEscape scoping test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-66eb66f1bb0912370993a9c5.md)

## Rule

- **Rule:**
  ```text
  Template i18n rendering must preserve translated template output: rendering child.html with LANGUAGE='de' produces '<title>fehlend</title>pass auf'.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying i18n template rendering or the TestInternationalization.test_trans test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-78c35823b434529fd6894233.md)

## Rule

- **Rule:** Tests for newstyle gettext compilation must assert that num appears only once in the generated format string, checking for the pattern "u?'%(num)s apple', u?'%(num)s apples', 3".
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for newstyle gettext compilation output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-79b65efd0d23983743a57f7a.md)

## Rule

- **Rule:** The autoescape extension must scope escaping to its block: with autoescape=True the inner block is escaped while outer content is not, and with autoescape=False the inner block is unescaped while outer content is escaped.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or extending autoescape extension scoping tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-854f5b4a6c09cf4d0630fe37.md)

## Rule

- **Rule:**
  ```text
  Template i18n pluralization must preserve German plural selection: user_count=1 renders 'Ein Benutzer online' and user_count=2 renders '2 Benutzer online'.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying i18n pluralization or the TestInternationalization.test_trans_plural test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b3dd2581b35a06d6290d485.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_ext.py that pin autoescape scoping must preserve that a macro defined inside {% autoescape val %} produces Markup when val is true and str when false, and compiled source reflects the escaping decision, asserting autoescape state is captured per-scope at compile time.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending autoescape scoping tests in tests/test_ext.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-909ae83fdbb1b70fe9cd2e2c.md)

## Rule

- **Rule:**
  ```text
  Tests for the trimmed trans modifier and babel_extract must assert that internal whitespace and newlines collapse to single spaces in extracted messages, while gettext preserves original spacing.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When adding or modifying tests for the trimmed trans modifier or babel_extract whitespace normalization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a501f417f957ac88296a2b55.md)

## Rule

- **Rule:** When modifying the newstyle i18n pluralize block, preserve that a pluralize block with a mismatched variable raises TemplateAssertionError.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** Changing pluralize block variable handling or i18n extension behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a9da607846c1caf9161e53a8.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_ext.py that pin i18n translation output must preserve that rendering child.html with LANGUAGE="de" yields "<title>fehlend</title>pass auf", pinning translated template output for the German locale.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending i18n translation tests in tests/test_ext.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c026a1f655e3f355c75e981e.md)

## Rule

- **Rule:** Tests for extension parse methods must assert that an extension parse method can emit an Output node calling a method with environment attributes, imported names, and a context reference node, and sets the node line number from the next stream token.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for extension parse method output nodes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c26a7a52474b42f87fb3ff1c.md)

## Rule

- **Rule:**
  ```text
  The Overlay extension parse protocol must build an OverlayScope node, parse until endoverlay, and set node.context via self.call_method('get_scope').
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** when modifying overlay extension parse tests or the OverlayScope parse protocol
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cbeef69e8a007229ba37786f.md)

## Rule

- **Rule:** Tests that exercise i18n extension behavior must assert the exact rendered output and error type (e.g. autoescape escaping of gettext markup, whitespace trimming around trans blocks, pluralization output and TemplateAssertionError on mismatched pluralize variables).
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying i18n extension rendering, autoescape interaction, trimming, or pluralization in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ceac16f98119d892b857047c.md)

## Rule

- **Rule:**
  ```text
  Tests for internationalization extensions must be grouped under the TestInternationalization class and use the pgettext helper that resolves the language from context.get('LANGUAGE', 'en') and applies _get_with_context with the context argument.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying internationalization extension tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d3f474a3d46388b18fe26135.md)

## Rule

- **Rule:**
  ```text
  Tests for newstyle i18n plural rendering must assert that the plural template renders singular and plural German forms based on user_count.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for newstyle i18n plural rendering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dac508cc526f782330cac6be.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_ext.py that pin i18n trimmed policy must preserve that the 'notrimmed' trans modifier overrides the environment's trimmed policy, preserving leading/trailing whitespace in the rendered output.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending i18n trimmed-policy tests in tests/test_ext.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e854d696c295714c69f100db.md)

## Rule

- **Rule:** When modifying the loopcontrols extension, preserve that continue skips the current iteration and break stops the loop.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** Changing loopcontrols extension behavior for continue or break.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e9d8edf52536ecaef1e48f4b.md)

## Rule

- **Rule:** Tests for Jinja2 i18n trimmed policy must assert that trans blocks with surrounding whitespace render with whitespace preserved normally but trimmed when the trimmed policy is active.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or adding tests for i18n trimmed policy behavior in tests/test_ext.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f73e833136d5a00c41e0dc94.md)
