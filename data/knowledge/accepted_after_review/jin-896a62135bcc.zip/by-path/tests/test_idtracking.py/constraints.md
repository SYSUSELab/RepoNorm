# Constraints for `tests/test_idtracking.py`

## Rule

- **Rule:**
  ```text
  In a for-loop with an inner if-branch assignment, the for-loop symbol table must store `item` and `x`, and loads must include aliases `l_1_x -> l_0_x`, `l_1_item -> param`, and `l_1_expression -> resolve`, following the scoped alias naming convention for nested symbol tracking.
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:** When modifying or extending symbol tracking tests for nested scopes and alias naming.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3c61270784642745812b1620.md)

## Rule

- **Rule:**
  ```text
  symbols_for_node must assign refs in the form l_<level>_<name> and produce load-kind tuples such as ("undefined", None), ("resolve", "bar"), and ("param", None) for identifier tracking.
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:**
  ```text
  when modifying identifier tracking tests or the symbols_for_node naming and load-kind contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a1475aeca12c1d58d161aee4.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_idtracking.py that pin symbol tracking must preserve that symbols_for_node on an If with an assignment in the branch records the assigned name in stores and refs, with load kind 'resolve' and a dump_stores mapping to the l_0_ prefixed name.
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:**
  ```text
  When modifying or extending symbol-tracking tests in tests/test_idtracking.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c9244d4f9003a151c43ca4f9.md)
