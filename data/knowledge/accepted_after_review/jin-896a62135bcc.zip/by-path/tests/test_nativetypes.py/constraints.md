# Constraints for `tests/test_nativetypes.py`

## Rule

- **Rule:** Tests for native types must assert that a loop over a single-element list renders to the native Python type of that element.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying tests for native type rendering of single-value loops.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29293f7fdc8f939a275d5d9a.md)

## Rule

- **Rule:** In native types mode, rendering a template containing only a string literal expression yields a str result, not a native wrapper, and the literal is concatenated into surrounding text.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When modifying native types rendering or string literal handling in templates.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-442837ee4a65866c9ed91aaf.md)

## Rule

- **Rule:**
  ```text
  The native-types test must assert that rendering `{{ missing is defined }}` is falsy, confirming undefined detection works in native rendering.
  ```
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When modifying or extending native-types undefined detection tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8eeb0f3e398f3a604972ab48.md)

## Rule

- **Rule:** Native template rendering must raise UndefinedError when an undefined value is used in arithmetic, and must preserve leading whitespace before rendered expressions.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** when modifying native template rendering tests or the native undefined/whitespace contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e1b395d15ee8b3ab0bdb1153.md)
