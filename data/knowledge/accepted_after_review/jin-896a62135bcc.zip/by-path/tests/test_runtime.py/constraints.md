# Constraints for `tests/test_runtime.py`

## Rule

- **Rule:** LoopContext.length must equal the length of the underlying sequence even when the sequence is a reversed iterator, computed from the iterable rather than iteration progress.
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:** when modifying LoopContext length tests or the length computation contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-05ae9366ea232ebc0c42e488.md)

## Rule

- **Rule:** When modifying LoopContext, preserve that length equals the length of the original input sequence even when the context is constructed over a reversed iterator.
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:** Changing LoopContext construction or length computation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7b7696a5c359d3b976b2e8ff.md)

## Rule

- **Rule:** Tests for loop index variables must assert the exact loop variable names and zero-based index values exposed to templates, including len, revindex0, index0, and val.
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:** when adding or modifying tests for loop index variables in templates
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8e130bad9e5a7858a220b914.md)

## Rule

- **Rule:**
  ```text
  Tests for pass_arg detection must verify that a callable class whose __getattr__ returns truthy values for arbitrary attributes is not misidentified as a pass_context function.
  ```
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:**
  ```text
  When adding or modifying pass_arg detection tests in tests/test_runtime.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cbde643b1a6f49e3e67104d7.md)
