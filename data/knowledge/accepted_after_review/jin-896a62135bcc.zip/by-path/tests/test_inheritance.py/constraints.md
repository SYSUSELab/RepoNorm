# Constraints for `tests/test_inheritance.py`

## Rule

- **Rule:**
  ```text
  Blocks defined inside a false conditional in a parent template must still be available via `self.x()`, and a child overriding such a block with `super()` must render the parent block content.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying or extending block preservation and `super()` behavior tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-14a04cab8166a69d6f14cf5e.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_inheritance.py that pin template inheritance must preserve that rendering a template that extends a layout produces the layout's block content in order, including nested blocks, as asserted by the exact output string.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying or extending template inheritance tests in tests/test_inheritance.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2188e2bb4bfb7afbf4ac616c.md)

## Rule

- **Rule:** Template inheritance must preserve block override and nested-block behavior as encoded by the layered template fixture set (LAYOUTTEMPLATE, LEVEL1-4, WORKINGTEMPLATE, DOUBLEEXTENDS).
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying inheritance block override behavior or the layered template fixtures in tests/test_inheritance.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8051f45d449374946fa3d4b3.md)

## Rule

- **Rule:** Tests for required blocks must verify that non-comment, non-whitespace content raises TemplateSyntaxError with the message 'Required blocks can only contain comments or whitespace'.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When adding or modifying required block validation tests in tests/test_inheritance.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9cb69a731c1aa0d47f73c562.md)

## Rule

- **Rule:** Tests for Jinja2 template inheritance must assert that required blocks raise TemplateRuntimeError with the exact message when not overridden, and render overrides when present.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying or adding tests for required block inheritance behavior in tests/test_inheritance.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bb8ec72b5003916375ef8301.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Jinja template inheritance must preserve dynamic inheritance semantics: a child template using `{% extends default %}` renders against different parent templates based on the runtime value of the `default` variable.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:** When modifying or adding tests for template inheritance, especially dynamic parent selection via a runtime variable.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d19461e2c09800aad8f78d15.md)

## Rule

- **Rule:** Tests for scoped blocks after inheritance must verify that macros imported with context remain visible inside scoped blocks, asserting the rendered output.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When adding or modifying scoped block inheritance tests in tests/test_inheritance.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dc6210cd5a59ef43925278af.md)
