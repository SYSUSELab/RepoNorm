# Constraints for `tests`

## Rule

- **Rule:** Coverage measurement is configured to restrict its source to the jinja2 and tests packages.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1afd991a416cc34d3c64bb08.md)

## Rule

- **Rule:** pytest test discovery is restricted to the tests directory via testpaths = tests.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b8c3668eac35841a5c5a48ac.md)

## Rule

- **Rule:**
  ```text
  pytest treats warnings as errors (filterwarnings = error), except the asyncio.base_events DeprecationWarning matching 'The loop argument' at line 542, which is ignored.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c5d5eaf1191869198cc90b82.md)

## Rule

- **Rule:** Include tests when a patch adds or changes code, and make sure the test fails without the patch.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-fb4097e34b7fb2af2cad6720.md)
