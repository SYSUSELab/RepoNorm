# Constraints for `tests/test_regression.py`

## Rule

- **Rule:** Template rendering must preserve loop-local scoping: a loop variable does not leak after the loop, and a subsequent set of the same name yields the set value.
- **Applies to:**
  - `tests/test_regression.py`
- **Condition:**
  ```text
  When modifying loop variable scoping or the TestCorner.test_assigned_scoping regression test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7f5f61992c056b7fcdaa2969.md)
