# Constraints for `tests/test_filters.py`

## Rule

- **Rule:** When modifying the int filter with a base argument, preserve that prefixed strings like 0x4d32 parse as base 16 and 011 as base 8, while invalid input such as 0x33Z in base 16 returns 0.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** Changing the int filter's base-argument parsing or failure fallback.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-01af3df4d6111c4ec932f9d5.md)

## Rule

- **Rule:** Tests for the truncate filter must assert the exact output for given length and custom end string, including behavior when breaking long words is true versus false, and that short input is left unchanged.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the truncate filter's length, end string, and break-long-words behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-170ae75a2204069d1fe0143c.md)

## Rule

- **Rule:** filesizeformat renders decimal units by default and binary units when passed true, fixing the exact output format for each unit.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying the filesizeformat filter or its expected output format.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-28c7bd48bb544a2f01ce437e.md)

## Rule

- **Rule:** Tests for the truncate filter must assert that the length parameter counts the ellipsis and truncation occurs at the end, e.g. truncate(7, true) on 'Joel is a slug' renders 'Joel...'.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying tests for the truncate filter's length and end-truncation behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2e36227907b48e2839e28618.md)

## Rule

- **Rule:** Tests for the int filter default fallback must assert that an unconvertible input returns the configured default value.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying tests for the int filter's default parameter behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-390c454574590f9b64c100c7.md)

## Rule

- **Rule:** Tests for selectattr and map(attribute=...) must assert filtering by attribute truthiness and extraction of named attributes from namedtuple-like objects.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying tests for selectattr truthiness filtering or map(attribute=...) extraction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-51941680ffdd197f29504360.md)

## Rule

- **Rule:**
  ```text
  When modifying the escape filter, preserve that it renders '<"&' as &lt;&#34;&gt;&amp;, escaping the double quote as &#34;.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** Changing the escape filter's character escaping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-51d38a17164194fab6946643.md)

## Rule

- **Rule:**
  ```text
  Tests for the wordwrap filter must verify that wrapping respects the environment's newline_sequence setting rather than always emitting a fixed newline.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying tests for the wordwrap filter's newline handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-586178100c79b2fdfb9a1ab1.md)

## Rule

- **Rule:** Tests for the forceescape filter must verify that already-marked-safe Markup values are still escaped, not only that plain strings are escaped.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When adding or modifying forceescape filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5c97169708b75979ea768ea1.md)

## Rule

- **Rule:** Tests that pin a Jinja2 filter's output must assert the exact rendered value produced by the filter, because filter semantics (e.g. abs, capitalize, pprint, round) are contractually fixed by these tests.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying or adding a test for a Jinja2 filter's rendered output in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6046add20665736b1e0943dc.md)

## Rule

- **Rule:** Tests for the trim filter must assert character-set semantics: chars=None trims whitespace, a specific chars value trims only those characters, and a combined set trims all specified characters.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying tests for the trim filter's chars parameter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-72878e309fe1f7f65bb8dac6.md)

## Rule

- **Rule:** Tests for the map filter's default argument must assert that the default is applied only when the attribute is missing, and that an existing attribute with value None is preserved as None.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the map filter's default argument behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7e71643dde4f728af0f6c4ff.md)

## Rule

- **Rule:** Tests for the urlize filter's rel policy must assert that setting urlize.rel to None causes urlize to emit an anchor without a rel attribute.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the urlize filter's rel policy
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8d2b4de3fca064bd46b502e2.md)

## Rule

- **Rule:**
  ```text
  Tests for the int filter must verify that objects implementing __int__ are accepted and rendered as the resulting integer, not only that plain integers work.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When adding or modifying int filter tests in tests/test_filters.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8dbce5f38e75a62d5836159d.md)

## Rule

- **Rule:**
  ```text
  When modifying the programmatic filter invocation API, preserve that env.call_filter("sum", [1, 2, 3]) returns 6.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  Changing env.call_filter or the programmatic filter invocation path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9f466556fd4c7c3394c81b6a.md)

## Rule

- **Rule:**
  ```text
  A `{% filter lower|escape %}` block must apply filters in order, so `<HEHE>` becomes `&lt;hehe&gt;` (lowercased then escaped).
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying or extending filter-block behavior tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-abf637c558c256152120909a.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Jinja filter behavior must preserve the documented filter semantics: `sum` accepts a string attribute argument (including dotted paths like 'real.value') and sums that attribute across items; `groupby` accepts dotted attribute paths like 'date.year'; `rejectattr` combined with `map(attribute=...)` and `join` filters by attribute; and `indent` preserves behavior when the input is a Markup instance.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
  - `tests/test_filters.py`
- **Condition:** When modifying or adding tests for the sum, groupby, rejectattr, or indent filters, including their attribute-path and Markup-input variants.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f5078073bb74ad8bcc47fe5b.md)
