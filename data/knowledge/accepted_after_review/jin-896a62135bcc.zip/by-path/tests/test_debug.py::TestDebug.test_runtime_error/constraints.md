# Constraints for `tests/test_debug.py::TestDebug.test_runtime_error`

## Rule

- **Rule:** Tests for runtime error traceback formatting must assert that rendering a template calling fail() produces a traceback matching a regex including the template file and line, the lambda frame, and the ZeroDivisionError message.
- **Applies to:**
  - `tests/test_debug.py::TestDebug.test_runtime_error`
- **Condition:** When adding or modifying tests for runtime error traceback formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1a9e8d10402ef1c6de28ca99.md)
