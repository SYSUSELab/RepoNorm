# Constraints for `tests/test_imports.py`

## Rule

- **Rule:** Tests for template import export boundaries must assert that importing a name not exported by a module raises UndefinedError with the message 'does not export the requested name'.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** When adding or modifying tests for template import export enforcement.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4a51d8f06615a6cd57d7037d.md)

## Rule

- **Rule:**
  ```text
  Tests in tests/test_imports.py that pin include behavior must preserve that include of a missing template raises TemplateNotFound, but with 'ignore missing' (with or without context) renders an empty string.
  ```
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:**
  ```text
  When modifying or extending include/ignore-missing tests in tests/test_imports.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-50e92dc79bed46a78967f864.md)

## Rule

- **Rule:** When modifying the include tag's argument resolution, preserve support for a list argument that mixes variables and string literals: each element is resolved independently, and an unresolved variable element falls through to the literal element rather than aborting the include.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** Changing how the include tag resolves a list argument containing both variables and literals.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5f306d6e5aa1adf181750ad1.md)

## Rule

- **Rule:** A context variable set by the caller must be visible to a template rendered via t.render(ctx), producing the expected interpolated output.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** When modifying template rendering with caller-supplied context or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-785cd47d45f383bf46f2925b.md)

## Rule

- **Rule:** Tests for template module exports must assert that top-level macros and set variables are exposed, while names starting with double underscore and macros defined inside a for loop are not exposed.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** when adding or modifying tests for template module export semantics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-92c28ab989ebf154cf865d5c.md)

## Rule

- **Rule:** The template parser must accept from-import forms with a trailing comma before 'with context' and must reject double commas and a trailing comma after 'with context' with TemplateSyntaxError.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** When modifying or adding tests for from-import syntax, particularly trailing commas and the 'with context' clause.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ab4f9919542ebcf18c1927c5.md)

## Rule

- **Rule:** Tests for import statements must assert that from-import requires at least one name, raising TemplateSyntaxError when the name list is empty.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** When adding or modifying tests for from-import syntax validation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bc5b0a266f22043cadd81330.md)

## Rule

- **Rule:**
  ```text
  Globals passed to from_string must override template-level set values when an imported module calls a function, so the imported module sees the passed globals rather than the template's local value.
  ```
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:**
  ```text
  when modifying import globals override tests or the from_string globals precedence contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d1f58933b0f15dc0be3003d5.md)
