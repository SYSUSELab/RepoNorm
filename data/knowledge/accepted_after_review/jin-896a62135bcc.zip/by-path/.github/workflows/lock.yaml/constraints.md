# Constraints for `.github/workflows/lock.yaml`

## Rule

- **Rule:** The lock job runs on ubuntu-latest and uses the dessant/lock-threads@v2 action with github-token set to ${{ github.token }}, issue-lock-inactive-days set to 14, and pr-lock-inactive-days set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6df2471ece675e15a6dd41c4.md)

## Rule

- **Rule:**
  ```text
  The 'Lock threads' workflow runs on a daily schedule defined by the cron expression '0 0 * * *'.
  ```
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Condition:**
  ```text
  workflow predicate: schedule: - cron: '0 0 * * *'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e13e63f0e12ed4c60b54ceef.md)
