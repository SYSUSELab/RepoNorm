# Constraints for `examples/basic`

## Rule

- **Rule:**
  ```text
  Example scripts under examples/basic/ that configure custom delimiters or line-statement prefixes must set them on the Environment constructor (e.g. line_statement_prefix, variable_start_string, variable_end_string) so the custom syntax is active for the templates they render.
  ```
- **Applies to:**
  - `examples/basic/**/*.py`
- **Condition:** When modifying or adding an example under examples/basic/ that demonstrates custom delimiters or line statements.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-055e1711b25ffa6982472483.md)

## Rule

- **Rule:** Example scripts under examples/basic/ that demonstrate a template feature must remain runnable end-to-end: they construct an Environment, load templates (via DictLoader or FileSystemLoader), and render output, so a contributor changing an example must keep its loader/render wiring intact rather than leaving a partial snippet.
- **Applies to:**
  - `examples/basic/**/*.py`
- **Condition:** When modifying or adding an example script under examples/basic/ that demonstrates a template feature.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1f932109b117112c07dbd979.md)

## Rule

- **Rule:** Example scripts under examples/basic/ that demonstrate the i18n extension must register gettext/ngettext callables in env.globals and use the ngettext signature (singular, plural, count) for pluralized {% trans %} blocks.
- **Applies to:**
  - `examples/basic/**/*.py`
- **Condition:** When modifying or adding an example under examples/basic/ that demonstrates the i18n extension or {% trans %} blocks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-52daa8747d5710a8d5ff0306.md)

## Rule

- **Rule:** Example scripts under examples/basic/ that demonstrate the debugger must construct an Environment with a FileSystemLoader pointing at the templates directory and render a template that triggers the debugger, so the example remains a runnable debugger walkthrough.
- **Applies to:**
  - `examples/basic/**/*.py`
- **Condition:** When modifying or adding an example under examples/basic/ that demonstrates the debugger.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-90471e58bb594e36eacf516c.md)

## Rule

- **Rule:** Example scripts under examples/basic/ that demonstrate template inheritance must use a loader (e.g. DictLoader) with named templates and exercise multi-level extends/super() so the inheritance behavior is actually rendered.
- **Applies to:**
  - `examples/basic/**/*.py`
- **Condition:** When modifying or adding an example under examples/basic/ that demonstrates template inheritance.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e5f1471c415db460a5d495eb.md)
