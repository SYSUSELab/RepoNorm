# Constraints for `.pre-commit-config.yaml`

## Rule

- **Rule:**
  ```text
  pre-commit autoupdate is scheduled monthly via the ci.autoupdate_schedule setting.
  ```
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ac45c2fa565df9ed84444b24.md)
