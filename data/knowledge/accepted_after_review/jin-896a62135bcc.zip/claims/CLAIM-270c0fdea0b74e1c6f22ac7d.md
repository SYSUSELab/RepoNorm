# Rule details

- **Rule:**
  ```text
  Tests for babel extraction must assert that babel_extract yields (lineno, funcname, message, comments) tuples, with trans/pluralize blocks extracted as ngettext with a (singular, plural, None) tuple and gettext calls mapped to the gettext keyword.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for babel extraction output.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:383-397`
