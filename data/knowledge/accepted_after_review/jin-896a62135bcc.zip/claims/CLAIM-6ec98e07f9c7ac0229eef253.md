# Rule details

- **Rule:** The reorder-python-imports hook runs with --application-directories src.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: reorder-python-imports
        args: ["--application-directories", "src"]

```

- **Sources:**
  - `.pre-commit-config.yaml:12-13`

## Review evidence locations

- `.pre-commit-config.yaml:9-13`
