# Rule details

- **Rule:**
  ```text
  A get_user_count function passed to the template must be called exactly once during rendering of a pluralized i18n message.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** when modifying i18n plural translation tests or the plural function call-count contract
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:323-332`
