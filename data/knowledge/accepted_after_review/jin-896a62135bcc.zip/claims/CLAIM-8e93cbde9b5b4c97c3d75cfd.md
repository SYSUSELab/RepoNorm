# Rule details

- **Rule:**
  ```text
  When modifying async filter variants, `do_sum` must remain registered as the async variant of `sync_do_sum` and accumulate over `auto_aiter(iterable)`, so async sum supports both async and sync iterables through the shared async_variant protocol.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing the async sum filter or the async_variant registration protocol for filters.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:1230-1245`
