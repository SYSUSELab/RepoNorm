# Rule details

- **Rule:** The SecurityError exception must subclass TemplateRuntimeError and be raised when a template attempts an insecure operation while the sandbox is enabled.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** when modifying SecurityError or adding sandbox-related exceptions
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/exceptions.py:147-160`
