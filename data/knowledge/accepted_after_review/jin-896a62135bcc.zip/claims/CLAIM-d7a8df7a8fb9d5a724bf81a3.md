# Rule details

- **Rule:**
  ```text
  Tests for tuple literal rendering must assert Python tuple syntax, including the trailing comma for single-element tuples: '()|(1,)|(1, 2)'.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for tuple literal rendering.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:337-339`
