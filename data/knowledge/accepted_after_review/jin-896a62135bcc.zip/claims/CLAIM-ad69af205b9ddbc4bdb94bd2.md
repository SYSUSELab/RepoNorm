# Rule details

- **Rule:**
  ```text
  LRUCache.__reversed__ must iterate keys oldest-first, implemented by iterating a tuple snapshot of the internal queue.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  Modifying LRUCache.__reversed__ or the internal queue iteration order.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/utils.py:558-565`
