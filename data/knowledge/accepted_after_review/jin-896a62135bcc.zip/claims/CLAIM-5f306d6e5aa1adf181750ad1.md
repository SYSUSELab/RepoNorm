# Rule details

- **Rule:** When modifying the include tag's argument resolution, preserve support for a list argument that mixes variables and string literals: each element is resolved independently, and an unresolved variable element falls through to the literal element rather than aborting the include.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** Changing how the include tag resolves a list argument containing both variables and literals.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_imports.py:149-162`
- `src/jinja2/environment.py:1043-1052`
