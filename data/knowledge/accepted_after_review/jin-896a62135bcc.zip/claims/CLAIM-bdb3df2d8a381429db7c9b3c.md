# Rule details

- **Rule:** The With node must declare fields targets, values, and body, replacing the older Scope-based implementation.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying or adding AST node classes in jinja2.nodes, especially With.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:378-385`
