# Rule details

- **Rule:** The Sub node must remain a BinExpr subclass whose operator attribute is '-', defining the subtraction operator mapping.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying the Sub node or binary operator mappings.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:971-974`
