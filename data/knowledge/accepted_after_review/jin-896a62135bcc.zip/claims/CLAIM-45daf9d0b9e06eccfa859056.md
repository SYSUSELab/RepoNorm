# Rule details

- **Rule:**
  ```text
  When modifying the compiler's import emission, preserve that _import_common emits make_module or make_module_async depending on async mode, passes with_context plus the dumped local context, and emits _get_default_module(_async) when no context is given.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when changing how imports with or without context are compiled
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:1081-1094`
