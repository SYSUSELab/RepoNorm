# Rule details

- **Rule:** Parser.parse must build a Template node from subparse with lineno=1 and set the environment on the result, defining the top-level parse contract.
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** When modifying the top-level parse entry point or Template node construction in the parser.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/parser.py:1036-1040`
