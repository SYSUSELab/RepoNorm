# Rule details

- **Rule:**
  ```text
  Tests for template import globals override must assert that an imported module sees the overridden global value passed to from_string rather than a locally set value.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying tests for template import globals override behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_imports.py:110-115`
