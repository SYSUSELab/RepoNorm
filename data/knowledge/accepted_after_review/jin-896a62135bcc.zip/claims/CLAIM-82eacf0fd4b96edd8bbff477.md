# Rule details

- **Rule:**
  ```text
  Template expression evaluation must preserve slicing semantics: list slicing and reverse slicing render as '[1, 2, 3]' and '[3, 2, 1]'.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying template expression slicing or the TestSyntax.test_slicing test.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:325-327`
