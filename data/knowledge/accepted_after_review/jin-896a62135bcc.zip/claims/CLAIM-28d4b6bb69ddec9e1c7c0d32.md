# Rule details

- **Rule:**
  ```text
  Node.can_assign must default to False so that nodes are non-assignable unless they explicitly override it; assignment targets must opt in.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  Modifying Expr.can_assign or adding new node types that may be assignment targets.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:470-485`
- `src/jinja2/nodes.py:621-639`
