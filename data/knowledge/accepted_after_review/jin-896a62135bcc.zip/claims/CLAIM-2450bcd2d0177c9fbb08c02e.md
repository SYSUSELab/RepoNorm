# Rule details

- **Rule:**
  ```text
  MemcachedBytecodeCache must document and rely on a minimal client interface of set(key, value[, timeout]) and get(key) returning None on miss; the Django cache interface is incompatible because it cannot store binary data.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying MemcachedBytecodeCache or its client interface expectations.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/bccache.py:287-318`
