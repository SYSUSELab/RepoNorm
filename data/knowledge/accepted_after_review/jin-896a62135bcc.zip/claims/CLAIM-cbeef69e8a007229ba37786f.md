# Rule details

- **Rule:**
  ```text
  The Overlay extension parse protocol must build an OverlayScope node, parse until endoverlay, and set node.context via self.call_method('get_scope').
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** when modifying overlay extension parse tests or the OverlayScope parse protocol
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:688-701`
