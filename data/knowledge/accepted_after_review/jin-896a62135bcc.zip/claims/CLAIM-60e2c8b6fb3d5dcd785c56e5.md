# Rule details

- **Rule:** Do not use the issue tracker for support questions; the issue tracker is for bugs and feature requests in Jinja itself.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Please don't use the issue tracker for this. The issue tracker is a
tool to address bugs and feature requests in Jinja itself. Use one of
the following resources for questions about using Jinja or issues with
your own code:

```

- **Sources:**
  - `CONTRIBUTING.rst:10-13`

## Review evidence locations

- `CONTRIBUTING.rst:10-13`
