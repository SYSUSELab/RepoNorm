# Rule details

- **Rule:** The Compare node must declare fields ("expr", "ops") and type ops as a list of Operand, defining the AST shape for comparison expressions.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying the Compare AST node schema or its ops typing.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Compare declares fields ("expr", "ops") and types ops as t.List["Operand"], matching the AST schema rule.
```

- **Sources:**
  - `src/jinja2/nodes.py:909-934`
