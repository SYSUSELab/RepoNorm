# Rule details

- **Rule:** When modifying the loopcontrols extension, preserve that continue skips the current iteration and break stops the loop.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** Changing loopcontrols extension behavior for continue or break.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:221-240`
