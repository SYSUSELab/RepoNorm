# Rule details

- **Rule:**
  ```text
  pop_assign_tracking must add only public (non-underscore-prefixed) names to context.exported_vars, using add for a single name and update for multiple names.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Modifying assignment tracking or exported variable collection in the compiler.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:793-822`
