# Rule details

- **Rule:**
  ```text
  `do_float` must return `float(value)` and fall back to the default (0.0) on TypeError or ValueError, with no string-prefix or base handling.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying `do_float` or its error handling, preserve the float(value) conversion and TypeError/ValueError fallback to the default without adding prefix/base parsing.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:936-944`
