# Rule details

- **Rule:**
  ```text
  The test_compile.py module must import Environment from jinja2.environment and DictLoader from jinja2.loaders, exercising compilation through those public entry points.
  ```
- **Applies to:**
  - `tests/test_compile.py`
- **Condition:** When modifying or adding compilation tests that use Environment and DictLoader public entry points.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_compile.py imports Environment from jinja2.environment and DictLoader from jinja2.loaders, exercising compilation through those public entry points.
```

- **Sources:**
  - `tests/test_compile.py`
