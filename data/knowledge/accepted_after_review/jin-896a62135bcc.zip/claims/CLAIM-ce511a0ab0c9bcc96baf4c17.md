# Rule details

- **Rule:**
  ```text
  do_tojson must be decorated with pass_eval_context and return Markup via htmlsafe_json_dumps, using eval_ctx.environment.policies["json.dumps_function"] and json.dumps_kwargs; output is safe for HTML and <script> tags but not for double-quoted HTML attributes, where |forceescape should be used.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_tojson or its HTML-safety contract.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:1594-1620`
