# Rule details

- **Rule:**
  ```text
  With `lstrip_blocks` enabled and `trim_blocks` disabled, the trailing dash on `{%- raw -%}` strips whitespace and newlines up to the first data character, and the trailing dash on `{%- endraw -%}` strips following whitespace.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending raw-block whitespace handling tests under lstrip_blocks/trim_blocks settings.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:62-69`
