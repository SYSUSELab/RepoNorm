# Rule details

- **Rule:**
  ```text
  Template construction from compiled code must keep the compiled namespace contract: from_code execs the code with environment and __file__ seeded, then _from_namespace requires the namespace to provide 'name', '__file__', 'blocks', 'root', and 'debug_info' and writes back 'environment' and '__jinja_template__'.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when changing Template.from_code, Template._from_namespace, or the compiled-code namespace keys they exchange
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:1198-1253`
