# Rule details

- **Rule:**
  ```text
  Async template rendering must go through the async module/render path: use make_module_async instead of make_module, and Template.generate must branch on environment.is_async to run the render coroutine via asyncio.run rather than yielding directly from root_render_func.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** When modifying template module creation or the generate/render path for async environments.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:1328-1404`
