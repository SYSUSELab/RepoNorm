# Rule details

- **Rule:**
  ```text
  Tests in tests/test_loader.py that pin PackageLoader.get_source must preserve that it returns source content, a name ending with the split template path, and an up_to_date callable that returns truthy, covering both nested (foo/test.html) and top-level (test.html) package templates.
  ```
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When modifying or extending PackageLoader.get_source tests in tests/test_loader.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_loader.py:300-307`
