# Rule details

- **Rule:**
  ```text
  symbols_for_node must assign refs in the form l_<level>_<name> and produce load-kind tuples such as ("undefined", None), ("resolve", "bar"), and ("param", None) for identifier tracking.
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:**
  ```text
  when modifying identifier tracking tests or the symbols_for_node naming and load-kind contract
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_idtracking.py:18-36`
