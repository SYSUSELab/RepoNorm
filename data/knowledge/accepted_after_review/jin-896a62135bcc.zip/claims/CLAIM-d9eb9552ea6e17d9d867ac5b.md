# Rule details

- **Rule:** AssignBlock must be a Stmt node with fields ("target", "filter", "body"), where filter is optional, representing block assignment with an optional filter.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying the AssignBlock AST node schema or its optional filter field.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
AssignBlock subclasses Stmt and declares fields ("target", "filter", "body") with filter typed as optional Filter, matching the required schema.
```

- **Sources:**
  - `src/jinja2/nodes.py:456-462`
