# Rule details

- **Rule:**
  ```text
  Tests in tests/test_lexnparse.py that pin TokenStream protocol must preserve that bool(ts) is true while not at EOF and false at EOF, while ts.eos is the inverse, defining the stream truthiness/end-of-stream protocol.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending TokenStream protocol tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:15-33`
