# Rule details

- **Rule:**
  ```text
  AsyncLoopContext._to_iterator must convert any iterable or async iterable into an async iterator via auto_aiter, providing a uniform async iteration entry point.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying AsyncLoopContext._to_iterator or async iteration entry points.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/runtime.py:584-591`
