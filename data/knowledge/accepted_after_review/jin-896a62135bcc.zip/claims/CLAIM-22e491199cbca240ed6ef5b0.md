# Rule details

- **Rule:** Read the Docs documentation builds use the dirhtml Sphinx builder.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  builder: dirhtml

```

- **Sources:**
  - `.readthedocs.yaml:8`

## Review evidence locations

- `.readthedocs.yaml:7-9`
