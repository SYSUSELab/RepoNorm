# Rule details

- **Rule:** Clone the main Jinja repository locally and change into the jinja directory.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   `Clone`_ the main repository locally.

    .. code-block:: text

        $ git clone https://github.com/pallets/jinja
        $ cd jinja

```

- **Sources:**
  - `CONTRIBUTING.rst:82-87`

## Review evidence locations

- `CONTRIBUTING.rst:80-87`
