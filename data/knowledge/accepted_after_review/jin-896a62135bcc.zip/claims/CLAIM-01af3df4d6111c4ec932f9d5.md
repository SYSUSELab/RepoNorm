# Rule details

- **Rule:** When modifying the int filter with a base argument, preserve that prefixed strings like 0x4d32 parse as base 16 and 011 as base 8, while invalid input such as 0x33Z in base 16 returns 0.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** Changing the int filter's base-argument parsing or failure fallback.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:205-211`
