# Rule details

- **Rule:**
  ```text
  The tox testenv:style environment depends on the `pre-commit` package.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
deps = pre-commit

```

- **Sources:**
  - `tox.ini:14`

## Review evidence locations

- `tox.ini:13-16`
