# Rule details

- **Rule:**
  ```text
  Tests for whitespace control with trim_blocks and lstrip_blocks enabled must assert that a comment followed by blank lines preserves leading spaces and newlines in the rendered output.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  when adding or modifying tests for comment handling under trim_blocks and lstrip_blocks
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:968-990`
