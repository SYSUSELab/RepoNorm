# Rule details

- **Rule:** mypy is configured to warn when returning a value of type Any.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
warn_return_any = True

```

- **Sources:**
  - `setup.cfg:102`

## Review evidence locations

- `setup.cfg:87-102`
