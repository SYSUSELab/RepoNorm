# Rule details

- **Rule:**
  ```text
  The Include AST node must declare fields template, with_context, and ignore_missing.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying or adding AST node classes in jinja2.nodes, especially Include.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:405-411`
