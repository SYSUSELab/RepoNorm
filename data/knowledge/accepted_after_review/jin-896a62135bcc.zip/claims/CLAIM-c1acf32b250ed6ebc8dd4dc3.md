# Rule details

- **Rule:** Tests for the map filter in async environments must assert that applying map to None yields an empty list rather than raising, treating None as an empty iterable.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When adding or modifying tests for the map filter with None or empty input in async environments.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async_filters.py:180-182`
