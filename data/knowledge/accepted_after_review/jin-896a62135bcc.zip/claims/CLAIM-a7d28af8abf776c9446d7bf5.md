# Rule details

- **Rule:**
  ```text
  RootVisitor.visit_OverlayScope must visit only the body children, not the context expression, so symbols introduced by the overlay context are not tracked as defined names.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  When modifying RootVisitor.visit_OverlayScope or overlay-scope symbol tracking.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/idtracking.py:198-200`
