# Rule details

- **Rule:**
  ```text
  The FrameSymbolVisitor.visit_Macro method must record a macro's name via symbols.store, so that macro names participate in the same symbol table as other assignments.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  when modifying FrameSymbolVisitor.visit_Macro or adding similar symbol-recording visitors
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/idtracking.py:270-271`
