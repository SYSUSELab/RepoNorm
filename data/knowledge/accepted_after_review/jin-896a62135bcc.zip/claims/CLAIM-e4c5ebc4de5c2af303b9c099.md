# Rule details

- **Rule:** Tests that exercise slice filtering must assert the exact chunking and fill behavior, including the number of slices and the fill value used for the last slice.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:**
  ```text
  When modifying slice filter chunking or fill behavior in tests/test_async_filters.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:73-79`
