# Rule details

- **Rule:** Tests for loop.cycle must assert that both positional arguments and unpacked sequences cycle through the provided values in order.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying tests for loop.cycle with positional or unpacked sequence arguments.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async.py:326-333`
