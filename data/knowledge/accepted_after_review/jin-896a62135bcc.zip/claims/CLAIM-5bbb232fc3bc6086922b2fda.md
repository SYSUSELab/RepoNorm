# Rule details

- **Rule:**
  ```text
  When implementing the is_up_to_date property, return True when _uptodate is None, otherwise delegate to the _uptodate callable.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  Modifying Template.is_up_to_date or adding auto-reload freshness checks.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:1477-1482`
