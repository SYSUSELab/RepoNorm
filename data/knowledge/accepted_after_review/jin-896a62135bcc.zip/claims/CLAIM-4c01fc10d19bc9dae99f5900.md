# Rule details

- **Rule:**
  ```text
  Tests for custom async filters must assert that filters registered on env_async.filters are applied to both static and dynamic values, with the rendered output preserving the filter results.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** when adding or modifying tests for custom async filters
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async_filters.py:228-235`
