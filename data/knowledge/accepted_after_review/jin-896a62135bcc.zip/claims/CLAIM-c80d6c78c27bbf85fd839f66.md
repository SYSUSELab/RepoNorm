# Rule details

- **Rule:** The tests job runs across a matrix including Linux, Windows, and Mac on Python 3.10 (tox py310), 3.11-dev (tox py311), 3.9 (tox py39), 3.8 (tox py38), 3.7 (tox py37), PyPy 3.7 (tox pypy37), and a Typing environment on Python 3.10 (tox typing).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        include:
          - {name: Linux, python: '3.10', os: ubuntu-latest, tox: py310}
          - {name: Windows, python: '3.10', os: windows-latest, tox: py310}
          - {name: Mac, python: '3.10', os: macos-latest, tox: py310}
          - {name: '3.11-dev', python: '3.11-dev', os: ubuntu-latest, tox: py311}
          - {name: '3.9', python: '3.9', os: ubuntu-latest, tox: py39}
          - {name: '3.8', python: '3.8', os: ubuntu-latest, tox: py38}
          - {name: '3.7', python: '3.7', os: ubuntu-latest, tox: py37}
          - {name: 'PyPy', python: 'pypy-3.7', os: ubuntu-latest, tox: pypy37}
          - {name: Typing, python: '3.10', os: ubuntu-latest, tox: typing}

```

- **Sources:**
  - `.github/workflows/tests.yaml:26-35`

## Review evidence locations

- `.github/workflows/tests.yaml:20-35`
