# Rule details

- **Rule:** Read the Docs documentation builds install the repository itself via pip from the repository root.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    - method: pip
      path: .

```

- **Sources:**
  - `.readthedocs.yaml:5-6`

## Review evidence locations

- `.readthedocs.yaml:2-6`
