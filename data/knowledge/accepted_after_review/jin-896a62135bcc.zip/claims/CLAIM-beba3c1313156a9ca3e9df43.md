# Rule details

- **Rule:**
  ```text
  `_parse_block` must enforce that a translatable section contains at most one pluralize section, forbid control structures inside translatable sections, and fail on unclosed translation blocks with explicit messages.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When modifying `_parse_block` or the i18n extension's block parsing rules.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/ext.py:489-503`
