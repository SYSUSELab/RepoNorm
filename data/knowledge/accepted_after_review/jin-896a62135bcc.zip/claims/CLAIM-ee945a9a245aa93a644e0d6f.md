# Rule details

- **Rule:** The black hook is configured as a pre-commit hook.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: black

```

- **Sources:**
  - `.pre-commit-config.yaml:17`

## Review evidence locations

- `.pre-commit-config.yaml:14-17`
