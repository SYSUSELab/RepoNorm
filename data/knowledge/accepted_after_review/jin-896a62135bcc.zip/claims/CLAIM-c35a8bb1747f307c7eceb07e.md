# Rule details

- **Rule:**
  ```text
  Extension classes must declare a `tags` set naming the block tag(s) they handle, and the tag name must match the block name used in templates and in the extension's own parse/end-tag handling.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:**
  ```text
  When adding or renaming a block tag handled by an extension example, update the `tags` declaration and the corresponding parse/end-tag names consistently.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/examples/cache_extension.py:5-20`
- `docs/examples/cache_extension.py:32-40`
