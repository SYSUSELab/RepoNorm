# Rule details

- **Rule:**
  ```text
  When modifying CodeGenerator.visit_Template, preserve the inheritance codegen: yield from parent_template.root_render_func(context) in sync mode and async for with yield event in async mode, gated on parent_template not being None when extends is not statically known.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When changing template inheritance code generation in CodeGenerator.visit_Template.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:892-907`
