# Rule details

- **Rule:** When a sequence is empty, the first filter must return environment.undefined("No first item, sequence was empty.") rather than raising StopIteration.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** Modifying the first filter or its handling of empty sequences.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
sync_do_first returns environment.undefined("No first item, sequence was empty.") on StopIteration instead of propagating the exception, matching the empty-sequence contract.
```

- **Sources:**
  - `src/jinja2/filters.py:582-589`
