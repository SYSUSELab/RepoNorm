# Rule details

- **Rule:**
  ```text
  ImmutableSandboxedEnvironment must behave exactly like SandboxedEnvironment except it forbids modifications to builtin mutable list, set, and dict via modifies_known_mutable; this is an API compatibility boundary for sandboxed environments.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying ImmutableSandboxedEnvironment or its modifies_known_mutable behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/sandbox.py:396-406`
