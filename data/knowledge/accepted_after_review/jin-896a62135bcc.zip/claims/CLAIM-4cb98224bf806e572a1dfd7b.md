# Rule details

- **Rule:**
  ```text
  LRUCache.clear must reset the cache so __getstate__ returns capacity, an empty _mapping, and an empty deque _queue.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when modifying LRUCache clear tests or the clear/__getstate__ state contract
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:61-67`
