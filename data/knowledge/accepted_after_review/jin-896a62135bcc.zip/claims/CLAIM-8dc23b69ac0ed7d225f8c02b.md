# Rule details

- **Rule:**
  ```text
  When modifying the AST node definitions, `FilterBlock` must keep its field contract: fields tuple `("body", "filter")` with `body` a list of Node and `filter` a Filter node.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Changing the FilterBlock AST node's fields or their typing.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:370-375`
