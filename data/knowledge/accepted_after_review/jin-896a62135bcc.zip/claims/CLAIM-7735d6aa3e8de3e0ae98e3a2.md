# Rule details

- **Rule:**
  ```text
  macro_body must reject an explicitly listed 'caller' argument without a default, and must declare kwargs/varargs parameters only when undeclared in the body and not already explicit parameters.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Modifying macro argument compilation or the caller/kwargs/varargs handling in the code generator.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
macro_body fails when 'caller' is explicit without a default (IndexError -> self.fail) and declares kwargs/varargs only when undeclared and not in skip_special_params.
```

- **Sources:**
  - `src/jinja2/compiler.py:611-692`
