# Rule details

- **Rule:**
  ```text
  `unsafe` must set `f.unsafe_callable = True` on the decorated function and return it, marking callables as unsafe for sandbox checks.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying the `unsafe` decorator or sandbox callable checks, preserve setting `f.unsafe_callable = True` and returning the function.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/sandbox.py:112-122`
