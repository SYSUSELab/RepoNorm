# Rule details

- **Rule:** Character encoding is UTF-8 (charset = utf-8).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
charset = utf-8

```

- **Sources:**
  - `.editorconfig:9`

## Review evidence locations

- `.editorconfig:3-10`
