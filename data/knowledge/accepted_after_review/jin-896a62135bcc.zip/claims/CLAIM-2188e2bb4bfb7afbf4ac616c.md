# Rule details

- **Rule:**
  ```text
  Tests in tests/test_inheritance.py that pin template inheritance must preserve that rendering a template that extends a layout produces the layout's block content in order, including nested blocks, as asserted by the exact output string.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying or extending template inheritance tests in tests/test_inheritance.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_inheritance.py:77-100`
