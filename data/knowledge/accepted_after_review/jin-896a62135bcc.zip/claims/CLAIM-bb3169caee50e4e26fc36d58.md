# Rule details

- **Rule:**
  ```text
  When modifying InternationalizationExtension._make_node, preserve the distinction between newstyle gettext (variables as keyword arguments, skipping 'num' when num_called_num) and old style (MarkSafeIfAutoescape wrapping with dict modulo substitution).
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When changing i18n node generation in InternationalizationExtension._make_node.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/ext.py:545-565`
