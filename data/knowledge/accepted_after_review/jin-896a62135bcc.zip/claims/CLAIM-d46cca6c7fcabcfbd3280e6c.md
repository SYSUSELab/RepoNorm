# Rule details

- **Rule:** When modifying NodeTransformer, preserve the replacement protocol: replace a node with the visitor function's return value, remove the node when the return value is None, and leave it unchanged when the original node is returned.
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:** When changing NodeTransformer's node replacement behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
NodeTransformer subclasses NodeVisitor and preserves the replacement protocol: non-None return replaces, None removes, original node leaves unchanged.
```

- **Sources:**
  - `src/jinja2/visitor.py:50-92`
