# Rule details

- **Rule:** The typing tox test environment installs dependencies from requirements/typing.txt.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
deps = -r requirements/typing.txt

```

- **Sources:**
  - `tox.ini:19`

## Review evidence locations

- `tox.ini:18-20`
