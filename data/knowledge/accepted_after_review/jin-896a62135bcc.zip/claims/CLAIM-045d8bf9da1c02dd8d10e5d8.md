# Rule details

- **Rule:**
  ```text
  Push commits to your fork on GitHub and create a pull request, linking to the issue being addressed with ``fixes #123`` in the pull request.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Push your commits to your fork on GitHub and
    `create a pull request`_. Link to the issue being addressed with
    ``fixes #123`` in the pull request.

```

- **Sources:**
  - `CONTRIBUTING.rst:161-163`

## Review evidence locations

- `CONTRIBUTING.rst:157-163`
