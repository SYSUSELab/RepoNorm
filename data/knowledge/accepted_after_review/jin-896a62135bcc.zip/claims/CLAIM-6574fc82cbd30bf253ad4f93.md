# Rule details

- **Rule:**
  ```text
  When modifying the parser's unary expression handling, preserve that unary minus/plus recursion passes with_filter=False so filters are not applied to the operand of a unary operator; filters apply only at the outer level when with_filter is true.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** when changing unary operator parsing or filter application in expressions
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/parser.py:630-646`
