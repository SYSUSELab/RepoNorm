# Rule details

- **Rule:**
  ```text
  The async filter tests must build user data as a namedtuple with fields `name` and `is_active`, including both active and inactive users, so filter behavior can be asserted against a stable mixed dataset.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When modifying or extending async filter test fixtures.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async_filters.py:146-160`
