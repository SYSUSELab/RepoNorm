# Rule details

- **Rule:**
  ```text
  Tests for newstyle i18n plural rendering must assert that the plural template renders singular and plural German forms based on user_count.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for newstyle i18n plural rendering.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:502-510`
