# Rule details

- **Rule:**
  ```text
  pre-commit autoupdate is scheduled monthly via the ci.autoupdate_schedule setting.
  ```
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
ci:
  autoupdate_schedule: monthly

```

- **Sources:**
  - `.pre-commit-config.yaml:1-2`
