# Rule details

- **Rule:**
  ```text
  The fs_env fixture must wrap a filesystem_loader in an Environment so debug tests operate against a filesystem-backed loader.
  ```
- **Applies to:**
  - `tests/test_debug.py`
- **Condition:**
  ```text
  When modifying or adding debug tests that require a filesystem-backed loader via the fs_env fixture.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_debug.py:13-16`
