# Rule details

- **Rule:** The pre-commit-hooks repository configures the fix-byte-order-marker hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: fix-byte-order-marker

```

- **Sources:**
  - `.pre-commit-config.yaml:26`

## Review evidence locations

- `.pre-commit-config.yaml:23-28`
