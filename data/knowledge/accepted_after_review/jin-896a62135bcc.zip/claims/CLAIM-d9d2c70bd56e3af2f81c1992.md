# Rule details

- **Rule:**
  ```text
  Tests for filter precedence must assert that filters bind tighter than the + operator, so 'foo'|upper + 'bar'|upper renders as FOOBAR.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for filter precedence relative to operators.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:455-457`
