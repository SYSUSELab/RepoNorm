# Rule details

- **Rule:**
  ```text
  When modifying `Concat.as_const`, preserve constant evaluation of a node list as string concatenation of `str(x.as_const(eval_ctx))` for child nodes.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When changing constant evaluation for concatenation nodes or node lists.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:896-906`
