# Rule details

- **Rule:** The escaped test must return True only for Markup instances and False for plain strings, even when autoescape is enabled, distinguishing already-safe markup from raw strings.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying the escaped test or the Markup/autoescape distinction it verifies.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/tests.py:202-204`
- `tests/test_tests.py:166-169`
