# Rule details

- **Rule:** Tests for unary operators must assert that unary plus and minus are evaluated at render time, producing the numeric value without the sign for plus and with the sign for minus.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** when adding or modifying tests for unary operator rendering
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:349-351`
