# Rule details

- **Rule:**
  ```text
  When modifying `modifies_known_mutable`, preserve the conservative detection: return `True` only when the attribute is in the unsafe set for a matching builtin mutable type, and return `False` for unsupported objects such as strings.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** When changing sandbox mutable-attribute detection or the unsafe attribute sets.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/sandbox.py:162-180`
