# Rule details

- **Rule:**
  ```text
  CodeGenerator.write must defer newlines and indentation until the next write: emit pending newlines, update code_lineno, record debug info, then write indentation before the actual string, so generated code line numbers track emitted newlines.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying CodeGenerator.write or generated-code line-number tracking.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:453-465`
