# Rule details

- **Rule:** The last filter must not be applied to generators: callers must convert to a list first, an empty sequence yields Undefined rather than raising, and there is intentionally no async variant of last because it may be unsafe in async mode.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** When modifying or adding filters, especially last, or when deciding whether a filter needs an async variant.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:602-621`
