# Rule details

- **Rule:** When implementing undefined detection, use isinstance(value, Undefined) rather than a sentinel value.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  Modifying test_undefined or adding undefined-detection logic.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/tests.py:29-48`
