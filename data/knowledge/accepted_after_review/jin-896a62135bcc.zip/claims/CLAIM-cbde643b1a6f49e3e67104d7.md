# Rule details

- **Rule:**
  ```text
  Tests for pass_arg detection must verify that a callable class whose __getattr__ returns truthy values for arbitrary attributes is not misidentified as a pass_context function.
  ```
- **Applies to:**
  - `tests/test_runtime.py`
- **Condition:**
  ```text
  When adding or modifying pass_arg detection tests in tests/test_runtime.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_runtime.py:59-75`
