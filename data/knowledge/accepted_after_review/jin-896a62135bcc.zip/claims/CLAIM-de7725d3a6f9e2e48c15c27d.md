# Rule details

- **Rule:** The tests job installs the matrix Python version via actions/setup-python.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: actions/setup-python@v2
        with:
          python-version: ${{ matrix.python }}

```

- **Sources:**
  - `.github/workflows/tests.yaml:38-40`

## Review evidence locations

- `.github/workflows/tests.yaml:36-40`
