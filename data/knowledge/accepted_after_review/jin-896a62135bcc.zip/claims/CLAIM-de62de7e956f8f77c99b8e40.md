# Rule details

- **Rule:**
  ```text
  The `even` Jinja test must return True for even integers and False for odd integers.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When modifying or extending the `even` Jinja test or its assertions.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/tests.py:19-21`
- `tests/test_tests.py:18-20`
