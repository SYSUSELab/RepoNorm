# Rule details

- **Rule:** When modifying the select filter, preserve that without a test it keeps only truthy values.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** Changing the select filter's default truthiness behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:711-714`
- `tests/test_async_filters.py:140-143`
