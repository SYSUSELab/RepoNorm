# Rule details

- **Rule:** Package data files are included in distributions.
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
include_package_data = true

```

- **Sources:**
  - `setup.cfg:35`
