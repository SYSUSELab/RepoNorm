# Rule details

- **Rule:** Tests for ChoiceLoader must verify that a template name present in a later loader is still found when an earlier loader cannot resolve it, exercising the ordered fallback.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:**
  ```text
  When adding or modifying ChoiceLoader tests in tests/test_loader.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/loaders.py:527-552`
- `tests/test_loader.py:44-50`
