# Rule details

- **Rule:** groupby('date.year') on async articles must group by nested attribute and render year groups in order, including a trailing empty segment.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** when modifying async groupby multidot tests or the nested-attribute grouping contract
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async_filters.py:82-94`
