# Rule details

- **Rule:**
  ```text
  Run `coverage html` to generate an HTML coverage report.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    $ coverage html

```

- **Sources:**
  - `CONTRIBUTING.rst:203`

## Review evidence locations

- `CONTRIBUTING.rst:192-205`
