# Rule details

- **Rule:**
  ```text
  Tests in tests/test_ext.py that pin autoescape scoping must preserve that a macro defined inside {% autoescape val %} produces Markup when val is true and str when false, and compiled source reflects the escaping decision, asserting autoescape state is captured per-scope at compile time.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying or extending autoescape scoping tests in tests/test_ext.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:663-686`
