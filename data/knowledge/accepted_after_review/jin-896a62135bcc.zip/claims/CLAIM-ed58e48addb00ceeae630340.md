# Rule details

- **Rule:** Stmt must be the abstract base node for all statement nodes, so concrete statement node types must inherit from it.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Adding or modifying statement node types in the AST hierarchy.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Stmt is defined as an abstract Node subclass (abstract = True) and serves as the base node for all statement nodes, satisfying the Stmt base-class contract.
```

- **Sources:**
  - `src/jinja2/nodes.py:280-283`
