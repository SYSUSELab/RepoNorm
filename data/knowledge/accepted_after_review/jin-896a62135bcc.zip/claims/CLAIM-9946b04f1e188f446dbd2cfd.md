# Rule details

- **Rule:** mypy is configured to disallow implicit re-export.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
no_implicit_reexport = True

```

- **Sources:**
  - `setup.cfg:97`

## Review evidence locations

- `setup.cfg:87-98`
