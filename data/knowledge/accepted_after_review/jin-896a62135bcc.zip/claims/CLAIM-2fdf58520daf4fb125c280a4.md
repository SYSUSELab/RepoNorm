# Rule details

- **Rule:** Coverage measurement is configured to run with branch coverage enabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
branch = True

```

- **Sources:**
  - `setup.cfg:54`

## Review evidence locations

- `setup.cfg:53-57`
