# Rule details

- **Rule:**
  ```text
  Macro code generation must emit a Macro(...) call whose argument tuple is built from macro_ref.node.args, appending a trailing comma for a single argument, and pass accesses_kwargs, accesses_varargs, accesses_caller, and context.eval_ctx.autoescape.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying CodeGenerator.macro_def or macro code generation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:694-704`
