# Rule details

- **Rule:** The docs tox environment builds HTML documentation with sphinx-build using -W (warnings as errors) and doctrees/output directories under the environment temp dir.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
commands = sphinx-build -W -b html -d {envtmpdir}/doctrees docs {envtmpdir}/html

```

- **Sources:**
  - `tox.ini:24`

## Review evidence locations

- `tox.ini:22-24`
