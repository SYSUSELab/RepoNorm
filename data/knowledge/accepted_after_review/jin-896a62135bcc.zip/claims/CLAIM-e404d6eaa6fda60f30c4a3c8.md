# Rule details

- **Rule:** Tests for LRUCache must assert that values() on an empty cache returns an empty list.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for LRUCache values() behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:34-36`
