# Rule details

- **Rule:** Tests for tuple literal and tuple-unpacking loop target syntax must cover trailing-comma forms such as {{ (1, 2,) }}, {{ 1, }}, and {% for x in foo, %}.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for tuple expression syntax in templates.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:484-495`
