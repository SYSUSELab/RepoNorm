# Rule details

- **Rule:** Tests for comment parsing must verify that comments (including multi-line comments at the start of a template) are stripped from output and do not affect subsequent parsing, such as a macro defined after a comment rendering normally.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for comment handling in templates.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:79-91`
- `tests/test_lexnparse.py:223-230`
