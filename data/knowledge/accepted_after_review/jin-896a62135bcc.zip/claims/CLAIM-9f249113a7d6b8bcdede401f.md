# Rule details

- **Rule:**
  ```text
  When modifying the i18n extension, `InternationalizationExtension.__init__` must install `_` as a global and extend the environment with `install_gettext_translations`, `install_null_translations`, `install_gettext_callables`, `uninstall_gettext_translations`, `extract_translations`, and `newstyle_gettext=False`, preserving the extension's public environment API surface.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Changing the i18n extension's initialization or its environment API surface.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/ext.py:257-267`
