# Rule details

- **Rule:**
  ```text
  Template subscript expressions must support negative indexing, so foo[0] and foo[-1] render as 0|2 for [0, 1, 2].
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying or adding tests for template subscript expression indexing behavior, including negative indices.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:333-335`
