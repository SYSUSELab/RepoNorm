# Rule details

- **Rule:**
  ```text
  Environment.parse must return the AST and, on TemplateSyntaxError, route through handle_exception with the original source so parse failures are reported via the environment's exception handling rather than propagating raw.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when changing Environment.parse or its TemplateSyntaxError handling path
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Environment.parse returns self._parse(source, name, filename) and catches TemplateSyntaxError to route through self.handle_exception(source=source), preserving parse error routing.
```

- **Sources:**
  - `src/jinja2/environment.py:584-601`
