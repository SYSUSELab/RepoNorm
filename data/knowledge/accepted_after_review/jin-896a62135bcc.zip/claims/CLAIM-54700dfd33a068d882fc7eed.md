# Rule details

- **Rule:**
  ```text
  When modifying CodeGenerator operator visitors, preserve the table-driven generation via _make_binop/_make_unop factory assignments rather than hand-written per-operator visitors.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When adding or changing binary/unary operator code generation in CodeGenerator.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:1671-1682`
