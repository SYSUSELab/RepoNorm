# Rule details

- **Rule:**
  ```text
  Environment.list_templates must raise TypeError when both extensions and filter_func are provided, require the loader to support list_templates, and otherwise filter names by extension or by the supplied predicate.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  Modifying Environment.list_templates or its argument validation/filtering behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:883-915`
