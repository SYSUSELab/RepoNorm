# Rule details

- **Rule:** pytest test discovery is restricted to the tests directory via testpaths = tests.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
testpaths = tests

```

- **Sources:**
  - `setup.cfg:47`
