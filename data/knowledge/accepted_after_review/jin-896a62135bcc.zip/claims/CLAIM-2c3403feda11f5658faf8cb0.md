# Rule details

- **Rule:** The optimizer must not perform optimizations such as loop unrolling because the AST lacks full scoping information; a second syntax tree storing scoping rules would be required.
- **Applies to:**
  - `src/jinja2/optimizer.py`
- **Condition:** When modifying the optimizer or considering scoping-dependent optimizations, preserve the limitation that loop unrolling and similar optimizations require a second syntax tree with scoping rules.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The optimizer module docstring states the AST lacks full scoping information and that loop unrolling would require a second syntax tree storing scoping rules, preserving the scoping limitation.
```

- **Sources:**
  - `src/jinja2/optimizer.py`
