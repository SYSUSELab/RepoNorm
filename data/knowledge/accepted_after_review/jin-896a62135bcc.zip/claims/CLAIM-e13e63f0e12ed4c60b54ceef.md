# Rule details

- **Rule:**
  ```text
  The 'Lock threads' workflow runs on a daily schedule defined by the cron expression '0 0 * * *'.
  ```
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Condition:**
  ```text
  workflow predicate: schedule: - cron: '0 0 * * *'
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
on:
  schedule:
    - cron: '0 0 * * *'

```

- **Sources:**
  - `.github/workflows/lock.yaml:3-5`

## Review evidence locations

- `.github/workflows/lock.yaml:1-5`
