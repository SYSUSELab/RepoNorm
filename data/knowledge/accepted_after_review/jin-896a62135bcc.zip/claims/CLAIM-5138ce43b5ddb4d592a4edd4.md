# Rule details

- **Rule:**
  ```text
  When modifying `visit_AssignBlock` in the compiler, preserve the behavior of disabling output checks for the block frame so set blocks can be used at top level in extended templates, and wrapping the captured buffer with `Markup` or identity based on autoescape.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When changing code generation for assignment blocks or set blocks in extended templates.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:1566-1584`
