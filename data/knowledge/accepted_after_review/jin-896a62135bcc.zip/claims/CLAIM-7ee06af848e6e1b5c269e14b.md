# Rule details

- **Rule:**
  ```text
  When modifying `_gettext_alias`, preserve it as a pass-context function that resolves and calls the context's 'gettext' callable, providing the `_` alias used in templates.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When changing the `_` gettext alias or its context resolution.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/ext.py:163-167`
