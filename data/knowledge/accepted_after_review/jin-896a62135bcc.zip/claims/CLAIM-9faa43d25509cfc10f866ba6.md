# Rule details

- **Rule:**
  ```text
  Inline gettext extension classes must declare a dependency on the i18n extension being loaded and configured, and must implement inline gettext blocks of the form `_(text)`.
  ```
- **Applies to:**
  - `docs/examples/inline_gettext_extension.py`
- **Condition:**
  ```text
  When modifying the inline gettext extension, preserve the i18n extension dependency and the `_(text)` block form.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/examples/inline_gettext_extension.py:13-20`
- `docs/examples/inline_gettext_extension.py:45-60`
