# Rule details

- **Rule:** The scoped special variable loop.first inside nested for loops must reflect the innermost loop, producing the documented nested output.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying loop scoping or special loop variables in async templates.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async.py:484-489`
