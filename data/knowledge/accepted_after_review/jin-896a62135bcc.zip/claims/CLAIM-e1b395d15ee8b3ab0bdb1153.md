# Rule details

- **Rule:** Native template rendering must raise UndefinedError when an undefined value is used in arithmetic, and must preserve leading whitespace before rendered expressions.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** when modifying native template rendering tests or the native undefined/whitespace contract
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_loop_look_alike renders a single-element loop and asserts native int result, consistent with native rendering behavior; it also relates to undefined/whitespace contract coverage.
```

- **Sources:**
  - `tests/test_nativetypes.py:68-72`

## Review evidence locations

- `tests/test_nativetypes.py:26-30`
- `tests/test_nativetypes.py:152-155`
