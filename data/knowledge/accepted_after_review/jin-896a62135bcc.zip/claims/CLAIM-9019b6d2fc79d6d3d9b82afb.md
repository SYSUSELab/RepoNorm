# Rule details

- **Rule:** Upgrade pip and setuptools with python -m pip install --upgrade pip setuptools.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Upgrade pip and setuptools.

    .. code-block:: text

        $ python -m pip install --upgrade pip setuptools

```

- **Sources:**
  - `CONTRIBUTING.rst:110-114`

## Review evidence locations

- `CONTRIBUTING.rst:110-114`
