# Rule details

- **Rule:**
  ```text
  Install the `coverage` package with `pip install coverage` before running coverage commands.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    $ pip install coverage

```

- **Sources:**
  - `CONTRIBUTING.rst:201`

## Review evidence locations

- `CONTRIBUTING.rst:195-203`
