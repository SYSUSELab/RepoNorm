# Rule details

- **Rule:**
  ```text
  When modifying the mark_safe filter or its compiler counterpart, preserve the invariant that mark_safe returns a Markup instance (and MarkSafe nodes compile to an explicit Markup construction) so autoescaping is bypassed.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when changing mark_safe filter behavior or MarkSafe node compilation
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:1264-1268`
- `src/jinja2/compiler.py:1869-1872`
