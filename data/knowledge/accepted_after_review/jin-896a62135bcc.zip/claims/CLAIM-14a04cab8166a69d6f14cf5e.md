# Rule details

- **Rule:**
  ```text
  Blocks defined inside a false conditional in a parent template must still be available via `self.x()`, and a child overriding such a block with `super()` must render the parent block content.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying or extending block preservation and `super()` behavior tests.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_inheritance.py:135-146`
