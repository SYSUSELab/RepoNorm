# Rule details

- **Rule:** BlockReference.super must return an Undefined named 'super' with a 'there is no parent block called ...' message when depth+1 exceeds the stack, otherwise a BlockReference at depth+1, so super degrades to Undefined at the top block.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when changing BlockReference.super or the parent-block resolution stack behavior
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
BlockReference.super returns an Undefined named 'super' with the no-parent-block message when depth+1 exceeds the stack, otherwise a BlockReference at depth+1.
```

- **Sources:**
  - `src/jinja2/runtime.py:355-361`
