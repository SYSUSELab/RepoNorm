# Rule details

- **Rule:**
  ```text
  Tests that exercise async rendering with a synchronous helper must preserve the documented behavior: a plain synchronous helper (e.g., `normal_func` returning 23) can be used as a non-async callable within async test scenarios.
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying or adding tests that use synchronous helpers within async rendering scenarios.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async.py:28-41`
