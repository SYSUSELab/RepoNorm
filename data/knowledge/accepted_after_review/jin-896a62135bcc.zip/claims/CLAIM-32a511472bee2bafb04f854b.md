# Rule details

- **Rule:** Jinja test semantics must treat booleans as numbers but not integers, large ints as integers but not floats, and only callables as callable, with specific truth values for strings, sequences, mappings, and iterables.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:** When modifying or extending parametrized Jinja test-type semantics assertions.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_tests.py:30-115`
