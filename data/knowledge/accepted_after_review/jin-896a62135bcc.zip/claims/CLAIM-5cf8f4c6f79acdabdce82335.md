# Rule details

- **Rule:**
  ```text
  Tests for the LRUCache utility must be grouped under a dedicated TestLRUCache class in tests/test_utils.py, providing focused coverage of LRUCache behavior.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for the LRUCache utility.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:18-38`
