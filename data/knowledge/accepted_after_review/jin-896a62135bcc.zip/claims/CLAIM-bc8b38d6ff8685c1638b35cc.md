# Rule details

- **Rule:**
  ```text
  UndeclaredNameVisitor.visit_Block must stop block visiting and not recurse into block body nodes.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying UndeclaredNameVisitor.visit_Block or block-body traversal in the compiler.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:271-290`
