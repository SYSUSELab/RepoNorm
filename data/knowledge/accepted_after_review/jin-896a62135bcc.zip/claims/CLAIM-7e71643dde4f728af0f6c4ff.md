# Rule details

- **Rule:** Tests for the map filter's default argument must assert that the default is applied only when the attribute is missing, and that an existing attribute with value None is preserved as None.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the map filter's default argument behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:683-704`
