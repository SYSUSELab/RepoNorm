# Rule details

- **Rule:** Extension.preprocess is the pre-lexing hook that receives source, name, and optional filename and must return the preprocessed source, defaulting to identity.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** when changing Extension.preprocess or the pre-lexing extension hook contract
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/ext.py:98-105`
