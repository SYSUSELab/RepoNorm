# Rule details

- **Rule:** Tests for the urlize filter's rel policy must assert that setting urlize.rel to None causes urlize to emit an anchor without a rel attribute.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** when adding or modifying tests for the urlize filter's rel policy
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:364-370`
