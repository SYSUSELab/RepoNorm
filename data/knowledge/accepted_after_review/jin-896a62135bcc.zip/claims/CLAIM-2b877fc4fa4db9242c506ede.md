# Rule details

- **Rule:** Use Black to format code; Black and other tools run automatically if pre-commit is installed using the instructions below.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Use `Black`_ to format your code. This and other tools will run
    automatically if you install `pre-commit`_ using the instructions
    below.

```

- **Sources:**
  - `CONTRIBUTING.rst:54-56`

## Review evidence locations

- `CONTRIBUTING.rst:52-56`
