# Rule details

- **Rule:** When modifying MemcachedBytecodeCache, preserve that bytecode is stored under the key prefix 'jinja2/bytecode/' combined with the bucket key.
- **Applies to:**
  - `tests/test_bytecode_cache.py`
- **Condition:** Changing MemcachedBytecodeCache key construction or prefix.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/bccache.py:332-346`
