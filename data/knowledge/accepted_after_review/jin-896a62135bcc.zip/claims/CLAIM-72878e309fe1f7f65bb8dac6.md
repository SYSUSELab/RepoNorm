# Rule details

- **Rule:** Tests for the trim filter must assert character-set semantics: chars=None trims whitespace, a specific chars value trims only those characters, and a combined set trims all specified characters.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying tests for the trim filter's chars parameter.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:86-92`
