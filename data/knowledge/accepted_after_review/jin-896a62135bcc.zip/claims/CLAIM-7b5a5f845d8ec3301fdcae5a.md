# Rule details

- **Rule:**
  ```text
  When modifying the runtime loop-rendering interface, `LoopRenderFunc` must remain declared as a `te.Protocol` defining the callable interface for loop rendering used by the runtime.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** Changing the runtime loop-rendering callable interface or its Protocol declaration.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/runtime.py:29-41`
