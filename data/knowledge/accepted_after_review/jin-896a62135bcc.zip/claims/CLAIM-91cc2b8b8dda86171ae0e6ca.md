# Rule details

- **Rule:**
  ```text
  The select_autoescape function must match extensions case-insensitively and normalize leading dots, enabling autoescape for 'foo.html' and 'FOO.HTML', disabling it for 'foo.txt' and 'FOO.TXT', using the default for unknown extensions, and using default_for_string for None.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When modifying or adding tests for select_autoescape extension matching and default behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/utils.py:599-621`
