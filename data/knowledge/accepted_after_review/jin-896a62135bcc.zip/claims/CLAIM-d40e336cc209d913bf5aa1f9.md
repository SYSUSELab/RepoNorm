# Rule details

- **Rule:** Environment instances may be modified only if they are not shared and no template has been loaded; modifications after the first template load lead to surprising effects and undefined behavior.
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** When modifying Environment configuration or adding mutable state that could be changed after template loading.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:142-148`
