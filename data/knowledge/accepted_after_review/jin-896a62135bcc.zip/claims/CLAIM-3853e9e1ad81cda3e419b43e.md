# Rule details

- **Rule:** When modifying the LRUCache, preserve that clear acquires the write lock before clearing both the mapping and the queue, so cache clearing is synchronized with concurrent access.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when changing LRUCache.clear or its locking behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/utils.py:480-484`
