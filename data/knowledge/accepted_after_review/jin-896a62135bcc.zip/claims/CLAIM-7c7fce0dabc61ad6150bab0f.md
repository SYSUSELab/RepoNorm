# Rule details

- **Rule:**
  ```text
  When classifying how a symbol is loaded, use the VAR_LOAD_* constants (param, resolve, alias, undefined) as the resolution protocol.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** Modifying symbol load classification or adding new load kinds in idtracking.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/idtracking.py:6-9`
- `src/jinja2/compiler.py:584-590`
