# Rule details

- **Rule:**
  ```text
  The AsyncLoopContext class must subclass LoopContext and declare _iterator as an AsyncIterator, establishing the async iteration variant of loop context.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when modifying AsyncLoopContext or adding async iteration variants
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/runtime.py:584-591`
