# Rule details

- **Rule:** The package root directory is src, so importable packages live under src/.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
package_dir = = src

```

- **Sources:**
  - `setup.cfg:34`

## Review evidence locations

- `setup.cfg:32-40`
