# Rule details

- **Rule:**
  ```text
  Indentation uses spaces (indent_style = space).
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
indent_style = space

```

- **Sources:**
  - `.editorconfig:4`

## Review evidence locations

- `.editorconfig:1-5`
