# Rule details

- **Rule:**
  ```text
  Tuple.can_assign must return True only if every item can be assigned, making assignment validity conjunctive across all items.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  Modifying Tuple.can_assign or assignment-validity logic for tuple/list nodes.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/nodes.py:627-639`
