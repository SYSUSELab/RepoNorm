# Rule details

- **Rule:** mypy is configured to warn about redundant casts.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
warn_redundant_casts = True

```

- **Sources:**
  - `setup.cfg:99`

## Review evidence locations

- `setup.cfg:87-99`
