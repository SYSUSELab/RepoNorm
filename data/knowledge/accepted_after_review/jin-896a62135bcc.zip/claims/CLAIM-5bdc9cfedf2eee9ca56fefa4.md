# Rule details

- **Rule:**
  ```text
  The `test_num_used_twice` test must assert that a pluralized trans block referencing the count variable twice renders the correct German plural form.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When modifying or extending internationalization pluralization tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:555-557`
