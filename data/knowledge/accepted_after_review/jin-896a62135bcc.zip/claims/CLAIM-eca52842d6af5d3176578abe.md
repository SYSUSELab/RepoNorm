# Rule details

- **Rule:** The false test must use identity comparison (value is False) so only the singleton False passes, not other falsy values.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** When modifying or adding built-in test functions in jinja2.tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/tests.py:104-109`
- `tests/test_tests.py:45-49`
