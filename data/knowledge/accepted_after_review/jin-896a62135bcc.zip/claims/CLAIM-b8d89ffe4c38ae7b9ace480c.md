# Rule details

- **Rule:** A test exercises chainable undefined async iteration, running an async test via asyncio.run.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When modifying async undefined iteration behavior or its tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_async.py:611-621`
