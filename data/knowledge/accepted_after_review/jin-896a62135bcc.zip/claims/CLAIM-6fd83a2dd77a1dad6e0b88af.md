# Rule details

- **Rule:**
  ```text
  When modifying Environment.compile, preserve that the name argument is the load name after join_path (not the filesystem filename), that raw=True returns generated Python source instead of a code object, and that defer_init allows generated module code to import without the global environment set.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when changing Environment.compile signature or its name/raw/defer_init handling
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/environment.py:727-756`
