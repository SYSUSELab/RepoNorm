# Rule details

- **Rule:**
  ```text
  Running `make help` in docs/ invokes `$(SPHINXBUILD) -M help "$(SOURCEDIR)" "$(BUILDDIR)" $(SPHINXOPTS) $(O)` to display Sphinx build help.
  ```
- **Applies to:**
  - `docs/**`
- **Condition:** command target: help
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
help:
	@$(SPHINXBUILD) -M help "$(SOURCEDIR)" "$(BUILDDIR)" $(SPHINXOPTS) $(O)

```

- **Sources:**
  - `docs/Makefile:11-12`

## Review evidence locations

- `docs/Makefile:10-12`
