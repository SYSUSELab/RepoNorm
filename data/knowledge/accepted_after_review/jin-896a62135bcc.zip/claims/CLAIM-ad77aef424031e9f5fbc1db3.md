# Rule details

- **Rule:** Tests for recursive loop semantics must assert that loop.previtem/loop.nextitem are undefined at the boundaries of a recursive loop, rendering the fallback value when the neighbor is not defined.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying tests for recursive loop neighbor variables.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_core_tags.py:128-145`
