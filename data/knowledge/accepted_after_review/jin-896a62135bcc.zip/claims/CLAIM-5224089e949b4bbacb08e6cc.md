# Rule details

- **Rule:**
  ```text
  The Tests workflow runs on pushes to the main branch and branches matching '*.x', ignoring changes under docs/** and to *.md and *.rst files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  push:
    branches:
      - main
      - '*.x'
    paths-ignore:
      - 'docs/**'
      - '*.md'
      - '*.rst'

```

- **Sources:**
  - `.github/workflows/tests.yaml:3-10`

## Review evidence locations

- `.github/workflows/tests.yaml:3-10`
