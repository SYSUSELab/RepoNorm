# Rule details

- **Rule:**
  ```text
  Tests that exercise Jinja filter behavior must preserve the documented filter semantics: `sum` accepts a string attribute argument (including dotted paths like 'real.value') and sums that attribute across items; `groupby` accepts dotted attribute paths like 'date.year'; `rejectattr` combined with `map(attribute=...)` and `join` filters by attribute; and `indent` preserves behavior when the input is a Markup instance.
  ```
- **Applies to:**
  - `tests/test_async_filters.py`
  - `tests/test_filters.py`
- **Condition:** When modifying or adding tests for the sum, groupby, rejectattr, or indent filters, including their attribute-path and Markup-input variants.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:414-428`
- `tests/test_filters.py:575-590`
- `tests/test_filters.py:739-750`
- `tests/test_filters.py:182-186`
