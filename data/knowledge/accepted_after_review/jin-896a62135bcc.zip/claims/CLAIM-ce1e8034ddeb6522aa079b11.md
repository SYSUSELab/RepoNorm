# Rule details

- **Rule:**
  ```text
  When modifying compiler output emission, `_output_child_post` must write the closing parenthesis and, when `finalize.src` is not None, write an additional closing parenthesis so finalized output expressions remain wrapped in extra parentheses.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Changing how the compiler emits closing parentheses for child expressions, especially finalized ones.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/compiler.py:1468-1477`
