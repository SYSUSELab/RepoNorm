# Rule details

- **Rule:** Tests for extension parse methods must assert that an extension parse method can emit an Output node calling a method with environment attributes, imported names, and a context reference node, and sets the node line number from the next stream token.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for extension parse method output nodes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_ext.py:148-166`
