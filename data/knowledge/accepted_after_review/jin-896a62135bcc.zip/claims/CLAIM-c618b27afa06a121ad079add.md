# Rule details

- **Rule:** The pprint filter output must match Python's pformat for both ASCII and non-ASCII strings, pinning the filter's formatting behavior.
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When modifying the pprint filter or its tests, including byte-fallback handling for non-ASCII input.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_filters.py:254-259`
- `tests/test_lexnparse.py:99-103`
