# Rule details

- **Rule:** FileSystemLoader must accept a pathlib-style searchpath and work with the common loader test helper.
- **Applies to:**
  - `tests/test_loader.py`
- **Condition:** When modifying FileSystemLoader searchpath handling or its tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_loader.py:120-140`
