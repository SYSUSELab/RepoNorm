# Rule details

- **Rule:** When a template uses {% set %} with a non-constant value, the compiler must mark the eval context volatile so the generated code re-evaluates the context at runtime; constant values may be folded at compile time.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Modifying EvalContextModifier compilation or eval-context constant folding in the code generator.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
visit_EvalContextModifier writes option assignments and sets frame.eval_ctx.volatile=True when the value is not a compile-time constant, otherwise setattr's the constant onto the eval context, matching the rule.
```

- **Sources:**
  - `src/jinja2/compiler.py:1934-1945`
