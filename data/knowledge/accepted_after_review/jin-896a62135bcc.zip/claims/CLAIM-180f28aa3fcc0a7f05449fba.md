# Rule details

- **Rule:**
  ```text
  A `{% set %}` inside a for loop must not leak to the outer scope; after the loop, the outer variable retains its original value.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending tests for `{% set %}` scoping inside for loops.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:564-570`
