# Rule details

- **Rule:**
  ```text
  SandboxedEnvironment.format_string must route formatting through SandboxedFormatter (or SandboxedEscapeFormatter for Markup), require exactly one positional argument and no kwargs for format_map, and return type(s)(rv) to preserve the input string type.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying format_string or adding sandboxed string formatting behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/sandbox.py:348-375`
