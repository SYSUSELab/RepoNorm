# Rule details

- **Rule:** filesizeformat renders decimal units by default and binary units when passed true, fixing the exact output format for each unit.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When modifying the filesizeformat filter or its expected output format.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/filters.py:633-643`
- `tests/test_filters.py:103-120`
