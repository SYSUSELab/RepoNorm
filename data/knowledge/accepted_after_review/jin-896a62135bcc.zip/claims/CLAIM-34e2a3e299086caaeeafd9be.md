# Rule details

- **Rule:** mypy is configured to enable local partial types.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
local_partial_types = True

```

- **Sources:**
  - `setup.cfg:96`

## Review evidence locations

- `setup.cfg:87-96`
