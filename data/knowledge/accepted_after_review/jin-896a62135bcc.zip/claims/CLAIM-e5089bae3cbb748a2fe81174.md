# Rule details

- **Rule:**
  ```text
  Running `make <target>` in docs/ invokes Sphinx via `$(SPHINXBUILD) -M <target> "$(SOURCEDIR)" "$(BUILDDIR)" $(SPHINXOPTS) $(O)`, forwarding the target name as the Sphinx builder.
  ```
- **Applies to:**
  - `docs/**`
- **Condition:** command target: %
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
%: Makefile
	@$(SPHINXBUILD) -M $@ "$(SOURCEDIR)" "$(BUILDDIR)" $(SPHINXOPTS) $(O)

```

- **Sources:**
  - `docs/Makefile:18-19`

## Review evidence locations

- `docs/Makefile:16-19`
