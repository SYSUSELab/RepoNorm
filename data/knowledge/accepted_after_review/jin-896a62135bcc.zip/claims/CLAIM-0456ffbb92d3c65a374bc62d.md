# Rule details

- **Rule:**
  ```text
  Run `coverage run -m pytest` to execute the test suite under coverage.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    $ coverage run -m pytest

```

- **Sources:**
  - `CONTRIBUTING.rst:202`

## Review evidence locations

- `CONTRIBUTING.rst:192-203`
