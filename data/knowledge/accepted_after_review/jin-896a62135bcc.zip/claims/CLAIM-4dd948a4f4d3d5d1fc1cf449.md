# Rule details

- **Rule:**
  ```text
  flake8 per-file-ignores exempts src/jinja2/__init__.py from F401.
  ```
- **Applies to:**
  - `src/jinja2/__init__.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
per-file-ignores =
    # __init__ module exports names
    src/jinja2/__init__.py: F401

```

- **Sources:**
  - `setup.cfg:83-85`
