# Rule details

- **Rule:**
  ```text
  Tests in tests/test_lexnparse.py that pin parser balancing must preserve the behavior that a dict literal followed by attribute access, e.g. {{ {'foo':'bar'}.foo }}, renders 'bar', covering brace balancing and attribute access.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying or extending parser balancing tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_lexnparse.py:219-221`
