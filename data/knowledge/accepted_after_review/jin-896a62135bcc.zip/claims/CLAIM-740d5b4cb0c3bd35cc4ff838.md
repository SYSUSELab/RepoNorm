# Rule details

- **Rule:** The sameas template test must use identity comparison (value is other) rather than equality, so that it correctly distinguishes the False singleton and other identity-sensitive values.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** when modifying or adding the sameas test in the template test registry
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/tests.py:179-189`
