# Rule details

- **Rule:** The float test must use isinstance(value, float) as its exact type check.
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:** When modifying or adding built-in test functions in jinja2.tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/jinja2/tests.py:130-135`
