# Constraints for `pyproject.toml`

## Rule

- **Rule:**
  ```text
  The build-and-publish-test-pypi job rewrites the package name in pyproject.toml after the #replace_package_name_marker line to "dspy-ai-test".
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-405eb148063a22c36584dfd2.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-test-pypi job rewrites the version in pyproject.toml after the #replace_package_version_marker line using the computed version.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7e083404b5d3d47d76c6e128.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-pypi job rewrites the package name in pyproject.toml after the #replace_package_name_marker line to "dspy".
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-927e3859199237b20ff56c1e.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-pypi job rewrites the version in pyproject.toml after the #replace_package_version_marker line using the extracted tag version.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bc212bb3bc2f007b16f8567e.md)
