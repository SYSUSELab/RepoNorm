# Constraints for `.github/workflows/precommits_check.yml`

## Rule

- **Rule:** The workflow sets up Python version 3.10 with pip caching.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-271af6ba139ae4cf06c6b0d2.md)

## Rule

- **Rule:**
  ```text
  The Pre-commit checks workflow is triggered only by manual workflow_dispatch.
  ```
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Condition:**
  ```text
  workflow predicate: workflow_dispatch:
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3a438fe847fdf72ae3ebeaab.md)

## Rule

- **Rule:** The Pre-Commit Checks step installs pre-commit and runs 'pre-commit run -v --files' against the changed files.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4655559d401d7d8e9e69546a.md)

## Rule

- **Rule:**
  ```text
  Pull request titles are checked against the regexp '(break|build|ci|docs|feat|fix|perf|refactor|style|test|ops|hotfix|release|maint|init|enh|revert)\([a-z,A-Z,0-9,\-,\_,\/,:]+\)(:)\s{1}([\w\s]+)'.
  ```
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9d23a9fa455b966e5a2ecdd0.md)

## Rule

- **Rule:** The changed files list is obtained via the jitterbit/get-changed-files action and exposed as steps.files.outputs.all.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aafadcfbd987c0ebf7c2fd94.md)

## Rule

- **Rule:** The pre-commit-checks job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b5e93568c3a11842cfd205d9.md)
