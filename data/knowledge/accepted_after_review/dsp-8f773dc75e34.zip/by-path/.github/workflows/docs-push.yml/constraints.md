# Constraints for `.github/workflows/docs-push.yml`

## Rule

- **Rule:**
  ```text
  The update-docs-subtree job runs only on push events to the stanfordnlp/dspy repository, and it pushes the docs directory to the dspy-docs repository on the master branch using the GH_PAT secret.
  ```
- **Applies to:**
  - `.github/workflows/docs-push.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push' && github.repository == 'stanfordnlp/dspy'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-20162444fdf9039da9b696d9.md)

## Rule

- **Rule:**
  ```text
  The build-test job runs only when the event is a pull_request, and it checks out the code, sets up Node.js version 18, then runs cd docs, pip install -r requirements.txt, and mkdocs build.
  ```
- **Applies to:**
  - `.github/workflows/docs-push.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'pull_request'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-adec0be2a0de531e10b95554.md)
