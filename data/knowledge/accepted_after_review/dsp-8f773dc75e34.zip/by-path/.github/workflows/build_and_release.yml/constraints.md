# Constraints for `.github/workflows/build_and_release.yml`

## Rule

- **Rule:** The build-and-publish-test-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-22a655b249c8c042c7ee59d0.md)

## Rule

- **Rule:**
  ```text
  The workflow runs on pushes of tags matching "*", triggering the extract-tag, build-and-publish-test-pypi, and build-and-publish-pypi jobs.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Condition:**
  ```text
  workflow predicate: push: tags: - "*"
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-279c2d3a72aa44fa9f656ea1.md)

## Rule

- **Rule:** The build-and-publish-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-38ae78fc4afbc7813790c4f1.md)

## Rule

- **Rule:** The build-and-publish-pypi job runs on ubuntu-latest and uses the pypi environment with id-token: write and contents: write permissions.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-54eb7bce2fe0ed0832aa3507.md)

## Rule

- **Rule:** The build-and-publish-test-pypi job publishes the distribution to TestPyPI using pypa/gh-action-pypi-publish@release/v1 with repository-url https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8139cef589b1d303b6c1f06a.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-pypi job runs only when github.repository_owner == 'stanfordnlp', and depends on extract-tag and build-and-publish-test-pypi.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Condition:**
  ```text
  workflow predicate: github.repository_owner == 'stanfordnlp'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-96f8ca859688a2a842d01f3d.md)

## Rule

- **Rule:**
  ```text
  The extract-tag job runs on ubuntu-latest and extracts the tag name from GITHUB_REF into the job output `version`.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-99dd382c9962fe41b708530c.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-test-pypi job builds a binary wheel with `python3 -m build`.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a0ba026844e6ebec33d6a4ae.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-test-pypi job computes the TestPyPI version by running .github/workflows/build_utils/test_version.py with package name "dspy-ai-test" and the extracted tag version.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d4d840e6ab116a13d04eaff8.md)

## Rule

- **Rule:** The build-and-publish-pypi job installs setuptools, wheel, twine, and build via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dd97bea9a6a2eef9c11c0691.md)

## Rule

- **Rule:** The build-and-publish-test-pypi job installs setuptools, wheel, twine, build, semver, and packaging via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ea9c4aa12e32c45e4cc53faf.md)

## Rule

- **Rule:** The build-and-publish-test-pypi job depends on extract-tag, runs on ubuntu-latest, and uses the pypi environment with id-token: write and contents: write permissions.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fa5707353832fd5fc9d1b9c1.md)
