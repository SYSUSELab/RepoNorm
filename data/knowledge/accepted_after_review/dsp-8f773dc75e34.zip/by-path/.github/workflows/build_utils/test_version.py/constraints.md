# Constraints for `.github/workflows/build_utils/test_version.py`

## Rule

- **Rule:** The version-bumping utility must be invoked with exactly two CLI arguments (package name and tag version); any other argument count must raise ValueError, and the computed new version must be printed to stdout.
- **Applies to:**
  - `.github/workflows/build_utils/test_version.py`
- **Condition:** When modifying the argument handling or output behavior of the version-bumping utility.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2261159ad5c580cb99a16f69.md)

## Rule

- **Rule:**
  ```text
  increment_version must parse the current version with PyPIVersion, and when a pre-release component exists, reconstruct a semver.Version from release plus the joined pre tuple before calling bump_prerelease.
  ```
- **Applies to:**
  - `.github/workflows/build_utils/test_version.py`
- **Condition:** When modifying the version-bump logic that handles pre-release components.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-c3aaf21218c99a021dcec7a7.md)
