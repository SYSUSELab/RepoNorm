# Constraints for `.github`

## Rule

- **Rule:** Pushing a semver tag triggers the GitHub Action that extracts the tag as the version.
- **Applies to:**
  - `.github/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3ec770c9ec9d4d3fcbd8d093.md)
