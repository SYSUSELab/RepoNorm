# Constraints for `dspy/propose/grounded_proposer.py`

## Rule

- **Rule:**
  ```text
  When changing dspy/propose/grounded_proposer.py generate_instruction_class, preserve the boolean toggles (use_dataset_summary, program_aware, use_task_demos, use_instruct_history, use_tip) and the return of a dspy.Predict over GenerateSingleModuleInstruction, which define the configurable inputs to grounded instruction generation.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:**
  ```text
  Modifying generate_instruction_class' configuration toggles or its returned Predict.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-288e1709287e28b8f8fc2e09.md)

## Rule

- **Rule:**
  ```text
  DescribeModule must remain a dspy.Signature with input fields program_code, program_example, program_description, module and output field module_description, each carrying explicit prefixes that structure the proposer prompt.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:** When modifying DescribeModule fields or their prefixes used by the proposer prompt.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3ac2f109db1cf6f5aa5f5267.md)

## Rule

- **Rule:**
  ```text
  When changing dspy/propose/grounded_proposer.py gather_examples_from_sets, preserve the filter that only yields candidate examples containing an 'augmented' key, since augmented-example generation depends on that key being present.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:**
  ```text
  Modifying gather_examples_from_sets' example filtering or augmented-example selection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a8b6ecfe74bc191c972bf75a.md)

## Rule

- **Rule:**
  ```text
  When modifying the GenerateSingleModuleInstruction signature in dspy/propose/grounded_proposer.py, gate InputFields consistently with the constructor flags use_dataset_summary, program_aware, use_instruct_history, and use_tip so the prompt schema varies per configuration as intended.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:** When adding or changing InputFields on GenerateSingleModuleInstruction or its constructor flags.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af73a111b355ed4ec5e023ee.md)
