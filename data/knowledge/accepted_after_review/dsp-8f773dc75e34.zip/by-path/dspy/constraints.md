# Constraints for `dspy`

## Rule

- **Rule:** Setuptools package discovery includes the dspy package and its subpackages.
- **Applies to:**
  - `dspy/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5046935612992f8ce4fca928.md)

## Rule

- **Rule:** Ruff indent-width is set to 4.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-830fc670d804318dce145cd0.md)

## Rule

- **Rule:** Ruff linting/formatting applies to Python files under dspy/ and tests/ as included by the include setting.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8876e3c28ccb3249fe435f00.md)

## Rule

- **Rule:** Ruff target-version is py310.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-d276e70dfd38da0229f94aec.md)

## Rule

- **Rule:** Ruff line-length is set to 120.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-dde087539e0518475f99700a.md)
