# Constraints for `dspy/__metadata__.py`

## Rule

- **Rule:**
  ```text
  The build-and-publish-pypi job rewrites __version__ in ./dspy/__metadata__.py after the #replace_package_version_marker line using the extracted tag version.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-01dc8d3cd21b9a57b9dbbc1e.md)

## Rule

- **Rule:**
  ```text
  The ruff-check hook excludes dspy/__metadata__.py and files under tests/reliability/ from its file selection.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c56263aef12dcf17a9b908b.md)

## Rule

- **Rule:**
  ```text
  The build-and-publish-pypi job rewrites __name__ in ./dspy/__metadata__.py after the #replace_package_name_marker line to "dspy".
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-961b31d3c3aefe074b089e0a.md)

## Rule

- **Rule:**
  ```text
  Ruff excludes dspy/__metadata__.py and tests/reliability/*.py from its checks.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df1497a7451cab7de547a4ca.md)
