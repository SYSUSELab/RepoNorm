# Constraints for `dspy/signatures/signature.py`

## Rule

- **Rule:**
  ```text
  infer_prefix must convert attribute names to human-readable prefixes, preserving all-uppercase acronyms like HTML/API while title-casing other words and inserting underscores around digits; changes must preserve this acronym and digit handling.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When modifying infer_prefix or the attribute-name-to-prefix conversion it performs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-271636bbc35a10e488e7b3ac.md)

## Rule

- **Rule:**
  ```text
  The Signature class supports three construction forms: subclassing with InputField/OutputField, calling Signature('input -> output'), and passing instructions as a second argument, with make_signature and ensure_signature recommended for programmatic use.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:** When modifying the Signature class or adding new signature construction forms in the signatures layer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bd5d679ceb8328db4cb78c61.md)
