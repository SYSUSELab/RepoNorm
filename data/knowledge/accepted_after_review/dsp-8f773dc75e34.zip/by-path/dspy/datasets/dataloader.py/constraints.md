# Constraints for `dspy/datasets/dataloader.py`

## Rule

- **Rule:**
  ```text
  When changing dspy/datasets/dataloader.py from_csv, preserve the loading convention: load via the HuggingFace datasets 'csv' loader, derive fields from dataset.features when fields is None, and convert each row to a dspy.Example with with_inputs(*input_keys) applied.
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  Modifying from_csv's CSV loading, field derivation, or Example construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-204ae81a2395faf54c29a4e8.md)

## Rule

- **Rule:**
  ```text
  train_test_split must validate train_size/test_size as either a float proportion in (0,1) or an int absolute count, raising ValueError otherwise; when test_size is omitted it is derived as the remainder, and train_size+test_size exceeding the dataset length is rejected.
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  When modifying DataLoader.train_test_split, preserve the float/int size validation, ValueError on invalid types, remainder derivation when test_size is omitted, and rejection of sizes exceeding dataset length.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bc8f354673b0d0b87ca2aa9f.md)

## Rule

- **Rule:**
  ```text
  DataLoader.from_parquet must load the parquet file as the 'train' split, default the field list to all dataset features when none are supplied, and wrap each row in dspy.Example.with_inputs(*input_keys).
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  When modifying DataLoader.from_parquet or its parquet-loading helpers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d31c0c9f6b435e6b1be66dae.md)
