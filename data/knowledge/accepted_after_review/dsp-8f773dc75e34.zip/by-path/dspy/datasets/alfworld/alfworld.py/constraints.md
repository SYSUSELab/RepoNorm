# Constraints for `dspy/datasets/alfworld/alfworld.py`

## Rule

- **Rule:**
  ```text
  EnvPool must be used as a pool of processes each with a unique env_worker, acquired via a context manager session; callers must use 'with pool.session() as sess' and then call init/step on the session rather than on the pool directly.
  ```
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** When modifying EnvPool or any caller that acquires and uses an environment session.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-5a3c464ffd65395f7e16105c.md)

## Rule

- **Rule:**
  ```text
  _EnvSession.__init__ must store an EnvPool and initialize wid, inq, and outq to None, deferring per-environment worker state acquisition until later.
  ```
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:**
  ```text
  When modifying _EnvSession construction or AlfWorld environment setup, preserve storing the EnvPool and initializing wid, inq, and outq to None rather than acquiring worker state at construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-61ae42a7f3b9530ed638bb16.md)

## Rule

- **Rule:** AlfWorld step(action) must communicate via queues: it puts ("step", action) on self.inq and returns self.outq.get(), defining the request/response protocol for environment stepping; changes must preserve this queue-based protocol.
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:**
  ```text
  When modifying _EnvSession.step or the queue-based communication between the session and its worker process.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-a3a89987029c5caf68de408c.md)
