# Constraints for `dspy/datasets/math.py`

## Rule

- **Rule:**
  ```text
  MATH.metric must require the external math_equivalence package and raise an ImportError with the install command when it is missing; changes must preserve this optional-dependency guard and its actionable error message.
  ```
- **Applies to:**
  - `dspy/datasets/math.py`
- **Condition:**
  ```text
  When modifying MATH.metric or its dependency handling for the math_equivalence package.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cde748d043912216fdd574fb.md)

## Rule

- **Rule:** The MATH dataset loader must load DigitalLearningGmbH/MATH-lighteval and sub-split the 'test' split into train/dev/test with size min(350, len//3) after a fixed random.Random(0) shuffle, because LMs are presumed trained on MATH's train split.
- **Applies to:**
  - `dspy/datasets/math.py`
- **Condition:** When modifying the MATH dataset loader split sizes, source dataset, or shuffle seed.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d5caf7e002da5f2c14ad7344.md)
