# Constraints for `dspy/streaming/messages.py`

## Rule

- **Rule:**
  ```text
  StreamResponse must be a dataclass carrying predict_name, signature_field_name, chunk, and is_last_chunk, defining the per-chunk streaming protocol consumers must handle.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:** When modifying StreamResponse or the per-chunk streaming message protocol.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2504625249bee0f72f7ae4f4.md)

## Rule

- **Rule:**
  ```text
  sync_send_to_stream._send must await stream.send(message), using an async send protocol to push messages onto a stream.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  When modifying sync_send_to_stream._send or its async send protocol.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-62f036eeef35c7ff9b053c82.md)
