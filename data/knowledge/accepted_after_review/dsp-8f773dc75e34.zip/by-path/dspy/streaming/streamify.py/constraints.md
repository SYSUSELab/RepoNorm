# Constraints for `dspy/streaming/streamify.py`

## Rule

- **Rule:**
  ```text
  streamify must wrap a program to stream outputs, accept status_message_provider, stream_listeners, include_final_prediction_in_output_stream, is_async_program, and async_streaming, append a StatusStreamingCallback if absent, and return an async or sync streamer depending on async_streaming; changes must preserve these parameters and the callback/streamer selection behavior.
  ```
- **Applies to:**
  - `dspy/streaming/streamify.py`
- **Condition:** When modifying streamify or its parameter handling and streamer selection.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0167cfe3779f0e823228f251.md)

## Rule

- **Rule:** The streamify producer must run in a background thread and execute the async runner via context.run(asyncio.run, runner()), propagating the captured context into the thread's event loop.
- **Applies to:**
  - `dspy/streaming/streamify.py`
- **Condition:** When modifying streamify producer threading or context propagation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-570f1b5cdee3edc20b589bd6.md)

## Rule

- **Rule:**
  ```text
  streaming_response must convert DSPy program output into OpenAI-compatible SSE chunks: Prediction values become data: {"prediction": ...}, litellm ModelResponseStream values become data: {"chunk": ...}, existing data: strings pass through, unknown types raise ValueError, and the stream terminates with data: [DONE].
  ```
- **Applies to:**
  - `dspy/streaming/streamify.py`
- **Condition:**
  ```text
  When modifying streaming_response or adding new output types to the streaming conversion path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6dad05e3df3c411f425a77ec.md)

## Rule

- **Rule:**
  ```text
  async_streamer must yield ModelResponseStream chunks directly when no listeners are configured, otherwise delegate each chunk to predict_id_to_listener listeners and yield the first truthy listener output; StatusMessage values are always yielded, and final Predictions are yielded only if include_final_prediction_in_output_stream or no listener has stream_start/cache_hit conditions.
  ```
- **Applies to:**
  - `dspy/streaming/streamify.py`
- **Condition:**
  ```text
  When modifying async_streamer or its listener delegation and final-prediction gating.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8c3174344a7468aa06fc207a.md)

## Rule

- **Rule:** When modifying the sync streaming bridge in dspy/streaming/streamify.py, preserve the Queue plus stop-sentinel protocol, the copying of contextvars into the producer thread, and the daemon-thread producer so async generators can be consumed synchronously without losing context or hanging.
- **Applies to:**
  - `dspy/streaming/streamify.py`
- **Condition:**
  ```text
  When changing apply_sync_streaming or the async-to-sync streaming bridge.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c2b65886d56dc9c6d7a2c648.md)
