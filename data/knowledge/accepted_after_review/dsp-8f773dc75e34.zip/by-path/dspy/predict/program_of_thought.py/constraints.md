# Constraints for `dspy/predict/program_of_thought.py`

## Rule

- **Rule:** ProgramOfThought constructs a PythonInterpreter by default when no interpreter is supplied, and this raises an exception if no available deno instance can be found.
- **Applies to:**
  - `dspy/predict/program_of_thought.py`
- **Condition:**
  ```text
  When modifying ProgramOfThought.__init__ or changing default interpreter construction in the predict layer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-085a1b5634c5d0237933bd70.md)
