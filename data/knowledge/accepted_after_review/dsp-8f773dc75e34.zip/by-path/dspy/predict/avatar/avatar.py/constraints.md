# Constraints for `dspy/predict/avatar/avatar.py`

## Rule

- **Rule:** The avatar predict module must import Action, ActionOutput, and Tool from dspy.predict.avatar.models and Actor from dspy.predict.avatar.signatures, establishing its dependency on those avatar-specific primitives.
- **Applies to:**
  - `dspy/predict/avatar/avatar.py`
- **Condition:** When modifying the avatar predict module's imports or its dependency on avatar-specific primitives.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-d2d6658e5168a808003c696f.md)
