# Constraints for `dspy/predict/avatar/__init__.py`

## Rule

- **Rule:**
  ```text
  The avatar package __init__ must re-export everything from the avatar, models, and signatures submodules via star imports; changes must preserve these re-exports so that the public avatar API remains available from the package root.
  ```
- **Applies to:**
  - `dspy/predict/avatar/__init__.py`
- **Condition:**
  ```text
  When modifying the avatar package __init__ or adding/removing submodule exports.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-cfca2592320ea4bef37b5c11.md)
