# Constraints for `dspy/predict/aggregation.py`

## Rule

- **Rule:**
  ```text
  When modifying default_normalize, preserve that it returns normalize_text(s) or None, so empty or falsy normalized text becomes None.
  ```
- **Applies to:**
  - `dspy/predict/aggregation.py`
- **Condition:** Changing normalization behavior for aggregation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d386a096325508ef329245cb.md)
