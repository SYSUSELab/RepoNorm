# Constraints for `dspy/dsp/colbertv2.py`

## Rule

- **Rule:**
  ```text
  ColBERTv2RetrieverLocal.__init__ must assert colbert_config, its checkpoint, and index_name are provided, build the index unless load_only is set, then load the index and store a searcher.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:**
  ```text
  When modifying ColBERTv2RetrieverLocal construction, preserve the required configuration assertions and the load_only-controlled index build/load sequence.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-40ac089951cc93ce9300897d.md)

## Rule

- **Rule:**
  ```text
  When delegating in ColBERTv2RetrieverLocal.__call__, the call must forward directly to self.forward with the same args and kwargs.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:** Modifying or extending the ColBERTv2RetrieverLocal call path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6247fd1529c598b79ed34657.md)

## Rule

- **Rule:**
  ```text
  ColBERTv2RetrieverLocal.get_index must attempt to import colbert and print an installation hint on ImportError, then import Searcher and Run/RunConfig and construct a Searcher within a Run context using the required RunConfig experiment/index/collection parameters.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:**
  ```text
  When modifying ColBERTv2RetrieverLocal.get_index or its colbert optional-dependency handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c2f2f498318844c9522a0a9e.md)

## Rule

- **Rule:**
  ```text
  ColBERTv2.__init__ must treat colbert as an optional dependency: on ImportError print an installation hint, and overwrite self.colbert_config.checkpoint with the constructor checkpoint argument.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:**
  ```text
  When modifying ColBERTv2.__init__ import handling or checkpoint configuration.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ff5f8685d6186f03f562918c.md)
