# Constraints for `dspy/dsp/utils/utils.py`

## Rule

- **Rule:**
  ```text
  timestamp(daydir=True) must produce a date-directory format using '/' separators, while daydir=False must use '-' and '_' separators, so callers relying on path layout must account for this branch.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:** When modifying timestamp formatting or callers that depend on its path layout.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-656b3dd191eba039653c7e7a.md)

## Rule

- **Rule:**
  ```text
  When changing dspy/dsp/utils/utils.py zip_first, preserve the assertion that when list1 is a tuple or list the zipped result length equals len(list1), raising an assertion error on length mismatch, while using zip(..., strict=False).
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:**
  ```text
  Modifying zip_first's length-checking or zip invocation behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-7bb6e96275954805aadfae92.md)

## Rule

- **Rule:**
  ```text
  load_batch_backgrounds must return None when args.qid2backgrounds is None, and for each qid distinguish integer background entries (indexing args.collection) from non-integer entries (using args.collectionX.get(pid, '')), joining with ' [SEP] '.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:** When modifying background loading or its integer/non-integer entry handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-7f5567c6d0ea23c38dbb1966.md)

## Rule

- **Rule:**
  ```text
  groupby_first_item groups list items by their first element and unwraps single-element rest lists to a scalar, defining the grouping utility's output shape.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:**
  ```text
  When modifying groupby_first_item or changing grouping utility output shape in the dsp utils layer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-e4c0adf55b17eda10ea0c991.md)
