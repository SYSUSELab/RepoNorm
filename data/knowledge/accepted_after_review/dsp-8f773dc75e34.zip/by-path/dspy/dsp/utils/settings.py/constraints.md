# Constraints for `dspy/dsp/utils/settings.py`

## Rule

- **Rule:**
  ```text
  Settings.__getitem__ must delegate to __getattr__ so item access and attribute access resolve the same configuration keys.
  ```
- **Applies to:**
  - `dspy/dsp/utils/settings.py`
- **Condition:**
  ```text
  When modifying Settings.__getitem__ or Settings attribute resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-0dd3d99700e31c7278294398.md)

## Rule

- **Rule:** When configuring dspy.settings, configure must be bound to the first calling thread and first async task, raising RuntimeError for configure from other threads or async tasks, with an IPython exception allowing reconfiguration in IPython environments.
- **Applies to:**
  - `dspy/dsp/utils/settings.py`
- **Condition:** Modifying or extending the settings configure guard in the settings module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-c263fa2f471a343b50f3180c.md)
