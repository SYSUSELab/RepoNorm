# Constraints for `dspy/dsp/utils/dpr.py`

## Rule

- **Rule:** The dpr utils module must retain its vendored DPR provenance and instantiate a module-level STokenizer = SimpleTokenizer().
- **Applies to:**
  - `dspy/dsp/utils/dpr.py`
- **Condition:** When modifying the dpr utils module or its tokenizer instantiation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-5ca1e1c6d02d956002b2130d.md)

## Rule

- **Rule:** The DPR tokenizer base class must define tokenize as raising NotImplementedError, marking it as an abstract extension point for tokenizer implementations.
- **Applies to:**
  - `dspy/dsp/utils/dpr.py`
- **Condition:** When modifying the DPR tokenizer base class or adding tokenizer implementations.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-61b5246ca8ab4c211bc7e0ed.md)

## Rule

- **Rule:** Tokens.pos must return None when 'pos' is absent from self.annotators, otherwise a list of POS tags extracted from each token's POS slot; callers must handle the None case.
- **Applies to:**
  - `dspy/dsp/utils/dpr.py`
- **Condition:** When modifying Tokens.pos or adding new annotation accessors on Tokens.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-a8800fb676082426105e78cd.md)

## Rule

- **Rule:**
  ```text
  locate_answers must tokenize the text and return character-level (offset, endpos) spans for each occurrence of each tokenized answer, using uncased word matching over sliding windows.
  ```
- **Applies to:**
  - `dspy/dsp/utils/dpr.py`
- **Condition:**
  ```text
  When modifying locate_answers or its answer-span matching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-c739ce14575a8ec0bc4555b1.md)

## Rule

- **Rule:**
  ```text
  SimpleTokenizer must define ALPHA_NUM as r'[\p{L}\p{N}\p{M}]+' and NON_WS as r'[^\p{Z}\p{C}]', using Unicode property classes for tokenization.
  ```
- **Applies to:**
  - `dspy/dsp/utils/dpr.py`
- **Condition:**
  ```text
  When modifying SimpleTokenizer's ALPHA_NUM or NON_WS regex patterns.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-f7cf678956bcec3c7289b913.md)
