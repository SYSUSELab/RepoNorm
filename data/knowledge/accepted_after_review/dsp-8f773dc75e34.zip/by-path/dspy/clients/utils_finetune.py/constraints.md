# Constraints for `dspy/clients/utils_finetune.py`

## Rule

- **Rule:** When validating a chat message dict for finetuning data, the dict must have exactly the keys role and content, role must be one of assistant/system/user, and content must be a str; otherwise a descriptive error string is returned.
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:** Modifying or extending chat-message validation for finetuning data.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1479b54894aafb206f660890.md)

## Rule

- **Rule:**
  ```text
  write_lines must serialize each item as a ujson.dumps line terminated by a newline, defining the JSONL convention used for finetune data and error logs; changes must preserve this line-oriented JSON serialization.
  ```
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:**
  ```text
  When modifying write_lines or any finetune data/error log writer that must remain JSONL-compatible.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-14f861550d018b7bcb3aeabc.md)

## Rule

- **Rule:** When inferring the finetuning data format, only dspy.ChatAdapter is supported; any other adapter must raise ValueError.
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:** Modifying or extending the adapter support in finetuning data-format inference.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-17e0e045522dd4fa550433cb.md)

## Rule

- **Rule:**
  ```text
  validate_data_format must assert data_format is CHAT or COMPLETION, raise ValueError if data is not a list, collect per-index errors from the format-specific finder, and on any errors write them to data_format_errors.log under the finetune directory before raising ValueError referencing that log path.
  ```
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:**
  ```text
  When modifying validate_data_format or adding finetune data-format validation in the clients layer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-211e0552e9e14ca68a7e9434.md)

## Rule

- **Rule:** The finetune utilities must define a Message TypedDict whose role is constrained to the literals 'user', 'assistant', or 'system' and whose content is a string, establishing the canonical chat message shape used by finetune data preparation.
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:** When modifying finetune data preparation or the Message TypedDict shape.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-52d014428f0d650ed6975690.md)

## Rule

- **Rule:**
  ```text
  When modifying get_finetune_directory, preserve resolution order: honor DSPY_FINETUNEDIR, fall back to a default under DSPY_CACHEDIR, and always create the directory before returning an absolute path.
  ```
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:** Changing finetune directory resolution or creation behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b2297d77edb02cfaacee7308.md)
