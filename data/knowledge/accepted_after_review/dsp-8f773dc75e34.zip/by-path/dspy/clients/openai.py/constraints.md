# Constraints for `dspy/clients/openai.py`

## Rule

- **Rule:**
  ```text
  When modifying TrainingJobOpenAI.__init__, preserve per-client provider job/file tracking state by initializing provider_file_id and provider_job_id to None.
  ```
- **Applies to:**
  - `dspy/clients/openai.py`
- **Condition:** Changing OpenAI client initialization or provider job/file tracking state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-df119a7721ba135431450d55.md)

## Rule

- **Rule:**
  ```text
  The OpenAI provider must maintain an explicit _OPENAI_MODELS allowlist enumerating supported model identifiers as a compatibility boundary for model routing.
  ```
- **Applies to:**
  - `dspy/clients/openai.py`
- **Condition:** When modifying the OpenAI provider's model routing or supported-model list.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ef5665392dfe6dce66ff0618.md)
