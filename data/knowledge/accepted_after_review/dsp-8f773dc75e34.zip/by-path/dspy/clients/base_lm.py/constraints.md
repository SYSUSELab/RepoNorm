# Constraints for `dspy/clients/base_lm.py`

## Rule

- **Rule:**
  ```text
  base_lm.py must define MAX_HISTORY_SIZE = 10_000 and a module-level GLOBAL_HISTORY list so history is capped at a fixed size rather than growing unbounded.
  ```
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:**
  ```text
  When modifying history storage or size limits in base_lm.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-33c51685a4372cf0a4c30efd.md)

## Rule

- **Rule:** BaseLM.copy must deep-copy the LM, reset history to empty, and route kwargs to attributes when present or to the kwargs dict otherwise.
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:** When modifying BaseLM.copy or subclass copy behavior, preserve deep-copy semantics, empty history reset, and kwargs routing to attributes or kwargs dict.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4c2b5f5a0b0a028d2624e258.md)

## Rule

- **Rule:**
  ```text
  When modifying BaseLM.update_history, preserve the history-retention contract: skip updates when settings.disable_history is set, cap GLOBAL_HISTORY at MAX_HISTORY_SIZE by dropping the oldest entry, update only global history when settings.max_history_size is 0, and otherwise cap self.history and each caller module's history at settings.max_history_size.
  ```
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:**
  ```text
  Changing history retention, capping, or disable-history behavior in BaseLM.update_history.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-58122581eb84e6ebd5fbc532.md)

## Rule

- **Rule:**
  ```text
  _process_lm_response must collapse outputs to plain strings only when every output dict has exactly one key (text); otherwise return dicts that may include logprobs and tool_calls, strip api_* kwargs before history logging, and record cost from response._hidden_params.
  ```
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:**
  ```text
  When modifying _process_lm_response or LM response handling, preserve the single-key text collapse rule, dict passthrough for logprobs/tool_calls, api_* stripping before history logging, and cost recording from _hidden_params.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8b336f7237e5dc3c785dc675.md)

## Rule

- **Rule:**
  ```text
  BaseLM subclasses must implement forward and return a value matching the OpenAI response format; BaseLM.__call__ is callback-wrapped and routes through self.forward then self._process_lm_response, so subclasses must not bypass that pipeline.
  ```
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:** When adding or modifying a BaseLM subclass or overriding forward in the LM client layer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8fc08d6fd5fbfdabd7183006.md)
