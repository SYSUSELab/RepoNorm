# Constraints for `dspy/clients/lm.py`

## Rule

- **Rule:**
  ```text
  alitellm_text_completion must split the model string into provider/model, resolve api_key and api_base from request or provider-specific environment variables, join message contents with 'BEGIN RESPONSE:', and call litellm.atext_completion with model prefixed 'text-completion-openai/' and exponential backoff retries.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** When modifying the litellm text-completion adapter or its model/credential resolution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-14819bdebb0c8e61b3485a37.md)

## Rule

- **Rule:**
  ```text
  When modifying litellm_completion, preserve default no-cache/no-store behavior, exponential_backoff_retry usage, and delegation to the stream completion function when one is configured.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:**
  ```text
  Changing litellm_completion defaults, retry behavior, or streaming delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-24c17e9ebf1319994a0c92d7.md)

## Rule

- **Rule:**
  ```text
  async_stream_completion must await stream_completion(request, cache_kwargs) so the async streaming path delegates to the same stream_completion used by the sync path with cache_kwargs.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:**
  ```text
  When modifying async_stream_completion or the shared stream_completion delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9bb33187af179518efbe9f1c.md)

## Rule

- **Rule:**
  ```text
  When modifying stream_completion, preserve that it calls litellm.acompletion with stream=True, attaches caller_predict_id to each chunk for stream listeners, forwards chunks via stream.send, and returns litellm.stream_chunk_builder over collected chunks.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** Changing the streaming completion path or chunk forwarding behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa3908fac7c1594152d45dc6.md)

## Rule

- **Rule:**
  ```text
  When changing dspy/clients/lm.py alitellm_completion, preserve the default cache of {"no-cache": True, "no-store": True} and the branch that calls litellm.acompletion with num_retries and retry_strategy="exponential_backoff_retry" when no stream completion is configured, otherwise awaits the stream completion.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:**
  ```text
  Modifying alitellm_completion's cache defaults, retry strategy, or stream/non-stream dispatch.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bb51643fa887b1b5001684c1.md)
