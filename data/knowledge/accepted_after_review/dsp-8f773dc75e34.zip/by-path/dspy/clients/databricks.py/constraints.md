# Constraints for `dspy/clients/databricks.py`

## Rule

- **Rule:**
  ```text
  TrainingJobDatabricks.status must require the databricks_genai package and raise an ImportError with an install hint when it is missing, and must return None when no finetuning run is set.
  ```
- **Applies to:**
  - `dspy/clients/databricks.py`
- **Condition:** When modifying TrainingJobDatabricks.status or its optional-dependency handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-243726a98f6153e399e83ca2.md)

## Rule

- **Rule:**
  ```text
  _validate_chat_data must require each finetuning record to be a dict with a 'messages' list, and each message to contain both 'role' and 'content' keys, raising ValueError with the offending data otherwise.
  ```
- **Applies to:**
  - `dspy/clients/databricks.py`
- **Condition:** When modifying finetuning chat data validation or its error behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5a4246151979b2792d675bb0.md)
