# Constraints for `dspy/clients/cache.py`

## Rule

- **Rule:** When modifying the two-level cache in dspy/clients/cache.py, preserve the ordering and layering: an in-memory cachetools.LRUCache consulted before an on-disk diskcache.FanoutCache, so that in-memory hits short-circuit disk access.
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:** When changing cache lookup, storage, or eviction behavior in the Cache class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0fe430d6131dcebd873b0725.md)

## Rule

- **Rule:**
  ```text
  When resetting the memory cache, the operation must be a no-op when enable_memory_cache is false and otherwise clear memory_cache under self._lock, so callers can invoke it regardless of cache configuration.
  ```
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:** Modifying or calling the memory-cache reset path in the cache client.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1cc82babbd9a13d844edc38e.md)

## Rule

- **Rule:**
  ```text
  Cache membership must be the union of the memory and disk tiers: __contains__ returns True when the key exists in either tier, so changes to either tier's lookup must keep the other tier reachable.
  ```
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:**
  ```text
  When modifying Cache.__contains__ or either cache tier's lookup behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-79fecbd3600e8243ecb0d719.md)
