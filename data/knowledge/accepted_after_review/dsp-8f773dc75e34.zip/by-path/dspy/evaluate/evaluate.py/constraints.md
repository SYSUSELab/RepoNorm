# Constraints for `dspy/evaluate/evaluate.py`

## Rule

- **Rule:**
  ```text
  stylize_metric_name formats float metric values as "✔️ [x.3f]" and non-float truthy values as "✔️ [x]", with falsy values rendered as empty string, defining the display convention for evaluation metric columns.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:**
  ```text
  When modifying stylize_metric_name or changing evaluation metric display formatting in the evaluate layer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-272d62a72d7913b670e1c5c9.md)

## Rule

- **Rule:** When modifying the evaluate module's display path, keep IPython display and HTML imports inside a try/except ImportError so notebook display support remains optional and IPython is not a hard dependency.
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** When adding or changing display/notebook rendering features in the evaluate module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-343dc93fa0e5c9ea9af1e98a.md)

## Rule

- **Rule:**
  ```text
  When rendering an EvaluationResult, __repr__ must show the score and a summarized results list rather than the full results, preserving the stable display contract for evaluation output.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** Modifying or extending the EvaluationResult display representation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5472fbac6b1da17e75ce347b.md)

## Rule

- **Rule:**
  ```text
  When modifying the evaluate module, contributors must account for the documented known limitations: counting failures with a max_failure threshold and printing failure/exception summaries, merge_dicts being quick-and-dirty, and display_table not handling False but handling 0.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:**
  ```text
  Modifying or extending the evaluate module's failure handling, merge_dicts, or display_table.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eaa6b3e1dffbf3edcd259332.md)
