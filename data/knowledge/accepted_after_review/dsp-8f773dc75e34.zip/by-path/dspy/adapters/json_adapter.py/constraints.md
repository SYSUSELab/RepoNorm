# Constraints for `dspy/adapters/json_adapter.py`

## Rule

- **Rule:** JSONAdapter's user message output requirements must instruct the model to respond with a JSON object listing output fields in signature order, each annotated with its type info; changes must preserve this ordering and type-annotation contract.
- **Applies to:**
  - `dspy/adapters/json_adapter.py`
- **Condition:**
  ```text
  When modifying JSONAdapter.user_message_output_requirements or the JSON output instructions it generates.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2a64e5d1d9bda2976187b4b9.md)

## Rule

- **Rule:**
  ```text
  When generating a pydantic model for OpenAI Structured Outputs, the model must use ConfigDict(extra='forbid'), strip json_schema_extra from properties, call enforce_required(schema), and override model_json_schema to return the precomputed schema.
  ```
- **Applies to:**
  - `dspy/adapters/json_adapter.py`
- **Condition:** Modifying the structured-outputs response-format generation in the JSON adapter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-902a8d866724f063585a61af.md)

## Rule

- **Rule:**
  ```text
  Output fields whose annotation origin is dict are open-ended mappings incompatible with OpenAI Structured Outputs; _get_structured_outputs_response_format must raise ValueError for them and callers must fall back to plain json_object response_format.
  ```
- **Applies to:**
  - `dspy/adapters/json_adapter.py`
- **Condition:**
  ```text
  When defining or modifying signatures used with structured outputs, or changing _get_structured_outputs_response_format / _has_open_ended_mapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-abee19dd783f80c8765bd103.md)
