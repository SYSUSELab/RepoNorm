# Constraints for `dspy/adapters/types/__init__.py`

## Rule

- **Rule:**
  ```text
  When adding a new adapter type to the adapters.types package, both the imports and the __all__ list must be updated so the type is publicly available.
  ```
- **Applies to:**
  - `dspy/adapters/types/__init__.py`
- **Condition:** Adding or removing a public adapter type in the adapters.types package.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-6ea45f0e2631e20cf123b40c.md)
