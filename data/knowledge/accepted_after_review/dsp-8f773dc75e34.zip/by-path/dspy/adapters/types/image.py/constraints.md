# Constraints for `dspy/adapters/types/image.py`

## Rule

- **Rule:**
  ```text
  When modifying Image.__repr__, preserve base64 payload redaction: base64 data must be summarized by encoded length and image type rather than printed verbatim, while non-base64 URLs remain shown verbatim.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  Changing how Image.__repr__ formats or logs image content.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-6ff0a45c15482ab99f4d38fb.md)

## Rule

- **Rule:**
  ```text
  When changing dspy/adapters/types/image.py Image.__str__, preserve that string conversion returns self.serialize_model() so str(image) yields the serialized model representation.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  Modifying Image.__str__ or the string representation of Image values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-f557bbf6448a39e9dfeee5b2.md)
