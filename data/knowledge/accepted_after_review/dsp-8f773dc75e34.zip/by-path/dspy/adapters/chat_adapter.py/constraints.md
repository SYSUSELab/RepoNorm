# Constraints for `dspy/adapters/chat_adapter.py`

## Rule

- **Rule:**
  ```text
  ChatAdapter.__call__ must fall back to JSONAdapter on any exception except ContextWindowExceededError, and must not retry when the instance is already a JSONAdapter; this defines the adapter fallback boundary.
  ```
- **Applies to:**
  - `dspy/adapters/chat_adapter.py`
- **Condition:**
  ```text
  When modifying ChatAdapter.__call__ or adding adapter fallback behavior in the adapter layer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-82b4d3d6cc2d41fdc7e7124e.md)
