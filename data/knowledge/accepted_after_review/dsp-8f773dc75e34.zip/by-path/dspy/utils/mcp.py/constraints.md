# Constraints for `dspy/utils/mcp.py`

## Rule

- **Rule:**
  ```text
  When importing mcp in dspy.utils.mcp, the import must be guarded under TYPE_CHECKING, while Tool and convert_input_schema_to_tool_args are imported normally.
  ```
- **Applies to:**
  - `dspy/utils/mcp.py`
- **Condition:** Modifying or extending imports in the MCP utility module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7e2304a97875b7e09f6fd00b.md)
