# Constraints for `dspy/utils/callback.py`

## Rule

- **Rule:**
  ```text
  on_adapter_parse_start is a no-op callback hook receiving call_id, adapter instance, and inputs, documenting the adapter parse lifecycle extension point for contributors implementing callbacks.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:** When implementing or modifying callback hooks in the callback layer, particularly adapter parse lifecycle hooks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-892058085e90351b1ec479ec.md)

## Rule

- **Rule:**
  ```text
  The on_adapter_format_end callback contract must specify that outputs is None when the adapter's format() is interrupted by an exception, with the exception passed separately; changes must preserve this error-signaling protocol.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:**
  ```text
  When modifying BaseCallback.on_adapter_format_end or any adapter format callback that signals errors.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa40d54df4d23a965347a680.md)
