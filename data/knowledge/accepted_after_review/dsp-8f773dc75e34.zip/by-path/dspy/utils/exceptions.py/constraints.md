# Constraints for `dspy/utils/exceptions.py`

## Rule

- **Rule:** When changing dspy/utils/exceptions.py, preserve AdapterParseError as the dedicated exception type raised when an adapter cannot parse an LM response, so adapter implementations and callers can rely on that stable error contract.
- **Applies to:**
  - `dspy/utils/exceptions.py`
- **Condition:** Modifying or replacing the exception type used for adapter parse failures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95b23ae1056306e4df0a8fc2.md)
