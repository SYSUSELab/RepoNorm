# Constraints for `dspy/utils/logging_utils.py`

## Rule

- **Rule:** DSPyLoggingStream must wrap sys.stderr and forward write()/flush() to whatever sys.stderr refers to at call time, and must support disabling to silence event logs.
- **Applies to:**
  - `dspy/utils/logging_utils.py`
- **Condition:** When modifying DSPyLoggingStream or its stderr forwarding behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e54c5b6d1b2c3cde8900d00a.md)
