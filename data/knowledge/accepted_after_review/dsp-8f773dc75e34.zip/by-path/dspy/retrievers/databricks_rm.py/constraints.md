# Constraints for `dspy/retrievers/databricks_rm.py`

## Rule

- **Rule:**
  ```text
  When changing dspy/retrievers/databricks_rm.py DatabricksRM.forward, preserve the validation that docs_id_column_name and text_column_name exist in the index manifest columns (raising an Exception naming the missing column otherwise) and the behavior of sorting results by score descending and truncating to self.k.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:** Modifying DatabricksRM.forward's column validation or result ordering/truncation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4c3a6d3c87797ca82570e839.md)

## Rule

- **Rule:**
  ```text
  DatabricksRM.forward must map legacy query_type values 'vector' and 'text' to 'ANN' for backwards compatibility while passing through 'ANN' and 'HYBRID' unchanged.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:**
  ```text
  When modifying DatabricksRM.forward query_type handling or adding new query_type values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-649303c67150153437fd4eac.md)

## Rule

- **Rule:**
  ```text
  DatabricksRM must resolve token, endpoint, client id, and client secret from constructor arguments or DATABRICKS_* environment variables, raise ValueError when the SDK is missing and credentials are incomplete, and require mlflow when use_with_databricks_agent_framework is enabled.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:** When modifying DatabricksRM credential resolution, SDK-missing error handling, or agent-framework dependency checks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af3cfdc87bc2544f26039f95.md)

## Rule

- **Rule:**
  ```text
  When extracting document ids in the Databricks retriever, the id must come from the configured docs_id_column_name; when that column is "metadata", the metadata field must be JSON-parsed and its document_id key returned.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:** Modifying or extending document-id extraction in the Databricks retriever.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b71d22f46ffdfc9d42779052.md)
