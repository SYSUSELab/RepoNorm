# Constraints for `dspy/retrievers/retrieve.py`

## Rule

- **Rule:**
  ```text
  single_query_passage must transpose passage dicts into column lists and rename the 'long_text' key to 'passages' before constructing a Prediction, preserving the field naming retrieval consumers depend on.
  ```
- **Applies to:**
  - `dspy/retrievers/retrieve.py`
- **Condition:**
  ```text
  When modifying single_query_passage or the passage-to-Prediction field mapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-080bbd56f2416f8b62a1f847.md)

## Rule

- **Rule:**
  ```text
  Retrieve.__init__ must generate a per-instance stage identifier from random.randbytes(8).hex() and store k (default 3) and callbacks (default empty list).
  ```
- **Applies to:**
  - `dspy/retrievers/retrieve.py`
- **Condition:**
  ```text
  When modifying Retrieve.__init__ or its stage identifier and default parameter handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7c64a09bbf793e9448c1b1f1.md)
