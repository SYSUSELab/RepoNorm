# Constraints for `dspy/retrievers/embeddings.py`

## Rule

- **Rule:**
  ```text
  When modifying the FAISS index construction in Embeddings._build_faiss, preserve the derived partition count int(2*sqrt(len(corpus))), the 32-byte PQ code configuration with 8-bit subquantizers, and nprobe = min(16, partitions); when faiss is unavailable, raise ImportError that advises installing faiss-cpu or raising brute_force_threshold rather than silently degrading.
  ```
- **Applies to:**
  - `dspy/retrievers/embeddings.py`
- **Condition:** When changing FAISS index construction or the missing-faiss fallback path in the embeddings retriever.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9eb0153f1a16b085af2abcdc.md)
