# Constraints for `dspy/__init__.py`

## Rule

- **Rule:**
  ```text
  Ruff lint rules I001, E402, and F405 are ignored for dspy/__init__.py.
  ```
- **Applies to:**
  - `dspy/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3772f8bba7efd216107ffb7f.md)
