# Constraints for `dspy/teleprompt/bettertogether.py`

## Rule

- **Rule:**
  ```text
  When joining strategy names in BetterTogether, the separator must be STRAT_SEP = " -> ", preserving the stable formatting convention for strategy identifiers.
  ```
- **Applies to:**
  - `dspy/teleprompt/bettertogether.py`
- **Condition:** Modifying or extending strategy-name formatting in the BetterTogether teleprompter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44e6be13b5e238a7ba816fe0.md)
