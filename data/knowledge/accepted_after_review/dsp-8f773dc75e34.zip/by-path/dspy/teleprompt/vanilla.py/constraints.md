# Constraints for `dspy/teleprompt/vanilla.py`

## Rule

- **Rule:** LabeledFewShot.compile must reset the student before assigning demos, return the student unchanged when the trainset is empty, and otherwise assign demos per predictor by sampling with Random(0) when sample=True or taking the first k trainset items.
- **Applies to:**
  - `dspy/teleprompt/vanilla.py`
- **Condition:** When modifying LabeledFewShot.compile or its demo-assignment behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f4688647a4d8b20bfe7ad007.md)
