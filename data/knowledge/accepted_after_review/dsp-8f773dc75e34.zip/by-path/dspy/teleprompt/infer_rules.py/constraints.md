# Constraints for `dspy/teleprompt/infer_rules.py`

## Rule

- **Rule:** InferRules must subclass BootstrapFewShot, inheriting and extending the bootstrap few-shot teleprompt behavior.
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:** When modifying InferRules or its inheritance from BootstrapFewShot.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-19106b543d53332e5af3ab3e.md)

## Rule

- **Rule:**
  ```text
  When changing dspy/teleprompt/infer_rules.py InferRules.update_program_instructions, preserve the in-place mutation of predictor.signature.instructions by appending a blank line and a 'Please adhere to the following rules when making your prediction:' section containing the natural-language rules.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:** Modifying how InferRules injects natural-language rules into predictor instructions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1b7cadfd32e517958da23287.md)

## Rule

- **Rule:**
  ```text
  When projecting trainset examples onto a predictor signature, each example must be filtered to keys present in the signature's input_fields or output_fields.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:** Modifying or extending demo projection in the infer-rules teleprompter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3e81a7fe0d5a85be0e4f4466.md)
