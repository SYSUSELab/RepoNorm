# Constraints for `dspy/teleprompt/gepa/gepa.py`

## Rule

- **Rule:**
  ```text
  `to_dict` serializes GEPA state including candidates, parents, scores, per-instance best candidates (converted to lists), eval counts, log_dir, seed, and best_idx, defining the persisted state schema.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  When modifying DspyGEPAResult.to_dict or the persisted GEPA state schema.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-00f1c15fdcd8bf36883a74cf.md)

## Rule

- **Rule:**
  ```text
  GEPA's AUTO_RUN_SETTINGS must map light/medium/heavy to n values 6/12/18, establishing the budget presets for automatic GEPA runs.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  when modifying GEPA AUTO_RUN_SETTINGS or automatic run budget presets
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-40374dc90363a0a1159d6f67.md)

## Rule

- **Rule:**
  ```text
  GEPA compilation must enforce exactly one budget configuration among auto, max_full_evals, and max_metric_calls; setting none or more than one is invalid.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  when modifying GEPA.compile or GEPA.__init__ budget-argument handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-42f3532166b2d569cb6c21c3.md)

## Rule

- **Rule:**
  ```text
  GEPA's reflection LM must be resolved through the fallback chain self.reflection_lm or settings.lm or student.get_lm().
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:** when modifying GEPA.compile reflection LM resolution or adding new LM configuration paths
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-4a194874ca199b471ee727fa.md)

## Rule

- **Rule:**
  ```text
  GEPA's DspyGEPAResult.best_candidate must be a property returning the candidate dict at best_idx, so callers read it without invoking a method and best_idx must remain valid.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  when modifying DspyGEPAResult.best_candidate or best_idx maintenance
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-514f728aa3b1ce0a0f6f5566.md)

## Rule

- **Rule:**
  ```text
  best_idx returns the index of the maximum value in val_aggregate_scores, so ties resolve to the first highest-scoring index.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  When modifying DspyGEPAResult.best_idx or its tie-breaking behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-5e561eff8e69e6f33ed80aa5.md)

## Rule

- **Rule:**
  ```text
  GEPA's feedback_fn_creator must return a PredictorFeedbackFn-compatible callable, establishing the per-predictor feedback extension point.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  when modifying GEPA.compile feedback_fn_creator or the PredictorFeedbackFn protocol
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-7f3b6e006c89e5005f6abeec.md)

## Rule

- **Rule:**
  ```text
  DspyGEPAResult.from_gepa_result rebuilds candidates through adapter.build_program while passing through parents, scores, best outputs, discovery counts, total metric calls, log_dir from run_dir, and seed, defining the adapter boundary for GEPA results.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  When modifying DspyGEPAResult.from_gepa_result or the GEPA result adaptation boundary.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-89e03f987b3ba84a99e3f0c7.md)

## Rule

- **Rule:** When no valset is provided, GEPA must use the trainset for both reflective updates and Pareto tracking, and log a suggestion to sample a valset for more diverse exploration within the same budget.
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:** when modifying GEPA.compile valset handling or Pareto tracking configuration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-a876cadb9726ee9afbaa6c4a.md)

## Rule

- **Rule:**
  ```text
  DspyGEPAResult is a frozen dataclass whose fields (candidates, parents, val_aggregate_scores, val_subscores, per_val_instance_best_candidates, discovery_eval_counts, best_outputs_valset, total_metric_calls, num_full_val_evals, log_dir, seed) define the public result contract of GEPA optimization runs.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:** When modifying DspyGEPAResult fields or its frozen dataclass contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-e12eec3e9a2c6b13a6448218.md)

## Rule

- **Rule:**
  ```text
  GEPA's auto_budget must validate num_trials, valset_size, and minibatch_size as >= 0 and full_eval_steps as >= 1, return early when N==0, and otherwise compute periodic full evals as (N+1)//m + 1 plus an extra final full eval when N < m.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  when modifying GEPA.auto_budget validation or full-eval accounting logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-e660cf37d35e17614f7e6faf.md)
