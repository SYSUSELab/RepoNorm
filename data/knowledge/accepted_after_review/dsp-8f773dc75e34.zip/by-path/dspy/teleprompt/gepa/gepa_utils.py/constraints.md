# Constraints for `dspy/teleprompt/gepa/gepa_utils.py`

## Rule

- **Rule:**
  ```text
  gepa_utils defines DSPyTrace as list[tuple[Any, dict[str, Any], Prediction]] and carries a TODO noting the DSPyAdapter currently uses GEPA's default propose_new_texts rather than a MIPROv2-style instruction proposal.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  When modifying the DSPyTrace type alias or the instruction proposal path in gepa_utils.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-039c8f3aefc639255324d1dc.md)

## Rule

- **Rule:**
  ```text
  GEPA's evaluate uses bootstrap_trace_data with capture_failed_parses=True and failure_score when capture_traces is set, and otherwise runs Evaluate with max_errors=len(batch)*100 and return_all_scores=True, defining the two evaluation paths and their error tolerances.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:** When modifying DspyAdapter.evaluate or the GEPA evaluation paths and error tolerances.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-1e572cad5fd2e751f9293953.md)

## Rule

- **Rule:**
  ```text
  GEPA feedback functions must return the same score as the module's score; make_reflective_dataset asserts this equality and rejects mismatched feedback scores.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  when modifying DspyAdapter.make_reflective_dataset or any GEPA feedback function that produces scores
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-62a32717b37fdb4e79c4ba1c.md)

## Rule

- **Rule:**
  ```text
  The gepa_utils module defines DspyAdapter as a GEPAAdapter parameterized over Example, TraceData, and Prediction, establishing the adapter contract between DSPy programs and the GEPA optimizer.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:** When modifying DspyAdapter or the adapter contract between DSPy programs and the GEPA optimizer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-6f3f2580663cc10f2a08ea14.md)

## Rule

- **Rule:**
  ```text
  When a prediction is a `FailedPrediction`, the reflective dataset builds a structure instruction from `ChatAdapter().format(...)` and sets Feedback to a parse-failure message, defining the fallback feedback path for unparseable outputs.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  When modifying DspyAdapter.make_reflective_dataset or the fallback feedback path for unparseable outputs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-71ec3f928a6d37474242fc3b.md)

## Rule

- **Rule:**
  ```text
  The GEPA feedback callable protocol requires a __call__ accepting predictor_output, predictor_inputs, module_inputs, module_outputs, and captured_trace, and returning a ScoreWithFeedback; captured_trace is shaped as a list of (Predictor, PredictorInputs, Prediction) tuples.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  When modifying PredictorFeedbackFn.__call__ or the GEPA feedback callable protocol.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-722e683590107e3a22974fd1.md)

## Rule

- **Rule:** GEPA candidate instruction strings are applied by deep-copying the student program and replacing each named predictor's signature instructions with the candidate string; the original program must not be mutated.
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  When modifying DspyAdapter.build_program or the candidate-to-program application path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-7b2e7f7f659be7d755a752bb.md)

## Rule

- **Rule:**
  ```text
  GEPA's feedback_fn_creator must return a PredictorFeedbackFn-compatible callable, establishing the per-predictor feedback extension point.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  when modifying GEPA.compile feedback_fn_creator or the PredictorFeedbackFn protocol
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-7f3b6e006c89e5005f6abeec.md)

## Rule

- **Rule:** ScoreWithFeedback is a Prediction subclass with typed fields score: float and feedback: str, so GEPA feedback results are expected to carry both a numeric score and textual feedback.
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:** When modifying ScoreWithFeedback or the GEPA feedback result schema.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-83fc0f496b8331c2ac1c82cd.md)

## Rule

- **Rule:**
  ```text
  GEPA's DspyAdapter must store student, metric_fn, feedback_map, failure_score, num_threads, add_format_failure_as_feedback, and rng, defaulting rng to random.Random(0) and caching named_predictors from the student module.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  when modifying DspyAdapter.__init__ or its stored configuration fields
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-ec3723393a11d0ece7b34f18.md)
