# Constraints for `dspy/teleprompt/simba_utils.py`

## Rule

- **Rule:**
  ```text
  append_a_demo_ must truncate input values longer than demo_input_field_maxlen with a '<TRUNCATED FOR BREVITY>' marker and keep only the last demo per predictor.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:**
  ```text
  When modifying append_a_demo_ or its demo-augmentation truncation behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0edf95039b5bda45c78956b7.md)

## Rule

- **Rule:** Program execution and metric evaluation exceptions must be swallowed and printed, leaving prediction as None and score as 0.0; downstream bucketing and strategy code must tolerate failed predictions and zero scores.
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:**
  ```text
  When modifying wrapped_program or any downstream bucketing/strategy code that consumes its prediction and score outputs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5a90140812633d3e58c583cb.md)

## Rule

- **Rule:**
  ```text
  When modifying append_a_rule, preserve that generated advice is applied by appending to each matching predictor's signature instructions via with_instructions, mutating predictor signatures in place.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:** Changing how generated SIMBA rules are applied to predictors.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-93532cae88b8d5256c22b7ef.md)

## Rule

- **Rule:**
  ```text
  When modifying prepare_models_for_resampling, preserve the temperature schedule: n LM copies start from the base LM's temperature followed by 0.5 + i*(0.5/n), deduplicated while preserving order and truncated to n.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:** Changing how resampling model copies or their temperatures are constructed.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-adc6a65c2f2ac9750ef8ee11.md)

## Rule

- **Rule:**
  ```text
  inspect_modules must iterate program.named_predictors() and format each predictor's signature instructions and input/output field descriptions with tab indentation and 80-dash separators, defining the inspection output format used by SIMBA utilities.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:**
  ```text
  When modifying inspect_modules or the SIMBA inspection output format.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bdaf2b174ca2dbe4325f7dea.md)

## Rule

- **Rule:**
  ```text
  wrapped_program must isolate each program call inside dspy.context(trace=[]) and then copy dspy.settings.trace, so the returned trace reflects only that call's trace rather than accumulated global trace state.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:**
  ```text
  When modifying wrapped_program or any code that captures trace state around a program call.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ebc46b57ec3193dc11e22efd.md)
