# Constraints for `dspy/teleprompt/copro_optimizer.py`

## Rule

- **Rule:**
  ```text
  GenerateInstructionGivenAttempts is a dspy.Signature with attempted_instructions as an InputField and proposed_instruction plus proposed_prefix_for_output_field as OutputFields, defining the signature used by the COPRO optimizer to propose improved instructions.
  ```
- **Applies to:**
  - `dspy/teleprompt/copro_optimizer.py`
- **Condition:** When modifying GenerateInstructionGivenAttempts or changing the COPRO optimizer's instruction-proposal signature in the teleprompt layer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6e65934510451ef1a1a38772.md)
