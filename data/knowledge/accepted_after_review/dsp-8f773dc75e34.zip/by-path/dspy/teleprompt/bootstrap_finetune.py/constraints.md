# Constraints for `dspy/teleprompt/bootstrap_finetune.py`

## Rule

- **Rule:**
  ```text
  all_predictors_have_lms must return True only if every predictor in the program has an LM set, defining the precondition used by finetune bootstrapping to decide whether LMs are ready; changes must preserve this all-predictors condition.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When modifying all_predictors_have_lms or the finetune bootstrapping precondition that checks LM readiness.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-366c18c467f351bba3cb6628.md)

## Rule

- **Rule:**
  ```text
  When normalizing train_kwargs for BootstrapFinetune, the value must be accepted as either a single dict or a per-LM dict and normalized via convert_to_lm_dict.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  Modifying or extending train_kwargs handling in the BootstrapFinetune teleprompter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6431f1e1b98df1b924933323.md)

## Rule

- **Rule:**
  ```text
  TraceData must remain a TypedDict with fields example_ind, example, prediction, trace (list of (Any, dict, Prediction) tuples), and score (float | None); changes to the trace record shape must preserve these field names and types because bootstrap finetuning consumes them.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:** When modifying the TraceData definition or any code that constructs/consumes trace records for bootstrap finetuning.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6afb8f1455d0d65e98865b95.md)

## Rule

- **Rule:** When collecting unique LMs across predictors, pred.lm must be gathered across all predictors and deduplicated via set, preserving the expectation that multiple predictors may share LM instances.
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:** Modifying or extending LM collection in the bootstrap-finetune teleprompter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a6858fa5cce0b7aa18311e39.md)

## Rule

- **Rule:**
  ```text
  When modifying finetuning program preparation in dspy/teleprompt/bootstrap_finetune.py, preserve the shared-predictor guard: assert_no_shared_predictor must compare named_predictors by id across the two programs and assert no shared predictor instances, and prepare_teacher must return the student unchanged when teacher is None, otherwise assert structural equivalency and no shared predictors before returning the teacher.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When changing finetuning program preparation, teacher selection, or predictor-sharing checks in bootstrap_finetune.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e80ee50d4415bad1169d9d98.md)
