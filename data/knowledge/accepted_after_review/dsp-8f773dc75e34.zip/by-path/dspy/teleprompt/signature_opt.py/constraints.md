# Constraints for `dspy/teleprompt/signature_opt.py`

## Rule

- **Rule:**
  ```text
  When modifying dspy/teleprompt/signature_opt.py, preserve its deprecated status in favor of COPRO and its documented SignatureOptimizer parameters and tracked statistics for backward compatibility.
  ```
- **Applies to:**
  - `dspy/teleprompt/signature_opt.py`
- **Condition:**
  ```text
  Changing the deprecated signature_opt module or its backward-compatibility surface.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-115503d13f65135aa003e056.md)

## Rule

- **Rule:**
  ```text
  When modifying SignatureOptimizer in dspy/teleprompt/signature_opt.py, preserve the deprecation boundary: __init__ must print a red warning that SignatureOptimizer is deprecated in favor of COPRO and will be removed in a future release before delegating to the superclass initializer.
  ```
- **Applies to:**
  - `dspy/teleprompt/signature_opt.py`
- **Condition:** When changing SignatureOptimizer initialization or its deprecation messaging.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-546fcc5c69d12ac1177fa86b.md)
