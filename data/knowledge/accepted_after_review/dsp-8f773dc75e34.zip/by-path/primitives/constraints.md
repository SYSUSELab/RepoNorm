# Constraints for `primitives`

## Rule

- **Rule:**
  ```text
  The dspy package includes the JS files matching primitives/*.js as package data.
  ```
- **Applies to:**
  - `primitives/*.js`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7d9e5dad6402e4f15f45374c.md)
