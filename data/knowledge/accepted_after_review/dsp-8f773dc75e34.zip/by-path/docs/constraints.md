# Constraints for `docs`

## Rule

- **Rule:**
  ```text
  The docs workflow triggers on pull requests limited to paths under docs/**.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-117c5974c5c544e66266fcda.md)

## Rule

- **Rule:**
  ```text
  CI runs `mkdocs build` to verify the documentation builds successfully before merging changes.
  ```
- **Applies to:**
  - `docs/**`
  - `mkdocs.yml`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-17374f72b3b619a96c466b22.md)

## Rule

- **Rule:** The MkDocs theme enables the features navigation.tabs, navigation.path, navigation.indexes, navigation.expand, toc.follow, navigation.top, search.suggest, and search.highlight.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-18344133430928241bb925da.md)

## Rule

- **Rule:** When the CI build check fails, review changes and ensure the documentation builds correctly locally before pushing updates.
- **Applies to:**
  - `docs/**`
  - `mkdocs.yml`
- **Condition:** the CI build check fails
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-18eddba783c527634b61c548.md)

## Rule

- **Rule:** The mkdocstrings Python handler uses Google docstring style.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1e38cfae6cc49e9a90b91669.md)

## Rule

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.tabbed markdown extension with alternate_style.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2133c75b872004285020a66f.md)

## Rule

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.emoji markdown extension with twemoji index and to_svg generator.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2f4cff7034bd7b4f7b7e39c8.md)

## Rule

- **Rule:** The mkdocstrings Python handler orders members by source.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-30560028ad24f2bd0f6b4e94.md)

## Rule

- **Rule:** The MkDocs theme is configured with name 'material'.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-455116b9c5019d2d3644296f.md)

## Rule

- **Rule:** Once documentation changes are merged to main, they are reflected on the live website usually within 5-15 minutes.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-490b74a8929dee2bcd4b3777.md)

## Rule

- **Rule:** The MkDocs site language is set to English (en).
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4db3100cf1583ec47b7772e9.md)

## Rule

- **Rule:** The MkDocs site defines a slate (dark) palette scheme with black primary and lime accent colors.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4f2ee52e63ab5ae201bab9ed.md)

## Rule

- **Rule:**
  ```text
  Documentation changes for the docs site are made in the `dspy/docs` folder.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-5ae40163c5c6c7669031d6a0.md)

## Rule

- **Rule:** The MkDocs site enables the pymdownx.arithmatex markdown extension with generic.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5e540e46781255c765f3e385.md)

## Rule

- **Rule:**
  ```text
  The MkDocs theme is configured with custom_dir 'overrides'.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a83606427001f5d667ba518d.md)

## Rule

- **Rule:**
  ```text
  The MkDocs site enables the search plugin with language en and separator '[\s\-\.]+'.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-aa6d42b54eae65d236a65d26.md)

## Rule

- **Rule:** The MkDocs documentation source directory is configured as "docs/".
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bb434ebce6e996d0ef557b39.md)

## Rule

- **Rule:**
  ```text
  The MkDocs site uses the DSPy logo at static/img/dspy_logo.png.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bc7d79164e7f8189c6029565.md)

## Rule

- **Rule:** The MkDocs site loads the extra stylesheet stylesheets/extra.css.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c16eab952d7a769ba740152e.md)

## Rule

- **Rule:** The MkDocs site uses the favicon at static/img/logo.png.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c67b3dac3caee0e1412e869c.md)

## Rule

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.inlinehilite, pymdownx.snippets, admonition, footnotes, pymdownx.details, pymdownx.superfences, pymdownx.mark, attr_list, and md_in_html markdown extensions.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-caedb627d513037b6ec230ca.md)

## Rule

- **Rule:** The MkDocs edit URI is configured as blob/main/docs/docs/.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ce3f5f0f250728049867f162.md)

## Rule

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.highlight markdown extension with anchor_linenums.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d5c13eb004711394a63ac9bf.md)

## Rule

- **Rule:**
  ```text
  The docs workflow triggers on pushes to the main branch limited to paths under docs/**.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d79612d92cd14d36048e1ff3.md)

## Rule

- **Rule:** The mkdocs-jupyter plugin ignores H1 titles.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d8f06d0d0786a0d36792b6c5.md)

## Rule

- **Rule:** Documentation changes are pushed on a new branch and opened as a PR for review and approval before merging into main.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-d970dc9d3dc9d7b161573ce6.md)

## Rule

- **Rule:**
  ```text
  Running `mkdocs build` generates a static build of the documentation site in the `site` directory.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e8846a02f20631ce64b43544.md)

## Rule

- **Rule:** Contributors pull the latest version of the live documentation site by cloning the dspy repo before making documentation changes.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-ec6cfcd13118a29f210eeff8.md)

## Rule

- **Rule:** The mkdocstrings Python handler renders source.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ed50ddbacba990063039894c.md)

## Rule

- **Rule:** The MkDocs site defines a default (light) palette scheme with white primary and black accent colors.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ee53e8915db5323359a97a8a.md)

## Rule

- **Rule:** The MkDocs site loads the extra JavaScript file js/runllm-widget.js.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f7f75b1585c0db73d5322671.md)
