# Constraints for `docs/scripts/generate_api_summary.py`

## Rule

- **Rule:**
  ```text
  The API summary navigation must be generated from the docs/api directory tree: directory names are mapped through INDEX_NAME to display titles, only .md files become nav entries keyed by file stem, and submodule sections must be emitted before file entries.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:**
  ```text
  When modifying generate_api_nav, build_nav_structure, format_nav_section, or INDEX_NAME in the API summary generator.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3c179f8e8eaa269d497f801d.md)

## Rule

- **Rule:** Running the API summary generator must rewrite the checked-in mkdocs.yml in place, preserving pre-nav and post-theme sections while stripping the existing '- API Reference:' nav entry and its continuation lines before inserting the regenerated section.
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:**
  ```text
  When modifying main() or read_mkdocs_sections in the API summary generator that rewrites mkdocs.yml.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-460612df8b084988e3e3298f.md)
