# Constraints for `docs/scripts/generate_api_docs.py`

## Rule

- **Rule:** When generating API documentation pages with mkdocstrings, emit the ::: directive as the last line of the page content so that the generated HTML does not leave an unclosed div.
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Modifying the API documentation page generator that emits mkdocstrings ::: directives.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-094d2dbd8104fdde5fa297a9.md)

## Rule

- **Rule:** Docs generation cleanup must recursively remove directories that contain no entries, descending into child directories before removal.
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  When modifying remove_empty_dirs or the post-generation cleanup step in the API docs generator.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-70703e1636652e17e0e91401.md)

## Rule

- **Rule:**
  ```text
  API documentation must exclude private and dunder methods except __call__, and must only document methods whose __module__ starts with 'dspy'; get_public_methods must apply this predicate when collecting class members.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  When changing should_document_method, get_public_methods, or get_module_contents filtering rules for which class members appear in generated API docs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-76f688771aab8336d07e5fa0.md)

## Rule

- **Rule:**
  ```text
  API documentation generation must derive its category taxonomy from the explicit API_MAPPING dict; objects not present in that mapping are excluded from generated docs rather than assigned a default category.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  When adding or modifying public dspy symbols or the API_MAPPING category dict in the docs generation script.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9e8da5ddb5e94ca9077e4904.md)
