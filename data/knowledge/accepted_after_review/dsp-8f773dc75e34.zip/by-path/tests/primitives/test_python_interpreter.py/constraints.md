# Constraints for `tests/primitives/test_python_interpreter.py`

## Rule

- **Rule:** Python interpreter tests must assert that executing code that raises a Python exception (e.g., '1+0/0') raises InterpreterError matching the original exception name (e.g., 'ZeroDivisionError'), defining the expected error translation.
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** When modifying or adding Python interpreter failure tests, keep the assertion that a Python exception is translated to InterpreterError matching the original exception name.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3cc3319603faa491b0a8f07f.md)

## Rule

- **Rule:** Tests for the PythonInterpreter must be skipped at module level when the deno executable is not found on PATH, so contributors must install Deno to run these tests.
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** When adding or modifying PythonInterpreter tests that depend on the deno executable.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-457427177f4b64bc4106f710.md)

## Rule

- **Rule:**
  ```text
  PythonInterpreter tests must assert the allowlist semantics of network access: enable_network_access=None raises InterpreterError matching "PythonError" on js.fetch, while enable_network_access=["example.com"] permits the same fetch and returns status 200.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** When adding or modifying a PythonInterpreter test that asserts network access allowlist behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6145ceea62de6be9ca701c87.md)

## Rule

- **Rule:**
  ```text
  The PythonInterpreter sandbox must enforce read-path access control: files are readable only when their real path is listed in enable_read_paths, and with enable_read_paths=None opening a sandboxed path fails with a permission-denied or no-such-file error.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:**
  ```text
  When modifying PythonInterpreter read-path handling or its tests, preserve the enable_read_paths allowlist enforcement and the failure when enable_read_paths=None.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-87dfa60fdecf196f16f9bcca.md)

## Rule

- **Rule:** Tests that assert captured stdout from PythonInterpreter.execute must expect the trailing newline produced by print, because execute returns raw captured stdout rather than stripped output.
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** When modifying or adding tests that assert the return value of PythonInterpreter.execute for code that prints.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95093830dd53529e64428f7b.md)
