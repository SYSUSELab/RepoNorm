# Constraints for `tests/primitives/test_base_module.py`

## Rule

- **Rule:**
  ```text
  Module deepcopy tests must assert that after Module.deepcopy, nested locks are shared by identity (shallow) while parameters are distinct objects with equal __dict__.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:**
  ```text
  When modifying Module.deepcopy behavior or its tests, preserve the assertion that nested locks are shared by identity while parameters are distinct objects with equal __dict__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0aebaf7ecc091b34ad637311.md)

## Rule

- **Rule:**
  ```text
  When track_usage=True, a ChainOfThought call must record lm_usage with positive prompt/completion/total token counts; when the LM has cache=True, repeated identical calls must produce empty lm_usage because cached responses are not counted.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:**
  ```text
  modifying usage tracking or LM caching behavior that affects whether cached responses contribute to lm_usage
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d7d1fd966604dfbdc5b0207.md)

## Rule

- **Rule:** Tests that verify per-predictor history recording under concurrency must assert history length on the program, its sub-predictors, and its chain-of-thought predictor after parallel execution, because history is recorded per predictor rather than only at the module level.
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When modifying or adding tests that exercise module history under concurrent execution (e.g., dspy.Parallel).
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-587ea1af4bcaf5c9f1b87463.md)

## Rule

- **Rule:** Tests covering version-mismatch warnings must assert that loading a program saved under different python/dspy/cloudpickle versions logs exactly one warning containing 'There is a mismatch of' per mismatched dependency while still loading the model correctly.
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When modifying version-mismatch warning behavior or the base module tests that cover loading programs saved under different dependency versions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-69e067a6f3d578dc76fad5cb.md)

## Rule

- **Rule:** Save/load must round-trip signature instructions and demos, and pickle is the supported path for non-JSON-serializable data such as datetime.date.
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When modifying program save/load serialization or adding round-trip tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-827f9dba98416fc61d9b6bea.md)

## Rule

- **Rule:**
  ```text
  When a module hierarchy records history, the same history entity object must be shared across ancestor callers (id equality between parent and child history entries), and disable_history=True must suppress recording while disable_history=False resumes it.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:**
  ```text
  modifying module history recording or the disable_history flag behavior across nested module calls
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dc03028f31621de5e5575810.md)
