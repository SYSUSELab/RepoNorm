# Constraints for `tests/primitives/test_example.py`

## Rule

- **Rule:** Example hashing must be value-based: examples with identical field values produce equal hashes.
- **Applies to:**
  - `tests/primitives/test_example.py`
- **Condition:** When modifying Example hashing or its tests, preserve the assertion that examples with identical field values produce equal hashes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3f15e93ce8244cb916c37d28.md)

## Rule

- **Rule:** Tests that assert exact string representations of core primitives (such as Example repr/str) must treat the asserted string as a stable display contract and update the assertion deliberately when the primitive's formatting changes.
- **Applies to:**
  - `tests/primitives/test_example.py`
- **Condition:** When modifying the repr or str implementation of a core primitive that has an exact-string assertion in its test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa986e42dea82ed906a79b69.md)
