# Constraints for `tests`

## Rule

- **Rule:**
  ```text
  Ruff lint rules S101, TID252, and ARG001 are ignored for Python files under tests/**.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0797fd557acbe2ae83395e20.md)

## Rule

- **Rule:**
  ```text
  The test job runs extra tests via uv run -p .venv pytest tests/ -m extra --extra after installing the test_extras extra.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-342dc353372740d34ecd6947.md)

## Rule

- **Rule:** The test job runs pytest over the tests/ directory via uv run -p .venv pytest -vv tests/.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-342f73b9f3cd4d314e6e076f.md)

## Rule

- **Rule:**
  ```text
  Tests that mutate dspy global settings must rely on the autouse clear_settings fixture, which yields and then restores dspy.settings from a deep copy of DEFAULT_CONFIG with inherit_config=False, so each test starts from default settings.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test that reads or mutates dspy global settings
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-381c1214023e8fff68b6051d.md)

## Rule

- **Rule:** Ruff indent-width is set to 4.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-830fc670d804318dce145cd0.md)

## Rule

- **Rule:** Ruff linting/formatting applies to Python files under dspy/ and tests/ as included by the include setting.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8876e3c28ccb3249fe435f00.md)

## Rule

- **Rule:**
  ```text
  Tests that are expected to fail with certain models are marked using the `@known_failing_models` decorator, and such known failures are logged without affecting the overall test result.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-aef10a9b69939ec418db0eb3.md)

## Rule

- **Rule:** Setuptools package discovery excludes the tests directory and its subpackages.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ce7c1a1c4e56b152d1fe5b71.md)

## Rule

- **Rule:** Ruff target-version is py310.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-d276e70dfd38da0229f94aec.md)

## Rule

- **Rule:**
  ```text
  The llm_call_test job runs pytest with -m llm_call --llm_call -vv --durations=5 over the tests/ directory.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d998f2a4308de0ac289be9a2.md)

## Rule

- **Rule:** Ruff line-length is set to 120.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-dde087539e0518475f99700a.md)

## Rule

- **Rule:**
  ```text
  The llm_call_test job sets LM_FOR_TEST=ollama/llama3.2:3b in the GitHub environment after pulling the llama3.2:3b model from the ollama service.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e16322e097967771fb87ed68.md)
