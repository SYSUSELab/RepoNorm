# Constraints for `tests/predict/test_predict.py`

## Rule

- **Rule:** Tests for Predict with enum-typed outputs must assert that the LM's lowercase string value is coerced back to the corresponding enum member, documenting enum value round-tripping behavior.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When adding or modifying Predict tests that cover enum-typed inputs or outputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c5ea6e0553f42616cc0a86d.md)

## Rule

- **Rule:** Predict tests must assert that a Predict configured with n=2 returns a Prediction whose completions.answer list contains both generated answers in order.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying Predict multi-output behavior or its tests, preserve the assertion that n=2 yields a Prediction with completions.answer containing both answers in order.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-581b3bd599079c1e5885e3bb.md)

## Rule

- **Rule:**
  ```text
  The trace buffer must be bounded by max_trace_size, retaining only the most recent entries after repeated Predict calls.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  When modifying trace buffering or its tests, preserve the bound that dspy.settings.trace length equals max_trace_size after more calls than the limit.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-642b21e07e91afc626a0da17.md)

## Rule

- **Rule:** Tests covering enum output coercion must assert that when an LM returns an enum value by its string value, the Predict output is coerced to the corresponding enum member.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying enum output handling or the predict tests that cover enum inputs and outputs with shared names and values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6b0303e382ac661cdff77953.md)

## Rule

- **Rule:**
  ```text
  Predict.dump_state must preserve serialized values through ujson round-trip: serialize_object normalizes a pydantic model's URL field to a trailing-slash form and serializes datetime to ISO format, and dump_state preserves these serialized values.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  When adding or modifying a Predict test that asserts dump_state serialization of pydantic non-primitive types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-751ddebaf02a5219b4cd808a.md)

## Rule

- **Rule:**
  ```text
  Predict tests must define signatures with field-level constraints (min_length, max_length, gt, lt, ge, le, multiple_of) on both input and output fields, exercising constraint propagation through dspy signatures.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying or adding predict tests for field constraints, keep the signature definition with field-level constraints on both input and output fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-87524b1dfe59a8d887eec80f.md)

## Rule

- **Rule:** Tests that exercise adapter handling of non-primitive annotated signature fields must define a custom type used for both input and output fields, because the adapter must serialize and validate non-primitive annotations on both sides.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying or adding tests for adapter handling of custom-typed signature fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cef8c52f822a146c0b0cbaa2.md)

## Rule

- **Rule:**
  ```text
  Predict tests that use a SpyLM must record each invocation's prompt, messages, and kwargs into self.calls, and return either a JSON-style string or a '[[ ## answer ## ]]' formatted string depending on self.return_json.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When adding or modifying a Predict test that uses a SpyLM to capture invocations.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e5d3087dd271892cb9261dbd.md)

## Rule

- **Rule:**
  ```text
  Tests for per-module history must assert that with disable_history=True configured, repeated Predict calls leave program.history empty, because the disable_history setting suppresses per-module history accumulation.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  When adding or modifying tests that cover the disable_history setting and per-module history accumulation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f66896ec8a659cfab43476b4.md)

## Rule

- **Rule:** Predict with chat history must send exactly 4 messages to the LM with prior question/answer content and the new question in the final message.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying chat history handling in Predict or adding chat history tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-faece9db19d5153b6ec63cda.md)
