# Constraints for `tests/predict/test_react.py`

## Rule

- **Rule:**
  ```text
  ReAct tests must assert that max_iters bounds the trajectory: with max_iters=2 the recorded trajectory contains exactly two thought/tool-call pairs and two observations, even when the model would succeed on a later turn.
  ```
- **Applies to:**
  - `tests/predict/test_react.py`
- **Condition:**
  ```text
  When modifying or adding ReAct error-retry tests that set max_iters, keep the assertion that the trajectory is truncated to exactly max_iters thought/tool-call pairs and observations.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-231813b3d0036d1e47deb844.md)

## Rule

- **Rule:**
  ```text
  Tests covering ReAct trajectory truncation must assert that after multiple tool calls, older entries such as thought_0 are absent from result.trajectory while newer entries such as thought_2 remain.
  ```
- **Applies to:**
  - `tests/predict/test_react.py`
- **Condition:** When modifying ReAct trajectory truncation behavior or the ReAct tests that cover long trajectories.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ad9a93989eafe92229b1c165.md)
