# Constraints for `tests/predict/test_best_of_n.py`

## Rule

- **Rule:** BestOfN tests must assert that when no candidate meets the threshold (e.g., threshold=0.0 with a module that always raises), the failure surfaces as ValueError rather than returning a prediction.
- **Applies to:**
  - `tests/predict/test_best_of_n.py`
- **Condition:** When modifying or adding BestOfN tests that exercise threshold failure, keep the assertion that a ValueError is raised when no candidate meets the threshold.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-83fffa219e60797c0a4c42f3.md)
