# Constraints for `tests/reliability/complex_types/generated/test_nesting_1/program.py`

## Rule

- **Rule:** Reliability tests for nested models must define Pydantic models referencing deeper nested models (e.g., ResultLevel5), exercising nested model serialization.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying or adding reliability tests for nested models, define Pydantic models that reference deeper nested models to exercise nested serialization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-1a512ee9ec0deedeb6437208.md)
