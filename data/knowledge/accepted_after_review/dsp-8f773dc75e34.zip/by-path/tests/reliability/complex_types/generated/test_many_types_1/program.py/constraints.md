# Constraints for `tests/reliability/complex_types/generated/test_many_types_1/program.py`

## Rule

- **Rule:** Reliability tests for complex types must define Pydantic models that exercise tuple, enum, datetime, and literal types together, asserting round-trip handling of these complex field types.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
- **Condition:** When modifying or adding reliability tests for complex types, define Pydantic models that exercise tuple, enum, datetime, and literal types together.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-50f3990c048aca2ba3c92f46.md)

## Rule

- **Rule:** Generated reliability test programs must build their dspy signature dynamically by iterating over the Pydantic input/output model fields and appending dspy.InputField/OutputField entries, so the program signature mirrors the Pydantic models.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
- **Condition:** When modifying or regenerating reliability test programs that pair Pydantic input/output models with a dspy signature.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-64e14ae8761739557b68e685.md)
