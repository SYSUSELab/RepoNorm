# Constraints for `tests/reliability/complex_types/generated/test_nesting_2/program.py`

## Rule

- **Rule:**
  ```text
  Reliability tests for nested models must define Pydantic models with required fields plus a nested Details field (e.g., Transaction with transaction_id and amount plus nested Details1), establishing the expected nested pydantic schema.
  ```
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_nesting_2/program.py`
- **Condition:** When modifying or adding reliability tests for nested models, define Pydantic models with required fields plus a nested Details field.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../../claims/CLAIM-d44bf8c15f10bb655e6d261c.md)
