# Constraints for `tests/reliability/conftest.py`

## Rule

- **Rule:**
  ```text
  Reliability test configuration must be read from reliability_conf.yaml and applied via dspy configuration with the parametrized model and adapter; tests must be skipped when no YAML config exists for the model, and should_ignore_failure and model_name must be stored on the request node for post-test handling.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** When modifying the reliability conftest autouse fixture that configures models for reliability tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3cf9bb87bdb9f907465b9e36.md)

## Rule

- **Rule:**
  ```text
  Reliability conftest must define the canonical MODEL_LIST and parameterize configure_model over it, marking each model as known-failing based on the test function's _known_failing_models attribute and using model names as parametrization IDs.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** When modifying reliability conftest model parametrization or known-failing model handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-becd7645127b5c5fab548c2a.md)
