# Constraints for `tests/reliability/test_pydantic_models.py`

## Rule

- **Rule:** Reliability tests define structured extraction output models as pydantic BaseModel classes whose fields each carry a Field(description=...), illustrating the expected shape of structured extraction outputs; preserve this field-description convention.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when defining or modifying structured extraction output models in reliability tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-37bf47e00b138bd64f280c34.md)

## Rule

- **Rule:** Enum classification tests must cover trailing-period variants that previously produced invalid enum responses, asserting correct enum values for both dspy.Predict and dspy.ChainOfThought.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** When modifying enum classification tests or handling trailing-period inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4648f2193f39df3e3664fc81.md)

## Rule

- **Rule:** The reliability test suite must define a Colorful Signature with a str input and a Color output field to exercise Pydantic enum output handling.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying the reliability test that exercises Pydantic enum output handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-46b62f40c8a9b6fc3072ac59.md)

## Rule

- **Rule:**
  ```text
  Reliability tests using pydantic answer models must assert answer.certainty is within [0,1] and len(answer.comments) >= 2, and grade both answer.value and answer.comments via assert_program_output_correct.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying reliability tests that use the pydantic answer model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-86d0789ec6f6c1e0aa16ff8b.md)

## Rule

- **Rule:**
  ```text
  Reliability tests for multiple primitive outputs assert each output field (entity_hu, entity_en, categories) against grading guidelines, with categories expected to be pipe-separated; keep this per-field assertion and pipe-separated categories convention.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying reliability tests that assert multiple primitive output fields
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a7a18067cb48ac27d8abde35.md)

## Rule

- **Rule:** ToolCalling signatures must enumerate allowed tool names and statuses via Literal annotations.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** When defining or modifying ToolCalling signatures in reliability tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa8dc7c94e057327c15bf571.md)

## Rule

- **Rule:** DSPy signatures must support non-primitive pydantic output types, as demonstrated by using a custom Answer type as an OutputField in reliability tests.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** When modifying reliability pydantic model tests or signature output types, preserve support for non-primitive pydantic output types as OutputFields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c417b95b891922f9326df368.md)

## Rule

- **Rule:**
  ```text
  Reliability pydantic model tests must define Answer with required 'value: str', 'certainty: float' described as between 0 and 1, and 'comments: list[str]' described as at least two comments.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when modifying or extending reliability pydantic model tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ce3c824fb3ca61a4d1b34874.md)

## Rule

- **Rule:** The reliability pydantic output test must use a pydantic model (ExtractEntityFromDescriptionOutput) as the type of an OutputField, demonstrating that structured pydantic outputs are supported in signatures.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** When modifying reliability pydantic output signature tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e9441773ace4605ecb86ef83.md)
