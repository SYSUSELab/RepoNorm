# Constraints for `tests/reliability/reliability_tests_conf.yaml`

## Rule

- **Rule:**
  ```text
  The configuration must specify a DSPy adapter to use when testing, e.g. `"chat"` (for `dspy.ChatAdapter`) or `"json"` (for `dspy.JSONAdapter`).
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../../../claims/CLAIM-29f20b73e269c9f9857cbf81.md)

## Rule

- **Rule:**
  ```text
  Any model that lacks configured `litellm_params` in the configuration file is ignored during testing.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../../claims/CLAIM-add6eb39d7a1d4e6abecc01b.md)
