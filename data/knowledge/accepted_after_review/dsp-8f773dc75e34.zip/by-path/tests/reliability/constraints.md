# Constraints for `tests/reliability`

## Rule

- **Rule:**
  ```text
  The ruff-check hook excludes dspy/__metadata__.py and files under tests/reliability/ from its file selection.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c56263aef12dcf17a9b908b.md)

## Rule

- **Rule:** Tests are set up to mark expected failures for known challenging cases where a specific model might struggle, while actual (unexpected) DSPy reliability issues are flagged as failures.
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7ba96d264c13fcc80416fd6e.md)

## Rule

- **Rule:**
  ```text
  Run a single generated test by invoking pytest on test_generated.py with a -k filter matching the test name.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-91e10694b63e8f3a5ef177a7.md)

## Rule

- **Rule:**
  ```text
  Run `python -m tests.reliability.generate -d <output_dir> -p "<program description>" -i "<input description>"` from the DSPy repository root directory to generate a test program and test inputs.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../claims/CLAIM-a752f309fa6893fd80cfbfc6.md)

## Rule

- **Rule:**
  ```text
  Reliability tests must obtain the judge program via _get_judge_program, which returns dspy.Predict(JudgeSignature), rather than constructing a judge inline.
  ```
- **Applies to:**
  - `tests/reliability/**/*.py`
- **Condition:** when a reliability test needs a judge program to evaluate outputs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ab84e55363df58322d4efacc.md)

## Rule

- **Rule:**
  ```text
  Running `pytest .` executes all tests for the configured models and displays detailed results for each model configuration.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b3143a8cfaf876ee54150fbf.md)

## Rule

- **Rule:**
  ```text
  All generated tests should be located in directories with the structure `tests/reliability/<test_type>/generated/<test_name>`, where `<test_type>` is the test type (e.g., `classification`, `complex_types`, `chat`) and `<test_name>` is a descriptive test name.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../claims/CLAIM-d1fbe64389c796afac27c4d3.md)

## Rule

- **Rule:**
  ```text
  Test DSPy programs and test inputs can be generated from text descriptions using the `tests.reliability.generate` CLI or the `tests.reliability.generate.generate_test_cases` API.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d9638b832515705b667de61b.md)

## Rule

- **Rule:**
  ```text
  Ruff excludes dspy/__metadata__.py and tests/reliability/*.py from its checks.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df1497a7451cab7de547a4ca.md)
