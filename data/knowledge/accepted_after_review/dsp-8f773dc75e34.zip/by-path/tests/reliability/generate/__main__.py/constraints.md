# Constraints for `tests/reliability/generate/__main__.py`

## Rule

- **Rule:**
  ```text
  The reliability generate CLI must expose required `--dst_path` and optional `--num_inputs` (default 1), `--program_instructions`, and `--input_instructions`, forwarding them to `generate_test_cases`.
  ```
- **Applies to:**
  - `tests/reliability/generate/__main__.py`
- **Condition:**
  ```text
  When modifying the reliability generate CLI entry point, preserve the required `--dst_path` argument and optional arguments with their defaults, forwarding to `generate_test_cases`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-c66c6bb37d17ef76521fe99d.md)
