# Constraints for `tests/reliability/generate/utils.py`

## Rule

- **Rule:**
  ```text
  Generated reliability test cases are represented by the GeneratedTestCase dataclass carrying name, program_path, program_input as a JSON string, and output_assertions; keep this schema when producing or consuming generated cases.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when changing how generated reliability test cases are represented or loaded
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-0e282c7bb7470abce59c6fa0.md)

## Rule

- **Rule:**
  ```text
  `_write_pretty_json` must return the indented JSON string when no path is given, and write to the file and return None when a path is provided.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying `_write_pretty_json` or its callers, preserve the dual-mode return contract: string when no path, None when a path is written.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-127850d9b0658e61f8912ab1.md)

## Rule

- **Rule:** Reliability test generation utilities must keep generated inputs schema-valid: caching is disabled and temperature is 0.5 so retries produce fresh inputs, and each generated input is validated against the program's input schema before input/assertions JSON files are written.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying generate_test_inputs or the reliability input-generation pipeline.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-1d3f4ad0e5df121ff05f24fd.md)

## Rule

- **Rule:**
  ```text
  Reliability schema generation must rename output fields that collide with input fields: rename_conflicting_fields appends '_output' to colliding output schema properties and updates the output required list accordingly.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying rename_conflicting_fields or input/output schema merging in the reliability generation utilities.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2a097b4322f50e87de7c244a.md)

## Rule

- **Rule:**
  ```text
  Reliability test retry wrappers must loop up to the configured `retries` count, print a retry message on each caught exception, and re-raise the exception once attempt >= retries.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When adding or modifying retry wrappers used by reliability test generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-2e896138aa319a2074d80a48.md)

## Rule

- **Rule:** Generated reliability cases are discovered by directory convention: a case directory must contain both program.py and an inputs directory, and each .json file in inputs must be an object with input and assertions keys; the case name is derived from the enclosing directory, case directory, and input filename.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When adding or modifying generated reliability case directories or the loader that discovers them.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-3f2227895b2310128721254d.md)

## Rule

- **Rule:** The reliability test input-generation signature must require natural-language, objective, verifiable assertions (ideally about 5) and permit leaving them blank when accurate assertions are difficult to generate.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the assertion-generation signature or its prompt, preserve the requirement for natural-language, objective, verifiable assertions and the allowance to leave them blank when accurate assertions are difficult.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-4a1d7ed33e0a0bf6934fb80f.md)

## Rule

- **Rule:**
  ```text
  ProgramGeneration requires program_input_fields and program_output_fields outputs to be valid JSON Schema strings without backticks or extra text.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying the ProgramGeneration signature or the reliability generation protocol that produces program_input_fields and program_output_fields.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-64895d56278a5fdda32bfc7f.md)

## Rule

- **Rule:**
  ```text
  Reliability test input generation must require program_input to be a JSON string whose schema precisely matches the program's input signature, including wrapper objects.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying or extending reliability test input generation helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-6497391936676404f2f28a17.md)

## Rule

- **Rule:**
  ```text
  Reliability test programs are generated by generate_test_program, which retries with @_retry(retries=5) and temperature=0.5 to obtain fresh programs, renames conflicting output fields, validates the generated program by loading it before copying files to dst_path, and writes a cleaned schema.json; preserve these generation and validation steps.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying the reliability test program generator or its validation and output-writing behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-6de69b5f84b31cbacd4f609b.md)

## Rule

- **Rule:**
  ```text
  Reliability JSON schema utilities must preserve DSPy field-type metadata through $ref expansion: expand_refs inlines $ref definitions and propagates the __dspy_field_type marker from the referencing schema onto the resolved definition.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying expand_refs or JSON schema resolution in the reliability generation utilities.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-84ad215612a371f02ff1177a.md)

## Rule

- **Rule:**
  ```text
  _json_input_to_program_input must parse a JSON string, validate it against the pydantic input schema, and return a dict keyed by the model's fields.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying reliability input conversion utilities.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-8d4d6abac8455fbf61ea0db3.md)

## Rule

- **Rule:**
  ```text
  The reliability test suite's _remove_line_from_file must rewrite the file keeping only lines whose stripped form differs from line_to_remove, so removal is whitespace-insensitive on the compared line.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when adding or modifying _remove_line_from_file in the reliability suite
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-94c41e4270e5ed310c756933.md)

## Rule

- **Rule:**
  ```text
  Generated reliability cases must be executed through `run_generated_case`, which loads the generated program, converts JSON input to program input, runs the program, and asserts each output assertion via `assert_program_output_correct`.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the generated-case runner or adding new generated reliability cases, preserve the load-convert-run-assert execution contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-9890cb1e23215765c2167c36.md)

## Rule

- **Rule:** Reliability test utilities must build a program-generation program by returning dspy.ChainOfThought(ProgramGeneration), the convention for generating DSPy test programs via chain-of-thought.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying the reliability suite's program-generation helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-b24808a98522aa39e0dacf30.md)

## Rule

- **Rule:** Generated reliability test programs must build a dspy.Signature by appending InputField/OutputField entries derived from ProgramInputs/ProgramOutputs pydantic model fields, and choose between dspy.ChainOfThought and dspy.Predict.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying or extending reliability test program generation helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-b45669588588f221ba38d6ca.md)

## Rule

- **Rule:**
  ```text
  The reliability suite's _split_schema must classify each top-level property as input only when __dspy_field_type == "input"; properties with __dspy_field_type == "output" or no field type default to outputs, so missing field-type metadata is treated as output.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when adding or modifying _split_schema or its callers in the reliability suite
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-c15f6d020c00826002a2ec29.md)

## Rule

- **Rule:**
  ```text
  The reliability test suite's program-loading helper _import_program_module_from_path must temporarily prepend the program's directory to sys.path, load the module via importlib.util.spec_from_file_location, and execute it.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying the reliability suite's program-loading helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-cc41345c7ba37f7d839d4741.md)

## Rule

- **Rule:**
  ```text
  _clean_json_schema_property must recursively strip desc, __dspy_field_type, title, prefix, and required keys from nested properties to produce the canonical cleaned schema shape.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying reliability schema-cleaning helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-da77f61bd5902af08b458d0c.md)

## Rule

- **Rule:**
  ```text
  _remove_comments_from_file must drop only lines whose stripped form starts with '#', preserving inline trailing comments.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying comment stripping behavior in reliability generation utilities.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-deb99f0f07ea145095bc2807.md)

## Rule

- **Rule:** Reliability schema helpers must fully dereference signature JSON schemas by popping $defs and expanding refs before validation.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying reliability test helpers that prepare signature JSON schemas for validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-e160aa4b31f91f3e80211d12.md)

## Rule

- **Rule:**
  ```text
  generate_models must invoke datamodel-code-generator with enum_field_as_literal='one', field_constraints=True, use_annotated=False, then strip the __future__ annotations import and generated comments.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying reliability model generation or its post-processing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-e9cc1af11a9f7d74fee5e884.md)

## Rule

- **Rule:**
  ```text
  Reliability schema cleaning must strip DSPy-internal keys: _clean_schema recursively removes '__dspy_field_type' and 'title' keys from JSON schema properties, defining the canonical schema shape used by reliability generation utilities.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _clean_schema or schema normalization in the reliability generation utilities.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-f4c2e8ad2cacfcad935b8b07.md)

## Rule

- **Rule:**
  ```text
  For nested properties, _split_schema must recurse and reattach nested inputs only when the parent field type is input, and nested outputs when the parent is output or has no field type, preserving the parent's cleaned schema alongside nested properties.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when adding or modifying _split_schema handling of nested properties in the reliability suite
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-fc5fd27b838bda8848752319.md)
