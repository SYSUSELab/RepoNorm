# Constraints for `tests/reliability/generate/__init__.py`

## Rule

- **Rule:**
  ```text
  generate_test_cases reuses an existing program when _directory_contains_program is true, otherwise generates a new program, then always generates inputs under dst_path/inputs and returns load_generated_cases; preserve this reuse-then-generate flow.
  ```
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:** when modifying the reliability test case generation entry point or its program-reuse decision
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-12e6be721d327f3b9e44aafc.md)

## Rule

- **Rule:** The reliability generate package must re-export GeneratedTestCase and the generate/load helpers from tests.reliability.generate.utils, establishing the public import surface for generated reliability cases.
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:** When modifying the public import surface of the reliability generate package.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-ae49ad7fed0eb1fa4d099229.md)

## Rule

- **Rule:**
  ```text
  Reliability test discovery must treat a directory as containing a generated program only when a file named exactly `program.py` is present; do not broaden discovery to other filenames or nested layouts.
  ```
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:**
  ```text
  When modifying reliability test discovery or the generated-case loader, preserve the exact `program.py` filename requirement for a directory to be considered a program directory.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-d47bb7bd291a01bea1a6bc66.md)
