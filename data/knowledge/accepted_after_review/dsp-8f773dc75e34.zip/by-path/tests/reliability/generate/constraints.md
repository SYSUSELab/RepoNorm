# Constraints for `tests/reliability/generate`

## Rule

- **Rule:**
  ```text
  Reliability test input files must be named input<N>.json and numbered sequentially; find_max_input_number treats a missing directory as zero and matches only that filename pattern.
  ```
- **Applies to:**
  - `tests/reliability/generate/**/*.py`
- **Condition:** when generating or locating reliability test input files
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3fd51c73784bc8d7d3bb6d08.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise generated-program imports must use _temporarily_prepend_to_system_path, which copies sys.path, inserts the path at index 0, and restores the original list in finally, rather than mutating sys.path directly.
  ```
- **Applies to:**
  - `tests/reliability/generate/**/*.py`
- **Condition:** when a test needs to import a generated program by temporarily modifying sys.path
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-43c11b577f85432279e7ba01.md)

## Rule

- **Rule:**
  ```text
  Reliability test input generation programs must be built as dspy.ChainOfThought over the _TestInputsGeneration signature.
  ```
- **Applies to:**
  - `tests/reliability/generate/**/*.py`
- **Condition:** when constructing a program to generate reliability test inputs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ba82f7f624fb3027d6e06ec4.md)
