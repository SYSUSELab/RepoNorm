# Constraints for `tests/reliability/utils.py`

## Rule

- **Rule:**
  ```text
  Reliability test utilities must expose a known_failing_models decorator factory that takes a list of model names and returns a decorator allowing the wrapped reliability test to fail for those named models.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when adding or modifying reliability test utilities that mark tests as expected to fail for specific models
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-204cee86e2fa7c24390d2c24.md)

## Rule

- **Rule:**
  ```text
  parse_reliability_conf_yaml must be lru_cache'd, require model_name per model_list entry, record only entries with litellm_params, require an adapter key, and wrap any failure in a ValueError naming the config file path.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when adding or modifying reliability config parsing utilities
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-29644a209ca720295a1ba76e.md)

## Rule

- **Rule:**
  ```text
  Reliability test utilities must keep get_adapter mapping reliability_conf.adapter 'chat' to ChatAdapter and 'json' to JSONAdapter, raising ValueError for any other value.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when modifying or extending reliability test adapter selection helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-29f6b31d7c9948f916e8beaf.md)

## Rule

- **Rule:**
  ```text
  The reliability test harness must route judge evaluations through a model named 'judge' as defined by `JUDGE_MODEL_NAME`.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  When modifying the reliability test harness or judge configuration, preserve the use of `JUDGE_MODEL_NAME = 'judge'` for routing judge evaluations.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5798df13909bfd33b3dfedfd.md)

## Rule

- **Rule:**
  ```text
  The known_failing_models decorator wrapper must use functools.wraps to preserve the wrapped test function's metadata.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When adding or modifying decorators that wrap reliability test functions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6c05ed3d9c1330fddb2dfc13.md)

## Rule

- **Rule:**
  ```text
  `judge_dspy_configuration` must load `reliability_conf.yaml` relative to the test module, build an adapter and judge LM params, raise ValueError if the judge model is missing, and apply them via `dspy.settings.context` for the duration of the context.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  When modifying `judge_dspy_configuration` or its configuration loading, preserve the relative `reliability_conf.yaml` load, adapter and judge LM param construction, ValueError on missing judge model, and `dspy.settings.context` application.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9272a990afd87dc0a6682d18.md)

## Rule

- **Rule:**
  ```text
  Tests expected to fail for specific models must be marked with the known_failing_models decorator, which attaches a _known_failing_models attribute to the test function.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When marking tests as expected to fail for specific models.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c75e76a78754022ab48deadd.md)

## Rule

- **Rule:**
  ```text
  ReliabilityTestConf must remain a pydantic model with `adapter: str` and `models: dict[str, Any]` fields, defining the configuration shape consumed by reliability test runs.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When modifying the reliability test configuration model used by reliability test runs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c7e0e1d485e84cdd700c1b78.md)

## Rule

- **Rule:**
  ```text
  assert_program_output_correct normalizes grading_guidelines to a list and, under judge_dspy_configuration(), runs an LLM judge program per guideline, asserting judge_response.correct with the justification in the failure message; preserve this grading contract.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when modifying the reliability output-grading helper or its judge invocation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fcc7aefd0c3996058ffda686.md)
