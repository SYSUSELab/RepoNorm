# Constraints for `tests/reliability/test_generated.py`

## Rule

- **Rule:**
  ```text
  Generated reliability cases are run by marking the test with @pytest.mark.reliability and parametrizing over load_generated_cases(_DIR_PATH) with case names as ids.
  ```
- **Applies to:**
  - `tests/reliability/test_generated.py`
- **Condition:** When adding or modifying the test that runs generated reliability cases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b0c9914c14bd28f5d1b4abdb.md)
