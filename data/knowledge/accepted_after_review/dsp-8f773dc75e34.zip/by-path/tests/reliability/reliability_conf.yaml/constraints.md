# Constraints for `tests/reliability/reliability_conf.yaml`

## Rule

- **Rule:** The reliability test configuration sets adapter to chat.
- **Applies to:**
  - `tests/reliability/reliability_conf.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f6221a31bc4498a09950a319.md)
