# Constraints for `tests/reliability/test_pydantic_models.py::test_tool_calling_with_literals`

## Rule

- **Rule:**
  ```text
  Tool-calling tests must assert that the predicted next_tool_name is constrained to a fixed set of literal tool names, parametrized over dspy.Predict and dspy.ChainOfThought.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py::test_tool_calling_with_literals`
- **Condition:** when adding or modifying tool-calling tests that verify literal tool-name constraints
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6bf85c89335e4570a9946c5d.md)
