# Constraints for `tests/evaluate/test_metrics.py`

## Rule

- **Rule:**
  ```text
  answer_exact_match must return False when the predicted answer differs from the example answer, preserving the exact-match metric's negative case.
  ```
- **Applies to:**
  - `tests/evaluate/test_metrics.py`
- **Condition:**
  ```text
  When modifying answer_exact_match or its tests, preserve the False result when the predicted answer differs from the example answer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e34edc2ef4fec272b3279d9a.md)
