# Constraints for `tests/retrievers/test_embeddings.py`

## Rule

- **Rule:**
  ```text
  The retriever must return the top-ranked passage first, so that retriever(query_text).passages[0] equals the expected passage.
  ```
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** When modifying retriever ranking or passage ordering behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a590ef86eb6e2669e70c62b7.md)

## Rule

- **Rule:** Tests covering concurrent embeddings search must assert that search is exercised with a multi-worker ThreadPoolExecutor over repeated queries and that results preserve the original query order.
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** When modifying embeddings search concurrency behavior or the embeddings tests that cover multithreaded search.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eeb885d135e45bba4adebdda.md)
