# Constraints for `tests/test_utils/server/litellm_server.py`

## Rule

- **Rule:** The litellm test server must map substrings in request message content to specific litellm exceptions: '429' to RateLimitError, '504' to Timeout, '400' to BadRequestError, and '401' to AuthenticationError.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when adding or modifying the litellm test server's error-injection behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-081480d20db0dcf6626b9deb.md)

## Rule

- **Rule:** Tests that intercept LM calls use the repository's test litellm server, whose acompletion logs the request kwargs and returns a mock LLM response.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When adding or modifying test infrastructure that intercepts LM calls.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-0ac94bbdd2b47e42c013996d.md)

## Rule

- **Rule:** DSPyTestModel must subclass litellm's CustomLLM extension point in the litellm test server.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when defining or modifying the test model used by the litellm test server
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-0cbf6123fdae9195f42c5ee0.md)

## Rule

- **Rule:**
  ```text
  The litellm test server's astreaming must yield a single GenericStreamingChunk with finish_reason 'stop', is_finished True, text '{"output_text": "Hello!"}', tool_use None, and zero usage tokens, defining the streaming response shape tests rely on.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When modifying the litellm test server's streaming response shape.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-ad03715ef4a8fc512b0c7026.md)

## Rule

- **Rule:**
  ```text
  _append_request_to_log_file must require the LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR environment variable, raising ValueError if unset, and append a JSON blob of model and messages to the log file.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying request logging in the litellm test server
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-afb3ec70b13e0c75f364759b.md)

## Rule

- **Rule:** The test LiteLLM server's completion method must append request kwargs to a log file and return a mock LLM response, and the mock response helper must throw exceptions based on request content before returning a mocked litellm completion.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When modifying the test LiteLLM server's completion method or mock response helper.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-b079cce304c854f3ca2cb9a5.md)
