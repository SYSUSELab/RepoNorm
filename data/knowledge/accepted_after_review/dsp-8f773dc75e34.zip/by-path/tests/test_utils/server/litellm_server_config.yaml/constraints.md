# Constraints for `tests/test_utils/server/litellm_server_config.yaml`

## Rule

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model-2" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-7b5ebc4fdd4b5180f876187c.md)

## Rule

- **Rule:**
  ```text
  The litellm test server config sets num_retries to 0.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-c61a5e8707925dde8f120777.md)

## Rule

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-dd70a4415be506c37a3d0d02.md)
