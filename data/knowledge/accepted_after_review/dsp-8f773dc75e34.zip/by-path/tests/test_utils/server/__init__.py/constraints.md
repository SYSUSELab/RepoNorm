# Constraints for `tests/test_utils/server/__init__.py`

## Rule

- **Rule:**
  ```text
  `read_litellm_test_server_request_logs` must read a jsonlines file line-by-line and `json.loads` each line into a list of dicts, defining the convention for parsing LiteLLM server request logs in integration tests.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** When modifying the LiteLLM test server request log reader used by integration tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-39e8a71010efb0b8d1bfe858.md)

## Rule

- **Rule:**
  ```text
  _get_litellm_config_path must resolve litellm_server_config.yaml relative to the test utils server module directory, defining where the LiteLLM test server config is expected.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:**
  ```text
  when adding or modifying _get_litellm_config_path or the LiteLLM test server config location
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-70dc50e46b4890505e2e37e2.md)

## Rule

- **Rule:**
  ```text
  The litellm_test_server fixture must start a real LiteLLM proxy subprocess on a random port with a request-log file path passed via an environment variable, wait for the port, yield (server_url, log_file_path), and kill the process on teardown.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:**
  ```text
  when modifying or extending the litellm_test_server fixture used by integration tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-874e7716940db26d0dd7758e.md)

## Rule

- **Rule:** Server-backed tests must wait for readiness by polling host/port with socket.connect in a loop, retrying every 0.5s and raising TimeoutError naming the port and timeout on expiry.
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when adding or modifying test utilities that wait for a server to become reachable
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-a8d7b3c44d1b66b26525f8e2.md)

## Rule

- **Rule:**
  ```text
  The test server helper must allocate a free TCP port by binding a socket to ('', 0) and reading `getsockname()[1]` to avoid port collisions in server tests.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:**
  ```text
  When modifying the test server helper or adding server tests, preserve the free-port allocation convention of binding to ('', 0) and reading `getsockname()[1]`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../claims/CLAIM-b59ce517b59d875e633d5162.md)
