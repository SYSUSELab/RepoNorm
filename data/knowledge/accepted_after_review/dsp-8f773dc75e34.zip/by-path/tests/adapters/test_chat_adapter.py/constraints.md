# Constraints for `tests/adapters/test_chat_adapter.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise adapter prompt formatting must assert the exact message structure and content-entry shape produced by the adapter, including the placement of few-shot example images in the example's user message and the query image in the final user message, and the {'type':'image_url','image_url':{'url':...}} content-entry form.
  ```
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** When modifying ChatAdapter.format image handling or the chat adapter tests that cover image formatting with few-shot examples.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-022fcd40b67c6cb7eb0c3148.md)

## Rule

- **Rule:** Adapter parse failures must raise the adapter-specific parse exception (AdapterParseError for ChatAdapter, ValueError with 'Failed to parse response' for TwoStepAdapter) rather than returning a partial or empty prediction.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
  - `tests/adapters/test_two_step_adapter.py`
- **Condition:** When modifying adapter parse error handling or adding a new adapter parse-failure test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0d4dc85fecd48e166c2d2350.md)

## Rule

- **Rule:**
  ```text
  When use_native_function_calling=True, the adapter must return parsed tool_calls with the missing output field set to None when content is None, and parse content with tool_calls set to None when no tool_calls are present.
  ```
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:**
  ```text
  When modifying native function calling tool_calls handling in the chat adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3d63d1989562675e00888609.md)

## Rule

- **Rule:** ChatAdapter must fall back to JSONAdapter when its own parsing fails, returning the parsed answer from the JSONAdapter call.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** When modifying ChatAdapter parsing or its tests, preserve the fallback to JSONAdapter on parse failure and the returned parsed answer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-69862c292cd5935502e3a931.md)

## Rule

- **Rule:** Tests that assert ChatAdapter.format output with tools must expect exactly two messages (a system message with the ToolCalls description and a user message with the question, tool names, and JSON-schema-like argument descriptions), because this message structure is the adapter's formatting contract.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** When modifying or adding tests for ChatAdapter.format when tools are present.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b459e01be42f96530990f209.md)

## Rule

- **Rule:** Chat adapter tests must mock litellm response objects using litellm's ChatCompletionMessageToolCall, Choices, Function, Message, and ModelResponse types rather than ad-hoc dictionaries.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** When modifying or adding chat adapter tests that mock litellm responses.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e4a250f5367984774dc327ae.md)

## Rule

- **Rule:**
  ```text
  When ChatAdapter.format processes an ImageWrapper containing nested images, it must flatten them into separate image_url content entries in the user message, preserving each image URL.
  ```
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** modifying ChatAdapter.format handling of ImageWrapper or nested image content
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e99a62615599d5df12b2abb0.md)
