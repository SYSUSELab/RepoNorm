# Constraints for `tests/adapters/test_baml_adapter.py`

## Rule

- **Rule:**
  ```text
  BAML adapter field-structure rendering must emit the alias as a comment using COMMENT_SYMBOL when a field has an alias but no description, emit a description as a comment when present, and omit the alias comment for a regular field without an alias.
  ```
- **Applies to:**
  - `tests/adapters/test_baml_adapter.py`
- **Condition:** When modifying BAML adapter schema rendering or its tests, preserve the alias-as-comment, description-as-comment, and no-alias-comment rendering rules.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0076ededaa4044df97fd40d8.md)

## Rule

- **Rule:** Adapter tests must assert that a failed structured-output parse raises AdapterParseError or pydantic.ValidationError, preserving the accepted error surface for type-casting failures.
- **Applies to:**
  - `tests/adapters/test_baml_adapter.py`
- **Condition:** When modifying or adding adapter tests that exercise invalid field types in a completion, keep the assertion on AdapterParseError or pydantic.ValidationError.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2751b82e9c5c4092d54232ba.md)

## Rule

- **Rule:** Tests covering BAML adapter field aliases must define a DSPy signature with an alias-bearing Pydantic output model and assert that the adapter handles field aliases correctly.
- **Applies to:**
  - `tests/adapters/test_baml_adapter.py`
- **Condition:** When modifying BAML adapter alias handling or the BAML adapter tests that cover field aliases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3812947c86ced54b65c4ad27.md)

## Rule

- **Rule:** Tests for the BAML adapter must assert that output formatting honors Pydantic field aliases rather than raw field names, and must exercise dspy.Signature subclasses with typed InputField/OutputField declarations including nested Pydantic models as field types.
- **Applies to:**
  - `tests/adapters/test_baml_adapter.py`
- **Condition:** When adding or modifying BAML adapter tests that cover output formatting or structured/nested field types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-71a8a982db018bcc3ed87b16.md)

## Rule

- **Rule:**
  ```text
  BAMLAdapter tests that exercise circular model definitions must define pydantic BaseModel classes with optional forward-referenced fields (e.g. CircularModelA with an optional related_b of type CircularModelB) to validate circular reference handling.
  ```
- **Applies to:**
  - `tests/adapters/test_baml_adapter.py`
- **Condition:** When adding or modifying a BAMLAdapter test that exercises circular model definitions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7af794e2a7be8919267464c2.md)

## Rule

- **Rule:** BAMLAdapter.format must expand a dspy.History into separate messages: a two-message history yields six total messages (system + 2 history pairs + user), with each history question and answer placed in its own message content.
- **Applies to:**
  - `tests/adapters/test_baml_adapter.py`
- **Condition:** When adding or modifying a BAMLAdapter test that asserts history expansion into messages.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7f6719c3f5780cebae7a9586.md)

## Rule

- **Rule:**
  ```text
  BAMLAdapter.format must place dspy.Image URLs from an ImageWrapper into the last user message content as image_url entries, one per image.
  ```
- **Applies to:**
  - `tests/adapters/test_baml_adapter.py`
- **Condition:** When modifying BAMLAdapter image formatting or adding image handling tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aeacbdbf5d4a492aae7a39d4.md)

## Rule

- **Rule:** Adapter tests must keep BAMLAdapter.parse behaviorally identical to JSONAdapter.parse for the same completion, so BAMLAdapter continues to inherit JSONAdapter's parsing semantics.
- **Applies to:**
  - `tests/adapters/test_baml_adapter.py`
- **Condition:** When modifying BAMLAdapter parsing or its test coverage, preserve the assertion that BAMLAdapter().parse and JSONAdapter().parse return identical results for the same completion.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c51987c78140f14b08da306f.md)

## Rule

- **Rule:**
  ```text
  BAMLAdapter.format_field_structure must map Python primitive types to BAML schema strings: str->"text: string,", int->"number: int,", float->"decimal: float,", bool->"flag: boolean,".
  ```
- **Applies to:**
  - `tests/adapters/test_baml_adapter.py`
- **Condition:**
  ```text
  When modifying BAMLAdapter.format_field_structure or its tests, preserve the primitive type-to-BAML-schema-string mappings for str, int, float, and bool.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c6c638ad5e0c6b93a13da530.md)
