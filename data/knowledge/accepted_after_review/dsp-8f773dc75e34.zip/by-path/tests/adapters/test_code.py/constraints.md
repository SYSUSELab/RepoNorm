# Constraints for `tests/adapters/test_code.py`

## Rule

- **Rule:**
  ```text
  dspy.Code must support language parameterization via subscript syntax (e.g. dspy.Code["java"]), exposing .code and .language attributes and including 'Programming language: <lang>' in description().
  ```
- **Applies to:**
  - `tests/adapters/test_code.py`
- **Condition:**
  ```text
  When modifying dspy.Code language parameterization or its tests, preserve the subscript syntax, the .code and .language attributes, and the 'Programming language: <lang>' description text.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8643a8b6adedd7e202f0ef1a.md)

## Rule

- **Rule:** Tests that verify dspy.Code parsing of dirty code must assert that code.code contains only the extracted code with markdown fences and surrounding reasoning text stripped, because this extraction behavior is the parsing contract.
- **Applies to:**
  - `tests/adapters/test_code.py`
- **Condition:** When modifying or adding tests for dspy.Code parsing of code containing markdown fences or surrounding text.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fad8a1b6dc758b081b437993.md)
