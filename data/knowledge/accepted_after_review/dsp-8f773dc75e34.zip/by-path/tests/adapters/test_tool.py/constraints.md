# Constraints for `tests/adapters/test_tool.py`

## Rule

- **Rule:** Tests that exercise tool argument parsing with nested pydantic-style inputs must assert the concrete return value produced by the tool, because nested dict arguments are parsed into model instances before invocation.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying or adding tests for Tool argument parsing with nested model/dict inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-55ad88793a34680fa64958ec.md)

## Rule

- **Rule:** Tests covering async Tool construction must assert that a Tool built from an async function exposes name/desc/args derived from the function signature, including JSON-schema types and defaults, and that acall awaits the underlying coroutine returning its result.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying async Tool construction or the tool tests that cover async function wrapping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e989eaadb016d1937560cd8.md)

## Rule

- **Rule:**
  ```text
  Tool calls must serialize into {'type': 'tool_calls', 'tool_calls': [...]} structures, including the empty case and multiple calls with function name and arguments.
  ```
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying tool call serialization format or adding tool call test cases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8ee1f391d9c5194b66fde2ef.md)
