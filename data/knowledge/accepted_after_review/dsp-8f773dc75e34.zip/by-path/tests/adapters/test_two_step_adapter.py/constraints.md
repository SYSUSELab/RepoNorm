# Constraints for `tests/adapters/test_two_step_adapter.py`

## Rule

- **Rule:** Adapter parse failures must raise the adapter-specific parse exception (AdapterParseError for ChatAdapter, ValueError with 'Failed to parse response' for TwoStepAdapter) rather than returning a partial or empty prediction.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
  - `tests/adapters/test_two_step_adapter.py`
- **Condition:** When modifying adapter parse error handling or adding a new adapter parse-failure test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0d4dc85fecd48e166c2d2350.md)

## Rule

- **Rule:** TwoStepAdapter.parse must use a separate extraction LM to parse the first LM response into structured fields, returning the parsed tags and confidence.
- **Applies to:**
  - `tests/adapters/test_two_step_adapter.py`
- **Condition:** When modifying TwoStepAdapter.parse or its tests, preserve the use of a separate extraction LM to parse the first LM response into structured fields and return parsed tags and confidence.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2b4cf7101dd563be13b3c224.md)

## Rule

- **Rule:** TwoStepAdapter tests must assert the two-step message protocol: the main LM receives a system message listing input and output fields plus a user message with the question, while the extraction LM receives a system message listing text/solution/answer fields plus a user message containing the main LM's raw text output.
- **Applies to:**
  - `tests/adapters/test_two_step_adapter.py`
- **Condition:** When adding or modifying a TwoStepAdapter test that asserts the message protocol between the main LM and the extraction LM.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d5a45c1f077fd21b4bab455b.md)
