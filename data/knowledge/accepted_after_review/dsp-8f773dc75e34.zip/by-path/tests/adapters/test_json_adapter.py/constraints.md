# Constraints for `tests/adapters/test_json_adapter.py`

## Rule

- **Rule:** JSON adapter tests must assert that tool definitions are serialized into the user message with their argument schemas and that the litellm completion call receives a tools argument of function-type dicts containing name, description, and JSON-schema parameters with required fields.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSON adapter tool-call formatting or its tests, preserve the assertion that tool definitions appear in the user message with argument schemas and that the litellm tools argument contains function-type dicts with name, description, and JSON-schema parameters including required fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0d4d75a9ea858150de1bdec0.md)

## Rule

- **Rule:**
  ```text
  Tests covering JSON adapter prompt formatting must assert that the system prompt contains numbered input field descriptions, an output field description, the '[[ ## user ## ]]' and '[[ ## question ## ]]' markers, and a JSON output schema instruction, and that the user message formats the pydantic input as JSON under the same markers.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSONAdapter prompt formatting or the JSON adapter tests that cover pydantic model formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-16066195f03c8dd362cbc29e.md)

## Rule

- **Rule:**
  ```text
  Adapter tests must assert the adapter's sync call returns a list of parsed output dicts, e.g. calling ChatAdapter with a DummyLM returns [{"answer": "Paris"}].
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When adding or modifying an adapter test that asserts the sync call return shape.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a37f77581921818af8673b5.md)

## Rule

- **Rule:**
  ```text
  JSON adapter image tests must assert that formatting a signature with two few-shot image examples and one input image yields exactly 6 messages (1 system, 2 user/assistant pairs, 1 user), with each image_url content block appearing at messages[1], [3], and [5].
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:**
  ```text
  When modifying JSON adapter image formatting or its tests, preserve the assertion that two few-shot image examples plus one input image produce exactly 6 messages with image_url blocks at indices 1, 3, and 5.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2efbab8eb606fdcf5145a787.md)

## Rule

- **Rule:**
  ```text
  Tests for the JSON adapter must assert that with use_native_function_calling=False, _get_structured_outputs_response_format is never called and litellm.completion is called once with response_format={'type': 'json_object'}, documenting the fallback to JSON mode.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When adding or modifying JSON adapter tests that cover the non-native function calling fallback path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6ac7cf92154a6b75b1ffd206.md)

## Rule

- **Rule:**
  ```text
  JSONAdapter must retry with response_format={'type': 'json_object'} when the first structured-output call raises, preserving the fallback contract.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:**
  ```text
  When modifying JSONAdapter structured-output handling or its tests, preserve the retry with response_format={'type': 'json_object'} after a first structured-output failure.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8d3fe6e7014c2b33ebeab5f8.md)

## Rule

- **Rule:** JSON adapter tests must declare signatures with a dspy.Image input field and a text output field, indicating the adapter is expected to serialize image inputs.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSON adapter image serialization or adding image input tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bd0b4cbdbcff93c9cc6184b9.md)

## Rule

- **Rule:**
  ```text
  Tests covering JSON adapter fallback behavior must assert that on structured-output failure the adapter retries with JSON mode, using a pydantic BaseModel response_format on the first call and {"type": "json_object"} on the second, with parsing succeeding on the second call.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSON adapter fallback behavior or the JSON adapter tests that cover structured-output failure recovery.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d29234b883454e3f02ee0134.md)

## Rule

- **Rule:**
  ```text
  Adapter tests that exercise structured-output fallback must verify that the first litellm.completion call uses a pydantic.BaseModel response_format and the retry falls back to {'type':'json_object'}.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying or adding tests for JSONAdapter structured-output fallback behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dadd335a370636dcdc568db2.md)

## Rule

- **Rule:** JSON adapter tests must assert that RuntimeError and ValueError raised by litellm.acompletion propagate out of program.acall with their original messages intact.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSON adapter async error handling or its tests, preserve the assertion that RuntimeError and ValueError from litellm.acompletion propagate through program.acall with original messages intact.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f8cf0fcc39a29e0ab0c4a364.md)
