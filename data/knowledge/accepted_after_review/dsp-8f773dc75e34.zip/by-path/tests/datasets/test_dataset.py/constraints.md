# Constraints for `tests/datasets/test_dataset.py`

## Rule

- **Rule:**
  ```text
  When CSVDataset is constructed with input_keys, those keys must be stored on the example and drive the example's inputs() output.
  ```
- **Applies to:**
  - `tests/datasets/test_dataset.py`
- **Condition:**
  ```text
  modifying CSVDataset input_keys handling or example inputs() derivation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b0f7cdaea3ca676153e54adc.md)

## Rule

- **Rule:** Dataset tests must define module-level CSV fixture data with content,question,answer columns, because this column layout is the stable fixture convention the Dataset tests parse.
- **Applies to:**
  - `tests/datasets/test_dataset.py`
- **Condition:** When modifying or adding dataset tests that need CSV fixture data.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ce5ea24c713ae3b0efe1c043.md)
