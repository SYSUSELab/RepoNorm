# Constraints for `tests/streaming/test_streaming.py`

## Rule

- **Rule:**
  ```text
  Streaming tests must drive the streaming path with a fixture that yields ModelResponseStream chunks whose Delta content is split across multiple chunks and whose final chunk carries the literal '[[ ## completed ## ]]' sentinel; the concatenated deltas must reconstruct the full message.
  ```
- **Applies to:**
  - `tests/streaming/test_streaming.py`
- **Condition:** When adding or modifying a streaming test that asserts chunk-by-chunk reconstruction of a model response.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-467579a66873b38f592eb733.md)

## Rule

- **Rule:** For an async streamified program, StatusMessage timestamps around a tool call must differ by at least 1 second when the tool explicitly sleeps for 1 second, verifying non-blocking status messages.
- **Applies to:**
  - `tests/streaming/test_streaming.py`
- **Condition:** When modifying async streaming status message emission or adding non-blocking status tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-65a8f47351c992b81aac1333.md)

## Rule

- **Rule:**
  ```text
  Streaming tests must exercise custom dspy.Module subclasses (not only built-in predictors) and must use fixtures that emit Gemini-style chunks with the [[ ## field ## ]] and [[ ## completed ## ]] delimiters, documenting the wire format the streaming parser must recognize.
  ```
- **Applies to:**
  - `tests/streaming/test_streaming.py`
- **Condition:** When adding or modifying streaming tests that cover custom Module subclasses or Gemini-style chunk parsing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6e6576fc70c2eb5fddaf5108.md)

## Rule

- **Rule:**
  ```text
  Sync streaming tests must assert that apply_sync_streaming yields exactly two StatusMessage values with specific tool-calling messages, defining the expected status message sequence for a tool-using program.
  ```
- **Applies to:**
  - `tests/streaming/test_streaming.py`
- **Condition:**
  ```text
  When modifying or adding sync streaming tests for tool-using programs, keep the assertion that apply_sync_streaming yields exactly two StatusMessage values with the expected tool-calling messages.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-995e269b274d8b36f11e7eed.md)

## Rule

- **Rule:**
  ```text
  When a streaming call has multiple StreamListeners, StreamResponse chunks must be emitted in per-listener field order: all chunks for the first listener's field first, then the second listener's field, with the final chunk marked is_last_chunk=True and belonging to the last listener's field.
  ```
- **Applies to:**
  - `tests/streaming/test_streaming.py`
- **Condition:** modifying streaming chunk emission or StreamListener handling that determines chunk order and last-chunk marking
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc5aac22adfd2ed4699595d4.md)

## Rule

- **Rule:**
  ```text
  Streaming responses must emit SSE-style chunks where every chunk starts with 'data: ', the prediction payload is JSON-encoded, and the final chunk is exactly 'data: [DONE]\n\n'.
  ```
- **Applies to:**
  - `tests/streaming/test_streaming.py`
- **Condition:** When modifying streaming response formatting or adding streaming protocol tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-db2b5b4cd95be4e72b0c511d.md)

## Rule

- **Rule:** Streaming tests must exercise XML tag boundaries split across individual stream chunks, with one ModelResponseStream per token fragment.
- **Applies to:**
  - `tests/streaming/test_streaming.py`
- **Condition:** When modifying streaming chunk granularity handling or adding XML streaming tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f069f15882dc019d66cc0e64.md)

## Rule

- **Rule:**
  ```text
  Streaming tests that configure a StreamListener with allow_reuse=True must assert the listener fires once per streamed message and that concatenated chunks equal the repeated message text.
  ```
- **Applies to:**
  - `tests/streaming/test_streaming.py`
- **Condition:** When adding or modifying a streaming test that exercises StreamListener reuse behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-faa88b12da9b420f98530436.md)
