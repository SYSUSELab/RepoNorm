# Constraints for `tests/clients/test_databricks.py`

## Rule

- **Rule:** Tests for the Databricks client must be skipped unless the Databricks SDK is importable and WorkspaceClient() can be constructed, and must document that they require valid Databricks credentials and are only used for manual testing.
- **Applies to:**
  - `tests/clients/test_databricks.py`
- **Condition:** When adding or modifying Databricks client tests that require credentials or the Databricks SDK.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c2d2b113783d36297374d62c.md)
