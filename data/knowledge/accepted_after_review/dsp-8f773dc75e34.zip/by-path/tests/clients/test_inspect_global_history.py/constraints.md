# Constraints for `tests/clients/test_inspect_global_history.py`

## Rule

- **Rule:**
  ```text
  When inspect_history(n) is called with n larger than the number of recorded history entries, GLOBAL_HISTORY length must remain unchanged; the call must not pad or error.
  ```
- **Applies to:**
  - `tests/clients/test_inspect_global_history.py`
- **Condition:**
  ```text
  modifying inspect_history or GLOBAL_HISTORY handling when the requested count exceeds available entries
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-52d4406b439c0a9592dbf4a1.md)

## Rule

- **Rule:**
  ```text
  Tests that assert dspy.inspect_history() behavior must treat GLOBAL_HISTORY as a module-level list reset by configuration: with a fresh DummyLM([]) and no prior calls, inspect_history() leaves GLOBAL_HISTORY as an empty list.
  ```
- **Applies to:**
  - `tests/clients/test_inspect_global_history.py`
- **Condition:**
  ```text
  When adding or modifying a test that asserts inspect_history() behavior with a fresh DummyLM and no prior calls.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-988217083d0492313a7be43b.md)
