# Constraints for `tests/teleprompt/test_copro_optimizer.py`

## Rule

- **Rule:** COPRO optimizer tests must use dspy.ChainOfThought rather than dspy.Predict as the predictor, because COPRO does not work with dspy.Predict.
- **Applies to:**
  - `tests/teleprompt/test_copro_optimizer.py`
- **Condition:** When modifying COPRO optimizer tests or their predictor setup, use dspy.ChainOfThought instead of dspy.Predict.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7a4fc98150f3d1ba6c53576a.md)

## Rule

- **Rule:**
  ```text
  COPRO with track_stats=True must attach total_calls, results_best, and results_latest to the compiled student, preserving the statistics-tracking contract.
  ```
- **Applies to:**
  - `tests/teleprompt/test_copro_optimizer.py`
- **Condition:**
  ```text
  When modifying COPRO statistics tracking or its tests, preserve the attachment of total_calls, results_best, and results_latest to the compiled student when track_stats=True.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aaa748cdc5594e649854b985.md)

## Rule

- **Rule:**
  ```text
  Tests that verify COPRO statistics tracking must assert that the optimized student receives total_calls and results_best attributes when track_stats is enabled, because these attributes are the observable contract of the statistics-tracking feature.
  ```
- **Applies to:**
  - `tests/teleprompt/test_copro_optimizer.py`
- **Condition:** When modifying or adding tests for COPRO optimizer statistics tracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b68c6be3c1b09951df58491d.md)
