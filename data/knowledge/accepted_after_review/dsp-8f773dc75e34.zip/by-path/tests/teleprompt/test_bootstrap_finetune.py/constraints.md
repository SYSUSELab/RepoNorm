# Constraints for `tests/teleprompt/test_bootstrap_finetune.py`

## Rule

- **Rule:** BootstrapFinetune tests must assert that multitask defaults to True when only metric is supplied, so callers can rely on multitask being enabled by default.
- **Applies to:**
  - `tests/teleprompt/test_bootstrap_finetune.py`
- **Condition:** When modifying or adding BootstrapFinetune initialization tests, keep the assertion that multitask defaults to True when only metric is supplied.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4c7f574947ac74ec3db46a66.md)
