# Constraints for `tests/teleprompt/test_bootstrap.py`

## Rule

- **Rule:**
  ```text
  The bootstrap test helper's forward must delegate **kwargs to self.predictor, a stable wrapper convention in teleprompt tests.
  ```
- **Applies to:**
  - `tests/teleprompt/test_bootstrap.py`
- **Condition:** When adding or modifying bootstrap test helpers that wrap a predictor.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bec73fdcb865a9bc7f54ee96.md)

## Rule

- **Rule:**
  ```text
  BootstrapFewShot tests must assert that with max_bootstrapped_demos=1 and max_labeled_demos=1 exactly one demo is produced matching the trainset example, and that DummyLM(follow_examples=True) returns the matching example's output rather than its next queued response.
  ```
- **Applies to:**
  - `tests/teleprompt/test_bootstrap.py`
- **Condition:**
  ```text
  When modifying or adding BootstrapFewShot effectiveness tests, keep the assertion that exactly one demo is produced and that DummyLM(follow_examples=True) returns the matching example's output.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e4ba4ec428c9c7a9db505c67.md)
