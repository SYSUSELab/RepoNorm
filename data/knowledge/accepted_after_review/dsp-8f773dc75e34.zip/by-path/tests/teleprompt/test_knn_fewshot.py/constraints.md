# Constraints for `tests/teleprompt/test_knn_fewshot.py`

## Rule

- **Rule:** KNNFewShot initialization tests must assert that the KNN k value and trainset size are set from the fixture, defining the expected initialization state.
- **Applies to:**
  - `tests/teleprompt/test_knn_fewshot.py`
- **Condition:** When modifying or adding KNNFewShot initialization tests, keep the assertion that the KNN k value and trainset size are set from the fixture.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6ed6a9c54b5e46a49c7b4f6c.md)
