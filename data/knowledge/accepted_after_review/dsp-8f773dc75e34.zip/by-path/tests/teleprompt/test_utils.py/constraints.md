# Constraints for `tests/teleprompt/test_utils.py`

## Rule

- **Rule:**
  ```text
  When eval_candidate_program is called with batch_size, it must call evaluate exactly once with a devset of length batch_size and callback_metadata {"metric_key": "eval_minibatch"}; when batch_size exceeds the trainset length, it must call evaluate once with the full devset and callback_metadata {"metric_key": "eval_full"}.
  ```
- **Applies to:**
  - `tests/teleprompt/test_utils.py`
- **Condition:**
  ```text
  modifying eval_candidate_program batching or its callback_metadata metric_key values
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0aa49d2daa574911d23c3a11.md)
