# Constraints for `tests/metadata/test_metadata.py`

## Rule

- **Rule:**
  ```text
  The build-and-publish-test-pypi job creates a venv named test_before_testpypi, installs the locally built wheel plus pytest and pytest-asyncio, and runs `pytest tests/metadata/test_metadata.py tests/predict`.
  ```
- **Applies to:**
  - `tests/metadata/test_metadata.py`
  - `tests/predict/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1446fb3682a8374d02215ba9.md)

## Rule

- **Rule:**
  ```text
  The workflow tests the locally built wheel by activating the test environment, installing `dist/*.whl` with pytest and pytest-asyncio, running `pytest tests/metadata/test_metadata.py tests/predict`, then deactivating and removing the test environment.
  ```
- **Applies to:**
  - `tests/metadata/test_metadata.py`
  - `tests/predict/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7b628a278bab76db5ae55d8a.md)
