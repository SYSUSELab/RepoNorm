# Constraints for `tests/propose/test_grounded_proposer.py`

## Rule

- **Rule:**
  ```text
  The grounded proposer test must parametrize demo_candidates over None and a nested list of Example demos, asserting propose_instruction_for_predictor returns the proposed instruction in both cases.
  ```
- **Applies to:**
  - `tests/propose/test_grounded_proposer.py`
- **Condition:**
  ```text
  When modifying grounded proposer demo_candidates handling or adding proposer tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-035200ea3e39a253b4940cab.md)
