# Constraints for `tests/utils/test_syncify.py`

## Rule

- **Rule:**
  ```text
  syncify-wrapped async programs must remain compatible with optimizer compilation, preserving the optimized program's demo count equal to max_bootstrapped_demos for both in_place=True and in_place=False.
  ```
- **Applies to:**
  - `tests/utils/test_syncify.py`
- **Condition:** When modifying syncify or its interaction with optimizer compilation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44504a84a1ec3a2696bf3302.md)

## Rule

- **Rule:** The syncify test defines a MyProgram subclass of dspy.Module, exercising syncification of a module program; preserve this module-program syncification coverage when changing syncify behavior.
- **Applies to:**
  - `tests/utils/test_syncify.py`
- **Condition:** when modifying syncify behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4e4fb320e2d7535942e72752.md)

## Rule

- **Rule:**
  ```text
  The syncify test module must construct a `dspy.Predict('question->answer')` in `__init__` to exercise syncify against a Predict program.
  ```
- **Applies to:**
  - `tests/utils/test_syncify.py`
- **Condition:**
  ```text
  When modifying syncify tests, preserve the construction of a `dspy.Predict('question->answer')` in `__init__` to exercise syncify against a Predict program.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-903fee1a8691195e5d94d7c3.md)

## Rule

- **Rule:**
  ```text
  `dspy.syncify` must produce a synchronous callable that maps inputs to outputs (1->2, 2->3) and, when `in_place=False`, must not mutate the original program.
  ```
- **Applies to:**
  - `tests/utils/test_syncify.py`
- **Condition:**
  ```text
  When modifying syncify tests or the syncify wrapper behavior, preserve the input-to-output mapping and the non-mutation guarantee when `in_place=False`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ab317ebd13290f20e4b855e8.md)
