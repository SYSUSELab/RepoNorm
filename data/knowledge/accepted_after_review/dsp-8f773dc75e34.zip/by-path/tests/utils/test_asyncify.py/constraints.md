# Constraints for `tests/utils/test_asyncify.py`

## Rule

- **Rule:**
  ```text
  The async limiter must remain a process-wide singleton whose total_tokens capacity tracks the async_max_workers setting, defaulting to 8 and reconfiguring to the context value.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:**
  ```text
  When modifying async limiter behavior or the async_max_workers context setting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4449b6fc762f69deb3f30984.md)

## Rule

- **Rule:**
  ```text
  Asyncify tests must launch n concurrent ask_the_question coroutines via asyncio.gather to exercise concurrent async behavior.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** when adding or modifying asyncify tests that exercise concurrent async behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6dc698ef7e573062b0d65eac.md)

## Rule

- **Rule:**
  ```text
  Asyncify tests must assert that total runtime for number_of_tasks with async_max_workers=capacity falls strictly between floor(number_of_tasks/capacity)*wait and ceil(number_of_tasks/capacity)*wait + 2*wait, encoding the expected asyncify concurrency bound.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** when adding or modifying asyncify tests that verify concurrency bounds
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a58abc0a2f3d18302f406cb7.md)
