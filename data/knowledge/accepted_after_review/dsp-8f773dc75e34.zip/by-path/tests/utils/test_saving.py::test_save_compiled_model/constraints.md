# Constraints for `tests/utils/test_saving.py::test_save_compiled_model`

## Rule

- **Rule:**
  ```text
  Save/load round-trip tests for compiled Predict programs must assert that demos and signature survive save(save_program=True) followed by dspy.load, and must carry the extra pytest marker.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py::test_save_compiled_model`
- **Condition:** when adding or modifying save/load round-trip tests for compiled programs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1180e6df051dea65cf320b06.md)
