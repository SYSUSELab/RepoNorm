# Constraints for `tests/utils/test_mcp.py`

## Rule

- **Rule:**
  ```text
  tests/utils/test_mcp.py skips the entire module at import time when the 'mcp' package is not installed, using pytest.skip with allow_module_level=True; preserve this module-level skip convention for optional dependencies.
  ```
- **Applies to:**
  - `tests/utils/test_mcp.py`
- **Condition:** when adding or modifying tests that depend on an optional package
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-67c0d93751a4e85aa858b3b8.md)

## Rule

- **Rule:**
  ```text
  MCP tool conversion tests must assert the name/desc/args/arg_types/arg_desc mapping, the 'No description provided. (Required)' fallback for missing descriptions, stringified acall results, and RuntimeError with 'Failed to call a MCP tool: ...' on tool errors.
  ```
- **Applies to:**
  - `tests/utils/test_mcp.py`
- **Condition:**
  ```text
  when adding or modifying tests for convert_mcp_tool schema mapping and error handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-75e81e8b540c03c9c998d671.md)
