# Constraints for `tests/utils/test_parallelizer.py`

## Rule

- **Rule:** Parallelizer tests must inject a deterministic single-item failure by raising ValueError only for item 3, to exercise error propagation.
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** when adding or modifying parallelizer tests that exercise error propagation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3827cebae8d38a8f109d4843.md)

## Rule

- **Rule:**
  ```text
  Parallelizer tests must assert that ParallelExecutor.execute preserves input order in results and that exceeding max_errors raises an Exception matching 'Execution cancelled due to errors or interruption.'.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:**
  ```text
  when modifying or extending ParallelExecutor tests covering result ordering or max_errors failure behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3e18689654f4b29444cdb57f.md)

## Rule

- **Rule:**
  ```text
  The parallel execution speed test must assert that ParallelExecutor(num_threads=5).execute(task, data) over five items completes in less than len(data) seconds, encoding a timing-based expectation for parallel execution.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** When modifying parallel execution speed tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b9c2d483002b0c9d47d37360.md)

## Rule

- **Rule:**
  ```text
  ParallelExecutor.execute must return results in input order with None in place of failed tasks when max_errors is not exceeded.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** When modifying ParallelExecutor.execute result handling or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f751972de1ca9dba9b7e7f3c.md)
