# Constraints for `tests/utils/test_unbatchify.py`

## Rule

- **Rule:**
  ```text
  Unbatchify tests must assert that the batch function is not invoked until max_batch_size submissions accumulate, and that each full batch is passed as a list in submission order.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:**
  ```text
  when modifying or extending unbatchify batching tests around max_batch_size triggering
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-694a051f63a11a54249cc338.md)

## Rule

- **Rule:**
  ```text
  The test asserts that Unbatchify with max_batch_size=5 and max_wait_time=0.15 does not invoke the batch function before the wait time elapses, then batches both submitted items in a single call returning [101, 201], verifying timeout-triggered batching semantics; preserve this timeout-triggered batching behavior.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** when modifying Unbatchify batching or timeout behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9c63d0e4cd950d4bec2b672b.md)
