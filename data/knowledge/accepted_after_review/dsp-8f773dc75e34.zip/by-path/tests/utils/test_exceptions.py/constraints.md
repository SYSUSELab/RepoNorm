# Constraints for `tests/utils/test_exceptions.py`

## Rule

- **Rule:** AdapterParseError string formatting must include the custom message, adapter name, raw LM response, expected output fields, and (when available) the actually parsed output fields in the fixed multi-line format.
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:** When modifying or extending AdapterParseError formatting or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8314fdef8ce4f945c7bdc937.md)

## Rule

- **Rule:** Adapter parse failures must preserve the exact AdapterParseError message format that includes the adapter name, the LM response, and the list of expected output fields.
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:** When changing AdapterParseError construction or the adapter parse-failure path that produces this message.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b0c9e6ef8ef527cc0582ab45.md)
