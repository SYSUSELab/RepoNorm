# Constraints for `tests/utils/test_saving.py`

## Rule

- **Rule:** Tests that save and load user-defined dspy.Module subclasses must define a CustomModel subclass of dspy.Module and exercise save/load behavior on it, not only on built-in modules.
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when adding or modifying a test that saves and loads a user-defined dspy.Module subclass
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-28ef588596dd19881ca38c6d.md)

## Rule

- **Rule:** The saving test signature uses datetime.date input fields and an int output field with a description, exercising serialization of date-typed signature fields; preserve date-typed field serialization when changing signature saving.
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when modifying signature serialization or saving behavior involving date-typed fields
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5aea5d3c89bca6a76fef83b2.md)

## Rule

- **Rule:** Tests that load a saved Predict with mismatched python/dspy/cloudpickle versions must assert that exactly three 'There is a mismatch of' warnings are logged and that a Predict with an equal signature still loads.
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when adding or modifying a test that loads a saved Predict with mismatched python/dspy/cloudpickle versions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6cf7c374ec204b1aa9f323fd.md)

## Rule

- **Rule:**
  ```text
  The custom-model save/load test must assert round-trip fidelity: after model.save(tmp_path, save_program=True) and dspy.load(tmp_path), the loaded object is a CustomModel with the same number of predictors and matching predictor signatures.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** When modifying custom-model save/load round-trip tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ab7c683d36cfd92f5767aa8d.md)

## Rule

- **Rule:**
  ```text
  Tests that save and load a dspy.Predict with save_program=True must assert that metadata.json and program.pkl are produced and that dspy.load returns a dspy.Predict whose signature equals the original's.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:**
  ```text
  when adding or modifying a test that saves and loads a dspy.Predict with save_program=True
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f3d37718b0222c245297685c.md)

## Rule

- **Rule:**
  ```text
  Saving a Predict with save_program=True and reloading via dspy.load preserves the signature, including instructions added via with_instructions; keep this save/load signature fidelity when changing saving or loading behavior.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when modifying program saving or loading behavior that affects signature preservation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fa5801574403225716820232.md)
