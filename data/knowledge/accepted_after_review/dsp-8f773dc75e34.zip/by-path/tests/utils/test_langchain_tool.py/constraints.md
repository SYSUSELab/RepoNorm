# Constraints for `tests/utils/test_langchain_tool.py`

## Rule

- **Rule:**
  ```text
  The langchain tool conversion test must verify that convert_langchain_tool maps a custom Pydantic class argument into args with a JSON schema object, arg_types mapping to the class, and arg_desc 'No description provided. (Required)', and that acall returns the tool result.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:** When modifying langchain tool conversion tests for custom Pydantic class arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7e1fc5127a0fc862df828265.md)

## Rule

- **Rule:**
  ```text
  convert_langchain_tool must map a langchain tool's name, description, args schema, arg_types, and arg_desc, and the converted tool's acall must invoke the underlying function.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:** When modifying langchain tool conversion or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae3f3b5937a623c105a6147c.md)
