# Constraints for `tests/utils/test_usage_tracker.py`

## Rule

- **Rule:**
  ```text
  The usage tracker test module imports UsageTracker and track_usage from dspy.utils.usage_tracker and asserts cumulative token accounting (e.g., 0 + 10 + 10); preserve cumulative token accounting when changing usage tracking.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:** when modifying usage tracking behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-284dcb6a6a2b726401dd0af1.md)

## Rule

- **Rule:**
  ```text
  Usage-tracking tests must assert that get_total_tokens() returns a dict keyed by LM/model identifier with per-model total_tokens values, preserving the multi-model aggregation contract.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:**
  ```text
  when modifying or extending usage-tracking tests that exercise track_usage and get_total_tokens
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3ec59a60f1da6b6d6bdde5db.md)

## Rule

- **Rule:**
  ```text
  UsageTracker merging must preserve previously unseen keys so that adding prompt_tokens then completion_tokens for the same model yields a total containing both keys.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:** when adding or modifying tests for UsageTracker merge behavior across entries with disjoint keys
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-55cb9847e8957bf6e637720b.md)

## Rule

- **Rule:**
  ```text
  The usage tracker merge test must assert that UsageTracker.add_usage merges entries across calls, summing prompt/completion/total tokens and merging nested detail dicts while tolerating None detail values, with expected totals 2717/246/2963 and preserved cached/audio/reasoning/accepted/rejected token details.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:** When modifying usage tracker merge tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a3f409897e41df4b76663de0.md)

## Rule

- **Rule:**
  ```text
  UsageTracker.get_total_tokens must aggregate per-model token counts and nested prompt/completion token detail fields across multiple add_usage entries, summing cached, audio, reasoning, accepted, and rejected token details.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:** When modifying UsageTracker aggregation of per-model and nested token detail fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ec37c43efb99e49ff77d18a5.md)

## Rule

- **Rule:**
  ```text
  UsageTracker.add_usage must store the exact usage entry dict under the model key, with usage_data[model] holding a list of length 1 after a single add.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:**
  ```text
  when adding or modifying tests for UsageTracker.add_usage storage behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f9806d45ff1dd63949888814.md)
