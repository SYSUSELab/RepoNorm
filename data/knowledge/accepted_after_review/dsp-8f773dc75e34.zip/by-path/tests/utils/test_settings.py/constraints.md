# Constraints for `tests/utils/test_settings.py`

## Rule

- **Rule:** The dspy.configure test must assert that lm, adapter, and callbacks settings are reflected on dspy.settings after configuration.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** When modifying dspy.configure settings tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-03cc60f717c22e9fbd286e51.md)

## Rule

- **Rule:** Tests that exercise dspy.context must assert that the previously configured LM and callbacks are restored after the context block exits, while the context LM and empty callbacks apply inside the block.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that enters a dspy.context block and configures a prior LM/callbacks via dspy.configure before the block
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0739bb237f22d88a3655bc3b.md)

## Rule

- **Rule:** Tests that run dspy.context inside thread workers must assert that after the workers finish, dspy.settings.lm.model and callbacks remain those configured by the outer dspy.configure, proving thread workers do not leak context changes.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that runs dspy.context inside a ThreadPoolExecutor or other thread workers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-07b12a0ff8d0ca66661bce18.md)

## Rule

- **Rule:**
  ```text
  test_dspy_context_with_dspy_parallel shows that dspy.Parallel runs each input pair under its own context: the France question uses the context LM gpt-4o-mini while the Germany question uses the configured gpt-4o, and the main thread's dspy.settings.lm remains gpt-4o after the parallel call; preserve this per-pair context isolation.
  ```
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying dspy.Parallel or context handling that affects per-pair LM isolation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3fb0594fea92db7a0a849ddd.md)

## Rule

- **Rule:** Settings tests must verify that dspy.settings.lm.model equals the model of the LM entered via dspy.context, confirming context-scoped LM overrides are visible inside the context.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying settings tests that verify context-scoped LM overrides
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-46c39bcff588dd42970eb320.md)

## Rule

- **Rule:** dspy.configure must raise RuntimeError when called from a different async task than the initial one, with the message 'dspy.settings.configure(...) can only be called from the same async'.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** When modifying dspy.configure async-task restrictions or their tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-52b759576c79eb0efed1d4ec.md)

## Rule

- **Rule:** Settings tests must assert that dspy.configure raises RuntimeError with message 'dspy.settings.configure(...) can only be called from the same async' when invoked from a different async task than the initial one.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying or extending settings tests covering async-task restrictions on dspy.configure
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-66335a91b221a7567335f73b.md)

## Rule

- **Rule:** Tests for dspy.context must assert context-local isolation of the selected LM and trace, verifying dspy.settings.lm.model and dspy.settings.trace reflect only the context's values.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying tests that verify dspy.context isolates LM selection and trace state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6c6405ff72b9500384d3b269.md)

## Rule

- **Rule:** Tests that exercise dspy.context in a different async task from the initial one must enter dspy.context with an LM inside an async function, since dspy.context is allowed in different async tasks from the initial one.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that uses dspy.context inside an async task other than the initial one
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8802b6b21bfbdb30f5e47929.md)

## Rule

- **Rule:** Tests that exercise dspy.configure thread/task restrictions must assert that configure is forbidden in child threads while remaining callable repeatedly in the same async task and usable via dspy.context in other tasks.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying tests covering dspy.configure call-site restrictions across threads and async tasks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b8237e583a6c7e1ef448cbe9.md)

## Rule

- **Rule:** dspy.context must isolate settings across async tasks: concurrent module.acall calls under a context use the context's LM while the outer dspy.settings.lm and trace remain unchanged.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** When modifying dspy.context behavior or its tests involving async tasks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c4a7ee31c5411976a68e296c.md)
