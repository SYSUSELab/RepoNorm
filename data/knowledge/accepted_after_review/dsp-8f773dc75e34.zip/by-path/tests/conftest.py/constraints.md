# Constraints for `tests/conftest.py`

## Rule

- **Rule:**
  ```text
  Async tests in this repository must run under the asyncio backend via the anyio_backend fixture defined in tests/conftest.py.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** when adding or modifying async tests or the shared anyio backend fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-32f467010c83c5f564ee438a.md)

## Rule

- **Rule:**
  ```text
  The lm_for_test fixture must read the LM_FOR_TEST environment variable and skip the test when it is unset, making LM-dependent tests opt-in via environment configuration.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  When modifying the lm_for_test fixture or adding LM-dependent tests that rely on it.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-38e36580a0fb627583439811.md)

## Rule

- **Rule:**
  ```text
  The test suite must define SKIP_DEFAULT_FLAGS for reliability, extra, and llm_call and import the litellm test server fixture, establishing the default marker-based test selection convention.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When modifying the root test conftest's default marker selection or litellm server fixture import.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-39456cafdbd8194491bf4c69.md)

## Rule

- **Rule:**
  ```text
  pytest_collection_modifyitems must skip items whose keyword matches a SKIP_DEFAULT_FLAGS entry unless the corresponding --flag option is passed.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When modifying pytest collection hooks or flag-gated test skipping.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-471f3423d837c19484fdaaa3.md)

## Rule

- **Rule:**
  ```text
  conftest.py must register pytest CLI skip flags dynamically from SKIP_DEFAULT_FLAGS as store_true options defaulting to False, so new skip flags are added to SKIP_DEFAULT_FLAGS rather than hand-written addoption calls.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** when adding or modifying pytest CLI skip flags in the test suite configuration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-829b7e77a2ca4861e35e013c.md)

## Rule

- **Rule:**
  ```text
  tests/conftest.py pytest_configure must register each flag in SKIP_DEFAULT_FLAGS as a pytest marker via config.addinivalue_line, defining the repository's custom skip-marker registration convention.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  when adding or modifying pytest_configure or the SKIP_DEFAULT_FLAGS list in tests/conftest.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-be4bbf4ee6a87de0987df362.md)
