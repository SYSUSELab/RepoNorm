# Constraints for `mkdocs.yml`

## Rule

- **Rule:**
  ```text
  CI runs `mkdocs build` to verify the documentation builds successfully before merging changes.
  ```
- **Applies to:**
  - `docs/**`
  - `mkdocs.yml`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-17374f72b3b619a96c466b22.md)

## Rule

- **Rule:** When the CI build check fails, review changes and ensure the documentation builds correctly locally before pushing updates.
- **Applies to:**
  - `docs/**`
  - `mkdocs.yml`
- **Condition:** the CI build check fails
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-18eddba783c527634b61c548.md)
