# Constraints for `.`

## Rule

- **Rule:**
  ```text
  The workflow checks out the main branch by running `git fetch origin` and `git checkout main`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0260821694d43edafbf7625a.md)

## Rule

- **Rule:**
  ```text
  The build_package job builds the package with `uv run -p .venv python -m build`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-03da620f7af06554913fcff4.md)

## Rule

- **Rule:** If the package is migrated to a new project, follow the documented steps to create a trusted publisher.
- **Applies to:**
  - `**`
- **Condition:** the package is migrated to a new project
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-0599e36f228ac20704a609df.md)

## Rule

- **Rule:** The test job runs against Python versions 3.10, 3.11, 3.12, and 3.13.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0a0dd26994d6a76c7523f6e6.md)

## Rule

- **Rule:** Pre-commit checks must be passing both locally and remotely.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-0c57526ab298f280dde89df1.md)

## Rule

- **Rule:** The check-added-large-files hook runs with a maximum file size of 1024 KB.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0e37d55c7413eba338f7e7c7.md)

## Rule

- **Rule:**
  ```text
  Every Python command must be prefixed with `uv run`, because uv creates a Python virtual environment and `uv run` points the command to that environment.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-0fcae80fae1ccf7793be4abe.md)

## Rule

- **Rule:**
  ```text
  Set up the development environment using conda by running `conda create -n dspy-dev python=3.11` followed by `conda activate dspy-dev`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-13892256debed79319f49000.md)

## Rule

- **Rule:** If a code change involves fixing a bug, include a code snippet or notebook showing how to reproduce the broken behavior.
- **Applies to:**
  - `**`
- **Condition:** the code change involves fixing a bug
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-13e509eb8726ad61d4f77bf0.md)

## Rule

- **Rule:** The workflow runs on pushes to the main branch.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-168b532cdd71d63bfc1cabc4.md)

## Rule

- **Rule:**
  ```text
  The project declares requires-python = ">=3.10, <3.14".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-17b3b57a1f231ca309836083.md)

## Rule

- **Rule:** Ruff's formatter is configured to use double quotes for strings (quote-style = "double").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1c715382a389f2a45c3f5a2a.md)

## Rule

- **Rule:** Contributors are recommended to open an issue (if one doesn't already exist) and discuss proposed changes before making any changes.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-1d9852be7dd14073f722be78.md)

## Rule

- **Rule:** Contributors must fix build failures before pushing.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-1ef2e671800f6bc6928f1e20.md)

## Rule

- **Rule:** Python 3.10 or later is required for the DSPy development environment.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-23e543c507971cdfa49a8d34.md)

## Rule

- **Rule:** Commit messages must follow the format {label}(dspy): {message}.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-26d419dce9d6a564856e2019.md)

## Rule

- **Rule:** Ensure all pre-commit checks pass before creating a pull request.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-2963f837a46cb0c11f3fdb00.md)

## Rule

- **Rule:** Ruff linting ignores rules B027, FBT003, C901, E501, UP035, RUF005, B904, F403, E721, UP031, and RUF022.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-298c1d04965e1b174960c7d2.md)

## Rule

- **Rule:** Verify the installation by running some unit tests.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-2bbf46c097a7e6b82cfd568b.md)

## Rule

- **Rule:** Ruff has no unfixable rules configured.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-32ac322184fa76918c3d3419.md)

## Rule

- **Rule:** To make code changes, fork the repository and set up the local development environment following the instructions in the "Environment Setup" section.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-3326eeb71916ea406b1f8ba4.md)

## Rule

- **Rule:**
  ```text
  The workflow auto-commits changes to a branch named `release-${{ needs.extract-tag.outputs.version }}` with commit message "Update versions" using `stefanzweifel/git-auto-commit-action@v5`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-389d74b77fe3d07fc9831965.md)

## Rule

- **Rule:** For minor changes (simple bug fixes or documentation fixes), a PR may be opened without prior discussion.
- **Applies to:**
  - `**`
- **Condition:** the change is a minor change such as a simple bug fix or documentation fix
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-3a68e8087166051a032b97fc.md)

## Rule

- **Rule:** Pre-commit hooks must be set up once after cloning the repository.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-3bddcb87af06530c4e103d2d.md)

## Rule

- **Rule:**
  ```text
  The workflow configures the git user as `actions@github.com` / `Github Actions`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-41caa8edfe965598c03e974e.md)

## Rule

- **Rule:**
  ```text
  Run `pre-commit run --files path/to/file1.py path/to/file2.py` to run pre-commit hooks against specific files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-424941f2f1a7716ec81d8e84.md)

## Rule

- **Rule:** Pre-commit hooks run with Python 3.10 as the default language version.
- **Applies to:**
  - `**/*.py`
  - `**/*.pyi`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-46054648fb34916b087ea94d.md)

## Rule

- **Rule:**
  ```text
  Run `pre-commit install` to install the pre-commit hook.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-47d50aeec0f943ea4cac0e62.md)

## Rule

- **Rule:** Coverage measurement is configured to track branch coverage (branch = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-50d9aded6989ca7e7da102ca.md)

## Rule

- **Rule:**
  ```text
  The build_package job verifies the built package by running `uv run -p .venv python -c "import dspy"`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-550bc52af6b44a8e22c6c1de.md)

## Rule

- **Rule:** The pre-commit configuration enables the check-toml, check-merge-conflict, and debug-statements hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-68e5f2bc569ab90a3e27ce6f.md)

## Rule

- **Rule:**
  ```text
  When you run `git commit`, the pre-commit hook runs automatically.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6b6a9f73cab07076b300935c.md)

## Rule

- **Rule:** Run unit tests to verify that the development environment is set up successfully.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-78deab8d52bc0d88c93a2c90.md)

## Rule

- **Rule:** Pre-commit hooks are used to automatically check and fix common issues.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8058b2cf0b5f8ca8d5de0cf4.md)

## Rule

- **Rule:**
  ```text
  The build_package job installs dependencies with `uv sync --dev -p .venv --extra dev`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-815406c4436ec49e943616e4.md)

## Rule

- **Rule:**
  ```text
  `ruff` is used for both linting and formatting.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-8cc266f0a74bbae02940220a.md)

## Rule

- **Rule:** Setting up the DSPy development environment requires forking the DSPy repository and cloning it locally.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-8d1eff840a5abd3ba713de47.md)

## Rule

- **Rule:** Open a pull request from your branch in your fork to the main branch in the DSPy repo once your changes are ready.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-90161c1a4a72bdf119e8661b.md)

## Rule

- **Rule:** When proposing a new feature, open a feature request to discuss it.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-96d9f2b0947b7503e6bfae27.md)

## Rule

- **Rule:** If the test-intro-script test fails, the workflow fails and the maintainer must make a fix and then delete and recreate the tag.
- **Applies to:**
  - `**`
- **Condition:** the test-intro-script test fails
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-996237eb607fab7311b74bd6.md)

## Rule

- **Rule:**
  ```text
  Create the release tag with the command `git tag X.Y.Z`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-9d09c9ef1635447a58ce1f78.md)

## Rule

- **Rule:** Code must follow the Google Python Style Guide.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-9e47137a43807945ba4f537e.md)

## Rule

- **Rule:** Ruff's formatter is configured to use automatic line-ending detection (line-ending = "auto").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9f9e605eb69b0fe81ae2d0eb.md)

## Rule

- **Rule:** Ruff's flake8-tidy-imports rule bans all relative imports.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3551c1311ad27f84a2e93dd.md)

## Rule

- **Rule:** Pre-commit installs only the pre-commit hook type by default.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a476048e67bea72ff86e039f.md)

## Rule

- **Rule:** When creating a new release for a major or minor version, update the default branch on the GitHub repository to the new release branch.
- **Applies to:**
  - `**`
- **Condition:** creating a new release for a major or minor version
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-a7e8021b0505361125e99665.md)

## Rule

- **Rule:** The fix job runs ruff check with --fix-only --diff --exit-non-zero-on-fix, and on failure prints guidance to run pre-commit run --all-files and exits 1.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a964bcc41f5c21218e1c4c2a.md)

## Rule

- **Rule:** Ruff's formatter is configured to indent with spaces (indent-style = "space").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ad834c437d44a9c3bbe2db34.md)

## Rule

- **Rule:** If there are no releases on the new project, a pending trusted publisher may have to be created to allow the first automated deployment.
- **Applies to:**
  - `**`
- **Condition:** the new project has no releases
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-af07851e27d8ab3f445e19a2.md)

## Rule

- **Rule:** The release automation requires a trusted publisher to be configured on both the pypi and test-pypi packages.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-b5fdc73d589d66595a4bace8.md)

## Rule

- **Rule:**
  ```text
  The workflow publishes the dspy distribution to PyPI using `pypa/gh-action-pypi-publish@release/v1` with attestations disabled.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bbf60ebfeb3d6d0cda670706.md)

## Rule

- **Rule:**
  ```text
  Ruff lint rule F401 is ignored for __init__.py files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c2cf7189d2e6c01df366f887.md)

## Rule

- **Rule:**
  ```text
  Coverage reporting excludes lines matching the configured patterns from coverage measurement, including "pragma: no cover", "def __repr__", "if self.debug:", "raise AssertionError", "raise NotImplementedError", "if __name__ == '__main__':", "logger", "try", "except", the regex "^\s*self\.\w+(:\s*[^=]+)?\s*=.*$", and "continue".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c34f4a1c7c933f8d15b18eed.md)

## Rule

- **Rule:**
  ```text
  Coverage omits __init__.py files, test_*.py files, tests/*.py files, conftest.py files, virtual environment directories (venv, virtualenv, .venv, .virtualenv, env, .env), and setup.py from measurement.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c7c5a84c45e5e24377ad024d.md)

## Rule

- **Rule:** Ruff's formatter is configured not to skip magic trailing commas (skip-magic-trailing-comma = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca5f361695bcd78bc95dd4ce.md)

## Rule

- **Rule:** The title of a pull/merge request must correspond to the required format.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-ca7ff5365ccdc03cce9affc7.md)

## Rule

- **Rule:**
  ```text
  Package discovery for setuptools includes the packages matching "dsp.*", "dspy.*", "dsp", and "dspy".
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ccca7f1e657e5df1a7e8bf63.md)

## Rule

- **Rule:** Pre-commit hooks are configured to run at the pre-commit stage.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ce09dc530213fc16628871a0.md)

## Rule

- **Rule:** When proposing a new feature and already having a design in mind, include a notebook/code example to demonstrate the idea.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-ce239cbf481a1bf0679dc7e7.md)

## Rule

- **Rule:** The check-yaml hook runs with the arguments --allow-multiple-documents and --unsafe.
- **Applies to:**
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ce94fae38731a97dea884e39.md)

## Rule

- **Rule:** Ruff's formatter is configured not to format code inside docstrings (docstring-code-format = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cf7ecf7c718282b5cfaac987.md)

## Rule

- **Rule:**
  ```text
  The build_package job installs the built wheel with `uv pip install dist/*.whl -p .venv`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d47e35e190a93334201f2d44.md)

## Rule

- **Rule:** Ruff linting selects the rule sets E, W, F, I, C, B, UP, N, RUF, and Q.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-d94ba2d1400e1e181c9073f8.md)

## Rule

- **Rule:**
  ```text
  The release workflow builds a binary wheel by running `python3 -m build`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df06c6c4f5657c42868c97fe.md)

## Rule

- **Rule:**
  ```text
  The build_package job runs on ubuntu-latest across a Python version matrix of 3.10, 3.11, 3.12, and 3.13.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e229a7d18b719e9ae59f98b0.md)

## Rule

- **Rule:** The workflow runs on pull requests of types opened, synchronize, and reopened.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e4c6d0f5ccfd0649a5c9b009.md)

## Rule

- **Rule:**
  ```text
  The workflow merges the release branch into main with `git merge --no-ff release-${{ needs.extract-tag.outputs.version }}` and pushes to main with `git push origin main`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eeb25c3d1e4a842979c80150.md)

## Rule

- **Rule:**
  ```text
  Ruff's isort lint rule treats the `dspy` package as first-party when classifying imports.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ef1403e771bf3c7098217a50.md)

## Rule

- **Rule:**
  ```text
  Before publishing to PyPI, the workflow creates a test virtual environment with `python -m venv test_before_pypi`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f82df6764ada9006740ec6ea.md)

## Rule

- **Rule:** When creating a new release for a major or minor version, create a new release branch with the last commit named 'release/X.Y'.
- **Applies to:**
  - `**`
- **Condition:** creating a new release for a major or minor version
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-fa235f0961fcef6ddb6a85e4.md)
