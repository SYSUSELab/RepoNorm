# Claim catalog

- [Rules 1–71](catalog/0001.md); scope preview: `tests/adapters/test_baml_adapter.py`
- [Rules 72–143](catalog/0002.md); scope preview: `.github/workflows/build_and_release.yml`
- [Rules 144–214](catalog/0003.md); scope preview: `**`
- [Rules 215–280](catalog/0004.md); scope preview: `dspy/teleprompt/bootstrap_finetune.py`
- [Rules 281–349](catalog/0005.md); scope preview: `dspy/adapters/chat_adapter.py`
- [Rules 350–419](catalog/0006.md); scope preview: `tests/reliability/test_pydantic_models.py`
- [Rules 420–496](catalog/0007.md); scope preview: `dspy/streaming/streamify.py`
- [Rules 497–542](catalog/0008.md); scope preview: `dspy/dsp/utils/utils.py`
