# Rule details

- **Rule:**
  ```text
  When DatabricksProvider.deploy_finetuned_model is called, dspy.settings.experimental must be True, and the deployed model must be referenced with the 'databricks/' prefix transformation of the model name.
  ```
- **Applies to:**
  - `tests/clients/test_databricks.py`
- **Condition:**
  ```text
  modifying DatabricksProvider.deploy_finetuned_model or the experimental gate and model-name transformation
  ```
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/clients/test_databricks.py:84-94`
