# Rule details

- **Rule:**
  ```text
  async_stream_completion must await stream_completion(request, cache_kwargs) so the async streaming path delegates to the same stream_completion used by the sync path with cache_kwargs.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:**
  ```text
  When modifying async_stream_completion or the shared stream_completion delegation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/lm.py:290-300`
