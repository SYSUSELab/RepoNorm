# Rule details

- **Rule:** Pre-commit hooks must be set up once after cloning the repository.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
First you need to set up the pre-commit hooks (do this once after cloning the repository):

```

- **Sources:**
  - `CONTRIBUTING.md:43`

## Review evidence locations

- `CONTRIBUTING.md:38-47`
