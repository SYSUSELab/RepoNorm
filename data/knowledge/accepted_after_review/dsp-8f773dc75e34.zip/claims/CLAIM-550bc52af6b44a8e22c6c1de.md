# Rule details

- **Rule:**
  ```text
  The build_package job verifies the built package by running `uv run -p .venv python -c "import dspy"`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Test import dspy
        run: uv run -p .venv python -c "import dspy"

```

- **Sources:**
  - `.github/workflows/run_tests.yml:157-158`

## Review evidence locations

- `.github/workflows/run_tests.yml:155-158`
