# Rule details

- **Rule:** Adapter parse failures must raise the adapter-specific parse exception (AdapterParseError for ChatAdapter, ValueError with 'Failed to parse response' for TwoStepAdapter) rather than returning a partial or empty prediction.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
  - `tests/adapters/test_two_step_adapter.py`
- **Condition:** When modifying adapter parse error handling or adding a new adapter parse-failure test.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_chat_adapter.py:190-198`
- `tests/adapters/test_two_step_adapter.py:166-181`
