# Rule details

- **Rule:** Run unit tests to verify that the development environment is set up successfully.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
To verify that your environment is set up successfully, run some unit tests:

```

- **Sources:**
  - `CONTRIBUTING.md:120`

## Review evidence locations

- `CONTRIBUTING.md:120-124`
- `CONTRIBUTING.md:144-148`
