# Rule details

- **Rule:** Tests covering version-mismatch warnings must assert that loading a program saved under different python/dspy/cloudpickle versions logs exactly one warning containing 'There is a mismatch of' per mismatched dependency while still loading the model correctly.
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When modifying version-mismatch warning behavior or the base module tests that cover loading programs saved under different dependency versions.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/primitives/test_base_module.py:180-225`
