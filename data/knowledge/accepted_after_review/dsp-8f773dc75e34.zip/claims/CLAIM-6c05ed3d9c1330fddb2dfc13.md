# Rule details

- **Rule:**
  ```text
  The known_failing_models decorator wrapper must use functools.wraps to preserve the wrapped test function's metadata.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When adding or modifying decorators that wrap reliability test functions.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/utils.py:43-60`
