# Rule details

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the version in `.github/.internal_dspyai/pyproject.toml` to the extracted tag version using a sed command targeting the `#replace_package_version_marker`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Update version for dspy-ai release
        run: sed -i '/#replace_package_version_marker/{n;s/version *= *"[^"]*"/version="${{ needs.extract-tag.outputs.version }}"/;}' .github/.internal_dspyai/pyproject.toml

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:114-115`
