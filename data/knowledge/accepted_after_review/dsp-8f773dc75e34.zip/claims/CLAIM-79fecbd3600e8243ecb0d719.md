# Rule details

- **Rule:**
  ```text
  Cache membership must be the union of the memory and disk tiers: __contains__ returns True when the key exists in either tier, so changes to either tier's lookup must keep the other tier reachable.
  ```
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:**
  ```text
  When modifying Cache.__contains__ or either cache tier's lookup behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/cache.py:61-63`
