# Rule details

- **Rule:**
  ```text
  The MkDocs site enables the search plugin with language en and separator '[\s\-\.]+'.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    - search:
        lang: en
        separator: '[\s\-\.]+'

```

- **Sources:**
  - `docs/mkdocs.yml:193-195`

## Review evidence locations

- `docs/mkdocs.yml:191-195`
