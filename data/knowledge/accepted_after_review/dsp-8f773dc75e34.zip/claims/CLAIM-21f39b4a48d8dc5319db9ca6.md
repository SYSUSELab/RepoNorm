# Rule details

- **Rule:** The user manually creates a release and includes release notes as described in docs/docs/release-checklist.md.
- **Applies to:**
  - `docs/docs/release-checklist.md`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
6. (Currently manual) the user creates a release and includes release notes, as described in docs/docs/release-checklist.md

```

- **Sources:**
  - `.github/.internal_dspyai/internals/build-and-release.md:14`

## Review evidence locations

- `.github/.internal_dspyai/internals/build-and-release.md:7-14`
