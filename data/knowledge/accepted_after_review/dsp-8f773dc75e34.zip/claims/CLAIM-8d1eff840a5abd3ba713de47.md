# Rule details

- **Rule:** Setting up the DSPy development environment requires forking the DSPy repository and cloning it locally.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Setting up your DSPy development environment requires you to fork the DSPy repository and clone it locally.

```

- **Sources:**
  - `CONTRIBUTING.md:94`

## Review evidence locations

- `CONTRIBUTING.md:90-100`
