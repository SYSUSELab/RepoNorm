# Rule details

- **Rule:**
  ```text
  JSONAdapter must retry with response_format={'type': 'json_object'} when the first structured-output call raises, preserving the fallback contract.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:**
  ```text
  When modifying JSONAdapter structured-output handling or its tests, preserve the retry with response_format={'type': 'json_object'} after a first structured-output failure.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/adapters/json_adapter.py:69-82`
