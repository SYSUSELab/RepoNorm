# Rule details

- **Rule:**
  ```text
  _json_input_to_program_input must parse a JSON string, validate it against the pydantic input schema, and return a dict keyed by the model's fields.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying reliability input conversion utilities.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:609-622`
