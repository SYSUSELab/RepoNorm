# Rule details

- **Rule:**
  ```text
  ProgramGeneration requires program_input_fields and program_output_fields outputs to be valid JSON Schema strings without backticks or extra text.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying the ProgramGeneration signature or the reliability generation protocol that produces program_input_fields and program_output_fields.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:380-402`
