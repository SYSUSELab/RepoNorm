# Rule details

- **Rule:**
  ```text
  streaming_response must convert DSPy program output into OpenAI-compatible SSE chunks: Prediction values become data: {"prediction": ...}, litellm ModelResponseStream values become data: {"chunk": ...}, existing data: strings pass through, unknown types raise ValueError, and the stream terminates with data: [DONE].
  ```
- **Applies to:**
  - `dspy/streaming/streamify.py`
- **Condition:**
  ```text
  When modifying streaming_response or adding new output types to the streaming conversion path.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/streaming/streamify.py:251-275`
