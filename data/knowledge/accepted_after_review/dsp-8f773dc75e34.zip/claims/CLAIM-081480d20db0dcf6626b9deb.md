# Rule details

- **Rule:** The litellm test server must map substrings in request message content to specific litellm exceptions: '429' to RateLimitError, '504' to Timeout, '400' to BadRequestError, and '401' to AuthenticationError.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when adding or modifying the litellm test server's error-injection behavior
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The litellm test server helper _throw_exception_based_on_content_if_applicable maps '429' to RateLimitError, '504' to Timeout, '400' to BadRequestError, and '401' to AuthenticationError based on message content substrings, matching the rule exactly.
```

- **Sources:**
  - `tests/test_utils/server/litellm_server.py`
