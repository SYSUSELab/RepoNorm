# Rule details

- **Rule:** Pre-commit hooks are used to automatically check and fix common issues.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
We follow the [Google Python Style Guide](https://google.github.io/styleguide/pyguide.html) and use `ruff` for both linting and formatting. To ensure consistent code quality, we use pre-commit hooks that automatically check and fix common issues.

```

- **Sources:**
  - `CONTRIBUTING.md:40`

## Review evidence locations

- `CONTRIBUTING.md:40-40`
