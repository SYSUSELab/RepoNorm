# Rule details

- **Rule:**
  ```text
  The workflow runs on pushes of tags matching "*", triggering the extract-tag, build-and-publish-test-pypi, and build-and-publish-pypi jobs.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Condition:**
  ```text
  workflow predicate: push: tags: - "*"
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
on:
  push:
    tags:
      - "*"

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:3-6`

## Review evidence locations

- `.github/workflows/build_and_release.yml:3-19`
- `.github/workflows/build_and_release.yml:67-70`
