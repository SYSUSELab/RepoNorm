# Rule details

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model-2" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
  - model_name: "dspy-test-model-2"
    litellm_params:
      model: "dspy-test-provider/dspy-test-model"

```

- **Sources:**
  - `tests/test_utils/server/litellm_server_config.yaml:5-7`
