# Rule details

- **Rule:**
  ```text
  Tests that exercise adapter prompt formatting must assert the exact message structure and content-entry shape produced by the adapter, including the placement of few-shot example images in the example's user message and the query image in the final user message, and the {'type':'image_url','image_url':{'url':...}} content-entry form.
  ```
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** When modifying ChatAdapter.format image handling or the chat adapter tests that cover image formatting with few-shot examples.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_chat_adapter.py:230-253`
- `tests/adapters/test_chat_adapter.py:283-319`
