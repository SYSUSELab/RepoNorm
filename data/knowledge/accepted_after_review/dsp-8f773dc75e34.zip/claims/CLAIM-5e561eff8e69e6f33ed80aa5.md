# Rule details

- **Rule:**
  ```text
  best_idx returns the index of the maximum value in val_aggregate_scores, so ties resolve to the first highest-scoring index.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  When modifying DspyGEPAResult.best_idx or its tie-breaking behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
DspyGEPAResult.best_idx returns max(range(len(scores)), key=lambda i: scores[i]) over val_aggregate_scores, an argmax with first-highest tie resolution.
```

- **Sources:**
  - `dspy/teleprompt/gepa/gepa.py:91-93`
