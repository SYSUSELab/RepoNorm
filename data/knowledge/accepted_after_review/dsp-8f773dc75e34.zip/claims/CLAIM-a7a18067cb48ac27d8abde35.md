# Rule details

- **Rule:**
  ```text
  Reliability tests for multiple primitive outputs assert each output field (entity_hu, entity_en, categories) against grading guidelines, with categories expected to be pipe-separated; keep this per-field assertion and pipe-separated categories convention.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying reliability tests that assert multiple primitive output fields
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/test_pydantic_models.py:89-106`
