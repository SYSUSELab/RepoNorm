# Rule details

- **Rule:**
  ```text
  Reliability test configuration must be read from reliability_conf.yaml and applied via dspy configuration with the parametrized model and adapter; tests must be skipped when no YAML config exists for the model, and should_ignore_failure and model_name must be stored on the request node for post-test handling.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** When modifying the reliability conftest autouse fixture that configures models for reliability tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/conftest.py:41-66`
