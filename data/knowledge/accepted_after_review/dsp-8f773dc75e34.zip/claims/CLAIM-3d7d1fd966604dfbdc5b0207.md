# Rule details

- **Rule:**
  ```text
  When track_usage=True, a ChainOfThought call must record lm_usage with positive prompt/completion/total token counts; when the LM has cache=True, repeated identical calls must produce empty lm_usage because cached responses are not counted.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:**
  ```text
  modifying usage tracking or LM caching behavior that affects whether cached responses contribute to lm_usage
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/primitives/test_base_module.py:233-251`
