# Rule details

- **Rule:**
  ```text
  On MacOS, building the site may additionally require installing libraries via `brew install cairo freetype libffi libjpeg libpng zlib`.
  ```
- **Applies to:**
  - `docs/README.md`
- **Condition:** On MacOS when building the site
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
4. (Optional) On MacOS you may also need to install libraries for building the site

```

- **Sources:**
  - `docs/README.md:38`

### Evidence 2 — explicit

```text
   brew install cairo freetype libffi libjpeg libpng zlib

```

- **Sources:**
  - `docs/README.md:40`

## Review evidence locations

- `docs/README.md:38-42`
