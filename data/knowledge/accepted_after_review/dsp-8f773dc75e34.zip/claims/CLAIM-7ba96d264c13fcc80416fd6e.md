# Rule details

- **Rule:** Tests are set up to mark expected failures for known challenging cases where a specific model might struggle, while actual (unexpected) DSPy reliability issues are flagged as failures.
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  This will execute all tests for the configured models and display detailed results for each model configuration. Tests are set up to mark expected failures for known challenging cases where a specific model might struggle, while actual (unexpected) DSPy reliability issues are flagged as failures (see below).

```

- **Sources:**
  - `tests/reliability/README.md:48`

## Review evidence locations

- `tests/reliability/README.md:42-48`
- `tests/reliability/README.md:75-83`
