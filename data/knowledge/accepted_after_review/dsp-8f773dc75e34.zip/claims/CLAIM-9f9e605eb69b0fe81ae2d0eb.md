# Rule details

- **Rule:** Ruff's formatter is configured to use automatic line-ending detection (line-ending = "auto").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
line-ending = "auto"

```

- **Sources:**
  - `pyproject.toml:164`
