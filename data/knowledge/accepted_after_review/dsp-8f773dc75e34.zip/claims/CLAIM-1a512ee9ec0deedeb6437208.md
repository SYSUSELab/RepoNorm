# Rule details

- **Rule:** Reliability tests for nested models must define Pydantic models referencing deeper nested models (e.g., ResultLevel5), exercising nested model serialization.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying or adding reliability tests for nested models, define Pydantic models that reference deeper nested models to exercise nested serialization.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
Level4 is a Pydantic model with field level5: Level5, referencing a deeper nested model to exercise nested serialization.
```

- **Sources:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py:12-13`

### Evidence 2 — current_observation

```text
Level3 is a Pydantic model in the nesting reliability test that references the deeper nested model Level4, exercising nested model serialization as the rule requires.
```

- **Sources:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py:16-17`

### Evidence 3 — current_observation

```text
Level2 is a Pydantic model in the nesting reliability test that references the deeper nested model Level3, exercising nested model serialization as the rule requires.
```

- **Sources:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py:20-21`

### Evidence 4 — current_observation

```text
Level1 is a Pydantic model in the nesting_1 reliability test that references the deeper nested model Level2, exercising nested serialization.
```

- **Sources:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py:24-25`

### Evidence 5 — current_observation

```text
ProgramInputs is a Pydantic model with a field level1: Level1, referencing a deeper nested model to exercise nested serialization.
```

- **Sources:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py:28-29`

### Evidence 6 — current_observation

```text
ResultLevel4 is a Pydantic model with a field referencing the deeper nested model ResultLevel5, exercising nested serialization.
```

- **Sources:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py:45-46`

### Evidence 7 — current_observation

```text
ResultLevel3 is a Pydantic model with field resultLevel4: ResultLevel4, referencing a deeper nested model to exercise nested serialization.
```

- **Sources:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py:49-50`

### Evidence 8 — current_observation

```text
ResultLevel1 is a Pydantic model in the nesting_1 reliability test that references the deeper nested model ResultLevel2, exercising nested serialization.
```

- **Sources:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py:57-58`

### Evidence 9 — current_observation

```text
ProgramOutputs is a Pydantic model whose resultLevel1 field references the deeper nested ResultLevel1 model, exercising nested model serialization.
```

- **Sources:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py:61-62`

## Review evidence locations

- `tests/reliability/complex_types/generated/test_nesting_1/program.py:7-29`
- `tests/reliability/complex_types/generated/test_nesting_1/program.py:40-62`
