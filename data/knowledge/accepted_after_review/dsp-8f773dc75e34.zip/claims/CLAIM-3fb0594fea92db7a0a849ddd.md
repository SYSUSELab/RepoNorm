# Rule details

- **Rule:**
  ```text
  test_dspy_context_with_dspy_parallel shows that dspy.Parallel runs each input pair under its own context: the France question uses the context LM gpt-4o-mini while the Germany question uses the configured gpt-4o, and the main thread's dspy.settings.lm remains gpt-4o after the parallel call; preserve this per-pair context isolation.
  ```
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying dspy.Parallel or context handling that affects per-pair LM isolation
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_settings.py:56-82`
- `tests/utils/test_settings.py:84-95`
