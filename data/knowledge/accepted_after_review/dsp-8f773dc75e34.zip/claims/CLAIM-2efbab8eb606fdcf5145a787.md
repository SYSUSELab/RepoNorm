# Rule details

- **Rule:**
  ```text
  JSON adapter image tests must assert that formatting a signature with two few-shot image examples and one input image yields exactly 6 messages (1 system, 2 user/assistant pairs, 1 user), with each image_url content block appearing at messages[1], [3], and [5].
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:**
  ```text
  When modifying JSON adapter image formatting or its tests, preserve the assertion that two few-shot image examples plus one input image produce exactly 6 messages with image_url blocks at indices 1, 3, and 5.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_json_adapter.py:268-287`
