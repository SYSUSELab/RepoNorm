# Rule details

- **Rule:**
  ```text
  The usage tracker test module imports UsageTracker and track_usage from dspy.utils.usage_tracker and asserts cumulative token accounting (e.g., 0 + 10 + 10); preserve cumulative token accounting when changing usage tracking.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:** when modifying usage tracking behavior or its tests
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_usage_tracker.py:1-2`
- `tests/utils/test_usage_tracker.py:72-85`
