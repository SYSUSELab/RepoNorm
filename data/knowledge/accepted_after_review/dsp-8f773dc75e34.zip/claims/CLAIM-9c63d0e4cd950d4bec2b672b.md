# Rule details

- **Rule:**
  ```text
  The test asserts that Unbatchify with max_batch_size=5 and max_wait_time=0.15 does not invoke the batch function before the wait time elapses, then batches both submitted items in a single call returning [101, 201], verifying timeout-triggered batching semantics; preserve this timeout-triggered batching behavior.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** when modifying Unbatchify batching or timeout behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_unbatchify.py:53-70`
