# Rule details

- **Rule:**
  ```text
  dspy.Code must support language parameterization via subscript syntax (e.g. dspy.Code["java"]), exposing .code and .language attributes and including 'Programming language: <lang>' in description().
  ```
- **Applies to:**
  - `tests/adapters/test_code.py`
- **Condition:**
  ```text
  When modifying dspy.Code language parameterization or its tests, preserve the subscript syntax, the .code and .language attributes, and the 'Programming language: <lang>' description text.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_code.py:36-45`
- `dspy/adapters/types/code.py:66-84`
