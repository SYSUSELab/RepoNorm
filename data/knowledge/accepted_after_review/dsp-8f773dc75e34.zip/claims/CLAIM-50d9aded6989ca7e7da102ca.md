# Rule details

- **Rule:** Coverage measurement is configured to track branch coverage (branch = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
branch = true

```

- **Sources:**
  - `pyproject.toml:85`

## Review evidence locations

- `pyproject.toml:84-86`
