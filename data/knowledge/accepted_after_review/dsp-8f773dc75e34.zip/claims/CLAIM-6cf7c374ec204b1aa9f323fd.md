# Rule details

- **Rule:** Tests that load a saved Predict with mismatched python/dspy/cloudpickle versions must assert that exactly three 'There is a mismatch of' warnings are logged and that a Predict with an equal signature still loads.
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when adding or modifying a test that loads a saved Predict with mismatched python/dspy/cloudpickle versions
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_load_with_version_mismatch asserts exactly three 'There is a mismatch of' warnings and that a Predict with equal signature still loads.
```

- **Sources:**
  - `tests/utils/test_saving.py`
