# Rule details

- **Rule:**
  ```text
  When resetting the memory cache, the operation must be a no-op when enable_memory_cache is false and otherwise clear memory_cache under self._lock, so callers can invoke it regardless of cache configuration.
  ```
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:** Modifying or calling the memory-cache reset path in the cache client.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/cache.py:147-152`
