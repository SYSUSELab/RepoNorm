# Rule details

- **Rule:** When no valset is provided, GEPA must use the trainset for both reflective updates and Pareto tracking, and log a suggestion to sample a valset for more diverse exploration within the same budget.
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:** when modifying GEPA.compile valset handling or Pareto tracking configuration
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/teleprompt/gepa/gepa.py:365-368`
