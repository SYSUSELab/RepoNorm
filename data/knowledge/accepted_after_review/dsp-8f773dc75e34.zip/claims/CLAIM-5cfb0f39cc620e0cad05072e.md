# Rule details

- **Rule:** When modifying the Deno-backed PythonInterpreter.execute protocol, preserve the JSON-line stdin/stdout exchange, single restart on BrokenPipeError, FinalAnswer-to-output mapping, SyntaxError propagation, and InterpreterError wrapping for other errors.
- **Applies to:**
  - `dspy/primitives/python_interpreter.py`
- **Condition:** Changing the interpreter execution protocol, error handling, or restart behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
PythonInterpreter.execute preserves the JSON-line stdin/stdout exchange, single BrokenPipeError restart, FinalAnswer-to-output mapping, SyntaxError propagation, and InterpreterError wrapping, matching the protocol rule.
```

- **Sources:**
  - `dspy/primitives/python_interpreter.py:168-218`
