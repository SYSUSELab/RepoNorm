# Rule details

- **Rule:**
  ```text
  When changing dspy.adapters' public surface, keep the exported adapter types (Adapter, ChatAdapter, JSONAdapter, XMLAdapter, TwoStepAdapter, Type, History, Image, Audio, Code, Tool, ToolCalls) listed in __all__ so the supported adapter API remains importable.
  ```
- **Applies to:**
  - `dspy/adapters/__init__.py`
- **Condition:** Modifying the dspy.adapters package exports or adding/removing adapter types.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The dspy.adapters __init__ module's __all__ enumerates Adapter, ChatAdapter, JSONAdapter, XMLAdapter, TwoStepAdapter, Type, History, Image, Audio, Code, Tool, and ToolCalls, matching the required exported adapter surface.
```

- **Sources:**
  - `dspy/adapters/__init__.py`
