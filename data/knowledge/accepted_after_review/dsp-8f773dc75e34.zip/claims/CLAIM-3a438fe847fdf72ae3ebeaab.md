# Rule details

- **Rule:**
  ```text
  The Pre-commit checks workflow is triggered only by manual workflow_dispatch.
  ```
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Condition:**
  ```text
  workflow predicate: workflow_dispatch:
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
on:
  workflow_dispatch:

```

- **Sources:**
  - `.github/workflows/precommits_check.yml:2-3`

## Review evidence locations

- `.github/workflows/precommits_check.yml:1-5`
