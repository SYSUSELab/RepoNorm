# Rule details

- **Rule:**
  ```text
  Tests that exercise a module instance's callbacks must assert that on_module_start receives the input kwargs and on_module_end receives the output, and that a different instance of the same module does not trigger the callback, because callbacks are scoped to the instance they are passed to.
  ```
- **Applies to:**
  - `tests/callback/test_callback.py`
- **Condition:** When adding or modifying tests that pass callbacks to a module instance and verify per-instance callback invocation.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/callback/test_callback.py:88-114`
