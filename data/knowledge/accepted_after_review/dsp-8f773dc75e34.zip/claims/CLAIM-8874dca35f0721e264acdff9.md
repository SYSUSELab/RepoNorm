# Rule details

- **Rule:**
  ```text
  Run `pytest tests/predict` to execute the predict tests.
  ```
- **Applies to:**
  - `tests/predict/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
pytest tests/predict

```

- **Sources:**
  - `CONTRIBUTING.md:147`

## Review evidence locations

- `CONTRIBUTING.md:144-148`
