# Rule details

- **Rule:**
  ```text
  When projecting trainset examples onto a predictor signature, each example must be filtered to keys present in the signature's input_fields or output_fields.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:** Modifying or extending demo projection in the infer-rules teleprompter.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/teleprompt/infer_rules.py:99-109`
