# Rule details

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.emoji markdown extension with twemoji index and to_svg generator.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    - pymdownx.emoji:
        emoji_index: !!python/name:material.extensions.emoji.twemoji
        emoji_generator: !!python/name:material.extensions.emoji.to_svg

```

- **Sources:**
  - `docs/mkdocs.yml:266-268`

## Review evidence locations

- `docs/mkdocs.yml:266-268`
