# Rule details

- **Rule:**
  ```text
  API documentation generation must derive its category taxonomy from the explicit API_MAPPING dict; objects not present in that mapping are excluded from generated docs rather than assigned a default category.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  When adding or modifying public dspy symbols or the API_MAPPING category dict in the docs generation script.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `docs/scripts/generate_api_docs.py:155-159`
- `docs/scripts/generate_api_docs.py:221-233`
