# Rule details

- **Rule:** Tests for the BAML adapter must assert that output formatting honors Pydantic field aliases rather than raw field names, and must exercise dspy.Signature subclasses with typed InputField/OutputField declarations including nested Pydantic models as field types.
- **Applies to:**
  - `tests/adapters/test_baml_adapter.py`
- **Condition:** When adding or modifying BAML adapter tests that cover output formatting or structured/nested field types.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_baml_adapter.py:53-63`
- `tests/adapters/test_baml_adapter.py:499-515`
