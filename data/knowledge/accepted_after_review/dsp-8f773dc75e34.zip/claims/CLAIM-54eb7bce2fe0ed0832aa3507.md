# Rule details

- **Rule:** The build-and-publish-pypi job runs on ubuntu-latest and uses the pypi environment with id-token: write and contents: write permissions.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    runs-on: ubuntu-latest
    environment:
      name: pypi
    permissions:
      id-token: write # IMPORTANT: mandatory for trusted publishing
      contents: write

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:71-76`

## Review evidence locations

- `.github/workflows/build_and_release.yml:67-76`
