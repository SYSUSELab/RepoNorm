# Rule details

- **Rule:**
  ```text
  The PythonInterpreter sandbox must enforce read-path access control: files are readable only when their real path is listed in enable_read_paths, and with enable_read_paths=None opening a sandboxed path fails with a permission-denied or no-such-file error.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:**
  ```text
  When modifying PythonInterpreter read-path handling or its tests, preserve the enable_read_paths allowlist enforcement and the failure when enable_read_paths=None.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/primitives/test_python_interpreter.py:81-106`
