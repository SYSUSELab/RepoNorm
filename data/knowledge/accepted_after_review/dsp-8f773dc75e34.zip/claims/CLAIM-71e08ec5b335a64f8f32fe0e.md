# Rule details

- **Rule:**
  ```text
  Run `uv sync --extra dev` to install the development environment dependencies.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
uv sync --extra dev

```

- **Sources:**
  - `CONTRIBUTING.md:115`

## Review evidence locations

- `CONTRIBUTING.md:108-118`
