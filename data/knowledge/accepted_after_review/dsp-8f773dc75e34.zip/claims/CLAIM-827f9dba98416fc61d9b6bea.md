# Rule details

- **Rule:** Save/load must round-trip signature instructions and demos, and pickle is the supported path for non-JSON-serializable data such as datetime.date.
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When modifying program save/load serialization or adding round-trip tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/primitives/test_base_module.py:61-73`
- `tests/primitives/test_base_module.py:76-86`
- `tests/primitives/test_base_module.py:109-118`
