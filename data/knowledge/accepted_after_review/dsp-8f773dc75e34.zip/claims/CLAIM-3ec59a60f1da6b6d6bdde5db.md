# Rule details

- **Rule:**
  ```text
  Usage-tracking tests must assert that get_total_tokens() returns a dict keyed by LM/model identifier with per-model total_tokens values, preserving the multi-model aggregation contract.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:**
  ```text
  when modifying or extending usage-tracking tests that exercise track_usage and get_total_tokens
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_usage_tracker.py:88-133`
