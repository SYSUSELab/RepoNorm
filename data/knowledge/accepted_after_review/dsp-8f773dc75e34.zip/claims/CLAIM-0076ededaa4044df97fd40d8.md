# Rule details

- **Rule:**
  ```text
  BAML adapter field-structure rendering must emit the alias as a comment using COMMENT_SYMBOL when a field has an alias but no description, emit a description as a comment when present, and omit the alias comment for a regular field without an alias.
  ```
- **Applies to:**
  - `tests/adapters/test_baml_adapter.py`
- **Condition:** When modifying BAML adapter schema rendering or its tests, preserve the alias-as-comment, description-as-comment, and no-alias-comment rendering rules.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_baml_adapter.py:518-541`
