# Rule details

- **Rule:** When generating API documentation pages with mkdocstrings, emit the ::: directive as the last line of the page content so that the generated HTML does not leave an unclosed div.
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Modifying the API documentation page generator that emits mkdocstrings ::: directives.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
generate_doc_page returns a page whose final content is the ::: directive followed by the END_API_REF comment, placing the mkdocstrings directive last to avoid the unclosed-div issue.
```

- **Sources:**
  - `docs/scripts/generate_api_docs.py:126-152`
