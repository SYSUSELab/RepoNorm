# Rule details

- **Rule:** The streamify producer must run in a background thread and execute the async runner via context.run(asyncio.run, runner()), propagating the captured context into the thread's event loop.
- **Applies to:**
  - `dspy/streaming/streamify.py`
- **Condition:** When modifying streamify producer threading or context propagation.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/streaming/streamify.py:218-241`
