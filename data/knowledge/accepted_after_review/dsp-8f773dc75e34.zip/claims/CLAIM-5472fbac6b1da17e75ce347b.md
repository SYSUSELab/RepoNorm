# Rule details

- **Rule:**
  ```text
  When rendering an EvaluationResult, __repr__ must show the score and a summarized results list rather than the full results, preserving the stable display contract for evaluation output.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** Modifying or extending the EvaluationResult display representation.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/evaluate/evaluate.py:46-59`
