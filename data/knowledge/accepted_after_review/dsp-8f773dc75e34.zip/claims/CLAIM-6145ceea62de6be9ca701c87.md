# Rule details

- **Rule:**
  ```text
  PythonInterpreter tests must assert the allowlist semantics of network access: enable_network_access=None raises InterpreterError matching "PythonError" on js.fetch, while enable_network_access=["example.com"] permits the same fetch and returns status 200.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** When adding or modifying a PythonInterpreter test that asserts network access allowlist behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/primitives/test_python_interpreter.py:152-171`
