# Rule details

- **Rule:** The build-and-publish-test-pypi process updates the package name placeholder in pyproject.toml to dspy-ai-test.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
1. Updates the package name placeholder in [pyproject.toml](https://github.com/stanfordnlp/dspy/blob/main/pyproject.toml) to `dspy-ai-test`*

```

- **Sources:**
  - `.github/.internal_dspyai/internals/build-and-release.md:37`

## Review evidence locations

- `.github/workflows/build_and_release.yml:43-48`
