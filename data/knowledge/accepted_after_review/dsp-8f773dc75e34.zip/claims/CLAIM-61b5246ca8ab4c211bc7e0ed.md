# Rule details

- **Rule:** The DPR tokenizer base class must define tokenize as raising NotImplementedError, marking it as an abstract extension point for tokenizer implementations.
- **Applies to:**
  - `dspy/dsp/utils/dpr.py`
- **Condition:** When modifying the DPR tokenizer base class or adding tokenizer implementations.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/dsp/utils/dpr.py:136-145`
