# Rule details

- **Rule:** The workflow sets up Python version 3.10 with pip caching.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
          python-version: "3.10"
          cache: "pip"

```

- **Sources:**
  - `.github/workflows/precommits_check.yml:13-14`

## Review evidence locations

- `.github/workflows/precommits_check.yml:9-14`
