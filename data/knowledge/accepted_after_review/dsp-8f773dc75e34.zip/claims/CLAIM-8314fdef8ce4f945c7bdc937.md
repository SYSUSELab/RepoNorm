# Rule details

- **Rule:** AdapterParseError string formatting must include the custom message, adapter name, raw LM response, expected output fields, and (when available) the actually parsed output fields in the fixed multi-line format.
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:** When modifying or extending AdapterParseError formatting or its tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/utils/exceptions.py:8-32`
- `tests/utils/test_exceptions.py:24-60`
