# Rule details

- **Rule:**
  ```text
  Tool calls must serialize into {'type': 'tool_calls', 'tool_calls': [...]} structures, including the empty case and multiple calls with function name and arguments.
  ```
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying tool call serialization format or adding tool call test cases.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_tool.py:397-442`
