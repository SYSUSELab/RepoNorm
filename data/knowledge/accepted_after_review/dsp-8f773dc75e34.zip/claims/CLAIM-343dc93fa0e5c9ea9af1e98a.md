# Rule details

- **Rule:** When modifying the evaluate module's display path, keep IPython display and HTML imports inside a try/except ImportError so notebook display support remains optional and IPython is not a hard dependency.
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** When adding or changing display/notebook rendering features in the evaluate module.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/evaluate/evaluate.py:16-35`
