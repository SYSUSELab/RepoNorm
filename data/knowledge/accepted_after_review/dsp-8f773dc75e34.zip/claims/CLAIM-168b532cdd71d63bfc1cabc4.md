# Rule details

- **Rule:** The workflow runs on pushes to the main branch.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  push:
    branches:
      - main

```

- **Sources:**
  - `.github/workflows/run_tests.yml:4-6`

## Review evidence locations

- `.github/workflows/run_tests.yml:3-8`
