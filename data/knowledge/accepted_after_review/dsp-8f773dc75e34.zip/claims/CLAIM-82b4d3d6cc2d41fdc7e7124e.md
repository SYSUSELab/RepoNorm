# Rule details

- **Rule:**
  ```text
  ChatAdapter.__call__ must fall back to JSONAdapter on any exception except ContextWindowExceededError, and must not retry when the instance is already a JSONAdapter; this defines the adapter fallback boundary.
  ```
- **Applies to:**
  - `dspy/adapters/chat_adapter.py`
- **Condition:**
  ```text
  When modifying ChatAdapter.__call__ or adding adapter fallback behavior in the adapter layer.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/adapters/chat_adapter.py:28-47`
