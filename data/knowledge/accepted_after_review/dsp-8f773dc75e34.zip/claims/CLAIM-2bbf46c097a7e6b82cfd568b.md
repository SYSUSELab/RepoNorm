# Rule details

- **Rule:** Verify the installation by running some unit tests.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Then verify the installation by running some unit tests:

```

- **Sources:**
  - `CONTRIBUTING.md:144`

## Review evidence locations

- `CONTRIBUTING.md:136-148`
