# Rule details

- **Rule:**
  ```text
  Reliability test utilities must keep get_adapter mapping reliability_conf.adapter 'chat' to ChatAdapter and 'json' to JSONAdapter, raising ValueError for any other value.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when modifying or extending reliability test adapter selection helpers
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/utils.py:146-152`
