# Rule details

- **Rule:** Reliability test generation utilities must keep generated inputs schema-valid: caching is disabled and temperature is 0.5 so retries produce fresh inputs, and each generated input is validated against the program's input schema before input/assertions JSON files are written.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying generate_test_inputs or the reliability input-generation pipeline.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:153-184`
- `tests/reliability/generate/utils.py:200-226`
