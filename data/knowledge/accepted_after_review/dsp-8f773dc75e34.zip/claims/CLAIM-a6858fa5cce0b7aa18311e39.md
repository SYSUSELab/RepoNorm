# Rule details

- **Rule:** When collecting unique LMs across predictors, pred.lm must be gathered across all predictors and deduplicated via set, preserving the expectation that multiple predictors may share LM instances.
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:** Modifying or extending LM collection in the bootstrap-finetune teleprompter.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/teleprompt/bootstrap_finetune.py:424-426`
