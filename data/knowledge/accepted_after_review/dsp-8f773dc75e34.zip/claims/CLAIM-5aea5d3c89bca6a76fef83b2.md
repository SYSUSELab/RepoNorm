# Rule details

- **Rule:** The saving test signature uses datetime.date input fields and an int output field with a description, exercising serialization of date-typed signature fields; preserve date-typed field serialization when changing signature saving.
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when modifying signature serialization or saving behavior involving date-typed fields
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_saving.py:40-54`
