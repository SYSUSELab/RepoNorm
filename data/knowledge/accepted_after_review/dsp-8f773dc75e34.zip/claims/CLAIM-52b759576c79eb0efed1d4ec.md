# Rule details

- **Rule:** dspy.configure must raise RuntimeError when called from a different async task than the initial one, with the message 'dspy.settings.configure(...) can only be called from the same async'.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** When modifying dspy.configure async-task restrictions or their tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/utils/test_settings.py:158-174`
