# Rule details

- **Rule:**
  ```text
  When changing dspy/propose/grounded_proposer.py gather_examples_from_sets, preserve the filter that only yields candidate examples containing an 'augmented' key, since augmented-example generation depends on that key being present.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:**
  ```text
  Modifying gather_examples_from_sets' example filtering or augmented-example selection.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/propose/grounded_proposer.py:177-187`
