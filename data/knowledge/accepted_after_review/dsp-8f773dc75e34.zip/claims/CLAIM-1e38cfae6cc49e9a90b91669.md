# Rule details

- **Rule:** The mkdocstrings Python handler uses Google docstring style.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
                    docstring_style: google

```

- **Sources:**
  - `docs/mkdocs.yml:200`

## Review evidence locations

- `docs/mkdocs.yml:196-204`
