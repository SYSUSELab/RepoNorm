# Rule details

- **Rule:**
  ```text
  The build-and-publish-test-pypi job builds a binary wheel with `python3 -m build`.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Build a binary wheel
        run: python3 -m build

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:47-48`

## Review evidence locations

- `.github/workflows/build_and_release.yml:43-48`
