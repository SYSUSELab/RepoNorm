# Rule details

- **Rule:**
  ```text
  The workflow configures the git user as `actions@github.com` / `Github Actions`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Configure git user
        run: |
          git config --global user.email "actions@github.com"
          git config --global user.name "Github Actions"

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:135-138`

## Review evidence locations

- `.github/workflows/build_and_release.yml:135-138`
