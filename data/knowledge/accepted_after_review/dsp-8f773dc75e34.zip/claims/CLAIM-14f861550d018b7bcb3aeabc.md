# Rule details

- **Rule:**
  ```text
  write_lines must serialize each item as a ujson.dumps line terminated by a newline, defining the JSONL convention used for finetune data and error logs; changes must preserve this line-oriented JSON serialization.
  ```
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:**
  ```text
  When modifying write_lines or any finetune data/error log writer that must remain JSONL-compatible.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/utils_finetune.py:60-81`
