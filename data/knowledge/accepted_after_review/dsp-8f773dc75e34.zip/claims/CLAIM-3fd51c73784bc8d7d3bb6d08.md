# Rule details

- **Rule:**
  ```text
  Reliability test input files must be named input<N>.json and numbered sequentially; find_max_input_number treats a missing directory as zero and matches only that filename pattern.
  ```
- **Applies to:**
  - `tests/reliability/generate/**/*.py`
- **Condition:** when generating or locating reliability test input files
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
find_max_input_number matches files named input<N>.json and returns 0 when the directory does not exist, following the input numbering convention.
```

- **Sources:**
  - `tests/reliability/generate/utils.py`
