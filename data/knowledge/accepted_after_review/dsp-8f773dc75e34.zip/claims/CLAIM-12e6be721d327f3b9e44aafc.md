# Rule details

- **Rule:**
  ```text
  generate_test_cases reuses an existing program when _directory_contains_program is true, otherwise generates a new program, then always generates inputs under dst_path/inputs and returns load_generated_cases; preserve this reuse-then-generate flow.
  ```
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:** when modifying the reliability test case generation entry point or its program-reuse decision
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/__init__.py:13-38`
