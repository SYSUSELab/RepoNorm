# Rule details

- **Rule:**
  ```text
  Predict tests must define signatures with field-level constraints (min_length, max_length, gt, lt, ge, le, multiple_of) on both input and output fields, exercising constraint propagation through dspy signatures.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying or adding predict tests for field constraints, keep the signature definition with field-level constraints on both input and output fields.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/predict/test_predict.py:609-632`
