# Rule details

- **Rule:**
  ```text
  Module deepcopy tests must assert that after Module.deepcopy, nested locks are shared by identity (shallow) while parameters are distinct objects with equal __dict__.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:**
  ```text
  When modifying Module.deepcopy behavior or its tests, preserve the assertion that nested locks are shared by identity while parameters are distinct objects with equal __dict__.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/primitives/test_base_module.py:25-58`
