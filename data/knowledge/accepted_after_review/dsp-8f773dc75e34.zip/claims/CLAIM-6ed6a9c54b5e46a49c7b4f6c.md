# Rule details

- **Rule:** KNNFewShot initialization tests must assert that the KNN k value and trainset size are set from the fixture, defining the expected initialization state.
- **Applies to:**
  - `tests/teleprompt/test_knn_fewshot.py`
- **Condition:** When modifying or adding KNNFewShot initialization tests, keep the assertion that the KNN k value and trainset size are set from the fixture.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/teleprompt/test_knn_fewshot.py:13-28`
