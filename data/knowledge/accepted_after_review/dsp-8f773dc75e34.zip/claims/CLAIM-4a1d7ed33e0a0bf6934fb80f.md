# Rule details

- **Rule:** The reliability test input-generation signature must require natural-language, objective, verifiable assertions (ideally about 5) and permit leaving them blank when accurate assertions are difficult to generate.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the assertion-generation signature or its prompt, preserve the requirement for natural-language, objective, verifiable assertions and the allowance to leave them blank when accurate assertions are difficult.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:460-480`
