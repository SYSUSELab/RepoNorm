# Rule details

- **Rule:**
  ```text
  Streaming tests must exercise custom dspy.Module subclasses (not only built-in predictors) and must use fixtures that emit Gemini-style chunks with the [[ ## field ## ]] and [[ ## completed ## ]] delimiters, documenting the wire format the streaming parser must recognize.
  ```
- **Applies to:**
  - `tests/streaming/test_streaming.py`
- **Condition:** When adding or modifying streaming tests that cover custom Module subclasses or Gemini-style chunk parsing.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/streaming/test_streaming.py:525-546`
- `tests/streaming/test_streaming.py:548-595`
