# Rule details

- **Rule:**
  ```text
  `read_litellm_test_server_request_logs` must read a jsonlines file line-by-line and `json.loads` each line into a list of dicts, defining the convention for parsing LiteLLM server request logs in integration tests.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** When modifying the LiteLLM test server request log reader used by integration tests.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils/server/__init__.py:48-62`
