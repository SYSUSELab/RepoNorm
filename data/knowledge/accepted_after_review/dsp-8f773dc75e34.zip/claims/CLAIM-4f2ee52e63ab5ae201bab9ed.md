# Rule details

- **Rule:** The MkDocs site defines a slate (dark) palette scheme with black primary and lime accent colors.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
        - scheme: slate
          toggle:
            icon: material/weather-sunny
            name: Switch to light mode
          primary: black
          accent: lime

```

- **Sources:**
  - `docs/mkdocs.yml:175-180`

## Review evidence locations

- `docs/mkdocs.yml:168-180`
