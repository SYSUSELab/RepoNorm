# Rule details

- **Rule:** Tests that intercept LM calls use the repository's test litellm server, whose acompletion logs the request kwargs and returns a mock LLM response.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When adding or modifying test infrastructure that intercepts LM calls.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils/server/litellm_server.py:12-19`
- `tests/test_utils/server/litellm_server.py:44-51`
