# Rule details

- **Rule:**
  ```text
  BaseLM subclasses must implement forward and return a value matching the OpenAI response format; BaseLM.__call__ is callback-wrapped and routes through self.forward then self._process_lm_response, so subclasses must not bypass that pipeline.
  ```
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:** When adding or modifying a BaseLM subclass or overriding forward in the LM client layer.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/clients/base_lm.py:12-18`
- `dspy/clients/base_lm.py:92-111`
