# Rule details

- **Rule:**
  ```text
  KNN.__init__ stores k, trainset, and the embedder, and builds trainset_vectors by joining each example's input-key values with ' | ' and embedding them as float32.
  ```
- **Applies to:**
  - `dspy/predict/knn.py`
- **Condition:**
  ```text
  When modifying KNN.__init__ or changing how trainset vectors are constructed in the predict layer.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/predict/knn.py:39-46`
