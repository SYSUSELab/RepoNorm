# Rule details

- **Rule:**
  ```text
  Every Python command must be prefixed with `uv run`, because uv creates a Python virtual environment and `uv run` points the command to that environment.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Note: You need to use the `uv run` prefix for every Python command, as uv creates a Python virtual
environment and `uv run` points the command to that environment. For example, to execute a Python script you will need
`uv run python script.py`.

```

- **Sources:**
  - `CONTRIBUTING.md:126-128`

## Review evidence locations

- `CONTRIBUTING.md:126-128`
