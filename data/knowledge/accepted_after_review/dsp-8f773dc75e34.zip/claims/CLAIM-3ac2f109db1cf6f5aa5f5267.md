# Rule details

- **Rule:**
  ```text
  DescribeModule must remain a dspy.Signature with input fields program_code, program_example, program_description, module and output field module_description, each carrying explicit prefixes that structure the proposer prompt.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:** When modifying DescribeModule fields or their prefixes used by the proposer prompt.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
DescribeModule is a dspy.Signature declaring the four input fields program_code, program_example, program_description, module and the output field module_description, each with explicit prefixes.
```

- **Sources:**
  - `dspy/propose/grounded_proposer.py:48-72`
