# Rule details

- **Rule:**
  ```text
  GEPA's feedback_fn_creator must return a PredictorFeedbackFn-compatible callable, establishing the per-predictor feedback extension point.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  when modifying GEPA.compile feedback_fn_creator or the PredictorFeedbackFn protocol
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/teleprompt/gepa/gepa.py:372-394`
- `dspy/teleprompt/gepa/gepa_utils.py:28-48`
