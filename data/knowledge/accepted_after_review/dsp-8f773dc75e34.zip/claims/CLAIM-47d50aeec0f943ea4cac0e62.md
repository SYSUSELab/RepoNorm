# Rule details

- **Rule:**
  ```text
  Run `pre-commit install` to install the pre-commit hook.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
pre-commit install

```

- **Sources:**
  - `CONTRIBUTING.md:46`

## Review evidence locations

- `CONTRIBUTING.md:43-47`
