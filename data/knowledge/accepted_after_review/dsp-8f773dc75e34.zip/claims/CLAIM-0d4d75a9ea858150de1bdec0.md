# Rule details

- **Rule:** JSON adapter tests must assert that tool definitions are serialized into the user message with their argument schemas and that the litellm completion call receives a tools argument of function-type dicts containing name, description, and JSON-schema parameters with required fields.
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When modifying JSON adapter tool-call formatting or its tests, preserve the assertion that tool definitions appear in the user message with argument schemas and that the litellm tools argument contains function-type dicts with name, description, and JSON-schema parameters including required fields.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_json_adapter.py:356-390`
- `tests/adapters/test_json_adapter.py:392-435`
