# Rule details

- **Rule:**
  ```text
  Run `python -m tests.reliability.generate -d <output_dir> -p "<program description>" -i "<input description>"` from the DSPy repository root directory to generate a test program and test inputs.
  ```
- **Applies to:**
  - `tests/reliability/**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
python \
    -m tests.reliability.generate \
    -d tests/reliability/classification/generated/test_example \
    -p "Generate a program that performs a classification task involving objects with multiple properties. The task should be realistic" \
    -i "Based on the program description, generate a challenging example" \

```

- **Sources:**
  - `tests/reliability/README.md:63-67`

## Review evidence locations

- `tests/reliability/README.md:58-69`
