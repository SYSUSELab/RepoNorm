# Rule details

- **Rule:**
  ```text
  OldField.__eq__ must compare self.__dict__ == __value.__dict__, so field equality is based on instance dictionaries and contributors changing Field attributes must consider this equality contract.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:**
  ```text
  When modifying OldField.__eq__ or Field attributes that affect equality.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
OldField.__eq__ compares self.__dict__ == __value.__dict__, exactly matching the stated instance-dictionary equality contract.
```

- **Sources:**
  - `dspy/signatures/field.py:89-90`
