# Rule details

- **Rule:**
  ```text
  When joining strategy names in BetterTogether, the separator must be STRAT_SEP = " -> ", preserving the stable formatting convention for strategy identifiers.
  ```
- **Applies to:**
  - `dspy/teleprompt/bettertogether.py`
- **Condition:** Modifying or extending strategy-name formatting in the BetterTogether teleprompter.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `dspy/teleprompt/bettertogether.py:21-23`
- `dspy/teleprompt/bettertogether.py:89-97`
