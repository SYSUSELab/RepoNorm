# Rule details

- **Rule:**
  ```text
  The build-and-publish-pypi job rewrites __name__ in ./dspy/__metadata__.py after the #replace_package_name_marker line to "dspy".
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Update package name in metadata.py
        run: sed -i '/#replace_package_name_marker/{n;s/__name__ *= *"[^"]*"/__name__="dspy"/;}' ./dspy/__metadata__.py

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:92-93`
