# Rule details

- **Rule:**
  ```text
  Tests for the JSON adapter must assert that with use_native_function_calling=False, _get_structured_outputs_response_format is never called and litellm.completion is called once with response_format={'type': 'json_object'}, documenting the fallback to JSON mode.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When adding or modifying JSON adapter tests that cover the non-native function calling fallback path.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/adapters/test_json_adapter.py:764-793`
