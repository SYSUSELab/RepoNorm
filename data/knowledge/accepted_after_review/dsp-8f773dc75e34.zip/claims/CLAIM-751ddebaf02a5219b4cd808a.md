# Rule details

- **Rule:**
  ```text
  Predict.dump_state must preserve serialized values through ujson round-trip: serialize_object normalizes a pydantic model's URL field to a trailing-slash form and serializes datetime to ISO format, and dump_state preserves these serialized values.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  When adding or modifying a Predict test that asserts dump_state serialization of pydantic non-primitive types.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/predict/test_predict.py:691-728`
