# Rule details

- **Rule:**
  ```text
  The reliability test harness must route judge evaluations through a model named 'judge' as defined by `JUDGE_MODEL_NAME`.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  When modifying the reliability test harness or judge configuration, preserve the use of `JUDGE_MODEL_NAME = 'judge'` for routing judge evaluations.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/utils.py:10-12`
- `tests/reliability/utils.py:75-83`
