# Rule details

- **Rule:**
  ```text
  Generated reliability test cases are represented by the GeneratedTestCase dataclass carrying name, program_path, program_input as a JSON string, and output_assertions; keep this schema when producing or consuming generated cases.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when changing how generated reliability test cases are represented or loaded
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/reliability/generate/utils.py:248-262`
