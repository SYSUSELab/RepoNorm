# Claim catalog

- [Rules 1–72](catalog/0001.md); scope preview: `src/click/testing.py`
- [Rules 73–146](catalog/0002.md); scope preview: `src/click/testing.py`
- [Rules 147–218](catalog/0003.md); scope preview: `tests/test_formatting.py`
- [Rules 219–291](catalog/0004.md); scope preview: `tests/test_options.py`
- [Rules 292–369](catalog/0005.md); scope preview: `src/click/types.py`
- [Rules 370–444](catalog/0006.md); scope preview: `src/click/_winconsole.py`
- [Rules 445–487](catalog/0007.md); scope preview: `tests/test_context.py`
