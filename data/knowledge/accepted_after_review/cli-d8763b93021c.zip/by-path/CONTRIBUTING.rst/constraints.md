# Constraints for `CONTRIBUTING.rst`

## Rule

- **Rule:** For feature additions or changes, branch off the "main" branch (e.g., origin/main).
- **Applies to:**
  - `CONTRIBUTING.rst`
- **Condition:** when submitting a feature addition or change
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-1fd6fd9be8ad5370583af683.md)

## Rule

- **Rule:** Create a branch to identify the issue being worked on; for bug or documentation fixes, branch off the latest ".x" branch (e.g., origin/8.1.x).
- **Applies to:**
  - `CONTRIBUTING.rst`
- **Condition:** when submitting a bug or documentation fix
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-8daf9d190da9557d2925478d.md)
