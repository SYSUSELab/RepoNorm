# Constraints for `click`

## Rule

- **Rule:** Coverage measurement is configured to restrict its source to the click package and the tests directory.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-28cd2030c9bb34be433ba7f3.md)
