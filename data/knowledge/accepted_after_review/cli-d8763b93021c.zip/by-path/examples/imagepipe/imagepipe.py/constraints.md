# Constraints for `examples/imagepipe/imagepipe.py`

## Rule

- **Rule:** Example commands that paste one image onto another must consume the first two images, yield the single image unchanged when only one is supplied, and otherwise paste the second onto the first with an RGBA/transparency mask and append the pasted filename to the base filename.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** when adding or modifying an imagepipe example command that pastes one image onto another
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-10c648d2543e7996594778d6.md)

## Rule

- **Rule:** Example commands that process a stream of images must be implemented as generator functions decorated with @processor and registered via @cli.command, yielding transformed images rather than returning them.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When adding or modifying an imagepipe example command that transforms a stream of images.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a621a0d568c32f5e92b4a0a.md)

## Rule

- **Rule:** The sharpen example command must clamp the user-supplied factor to a minimum of 1.0 before passing it to ImageEnhance.Sharpness, so factors below 1.0 are silently raised rather than rejected or passed through.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the sharpen command's factor handling in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-200cf2c00aad35dfffeb0e10.md)

## Rule

- **Rule:**
  ```text
  The imagepipe example must use @cli.result_callback to chain subcommand-returned processor functions into a stream pipeline and iterate the final stream to force evaluation.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When adding or modifying subcommands in the imagepipe example that return processor functions for the result callback to chain.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2dbe77be6ab84e6a7d7af993.md)

## Rule

- **Rule:** Example commands that use a chained group must allow multiple subcommands to be piped together, with a docstring demonstrating the pipe syntax.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When adding or modifying a chained group in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e09f033ac0a46152369776f.md)

## Rule

- **Rule:** Example commands that accept multiple input paths must treat '-' as reading from binary stdin and must catch exceptions per input, echoing an error to stderr rather than aborting the whole command.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying or adding an example command that accepts multiple input paths, especially the imagepipe open command.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-88e512f36bef20a6e71253bc.md)

## Rule

- **Rule:**
  ```text
  The imagepipe example's copy_filename helper must copy the filename attribute from an old file-like object to a new one and return the new object.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:**
  ```text
  When modifying the copy_filename helper in the imagepipe example.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a67690f4e59f4df09a2dfdcf.md)

## Rule

- **Rule:** Example commands that use a processor decorator must forward the stream plus any additional arguments and keyword arguments to the wrapped function.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When adding or modifying a processor decorator in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bfb6bba7d58389de35df5cb2.md)

## Rule

- **Rule:** The imagepipe save command must catch exceptions per image, report the failure to stderr, and continue iterating so that one failed save does not abort processing of remaining images.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the imagepipe save command's per-image processing loop or its error handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ec2e6841b5dfe4035467bda3.md)
