# Constraints for `examples/repo/repo.py`

## Rule

- **Rule:**
  ```text
  Example commands that maintain mutable state must initialize it in the context object's __init__ (e.g. home, empty config dict, verbose=False) so commands share consistent state.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** when modifying the shared context object's initialization in the repo example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-094504a10eca535e1a8c34a6.md)

## Rule

- **Rule:** Example commands that copy files must accept variadic source paths and a single destination path, support a --force flag, and echo each copy operation.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When adding or modifying a copy command in the repo example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-13324d8c153b06abde4a4992.md)

## Rule

- **Rule:**
  ```text
  Example commands that prompt for sensitive input must use click.password_option (or an equivalent masked prompt) and must not echo the raw value; the example stores the password masked as '*' * len(password).
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** when adding or modifying an example command that prompts for a password or other sensitive input
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-13b8c8b16402ece8bc6303c8.md)

## Rule

- **Rule:** The repo example's commit command must use multiple=True for --message/-m, build an editor hint with the marker "# Files to be committed:" when no message is provided, abort on None or empty message, and otherwise join multiple messages with newlines.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the commit command's message handling in the repo example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a180052db401e7935fa727b.md)

## Rule

- **Rule:**
  ```text
  The repo example must create a pass decorator via click.make_pass_decorator(Repo) to pass a Repo object through the context to commands.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying the repo example's context object passing mechanism.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5d1c28d18cf3430c6f87ae9f.md)

## Rule

- **Rule:**
  ```text
  Example click groups that manage shared state must store a state object on ctx.obj in the group callback and provide it to subcommands via a pass_repo-style decorator.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When adding or modifying a click group in the repo example that manages shared state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c4bd4da67be47708f88ea848.md)

## Rule

- **Rule:** Example commands that accept optional positional arguments must derive defaults from the supplied value (e.g. the last path component of src, or '.') rather than requiring the caller to pass them explicitly.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** when adding or modifying an example command with an optional destination or similar positional argument
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f23be472e3801765f696a5a8.md)
