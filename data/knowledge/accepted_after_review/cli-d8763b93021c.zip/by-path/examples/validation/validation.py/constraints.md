# Constraints for `examples/validation/validation.py`

## Rule

- **Rule:** Example commands that accept a URL argument must validate it through the example's URL parameter type, which rejects any scheme other than http/https via self.fail and skips scheme validation for already-parsed tuple values.
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** when adding or modifying an example command that accepts a URL argument
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3f60578fc717355a5baffca4.md)

## Rule

- **Rule:**
  ```text
  The validation example must demonstrate three validation approaches: a callback (validate_count), a custom type (URL), and manual validation in the command function raising BadParameter with a param_hint.
  ```
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** When modifying the validation example's validation approaches.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9ce3eea5b28712ab64387ac1.md)
