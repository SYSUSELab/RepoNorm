# Constraints for `examples/completion/completion.py`

## Rule

- **Rule:** Example click groups must be defined with no subcommands, relying on later registration of commands via decorators.
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When defining a click group in an example that will have commands registered later.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6dc632f501d4d843cc38ba8e.md)

## Rule

- **Rule:**
  ```text
  The completion example must register custom shell completion by importing CompletionItem from click.shell_completion and attaching shell_complete callbacks to arguments, with cli.add_command(group) used to register groups.
  ```
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When adding or modifying shell completion wiring in the completion example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7a7850c50260004e786b3541.md)

## Rule

- **Rule:** Example shell completion callbacks must return CompletionItem objects with help strings and match the incomplete value against both the value and the help text.
- **Applies to:**
  - `examples/completion/completion.py`
- **Condition:** When adding or modifying a shell completion callback in the completion example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dfec9d11a6b78a5a48d14b0f.md)
