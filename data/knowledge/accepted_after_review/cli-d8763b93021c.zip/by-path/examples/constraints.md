# Constraints for `examples`

## Rule

- **Rule:**
  ```text
  Example helper decorators that wrap functions must use functools.update_wrapper to preserve the wrapped function's metadata, rather than manually copying attributes.
  ```
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example helper decorator that wraps a function.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0a6c3d018e2783737e351102.md)

## Rule

- **Rule:** Ruff excludes the examples/ directory from linting via extend-exclude.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2b683e197feea26882b7bf8a.md)

## Rule

- **Rule:** Example CLI classes that extend click.Group must subclass click.Group directly and override behavior through methods, rather than composing or wrapping a Group instance.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example CLI class that customizes group behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2d75467d3a6381a3616d5876.md)

## Rule

- **Rule:** Example completion callbacks may return a plain list of strings as a shortcut for a list of CompletionItem objects, so custom completion functions are not required to construct CompletionItem instances.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:** When adding or modifying an example completion callback that returns completion candidates.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-78a8a8c4c919b472d2b2f7c9.md)

## Rule

- **Rule:** Example commands that override command resolution must return the canonical command name rather than the alias used, so downstream resolution sees the real command name.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:**
  ```text
  When adding or modifying an example command that overrides resolve_command to handle aliases.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-dacd855fb5c522c1e87b8f74.md)
