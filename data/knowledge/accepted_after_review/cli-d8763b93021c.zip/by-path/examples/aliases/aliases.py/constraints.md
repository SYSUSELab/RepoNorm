# Constraints for `examples/aliases/aliases.py`

## Rule

- **Rule:**
  ```text
  The aliases example's get_command must resolve commands in order: builtin commands, explicit config alias, then automatic abbreviation; abbreviation only succeeds when exactly one command matches, otherwise ctx.fail reports 'Too many matches'.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** When modifying command resolution logic in the aliases example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-253229a7a0c5e9207e3faa19.md)

## Rule

- **Rule:** Example commands that read or write an aliases config file must use configparser.RawConfigParser with an 'aliases' section, tolerate a missing section on read, and write in binary mode so the on-disk format stays compatible.
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when modifying config reading or writing in the aliases example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2b56b0541c768b985cae085b.md)

## Rule

- **Rule:**
  ```text
  Example commands that need configuration must load it in a group-level callback (e.g. read_config) so the config is available even when the group never executes, defaulting to a file next to the module (e.g. aliases.ini) rather than requiring the subcommand to load it.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when adding or modifying an example command group that needs configuration available to all subcommands
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-519123bb9a9a7db3d0cd3319.md)

## Rule

- **Rule:** The aliases example must initialize path to the current working directory and an empty aliases dict, demonstrating a simple alias storage pattern.
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** When modifying the aliases example's alias storage initialization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-98a564216e78e31faa3c1e09.md)

## Rule

- **Rule:** Example commands that add an alias must update the aliases mapping with a single alias-to-command entry.
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** when modifying alias addition in the aliases example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ed93e1c4fac31bffd7a89af9.md)

## Rule

- **Rule:**
  ```text
  The aliases example's status command must use @pass_config to receive a config object and echo a status message including config.path.
  ```
- **Applies to:**
  - `examples/aliases/aliases.py`
- **Condition:** When modifying the aliases example's status command.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f60743620d9dfa49619e0e74.md)
