# Constraints for `examples/termui/termui.py`

## Rule

- **Rule:** Example commands that clear the screen must call click.clear() to demonstrate the screen-clearing API.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When adding or modifying a clear command in the termui example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-072648da229c8aa3b470e2eb.md)

## Rule

- **Rule:** The termui example must define a top-level click group 'cli' showcasing terminal UI helpers.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying the termui example's top-level CLI group.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0d93dd72fa6259e2541bc468.md)

## Rule

- **Rule:** The termui example's menu command must use click.getchar() in a loop with main/debug/quit states to handle interactive character input.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying the termui example's menu command interactive input handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1dbb36fe1ba7b2542255abe4.md)

## Rule

- **Rule:**
  ```text
  Example progressbar demonstrations must support various configurations including fill_char styling, item_show_func, custom bar_template, width=0, and non-linear progress via manual bar.update.
  ```
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When adding or modifying a progressbar demonstration in the termui example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-59ee2449cc6e8d656b110dcb.md)

## Rule

- **Rule:** Example commands that demonstrate ANSI coloring must call click.style with fg and bg set to the same color name when showing foreground and background coloring.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** when modifying the colordemo command in the termui example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d3adb6c33758bc5af23f53dc.md)

## Rule

- **Rule:** The termui example's pause command must call click.pause() to wait for a button press.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying the termui example's pause command or its waiting behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eba381dbf143cf91ef511926.md)

## Rule

- **Rule:** Example commands that launch a URL must call click.launch with the appropriate variant flag (e.g. locate=True for the locate command) rather than invoking a platform-specific opener directly.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** when adding or modifying an example command that opens or locates a URL
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fdeb30e68db61a34f80d9995.md)
