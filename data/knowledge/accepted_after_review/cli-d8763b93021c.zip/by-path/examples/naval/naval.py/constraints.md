# Constraints for `examples/naval/naval.py`

## Rule

- **Rule:** The naval example's ship group must define a 'new' subcommand that takes a name argument and echoes the created ship.
- **Applies to:**
  - `examples/naval/naval.py`
- **Condition:** When adding or modifying subcommands on the naval example's ship group.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-787b684b7d7c185c5bcecaad.md)

## Rule

- **Rule:**
  ```text
  The naval example must apply @click.group() together with @click.version_option() on the cli function, demonstrating combined group and version-option decoration.
  ```
- **Applies to:**
  - `examples/naval/naval.py`
- **Condition:** When modifying the naval example's cli function decoration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a5a2fe3c2f1b2f3621462b33.md)

## Rule

- **Rule:** The naval example must import click, indicating the example is built on the public click API.
- **Applies to:**
  - `examples/naval/naval.py`
- **Condition:** When modifying the naval example's imports.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e3167ce56531f94bc31ed0db.md)
