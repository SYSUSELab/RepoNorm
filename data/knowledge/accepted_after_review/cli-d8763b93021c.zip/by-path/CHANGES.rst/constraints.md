# Constraints for `CHANGES.rst`

## Rule

- **Rule:** An entry must be added in CHANGES.rst using the same style as other entries, and relevant docstrings must include .. versionchanged:: inline changelogs.
- **Applies to:**
  - `**/*.py`
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-bb7c625621ef139e27960b17.md)

## Rule

- **Rule:** The flit sdist build includes docs/, requirements/, tests/, CHANGES.rst, and tox.ini in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `requirements/**`
  - `tests/**`
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c1e594104b9bca604862ff95.md)
