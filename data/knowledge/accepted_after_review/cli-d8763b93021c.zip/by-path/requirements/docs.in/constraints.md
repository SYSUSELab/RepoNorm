# Constraints for `requirements/docs.in`

## Rule

- **Rule:** The update-requirements tox environment runs pip-compile on docs.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/docs.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a333ae298a7c54123c0862f2.md)
