# Constraints for `requirements/build.in`

## Rule

- **Rule:** The update-requirements tox environment runs pip-compile on build.in with -q and posargs defaulting to -U.
- **Applies to:**
  - `requirements/build.in`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aa40ab6ac15aefec362b96b3.md)
