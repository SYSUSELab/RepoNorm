# Constraints for `tests/test_command_decorators.py`

## Rule

- **Rule:** Tests covering Click command-decorator application must verify that the decorator can be applied to a minimal callback function and that the resulting command executes correctly.
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** when modifying or adding tests for Click command-decorator application to a minimal callback
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1d69dbcafed0f2ed6828c9f5.md)

## Rule

- **Rule:**
  ```text
  test_generate_name must parametrize over init_data, init_data_command, init_data_cmd, init_data_group, and init_data_grp, set f.__name__ to the name, wrap it with click.command, and assert the generated command name is 'init-data'.
  ```
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:**
  ```text
  When modifying or extending test_generate_name, preserve the parametrization over the five name variants and the assertion that the generated command name is 'init-data'.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-37e2de895f5bf5e76158c562.md)

## Rule

- **Rule:** Tests covering Click group decorator cls parameter must verify that @click.group(cls=CustomGroup) creates a group of the custom subclass.
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** when modifying or adding tests for the Click group decorator cls parameter with a custom Group subclass
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-37ff288ce2f7f5359c33c036.md)

## Rule

- **Rule:**
  ```text
  Tests that verify click's extension points must keep the minimal subclass pattern: a CustomCommand subclass of click.Command with an empty body, and a click.Group subclass setting command_class to a custom Command subclass, so that subclassing and command_class behavior remain covered.
  ```
- **Applies to:**
  - `tests/test_command_decorators.py`
  - `tests/test_custom_classes.py`
- **Condition:**
  ```text
  When modifying or adding tests that exercise click.Command subclassing or the command_class extension point on groups.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-98cd1c6215bda21d244302a5.md)

## Rule

- **Rule:**
  ```text
  Tests for command decorator params must assert that params passed to the decorator are appended in order, with cli.params[0].name == 'a' and cli.params[1].name == 'b', and that invoking with '1 2' outputs '1 2'.
  ```
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** When modifying or adding tests for command decorator params ordering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ce07cb5b989aaccf7382422f.md)
