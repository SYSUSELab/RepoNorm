# Constraints for `tests/test_normalization.py`

## Rule

- **Rule:** Normalization tests must assert that uppercase option names such as --FOO and -X are accepted and their values are passed through, confirming case-insensitive option matching.
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:** When modifying or extending normalization tests, preserve assertions that uppercase option names are accepted and values passed through.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-45ff0143f18b147952570aae.md)

## Rule

- **Rule:**
  ```text
  Normalization tests must define a click.group with CONTEXT_SETTINGS as a stable fixture for exercising context normalization behavior.
  ```
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:**
  ```text
  When modifying or extending normalization tests that define a click.group with CONTEXT_SETTINGS.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5af48afed3396455a600159d.md)

## Rule

- **Rule:**
  ```text
  Normalization tests must define CONTEXT_SETTINGS with token_normalize_func=lambda x: x.lower() to establish the shared case-insensitive normalization convention.
  ```
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:**
  ```text
  When adding or modifying normalization tests, use CONTEXT_SETTINGS with token_normalize_func=lambda x: x.lower() for case-insensitive normalization.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8ad0baef3cd8272e8faa34e1.md)
