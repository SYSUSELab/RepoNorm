# Constraints for `tests/test_custom_classes.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise group_class behavior must preserve the invariant that a group with group_class = type creates subgroups of the same type as itself.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:**
  ```text
  When modifying or adding tests that assert group_class = type subgroup creation behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0dd91ca55748ee26752870e6.md)

## Rule

- **Rule:**
  ```text
  Tests covering Click group_class resolution must verify that a group with a custom group_class creates subgroups of that type by default, but that explicitly passing cls=click.Group overrides the custom class.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:**
  ```text
  when modifying or adding tests for Click group_class resolution or subgroup class selection
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8d688900e5494b3e244280b3.md)

## Rule

- **Rule:**
  ```text
  CustomGroup must set command_class = CustomCommand to demonstrate the command_class attribute controlling the command type created by a group.
  ```
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:**
  ```text
  When modifying or extending custom class tests, preserve the use of command_class attribute to control the command type created by a group.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-93afde2e755431a4d7ea9824.md)

## Rule

- **Rule:**
  ```text
  Tests that verify click's extension points must keep the minimal subclass pattern: a CustomCommand subclass of click.Command with an empty body, and a click.Group subclass setting command_class to a custom Command subclass, so that subclassing and command_class behavior remain covered.
  ```
- **Applies to:**
  - `tests/test_command_decorators.py`
  - `tests/test_custom_classes.py`
- **Condition:**
  ```text
  When modifying or adding tests that exercise click.Command subclassing or the command_class extension point on groups.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-98cd1c6215bda21d244302a5.md)

## Rule

- **Rule:** Tests that exercise custom Group subclasses must preserve the subclassing contract; changing Group subclass behavior requires updating these tests.
- **Applies to:**
  - `tests/test_custom_classes.py`
- **Condition:** When modifying click.Group subclassing behavior, the custom-subgroup test must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b66b79f06f2b84fa86658b8b.md)
