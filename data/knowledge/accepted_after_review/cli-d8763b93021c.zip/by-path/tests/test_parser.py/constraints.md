# Constraints for `tests/test_parser.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise Click's internal parser helpers must import _OptionParser from click.parser and split_arg_string from click.shell_completion directly, since these internal helpers are exercised directly by tests.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:** when modifying or adding tests that exercise Click's internal parser helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-436c12b2fd364ab129f63036.md)

## Rule

- **Rule:**
  ```text
  Tests for split_arg_string must verify that quoted strings and backslash escapes are handled, including that an unterminated quote still yields the quoted content and a trailing backslash is dropped.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:**
  ```text
  when adding or modifying tests for split_arg_string in tests/test_parser.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-69a37ef2022ee510bd1610af.md)
