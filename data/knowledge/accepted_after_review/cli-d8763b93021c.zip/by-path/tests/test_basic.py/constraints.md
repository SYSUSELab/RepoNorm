# Constraints for `tests/test_basic.py`

## Rule

- **Rule:**
  ```text
  Tests for click group help and execution must assert that --help output contains 'COMMAND [ARGS]...' and both root and subcommand descriptions without executing the root, while invoking the subcommand executes both root and subcommand with exit_code 0.
  ```
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests for click group help output or group command execution
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-503701d22a854f5d47db2100.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Click's option parsing must preserve the exact collected-value ordering and separator conventions when using multiple=True options, since downstream assertions join repeated values with '|'.
  ```
- **Applies to:**
  - `tests/test_basic.py`
  - `tests/test_options.py`
- **Condition:** when modifying or adding tests that use multiple=True options and assert on collected values
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5c2010afec43e364bcdd9214.md)

## Rule

- **Rule:** Basic CLI functionality tests must assert that --help exits 0, prints help text, and does not execute the command body, while invoking with no args executes the command body and exits 0.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying basic CLI invocation tests covering --help and no-argument execution
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6b902901c5635dc55ca8067b.md)

## Rule

- **Rule:** Tests asserting Click's eager-flag evaluation order must preserve the documented sequence: eager flags run before normal flags, and repeated normal flags are processed once.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when modifying or adding tests that assert Click eager-flag versus normal-flag evaluation order
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-728dc37c7e9381cc96e40bf7.md)

## Rule

- **Rule:**
  ```text
  Tests for click.Path options must verify that file_okay=False, exists=True, writable=True ensures the path is an existing writable directory, and the callback can write files into it.
  ```
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:**
  ```text
  When adding or modifying tests for click.Path option validation with file_okay, exists, and writable parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-74f9c8271b0f07785abf8d26.md)

## Rule

- **Rule:** Tests that exercise hidden options must preserve the convention that hidden options do not appear in --help output.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When modifying or adding tests that assert hidden options are excluded from --help output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b7b5ebc98d210d73134d0d9.md)

## Rule

- **Rule:** Tests that exercise boolean flags must preserve the contract that the flag's return value equals the expected boolean, with default=True inverting the expectation.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When modifying or adding tests that assert boolean flag return values with parametrized defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8bec742d2b8196292ffa9937.md)

## Rule

- **Rule:**
  ```text
  Tests covering lazy file mode must assert that opening is deferred: a directory path passed as --file exits 1 when do_io is True (lazy open attempted) but exits 0 when do_io is False, while non-lazy input exits 2 with an invalid value message.
  ```
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when adding or modifying tests for lazy file mode or --file option handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a0bd400d407489ca25fc521b.md)

## Rule

- **Rule:** Tests that exercise Click's option validation must preserve the exact error message format "Invalid value for '--foo': Value needs to be positive" for custom callbacks and the exact UUID error message "Error: Invalid value for '--u': 'x' is not a valid UUID." for invalid UUIDs.
- **Applies to:**
  - `tests/test_basic.py`
  - `tests/test_options.py`
- **Condition:** when modifying or adding tests that assert on Click's option validation error messages
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c4525eefb89150b8d8c5f083.md)

## Rule

- **Rule:** Tests for click float option parsing must assert that empty args yield the default value, '--f=23.5' yields 23.5, and invalid input '--f=x' produces an error message and a non-None exception.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests for click float option parsing
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c4d532fff4b3fafb46e7c74d.md)

## Rule

- **Rule:** Boolean flag conversion must accept the case-insensitive truthy set 1/true/t/yes/y/on and falsy set 0/false/f/no/n/off, with lowercase and title-cased forms producing the same result.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When modifying boolean flag conversion behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c775247ecc798bb2378c575e.md)

## Rule

- **Rule:** Tests covering Click subcommand registration must verify that a subcommand is registered by decorating a function with @cli.command() on an existing group and that the subcommand body echoes a sentinel string used by tests to verify execution.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when modifying or adding tests for Click subcommand registration via @cli.command() on an existing group
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ceaae26399fede13585edee5.md)

## Rule

- **Rule:** click.File options with lazy=False must open the file eagerly so the callback can write to it immediately, in contrast to lazy file handling.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When modifying click.File lazy/eager opening behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e9c50aa3e638cf262010cfa8.md)

## Rule

- **Rule:** String option defaults must be passed through to the command callback, so an option declared with default="no value" echoes that default when not supplied.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When modifying string option default handling or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fa25fbdcb0f724afcf48a135.md)
