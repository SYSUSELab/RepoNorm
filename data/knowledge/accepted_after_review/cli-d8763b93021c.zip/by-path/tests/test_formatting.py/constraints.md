# Constraints for `tests/test_formatting.py`

## Rule

- **Rule:** Tests that exercise custom ParamType rendering must preserve the convention that a command with a custom ParamType instance and a help option renders the custom type in help output.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying or adding tests that assert custom ParamType rendering in help output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0adb7ec8cfec12697a540d7d.md)

## Rule

- **Rule:** Tests that assert exact help/usage text must keep the expected output in sync with the formatter's wrapping, paragraph, and indentation behavior; changing help rendering requires updating these exact-output assertions.
- **Applies to:**
  - `tests/test_formatting.py`
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying help-text rendering (wrapping, \b paragraph preservation, indentation, or envvar/option help display), the exact-output assertions in the formatting and options tests must be updated to match.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4ce25edb65b8ee3cf39e5d0e.md)

## Rule

- **Rule:** Tests that assert exact CLI usage-error output must preserve the full rendered block: the 'Usage:' line, the "Try 'cmd --help' for help." line, a blank line, and the 'Error: ...' line, with exit code 2.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying or adding tests that assert CLI usage-error output formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-78ab6e1852272c7368cea20d.md)

## Rule

- **Rule:** Tests covering Click metavar formatting must verify that an explicit metavar overrides the type-derived name in help formatting.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** when modifying or adding tests for Click metavar formatting in help output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9831ba84a48d521d202fea55.md)

## Rule

- **Rule:**
  ```text
  Help text truncation must occur at a form feed (\f) in a command docstring, and tests must define a command whose docstring contains \f followed by text.
  ```
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying help text truncation behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bc334eec2efb349dd0ba19f0.md)

## Rule

- **Rule:** Tests that exercise usage-error formatting must preserve the convention that a missing required argument exits with code 2 and prints a usage line followed by "Error: Missing argument 'ARG'.".
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying or adding tests that assert usage-error output for a missing required argument.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cfcd55d3705ddf7d0b749ab4.md)
