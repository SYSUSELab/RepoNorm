# Constraints for `tests/test_compat.py`

## Rule

- **Rule:**
  ```text
  Tests for should_strip_ansi must verify that a stream whose __module__ is 'ipykernel.faked' returns False, so Jupyter kernel streams are detected by module name and ANSI stripping is disabled.
  ```
- **Applies to:**
  - `tests/test_compat.py`
- **Condition:**
  ```text
  when adding or modifying tests for should_strip_ansi in tests/test_compat.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8c46fc020fb78e79415d8876.md)
