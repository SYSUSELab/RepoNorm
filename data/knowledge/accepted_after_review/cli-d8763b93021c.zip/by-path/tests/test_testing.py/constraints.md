# Constraints for `tests/test_testing.py`

## Rule

- **Rule:** Tests that exercise File argument behavior must preserve the convention that a click.File() argument exposes the opened file's name and mode.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying or adding tests that assert click.File() argument attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3c9707667f3e8eda7b4f91cf.md)

## Rule

- **Rule:** The testing harness must handle a string exit code from sys.exit by producing the corresponding exit code and output.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying or extending tests for the testing harness's handling of string exit codes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4574aaa45a8c9fab273821fb.md)

## Rule

- **Rule:**
  ```text
  Tests that set prog_name in CliRunner invocations must assert no exception and output 'ok\n', verifying that prog_name can be set in the runner invocation.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  when adding or modifying tests that set prog_name in CliRunner invocations in tests/test_testing.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5860203b2cdba6c0f8b4271b.md)

## Rule

- **Rule:** Tests covering CliRunner environment-variable injection must verify that the runner injects the specified environment variable so that the command body can read it via os.environ.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** when modifying or adding tests for CliRunner environment-variable injection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7b6e8059aeb2a833345f075b.md)

## Rule

- **Rule:**
  ```text
  CliRunner must capture stdout and stderr separately, and the cli_stderr fixture must interleave stdout and stderr writes via click.echo(err=True) to assert that behavior.
  ```
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying CliRunner stdout/stderr capture behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-83b9d70725702d74b0534609.md)

## Rule

- **Rule:** Tests that exercise CliRunner stream separation must assert that result.output interleaves stdout and stderr in write order, result.stdout contains only stdout lines, result.stderr contains only stderr lines, and an empty-stderr command yields result.stderr == ''.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:**
  ```text
  when adding or modifying CliRunner stream-separation tests in tests/test_testing.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-99ff9564d24a67836055ad1f.md)
