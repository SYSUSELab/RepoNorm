# Constraints for `tests/test_arguments.py`

## Rule

- **Rule:** Tests that exercise argument construction must preserve the convention that constructing click.Argument with multiple=True raises TypeError with a message matching "multiple".
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying or adding tests that assert click.Argument rejects multiple=True.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-932329d62dbaa38c601b3196.md)
