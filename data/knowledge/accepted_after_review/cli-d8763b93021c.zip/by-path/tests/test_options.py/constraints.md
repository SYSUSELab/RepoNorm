# Constraints for `tests/test_options.py`

## Rule

- **Rule:** Tests that subclass click.Argument to define a custom argument type must demonstrate that Argument is designed for subclassing and that the custom class is used in test scenarios.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when adding or modifying tests that subclass click.Argument for custom argument types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-06fad2a24db590d47a69aad0.md)

## Rule

- **Rule:** Tests for invalid nargs configuration must assert that a TypeError is raised with a message matching 'nargs=-1'.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying or adding tests for invalid nargs error handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0b12729ec112405d8c449f72.md)

## Rule

- **Rule:** Tests covering Click case-insensitive Choice must verify that a case-insensitive Choice accepts case variants and echoes the canonical choice, while a case-sensitive command rejects non-canonical variants with exit code 2.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when modifying or adding tests for Click case-insensitive Choice behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1e05d45201c31933d93a1a21.md)

## Rule

- **Rule:**
  ```text
  With auto_envvar_prefix='test' and env TEST_ARG=foo, invoking the command with no arguments must succeed and output 'foo', showing the prefix is uppercased and combined with the argument name.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying or extending tests for auto_envvar_prefix, preserve the behavior that the prefix is uppercased and combined with the argument name to read environment variables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-23f91a1fd60a13da8bdb5af0.md)

## Rule

- **Rule:**
  ```text
  Tests for click nargs parameters with auto_envvar_prefix must assert that environment variable values are split on whitespace into multiple values, e.g. TEST_ARG='foo bar' yields 'foo|bar\n' and 'x 1 y 2' yields 'x|1\ny|2\n'.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying tests for click nargs parameters with auto_envvar_prefix
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3bab3540d6d3933a113b8ef8.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise click's help/usage rendering must preserve the documented output contracts: make_default_short_help truncates at word boundaries within max_length and appends an ellipsis (a no-wrap marker does not change the result), show_choices=False renders type metavars such as [TEXT] or [TEXT|INTEGER] instead of choice values, and an empty multiple default with show_default=True is omitted from help (get_help_extra returns {} and the help record message is 'values').
  ```
- **Applies to:**
  - `tests/test_options.py`
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests that assert click help/usage output for short-help truncation, choice metavars, or empty multiple defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-49ced9dfbcec31ad8309798e.md)

## Rule

- **Rule:**
  ```text
  A test command using nargs=2 (without multiple) must parse the two values as a single tuple, echoed joined by '|'.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying or extending tests for nargs=2 parsing without multiple.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4ba1690d5f6216ba3dba4fbb.md)

## Rule

- **Rule:** Tests that assert exact help/usage text must keep the expected output in sync with the formatter's wrapping, paragraph, and indentation behavior; changing help rendering requires updating these exact-output assertions.
- **Applies to:**
  - `tests/test_formatting.py`
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying help-text rendering (wrapping, \b paragraph preservation, indentation, or envvar/option help display), the exact-output assertions in the formatting and options tests must be updated to match.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4ce25edb65b8ee3cf39e5d0e.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise click's file and option parsing utilities must preserve the documented behaviors: click.open_file with encoding='utf8' and errors='ignore' reads invalid UTF-8 bytes without raising, and a multiple option with is_flag=False and flag_value='flag' collects 'flag' when passed without a value and the following token as a value otherwise, producing a tuple of mixed values.
  ```
- **Applies to:**
  - `tests/test_options.py`
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When modifying or adding tests that assert open_file error handling or multiple-option optional-value parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5457a4d06ce4d34373ca9a95.md)

## Rule

- **Rule:** Tests that exercise Click's option prefixes must preserve the acceptance of non-standard prefixes like '++' as flag option names, demonstrating that option prefixes are not limited to '--' and '-'.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when modifying or adding tests that exercise option prefix handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5b7b893689a5b5ae5acf98a7.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Click's option parsing must preserve the exact collected-value ordering and separator conventions when using multiple=True options, since downstream assertions join repeated values with '|'.
  ```
- **Applies to:**
  - `tests/test_basic.py`
  - `tests/test_options.py`
- **Condition:** when modifying or adding tests that use multiple=True options and assert on collected values
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5c2010afec43e364bcdd9214.md)

## Rule

- **Rule:**
  ```text
  Tests covering Click boolean-flag default display must verify that when a boolean flag has only one option and its default is False or None, get_help_extra returns an empty dict and the help record omits the "[default: ...]" text even when show_default=True.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when modifying or adding tests for Click boolean-flag default display in help output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-72f3763f13f8cedf24382518.md)

## Rule

- **Rule:**
  ```text
  An empty-string environment variable (both MYPATH and AUTO_MYPATH with auto_envvar_prefix) must be treated as unset, producing 'mypath: None' output with no exception.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying or extending tests for environment variable handling of empty-string values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-734ebde01330f01f8c80cb69.md)

## Rule

- **Rule:** Tests that exercise option suggestion and bool-flag-with-type behavior must be updated when option parsing or suggestion logic changes.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying unknown-option suggestion logic or bool-flag-with-type acceptance, the corresponding assertions in the options test file must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-846a5a2fe071e6546465b39c.md)

## Rule

- **Rule:** Tests covering Click option-prefix parsing must verify that options accept a configurable doubled prefix (e.g. "++foo") and that help output renders the configured prefix form.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when modifying or adding tests for Click option-prefix parsing or help rendering of prefixed options
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-856cda2567a3f713b288580d.md)

## Rule

- **Rule:**
  ```text
  Multiple=True options must split envvar values on os.path.pathsep, and auto_envvar_prefix must map TEST_ARG to the option, producing pathsep-joined output.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying multiple-option envvar splitting or auto_envvar_prefix behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8ec73a637be26b7ea9381afc.md)

## Rule

- **Rule:** Tests for click option validation callbacks must assert that the callback raises click.BadParameter with the expected message for invalid values and returns the value otherwise.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When adding or modifying tests for click option validation callbacks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b64645632c5e54ac00e81ebc.md)

## Rule

- **Rule:**
  ```text
  Tests that verify custom option/argument classes must keep using the get_help_record override and default/hidden display behavior as the extension points under test.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying tests for custom option or argument classes and their help/default rendering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-be5083cea9c5f4a83ba76f71.md)

## Rule

- **Rule:** Tests that exercise Click's option validation must preserve the exact error message format "Invalid value for '--foo': Value needs to be positive" for custom callbacks and the exact UUID error message "Error: Invalid value for '--u': 'x' is not a valid UUID." for invalid UUIDs.
- **Applies to:**
  - `tests/test_basic.py`
  - `tests/test_options.py`
- **Condition:** when modifying or adding tests that assert on Click's option validation error messages
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c4525eefb89150b8d8c5f083.md)

## Rule

- **Rule:**
  ```text
  click.Option(['foo']) must raise TypeError whose message contains 'name was passed (foo)', 'declare an argument', and "'--foo'", pinning the error text for options declared without dashes.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying or extending tests for option declaration errors when names lack dashes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c4d8baaa899bb6206eb55509.md)

## Rule

- **Rule:** Tests for click option help output must assert that multiple default values are shown alongside option names, e.g. 'foo, bar' and '1, 2'.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When adding or modifying tests for click option help output with multiple defaults
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d8f660d6e79d645ae2b83630.md)

## Rule

- **Rule:** Tests that exercise custom option validation callbacks must preserve the convention that validation failures are signaled by raising click.BadParameter with a descriptive message.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying or adding tests for custom option callbacks that validate parameter values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e292974b150b2aa80dd25c80.md)

## Rule

- **Rule:** Tests that exercise option help text must preserve the convention that paragraph breaks in help strings are rendered as an indented blank line followed by the continuation paragraph, with indentation matching the option column.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying or adding tests that assert option help text rendering with paragraph breaks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e55587049ca3ee626fa5bb36.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise prompted options with callable defaults must preserve the convention that show_default may be a custom label string (e.g. "current user") rather than a boolean.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying or adding tests for prompted options that use a callable default and a custom show_default label.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f2821c58ad119db775f11492.md)

## Rule

- **Rule:** Help output for a dynamic default must contain '(dynamic)' and must not contain 'lambda', establishing the placeholder used for callable defaults in help text.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying or extending tests for help output of options with dynamic (callable) defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fb36fe6b93090687bdef20f4.md)

## Rule

- **Rule:** Tests for boolean flag aliases must declare options with paired boolean flags (e.g. --warnings/--no-warnings) plus short aliases and default=True, and assert the callback receives the resolved boolean.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when adding or modifying tests for boolean flag aliases or paired flag declarations
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fd0f8043590fdf537c346874.md)
