# Constraints for `tests/test_termui.py`

## Rule

- **Rule:**
  ```text
  Tests covering Click progress-bar formatting must verify the exact formatted progress line including bar, position, and percentage for the parametrized length, show_percent, show_pos, and pos values.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** when modifying or adding tests for Click progress-bar formatting of the progress line
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2d59649ec622febb8586e716.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Click's progressbar must keep iteration inside the progressbar's context manager, since iterating outside the with block raises RuntimeError, and non-TTY output must remain exactly 'working\n'.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** when modifying or adding tests that iterate a progressbar or assert on non-TTY progressbar output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-38f187c5a3840bf29cb372e4.md)

## Rule

- **Rule:**
  ```text
  Tests for click progressbar rendering must monkeypatch click._termui_impl.isatty to True and assert that a padded progressbar label is preserved in output, guarding against a strip regression.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When adding or modifying tests for click progressbar rendering
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3e9f45c9e84c96eaa7818d7b.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise progress bar formatting must preserve the invariant that format_bar renders a fixed-width bar where an unfinished bar at pos 7 shows '#######-' and a finished bar shows all eight '#' characters regardless of pos.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When modifying or adding tests that assert progress bar format_bar output for fixed widths.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4e64d8b6ef87f81de7e3123c.md)

## Rule

- **Rule:** Tests for confirmation prompts must assert that matching password input returns the password, empty input with empty default returns empty string, prompt=False returns None, and a custom prompt text appears in output.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  when adding or modifying confirmation prompt tests in tests/test_termui.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-521a33474be048d23a39e4f8.md)

## Rule

- **Rule:** Tests that exercise Windows getchar special-key behavior must preserve the convention that getchar returns the special key character followed by the next key character when msvcrt.getwch yields a special key then a normal key, and must be skipped when not on Windows.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying or adding tests that assert Windows getchar special-key handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5bcd0c404945179ef420f7df.md)

## Rule

- **Rule:**
  ```text
  Tests for prompt option interaction must parameterize prompt=True together with prompt_required and required, treating prompt_required as a distinct option behavior tested independently from required.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  when adding or modifying tests for prompt option interaction or prompt_required behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a3f12786eb45e7d3dc66d0d7.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise click's terminal prompt behavior must parametrize over the prompt/required flag combinations and assert the exact prompt-vs-error outcome, because prompt_required and required interact: with prompt_required=True and required=False a flag without a value errors while no args prompts, and with required=True both no args and a valueless flag prompt.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When adding or modifying tests for click prompt behavior involving prompt_required and required flags
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bffd28322820574b555335ef.md)

## Rule

- **Rule:**
  ```text
  Windows-specific getchar behavior must keep mapping Ctrl-C (\x03) to KeyboardInterrupt and Ctrl-Z (\x1a) to EOFError, tested by monkeypatching msvcrt.getwch and disabling _getchar.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying Windows getchar exception handling or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cd14cbcf283b740a008dd881.md)

## Rule

- **Rule:**
  ```text
  The file prompt must display and echo the file path in the format 'file [<path>]: \n<path>\n' regardless of file_kwargs variants mode='rt', mode='rb', and lazy=True.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying or extending file prompt tests that assert the default display and echoed value.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d91992ee75bac8fde4566600.md)

## Rule

- **Rule:** Progressbar tests must assert that iterating a progressbar over range(3) yields exactly three items, confirming the progressbar is a transparent iterable wrapper.
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying or extending progressbar tests, preserve the assertion that iterating over a progressbar yields exactly the wrapped items.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eb2f8722e0e716bad3704783.md)
