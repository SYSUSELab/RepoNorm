# Constraints for `tests/test_utils.py`

## Rule

- **Rule:** Tests that assert exact stdout/stderr routing for echo/prompt/confirm/pause must be updated when output routing changes; the routing contract (including leading-space and prompt-text placement) is pinned.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying echo/prompt/confirm/pause output routing between stdout and stderr, the exact-routing assertions in the utils test must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-002fb5be1203be478035a58d.md)

## Rule

- **Rule:** LazyFile iteration must yield the file's lines, and tests must compare each expected line to the stripped actual line.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying LazyFile iteration behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-006d570907d25a374b4385c8.md)

## Rule

- **Rule:** Tests for click.echo must verify it does not fail when sys.stdout and sys.stderr are None, as occurs with pythonw on Windows.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests for click.echo behavior under missing standard streams.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-12fb35428b53a2624410a2db.md)

## Rule

- **Rule:**
  ```text
  Tests for click.echo_via_pager must parametrize over string, list, generator function, generator instance, and generator expression inputs, using lambdas to avoid pytest parameter reuse exhausting generators, and assert each produces the same pager output.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for click.echo_via_pager input handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-159b58a5a366e3631b020503.md)

## Rule

- **Rule:**
  ```text
  Tests for _detect_program_name must define expected outputs for plain filenames, absolute paths, package __main__.py, package cli.py, and './example', pinning the program-name detection rules for python -m invocations.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when adding or modifying tests for _detect_program_name in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2899b75604da5522b52c6aa8.md)

## Rule

- **Rule:** click.prompt with a string default and type=int must return an int, verifying that the default is cast through the declared type.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or extending tests for prompt default type casting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-376f2f399e53009c3b0bdc16.md)

## Rule

- **Rule:** The test defines a command using click.confirm with default=True, branching to echo 'yes!' or 'no :(' based on the confirmation result.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or extending tests for click.confirm with default=True.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3fa83b6d228e0ab67ff1b6c7.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise click's help/usage rendering must preserve the documented output contracts: make_default_short_help truncates at word boundaries within max_length and appends an ellipsis (a no-wrap marker does not change the result), show_choices=False renders type metavars such as [TEXT] or [TEXT|INTEGER] instead of choice values, and an empty multiple default with show_default=True is omitted from help (get_help_extra returns {} and the help record message is 'values').
  ```
- **Applies to:**
  - `tests/test_options.py`
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests that assert click help/usage output for short-help truncation, choice metavars, or empty multiple defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-49ced9dfbcec31ad8309798e.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise click's file and option parsing utilities must preserve the documented behaviors: click.open_file with encoding='utf8' and errors='ignore' reads invalid UTF-8 bytes without raising, and a multiple option with is_flag=False and flag_value='flag' collects 'flag' when passed without a value and the following token as a value otherwise, producing a tuple of mixed values.
  ```
- **Applies to:**
  - `tests/test_options.py`
  - `tests/test_utils.py`
- **Condition:**
  ```text
  When modifying or adding tests that assert open_file error handling or multiple-option optional-value parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5457a4d06ce4d34373ca9a95.md)

## Rule

- **Rule:** Tests for KeepOpenFile iteration must write lines to a file and assert that iterating click.utils.KeepOpenFile(f) yields each line matching the expected value after strip().
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when adding or modifying tests for KeepOpenFile iteration in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-58bd4e9681cfa5c94787720e.md)

## Rule

- **Rule:**
  ```text
  click.unstyle must strip non-SGR ANSI sequences such as cursor show/hide (\x1b[?25l / \x1b[?25h) while preserving surrounding text, so unstyle is not limited to color codes.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or extending tests for ANSI sequence stripping behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-619997141c81753ad48ee83e.md)

## Rule

- **Rule:** Tests that exercise ANSI style mapping must preserve the convention that click.style maps named colors, integer and RGB background values, and boolean attributes to specific ANSI escape sequences, with click.unstyle reversing them and reset=False omitting the trailing reset.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests that assert click.style and click.unstyle ANSI escape sequence mappings.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-76746297ace8550dc073d596.md)

## Rule

- **Rule:**
  ```text
  Tests for _expand_args must assert that user home, environment variables, and glob patterns are expanded, and that unmatched or invalid glob patterns (including pytest-style identifiers) are returned unchanged rather than raising.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when adding or modifying tests for _expand_args or argument expansion behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7c080fd812c80fa04b9d097f.md)

## Rule

- **Rule:**
  ```text
  Tests for click.echo must verify that output is written to an arbitrary file-like object passed via file=, including the appended newline, and must use the emulate_input helper convention (replacing sys.stdin with StringIO) when simulating keyboard input.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When adding or modifying tests for click.echo output redirection or tests that simulate keyboard input
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ae325fdf005612d1f1648534.md)

## Rule

- **Rule:** Tests that exercise atomic file permission behavior must preserve the convention that a newly written file's permission bits match those of a file created under the current umask, and must be skipped on Windows where os.stat() is not fully supported.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests that assert atomic file permission behavior for newly written files.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cf7349b0008da4d05f133d66.md)

## Rule

- **Rule:**
  ```text
  Tests for non-ASCII byte output must assert that the CLI echoes the exact bytes (e.g. b'\xf6') without corruption.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests for non-ASCII byte output handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d8183bb2e5baaebf95a4c38b.md)

## Rule

- **Rule:**
  ```text
  Tests for click.echo color behavior must monkeypatch click._compat.isatty and assert that color=False strips ANSI styling, color=True preserves it, and default color behavior follows isatty; these tests are skipped on Windows.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when adding or modifying click.echo color tests in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d8540ebe6db0f4471274d0fa.md)

## Rule

- **Rule:**
  ```text
  Tests for confirm prompts must assert exact prompt/response output: default-True prompts render 'Foo [Y/n]: ' and empty input yields 'yes!', while default-False prompts render 'Foo [y/N]: ' and empty input yields 'no :('.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests for confirm prompt formatting and default-echo behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f393c7bd373918c59cb3cd5c.md)
