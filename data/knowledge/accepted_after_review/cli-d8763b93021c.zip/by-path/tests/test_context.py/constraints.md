# Constraints for `tests/test_context.py`

## Rule

- **Rule:**
  ```text
  Tests covering Click context option-prefix propagation must verify that Context._opt_prefixes is inherited from parent to child context.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when modifying or adding tests for Click context option-prefix propagation between parent and child contexts
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5a07980a6c7c9159cdf0fa99.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise click context APIs must preserve the documented behaviors: pass_meta_key generates a docstring including the default description referencing click.Context.meta (with custom doc_description replacing it), ctx.get_parameter_source reports where an option value originated, and ctx.call_on_close callbacks run on context teardown.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  When modifying or adding tests that assert pass_meta_key docstring generation, parameter source inspection, or close callback execution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5c746c57388f68114a000843.md)

## Rule

- **Rule:**
  ```text
  Tests for click context resource lifecycle must assert that ctx.with_resource registers a context manager whose value is available during the scope and is closed on scope exit, with the returned value reflecting post-close state.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  When adding or modifying tests for click context resource lifecycle with ctx.with_resource
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aa137e21c9c5e02ea53bd70e.md)

## Rule

- **Rule:**
  ```text
  Context lifecycle tests must verify that a call_on_close callback can still read the current context object via click.get_current_context(), indicating close callbacks run while the context is still active.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  When modifying or extending context lifecycle tests, preserve the assertion that call_on_close callbacks can read the current context via click.get_current_context().
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c8f9b493622d79eac96f9461.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise the pass-object decorator pattern must keep the injected-object contract; changing pass_* decorator behavior requires updating these tests.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  When modifying pass_* decorator injection behavior, the pass-object test in the context test file must be updated.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ecf004ec8506df35db2646e0.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Click's context pushing must preserve the distinction between ctx.scope(cleanup=False), which increments _depth without running close callbacks, and ctx.scope(), which increments _depth and runs close callbacks.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** when modifying or adding tests that exercise ctx.scope with or without cleanup
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f006919196c998ab97d2dd83.md)

## Rule

- **Rule:**
  ```text
  Tests for click multi-enter command handling must assert that invoking a multi-enter command yields no exception and records called == [True], verifying repeated-enter handling.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:** When adding or modifying tests for click multi-enter command handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f3f57c3ba4f148d87a0c0d6e.md)
