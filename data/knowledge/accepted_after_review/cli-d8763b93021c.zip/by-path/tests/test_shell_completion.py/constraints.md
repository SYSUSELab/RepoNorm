# Constraints for `tests/test_shell_completion.py`

## Rule

- **Rule:** Tests covering Click shell-completion option scoping must verify that a group and its subcommand may each define the same option and that completion offers the subcommand's option only after the subcommand name is present, otherwise offering the group's option.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when modifying or adding tests for Click shell-completion option scoping between a group and its subcommand
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1946144c734066df39bcc115.md)

## Rule

- **Rule:** Shell completion for arguments must use the argument's default value when no value is supplied and must ignore type validation, returning the next argument's default even when the prior value is invalid.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or extending shell completion tests for arguments, preserve the behavior that defaults are used and type validation is bypassed during completion.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1afd7b5de77943666ceec116.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise click's shell completion must preserve the plain completion output protocol: a custom shell_complete callback can read context obj choices and emits newline-separated completion candidates such as 'plain,a\nplain,b\n' for bash.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When modifying or adding tests that assert shell completion output from a custom shell_complete callback, the test must preserve the plain completion output protocol: the callback reads context obj choices and emits newline-separated completion candidates such as 'plain,a\nplain,b\n' for bash.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-20d5e14940cb8295671728e7.md)

## Rule

- **Rule:**
  ```text
  Shell completion tests must keep exercising the public shell_completion API surface (add_completion_class, CompletionItem, ShellComplete) together with core Command/Group/Option/Argument and Choice/File/Path types, because these are the stable entry points the completion tests depend on.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying shell completion tests or the completion API surface they import.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2c40f40da6af63474aa830fd.md)

## Rule

- **Rule:**
  ```text
  Tests for shell completion must parametrize over bash, zsh, and fish and assert that invoking with _CLI_COMPLETE=<shell>_source produces output containing _CLI_COMPLETE=<shell>_complete.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or adding tests for shell completion source/complete protocol behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-362ea6e46ce841769ffa5366.md)

## Rule

- **Rule:**
  ```text
  Tests for add_completion_class must verify that registering a shell name adds it to _available_shells and returns the class, and that the shell name is absent before registration.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying tests for add_completion_class in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3d1c6d5ea832f8aeafc7c4d6.md)

## Rule

- **Rule:** Absolute-path completion for a Path option must yield exactly one completion whose value is the absolute prefix, documenting absolute-path completion behavior.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying absolute-path completion behavior or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-71826de416388f8e429886c0.md)

## Rule

- **Rule:** Shell completion for an option with nargs=2 and a Choice type must return the choice values until both arguments are supplied, then return an empty list.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or extending shell completion tests for options with nargs=2 and a Choice type.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-79fcedc11c236a9419844ef7.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise Click's shell-completion registry must snapshot and restore click.shell_completion._available_shells so that mutations do not leak across tests.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when a test mutates or registers entries in click.shell_completion._available_shells
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-88cf01d913d6cbf6fafa600d.md)

## Rule

- **Rule:** Tests for click shell completion of a Group must assert that an empty prefix returns command names and a '-' prefix returns option/help tokens, establishing the expected completion ordering and content.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When adding or modifying tests for click shell completion of Group commands
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-94bb7172bbea116b24789ad2.md)

## Rule

- **Rule:** Tests for shell completion of flag options must verify that completing '--' yields the flag names and that after the flag is given, completion falls through to the Choice argument values, confirming flags do not consume a value.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying shell completion tests for flag options in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9661cf4c56b5ca4d5e40ba5f.md)

## Rule

- **Rule:** Tests covering Click shell-completion callbacks must verify that the completion callback reads choices from the context object (ctx.obj).
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when modifying or adding tests for Click shell-completion callbacks that read choices from the context object
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-986d15ace174b982796ece03.md)

## Rule

- **Rule:**
  ```text
  Shell completion for an option with is_flag=False and a flag_value must yield no words after the option name with an empty prefix, yield the flag option for a '-' prefix, and yield none after both the option and its flag have been supplied.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When modifying or extending shell completion tests for options with is_flag=False and a flag_value.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ae0e87e747021b48782d0514.md)

## Rule

- **Rule:** Tests that exercise custom shell-completion callbacks must preserve the (ctx, param, incomplete) signature and list-of-strings return contract; changing the callback protocol requires updating these tests.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying the shell-completion callback protocol (signature or return type), the custom-callback test must be updated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b2189d7f57909e8753c19042.md)

## Rule

- **Rule:** Shell completion for a Choice type must filter candidates by the incomplete prefix: an empty prefix returns all choices, a partial prefix returns only matching choices, and an exact match returns only that choice.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or extending shell completion tests for Choice-typed parameters, preserve prefix-based candidate filtering semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b2ed3f06145a311c82518d3f.md)

## Rule

- **Rule:** Shell completion for an option must exclude options already present on the command line; once an option has been supplied, its other spellings must not be suggested again.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or extending shell completion tests for options that have already been supplied on the command line.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b74cba8d525da5926dd2eacd.md)

## Rule

- **Rule:** Tests for CompletionItem must assert that arbitrary keyword data is accepted and that unset attributes return None, defining its attribute access behavior.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when adding or modifying tests for CompletionItem attribute access or data handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d4c1198e7c43d98bbcddeac2.md)

## Rule

- **Rule:**
  ```text
  Shell completion tests must parametrize over Path type configurations and assert that File() or Path() yields completion item type "file" while Path(file_okay=False) yields "dir".
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying path-type completion item type mapping or its tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-db9cc52e525e1266f803e586.md)
