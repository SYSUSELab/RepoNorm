# Constraints for `tests`

## Rule

- **Rule:**
  ```text
  Pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0d62a1719df3b1583e69c95d.md)

## Rule

- **Rule:** Tests for option callbacks must assert that any global state mutated by the callback (e.g., logger level) is reverted to its initial value after CLI invocation.
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test for a Click option callback that mutates global state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-237788893a028df8be2be01a.md)

## Rule

- **Rule:** Coverage measurement is configured to restrict its source to the click package and the tests directory.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-28cd2030c9bb34be433ba7f3.md)

## Rule

- **Rule:** Tests for multiple sequential prompts must define a command with multiple prompt options and drive them through CliRunner with scripted input.
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test for multiple sequential Click prompts
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-30d8e4b7fd1da75ed74c6adb.md)

## Rule

- **Rule:** Tests for flag options must assert that duplicate flag names on both sides of a '--foo/--foo' declaration raise ValueError with the message 'cannot use the same flag for true/false'.
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test for Click flag option duplicate-name validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-35216c901fb8c2674596c25e.md)

## Rule

- **Rule:** Tests for shell completion must use a helper that maps completion items to their .value strings for assertion convenience.
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test for shell completion output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3799af0506b4e610b0101196.md)

## Rule

- **Rule:** Patches that add or change code must include tests, and the test must fail without the patch.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-54f775d25f891ea6b747b0e7.md)

## Rule

- **Rule:** Tests for atomic file writes must assert that the resulting file permissions match the original permissions after the CLI modifies the file.
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test for atomic file write permission preservation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5b422d9b4c84e44ae9f44365.md)

## Rule

- **Rule:** Tests for UUID-typed options must define a command with a UUID option and a fixed default UUID string, exercising UUID parameter conversion and echo formatting.
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test for a Click UUID-typed option
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a121a6416dd634f1c6864b86.md)

## Rule

- **Rule:**
  ```text
  Tests for path options must assert that a directory target writes the file inside it, that an existing file target produces an 'is a file' error, and that showtype/exists options report is_file/is_dir/exists flags in output.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test for Click path option behavior with directory and file targets
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b279ec849749f74321d71c4e.md)

## Rule

- **Rule:** The flit sdist build includes docs/, requirements/, tests/, CHANGES.rst, and tox.ini in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `requirements/**`
  - `tests/**`
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c1e594104b9bca604862ff95.md)

## Rule

- **Rule:**
  ```text
  Tests for range types must assert that invalid clamp/max_open combinations raise at construction time and that post-construction mutation of clamp raises at conversion time.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:**
  ```text
  when adding or modifying a test for Click range type validation of clamp and max_open
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c6f363f5111181d8a995f721.md)

## Rule

- **Rule:** Tests for case-insensitive Choice parameters must assert that the original choice value as defined is returned, not the user-supplied casing.
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test for a case-insensitive Click Choice parameter
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c6ff5664a730507111ce87be.md)

## Rule

- **Rule:**
  ```text
  Tests that exercise CLI behavior through CliRunner must invoke the runner with standalone_mode=False when asserting on the command's return_value, so that Click returns the callback result instead of exiting.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:**
  ```text
  when adding or modifying a test that asserts on a Click command's return_value via CliRunner
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-dac855aeaf04c4523eb7fd97.md)

## Rule

- **Rule:**
  ```text
  Tests for docstring help text must assert that a leading \b marker suppresses rewrapping and that the marker itself does not appear in short help output.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:**
  ```text
  when adding or modifying a test for Click help text derived from a docstring containing the \b marker
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f8b0ae3e2bc754a8fa924f8c.md)

## Rule

- **Rule:** Tests for custom ParamType metavar rendering must assert that the custom metavar appears in the usage line of help output.
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test for a custom Click ParamType's metavar in help output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fb19210e96907013eae04b3d.md)
