# Constraints for `tests/typing/typing_confirmation_option.py`

## Rule

- **Rule:**
  ```text
  Typing example modules under tests/typing must remain static typing compatibility checks: typing_aliased_group defines a command 'pop' returning None to exercise aliased group typing, and typing_confirmation_option asserts a confirmation-option command is typed as click.Command for the documented yes-parameter pattern.
  ```
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
  - `tests/typing/typing_confirmation_option.py`
- **Condition:** When modifying or adding typing example modules under tests/typing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-986d645fda9f79e856caed5c.md)
