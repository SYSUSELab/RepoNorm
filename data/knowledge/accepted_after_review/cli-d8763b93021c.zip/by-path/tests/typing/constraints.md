# Constraints for `tests/typing`

## Rule

- **Rule:** mypy is configured with strict mode enabled.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4771caabc8378478a87bda27.md)

## Rule

- **Rule:** The typing test environment runs pyright against the tests/typing directory.
- **Applies to:**
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-85cdb12a75cc387fa86dd6a6.md)

## Rule

- **Rule:** mypy is configured to show error codes in its output.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9fb387ed633000139a92dbee.md)

## Rule

- **Rule:** mypy is configured to check the files under src/click and tests/typing.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a5a60396cc4b56cc56b3d72a.md)

## Rule

- **Rule:** mypy is configured with pretty output enabled.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f0f6325a7daf927eac59e437.md)

## Rule

- **Rule:** Pyright type checking is scoped to the src/click and tests/typing directories.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fcc25a308a6e9f3469bc4ff3.md)
