# Constraints for `tests/typing/typing_group_kw_options.py`

## Rule

- **Rule:**
  ```text
  Tests that exercise Click's typing must use typing_extensions.assert_type to assert that a decorated command object is statically typed as click.Group.
  ```
- **Applies to:**
  - `tests/typing/typing_group_kw_options.py`
- **Condition:** when modifying or adding typing tests that assert on decorated command object types
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5797206233b173118f1de8f6.md)
