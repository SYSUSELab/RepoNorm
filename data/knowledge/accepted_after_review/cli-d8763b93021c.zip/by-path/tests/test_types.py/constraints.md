# Constraints for `tests/test_types.py`

## Rule

- **Rule:**
  ```text
  Tests that require symlink support must gate on the _symlinks_supported probe, which creates a target file and attempts os.symlink in a temporary directory, returning False on OSError, so that symlink-dependent tests are skipped on unsupported platforms.
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or adding tests that depend on symlink support.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2fa8f3d24a8c9cc94ca1e79a.md)

## Rule

- **Rule:**
  ```text
  Converting a directory whose name contains a newline must raise BadParameter whose message contains the escaped 'my\\ndir'; this test is skipped on Windows.
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or extending tests for path conversion errors with escaped sequences.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bc050402545db6dbf86af6b0.md)
