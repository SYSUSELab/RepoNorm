# Constraints for `tests/test_imports.py`

## Rule

- **Rule:**
  ```text
  Tests must enforce an ALLOWED_IMPORTS allowlist for click's top-level imports, tracking imports via a patched builtins.__import__ and adding ctypes/msvcrt/time on Windows.
  ```
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:**
  ```text
  When adding or modifying tests that enforce click's top-level import allowlist by running an import probe in a subprocess and asserting every imported module is in ALLOWED_IMPORTS
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0b96d71f70d6356549fd487a.md)
