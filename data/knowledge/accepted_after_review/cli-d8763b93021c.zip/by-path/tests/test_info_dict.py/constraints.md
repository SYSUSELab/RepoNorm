# Constraints for `tests/test_info_dict.py`

## Rule

- **Rule:**
  ```text
  Tests for ParamType info dicts must assert that the info dict includes a `name` key even when the param type has no explicit name, falling back to the class name.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  when adding or modifying tests for ParamType info dicts or to_info_dict behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2ea9afd23e92d8785d0a1277.md)

## Rule

- **Rule:**
  ```text
  Tests that pin the serialized info-dict schema must be updated whenever Context.to_info_dict keys change; the exact key set is a compatibility contract.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  When adding, removing, or renaming keys in Context.to_info_dict, the exact-key assertion in the info-dict test must be updated.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-54703f2c97038ba202d0def7.md)
