# Constraints for `docs`

## Rule

- **Rule:**
  ```text
  After building, open `_build/html/index.html` in a browser to view the docs.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../claims/CLAIM-1053b68ac6ae267a946ddf7a.md)

## Rule

- **Rule:** Relevant docs pages and docstrings must be updated, and docs pages and docstrings should be wrapped at 72 characters.
- **Applies to:**
  - `**/*.py`
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../claims/CLAIM-5966b077ce720f4cbb483f9a.md)

## Rule

- **Rule:** Sphinx documentation builds fail on warnings.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a2dc569071f3bc1307b97212.md)

## Rule

- **Rule:**
  ```text
  The docs tox environment builds documentation with sphinx-build using -E -W -b dirhtml, reading from docs and writing to docs/_build/dirhtml.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a86dc268988b290746c176c2.md)

## Rule

- **Rule:** The flit sdist build includes docs/, requirements/, tests/, CHANGES.rst, and tox.ini in the source distribution.
- **Applies to:**
  - `CHANGES.rst`
  - `docs/**`
  - `requirements/**`
  - `tests/**`
  - `tox.ini`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c1e594104b9bca604862ff95.md)

## Rule

- **Rule:** Sphinx documentation builds use the dirhtml builder.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c46f4d5dabe4edc428279c3c.md)

## Rule

- **Rule:** The docs tox environment installs its dependencies from requirements/docs.txt.
- **Applies to:**
  - `docs/**`
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ce963200b61501093d4abeb1.md)
