# Constraints for `docs/_build`

## Rule

- **Rule:**
  ```text
  The flit sdist build excludes docs/_build/ from the source distribution.
  ```
- **Applies to:**
  - `docs/_build/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-03dd292af8afd81e9e1936f0.md)
