# Constraints for `.github/workflows/lock.yaml`

## Rule

- **Rule:** The lock workflow grants write permission to issues and pull requests.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0a2cd5bbf8f10b16b9cd97d5.md)

## Rule

- **Rule:**
  ```text
  The lock workflow runs on a daily schedule defined by the cron expression '0 0 * * *'.
  ```
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Condition:**
  ```text
  workflow predicate: schedule: - cron: '0 0 * * *'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-61388d1d4db0459e6684ead6.md)

## Rule

- **Rule:** The lock job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-97e324b588c20b96b4cfd8c0.md)

## Rule

- **Rule:** The lock workflow uses the dessant/lock-threads action pinned to commit 1bf7ec25051fe7c00bdd17e6a7cf3d7bfb7dc771 (v5.0.1).
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a8d1deffb940ff6223e7090d.md)

## Rule

- **Rule:** The lock workflow uses the concurrency group 'lock'.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ae05d99d71a34a2056c0fd3d.md)

## Rule

- **Rule:** The lock-threads action is configured with issue-inactive-days, pr-inactive-days, and discussion-inactive-days all set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ddc9e06c4d562a417abf3fae.md)
