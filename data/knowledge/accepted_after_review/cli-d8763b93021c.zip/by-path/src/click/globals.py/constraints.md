# Constraints for `src/click/globals.py`

## Rule

- **Rule:**
  ```text
  When modifying pop_context, preserve that it removes the top level from the context stack via _local.stack.pop(), requiring a prior push and raising IndexError on empty stack.
  ```
- **Applies to:**
  - `src/click/globals.py`
- **Condition:**
  ```text
  When changing pop_context or context stack management.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2eaa8b7939681aafa3ea27af.md)

## Rule

- **Rule:**
  ```text
  get_current_context must be overloaded so that silent=False (the default) returns Context, encoding the non-optional return contract for the default call.
  ```
- **Applies to:**
  - `src/click/globals.py`
- **Condition:**
  ```text
  when modifying get_current_context signature or return type annotations
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b3986ae3d7b2ef0b76404406.md)
