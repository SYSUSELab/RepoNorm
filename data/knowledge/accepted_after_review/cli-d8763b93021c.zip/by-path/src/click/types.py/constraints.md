# Constraints for `src/click/types.py`

## Rule

- **Rule:**
  ```text
  ParamType.to_info_dict must derive param_type by stripping the 'ParamType' or 'ParameterType' suffix from the class name and fall back to that derived name when the instance has no name attribute, so custom subclasses without a name still produce a valid info dict.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying ParamType.to_info_dict or adding a ParamType subclass that omits a name attribute.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-01ec075c827d262aa020a898.md)

## Rule

- **Rule:**
  ```text
  When modifying choice validation messages, preserve that get_invalid_choice_message builds a singular/plural ngettext message using repr of the value and the joined repr of choices, so the message wording depends on the number of choices.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when changing how invalid choice errors are formatted
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-05a53dc466c9c4e1b4cf2c56.md)

## Rule

- **Rule:**
  ```text
  When modifying Path.coerce_path_result, preserve the conversion behavior: values are converted to str via os.fsdecode, to bytes via os.fsencode, or to the configured PathLike type, and returned unchanged when they already match the type.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing Path.coerce_path_result or its path type conversion logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-18c75754ded5ac8d63701ca6.md)

## Rule

- **Rule:** ParamType.convert may be a no-op that returns the value unchanged; conversion is optional for param types that do not transform input.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When adding or modifying a ParamType subclass's convert method.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1c460e47e01366c4b3540d76.md)

## Rule

- **Rule:** The numeric convert method must catch ValueError from the number class and call fail with a localized message naming the value and number type, defining the error message contract for numeric parameter types.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when modifying numeric parameter type conversion or error messages
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-209642404320e34120c1d166.md)

## Rule

- **Rule:**
  ```text
  ParamType.__call__ must skip conversion when the incoming value is None and return None unchanged; subclasses must not assume convert is invoked for None.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying ParamType.__call__ or a ParamType subclass's convert method to handle optional values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2dd35e53bd57c07a6227d593.md)

## Rule

- **Rule:** ParamType.fail must raise BadParameter with the provided message, ctx, and param so parameter types signal invalid values through the standard error channel.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When implementing or modifying a ParamType subclass that needs to reject an invalid value.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2e80d3fabf3c629c7cbe2001.md)

## Rule

- **Rule:**
  ```text
  When modifying _NumberRangeBase.__repr__, preserve the representation that includes the range description and appends ' clamped' when clamping is enabled.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing _NumberRangeBase.__repr__ or its clamped representation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3218c1ce2dc8f0557203c0a6.md)

## Rule

- **Rule:** UnprocessedParamType must keep name 'text' and pass values through without conversion, serving as the default unprocessed parameter type.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when modifying UnprocessedParamType's name or conversion behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-35c9830ea1362b906fa21434.md)

## Rule

- **Rule:**
  ```text
  When modifying FloatRange.__init__, preserve the validation that raises TypeError when clamp is True together with min_open or max_open, since clamping is not supported for open bounds.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing FloatRange.__init__ clamp or open-bound validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-52909e6e71029dcf3d5c3a21.md)

## Rule

- **Rule:**
  ```text
  When modifying DateTime._try_to_convert_date, preserve that it returns None on ValueError from datetime.strptime, treating unparseable date formats as non-matches rather than errors.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing DateTime._try_to_convert_date or date parsing error handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-58e4e9c95b1e7f794a1f222b.md)

## Rule

- **Rule:**
  ```text
  IntRange._clamp must return the bound unchanged when the range is closed, and bound + dir when open, so open bounds are adjusted by the direction to exclude the endpoint.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  when modifying IntRange._clamp or range bound handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6914271c151a7441e627d03f.md)

## Rule

- **Rule:**
  ```text
  When modifying Choice.shell_complete, preserve prefix matching of choices with case-insensitive comparison when case_sensitive is False, returning CompletionItem objects.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing Choice.shell_complete or its matching logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6f54c433bdf1628c7cdc1337.md)

## Rule

- **Rule:**
  ```text
  IntRange must document that min/max omitted means unbounded in that direction, min_open/max_open exclude the boundary, and clamp clamps out-of-range values instead of failing; min_open/max_open were added in 8.0.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when modifying IntRange bounds, clamping, or open-boundary behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-72000950870441600a6da470.md)

## Rule

- **Rule:**
  ```text
  FloatRange documents that clamp is not supported when either boundary is marked open, and that min_open/max_open were added in version 8.0; these constraints govern how range validation must behave.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying FloatRange validation or clamp behavior with open boundaries.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7557857b40e16bb7f38131c9.md)

## Rule

- **Rule:**
  ```text
  When modifying CompositeParamType in types.py, preserve that it subclasses ParamType and sets is_composite = True, marking it as a type that consumes multiple values.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Changing CompositeParamType inheritance or is_composite flag
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7aba3ca3eb26673ace67782b.md)

## Rule

- **Rule:**
  ```text
  When modifying DateTime.__repr__, preserve the stable literal representation "DateTime" used for type display.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing DateTime.__repr__ or its type display representation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7f1a498446bfa9bbaf9ae5e1.md)

## Rule

- **Rule:**
  ```text
  Choice.get_metavar must use type-name metavars deduplicated via dict.fromkeys when the parameter is an option and show_choices is false, otherwise stringify choices; required arguments get curly braces while options and optional arguments get square brackets.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying or extending Choice.get_metavar or related metavar formatting logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7fa2b7b11f921a7484970be6.md)

## Rule

- **Rule:**
  ```text
  Path type must derive its display name from file_okay/dir_okay: file-only yields 'file', dir-only yields 'directory', and both or neither yields 'path', which determines the name shown in error messages.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Path.__init__ or the display name used in Path error messages.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9a03bcc2eeaccc92dba491b1.md)

## Rule

- **Rule:**
  ```text
  When modifying ParamType.get_metavar in types.py, preserve the behavior that it returns the metavar default for a parameter if the type provides one, allowing custom types to control help metavar display.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Changing ParamType.get_metavar or custom type metavar handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9ee6cd070ad61a10213f013d.md)

## Rule

- **Rule:**
  ```text
  Custom ParamType subclasses must set the `name` class attribute, return None from convert when the value is None, accept both string and already-converted values in convert, and tolerate ctx and param being None (e.g. prompt input).
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when adding or modifying a ParamType subclass or its convert method
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b2f7b2e26c4e7880a0058895.md)

## Rule

- **Rule:**
  ```text
  When modifying Path type behavior, preserve that when exists is not True further checks are silently skipped, allow_dash permits a single dash indicating a standard stream without opening it, and envvar_list_splitter is os.path.pathsep.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When changing Path type validation, dash handling, or envvar splitting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bb7603765045af2bb93a651d.md)

## Rule

- **Rule:** OptionHelpExtra must be a TypedDict with total=False containing envvars, default, range, and required keys, defining the optional metadata fields used for option help rendering.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying option help metadata fields or the OptionHelpExtra TypedDict.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d014468428286930369c89c2.md)

## Rule

- **Rule:**
  ```text
  _NumberRangeBase must subclass _NumberParamTypeBase, establishing the inheritance relationship for numeric range parameter types.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying _NumberRangeBase or numeric range parameter type inheritance.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d43a3c072576181b13d7c5fc.md)

## Rule

- **Rule:**
  ```text
  When modifying _NumberParamTypeBase, preserve the extension protocol: _number_class is declared as a class variable so numeric ParamType subclasses supply their concrete number type.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Modifying _NumberParamTypeBase or adding numeric ParamType subclasses.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-edf9d403232bc6929259159f.md)

## Rule

- **Rule:** DateTime.convert must return datetime values unchanged and otherwise try each configured format, failing with a pluralized message listing all formats when none match.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When modifying or extending DateTime.convert or related datetime conversion logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f3b176b2d38dd8ceeb0b7f26.md)
