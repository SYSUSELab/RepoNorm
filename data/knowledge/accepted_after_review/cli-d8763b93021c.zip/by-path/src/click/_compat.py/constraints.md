# Constraints for `src/click/_compat.py`

## Rule

- **Rule:**
  ```text
  _FixupStream.readable must return True when _force_readable is set, otherwise delegate to the wrapped stream's readable() if present, and fall back to attempting a zero-byte read, returning False on any exception.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  when modifying _FixupStream.readable or stream compatibility behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-08bd3af902df845e64f4d01a.md)

## Rule

- **Rule:**
  ```text
  get_binary_stderr must raise RuntimeError when no binary writer can be determined for sys.stderr.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When modifying binary stderr access or its failure mode.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-213859635fc80b339a84da7e.md)

## Rule

- **Rule:** The seekable check must prefer the wrapped stream's own seekable attribute when present and only fall back to a seek/tell probe when that attribute is absent, treating probe exceptions as non-seekable.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  when modifying _FixupStream.seekable or its fallback probe behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-555df78c4ec415aafc3910e0.md)

## Rule

- **Rule:**
  ```text
  The wrapper's __repr__ must delegate to repr(self._f), preserving the wrapped file object's representation for debugging.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  when modifying wrapper __repr__ or debugging representation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-648e7a49ed995709bfc0113a.md)

## Rule

- **Rule:**
  ```text
  When modifying file opening compatibility, preserve that _wrap_io_open must not pass encoding/errors when the mode contains 'b'; binary mode opens are delegated to plain open(file, mode), while text mode forwards encoding and errors.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** when changing file opening logic or encoding handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6989db362b2a846a5ce4d2f1.md)

## Rule

- **Rule:**
  ```text
  _compat read1 must use the underlying stream's read1 when available and otherwise fall back to read(size), preserving read1 semantics across stream implementations that lack it.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** when modifying stream compatibility wrappers or read1 fallback logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7b83a916268c3d6cb9ccc735.md)

## Rule

- **Rule:**
  ```text
  _NonClosingTextIOWrapper must subclass io.TextIOWrapper to provide a text wrapper that does not close its underlying stream, used to avoid closing shared buffers.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** when modifying stream wrappers that must not close shared underlying streams
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8180cb1df9287ac93f532746.md)

## Rule

- **Rule:**
  ```text
  strip_ansi must remove ANSI escape sequences by substituting matches of the module-level _ansi_re pattern with the empty string.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying strip_ansi or the _ansi_re pattern.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-86d8ecb65b51a378dc944230.md)

## Rule

- **Rule:**
  ```text
  get_binary_stdout must raise RuntimeError when no binary writer can be determined for sys.stdout, making the failure mode explicit.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying get_binary_stdout or binary stdout detection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-896a75da2b3829cf9afe36a6.md)

## Rule

- **Rule:**
  ```text
  When modifying get_text_stdout, preserve the Windows-console special-casing: first attempt _get_windows_console_stream and otherwise fall back to _force_correct_text_writer with force_writable=True.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying get_text_stdout text stream resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8aef9983bd2b235615e4e66b.md)

## Rule

- **Rule:**
  ```text
  get_text_stdin must first try the Windows console stream and fall back to _force_correct_text_reader with force_readable=True, so stdin text handling is platform-conditional.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying get_text_stdin or adding platform-specific stdin handling in the compatibility layer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8fe386c419a21ef1ed2e4529.md)

## Rule

- **Rule:**
  ```text
  get_text_stderr first tries _get_windows_console_stream and falls back to _force_correct_text_writer with force_writable=True, ensuring stderr is a writable text stream.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying stderr text stream acquisition in _compat.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9ba7160f9ed8d0f9cd90b76c.md)

## Rule

- **Rule:**
  ```text
  When modifying _find_binary_reader, preserve the detection behavior: return the stream itself when _is_binary_reader(stream, False) is true, otherwise check stream.buffer with _is_binary_reader(buf, True) and return it, else None, explicitly handling detached and closed-buffer stream cases.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing _find_binary_reader or its binary stream detection logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a25c2dc9f2f428f674070d7c.md)

## Rule

- **Rule:** isatty must wrap stream.isatty() in a broad exception handler and return False on any exception, so non-standard streams that raise on isatty are treated as non-interactive.
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:** When modifying isatty or adding stream capability checks in the compatibility layer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a6a32af63e911833a51b906c.md)

## Rule

- **Rule:**
  ```text
  When modifying _is_compat_stream_attr, preserve the compatibility rule: a stream attribute is compatible when it equals the desired value, or when the desired value is None and the attribute has any non-None value.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying _is_compat_stream_attr compatibility checks.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aaf5bf08651a5024b87b79e5.md)

## Rule

- **Rule:**
  ```text
  When modifying _compat module import-time behavior, preserve the platform gating: CYGWIN and WIN are derived from sys.platform prefixes, and _winconsole import plus ANSI stream wrapper installation occur only when sys.platform starts with 'win' and WIN is true.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Modifying _compat platform detection or Windows-specific import-time wrapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b23bf23874b6e39271bca83c.md)

## Rule

- **Rule:**
  ```text
  When modifying auto_wrap_for_ansi._safe_write, preserve the invariant that all ANSI state is reset before re-raising any exception from the underlying write, ensuring terminal state is restored on failure.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When changing _safe_write or its exception handling around the underlying write.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f9a9da2f9e08c4814728baa8.md)

## Rule

- **Rule:**
  ```text
  When modifying _force_correct_text_stream in _compat.py, preserve that it returns a compatible text stream as-is unless encoding is None and the stream is misconfigured; otherwise it wraps the underlying binary reader, defaulting errors to 'replace' to avoid exceptions.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  Changing _force_correct_text_stream wrapping or error defaulting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ff9005e0654d31ca3665e931.md)
