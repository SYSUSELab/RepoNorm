# Constraints for `src/click/_winconsole.py`

## Rule

- **Rule:** The Windows console module must assert sys.platform == 'win32' at import time and map file descriptors 0/1/2 to text stream factories.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When modifying or extending the Windows console module or its platform guard and stream-factory mappings.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1ed76341a55c35f7f08fd032.md)

## Rule

- **Rule:**
  ```text
  When modifying Windows console stream wrappers, preserve that ConsoleStream delegates unknown attribute access to self._text_stream via __getattr__, maintaining the text stream interface.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** when changing ConsoleStream or its attribute delegation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-51fb651b7b8d5ff7699e27c2.md)

## Rule

- **Rule:**
  ```text
  The Py_buffer ctypes Structure must preserve its exact field layout used for Windows console buffer access.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:**
  ```text
  when modifying Windows console buffer handling or the Py_buffer structure
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-59dd1e444744020367dafff9.md)

## Rule

- **Rule:**
  ```text
  When modifying Windows console text streams, preserve that _get_text_stderr wraps the Windows STDERR_HANDLE in a _NonClosingTextIOWrapper using utf-16-le with strict errors and line_buffering=True, then casts the result to TextIO via ConsoleStream.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** when changing Windows console stream handling or encoding
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7260057aabc35754646c405b.md)

## Rule

- **Rule:** The Windows console isatty method delegates to self.buffer.isatty(), so TTY detection follows the underlying buffer.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When modifying ConsoleStream.isatty or TTY detection on Windows.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9289c11fb79460cf4b9859e2.md)

## Rule

- **Rule:** The Windows console isatty override must call super().isatty() and then unconditionally return True, so Windows console streams always report as TTY.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When modifying or extending the Windows console isatty override or related platform behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bb54223a42273d4d8af3ebd0.md)

## Rule

- **Rule:**
  ```text
  _get_text_stdin wraps a Windows console reader in a non-closing text wrapper using utf-16-le with strict errors and line buffering, then casts it to a ConsoleStream.
  ```
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When modifying Windows stdin text stream construction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c2407b5d5281ca02507bf755.md)
