# Constraints for `src/click/parser.py`

## Rule

- **Rule:**
  ```text
  When modifying _ParsingState.__init__, preserve the initialization of opts, largs, rargs, and order parsing state so contributors extending the parser account for this mutable state.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing _ParsingState.__init__ or extending the option parser's mutable state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6b3a3ccfd761237ced0516c8.md)

## Rule

- **Rule:**
  ```text
  _split_opt must treat a leading alphanumeric character as a long option (empty prefix), a doubled leading character as a two-character short prefix, and otherwise a single-character prefix.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** When modifying option string splitting into prefix and name.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7b99623d25772d44cea5443c.md)

## Rule

- **Rule:**
  ```text
  When modifying option parsing, preserve that Option.takes_value is True only when action is 'store' or 'append', defining which parser actions consume a following value.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** when changing how options consume values or adding new actions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cb23a0ee73489dd9af13eea6.md)

## Rule

- **Rule:**
  ```text
  When modifying _normalize_opt, preserve that it returns the option unchanged when ctx or its token_normalize_func is None, otherwise splits the prefix and applies the normalization function to the option name.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:**
  ```text
  When changing _normalize_opt or token normalization logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e2fb7023f61009c26b99b18f.md)

## Rule

- **Rule:** Option parsing rejects an option whose split prefix is empty with ValueError, and classifies an option as short only when both prefix and value are single characters; otherwise it is treated as long and the full prefix is registered.
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** When modifying option prefix parsing or short/long option classification.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e67a553c31745d53c4a28fb1.md)
