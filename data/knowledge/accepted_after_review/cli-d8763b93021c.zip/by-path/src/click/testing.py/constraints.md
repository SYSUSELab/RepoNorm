# Constraints for `src/click/testing.py`

## Rule

- **Rule:**
  ```text
  The testing helper's visible_input must write the prompt to stdout, read a line from text_input, strip CR/LF, echo the value, and flush, defining how simulated interactive input is surfaced in test output.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying simulated interactive input in the testing helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0005dcbefc3342d9b4abeae4.md)

## Rule

- **Rule:**
  ```text
  BytesIOCopy.flush must delegate to super().flush() and then copy_to.flush() to keep the mirrored buffer synchronized.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying BytesIOCopy.flush or testing stream mirroring behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c8973f8c185ca1bbf3c3669.md)

## Rule

- **Rule:**
  ```text
  CliRunner.invoke must preserve the documented versioned result attributes: output_bytes mixes stdout_bytes and stderr_bytes as seen in a terminal since 8.2, stderr_bytes is always returned, return_value holds the invoked command's return value since 8.0, and exc_info holds the traceback when available since 3.0.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying CliRunner.invoke or its result attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-23ee5919777fae0dfbb931db.md)

## Rule

- **Rule:**
  ```text
  EchoingStdin.read1 must delegate to self._echo(self._input.read1(n)) so bytes read through read1 are echoed to the captured output stream.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying EchoingStdin.read1 or testing stream echo behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-52553c5aed48c83d957a0051.md)

## Rule

- **Rule:**
  ```text
  CliRunner's hidden_input helper must write the prompt to stdout, flush, then read a line from text_input and strip trailing CR/LF.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When modifying simulated prompt input capture in CliRunner.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a56cde7c172584bf49c82e0b.md)

## Rule

- **Rule:** When modifying EchoingStdin.readline, preserve that it echoes the bytes read from the wrapped input stream so test input supplied to CliRunner is reflected in captured output.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When changing EchoingStdin.readline or CliRunner input echoing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d2392a542ee24b2e1af1d01d.md)

## Rule

- **Rule:**
  ```text
  When modifying EchoingStdin.__getattr__, preserve the delegation behavior that forwards attribute access to self._input, the underlying input stream.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:**
  ```text
  When changing EchoingStdin.__getattr__ or its attribute delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f1095d78bff71c81bbb61f00.md)
