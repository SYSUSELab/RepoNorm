# Constraints for `src/click/exceptions.py`

## Rule

- **Rule:**
  ```text
  When modifying ClickException, preserve the invariant that it is the base exception Click handles and shows to the user, with a class-level exit_code default of 1.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When changing ClickException or its exit_code default.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a46542ca6bbacc97f6aaf7a.md)

## Rule

- **Rule:** Abort is a RuntimeError subclass documented as an internal signalling exception that tells Click to abort, so callers should treat it as control flow rather than a user-facing error.
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When modifying Abort or code that catches or raises it.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1e7bef10393b9bb9c04878a7.md)

## Rule

- **Rule:** When modifying exception hierarchy, preserve that BadArgumentUsage is a UsageError subclass raised when an argument is supplied but used incorrectly, such as an incorrect number of values.
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when changing exception classes or argument usage error handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3a2387bd0e484246251e7b1b.md)

## Rule

- **Rule:** When modifying exception hierarchy, preserve that NoArgsIsHelpError subclasses UsageError, establishing that invoking a command with no arguments is treated as a usage error that can surface help.
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when changing exception classes or usage error handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-42268fa5925e8c36c94af5c5.md)

## Rule

- **Rule:**
  ```text
  When modifying error output, preserve the convention that ClickException.show writes 'Error: <message>' to stderr by default via get_text_stderr when no file is provided.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when changing how ClickException errors are displayed
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa33118e2edbe3ccfb46d3e4.md)

## Rule

- **Rule:**
  ```text
  BadParameter must format a standardized error message for a bad parameter, accept param and param_hint, and support param_hint as a string or a list whose items are quoted and separated, attaching contextual parameter info when possible.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when modifying BadParameter formatting or parameter error messages
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b59339f7602aad6c574d55e2.md)

## Rule

- **Rule:**
  ```text
  ClickException.format_message must return self.message unchanged, so subclasses or callers expecting transformation get the raw message.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When modifying ClickException.format_message or subclass message formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bb1be47edbaf4e1c5571c94f.md)

## Rule

- **Rule:** BadOptionUsage must be a UsageError subclass raised when an option is supplied but used incorrectly, such as an incorrect number of arguments.
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When modifying or adding option misuse exception handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-df05363ddd52981f37cba5b8.md)

## Rule

- **Rule:**
  ```text
  ClickException.__init__ must initialize the base Exception with the message and also store the message on self.message so it remains available as an attribute.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when modifying ClickException initialization or message storage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eff81114648d6ff513cf1127.md)
