# Constraints for `src/click/formatting.py`

## Rule

- **Rule:**
  ```text
  When modifying HelpFormatter.write_dl in formatting.py, preserve that it raises TypeError if rows do not have exactly two columns and wraps the second column text with a minimum width of 10.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  Changing HelpFormatter.write_dl row validation or column wrapping
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-49b2655b7fec122d313448f6.md)

## Rule

- **Rule:**
  ```text
  When modifying help formatting defaults, preserve that HelpFormatter width defaults to terminal width minus 2, clamped between 50 and max_width (default 80), with FORCED_WIDTH overriding terminal detection.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** when changing HelpFormatter width calculation or terminal detection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4f21eee4b00ba5c6892d48ca.md)

## Rule

- **Rule:**
  ```text
  wrap_text with preserve_paragraphs=True treats a paragraph prefixed by a line containing the \b (\x08) character as raw: it is emitted via wrapper.indent_only without rewrapping, while normal paragraphs are filled.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When modifying wrap_text paragraph handling or the \b raw-paragraph extension.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5a3b73b5170e0f265d60433b.md)

## Rule

- **Rule:**
  ```text
  measure_table must compute the maximum width of each column across rows using term_len, returning a tuple of widths sorted by column index.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** When modifying table width measurement or column width computation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-787798dea1155c7cf7dcb10a.md)

## Rule

- **Rule:**
  ```text
  When modifying help formatting indentation, preserve that HelpFormatter.indent increases current_indent by indent_increment, defining the indentation step used in help formatting.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** when changing HelpFormatter indentation logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8ece5ed01d4ef7ed0cf56b63.md)

## Rule

- **Rule:** When modifying help formatting, preserve that HelpFormatter.write appends to an internal buffer rather than emitting immediately, so output is only produced when the buffer is flushed.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** when changing how HelpFormatter produces output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9781a7c7f7c05af8fc77ced0.md)

## Rule

- **Rule:**
  ```text
  write_paragraph must only write a newline when the buffer is non-empty, avoiding a leading blank line in formatted output.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:**
  ```text
  When modifying or extending HelpFormatter.write_paragraph or related paragraph writing logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b74a23076d4c8538718a7e1b.md)

## Rule

- **Rule:** When modifying HelpFormatter in formatting.py, preserve the documented contract that it always writes into memory and that width defaults to terminal width clamped to a maximum of 78.
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** Changing HelpFormatter width defaulting or output buffering behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d22826a5dc3954b487c62134.md)

## Rule

- **Rule:**
  ```text
  _flush_par must treat a buffer whose first stripped element is '\b' as a preformatted paragraph (joined with newlines, marked True) and otherwise join the buffer with spaces, using indent or 0.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** when modifying help text paragraph flushing or preformatted block handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-db1ad68d5381444128740228.md)
