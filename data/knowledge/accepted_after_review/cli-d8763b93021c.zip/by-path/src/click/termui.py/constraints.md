# Constraints for `src/click/termui.py`

## Rule

- **Rule:** confirm builds its prompt with default 'y/n' when default is None, 'Y/n' when default is truthy, and 'y/N' otherwise; it loops on invalid input, treats y/yes as True and n/no as False, and raises Abort on KeyboardInterrupt/EOFError or when abort is set and the answer is negative.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** When modifying the confirm prompt function or its input handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-09be6adaef1cb545fe0d9721.md)

## Rule

- **Rule:** termui.pause returns immediately without output when stdin or stdout is not a tty, and otherwise prints the info message, waits for a key, and clears the message in a finally block; KeyboardInterrupt and EOFError during getchar are swallowed.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** When modifying termui.pause or its tty gating and cleanup behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1e36f86df2d991dad57ec265.md)

## Rule

- **Rule:** secho must style the message only when it is not bytes/bytearray, passing bytes through to echo unstyled, and must convert non-string messages to str.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** when modifying secho's message handling or styling path
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-24724711f08edd488417e7e1.md)

## Rule

- **Rule:**
  ```text
  When modifying terminal UI wrappers, preserve that raw_terminal is a thin wrapper that imports and delegates to _termui_impl.raw_terminal, returning an AbstractContextManager[int].
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  when changing raw_terminal or its delegation to _termui_impl
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-249ad6de889e4a8be77e3ff5.md)

## Rule

- **Rule:**
  ```text
  _build_prompt must append choice values in parentheses only when a Choice type is supplied with show_choices, and append the formatted default in brackets only when default is not None and show_default is set, preserving the exact prompt composition order.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  When modifying _build_prompt or adding prompt formatting options in the termui module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-727f6e4d60ea824fc679a13c.md)

## Rule

- **Rule:**
  ```text
  When modifying prompt() in termui.py, preserve the re-prompt loop: value_proc rejections (UsageError) must re-prompt with the error message, and when confirmation_prompt is set the second entry must match the first or the prompt repeats; confirmation_prompt=True must be replaced by the translated 'Repeat for confirmation' string.
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** Changing prompt() input validation, confirmation, or error re-prompt behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eaca096f29ba139f0b5ee4fc.md)
