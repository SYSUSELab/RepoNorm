# Constraints for `src/click/core.py`

## Rule

- **Rule:** Context.close() must close the exit stack and then replace it with a fresh ExitStack so the context can be reused after closing.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying or extending Context.close or related context lifecycle logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-03499051f5c92ecc507e5298.md)

## Rule

- **Rule:**
  ```text
  Command.main must be overloaded with standalone_mode: Literal[True] returning NoReturn, encoding the invariant that standalone mode exits the process rather than returning.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Command.main signature or standalone_mode typing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0b4eef58a98419b9bb4130ab.md)

## Rule

- **Rule:**
  ```text
  value_from_envvar must split the resolved envvar value via the parameter type's split_envvar_value only when the value is not None and nargs is not 1, so single-value parameters receive the raw string.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying value_from_envvar's envvar resolution or splitting behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-103da921e689ab75d789f49a.md)

## Rule

- **Rule:**
  ```text
  When modifying Context.show_default in core.py, preserve the default inheritance behavior: show_default defaults to the value from the parent context as of Click 8.0.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Context.show_default defaulting or parent-context inheritance
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-10ac47d53db9445256a64639.md)

## Rule

- **Rule:**
  ```text
  When modifying Group.resolve_command, preserve the resolution protocol: apply ctx.token_normalize_func when the initial lookup fails, and when still unresolved and not resilient_parsing, re-parse args if the first token looks like an option before failing with 'No such command', preserving --help routing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Group.resolve_command lookup, token normalization, or option-like fallback handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-126659bab1003f893a580746.md)

## Rule

- **Rule:**
  ```text
  When modifying Context.find_root, preserve the traversal behavior that walks parent links to the outermost context so nested contexts can locate the root for shared state.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Context.find_root or its parent-link traversal.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-136a95690b8438f70967b0a1.md)

## Rule

- **Rule:**
  ```text
  make_metavar must return the explicit metavar if set, otherwise the type's get_metavar, falling back to the uppercased type name, and append '...' when nargs != 1, defining metavar derivation and multi-value notation.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** when modifying parameter metavar derivation or multi-value notation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-13ffd8b7690be200e236da42.md)

## Rule

- **Rule:**
  ```text
  get_error_hint must append the environment variable name to the hint only when show_envvar is true, making envvar hints opt-in per parameter.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying error hint generation or envvar display behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-16b09fb74c37e845fb38cfc6.md)

## Rule

- **Rule:**
  ```text
  get_default must support a callable default protocol, accepting ctx and call and returning Any, a callable, or None.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying the get_default method or its typing overloads.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-17b5b0e941bd2df3829dafca.md)

## Rule

- **Rule:**
  ```text
  When modifying parameter processing order, preserve the sort key that orders eager parameters first and then by invocation_order index, assigning float('inf') to parameters absent from invocation_order so they sort last.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing iter_params_for_processing or its sort_key, or altering how invocation_order is populated.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1802292a40bacee792c06eca.md)

## Rule

- **Rule:**
  ```text
  When modifying Command.format_help in core.py, preserve the documented low-level help composition order: format_usage, then format_help_text, then format_options, then format_epilog.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Command.format_help composition or ordering of help sections
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-23a0e64cf20e22202f22d294.md)

## Rule

- **Rule:** When modifying Group.group or Command.group, preserve the overloaded decorator behavior: a bare callable is accepted and returns a Group, and the decorator form produces a Group, so both direct and parenthesized decorator usage remain supported.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Group.group or Command.group overloads or decorator-based group creation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2bc00fdf0eb2120764dcc8ce.md)

## Rule

- **Rule:**
  ```text
  collect_usage_pieces starts with options_metavar when set, then extends with each parameter's get_usage_pieces, defining the composition of the usage line.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying usage line composition or Command.collect_usage_pieces.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-31fc79153db7fe12c6cae9c5.md)

## Rule

- **Rule:**
  ```text
  When modifying Group.__init__, preserve the invariant that chain mode cannot be combined with optional arguments; the constructor must raise RuntimeError for that combination, and no_args_is_help must default to the negation of invoke_without_command.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Group.__init__ command normalization, no_args_is_help defaulting, or chain-mode validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3355a6d227398129e47c546f.md)

## Rule

- **Rule:**
  ```text
  When modifying Context.find_object in core.py, preserve the behavior that it walks up the parent chain and returns the first node whose obj is an instance of the requested type, returning None if no ancestor matches.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Context.find_object parent-chain traversal or type matching
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3baf6d37641226d2eaf2b057.md)

## Rule

- **Rule:**
  ```text
  As of Click 8.2, envvar used with flag_value must always use the flag_value rather than the environment variable's value.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Option envvar handling or flag_value resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-40cade592fe96fab5dcefd00.md)

## Rule

- **Rule:**
  ```text
  When modifying Command.format_options, preserve that it collects non-None get_help_record results from get_params and writes them under a translated 'Options' section only when at least one option exists.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Command.format_options or help option formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-42755375f6dfdb64bc8c4e99.md)

## Rule

- **Rule:**
  ```text
  When modifying Command.format_epilog, preserve the behavior that the epilog is written only when self.epilog is set, applying inspect.cleandoc and writing it as an indented paragraph in the help formatter.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Command.format_epilog epilog rendering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-44fb2aa39bc65a52e9a260b5.md)

## Rule

- **Rule:** When modifying Context.abort, preserve that it raises Abort and is annotated as NoReturn, terminating control flow via an exception.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Context.abort or its exception behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-510bb8ed8ed84e6b8eb41e41.md)

## Rule

- **Rule:**
  ```text
  When modifying _MultiCommand, preserve the deprecation boundary: _MultiCommand is deprecated as of 8.2 and scheduled for removal in Click 9.0, with Group as the replacement; do not remove or change this compatibility boundary without updating the deprecation schedule.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing _MultiCommand or its deprecation metadata.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-55cc8ccfe8e75967bf6ae086.md)

## Rule

- **Rule:**
  ```text
  Command.get_help must build a formatter via ctx.make_formatter, call format_help, and return the value with trailing newlines stripped.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Command.get_help or help formatting logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-55e2cdca8e4bef3ae1c627ee.md)

## Rule

- **Rule:** When modifying Context.invoke, preserve both invocation modes: passing a callback directly, or passing a Command whose callback is invoked with a new sub-context; in command mode, missing exposed params are filled from defaults and all kwargs are tracked in ctx.params so forward() can pass them at multiple levels.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Context.invoke or its callback/command invocation modes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-58dc6193a72b68b559c019c3.md)

## Rule

- **Rule:**
  ```text
  When modifying Context.protected_args, preserve the deprecation boundary: protected_args is deprecated and will be removed in Click 9.0, with args containing remaining unparsed tokens; do not remove or change this compatibility boundary without updating the deprecation schedule.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Context.protected_args or its deprecation metadata.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-590e4a8a65b694e2cd5c583a.md)

## Rule

- **Rule:**
  ```text
  Command.get_short_help_str must prefer explicit short_help (cleandoc-normalized), otherwise derive from help via make_default_short_help with a default limit of 45, and prefix deprecated commands with a translated '(Deprecated)' marker.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Command.get_short_help_str or adding help text derivation logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5b59125d633c1f590e1ba5f4.md)

## Rule

- **Rule:**
  ```text
  Group.list_commands must return sorted(self.commands), establishing alphabetical ordering as the default subcommand listing order.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Group.list_commands or adding subcommand listing behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5cc0f070e468106936fa3d95.md)

## Rule

- **Rule:**
  ```text
  The group decorator must create a Group command from the decorated function, add it to the parent group via add_command, and return the created command.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying or extending the Group.group decorator or adding new group decorators.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5d5b4e482feec124b1967860.md)

## Rule

- **Rule:**
  ```text
  Parameter.get_help_record must return None by default, defining the no-help-record contract that subclasses override.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Parameter.get_help_record or help-record generation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5d92f7da89f106cff5a97394.md)

## Rule

- **Rule:**
  ```text
  Group.shell_complete must return CompletionItems for visible subcommands with their short help, then extend with super().shell_complete results so subcommand completion includes help text and inherited completions.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying shell completion for Group or adding subcommand completion behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6ee8739a7e014fe5c4eda8f7.md)

## Rule

- **Rule:**
  ```text
  Group.get_command must return the Command from self.commands by name or None if absent, defining the base command lookup contract.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Group.get_command or its lookup behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-719cdf89f61dc315219f7dd1.md)

## Rule

- **Rule:**
  ```text
  get_usage_pieces must return an empty list by default, so base parameters contribute no usage pieces unless overridden.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying the base Parameter.get_usage_pieces method or its default behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8e16f7d32b5ba3a23cd47709.md)

## Rule

- **Rule:**
  ```text
  Group merged with and replaced the MultiCommand base class in 8.2, and since 8.0 the commands argument may be a list of command objects; group_class set to the literal type makes subgroups inherit the current group's class.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Group class hierarchy, commands argument handling, or group_class behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-91fec0361ce6e009b01ddfe1.md)

## Rule

- **Rule:**
  ```text
  When modifying context resource management, preserve that Context.with_resource registers a context manager on the context's ExitStack via enter_context, returning __enter__'s result and cleaning up when the context is popped.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** when changing how Context manages resources or cleanup
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-93a9b3943764fdf96d2335ea.md)

## Rule

- **Rule:**
  ```text
  CommandCollection.list_commands must merge super().list_commands with each source's list_commands into a set and return sorted results, deduplicating duplicate command names and producing deterministic order.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying CommandCollection.list_commands or its merge behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-963c98112a1082dfa845f0f6.md)

## Rule

- **Rule:** When modifying Option in core.py, preserve the Click 8.1 behavior that a single option boolean flag's default is not shown if its value is False.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** Changing Option boolean flag default display behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9e536641c9cd93927dfbedfb.md)

## Rule

- **Rule:**
  ```text
  When modifying Command.__init__, preserve the public constructor defaults: options_metavar='[OPTIONS]', add_help_option=True, no_args_is_help=False, hidden=False, deprecated=False, and params stored as params or [].
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Command.__init__ signature or default values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-abea0e2bb60f850fcfc23793.md)

## Rule

- **Rule:** Context.forward only accepts Command instances (raises TypeError for callbacks) and fills missing kwargs from self.params so forwarded params persist across multiple forward levels.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying Context.forward or its parameter forwarding behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ac595a5068cbaf2f7a612700.md)

## Rule

- **Rule:**
  ```text
  When modifying Context.command_path, preserve the usage-path computation: join the parent's command_path with each parent parameter's get_usage_pieces, then append the current info_name and strip leading whitespace, so usage strings include parent parameter placeholders.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Context.command_path usage-path construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ac7d4998ab75fa0c05ca6741.md)

## Rule

- **Rule:**
  ```text
  When modifying Context.call_on_close, preserve the teardown contract: callbacks are registered on the context's exit stack and run when the context tears down; resources supporting the context manager protocol should instead be registered via with_resource.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Context.call_on_close teardown registration or resource lifecycle handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ad241b0f11637121f8fe6276.md)

## Rule

- **Rule:**
  ```text
  Group.add_command must raise TypeError when neither an explicit name nor cmd.name is available, and must call _check_nested_chain before storing the command in self.commands.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Group.add_command or command registration logic
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aedbc6836f2ac3ecf8ca5999.md)

## Rule

- **Rule:**
  ```text
  The help option callback must echo the context help and exit only when a value is present and resilient_parsing is false, so help output is suppressed during resilient parsing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** when modifying help option callback or resilient parsing behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-afd8533bf6590b06cd8ea34a.md)

## Rule

- **Rule:**
  ```text
  When modifying Option.prompt_for_value in core.py, preserve the flow: compute the default before prompting, route boolean flags through confirm, and forward show_default to prompt only when it is a bool.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Option.prompt_for_value default computation, boolean routing, or show_default forwarding
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b8143993c6e6c7408b357adc.md)

## Rule

- **Rule:**
  ```text
  Parameter must preserve the documented deprecation of the autocompletion parameter renamed to shell_complete in 8.0, with the old name wrapped until 8.1.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Parameter's autocompletion or shell_complete parameter handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bcfe42e07769e7fc5fc4318a.md)

## Rule

- **Rule:**
  ```text
  When the completion environment variable is set, _main_shell_completion must delegate to shell_complete and call sys.exit with its return value, exiting before the program is invoked.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying the main shell completion entry point or its delegation to shell_complete.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bde96a768f3271c7d3ac30c6.md)

## Rule

- **Rule:**
  ```text
  Group.to_info_dict must recursively build a commands mapping by calling list_commands/get_command and entering each subcommand's context with scope(cleanup=False), and include the group's chain flag in the result.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Group.to_info_dict or command introspection output
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c725587672f06ee0eb1da564.md)

## Rule

- **Rule:**
  ```text
  _parse_decls is an abstract method raising NotImplementedError, defining the extension contract for parameter subclasses to parse declarations.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying or extending Parameter._parse_decls or adding new parameter subclasses.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ca7094f4a2c13b152b4abd14.md)

## Rule

- **Rule:**
  ```text
  When modifying Option.get_help_extra, preserve the behavior that ctx.resilient_parsing is temporarily set to True while computing the default value so type-casting failures for defaults do not break help generation, and envvar names are derived from auto_envvar_prefix.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Option.get_help_extra default-value computation or envvar-name derivation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dda77c33eadb00e0d0f63175.md)

## Rule

- **Rule:**
  ```text
  When modifying Option.get_default, preserve the multi-flag default-selection protocol: for non-boolean flags, scan all params in the same command group and return the flag_value of the matching param whose default is truthy, otherwise None.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Option.get_default default-selection logic for non-boolean flags.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e239e10446bc6c5e38f1f263.md)

## Rule

- **Rule:**
  ```text
  Context.protected_args is a deprecated property that must emit a DeprecationWarning stating removal in Click 9.0 and that 'args' will contain remaining unparsed tokens.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Context.protected_args or adding deprecated compatibility properties to Context.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e4373edfc42694eaab20c32a.md)

## Rule

- **Rule:** The callback wrapper must call the old callback with the value and args, then pass the result through f, preserving the callback transformation pattern.
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying the result_callback decorator wrapper or its callback transformation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e480d74f5de3150f8cce273e.md)

## Rule

- **Rule:**
  ```text
  Option.add_to_parser must map multiple to append, count to count, and otherwise store; flags use a _const action, and bool flags with secondary options register both primary and secondary options with const True/False.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying or extending Option.add_to_parser or adding new option action mappings.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eb4a1c7cec25fe6d8ba84ec2.md)

## Rule

- **Rule:**
  ```text
  When modifying Option.__init__ flag/prompt derivation, preserve that prompt=True requires a name and derives prompt text from it, _flag_needs_value is set when prompt is enabled but not required, is_flag is inferred from flag_value, _flag_needs_value, or secondary_opts, count options default to IntRange(min=0) with default 0, and the __debug__-guarded TypeErrors remain enforced.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Option.__init__ flag, prompt, count, or secondary-option derivation logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f032f04fa6dffe0aeb3caf1a.md)

## Rule

- **Rule:**
  ```text
  Parameter.get_default must consult ctx.lookup_default first (with call=False), fall back to self.default, and only invoke the value if call is True and it is callable; type casting is not performed when getting a default, and default_map is consulted first.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying or extending Parameter.get_default or related default resolution logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f039fecb647b7694a3dd532d.md)

## Rule

- **Rule:**
  ```text
  The batch helper must group an iterable into tuples of batch_size using zip over repeated iterators, returning a list of tuples.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying the batch helper or its grouping behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f0b2fd898f3396631cb1a469.md)

## Rule

- **Rule:**
  ```text
  When modifying Context.to_info_dict in core.py, preserve the returned dict keys (command info, info_name, allow_extra_args, allow_interspersed_args, ignore_unknown_options, auto_envvar_prefix) and the traversal of the CLI structure for documentation tools.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Changing Context.to_info_dict output keys or CLI structure traversal
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f0efefeb66946b2ebbe57fbe.md)

## Rule

- **Rule:**
  ```text
  Help, epilog, and short_help text must be stored unprocessed on Command and formatted only at help-output time, so contributors must not pre-format or eagerly process these strings when constructing commands.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying how Command stores or renders help, epilog, or short_help text.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f22ac9e758041ecd5fd66c81.md)

## Rule

- **Rule:**
  ```text
  get_default has an overload taking ctx and a call literal True and returning Any | None, indicating a callable default path.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Parameter.get_default or its overloads.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f2f265c9276c10aebf5751ea.md)
