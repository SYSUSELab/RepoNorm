# Constraints for `src/click/utils.py`

## Rule

- **Rule:**
  ```text
  LazyFile.open must translate OSError from open_stream into FileError carrying the filename and strerror hint, and cache the opened stream in self._f so subsequent calls return the same handle.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying LazyFile.open or the error handling around lazy file opening.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-028fc47a736c259d6db01b97.md)

## Rule

- **Rule:**
  ```text
  When modifying file wrapper context management, preserve that KeepOpenFile.__enter__ returns self, so the file wrapper is usable directly as a context manager.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when changing KeepOpenFile or its context manager behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0e30875cb7d66d26665061fd.md)

## Rule

- **Rule:** The wrapper constructor must store the wrapped IO object as self.wrapped, which is the delegation target for attribute access.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying the wrapper constructor or its delegation target
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-12880dc83cffda715b83102f.md)

## Rule

- **Rule:**
  ```text
  _detect_program_name must return the basename for file execution and 'python -m <module>' for module execution, handling __package__ being None, empty, or a zipapp value.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  when modifying _detect_program_name's handling of __package__ or execution mode detection
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-492d72b190f6c89b3f529f4c.md)

## Rule

- **Rule:**
  ```text
  get_text_stream must look up the named stream in text_streams and raise TypeError for unknown names, with encoding and errors overrides passed to the opener.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying text stream lookup or its error handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-62f12de093fcd3cbc48697eb.md)

## Rule

- **Rule:**
  ```text
  open_file must treat '-' as stdin/stdout, wrap non-closable streams in KeepOpenFile so context-manager use does not close standard streams, return LazyFile when lazy=True, and use a temp-file replace strategy when atomic=True.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying open_file or adding new file-opening modes that interact with standard streams, lazy loading, or atomic writes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-63a4ab90243a5237c6bd3098.md)

## Rule

- **Rule:**
  ```text
  LazyFile.__repr__ must return repr of the underlying file when opened, otherwise a descriptive '<unopened file ...>' string including the formatted filename and mode.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying LazyFile.__repr__ or adding lazy file wrappers that need a repr.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-73f654a6cf5eae530f2370ea.md)

## Rule

- **Rule:**
  ```text
  make_default_short_help considers only the first paragraph, strips a leading \b no-rewrap marker, truncates at a sentence-ending period without ellipsis, and otherwise truncates with "..." while removing words until the length fits max_length.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying short help text generation or its truncation behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c3c382a89e23eadfa8630143.md)

## Rule

- **Rule:** echo must preserve its output compatibility guarantees: flush output, strip ANSI codes when the output stream is not an interactive terminal, write bytes to a discovered binary writer, and return early when no standard streams are attached.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying echo's stream selection, ANSI stripping, byte writing, or flush behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-db6f72e4bb5b822f797a8be6.md)

## Rule

- **Rule:** The stream flush wrapper must suppress only OSError with errno EPIPE and re-raise all other OSErrors, preserving the broken-pipe compatibility boundary.
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** when modifying the flush wrapper's exception handling for output streams
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e1cfc6baaf689469d5dcfa55.md)

## Rule

- **Rule:**
  ```text
  When modifying KeepOpenFile.__exit__ in utils.py, preserve that it is a no-op accepting exception type, value, and traceback and returning None, so exceptions are not suppressed.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  Changing KeepOpenFile.__exit__ exception handling or return value
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e818e5c80cadd76dd471cafb.md)

## Rule

- **Rule:**
  ```text
  LazyFile.close_intelligently must only close the underlying file when should_close is True, so files not opened by the lazy wrapper (such as stdin) are never closed.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying LazyFile.close_intelligently or adding lazy file wrappers that may wrap caller-owned streams.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ec7657ab605685dac25375b0.md)
