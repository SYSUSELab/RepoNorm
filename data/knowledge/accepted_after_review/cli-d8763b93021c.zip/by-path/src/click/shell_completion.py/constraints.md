# Constraints for `src/click/shell_completion.py`

## Rule

- **Rule:**
  ```text
  ShellComplete.get_completions must resolve the context and incomplete value from the args, then delegate to the resolved object's shell_complete(ctx, incomplete) method, defining the extension protocol for completion targets.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying or extending ShellComplete.get_completions or adding new completion targets.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-02df71f546fbbaea992f1b97.md)

## Rule

- **Rule:**
  ```text
  get_completion_args must read COMP_WORDS and COMP_CWORD from the environment, slice args as cwords[1:cword], and treat a missing cwords[cword] as an empty incomplete string.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** When modifying Bash completion argument parsing from environment variables.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-05aad449b7e287fb2c131be5.md)

## Rule

- **Rule:**
  ```text
  When modifying CompletionItem.__init__, preserve the shell completion item data contract: store value, type (default 'plain'), help, and capture remaining kwargs in _info.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying CompletionItem.__init__ field storage or default type handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1a51b9ed536418268107fee4.md)

## Rule

- **Rule:**
  ```text
  _resolve_context must set resilient_parsing=True on the context and walk the command hierarchy without triggering prompts or callbacks; for chained groups it must build nested sub-contexts with allow_extra_args=True and allow_interspersed_args=False, returning the deepest resolvable context.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying _resolve_context or adding context resolution logic for shell completion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-282a20e27f80deb22a7c890e.md)

## Rule

- **Rule:** When adding a new shell to shell completion, implement it as a ShellComplete subclass that binds the shell name and a dedicated source template rather than branching inside a single formatter.
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** when adding support for a new shell to shell completion
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-382a5ad31ba918a9f4ea3949.md)

## Rule

- **Rule:**
  ```text
  ShellComplete.source_vars must return a dict containing complete_func, complete_var, and prog_name for formatting source_template, defining the variables available to completion script templates.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying ShellComplete.source_vars or adding new variables to completion script templates.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-48b3130199eb89f74f52a34f.md)

## Rule

- **Rule:**
  ```text
  When modifying ShellComplete.func_name, preserve the shell function name contract: sanitize prog_name by replacing '-' with '_' and stripping non-word characters with re.sub(r"\W*", "", ..., flags=re.ASCII), then wrap it as _{safe_name}_completion.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying ShellComplete.func_name sanitization or completion function naming.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-4da1587fc03f64a10ac7cf1e.md)

## Rule

- **Rule:**
  ```text
  When modifying ShellComplete.format_completion in shell_completion.py, preserve its abstract-style contract: it must raise NotImplementedError so each shell-specific subclass implements completion item formatting.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Changing ShellComplete.format_completion or adding shell-specific completion subclasses
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7425cc3f2a20e0986454c0fa.md)

## Rule

- **Rule:**
  ```text
  Bash shell completion must verify Bash version >= 4.4 and emit an error when the version is older or cannot be detected.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** When modifying or adding Bash shell completion version checking logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-7f198152d3f427557dc13168.md)

## Rule

- **Rule:**
  ```text
  Each shell completion class must declare a name and a source_template, as ZshComplete does with name = "zsh" and source_template = _SOURCE_ZSH.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** when adding or modifying a shell completion class
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c21067487fff103e2a33e215.md)

## Rule

- **Rule:**
  ```text
  ShellComplete.complete must orchestrate get_completion_args, get_completions, and format_completion per item, joining results with newlines, defining the completion output protocol.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** when modifying shell completion output or the complete method
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c56f4055f0b78750c02e3c0b.md)

## Rule

- **Rule:**
  ```text
  When modifying CompletionItem, preserve __slots__ for value, type, help, and _info, and support arbitrary metadata via item.attr returning None for attributes not passed.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** When changing CompletionItem structure or attribute access.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fb6b72623b62996b080c11ef.md)
