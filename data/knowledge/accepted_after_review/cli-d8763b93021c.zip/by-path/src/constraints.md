# Constraints for `src`

## Rule

- **Rule:** Ruff treats src as the source root directory.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d737fef1764aa6ca4bca412b.md)
