# Constraints for `pyproject.toml`

## Rule

- **Rule:**
  ```text
  For the mypy override applying to the "colorama.*" module, missing imports are ignored.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ce70af76e235232ff49cd73a.md)
