# Constraints for `.`

## Rule

- **Rule:** Ruff linting is configured with the rule set B, E, F, I, UP, and W selected.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-04e007ad3a4be09c578ef325.md)

## Rule

- **Rule:** The pre-commit workflow runs on ubuntu-latest.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0883e170360007ab3c29d3fa.md)

## Rule

- **Rule:** Ruff shows fixes in its output (show-fixes = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1a43900dfe021bd5aa30f560.md)

## Rule

- **Rule:** Files with the extensions css, html, js, json, jsx, scss, ts, tsx, yaml, or yml use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.jsx`
  - `**/*.scss`
  - `**/*.ts`
  - `**/*.tsx`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1b7248c8e04eeab906db3ab2.md)

## Rule

- **Rule:**
  ```text
  mypy is configured to type-check with python_version set to "3.8".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-21376d453d4c948db2ad9e67.md)

## Rule

- **Rule:**
  ```text
  Open ``htmlcov/index.html`` in a browser to explore the coverage report.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-21e7ecfd78ce2db7aff32a1d.md)

## Rule

- **Rule:** The typing test environment runs mypy as a command.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-26a90b8c29b9deac223ff6c6.md)

## Rule

- **Rule:** The typing job runs on ubuntu-latest, installs tox with pip, and runs tox run -e typing.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2e36b9c8475fee609ccf0d08.md)

## Rule

- **Rule:**
  ```text
  The typing job caches ./.mypy_cache keyed by mypy|hashFiles('pyproject.toml').
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3001ff6ce885ec3a410a832b.md)

## Rule

- **Rule:** The tests job runs on a matrix of Python versions 3.13, 3.12, 3.11, 3.10, 3.9, and 3.8, plus Windows and macOS on Python 3.12 and PyPy 3.10, with fail-fast disabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-372c7f75da7177bbc532bfc1.md)

## Rule

- **Rule:**
  ```text
  Run ``pytest`` using ``coverage`` and generate a report to find lines lacking test coverage.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-38915d9b31f068e8b795c2c9.md)

## Rule

- **Rule:**
  ```text
  The project's build backend is flit_core.buildapi.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3c6883eb2e5fd7aabd305df4.md)

## Rule

- **Rule:**
  ```text
  Files matching the [*] section have a maximum line length of 88.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3ea824520d7db756ba475ee7.md)

## Rule

- **Rule:** Pyright type checking targets Python 3.8.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-44ad85a2641fd9f51a43e8b8.md)

## Rule

- **Rule:** The pre-commit configuration enables the ruff hook from the astral-sh/ruff-pre-commit repository at rev v0.7.1.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4b270db0400deb0493b90d9e.md)

## Rule

- **Rule:**
  ```text
  Files matching the [*] section are configured to trim trailing whitespace.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4ca339d95bafd99842f4ee26.md)

## Rule

- **Rule:**
  ```text
  Clone the main repository locally with `git clone https://github.com/pallets/click` and enter it with `cd click`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-4f0bfaf5229830986198b4a0.md)

## Rule

- **Rule:** The pre-commit workflow runs on push events to the main and stable branches.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-53a6e299e886d38f7a7c5780.md)

## Rule

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.8 via requires-python = ">=3.8".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5776411247f55833132b6580.md)

## Rule

- **Rule:** Relevant docs pages and docstrings must be updated, and docs pages and docstrings should be wrapped at 72 characters.
- **Applies to:**
  - `**/*.py`
  - `docs/**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-5966b077ce720f4cbb483f9a.md)

## Rule

- **Rule:** The pre-commit workflow runs the pre-commit/action step.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5bcd413cc40ecb2c3d5bbed2.md)

## Rule

- **Rule:**
  ```text
  Files matching the [*] section use LF line endings.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5d296d80a8a3661bab0c2374.md)

## Rule

- **Rule:** The pre-commit configuration enables the check-merge-conflict hook from the pre-commit/pre-commit-hooks repository at rev v5.0.0.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5de2c330503d6245490031a1.md)

## Rule

- **Rule:** Ruff isort linting enforces single-line import formatting (force-single-line = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-621b35d9e44b2380761db6f7.md)

## Rule

- **Rule:** Ruff uses the full output format (output-format = "full").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-69ef22988e66d1ae9579e2b4.md)

## Rule

- **Rule:** The pre-commit workflow sets up Python version 3.x.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6ed19e25bd0efda6dd0f8e3f.md)

## Rule

- **Rule:**
  ```text
  Configure git with the contributor's username and email using `git config --global user.name` and `git config --global user.email`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-76ba13f00fd6d3a3772d66d1.md)

## Rule

- **Rule:** Read the Docs builds use Python 3.12.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-785f72deee826cff0e9aae1e.md)

## Rule

- **Rule:**
  ```text
  The project declares colorama as a dependency only on Windows (platform_system == 'Windows').
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7f40e61cf3babd359d2fb818.md)

## Rule

- **Rule:** Pyright runs in basic type checking mode.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-80aceb5e70b765c222b9babc.md)

## Rule

- **Rule:** Code must be formatted using Black; Black and other tools run automatically when pre-commit is installed.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-82947f5c208ef24bc1467008.md)

## Rule

- **Rule:**
  ```text
  Files matching the [*] section use space indentation.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-857fa404dc21b03c04b586bd.md)

## Rule

- **Rule:** Ruff isort linting does not order imports by type (order-by-type = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-91fd2aa337e189e5b9acfbcb.md)

## Rule

- **Rule:** The tox 'style' test environment declares pre-commit as its dependency.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a2455bd572f32aad53d32fde.md)

## Rule

- **Rule:** Ruff applies fixes automatically (fix = true).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a43b4e27650d4414590b69ef.md)

## Rule

- **Rule:** Read the Docs documentation builds install the repository itself via pip from the repository root.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a6ff3e611c513e4c95c4d386.md)

## Rule

- **Rule:**
  ```text
  The Tests workflow runs on pushes to the main and stable branches, ignoring changes under docs/** and to *.md and *.rst files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a792d561223230a3aacb58dd.md)

## Rule

- **Rule:**
  ```text
  The Tests workflow runs on pull requests, ignoring changes under docs/** and to *.md and *.rst files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b81ec3e1622a48c5e4bedc74.md)

## Rule

- **Rule:** The pre-commit workflow runs the pre-commit-ci/lite-action step when the job has not been cancelled.
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: ${{ !cancelled() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b972c4959abd3a9140e2717b.md)

## Rule

- **Rule:**
  ```text
  Add your fork as a remote named "fork" with `git remote add fork https://github.com/{username}/click`, replacing `{username}` with your username.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-b9cddf3fa61c2db8236d3d83.md)

## Rule

- **Rule:** An entry must be added in CHANGES.rst using the same style as other entries, and relevant docstrings must include .. versionchanged:: inline changelogs.
- **Applies to:**
  - `**/*.py`
  - `CHANGES.rst`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-bb7c625621ef139e27960b17.md)

## Rule

- **Rule:**
  ```text
  The pre-commit workflow runs on pull_request events.
  ```
- **Applies to:**
  - `**`
- **Condition:**
  ```text
  workflow predicate: pull_request:
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c02d963064911d24190afa50.md)

## Rule

- **Rule:**
  ```text
  Files matching the [*] section use UTF-8 charset.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c1cd8e94713700a0cfeff4f6.md)

## Rule

- **Rule:** The typing test environment runs pyright --verifytypes click --ignoreexternal.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c4603d7bd613a3800636b587.md)

## Rule

- **Rule:** The typing test environment installs its dependencies from requirements/typing.txt.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d34112251a76b09e0a590b1b.md)

## Rule

- **Rule:**
  ```text
  Pytest is configured to turn warnings into errors via filterwarnings = ["error"].
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d84eb57776aeb15cfd023ccb.md)

## Rule

- **Rule:** The gha-update tool is configured with tag-only set to the single entry "slsa-framework/slsa-github-generator".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d8770eeb92eaf95dc8a05f24.md)

## Rule

- **Rule:**
  ```text
  Coverage path mapping is configured with source paths "src" and "*/site-packages".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e1495c8f8e291c0ebc760692.md)

## Rule

- **Rule:** Coverage measurement is configured to track branch coverage.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e1da7c7e4157e7e795505bfc.md)

## Rule

- **Rule:**
  ```text
  The project declares flit_core<4 as its build requirement.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eec76cf038359925610a9081.md)

## Rule

- **Rule:**
  ```text
  Install the pre-commit hooks with `pre-commit install`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-eed92a64d6249e670767a98d.md)

## Rule

- **Rule:** Run the basic test suite with pytest.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-f19d17c4bf5fe67749abf158.md)

## Rule

- **Rule:** The tests job installs tox with pip and runs tox for the matrix environment (matrix.tox, or py{python} derived from the matrix Python version).
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f6a67821576101edf16be963.md)

## Rule

- **Rule:**
  ```text
  Files matching the [*] section are configured to insert a final newline.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f72088055f874630f713dd97.md)

## Rule

- **Rule:** Include tests that cover any code changes made, and ensure the test fails without the patch.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-fd4a5decede8dd15f7dc8cc4.md)

## Rule

- **Rule:**
  ```text
  The tox 'style' test environment sets skip_install to true, so the package is not installed into that environment.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fdd22ff404286fe9af9aa43a.md)

## Rule

- **Rule:**
  ```text
  Create a virtualenv with `python3 -m venv env` and activate it with `. env/bin/activate`; on Windows activate with `env\Scripts\activate`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-fe7c6f070b55634c59832006.md)
