# Rule details

- **Rule:**
  ```text
  Tests for add_completion_class must verify that registering a shell name adds it to _available_shells and returns the class, and that the shell name is absent before registration.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying tests for add_completion_class in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:358-375`
