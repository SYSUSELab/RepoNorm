# Rule details

- **Rule:** Tests that exercise custom ParamType rendering must preserve the convention that a command with a custom ParamType instance and a help option renders the custom type in help output.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying or adding tests that assert custom ParamType rendering in help output.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_formatting.py:249-267`
