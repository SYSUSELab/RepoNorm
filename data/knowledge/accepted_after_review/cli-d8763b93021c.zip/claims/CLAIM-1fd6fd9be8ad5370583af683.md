# Rule details

- **Rule:** For feature additions or changes, branch off the "main" branch (e.g., origin/main).
- **Applies to:**
  - `CONTRIBUTING.rst`
- **Condition:** when submitting a feature addition or change
- **Normative strength:** `required`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    If you're submitting a feature addition or change, branch off of the
    "main" branch.

```

- **Sources:**
  - `CONTRIBUTING.rst:143-144`

### Evidence 2 — explicit

```text
        $ git fetch origin
        $ git checkout -b your-branch-name origin/main

```

- **Sources:**
  - `CONTRIBUTING.rst:148-149`

## Review evidence locations

- `CONTRIBUTING.rst:143-149`
