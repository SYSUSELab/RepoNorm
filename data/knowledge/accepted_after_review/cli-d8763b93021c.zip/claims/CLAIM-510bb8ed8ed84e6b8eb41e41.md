# Rule details

- **Rule:** When modifying Context.abort, preserve that it raises Abort and is annotated as NoReturn, terminating control flow via an exception.
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When changing Context.abort or its exception behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:699-701`
