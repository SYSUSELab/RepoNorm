# Rule details

- **Rule:**
  ```text
  Tests for prompt option interaction must parameterize prompt=True together with prompt_required and required, treating prompt_required as a distinct option behavior tested independently from required.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  when adding or modifying tests for prompt option interaction or prompt_required behavior
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_termui.py:383-399`
