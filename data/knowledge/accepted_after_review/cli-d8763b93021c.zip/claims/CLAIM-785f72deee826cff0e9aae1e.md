# Rule details

- **Rule:** Read the Docs builds use Python 3.12.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    python: '3.12'

```

- **Sources:**
  - `.readthedocs.yaml:5`

## Review evidence locations

- `.readthedocs.yaml:5-5`
