# Rule details

- **Rule:**
  ```text
  Tests that exercise Click's option parsing must preserve the exact collected-value ordering and separator conventions when using multiple=True options, since downstream assertions join repeated values with '|'.
  ```
- **Applies to:**
  - `tests/test_basic.py`
  - `tests/test_options.py`
- **Condition:** when modifying or adding tests that use multiple=True options and assert on collected values
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:168-201`
