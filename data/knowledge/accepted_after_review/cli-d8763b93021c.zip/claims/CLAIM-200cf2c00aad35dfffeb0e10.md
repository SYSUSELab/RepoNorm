# Rule details

- **Rule:** The sharpen example command must clamp the user-supplied factor to a minimum of 1.0 before passing it to ImageEnhance.Sharpness, so factors below 1.0 are silently raised rather than rejected or passed through.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying the sharpen command's factor handling in the imagepipe example.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/imagepipe/imagepipe.py:250-260`
