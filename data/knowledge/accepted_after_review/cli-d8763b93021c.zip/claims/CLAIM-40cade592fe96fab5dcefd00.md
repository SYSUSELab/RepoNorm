# Rule details

- **Rule:**
  ```text
  As of Click 8.2, envvar used with flag_value must always use the flag_value rather than the environment variable's value.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Option envvar handling or flag_value resolution.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:2432-2434`
