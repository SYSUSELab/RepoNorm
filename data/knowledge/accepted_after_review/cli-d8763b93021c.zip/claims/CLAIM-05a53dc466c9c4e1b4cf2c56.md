# Rule details

- **Rule:**
  ```text
  When modifying choice validation messages, preserve that get_invalid_choice_message builds a singular/plural ngettext message using repr of the value and the joined repr of choices, so the message wording depends on the number of choices.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:** when changing how invalid choice errors are formatted
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:309-321`
