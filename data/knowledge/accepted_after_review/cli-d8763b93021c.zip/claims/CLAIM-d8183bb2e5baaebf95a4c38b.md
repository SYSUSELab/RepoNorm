# Rule details

- **Rule:**
  ```text
  Tests for non-ASCII byte output must assert that the CLI echoes the exact bytes (e.g. b'\xf6') without corruption.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** when adding or modifying tests for non-ASCII byte output handling
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:24-30`
