# Rule details

- **Rule:**
  ```text
  The imagepipe example must use @cli.result_callback to chain subcommand-returned processor functions into a stream pipeline and iterate the final stream to force evaluation.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When adding or modifying subcommands in the imagepipe example that return processor functions for the result callback to chain.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/imagepipe/imagepipe.py:10-39`
