# Rule details

- **Rule:** BadOptionUsage must be a UsageError subclass raised when an option is supplied but used incorrectly, such as an incorrect number of arguments.
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** When modifying or adding option misuse exception handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/exceptions.py:232-246`
