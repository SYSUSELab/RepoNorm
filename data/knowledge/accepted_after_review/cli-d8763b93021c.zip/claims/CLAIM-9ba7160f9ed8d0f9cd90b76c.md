# Rule details

- **Rule:**
  ```text
  get_text_stderr first tries _get_windows_console_stream and falls back to _force_correct_text_writer with force_writable=True, ensuring stderr is a writable text stream.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying stderr text stream acquisition in _compat.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_compat.py:351-355`
