# Rule details

- **Rule:** Tests for typing-aliased groups must declare a command with cls=AliasedGroup, exercising the custom command-class typing path.
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:** when adding or modifying typing tests for custom command classes such as AliasedGroup
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
AliasedGroup.get_command in tests/typing/typing_aliased_group.py exercises the custom command-class typing path, consistent with the AliasedGroup typing contract asserted by the test.
```

- **Sources:**
  - `tests/typing/typing_aliased_group.py:11-20`

## Review evidence locations

- `tests/typing/typing_aliased_group.py:31-36`
