# Rule details

- **Rule:**
  ```text
  Files matching the [*] section are configured to trim trailing whitespace.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
trim_trailing_whitespace = true

```

- **Sources:**
  - `.editorconfig:7`
