# Rule details

- **Rule:** Example commands that override command resolution must return the canonical command name rather than the alias used, so downstream resolution sees the real command name.
- **Applies to:**
  - `examples/**/*.py`
- **Condition:**
  ```text
  When adding or modifying an example command that overrides resolve_command to handle aliases.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/aliases/aliases.py:70-73`
