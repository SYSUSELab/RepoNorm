# Rule details

- **Rule:**
  ```text
  Parameter must preserve the documented deprecation of the autocompletion parameter renamed to shell_complete in 8.0, with the old name wrapped until 8.1.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Parameter's autocompletion or shell_complete parameter handling
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Parameter's docstring documents the 8.0 rename of autocompletion to shell_complete with the old name wrapped until 8.1, and the 2.0 callback signature change with old formats still working but warning, matching the compatibility contract.
```

- **Sources:**
  - `src/click/core.py:1950-2384`
