# Rule details

- **Rule:**
  ```text
  Converting a directory whose name contains a newline must raise BadParameter whose message contains the escaped 'my\\ndir'; this test is skipped on Windows.
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or extending tests for path conversion errors with escaped sequences.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_types.py:238-246`
