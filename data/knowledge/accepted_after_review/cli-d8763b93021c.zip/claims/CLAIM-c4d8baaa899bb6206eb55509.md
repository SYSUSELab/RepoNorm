# Rule details

- **Rule:**
  ```text
  click.Option(['foo']) must raise TypeError whose message contains 'name was passed (foo)', 'declare an argument', and "'--foo'", pinning the error text for options declared without dashes.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying or extending tests for option declaration errors when names lack dashes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:26-33`
