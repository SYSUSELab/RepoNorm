# Rule details

- **Rule:** ParamType.fail must raise BadParameter with the provided message, ctx, and param so parameter types signal invalid values through the standard error channel.
- **Applies to:**
  - `src/click/types.py`
- **Condition:** When implementing or modifying a ParamType subclass that needs to reject an invalid value.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:133-140`
