# Rule details

- **Rule:**
  ```text
  When modifying option parsing, preserve that Option.takes_value is True only when action is 'store' or 'append', defining which parser actions consume a following value.
  ```
- **Applies to:**
  - `src/click/parser.py`
- **Condition:** when changing how options consume values or adding new actions
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/parser.py:162-164`
