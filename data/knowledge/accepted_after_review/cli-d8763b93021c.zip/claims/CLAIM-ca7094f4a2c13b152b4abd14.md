# Rule details

- **Rule:**
  ```text
  _parse_decls is an abstract method raising NotImplementedError, defining the extension contract for parameter subclasses to parse declarations.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying or extending Parameter._parse_decls or adding new parameter subclasses.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:2141-2144`
