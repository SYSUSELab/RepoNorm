# Rule details

- **Rule:**
  ```text
  Typing example modules under tests/typing must remain static typing compatibility checks: typing_aliased_group defines a command 'pop' returning None to exercise aliased group typing, and typing_confirmation_option asserts a confirmation-option command is typed as click.Command for the documented yes-parameter pattern.
  ```
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
  - `tests/typing/typing_confirmation_option.py`
- **Condition:** When modifying or adding typing example modules under tests/typing.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
typing_aliased_group.py is a typing example module under tests/typing that defines commands and a type assertion for static typing compatibility.
```

- **Sources:**
  - `tests/typing/typing_aliased_group.py`

### Evidence 2 — current_observation

```text
typing_confirmation_option.py is a typing example module under tests/typing that asserts the confirmation-option command is typed as click.Command, matching the documented yes-parameter pattern.
```

- **Sources:**
  - `tests/typing/typing_confirmation_option.py`
