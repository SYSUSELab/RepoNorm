# Rule details

- **Rule:**
  ```text
  When modifying parameter processing order, preserve the sort key that orders eager parameters first and then by invocation_order index, assigning float('inf') to parameters absent from invocation_order so they sort last.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing iter_params_for_processing or its sort_key, or altering how invocation_order is populated.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:115-132`
