# Rule details

- **Rule:**
  ```text
  Shell completion tests must keep exercising the public shell_completion API surface (add_completion_class, CompletionItem, ShellComplete) together with core Command/Group/Option/Argument and Choice/File/Path types, because these are the stable entry points the completion tests depend on.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying shell completion tests or the completion API surface they import.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_shell_completion.py imports add_completion_class, CompletionItem, ShellComplete, and core Command/Group/Option/Argument plus Choice/File/Path types, exercising the public completion API surface.
```

- **Sources:**
  - `tests/test_shell_completion.py`
