# Rule details

- **Rule:**
  ```text
  After building, open `_build/html/index.html` in a browser to view the docs.
  ```
- **Applies to:**
  - `docs/**`
- **Normative strength:** `recommended`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
Open ``_build/html/index.html`` in your browser to view the docs.

```

- **Sources:**
  - `CONTRIBUTING.rst:214`

## Review evidence locations

- `CONTRIBUTING.rst:214-214`
