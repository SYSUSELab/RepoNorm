# Rule details

- **Rule:** Example commands that use a processor decorator must forward the stream plus any additional arguments and keyword arguments to the wrapped function.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When adding or modifying a processor decorator in the imagepipe example.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — current_observation

```text
The processor decorator's new_func forwards *args and **kwargs to the wrapped function, matching the rule that processor decorators forward the stream plus additional arguments and keyword arguments.
```

- **Sources:**
  - `examples/imagepipe/imagepipe.py:47-51`

### Evidence 2 — current_observation

```text
display_cmd is decorated with @processor and yields images, forwarding the stream through the processor decorator.
```

- **Sources:**
  - `examples/imagepipe/imagepipe.py:123-128`

## Review evidence locations

- `examples/imagepipe/imagepipe.py:47-51`
- `examples/imagepipe/imagepipe.py:123-128`
