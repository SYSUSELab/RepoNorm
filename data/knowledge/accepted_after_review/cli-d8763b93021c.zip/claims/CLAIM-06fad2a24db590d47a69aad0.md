# Rule details

- **Rule:** Tests that subclass click.Argument to define a custom argument type must demonstrate that Argument is designed for subclassing and that the custom class is used in test scenarios.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when adding or modifying tests that subclass click.Argument for custom argument types
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:621-634`
