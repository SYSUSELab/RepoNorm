# Rule details

- **Rule:** Tests for CompletionItem must assert that arbitrary keyword data is accepted and that unset attributes return None, defining its attribute access behavior.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** when adding or modifying tests for CompletionItem attribute access or data handling
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:285-288`
