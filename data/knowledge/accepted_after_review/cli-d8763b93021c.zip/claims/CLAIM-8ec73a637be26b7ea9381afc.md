# Rule details

- **Rule:**
  ```text
  Multiple=True options must split envvar values on os.path.pathsep, and auto_envvar_prefix must map TEST_ARG to the option, producing pathsep-joined output.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying multiple-option envvar splitting or auto_envvar_prefix behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test file asserts that multiple=True options split envvar values on os.path.pathsep and that auto_envvar_prefix maps TEST_ARG to the option, producing pathsep-joined output.
```

- **Sources:**
  - `tests/test_options.py`
