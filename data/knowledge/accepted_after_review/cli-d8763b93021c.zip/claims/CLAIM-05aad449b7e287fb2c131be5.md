# Rule details

- **Rule:**
  ```text
  get_completion_args must read COMP_WORDS and COMP_CWORD from the environment, slice args as cwords[1:cword], and treat a missing cwords[cword] as an empty incomplete string.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:** When modifying Bash completion argument parsing from environment variables.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/shell_completion.py:334-344`
