# Rule details

- **Rule:** The pre-commit workflow sets up Python version 3.x.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    - uses: actions/setup-python@f677139bbe7f9c59b41e40162b753c062f5d49a3 # v5.2.0
      with:
        python-version: 3.x

```

- **Sources:**
  - `.github/workflows/pre-commit.yaml:11-13`

## Review evidence locations

- `.github/workflows/pre-commit.yaml:11-13`
