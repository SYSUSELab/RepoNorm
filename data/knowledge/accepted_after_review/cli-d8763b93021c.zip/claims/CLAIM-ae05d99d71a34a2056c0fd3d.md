# Rule details

- **Rule:** The lock workflow uses the concurrency group 'lock'.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
concurrency:
  group: lock

```

- **Sources:**
  - `.github/workflows/lock.yaml:13-14`

## Review evidence locations

- `.github/workflows/lock.yaml:13-14`
