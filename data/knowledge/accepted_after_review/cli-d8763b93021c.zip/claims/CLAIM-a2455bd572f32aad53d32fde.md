# Rule details

- **Rule:** The tox 'style' test environment declares pre-commit as its dependency.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
deps = pre-commit

```

- **Sources:**
  - `tox.ini:19`

## Review evidence locations

- `tox.ini:19-19`
