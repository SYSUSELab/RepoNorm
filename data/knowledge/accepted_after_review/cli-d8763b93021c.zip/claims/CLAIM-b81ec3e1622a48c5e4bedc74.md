# Rule details

- **Rule:**
  ```text
  The Tests workflow runs on pull requests, ignoring changes under docs/** and to *.md and *.rst files.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  pull_request:
    paths-ignore: [ 'docs/**', '*.md', '*.rst' ]

```

- **Sources:**
  - `.github/workflows/tests.yaml:6-7`

## Review evidence locations

- `.github/workflows/tests.yaml:6-7`
