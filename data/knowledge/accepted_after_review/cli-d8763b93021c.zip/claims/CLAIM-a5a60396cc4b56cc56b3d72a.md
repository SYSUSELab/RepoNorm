# Rule details

- **Rule:** mypy is configured to check the files under src/click and tests/typing.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
files = ["src/click", "tests/typing"]

```

- **Sources:**
  - `pyproject.toml:62`
