# Rule details

- **Rule:**
  ```text
  Install the development dependencies and then install Click in editable mode with `pip install -r requirements/dev.txt && pip install -e .`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
-   Install the development dependencies, then install Click in
    editable mode.

    .. code-block:: text

        $ pip install -r requirements/dev.txt && pip install -e .

```

- **Sources:**
  - `CONTRIBUTING.rst:110-115`

## Review evidence locations

- `CONTRIBUTING.rst:110-115`
