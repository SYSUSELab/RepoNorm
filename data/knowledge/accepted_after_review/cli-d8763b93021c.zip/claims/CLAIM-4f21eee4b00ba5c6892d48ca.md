# Rule details

- **Rule:**
  ```text
  When modifying help formatting defaults, preserve that HelpFormatter width defaults to terminal width minus 2, clamped between 50 and max_width (default 80), with FORCED_WIDTH overriding terminal detection.
  ```
- **Applies to:**
  - `src/click/formatting.py`
- **Condition:** when changing HelpFormatter width calculation or terminal detection
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
HelpFormatter.__init__ computes width as terminal width minus 2, clamps between 50 and max_width (default 80), and honors FORCED_WIDTH.
```

- **Sources:**
  - `src/click/formatting.py:116-133`
