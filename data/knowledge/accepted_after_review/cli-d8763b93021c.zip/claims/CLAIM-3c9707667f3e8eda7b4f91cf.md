# Rule details

- **Rule:** Tests that exercise File argument behavior must preserve the convention that a click.File() argument exposes the opened file's name and mode.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying or adding tests that assert click.File() argument attributes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_testing.py:374-382`
