# Rule details

- **Rule:**
  ```text
  Group.shell_complete must return CompletionItems for visible subcommands with their short help, then extend with super().shell_complete results so subcommand completion includes help text and inherited completions.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying shell completion for Group or adding subcommand completion behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:1857-1874`
