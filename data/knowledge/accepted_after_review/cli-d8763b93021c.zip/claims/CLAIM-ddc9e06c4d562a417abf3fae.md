# Rule details

- **Rule:** The lock-threads action is configured with issue-inactive-days, pr-inactive-days, and discussion-inactive-days all set to 14.
- **Applies to:**
  - `.github/workflows/lock.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
          issue-inactive-days: 14
          pr-inactive-days: 14
          discussion-inactive-days: 14

```

- **Sources:**
  - `.github/workflows/lock.yaml:21-23`

## Review evidence locations

- `.github/workflows/lock.yaml:19-23`
