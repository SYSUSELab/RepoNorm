# Rule details

- **Rule:**
  ```text
  When modifying DateTime.__repr__, preserve the stable literal representation "DateTime" used for type display.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When changing DateTime.__repr__ or its type display representation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
DateTime.__repr__ returns the literal string "DateTime", preserving the stable type display representation required by r2.
```

- **Sources:**
  - `src/click/types.py:417-418`
