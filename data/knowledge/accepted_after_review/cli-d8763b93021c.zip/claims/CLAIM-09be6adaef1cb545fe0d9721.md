# Rule details

- **Rule:** confirm builds its prompt with default 'y/n' when default is None, 'Y/n' when default is truthy, and 'y/N' otherwise; it loops on invalid input, treats y/yes as True and n/no as False, and raises Abort on KeyboardInterrupt/EOFError or when abort is set and the answer is negative.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** When modifying the confirm prompt function or its input handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/termui.py:194-252`
