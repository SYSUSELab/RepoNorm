# Rule details

- **Rule:** Example commands that demonstrate ANSI coloring must call click.style with fg and bg set to the same color name when showing foreground and background coloring.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** when modifying the colordemo command in the termui example
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/termui/termui.py:14-20`
