# Rule details

- **Rule:**
  ```text
  get_error_hint must append the environment variable name to the hint only when show_envvar is true, making envvar hints opt-in per parameter.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** When modifying error hint generation or envvar display behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:2584-2588`
