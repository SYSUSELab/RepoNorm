# Rule details

- **Rule:**
  ```text
  The help option callback must echo the context help and exit only when a value is present and resilient_parsing is false, so help output is suppressed during resilient parsing.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:** when modifying help option callback or resilient parsing behavior
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:1020-1023`
