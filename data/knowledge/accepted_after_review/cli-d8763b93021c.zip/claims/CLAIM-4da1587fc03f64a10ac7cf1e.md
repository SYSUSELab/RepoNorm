# Rule details

- **Rule:**
  ```text
  When modifying ShellComplete.func_name, preserve the shell function name contract: sanitize prog_name by replacing '-' with '_' and stripping non-word characters with re.sub(r"\W*", "", ..., flags=re.ASCII), then wrap it as _{safe_name}_completion.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  Modifying ShellComplete.func_name sanitization or completion function naming.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
ShellComplete.func_name replaces '-' with '_', strips non-word characters via re.sub with re.ASCII, and wraps the result as _{safe_name}_completion.
```

- **Sources:**
  - `src/click/shell_completion.py:231-236`
