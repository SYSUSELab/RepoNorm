# Rule details

- **Rule:** Ruff isort linting does not order imports by type (order-by-type = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
order-by-type = false

```

- **Sources:**
  - `pyproject.toml:97`

## Review evidence locations

- `pyproject.toml:95-97`
