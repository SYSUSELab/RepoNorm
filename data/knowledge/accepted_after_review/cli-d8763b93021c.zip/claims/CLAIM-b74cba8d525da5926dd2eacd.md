# Rule details

- **Rule:** Shell completion for an option must exclude options already present on the command line; once an option has been supplied, its other spellings must not be suggested again.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or extending shell completion tests for options that have already been supplied on the command line.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:25-32`
