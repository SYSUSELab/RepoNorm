# Rule details

- **Rule:** The build job installs build requirements with pip install -r requirements/build.txt.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
      - run: pip install -r requirements/build.txt

```

- **Sources:**
  - `.github/workflows/publish.yaml:18`
