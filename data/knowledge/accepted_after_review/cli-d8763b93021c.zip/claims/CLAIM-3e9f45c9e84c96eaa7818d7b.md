# Rule details

- **Rule:**
  ```text
  Tests for click progressbar rendering must monkeypatch click._termui_impl.isatty to True and assert that a padded progressbar label is preserved in output, guarding against a strip regression.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When adding or modifying tests for click progressbar rendering
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_termui.py:28-41`
