# Rule details

- **Rule:** Ruff treats src as the source root directory.
- **Applies to:**
  - `src/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
src = ["src"]

```

- **Sources:**
  - `pyproject.toml:80`

## Review evidence locations

- `pyproject.toml:78-83`
