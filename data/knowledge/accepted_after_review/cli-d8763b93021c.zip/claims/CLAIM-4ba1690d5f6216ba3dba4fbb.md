# Rule details

- **Rule:**
  ```text
  A test command using nargs=2 (without multiple) must parse the two values as a single tuple, echoed joined by '|'.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying or extending tests for nargs=2 parsing without multiple.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:376-386`
