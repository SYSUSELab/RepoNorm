# Rule details

- **Rule:**
  ```text
  The testing helper's visible_input must write the prompt to stdout, read a line from text_input, strip CR/LF, echo the value, and flush, defining how simulated interactive input is surfaced in test output.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** when modifying simulated interactive input in the testing helper
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/testing.py:334-340`
