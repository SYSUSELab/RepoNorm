# Rule details

- **Rule:**
  ```text
  Tests that exercise CLI behavior through CliRunner must invoke the runner with standalone_mode=False when asserting on the command's return_value, so that Click returns the callback result instead of exiting.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Condition:**
  ```text
  when adding or modifying a test that asserts on a Click command's return_value via CliRunner
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_testing.py:361-371`
