# Rule details

- **Rule:**
  ```text
  get_text_stream must look up the named stream in text_streams and raise TypeError for unknown names, with encoding and errors overrides passed to the opener.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:** When modifying text stream lookup or its error handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/utils.py:337-355`
