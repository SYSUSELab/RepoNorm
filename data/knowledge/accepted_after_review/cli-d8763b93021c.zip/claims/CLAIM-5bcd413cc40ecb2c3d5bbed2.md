# Rule details

- **Rule:** The pre-commit workflow runs the pre-commit/action step.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    - uses: pre-commit/action@2c7b3805fd2a0fd8c1884dcaebf91fc102a13ecd # v3.0.1

```

- **Sources:**
  - `.github/workflows/pre-commit.yaml:14`

## Review evidence locations

- `.github/workflows/pre-commit.yaml:14-14`
