# Rule details

- **Rule:** The typing job runs on ubuntu-latest, installs tox with pip, and runs tox run -e typing.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
    runs-on: ubuntu-latest

```

- **Sources:**
  - `.github/workflows/tests.yaml:36`

### Evidence 2 — explicit

```text
      - run: pip install tox
      - run: tox run -e typing

```

- **Sources:**
  - `.github/workflows/tests.yaml:49-50`

## Review evidence locations

- `.github/workflows/tests.yaml:36-36`
- `.github/workflows/tests.yaml:49-50`
