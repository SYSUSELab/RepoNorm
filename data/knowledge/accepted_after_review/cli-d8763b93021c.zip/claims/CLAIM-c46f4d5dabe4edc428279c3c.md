# Rule details

- **Rule:** Sphinx documentation builds use the dirhtml builder.
- **Applies to:**
  - `docs/**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  builder: dirhtml

```

- **Sources:**
  - `.readthedocs.yaml:12`

## Review evidence locations

- `.readthedocs.yaml:12-12`
