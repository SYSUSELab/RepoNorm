# Rule details

- **Rule:**
  ```text
  LazyFile.__repr__ must return repr of the underlying file when opened, otherwise a descriptive '<unopened file ...>' string including the formatted filename and mode.
  ```
- **Applies to:**
  - `src/click/utils.py`
- **Condition:**
  ```text
  When modifying LazyFile.__repr__ or adding lazy file wrappers that need a repr.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/utils.py:146-149`
