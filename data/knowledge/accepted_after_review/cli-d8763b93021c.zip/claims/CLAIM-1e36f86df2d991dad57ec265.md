# Rule details

- **Rule:** termui.pause returns immediately without output when stdin or stdout is not a tty, and otherwise prints the info message, waits for a key, and clears the message in a finally block; KeyboardInterrupt and EOFError during getchar are swallowed.
- **Applies to:**
  - `src/click/termui.py`
- **Condition:** When modifying termui.pause or its tty gating and cleanup behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/termui.py:762-793`
