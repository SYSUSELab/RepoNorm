# Rule details

- **Rule:** Pyright runs in basic type checking mode.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
typeCheckingMode = "basic"

```

- **Sources:**
  - `pyproject.toml:76`

## Review evidence locations

- `pyproject.toml:73-76`
