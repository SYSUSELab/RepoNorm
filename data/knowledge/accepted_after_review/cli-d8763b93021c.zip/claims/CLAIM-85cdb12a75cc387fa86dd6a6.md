# Rule details

- **Rule:** The typing test environment runs pyright against the tests/typing directory.
- **Applies to:**
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
commands =
    mypy
    pyright tests/typing
    pyright --verifytypes click --ignoreexternal

```

- **Sources:**
  - `tox.ini:25-28`
