# Rule details

- **Rule:**
  ```text
  Tests that exercise Click's shell-completion registry must snapshot and restore click.shell_completion._available_shells so that mutations do not leak across tests.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when a test mutates or registers entries in click.shell_completion._available_shells
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:349-359`
