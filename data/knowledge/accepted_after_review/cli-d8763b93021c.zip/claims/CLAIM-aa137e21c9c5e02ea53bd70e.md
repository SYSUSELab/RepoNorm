# Rule details

- **Rule:**
  ```text
  Tests for click context resource lifecycle must assert that ctx.with_resource registers a context manager whose value is available during the scope and is closed on scope exit, with the returned value reflecting post-close state.
  ```
- **Applies to:**
  - `tests/test_context.py`
- **Condition:**
  ```text
  When adding or modifying tests for click context resource lifecycle with ctx.with_resource
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_context.py:410-423`
