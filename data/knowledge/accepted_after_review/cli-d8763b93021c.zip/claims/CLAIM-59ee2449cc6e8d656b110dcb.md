# Rule details

- **Rule:**
  ```text
  Example progressbar demonstrations must support various configurations including fill_char styling, item_show_func, custom bar_template, width=0, and non-linear progress via manual bar.update.
  ```
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When adding or modifying a progressbar demonstration in the termui example.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/termui/termui.py:50-100`
