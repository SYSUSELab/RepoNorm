# Rule details

- **Rule:** The naval example's ship group must define a 'new' subcommand that takes a name argument and echoes the created ship.
- **Applies to:**
  - `examples/naval/naval.py`
- **Condition:** When adding or modifying subcommands on the naval example's ship group.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/naval/naval.py:15-24`
