# Rule details

- **Rule:**
  ```text
  Group.add_command must raise TypeError when neither an explicit name nor cmd.name is available, and must call _check_nested_chain before storing the command in self.commands.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Group.add_command or command registration logic
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Group.add_command raises TypeError when neither an explicit name nor cmd.name is available and calls _check_nested_chain before storing the command in self.commands, matching the registration contract.
```

- **Sources:**
  - `src/click/core.py:1545-1553`
