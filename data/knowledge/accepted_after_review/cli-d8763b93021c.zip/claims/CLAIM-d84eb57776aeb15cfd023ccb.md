# Rule details

- **Rule:**
  ```text
  Pytest is configured to turn warnings into errors via filterwarnings = ["error"].
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
filterwarnings = [
    "error",
]

```

- **Sources:**
  - `pyproject.toml:49-51`

## Review evidence locations

- `pyproject.toml:47-51`
