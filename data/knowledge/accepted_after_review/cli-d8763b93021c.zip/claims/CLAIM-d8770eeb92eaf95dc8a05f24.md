# Rule details

- **Rule:** The gha-update tool is configured with tag-only set to the single entry "slsa-framework/slsa-github-generator".
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
tag-only = [
    "slsa-framework/slsa-github-generator",
]

```

- **Sources:**
  - `pyproject.toml:100-102`

## Review evidence locations

- `pyproject.toml:99-102`
