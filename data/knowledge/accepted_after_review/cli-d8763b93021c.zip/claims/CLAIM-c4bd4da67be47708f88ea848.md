# Rule details

- **Rule:**
  ```text
  Example click groups that manage shared state must store a state object on ctx.obj in the group callback and provide it to subcommands via a pass_repo-style decorator.
  ```
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When adding or modifying a click group in the repo example that manages shared state.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
The cli group callback stores a Repo object on ctx.obj (ctx.obj = Repo(...)) and the example provides it to subcommands via a pass_repo-style decorator, matching the shared-state convention.
```

- **Sources:**
  - `examples/repo/repo.py:44-57`
