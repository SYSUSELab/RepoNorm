# Rule details

- **Rule:**
  ```text
  When modifying Context.command_path, preserve the usage-path computation: join the parent's command_path with each parent parameter's get_usage_pieces, then append the current info_name and strip leading whitespace, so usage strings include parent parameter placeholders.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Context.command_path usage-path construction.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Context.command_path joins the parent command_path with parent parameter get_usage_pieces, appends the current info_name, and strips leading whitespace, matching the rule.
```

- **Sources:**
  - `src/click/core.py:615-631`
