# Rule details

- **Rule:**
  ```text
  Tests that exercise progress bar formatting must preserve the invariant that format_bar renders a fixed-width bar where an unfinished bar at pos 7 shows '#######-' and a finished bar shows all eight '#' characters regardless of pos.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When modifying or adding tests that assert progress bar format_bar output for fixed widths.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_termui.py:132-143`
