# Rule details

- **Rule:** The build job runs on ubuntu-latest.
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
  build:
    runs-on: ubuntu-latest

```

- **Sources:**
  - `.github/workflows/publish.yaml:7-8`

## Review evidence locations

- `.github/workflows/publish.yaml:6-8`
