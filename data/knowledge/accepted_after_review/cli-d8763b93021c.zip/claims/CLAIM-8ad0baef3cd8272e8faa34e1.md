# Rule details

- **Rule:**
  ```text
  Normalization tests must define CONTEXT_SETTINGS with token_normalize_func=lambda x: x.lower() to establish the shared case-insensitive normalization convention.
  ```
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:**
  ```text
  When adding or modifying normalization tests, use CONTEXT_SETTINGS with token_normalize_func=lambda x: x.lower() for case-insensitive normalization.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_normalization.py:1-3`
