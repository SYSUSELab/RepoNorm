# Rule details

- **Rule:**
  ```text
  Tests for command decorator params must assert that params passed to the decorator are appended in order, with cli.params[0].name == 'a' and cli.params[1].name == 'b', and that invoking with '1 2' outputs '1 2'.
  ```
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** When modifying or adding tests for command decorator params ordering.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_command_decorators.py:62-73`
