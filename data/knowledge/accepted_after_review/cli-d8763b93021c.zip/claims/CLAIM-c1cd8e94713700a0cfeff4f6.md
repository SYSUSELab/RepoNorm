# Rule details

- **Rule:**
  ```text
  Files matching the [*] section use UTF-8 charset.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
charset = utf-8

```

- **Sources:**
  - `.editorconfig:9`
