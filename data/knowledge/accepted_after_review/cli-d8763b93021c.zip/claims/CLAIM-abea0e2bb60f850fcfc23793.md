# Rule details

- **Rule:**
  ```text
  When modifying Command.__init__, preserve the public constructor defaults: options_metavar='[OPTIONS]', add_help_option=True, no_args_is_help=False, hidden=False, deprecated=False, and params stored as params or [].
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing Command.__init__ signature or default values.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:895-936`
