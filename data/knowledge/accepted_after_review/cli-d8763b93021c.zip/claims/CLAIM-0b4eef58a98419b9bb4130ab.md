# Rule details

- **Rule:**
  ```text
  Command.main must be overloaded with standalone_mode: Literal[True] returning NoReturn, encoding the invariant that standalone mode exits the process rather than returning.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Command.main signature or standalone_mode typing
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:1241-1259`
