# Rule details

- **Rule:** The tox testenv uses .pkg as the wheel build environment.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
wheel_build_env = .pkg

```

- **Sources:**
  - `tox.ini:12`
