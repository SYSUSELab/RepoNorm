# Rule details

- **Rule:**
  ```text
  collect_usage_pieces starts with options_metavar when set, then extends with each parameter's get_usage_pieces, defining the composition of the usage line.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying usage line composition or Command.collect_usage_pieces.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:994-1003`
