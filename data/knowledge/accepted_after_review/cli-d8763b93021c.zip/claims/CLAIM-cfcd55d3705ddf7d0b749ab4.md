# Rule details

- **Rule:** Tests that exercise usage-error formatting must preserve the convention that a missing required argument exits with code 2 and prints a usage line followed by "Error: Missing argument 'ARG'.".
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying or adding tests that assert usage-error output for a missing required argument.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_formatting.py:145-158`
