# Rule details

- **Rule:**
  ```text
  When modifying error output, preserve the convention that ClickException.show writes 'Error: <message>' to stderr by default via get_text_stderr when no file is provided.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:** when changing how ClickException errors are displayed
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/exceptions.py:35-45`
