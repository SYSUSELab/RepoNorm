# Rule details

- **Rule:**
  ```text
  When modifying Option.get_help_extra, preserve the behavior that ctx.resilient_parsing is temporarily set to True while computing the default value so type-casting failures for defaults do not break help generation, and envvar names are derived from auto_envvar_prefix.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Option.get_help_extra default-value computation or envvar-name derivation.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:2727-2756`
