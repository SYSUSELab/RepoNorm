# Rule details

- **Rule:** Tests that exercise Click's option prefixes must preserve the acceptance of non-standard prefixes like '++' as flag option names, demonstrating that option prefixes are not limited to '--' and '-'.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** when modifying or adding tests that exercise option prefix handling
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:10-19`
