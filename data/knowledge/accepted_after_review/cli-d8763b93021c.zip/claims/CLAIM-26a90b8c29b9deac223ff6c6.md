# Rule details

- **Rule:** The typing test environment runs mypy as a command.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
commands =
    mypy
    pyright tests/typing
    pyright --verifytypes click --ignoreexternal

```

- **Sources:**
  - `tox.ini:25-28`
