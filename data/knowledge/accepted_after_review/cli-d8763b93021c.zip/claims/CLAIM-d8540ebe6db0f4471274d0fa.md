# Rule details

- **Rule:**
  ```text
  Tests for click.echo color behavior must monkeypatch click._compat.isatty and assert that color=False strips ANSI styling, color=True preserves it, and default color behavior follows isatty; these tests are skipped on Windows.
  ```
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:**
  ```text
  when adding or modifying click.echo color tests in tests/test_utils.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:212-237`
