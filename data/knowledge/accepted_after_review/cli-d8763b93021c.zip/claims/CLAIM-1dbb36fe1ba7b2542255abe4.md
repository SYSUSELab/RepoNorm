# Rule details

- **Rule:** The termui example's menu command must use click.getchar() in a loop with main/debug/quit states to handle interactive character input.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying the termui example's menu command interactive input handling.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/termui/termui.py:144-169`
