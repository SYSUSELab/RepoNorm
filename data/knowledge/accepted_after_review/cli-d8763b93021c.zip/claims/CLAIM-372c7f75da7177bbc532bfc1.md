# Rule details

- **Rule:** The tests job runs on a matrix of Python versions 3.13, 3.12, 3.11, 3.10, 3.9, and 3.8, plus Windows and macOS on Python 3.12 and PyPy 3.10, with fail-fast disabled.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
      fail-fast: false
      matrix:
        include:
          - {python: '3.13'}
          - {python: '3.12'}
          - {name: Windows, python: '3.12', os: windows-latest}
          - {name: Mac, python: '3.12', os: macos-latest}
          - {python: '3.11'}
          - {python: '3.10'}
          - {python: '3.9'}
          - {python: '3.8'}
          - {name: PyPy, python: 'pypy-3.10', tox: pypy310}

```

- **Sources:**
  - `.github/workflows/tests.yaml:13-24`

## Review evidence locations

- `.github/workflows/tests.yaml:13-24`
