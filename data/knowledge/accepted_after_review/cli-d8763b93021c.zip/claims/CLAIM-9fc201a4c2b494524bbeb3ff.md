# Rule details

- **Rule:** The update-requirements tox environment installs pip-tools as its dependency.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
deps = pip-tools

```

- **Sources:**
  - `tox.ini:47`
