# Rule details

- **Rule:**
  ```text
  Tests that exercise click's help/usage rendering must preserve the documented output contracts: make_default_short_help truncates at word boundaries within max_length and appends an ellipsis (a no-wrap marker does not change the result), show_choices=False renders type metavars such as [TEXT] or [TEXT|INTEGER] instead of choice values, and an empty multiple default with show_default=True is omitted from help (get_help_extra returns {} and the help record message is 'values').
  ```
- **Applies to:**
  - `tests/test_options.py`
  - `tests/test_utils.py`
- **Condition:** When modifying or adding tests that assert click help/usage output for short-help truncation, choice metavars, or empty multiple defaults.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:474-507`
- `tests/test_options.py:830-838`
- `tests/test_options.py:958-991`
