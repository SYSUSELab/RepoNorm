# Rule details

- **Rule:**
  ```text
  get_default must support a callable default protocol, accepting ctx and call and returning Any, a callable, or None.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying the get_default method or its typing overloads.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:2167-2208`
