# Rule details

- **Rule:** The tox testenv uses frozen constraints.
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
use_frozen_constraints = true

```

- **Sources:**
  - `tox.ini:14`
