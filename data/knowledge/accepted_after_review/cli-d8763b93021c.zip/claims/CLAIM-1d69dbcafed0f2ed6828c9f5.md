# Rule details

- **Rule:** Tests covering Click command-decorator application must verify that the decorator can be applied to a minimal callback function and that the resulting command executes correctly.
- **Applies to:**
  - `tests/test_command_decorators.py`
- **Condition:** when modifying or adding tests for Click command-decorator application to a minimal callback
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_command_decorators.py:6-13`
