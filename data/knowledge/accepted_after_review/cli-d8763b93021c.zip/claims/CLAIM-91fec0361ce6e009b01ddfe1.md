# Rule details

- **Rule:**
  ```text
  Group merged with and replaced the MultiCommand base class in 8.2, and since 8.0 the commands argument may be a list of command objects; group_class set to the literal type makes subgroups inherit the current group's class.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying Group class hierarchy, commands argument handling, or group_class behavior.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:1426-1477`
