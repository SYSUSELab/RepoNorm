# Rule details

- **Rule:**
  ```text
  When modifying terminal UI wrappers, preserve that raw_terminal is a thin wrapper that imports and delegates to _termui_impl.raw_terminal, returning an AbstractContextManager[int].
  ```
- **Applies to:**
  - `src/click/termui.py`
- **Condition:**
  ```text
  when changing raw_terminal or its delegation to _termui_impl
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/termui.py:756-759`
