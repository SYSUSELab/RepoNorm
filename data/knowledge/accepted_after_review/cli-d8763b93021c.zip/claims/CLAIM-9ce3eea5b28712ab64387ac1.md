# Rule details

- **Rule:**
  ```text
  The validation example must demonstrate three validation approaches: a callback (validate_count), a custom type (URL), and manual validation in the command function raising BadParameter with a param_hint.
  ```
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** When modifying the validation example's validation approaches.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/validation/validation.py:27-45`
