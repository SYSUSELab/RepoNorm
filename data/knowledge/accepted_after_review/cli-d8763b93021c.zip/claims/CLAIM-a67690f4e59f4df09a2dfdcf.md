# Rule details

- **Rule:**
  ```text
  The imagepipe example's copy_filename helper must copy the filename attribute from an old file-like object to a new one and return the new object.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:**
  ```text
  When modifying the copy_filename helper in the imagepipe example.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `examples/imagepipe/imagepipe.py:69-71`
