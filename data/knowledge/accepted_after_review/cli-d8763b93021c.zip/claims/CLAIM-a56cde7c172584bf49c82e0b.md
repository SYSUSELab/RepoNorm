# Rule details

- **Rule:**
  ```text
  CliRunner's hidden_input helper must write the prompt to stdout, flush, then read a line from text_input and strip trailing CR/LF.
  ```
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When modifying simulated prompt input capture in CliRunner.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/testing.py:342-346`
