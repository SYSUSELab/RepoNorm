# Rule details

- **Rule:**
  ```text
  Tests that require symlink support must gate on the _symlinks_supported probe, which creates a target file and attempts os.symlink in a temporary directory, returning False on OSError, so that symlink-dependent tests are skipped on unsupported platforms.
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying or adding tests that depend on symlink support.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_types.py:109-125`
