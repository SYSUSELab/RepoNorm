# Rule details

- **Rule:** The Windows console isatty override must call super().isatty() and then unconditionally return True, so Windows console streams always report as TTY.
- **Applies to:**
  - `src/click/_winconsole.py`
- **Condition:** When modifying or extending the Windows console isatty override or related platform behavior.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_winconsole.py:108-114`
