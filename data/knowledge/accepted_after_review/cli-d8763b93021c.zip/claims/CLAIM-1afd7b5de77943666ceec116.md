# Rule details

- **Rule:** Shell completion for arguments must use the argument's default value when no value is supplied and must ignore type validation, returning the next argument's default even when the prior value is invalid.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** When modifying or extending shell completion tests for arguments, preserve the behavior that defaults are used and type validation is bypassed during completion.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:93-105`
