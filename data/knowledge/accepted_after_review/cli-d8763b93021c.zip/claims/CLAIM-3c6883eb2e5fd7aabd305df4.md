# Rule details

- **Rule:**
  ```text
  The project's build backend is flit_core.buildapi.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
build-backend = "flit_core.buildapi"

```

- **Sources:**
  - `pyproject.toml:30`

## Review evidence locations

- `pyproject.toml:28-30`
