# Rule details

- **Rule:**
  ```text
  When modifying Command.format_epilog, preserve the behavior that the epilog is written only when self.epilog is set, applying inspect.cleandoc and writing it as an indented paragraph in the help formatter.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  Modifying Command.format_epilog epilog rendering.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Command.format_epilog writes the epilog only when self.epilog is set, applies inspect.cleandoc, and writes it as an indented paragraph, matching the rule.
```

- **Sources:**
  - `src/click/core.py:1112-1119`
