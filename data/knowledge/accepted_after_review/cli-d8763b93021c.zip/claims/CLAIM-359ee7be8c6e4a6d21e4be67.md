# Rule details

- **Rule:**
  ```text
  The tox testenv `update-actions` runs the command `gha-update`.
  ```
- **Applies to:**
  - `tox.ini`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
commands = gha-update

```

- **Sources:**
  - `tox.ini:37`
