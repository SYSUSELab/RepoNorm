# Rule details

- **Rule:**
  ```text
  get_binary_stdout must raise RuntimeError when no binary writer can be determined for sys.stdout, making the failure mode explicit.
  ```
- **Applies to:**
  - `src/click/_compat.py`
- **Condition:**
  ```text
  When modifying get_binary_stdout or binary stdout detection.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/_compat.py:323-327`
