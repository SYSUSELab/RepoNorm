# Rule details

- **Rule:** Tests for multiple sequential prompts must define a command with multiple prompt options and drive them through CliRunner with scripted input.
- **Applies to:**
  - `tests/**/*.py`
- **Condition:** when adding or modifying a test for multiple sequential Click prompts
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_testing.py:76-84`
