# Rule details

- **Rule:**
  ```text
  When modifying _MultiCommand, preserve the deprecation boundary: _MultiCommand is deprecated as of 8.2 and scheduled for removal in Click 9.0, with Group as the replacement; do not remove or change this compatibility boundary without updating the deprecation schedule.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When changing _MultiCommand or its deprecation metadata.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
_MultiCommand's class docstring states it is deprecated as of 8.2 and will be removed in Click 9.0, with Group as the replacement, matching the deprecation-boundary rule.
```

- **Sources:**
  - `src/click/core.py:1877-1881`
