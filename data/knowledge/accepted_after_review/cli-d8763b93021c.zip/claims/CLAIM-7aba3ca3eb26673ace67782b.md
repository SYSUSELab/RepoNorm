# Rule details

- **Rule:**
  ```text
  When modifying CompositeParamType in types.py, preserve that it subclasses ParamType and sets is_composite = True, marking it as a type that consumes multiple values.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  Changing CompositeParamType inheritance or is_composite flag
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
CompositeParamType subclasses ParamType and sets is_composite = True, satisfying the rule preserving its multi-value type contract.
```

- **Sources:**
  - `src/click/types.py:160-165`
