# Rule details

- **Rule:** The test defines a command using click.confirm with default=True, branching to echo 'yes!' or 'no :(' based on the confirmation result.
- **Applies to:**
  - `tests/test_utils.py`
- **Condition:** When modifying or extending tests for click.confirm with default=True.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_utils.py:133-150`
