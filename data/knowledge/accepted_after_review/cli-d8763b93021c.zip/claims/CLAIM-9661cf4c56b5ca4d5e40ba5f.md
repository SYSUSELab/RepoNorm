# Rule details

- **Rule:** Tests for shell completion of flag options must verify that completing '--' yields the flag names and that after the flag is given, completion falls through to the Choice argument values, confirming flags do not consume a value.
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  when adding or modifying shell completion tests for flag options in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_shell_completion.py:175-186`
