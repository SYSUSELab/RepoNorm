# Rule details

- **Rule:**
  ```text
  Sphinx autodoc options in docs/conf.py must keep autodoc_member_order='bysource', autodoc_typehints='description', and autodoc_preserve_defaults=True so generated API documentation preserves source member order, renders type hints in the description, and shows original default values.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:**
  ```text
  When modifying Sphinx configuration in docs/conf.py, preserve the autodoc_member_order, autodoc_typehints, and autodoc_preserve_defaults settings.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
docs/conf.py sets autodoc_member_order='bysource', autodoc_typehints='description', and autodoc_preserve_defaults=True, matching the rule for preserving source order, description type hints, and original defaults.
```

- **Sources:**
  - `docs/conf.py`
