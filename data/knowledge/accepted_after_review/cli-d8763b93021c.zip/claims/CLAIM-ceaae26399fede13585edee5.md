# Rule details

- **Rule:** Tests covering Click subcommand registration must verify that a subcommand is registered by decorating a function with @cli.command() on an existing group and that the subcommand body echoes a sentinel string used by tests to verify execution.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** when modifying or adding tests for Click subcommand registration via @cli.command() on an existing group
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_basic.py:56-79`
