# Rule details

- **Rule:**
  ```text
  Example groups that discover subcommands from a folder must scan for files matching cmd_*.py, strip the 'cmd_' prefix and '.py' suffix, and sort the resulting names.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** when modifying subcommand discovery in the complex example group
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
list_commands scans cmd_folder via os.listdir for files ending in .py and starting with cmd_, strips the prefix/suffix, and sorts the names, matching the folder-based discovery rule.
```

- **Sources:**
  - `examples/complex/complex/cli.py:32-38`
