# Rule details

- **Rule:**
  ```text
  Help text truncation must occur at a form feed (\f) in a command docstring, and tests must define a command whose docstring contains \f followed by text.
  ```
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying help text truncation behavior or its tests.
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_formatting.py defines commands whose docstrings contain a form feed (\f) followed by text (test_truncating_docstring, test_truncating_docstring_no_help) and asserts help output truncates at the form feed, matching the form-feed truncation contract.
```

- **Sources:**
  - `tests/test_formatting.py`
