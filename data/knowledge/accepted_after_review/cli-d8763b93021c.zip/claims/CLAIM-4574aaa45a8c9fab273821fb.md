# Rule details

- **Rule:** The testing harness must handle a string exit code from sys.exit by producing the corresponding exit code and output.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying or extending tests for the testing harness's handling of string exit codes.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_testing.py:213-218`
- `tests/test_testing.py:252-256`
