# Rule details

- **Rule:**
  ```text
  With auto_envvar_prefix='test' and env TEST_ARG=foo, invoking the command with no arguments must succeed and output 'foo', showing the prefix is uppercased and combined with the argument name.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying or extending tests for auto_envvar_prefix, preserve the behavior that the prefix is uppercased and combined with the argument name to read environment variables.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_options.py:365-373`
