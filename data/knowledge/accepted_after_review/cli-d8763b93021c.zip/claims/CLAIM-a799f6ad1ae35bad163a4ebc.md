# Rule details

- **Rule:**
  ```text
  The build job generates a hash by running sha256sum over dist contents and base64-encoding the result into $GITHUB_OUTPUT.
  ```
- **Applies to:**
  - `.github/workflows/publish.yaml`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: cd dist && echo "hash=$(sha256sum * | base64 -w0)" >> $GITHUB_OUTPUT

```

- **Sources:**
  - `.github/workflows/publish.yaml:25`
