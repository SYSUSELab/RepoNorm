# Rule details

- **Rule:** Example commands that accept a URL argument must validate it through the example's URL parameter type, which rejects any scheme other than http/https via self.fail and skips scheme validation for already-parsed tuple values.
- **Applies to:**
  - `examples/validation/validation.py`
- **Condition:** when adding or modifying an example command that accepts a URL argument
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
URL.convert rejects non-http/https schemes via self.fail and skips scheme validation for already-parsed tuple values, matching the URL validation rule.
```

- **Sources:**
  - `examples/validation/validation.py:15-24`
