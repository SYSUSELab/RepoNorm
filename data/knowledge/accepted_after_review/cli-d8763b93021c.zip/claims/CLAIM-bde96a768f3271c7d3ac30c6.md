# Rule details

- **Rule:**
  ```text
  When the completion environment variable is set, _main_shell_completion must delegate to shell_complete and call sys.exit with its return value, exiting before the program is invoked.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  When modifying the main shell completion entry point or its delegation to shell_complete.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/core.py:1374-1404`
