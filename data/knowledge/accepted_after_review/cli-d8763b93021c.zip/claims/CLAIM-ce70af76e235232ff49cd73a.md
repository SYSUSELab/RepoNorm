# Rule details

- **Rule:**
  ```text
  For the mypy override applying to the "colorama.*" module, missing imports are ignored.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Supporting evidence

### Evidence 1 — explicit

```text
module = [
    "colorama.*",
]

```

- **Sources:**
  - `pyproject.toml:68-70`

### Evidence 2 — explicit

```text
ignore_missing_imports = true

```

- **Sources:**
  - `pyproject.toml:71`

## Review evidence locations

- `pyproject.toml:67-71`
