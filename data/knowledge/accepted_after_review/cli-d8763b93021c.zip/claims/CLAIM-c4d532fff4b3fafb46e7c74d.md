# Rule details

- **Rule:** Tests for click float option parsing must assert that empty args yield the default value, '--f=23.5' yields 23.5, and invalid input '--f=x' produces an error message and a non-None exception.
- **Applies to:**
  - `tests/test_basic.py`
- **Condition:** When adding or modifying tests for click float option parsing
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `tests/test_basic.py:182-202`
