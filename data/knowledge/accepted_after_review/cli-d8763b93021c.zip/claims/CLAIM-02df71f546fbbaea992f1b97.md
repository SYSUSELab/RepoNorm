# Rule details

- **Rule:**
  ```text
  ShellComplete.get_completions must resolve the context and incomplete value from the args, then delegate to the resolved object's shell_complete(ctx, incomplete) method, defining the extension protocol for completion targets.
  ```
- **Applies to:**
  - `src/click/shell_completion.py`
- **Condition:**
  ```text
  When modifying or extending ShellComplete.get_completions or adding new completion targets.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/shell_completion.py:265-275`
