# Rule details

- **Rule:** When modifying EchoingStdin.readline, preserve that it echoes the bytes read from the wrapped input stream so test input supplied to CliRunner is reflected in captured output.
- **Applies to:**
  - `src/click/testing.py`
- **Condition:** When changing EchoingStdin.readline or CliRunner input echoing.
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/testing.py:35-48`
