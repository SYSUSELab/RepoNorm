# Rule details

- **Rule:**
  ```text
  Command.get_help must build a formatter via ctx.make_formatter, call format_help, and return the value with trailing newlines stripped.
  ```
- **Applies to:**
  - `src/click/core.py`
- **Condition:**
  ```text
  when modifying Command.get_help or help formatting logic
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — current_observation

```text
Command.get_help builds a formatter via ctx.make_formatter, calls format_help, and returns formatter.getvalue().rstrip("\n"), matching the rule.
```

- **Sources:**
  - `src/click/core.py:1041-1048`
