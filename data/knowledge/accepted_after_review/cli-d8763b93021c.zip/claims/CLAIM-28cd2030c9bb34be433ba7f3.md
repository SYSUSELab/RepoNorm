# Rule details

- **Rule:** Coverage measurement is configured to restrict its source to the click package and the tests directory.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Acceptance source:** `automatic_verification`

## Supporting evidence

### Evidence 1 — explicit

```text
source = ["click", "tests"]

```

- **Sources:**
  - `pyproject.toml:55`
