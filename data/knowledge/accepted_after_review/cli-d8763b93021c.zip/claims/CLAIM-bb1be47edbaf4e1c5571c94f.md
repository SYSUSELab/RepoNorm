# Rule details

- **Rule:**
  ```text
  ClickException.format_message must return self.message unchanged, so subclasses or callers expecting transformation get the raw message.
  ```
- **Applies to:**
  - `src/click/exceptions.py`
- **Condition:**
  ```text
  When modifying ClickException.format_message or subclass message formatting.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/exceptions.py:31-39`
