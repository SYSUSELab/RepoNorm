# Rule details

- **Rule:**
  ```text
  Path type must derive its display name from file_okay/dir_okay: file-only yields 'file', dir-only yields 'directory', and both or neither yields 'path', which determines the name shown in error messages.
  ```
- **Applies to:**
  - `src/click/types.py`
- **Condition:**
  ```text
  When modifying Path.__init__ or the display name used in Path error messages.
  ```
- **Normative strength:** `observed`
- **Acceptance source:** `model_review`

## Review evidence locations

- `src/click/types.py:816-843`
