# winconsole

The `winconsole` module (`src/click/_winconsole.py`) provides a Windows-specific
implementation for reading from and writing to the native Windows console using
the wide-character (`W`) Win32 APIs. It exists because the standard Python
`io` stack on Windows does not correctly handle the UTF-16-LE encoding used by
the Windows console, nor does it reliably support interactive console input and
output for tools like Click.

This module is part of the **platform_and_terminal_foundation** layer of the
Click framework. It is a private, internal module (note the leading underscore)
and is only imported on Windows platforms.

> **Platform constraint:** The module begins with `assert sys.platform == "win32"`,
> so it can only be imported on Windows. On other platforms the import will fail
> immediately.

---

## Purpose and Core Functionality

The module solves three related problems:

1. **Correct encoding** — The Windows console communicates in UTF-16-LE, but
   Python's default text streams may use a different encoding. This module
   wraps the console handles with streams that explicitly use `utf-16-le`.
2. **Native console I/O** — It uses `ReadConsoleW` / `WriteConsoleW` from
   `kernel32` to interact with the console directly, bypassing the C runtime's
   byte-oriented I/O.
3. **Transparent stream replacement** — It exposes a factory
   (`_get_windows_console_stream`) that the compatibility layer can call to
   replace `sys.stdin`, `sys.stdout`, and `sys.stderr` with console-aware
   streams when appropriate.

---

## Architecture Overview

The module is organized into three conceptual layers: a low-level buffer
access layer, a raw I/O layer, and a high-level stream wrapper layer.

```mermaid
graph TD
    subgraph "High-level stream layer"
        CS[ConsoleStream]
        FTS[_get_text_stdin / stdout / stderr]
        GWS[_get_windows_console_stream]
    end

    subgraph "Raw I/O layer"
        RIOB[_WindowsConsoleRawIOBase]
        RDR[_WindowsConsoleReader]
        WTR[_WindowsConsoleWriter]
    end

    subgraph "Buffer access layer"
        PB[Py_buffer]
        GB[get_buffer]
    end

    subgraph "Win32 API"
        RCW[ReadConsoleW]
        WCW[WriteConsoleW]
        GCM[GetConsoleMode]
        GSH[GetStdHandle]
    end

    GWS --> FTS
    FTS --> CS
    CS --> RDR
    CS --> WTR
    RDR --> RIOB
    WTR --> RIOB
    RDR --> GB
    WTR --> GB
    GB --> PB
    RDR --> RCW
    WTR --> WCW
    GWS --> GCM
    RIOB --> GSH
```

---

## Core Components

### `Py_buffer` (Structure)

A `ctypes.Structure` that mirrors the CPython `Py_buffer` C struct. It is used
to obtain a raw, writable memory view over a Python buffer object so that the
Win32 wide-character APIs can read from or write into it directly.

| Field | ctypes type | Description |
|-------|-------------|-------------|
| `buf` | `c_void_p` | Pointer to the underlying memory |
| `obj` | `py_object` | The exporting object |
| `len` | `c_ssize_t` | Length in bytes |
| `itemsize` | `c_ssize_t` | Size of one item |
| `readonly` | `c_int` | Read-only flag |
| `ndim` | `c_int` | Number of dimensions |
| `format` | `c_char_p` | Format string |
| `shape` | `c_ssize_p` | Shape array |
| `strides` | `c_ssize_p` | Strides array |
| `suboffsets` | `c_ssize_p` | Sub-offsets array |
| `internal` | `c_void_p` | Internal field |

The companion `get_buffer(obj, writable=False)` helper acquires a buffer via
`PyObject_GetBuffer`, casts the memory to a `c_char` array, and always releases
the buffer with `PyBuffer_Release` in a `finally` block.

> **PyPy limitation:** On PyPy, `ctypes.pythonapi` is unavailable, so
> `get_buffer` is set to `None`. In that case the entire console-stream
> replacement mechanism is disabled (see `_get_windows_console_stream`).

### `_WindowsConsoleRawIOBase`

The base class for the raw console reader and writer. It subclasses
`io.RawIOBase` and stores the Win32 `handle` (an integer file handle). It
overrides `isatty()` to always return `True`, since these streams always
represent a real console.

### `_WindowsConsoleReader`

A readable raw I/O object that reads UTF-16-LE data from the console.

- `readable()` returns `True`.
- `readinto(b)` reads into the provided buffer:
  - Returns `0` for an empty buffer.
  - Raises `ValueError` if the requested byte count is odd (UTF-16-LE requires
    an even number of bytes).
  - Converts bytes to code units (`bytes // 2`) and calls `ReadConsoleW`.
  - If `GetLastError()` reports `ERROR_OPERATION_ABORTED`, it sleeps briefly
    (`time.sleep(0.1)`) to allow a pending `KeyboardInterrupt` to be delivered.
  - Raises `OSError` if the read fails.
  - Returns `0` when the first code unit equals `EOF` (`b"\x1a"`), signaling
    end-of-input.
  - Otherwise returns `2 * code_units_read`.

### `_WindowsConsoleWriter`

A writable raw I/O object that writes UTF-16-LE data to the console.

- `writable()` returns `True`.
- `_get_error_message(errno)` maps Win32 error codes to human-readable strings
  (`ERROR_SUCCESS`, `ERROR_NOT_ENOUGH_MEMORY`, or a generic `Windows error N`).
- `write(b)` writes into the console:
  - Caps the number of code units written per call at `MAX_BYTES_WRITTEN`
    (`32767`) to respect the Win32 API limit.
  - Calls `WriteConsoleW`.
  - Raises `OSError` if nothing was written despite a non-empty input buffer.
  - Returns the number of bytes written (`2 * code_units_written`).

### `ConsoleStream`

A high-level wrapper that presents a single object supporting both text and
binary writes, delegating to an underlying text stream and byte stream.

- `__init__(text_stream, byte_stream)` stores both streams; `buffer` is the
  byte stream.
- `name` proxies to `self.buffer.name`.
- `write(x)`:
  - If `x` is a `str`, writes to the text stream.
  - Otherwise flushes the text stream (ignoring errors) and writes the bytes
    to the binary buffer.
- `writelines(lines)` writes each line via `write`.
- `__getattr__` delegates unknown attributes to the text stream.
- `isatty()` delegates to `self.buffer.isatty()`.
- `__repr__` shows the stream name and encoding.

---

## Stream Factory Functions

Three private factory functions build the console-aware text streams. Each
wraps a `_WindowsConsoleReader`/`_WindowsConsoleWriter` in a buffered I/O
object, then in a `_NonClosingTextIOWrapper` configured for `utf-16-le` with
`line_buffering=True`, and finally in a `ConsoleStream`.

| Function | Handle | Raw object | Purpose |
|----------|--------|-----------|---------|
| `_get_text_stdin` | `STDIN_HANDLE` (-10) | `_WindowsConsoleReader` | Console input |
| `_get_text_stdout` | `STDOUT_HANDLE` (-11) | `_WindowsConsoleWriter` | Console output |
| `_get_text_stderr` | `STDERR_HANDLE` (-12) | `_WindowsConsoleWriter` | Console error output |

These are registered in the `_stream_factories` mapping keyed by file
descriptor (`0`, `1`, `2`).

### `_is_console(f)`

Determines whether a text stream `f` refers to a real Windows console. It:

1. Returns `False` if `f` has no `fileno` attribute.
2. Obtains the file descriptor, returning `False` on `OSError` or
   `io.UnsupportedOperation`.
3. Converts the descriptor to an OS handle via `msvcrt.get_osfhandle`.
4. Calls `GetConsoleMode` and returns whether it succeeds.

### `_get_windows_console_stream(f, encoding, errors)`

The public entry point used by the compatibility layer. It returns a
console-aware text stream for `f`, or `None` if replacement is not applicable.

It returns `None` when any of the following hold:

- `get_buffer` is `None` (PyPy).
- `encoding` is not `"utf-16-le"` or `None`.
- `errors` is not `"strict"` or `None`.
- `f` is not a console (`_is_console` returns `False`).
- `f.fileno()` is not one of `0`, `1`, `2`.
- `f` has no `buffer` attribute.

Otherwise it calls the matching factory from `_stream_factories`.

---

## Data Flow

The following diagram shows the flow of data when Click writes text to the
console and reads input from it.

```mermaid
sequenceDiagram
    participant App as Application / Click
    participant CS as ConsoleStream
    participant TW as _NonClosingTextIOWrapper
    participant BW as BufferedWriter / BufferedReader
    participant Raw as _WindowsConsoleWriter / Reader
    participant API as WriteConsoleW / ReadConsoleW

    Note over App,API: Writing text
    App->>CS: write("hello")
    CS->>TW: write("hello")
    TW->>BW: encode utf-16-le + buffer
    BW->>Raw: write(bytes)
    Raw->>Raw: get_buffer(b)
    Raw->>API: WriteConsoleW(handle, buf, code_units)
    API-->>Raw: code_units_written
    Raw-->>BW: bytes_written
    BW-->>TW: count
    TW-->>CS: count
    CS-->>App: count

    Note over App,API: Reading text
    App->>CS: read()
    CS->>TW: read()
    TW->>BW: read()
    BW->>Raw: readinto(b)
    Raw->>API: ReadConsoleW(handle, buf, code_units)
    API-->>Raw: code_units_read
    Raw-->>BW: bytes_read
    BW-->>TW: decode utf-16-le
    TW-->>CS: str
    CS-->>App: str
```

---

## Component Interaction

```mermaid
classDiagram
    class io.RawIOBase
    class _WindowsConsoleRawIOBase {
        +handle
        +isatty() True
    }
    class _WindowsConsoleReader {
        +readable() True
        +readinto(b) int
    }
    class _WindowsConsoleWriter {
        +writable() True
        +_get_error_message(errno) str
        +write(b) int
    }
    class ConsoleStream {
        +_text_stream
        +buffer
        +name
        +write(x) int
        +writelines(lines)
        +isatty() bool
    }
    class Py_buffer {
        +buf
        +obj
        +len
        ...
    }

    io.RawIOBase <|-- _WindowsConsoleRawIOBase
    _WindowsConsoleRawIOBase <|-- _WindowsConsoleReader
    _WindowsConsoleRawIOBase <|-- _WindowsConsoleWriter
    ConsoleStream --> _WindowsConsoleReader : wraps (stdin)
    ConsoleStream --> _WindowsConsoleWriter : wraps (stdout/stderr)
    _WindowsConsoleReader ..> Py_buffer : uses get_buffer
    _WindowsConsoleWriter ..> Py_buffer : uses get_buffer
```

---

## Relationship to Other Modules

The `winconsole` module is a leaf dependency within the
**platform_and_terminal_foundation** layer. It depends on and is consumed by
the following modules:

```mermaid
graph LR
    subgraph "platform_and_terminal_foundation"
        COMPAT[compat]
        WIN[winconsole]
        TERM[termui_impl]
        TW[textwrap]
    end
    COMPAT -->|_NonClosingTextIOWrapper| WIN
    WIN -.->|_get_windows_console_stream| COMPAT
```

- **[compat](compat.md)** — Provides `_NonClosingTextIOWrapper`, which the
  stream factories use to build text streams that do not close their underlying
  binary stream on garbage collection. The `compat` module is also the primary
  consumer of `_get_windows_console_stream`, calling it to decide whether to
  replace the standard streams.
- **[termui_impl](termui_impl.md)** — The terminal UI implementation
  (`Editor`, `ProgressBar`) relies on the console streams being correctly set
  up so that interactive output renders properly on Windows.
- **[textwrap](textwrap.md)** — Provides text wrapping used for help output
  that ultimately flows through these console streams.

---

## Constants Reference

| Constant | Value | Meaning |
|----------|-------|---------|
| `STDIN_HANDLE` | `GetStdHandle(-10)` | Standard input handle |
| `STDOUT_HANDLE` | `GetStdHandle(-11)` | Standard output handle |
| `STDERR_HANDLE` | `GetStdHandle(-12)` | Standard error handle |
| `PyBUF_SIMPLE` | `0` | Simple buffer request flag |
| `PyBUF_WRITABLE` | `1` | Writable buffer request flag |
| `ERROR_SUCCESS` | `0` | Win32 success code |
| `ERROR_NOT_ENOUGH_MEMORY` | `8` | Win32 out-of-memory code |
| `ERROR_OPERATION_ABORTED` | `995` | Win32 aborted-operation code |
| `STDIN_FILENO` | `0` | stdin file descriptor |
| `STDOUT_FILENO` | `1` | stdout file descriptor |
| `STDERR_FILENO` | `2` | stderr file descriptor |
| `EOF` | `b"\x1a"` | Console end-of-input marker |
| `MAX_BYTES_WRITTEN` | `32767` | Max bytes per `WriteConsoleW` call |

---

## Process Flow: Stream Replacement

```mermaid
flowchart TD
    A[compat calls _get_windows_console_stream] --> B{get_buffer is None?}
    B -->|Yes PyPy| Z[Return None]
    B -->|No| C{encoding in utf-16-le/None?}
    C -->|No| Z
    C -->|Yes| D{errors in strict/None?}
    D -->|No| Z
    D -->|Yes| E{_is_console f ?}
    E -->|No| Z
    E -->|Yes| F{fileno in 0,1,2?}
    F -->|No| Z
    F -->|Yes| G{f has buffer?}
    G -->|No| Z
    G -->|Yes| H[Call matching factory]
    H --> I[Build raw reader/writer]
    I --> J[Wrap in Buffered IO]
    J --> K[Wrap in _NonClosingTextIOWrapper utf-16-le]
    K --> L[Wrap in ConsoleStream]
    L --> M[Return ConsoleStream]
```

---

## Summary

The `winconsole` module is a focused, Windows-only compatibility shim that
makes Click's console I/O correct and reliable. It bridges Python's `io`
abstraction with the native Win32 wide-character console APIs, handling
UTF-16-LE encoding, buffer acquisition via `ctypes`, and the subtle edge cases
of interactive console input (such as `KeyboardInterrupt` delivery and the
`EOF` marker). Its single public-facing entry point,
`_get_windows_console_stream`, is consumed by the
[compat](compat.md) module to transparently upgrade the standard streams when
running on a real Windows console.
