# Testing Module

## Introduction

The `testing` module (`src/click/testing.py`) provides the infrastructure needed to invoke Click command-line applications in a fully isolated environment for unit testing purposes. Its central abstraction, [`CliRunner`](#clirunner), captures standard input/output/error streams, environment variables, and terminal-related global state so that a CLI can be exercised programmatically and its behavior asserted deterministically.

The module is part of the **developer and shell integration tooling** group, sitting alongside [shell completion](shell_completion.md). It depends on the core command model ([cli_framework_core](cli_framework_core.md)), the platform/terminal foundation ([platform_and_terminal_foundation](platform_and_terminal_foundation.md)), and the parameter/IO utilities ([parameter_types_and_io_utilities](parameter_types_and_io_utilities.md)).

> **Note:** `CliRunner` mutates global interpreter state (`sys.stdin`, `sys.stdout`, `sys.stderr`, `os.environ`, and several Click module-level hooks). It therefore only works in single-threaded systems without concurrency.

---

## Architecture Overview

The module is organized around a runner that sets up an isolation context, invokes a command, and packages the captured output into a result object.

```mermaid
graph TD
    subgraph "testing.py"
        CliRunner["CliRunner<br/>(orchestrator)"]
        Result["Result<br/>(captured output)"]
        StreamMixer["StreamMixer<br/>(stdout+stderr mix)"]
        BytesIOCopy["BytesIOCopy<br/>(tee'd BytesIO)"]
        EchoingStdin["EchoingStdin<br/>(echo input to stdout)"]
        NamedWrapper["_NamedTextIOWrapper<br/>(named text stream)"]
        make_input["make_input_stream()"]
        pause_echo["_pause_echo()"]
    end

    CliRunner -->|creates| StreamMixer
    CliRunner -->|creates| EchoingStdin
    CliRunner -->|creates| NamedWrapper
    CliRunner -->|uses| make_input
    CliRunner -->|uses| pause_echo
    CliRunner -->|returns| Result
    StreamMixer -->|contains| BytesIOCopy
    Result -->|references| CliRunner
```

### Component Responsibilities

| Component | Responsibility |
|-----------|----------------|
| [`CliRunner`](#clirunner) | Sets up isolation, invokes the command, and returns a [`Result`](#result). |
| [`Result`](#result) | Immutable container for captured stdout/stderr/output bytes, exit code, return value, and exception info. |
| [`StreamMixer`](#streammixer) | Provides separate `stdout`/`stderr` buffers plus a combined `output` buffer preserving write order. |
| [`BytesIOCopy`](#bytesiocopy) | A `BytesIO` subclass that mirrors every write into a second buffer (the "tee" mechanism). |
| [`EchoingStdin`](#echoingstdin) | Wraps an input stream so that reads are echoed to an output stream. |
| [`_NamedTextIOWrapper`](#_namedtextiowrapper) | A `TextIOWrapper` with a fixed `name`/`mode` and `EOFError`-on-`StopIteration` semantics. |
| `make_input_stream()` | Normalizes `str`/`bytes`/stream input into a binary reader. |
| `_pause_echo()` | Context manager that temporarily suppresses echoing on an [`EchoingStdin`](#echoingstdin). |

---

## Core Components

### CliRunner

`CliRunner` is the primary entry point. It is configured once and reused across tests.

```python
runner = CliRunner()
result = runner.invoke(my_cli, ["--help"])
assert result.exit_code == 0
```

**Constructor parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `charset` | `"utf-8"` | Character set used for input/output encoding. |
| `env` | `{}` | Base environment variable overrides. |
| `echo_stdin` | `False` | When `True`, reading from `<stdin>` is echoed to `<stdout>`. |
| `catch_exceptions` | `True` | Whether to catch exceptions other than `SystemExit` during `invoke`. |

**Key methods:**

- `get_default_prog_name(cli)` — Returns `cli.name` or `"root"`.
- `make_env(overrides)` — Merges the runner's base env with per-invocation overrides.
- [`isolation(...)`](#isolation-context-manager) — Context manager that installs the isolated environment.
- [`invoke(...)`](#invoke-method) — Runs the command and returns a [`Result`](#result).
- [`isolated_filesystem(...)`](#isolated_filesystem-context-manager) — Creates and `chdir`s into a temporary directory.

#### isolation() context manager

`isolation()` is the heart of the module. It performs the following mutations and restores them on exit:

```mermaid
flowchart TD
    Start([Enter isolation]) --> Save["Save old state:<br/>sys.stdin/stdout/stderr,<br/>FORCED_WIDTH, prompt funcs,<br/>should_strip_ansi hooks"]
    Save --> Mixer["Create StreamMixer<br/>(stdout, stderr, output)"]
    Mixer --> Stdin["Wrap input in _NamedTextIOWrapper<br/>(optionally EchoingStdin)"]
    Stdin --> Stdout["Bind sys.stdout / sys.stderr<br/>to mixer streams"]
    Stdout --> Hooks["Patch termui.visible_prompt_func,<br/>hidden_prompt_func, _getchar,<br/>utils/_compat.should_strip_ansi"]
    Hooks --> Env["Apply env overrides to os.environ"]
    Env --> Yield["yield (stdout, stderr, output)"]
    Yield --> Restore["Restore all saved state<br/>and os.environ"]
    Restore --> End([Exit isolation])
```

Notable behaviors:

- `formatting.FORCED_WIDTH` is set to `80` so help output is deterministic regardless of terminal size (see [formatting](cli_framework_core.md)).
- When `echo_stdin` is enabled, `text_input._CHUNK_SIZE` is forced to `1` to prevent buffered reads from echoing early.
- `<stderr>` is opened with `errors="backslashreplace"` so undecodable bytes never raise.
- The prompt functions (`visible_input`, `hidden_input`, `_getchar`) are patched into the `termui` module (see [platform_and_terminal_foundation](platform_and_terminal_foundation.md)) and wrapped with `_pause_echo` so that programmatic prompts do not double-echo input.

#### invoke() method

`invoke()` wraps `isolation()` and drives the command:

```mermaid
sequenceDiagram
    participant Test
    participant CliRunner
    participant isolation
    participant Command
    participant Result

    Test->>CliRunner: invoke(cli, args, input, env, ...)
    CliRunner->>CliRunner: resolve catch_exceptions
    CliRunner->>isolation: enter isolation(input, env, color)
    isolation-->>CliRunner: (stdout, stderr, output) streams
    CliRunner->>CliRunner: shlex.split(args) if str
    CliRunner->>CliRunner: resolve prog_name
    CliRunner->>Command: cli.main(args, prog_name, **extra)
    Command-->>CliRunner: return_value / SystemExit / Exception
    CliRunner->>CliRunner: flush streams, read getvalue()
    CliRunner->>Result: construct Result(...)
    Result-->>Test: Result
```

Exit-code handling:

- `SystemExit` with `code=None` → exit code `0`.
- `SystemExit` with a non-zero integer → recorded as `exception` and `exit_code`.
- `SystemExit` with a non-integer code → the code is written to stdout and exit code becomes `1`.
- Other exceptions → re-raised if `catch_exceptions` is `False`, otherwise recorded with `exit_code = 1`.

#### isolated_filesystem() context manager

Creates a temporary directory via `tempfile.mkdtemp`, changes the working directory into it, and restores the original CWD on exit. If `temp_dir` is provided, the created directory is **not** removed on exit; otherwise it is recursively deleted.

---

### Result

`Result` holds the captured outcome of an invocation. It is constructed by [`CliRunner.invoke`](#invoke-method) and exposes both raw bytes and decoded string views.

| Attribute / Property | Type | Description |
|----------------------|------|-------------|
| `runner` | `CliRunner` | The runner that produced the result. |
| `stdout_bytes` | `bytes` | Raw standard output. |
| `stderr_bytes` | `bytes` | Raw standard error. |
| `output_bytes` | `bytes` | Interleaved stdout+stderr as seen in a terminal. |
| `return_value` | `Any` | Value returned by the invoked command. |
| `exit_code` | `int` | Process exit code. |
| `exception` | `BaseException \| None` | The exception raised, if any. |
| `exc_info` | `tuple \| None` | `sys.exc_info()`-style traceback tuple. |
| `output` | `str` | Decoded, newline-normalized mix of stdout+stderr. |
| `stdout` | `str` | Decoded, newline-normalized stdout. |
| `stderr` | `str` | Decoded, newline-normalized stderr. |

All string properties decode using `runner.charset` with `errors="replace"` and normalize `\r\n` to `\n`.

> **Version note (8.2):** `output` is no longer a proxy for `stdout`; it now has its own independent stream that mixes stdout and stderr in write order. `stderr` no longer raises when empty.

---

### StreamMixer

`StreamMixer` provides three buffers:

- `stdout` — a [`BytesIOCopy`](#bytesiocopy) that tees into `output`.
- `stderr` — a [`BytesIOCopy`](#bytesiocopy) that tees into `output`.
- `output` — the combined buffer receiving both streams in write order.

This design lets tests assert on individual streams *and* on the combined terminal view without re-running the command.

---

### BytesIOCopy

A subclass of `io.BytesIO` that mirrors every `write()` into a `copy_to` buffer and forwards `flush()` to both. This is the "tee" primitive underlying [`StreamMixer`](#streammixer).

```mermaid
graph LR
    W["write(b)"] --> Copy["copy_to.write(b)"]
    W --> Super["super().write(b)"]
```

---

### EchoingStdin

Wraps a binary input stream and an output stream. Every read operation (`read`, `read1`, `readline`, `readlines`, iteration) echoes the returned bytes to the output stream unless echoing is paused. Unknown attributes are delegated to the wrapped input via `__getattr__`.

Echoing is toggled by the `_paused` flag, which is managed by [`_pause_echo`](#_pause_echo).

---

### _NamedTextIOWrapper

A `TextIOWrapper` subclass that:

- Reports a fixed `name` and `mode` (used to make `sys.stdin`/`sys.stdout`/`sys.stderr` look like real named streams).
- Converts `StopIteration` from `__next__` into `EOFError`, matching the behavior expected by interactive prompt code.

---

### Helper Functions

#### make_input_stream()

Normalizes the `input` argument of [`invoke`](#invoke-method) into a binary reader:

1. If the object has a `read` attribute, it is resolved to a binary reader via `_find_binary_reader` (from [platform_and_terminal_foundation](platform_and_terminal_foundation.md)); a `TypeError` is raised if none is found.
2. `None` becomes an empty `BytesIO`.
3. `str` is encoded using the runner's charset.
4. `bytes` are wrapped directly in a `BytesIO`.

#### _pause_echo()

A context manager that sets `stream._paused = True` on entry and `False` on exit, suppressing echo while a prompt reads input programmatically.

---

## Data Flow

The following diagram traces input and output through a single `invoke()` call.

```mermaid
flowchart LR
    subgraph Input
        InArg["input (str/bytes/stream)"]
        InArg --> MIS["make_input_stream()"]
        MIS --> Echo["EchoingStdin (optional)"]
        Echo --> StdinWrap["_NamedTextIOWrapper<br/>sys.stdin"]
    end

    subgraph Execution
        StdinWrap --> Cmd["Command.main()"]
        Cmd --> OutW["sys.stdout<br/>_NamedTextIOWrapper"]
        Cmd --> ErrW["sys.stderr<br/>_NamedTextIOWrapper"]
    end

    subgraph Capture
        OutW --> SMout["StreamMixer.stdout<br/>(BytesIOCopy)"]
        ErrW --> SMerr["StreamMixer.stderr<br/>(BytesIOCopy)"]
        SMout --> SMout2["StreamMixer.output"]
        SMerr --> SMout2
    end

    subgraph Result
        SMout --> RB["Result.stdout_bytes"]
        SMerr --> RB2["Result.stderr_bytes"]
        SMout2 --> RB3["Result.output_bytes"]
    end
```

---

## Component Interaction

```mermaid
classDiagram
    class CliRunner {
        +charset
        +env
        +echo_stdin
        +catch_exceptions
        +get_default_prog_name(cli)
        +make_env(overrides)
        +isolation(input, env, color)
        +invoke(cli, args, input, env, catch_exceptions, color, **extra)
        +isolated_filesystem(temp_dir)
    }
    class Result {
        +runner
        +stdout_bytes
        +stderr_bytes
        +output_bytes
        +return_value
        +exit_code
        +exception
        +exc_info
        +output
        +stdout
        +stderr
    }
    class StreamMixer {
        +output
        +stdout
        +stderr
    }
    class BytesIOCopy {
        +copy_to
        +write(b)
        +flush()
    }
    class EchoingStdin {
        +read(n)
        +readline(n)
        +readlines()
    }
    class _NamedTextIOWrapper {
        +name
        +mode
        +__next__()
    }

    CliRunner ..> Result : creates
    CliRunner ..> StreamMixer : creates
    CliRunner ..> EchoingStdin : creates
    CliRunner ..> _NamedTextIOWrapper : creates
    StreamMixer *-- BytesIOCopy : stdout/stderr
    Result --> CliRunner : references
```

---

## Dependencies

The testing module imports from several sibling modules. Refer to their documentation for details rather than duplicating here.

```mermaid
graph TD
    testing["testing.py"]
    testing --> compat["_compat<br/>(_find_binary_reader)"]
    testing --> formatting["formatting<br/>(FORCED_WIDTH)"]
    testing --> termui["termui<br/>(prompt funcs, _getchar)"]
    testing --> utils["utils<br/>(should_strip_ansi)"]
    testing -.TYPE_CHECKING.-> core["core<br/>(Command)"]
```

| Dependency | Used For | Documentation |
|------------|----------|---------------|
| `_compat` | `_find_binary_reader`, `should_strip_ansi` patching | [platform_and_terminal_foundation](platform_and_terminal_foundation.md) |
| `formatting` | `FORCED_WIDTH` override for deterministic help output | [cli_framework_core](cli_framework_core.md) |
| `termui` | Patching `visible_prompt_func`, `hidden_prompt_func`, `_getchar` | [platform_and_terminal_foundation](platform_and_terminal_foundation.md) |
| `utils` | Patching `should_strip_ansi` | [parameter_types_and_io_utilities](parameter_types_and_io_utilities.md) |
| `core.Command` | Type hint for the command being invoked | [cli_framework_core](cli_framework_core.md) |

---

## Usage Patterns

### Basic invocation

```python
from click.testing import CliRunner

runner = CliRunner()
result = runner.invoke(my_cli, ["--name", "World"])
assert result.exit_code == 0
assert "Hello World" in result.output
```

### Providing stdin input

```python
result = runner.invoke(my_cli, input="yes\n")
```

### Isolating the filesystem

```python
with runner.isolated_filesystem():
    with open("data.txt", "w") as f:
        f.write("content")
    result = runner.invoke(my_cli, ["process", "data.txt"])
```

### Asserting on separate streams

```python
result = runner.invoke(my_cli)
assert "warning" in result.stderr
assert "result" in result.stdout
assert result.output == result.stdout + result.stderr  # order-dependent
```

### Disabling exception catching

```python
runner = CliRunner(catch_exceptions=False)
runner.invoke(my_cli)  # raises instead of recording the exception
```

---

## Version History Highlights

| Version | Change |
|---------|--------|
| 8.2 | Added `catch_exceptions` parameter; removed `mix_stderr`; `output`/`output_bytes` introduced as an independent mixed stream; `stderr` always returned. |
| 8.0 | Added `return_value` to `Result`; added `temp_dir` to `isolated_filesystem`; `<stderr>` opened with `errors="backslashreplace"`. |
| 4.0 | Added `color` parameter to `isolation`/`invoke`. |
| 3.0 | Added `catch_exceptions` and `exc_info`. |

---

## Related Documentation

- [cli_framework_core](cli_framework_core.md) — `Command`, `Context`, and the `formatting` module used for deterministic help output.
- [parameter_types_and_io_utilities](parameter_types_and_io_utilities.md) — `utils.should_strip_ansi` and IO helpers.
- [platform_and_terminal_foundation](platform_and_terminal_foundation.md) — `_compat._find_binary_reader`, `termui` prompt functions, and terminal detection.
- [shell_completion](shell_completion.md) — the sibling tooling module for shell completion.
