# Compat Module (`src/click/_compat.py`)

## Introduction

The `compat` module is Click's **platform and terminal foundation layer**. It provides a
consistent, cross-platform abstraction over the messy realities of Python I/O streams,
text encodings, ANSI color handling, and atomic file writes. Every other part of Click
that needs to read from or write to a stream — help output, error messages, progress
bars, prompts, and file parameters — ultimately relies on the primitives defined here.

The module's responsibilities can be summarized as:

1. **Stream normalization** — turning arbitrary binary/text streams into well-behaved
   text streams with predictable encodings and error handling.
2. **Standard stream access** — providing cached, correctly-configured accessors for
   `stdin`, `stdout`, and `stderr` in both binary and text forms.
3. **ANSI handling** — detecting whether ANSI escape codes should be emitted and
   stripping them when necessary (with Windows/colorama support).
4. **Atomic file writes** — writing files safely via a temporary file and atomic
   rename, used by Click's file parameters.

> **Note:** This module is private (leading underscore). It is an internal
> implementation detail of Click and is not part of the public API.

---

## Architecture Overview

The `compat` module sits at the bottom of Click's dependency stack. It has no
dependencies on other Click modules (except a lazy import of `_winconsole` on Windows),
which makes it the foundation that the rest of the library builds upon.

```mermaid
graph TD
    subgraph "compat module (src/click/_compat.py)"
        A[_FixupStream]
        B[_NonClosingTextIOWrapper]
        C[_AtomicFile]
        D[Stream helpers]
        E[ANSI helpers]
        F[Standard stream accessors]
    end

    subgraph "Platform layer"
        WC[_winconsole.py]
        TU[_termui_impl.py]
        TW[_textwrap.py]
    end

    subgraph "Higher-level Click modules"
        CORE[core.py]
        TYPES[types.py]
        UTILS[utils.py]
        FMT[formatting.py]
        TEST[testing.py]
    end

    B --> A
    F --> B
    F --> WC
    E --> WC
    D --> B
    C --> D

    WC --> A
    TU --> F
    TU --> E
    TW --> E

    CORE --> F
    CORE --> E
    TYPES --> C
    TYPES --> F
    UTILS --> F
    FMT --> E
    TEST --> F
```

### Component Relationships

```mermaid
classDiagram
    class _FixupStream {
        +_stream: BinaryIO
        +_force_readable: bool
        +_force_writable: bool
        +read1(size) bytes
        +readable() bool
        +writable() bool
        +seekable() bool
        +__getattr__(name)
    }

    class _NonClosingTextIOWrapper {
        +_stream: BinaryIO
        +__del__()
        +isatty() bool
    }

    class _AtomicFile {
        +_f: IO
        +_tmp_filename: str
        +_real_filename: str
        +closed: bool
        +name: str
        +close(delete)
        +__enter__()
        +__exit__(exc_type, exc_value, tb)
        +__getattr__(name)
    }

    _NonClosingTextIOWrapper --> _FixupStream : wraps
    _AtomicFile --> _NonClosingTextIOWrapper : may wrap
```

---

## Core Components

### `_FixupStream`

A transparent proxy that adapts legacy or poorly-behaved binary streams to the modern
`io` interface. Many objects placed on `sys.stdin`/`sys.stdout` (notably in certain
Jupyter notebook versions) do not fully implement the `io.RawIOBase` protocol. This
class fills the gaps.

| Method | Behavior |
| --- | --- |
| `__getattr__` | Delegates all unknown attributes to the wrapped stream. |
| `read1(size)` | Uses the underlying `read1` if present, otherwise falls back to `read`. |
| `readable()` | Returns `True` if forced; otherwise probes the stream (via `readable()` or a `read(0)` call). |
| `writable()` | Returns `True` if forced; otherwise probes the stream (via `writable()` or a `write(b"")` call). |
| `seekable()` | Probes the stream via `seekable()` or a `seek(tell())` round-trip. |

The `force_readable` / `force_writable` flags exist specifically to work around tools
that place badly-patched objects on `sys` (e.g. some Jupyter notebook versions).

### `_NonClosingTextIOWrapper`

A subclass of `io.TextIOWrapper` that:

- Wraps the incoming binary stream in a `_FixupStream` before delegating to the parent
  constructor, ensuring the stream satisfies the `io` protocol.
- **Does not close the underlying stream** when garbage collected — `__del__` calls
  `detach()` instead of `close()`. This is critical because Click frequently wraps
  `sys.stdout`/`sys.stderr`, which must remain open for the lifetime of the process.
- Overrides `isatty()` to query the *original* stream (working around a
  [PyPy issue](https://bitbucket.org/pypy/pypy/issue/1803)).

### `_AtomicFile`

A file-like wrapper that implements **atomic writes**. When a file is opened in atomic
mode, Click writes to a temporary file in the same directory and then atomically
`os.replace`s it over the target on close. This guarantees that readers never observe a
partially-written file.

| Member | Description |
| --- | --- |
| `name` | Returns the *real* (target) filename, not the temp filename. |
| `close(delete=False)` | Closes the temp file and atomically replaces the target. |
| `__enter__` / `__exit__` | Context-manager support; on exception the temp file is discarded. |
| `__getattr__` | Delegates all other attributes to the wrapped file object. |

---

## Stream Normalization Pipeline

The heart of the module is a pipeline that converts *any* stream into a correctly
configured text stream. This is what allows Click to behave consistently regardless of
the host environment's default encoding.

```mermaid
flowchart TD
    Start([Input stream]) --> IsBinary{Is it a binary<br/>reader/writer?}
    IsBinary -->|Yes| UseBinary[Use as binary stream]
    IsBinary -->|No| Compatible{Compatible encoding<br/>& errors?}
    Compatible -->|Yes, and not<br/>misconfigured ASCII| ReturnAsIs[Return stream as-is]
    Compatible -->|No| FindBinary[Find underlying<br/>binary stream]
    FindBinary --> Found{Found?}
    Found -->|No| ReturnAsIs
    Found -->|Yes| UseBinary
    UseBinary --> MakeText[_make_text_stream]
    MakeText --> Wrap[_NonClosingTextIOWrapper]
    Wrap --> End([Correct text stream])
```

### Key helper functions

| Function | Purpose |
| --- | --- |
| `_make_text_stream` | Wraps a binary stream in a `_NonClosingTextIOWrapper` with line buffering. |
| `is_ascii_encoding` | Checks whether an encoding resolves to ASCII. |
| `get_best_encoding` | Returns the stream's encoding, upgrading ASCII to UTF-8. |
| `_is_binary_reader` / `_is_binary_writer` | Probe whether a stream is binary. |
| `_find_binary_reader` / `_find_binary_writer` | Locate the underlying binary stream (handling detached streams and `.buffer`). |
| `_stream_is_misconfigured` | Detects streams defaulting to ASCII (common in unittest environments). |
| `_is_compatible_text_stream` | Checks whether a stream's `encoding`/`errors` match the desired values. |
| `_force_correct_text_stream` | The central dispatcher implementing the flowchart above. |
| `_force_correct_text_reader` / `_force_correct_text_writer` | Reader/writer specializations. |

---

## Standard Stream Accessors

Click exposes a uniform set of accessors for the standard streams. These are the
functions that higher-level modules call.

### Binary accessors

- `get_binary_stdin()`
- `get_binary_stdout()`
- `get_binary_stderr()`

Each raises `RuntimeError` if a binary stream cannot be determined.

### Text accessors

- `get_text_stdin(encoding=None, errors=None)`
- `get_text_stdout(encoding=None, errors=None)`
- `get_text_stderr(encoding=None, errors=None)`

On Windows these first attempt to obtain a Windows console stream (see
[winconsole](winconsole.md)); otherwise they fall back to the normalization pipeline.

### Cached default accessors

Because wrapping streams is relatively expensive and the result should be stable, Click
provides cached variants built via `_make_cached_stream_func`:

- `_default_text_stdin`
- `_default_text_stdout`
- `_default_text_stderr`

These use a `WeakKeyDictionary` keyed on the original stream, so the wrapper is reused
as long as the underlying stream is alive.

### Stream registries

Two mappings expose the accessors by name, used by Click's `echo`/`get_text_stream`
machinery:

```python
binary_streams = {"stdin": get_binary_stdin, "stdout": get_binary_stdout, "stderr": get_binary_stderr}
text_streams   = {"stdin": get_text_stdin,   "stdout": get_text_stdout,   "stderr": get_text_stderr}
```

---

## ANSI Color Handling

Click needs to decide whether to emit ANSI escape sequences (colors/styles) and to
measure the *visible* width of strings that may contain them.

| Function | Purpose |
| --- | --- |
| `strip_ansi(value)` | Removes ANSI escape sequences using the `_ansi_re` regex. |
| `term_len(x)` | Returns the visible length of a string (length after stripping ANSI). |
| `should_strip_ansi(stream, color)` | Decides whether ANSI codes should be stripped based on TTY status, Jupyter detection, and the explicit `color` flag. |
| `isatty(stream)` | Safe `isatty()` that returns `False` on any exception. |
| `_is_jupyter_kernel_output(stream)` | Detects ipykernel output streams (which should not receive ANSI codes). |
| `auto_wrap_for_ansi(stream, color)` | **Windows only** — wraps a stream with colorama's `AnsiToWin32` to translate ANSI codes into Win32 console calls. |

### ANSI decision flow

```mermaid
flowchart TD
    A[should_strip_ansi] --> B{color explicitly set?}
    B -->|Yes| C[Return not color]
    B -->|No| D{stream is a TTY?}
    D -->|No| E{Is Jupyter kernel output?}
    D -->|Yes| F[Do not strip]
    E -->|Yes| F
    E -->|No| G[Strip ANSI]
```

On Windows, `auto_wrap_for_ansi` caches wrappers in a `WeakKeyDictionary` and installs a
`_safe_write` shim that resets colorama state if a write fails.

---

## Atomic File Writes

The `open_stream` function is the public entry point for opening files, and it supports
an `atomic` flag used by Click's `File` parameter type (see [types](types.md)).

```mermaid
flowchart TD
    A[open_stream] --> B{filename == '-'?}
    B -->|Yes| C[Return std stream]
    B -->|No| D{atomic?}
    D -->|No| E[_wrap_io_open]
    D -->|Yes| F{Mode valid?}
    F -->|'a' in mode| G[ValueError: no append]
    F -->|'x' in mode| H[ValueError: use overwrite]
    F -->|'w' not in mode| I[ValueError: need w-mode]
    F -->|valid| J[Create temp file<br/>in same dir]
    J --> K[Wrap in _AtomicFile]
    K --> L[Return _AtomicFile, True]
```

Key behaviors:

- `"-"` is treated as a standard stream (stdin for reads, stdout for writes).
- Atomic writes reject `a` (append) and `x` (exclusive) modes and require `w` mode.
- The temporary file is created with `O_EXCL` and retried on collision, preserving the
  original file's permissions.
- `_wrap_io_open` avoids passing `encoding`/`errors` when the mode is binary.

---

## Platform-Specific Behavior

The module branches on `sys.platform` at import time:

| Constant / Branch | Meaning |
| --- | --- |
| `CYGWIN` | `sys.platform` starts with `"cygwin"`. |
| `WIN` | `sys.platform` starts with `"win"`. |
| `_get_argv_encoding()` | Windows: uses `locale.getpreferredencoding()`; otherwise the stdin encoding or filesystem encoding. |
| `_get_windows_console_stream()` | Windows: delegates to [winconsole](winconsole.md); otherwise returns `None`. |
| `auto_wrap_for_ansi` | Windows: real colorama wrapper; otherwise `None`. |

---

## Data Flow: From `sys.stdout` to a Rendered Line

The following sequence shows how a higher-level module (e.g. `formatting.py` or
`_termui_impl.py`) obtains a usable output stream.

```mermaid
sequenceDiagram
    participant Caller as Higher-level module
    participant Compat as _compat
    participant Win as _winconsole (Windows)
    participant Wrapper as _NonClosingTextIOWrapper

    Caller->>Compat: get_text_stdout(encoding, errors)
    Compat->>Win: _get_windows_console_stream(sys.stdout, ...)
    alt Windows console available
        Win-->>Compat: ConsoleStream
        Compat-->>Caller: ConsoleStream
    else Fallback
        Compat->>Compat: _force_correct_text_writer(sys.stdout, ...)
        Compat->>Wrapper: _make_text_stream(binary, encoding, errors)
        Wrapper-->>Compat: text stream
        Compat-->>Caller: text stream
    end
```

---

## Integration with Other Modules

| Module | How it uses `compat` |
| --- | --- |
| [core](core.md) | Uses `_default_text_stdout`/`_default_text_stderr` for `echo`, and `should_strip_ansi`/`strip_ansi` for color decisions. |
| [types](types.md) | Uses `open_stream` (with `atomic`) for the `File` and `Path` parameter types. |
| [utils](utils.md) | Uses text stream accessors and `_NonClosingTextIOWrapper` for `LazyFile`/`KeepOpenFile`. |
| [formatting](formatting.md) | Uses `term_len`/`strip_ansi` to compute visible widths for help text wrapping. |
| [testing](testing.md) | Uses stream accessors and `_NonClosingTextIOWrapper` to build `CliRunner`'s captured streams. |
| [winconsole](winconsole.md) | Provides `_get_windows_console_stream` and `ConsoleStream` on Windows. |
| [termui_impl](termui_impl.md) | Uses `_default_text_stdout`, `isatty`, and `term_len` for `ProgressBar` and `Editor`. |
| [textwrap](textwrap.md) | Relies on `term_len`/`strip_ansi` indirectly for width-aware wrapping. |

---

## Summary

The `compat` module is the invisible workhorse of Click. By centralizing the thorny
details of stream normalization, encoding detection, ANSI handling, and atomic file
writes, it lets the rest of the library assume a clean, consistent I/O environment. Its
three core classes — `_FixupStream`, `_NonClosingTextIOWrapper`, and `_AtomicFile` —
each solve a specific, well-defined problem, while the surrounding helper functions
compose them into a robust cross-platform I/O layer.
