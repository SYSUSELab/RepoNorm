# `cli_framework_core` Module Overview

## Purpose

The `cli_framework_core` module is the heart of the Click command-line framework. It provides the fundamental building blocks for defining, parsing, and executing command-line interfaces: commands, groups, parameters, contexts, and the invocation pipeline. It also handles user-facing error reporting and help-text formatting.

This module is responsible for:

- Defining the command/group object model (`Command`, `Group`, `MultiCommand`, `Context`).
- Declaring and processing parameters (`Parameter`, `Option`, `Argument`).
- Parsing raw command-line tokens into structured parameters (via the `parser` submodule).
- Raising and rendering user-facing errors (via the `exceptions` submodule).
- Producing formatted help and usage text (via the `formatting` submodule).

## Architecture

The core module is composed of four tightly coupled submodules. `core.py` is the central orchestrator; it depends on `parser.py` for token parsing, on `exceptions.py` for error signaling, and on `formatting.py` for help/usage rendering.

```mermaid
graph TD
    subgraph cli_framework_core
        CORE["core.py<br/>Command, Group, Context,<br/>Parameter, Option, Argument"]
        PARSER["parser.py<br/>OptionParser, Argument,<br/>ParsingState"]
        EXC["exceptions.py<br/>ClickException, UsageError,<br/>BadParameter, Abort"]
        FMT["formatting.py<br/>HelpFormatter,<br/>wrap_text, join_options"]
    end

    CORE -->|"uses to tokenize argv"| PARSER
    CORE -->|"raises / catches"| EXC
    CORE -->|"renders help & usage"| FMT
    PARSER -->|"raises on bad input"| EXC
    FMT -->|"may raise formatting errors"| EXC

    CORE -.->|"invokes callbacks"| USER["User command callbacks"]
    EXC -.->|"prints to stderr"| IO["stdout / stderr"]
    FMT -.->|"writes help text"| IO
```

### Execution flow (high level)

```mermaid
sequenceDiagram
    participant User
    participant Command as Command/Group (core)
    participant Parser as OptionParser (parser)
    participant Ctx as Context (core)
    participant Fmt as HelpFormatter (formatting)
    participant Exc as Exceptions

    User->>Command: main(args)
    Command->>Ctx: make_context(args)
    Ctx->>Parser: parse_args(args)
    Parser-->>Ctx: opts, args, order
    alt parsing error
        Parser->>Exc: raise UsageError / BadParameter
        Exc-->>User: print error + usage
    else success
        Ctx->>Command: invoke(ctx)
        Command->>Fmt: format_help() (if --help)
        Fmt-->>User: help text
        Command->>User: run callback
    end
```

## Core Components

The module is documented across four child pages:

- **[core.md](docs/core.md)** — The central object model: `Command`, `Group`/`MultiCommand`, `Context`, `Parameter`, `Option`, `Argument`, and the invocation pipeline (`main`, `make_context`, `invoke`, `parse_args`).
- **[parser.md](docs/parser.md)** — Low-level command-line token parsing: `OptionParser`, `Argument`, `ParsingState`, and the option/argument matching logic.
- **[exceptions.md](docs/exceptions.md)** — The exception hierarchy used for user-facing errors: `ClickException`, `UsageError`, `BadParameter`, `MissingParameter`, `Abort`, and their formatting/exit-code behavior.
- **[formatting.md](docs/formatting.md)** — Help and usage text generation: `HelpFormatter`, `wrap_text`, `join_options`, and related layout utilities.

Together these four submodules form the complete CLI framework core: `core.py` defines *what* a CLI is, `parser.py` defines *how* input is interpreted, `exceptions.py` defines *how* failures are reported, and `formatting.py` defines *how* help is presented.