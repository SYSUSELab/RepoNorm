# Parser Module

## Introduction

The `parser` module (`src/click/parser.py`) is the low-level command-line token
processing engine of Click. It is responsible for taking a raw list of command-line
tokens (e.g. `["--verbose", "-n", "3", "input.txt"]`) and turning them into a
structured mapping of option values, positional argument values, and an ordered
record of which parameters were encountered.

The module is a heavily simplified derivative of the standard library's `optparse`
module. Click deliberately re-implements this logic rather than reusing `optparse`
directly because:

- Error message differences between Python 2.x and 3.x needed to be controlled.
- `optparse` uses `gettext` internally, which caused unwanted side effects.
- Click implements higher-level concerns (type handling, help formatting, defaults,
  prompting, environment variables) in the [core module](core.md), so the parser only
  needs to handle raw tokenization and dispatch.

> **Deprecation note:** As of Click 8.2, the public-facing names in this module
> (`OptionParser`, `Argument`, `Option`, `ParsingState`, `split_opt`, `normalize_opt`)
> are deprecated and will be removed in Click 9.0. The internal underscore-prefixed
> classes remain the active implementation used by the [core module](core.md).

---

## Architecture Overview

The parser module sits between the raw command-line input and the high-level
parameter objects defined in the [core module](core.md). It has no knowledge of
types, defaults, or help text — those are handled by `Parameter` subclasses
(`Option`, `Argument`) which *register themselves* with the parser.

```mermaid
graph TD
    subgraph "core module"
        CMD[Command]
        CTX[Context]
        OPT[Option]
        ARG[Argument]
        PARAM[Parameter]
    end

    subgraph "parser module"
        OP[_OptionParser]
        O[_Option]
        A[_Argument]
        PS[_ParsingState]
    end

    subgraph "exceptions module"
        NSO[NoSuchOption]
        BOU[BadOptionUsage]
        BAU[BadArgumentUsage]
        UE[UsageError]
    end

    CMD -->|creates| OP
    CTX -->|configures| OP
    OPT -->|add_to_parser| OP
    ARG -->|add_to_parser| OP
    OP -->|creates| O
    OP -->|creates| A
    OP -->|creates| PS
    O -->|process| PS
    A -->|process| PS
    OP -.->|raises| NSO
    OP -.->|raises| BOU
    A -.->|raises| BAU
    NSO --> UE
    BOU --> UE
    BAU --> UE
```

### Key Design Principles

1. **Separation of concerns** — The parser only understands *tokens*, not *semantics*.
   It does not cast types, apply defaults, or read environment variables.
2. **Registration-based** — Parameters register themselves via `add_option` /
   `add_argument`, passing a back-reference (`obj`) to the high-level parameter.
3. **Order preservation** — The parser records the order in which parameters appear
   on the command line, enabling features like `ParameterSource` tracking.
4. **Resilient parsing** — When `Context.resilient_parsing` is enabled (used for shell
   completion), usage errors are swallowed rather than raised.

---

## Core Components

### `_OptionParser`

The central orchestrator. It maintains registries of known short options, long
options, and positional arguments, then drives the token-processing loop.

| Attribute | Purpose |
|-----------|---------|
| `ctx` | Optional [`Context`](core.md) providing configuration. |
| `allow_interspersed_args` | If `False`, parsing stops at the first non-option token. |
| `ignore_unknown_options` | If `True`, unknown options are collected rather than erroring. |
| `_short_opt` | Map of short option strings → `_Option`. |
| `_long_opt` | Map of long option strings → `_Option`. |
| `_opt_prefixes` | Set of valid option prefixes (e.g. `{"-", "--"}`). |
| `_args` | Ordered list of registered `_Argument` objects. |

**Public methods:**

- `add_option(obj, opts, dest, action, nargs, const)` — Registers an option.
- `add_argument(obj, dest, nargs)` — Registers a positional argument.
- `parse_args(args)` — Returns `(values, leftover_args, order)`.

**Internal methods:**

- `_process_args_for_options(state)` — Scans tokens, dispatching options.
- `_process_args_for_args(state)` — Unpacks positional arguments.
- `_match_long_opt(opt, explicit_value, state)` — Handles `--long` options.
- `_match_short_opt(arg, state)` — Handles clustered `-abc` short options.
- `_get_value_from_state(option_name, option, state)` — Consumes option values.
- `_process_opts(arg, state)` — Entry point for a single option token.

### `_Option`

Represents a single registered option. It knows its short/long spellings, the
destination key, the action to perform, and the number of values it consumes.

**Supported actions:**

| Action | Behavior |
|--------|----------|
| `store` | Store the value at `dest`. |
| `store_const` | Store the fixed `const` value. |
| `append` | Append the value to a list at `dest`. |
| `append_const` | Append the fixed `const` value to a list. |
| `count` | Increment an integer counter at `dest`. |

The `takes_value` property returns `True` for `store` and `append` actions.

### `_Argument`

Represents a positional argument. It supports `nargs` values including `-1`
(consume all remaining tokens). It validates that the correct number of values
was supplied, raising `BadArgumentUsage` on mismatch.

### `_ParsingState`

A mutable container holding the in-progress parse results:

| Attribute | Purpose |
|-----------|---------|
| `opts` | Dict mapping destination names → parsed values. |
| `largs` | Left arguments (positional tokens collected so far). |
| `rargs` | Right arguments (tokens not yet processed). |
| `order` | Ordered list of `Parameter` objects as encountered. |

---

## Parsing Flow

The following diagram shows how a raw argument list flows through the parser.

```mermaid
flowchart TD
    START([parse_args args]) --> INIT[Create _ParsingState]
    INIT --> OPTS[_process_args_for_options]
    OPTS --> LOOP{rargs empty?}
    LOOP -->|No| POP[Pop first token]
    POP --> DASH{token == '--'?}
    DASH -->|Yes| DONE_OPTS[Stop option processing]
    DASH -->|No| PREFIX{starts with opt prefix?}
    PREFIX -->|Yes| PROC[_process_opts]
    PREFIX -->|No| INTERSECT{allow_interspersed_args?}
    INTERSECT -->|Yes| APPEND[Append to largs]
    INTERSECT -->|No| PUSH[Push back & stop]
    APPEND --> LOOP
    PROC --> LOOP
    DONE_OPTS --> ARGS[_process_args_for_args]
    PUSH --> ARGS
    ARGS --> UNPACK[_unpack_args]
    UNPACK --> ASSIGN[Assign values to _Argument objects]
    ASSIGN --> RESULT([Return opts, largs, order])
```

### Option Matching Detail

When a token begins with an option prefix, `_process_opts` first attempts a **long
option match**. If that fails with `NoSuchOption`, it falls back to **short option
matching** — unless the token used a two-character prefix (e.g. `--foo`), in which
case the error is re-raised.

```mermaid
flowchart TD
    TOKEN[Option token] --> SPLIT{contains '='?}
    SPLIT -->|Yes| SPLITV[Split into opt + explicit value]
    SPLIT -->|No| NOSPLIT[opt = token]
    SPLITV --> NORM[Normalize opt]
    NOSPLIT --> NORM
    NORM --> LONG[_match_long_opt]
    LONG --> FOUND{found?}
    FOUND -->|Yes| TAKES{takes_value?}
    TAKES -->|Yes| GETVAL[_get_value_from_state]
    TAKES -->|No| CONST[value = None]
    GETVAL --> PROCESS[option.process]
    CONST --> PROCESS
    FOUND -->|No| TWOPREFIX{two-char prefix?}
    TWOPREFIX -->|Yes| RAISE[Re-raise NoSuchOption]
    TWOPREFIX -->|No| SHORT[_match_short_opt]
    SHORT --> PROCESS
```

### Short Option Clustering

Short options can be clustered (e.g. `-abc`). The parser iterates character by
character. If an option takes a value, the remaining characters are treated as the
value (e.g. `-n5` → `-n` with value `5`). Unknown characters are either collected
(when `ignore_unknown_options` is set) or raise `NoSuchOption`.

---

## Value Consumption and the Flag Sentinel

A key subtlety is the `_flag_needs_value` sentinel. When an option is configured
with `prompt` but `prompt_required=False` (see [`Option`](core.md)), it may be
supplied as a bare flag. In that case the parser emits `_flag_needs_value` instead
of a real value, signalling to the higher-level `Option.consume_value` that it
should either prompt the user or fall back to `flag_value`.

```mermaid
sequenceDiagram
    participant Parser as _OptionParser
    participant Opt as _Option
    participant State as _ParsingState
    participant Core as Option.consume_value

    Parser->>Opt: _get_value_from_state
    Opt-->>Parser: _flag_needs_value (sentinel)
    Parser->>Opt: process(sentinel, state)
    Opt->>State: opts[dest] = sentinel
    Note over Core: Later, during value processing
    Core->>Core: detect sentinel
    Core->>Core: prompt or use flag_value
```

---

## Dependencies

```mermaid
graph LR
    subgraph "parser.py"
        P[_OptionParser]
    end
    P -->|imports| EXC[exceptions module]
    P -->|type hints| CORE[core module]
    P -->|deprecated re-export| SC[shell_completion module]

    EXC --> NSO[NoSuchOption]
    EXC --> BOU[BadOptionUsage]
    EXC --> BAU[BadArgumentUsage]
    EXC --> UE[UsageError]
```

### Inbound Dependencies

- **[core module](core.md)** — `Command` creates an `_OptionParser` and populates it
  by calling `add_to_parser` on each `Parameter`. `Context` supplies configuration
  (`allow_interspersed_args`, `ignore_unknown_options`, `token_normalize_func`,
  `resilient_parsing`).
- **[exceptions module](exceptions.md)** — The parser raises `NoSuchOption`,
  `BadOptionUsage`, and `BadArgumentUsage`, all subclasses of `UsageError`.

### Outbound Dependencies

- **[shell_completion module](shell_completion.md)** — The deprecated
  `split_arg_string` name is re-exported from `shell_completion` via the module-level
  `__getattr__`.

---

## Error Handling

The parser raises errors from the [exceptions module](exceptions.md):

| Error | Trigger |
|-------|---------|
| `NoSuchOption` | An unknown option is encountered (with fuzzy-match suggestions). |
| `BadOptionUsage` | An option that takes no value is given one, or too few values are supplied. |
| `BadArgumentUsage` | A positional argument receives the wrong number of values. |

When `Context.resilient_parsing` is `True`, `parse_args` catches `UsageError` and
returns whatever partial state was accumulated. This is essential for shell
completion, where incomplete command lines must not crash.

---

## Token Normalization

The `_normalize_opt` helper applies `Context.token_normalize_func` to option names,
enabling case-insensitive or otherwise normalized matching. The `_split_opt` helper
separates an option's prefix from its body (e.g. `--foo` → `("--", "foo")`).

---

## Relationship to Other Modules

| Module | Relationship |
|--------|--------------|
| [core module](core.md) | Consumes the parser; `Option`/`Argument` register with it and interpret its output. |
| [exceptions module](exceptions.md) | Provides the error types the parser raises. |
| [shell_completion module](shell_completion.md) | Source of the deprecated `split_arg_string` re-export. |
| [parameter_types_and_io_utilities](parameter_types_and_io_utilities.md) | Type casting happens *after* parsing, in the core layer. |

---

## Summary

The parser module is a focused, dependency-light tokenizer that bridges raw
command-line input and Click's high-level parameter system. By keeping type
handling, defaults, and formatting out of scope, it remains small and predictable,
while the [core module](core.md) layers rich behavior on top of its structured
output.
