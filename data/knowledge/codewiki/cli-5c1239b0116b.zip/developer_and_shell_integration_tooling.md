# Developer and Shell Integration Tooling

## Purpose

The `developer_and_shell_integration_tooling` module provides the auxiliary tooling that makes Click-based command-line applications pleasant to develop, test, and use interactively. It bundles two complementary concerns:

- **Shell completion** (`shell_completion.py`): Generates and serves completion scripts so that users can tab-complete commands, options, and parameter values in their shell (Bash, Zsh, Fish). It also exposes the machinery for custom completion callbacks and completion item metadata.
- **Testing utilities** (`testing.py`): Offers a `CliRunner` and related helpers that let developers invoke CLI commands in-process, capture output, feed stdin, and assert on exit codes and results without spawning subprocesses.

Together these components bridge the gap between the core CLI framework and the external environments (shells and test suites) in which Click applications are exercised.

## Architecture

The module sits on top of the core CLI framework and the parameter/IO utilities, and it is consumed by both end users (via shell completion) and developers (via testing).

```mermaid
graph TD
    subgraph "developer_and_shell_integration_tooling"
        SC[shell_completion.py]
        TST[testing.py]
    end

    subgraph "cli_framework_core"
        CORE[core.py]
        PARSER[parser.py]
        EXC[exceptions.py]
        FMT[formatting.py]
    end

    subgraph "parameter_types_and_io_utilities"
        TYPES[types.py]
        UTILS[utils.py]
    end

    subgraph "platform_and_terminal_foundation"
        COMPAT[_compat.py]
        WINCON[_winconsole.py]
        TERMUI[_termui_impl.py]
        WRAP[_textwrap.py]
    end

    SC --> CORE
    SC --> PARSER
    SC --> TYPES
    SC --> UTILS
    SC --> COMPAT

    TST --> CORE
    TST --> UTILS
    TST --> COMPAT
    TST --> TERMUI

    CORE --> PARSER
    CORE --> EXC
    CORE --> FMT
    CORE --> TYPES
    CORE --> UTILS
    UTILS --> COMPAT
    TERMUI --> COMPAT
    WINCON --> COMPAT
```

At a high level:

- `shell_completion.py` inspects `Command`, `Option`, and `Argument` objects from the core framework, resolves parameter types from `types.py`, and emits shell-specific completion scripts. It relies on `_compat.py` for cross-platform behavior.
- `testing.py` drives `Command`/`Context` execution directly, using `utils.py` for stream handling and `_compat.py`/`_termui_impl.py` to emulate terminal behavior (e.g., echo, prompts, and pager interactions) inside a controlled test harness.

## Core Components

- [Shell Completion](./shell_completion.md) — completion script generation, the `shell_complete` protocol, and completion item types.
- [Testing](./testing.md) — the `CliRunner`, `Result` object, and in-process invocation helpers for asserting CLI behavior.