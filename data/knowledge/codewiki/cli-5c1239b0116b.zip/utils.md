# Utils Module

## Introduction

The `utils` module (`src/click/utils.py`) provides the low-level I/O and
environment utilities that the rest of Click is built on. It is the bridge
between Click's high-level abstractions (commands, parameters, and the
`echo`-based output model) and the platform-specific stream handling
implemented in the [compat module](compat.md).

Its responsibilities fall into four broad areas:

1. **Safe file handling** — `LazyFile`, `KeepOpenFile`, and `open_file`
   provide deferred, atomic, and standard-stream-aware file opening.
2. **Output and streams** — `echo`, `get_binary_stream`, and
   `get_text_stream` provide the canonical way to write output and obtain
   system streams, with correct encoding, ANSI, and Windows console
   handling.
3. **Display helpers** — `format_filename`, `make_str`,
   `make_default_short_help`, and `get_app_dir` format values for display
   and locate platform-appropriate config directories.
4. **Internal helpers** — `safecall`, `_detect_program_name`,
   `_expand_args`, and `PacifyFlushWrapper` support the framework's
   internals (help text, argument expansion, and clean interpreter
   shutdown).

The module is consumed by nearly every other part of Click, most notably
the [core module](core.md) (for `echo` and file parameters), the
[types module](types.md) (for the `File` and `Path` parameter types), and
the [testing module](testing.md) (for stream capture).

## Architecture

The `utils` module sits between Click's public API and the platform
compatibility layer. It does not implement platform detection itself;
instead it delegates to `_compat` and `globals`.

```mermaid
graph TD
    subgraph "Public / High-level"
        CORE["core.py<br/>(Command, Context, echo usage)"]
        TYPES["types.py<br/>(File, Path param types)"]
        TESTING["testing.py<br/>(CliRunner capture)"]
    end

    subgraph "utils.py (this module)"
        ECHO["echo()"]
        STREAMS["get_binary_stream()<br/>get_text_stream()"]
        OPEN["open_file()<br/>LazyFile<br/>KeepOpenFile"]
        FMT["format_filename()<br/>make_str()<br/>make_default_short_help()"]
        APP["get_app_dir()"]
        INTERNAL["safecall()<br/>_detect_program_name()<br/>_expand_args()<br/>PacifyFlushWrapper"]
    end

    subgraph "Foundation"
        COMPAT["_compat.py<br/>(open_stream, streams, ANSI)"]
        GLOBALS["globals.py<br/>(resolve_color_default)"]
        EXC["exceptions.py<br/>(FileError)"]
    end

    CORE --> ECHO
    CORE --> OPEN
    TYPES --> OPEN
    TESTING --> STREAMS
    ECHO --> COMPAT
    ECHO --> GLOBALS
    STREAMS --> COMPAT
    OPEN --> COMPAT
    OPEN --> EXC
    FMT --> COMPAT
    APP --> COMPAT
```

## Core Components

### `LazyFile`

A file-like wrapper that defers the actual opening of a file until it is
first accessed, while still performing early validation so that obvious
errors (e.g. a bad path) surface as soon as possible.

| Attribute / Method | Purpose |
| --- | --- |
| `__init__(filename, mode, encoding, errors, atomic)` | Stores configuration. For `-` it opens the standard stream immediately; for read modes it opens and closes the file once to catch access errors early. |
| `open()` | Opens the file on first use, raising `FileError` (from [exceptions](exceptions.md)) on `OSError`. |
| `close()` | Closes the underlying file unconditionally. |
| `close_intelligently()` | Closes only if the wrapper opened the file (never closes `stdin`/`stdout`). |
| `__getattr__` | Proxies all other attribute access to the opened file. |
| `__enter__` / `__exit__` | Context-manager support; `__exit__` calls `close_intelligently()`. |
| `__iter__` | Opens the file and iterates over its lines. |

The `atomic` flag is forwarded to `open_stream`, enabling write-to-temp
then rename semantics.

### `KeepOpenFile`

A thin proxy that prevents a wrapped file from being closed when used as a
context manager. This is essential for standard streams: `open_file("-")`
returns a `KeepOpenFile` so that `with open_file("-") as f:` does not close
`stdout`/`stdin` on exit.

- `__getattr__` proxies all attribute access to the wrapped file.
- `__enter__` returns `self`; `__exit__` is a no-op.
- `__iter__` delegates to the wrapped file.

### `PacifyFlushWrapper`

Wraps a stream to suppress `BrokenPipeError` (`errno.EPIPE`) raised during
`flush()`. Python always flushes `sys.stdout`/`sys.stderr` at interpreter
shutdown, and a broken pipe at that point would otherwise produce a noisy
traceback. All other attributes are proxied to the wrapped stream, and any
non-`EPIPE` `OSError` is re-raised.

## Key Functions

### Output and Streams

```mermaid
flowchart TD
    A["echo(message, file, nl, err, color)"] --> B{file given?}
    B -- no --> C["_default_text_stdout()<br/>or _default_text_stderr()"]
    B -- yes --> D[use file]
    C --> E{file is None?}
    E -- yes --> F[return silently]
    E -- no --> G[coerce message to str/bytes]
    D --> G
    G --> H{nl?}
    H -- yes --> I[append newline]
    H -- no --> J[skip]
    I --> K{bytes output?}
    J --> K
    K -- yes --> L["_find_binary_writer()<br/>write bytes"]
    K -- no --> M["resolve_color_default()"]
    M --> N{"should_strip_ansi()?"}
    N -- yes --> O[strip ANSI codes]
    N -- no --> P{"WIN?"}
    P -- yes --> Q["auto_wrap_for_ansi()"]
    P -- no --> R[write as-is]
    O --> S[write + flush]
    Q --> S
    R --> S
    L --> S
```

- **`echo(message, file, nl, err, color)`** — The canonical output
  function, used instead of `print`. It ensures correct encoding on Linux,
  Unicode support on the Windows console, binary/text output support, ANSI
  color handling, and always flushes. Color resolution is delegated to
  `resolve_color_default` in [globals](globals.md), and ANSI stripping /
  wrapping to the [compat module](compat.md).
- **`get_binary_stream(name)`** — Returns a `BinaryIO` for `stdin`,
  `stdout`, or `stderr` via `binary_streams` from `_compat`.
- **`get_text_stream(name, encoding, errors)`** — Returns a `TextIO` via
  `text_streams` from `_compat`, with optional encoding/error overrides.

### File Handling

- **`open_file(filename, mode, encoding, errors, lazy, atomic)`** — The
  unified file-opening entry point. Handles `-` (standard streams), lazy
  opening (`LazyFile`), and atomic writes. When the stream should not be
  closed (standard streams), it wraps the result in `KeepOpenFile`. This
  function backs the `File` parameter type in [types](types.md).

### Display and Formatting

- **`format_filename(filename, shorten)`** — Formats a filename for UI
  display, replacing invalid bytes or surrogate escapes with the
  replacement character `�`. Optionally shortens to the basename.
- **`make_str(value)`** — Converts any value to a valid string, decoding
  bytes using the filesystem encoding with a UTF-8 fallback.
- **`make_default_short_help(help, max_length)`** — Produces a condensed
  one-line summary of a help string for command listings, respecting
  sentence boundaries and the `\b` no-rewrap marker.
- **`get_app_dir(app_name, roaming, force_posix)`** — Returns the
  platform-appropriate configuration directory (macOS, Unix/XDG, or
  Windows roaming/local).

### Internal Helpers

- **`safecall(func)`** — Wraps a function so that any exception is
  swallowed and `None` is returned. Used for best-effort operations.
- **`_detect_program_name(path, _main)`** — Determines the command used to
  run the program (file name or `python -m module`) for help text.
- **`_expand_args(args, user, env, glob_recursive)`** — Simulates Unix
  shell expansion (user home, environment variables, globbing) for use on
  Windows.
- **`_posixify(name)`** — Converts a name to a lowercase, hyphenated POSIX
  form.

## Data Flow: Opening a File

The following sequence shows how `open_file` coordinates the lazy and
standard-stream behaviors with the compatibility layer.

```mermaid
sequenceDiagram
    participant Caller
    participant open_file
    participant LazyFile
    participant open_stream
    participant KeepOpenFile

    Caller->>open_file: open_file(filename, mode, lazy, atomic)
    alt lazy=True
        open_file->>LazyFile: construct
        LazyFile-->>Caller: LazyFile instance
        Note over LazyFile: file opened on first access
    else lazy=False
        open_file->>open_stream: open_stream(filename, mode, ...)
        open_stream-->>open_file: (f, should_close)
        alt should_close=False (std stream)
            open_file->>KeepOpenFile: wrap f
            KeepOpenFile-->>Caller: KeepOpenFile instance
        else should_close=True
            open_file-->>Caller: f
        end
    end
```

## Dependencies

| Dependency | Used For |
| --- | --- |
| [`_compat`](compat.md) | `open_stream`, default text streams, binary writer detection, ANSI wrapping/stripping, `WIN` flag, stream registries |
| [`globals`](globals.md) | `resolve_color_default` for `echo` color resolution |
| [`exceptions`](exceptions.md) | `FileError` raised by `LazyFile.open()` |

## Consumers

| Consumer | Usage |
| --- | --- |
| [`core`](core.md) | `echo` for output; `open_file`/`LazyFile` for file parameters; `_detect_program_name` and `make_default_short_help` for help text |
| [`types`](types.md) | `open_file` and `LazyFile` back the `File` and `Path` parameter types |
| [`testing`](testing.md) | `get_binary_stream`/`get_text_stream` and stream wrappers for output capture |

## Related Modules

- [compat](compat.md) — Platform compatibility and stream primitives.
- [globals](globals.md) — Context-local state such as the color default.
- [exceptions](exceptions.md) — `FileError` and other Click exceptions.
- [core](core.md) — The command/context framework that consumes these utilities.
- [types](types.md) — Parameter types built on the file utilities.
- [testing](testing.md) — Test harness that captures streams.
