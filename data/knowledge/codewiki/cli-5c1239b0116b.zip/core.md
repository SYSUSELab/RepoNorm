# Core Module

## Introduction

The **Core** module (`src/click/core.py`) is the heart of the Click framework. It defines the fundamental building blocks that every Click-based command-line application is composed of: **Commands**, **Groups**, **Parameters** (Options and Arguments), and the **Context** object that carries state throughout an invocation.

This module is responsible for:

- Defining the command hierarchy (`Command`, `Group`, `CommandCollection`).
- Defining the parameter model (`Parameter`, `Option`, `Argument`).
- Orchestrating parsing, value resolution, type conversion, and callback invocation.
- Managing invocation state through the `Context` object.
- Rendering usage and help output via the [`HelpFormatter`](formatting.md).
- Delegating low-level token parsing to the [`_OptionParser`](parser.md).
- Raising structured errors defined in the [`exceptions`](exceptions.md) module.

The core module sits at the center of the framework and depends on nearly every other module. The diagram below shows how it relates to its sibling modules.

```mermaid
graph TD
    Core["core.py<br/>(Command, Group, Context,<br/>Parameter, Option, Argument)"]
    Parser["parser.py<br/>(_OptionParser, _ParsingState)"]
    Exceptions["exceptions.py<br/>(UsageError, BadParameter, ...)"]
    Formatting["formatting.py<br/>(HelpFormatter)"]
    Types["types.py<br/>(ParamType, ...)"]
    Utils["utils.py<br/>(echo, make_str, ...)"]
    ShellCompletion["shell_completion.py<br/>(CompletionItem)"]
    Globals["globals.py<br/>(push_context, pop_context)"]

    Core --> Parser
    Core --> Exceptions
    Core --> Formatting
    Core --> Types
    Core --> Utils
    Core --> ShellCompletion
    Core --> Globals
    Parser --> Exceptions
    Parser --> Types
    Formatting --> Utils
```

> **Note:** Detailed documentation for each dependency lives in its own file:
> [parser.md](parser.md), [exceptions.md](exceptions.md), [formatting.md](formatting.md),
> [types.md](types.md), [utils.md](utils.md), [shell_completion.md](shell_completion.md).

---

## Architecture Overview

The core module is organized around three conceptual layers:

1. **Command layer** — `Command`, `Group`, `CommandCollection` (and the deprecated `_BaseCommand` / `_MultiCommand` shims). These define *what* runs.
2. **Parameter layer** — `Parameter`, `Option`, `Argument`. These define *how* input is collected and validated.
3. **Context layer** — `Context` and `ParameterSource`. These carry *state* across the invocation lifecycle.

```mermaid
classDiagram
    class Command {
        +name
        +params: list[Parameter]
        +callback
        +make_context()
        +parse_args()
        +invoke()
        +main()
        +get_help()
    }
    class Group {
        +commands: dict
        +chain: bool
        +add_command()
        +command()
        +group()
        +resolve_command()
    }
    class CommandCollection {
        +sources: list[Group]
        +add_source()
    }
    class Parameter {
        +name
        +type: ParamType
        +required
        +default
        +consume_value()
        +process_value()
        +handle_parse_result()
    }
    class Option {
        +is_flag
        +prompt
        +multiple
        +count
    }
    class Argument {
        +nargs
    }
    class Context {
        +command
        +parent
        +params
        +obj
        +invoke()
        +forward()
        +exit()
    }
    class ParameterSource {
        <<enum>>
        COMMANDLINE
        ENVIRONMENT
        DEFAULT
        DEFAULT_MAP
        PROMPT
    }

    Command <|-- Group
    Group <|-- CommandCollection
    Parameter <|-- Option
    Parameter <|-- Argument
    Command --> Context : creates
    Command --> Parameter : owns
    Context --> ParameterSource : tracks
```

---

## Command Layer

### `Command`

`Command` is the base class for all commands. It encapsulates:

- **Metadata**: `name`, `help`, `epilog`, `short_help`, `hidden`, `deprecated`.
- **Parameters**: a list of `Parameter` objects (`params`).
- **Parsing**: `make_parser()` builds an [`_OptionParser`](parser.md) and `parse_args()` drives it.
- **Invocation**: `invoke()` calls the user callback with resolved parameters.
- **Help rendering**: `get_help()`, `format_help()`, `format_usage()`, `format_options()`.
- **Entry point**: `main()` (aliased by `__call__`) is the standard way to run a CLI.

Key class attributes that influence the created `Context`:

| Attribute | Default | Purpose |
|-----------|---------|---------|
| `context_class` | `Context` | Class used by `make_context()`. |
| `allow_extra_args` | `False` | Whether trailing args are tolerated. |
| `allow_interspersed_args` | `True` | Whether options and args may be mixed. |
| `ignore_unknown_options` | `False` | Whether unknown options are passed through. |

The `main()` method implements the full application lifecycle, including shell-completion short-circuiting, exception handling, and standalone-mode exit behavior.

```mermaid
flowchart TD
    A["main(args, prog_name, ...)"] --> B["_main_shell_completion()"]
    B -->|completion requested| Z1["sys.exit(rv)"]
    B -->|no completion| C["make_context()"]
    C --> D["parse_args()"]
    D --> E["invoke()"]
    E --> F{"standalone_mode?"}
    F -->|True| G["ctx.exit()"]
    F -->|False| H["return rv"]
    E -->|ClickException| I["e.show(); sys.exit(code)"]
    E -->|Abort| J["echo('Aborted!'); sys.exit(1)"]
```

### `Group`

`Group` extends `Command` to nest subcommands. Notable behaviors:

- Maintains a `commands` mapping of name → `Command`.
- `add_command()` registers subcommands and enforces the chain-mode constraint via `_check_nested_chain()`.
- `command()` and `group()` are decorator shortcuts that create and register subcommands.
- `resolve_command()` looks up a subcommand by name, applying `token_normalize_func` if needed.
- `result_callback()` registers a callback invoked with the subcommand's return value.
- **Chain mode** (`chain=True`) allows multiple subcommands in a single invocation; the result callback receives a list of results.

`Group` overrides `parse_args()` to split remaining tokens into `_protected_args` (the subcommand name) and `args` (its arguments).

### `CommandCollection`

`CommandCollection` is a `Group` that "flattens" commands from multiple source groups. Lookups fall through to each registered source in order. This is useful for building a unified CLI from several independent groups.

### Deprecated shims

- `_BaseCommand` (metaclass `_FakeSubclassCheck`) — deprecated alias for `Command`.
- `_MultiCommand` — deprecated alias for `Group`.
- Module-level `__getattr__` emits `DeprecationWarning` for `BaseCommand` and `MultiCommand`.

---

## Parameter Layer

### `Parameter`

`Parameter` is the abstract base for `Option` and `Argument`. It handles:

- **Declaration parsing** (`_parse_decls`) — implemented by subclasses.
- **Default resolution** (`get_default`) — checks `ctx.default_map` first, then the local default.
- **Value consumption** (`consume_value`) — resolves the value and its [`ParameterSource`](#parametersource).
- **Type casting** (`type_cast_value`) — applies the [`ParamType`](types.md) and handles `nargs`/`multiple`.
- **Validation** (`process_value`) — enforces `required`, then runs the user callback.
- **Parse-result handling** (`handle_parse_result`) — the main entry point called during parsing.

The value resolution order is:

```mermaid
flowchart LR
    A["Command line opts"] -->|found| S1["COMMANDLINE"]
    A -->|not found| B["Environment variable"]
    B -->|found| S2["ENVIRONMENT"]
    B -->|not found| C["ctx.default_map"]
    C -->|found| S3["DEFAULT_MAP"]
    C -->|not found| D["Parameter default"]
    D -->|found| S4["DEFAULT"]
    D -->|not found| E["Prompt (if enabled)"]
    E --> S5["PROMPT"]
```

### `Option`

`Option` adds command-line-specific features:

- **Flags**: `is_flag`, `flag_value`, boolean flag auto-detection.
- **Prompting**: `prompt`, `confirmation_prompt`, `hide_input`, `prompt_required`.
- **Repetition**: `multiple` (append), `count` (increment).
- **Help extras**: `show_default`, `show_envvar`, `show_choices`, `hidden`.
- **Auto-envvar**: `allow_from_autoenv` pulls values from `ctx.auto_envvar_prefix`.

`Option.add_to_parser()` translates these settings into parser actions (`store`, `append`, `count`, `store_const`, etc.).

### `Argument`

`Argument` represents positional parameters. It is required by default (unless a default is given or `nargs <= 0`), supports `nargs=-1` for variadic collection, and does not support `multiple`.

---

## Context Layer

### `Context`

`Context` is the stateful object threaded through an entire invocation. It is normally invisible to command callbacks unless they opt in (e.g., via `@pass_context`).

Responsibilities:

- **Hierarchy**: `parent`, `command`, `command_path`, `find_root()`.
- **State**: `params`, `args`, `obj`, `meta`, `invoked_subcommand`.
- **Configuration inheritance**: terminal width, color, `show_default`, `help_option_names`, `token_normalize_func`, `auto_envvar_prefix`.
- **Resource management**: `with_resource()`, `call_on_close()`, `close()` via an `ExitStack`.
- **Invocation helpers**: `invoke()`, `forward()`, `exit()`, `fail()`, `abort()`.
- **Parameter source tracking**: `set_parameter_source()`, `get_parameter_source()`.

`Context` is a context manager: entering pushes it onto the thread-local stack (via [`push_context`](globals.md)), and exiting pops it and runs cleanup when the depth reaches zero.

```mermaid
sequenceDiagram
    participant Cmd as Command
    participant Ctx as Context
    participant Parser as _OptionParser
    participant Param as Parameter

    Cmd->>Ctx: make_context(info_name, args)
    Ctx->>Ctx: __enter__ (push_context)
    Cmd->>Parser: make_parser(ctx)
    Cmd->>Parser: parse_args(args)
    Parser-->>Cmd: (opts, args, param_order)
    loop for each param in processing order
        Cmd->>Param: handle_parse_result(ctx, opts, args)
        Param->>Ctx: set_parameter_source()
        Param->>Param: process_value()
    end
    Cmd->>Ctx: invoke(callback, **ctx.params)
    Ctx->>Ctx: __exit__ (pop_context, close)
```

### `ParameterSource`

`ParameterSource` is an `enum.Enum` describing where a parameter's value came from:

| Member | Meaning |
|--------|---------|
| `COMMANDLINE` | Provided on the command line. |
| `ENVIRONMENT` | Provided via an environment variable. |
| `DEFAULT` | Taken from the parameter's default. |
| `DEFAULT_MAP` | Taken from `Context.default_map`. |
| `PROMPT` | Provided interactively via a prompt. |

Retrieve it with `Context.get_parameter_source(name)`.

---

## Helper Functions

The module also defines several module-level helpers used internally:

| Function | Purpose |
|----------|---------|
| `augment_usage_errors(ctx, param)` | Context manager that attaches `ctx`/`param` to raised errors. |
| `iter_params_for_processing(invocation_order, declaration_order)` | Orders parameters by eagerness and invocation order. |
| `_complete_visible_commands(ctx, incomplete)` | Yields non-hidden subcommands matching a prefix. |
| `_check_nested_chain(base, name, cmd, register)` | Enforces the chain-mode nesting constraint. |
| `batch(iterable, batch_size)` | Groups an iterable into fixed-size tuples. |
| `_check_iter(value)` | Validates that a value is iterable but not a string. |

---

## Data Flow: From CLI to Callback

The following diagram summarizes the end-to-end flow of a single command invocation.

```mermaid
flowchart TD
    A["sys.argv"] --> B["Command.main()"]
    B --> C["Command.make_context()"]
    C --> D["Command.parse_args()"]
    D --> E["_OptionParser.parse_args()"]
    E --> F["_ParsingState (opts, largs, order)"]
    F --> G["iter_params_for_processing()"]
    G --> H["Parameter.handle_parse_result()"]
    H --> I["consume_value() → ParameterSource"]
    I --> J["type_cast_value() → ParamType"]
    J --> K["process_value() → required check + callback"]
    K --> L["ctx.params populated"]
    L --> M["Command.invoke()"]
    M --> N["ctx.invoke(callback, **ctx.params)"]
    N --> O["User callback executes"]
```

---

## Extension Points

Developers commonly extend the core module in the following ways:

- **Custom commands**: subclass `Command` or `Group` and set `context_class` / `command_class` / `group_class`.
- **Custom parameters**: subclass `Parameter`, `Option`, or `Argument` and implement `_parse_decls`, `add_to_parser`, and `get_help_record`.
- **Custom types**: subclass [`ParamType`](types.md) and implement `convert`.
- **Custom formatting**: subclass [`HelpFormatter`](formatting.md) and set `Context.formatter_class`.
- **Custom completion**: implement `shell_complete` on commands, parameters, or types (see [shell_completion.md](shell_completion.md)).

---

## Related Modules

- [parser.md](parser.md) — Low-level token parsing (`_OptionParser`, `_ParsingState`).
- [exceptions.md](exceptions.md) — Error hierarchy (`UsageError`, `BadParameter`, `Abort`, `Exit`, ...).
- [formatting.md](formatting.md) — Help/usage text rendering (`HelpFormatter`).
- [types.md](types.md) — Parameter type system (`ParamType` and built-in types).
- [utils.md](utils.md) — I/O helpers (`echo`, `LazyFile`, `PacifyFlushWrapper`).
- [shell_completion.md](shell_completion.md) — Shell completion support (`CompletionItem`, `ShellComplete`).
- [testing.md](testing.md) — `CliRunner` and test utilities.
