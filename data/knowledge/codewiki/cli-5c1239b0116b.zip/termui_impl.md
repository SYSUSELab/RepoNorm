# termui_impl Module

## Introduction

The `termui_impl` module (`src/click/_termui_impl.py`) contains the concrete implementations of Click's terminal user interface (TUI) functionality. To keep Click's import time low, infrequently used terminal features are isolated in this module and imported lazily only when needed.

The module provides three primary capabilities:

1. **`ProgressBar`** — a generic, iterable-aware progress bar that renders live progress to a terminal.
2. **`Editor`** — a helper that opens the user's preferred text editor to edit text or files.
3. **Pager and terminal helpers** — functions such as `pager`, `open_url`, `getchar`, and `raw_terminal` that handle paging output, opening URLs, and reading raw keystrokes across platforms.

This module is part of the [platform_and_terminal_foundation](platform_and_terminal_foundation.md) group and relies heavily on the low-level primitives provided by the [compat](compat.md) module.

---

## Architecture Overview

The module sits between Click's high-level public API and the platform-specific compatibility layer. It is consumed by higher-level modules (such as the core command/context machinery) and depends on `_compat` for cross-platform behavior.

```mermaid
graph TD
    subgraph "termui_impl (current module)"
        PB[ProgressBar]
        ED[Editor]
        PG[pager / _pipepager / _tempfilepager / _nullpager]
        OU[open_url]
        GC[getchar / raw_terminal]
    end

    subgraph "compat"
        COMPAT[_compat: isatty, strip_ansi, term_len,<br/>open_stream, get_best_encoding,<br/>_default_text_stdout, WIN, CYGWIN]
    end

    subgraph "utils"
        ECHO[echo]
    end

    subgraph "exceptions"
        CE[ClickException]
    end

    subgraph "stdlib"
        STDLIB[os, sys, time, math, shlex,<br/>subprocess, tempfile, shutil,<br/>termios, tty, msvcrt]
    end

    PB --> COMPAT
    PB --> ECHO
    ED --> COMPAT
    ED --> CE
    PG --> COMPAT
    PG --> STDLIB
    OU --> STDLIB
    GC --> COMPAT
    GC --> STDLIB
```

---

## Component Relationships

The following diagram shows how the public entry points relate to their internal helpers.

```mermaid
graph LR
    subgraph "ProgressBar"
        PB[ProgressBar]
        PB --> RP[render_progress]
        PB --> RF[render_finish]
        PB --> GEN[generator]
        PB --> UPD[update / make_step]
        PB --> FMT[format_* helpers]
    end

    subgraph "Editor"
        ED[Editor]
        ED --> GE[get_editor]
        ED --> EF[edit_files]
        ED --> E[edit]
    end

    subgraph "Pager"
        PG[pager]
        PG --> PP[_pipepager]
        PG --> TP[_tempfilepager]
        PG --> NP[_nullpager]
    end
```

---

## ProgressBar

`ProgressBar` is a generic class (`ProgressBar[V]`) that renders a live, updating progress indicator. It can wrap an existing iterable or operate over a fixed number of steps.

### Key Responsibilities

- Track progress position (`pos`), total length (`length`), and completion state.
- Compute and display percentage, position, ETA, and custom item information.
- Render a bar using configurable fill/empty characters and a template.
- Adapt to terminal width automatically when `width=0`.
- Degrade gracefully when output is not a TTY (only the label is printed once).

### Construction Parameters

| Parameter | Type | Default | Purpose |
|-----------|------|---------|---------|
| `iterable` | `Iterable[V] \| None` | — | Items to iterate over. |
| `length` | `int \| None` | `None` | Total number of steps; inferred via `length_hint` if omitted. |
| `fill_char` | `str` | `"#"` | Character used for the completed portion of the bar. |
| `empty_char` | `str` | `" "` | Character used for the remaining portion. |
| `bar_template` | `str` | `"%(bar)s"` | Template with `%(label)s`, `%(bar)s`, `%(info)s`. |
| `info_sep` | `str` | `"  "` | Separator between info bits. |
| `hidden` | `bool` | `False` | Suppress all rendering. |
| `show_eta` | `bool` | `True` | Show estimated time remaining. |
| `show_percent` | `bool \| None` | `None` | Show percentage (auto when `None`). |
| `show_pos` | `bool` | `False` | Show current position. |
| `item_show_func` | `Callable[[V \| None], str \| None] \| None` | `None` | Render info for the current item. |
| `label` | `str \| None` | `None` | Static label prefix. |
| `file` | `TextIO \| None` | `None` | Output stream (defaults to stdout). |
| `color` | `bool \| None` | `None` | Force color on/off. |
| `update_min_steps` | `int` | `1` | Minimum steps before re-rendering. |
| `width` | `int` | `30` | Bar width; `0` enables auto-width. |

### Usage Pattern

`ProgressBar` must be used as a context manager. Iteration is only permitted inside the `with` block.

```python
with ProgressBar(items) as bar:
    for item in bar:
        process(item)
```

### Lifecycle and Data Flow

```mermaid
sequenceDiagram
    participant User
    participant PB as ProgressBar
    participant Term as Terminal (file)

    User->>PB: __enter__()
    PB->>Term: render_progress()
    User->>PB: __iter__()
    PB->>PB: generator()
    loop For each item
        PB->>PB: set current_item
        PB->>Term: render_progress() (if interval start)
        PB-->>User: yield item
        User->>PB: (block returns)
        PB->>PB: update(1) -> make_step()
        PB->>Term: render_progress()
    end
    PB->>PB: finish()
    PB->>Term: render_progress()
    User->>PB: __exit__()
    PB->>Term: render_finish()
```

### Rendering Logic

The rendering pipeline is composed of several `format_*` methods that build up the final line:

```mermaid
graph TD
    FPL[format_progress_line] --> FB[format_bar]
    FPL --> FP[format_pos]
    FPL --> FPC[format_pct]
    FPL --> FE[format_eta]
    FPL --> ISF[item_show_func]
    FB --> PCT[pct property]
    FB --> TPI[time_per_iteration]
    FE --> ETA[eta property]
```

- **`pct`** — fraction complete (`pos / length`), clamped to `1.0`.
- **`time_per_iteration`** — rolling average of the last 7 step durations.
- **`eta`** — `time_per_iteration * (length - pos)`.
- **`format_bar`** — when `length` is known, fills proportionally; when unknown, animates a single moving fill character using a cosine function.

### Terminal Width Handling

When `autowidth` is enabled (`width == 0`), `render_progress` recomputes the bar width on every render based on `shutil.get_terminal_size().columns` minus the length of the surrounding "clutter" (label, info bits). It tracks `max_width` to clear stale characters when the terminal shrinks.

### Non-TTY Behavior

When the output stream is not a TTY (`_is_atty` is `False`), the bar does not render live updates. Instead, only the label is echoed once, and iteration simply yields items without per-step rendering.

### Iteration Internals

The iterator interface is defined in terms of `generator()`. `__next__` calls `next(iter(self))`, which is safe because `self.iter` is a re-entry-safe iterable consumed by the generator. This design is explicitly documented as fragile — changes to `generator()` must be evaluated against both `iter(bar)` and `next(bar)`.

---

## Editor

`Editor` opens the user's preferred text editor to edit text or files, then returns the edited content.

### Key Responsibilities

- Resolve the editor command from configuration or environment.
- Write initial content to a temporary file.
- Launch the editor and wait for it to exit.
- Detect whether the file was actually saved (via modification time).
- Return the edited content in the same type it was provided (`str` or `bytes`).

### Construction Parameters

| Parameter | Type | Default | Purpose |
|-----------|------|---------|---------|
| `editor` | `str \| None` | `None` | Explicit editor command; auto-detected if `None`. |
| `env` | `Mapping[str, str] \| None` | `None` | Extra environment variables for the editor process. |
| `require_save` | `bool` | `True` | If `True`, return `None` when the file was not modified. |
| `extension` | `str` | `".txt"` | Suffix for the temporary file. |

### Editor Resolution

`get_editor` resolves the editor in the following priority order:

```mermaid
graph TD
    A[Explicit self.editor] -->|set| Z[Use it]
    A -->|not set| B[VISUAL env var]
    B -->|set| Z
    B -->|not set| C[EDITOR env var]
    C -->|set| Z
    C -->|not set| D{Windows?}
    D -->|yes| E[notepad]
    D -->|no| F[sensible-editor / vim / nano]
    F -->|found| Z
    F -->|none found| G[vi]
```

### Edit Flow

```mermaid
sequenceDiagram
    participant User
    participant ED as Editor
    participant FS as Temp File
    participant Proc as Editor Process

    User->>ED: edit(text)
    ED->>FS: write encoded data
    ED->>FS: backdate mtime by 2s
    ED->>FS: record timestamp
    ED->>Proc: edit_files([name])
    Proc-->>ED: exit code
    alt exit code != 0
        ED-->>User: raise ClickException
    end
    ED->>FS: check mtime
    alt require_save and unchanged
        ED-->>User: return None
    else
        ED->>FS: read content
        ED-->>User: return str or bytes
    end
    ED->>FS: unlink temp file
```

### Type Handling

`edit` is overloaded to preserve input type:

- `bytes`/`bytearray` input → `bytes` output.
- `str`/`None` input → `str` output.

On Windows, text is normalized to CRLF and encoded as `utf-8-sig`; on other platforms it is encoded as `utf-8`. When reading back, `utf-8-sig` decoding and CRLF→LF normalization are applied.

### Modification-Time Workaround

Because some filesystems (e.g., macOS 10.12 Extended, FAT32) have coarse mtime resolution, the file's mtime is set 2 seconds in the past before launching the editor. This ensures that even a very fast editor save produces a detectable mtime change.

---

## Pager Functions

The pager subsystem decides how to page through text output based on the environment.

### `pager(generator, color=None)`

The main entry point. It selects a paging strategy in the following order:

```mermaid
graph TD
    A[pager] --> B{stdin and stdout are TTYs?}
    B -->|no| NP[_nullpager]
    B -->|yes| C{PAGER env var set?}
    C -->|yes, Windows| TP1[_tempfilepager]
    C -->|yes, non-Windows| PP1[_pipepager]
    C -->|no| D{TERM is dumb/emacs?}
    D -->|yes| NP
    D -->|no| E{Windows/os2?}
    E -->|yes| TP2[_tempfilepager with more]
    E -->|no| F[_pipepager with less]
    F -->|failed| G[_pipepager with more]
    G -->|failed| NP
```

### Pager Strategies

| Function | Strategy | Notes |
|----------|----------|-------|
| `_pipepager` | Pipes text to a subprocess via stdin. | Supports color; auto-enables `-R` for `less`. Handles `BrokenPipeError` and `KeyboardInterrupt`. |
| `_tempfilepager` | Writes text to a temp file and invokes the pager on it. | Used on Windows and as a fallback. |
| `_nullpager` | Writes text directly to the stream. | Ultimate fallback; strips ANSI when color is disabled. |

### Color Handling

When `color` is `None` and the pager is `less`, the module inspects the `LESS` environment variable and command-line flags. If no flags are present, it sets `LESS=-R` and enables color. If `r` or `R` is present in the flags, color is enabled.

### Signal Handling

`_pipepager` waits for the pager process in a loop that swallows `KeyboardInterrupt`. This is because `less` catches `^C` for its own UI purposes and does not exit, which would otherwise leave the terminal in a broken state.

---

## Terminal Helpers

### `open_url(url, wait=False, locate=False)`

Opens a URL or file location using the platform's default handler. Returns an exit code.

| Platform | Command | Notes |
|----------|---------|-------|
| macOS (`darwin`) | `open` | `-W` for wait, `-R` for locate. |
| Windows | `explorer` / `start` | `/select,` for locate, `/WAIT` for wait. |
| Cygwin | `cygstart` | `-w` for wait. |
| Other | `xdg-open` | Falls back to `webbrowser` for HTTP(S) URLs. |

### `getchar(echo)` and `raw_terminal()`

These provide cross-platform raw character input.

- **Windows**: Uses `msvcrt.getwch`/`getwche`. Handles special-key sequences prefixed with `\x00` or `\xe0` by reading a second character.
- **Unix**: Uses `termios` and `tty` to set the terminal to raw mode, reading up to 32 bytes at a time. Falls back to opening `/dev/tty` when stdin is not a TTY.

### `_translate_ch_to_exc(ch)`

Translates control characters into exceptions:

| Character | Platform | Exception |
|-----------|----------|-----------|
| `\x03` (Ctrl+C) | All | `KeyboardInterrupt` |
| `\x04` (Ctrl+D) | Unix | `EOFError` |
| `\x1a` (Ctrl+Z) | Windows | `EOFError` |

---

## Platform-Specific Constants

The module defines bar control sequences based on the OS:

```python
if os.name == "nt":
    BEFORE_BAR = "\r"
    AFTER_BAR = "\n"
else:
    BEFORE_BAR = "\r\033[?25l"   # carriage return + hide cursor
    AFTER_BAR = "\033[?25h\n"    # show cursor + newline
```

On Unix-like systems, the cursor is hidden while the bar renders and restored when finished.

---

## Dependencies

### Internal Dependencies

| Dependency | Used For |
|------------|----------|
| [compat](compat.md) — `isatty` | Detect TTY streams. |
| [compat](compat.md) — `strip_ansi` | Remove ANSI codes for non-color output. |
| [compat](compat.md) — `term_len` | Measure visible line length. |
| [compat](compat.md) — `open_stream` | Open files for the tempfile pager. |
| [compat](compat.md) — `get_best_encoding` | Determine encoding for pager output. |
| [compat](compat.md) — `_default_text_stdout` | Default output stream. |
| [compat](compat.md) — `WIN`, `CYGWIN` | Platform detection. |
| [utils](utils.md) — `echo` | Write rendered output. |
| [exceptions](exceptions.md) — `ClickException` | Report editor failures. |

### Standard Library Dependencies

`collections.abc`, `contextlib`, `math`, `os`, `shlex`, `sys`, `time`, `typing`, `gettext`, `io`, `pathlib`, `shutil`, `types`, plus platform-specific `termios`/`tty` (Unix) and `msvcrt` (Windows).

---

## Design Notes

- **Lazy Importing**: The module is imported on demand to keep Click's startup fast. Heavy imports (`subprocess`, `tempfile`, `shutil`) are performed inside functions.
- **Graceful Degradation**: Every terminal feature has a fallback path for non-TTY environments (e.g., `_nullpager`, non-TTY progress rendering).
- **Cross-Platform Abstraction**: Platform differences (Windows console, Cygwin, macOS) are encapsulated within this module and the [compat](compat.md) layer.
- **Re-entry Safety**: The `ProgressBar` iterator is carefully designed so that `iter(bar)` and `next(bar)` both work correctly.

---

## Related Modules

- [compat](compat.md) — Low-level platform compatibility primitives.
- [utils](utils.md) — Output helpers including `echo`.
- [exceptions](exceptions.md) — Exception types raised by this module.
- [core](core.md) — Higher-level command machinery that consumes TUI features.
