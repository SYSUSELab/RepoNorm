# Shell Completion Module

## Introduction

The `shell_completion` module (`src/click/shell_completion.py`) provides tab-completion support for Click-based command line applications across multiple shells: **Bash**, **Zsh**, and **Fish**. It enables users to press `<TAB>` while typing a command to receive context-aware suggestions for subcommands, option names, and option/argument values.

The module is part of the [developer and shell integration tooling](developer_and_shell_integration_tooling.md) group and works closely with the [CLI framework core](cli_framework_core.md) to introspect the command hierarchy and resolve the correct completion target.

### Key Capabilities

- **Multi-shell support**: Built-in implementations for Bash, Zsh, and Fish, with an extensible registry for custom shells.
- **Context-aware completion**: Resolves the active command/subcommand and the parameter being completed.
- **Rich completion metadata**: The `CompletionItem` class carries a value, a type hint (`plain`, `dir`, `file`), and optional help text.
- **Custom completions**: Parameters can supply a `shell_complete` callback (see [parameter types and IO utilities](parameter_types_and_io_utilities.md)) to override default type-based completion.

---

## Architecture Overview

The module is organized around an abstract base class (`ShellComplete`) and concrete shell-specific subclasses. A registry maps shell names to their implementations, and a set of helper functions performs the heavy lifting of resolving the completion context.

```mermaid
graph TD
    subgraph "Entry Point"
        SC["shell_complete()"]
    end

    subgraph "Registry"
        REG["_available_shells"]
        ADD["add_completion_class()"]
        GET["get_completion_class()"]
    end

    subgraph "Base & Subclasses"
        BASE["ShellComplete (abstract)"]
        BASH["BashComplete"]
        ZSH["ZshComplete"]
        FISH["FishComplete"]
    end

    subgraph "Data Model"
        ITEM["CompletionItem"]
    end

    subgraph "Resolution Helpers"
        RC["_resolve_context()"]
        RI["_resolve_incomplete()"]
        IIA["_is_incomplete_argument()"]
        IIO["_is_incomplete_option()"]
        SOO["_start_of_option()"]
        SAS["split_arg_string()"]
    end

    SC --> GET
    GET --> REG
    ADD --> REG
    REG --> BASH
    REG --> ZSH
    REG --> FISH
    BASH --> BASE
    ZSH --> BASE
    FISH --> BASE
    BASE --> RC
    BASE --> RI
    BASE --> ITEM
    RI --> IIA
    RI --> IIO
    IIO --> SOO
    BASE --> SAS
```

---

## Core Components

### `shell_complete()` — Module Entry Point

The top-level function invoked by the CLI framework when a completion request is detected.

```python
def shell_complete(
    cli: Command,
    ctx_args: MutableMapping[str, Any],
    prog_name: str,
    complete_var: str,
    instruction: str,
) -> int:
```

**Behavior:**

1. Parses the `instruction` string of the form `{instruction}_{shell}` (e.g. `bash_source`, `zsh_complete`).
2. Looks up the appropriate `ShellComplete` subclass via `get_completion_class()`.
3. Instantiates the completion handler.
4. Dispatches based on the instruction:
   - `source` → emits the shell script that registers the completion function.
   - `complete` → emits the completion data for the current input.
5. Returns a status code (`0` on success, `1` on failure).

> **Integration note:** This function is called from `Command._main_shell_completion()` in the [CLI framework core](cli_framework_core.md), which detects the completion environment variable (default `_{PROG_NAME}_COMPLETE`) and exits early with the returned status code.

---

### `CompletionItem` — Completion Data Model

Represents a single completion suggestion along with metadata.

| Attribute | Type | Description |
|-----------|------|-------------|
| `value` | `Any` | The completion suggestion text. |
| `type` | `str` | Special shell handling hint. Click uses `"plain"`, `"dir"`, and `"file"`. |
| `help` | `str \| None` | Help string shown next to the value (if the shell supports it). |
| `_info` | `dict` | Arbitrary metadata passed via `**kwargs`. |

The class uses `__slots__` for memory efficiency and implements `__getattr__` to expose arbitrary metadata attributes, returning `None` when an attribute was not provided.

```python
item = CompletionItem("myfile.txt", type="file", help="A text file")
item.value   # "myfile.txt"
item.type    # "file"
item.help    # "A text file"
item.custom  # None (not provided)
```

---

### `ShellComplete` — Abstract Base Class

The base class defines the completion protocol. Subclasses override the shell-specific pieces.

**Class attributes:**

| Attribute | Description |
|-----------|-------------|
| `name` | Registry name (e.g. `"bash"`). Used in completion instructions. |
| `source_template` | `%`-style template for the shell script. Must be provided by subclasses. |

**Instance attributes:** `cli`, `ctx_args`, `prog_name`, `complete_var`.

**Key methods:**

| Method | Purpose |
|--------|---------|
| `func_name` (property) | Derives a safe shell function name from `prog_name`. |
| `source_vars()` | Returns the dict used to format `source_template`. |
| `source()` | Produces the shell script defining the completion function. |
| `get_completion_args()` | **Abstract** — extracts `(args, incomplete)` from shell env vars. |
| `get_completions(args, incomplete)` | Resolves context and delegates to the target object's `shell_complete`. |
| `format_completion(item)` | **Abstract** — formats a `CompletionItem` for the shell. |
| `complete()` | Orchestrates the full completion flow. |

#### Completion Flow

```mermaid
sequenceDiagram
    participant Shell
    participant Script as Shell Script
    participant CLI as CLI Program
    participant SC as ShellComplete
    participant Ctx as Context/Command

    Shell->>Script: User presses TAB
    Script->>CLI: env COMP_WORDS/COMP_CWORD + complete_var
    CLI->>SC: shell_complete(...)
    SC->>SC: get_completion_args()
    SC->>SC: get_completions(args, incomplete)
    SC->>Ctx: _resolve_context() + _resolve_incomplete()
    Ctx-->>SC: target object (Command/Parameter)
    SC->>Ctx: obj.shell_complete(ctx, incomplete)
    Ctx-->>SC: list[CompletionItem]
    SC->>SC: format_completion() per item
    SC-->>CLI: formatted string
    CLI-->>Script: stdout
    Script-->>Shell: COMPREPLY / compadd / echo
```

---

### Shell-Specific Subclasses

Each subclass implements `get_completion_args()` and `format_completion()` for its shell's conventions.

#### `BashComplete`

- **Name:** `"bash"`
- **Version check:** `_check_version()` verifies Bash ≥ 4.4 (required for the `nosort` option) and warns otherwise.
- **Args extraction:** Reads `COMP_WORDS` and `COMP_CWORD` environment variables.
- **Format:** `"{type},{value}"` (comma-separated).

#### `ZshComplete`

- **Name:** `"zsh"`
- **Args extraction:** Reads `COMP_WORDS` and `COMP_CWORD`.
- **Format:** Newline-separated triple: `"{type}\n{value}\n{help or '_'}"`.

#### `FishComplete`

- **Name:** `"fish"`
- **Args extraction:** Reads `COMP_WORDS` and `COMP_CWORD`; removes the partial word from complete args since Fish stores it in both.
- **Format:** `"{type},{value}"` or `"{type},{value}\t{help}"` when help is present.

```mermaid
classDiagram
    class ShellComplete {
        <<abstract>>
        +name: str
        +source_template: str
        +func_name: str
        +source() str
        +get_completion_args()* tuple
        +get_completions(args, incomplete) list
        +format_completion(item)* str
        +complete() str
    }
    class BashComplete {
        +name = "bash"
        +_check_version()
        +get_completion_args()
        +format_completion(item)
    }
    class ZshComplete {
        +name = "zsh"
        +get_completion_args()
        +format_completion(item)
    }
    class FishComplete {
        +name = "fish"
        +get_completion_args()
        +format_completion(item)
    }
    ShellComplete <|-- BashComplete
    ShellComplete <|-- ZshComplete
    ShellComplete <|-- FishComplete
```

---

## Registry and Extensibility

The module maintains a registry (`_available_shells`) mapping shell names to `ShellComplete` subclasses.

```python
_available_shells = {
    "bash": BashComplete,
    "fish": FishComplete,
    "zsh": ZshComplete,
}
```

| Function | Purpose |
|----------|---------|
| `add_completion_class(cls, name=None)` | Registers a custom `ShellComplete` subclass. Defaults to the class's `name` attribute. |
| `get_completion_class(shell)` | Looks up a registered class by name; returns `None` if not found. |

**Example — registering a custom shell:**

```python
from click.shell_completion import ShellComplete, add_completion_class

@add_completion_class
class MyShellComplete(ShellComplete):
    name = "myshell"
    source_template = "..."

    def get_completion_args(self):
        ...

    def format_completion(self, item):
        ...
```

---

## Context Resolution Helpers

These internal functions translate the raw shell arguments into a Click object capable of producing completions.

### `split_arg_string(string)`

Splits an argument string like `shlex.split`, but tolerates incomplete input (missing closing quotes or trailing escapes). Moved here from `parser` in version 8.2.

```python
split_arg_string("example 'my file")  # ["example", "my file"]
split_arg_string("example my\\")      # ["example", "my"]
```

### `_resolve_context(cli, ctx_args, prog_name, args)`

Builds the `Context` hierarchy by traversing complete arguments through nested `Group` commands. It sets `resilient_parsing=True` to avoid triggering prompts or callbacks. Handles both regular groups and **chained** groups.

### `_resolve_incomplete(ctx, args, incomplete)`

Determines which Click object should handle the completion of the incomplete value. The resolution order is:

1. Normalize `=` handling for long options (e.g. `--opt=val`).
2. If the incomplete value looks like an option and `--` hasn't been seen → the **command** provides option-name completions.
3. If the last complete arg is an option awaiting a value → the **option** provides value completions.
4. Otherwise, the first argument without a parsed value → the **argument** provides value completions.
5. Fallback → the **command** provides subcommand-name completions.

```mermaid
flowchart TD
    A[incomplete value] --> B{Looks like option?}
    B -- Yes, no '--' --> C[Command: option names]
    B -- No --> D{Last arg is option needing value?}
    D -- Yes --> E[Option: value completions]
    D -- No --> F{Unparsed argument exists?}
    F -- Yes --> G[Argument: value completions]
    F -- No --> H[Command: subcommand names]
```

### Predicate Helpers

| Function | Purpose |
|----------|---------|
| `_is_incomplete_argument(ctx, param)` | Checks whether an `Argument` can still accept values (handles `nargs=-1`, `nargs>1`, and command-line source). |
| `_is_incomplete_option(ctx, args, param)` | Checks whether an `Option` needs a value (skips flags and count options). |
| `_start_of_option(ctx, value)` | Checks whether a value begins with a known option prefix. |

---

## Integration with the CLI Framework

The shell completion module is tightly coupled with the [CLI framework core](cli_framework_core.md):

- **`Command.shell_complete()`** — returns option-name and chained-command completions.
- **`Group.shell_complete()`** — extends the above with subcommand-name completions.
- **`Parameter.shell_complete()`** — delegates to a custom `shell_complete` callback if provided, otherwise to the parameter's `type.shell_complete()` (see [parameter types and IO utilities](parameter_types_and_io_utilities.md)).
- **`Command._main_shell_completion()`** — detects the completion environment variable and invokes `shell_complete()`.

```mermaid
graph LR
    subgraph "CLI Framework Core"
        MAIN["Command.main()"]
        MSC["Command._main_shell_completion()"]
        CMD["Command.shell_complete()"]
        GRP["Group.shell_complete()"]
        PARAM["Parameter.shell_complete()"]
    end

    subgraph "Shell Completion"
        SC["shell_complete()"]
        BASE["ShellComplete.get_completions()"]
    end

    subgraph "Parameter Types"
        TYPE["ParamType.shell_complete()"]
    end

    MAIN --> MSC
    MSC --> SC
    SC --> BASE
    BASE --> CMD
    BASE --> GRP
    BASE --> PARAM
    PARAM --> TYPE
```

---

## Data Flow Summary

```mermaid
flowchart LR
    A[Shell env vars<br/>COMP_WORDS, COMP_CWORD] --> B[get_completion_args]
    B --> C[args, incomplete]
    C --> D[_resolve_context]
    D --> E[Context]
    C --> F[_resolve_incomplete]
    E --> F
    F --> G[Command or Parameter]
    G --> H[obj.shell_complete]
    H --> I[list of CompletionItem]
    I --> J[format_completion]
    J --> K[Formatted output string]
    K --> L[Shell displays suggestions]
```

---

## Related Documentation

- [CLI Framework Core](cli_framework_core.md) — `Command`, `Group`, `Context`, `Parameter`, and the `shell_complete` methods that produce completions.
- [Parameter Types and IO Utilities](parameter_types_and_io_utilities.md) — `ParamType.shell_complete()` implementations for type-based value completion.
- [Developer and Shell Integration Tooling](developer_and_shell_integration_tooling.md) — the parent module group, including the testing utilities.
- [Platform and Terminal Foundation](platform_and_terminal_foundation.md) — low-level terminal handling used by `echo()`.
