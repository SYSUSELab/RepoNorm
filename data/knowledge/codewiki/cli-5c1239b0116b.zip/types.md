# Parameter Types Module

## Introduction

The `types` module (`src/click/types.py`) is the **type system** of the Click CLI framework. It defines how raw string values coming from the command line, environment variables, or Python code are **validated** and **converted** into the correct Python types.

Every parameter in a Click command (an `Option` or `Argument`) is associated with a `ParamType`. When a user supplies a value, Click delegates to the parameter's type to:

1. **Convert** the raw string into a Python object (e.g. `"42"` → `42`).
2. **Validate** the value against constraints (e.g. a number must fall within a range, a path must exist).
3. **Fail** with a descriptive, user-facing error message when conversion or validation is not possible.
4. **Provide shell completion** hints for interactive shells.
5. **Describe itself** for help text and documentation generation.

This module is a foundational dependency for the [core module](core.md) (which owns `Parameter`, `Option`, `Argument`, and `Context`) and is consumed by the [shell completion module](shell_completion.md) and the [formatting module](formatting.md).

---

## Architecture Overview

The type system is built around a single abstract base class, `ParamType`, from which all concrete types derive. A small set of helper base classes (`_NumberParamTypeBase`, `_NumberRangeBase`, `CompositeParamType`) provide shared behavior for families of types.

```mermaid
classDiagram
    class ParamType {
        <<abstract>>
        +name: str
        +is_composite: bool
        +arity: int
        +envvar_list_splitter
        +__call__(value, param, ctx)
        +convert(value, param, ctx)
        +fail(message, param, ctx)
        +get_metavar(param, ctx)
        +get_missing_message(param, ctx)
        +split_envvar_value(rv)
        +shell_complete(ctx, param, incomplete)
        +to_info_dict()
    }

    class CompositeParamType {
        +is_composite = True
        +arity
    }

    class FuncParamType {
        +func
    }

    class UnprocessedParamType
    class StringParamType
    class Choice {
        +choices
        +case_sensitive
        +normalize_choice()
    }
    class DateTime {
        +formats
    }
    class _NumberParamTypeBase {
        +_number_class
    }
    class _NumberRangeBase {
        +min, max
        +min_open, max_open
        +clamp
    }
    class IntParamType
    class IntRange
    class FloatParamType
    class FloatRange
    class BoolParamType
    class UUIDParameterType
    class File {
        +mode, encoding, errors
        +lazy, atomic
    }
    class Path {
        +exists, file_okay, dir_okay
        +readable, writable, executable
    }
    class Tuple {
        +types
    }

    ParamType <|-- CompositeParamType
    ParamType <|-- FuncParamType
    ParamType <|-- UnprocessedParamType
    ParamType <|-- StringParamType
    ParamType <|-- Choice
    ParamType <|-- DateTime
    ParamType <|-- _NumberParamTypeBase
    ParamType <|-- BoolParamType
    ParamType <|-- UUIDParameterType
    ParamType <|-- File
    ParamType <|-- Path
    CompositeParamType <|-- Tuple
    _NumberParamTypeBase <|-- _NumberRangeBase
    _NumberParamTypeBase <|-- IntParamType
    _NumberParamTypeBase <|-- FloatParamType
    _NumberRangeBase <|-- IntRange
    _NumberRangeBase <|-- FloatRange
    IntParamType <|-- IntRange
    FloatParamType <|-- FloatRange
```

### Type Families

| Family | Base Class | Concrete Types | Purpose |
|--------|-----------|----------------|---------|
| Scalar | `ParamType` | `StringParamType`, `BoolParamType`, `UUIDParameterType`, `UnprocessedParamType` | Convert a single value to a Python scalar |
| Numeric | `_NumberParamTypeBase` | `IntParamType`, `FloatParamType` | Convert to `int` / `float` |
| Numeric Range | `_NumberRangeBase` | `IntRange`, `FloatRange` | Numeric conversion plus min/max bounds |
| Enumerated | `ParamType` | `Choice` | Restrict to a fixed set of values |
| Temporal | `ParamType` | `DateTime` | Parse date strings into `datetime` |
| I/O | `ParamType` | `File`, `Path` | Open files or validate filesystem paths |
| Composite | `CompositeParamType` | `Tuple` | Apply different types to multiple values |
| Callable | `ParamType` | `FuncParamType` | Wrap an arbitrary callable as a type |

---

## The `ParamType` Base Class

`ParamType` defines the contract every type must satisfy. To implement a custom type, a subclass must:

- Set the `name` class attribute.
- Return `None` when called with `None` (handled by the default `__call__`).
- Implement `convert` to convert strings to the target type **and** accept values already of the correct type.
- Be able to convert when `ctx` and `param` are `None` (this occurs during prompt input conversion).

### Key Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `name` | `str` | Descriptive name used in error messages and help text. |
| `is_composite` | `bool` | Whether the type consumes multiple values (e.g. `Tuple`). |
| `arity` | `int` | Number of values the type consumes. |
| `envvar_list_splitter` | `str \| None` | Separator used to split list values from environment variables. `None` means whitespace; `File` and `Path` use `os.path.pathsep`. |

### Key Methods

- **`__call__(value, param, ctx)`** — The public entry point. Returns `None` for `None` input, otherwise delegates to `convert`.
- **`convert(value, param, ctx)`** — The core conversion/validation hook. Default implementation returns the value unchanged.
- **`fail(message, param, ctx)`** — Raises a `BadParameter` exception with the given message. This is the standard way for a type to signal an invalid value.
- **`get_metavar(param, ctx)`** — Returns the placeholder shown in help text (e.g. `[a|b|c]` for a `Choice`).
- **`get_missing_message(param, ctx)`** — Returns extra information shown when a required value is missing.
- **`split_envvar_value(rv)`** — Splits an environment variable value into chunks using `envvar_list_splitter`.
- **`shell_complete(ctx, param, incomplete)`** — Returns a list of `CompletionItem` objects for shell completion. Default returns an empty list.
- **`to_info_dict()`** — Returns a dictionary describing the type, used by `Context.to_info_dict()` for documentation generation.

---

## Concrete Types

### Scalar Types

#### `StringParamType` (`STRING`)
The implicit default type. Converts `bytes` to `str` using the argv encoding (falling back to the filesystem encoding and finally UTF-8 with replacement), and calls `str()` on other values.

#### `UnprocessedParamType` (`UNPROCESSED`)
A no-op type that returns the value unchanged. Unlike `STRING`, it does **not** decode bytes. Useful when working with file paths that may appear as bytes or unicode.

#### `BoolParamType` (`BOOL`)
Converts values to booleans. Accepts `True`/`False` directly, and the following string forms (case-insensitive, stripped):
- **True:** `1`, `true`, `t`, `yes`, `y`, `on`
- **False:** `0`, `false`, `f`, `no`, `n`, `off`

#### `UUIDParameterType` (`UUID`)
Converts strings to `uuid.UUID` objects, passing through existing `UUID` instances.

### Numeric Types

#### `_NumberParamTypeBase`
Shared base for numeric types. Uses the `_number_class` class attribute to perform conversion and fails with a standardized message on `ValueError`.

#### `IntParamType` (`INT`) / `FloatParamType` (`FLOAT`)
Concrete numeric types backed by `int` and `float` respectively.

#### `_NumberRangeBase`
Extends `_NumberParamTypeBase` with range validation. Constructor parameters:

| Parameter | Description |
|-----------|-------------|
| `min` / `max` | Inclusive (or exclusive) bounds. `None` means unbounded. |
| `min_open` / `max_open` | If `True`, the corresponding bound is exclusive. |
| `clamp` | If `True`, out-of-range values are clamped to the boundary instead of failing. |

The `_describe_range()` method produces a human-readable range string (e.g. `0<=x<=10`) used in error messages and `__repr__`.

#### `IntRange` / `FloatRange`
Concrete range types. `IntRange` clamps to `bound + dir` for open bounds. `FloatRange` **does not support clamping with open bounds** and raises `TypeError` at construction time if both are specified.

### Enumerated Type

#### `Choice`
Restricts a value to a fixed set of supported values. Key features:

- Accepts any iterable of choices (converted to a tuple).
- Supports non-`str` choices (since 8.2.0), including `enum.Enum` members.
- `case_sensitive` flag controls case-insensitive matching.
- **`normalize_choice(choice, ctx)`** — Maps a choice to its normalized string form. By default uses `Context.token_normalize_func` and casefolds when not case-sensitive. Can be overridden for custom normalization.
- **`get_metavar`** — Produces `{a|b|c}` for required arguments and `[a|b|c]` for options/optional arguments.
- **`shell_complete`** — Completes choices matching the incomplete value.

### Temporal Type

#### `DateTime`
Parses date strings into `datetime` objects using a configurable list of `strptime` format strings. Defaults to:
- `%Y-%m-%d`
- `%Y-%m-%dT%H:%M:%S`
- `%Y-%m-%d %H:%M:%S`

Formats are tried in order; the first successful parse wins. Existing `datetime` instances pass through unchanged.

### I/O Types

#### `File`
Declares a parameter as a file for reading or writing. The file is automatically closed when the context tears down.

| Parameter | Description |
|-----------|-------------|
| `mode` | File mode (default `"r"`). |
| `encoding` / `errors` | Text encoding and error handling. |
| `lazy` | Open on first I/O rather than immediately. Defaults to non-lazy for stdin/stdout and read files, lazy for writes. |
| `atomic` | Write to a temporary file and move it into place on completion. |

The special value `-` maps to stdin/stdout. `File` uses `os.path.pathsep` as its `envvar_list_splitter`. It delegates actual opening to `open_stream` (see [platform_and_terminal_foundation](platform_and_terminal_foundation.md)) and lazy opening to `LazyFile` (see [utils](utils.md)).

#### `Path`
Similar to `File` but returns the filename instead of an open file. Supports validation flags:

| Flag | Description |
|------|-------------|
| `exists` | The path must exist. |
| `file_okay` / `dir_okay` | Whether files/directories are acceptable. |
| `readable` / `writable` / `executable` | Permission checks. |
| `resolve_path` | Resolve to an absolute, symlink-free path. |
| `allow_dash` | Allow `-` to indicate a standard stream. |
| `path_type` | Convert the result to a specific type (e.g. `pathlib.Path`). |

The `name` attribute is dynamically set to `"file"`, `"directory"`, or `"path"` based on the `file_okay`/`dir_okay` combination.

### Composite Type

#### `Tuple`
Applies a different type to each item of a fixed-length value. Only usable when `nargs` is a fixed number. Its `arity` equals the number of sub-types, and `name` is the space-joined names of the sub-types (e.g. `<text integer>`). Conversion validates the value length and applies each sub-type in turn.

### Callable Type

#### `FuncParamType`
Wraps an arbitrary callable as a type. The callable's `__name__` becomes the type name. On `ValueError`, the value is stringified and passed to `fail`.

---

## Type Inference: `convert_type`

The `convert_type(ty, default)` function maps Python types (or default values) to the most appropriate `ParamType`:

```mermaid
flowchart TD
    A[convert_type ty, default] --> B{ty is None<br/>and default set?}
    B -- Yes --> C[Infer ty from default]
    C --> D{default is tuple/list?}
    D -- Yes --> E[Build Tuple from item types]
    D -- No --> F[ty = type default]
    B -- No --> G{ty is tuple?}
    E --> G
    F --> G
    G -- Yes --> H[Return Tuple]
    G -- No --> I{ty is ParamType?}
    I -- Yes --> J[Return ty]
    I -- No --> K{ty is str/None?}
    K -- Yes --> L[Return STRING]
    K -- No --> M{ty is int?}
    M -- Yes --> N[Return INT]
    M -- No --> O{ty is float?}
    O -- Yes --> P[Return FLOAT]
    O -- No --> Q{ty is bool?}
    Q -- Yes --> R[Return BOOL]
    Q -- No --> S{guessed_type?}
    S -- Yes --> L
    S -- No --> T[Return FuncParamType ty]
```

This function is the bridge between Python's type system and Click's type system, allowing users to pass `int`, `float`, `bool`, `str`, tuples, or custom callables as the `type=` argument of a parameter.

---

## Predefined Type Instances

The module exposes ready-to-use singleton instances for the common types:

| Constant | Type | Notes |
|----------|------|-------|
| `UNPROCESSED` | `UnprocessedParamType` | No conversion, preserves bytes. |
| `STRING` | `StringParamType` | Default type. |
| `INT` | `IntParamType` | Integer values. |
| `FLOAT` | `FloatParamType` | Floating-point values. |
| `BOOL` | `BoolParamType` | Boolean flags. |
| `UUID` | `UUIDParameterType` | UUID values. |

---

## Data Flow: Value Conversion

The following sequence diagram shows how a raw command-line value flows through the type system during command invocation.

```mermaid
sequenceDiagram
    participant Parser as parser module
    participant Param as Parameter (core)
    participant Type as ParamType
    participant Ctx as Context

    Parser->>Param: raw string value
    Param->>Type: __call__(value, param, ctx)
    alt value is None
        Type-->>Param: None
    else value present
        Type->>Type: convert(value, param, ctx)
        alt conversion succeeds
            Type-->>Param: converted Python object
        else conversion fails
            Type->>Type: fail(message, param, ctx)
            Type-->>Ctx: raise BadParameter
        end
    end
    Param-->>Ctx: store converted value
```

### Environment Variable Splitting

When a value originates from an environment variable and the type expects a list, `split_envvar_value` is used:

```mermaid
flowchart LR
    A[Env var string] --> B{envvar_list_splitter}
    B -- None --> C[Split on whitespace]
    B -- pathsep --> D[Split on : or ;]
    C --> E[Sequence of chunks]
    D --> E
```

`File` and `Path` set `envvar_list_splitter = os.path.pathsep`; all other types default to `None` (whitespace splitting).

---

## Dependencies

```mermaid
graph TD
    types[types.py]
    core[core.py]
    exceptions[exceptions.py]
    utils[utils.py]
    compat[_compat.py]
    shell_completion[shell_completion.py]

    types -->|BadParameter| exceptions
    types -->|LazyFile, format_filename, safecall| utils
    types -->|open_stream, _get_argv_encoding| compat
    types -.->|CompletionItem| shell_completion
    core -->|ParamType, convert_type| types
    shell_completion -->|ParamType.shell_complete| types
```

### Outbound Dependencies

| Dependency | Used For |
|------------|----------|
| [`exceptions.BadParameter`](exceptions.md) | Raised by `ParamType.fail` for invalid values. |
| [`utils.LazyFile`](utils.md) | Deferred file opening in `File`. |
| [`utils.format_filename`](utils.md) | Safe filename display in error messages. |
| [`utils.safecall`](utils.md) | Exception-swallowing wrappers for close/flush callbacks. |
| [`_compat.open_stream`](platform_and_terminal_foundation.md) | Opening files and standard streams. |
| [`_compat._get_argv_encoding`](platform_and_terminal_foundation.md) | Decoding bytes in `StringParamType`. |
| [`shell_completion.CompletionItem`](shell_completion.md) | Returned by `shell_complete` implementations. |

### Inbound Dependencies

- The [core module](core.md) uses `ParamType` and `convert_type` to attach types to parameters and to infer types from defaults.
- The [shell completion module](shell_completion.md) invokes `ParamType.shell_complete` to generate completions.

---

## Documentation Generation: `OptionHelpExtra`

`OptionHelpExtra` is a `TypedDict` describing the extra help information an option can contribute. It is used by the help formatting pipeline (see [formatting](formatting.md)) and the core module.

| Key | Type | Description |
|-----|------|-------------|
| `envvars` | `tuple[str, ...]` | Environment variables that can supply the value. |
| `default` | `str` | The default value shown in help. |
| `range` | `str` | The accepted range (from `_NumberRangeBase._describe_range`). |
| `required` | `str` | Required marker text. |

---

## Extension Points

To create a custom type, subclass `ParamType` and implement:

1. **`name`** — a descriptive class attribute.
2. **`convert(value, param, ctx)`** — the conversion and validation logic. Call `self.fail(...)` on invalid input.
3. Optionally override **`get_metavar`**, **`get_missing_message`**, **`shell_complete`**, and **`to_info_dict`** for richer integration.

For types that consume multiple values, subclass `CompositeParamType` and implement the `arity` property.

For numeric types with custom bounds, subclass `_NumberRangeBase` and implement `_clamp`.

---

## Related Modules

- [core](core.md) — `Parameter`, `Option`, `Argument`, `Context`, and `ParameterSource`.
- [exceptions](exceptions.md) — `BadParameter` and the exception hierarchy.
- [utils](utils.md) — `LazyFile`, `format_filename`, `safecall`.
- [shell_completion](shell_completion.md) — `CompletionItem` and shell completion backends.
- [formatting](formatting.md) — `HelpFormatter` and help text rendering.
- [platform_and_terminal_foundation](platform_and_terminal_foundation.md) — `open_stream`, `_get_argv_encoding`, and platform compatibility.
