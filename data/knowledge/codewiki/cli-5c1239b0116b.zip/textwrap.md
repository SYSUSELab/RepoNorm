# textwrap Module

## Introduction

The `textwrap` module provides a specialized text-wrapping utility for the Click CLI framework. It is a thin, purpose-built extension of Python's standard library [`textwrap.TextWrapper`](https://docs.python.org/3/library/textwrap.html) that adapts its behavior to the specific needs of terminal help-page rendering.

The module's single public component, [`TextWrapper`](#textwrapper), augments the standard wrapper with three capabilities that the standard library does not offer out of the box:

1. **Long-word handling tuned for narrow terminals** — a reimplementation of `_handle_long_word` that guarantees at least one character of progress per line.
2. **Scoped indentation** — an `extra_indent` context manager that temporarily adds indentation to both the initial and subsequent lines.
3. **Indent-only mode** — an `indent_only` method that applies indentation without performing any wrapping.

This module sits in the **platform_and_terminal_foundation** layer of the framework and is consumed primarily by the help-formatting subsystem (see [formatting.md](formatting.md)).

---

## Module Position in the System

The `textwrap` module is a low-level, dependency-free utility. It depends only on the Python standard library and is consumed by higher-level formatting code.

```mermaid
graph TD
    subgraph "platform_and_terminal_foundation"
        TW["textwrap<br/>(TextWrapper)"]
        COMPAT["compat<br/>(_FixupStream, _AtomicFile)"]
        WIN["winconsole"]
        TERM["termui_impl<br/>(Editor, ProgressBar)"]
    end

    subgraph "cli_framework_core"
        FMT["formatting<br/>(HelpFormatter)"]
        CORE["core<br/>(Command, Context, ...)"]
    end

    FMT -->|"wrap_text / TextWrapper"| TW
    CORE -->|"renders help via"| FMT
    FMT -.->|"terminal width"| COMPAT

    style TW fill:#f9f,stroke:#333,stroke-width:2px
```

The module is intentionally isolated: it has **no internal Click dependencies**, which makes it safe to import from anywhere in the framework without risking circular imports.

---

## Core Component: `TextWrapper`

`TextWrapper` subclasses `textwrap.TextWrapper` and overrides or adds the following members.

### Class Overview

```mermaid
classDiagram
    class TextWrapper {
        +_handle_long_word(reversed_chunks, cur_line, cur_len, width)
        +extra_indent(indent) Iterator~None~
        +indent_only(text) str
    }
    class StdTextWrapper {
        <<stdlib>>
        +initial_indent
        +subsequent_indent
        +break_long_words
        +width
        +wrap(text)
        +fill(text)
    }
    StdTextWrapper <|-- TextWrapper
```

### Inherited Configuration

Because `TextWrapper` extends the standard library class, it inherits all of its configuration attributes. The most relevant for Click's usage are:

| Attribute | Purpose |
|-----------|---------|
| `width` | Maximum line length before wrapping. |
| `initial_indent` | String prepended to the first line of output. |
| `subsequent_indent` | String prepended to all lines after the first. |
| `break_long_words` | Whether words longer than `width` may be broken. |
| `break_on_hyphens` | Whether to break on hyphens. |
| `replace_whitespace` | Whether to collapse whitespace. |

These attributes are mutated by `extra_indent` and read by `indent_only`.

---

### Method: `_handle_long_word`

```python
def _handle_long_word(
    self,
    reversed_chunks: list[str],
    cur_line: list[str],
    cur_len: int,
    width: int,
) -> None:
```

This override replaces the standard library's long-word handler. It is invoked by the inherited `wrap()` machinery whenever a single word is longer than the available `width`.

**Behavior:**

- Computes `space_left = max(width - cur_len, 1)`, guaranteeing **at least one character** of progress even when the current line is already full. This prevents infinite loops that can occur with the standard implementation in edge cases.
- If `break_long_words` is enabled, it splits the last chunk: the first `space_left` characters are appended to `cur_line`, and the remainder is written back into `reversed_chunks` for the next iteration.
- If `break_long_words` is disabled **and** the current line is empty, it moves the entire oversized word onto the current line (accepting an over-long line rather than dropping content).

```mermaid
flowchart TD
    A["_handle_long_word called"] --> B["space_left = max(width - cur_len, 1)"]
    B --> C{"break_long_words?"}
    C -->|Yes| D["cut = last[:space_left]<br/>res = last[space_left:]"]
    D --> E["cur_line.append(cut)<br/>reversed_chunks[-1] = res"]
    C -->|No| F{"cur_line empty?"}
    F -->|Yes| G["cur_line.append(reversed_chunks.pop())"]
    F -->|No| H["do nothing"]
```

---

### Method: `extra_indent`

```python
@contextmanager
def extra_indent(self, indent: str) -> cabc.Iterator[None]:
```

A context manager that temporarily increases both `initial_indent` and `subsequent_indent` by the given `indent` string. On exit (including on exception), the original indentation values are restored.

This is used to render nested content — for example, indenting the body of a help section relative to its heading — without permanently mutating the wrapper's configuration.

```mermaid
sequenceDiagram
    participant Caller
    participant TW as TextWrapper
    Caller->>TW: with extra_indent("  ")
    TW->>TW: save old initial/subsequent indent
    TW->>TW: initial_indent += "  "
    TW->>TW: subsequent_indent += "  "
    Caller->>TW: wrap(text)  (indented output)
    Caller->>TW: __exit__
    TW->>TW: restore old indents
```

---

### Method: `indent_only`

```python
def indent_only(self, text: str) -> str:
```

Applies indentation to an already-formatted block of text **without wrapping**. Each line is prefixed with `initial_indent` (first line) or `subsequent_indent` (all remaining lines), and the lines are rejoined with newlines.

This is useful when the caller has already wrapped the text and only needs consistent indentation applied — for instance, when re-indenting pre-wrapped help output.

```mermaid
flowchart LR
    A["text.splitlines()"] --> B{"idx == 0?"}
    B -->|Yes| C["indent = initial_indent"]
    B -->|No| D["indent = subsequent_indent"]
    C --> E["rv.append(indent + line)"]
    D --> E
    E --> F["'\\n'.join(rv)"]
```

---

## Data Flow

The following diagram shows how text flows through `TextWrapper` when used by the help formatter.

```mermaid
flowchart TD
    INPUT["Raw help text / argument list"] --> WRAP["TextWrapper.wrap()<br/>(inherited)"]
    WRAP --> HLW["_handle_long_word()<br/>(override)"]
    HLW --> WRAP
    WRAP --> OUT["Wrapped lines"]

    INPUT2["Pre-wrapped text"] --> IO["indent_only()"]
    IO --> OUT2["Indented text"]

    subgraph "Scoped indentation"
        EI["extra_indent(indent)"] -.->|"mutates"| WRAP
        EI -.->|"mutates"| IO
    end
```

---

## Integration with the Help Formatter

The primary consumer of this module is [`HelpFormatter`](formatting.md) in the **cli_framework_core** layer. `HelpFormatter` uses a `TextWrapper` instance (via its `wrap_text` helper) to:

- Wrap usage lines (`write_usage`).
- Re-wrap and re-indent descriptive text while preserving paragraphs (`write_text`).
- Format definition lists of options and commands (`write_dl`).

The `extra_indent` context manager aligns with `HelpFormatter`'s `indentation()` and `section()` context managers, which manage the formatter's own `current_indent` state. Together they produce consistently indented, width-aware help output.

```mermaid
graph LR
    HF["HelpFormatter"] -->|"write_text / write_dl"| WT["wrap_text()"]
    WT --> TW["TextWrapper"]
    HF -->|"indentation() / section()"| IND["current_indent state"]
    TW -.->|"extra_indent aligns with"| IND
```

---

## Design Notes

- **No external dependencies.** The module imports only `collections.abc`, `textwrap`, and `contextlib`, keeping it usable in any layer.
- **Subclassing over composition.** By extending the standard `TextWrapper`, Click reuses the entire wrapping algorithm and only overrides the specific behavior that differs.
- **Exception-safe indentation.** `extra_indent` uses `try/finally` to guarantee restoration of indentation state, preventing configuration leakage between formatting operations.
- **Progress guarantee.** The `max(width - cur_len, 1)` computation in `_handle_long_word` is a deliberate robustness measure against pathological inputs.

---

## Related Modules

- [formatting.md](formatting.md) — `HelpFormatter`, the primary consumer of this module.
- [compat.md](compat.md) — platform compatibility utilities used alongside text wrapping for terminal width detection.
- [core.md](core.md) — the command/context layer that ultimately renders help pages.
