# Exceptions Module

## Introduction

The `exceptions` module (`src/click/exceptions.py`) defines the exception hierarchy used throughout Click to signal, format, and display errors to end users. It provides a small but carefully designed set of exception classes that:

- Distinguish between **user-facing errors** (which Click formats and prints) and **internal control-flow signals** (which Click catches to abort or exit).
- Carry **contextual information** (the `Context`, the offending `Parameter`, or a `param_hint`) so that error messages can be rendered with the correct usage line, help hint, and parameter name.
- Attach **exit codes** so that standalone-mode invocations terminate with the appropriate status.

This module is a foundational dependency for the [core](core.md) module (which raises these exceptions during parsing and invocation) and is consumed by the [parser](parser.md) and [formatting](formatting.md) modules indirectly through the command lifecycle.

---

## Architecture Overview

The exception hierarchy is rooted at two independent base classes: `ClickException` (user-facing, printable errors) and `RuntimeError` (internal control-flow signals). All user-facing errors derive from `ClickException`, while `Abort` and `Exit` derive directly from `RuntimeError`.

```mermaid
classDiagram
    class Exception
    class RuntimeError
    class ClickException {
        +int exit_code = 1
        +bool show_color
        +str message
        +format_message() str
        +show(file) None
    }
    class UsageError {
        +int exit_code = 2
        +Context ctx
        +Command cmd
        +show(file) None
    }
    class BadParameter {
        +Parameter param
        +str param_hint
        +format_message() str
    }
    class MissingParameter {
        +str param_type
        +format_message() str
    }
    class NoSuchOption {
        +str option_name
        +Sequence possibilities
        +format_message() str
    }
    class BadOptionUsage {
        +str option_name
    }
    class BadArgumentUsage
    class NoArgsIsHelpError {
        +show(file) None
    }
    class FileError {
        +str ui_filename
        +str filename
        +format_message() str
    }
    class Abort
    class Exit {
        +int exit_code
    }

    Exception <|-- ClickException
    ClickException <|-- UsageError
    ClickException <|-- FileError
    UsageError <|-- BadParameter
    UsageError <|-- NoSuchOption
    UsageError <|-- BadOptionUsage
    UsageError <|-- BadArgumentUsage
    UsageError <|-- NoArgsIsHelpError
    BadParameter <|-- MissingParameter
    RuntimeError <|-- Abort
    RuntimeError <|-- Exit
```

### Two Categories of Exceptions

| Category | Base Class | Purpose | Handled By |
|----------|-----------|---------|------------|
| **User-facing errors** | `ClickException` | Report a problem to the user with a formatted message and exit code. | `Command.main` catches these, calls `.show()`, and exits with `.exit_code`. |
| **Control-flow signals** | `RuntimeError` (`Abort`, `Exit`) | Signal Click to abort or exit without being treated as an error. | `Command.main` catches these and terminates the process (or returns the exit code in non-standalone mode). |

---

## Component Reference

### `ClickException`

The base class for all exceptions that Click can handle and display to the user.

- **`exit_code`** (class attribute, default `1`): The process exit code used when the exception propagates to `Command.main`.
- **`show_color`**: The color setting is resolved at construction time via `resolve_color_default()` and cached, because the `Context` may be torn down before the message is printed.
- **`format_message()`**: Returns the raw message. Subclasses override this to produce richer, context-aware messages.
- **`show(file=None)`**: Prints `Error: {message}` to the given file (defaulting to `get_text_stderr()`), honoring the cached color setting.

### `UsageError`

Signals that the user invoked the command incorrectly. This is the most important subclass because it carries the `Context` needed to render the usage line.

- **`exit_code = 2`** (overrides the base `1`).
- **`ctx`**: The context that caused the error. Click fills this in automatically in many situations.
- **`cmd`**: Convenience reference to `ctx.command`.
- **`show()`**: Renders the command's usage line, an optional "Try '{command} {option}' for help." hint (only if the command has a help option), and the error message. Color is taken from `ctx.color`.

### `BadParameter`

Formats a standardized "Invalid value for ..." message for a bad parameter. It is typically raised from a parameter callback or a `ParamType` conversion, and Click attaches the offending `Parameter` automatically.

- **`param`**: The parameter that caused the error.
- **`param_hint`**: An alternative to `param` for custom validation; a string is used verbatim, a sequence is joined with `" / "` and each item is `repr`-quoted (via `_join_param_hints`).
- **`format_message()`**: Produces `Invalid value for {param_hint}: {message}`, falling back to `Invalid value: {message}` when no hint is available. The hint is derived from `param.get_error_hint(ctx)` when `param` is set.

### `MissingParameter`

A specialization of `BadParameter` raised when a required option or argument is not provided.

- **`param_type`**: One of `'parameter'`, `'option'`, or `'argument'`; defaults to the value inherited from `param.param_type_name`.
- **`format_message()`**: Builds a message of the form `Missing {type}{hint}.{extra}`, where the extra text comes from `param.type.get_missing_message(...)`. Known types are translated to localized strings (`Missing argument`, `Missing option`, `Missing parameter`).
- **`__str__()`**: Returns a concise `Missing parameter: {name}` when no message was supplied.

### `NoSuchOption`

Raised when an unknown option is encountered. It can carry a list of `possibilities` to produce a "Did you mean ...?" suggestion.

- **`option_name`**: The unrecognized option.
- **`possibilities`**: Candidate option names used to build a suggestion via `ngettext`.
- **`format_message()`**: Appends `Did you mean {possibility}?` (single) or `(Possible options: ...)` (multiple) to the base message.

### `BadOptionUsage`

Raised when an option is supplied but used incorrectly (e.g., wrong number of arguments). Stores the offending `option_name`.

### `BadArgumentUsage`

Raised when an argument is supplied but used incorrectly (e.g., wrong number of values). It adds no extra state beyond `UsageError`.

### `NoArgsIsHelpError`

A specialized `UsageError` raised by `Command.parse_args` when `no_args_is_help` is enabled and no arguments are given. Its message is the command's full help text, and its `show()` method prints that help to stderr rather than the standard error format.

### `FileError`

Raised when a file cannot be opened. It stores both the raw `filename` and a display-safe `ui_filename` produced by `format_filename` (which replaces invalid bytes/surrogates with the replacement character).

- **`format_message()`**: Produces `Could not open file {filename!r}: {message}`.

### `Abort`

An internal signalling exception (subclass of `RuntimeError`) that tells Click to abort. It carries no payload. `Command.main` catches it, prints `Aborted!`, and exits with code `1`.

### `Exit`

An internal signalling exception (subclass of `RuntimeError`) that indicates the application should exit with a specific status code.

- **`exit_code`**: The status code (default `0`), stored via `__slots__` for a minimal footprint.
- `Context.exit()` closes registered resources before raising `Exit`.

---

## Exception Flow

The following diagram shows how exceptions flow through the command lifecycle, from being raised during parsing/invocation to being handled by `Command.main`.

```mermaid
sequenceDiagram
    participant User
    participant Command as Command.main
    participant Parse as Command.parse_args
    participant Param as Parameter.handle_parse_result
    participant Exc as exceptions module

    User->>Command: invoke CLI
    Command->>Parse: parse_args(ctx, args)
    Parse->>Param: handle_parse_result(...)
    Param->>Exc: raise BadParameter / MissingParameter
    Exc-->>Parse: propagate
    Parse-->>Command: propagate
    Command->>Exc: e.show()
    Exc-->>User: print usage + error message
    Command->>User: sys.exit(e.exit_code)
```

### Handling in `Command.main`

`Command.main` wraps invocation in a layered `try/except` that maps each exception type to a behavior:

```mermaid
flowchart TD
    A[Invoke command] --> B{Exception?}
    B -->|EOFError / KeyboardInterrupt| C[raise Abort]
    B -->|ClickException| D{standalone_mode?}
    D -->|Yes| E[e.show&#40;&#41;; sys.exit&#40;e.exit_code&#41;]
    D -->|No| F[re-raise]
    B -->|OSError EPIPE| G[Pacify streams; sys.exit&#40;1&#41;]
    B -->|Exit| H{standalone_mode?}
    H -->|Yes| I[sys.exit&#40;e.exit_code&#41;]
    H -->|No| J[return e.exit_code]
    B -->|Abort| K{standalone_mode?}
    K -->|Yes| L[echo 'Aborted!'; sys.exit&#40;1&#41;]
    K -->|No| M[re-raise]
```

---

## Dependencies

The module depends on a small set of helpers from sibling modules. These are referenced rather than reimplemented here.

```mermaid
graph LR
    EXC[exceptions.py]
    EXC --> COMPAT["_compat.get_text_stderr"]
    EXC --> GLOBALS["globals.resolve_color_default"]
    EXC --> UTILS["utils.echo, utils.format_filename"]
    EXC -.TYPE_CHECKING.-> CORE["core.Command, Context, Parameter"]
    CORE -.raises.-> EXC
    PARSER["parser"] -.raises.-> EXC
```

| Dependency | Source Module | Usage |
|------------|---------------|-------|
| `get_text_stderr` | [_compat](compat.md) | Default output stream for `show()`. |
| `resolve_color_default` | [globals](globals.md) | Resolves the color flag at construction time. |
| `echo` | [utils](utils.md) | Writes formatted messages to streams. |
| `format_filename` | [utils](utils.md) | Produces display-safe filenames for `FileError`. |
| `Command`, `Context`, `Parameter` | [core](core.md) | Type-only imports (under `TYPE_CHECKING`) to avoid circular imports. |

> **Note on circular imports:** `core.py` imports from `exceptions.py`, so `exceptions.py` imports `Command`, `Context`, and `Parameter` only under `if t.TYPE_CHECKING:` to break the cycle at runtime.

---

## Integration with the Core Module

The exceptions module is tightly coupled to the [core](core.md) module. Key integration points:

- **`Context.fail(message)`** raises `UsageError(message, self)`.
- **`Context.abort()`** raises `Abort()`.
- **`Context.exit(code)`** closes resources and raises `Exit(code)`.
- **`Parameter.process_value`** raises `MissingParameter` for missing required values.
- **`Parameter.type_cast_value`** raises `BadParameter` for non-iterable or wrong-arity values.
- **`Command.parse_args`** raises `NoArgsIsHelpError` when `no_args_is_help` is set and no args are given.
- **`Command.main`** is the central handler that catches `ClickException`, `Abort`, and `Exit`.

The `augment_usage_errors` context manager (defined in `core.py`) attaches the current `Context` and `Parameter` to `UsageError`/`BadParameter` instances raised inside parameter processing, ensuring error messages are fully contextualized even when the raiser did not supply them.

---

## Design Notes

- **Cached color:** `ClickException.__init__` caches `resolve_color_default()` because the `Context` may be gone by the time `show()` runs.
- **Localization:** All user-facing strings are wrapped with `gettext`/`ngettext` for translation.
- **Exit codes:** `ClickException` defaults to `1`, `UsageError` to `2`, and `Exit` to `0` — matching conventional Unix exit-code semantics.
- **`__slots__` on `Exit`:** Minimizes the object footprint for a frequently-raised control-flow signal.
- **Separation of concerns:** `Abort` and `Exit` deliberately do **not** inherit from `ClickException`, so they are never treated as printable errors.

---

## Related Documentation

- [core](core.md) — `Command`, `Context`, and `Parameter`, which raise and handle these exceptions.
- [parser](parser.md) — the option parser that triggers `NoSuchOption` and related errors.
- [formatting](formatting.md) — `HelpFormatter`, used to render usage lines shown by `UsageError.show()`.
- [utils](utils.md) — `echo` and `format_filename` helpers.
- [compat](compat.md) — `get_text_stderr` and stream handling.
- [globals](globals.md) — `resolve_color_default` and the current-context stack.
