# Formatting Module

## Introduction

The `formatting` module (`src/click/formatting.py`) is responsible for rendering text-based help pages for the Click CLI framework. It provides the low-level primitives that turn structured help data (usage strings, headings, paragraphs, and definition lists of options/commands) into neatly wrapped, terminal-width-aware text.

The module is intentionally decoupled from the command model: it does not know about `Command`, `Option`, or `Parameter` objects. Instead, the [core module](core.md) collects help data and hands it to the formatter as plain strings and tuples. This separation keeps the formatting logic reusable and independently testable.

The module exposes one primary class, `HelpFormatter`, plus a set of module-level helper functions (`measure_table`, `iter_rows`, `wrap_text`, `join_options`) and a global `FORCED_WIDTH` override used by the test system.

---

## Architecture Overview

The formatting module sits between the command model (which produces help content) and the terminal output layer (which provides width and ANSI-aware length measurement).

```mermaid
graph TD
    subgraph "Command Model"
        CORE["core.py<br/>Command / Group / Option / Parameter"]
    end

    subgraph "Formatting Module"
        HF["HelpFormatter"]
        WT["wrap_text()"]
        MT["measure_table()"]
        IR["iter_rows()"]
        JO["join_options()"]
        FW["FORCED_WIDTH"]
    end

    subgraph "Supporting Modules"
        TW["_textwrap.TextWrapper"]
        COMPAT["_compat.term_len()"]
        PARSER["parser._split_opt()"]
    end

    CORE -->|"usage, headings,<br/>dl rows"| HF
    HF --> WT
    HF --> MT
    HF --> IR
    HF --> JO
    WT --> TW
    HF --> COMPAT
    WT --> COMPAT
    MT --> COMPAT
    JO --> PARSER
    FW -.->|"overrides width"| HF
```

---

## Core Component: `HelpFormatter`

`HelpFormatter` accumulates formatted output into an in-memory buffer (`self.buffer`) and exposes methods to write each kind of help element. It always writes into memory; the caller retrieves the final string via `getvalue()`.

### Construction and Width Resolution

```python
HelpFormatter(indent_increment=2, width=None, max_width=None)
```

| Parameter | Description |
|-----------|-------------|
| `indent_increment` | Number of spaces added per indentation level (default `2`). |
| `width` | Explicit text width. If `None`, falls back to `FORCED_WIDTH`, then to the terminal width. |
| `max_width` | Upper bound for the auto-detected terminal width (default `80`). |

When `width` is not supplied, the effective width is computed as:

```
width = max(min(terminal_columns, max_width) - 2, 50)
```

This clamps the terminal width to a maximum of `max_width` (minus a 2-column margin) and enforces a minimum of 50 columns so output remains readable on narrow terminals.

### State

| Attribute | Purpose |
|-----------|---------|
| `current_indent` | Current indentation level in spaces. |
| `buffer` | List of string fragments accumulated during formatting. |

### Methods

| Method | Purpose |
|--------|---------|
| `write(string)` | Appends a raw string to the buffer. |
| `indent()` / `dedent()` | Increase / decrease `current_indent` by `indent_increment`. |
| `write_usage(prog, args, prefix)` | Writes a usage line, wrapping arguments to fit. |
| `write_heading(heading)` | Writes a section heading followed by `:`. |
| `write_paragraph()` | Inserts a blank line separator if the buffer is non-empty. |
| `write_text(text)` | Writes re-indented, paragraph-preserving wrapped text. |
| `write_dl(rows, col_max, col_spacing)` | Writes a two-column definition list (options/commands). |
| `section(name)` | Context manager: paragraph + heading + indent. |
| `indentation()` | Context manager: temporary indent increase. |
| `getvalue()` | Returns the joined buffer contents. |

---

## Helper Functions

### `measure_table(rows)`

Computes the maximum width of each column across all rows, returning a tuple of column widths. Uses `term_len` so ANSI escape sequences do not inflate the measured width.

### `iter_rows(rows, col_count)`

Normalizes rows to a fixed column count by padding short rows with empty strings. This guarantees downstream code can unpack a consistent number of columns.

### `wrap_text(text, width=78, initial_indent="", subsequent_indent="", preserve_paragraphs=False)`

The central text-wrapping routine. It:

1. Expands tabs.
2. Builds a `TextWrapper` (from [_textwrap](platform_and_terminal_foundation.md)) with the requested indents and `replace_whitespace=False`.
3. If `preserve_paragraphs` is `False`, performs a simple `fill`.
4. If `preserve_paragraphs` is `True`, splits the text into paragraphs (separated by blank lines), detects each paragraph's leading indentation, and re-wraps each paragraph independently. A paragraph whose first line is the `\b` (backspace) marker is emitted verbatim via `indent_only` (no rewrapping).

### `join_options(options)`

Given a sequence of option strings (e.g. `["-f", "--file"]`), it:

- Splits each option into its prefix and body using `_split_opt` (from the [parser module](parser.md)).
- Sorts options by prefix length so short flags appear first.
- Joins them with `", "`.
- Returns `(formatted_string, any_prefix_is_slash)`, where the boolean flags whether any option used the Windows-style `/` prefix.

---

## Data Flow

The following diagram shows how help content flows from the command model through the formatter to the final string.

```mermaid
sequenceDiagram
    participant Cmd as Command (core.py)
    participant HF as HelpFormatter
    participant Wrap as wrap_text()
    participant TW as TextWrapper
    participant Compat as term_len()

    Cmd->>HF: HelpFormatter(width=...)
    Cmd->>HF: write_usage(prog, args)
    HF->>Wrap: wrap_text(args, ...)
    Wrap->>TW: fill / indent_only
    TW-->>Wrap: wrapped text
    Wrap-->>HF: wrapped text
    HF->>HF: buffer.append(...)

    Cmd->>HF: section("Options")
    HF->>HF: write_paragraph + write_heading + indent

    Cmd->>HF: write_dl(rows)
    HF->>HF: measure_table(rows)
    HF->>Compat: term_len(col)
    Compat-->>HF: visible width
    HF->>Wrap: wrap_text(second, ...)
    Wrap-->>HF: wrapped value
    HF->>HF: buffer.append(...)

    Cmd->>HF: getvalue()
    HF-->>Cmd: full help string
```

---

## Definition List Formatting

`write_dl` is the most involved method, as it renders the two-column layout used for options and subcommands. Its process is:

```mermaid
flowchart TD
    A["write_dl(rows, col_max, col_spacing)"] --> B["measure_table(rows)"]
    B --> C{"len(widths) == 2?"}
    C -- No --> D["raise TypeError"]
    C -- Yes --> E["first_col = min(widths[0], col_max) + col_spacing"]
    E --> F["for each row in iter_rows(...)"]
    F --> G["write indented first column"]
    G --> H{"second column empty?"}
    H -- Yes --> I["write newline, continue"]
    H -- No --> J{"term_len(first) <= first_col - col_spacing?"}
    J -- Yes --> K["pad with spaces to first_col"]
    J -- No --> L["newline + indent to first_col"]
    K --> M["wrap second column to text_width"]
    L --> M
    M --> N["write first line, indent subsequent lines"]
    N --> F
```

Key behaviors:

- The first column width is capped at `col_max` (default `30`) to prevent a single long option from pushing all descriptions far to the right.
- `col_spacing` (default `2`) controls the gap between columns.
- The second column's wrap width is `max(self.width - first_col - 2, 10)`, guaranteeing at least 10 columns.
- Descriptions are wrapped with `preserve_paragraphs=True`, so multi-paragraph help text is respected.

---

## Context Managers

Two context managers simplify indentation management and guarantee balanced indent/dedent calls even when exceptions occur.

```mermaid
stateDiagram-v2
    [*] --> Idle
    Idle --> Indented: section() / indentation()
    Indented --> Idle: dedent() in finally
    note right of Indented
        write_paragraph + write_heading
        (section only) then indent
    end note
```

- `section(name)`: writes a paragraph break, a heading, then indents for the duration of the block.
- `indentation()`: only increases indentation for the duration of the block.

Both use `try/finally` to ensure `dedent()` always runs.

---

## Dependencies

| Dependency | Source Module | Usage |
|------------|---------------|-------|
| `term_len` | [_compat](platform_and_terminal_foundation.md) | ANSI-aware visible string length for column measurement and wrapping decisions. |
| `_split_opt` | [parser](parser.md) | Splits option strings into prefix/body for `join_options`. |
| `TextWrapper` | [_textwrap](platform_and_terminal_foundation.md) | Underlying wrapping engine with `extra_indent` and `indent_only` extensions. |
| `shutil.get_terminal_size` | stdlib | Auto-detects terminal width when no width is forced. |

```mermaid
graph LR
    FORMATTING["formatting.py"]
    FORMATTING --> COMPAT["_compat.py<br/>term_len"]
    FORMATTING --> PARSER["parser.py<br/>_split_opt"]
    FORMATTING --> TEXTWRAP["_textwrap.py<br/>TextWrapper"]
    FORMATTING --> STDLIB["stdlib<br/>shutil, gettext, contextlib"]
```

---

## Testing Support

The module-level `FORCED_WIDTH` global allows the test system to pin the output width deterministically, bypassing terminal auto-detection. When set, `HelpFormatter` uses it as the width unless an explicit `width` argument is provided. This is exercised by the [testing module](testing.md).

---

## Related Modules

- [core](core.md) — Produces the help content (usage, options, commands) consumed by `HelpFormatter`.
- [parser](parser.md) — Provides `_split_opt` used by `join_options`.
- [platform_and_terminal_foundation](platform_and_terminal_foundation.md) — Provides `term_len` and `TextWrapper`.
- [testing](testing.md) — Uses `FORCED_WIDTH` to produce deterministic help output in tests.
