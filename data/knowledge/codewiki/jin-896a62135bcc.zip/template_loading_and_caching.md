# Template Loading and Caching

## Purpose

The `template_loading_and_caching` module is responsible for locating, retrieving, and caching Jinja2 templates. It decouples the template *source* (where templates come from) from the template *environment* (how templates are compiled and rendered), and it provides a persistent bytecode cache so that expensive compilation work can be reused across process restarts.

The module consists of two cooperating subsystems:

- **Loaders** (`src/jinja2/loaders.py`) — abstract and concrete implementations of template retrieval. Loaders resolve a template name to its source text (and optionally a filename, uptodate check, and bytecode cache). They support filesystem, package, dictionary, function, and prefix-based sources, as well as a choice loader that tries multiple loaders in order.
- **Bytecode cache** (`src/jinja2/bccache.py`) — a backend-agnostic cache for compiled template code. It stores the generated Python bytecode keyed by template name and a checksum of the source, so that unchanged templates can be loaded without re-parsing and re-compiling.

Together these components let Jinja2 efficiently serve templates from arbitrary storage while avoiding redundant compilation.

## Architecture

```mermaid
graph TD
    subgraph Environment
        E[Environment]
    end

    subgraph "Template Loading and Caching"
        subgraph Loaders
            BL[BaseLoader]
            FL[FileSystemLoader]
            PL[PackageLoader]
            DL[DictLoader]
            FnL[FunctionLoader]
            PFL[PrefixLoader]
            CL[ChoiceLoader]
            ML[ModuleLoader]
        end

        subgraph "Bytecode Cache"
            BC[BytecodeCache]
            FBC[FileSystemBytecodeCache]
            MBC[MemcachedBytecodeCache]
        end
    end

    E -->|get_template / get_or_select_template| BL
    BL --> FL
    BL --> PL
    BL --> DL
    BL --> FnL
    BL --> PFL
    BL --> CL
    BL --> ML

    BL -->|get_source| SRC[Template Source]
    BL -->|load| BC
    BC --> FBC
    BC --> MBC

    SRC -->|compile| E
    BC -->|cached bytecode| E
```

The `Environment` delegates template lookup to a configured loader. The loader returns the template source along with metadata (filename, uptodate callable, and an optional bytecode cache). The environment then either compiles the source or reuses cached bytecode from the configured `BytecodeCache` backend.

## Core Components

- [Loaders](./loaders.md) — `BaseLoader` and its concrete subclasses (`FileSystemLoader`, `PackageLoader`, `DictLoader`, `FunctionLoader`, `PrefixLoader`, `ChoiceLoader`, `ModuleLoader`), which define how template names map to source content.
- [Bytecode Cache](./bytecode_cache.md) — `BytecodeCache` and its backends (`FileSystemBytecodeCache`, `MemcachedBytecodeCache`), which persist compiled template code and validate it against source checksums.