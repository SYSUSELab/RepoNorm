# Template Parsing Frontend

## Purpose

The `template_parsing_frontend` module is the entry point of the Jinja2 template compilation pipeline. It is responsible for transforming raw template source text into an abstract syntax tree (AST) that downstream stages (compilation and code generation) can consume. This stage performs lexical analysis, syntactic parsing, AST node representation, and tree traversal utilities.

The frontend is deliberately decoupled from code generation and runtime execution: it produces a language-agnostic AST (`nodes.py`) that the compiler later walks to emit Python code. This separation allows the parser to be reused for tooling such as static analysis, syntax highlighting, and template introspection.

## Architecture

The module is composed of four cooperating components that form a linear pipeline, with the visitor providing a generic traversal mechanism used across the AST:

```mermaid
flowchart LR
    A[Template Source<br/>string] --> B[lexer.py<br/>Tokenization]
    B -->|TokenStream| C[parser.py<br/>Recursive-descent parsing]
    C -->|AST| D[nodes.py<br/>Node classes]
    D --> E[visitor.py<br/>NodeVisitor / NodeTransformer]
    E --> F[Downstream:<br/>compiler / optimizer / meta]

    subgraph template_parsing_frontend
        B
        C
        D
        E
    end
```

### Component responsibilities

- **`lexer.py`** — Splits raw template text into a stream of tokens. It handles Jinja delimiters (`{{ }}`, `{% %}`, `{# #}`), whitespace control, line statements, and raw blocks. It exposes `Lexer`, `Token`, `TokenStream`, and `describe_token`/`describe_token_expr` helpers.
- **`parser.py`** — A recursive-descent parser that consumes the token stream and builds an AST. It implements the grammar for expressions, statements, blocks, inheritance, macros, filters, tests, and control structures. The public entry point is `Parser.parse()`.
- **`nodes.py`** — Defines the AST node hierarchy (`Node`, `Stmt`, `Expr`, and concrete subclasses such as `Template`, `For`, `If`, `Name`, `Getattr`, `Call`, etc.). Nodes carry source location metadata (`lineno`) and support `find`, `find_all`, and `iter_child_nodes` for tree inspection.
- **`visitor.py`** — Provides `NodeVisitor` and `NodeTransformer` base classes implementing the visitor pattern over the AST. These are used by the compiler, optimizer, and analysis tools to walk or rewrite the tree without coupling to specific node types.

### Data flow

1. The `Environment` invokes the lexer on the template source.
2. The lexer emits a `TokenStream`.
3. The parser consumes the stream and produces a `nodes.Template` root node.
4. The AST is passed to the compiler (or other consumers), which uses `visitor.py` to traverse it.

## Core Components

- [Lexer](./lexer.md) — tokenization of template source, delimiter handling, and token stream utilities.
- [Parser](./parser.md) — recursive-descent parser producing the AST.
- [Nodes](./nodes.md) — AST node class hierarchy and tree inspection helpers.
- [Visitor](./visitor.md) — generic `NodeVisitor` and `NodeTransformer` traversal utilities.