# Meta Module

## Introduction

The `meta` module (`src/jinja2/meta.py`) provides **introspection utilities** for Jinja2 templates. It exposes information about a parsed template's Abstract Syntax Tree (AST) that is useful for static analysis, dependency tracking, and tooling — without ever rendering the template.

The module answers two key questions about a template:

1. **Which variables will be looked up from the context at runtime?** — via `find_undeclared_variables`.
2. **Which other templates does this template reference?** — via `find_referenced_templates`.

These capabilities are essential for build systems, linters, IDE integrations, and incremental rebuild pipelines (e.g., "rebuild this page if its layout template changes").

The module is intentionally small. Its central trick is to **reuse the compiler's code generator** as a static analysis engine: instead of emitting Python source, it walks the AST and records which names would need to be resolved from the runtime context.

---

## Core Components

| Component | Kind | Purpose |
|-----------|------|---------|
| `TrackingCodeGenerator` | Class | A `CodeGenerator` subclass that records undeclared identifiers instead of writing code. |
| `find_undeclared_variables` | Function | Returns the set of variables resolved from the context at runtime. |
| `find_referenced_templates` | Function | Yields template names referenced by `extends`, `include`, `import`, and `from ... import`. |

---

## Architecture

The `meta` module sits in the **compilation and codegen** layer of Jinja2. It depends on the compiler and the AST node definitions, but is itself a leaf consumer — nothing in the core rendering pipeline depends on it.

```mermaid
graph TD
    subgraph "Compilation & Codegen"
        CG["CodeGenerator<br/>(compiler.py)"]
        FR["Frame<br/>(compiler.py)"]
        SYM["Symbols<br/>(idtracking.py)"]
        TCG["TrackingCodeGenerator<br/>(meta.py)"]
        OPT["Optimizer<br/>(optimizer.py)"]
    end

    subgraph "Template Parsing Frontend"
        NODES["nodes.py<br/>(Template, Node, Extends,<br/>Include, Import, FromImport)"]
        PARSER["Parser<br/>(parser.py)"]
    end

    subgraph "Runtime & API"
        ENV["Environment<br/>(environment.py)"]
    end

    TCG -->|extends| CG
    CG --> FR
    CG --> OPT
    FR --> SYM
    TCG -->|reads symbols.loads| SYM
    TCG -->|reads environment.globals| ENV
    TCG -->|visits| NODES
    PARSER -->|produces| NODES
    ENV -->|parse| PARSER
```

### Key Relationships

- **`TrackingCodeGenerator` → `CodeGenerator`**: Inherits the full AST visitor machinery. It overrides `write` (to suppress output) and `enter_frame` (to capture undeclared names).
- **`TrackingCodeGenerator` → `Frame` / `Symbols`**: During traversal, each `Frame` carries a `Symbols` object whose `loads` dictionary maps identifiers to load instructions. The generator inspects these to find names that must be resolved from the context.
- **`TrackingCodeGenerator` → `Environment`**: Uses `environment.globals` to filter out names that are provided globally (and therefore not "undeclared").
- **`find_referenced_templates` → `nodes`**: Uses `Node.find_all` to locate reference nodes (`Extends`, `FromImport`, `Import`, `Include`) and inspects their `template` field.

See [compilation_and_codegen](compilation_and_codegen.md) for details on the compiler, frames, and symbol tracking, and [template_parsing_frontend](template_parsing_frontend.md) for the AST node model.

---

## Component Details

### `TrackingCodeGenerator`

```python
class TrackingCodeGenerator(CodeGenerator):
    """We abuse the code generator for introspection."""

    def __init__(self, environment: "Environment") -> None:
        super().__init__(environment, "<introspection>", "<introspection>")
        self.undeclared_identifiers: t.Set[str] = set()

    def write(self, x: str) -> None:
        """Don't write."""

    def enter_frame(self, frame: Frame) -> None:
        """Remember all undeclared identifiers."""
        super().enter_frame(frame)
        for _, (action, param) in frame.symbols.loads.items():
            if action == "resolve" and param not in self.environment.globals:
                self.undeclared_identifiers.add(param)
```

**How it works:**

1. It is constructed with a placeholder name/filename (`"<introspection>"`) since no real template is being compiled.
2. `write` is overridden to a no-op, so no Python source is ever produced — the generator only performs its bookkeeping side effects.
3. `enter_frame` is overridden to inspect `frame.symbols.loads`. Each entry is a `(action, param)` tuple. When the action is `"resolve"` (i.e., `VAR_LOAD_RESOLVE`), the name must be looked up from the runtime context. If that name is **not** in `environment.globals`, it is recorded as undeclared.

> **Note:** The `"resolve"` string corresponds to the `VAR_LOAD_RESOLVE` constant used by the compiler's symbol tracking. See [compilation_and_codegen](compilation_and_codegen.md) for the full set of load instructions (`parameter`, `resolve`, `alias`, `undefined`).

### `find_undeclared_variables`

```python
def find_undeclared_variables(ast: nodes.Template) -> t.Set[str]:
    codegen = TrackingCodeGenerator(ast.environment)
    codegen.visit(ast)
    return codegen.undeclared_identifiers
```

Returns the set of all variables that will be looked up from the context at runtime. Because the execution path is unknown at compile time, **all** potentially-used variables are returned regardless of which branch would actually execute.

**Example:**

```python
>>> from jinja2 import Environment, meta
>>> env = Environment()
>>> ast = env.parse('{% set foo = 42 %}{{ bar + foo }}')
>>> meta.find_undeclared_variables(ast) == {'bar'}
True
```

Note that `foo` is *not* returned because it is assigned within the template (`{% set foo = 42 %}`), whereas `bar` is resolved from the context.

> **Implementation caveat:** Internally this uses the code generator, which may raise a `TemplateAssertionError` during compilation. Consequently, this function can raise that exception as well.

### `find_referenced_templates`

```python
_ref_types = (nodes.Extends, nodes.FromImport, nodes.Import, nodes.Include)

def find_referenced_templates(ast: nodes.Template) -> t.Iterator[t.Optional[str]]:
    ...
```

Returns an iterator over all **hardcoded** template extensions, inclusions, and imports found in the AST. When dynamic inheritance or inclusion is used (i.e., the template name is not a constant), `None` is yielded for that reference.

**Example:**

```python
>>> from jinja2 import Environment, meta
>>> env = Environment()
>>> ast = env.parse('{% extends "layout.html" %}{% include helper %}')
>>> list(meta.find_referenced_templates(ast))
['layout.html', None]
```

Here `"layout.html"` is a constant string, while `helper` is a dynamic expression, so `None` is yielded.

**Resolution logic:**

```mermaid
flowchart TD
    A[For each Extends/Include/Import/FromImport node] --> B{template field type?}
    B -->|Const string| C[Yield the string]
    B -->|Const tuple/list| D[For each item:<br/>yield string consts,<br/>yield None for dynamic]
    B -->|Tuple/List node| E[For each item:<br/>yield string consts,<br/>yield None for dynamic]
    B -->|Other dynamic expr| F[Yield None]
    B -->|Include with tuple/list value| G[Yield each string element]
```

This function is useful for **dependency tracking** — for example, rebuilding parts of a website after a layout template changes.

---

## Data Flow

The following diagram shows how a template string flows through parsing into the meta introspection functions.

```mermaid
sequenceDiagram
    participant User
    participant Env as Environment
    participant Parser
    participant AST as nodes.Template
    participant TCG as TrackingCodeGenerator
    participant Sym as Symbols

    User->>Env: env.parse(source)
    Env->>Parser: parse(source)
    Parser->>AST: build AST
    AST-->>User: return AST

    User->>TCG: find_undeclared_variables(ast)
    TCG->>AST: visit(ast)
    loop each frame
        TCG->>Sym: inspect frame.symbols.loads
        Sym-->>TCG: (action, param) entries
        TCG->>TCG: record "resolve" names not in globals
    end
    TCG-->>User: set of undeclared identifiers

    User->>AST: find_referenced_templates(ast)
    AST->>AST: find_all(ref_types)
    AST-->>User: iterator of template names / None
```

---

## Process Flow: Finding Undeclared Variables

```mermaid
flowchart TD
    Start([find_undeclared_variables]) --> Create[Create TrackingCodeGenerator<br/>with ast.environment]
    Create --> Visit[codegen.visit(ast)]
    Visit --> EnterFrame[enter_frame called per frame]
    EnterFrame --> Iterate[Iterate frame.symbols.loads]
    Iterate --> Check{action == 'resolve'<br/>AND param not in globals?}
    Check -->|Yes| Add[Add param to<br/>undeclared_identifiers]
    Check -->|No| Skip[Skip]
    Add --> More{More entries?}
    Skip --> More
    More -->|Yes| Iterate
    More -->|No| Done[Return undeclared_identifiers]
    Done --> End([set of names])
```

---

## Integration with the Broader System

The `meta` module is a **consumer** of the compilation infrastructure and is not part of the rendering hot path. Its position in the overall Jinja2 architecture:

```mermaid
graph LR
    subgraph Frontend["Template Parsing Frontend"]
        LEX[Lexer]
        PAR[Parser]
        NOD[AST Nodes]
    end

    subgraph Codegen["Compilation & Codegen"]
        COMP[Compiler]
        META["meta.py<br/>(introspection)"]
    end

    subgraph Runtime["Runtime & API"]
        ENVR[Environment]
        RT[Runtime]
    end

    LEX --> PAR --> NOD
    NOD --> COMP
    NOD --> META
    COMP --> RT
    ENVR --> PAR
    ENVR --> COMP
    META -.reads globals.-> ENVR
```

- **Upstream dependency:** The [template_parsing_frontend](template_parsing_frontend.md) produces the `nodes.Template` AST that both meta functions consume.
- **Sibling dependency:** The [compilation_and_codegen](compilation_and_codegen.md) module provides `CodeGenerator`, `Frame`, and `Symbols`, which `TrackingCodeGenerator` extends and inspects.
- **Environment dependency:** The [runtime_execution_and_api](runtime_execution_and_api.md) module's `Environment` supplies `globals` (used to filter undeclared names) and the `parse` method that produces ASTs.

---

## Summary

The `meta` module is a compact but powerful introspection layer. By subclassing the compiler's `CodeGenerator` and suppressing its output, it repurposes the compilation pipeline as a static analyzer. This design choice means:

- **No duplicated AST-walking logic** — the meta module inherits the full, correct traversal behavior of the compiler.
- **Consistency** — undeclared-variable detection uses the exact same symbol-tracking rules as actual compilation.
- **Trade-off** — because it reuses the compiler, it can raise `TemplateAssertionError` for templates that would fail compilation.

For deeper understanding of the machinery it relies on, refer to [compilation_and_codegen](compilation_and_codegen.md) (compiler, frames, symbol tracking) and [template_parsing_frontend](template_parsing_frontend.md) (AST node model).
