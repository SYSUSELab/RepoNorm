# Runtime Execution Module

## Introduction

The `runtime` module (`src/jinja2/runtime.py`) provides the **runtime functions and state used by compiled templates**. While the [template parsing frontend](template_parsing_frontend.md) turns template source into an AST and the [compilation and codegen](compilation_and_codegen.md) module turns that AST into Python code, the runtime module supplies the *objects and helpers that the generated code calls into at render time*.

Its responsibilities include:

- **Context management** — holding template variables, blocks, and the `self` reference (`Context`, `TemplateReference`, `BlockReference`).
- **Loop state** — exposing loop metadata (`index`, `first`, `last`, `cycle`, etc.) to templates (`LoopContext`, `AsyncLoopContext`).
- **Macro wrapping** — adapting compiled macro functions to the template calling convention (`Macro`).
- **Undefined handling** — representing missing values with configurable behavior (`Undefined`, `ChainableUndefined`, `DebugUndefined`, `StrictUndefined`).
- **Runtime helpers** — string joining, identity, and the set of names exported into the generated module namespace.

This module sits at the boundary between the compiled template code and the [environment](runtime_execution_and_api.md) that orchestrates rendering.

---

## Architecture Overview

The runtime module is consumed by generated template code. The [Environment](runtime_execution_and_api.md) creates a `Context` (via `new_context`), which is threaded through every compiled function. The diagram below shows how the runtime components relate to the surrounding subsystems.

```mermaid
graph TD
    subgraph "Compilation & Codegen"
        CG[CodeGenerator]
    end

    subgraph "Runtime Module"
        NC[new_context]
        CTX[Context]
        TR[TemplateReference]
        BR[BlockReference]
        LC[LoopContext]
        ALC[AsyncLoopContext]
        MAC[Macro]
        UND[Undefined]
        CUND[ChainableUndefined]
        DUND[DebugUndefined]
        SUND[StrictUndefined]
        HELP[identity / markup_join / str_join]
    end

    subgraph "Environment & API"
        ENV[Environment]
        TPL[Template]
    end

    subgraph "Support"
        EC[EvalContext]
        EXC[UndefinedError / TemplateRuntimeError]
        UTIL[utils: _PassArg, concat, missing, internalcode]
        ASYNC[async_utils: auto_aiter, auto_await]
    end

    CG -->|generates calls to| NC
    CG -->|generates calls to| HELP
    CG -->|generates calls to| MAC
    CG -->|generates calls to| LC
    ENV -->|context_class| CTX
    ENV -->|undefined| UND
    NC --> CTX
    CTX --> TR
    CTX --> BR
    CTX --> EC
    TR --> BR
    LC --> ALC
    UND --> CUND
    UND --> DUND
    UND --> SUND
    UND -->|raises| EXC
    CTX -->|uses| UTIL
    ALC -->|uses| ASYNC
    MAC -->|uses| EC
```

---

## Core Components

### Context

`Context` is the central runtime object. It is an immutable mapping (registered as `abc.Mapping`) that holds:

- `parent` — the base variable mapping (environment globals + passed vars).
- `vars` — variables set by generated template code (e.g. `{% set %}`).
- `environment` — the owning [Environment](runtime_execution_and_api.md).
- `eval_ctx` — the current `EvalContext` (autoescape state, etc.).
- `blocks` — a mapping of block name to a *stack* of block callables, enabling template inheritance.
- `exported_vars` — names exported by the template.

Key methods:

| Method | Purpose |
| --- | --- |
| `resolve(key)` | Look up a variable, returning an `Undefined` if missing. |
| `resolve_or_missing(key)` | The overridable lookup hook; returns the `missing` sentinel when absent. |
| `get(key, default)` | Dict-style lookup with a default. |
| `get_all()` | Return the full context as a dict (may not be a copy). |
| `get_exported()` | Return only exported variables. |
| `call(obj, *args, **kwargs)` | Invoke a callable, injecting context/eval-context/environment based on `_PassArg`. |
| `derived(locals)` | Create an independent child context (used for loops/blocks). |
| `super(name, current)` | Return the parent `BlockReference` for a block. |

The `call` method is the heart of Jinja's "pass context" mechanism. It inspects the callable's `jinja_pass_arg` attribute (set by decorators like `pass_eval_context`) and injects the appropriate first argument. It also handles `_loop_vars` and `_block_vars` by deriving a new context so that loop/block scoped variables are visible without mutating the shared context.

```mermaid
flowchart TD
    A[Context.call obj] --> B{obj has __call__ with pass_arg?}
    B -->|yes| C[unwrap to __call__]
    B -->|no| D[inspect _PassArg.from_obj]
    C --> D
    D --> E{pass_arg type}
    E -->|context| F[derive context from _loop_vars/_block_vars, prepend]
    E -->|eval_context| G[prepend eval_ctx]
    E -->|environment| H[prepend environment]
    E -->|None| I[no injection]
    F --> J[invoke obj]
    G --> J
    H --> J
    I --> J
    J --> K{StopIteration?}
    K -->|yes| L[return Undefined]
    K -->|no| M[return result]
```

### TemplateReference and BlockReference

`TemplateReference` is the object bound to `self` inside templates. Indexing it (`self["blockname"]`) returns a `BlockReference` for that block.

`BlockReference` represents a single block on a template reference. It holds a *stack* of block implementations (from the inheritance chain) and a `depth` pointer. Calling it renders the block at the current depth; the `super` property returns a `BlockReference` one level deeper, enabling `{{ super() }}`. It supports both synchronous (`__call__`) and asynchronous (`_async_call`) rendering, choosing based on `environment.is_async`.

### LoopContext and AsyncLoopContext

`LoopContext` wraps an iterable to expose rich loop metadata to templates. It is both an iterator and a callable (for recursive loops).

| Attribute | Meaning |
| --- | --- |
| `index0` / `index` | Zero-based / one-based iteration counter. |
| `revindex0` / `revindex` | Reverse counters (require `length`). |
| `first` / `last` | Whether this is the first/last iteration. |
| `length` | Length of the iterable (eagerly materialized if needed). |
| `previtem` / `nextitem` | Neighboring items (Undefined at boundaries). |
| `depth` / `depth0` | Recursion depth. |
| `cycle(*args)` | Cycle through values by `index0`. |
| `changed(*value)` | Detect value changes between iterations. |

`last` and `nextitem` use `_peek_next`, which advances the underlying iterator one step ahead and caches the result in `_after`. This is why the docs warn about interaction with `itertools.groupby`.

`AsyncLoopContext` subclasses `LoopContext` and overrides the iterator machinery to use `auto_aiter` and `__anext__`, making `length`, `revindex0`, `revindex`, `last`, and `nextitem` awaitable.

```mermaid
classDiagram
    class LoopContext {
        +index0
        +length
        +depth
        +index
        +revindex0
        +revindex
        +first
        +last
        +previtem
        +nextitem
        +cycle(*args)
        +changed(*value)
        +__next__()
        +__call__(iterable)
    }
    class AsyncLoopContext {
        +length (async)
        +revindex0 (async)
        +revindex (async)
        +last (async)
        +nextitem (async)
        +__anext__()
    }
    LoopContext <|-- AsyncLoopContext
```

### Macro

`Macro` wraps a compiled macro function, adapting it to the template calling convention. It handles:

- **Argument binding** — positional args are consumed up to `_argument_count`, then keyword args and defaults fill the rest.
- **Caller support** — if the macro declares a `caller` argument (or `catch_kwargs`), the caller is injected.
- **Varargs / kwargs** — controlled by `catch_varargs` and `catch_kwargs`.
- **Autoescape** — determined at *call time* from the passed `EvalContext` (falling back to the compile-time default), because whether a macro is safe depends on where it is used, not where it was defined.

The `__call__` method is decorated with `@pass_eval_context`, so the `EvalContext` is injected as the first argument. It supports async invocation via `_async_invoke` when `environment.is_async`.

### Undefined and Subclasses

`Undefined` is the default representation of missing values. It is deliberately permissive for printing and iteration but raises `UndefinedError` for almost every other operation (arithmetic, attribute access, comparison, calling, etc.). The error message is built dynamically by `_undefined_message` based on how the value was accessed.

```mermaid
classDiagram
    class Undefined {
        +_undefined_hint
        +_undefined_obj
        +_undefined_name
        +_undefined_exception
        +_undefined_message
        +_fail_with_undefined_error()
        +__str__() ""
        +__bool__() False
        +__iter__() empty
    }
    class ChainableUndefined {
        +__getattr__() self
        +__getitem__() self
    }
    class DebugUndefined {
        +__str__() debug repr
    }
    class StrictUndefined {
        +__iter__ = fail
        +__str__ = fail
        +__bool__ = fail
        +__eq__ = fail
    }
    Undefined <|-- ChainableUndefined
    Undefined <|-- DebugUndefined
    Undefined <|-- StrictUndefined
```

| Class | Behavior |
| --- | --- |
| `Undefined` | Prints as `""`, falsy, iterates empty; other ops raise. |
| `ChainableUndefined` | `__getattr__`/`__getitem__` return `self`, allowing `foo.bar['baz']` chains. |
| `DebugUndefined` | Prints the original template expression (e.g. `{{ foo }}`) for debugging. |
| `StrictUndefined` | Raises on *any* operation, including printing, iteration, and boolean tests. |

The `make_logging_undefined(logger, base)` factory dynamically creates a subclass that logs warnings on print/iteration/boolean access and errors on failures. The `Environment.undefined` attribute selects which class is used.

### Runtime Helpers

| Helper | Purpose |
| --- | --- |
| `identity(x)` | Returns its argument unchanged. |
| `markup_join(seq)` | Concatenates, escaping if any element has `__html__`. |
| `str_join(seq)` | Converts each element to `str` and concatenates. |
| `new_context(...)` | Internal factory that builds a `Context` from environment, blocks, vars, globals, and locals. |

### Exported Names

The module defines two lists that are injected into the generated template module namespace:

- `exported` — `LoopContext`, `TemplateReference`, `Macro`, `Markup`, `TemplateRuntimeError`, `missing`, `escape`, `markup_join`, `str_join`, `identity`, `TemplateNotFound`, `Namespace`, `Undefined`, `internalcode`.
- `async_exported` — `AsyncLoopContext`, `auto_aiter`, `auto_await`.

These are the symbols that compiled templates reference directly, which is why they must remain stable.

---

## Data Flow During Rendering

The following sequence shows how the runtime objects participate in a typical render.

```mermaid
sequenceDiagram
    participant TPL as Template
    participant ENV as Environment
    participant NC as new_context
    participant CTX as Context
    participant GEN as Generated Code
    participant LC as LoopContext
    participant MAC as Macro

    TPL->>ENV: render(vars)
    ENV->>NC: new_context(env, name, blocks, vars)
    NC->>CTX: context_class(...)
    NC-->>ENV: Context
    ENV->>GEN: root(context)
    GEN->>CTX: resolve("items")
    CTX-->>GEN: value
    GEN->>LC: LoopContext(items, undefined)
    loop each item
        GEN->>LC: __next__()
        LC-->>GEN: (item, loop)
        GEN->>MAC: macro call (with EvalContext)
        MAC-->>GEN: rendered string
    end
    GEN-->>ENV: output
    ENV-->>TPL: rendered result
```

---

## Dependencies

The runtime module depends on several other modules. Refer to their documentation for details rather than duplicating here.

```mermaid
graph LR
    RT[runtime.py] --> NODES[nodes.py<br/>EvalContext]
    RT --> UTILS[utils.py<br/>_PassArg, concat,<br/>internalcode, missing,<br/>object_type_repr,<br/>pass_eval_context]
    RT --> ASYNC[async_utils.py<br/>auto_aiter, auto_await]
    RT --> EXC[exceptions.py<br/>UndefinedError,<br/>TemplateRuntimeError,<br/>TemplateNotFound]
    RT --> MS[markupsafe<br/>Markup, escape, soft_str]
    ENV[environment.py] --> RT
    CG[compiler.py] --> RT
```

- **[nodes](template_parsing_frontend.md)** — `EvalContext` carries autoescape and environment state.
- **[utils](utils.md)** — `_PassArg` drives argument injection; `concat`, `missing`, `internalcode`, `object_type_repr`, and `pass_eval_context` are core helpers.
- **[async_utils](runtime_execution_and_api.md)** — `auto_aiter`/`auto_await` power async loops and macros.
- **[exceptions](runtime_execution_and_api.md)** — `UndefinedError` and `TemplateRuntimeError` are raised by undefined values and runtime failures.
- **[environment](runtime_execution_and_api.md)** — creates contexts, selects the `undefined` class, and drives rendering.
- **[compiler](compilation_and_codegen.md)** — generates code that calls into the runtime helpers and classes.

---

## Integration Points

| Consumer | How it uses the runtime |
| --- | --- |
| [Environment](runtime_execution_and_api.md) | Sets `context_class = Context` and `undefined = Undefined`; calls `new_context` during rendering. |
| [CodeGenerator](compilation_and_codegen.md) | Emits references to `LoopContext`, `Macro`, `TemplateReference`, `markup_join`, `str_join`, `identity`, etc. |
| [Extensions](extension_and_customization.md) | May subclass `Context` or `Undefined`, and rely on `_PassArg`-based injection. |
| [Sandbox](extension_and_customization.md) | Wraps `Environment` and interacts with undefined/context behavior. |

---

## Summary

The `runtime` module is the execution-time backbone of Jinja. It provides the `Context` that carries variables and blocks, the `LoopContext` family that exposes loop metadata, the `Macro` wrapper that adapts compiled macros, and the `Undefined` hierarchy that governs how missing values behave. Together with the helper functions and exported names, it forms the stable interface that compiled templates call into, bridging the [compiler](compilation_and_codegen.md) output and the [environment](runtime_execution_and_api.md) that orchestrates rendering.
