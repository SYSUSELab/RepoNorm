# Loaders Module

## Introduction

The **loaders** module (`src/jinja2/loaders.py`) provides the API and concrete implementations for loading Jinja templates from a variety of data sources. A *loader* is responsible for locating a template by name, returning its source text, and (optionally) providing a mechanism to detect whether the template has changed since it was last loaded.

Loaders are the bridge between the abstract [`Environment`](runtime_execution_and_api.md) and the physical storage of templates — whether that storage is the file system, a Python package, a zip archive, an in-memory dictionary, or a user-supplied function. The environment delegates all template retrieval to its configured loader via `Environment.get_template`, which ultimately calls `BaseLoader.load`.

This module belongs to the **template_loading_and_caching** group and works closely with the [bytecode cache](bytecode_cache.md) to avoid recompiling unchanged templates.

---

## Core Concepts

### The Loader Contract

Every loader implements (or inherits) the following interface:

| Method | Purpose |
| --- | --- |
| `get_source(environment, template)` | Returns a `(source, filename, uptodate)` tuple or raises `TemplateNotFound`. This is the primary method subclasses override. |
| `load(environment, name, globals)` | Orchestrates source retrieval, bytecode caching, compilation, and template construction. Subclasses should **not** override this. |
| `list_templates()` | Returns a sorted list of all template names the loader can find. Raises `TypeError` if unsupported. |
| `has_source_access` | Class attribute; when `False`, the loader cannot expose template source (e.g. `ModuleLoader`). |

The `uptodate` callable returned by `get_source` is used by the environment's auto-reload mechanism: it is invoked with no arguments and must return `True` if the template is still current, or `False` to force a reload.

### Path Sanitization

The module-level helper `split_template_path(template)` splits a template name into path segments and rejects any segment containing a path separator or `..`, raising `TemplateNotFound` to prevent directory-traversal attacks. All file-based loaders use it before touching the filesystem.

---

## Architecture

The following diagram shows the class hierarchy and how the loaders relate to the environment and bytecode cache.

```mermaid
classDiagram
    class BaseLoader {
        +bool has_source_access
        +get_source(env, template)
        +list_templates()
        +load(env, name, globals)
    }
    class FileSystemLoader
    class PackageLoader
    class DictLoader
    class FunctionLoader
    class PrefixLoader
    class ChoiceLoader
    class ModuleLoader {
        +has_source_access = False
        +get_template_key(name)
        +get_module_filename(name)
    }
    class _TemplateModule

    BaseLoader <|-- FileSystemLoader
    BaseLoader <|-- PackageLoader
    BaseLoader <|-- DictLoader
    BaseLoader <|-- FunctionLoader
    BaseLoader <|-- PrefixLoader
    BaseLoader <|-- ChoiceLoader
    BaseLoader <|-- ModuleLoader
    ModuleType <|-- _TemplateModule
    ModuleLoader ..> _TemplateModule : creates
    PrefixLoader o-- BaseLoader : delegates to
    ChoiceLoader o-- BaseLoader : delegates to
```

### Component Responsibilities

| Component | Responsibility |
| --- | --- |
| `BaseLoader` | Abstract base class defining the loader contract and the shared `load` orchestration logic. |
| `FileSystemLoader` | Loads templates from one or more directories on the file system. |
| `PackageLoader` | Loads templates from a directory inside an installed Python package (directory or zip/egg). |
| `DictLoader` | Loads templates from an in-memory `dict` mapping names to source. Ideal for testing. |
| `FunctionLoader` | Delegates loading to a user-supplied callable. |
| `PrefixLoader` | Dispatches to sub-loaders based on a name prefix (e.g. `app1/index.html`). |
| `ChoiceLoader` | Tries a sequence of loaders in order, returning the first match. |
| `ModuleLoader` | Loads precompiled templates from Python modules on disk. |
| `_TemplateModule` | A `ModuleType` subclass supporting weak references, used internally by `ModuleLoader`. |

---

## The Load Pipeline

`BaseLoader.load` is the central orchestration method. It ties together source retrieval, the [bytecode cache](bytecode_cache.md), the compiler, and template construction.

```mermaid
flowchart TD
    A[Environment.get_template] --> B[BaseLoader.load]
    B --> C[get_source env, name]
    C -->|TemplateNotFound| X[propagate error]
    C -->|source, filename, uptodate| D{bytecode_cache set?}
    D -->|yes| E[bcc.get_bucket]
    E --> F{bucket.code present?}
    D -->|no| G[compile source]
    F -->|yes| H[use cached code]
    F -->|no| G
    G --> I{bcc set and bucket empty?}
    I -->|yes| J[bucket.code = code; bcc.set_bucket]
    I -->|no| K[skip]
    H --> L[template_class.from_code]
    J --> L
    K --> L
    L --> M[Template instance]
```

Key points:

1. **Source retrieval** — `get_source` returns the raw template text, an optional filename (used for tracebacks), and an `uptodate` callable.
2. **Bytecode cache lookup** — If the environment has a `bytecode_cache`, a bucket is fetched using the name, filename, and source checksum. See [bytecode_cache.md](bytecode_cache.md) for details.
3. **Compilation** — If no valid cached code exists, `Environment.compile` parses and generates bytecode.
4. **Cache write-back** — Newly compiled code is stored back into the bucket.
5. **Template construction** — `template_class.from_code` builds the final `Template` object.

> **Note:** Composite loaders (`PrefixLoader`, `ChoiceLoader`) override `load` to delegate to their child loaders rather than calling `get_source` directly, ensuring each child's own caching and compilation path is used.

---

## Loader Implementations

### FileSystemLoader

Loads templates from one or more directories. Directories are searched in order, stopping at the first match.

```python
loader = FileSystemLoader(["/override/templates", "/default/templates"])
```

- **Parameters:** `searchpath` (str, `PathLike`, or sequence), `encoding` (default `utf-8`), `followlinks` (default `False`).
- **`get_source`:** Joins each search path with the sanitized template segments, reads the file, and captures its `mtime` for the `uptodate` closure.
- **`list_templates`:** Walks each search path, normalizing separators to `/` and returning a sorted, de-duplicated list.

### PackageLoader

Loads templates from a directory within an installed Python package.

```python
loader = PackageLoader("project.ui", "pages")
```

- **Parameters:** `package_name`, `package_path` (default `templates`), `encoding` (default `utf-8`).
- **Behavior:** Uses `importlib.util.find_spec` to locate the package. Supports standard directory installs, zip/egg installs (via `zipimport`), and limited PEP 420 namespace packages.
- **`get_source`:** For directory packages, reads the file and provides an `mtime`-based `uptodate`. For zip packages, reads via the zip importer and reports `uptodate = None` (always current).
- **`list_templates`:** Walks the directory or enumerates the zip's `_files` metadata.

### DictLoader

Loads templates from an in-memory mapping. Auto-reload is effectively supported by comparing the current mapping value.

```python
loader = DictLoader({"index.html": "source here"})
```

- **`get_source`:** Returns the mapped source with `filename = None` and an `uptodate` closure comparing against the current mapping value.
- **`list_templates`:** Returns the sorted keys.

### FunctionLoader

Delegates loading to a user-supplied callable.

```python
def load_template(name):
    if name == "index.html":
        return "..."

loader = FunctionLoader(load_template)
```

- The callable may return a plain source string, a `(source, filename, uptodate)` tuple, or `None` (which raises `TemplateNotFound`).

### PrefixLoader

Dispatches to sub-loaders based on a prefix delimited by a configurable `delimiter` (default `/`).

```python
loader = PrefixLoader({
    "app1": PackageLoader("mypackage.app1"),
    "app2": PackageLoader("mypackage.app2"),
})
```

- **`get_loader`:** Splits the template name on the delimiter and looks up the corresponding loader.
- **`get_source` / `load`:** Delegate to the resolved child loader, re-raising `TemplateNotFound` with the *prefixed* name so error messages remain accurate.
- **`list_templates`:** Prefixes each child's templates with the prefix and delimiter.

### ChoiceLoader

Tries a sequence of loaders in order, returning the first successful match.

```python
loader = ChoiceLoader([
    FileSystemLoader("/path/to/user/templates"),
    FileSystemLoader("/path/to/system/templates"),
])
```

- Useful for letting user templates override built-in templates.
- **`get_source` / `load`:** Iterate over child loaders, swallowing `TemplateNotFound` until one succeeds.
- **`list_templates`:** Returns the sorted union of all child template lists.

### ModuleLoader

Loads **precompiled** templates from Python modules on disk. Templates are typically produced by `Environment.compile_templates`.

```python
loader = ChoiceLoader([
    ModuleLoader("/path/to/compiled/templates"),
    FileSystemLoader("/path/to/templates"),
])
```

- **`has_source_access = False`** — this loader cannot expose template source.
- **Construction:** Creates a synthetic `_TemplateModule` whose `__path__` points at the given directories, and registers it in `sys.modules` via a `weakref.proxy` so it is garbage-collected when the loader is released.
- **`get_template_key` / `get_module_filename`:** Derive a deterministic module name from the SHA-1 hash of the template name (`tmpl_<hash>` / `tmpl_<hash>.py`).
- **`load`:** Imports the compiled module, removes it from `sys.modules` (keeping only the attribute reference), and builds the template via `template_class.from_module_dict`.

---

## Data Flow: Loading a Template

The sequence below illustrates a typical load through a `FileSystemLoader` with a bytecode cache configured.

```mermaid
sequenceDiagram
    participant App
    participant Env as Environment
    participant Loader as FileSystemLoader
    participant BCC as BytecodeCache
    participant Tmpl as Template

    App->>Env: get_template("index.html")
    Env->>Env: check cache (LRU)
    Env->>Loader: load(env, "index.html", globals)
    Loader->>Loader: get_source(env, "index.html")
    Loader-->>Loader: (source, filename, uptodate)
    Loader->>BCC: get_bucket(env, name, filename, source)
    BCC-->>Loader: bucket (code or None)
    alt code is None
        Loader->>Env: compile(source, name, filename)
        Env-->>Loader: code
        Loader->>BCC: set_bucket(bucket)
    end
    Loader->>Tmpl: from_code(env, code, globals, uptodate)
    Tmpl-->>Loader: Template
    Loader-->>Env: Template
    Env->>Env: store in LRU cache
    Env-->>App: Template
```

---

## Dependencies

```mermaid
graph LR
    subgraph loaders
        BL[BaseLoader]
        FSL[FileSystemLoader]
        PL[PackageLoader]
        DL[DictLoader]
        FL[FunctionLoader]
        PreL[PrefixLoader]
        CL[ChoiceLoader]
        ML[ModuleLoader]
    end

    BL -->|uses| EX[exceptions.TemplateNotFound]
    BL -->|uses| UT[utils.internalcode]
    FSL -->|uses| UT2[utils.open_if_exists]
    BL -->|calls| ENV[environment.Environment.compile]
    BL -->|calls| BCC[bccache.BytecodeCache]
    BL -->|builds| TMPL[environment.Template]
    ML -->|uses| SYS[sys.modules / weakref]
    PL -->|uses| IMP[importlib / zipimport]
```

### External Dependencies

- `importlib.util`, `import_module` — package introspection for `PackageLoader`.
- `zipimport` — zip/egg package support.
- `weakref` — weak module registration in `ModuleLoader`.
- `hashlib.sha1` — deterministic module keys in `ModuleLoader`.

### Internal Dependencies

- [`exceptions.TemplateNotFound`](runtime_execution_and_api.md) — raised when a template cannot be located.
- [`utils.internalcode`](utils.md) — marks `load` as internal API.
- [`utils.open_if_exists`](utils.md) — safe file opening for `FileSystemLoader`.
- [`environment.Environment`](runtime_execution_and_api.md) — provides `compile`, `bytecode_cache`, and `template_class`.
- [`bccache.BytecodeCache`](bytecode_cache.md) — optional compilation cache.

---

## Choosing a Loader

| Scenario | Recommended Loader |
| --- | --- |
| Templates on disk in a project directory | `FileSystemLoader` |
| Templates shipped inside a distributable package | `PackageLoader` |
| Unit tests / small embedded templates | `DictLoader` |
| Templates from a database or custom backend | `FunctionLoader` (or a custom `BaseLoader` subclass) |
| Multiple namespaces (e.g. per-app) | `PrefixLoader` |
| Layered overrides (user over system) | `ChoiceLoader` |
| Precompiled templates for fast startup | `ModuleLoader` |

---

## Extending the Module

To implement a custom loader, subclass `BaseLoader` and override `get_source`:

```python
from jinja2 import BaseLoader, TemplateNotFound

class MyLoader(BaseLoader):
    def __init__(self, path):
        self.path = path

    def get_source(self, environment, template):
        # return (source, filename, uptodate) or raise TemplateNotFound
        ...
```

Optionally override `list_templates` to support enumeration, and set `has_source_access = False` if the source cannot be exposed. Do **not** override `load` unless you are building a composite loader that delegates to other loaders.

---

## Related Documentation

- [runtime_execution_and_api.md](runtime_execution_and_api.md) — `Environment`, `Template`, and exception types.
- [bytecode_cache.md](bytecode_cache.md) — how compiled templates are cached and reused.
- [utils.md](utils.md) — shared helpers such as `internalcode` and `open_if_exists`.
- [compilation_and_codegen.md](compilation_and_codegen.md) — the compilation pipeline invoked by `BaseLoader.load`.
