# Exceptions Module

## Introduction

The `exceptions` module (`src/jinja2/exceptions.py`) defines the complete exception hierarchy used throughout the Jinja2 template engine. It provides a single, well-organized set of error types that are raised during every phase of template processing: lexing, parsing, compilation, loading, and runtime execution.

The module is intentionally small and dependency-light. Its only runtime dependency is the `Undefined` type from the [runtime module](runtime.md), which is imported lazily to avoid circular imports. Because nearly every other Jinja2 module raises one of these exceptions, this module acts as a shared contract between the [template parsing frontend](template_parsing_frontend.md), the [compilation and codegen](compilation_and_codegen.md) layer, the [runtime execution and API](runtime_execution_and_api.md), the [template loading and caching](template_loading_and_caching.md) subsystem, and the [extension and customization](extension_and_customization.md) layer.

## Purpose and Core Functionality

The module serves three primary purposes:

1. **A common base class** (`TemplateError`) so that callers can catch *all* Jinja2 errors with a single `except` clause.
2. **Specialized error types** that carry structured metadata (line numbers, filenames, template names) to produce helpful diagnostics.
3. **Semantic separation** between *syntax/compile-time* errors and *runtime* errors, allowing applications to distinguish between "the template is malformed" and "the template failed while rendering".

## Exception Hierarchy

All exceptions derive from `TemplateError`, which itself derives from Python's built-in `Exception`. The hierarchy splits into two major branches: syntax/compile-time errors and runtime errors.

```mermaid
classDiagram
    Exception <|-- TemplateError
    TemplateError <|-- TemplateSyntaxError
    TemplateError <|-- TemplateRuntimeError
    TemplateError <|-- TemplateNotFound

    TemplateSyntaxError <|-- TemplateAssertionError

    TemplateRuntimeError <|-- UndefinedError
    TemplateRuntimeError <|-- SecurityError
    TemplateRuntimeError <|-- FilterArgumentError

    TemplateNotFound <|-- TemplatesNotFound

    IOError <|-- TemplateNotFound
    LookupError <|-- TemplateNotFound

    class TemplateError {
        +message: Optional[str]
        +__init__(message)
    }
    class TemplateSyntaxError {
        +lineno: int
        +name: Optional[str]
        +filename: Optional[str]
        +source: Optional[str]
        +translated: bool
        +__str__()
        +__reduce__()
    }
    class TemplateNotFound {
        +name
        +templates: list
        +message: Optional[str]
        +__str__()
    }
    class TemplatesNotFound {
        +templates: list
    }
    class TemplateAssertionError
    class TemplateRuntimeError
    class UndefinedError
    class SecurityError
    class FilterArgumentError
```

### Base Class: `TemplateError`

`TemplateError` is the root of the hierarchy. It stores an optional `message` and exposes it through a `message` property that reads from `self.args[0]`. This design keeps the exception compatible with standard Python exception pickling while providing a convenient accessor.

```python
class TemplateError(Exception):
    """Baseclass for all template errors."""

    def __init__(self, message: t.Optional[str] = None) -> None:
        super().__init__(message)

    @property
    def message(self) -> t.Optional[str]:
        return self.args[0] if self.args else None
```

## Syntax and Compile-Time Errors

### `TemplateSyntaxError`

Raised when the template source cannot be parsed or compiled. It is the most information-rich exception in the module, carrying:

| Attribute | Description |
|-----------|-------------|
| `message` | The human-readable error message |
| `lineno` | The line number where the error occurred |
| `name` | The template name (load name) |
| `filename` | The filesystem filename, if known |
| `source` | The full template source, used to render the offending line |
| `translated` | Set to `True` when the debug extension rewrote the traceback |

Its `__str__` method builds a multi-line diagnostic that includes the location and, when `source` is available, the offending source line:

```
unexpected end of template
  File "example.html", line 12
    {% for item in items %}
```

The custom `__reduce__` method exists to work around a Python limitation ([bpo-1692335](https://bugs.python.org/issue1692335)) where exceptions requiring multiple positional arguments cannot be pickled correctly.

This exception is raised by the [lexer](template_parsing_frontend.md) (via the `Failure` helper class), the [parser](template_parsing_frontend.md) (via `Parser.fail`), and the [compiler](compilation_and_codegen.md). The `Environment.parse` and `Environment.compile` methods catch it and route it through `handle_exception` for traceback rewriting.

### `TemplateAssertionError`

A direct subclass of `TemplateSyntaxError` used for compile-time errors that are *not* strictly syntax errors — for example, importing a name that starts with an underscore, or a `required` block containing non-whitespace content. It shares all attributes and behavior with its parent.

## Runtime Errors

### `TemplateRuntimeError`

The base class for all errors that occur while a template is being *rendered* (as opposed to parsed or compiled). Jinja raises this directly in a few situations, such as referencing an unknown filter or test.

### `UndefinedError`

Raised when a template attempts an operation on an `Undefined` value. The [runtime module](runtime.md)'s `Undefined` class is configured with an exception type (defaulting to `UndefinedError`) and calls `_fail_with_undefined_error()` to raise it. This is the most common runtime error users encounter.

### `SecurityError`

Raised by the [sandbox](extension_and_customization.md) when a template attempts to access an unsafe attribute or call an unsafe callable. The `SandboxedEnvironment.unsafe_undefined` method constructs an `Undefined` instance whose `exc` is `SecurityError`, so that accessing the unsafe value raises this error.

### `FilterArgumentError`

Raised when a filter is invoked with inappropriate arguments. It is a specialized `TemplateRuntimeError` that lets applications distinguish filter misuse from other runtime failures.

## Template Loading Errors

### `TemplateNotFound`

Raised when a requested template does not exist. It inherits from three bases:

- `IOError` — so it behaves like a file-not-found error
- `LookupError` — so it behaves like a missing-key error
- `TemplateError` — so it is caught by the common Jinja2 base class

It carries a `name` (the requested template name) and a `templates` list (initially `[name]`). A notable behavior (added in Jinja 2.11) is that if the `name` is an `Undefined` instance and no message was provided, the constructor calls `name._fail_with_undefined_error()`, converting the situation into an `UndefinedError`.

This exception is raised by loaders in the [template loading and caching](template_loading_and_caching.md) module (e.g., `BaseLoader.get_source`) and by `Environment.get_template`.

### `TemplatesNotFound`

A subclass of `TemplateNotFound` raised when *multiple* candidate templates are tried and none are found. Because it subclasses `TemplateNotFound`, catching the base class catches both. It stores the full list of attempted names in `templates` and builds a descriptive message such as:

```
none of the templates given were found: a.html, b.html, c.html
```

If any name in the list is an `Undefined` instance, its `_undefined_message` is used instead of the raw value, producing a more helpful diagnostic. It is raised by `Environment.select_template`.

## Component Interaction

The following diagram shows how the various Jinja2 subsystems raise and consume these exceptions.

```mermaid
flowchart TD
    subgraph Frontend["Template Parsing Frontend"]
        Lexer["Lexer / Failure"]
        Parser["Parser.fail"]
    end

    subgraph Compile["Compilation & Codegen"]
        CodeGen["CodeGenerator"]
    end

    subgraph Runtime["Runtime Execution & API"]
        Env["Environment"]
        Undef["Undefined"]
    end

    subgraph Loading["Template Loading & Caching"]
        Loader["BaseLoader"]
    end

    subgraph Sandbox["Extension & Customization"]
        SandboxEnv["SandboxedEnvironment"]
    end

    Lexer -->|raises| TSE["TemplateSyntaxError"]
    Parser -->|raises| TSE
    Parser -->|raises| TAE["TemplateAssertionError"]
    CodeGen -->|raises| TSE
    CodeGen -->|raises| TAE

    Env -->|raises| TSE
    Env -->|raises| TNF["TemplateNotFound"]
    Env -->|raises| TSNF["TemplatesNotFound"]
    Env -->|raises| TRT["TemplateRuntimeError"]

    Undef -->|raises| UE["UndefinedError"]

    Loader -->|raises| TNF

    SandboxEnv -->|raises| SE["SecurityError"]

    TSE -.->|subclass| TAE
    TNF -.->|subclass| TSNF
    TRT -.->|subclass| UE
    TRT -.->|subclass| SE
    TRT -.->|subclass| FAE["FilterArgumentError"]
```

## Data Flow: From Template Source to Exception

The diagram below traces how a template flows through the engine and where each exception type can be raised.

```mermaid
sequenceDiagram
    participant App as Application
    participant Env as Environment
    participant Loader as BaseLoader
    participant Lexer as Lexer
    participant Parser as Parser
    participant Compiler as CodeGenerator
    participant Runtime as Runtime (Undefined)

    App->>Env: get_template("page.html")
    Env->>Loader: load(env, name)
    alt template missing
        Loader-->>Env: raise TemplateNotFound
        Env-->>App: TemplateNotFound
    end
    Loader->>Env: compile(source)
    Env->>Lexer: tokenize(source)
    alt lexical error
        Lexer-->>Env: raise TemplateSyntaxError
    end
    Env->>Parser: parse()
    alt parse error
        Parser-->>Env: raise TemplateSyntaxError / TemplateAssertionError
    end
    Env->>Compiler: generate(ast)
    alt compile error
        Compiler-->>Env: raise TemplateSyntaxError / TemplateAssertionError
    end
    Env-->>App: Template
    App->>Runtime: render(context)
    alt undefined access
        Runtime-->>App: raise UndefinedError
    end
    alt unsafe access (sandbox)
        Runtime-->>App: raise SecurityError
    end
```

## Exception Reference Table

| Exception | Base(s) | Phase | Typical Raiser |
|-----------|---------|-------|----------------|
| `TemplateError` | `Exception` | — | Base class only |
| `TemplateSyntaxError` | `TemplateError` | Lex / Parse / Compile | `Lexer`, `Parser.fail`, `CodeGenerator` |
| `TemplateAssertionError` | `TemplateSyntaxError` | Parse / Compile | `Parser`, `CodeGenerator` |
| `TemplateRuntimeError` | `TemplateError` | Runtime | `Environment._filter_test_common` |
| `UndefinedError` | `TemplateRuntimeError` | Runtime | `Undefined._fail_with_undefined_error` |
| `SecurityError` | `TemplateRuntimeError` | Runtime | `SandboxedEnvironment` |
| `FilterArgumentError` | `TemplateRuntimeError` | Runtime | Filter invocation |
| `TemplateNotFound` | `IOError`, `LookupError`, `TemplateError` | Load | `BaseLoader.get_source`, `Environment.get_template` |
| `TemplatesNotFound` | `TemplateNotFound` | Load | `Environment.select_template` |

## Design Notes

- **Lazy import of `Undefined`**: The module imports `Undefined` only inside method bodies (and under `TYPE_CHECKING` for annotations). This avoids a circular import, since the [runtime module](runtime.md) imports exception types from this module.
- **Pickling support**: `TemplateSyntaxError.__reduce__` ensures the exception can be serialized even though its constructor requires multiple positional arguments.
- **Multiple inheritance for `TemplateNotFound`**: Inheriting from `IOError` and `LookupError` lets existing code that catches file or lookup errors continue to work without modification.
- **`message` attribute shadowing**: `TemplateNotFound` explicitly declares `message: t.Optional[str] = None` as a class attribute to silence Python's deprecation warning about the `message` attribute, since it is intentionally used here.

## Related Modules

- [Runtime Execution and API](runtime_execution_and_api.md) — defines `Undefined`, which raises `UndefinedError`, and `Environment`, which raises loading and syntax errors.
- [Template Parsing Frontend](template_parsing_frontend.md) — the lexer and parser raise `TemplateSyntaxError` and `TemplateAssertionError`.
- [Compilation and Codegen](compilation_and_codegen.md) — the compiler raises syntax and assertion errors during code generation.
- [Template Loading and Caching](template_loading_and_caching.md) — loaders raise `TemplateNotFound`.
- [Extension and Customization](extension_and_customization.md) — the sandbox raises `SecurityError`; the debug extension rewrites `TemplateSyntaxError` tracebacks.
