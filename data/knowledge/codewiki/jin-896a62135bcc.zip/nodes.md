# Nodes Module

## Introduction

The `nodes` module (`src/jinja2/nodes.py`) defines the **Abstract Syntax Tree (AST)** used throughout Jinja2. It provides the complete set of node classes that the [parser](parser.md) produces, the [compiler](compiler.md) consumes, and the [optimizer](optimizer.md) transforms. Every template, once parsed, becomes a tree of `Node` instances rooted at a `Template` node.

The module serves three primary purposes:

1. **Node type definitions** — A rich hierarchy of statement, expression, literal, and helper nodes representing every construct in the Jinja template language.
2. **Tree traversal utilities** — Methods on `Node` (`iter_child_nodes`, `find`, `find_all`, `set_ctx`, `set_lineno`, `set_environment`) used by the parser, compiler, and visitors.
3. **Constant folding support** — The `as_const()` protocol that allows expressions to be evaluated at compile time, powering the [optimizer](optimizer.md) and the compiler's constant-folding optimizations.

The module also defines `EvalContext`, which carries evaluation-time information (environment, autoescape state, volatility) through the tree.

---

## Architecture Overview

The nodes module sits at the center of the Jinja2 compilation pipeline. It is produced by the parser, transformed by visitors/optimizers, and consumed by the compiler.

```mermaid
graph TD
    subgraph "Frontend"
        LEX[lexer.py<br/>Tokenization]
        PAR[parser.py<br/>Parser]
    end

    subgraph "nodes.py"
        NODE[Node hierarchy]
        EVAL[EvalContext]
        NT[NodeType metaclass]
    end

    subgraph "Transformation"
        VIS[visitor.py<br/>NodeVisitor / NodeTransformer]
        OPT[optimizer.py<br/>Optimizer]
        IDT[idtracking.py<br/>Symbols]
    end

    subgraph "Backend"
        COMP[compiler.py<br/>CodeGenerator]
        META[meta.py<br/>TrackingCodeGenerator]
        NAT[nativetypes.py<br/>NativeCodeGenerator]
    end

    LEX --> PAR
    PAR -->|produces| NODE
    NODE --> EVAL
    NT -.->|metaclass of| NODE
    NODE -->|traversed by| VIS
    VIS --> OPT
    VIS --> IDT
    NODE -->|consumed by| COMP
    COMP --> META
    COMP --> NAT
    OPT -->|rewrites| NODE
```

---

## Node Class Hierarchy

All nodes derive from the abstract `Node` base class. The hierarchy is organized into four major categories, as documented in the `Node` docstring:

- **`Stmt`** — statements (control flow, assignments, output)
- **`Expr`** — expressions (values, operators, lookups)
- **`Helper`** — nodes that exist only in a specific context (e.g., `Pair`, `Keyword`, `Operand`)
- **`Template`** — the outermost wrapper node

```mermaid
classDiagram
    class Node {
        +fields: Tuple
        +attributes: Tuple
        +lineno: int
        +environment: Environment
        +iter_fields()
        +iter_child_nodes()
        +find()
        +find_all()
        +set_ctx()
        +set_lineno()
        +set_environment()
        +dump()
    }

    class Stmt
    class Expr {
        +as_const(eval_ctx)
        +can_assign()
    }
    class Helper
    class Template

    Node <|-- Stmt
    Node <|-- Expr
    Node <|-- Helper
    Node <|-- Template

    Stmt <|-- Output
    Stmt <|-- Extends
    Stmt <|-- For
    Stmt <|-- If
    Stmt <|-- Macro
    Stmt <|-- CallBlock
    Stmt <|-- FilterBlock
    Stmt <|-- With
    Stmt <|-- Block
    Stmt <|-- Include
    Stmt <|-- Import
    Stmt <|-- FromImport
    Stmt <|-- ExprStmt
    Stmt <|-- Assign
    Stmt <|-- AssignBlock
    Stmt <|-- Continue
    Stmt <|-- Break
    Stmt <|-- Scope
    Stmt <|-- OverlayScope
    Stmt <|-- EvalContextModifier
    Stmt <|-- ScopedEvalContextModifier

    Expr <|-- BinExpr
    Expr <|-- UnaryExpr
    Expr <|-- Name
    Expr <|-- NSRef
    Expr <|-- Literal
    Expr <|-- CondExpr
    Expr <|-- _FilterTestCommon
    Expr <|-- Call
    Expr <|-- Getitem
    Expr <|-- Getattr
    Expr <|-- Slice
    Expr <|-- Concat
    Expr <|-- Compare
    Expr <|-- EnvironmentAttribute
    Expr <|-- ExtensionAttribute
    Expr <|-- ImportedName
    Expr <|-- InternalName
    Expr <|-- MarkSafe
    Expr <|-- MarkSafeIfAutoescape
    Expr <|-- ContextReference
    Expr <|-- DerivedContextReference

    Literal <|-- Const
    Literal <|-- TemplateData
    Literal <|-- Tuple
    Literal <|-- List
    Literal <|-- Dict

    BinExpr <|-- Mul
    BinExpr <|-- Div
    BinExpr <|-- FloorDiv
    BinExpr <|-- Add
    BinExpr <|-- Sub
    BinExpr <|-- Mod
    BinExpr <|-- Pow
    BinExpr <|-- And
    BinExpr <|-- Or

    UnaryExpr <|-- Not
    UnaryExpr <|-- Neg
    UnaryExpr <|-- Pos

    _FilterTestCommon <|-- Filter
    _FilterTestCommon <|-- Test

    Helper <|-- Pair
    Helper <|-- Keyword
    Helper <|-- Operand
```

---

## Core Concepts

### The `NodeType` Metaclass

`NodeType` is the metaclass for all nodes. It automatically handles **field and attribute inheritance**: when a subclass is created, the `fields` and `attributes` tuples from the parent class are merged with those declared on the child. This enforces a single-inheritance, conflict-free layout.

```python
class NodeType(type):
    def __new__(mcs, name, bases, d):
        for attr in "fields", "attributes":
            storage = []
            storage.extend(getattr(bases[0] if bases else object, attr, ()))
            storage.extend(d.get(attr, ()))
            assert len(bases) <= 1, "multiple inheritance not allowed"
            assert len(storage) == len(set(storage)), "layout conflict"
            d[attr] = tuple(storage)
        d.setdefault("abstract", False)
        return type.__new__(mcs, name, bases, d)
```

> **Note:** At the end of the module, `NodeType.__new__` is replaced with a failing function to prevent users from creating custom node types. Extensions must use the built-in nodes or the helper nodes provided for extensions.

### Fields vs. Attributes

- **Fields** are passed as positional arguments to the constructor and represent the structural children of a node (e.g., `For.target`, `For.iter`, `For.body`).
- **Attributes** are passed as keyword arguments and are metadata. Every node has two default attributes: `lineno` and `environment`.

The `Node.__init__` validates that the correct number of positional arguments is supplied and that no unknown attributes are passed.

### The `as_const()` Protocol

Expressions implement `as_const(eval_ctx)`, which attempts to evaluate the node to a Python constant at compile time. If evaluation is not possible (e.g., the value depends on runtime data, or the environment is sandboxed with intercepted operators), the method raises `Impossible`. This protocol is the foundation of constant folding in the [optimizer](optimizer.md) and the compiler.

```mermaid
flowchart TD
    A[Expr.as_const called] --> B{Can evaluate?}
    B -->|Yes| C[Return Python constant]
    B -->|No| D[Raise Impossible]
    C --> E[Optimizer replaces node with Const]
    D --> F[Node evaluated at runtime]
```

### `EvalContext`

`EvalContext` holds evaluation-time information that flows through the tree during compilation:

| Attribute | Description |
|-----------|-------------|
| `environment` | The Jinja `Environment` instance |
| `autoescape` | Whether autoescaping is active (resolved from `environment.autoescape`) |
| `volatile` | Set to `True` when a value cannot be determined at compile time |

It supports `save()` / `revert()` for scoped modifications (used by `ScopedEvalContextModifier`).

---

## Node Categories

### Statement Nodes (`Stmt`)

Statements represent control flow and template structure. Key examples:

| Node | Purpose |
|------|---------|
| `Template` | Outermost wrapper; `body` is the list of top-level nodes |
| `Output` | Holds expressions to be printed (template data and `{{ }}`) |
| `For` | For loop with `target`, `iter`, `body`, `else_`, `test`, `recursive` |
| `If` | Conditional with `test`, `body`, `elif_`, `else_` |
| `Macro` | Macro definition with `name`, `args`, `defaults`, `body` |
| `CallBlock` | Unnamed macro invoked via `call` |
| `FilterBlock` | Applies a filter to a block body |
| `Block` | Named block with `scoped` and `required` flags |
| `Extends` | Template inheritance |
| `Include` / `Import` / `FromImport` | Template inclusion and importing |
| `Assign` / `AssignBlock` | Variable assignment |
| `With` | Scoped variable binding |
| `Scope` / `OverlayScope` | Artificial scopes |
| `EvalContextModifier` / `ScopedEvalContextModifier` | Modify the eval context |
| `Continue` / `Break` | Loop control |

### Expression Nodes (`Expr`)

Expressions produce values. They implement `as_const()` and `can_assign()`.

- **Binary operators** (`BinExpr` subclasses): `Add`, `Sub`, `Mul`, `Div`, `FloorDiv`, `Mod`, `Pow`, `And`, `Or`. Each maps to a Python operator via `_binop_to_func`.
- **Unary operators** (`UnaryExpr` subclasses): `Not`, `Neg`, `Pos`, mapped via `_uaop_to_func`.
- **Literals** (`Literal` subclasses): `Const`, `TemplateData`, `Tuple`, `List`, `Dict`.
- **Lookups**: `Name`, `NSRef`, `Getattr`, `Getitem`, `Slice`.
- **Calls and filters**: `Call`, `Filter`, `Test` (both via `_FilterTestCommon`).
- **Comparison**: `Compare` with a list of `Operand` helpers, mapped via `_cmpop_to_func`.
- **Special**: `CondExpr`, `Concat`, `MarkSafe`, `MarkSafeIfAutoescape`, `ContextReference`, `DerivedContextReference`.

### Helper Nodes (`Helper`)

Helpers exist only within a specific parent context:

- `Pair` — key/value pair for `Dict`
- `Keyword` — key/value pair for keyword arguments
- `Operand` — operator/expression pair for `Compare`

### Extension Helper Nodes

These nodes are provided specifically for use by [extensions](extension_and_customization.md):

- `EnvironmentAttribute` — loads an attribute from the environment
- `ExtensionAttribute` — loads an attribute from a bound extension
- `ImportedName` — represents an optimized import
- `InternalName` — compiler-internal identifier (created via `Parser.free_identifier`)
- `MarkSafe` / `MarkSafeIfAutoescape` — mark expressions as safe

---

## Tree Traversal and Manipulation

The `Node` base class provides several traversal utilities used throughout the codebase:

```mermaid
flowchart LR
    subgraph "Node traversal API"
        IF[iter_fields]
        ICN[iter_child_nodes]
        F[find]
        FA[find_all]
    end
    IF --> ICN
    ICN --> F
    ICN --> FA
```

| Method | Description |
|--------|-------------|
| `iter_fields(exclude, only)` | Yields `(name, value)` for each field |
| `iter_child_nodes(exclude, only)` | Yields direct child `Node` instances (flattens lists) |
| `find(node_type)` | Returns the first node of a given type, or `None` |
| `find_all(node_type)` | Yields all nodes of a given type (recursively) |
| `set_ctx(ctx)` | Resets the `ctx` field of the node and all descendants (used for assignment targets) |
| `set_lineno(lineno, override)` | Sets line numbers across the subtree |
| `set_environment(environment)` | Attaches an environment to all nodes |
| `dump()` | Produces a Python-repr-like string of the tree |

These methods are heavily used by the [parser](parser.md) (e.g., `set_ctx("store")` on assignment targets, `set_environment` at the end of parsing) and by the [compiler](compiler.md) (e.g., `find_all(nodes.Block)` to collect blocks).

---

## Interaction with Other Modules

### Parser → Nodes

The [parser](parser.md) constructs node instances as it consumes tokens from the [lexer](lexer.md). For example, `parse_for()` builds a `nodes.For`, `parse_if()` builds a `nodes.If`, and `parse_expression()` builds the expression tree. The parser also uses `Node.set_ctx()` to mark assignment targets and `Node.set_environment()` to attach the environment to the final `Template` node.

### Nodes → Visitor

The [visitor](visitor.md) module (`NodeVisitor`, `NodeTransformer`) walks the tree using `iter_child_nodes()`. The `NodeTransformer` uses `iter_fields()` to replace or remove nodes in place. The [optimizer](optimizer.md) is a `NodeTransformer` that folds constant expressions using `as_const()`.

### Nodes → Compiler

The [compiler](compiler.md) (`CodeGenerator`) is a `NodeVisitor` with a `visit_*` method for every node type. It reads node fields to emit Python source code. The [idtracking](idtracking.md) module's `Symbols` class analyzes nodes to determine variable references and loads.

### Nodes → Runtime

Some nodes reference runtime constructs. For example, `ContextReference` compiles to the runtime `context` object, and `MarkSafe` compiles to `Markup`. The [runtime](runtime_execution_and_api.md) module provides `Context`, `Macro`, `LoopContext`, and `Undefined`, which the compiled code interacts with.

### `_PassArg` and Filters/Tests

The `_FilterTestCommon.as_const()` method uses `_PassArg.from_obj()` (from [utils](utils.md)) to determine whether a filter or test requires the context, eval context, or environment to be passed. This same mechanism is used by the compiler when emitting filter/test calls.

```mermaid
sequenceDiagram
    participant P as Parser
    participant N as nodes.py
    participant O as Optimizer
    participant C as CodeGenerator

    P->>N: Construct node tree
    N->>N: set_environment()
    O->>N: as_const() for folding
    N-->>O: Const or Impossible
    C->>N: visit_*() per node
    N-->>C: fields for codegen
```

---

## Constant Folding Flow

The `as_const()` protocol enables compile-time evaluation. The flow below shows how a binary expression is folded:

```mermaid
flowchart TD
    A[BinExpr.as_const] --> B{Sandboxed and<br/>intercepted op?}
    B -->|Yes| C[Raise Impossible]
    B -->|No| D[Lookup operator in _binop_to_func]
    D --> E[Evaluate left.as_const]
    E --> F[Evaluate right.as_const]
    F --> G[Apply operator]
    G --> H[Return result]
    E -->|Impossible| C
    F -->|Impossible| C
    G -->|Exception| C
```

The `Optimizer` (a `NodeTransformer`) calls `as_const()` on every `Expr` node and replaces it with a `Const` node when successful, using `Const.from_untrusted()` to verify the value has a safe representation.

---

## Key Data Structures

### Operator Mapping Tables

The module defines three module-level dictionaries that map Jinja operators to Python callables:

| Table | Maps | Used by |
|-------|------|---------|
| `_binop_to_func` | Binary operators (`+`, `-`, `*`, ...) | `BinExpr.as_const` |
| `_uaop_to_func` | Unary operators (`not`, `+`, `-`) | `UnaryExpr.as_const` |
| `_cmpop_to_func` | Comparison operators (`eq`, `ne`, `in`, ...) | `Compare.as_const` |

### `Impossible` Exception

`Impossible` is raised whenever a node cannot perform a requested action (typically constant evaluation). It is caught by the optimizer and compiler to fall back to runtime evaluation.

---

## Summary

The `nodes` module is the **data model** of Jinja2's template language. It:

- Defines the complete AST via a metaclass-driven class hierarchy
- Provides traversal and mutation utilities used by the parser, visitors, and compiler
- Implements the `as_const()` constant-folding protocol that powers compile-time optimization
- Carries `EvalContext` through the tree to track autoescape and volatility

It is the central hub connecting the [lexer](lexer.md) and [parser](parser.md) (which produce nodes) to the [compiler](compiler.md), [optimizer](optimizer.md), and [idtracking](idtracking.md) (which consume and transform them).

## Related Modules

- [lexer](lexer.md) — Tokenizes template source
- [parser](parser.md) — Builds the node tree
- [visitor](visitor.md) — Generic tree traversal (`NodeVisitor`, `NodeTransformer`)
- [compiler](compiler.md) — Generates Python code from nodes
- [optimizer](optimizer.md) — Constant folding via `as_const()`
- [idtracking](idtracking.md) — Symbol/reference analysis over nodes
- [runtime_execution_and_api](runtime_execution_and_api.md) — Runtime objects referenced by compiled nodes
- [extension_and_customization](extension_and_customization.md) — Extensions that construct and consume nodes
- [utils](utils.md) — `_PassArg` used by filter/test constant folding
