# Native Types Module

## Introduction

The `nativetypes` module extends Jinja's standard rendering pipeline to produce **native Python types** instead of strings. While a regular Jinja template always renders to a `str`, a native template can render directly to `int`, `float`, `list`, `dict`, `tuple`, `bool`, `None`, or any other Python object that can be represented by a literal expression.

This is particularly useful when templates are used as lightweight configuration or data-serialization formats, where the output is expected to be consumed by Python code rather than displayed to a user.

The module is built on top of the [compilation and code generation](compiler.md) subsystem and the [runtime execution and API](environment.md) subsystem, customizing both the code generator and the environment/template classes.

**Source file:** `src/jinja2/nativetypes.py`

### Core Components

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `native_concat` | function | Converts a stream of rendered nodes into a single native Python value. |
| `NativeCodeGenerator` | class | A `CodeGenerator` subclass that omits `str()` wrapping around output nodes. |
| `NativeEnvironment` | class | An `Environment` subclass wired to use `NativeCodeGenerator` and `native_concat`. |
| `NativeTemplate` | class | A `Template` subclass whose `render`/`render_async` return native types. |

---

## Architecture Overview

The module follows the classic Jinja extension pattern: it subclasses the three central abstractions (`CodeGenerator`, `Environment`, `Template`) and overrides only the pieces responsible for turning rendered output into a final value.

```mermaid
graph TD
    subgraph "nativetypes module"
        NE[NativeEnvironment]
        NT[NativeTemplate]
        NCG[NativeCodeGenerator]
        NC[native_concat]
    end

    subgraph "compilation_and_codegen"
        ENV[Environment]
        CG[CodeGenerator]
        FR[Frame]
        HSR[has_safe_repr]
    end

    subgraph "runtime_execution_and_api"
        TPL[Template]
        CTX[Context]
    end

    NE -- "extends" --> ENV
    NT -- "extends" --> TPL
    NCG -- "extends" --> CG

    NE -- "code_generator_class" --> NCG
    NE -- "concat" --> NC
    NE -- "template_class" --> NT
    NT -- "environment_class" --> NE

    NCG -- "uses" --> FR
    NCG -- "uses" --> HSR
    NT -- "uses" --> CTX
```

### Class Relationship Diagram

```mermaid
classDiagram
    class Environment {
        +code_generator_class
        +concat
        +template_class
        +is_async
    }
    class Template {
        +environment_class
        +render()
        +render_async()
        +new_context()
        +root_render_func()
    }
    class CodeGenerator {
        +_default_finalize()
        +_output_const_repr()
        +_output_child_to_const()
        +_output_child_pre()
        +_output_child_post()
    }

    Environment <|-- NativeEnvironment
    Template <|-- NativeTemplate
    CodeGenerator <|-- NativeCodeGenerator

    NativeEnvironment --> NativeCodeGenerator : code_generator_class
    NativeEnvironment --> NativeTemplate : template_class
    NativeTemplate --> NativeEnvironment : environment_class
```

---

## Component Details

### `native_concat`

```python
def native_concat(values: t.Iterable[t.Any]) -> t.Optional[t.Any]:
```

The heart of native rendering. It receives the iterable of values produced by the compiled template's `root_render_func` and reduces them to a single Python value using the following algorithm:

1. **Empty input** → returns `None`.
2. **Single value** → if it is not a string, it is returned as-is; if it is a string, it falls through to parsing.
3. **Multiple values** → all values are joined into a single string (re-joining the already-consumed head if the input was a generator).
4. **Parsing** → the resulting string is parsed with `ast.parse(..., mode="eval")` and evaluated with `ast.literal_eval`. If parsing succeeds, the native value is returned; otherwise the raw string is returned.

> **Note on Python 3.10+:** `ast.literal_eval` strips leading whitespace/tabs from the input string. To preserve backwards compatibility, `native_concat` calls `ast.parse` itself (which does not strip) before passing the AST to `literal_eval`.

```mermaid
flowchart TD
    A[values iterable] --> B{head = first 2 items}
    B -->|empty| C[return None]
    B -->|1 item| D{is it a str?}
    D -->|no| E[return raw value]
    D -->|yes| F[raw = that string]
    B -->|2+ items| G[re-chain generator if needed]
    G --> H[raw = join of str v for v in values]
    F --> I[ast.parse raw mode=eval]
    H --> I
    I --> J{literal_eval succeeds?}
    J -->|yes| K[return parsed native value]
    J -->|no| L[return raw string]
```

The `try/except` guards against `ValueError`, `SyntaxError`, and `MemoryError`, all of which indicate the string is not a valid Python literal.

### `NativeCodeGenerator`

```python
class NativeCodeGenerator(CodeGenerator):
```

A subclass of [`CodeGenerator`](compiler.md) that changes how output nodes are compiled so that values are **not** coerced to strings. It overrides five methods:

| Method | Standard behavior | Native behavior |
|--------|-------------------|-----------------|
| `_default_finalize` | `str(value)` | returns `value` unchanged |
| `_output_const_repr` | `repr(concat(group))` | `repr("".join(str(v) for v in group))` |
| `_output_child_to_const` | escapes + finalizes constants | returns `const` directly for `TemplateData`, otherwise `finalize.const(const)`; raises `Impossible` if `has_safe_repr` fails |
| `_output_child_pre` | writes `str(`/`escape(` wrappers | writes only `finalize.src` if present |
| `_output_child_post` | writes closing `)` | writes `)` only if `finalize.src` is present |

The key insight is that by **not** wrapping output children in `str(...)`, the generated code yields the raw Python objects. The `native_concat` function then decides whether to return a single object directly or to join and re-parse multiple fragments.

`has_safe_repr` (imported from the compiler module) is used to verify that a constant can be safely represented as a Python literal before it is emitted at compile time.

### `NativeEnvironment`

```python
class NativeEnvironment(Environment):
    code_generator_class = NativeCodeGenerator
    concat = staticmethod(native_concat)
```

A thin subclass of [`Environment`](environment.md) that wires together the native code generator and the native concatenation function. Because `concat` is a `staticmethod`, it is invoked as `environment.concat(...)` without an implicit `self`, matching the call sites in `NativeTemplate`.

### `NativeTemplate`

```python
class NativeTemplate(Template):
    environment_class = NativeEnvironment
```

A subclass of [`Template`](environment.md) that overrides the two rendering entry points:

- **`render(*args, **kwargs)`** — builds a context via `new_context`, calls `root_render_func`, and passes the result to `environment_class.concat`. Exceptions are routed through `environment.handle_exception()`.
- **`render_async(*args, **kwargs)`** — the async equivalent; raises `RuntimeError` if the environment was not created with async mode enabled, then collects the async generator into a list before concatenation.

The class attribute `environment_class = NativeEnvironment` ensures that a `NativeTemplate` created directly (via `Template.__new__`) uses a native environment.

Finally, the module closes the loop by assigning:

```python
NativeEnvironment.template_class = NativeTemplate
```

This mutual wiring guarantees that `NativeEnvironment` produces `NativeTemplate` instances and that `NativeTemplate` uses `NativeEnvironment`.

---

## Data Flow

The following sequence diagram shows how a native render flows through the system, from the caller down to the returned native value.

```mermaid
sequenceDiagram
    participant User
    participant NT as NativeTemplate
    participant NE as NativeEnvironment
    participant CG as NativeCodeGenerator
    participant NC as native_concat

    Note over CG: Compile time
    NE->>CG: generate(template AST)
    CG->>CG: _output_child_pre (no str wrapper)
    CG->>CG: _output_child_to_const (raw const)
    CG-->>NE: compiled code object

    Note over NT: Render time
    User->>NT: render(**kwargs)
    NT->>NT: new_context(kwargs)
    NT->>NT: root_render_func(ctx)
    NT->>NC: concat(rendered nodes)
    NC->>NC: join / literal_eval
    NC-->>NT: native Python value
    NT-->>User: native value
```

### Compile-time vs. Runtime Responsibilities

```mermaid
graph LR
    subgraph "Compile time (NativeCodeGenerator)"
        A[Output node children] --> B{constant?}
        B -->|yes, safe repr| C[emit literal]
        B -->|no| D[emit runtime expression without str]
    end
    subgraph "Runtime (native_concat)"
        E[rendered fragments] --> F{single non-str?}
        F -->|yes| G[return as-is]
        F -->|no| H[join + literal_eval]
    end
    C --> E
    D --> E
```

---

## Integration with the Broader System

The `nativetypes` module sits in the **compilation and code generation** layer of Jinja, but it reaches into the **runtime execution and API** layer to override rendering behavior.

```mermaid
graph TD
    subgraph "template_parsing_frontend"
        LEX[lexer]
        PAR[parser]
        NODES[nodes]
        VIS[visitor]
    end

    subgraph "compilation_and_codegen"
        COMP[compiler]
        OPT[optimizer]
        IDT[idtracking]
        META[meta]
        NAT[nativetypes]
    end

    subgraph "runtime_execution_and_api"
        ENV[environment]
        RT[runtime]
        EXC[exceptions]
    end

    subgraph "template_loading_and_caching"
        LOAD[loaders]
        BCC[bccache]
    end

    LEX --> PAR --> NODES --> COMP
    COMP --> NAT
    NAT --> ENV
    ENV --> RT
    ENV --> EXC
    LOAD --> ENV
    BCC --> ENV
```

### Dependency Summary

| Dependency | Used for |
|------------|----------|
| [`compiler.CodeGenerator`](compiler.md) | Base class for `NativeCodeGenerator`; provides output-node compilation hooks. |
| [`compiler.Frame`](compiler.md) | Compile-time frame passed to the overridden output methods. |
| [`compiler.has_safe_repr`](compiler.md) | Validates that a constant can be emitted as a Python literal. |
| [`environment.Environment`](environment.md) | Base class for `NativeEnvironment`; provides `concat`, `code_generator_class`, `template_class`. |
| [`environment.Template`](environment.md) | Base class for `NativeTemplate`; provides `render`, `render_async`, `new_context`, `root_render_func`. |
| [`nodes`](nodes.md) | Node types (`Expr`, `TemplateData`, `Impossible`) referenced by the code generator overrides. |

---

## Usage Example

```python
from jinja2.nativetypes import NativeEnvironment

env = NativeEnvironment()

# Renders to an int, not the string "42"
t = env.from_string("{{ 40 + 2 }}")
assert t.render() == 42

# Renders to a list
t = env.from_string("{{ [1, 2, 3] }}")
assert t.render() == [1, 2, 3]

# Renders to a dict
t = env.from_string("{{ {'a': 1, 'b': 2} }}")
assert t.render() == {"a": 1, "b": 2}

# Multiple fragments are joined and re-parsed
t = env.from_string("{{ 1 }}{{ 2 }}")
assert t.render() == 12

# Non-literal output falls back to a string
t = env.from_string("hello {{ name }}")
assert t.render(name="world") == "hello world"
```

### Async Usage

```python
env = NativeEnvironment(enable_async=True)
t = env.from_string("{{ [x async for x in ...] }}")  # async-capable template
value = await t.render_async()
```

---

## Design Notes and Caveats

- **Single-node fast path:** When a template renders to exactly one non-string node, that object is returned directly without any string conversion. This is the most efficient and most "native" case.
- **Multi-node re-parsing:** When a template produces multiple fragments, they are concatenated into a string and re-parsed. This means `{{ 1 }}{{ 2 }}` yields the integer `12`, not the tuple `(1, 2)`.
- **Fallback to string:** Any output that is not a valid Python literal (e.g., free-form text) is returned as a plain string, making the behavior a graceful superset of normal rendering.
- **`literal_eval` safety:** Because `ast.literal_eval` only evaluates literals, native rendering does not execute arbitrary code — it is safe to use with untrusted template output.
- **Python 3.10+ whitespace handling:** The explicit `ast.parse` call preserves leading whitespace that `literal_eval` would otherwise strip, maintaining consistent behavior across Python versions.
- **Async support:** `render_async` requires `enable_async=True` on the environment and raises `RuntimeError` otherwise.

---

## Related Documentation

- [Compilation and Code Generation](compiler.md) — the `CodeGenerator`, `Frame`, and `has_safe_repr` that `NativeCodeGenerator` builds upon.
- [Runtime Execution and API](environment.md) — the `Environment` and `Template` base classes extended here.
- [Template Parsing Frontend](nodes.md) — the AST node types referenced by the code generator overrides.
- [Template Loading and Caching](loaders.md) — how templates are loaded before native rendering.
