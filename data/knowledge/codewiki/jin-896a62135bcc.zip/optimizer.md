# Optimizer Module

## Introduction

The `optimizer` module provides a compile-time AST (Abstract Syntax Tree) optimization pass for Jinja templates. Its primary responsibility is **constant folding**: it walks the parsed template AST and replaces expressions that can be evaluated at compile time with their pre-computed constant values. This reduces the amount of work performed at render time and produces smaller, faster generated Python code.

The module is intentionally small and focused. It exposes a single public function, `optimize`, and a single class, `Optimizer`, which is a specialized `NodeTransformer`. The optimizer is invoked by the code generation pipeline (see [compiler.md](compiler.md)) when the environment is configured with `optimized=True` (the default).

> **Design note:** Because the AST does not carry complete scoping information, the optimizer cannot perform aggressive transformations such as loop unrolling (unrolled loops would have a different scope). A second syntax tree storing scoping rules would be required to enable such optimizations.

---

## Architecture Overview

The optimizer sits between the parsing frontend and the code generator. It consumes a parsed AST and produces a semantically equivalent, but partially pre-evaluated, AST.

```mermaid
flowchart LR
    subgraph Frontend["Template Parsing Frontend"]
        L[Lexer] --> P[Parser]
        P --> AST[AST: nodes.Template]
    end

    subgraph Compilation["Compilation & Codegen"]
        AST --> OPT[Optimizer]
        OPT --> CG[CodeGenerator]
        CG --> PY[Generated Python Code]
    end

    ENV[Environment] -.->|optimized flag| OPT
    ENV -.->|environment ref| OPT
```

The optimizer is a **pure AST-to-AST transformation**: it does not execute the template, does not touch the environment's runtime state, and does not emit code. It only rewrites nodes in place.

---

## Core Components

### `optimize(node, environment)`

The module-level entry point. It instantiates an `Optimizer` with the given environment and runs the visitor over the supplied node tree.

```python
def optimize(node: nodes.Node, environment: "Environment") -> nodes.Node:
    optimizer = Optimizer(environment)
    return t.cast(nodes.Node, optimizer.visit(node))
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `node` | `nodes.Node` | The root of the AST to optimize (typically a `nodes.Template`). |
| `environment` | `Environment` | The environment providing configuration and the `finalize`/`undefined` context used during constant evaluation. |

**Returns:** The optimized node tree (the same tree, mutated in place).

### `Optimizer`

A subclass of `NodeTransformer` (from [visitor.md](visitor.md)) that performs constant folding.

```python
class Optimizer(NodeTransformer):
    def __init__(self, environment: "t.Optional[Environment]") -> None:
        self.environment = environment
```

The class stores a reference to the environment, which is passed down to `Const.from_untrusted` so that newly created constant nodes carry the correct environment reference.

#### `generic_visit(node, *args, **kwargs)`

This is the heart of the optimizer. It overrides the base `NodeTransformer.generic_visit` to add constant-folding behavior after the standard recursive traversal.

```python
def generic_visit(self, node, *args, **kwargs):
    node = super().generic_visit(node, *args, **kwargs)

    # Do constant folding. Some other nodes besides Expr have
    # as_const, but folding them causes errors later on.
    if isinstance(node, nodes.Expr):
        try:
            return nodes.Const.from_untrusted(
                node.as_const(args[0] if args else None),
                lineno=node.lineno,
                environment=self.environment,
            )
        except nodes.Impossible:
            pass

    return node
```

**Algorithm:**

1. **Recurse first** — call `super().generic_visit(...)` so that all child nodes are optimized bottom-up before the current node is considered.
2. **Attempt folding** — if the (now-optimized) node is an `Expr`, try to evaluate it to a constant via `node.as_const(...)`.
3. **Wrap in `Const`** — if evaluation succeeds, wrap the resulting value in a `nodes.Const` using `Const.from_untrusted`, preserving the original line number and environment.
4. **Graceful fallback** — if `as_const` raises `nodes.Impossible`, the node is left unchanged and will be evaluated at runtime.

> **Why only `Expr` nodes?** The comment in the source notes that although other node types also implement `as_const`, folding them causes errors later in the pipeline. Restricting folding to `Expr` nodes keeps the transformation safe.

---

## Constant Folding Process

The following sequence diagram illustrates how a single expression node is folded during a traversal.

```mermaid
sequenceDiagram
    participant T as NodeTransformer.generic_visit
    participant O as Optimizer.generic_visit
    participant E as Expr node
    participant C as Const.from_untrusted

    O->>T: super().generic_visit(node)
    T-->>O: node (children optimized)
    O->>O: isinstance(node, Expr)?
    alt node is Expr
        O->>E: node.as_const(eval_ctx)
        alt evaluation succeeds
            E-->>O: constant value
            O->>C: from_untrusted(value, lineno, environment)
            C->>C: has_safe_repr(value)?
            alt safe repr
                C-->>O: Const node
                O-->>T: Const node (replaces Expr)
            else unsafe repr
                C-->>O: raise Impossible
                O-->>T: original node
            end
        else evaluation impossible
            E-->>O: raise Impossible
            O-->>T: original node
        end
    else node is not Expr
        O-->>T: node unchanged
    end
```

### Two-Layer Safety Check

Constant folding is guarded by **two independent safety mechanisms**:

1. **`Expr.as_const()`** — Each expression node decides whether it can be evaluated statically. Nodes that depend on runtime state (e.g., variable lookups, function calls) raise `nodes.Impossible`. See [nodes.md](nodes.md) for the `Expr` base class and its subclasses.

2. **`Const.from_untrusted()`** — Even when a value is computed, it is only accepted if it has a *safe representation* (i.e., `eval(repr(x)) == x`). This is verified by `has_safe_repr` in the compiler module. Values that cannot be safely embedded in generated source code raise `Impossible` and are left for runtime evaluation.

```mermaid
flowchart TD
    A[Expr node] --> B{as_const succeeds?}
    B -->|No: Impossible| Z[Keep node for runtime]
    B -->|Yes| C{has_safe_repr?}
    C -->|No: Impossible| Z
    C -->|Yes| D[Replace with Const node]
```

---

## Integration with the Compilation Pipeline

The optimizer is not invoked directly by end users. Instead, it is wired into the code generation process through the `CodeGenerator`.

```mermaid
flowchart TD
    ENV[Environment.compile] --> GEN[generate / CodeGenerator]
    GEN --> CHK{optimized?}
    CHK -->|True| NEW[Create Optimizer instance]
    CHK -->|False| SKIP[optimizer = None]
    NEW --> VISIT[CodeGenerator visits AST]
    SKIP --> VISIT
    VISIT --> OUT[Generated Python source]
```

Key integration points:

- **`Environment.optimized`** — The environment flag (default `True`) controls whether optimization is enabled. It is passed through `Environment._generate` into the `generate` function and ultimately to `CodeGenerator`.
- **`CodeGenerator.__init__`** — When `optimized=True`, the code generator constructs an `Optimizer(environment)` and stores it as `self.optimizer`. The `optimized` property returns `self.optimizer is not None`.
- **`CodeGenerator._output_child_to_const`** — During output generation, the compiler independently attempts to convert `Output` children to constants using `node.as_const(frame.eval_ctx)`, complementing the optimizer's work at the AST level.

For full details on how the optimizer is consumed, see [compiler.md](compiler.md).

---

## Dependencies

```mermaid
graph TD
    OPT[optimizer.Optimizer]
    OPT -->|subclasses| NT[visitor.NodeTransformer]
    OPT -->|reads/writes| NODES[nodes module]
    OPT -->|uses| CONST[nodes.Const.from_untrusted]
    OPT -->|catches| IMP[nodes.Impossible]
    OPT -->|holds ref| ENV[environment.Environment]
    CONST -->|calls| HSR[compiler.has_safe_repr]

    NT --> NV[visitor.NodeVisitor]
    NODES --> EXPR[nodes.Expr.as_const]
```

| Dependency | Purpose |
|------------|---------|
| [`visitor.NodeTransformer`](visitor.md) | Base class providing recursive AST traversal and node replacement. |
| [`nodes`](nodes.md) | AST node types; `Expr`, `Const`, `Impossible`, and `Node` are central. |
| [`compiler.has_safe_repr`](compiler.md) | Validates that a constant value can be safely represented in generated code. |
| [`environment.Environment`](environment.md) | Provides configuration and is attached to newly created `Const` nodes. |

---

## Data Flow Summary

```mermaid
flowchart LR
    A[Parsed AST] --> B[Optimizer.visit]
    B --> C[NodeTransformer.generic_visit]
    C --> D[Recurse into children]
    D --> E{Expr node?}
    E -->|Yes| F[as_const + from_untrusted]
    E -->|No| G[Leave unchanged]
    F --> H[Optimized AST]
    G --> H
    H --> I[CodeGenerator]
```

The optimizer performs a **single bottom-up pass** over the AST. Because children are optimized before their parents, nested constant expressions are fully collapsed (e.g., `1 + 2 + 3` becomes `Const(6)`).

---

## Limitations

- **No loop unrolling** — Loops cannot be unrolled because the AST lacks scoping information; unrolled loops would have a different scope.
- **No scope-aware optimizations** — The compiler is responsible for discovering scoping rules, so the optimizer cannot make decisions that depend on variable scope.
- **Only `Expr` nodes are folded** — Folding other node types (which also implement `as_const`) causes downstream errors.
- **Safe-representation constraint** — Only values with a safe `repr` are folded; others remain runtime expressions.

---

## Related Documentation

- [compiler.md](compiler.md) — The code generator that consumes the optimized AST.
- [nodes.md](nodes.md) — AST node definitions, including `Expr`, `Const`, and `Impossible`.
- [visitor.md](visitor.md) — The `NodeVisitor` / `NodeTransformer` traversal framework.
- [environment.md](environment.md) — The `Environment` and its `optimized` configuration flag.
