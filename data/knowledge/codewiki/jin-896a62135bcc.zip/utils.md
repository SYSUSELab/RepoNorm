# Utils Module

## Introduction

The `utils` module (`src/jinja2/utils.py`) provides a collection of foundational helper utilities that are shared across the entire Jinja2 template engine. Unlike the higher-level modules that implement parsing, compilation, or rendering, this module contains small, self-contained building blocks that other modules depend on.

Its responsibilities fall into several categories:

- **Template-facing helper objects** — `Cycler`, `Joiner`, and `Namespace`, which are exposed directly to template authors as globals.
- **Caching infrastructure** — `LRUCache`, a lightweight least-recently-used cache used to store compiled templates.
- **Argument-passing decorators** — `pass_context`, `pass_eval_context`, `pass_environment`, and the `_PassArg` enum that powers them, allowing filters/tests/functions to receive runtime context.
- **General-purpose helpers** — string/URL utilities (`urlize`, `url_quote`), serialization (`htmlsafe_json_dumps`), import helpers (`import_string`), and various small utilities (`is_undefined`, `consume`, `clear_caches`, `object_type_repr`, `pformat`, `open_if_exists`, `generate_lorem_ipsum`, `select_autoescape`).

Because these utilities are consumed by nearly every other module, this module sits at the bottom of the dependency graph and has minimal dependencies of its own (only `markupsafe` and the standard library, plus lazy imports of Jinja internals to avoid circular imports).

---

## Architecture Overview

The `utils` module is a leaf dependency: many modules import from it, but it imports very little from the rest of Jinja2 (and only lazily, inside function bodies, to break circular dependencies).

```mermaid
graph TD
    subgraph "utils module"
        Cycler
        Joiner
        Namespace
        LRUCache
        PassArg["_PassArg"]
        Decorators["pass_context / pass_eval_context / pass_environment"]
        Helpers["urlize / url_quote / htmlsafe_json_dumps / import_string / ..."]
    end

    subgraph "Consumers"
        Environment["environment.Environment"]
        Runtime["runtime.Undefined / Context"]
        Filters["filters (filters & tests)"]
        Ext["ext (extensions)"]
        Loaders["loaders"]
        Lexer["lexer.Lexer"]
    end

    Decorators --> PassArg
    Environment -->|uses| LRUCache
    Environment -->|uses| Decorators
    Environment -->|uses| Helpers
    Runtime -->|uses| Helpers
    Filters -->|uses| Decorators
    Filters -->|uses| Helpers
    Ext -->|uses| Helpers
    Loaders -->|uses| Helpers
    Lexer -->|uses| Helpers
```

### Key Design Principles

1. **Lazy imports for circular-dependency avoidance.** Functions such as `is_undefined`, `clear_caches`, and `generate_lorem_ipsum` import their Jinja2 dependencies *inside* the function body. This keeps `utils` importable at the very start of the import chain.
2. **Template-global exposure.** `Cycler`, `Joiner`, and `Namespace` are registered as template globals so they can be used directly in templates (e.g. `{% set row = cycler("odd", "even") %}`).
3. **Decorator-based context injection.** The `_PassArg` enum is a lightweight marker attached to functions, later inspected by the environment when invoking filters/tests.

---

## Core Components

### `_PassArg` (enum)

`_PassArg` is an enumeration that marks *which* runtime object should be injected as the first argument to a decorated callable. It has three members:

| Member | Injected object | Decorator |
|--------|-----------------|-----------|
| `context` | `runtime.Context` | `pass_context` |
| `eval_context` | `nodes.EvalContext` | `pass_eval_context` |
| `environment` | `environment.Environment` | `pass_environment` |

The class method `from_obj(obj)` inspects an arbitrary object for a `jinja_pass_arg` attribute and returns the corresponding `_PassArg` member (or `None`). This is the mechanism the environment uses to decide how to call a filter or test.

```mermaid
classDiagram
    class _PassArg {
        <<enum>>
        context
        eval_context
        environment
        +from_obj(obj) Optional~_PassArg~
    }
    class pass_context {
        <<decorator>>
        sets jinja_pass_arg = context
    }
    class pass_eval_context {
        <<decorator>>
        sets jinja_pass_arg = eval_context
    }
    class pass_environment {
        <<decorator>>
        sets jinja_pass_arg = environment
    }
    pass_context --> _PassArg
    pass_eval_context --> _PassArg
    pass_environment --> _PassArg
```

**Interaction with the environment:** When a filter or test is invoked, `Environment._filter_test_common` calls `_PassArg.from_obj(func)` and, based on the result, inserts the appropriate object at the front of the argument list. See [runtime_execution_and_api.md](runtime_execution_and_api.md) for the full invocation flow.

### `LRUCache`

`LRUCache` is a simple least-recently-used cache implementation registered as a `collections.abc.MutableMapping`. It is optimized for small capacities (below ~1000 entries), which is sufficient for its primary use case: caching compiled templates in the `Environment`.

**Internal structure:**
- `_mapping`: a `dict` mapping keys to values.
- `_queue`: a `deque` tracking usage order (most-recently-used at the right).
- `_wlock`: a `threading.Lock` guarding mutations for thread safety.

**Behavior:**
- `__getitem__` moves the accessed key to the most-recently-used position.
- `__setitem__` evicts the least-recently-used entry (`_popleft`) when capacity is reached.
- Supports `get`, `setdefault`, `clear`, `copy`, `items`, `values`, `keys`, and iteration (most-recent-first via `__iter__`, oldest-first via `__reversed__`).
- Implements `__getstate__`/`__setstate__`/`__getnewargs__` for pickling, re-establishing the lock and queue aliases via `_postinit`.

```mermaid
flowchart LR
    A["__setitem__(key, value)"] --> B{"key in mapping?"}
    B -- yes --> C["remove key from queue"]
    B -- no --> D{"len == capacity?"}
    D -- yes --> E["evict _popleft()"]
    D -- no --> F["append key to queue"]
    C --> F
    E --> F
    F --> G["mapping[key] = value"]
```

The `Environment` uses this cache (via `create_cache`) to store loaded templates keyed by `(weakref(loader), name)`. See [template_loading_and_caching.md](template_loading_and_caching.md) for cache integration details.

### `Cycler`

`Cycler` cycles through a fixed set of items, yielding one at a time and restarting when the end is reached. It is exposed to templates as the `cycler` global and is useful for alternating values across (possibly multiple) loops.

- `__init__(*items)`: requires at least one item, otherwise raises `RuntimeError`.
- `current` (property): the item that will be returned next.
- `next()` / `__next__()`: returns the current item and advances the position (wrapping via modulo).
- `reset()`: resets the position to the first item.

### `Joiner`

`Joiner` is a small helper that returns an empty string on its first call and a separator on every subsequent call. It is exposed to templates as the `joiner` global and is typically used to insert separators between items.

- `__init__(sep=", ")`: configures the separator.
- `__call__()`: returns `""` the first time, then `sep` thereafter.

### `Namespace`

`Namespace` is a mutable object that holds arbitrary attributes, initialized from a dictionary or keyword arguments. It is exposed to templates as the `namespace` global, allowing templates to carry mutable state across scopes (e.g. accumulating values inside a loop).

- `__init__(*args, **kwargs)`: stores attributes in a private `__attrs` dict.
- `__getattribute__`: resolves attribute access against `__attrs`, raising `AttributeError` for missing names (with special handling for `_Namespace__attrs` and `__class__`).
- `__setitem__`: allows item-style assignment.
- `__repr__`: renders as `<Namespace {...}>`.

---

## Data Flow: Context Injection via Decorators

The following sequence shows how the decorators and `_PassArg` cooperate with the environment at render time.

```mermaid
sequenceDiagram
    participant Tpl as Template (compiled)
    participant Env as Environment
    participant PassArg as _PassArg
    participant Func as Filter/Test function

    Tpl->>Env: call_filter(name, value, ...)
    Env->>Env: func = self.filters[name]
    Env->>PassArg: from_obj(func)
    PassArg-->>Env: _PassArg.context / eval_context / environment / None
    alt context
        Env->>Func: func(context, value, ...)
    else eval_context
        Env->>Func: func(eval_ctx, value, ...)
    else environment
        Env->>Func: func(environment, value, ...)
    else None
        Env->>Func: func(value, ...)
    end
    Func-->>Env: result
    Env-->>Tpl: result
```

---

## Utility Functions Reference

Beyond the core classes, the module provides a set of standalone helpers. These are grouped below by purpose.

### Undefined & runtime helpers

| Function | Purpose |
|----------|---------|
| `is_undefined(obj)` | Instance check against `runtime.Undefined`; convenient for custom filters/tests. |
| `internalcode(f)` | Marks a function's code object as internal (tracked in `internal_code`). |
| `consume(iterable)` | Exhausts an iterable without using its values. |
| `clear_caches()` | Clears Jinja's internal environment and lexer caches. |

### Import & file helpers

| Function | Purpose |
|----------|---------|
| `import_string(import_name, silent=False)` | Imports an object from a dotted or colon-delimited path. |
| `open_if_exists(filename, mode="rb")` | Opens a file only if it exists, else returns `None`. |

### Formatting & representation

| Function | Purpose |
|----------|---------|
| `object_type_repr(obj)` | Returns a readable type name, with special cases for `None`/`Ellipsis`. |
| `pformat(obj)` | Wraps `pprint.pformat`. |
| `htmlsafe_json_dumps(obj, dumps=None, **kwargs)` | JSON-serializes and escapes HTML-unsafe characters, returning `Markup`. Backs the `|tojson` filter. |

### URL & text helpers

| Function | Purpose |
|----------|---------|
| `urlize(text, ...)` | Converts URLs and emails in text into clickable links. |
| `url_quote(obj, charset="utf-8", for_qs=False)` | Quotes a string/bytes for use in a URL. |
| `generate_lorem_ipsum(n=5, html=True, min=20, max=100)` | Generates lorem ipsum placeholder text. |

### Configuration helpers

| Function | Purpose |
|----------|---------|
| `select_autoescape(...)` | Returns a callable that decides autoescaping based on template filename. |

### Module-level singletons & constants

| Name | Purpose |
|------|---------|
| `missing` | A singleton representing a missing value at runtime. |
| `internal_code` | A set of code objects marked as internal. |
| `concat` | Alias for `"".join`. |
| `_http_re`, `_email_re` | Compiled regexes used by `urlize`. |

---

## Dependencies

```mermaid
graph LR
    subgraph "External"
        markupsafe
        stdlib["stdlib: enum, json, os, re, typing, collections, random, threading, types, urllib"]
    end
    subgraph "Jinja2 (lazy imports)"
        runtime["runtime.Undefined"]
        environment["environment.get_spontaneous_environment"]
        lexer["lexer._lexer_cache"]
        constants["constants.LOREM_IPSUM_WORDS"]
    end
    utils["utils module"] --> markupsafe
    utils --> stdlib
    utils -.->|lazy| runtime
    utils -.->|lazy| environment
    utils -.->|lazy| lexer
    utils -.->|lazy| constants
```

The lazy (dotted) edges are imported inside function bodies to avoid circular imports at module load time.

---

## How the Module Fits into the System

The `utils` module is a foundational layer consumed throughout Jinja2:

- **Environment** ([runtime_execution_and_api.md](runtime_execution_and_api.md)) uses `LRUCache` for template caching, the `pass_*` decorators for filter/test invocation, and helpers like `select_autoescape` and `htmlsafe_json_dumps`.
- **Runtime** ([runtime_execution_and_api.md](runtime_execution_and_api.md)) relies on `is_undefined`, `object_type_repr`, and the `missing` singleton.
- **Filters & Tests** ([extension_and_customization.md](extension_and_customization.md)) use the `pass_*` decorators and helpers such as `urlize`, `url_quote`, and `htmlsafe_json_dumps`.
- **Extensions** ([extension_and_customization.md](extension_and_customization.md)) use `import_string`, `clear_caches`, and `internalcode`.
- **Loaders & Bytecode Cache** ([template_loading_and_caching.md](template_loading_and_caching.md)) use `open_if_exists` and related file helpers.
- **Lexer** ([template_parsing_frontend.md](template_parsing_frontend.md)) participates in `clear_caches` via `_lexer_cache`.

Because it has no hard dependencies on higher-level modules, `utils` can be imported first and safely referenced everywhere else in the codebase.
