# Lexer Module

## Introduction

The `lexer` module (`src/jinja2/lexer.py`) implements a combined **Jinja / Python lexer** for the Jinja2 template engine. Its primary responsibility is to transform raw template source text into a stream of structured tokens that the [parser](parser.md) can consume to build an abstract syntax tree (AST).

The lexer performs several critical preprocessing tasks:

- **Separates template data from template code** — distinguishing literal text from expressions, statements, and comments.
- **Filters out invalid operators** — such as bitshift operators (`<<`, `>>`) that are not permitted in templates.
- **Handles whitespace control** — supporting `trim_blocks`, `lstrip_blocks`, and inline whitespace modifiers (`-`, `+`).
- **Normalizes newlines** — converting all line endings to a configured sequence.
- **Validates syntax** — raising `TemplateSyntaxError` for malformed input (unbalanced braces, invalid identifiers, unterminated tags, etc.).

The lexer is the **first stage** of the template parsing frontend pipeline and is a foundational dependency for the parser, which in turn feeds the [compiler](compiler.md).

---

## Architecture Overview

The lexer sits at the very beginning of the template processing pipeline. It is driven by configuration values from the [environment](environment.md) and produces tokens consumed by the [parser](parser.md).

```mermaid
flowchart LR
    subgraph Input
        SRC["Template Source<br/>(str)"]
    end

    subgraph "Lexer Module"
        LEX["Lexer"]
        TS["TokenStream"]
        TK["Token"]
    end

    subgraph "Environment Config"
        ENV["Environment<br/>(delimiters, whitespace flags)"]
    end

    subgraph Downstream
        PAR["Parser"]
        NODES["nodes (AST)"]
    end

    ENV -->|"compile_rules / get_lexer"| LEX
    SRC --> LEX
    LEX -->|"tokenize()"| TS
    TS -->|"yields"| TK
    TS --> PAR
    PAR --> NODES
```

### Key Design Principles

1. **Environment-agnostic lexers** — A `Lexer` is *not* bound to a single environment. Multiple environments that share identical delimiter and whitespace configuration can reuse the same lexer instance via the `_lexer_cache`.
2. **Rule-based tokenization** — Tokenization is driven by an ordered list of `_Rule` objects, each pairing a compiled regular expression with the tokens it produces and an optional state transition command.
3. **State machine** — The lexer maintains a stack of states (`root`, `block_begin`, `variable_begin`, `comment_begin`, `raw_begin`, etc.) to switch between literal-text mode and code-parsing mode.

---

## Core Components

### `Lexer`

The central class implementing the lexer. It is normally instantiated automatically by the environment (via `get_lexer`) and rarely needs to be created directly.

**Responsibilities:**

- Compiles the lexing rules from environment configuration (`compile_rules`).
- Builds the global rule table (`self.rules`) keyed by state name.
- Provides the public `tokenize()` entry point and the lower-level `tokeniter()` / `wrap()` generators.

**Key methods:**

| Method | Purpose |
| --- | --- |
| `tokenize(source, name, filename, state)` | Public entry point; returns a `TokenStream`. |
| `tokeniter(source, name, filename, state)` | Core state-machine generator yielding `(lineno, token_type, value)` tuples. |
| `wrap(stream, name, filename)` | Converts raw tuples into `Token` objects, performing value conversion and filtering. |
| `_normalize_newlines(value)` | Replaces all newline variants with the configured `newline_sequence`. |

**Constructor highlights:**

- Builds `tag_rules` (whitespace, float, integer, name, string, operator).
- Assembles `root_tag_rules` from `compile_rules(environment)`.
- Constructs the `root` rule with a `raw` block special case.
- Sets up per-state rule lists for comments, blocks, variables, raw blocks, line statements, and line comments.
- Configures `lstrip_unless_re` when `lstrip_blocks` is enabled.

### `Token`

A `NamedTuple` representing a single lexical token with three fields:

| Field | Type | Description |
| --- | --- | --- |
| `lineno` | `int` | Line number where the token begins. |
| `type` | `str` | Interned token type (e.g., `TOKEN_NAME`, `TOKEN_STRING`). |
| `value` | `str` | The token's textual or converted value. |

**Methods:**

- `test(expr)` — Tests the token against a token expression, either a bare type (`"name"`) or a `"type:value"` pair.
- `test_any(*iterable)` — Returns `True` if the token matches any of the given expressions.
- `__str__` — Returns a human-readable description via `describe_token`.

### `TokenStream`

An iterable wrapper around a token generator that supports **lookahead** and **pushback**, which the parser relies on heavily.

| Member | Description |
| --- | --- |
| `current` | The currently active token. |
| `eos` | Property; `True` when at end of stream. |
| `push(token)` | Pushes a token back onto the stream. |
| `look()` | Returns the next token without consuming it. |
| `skip(n)` | Advances `n` tokens. |
| `next_if(expr)` | Advances and returns the token if it matches `expr`, else `None`. |
| `skip_if(expr)` | Boolean variant of `next_if`. |
| `expect(expr)` | Advances and returns the token, raising `TemplateSyntaxError` on mismatch. |
| `close()` | Closes the stream and sets `current` to an EOF token. |

### `TokenStreamIterator`

The iterator returned by `TokenStream.__iter__`. It yields tokens until the EOF token is reached, at which point it closes the stream and raises `StopIteration`.

### `Failure`

A small helper class used inside `_Rule` definitions to represent **known error conditions**. When the lexer encounters a `Failure` token, it raises the associated `TemplateSyntaxError` (or a subclass) with the configured message.

```python
class Failure:
    def __init__(self, message, cls=TemplateSyntaxError): ...
    def __call__(self, lineno, filename):  # raises
        raise self.error_class(self.message, lineno, filename)
```

### `OptionalLStrip`

A special `tuple` subclass used to mark a rule whose matched text may have leading whitespace stripped (when `lstrip_blocks` is enabled). It behaves like a normal tuple but signals the lexer to apply lstrip logic.

### `_Rule`

A `NamedTuple` describing a single lexing rule:

| Field | Type | Description |
| --- | --- | --- |
| `pattern` | `Pattern[str]` | Compiled regular expression. |
| `tokens` | `str \| tuple \| tuple[Failure]` | Token type(s) to emit, or `"#bygroup"` for dynamic resolution. |
| `command` | `str \| None` | State transition command (`"#pop"`, `"#bygroup"`, or a state name). |

---

## Token Types

The module defines a comprehensive set of interned token type constants. They fall into several categories:

```mermaid
flowchart TB
    subgraph "Structural / Delimiter Tokens"
        BB["block_begin / block_end"]
        VB["variable_begin / variable_end"]
        CB["comment_begin / comment_end"]
        RB["raw_begin / raw_end"]
        LB["linestatement_begin / linestatement_end"]
        LCB["linecomment_begin / linecomment_end"]
    end

    subgraph "Literal Tokens"
        DATA["data"]
        STR["string"]
        INT["integer"]
        FLT["float"]
        NAME["name"]
        WS["whitespace"]
    end

    subgraph "Operator Tokens"
        OPS["add, sub, mul, div, floordiv, mod, pow,<br/>eq, ne, gt, gteq, lt, lteq, assign,<br/>dot, colon, pipe, comma, semicolon, tilde,<br/>lparen, rparen, lbracket, rbracket, lbrace, rbrace"]
    end

    subgraph "Control Tokens"
        INIT["initial"]
        EOF["eof"]
    end
```

### Operator Mapping

The `operators` dictionary maps operator strings to token types, and `reverse_operators` provides the inverse. The `operator_re` regex is built by sorting operators by descending length so that multi-character operators (e.g., `**`, `//`, `==`) are matched before their single-character prefixes.

### Ignored Tokens

- `ignored_tokens` — Tokens completely dropped during `wrap()` (comments, whitespace, line comments).
- `ignore_if_empty` — Tokens suppressed when their value is empty (whitespace, data, comments).

---

## Lexing Process

The lexing process is a two-phase pipeline: `tokeniter()` performs the state-machine tokenization, and `wrap()` converts the raw output into `Token` objects.

```mermaid
flowchart TD
    A["tokenize(source)"] --> B["tokeniter(source)"]
    B --> C["wrap(stream)"]
    C --> D["TokenStream"]

    subgraph "tokeniter (state machine)"
        B1["Split source into lines<br/>normalize newlines"]
        B2["Initialize stack = ['root']"]
        B3["Match rules against source[pos:]"]
        B4{"Match found?"}
        B5["Handle tuple tokens<br/>(lstrip, bygroup, Failure)"]
        B6["Handle string tokens<br/>(balance braces)"]
        B7["Apply state transition"]
        B8["Advance pos"]
        B9["Raise TemplateSyntaxError"]
        B1 --> B2 --> B3 --> B4
        B4 -->|yes| B5
        B4 -->|yes| B6
        B5 --> B7
        B6 --> B7
        B7 --> B8 --> B3
        B4 -->|no, EOF| B10["return"]
        B4 -->|no, mid-source| B9
    end

    subgraph "wrap (conversion)"
        C1["Skip ignored tokens"]
        C2["Convert values<br/>(int, float, string unescape)"]
        C3["Map operators to token types"]
        C4["Validate identifiers"]
        C5["Yield Token"]
        C1 --> C2 --> C3 --> C4 --> C5
    end
```

### Phase 1: `tokeniter()` — State Machine

1. **Line normalization** — The source is split on newline variants and rejoined with `\n`. Trailing newlines are removed unless `keep_trailing_newline` is set.
2. **State stack initialization** — Starts with `["root"]`; an optional `state` argument (`"variable"` or `"block"`) pushes the corresponding `_begin` state.
3. **Main loop** — For each state, rules are tried in order. The first matching rule wins.
4. **Brace balancing** — A `balancing_stack` tracks `{}`, `()`, `[]`. End tags (`variable_end`, `block_end`, `linestatement_end`) are only matched when the stack is balanced, preventing premature termination inside nested expressions.
5. **Whitespace control** — For `OptionalLStrip` rules, the `strip_sign` (`-`, `+`, or empty) determines whether surrounding whitespace is stripped or preserved.
6. **State transitions** — Commands `#pop`, `#bygroup`, or a literal state name modify the stack.
7. **Infinite-loop guard** — If a rule matches an empty string without a state change, a `RuntimeError` is raised.

### Phase 2: `wrap()` — Token Conversion

Converts raw `(lineno, token, value_str)` tuples into `Token` objects:

- Drops `ignored_tokens`.
- Remaps `linestatement_begin/end` → `block_begin/end`.
- Skips `raw_begin`/`raw_end` (not needed by the parser).
- Normalizes newlines in `data`.
- Validates identifiers (`name` tokens must be valid Python identifiers).
- Unescapes string literals.
- Parses integers (with `_` separators) and floats.
- Maps operator strings to their token types.

---

## State Machine

The lexer uses a stack-based state machine. Each state has its own ordered list of `_Rule` objects in `self.rules`.

```mermaid
stateDiagram-v2
    [*] --> root
    root --> comment_begin: comment_start_string
    root --> block_begin: block_start_string
    root --> variable_begin: variable_start_string
    root --> raw_begin: block_start + raw
    root --> linestatement_begin: line_statement_prefix
    root --> linecomment_begin: line_comment_prefix

    comment_begin --> root: comment_end_string (#pop)
    block_begin --> root: block_end_string (#pop)
    variable_begin --> root: variable_end_string (#pop)
    raw_begin --> root: endraw (#pop)
    linestatement_begin --> root: newline/EOF (#pop)
    linecomment_begin --> root: newline/EOF (#pop)
```

| State | Entered By | Exited By |
| --- | --- | --- |
| `root` | Initial state | — |
| `comment_begin` | Comment start delimiter | Comment end delimiter (`#pop`) |
| `block_begin` | Block start delimiter | Block end delimiter (`#pop`) |
| `variable_begin` | Variable start delimiter | Variable end delimiter (`#pop`) |
| `raw_begin` | `{% raw %}` | `{% endraw %}` (`#pop`) |
| `linestatement_begin` | Line statement prefix | Newline or EOF (`#pop`) |
| `linecomment_begin` | Line comment prefix | Newline or EOF (`#pop`) |

---

## Rule Compilation and Caching

### `compile_rules(environment)`

Builds the ordered list of root-level tag rules from environment configuration. Rules are sorted by descending delimiter length so that longer delimiters (e.g., `<%=`) are matched before shorter ones (e.g., `<%`).

### `get_lexer(environment)`

Returns a cached `Lexer` instance. The cache key is a tuple of all configuration values that affect lexing:

- `block_start_string` / `block_end_string`
- `variable_start_string` / `variable_end_string`
- `comment_start_string` / `comment_end_string`
- `line_statement_prefix` / `line_comment_prefix`
- `trim_blocks` / `lstrip_blocks`
- `newline_sequence` / `keep_trailing_newline`

The cache (`_lexer_cache`) is an [`LRUCache`](utils.md) with a capacity of 50, allowing multiple environments to share lexers when their configurations match.

```mermaid
flowchart LR
    ENV["Environment"] -->|"config tuple"| KEY["Cache Key"]
    KEY --> CACHE{"_lexer_cache<br/>(LRUCache, cap=50)"}
    CACHE -->|hit| LEX["Lexer"]
    CACHE -->|miss| NEW["Lexer(environment)"]
    NEW --> CACHE
```

---

## Whitespace Control

The lexer supports three whitespace-control mechanisms:

1. **`trim_blocks`** — When enabled, the first newline after a block tag is removed (`block_suffix_re = "\\n?"`).
2. **`lstrip_blocks`** — When enabled, leading whitespace before a block tag is stripped, *unless* non-whitespace precedes it on the line (governed by `lstrip_unless_re`).
3. **Inline modifiers** — The `-` and `+` signs immediately inside delimiters control whitespace stripping/preservation for individual tags.

The `OptionalLStrip` tuple marks rules where lstrip logic applies. During matching, the `strip_sign` group determines the behavior:

- `-` → strip all whitespace between text and tag.
- `+` → preserve whitespace.
- empty → apply `lstrip_blocks` if enabled and not a variable expression.

---

## Error Handling

The lexer raises [`TemplateSyntaxError`](exceptions.md) for various malformed inputs:

| Condition | Message |
| --- | --- |
| Unbalanced closing brace | `unexpected '}'` |
| Mismatched brace | `unexpected '}', expected ')'` |
| Invalid identifier | `Invalid character in identifier` |
| Unterminated comment | `Missing end of comment tag` |
| Unterminated raw block | `Missing end of raw directive` |
| Unexpected character | `unexpected char '...' at ...` |
| Failed `expect()` | `expected token '...', got '...'` |

The `Failure` class encapsulates known error conditions within rule definitions, allowing the lexer to raise the appropriate error when a rule matches an invalid pattern.

---

## Dependencies

```mermaid
flowchart TD
    LEXER["lexer.py"]

    LEXER --> IDENT["_identifier.py<br/>(name_re pattern)"]
    LEXER --> EXC["exceptions.py<br/>(TemplateSyntaxError)"]
    LEXER --> UTILS["utils.py<br/>(LRUCache)"]
    LEXER -.->|"TYPE_CHECKING"| ENV["environment.py<br/>(Environment)"]

    PARSER["parser.py"] --> LEXER
    ENV --> LEXER
```

| Dependency | Usage |
| --- | --- |
| [`_identifier`](utils.md) | Provides `name_re`, the regex pattern for valid identifiers. |
| [`exceptions`](exceptions.md) | `TemplateSyntaxError` for all syntax errors. |
| [`utils`](utils.md) | `LRUCache` for the lexer cache. |
| [`environment`](environment.md) | Type-only import; supplies configuration values. |

---

## Integration with the Parser

The [parser](parser.md) consumes the `TokenStream` produced by the lexer. It relies on the stream's lookahead and pushback capabilities (`look`, `push`, `next_if`, `skip_if`, `expect`) to implement recursive-descent parsing. The parser maps token types to AST nodes defined in the [nodes](nodes.md) module.

```mermaid
sequenceDiagram
    participant Env as Environment
    participant Lex as Lexer
    participant TS as TokenStream
    participant Par as Parser
    participant Nodes as nodes (AST)

    Env->>Lex: get_lexer(environment)
    Env->>Lex: tokenize(source)
    Lex->>TS: TokenStream(...)
    Env->>Par: Parser(environment, source)
    Par->>TS: current / look() / next_if()
    TS-->>Par: Token
    Par->>Nodes: build AST nodes
```

---

## Summary

The `lexer` module is the entry point of Jinja2's template parsing frontend. Through a rule-based, stack-driven state machine, it converts raw template text into a validated token stream, handling delimiter configuration, whitespace control, newline normalization, and syntax validation. Its output feeds directly into the [parser](parser.md), which constructs the AST consumed by the [compiler](compiler.md).

### Related Documentation

- [parser.md](parser.md) — Consumes the token stream to build the AST.
- [nodes.md](nodes.md) — AST node definitions.
- [environment.md](environment.md) — Provides lexer configuration.
- [exceptions.md](exceptions.md) — `TemplateSyntaxError` and related errors.
- [utils.md](utils.md) — `LRUCache` used for lexer caching.
- [compiler.md](compiler.md) — Downstream code generation.
