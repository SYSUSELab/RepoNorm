# Filters Module

## Introduction

The `filters` module (`src/jinja2/filters.py`) implements Jinja's built-in template filters — the functions invoked with the `|` operator inside templates (e.g. `{{ name|upper }}`). It provides a large library of data-transformation utilities covering string manipulation, sequence processing, sorting/grouping, type conversion, HTML/URL safety, and JSON serialization.

The module is part of the [extension and customization](ext.md) layer of Jinja. It is consumed by the [runtime execution and API](environment.md) layer: the `Environment` registers every filter in its `filters` mapping (via the module-level `FILTERS` dictionary), and the compiler emits calls to `Environment.call_filter` when a template uses the `|` operator.

This document focuses on the module's architecture, the two core components (`HasHTML` and `_GroupTuple`), the filter dispatch mechanism, and how filters integrate with the rest of Jinja. For details on the environment that hosts filters, see [environment.md](environment.md); for the runtime context and undefined handling, see [runtime.md](runtime.md).

---

## Purpose and Core Functionality

The filters module provides:

1. **A registry of built-in filters** — the `FILTERS` dictionary maps filter names to callables. This dictionary is copied into every `Environment` instance as `Environment.filters`.
2. **Filter implementations** — plain functions such as `do_upper`, `do_sort`, `do_groupby`, `do_tojson`, etc.
3. **Attribute-access helpers** — `make_attrgetter`, `make_multi_attrgetter`, and `_prepare_attribute_parts` provide dotted-path attribute lookup used by many filters (`sort`, `groupby`, `map`, `selectattr`, `unique`, `min`, `max`, `sum`).
4. **Async variants** — filters that operate on iterables have async counterparts generated via the `@async_variant` decorator, enabling use in async environments.
5. **Two supporting types** — `HasHTML` (a typing protocol) and `_GroupTuple` (a namedtuple subclass used by `groupby`).

---

## Architecture Overview

The filters module sits between the template author (who writes `|filter`) and the runtime environment (which resolves and invokes the filter). The following diagram shows the high-level position of the module.

```mermaid
graph TD
    subgraph "Template Author"
        T["{{ value|filter(args) }}"]
    end

    subgraph "Compilation & Codegen"
        C["compiler.py<br/>CodeGenerator"]
    end

    subgraph "Runtime Execution & API"
        E["environment.py<br/>Environment.call_filter"]
        CTX["runtime.py<br/>Context"]
        UND["runtime.py<br/>Undefined"]
    end

    subgraph "Filters Module (this module)"
        REG["FILTERS registry"]
        IMPL["Filter implementations<br/>(do_upper, do_sort, ...)"]
        HELP["Attribute helpers<br/>(make_attrgetter, ...)"]
        TYPES["HasHTML, _GroupTuple"]
    end

    subgraph "Utilities"
        U["utils.py<br/>pass_context, pass_environment,<br/>pass_eval_context, urlize, ..."]
        AU["async_utils.py<br/>async_variant, auto_aiter, ..."]
    end

    T --> C
    C --> E
    E --> REG
    REG --> IMPL
    IMPL --> HELP
    IMPL --> TYPES
    IMPL --> U
    IMPL --> AU
    IMPL --> UND
    E --> CTX
```

---

## Core Components

### `HasHTML`

`HasHTML` is a `typing.Protocol` (defined only under `TYPE_CHECKING`) that describes any object exposing an `__html__()` method returning a string. It is the structural type used by filters that must respect pre-escaped HTML content.

```python
class HasHTML(te.Protocol):
    def __html__(self) -> str:
        pass
```

**Role:** Filters such as `do_forceescape`, `do_striptags`, and `do_replace` check `hasattr(value, "__html__")` to decide whether a value is already HTML-safe (typically a `markupsafe.Markup` instance). When present, the filter calls `__html__()` to obtain the raw HTML string before processing. This protocol documents that contract for type checkers without introducing a runtime dependency.

**Related filters:**
- `do_forceescape` — calls `__html__()` then escapes the result.
- `do_striptags` — calls `__html__()` then strips tags via `Markup.striptags()`.
- `do_replace` — inspects `__html__` on the search/replacement strings to decide escaping behavior.

### `_GroupTuple`

`_GroupTuple` is a `typing.NamedTuple` subclass with two fields, `grouper` and `list`, used as the element type yielded by the `groupby` filter.

```python
class _GroupTuple(t.NamedTuple):
    grouper: t.Any
    list: t.List

    def __repr__(self) -> str:
        return tuple.__repr__(self)

    def __str__(self) -> str:
        return tuple.__str__(self)
```

**Role:** `groupby` returns a list of `(grouper, list)` pairs. Using a namedtuple lets templates access either by index (`group[0]`) or by name (`group.grouper`, `group.list`). The custom `__repr__` and `__str__` delegate to the plain `tuple` implementations so that debugging output looks like an ordinary tuple rather than a namedtuple, hiding the internal subclass from users.

**Used by:** `sync_do_groupby` and its async variant `do_groupby`.

---

## Filter Dispatch and Invocation

Filters are not called directly by templates. Instead, the compiler emits a call to `Environment.call_filter`, which performs name resolution and argument injection. The following sequence diagram shows the full path from a template expression to a filter implementation.

```mermaid
sequenceDiagram
    participant Tpl as Template
    participant CG as CodeGenerator
    participant Env as Environment
    participant Reg as FILTERS registry
    participant Fn as Filter function
    participant Dec as pass_* decorator

    Tpl->>CG: {{ value|sort(attribute="name") }}
    CG->>Env: call_filter("sort", value, args, kwargs, context)
    Env->>Reg: lookup "sort"
    Reg-->>Env: do_sort
    Env->>Dec: _PassArg.from_obj(do_sort)
    Dec-->>Env: environment (inject Environment)
    Env->>Fn: do_sort(environment, value, ...)
    Fn-->>Env: result
    Env-->>CG: result
    CG-->>Tpl: rendered output
```

### Argument Injection Decorators

Many filters need access to runtime objects beyond their explicit arguments. The module uses decorators from [utils.md](utils.md) to declare these dependencies:

| Decorator | Injected first argument | Example filters |
|-----------|------------------------|-----------------|
| `@pass_context` | `Context` | `do_random`, `do_map`, `do_select`, `do_reject`, `do_selectattr`, `do_rejectattr` |
| `@pass_environment` | `Environment` | `do_sort`, `do_unique`, `do_min`, `do_max`, `do_first`, `do_last`, `do_truncate`, `do_wordwrap`, `do_groupby`, `do_sum`, `do_attr` |
| `@pass_eval_context` | `EvalContext` | `do_replace`, `do_xmlattr`, `do_join`, `do_urlize`, `do_tojson` |

The `Environment._filter_test_common` method inspects the callable's `jinja_pass_arg` attribute (set by these decorators) and inserts the appropriate object as the first positional argument. See [environment.md](environment.md) for the resolution logic.

### Async Variants

Filters that iterate over sequences have both a synchronous implementation and an async variant. The `@async_variant` decorator (from [async_utils.md](async_utils.md)) wraps the sync function and dispatches to the async version when the environment is in async mode.

```mermaid
graph LR
    CALL["do_sort / do_map / do_join ..."] --> AV{"async_variant<br/>wrapper"}
    AV -->|"env.is_async == False"| SYNC["sync_do_*"]
    AV -->|"env.is_async == True"| ASYNC["async do_*"]
    ASYNC --> AA["auto_aiter / auto_await / auto_to_list"]
```

Filters with async variants include: `join`, `first`, `slice`, `groupby`, `sum`, `list`, `map`, `select`, `reject`, `selectattr`, `rejectattr`.

---

## Filter Categories

The `FILTERS` registry groups filters by purpose. The table below summarizes the categories and their key filters.

| Category | Filters | Notes |
|----------|---------|-------|
| **String manipulation** | `upper`, `lower`, `capitalize`, `title`, `trim`, `center`, `indent`, `truncate`, `wordwrap`, `wordcount`, `replace`, `format`, `striptags` | Most use `soft_str` from `markupsafe` to preserve safety. |
| **Sequence processing** | `first`, `last`, `random`, `list`, `reverse`, `slice`, `batch`, `unique`, `join`, `sum`, `min`, `max` | Several have async variants. |
| **Sorting & grouping** | `sort`, `dictsort`, `groupby` | Rely on `make_attrgetter` / `make_multi_attrgetter`. |
| **Selection** | `select`, `reject`, `selectattr`, `rejectattr`, `map` | Delegate to `prepare_select_or_reject` / `prepare_map`. |
| **Type conversion** | `int`, `float`, `string`, `list`, `attr` | `attr` uses `Environment.getattr` semantics. |
| **HTML/URL safety** | `escape`, `forceescape`, `safe`, `mark_unsafe`, `xmlattr`, `urlencode`, `urlize`, `tojson` | Interact with `markupsafe` and `EvalContext.autoescape`. |
| **Formatting** | `filesizeformat`, `pprint`, `round` | `round` supports `common`/`ceil`/`floor`. |
| **Defaults** | `default` (alias `d`) | Works with `Undefined` and `ChainableUndefined`. |

---

## Attribute Lookup Helpers

A significant portion of the module is dedicated to resolving dotted attribute paths, which is shared by many filters.

```mermaid
graph TD
    A["make_attrgetter(env, attribute, postprocess, default)"] --> P["_prepare_attribute_parts"]
    M["make_multi_attrgetter(env, attribute, postprocess)"] --> P
    P --> SPLIT["split on '.'<br/>convert digit parts to int"]
    A --> GET["env.getitem(item, part)"]
    M --> GET
    GET --> UND["Undefined if missing"]
    A --> PP["postprocess (e.g. ignore_case)"]
    M --> PP
```

- **`_prepare_attribute_parts`** — splits a dotted string like `"address.city"` into `["address", "city"]`, converting numeric segments to integers (so `"items.0"` indexes a list).
- **`make_attrgetter`** — returns a callable that walks the parts using `Environment.getitem`, optionally substituting a `default` when an `Undefined` is encountered, and applying a `postprocess` (commonly `ignore_case`).
- **`make_multi_attrgetter`** — handles comma-separated attribute lists (e.g. `"age,name"`), returning a list of extracted values. Used by `sort` for multi-key sorting.
- **`ignore_case`** — a postprocessor that lowercases strings and passes other types through unchanged.

These helpers are the backbone of `sort`, `unique`, `min`, `max`, `groupby`, `map`, `selectattr`, and `rejectattr`.

---

## Data Flow: A Representative Filter (`groupby`)

The following diagram traces the data flow through `groupby`, illustrating how the helpers, `_GroupTuple`, and the environment interact.

```mermaid
flowchart TD
    IN["value: Iterable[V]<br/>attribute: str"] --> EXPR["make_attrgetter(env, attribute, default)"]
    EXPR --> SORTED["sorted(value, key=expr)"]
    SORTED --> GB["itertools.groupby(sorted, expr)"]
    GB --> BUILD["_GroupTuple(key, list(values))"]
    BUILD --> OUT["List[_GroupTuple]<br/>(grouper, list)"]
    OUT --> TPL["Template: group.grouper / group.list"]
```

The async variant `do_groupby` follows the same flow but awaits `auto_to_list(value)` before sorting and grouping.

---

## Integration with the Environment

The `FILTERS` dictionary is the module's public integration point. During `Environment.__init__`, the environment copies it:

```python
self.filters = DEFAULT_FILTERS.copy()
```

where `DEFAULT_FILTERS` is imported from this module. This means:

- Every `Environment` starts with all built-in filters.
- Users can add or override filters by mutating `env.filters`.
- The compiler resolves `|name` by looking up `name` in `env.filters` at compile time, then emits a runtime call to `Environment.call_filter`.

For the full lifecycle of filter resolution and invocation, see [environment.md](environment.md). For the `Context` and `Undefined` types that filters receive and return, see [runtime.md](runtime.md). For the `FilterArgumentError` raised on invalid arguments, see [exceptions.md](exceptions.md).

---

## Error Handling

Filters raise `FilterArgumentError` (a subclass of `TemplateRuntimeError`) when called with invalid arguments. Examples:

- `do_dictsort` — invalid `by` value (must be `"key"` or `"value"`).
- `do_round` — invalid `method` (must be `common`, `ceil`, or `floor`).
- `do_format` — mixing positional and keyword arguments.
- `do_reverse` — non-iterable argument.
- `do_urlize` — invalid URI scheme prefix.
- `prepare_map` / `prepare_select_or_reject` — missing required arguments.

When a filter encounters an empty sequence (e.g. `first`, `last`, `min`, `max`, `random`), it returns an `Undefined` object rather than raising, allowing templates to handle the absence gracefully.

---

## Summary

The filters module is a self-contained library of template transformations that plugs into Jinja through the `FILTERS` registry and the `Environment.call_filter` dispatch mechanism. Its design emphasizes:

- **Composability** — shared attribute-lookup helpers power many filters.
- **Safety** — consistent use of `markupsafe` (`escape`, `Markup`, `soft_str`) and `EvalContext.autoescape` awareness.
- **Async support** — parallel async implementations via `@async_variant`.
- **Extensibility** — a simple name-to-callable registry that users can extend.

For related functionality, see:
- [environment.md](environment.md) — the `Environment` that hosts and dispatches filters.
- [runtime.md](runtime.md) — `Context`, `Undefined`, and runtime helpers.
- [utils.md](utils.md) — `pass_context`, `pass_environment`, `pass_eval_context`, `urlize`, `pformat`.
- [async_utils.md](async_utils.md) — `async_variant`, `auto_aiter`, `auto_await`, `auto_to_list`.
- [exceptions.md](exceptions.md) — `FilterArgumentError` and related exceptions.
- [ext.md](ext.md) — the extension layer that filters belong to.
