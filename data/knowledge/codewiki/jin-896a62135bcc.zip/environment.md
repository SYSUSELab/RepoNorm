# Environment Module

## Introduction

The `environment` module (`src/jinja2/environment.py`) is the **central orchestration layer** of Jinja2. It provides the `Environment` class — the shared configuration hub that ties together every other subsystem (lexing, parsing, compilation, loading, caching, runtime execution, and extensions) — along with the `Template` class and its supporting runtime wrappers (`TemplateModule`, `TemplateExpression`, `TemplateStream`).

In short, this module answers the question: *"Given a template source and a set of configuration options, how do I turn it into a renderable object and execute it?"*

It is the primary public API surface of Jinja2. Most users interact with Jinja2 exclusively through `Environment` and `Template`.

---

## Core Components

| Component | Responsibility |
|-----------|----------------|
| `Environment` | Central configuration and factory. Holds filters, tests, globals, policies, loader, cache, extensions, and compilation settings. |
| `Template` | A compiled, renderable template. Wraps generated Python code and exposes `render`, `generate`, `stream`, `module`, etc. |
| `TemplateModule` | Represents an imported template; exposes exported names as attributes and renders to a string. |
| `TemplateExpression` | Wraps a compiled expression (from `compile_expression`) into a callable. |
| `TemplateStream` | A buffered iterator over rendered output, useful for streaming large templates. |

### Module-level helpers

- `get_spontaneous_environment` — LRU-cached factory for environments created implicitly by direct `Template(...)` usage.
- `create_cache` / `copy_cache` — build the template cache (`None`, `dict`, or `LRUCache`) based on `cache_size`.
- `load_extensions` — instantiate and bind extensions to an environment.
- `_environment_config_check` — sanity-checks configuration (undefined subclass, distinct delimiters, valid newline sequence).

---

## Architecture Overview

The `Environment` sits at the center and delegates to specialized subsystems. The diagram below shows how the environment module connects to the rest of Jinja2.

```mermaid
graph TD
    subgraph "environment module"
        ENV[Environment]
        TPL[Template]
        TM[TemplateModule]
        TE[TemplateExpression]
        TS[TemplateStream]
    end

    subgraph "template_parsing_frontend"
        LEX[Lexer]
        PAR[Parser]
        NODES[nodes.Template AST]
    end

    subgraph "compilation_and_codegen"
        GEN[generate / CodeGenerator]
        OPT[Optimizer]
    end

    subgraph "template_loading_and_caching"
        LOADER[BaseLoader]
        BCC[BytecodeCache]
    end

    subgraph "runtime_execution_and_api"
        CTX[Context / new_context]
        UND[Undefined]
        EXC[exceptions]
    end

    subgraph "extension_and_customization"
        EXT[Extension]
    end

    ENV -->|preprocess/tokenize| LEX
    ENV -->|parse| PAR
    PAR --> NODES
    ENV -->|_generate| GEN
    GEN --> OPT
    ENV -->|_compile| TPL
    ENV -->|_load_template| LOADER
    LOADER --> BCC
    LOADER --> TPL
    ENV -->|load_extensions| EXT
    EXT -->|preprocess/filter_stream/parse| LEX
    EXT -->|parse| PAR
    TPL -->|new_context| CTX
    CTX --> UND
    TPL --> TM
    TPL --> TE
    TPL --> TS
    ENV -.uses.-> EXC
```

---

## The `Environment` Class

`Environment` is the shared configuration object. It is designed to be created once and reused across many templates. **Modifying an environment after the first template is loaded leads to undefined behavior**, and *shared* environments (e.g. spontaneous environments) must never be modified.

### Configuration Categories

The constructor parameters fall into several logical groups:

```mermaid
graph LR
    subgraph "Lexer / Parser"
        A1[block_start/end_string]
        A2[variable_start/end_string]
        A3[comment_start/end_string]
        A4[line_statement/comment_prefix]
        A5[trim_blocks / lstrip_blocks]
        A6[newline_sequence]
        A7[keep_trailing_newline]
    end
    subgraph "Runtime"
        B1[undefined]
        B2[optimized]
        B3[finalize]
        B4[autoescape]
        B5[enable_async]
    end
    subgraph "Defaults"
        C1[filters]
        C2[tests]
        C3[globals]
        C4[policies]
    end
    subgraph "Loading / Caching"
        D1[loader]
        D2[cache_size]
        D3[auto_reload]
        D4[bytecode_cache]
    end
    subgraph "Extensions"
        E1[extensions]
    end
```

> **Important:** The constructor argument order is part of the internal contract (used by spontaneous environments and unit tests). New parameters must be appended at the end without changing existing ones.

### Key Class Attributes

| Attribute | Purpose |
|-----------|---------|
| `sandboxed` | Flag controlling code generation for sandboxing (see [extension_and_customization](extension_and_customization.md)). |
| `overlayed` / `linked_to` | Track overlay environments created via `overlay()`. |
| `shared` | Marks environments that must not be modified. |
| `code_generator_class` | The `CodeGenerator` subclass used for codegen. |
| `context_class` | The `Context` subclass used at runtime. |
| `template_class` | The `Template` subclass produced by this environment. |
| `concat` | String concatenation function (`"".join`). |

### Lifecycle Methods

#### Environment creation and derivation

- **`overlay(**attributes)`** — Creates a new environment that shares data with the current one but overrides selected attributes. Extensions are re-bound to the new environment. Useful for per-request configuration without mutating the base environment.
- **`extend(**attributes)`** — Adds attributes only if they don't already exist (used by extensions to register config without breaking inheritance).
- **`add_extension(extension)`** — Adds an extension after construction.

#### Parsing and compilation pipeline

The environment exposes the full compilation pipeline as public methods:

```mermaid
flowchart LR
    SRC[source string] --> PRE[preprocess]
    PRE --> LEX[lex / _tokenize]
    LEX --> PARSE[parse / _parse]
    PARSE --> AST[nodes.Template]
    AST --> GEN[_generate]
    GEN --> CODE[python source]
    CODE --> COMPILE[_compile]
    COMPILE --> CO[CodeType]
    CO --> TPL[Template.from_code]
```

| Method | Description |
|--------|-------------|
| `lex(source, name, filename)` | Yields `(lineno, token_type, value)` tuples. Does **not** preprocess. |
| `preprocess(source, name, filename)` | Applies all extension `preprocess` hooks. |
| `_tokenize(...)` | Preprocesses, tokenizes, and applies extension `filter_stream` hooks. |
| `parse(source, name, filename)` | Returns the AST (`nodes.Template`). |
| `_parse(...)` | Internal parse used by `parse` and `compile`. |
| `_generate(...)` | Hook that calls `generate()` from the compiler module. |
| `_compile(source, filename)` | Hook that calls Python's `compile()`. |
| `compile(source, name, filename, raw, defer_init)` | Full pipeline; returns a `CodeType` (or source string if `raw=True`). |
| `compile_expression(source, undefined_to_none)` | Compiles a single expression into a `TemplateExpression`. |
| `compile_templates(target, ...)` | Compiles all loader templates into a zip/folder (uses `ModuleLoader`). |

#### Template loading

| Method | Description |
|--------|-------------|
| `get_template(name, parent, globals)` | Loads a single template by name (cached). |
| `select_template(names, parent, globals)` | Tries multiple names in order; raises `TemplatesNotFound`. |
| `get_or_select_template(...)` | Dispatches to `get_template` or `select_template`. |
| `_load_template(name, globals)` | Internal cache-aware loader. |
| `from_string(source, globals, template_class)` | Compiles a template from a string without a loader. |
| `list_templates(extensions, filter_func)` | Lists templates via the loader. |
| `join_path(template, parent)` | Hook for relative template resolution (default: identity). |
| `make_globals(d)` | Builds a `ChainMap` of template globals over environment globals. |

#### Value access and filter/test invocation

- **`getitem(obj, argument)`** — Prefers item access, falls back to attribute.
- **`getattr(obj, attribute)`** — Prefers attribute access, falls back to item.
- **`call_filter(...)` / `call_test(...)`** — Invoke filters/tests exactly as the compiler does, honoring `@pass_context`, `@pass_eval_context`, and `@pass_environment` decorators via `_PassArg`.
- **`_filter_test_common(...)`** — Shared implementation for filters and tests.

#### Error handling

- **`handle_exception(source)`** — Rewrites the traceback stack via `jinja2.debug.rewrite_traceback_stack` and re-raises.

---

## The `Template` Class

A `Template` is a compiled, renderable object. It is **immutable** — modifications are not supported.

### Construction paths

```mermaid
graph TD
    A[Template.__new__] -->|direct usage| B[get_spontaneous_environment]
    B --> C[env.from_string]
    C --> D[Template.from_code]
    E[Loader.load] --> D
    F[Template.from_module_dict] --> G[_from_namespace]
    D --> G
```

| Classmethod / Method | Purpose |
|----------------------|---------|
| `__new__(source, ...)` | Direct construction; creates a spontaneous environment and compiles. |
| `from_code(environment, code, globals, uptodate)` | Builds a template from compiled code (used by loaders). |
| `from_module_dict(environment, module_dict, globals)` | Builds a template from a module (used by `ModuleLoader`). |
| `_from_namespace(...)` | Shared internal constructor that wires up `blocks`, `root_render_func`, `debug_info`, etc. |

### Rendering methods

| Method | Returns | Notes |
|--------|---------|-------|
| `render(*args, **kwargs)` | `str` | Full render. Handles async by running an event loop. |
| `render_async(*args, **kwargs)` | coroutine → `str` | Requires `enable_async`. |
| `generate(*args, **kwargs)` | `Iterator[str]` | Lazy piece-by-piece rendering. |
| `generate_async(...)` | `AsyncIterator[str]` | Async variant. |
| `stream(*args, **kwargs)` | `TemplateStream` | Wraps `generate`. |

### Context and module methods

| Method | Purpose |
|--------|---------|
| `new_context(vars, shared, locals)` | Creates a `Context` (delegates to `runtime.new_context`). |
| `make_module(vars, shared, locals)` | Evaluates the template as a module (uncached). |
| `make_module_async(...)` | Async module creation. |
| `module` (property) | Cached default module; unavailable in async mode. |
| `_get_default_module(ctx)` / `_get_default_module_async(ctx)` | Internal module resolution with import-globals handling. |

### Introspection

- **`is_up_to_date`** — Whether the source has changed (drives `auto_reload`).
- **`debug_info`** — Mapping of template lines to generated code lines.
- **`get_corresponding_lineno(lineno)`** — Maps a bytecode line back to a template line.

---

## Supporting Runtime Wrappers

### `TemplateModule`

Represents an imported template. Exported names become attributes; `str()`/`__html__()` render the body. In async mode a `body_stream` must be supplied.

### `TemplateExpression`

Returned by `Environment.compile_expression`. Calling it evaluates the wrapped expression with the given keyword arguments, optionally converting `Undefined` results to `None`.

### `TemplateStream`

A buffered iterator over rendered output. Key methods:

- `enable_buffering(size=5)` / `disable_buffering()` — toggle output buffering.
- `dump(fp, encoding, errors)` — write the stream to a file or file-like object.
- `_buffered_generator(size)` — internal generator that concatenates `size` items per yield.

---

## Data Flow: From Source to Rendered Output

```mermaid
sequenceDiagram
    participant User
    participant Env as Environment
    participant Loader as BaseLoader
    participant Parser as Parser
    participant Compiler as CodeGenerator
    participant Tpl as Template
    participant Ctx as Context

    User->>Env: get_template("page.html")
    Env->>Env: check cache
    alt cache miss
        Env->>Loader: load(env, name, globals)
        Loader->>Loader: get_source()
        Loader->>Env: compile(source, name, filename)
        Env->>Parser: parse(source)
        Parser-->>Env: nodes.Template
        Env->>Compiler: generate(ast)
        Compiler-->>Env: python source
        Env->>Env: _compile(source)
        Env->>Tpl: Template.from_code(code, globals)
        Loader-->>Env: Template
        Env->>Env: store in cache
    end
    Env-->>User: Template
    User->>Tpl: render(name="World")
    Tpl->>Ctx: new_context(vars)
    Tpl->>Tpl: root_render_func(ctx)
    Tpl-->>User: rendered string
```

---

## Extension Integration

Extensions hook into the environment at multiple pipeline stages. The environment loads them via `load_extensions` and iterates them by priority (`iter_extensions`).

```mermaid
flowchart LR
    SRC[source] -->|preprocess| EXT1[Extension.preprocess]
    EXT1 -->|tokenize| TS[TokenStream]
    TS -->|filter_stream| EXT2[Extension.filter_stream]
    EXT2 -->|parse| P[Parser]
    P -->|tag match| EXT3[Extension.parse]
    EXT3 --> AST[nodes]
```

Extensions are bound to environments via `Extension.bind`, which is used by `Environment.overlay` to re-bind extensions to the new environment. See [extension_and_customization](extension_and_customization.md) for details on writing extensions.

---

## Dependencies

The environment module depends on nearly every other Jinja2 subsystem:

| Dependency | Used For | Documentation |
|------------|----------|---------------|
| `lexer` | Tokenization (`get_lexer`, `Lexer`, `TokenStream`) | [template_parsing_frontend](template_parsing_frontend.md) |
| `parser` | AST construction (`Parser`) | [template_parsing_frontend](template_parsing_frontend.md) |
| `nodes` | AST node types (`nodes.Template`, `EvalContext`) | [template_parsing_frontend](template_parsing_frontend.md) |
| `compiler` | Code generation (`CodeGenerator`, `generate`) | [compilation_and_codegen](compilation_and_codegen.md) |
| `runtime` | Execution (`Context`, `new_context`, `Undefined`) | [runtime_execution_and_api](runtime_execution_and_api.md) |
| `exceptions` | Error types (`TemplateNotFound`, `TemplateSyntaxError`, etc.) | [runtime_execution_and_api](runtime_execution_and_api.md) |
| `loaders` | Template loading (`BaseLoader`, `ModuleLoader`) | [template_loading_and_caching](template_loading_and_caching.md) |
| `bccache` | Bytecode caching (`BytecodeCache`) | [template_loading_and_caching](template_loading_and_caching.md) |
| `ext` | Extensions (`Extension`) | [extension_and_customization](extension_and_customization.md) |
| `utils` | Helpers (`LRUCache`, `_PassArg`, `concat`, `import_string`) | [utils](utils.md) |
| `defaults` | Default configuration values | — |
| `debug` | Traceback rewriting (`rewrite_traceback_stack`) | — |

### Dependency graph

```mermaid
graph TD
    ENV[environment]
    ENV --> LEXER[lexer]
    ENV --> PARSER[parser]
    ENV --> NODES[nodes]
    ENV --> COMPILER[compiler]
    ENV --> RUNTIME[runtime]
    ENV --> EXCEPTIONS[exceptions]
    ENV --> LOADERS[loaders]
    ENV --> BCCACHE[bccache]
    ENV --> EXT[ext]
    ENV --> UTILS[utils]
    ENV --> DEFAULTS[defaults]
    ENV --> DEBUG[debug]

    LOADERS --> BCCACHE
    LOADERS --> ENV
    COMPILER --> NODES
    COMPILER --> RUNTIME
    PARSER --> NODES
    PARSER --> LEXER
    EXT --> PARSER
    EXT --> LEXER
```

> Note: `loaders` and `ext` have a circular relationship with `environment` (they reference `Environment` for typing and runtime), which is why several imports are deferred inside methods (e.g. `from .loaders import ModuleLoader` inside `compile_templates`).

---

## Caching Strategy

The environment maintains a template cache keyed by `(weakref.ref(loader), name)`:

- `cache_size == 0` → no cache (`None`).
- `cache_size < 0` → unbounded `dict`.
- `cache_size > 0` → `LRUCache` (default 400).

On cache hit, if `auto_reload` is enabled, `template.is_up_to_date` is checked. If the template is stale, it is reloaded. When `globals` are passed and the template is cached, the template's globals are updated in place.

A separate **bytecode cache** (`bytecode_cache`) can persist compiled code across processes, avoiding re-parsing unchanged templates. See [template_loading_and_caching](template_loading_and_caching.md).

---

## Async Support

When `enable_async=True`:

- `Template.render` runs `render_async` via an event loop.
- `Template.generate` collects `generate_async` results.
- `Template.module` is **unavailable**; use `make_module_async` / `_get_default_module_async`.
- `TemplateModule` requires an explicit `body_stream`.

---

## Summary

The `environment` module is the glue of Jinja2:

1. **`Environment`** centralizes configuration and orchestrates the compile/load/render pipeline.
2. **`Template`** is the compiled, renderable artifact produced by the environment.
3. **`TemplateModule`**, **`TemplateExpression`**, and **`TemplateStream`** provide specialized runtime views over templates.

It depends on and coordinates every other subsystem, making it the natural entry point for understanding Jinja2's architecture. For deeper dives into specific stages, refer to the linked module documentation.
