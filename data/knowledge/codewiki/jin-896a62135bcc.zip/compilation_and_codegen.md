# Compilation and Codegen Module

## Purpose

The `compilation_and_codegen` module is responsible for transforming Jinja2's parsed template AST (produced by the `template_parsing_frontend`) into executable Python source code. It sits at the heart of Jinja2's template rendering pipeline: after the lexer and parser have produced a node tree, this module walks that tree, tracks variable scopes and identifiers, applies optimizations, and emits Python bytecode-ready source that the runtime can execute.

Beyond raw code generation, the module also provides supporting facilities for:
- **Optimization** of the generated AST before compilation (constant folding, dead code elimination, etc.).
- **Identifier tracking** to correctly resolve variable scopes, block scoping, and symbol references during code generation.
- **Template introspection** via `meta.py`, allowing analysis of undeclared variables, referenced templates, and other static properties without rendering.
- **Native Python type support** through `nativetypes.py`, enabling templates to produce native Python objects (lists, dicts, etc.) rather than string output.

## Architecture

The module is composed of five cooperating components. The compiler is the central orchestrator, consuming the parsed AST and delegating scope analysis to the identifier tracker, optional AST rewrites to the optimizer, and exposing introspection and native-type variants as sibling entry points.

```mermaid
flowchart TD
    subgraph Frontend["template_parsing_frontend"]
        Parser["parser.py"]
        Nodes["nodes.py"]
        Visitor["visitor.py"]
    end

    subgraph CC["compilation_and_codegen"]
        Compiler["compiler.py<br/>(CodeGenerator)"]
        Optimizer["optimizer.py<br/>(AST optimization)"]
        IDTracking["idtracking.py<br/>(symbol/scope tracking)"]
        Meta["meta.py<br/>(static introspection)"]
        Native["nativetypes.py<br/>(native Python output)"]
    end

    subgraph Runtime["runtime_execution_and_api"]
        Env["environment.py"]
        RT["runtime.py"]
    end

    Parser -->|AST| Compiler
    Nodes --> Compiler
    Visitor --> Compiler

    Compiler -->|uses| IDTracking
    Compiler -->|optional rewrite| Optimizer
    Optimizer -->|optimized AST| Compiler

    Meta -->|walks AST| Nodes
    Meta -->|uses| IDTracking

    Native -->|subclasses| Compiler
    Native -->|subclasses| Env

    Compiler -->|generated Python source| Env
    Env -->|exec| RT
```

### Data Flow

```mermaid
sequenceDiagram
    participant Parser as parser.py
    participant Opt as optimizer.py
    participant ID as idtracking.py
    participant CG as compiler.py
    participant Env as environment.py

    Parser->>Opt: Parsed AST (nodes.Template)
    Opt->>Opt: Constant folding / dead code removal
    Opt->>CG: Optimized AST
    CG->>ID: Request symbol analysis
    ID-->>CG: Frames, symbols, refs
    CG->>CG: Emit Python source (visit_* methods)
    CG-->>Env: Generated code + metadata
    Env->>Env: Compile & execute
```

## Core Components

The module's behavior is documented in detail across the following component references:

- **[compiler.md](./compiler.md)** — The `CodeGenerator` class and its `visit_*` methods that translate each AST node type into Python source. This is the primary entry point for code generation.
- **[optimizer.md](./optimizer.md)** — AST-level optimizations applied before code generation, including constant folding and node simplification.
- **[idtracking.md](./idtracking.md)** — Symbol and scope tracking (`Symbols`, `Frame`, `RootVisitor`, etc.) used by the compiler to resolve variable references and block scoping correctly.
- **[meta.md](./meta.md)** — Static template introspection utilities (`find_undeclared_variables`, `find_referenced_templates`) that analyze the AST without rendering.
- **[nativetypes.md](./nativetypes.md)** — `NativeEnvironment` and `NativeTemplate` variants that produce native Python values instead of strings, built on top of the standard compiler.

## Relationship to Other Modules

- **Upstream dependency:** Consumes the AST produced by `template_parsing_frontend` (`lexer.py`, `parser.py`, `nodes.py`, `visitor.py`).
- **Downstream consumer:** The generated Python source is handed to `runtime_execution_and_api` (`environment.py`, `runtime.py`) for compilation and execution.
- **Cross-cutting:** `utils.py` provides shared helpers used throughout code generation.