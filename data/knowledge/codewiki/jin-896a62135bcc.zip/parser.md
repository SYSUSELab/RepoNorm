# Parser Module

## Introduction

The **Parser** module (`src/jinja2/parser.py`) is the central component of Jinja's
template parsing frontend. It consumes the flat stream of tokens produced by the
[lexer](lexer.md) and transforms them into a structured **Abstract Syntax Tree (AST)**
composed of [node](nodes.md) objects. This AST is the intermediate representation
that the [compiler](compiler.md) later turns into executable Python code.

The parser is a classic **recursive-descent parser**. It implements the full Jinja
grammar: statements (`{% ... %}`), expressions (`{{ ... }}`), template data, and
extension-provided tags. It is exposed to extensions through the
[`Extension.parse`](extensions.md) hook, allowing third parties to plug custom
statement syntax into the language.

> **Position in the pipeline:** `source → lexer → TokenStream → Parser → AST (nodes) → compiler → Python code`

---

## Architecture Overview

The parser sits between the lexer and the compiler. It is instantiated by the
[`Environment`](environment.md) and driven by the `TokenStream` produced by the
lexer.

```mermaid
flowchart LR
    subgraph Frontend["Template Parsing Frontend"]
        LEX["Lexer<br/>(lexer.py)"]
        TS["TokenStream<br/>(lexer.py)"]
        PAR["Parser<br/>(parser.py)"]
        NODES["AST Nodes<br/>(nodes.py)"]
    end

    ENV["Environment<br/>(environment.py)"]
    EXT["Extensions<br/>(ext.py)"]
    COMP["Compiler<br/>(compiler.py)"]

    ENV -->|"_tokenize()"| LEX
    LEX --> TS
    TS -->|"tokens"| PAR
    EXT -->|"parse() hook"| PAR
    PAR -->|"builds"| NODES
    NODES -->|"Template node"| COMP
    ENV -->|"iter_extensions()"| PAR
```

### Key Responsibilities

| Responsibility | Description |
| --- | --- |
| **Statement dispatch** | Routes statement keywords (`for`, `if`, `block`, ...) to dedicated `parse_*` methods. |
| **Expression parsing** | Implements the full operator-precedence grammar for expressions. |
| **AST construction** | Instantiates `nodes.*` objects with correct fields, line numbers, and contexts. |
| **Error reporting** | Produces human-readable `TemplateSyntaxError` messages with line numbers and nesting hints. |
| **Extension integration** | Dispatches unknown tags to registered extensions. |

---

## The `Parser` Class

The `Parser` class is the single core component of this module. It is stateful and
holds a reference to the current token stream, the environment, and bookkeeping
stacks used for error reporting.

### Construction

```python
Parser(environment, source, name=None, filename=None, state=None)
```

| Parameter | Purpose |
| --- | --- |
| `environment` | The [`Environment`](environment.md) providing configuration and extensions. |
| `source` | The raw template source string. |
| `name` | The template load name (used in error messages). |
| `filename` | The filesystem filename (used in error messages). |
| `state` | Optional lexer state (`"variable"` or `"block"`) for parsing fragments. |

During construction the parser:

1. Calls `environment._tokenize(...)` to obtain a `TokenStream` (this applies
   extension preprocessing and stream filtering).
2. Builds an `extensions` mapping from tag name → `Extension.parse` callable by
   iterating `environment.iter_extensions()`.
3. Initializes internal state: `_last_identifier`, `_tag_stack`, and
   `_end_token_stack`.

### Internal State

```mermaid
classDiagram
    class Parser {
        +Environment environment
        +TokenStream stream
        +str name
        +str filename
        +bool closed
        +dict extensions
        +int _last_identifier
        +list _tag_stack
        +list _end_token_stack
        +parse() Template
        +parse_statement()
        +parse_statements()
        +subparse()
        +parse_expression()
        +fail()
    }
```

- **`_tag_stack`** — tracks the currently open statement tags, enabling error
  messages like *"The innermost block that needs to be closed is 'for'."*
- **`_end_token_stack`** — tracks the set of end tokens expected at each nesting
  level, enabling *"Jinja was looking for the following tags: ..."* messages.
- **`_last_identifier`** — counter used by `free_identifier()` to generate unique
  internal names (`fi1`, `fi2`, ...).

---

## Parsing Flow

The parser is driven by a single public entry point, `parse()`, which delegates to
`subparse()` for the template body.

```mermaid
flowchart TD
    START["parse()"] --> SUB["subparse()"]
    SUB --> LOOP{"next token?"}
    LOOP -->|"data"| DATA["append TemplateData"]
    LOOP -->|"variable_begin"| VAR["parse_tuple() → Output"]
    LOOP -->|"block_begin"| BLK["parse_statement()"]
    LOOP -->|"eof"| DONE["flush_data()"]
    BLK --> KW{"keyword?"}
    KW -->|"for/if/block/..."| DISPATCH["parse_&lt;keyword&gt;()"]
    KW -->|"call/filter"| SPECIAL["parse_call_block()/parse_filter_block()"]
    KW -->|"extension tag"| EXT["extension.parse(self)"]
    KW -->|"unknown"| ERR["fail_unknown_tag()"]
    DISPATCH --> SUB
    SPECIAL --> SUB
    EXT --> SUB
    DATA --> LOOP
    VAR --> LOOP
    DONE --> TPL["Template node"]
```

### `parse()` → `subparse()`

`subparse()` is the workhorse that walks the token stream. It:

1. Buffers consecutive `data` tokens into `TemplateData` nodes.
2. On `variable_begin`, parses an expression tuple and wraps it in an `Output` node.
3. On `block_begin`, flushes buffered data and calls `parse_statement()`.
4. Returns when one of the `end_tokens` is encountered (used for nested bodies).

`parse()` wraps the result in a `nodes.Template` and calls
`set_environment(self.environment)` so every node in the tree knows its environment.

---

## Statement Parsing

`parse_statement()` is the dispatcher for all `{% ... %}` blocks. It looks up the
current token value against `_statement_keywords` and calls the corresponding
`parse_<keyword>` method.

```mermaid
flowchart LR
    PS["parse_statement()"] --> SK{"in _statement_keywords?"}
    SK -->|"yes"| M["getattr(self, 'parse_' + value)()"]
    SK -->|"call"| CB["parse_call_block()"]
    SK -->|"filter"| FB["parse_filter_block()"]
    SK -->|"no"| EX{"registered extension?"}
    EX -->|"yes"| EP["extension.parse(self)"]
    EX -->|"no"| FAIL["fail_unknown_tag()"]
```

### Statement Keyword Map

| Keyword | Method | Produces |
| --- | --- | --- |
| `for` | `parse_for` | `nodes.For` |
| `if` | `parse_if` | `nodes.If` |
| `block` | `parse_block` | `nodes.Block` |
| `extends` | `parse_extends` | `nodes.Extends` |
| `print` | `parse_print` | `nodes.Output` |
| `macro` | `parse_macro` | `nodes.Macro` |
| `include` | `parse_include` | `nodes.Include` |
| `from` | `parse_from` | `nodes.FromImport` |
| `import` | `parse_import` | `nodes.Import` |
| `set` | `parse_set` | `nodes.Assign` / `nodes.AssignBlock` |
| `with` | `parse_with` | `nodes.With` |
| `autoescape` | `parse_autoescape` | `nodes.Scope` |
| `call` | `parse_call_block` | `nodes.CallBlock` |
| `filter` | `parse_filter_block` | `nodes.FilterBlock` |

### `parse_statements()` — Body Parsing

Most statement parsers delegate their body to `parse_statements(end_tokens, drop_needle)`.
This method:

1. Skips an optional leading colon (Python compatibility).
2. Expects a `block_end` token.
3. Calls `subparse(end_tokens)` to parse the body.
4. Detects premature EOF and reports it via `fail_eof()`.
5. Optionally consumes the terminating token (`drop_needle=True`).

---

## Expression Parsing

Expression parsing follows a strict **operator-precedence** hierarchy, with each
level delegating to the next-lower level. This is the classic recursive-descent
technique for handling precedence.

```mermaid
flowchart TD
    E["parse_expression()"] --> CE["parse_condexpr()"]
    CE --> OR["parse_or()"]
    OR --> AND["parse_and()"]
    AND --> NOT["parse_not()"]
    NOT --> CMP["parse_compare()"]
    CMP --> M1["parse_math1()  (+ -)"]
    M1 --> CAT["parse_concat()  (~)"]
    CAT --> M2["parse_math2()  (* / // %)"]
    M2 --> POW["parse_pow()  (**)"]
    POW --> UN["parse_unary()  (- +)"]
    UN --> PRI["parse_primary()"]
    PRI --> POST["parse_postfix()"]
    POST --> FILT["parse_filter_expr()"]
```

### Precedence Levels (lowest → highest)

| Level | Method | Operators / Constructs |
| --- | --- | --- |
| 1 | `parse_condexpr` | `a if b else c` |
| 2 | `parse_or` | `or` |
| 3 | `parse_and` | `and` |
| 4 | `parse_not` | `not` |
| 5 | `parse_compare` | `==`, `!=`, `<`, `<=`, `>`, `>=`, `in`, `not in` |
| 6 | `parse_math1` | `+`, `-` |
| 7 | `parse_concat` | `~` (string concatenation) |
| 8 | `parse_math2` | `*`, `/`, `//`, `%` |
| 9 | `parse_pow` | `**` |
| 10 | `parse_unary` | unary `-`, `+` |
| 11 | `parse_primary` | literals, names, tuples, lists, dicts |
| 12 | `parse_postfix` | `.attr`, `[item]`, `(call)` |
| 13 | `parse_filter_expr` | `\| filter`, `is test` |

### Primary and Postfix Expressions

- **`parse_primary()`** handles literals (`true`, `false`, `none`, strings, numbers),
  names, parenthesized tuples, lists (`parse_list`), and dicts (`parse_dict`).
- **`parse_postfix()`** handles attribute access (`parse_subscript`), subscripting,
  and calls (`parse_call`).
- **`parse_filter_expr()`** handles filter application (`parse_filter`) and tests
  (`parse_test`).

### Assignment Targets

`parse_assign_target()` parses the left-hand side of assignments. It supports:

- Plain names (`name_only=True`).
- Tuples (default).
- Namespace references (`ns.attr`) when `with_namespace=True`.

It calls `target.set_ctx("store")` to mark the node as an assignment target, and
validates assignability via `target.can_assign()`.

---

## Error Reporting

The parser is designed to produce helpful, human-readable syntax errors. All errors
are raised as [`TemplateSyntaxError`](exceptions.md) with line numbers, template
name, and filename.

```mermaid
flowchart TD
    FAIL["fail(msg, lineno, exc)"] --> RAISE["raise exc(msg, lineno, name, filename)"]
    UNK["fail_unknown_tag(name)"] --> FUE["_fail_ut_eof(name, ...)"]
    EOF["fail_eof(end_tokens)"] --> FUE
    FUE --> BUILD["Build message:<br/>- unknown tag / unexpected EOF<br/>- expected tags<br/>- innermost open block"]
    BUILD --> FAIL
```

| Method | Purpose |
| --- | --- |
| `fail()` | Core error raiser; fills in line number, name, and filename. |
| `fail_unknown_tag()` | Reports an unrecognized tag with nesting hints. |
| `fail_eof()` | Reports unexpected end-of-template. |
| `_fail_ut_eof()` | Shared logic that assembles the diagnostic message. |

The `_tag_stack` and `_end_token_stack` are the key data structures that make these
messages informative — they let the parser tell the user *what* it was expecting and
*which* block is still open.

---

## Extension Integration

Extensions can register custom statement tags. During construction, the parser
builds a mapping from tag name to the extension's `parse` method:

```python
for extension in environment.iter_extensions():
    for tag in extension.tags:
        self.extensions[tag] = extension.parse
```

When `parse_statement()` encounters an unknown keyword, it checks this mapping and
delegates to the extension. See the [extensions module](extensions.md) for details
on writing custom tags.

```mermaid
sequenceDiagram
    participant P as Parser
    participant E as Environment
    participant X as Extension
    P->>E: iter_extensions()
    E-->>P: [Extension, ...]
    P->>P: build extensions[tag] = ext.parse
    Note over P: Later, during parsing...
    P->>P: parse_statement() sees unknown tag
    P->>X: extension.parse(self)
    X-->>P: Node or list[Node]
```

---

## Dependencies

```mermaid
flowchart TD
    PARSER["Parser<br/>(parser.py)"]

    PARSER -->|"uses"| LEXER["lexer.py<br/>TokenStream, describe_token"]
    PARSER -->|"builds"| NODES["nodes.py<br/>all AST node types"]
    PARSER -->|"raises"| EXC["exceptions.py<br/>TemplateSyntaxError, TemplateAssertionError"]
    PARSER -->|"configured by"| ENV["environment.py<br/>Environment"]
    PARSER -->|"dispatches to"| EXT["ext.py<br/>Extension.parse"]

    ENV -->|"creates"| PARSER
    NODES -->|"consumed by"| COMP["compiler.py"]
```

### Upstream (inputs)

- **[lexer](lexer.md)** — provides `TokenStream`, `Token`, `describe_token`,
  `describe_token_expr`. The parser never touches raw source; it only reads tokens.
- **[environment](environment.md)** — creates the parser and supplies the token
  stream via `_tokenize()`.

### Downstream (outputs)

- **[nodes](nodes.md)** — the parser constructs every AST node type defined here.
- **[compiler](compiler.md)** — consumes the `Template` node produced by `parse()`.

### Related

- **[exceptions](exceptions.md)** — `TemplateSyntaxError` and `TemplateAssertionError`
  are the error types raised by the parser.
- **[extensions](extensions.md)** — plug into the parser via the `parse` hook.

---

## Public API Summary

| Method | Description |
| --- | --- |
| `parse()` | Parse the whole template into a `nodes.Template`. |
| `parse_expression()` | Parse a single expression (used by `compile_expression`). |
| `parse_statement()` | Parse a single statement. |
| `parse_statements()` | Parse a body until end tokens are reached. |
| `subparse()` | Low-level body parser handling data, variables, and blocks. |
| `fail()` | Raise a syntax error with location info. |
| `free_identifier()` | Generate a unique internal name node. |

### Usage Example

The parser is normally used indirectly through the environment:

```python
env = Environment()
ast = env.parse("{% for x in items %}{{ x }}{% endfor %}")
# ast is a nodes.Template containing a nodes.For node
```

For expression-only parsing (e.g. configuration files):

```python
expr = env.compile_expression("foo == 42")
expr(foo=42)  # True
```

---

## Design Notes

- **Recursive descent** keeps the grammar readable and maps directly to the Jinja
  language specification, at the cost of deep call stacks for deeply nested
  expressions.
- **Context tracking** (`set_ctx`) distinguishes load vs. store contexts, which the
  compiler relies on to generate correct assignment code.
- **Line number propagation** — every node is created with a `lineno`, enabling
  precise error messages and tracebacks downstream.
- **Extension-first design** — unknown tags are not errors until extensions have
  had a chance to claim them, making the language extensible without modifying the
  parser.
