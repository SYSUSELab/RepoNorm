# Extensions Module

## Introduction

The **extensions module** (`src/jinja2/ext.py`) provides the extension API for adding custom tags and behavior to the Jinja template engine. Extensions operate at the **parser level**, allowing developers to introduce new template syntax (tags), preprocess source code, filter token streams, and inject runtime callables into the environment.

This module is the foundation of Jinja's customization mechanism. It defines the abstract `Extension` base class that all extensions inherit from, and ships with four built-in extensions:

| Extension | Tag(s) | Purpose |
|-----------|--------|---------|
| `InternationalizationExtension` | `{% trans %}` | Adds gettext-based translation support |
| `ExprStmtExtension` | `{% do %}` | Evaluates an expression without outputting it |
| `LoopControlExtension` | `{% break %}`, `{% continue %}` | Adds loop control flow |
| `DebugExtension` | `{% debug %}` | Dumps available context, filters, and tests |

The module also provides the standalone `extract_from_ast` and `babel_extract` functions used by the Babel toolchain to extract translatable strings from templates.

> **Related modules:** Extensions are tightly coupled to the [template parsing frontend](template_parsing_frontend.md) (lexer, parser, nodes), the [runtime execution and API](runtime_execution_and_api.md) (Environment, Context), and the [compilation and codegen](compilation_and_codegen.md) pipeline.

---

## Architecture Overview

The extension system sits between the environment configuration and the parser. Extensions are registered on an `Environment`, then consulted during tokenization and parsing.

```mermaid
graph TD
    Env["Environment<br/>(runtime_execution_and_api)"]
    Ext["Extension<br/>(base class)"]
    Parser["Parser<br/>(template_parsing_frontend)"]
    Lexer["Lexer / TokenStream<br/>(template_parsing_frontend)"]
    Nodes["nodes.*<br/>(template_parsing_frontend)"]
    Context["Context<br/>(runtime_execution_and_api)"]

    Env -->|"load_extensions()"| Ext
    Env -->|"iter_extensions()"| Ext
    Ext -->|"preprocess(source)"| Lexer
    Ext -->|"filter_stream(stream)"| Lexer
    Ext -->|"parse(parser)"| Parser
    Parser -->|"produces"| Nodes
    Ext -->|"attr() / call_method()"| Nodes
    Ext -->|"runtime callables"| Context
```

### Extension Lifecycle

Extensions participate in three distinct phases of template processing:

```mermaid
sequenceDiagram
    participant Env as Environment
    participant Ext as Extension
    participant Lexer as Lexer/TokenStream
    participant Parser as Parser
    participant Nodes as AST Nodes

    Note over Env,Ext: 1. Registration
    Env->>Ext: __init__(environment)
    Env->>Ext: bind(environment) [for overlays]

    Note over Env,Lexer: 2. Preprocessing & Tokenization
    Env->>Ext: preprocess(source, name, filename)
    Ext-->>Env: modified source
    Env->>Lexer: tokenize(source)
    Env->>Ext: filter_stream(stream)
    Ext-->>Env: filtered token stream

    Note over Parser,Nodes: 3. Parsing
    Parser->>Ext: parse(parser) [when tag matches]
    Ext-->>Parser: Node or List[Node]
    Parser->>Nodes: build AST
```

---

## Core Components

### `Extension` (Base Class)

The abstract base class that all extensions inherit from. It defines the extension contract and provides helper methods for generating AST nodes.

**Key attributes:**

- `identifier` — A class variable automatically set in `__init_subclass__` to `f"{cls.__module__}.{cls.__name__}"`. This uniquely identifies the extension and is used by `ExtensionAttribute` nodes to reference extension state at runtime.
- `tags` — A `set` of tag names the extension listens for (e.g., `{"trans"}`). When the parser encounters a matching tag, it dispatches to `parse()`.
- `priority` — An integer (default `100`) controlling extension ordering. Lower values run first, which matters for preprocessing extensions.
- `environment` — The bound `Environment` instance. Extensions **must not** store environment-specific data on `self`, because they may be rebound to another environment via `bind()`.

**Key methods:**

| Method | Phase | Description |
|--------|-------|-------------|
| `bind(environment)` | Registration | Creates a shallow copy bound to a new environment (used for overlays). |
| `preprocess(source, name, filename)` | Preprocessing | Transforms raw source before lexing. Default returns source unchanged. |
| `filter_stream(stream)` | Tokenization | Filters/transforms the `TokenStream`. Default returns stream unchanged. |
| `parse(parser)` | Parsing | Called when a registered tag matches. Must return a `Node` or list of nodes. Raises `NotImplementedError` by default. |
| `attr(name, lineno)` | Codegen helper | Returns an `ExtensionAttribute` node referencing extension state. |
| `call_method(name, args, kwargs, ...)` | Codegen helper | Shortcut for `attr()` + `Call` node. |

**Configuration pattern:** Because extensions are instantiated by the environment and identified by import name, they cannot accept constructor arguments. Configuration must be stored on the environment (typically via `environment.extend(...)`), using well-namespaced attribute names to avoid collisions.

```mermaid
classDiagram
    class Extension {
        +identifier: str
        +tags: Set[str]
        +priority: int
        +environment: Environment
        +bind(environment) Extension
        +preprocess(source, name, filename) str
        +filter_stream(stream) TokenStream
        +parse(parser) Node|List[Node]
        +attr(name, lineno) ExtensionAttribute
        +call_method(name, ...) Call
    }
    class InternationalizationExtension {
        +tags = {"trans"}
        +parse(parser)
        +_install(translations)
        +_extract(source)
    }
    class ExprStmtExtension {
        +tags = {"do"}
        +parse(parser) ExprStmt
    }
    class LoopControlExtension {
        +tags = {"break", "continue"}
        +parse(parser) Break|Continue
    }
    class DebugExtension {
        +tags = {"debug"}
        +parse(parser) Output
        +_render(context) str
    }
    Extension <|-- InternationalizationExtension
    Extension <|-- ExprStmtExtension
    Extension <|-- LoopControlExtension
    Extension <|-- DebugExtension
```

---

### `InternationalizationExtension`

The most complex built-in extension, adding gettext-based translation support via the `{% trans %}` tag.

**Registration:** On construction it registers `_` as a global alias and extends the environment with several methods:

- `install_gettext_translations(translations, newstyle)` — Installs a translations object.
- `install_null_translations(newstyle)` — Installs a no-op `NullTranslations`.
- `install_gettext_callables(gettext, ngettext, ...)` — Installs raw callables.
- `uninstall_gettext_translations(translations)` — Removes installed callables.
- `extract_translations(source)` — Extracts translatable strings.
- `newstyle_gettext` — A flag (default `False`) enabling newstyle gettext calls.

**Translation function wrappers:** The module provides factory functions that wrap raw gettext callables to handle autoescaping and format-string expansion:

- `_make_new_gettext` → wraps `gettext`
- `_make_new_ngettext` → wraps `ngettext`
- `_make_new_pgettext` → wraps `pgettext` (context-aware)
- `_make_new_npgettext` → wraps `npgettext` (context + plural)

These wrappers use `@pass_context` to access `eval_ctx.autoescape` and always treat the result as a format string (`rv % variables`).

**Parsing the `{% trans %}` tag:** The `parse()` method handles a fairly rich grammar:

```mermaid
flowchart TD
    Start["{% trans ... %}"] --> Vars["Parse variables<br/>(name, name=expr, trimmed/notrimmed)"]
    Vars --> BlockEnd["expect block_end"]
    BlockEnd --> Singular["_parse_block(allow_pluralize=True)"]
    Singular --> CheckPlural{"pluralize<br/>tag?"}
    CheckPlural -->|Yes| Plural["Parse plural variable<br/>_parse_block(allow_pluralize=False)"]
    CheckPlural -->|No| NoPlural["plural_expr = None"]
    Plural --> Trim["Apply whitespace trimming<br/>if policy enabled"]
    NoPlural --> Trim
    Trim --> MakeNode["_make_node()"]
    MakeNode --> Result["Output node<br/>(+ optional plural assignment)"]
```

The `_parse_block` helper collects referenced variable names and builds a format string, replacing `{{ name }}` with `%(name)s` and escaping literal `%` as `%%`. Control structures inside translation blocks are rejected.

**`_make_node`** generates either a `gettext(...)` or `ngettext(...)` call. In newstyle mode, variables are passed as keyword arguments; otherwise the result is wrapped in `MarkSafeIfAutoescape` and a `Mod` (modulo) node applies the variable dict.

**Whitespace trimming** is controlled by the `ext.i18n.trimmed` policy and the `trimmed`/`notrimmed` inline keywords, using the `_ws_re` regex (`\s*\n\s*`).

---

### `ExprStmtExtension`

Adds the `{% do %}` tag, which evaluates an expression for its side effects without producing output (analogous to Python's expression statement).

```python
def parse(self, parser):
    node = nodes.ExprStmt(lineno=next(parser.stream).lineno)
    node.node = parser.parse_tuple()
    return node
```

---

### `LoopControlExtension`

Adds `{% break %}` and `{% continue %}` tags for loop control flow. The `parse()` method inspects the matched token value and returns the corresponding `Break` or `Continue` node.

---

### `DebugExtension`

Adds the `{% debug %}` tag (since Jinja 2.11.0), which dumps the current context, available filters, and tests as a formatted string.

- `parse()` builds an `Output` node wrapping a call to `_render` with a `ContextReference`.
- `_render(context)` collects `context.get_all()`, sorted filter names, and sorted test names, then formats them with `pprint.pformat(depth=3, compact=True)`.

---

### Translation Extraction Helpers

#### `extract_from_ast(ast, gettext_functions, babel_style)`

Walks a parsed `Template` AST, finding all `Call` nodes whose callee is a `Name` matching one of the `gettext_functions` (default `GETTEXT_FUNCTIONS = ("_", "gettext", "ngettext", "pgettext", "npgettext")`). For each match it yields a `(lineno, function_name, message)` tuple.

- In **babel style** (default), non-string arguments and keyword arguments are returned as `None`, allowing Babel to interpret intent.
- With `babel_style=False`, only string arguments are returned, and invalid calls are skipped.

#### `_CommentFinder`

A helper that locates translator comments preceding gettext calls in a token stream. It searches **backwards** from a given line number for `comment`/`linecomment` tokens whose prefix matches one of the `comment_tags`. Note: it can only find comments forward — once a comment for a later line is consumed, earlier comments are no longer retrievable.

#### `babel_extract(fileobj, keywords, comment_tags, options)`

The Babel extraction entry point. It:

1. Builds an `Environment` from `options` (block/variable/comment delimiters, trim settings, etc.).
2. Ensures `InternationalizationExtension` is registered.
3. Parses the source and lexes it (respecting the `silent` option for syntax errors).
4. Yields `(lineno, funcname, message, comments)` tuples, pairing each extracted message with comments found by `_CommentFinder`.

```mermaid
flowchart LR
    File["fileobj"] --> Env["Build Environment<br/>from options"]
    Env --> Parse["environment.parse(source)"]
    Env --> Lex["environment.lex(preprocess(source))"]
    Parse --> Extract["extract_from_ast()"]
    Lex --> Finder["_CommentFinder"]
    Extract --> Yield["yield (lineno, func, message, comments)"]
    Finder --> Yield
```

---

## Data Flow: From Source to AST

The following diagram shows how an extension's hooks are invoked across the full pipeline, from raw source to executable template.

```mermaid
flowchart TD
    Source["Raw template source"] --> Pre["Extension.preprocess()<br/>(priority order)"]
    Pre --> Lex["Lexer.tokenize()"]
    Lex --> Filter["Extension.filter_stream()"]
    Filter --> Stream["TokenStream"]
    Stream --> Parser["Parser"]
    Parser -->|"tag matches extension.tags"| Parse["Extension.parse(parser)"]
    Parse --> AST["AST Nodes"]
    AST --> Compiler["CodeGenerator<br/>(compilation_and_codegen)"]
    Compiler --> Code["Python code object"]
    Code --> Runtime["Runtime execution<br/>(runtime_execution_and_api)"]
```

---

## Dependencies

The extensions module depends on several other Jinja modules:

```mermaid
graph LR
    Ext["ext.py"]
    Ext --> defaults["defaults"]
    Ext --> nodes["nodes<br/>(template_parsing_frontend)"]
    Ext --> Environment["environment.Environment<br/>(runtime_execution_and_api)"]
    Ext --> exceptions["exceptions<br/>(runtime_execution_and_api)"]
    Ext --> runtime["runtime<br/>(Context, concat, Undefined)"]
    Ext --> utils["utils<br/>(import_string, pass_context)"]
    Ext -.->|"TYPE_CHECKING"| lexer["lexer<br/>(Token, TokenStream)"]
    Ext -.->|"TYPE_CHECKING"| parser["parser.Parser"]
    Ext --> markupsafe["markupsafe.Markup"]
```

| Dependency | Usage |
|------------|-------|
| `defaults` | Default delimiter/trim settings for `babel_extract`'s environment. |
| `nodes` | AST node construction (`Output`, `Call`, `Const`, `Name`, `ExprStmt`, `Break`, `Continue`, `ExtensionAttribute`, etc.). |
| `environment.Environment` | The environment extensions bind to; used by `babel_extract`. |
| `exceptions` | `TemplateAssertionError`, `TemplateSyntaxError` for parse-time failures. |
| `runtime` | `Context` (for `@pass_context` callables), `concat`, `Undefined`. |
| `utils` | `import_string` (loading extensions by name), `pass_context` decorator. |
| `lexer` / `parser` | Type-only imports for `TokenStream` and `Parser` signatures. |
| `markupsafe.Markup` | Wrapping translated strings when autoescape is enabled. |

---

## Public API Summary

### Classes

- `Extension` — Base class for all extensions.
- `InternationalizationExtension` (alias `i18n`) — gettext support.
- `ExprStmtExtension` (alias `do`) — `{% do %}` tag.
- `LoopControlExtension` (alias `loopcontrols`) — `{% break %}` / `{% continue %}`.
- `DebugExtension` (alias `debug`) — `{% debug %}` tag.

### Functions

- `extract_from_ast(ast, gettext_functions, babel_style)` — Extract translatable strings from an AST.
- `babel_extract(fileobj, keywords, comment_tags, options)` — Babel extraction entry point.

### Constants

- `GETTEXT_FUNCTIONS` — Tuple of recognized gettext function names.

### Convenience Aliases

```python
i18n = InternationalizationExtension
do = ExprStmtExtension
loopcontrols = LoopControlExtension
debug = DebugExtension
```

---

## Writing a Custom Extension

To create a custom extension:

1. **Subclass `Extension`** and set the `tags` attribute to the tag names you want to handle.
2. **Implement `parse(parser)`** to consume tokens and return AST nodes. Use `parser.stream` to inspect/advance tokens and `parser.parse_expression()` / `parser.parse_tuple()` to parse sub-expressions.
3. **Optionally override `preprocess()`** to transform source before lexing, or **`filter_stream()`** to transform tokens.
4. **Use `self.attr()` and `self.call_method()`** to reference extension state and methods from generated template code.
5. **Register the extension** by passing its import path or class to the `Environment(extensions=[...])` constructor, or via `environment.add_extension(...)`.

> **Note:** Extensions must not store environment-specific data on `self`, since `bind()` may rebind them to another environment (e.g., for overlays). Store configuration on the environment instead, using namespaced attribute names.

For details on the parser API used by extensions, see the [template parsing frontend](template_parsing_frontend.md) documentation. For the environment registration mechanism, see [runtime execution and API](runtime_execution_and_api.md).
