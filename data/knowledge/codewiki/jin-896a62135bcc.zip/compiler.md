# Compiler Module

## Introduction

The **compiler module** (`jinja2/compiler.py`) is the code generation engine of Jinja2. It transforms the abstract syntax tree (AST) produced by the [template parsing frontend](template_parsing_frontend.md) into executable Python source code. This generated code, when compiled and executed, renders the template by producing a stream of output events.

The compiler sits at the heart of the template lifecycle:

```
Template Source → Lexer → Parser → AST → [Compiler] → Python Source → Code Object → Rendered Output
```

The module's central class, `CodeGenerator`, is a `NodeVisitor` that walks the AST and emits Python code for each node. It is supported by several helper visitors and data structures that handle symbol tracking, dependency resolution, constant folding, and frame management.

## Architecture Overview

The compiler module is composed of a primary code generator and a set of collaborating components. The following diagram shows the high-level architecture and how the pieces fit together.

```mermaid
graph TD
    subgraph "Compiler Module (compiler.py)"
        CG[CodeGenerator]
        Frame[Frame]
        MacroRef[MacroRef]
        DFV[DependencyFinderVisitor]
        UNV[UndeclaredNameVisitor]
        CE[CompilerExit]
        VE[VisitorExit]
        FI[CodeGenerator._FinalizeInfo]
    end

    subgraph "Supporting Modules"
        OPT[Optimizer<br/>optimizer.py]
        SYM[Symbols<br/>idtracking.py]
        FSV[FrameSymbolVisitor<br/>idtracking.py]
        RV[RootVisitor<br/>idtracking.py]
        NV[NodeVisitor<br/>visitor.py]
        NT[NodeTransformer<br/>visitor.py]
    end

    subgraph "Subclasses"
        TCG[TrackingCodeGenerator<br/>meta.py]
        NCG[NativeCodeGenerator<br/>nativetypes.py]
    end

    subgraph "External"
        ENV[Environment<br/>environment.py]
        NODES[nodes.py AST]
        RT[runtime.py]
    end

    CG -->|extends| NV
    CG -->|uses| Frame
    CG -->|uses| MacroRef
    CG -->|uses| DFV
    CG -->|uses| UNV
    CG -->|uses| OPT
    CG -->|uses| SYM
    CG -->|uses| FI
    CG -->|reads| ENV
    CG -->|visits| NODES
    CG -->|emits refs to| RT

    Frame -->|contains| SYM
    SYM -->|analyzed by| RV
    RV -->|delegates to| FSV
    FSV -->|extends| NV
    OPT -->|extends| NT

    TCG -->|extends| CG
    NCG -->|extends| CG

    DFV -->|extends| NV
    UNV -->|extends| NV
```

## Core Components

### CodeGenerator

`CodeGenerator` is the primary class of the module. It extends `NodeVisitor` and implements a `visit_<NodeType>` method for every AST node type. Each visitor method writes Python source code to an internal stream (`StringIO` by default) that, when executed, renders the template.

**Key responsibilities:**

- **Statement generation**: Emits Python control flow (`if`, `for`, `yield`, function definitions) for template statements such as `{% for %}`, `{% if %}`, `{% block %}`, `{% macro %}`, and `{% extends %}`.
- **Expression generation**: Emits Python expressions for template expressions, including operators, filters, tests, attribute/item access, and function calls.
- **Output handling**: Manages the `yield`-based output protocol, including buffering for macros and filter blocks, and constant folding of static output.
- **Inheritance**: Generates the block registry and parent-template chaining logic for template inheritance.
- **Dependency resolution**: Collects and emits runtime lookups for filters and tests via `pull_dependencies`.
- **Debug info**: Tracks line-number mappings between template source and generated code.

**Construction parameters:**

| Parameter | Description |
|-----------|-------------|
| `environment` | The `Environment` providing configuration, filters, tests, and globals. |
| `name` | The template's load name. |
| `filename` | The template's filesystem filename (for error reporting). |
| `stream` | Optional output stream; defaults to a new `StringIO`. |
| `defer_init` | If `True`, the generated code can be imported without a global environment variable. |
| `optimized` | If `True`, an `Optimizer` is attached for constant folding. |

**Notable internal state:**

- `blocks`: Registry of all `{% block %}` nodes, keyed by name.
- `import_aliases`: Mapping of imported names to generated aliases.
- `filters` / `tests`: Maps of filter/test names to generated variable identifiers.
- `_assign_stack`: Tracks top-level assignments for context export.
- `_param_def_block`: Tracks macro parameter definitions to skip undefined checks.
- `_context_reference_stack`: Tracks the current context reference (for scoped blocks and overlay scopes).
- `debug_info`: List of `(template_lineno, code_lineno)` tuples.

**Key methods:**

- `visit_Template`: The entry point. Generates the root render function, block functions, the block registry, and debug info.
- `macro_body` / `macro_def`: Generate the function body and `Macro` wrapper for macros and call blocks.
- `pull_dependencies`: Emits runtime lookups for filters and tests used in the template.
- `enter_frame` / `leave_frame`: Emit variable initialization and cleanup code based on symbol load instructions.
- `push_assign_tracking` / `pop_assign_tracking`: Track assignments that must be exported to the context.
- `_make_finalize`: Builds the finalize function used for output nodes (cached).

### Frame

`Frame` holds compile-time information for a lexical scope during code generation. Frames form a tree that mirrors the nesting of template constructs (templates, blocks, loops, macros, scopes).

**Key attributes:**

| Attribute | Description |
|-----------|-------------|
| `eval_ctx` | The `EvalContext` (autoescape, volatile flags). |
| `parent` | The parent frame, or `None` for the root. |
| `symbols` | The `Symbols` instance tracking variable references for this scope. |
| `buffer` | Name of the list used as an output buffer, or `None` if using `yield`. |
| `block` | Name of the enclosing block, or `None`. |
| `toplevel` | `True` for the root frame and soft frames (e.g. `if` conditions). |
| `rootlevel` | `True` only for the outermost frame (used to optimize inheritance). |
| `loop_frame` | `True` inside a loop body. |
| `block_frame` | `True` inside a block function. |
| `soft_frame` | `True` inside an `if`/conditional expression (affects error timing). |
| `require_output_check` | `True` when output must be guarded by a parent-template check. |

**Frame creation methods:**

- `inner(isolated=False)`: Creates a child frame. If `isolated`, creates a frame with a fresh symbol table (used for overlay scopes).
- `soft()`: Creates a copy that is no longer root-level, used for `if` statements and conditional expressions.
- `copy()`: Shallow-copies the frame and its symbols.

### MacroRef

`MacroRef` is a small data holder that records metadata about a macro or call block during code generation. It tracks whether the macro accesses the special `caller`, `kwargs`, or `varargs` parameters, which is needed to construct the runtime `Macro` object.

### DependencyFinderVisitor

A `NodeVisitor` that collects the names of all filters and tests used in a template. It stops visiting at `Block` nodes (since blocks are compiled separately). The collected names are used by `CodeGenerator.pull_dependencies` to emit runtime lookups.

### UndeclaredNameVisitor

A `NodeVisitor` that checks whether a given set of names is accessed without being declared. Unlike the frame symbol visitor, it does **not** stop at closure frames. It raises `VisitorExit` early once all target names have been found undeclared. Used by the `find_undeclared` helper.

### CompilerExit

An exception raised when the compiler encounters a situation where further processing of the current block makes no sense (e.g. a known `{% extends %}` that terminates execution). Blocks that raise this exception are not further processed.

### VisitorExit

An exception used by `UndeclaredNameVisitor` to signal an early stop once its work is complete.

### CodeGenerator._FinalizeInfo

A `NamedTuple` holding the two pieces of finalize information:

- `const`: A callable to finalize constant data at compile time (or `None`).
- `src`: Source code to emit around runtime-evaluated nodes (or `None`).

This is produced by `_make_finalize` and cached on the generator instance.

## Compilation Process Flow

The following sequence diagram illustrates how a template is compiled from an AST to Python source.

```mermaid
sequenceDiagram
    participant Env as Environment
    participant Gen as generate()
    participant CG as CodeGenerator
    participant Opt as Optimizer
    participant Sym as Symbols
    participant Stream as Output Stream

    Env->>Gen: generate(node, environment, ...)
    Gen->>CG: instantiate code_generator_class
    CG->>Opt: create Optimizer (if optimized)
    Gen->>CG: visit(Template node)
    CG->>CG: visit_Template()
    CG->>CG: collect blocks & imports
    CG->>CG: emit root render function
    CG->>Sym: analyze_node (build symbol table)
    CG->>CG: pull_dependencies()
    CG->>CG: blockvisit(body)
    loop For each AST node
        CG->>Opt: optimizeconst (constant folding)
        Opt-->>CG: folded Const or original node
        CG->>Stream: write generated Python
    end
    CG->>CG: emit block functions
    CG->>CG: emit block registry & debug info
    Gen-->>Env: return generated source
```

### Step-by-step

1. **Entry**: `Environment.compile` calls the module-level `generate` function, which instantiates the environment's `code_generator_class` (default `CodeGenerator`).
2. **Template visit**: `visit_Template` is invoked with the root `Template` node. It:
   - Emits imports from `jinja2.runtime`.
   - Collects all `Block` nodes into `self.blocks` (failing on duplicates).
   - Collects all `ImportedName` nodes and emits import statements.
   - Generates the `root` render function.
   - Generates a function for each block.
   - Emits the `blocks` registry and `debug_info`.
3. **Frame setup**: A root `Frame` is created and its `Symbols` are populated via `analyze_node`, which uses `RootVisitor` → `FrameSymbolVisitor`.
4. **Dependency pulling**: `pull_dependencies` walks the body with `DependencyFinderVisitor` and emits runtime lookups for filters/tests.
5. **Body visiting**: `blockvisit` iterates over the body nodes, dispatching to the appropriate `visit_*` method for each.
6. **Constant folding**: Expression visitors decorated with `@optimizeconst` attempt to fold constants via the `Optimizer` when the frame is not volatile.
7. **Output**: The generated source is returned (or written to the provided stream).

## Symbol Tracking and Frame Management

The compiler relies on the [idtracking module](idtracking.md) to resolve template variable names to unique Python identifiers and to determine how each variable should be loaded.

```mermaid
graph LR
    subgraph "Frame Tree"
        RF[Root Frame<br/>level 0]
        BF[Block Frame<br/>level 1]
        LF[Loop Frame<br/>level 1]
        MF[Macro Frame<br/>level 1]
    end

    RF -->|inner| BF
    RF -->|inner| LF
    RF -->|inner| MF

    subgraph "Symbols per Frame"
        S0[Symbols level 0]
        S1[Symbols level 1]
    end

    RF --- S0
    BF --- S1
    LF --- S1
    MF --- S1
```

**Load instructions** (defined in `idtracking.py`) determine how `enter_frame` initializes variables:

| Instruction | Meaning | Generated code |
|-------------|---------|----------------|
| `VAR_LOAD_PARAMETER` | Function parameter, always defined. | (no code) |
| `VAR_LOAD_RESOLVE` | Resolve from context at runtime. | `target = resolve('name')` |
| `VAR_LOAD_ALIAS` | Alias to an outer-scope variable. | `target = outer_ref` |
| `VAR_LOAD_UNDEFINED` | Not yet assigned. | `target = missing` |

The `FrameSymbolVisitor` and `RootVisitor` (both in `idtracking.py`) populate the `Symbols` object by walking the AST. `RootVisitor` handles the top-level structure (templates, blocks, macros, loops), while `FrameSymbolVisitor` handles the details of name binding within a frame.

## Optimization

When the environment is configured with `optimized=True` (the default), the `CodeGenerator` attaches an `Optimizer` instance. The `@optimizeconst` decorator wraps expression visitors so that, before generating code, the optimizer attempts to fold the node into a constant via `node.as_const()`.

```mermaid
flowchart TD
    A[visit expression node] --> B{optimizer enabled<br/>and frame not volatile?}
    B -->|No| F[generate code normally]
    B -->|Yes| C[Optimizer.visit node]
    C --> D{node changed?}
    D -->|No| F
    D -->|Yes| E[visit folded node]
    E --> F
```

The `Optimizer` (in [optimizer.md](optimizer.md)) is a `NodeTransformer` that performs constant folding on `Expr` nodes. If folding is impossible (`nodes.Impossible` is raised), the original node is retained.

## Output Generation and Finalization

Output nodes (`{{ ... }}`) are handled by `visit_Output`, which performs several optimizations:

1. **Constant folding**: Children that can be converted to constants at compile time are grouped and emitted as literal strings.
2. **Finalization**: The `_make_finalize` method builds a `_FinalizeInfo` describing how to apply the environment's `finalize` function (if any) to output values.
3. **Autoescape handling**: Depending on `eval_ctx.autoescape` and `eval_ctx.volatile`, output is wrapped in `escape()`, `str()`, or a runtime conditional.
4. **Buffering**: If the frame has a buffer (inside a macro or filter block), output is appended to the buffer list instead of yielded.

The `_FinalizeInfo` namedtuple separates compile-time (`const`) and runtime (`src`) finalization, allowing constants to be finalized eagerly while runtime values are wrapped in generated code.

## Subclasses and Specializations

The `CodeGenerator` is designed for extension. Two notable subclasses exist:

### TrackingCodeGenerator (meta.py)

Used for template introspection. It overrides `write` to discard output and `enter_frame` to record all undeclared identifiers. This powers the `meta.find_undeclared_variables` API. See [meta.md](meta.md).

### NativeCodeGenerator (nativetypes.py)

Renders Python native types instead of strings by omitting `str()` wrapping around output nodes. It overrides `_default_finalize`, `_output_const_repr`, `_output_child_to_const`, `_output_child_pre`, and `_output_child_post`. See [nativetypes.md](nativetypes.md).

```mermaid
classDiagram
    class NodeVisitor {
        +visit(node)
        +generic_visit(node)
    }
    class CodeGenerator {
        +visit_Template()
        +visit_Block()
        +visit_For()
        +visit_If()
        +visit_Macro()
        +visit_Output()
        +pull_dependencies()
        +enter_frame()
        +leave_frame()
    }
    class TrackingCodeGenerator {
        +undeclared_identifiers
        +write()
        +enter_frame()
    }
    class NativeCodeGenerator {
        +_default_finalize()
        +_output_child_to_const()
    }
    NodeVisitor <|-- CodeGenerator
    CodeGenerator <|-- TrackingCodeGenerator
    CodeGenerator <|-- NativeCodeGenerator
```

## Integration with the Environment

The compiler is tightly coupled to the `Environment` (see [runtime_execution_and_api.md](runtime_execution_and_api.md)):

- The environment provides `code_generator_class`, which the `generate` function instantiates.
- The environment supplies `filters`, `tests`, `globals`, `finalize`, `autoescape`, `undefined`, `is_async`, and `sandboxed` — all of which influence code generation.
- The environment's `compile` method orchestrates parsing → generation → Python compilation.

```mermaid
graph TD
    ENV[Environment.compile] -->|parse| P[Parser]
    P -->|AST| G[generate]
    G -->|instantiate| CG[code_generator_class]
    CG -->|emit| SRC[Python source]
    SRC -->|compile| CO[Code object]
    CO -->|exec| MOD[Template module]
    MOD -->|render| OUT[Output stream]
```

## Generated Code Structure

For a typical template, the generated Python module contains:

1. **Imports** from `jinja2.runtime` (e.g. `Markup`, `missing`, `concat`, `escape`, `identity`, `TemplateReference`, `Macro`, `LoopContext`).
2. **A `root` function**: `def root(context, missing=missing, environment=environment):` — the main render generator.
3. **Block functions**: `def block_<name>(context, missing=missing, environment=environment):` — one per `{% block %}`.
4. **A `blocks` dictionary**: Maps block names to their functions.
5. **A `debug_info` string**: Encodes line-number mappings.
6. **A `name` variable**: The template's load name.

The `root` and block functions are Python generators that `yield` output events. This streaming design allows templates to be rendered incrementally.

## Error Handling

The compiler raises `TemplateAssertionError` (via the `fail` method) for compile-time errors such as:

- Duplicate block definitions.
- `{% extends %}` in a non-top-level scope.
- Assignment to the special `loop` variable.
- Missing filters/tests (when not in a soft frame).
- Invalid `caller` argument placement in macros.

Runtime errors (e.g. missing filters inside `if`/conditional expressions) are deferred to runtime via the dependency-pulling mechanism, which emits `try`/`except KeyError` blocks that raise `TemplateRuntimeError`.

## Related Modules

- [template_parsing_frontend.md](template_parsing_frontend.md) — Produces the AST consumed by the compiler.
- [optimizer.md](optimizer.md) — Constant folding used during code generation.
- [idtracking.md](idtracking.md) — Symbol and frame tracking.
- [meta.md](meta.md) — Introspection via `TrackingCodeGenerator`.
- [nativetypes.md](nativetypes.md) — Native type rendering via `NativeCodeGenerator`.
- [runtime_execution_and_api.md](runtime_execution_and_api.md) — The `Environment` and runtime objects referenced by generated code.
- [extension_and_customization.md](extension_and_customization.md) — Extensions that hook into compilation.
