# Bytecode Cache Module

## Introduction

The **bytecode cache** module (`src/jinja2/bccache.py`) provides an optional caching layer for compiled Jinja template bytecode. Template compilation is an expensive operation — lexing, parsing, AST generation, optimization, and Python code generation all happen before a template can be rendered. For applications that load many complex templates (especially forking web applications initialized on the first request), recompiling every template on every process start can become a significant performance bottleneck.

The bytecode cache solves this by persisting the compiled Python code objects (`CodeType`) so that subsequent loads can skip the entire compilation pipeline and jump straight to execution. The cache is keyed by a hash of the template name and filename, and validated against a checksum of the template source, ensuring that stale bytecode is automatically rejected when a template changes.

This module belongs to the **template loading and caching** subsystem, working alongside the [template loaders](template_loading_and_caching.md) to intercept the compilation step.

---

## Core Concepts

### The Compilation Pipeline

To understand what the bytecode cache accelerates, consider the normal template loading flow:

```mermaid
flowchart LR
    A[Template Source] --> B[Lexer]
    B --> C[Parser]
    C --> D[AST Nodes]
    D --> E[Optimizer]
    E --> F[CodeGenerator]
    F --> G[Python Source]
    G --> H[compile]
    H --> I[CodeType Object]
    I --> J[Template Execution]
```

The bytecode cache stores the final `CodeType` object (step **I**), allowing the entire pipeline from **B** to **H** to be skipped on cache hits.

### Cache Invalidation Strategy

The module uses a two-level validation scheme to guarantee correctness:

1. **Magic header** (`bc_magic`) — Identifies the file as a Jinja bytecode cache and encodes the cache format version (`bc_version = 5`) plus the Python major/minor version. This prevents loading bytecode produced by an incompatible Python interpreter or an older Jinja cache format.
2. **Source checksum** — A SHA-1 hash of the template source. If the source has changed, the cached bytecode is discarded and the template is recompiled.

This design means individual cache backends never need to implement invalidation logic themselves — the `Bucket` class handles it transparently.

---

## Architecture

The module is organized around a small class hierarchy with a clear separation between the *cache contract*, the *cache unit*, and *concrete backends*.

```mermaid
classDiagram
    class BytecodeCache {
        <<abstract>>
        +load_bytecode(bucket)
        +dump_bytecode(bucket)
        +clear()
        +get_cache_key(name, filename)
        +get_source_checksum(source)
        +get_bucket(environment, name, filename, source)
        +set_bucket(bucket)
    }
    class FileSystemBytecodeCache {
        +directory
        +pattern
        +load_bytecode(bucket)
        +dump_bytecode(bucket)
        +clear()
    }
    class MemcachedBytecodeCache {
        +client
        +prefix
        +timeout
        +ignore_memcache_errors
        +load_bytecode(bucket)
        +dump_bytecode(bucket)
    }
    class Bucket {
        +environment
        +key
        +checksum
        +code
        +reset()
        +load_bytecode(f)
        +write_bytecode(f)
        +bytecode_from_string(string)
        +bytecode_to_string()
    }
    class _MemcachedClient {
        <<protocol>>
        +get(key)
        +set(key, value, timeout)
    }

    BytecodeCache <|-- FileSystemBytecodeCache
    BytecodeCache <|-- MemcachedBytecodeCache
    BytecodeCache ..> Bucket : creates
    MemcachedBytecodeCache ..> _MemcachedClient : uses
```

### Component Responsibilities

| Component | Responsibility |
|-----------|----------------|
| `BytecodeCache` | Abstract base class defining the cache contract and providing shared key/checksum/bucket logic. |
| `Bucket` | The unit of caching for a single template. Handles serialization, deserialization, and invalidation. |
| `FileSystemBytecodeCache` | Concrete backend storing bytecode as files on disk. |
| `MemcachedBytecodeCache` | Concrete backend storing bytecode in a memcached server. |
| `_MemcachedClient` | A `typing.Protocol` describing the minimal client interface required by the memcached backend. |

---

## Component Details

### `Bucket`

A `Bucket` represents the cached bytecode for **one** template. It is created and initialized by the cache (via `BytecodeCache.get_bucket`) and passed to the loading functions. Each bucket carries:

- `environment` — the owning `Environment` instance.
- `key` — the unique cache key (hash of name + filename).
- `checksum` — the SHA-1 checksum of the template source.
- `code` — the cached `CodeType` object, or `None` if not yet loaded.

The bucket is responsible for the **serialization format** and **invalidation logic**:

```mermaid
flowchart TD
    Start[load_bytecode f] --> Magic{Read magic header}
    Magic -->|mismatch| Reset[reset: code = None]
    Magic -->|match| Checksum{Read checksum}
    Checksum -->|mismatch| Reset
    Checksum -->|match| Marshal{Try marshal.load}
    Marshal -->|EOFError/ValueError/TypeError| Reset
    Marshal -->|success| Set[code = loaded CodeType]
```

The on-disk / in-memory format written by `write_bytecode` is:

```
[ bc_magic ][ pickled checksum ][ marshalled code object ]
```

Key methods:

- `reset()` — Unloads the bytecode by setting `code = None`.
- `load_bytecode(f)` — Reads and validates bytecode from a binary file-like object.
- `write_bytecode(f)` — Serializes the bytecode to a binary file-like object. Raises `TypeError` if the bucket is empty.
- `bytecode_from_string(string)` / `bytecode_to_string()` — Convenience wrappers around the file-based methods using `BytesIO`, used by the memcached backend.

### `BytecodeCache` (Abstract Base)

The base class defines the contract that all backends must fulfill and provides shared, backend-agnostic logic.

**Methods subclasses must override:**

- `load_bytecode(bucket)` — Load bytecode into the bucket. Must do nothing if no cached code is found.
- `dump_bytecode(bucket)` — Write the bucket's bytecode back to the cache. Must raise on failure rather than fail silently.

**Methods provided by the base class:**

- `get_cache_key(name, filename)` — Computes a SHA-1 hex digest from the template name and (optionally) filename.
- `get_source_checksum(source)` — Computes a SHA-1 hex digest of the template source.
- `get_bucket(environment, name, filename, source)` — Factory that builds a `Bucket`, computes its key and checksum, and attempts to load existing bytecode into it.
- `set_bucket(bucket)` — Persists a bucket by delegating to `dump_bytecode`.
- `clear()` — No-op by default; subclasses may implement cache clearing.

### `FileSystemBytecodeCache`

Stores bytecode as individual files on the filesystem. This is the most common backend and is used by default in many deployments.

**Constructor parameters:**

- `directory` — The directory where cache files are stored. If `None`, a safe default is chosen via `_get_default_cache_dir()`.
- `pattern` — A filename pattern (default `"__jinja2_%s.cache"`) where `%s` is replaced by the bucket key. Multiple independent caches can share a directory by using different patterns.

**Default directory selection** (`_get_default_cache_dir`) is security-conscious:

```mermaid
flowchart TD
    A[Get system temp dir] --> B{Windows?}
    B -->|yes| C[Use temp dir directly]
    B -->|no| D{Has getuid?}
    D -->|no| E[Raise RuntimeError]
    D -->|yes| F[Build _jinja2-cache-UID dir]
    F --> G{Create dir with mode 0700}
    G --> H{Verify owner, is-dir, mode 0700}
    H -->|unsafe| E
    H -->|safe| I[Return dir]
```

On UNIX systems, the cache directory is created with `S_IRWXU` (owner-only) permissions and verified to be owned by the current user, a directory, and mode `0700`. If any check fails, a `RuntimeError` is raised rather than risking writing to an unsafe location.

**Methods:**

- `load_bytecode(bucket)` — Opens the cache file if it exists and delegates to `bucket.load_bytecode`.
- `dump_bytecode(bucket)` — Writes the bucket to its cache file.
- `clear()` — Removes all files matching the pattern from the directory. The `os.remove` import is performed lazily because Google App Engine does not support filesystem write access.

### `MemcachedBytecodeCache`

Stores bytecode in a memcached server. It does **not** enforce a specific memcached library; instead it accepts any client implementing the minimal interface described by `_MemcachedClient`.

**Compatible libraries:** `cachelib`, `python-memcached`. (Django's cache interface is *not* directly compatible because it does not support binary data, though the underlying client can be passed.)

**Constructor parameters:**

- `client` — The memcached client instance.
- `prefix` — Key prefix added before the bucket key (default `"jinja2/bytecode/"`).
- `timeout` — Optional expiration timeout in seconds. A high or no timeout is recommended.
- `ignore_memcache_errors` — If `True` (default), memcache errors are swallowed; if `False`, they propagate.

**Methods:**

- `load_bytecode(bucket)` — Fetches the value from the client and loads it via `bucket.bytecode_from_string`. Errors are ignored unless `ignore_memcache_errors` is `False`.
- `dump_bytecode(bucket)` — Serializes the bucket via `bucket.bytecode_to_string` and stores it, passing the timeout if set.

This backend does **not** support clearing; `clear()` remains the base-class no-op.

### `_MemcachedClient` (Protocol)

A `typing.Protocol` (only defined under `TYPE_CHECKING`) that documents the minimal client interface required by `MemcachedBytecodeCache`:

- `get(key: str) -> bytes` — Returns the cached value, or `None` if absent.
- `set(key: str, value: bytes, timeout: Optional[int] = None) -> None` — Stores a value with an optional timeout.

---

## Integration with the Loading Pipeline

The bytecode cache is wired into the template loading flow through the `Environment` and `BaseLoader` classes. The `Environment` accepts a `bytecode_cache` parameter, and `BaseLoader.load` consults it during template loading.

```mermaid
sequenceDiagram
    participant App as Application
    participant Env as Environment
    participant Loader as BaseLoader
    participant BCC as BytecodeCache
    participant Bucket as Bucket

    App->>Env: get_template(name)
    Env->>Loader: load(environment, name, globals)
    Loader->>Loader: get_source(environment, name)
    Note over Loader: returns (source, filename, uptodate)
    Loader->>Env: bytecode_cache
    alt bytecode cache configured
        Loader->>BCC: get_bucket(env, name, filename, source)
        BCC->>Bucket: new Bucket(env, key, checksum)
        BCC->>BCC: load_bytecode(bucket)
        BCC-->>Loader: bucket
        Loader->>Bucket: bucket.code
    end
    alt code is None (cache miss)
        Loader->>Env: compile(source, name, filename)
        Env-->>Loader: CodeType
        Loader->>Bucket: bucket.code = code
        Loader->>BCC: set_bucket(bucket)
    end
    Loader->>Env: template_class.from_code(...)
    Env-->>App: Template
```

The relevant logic in `BaseLoader.load` (see [template loaders](template_loading_and_caching.md)) is:

1. Fetch the source, filename, and uptodate function from `get_source`.
2. If a bytecode cache is configured, obtain a bucket via `get_bucket` and read `bucket.code`.
3. If no code was cached, compile the template via `Environment.compile` (see [compilation and codegen](compilation_and_codegen.md)).
4. If the cache is configured and the bucket had no code, store the newly compiled code back into the cache via `set_bucket`.

This design keeps the cache entirely transparent to the rest of the system — the loader simply checks whether code is available before compiling.

---

## Data Flow

The following diagram shows how data flows through the cache during a load and a store operation.

```mermaid
flowchart TD
    subgraph Load["Cache Load (get_bucket)"]
        L1[Template name + filename] --> L2[get_cache_key -> SHA1]
        L3[Template source] --> L4[get_source_checksum -> SHA1]
        L2 --> L5[Bucket env, key, checksum]
        L4 --> L5
        L5 --> L6[load_bytecode bucket]
        L6 --> L7{Valid magic + checksum?}
        L7 -->|yes| L8[bucket.code = CodeType]
        L7 -->|no| L9[bucket.code = None]
    end

    subgraph Store["Cache Store (set_bucket)"]
        S1[bucket.code = CodeType] --> S2[dump_bytecode bucket]
        S2 --> S3[write_bytecode: magic + checksum + marshal]
        S3 --> S4[Persist to backend]
    end
```

---

## Usage Examples

### Configuring a Filesystem Cache

```python
from jinja2 import Environment, FileSystemLoader
from jinja2.bccache import FileSystemBytecodeCache

bcc = FileSystemBytecodeCache("/tmp/jinja_cache", "%s.cache")
env = Environment(
    loader=FileSystemLoader("templates"),
    bytecode_cache=bcc,
)
```

### Configuring a Memcached Cache

```python
from jinja2 import Environment, FileSystemLoader
from jinja2.bccache import MemcachedBytecodeCache
import memcache

client = memcache.Client(["127.0.0.1:11211"])
bcc = MemcachedBytecodeCache(client, prefix="myapp/jinja/", timeout=3600)
env = Environment(
    loader=FileSystemLoader("templates"),
    bytecode_cache=bcc,
)
```

### Implementing a Custom Backend

```python
from jinja2.bccache import BytecodeCache

class MyCache(BytecodeCache):
    def __init__(self, directory):
        self.directory = directory

    def load_bytecode(self, bucket):
        filename = os.path.join(self.directory, bucket.key)
        if os.path.exists(filename):
            with open(filename, "rb") as f:
                bucket.load_bytecode(f)

    def dump_bytecode(self, bucket):
        filename = os.path.join(self.directory, bucket.key)
        with open(filename, "wb") as f:
            bucket.write_bytecode(f)
```

---

## Design Considerations

### Why Marshal + Pickle?

The serialization format combines two Python standard-library mechanisms:

- **`marshal`** is used for the `CodeType` object because it is the only standard-library serializer capable of round-tripping code objects.
- **`pickle`** is used for the checksum and version metadata because it is more portable and version-tolerant than marshal for simple data.

### Version Compatibility

The `bc_magic` header embeds both the Jinja cache format version (`bc_version = 5`) and the Python interpreter version. This ensures that:

- Upgrading Python invalidates all cached bytecode (code objects are not portable across Python versions).
- Changing the Jinja cache format invalidates old caches.

### Error Tolerance

The `Bucket.load_bytecode` method catches `EOFError`, `ValueError`, and `TypeError` from `marshal.load`, treating any deserialization failure as a cache miss. This makes the cache resilient to truncated or corrupted cache files — the worst case is a recompilation, never a crash.

### Security

The filesystem backend's default directory logic is deliberately defensive, verifying ownership and permissions to avoid writing cache files to a world-writable or attacker-controlled location.

---

## Related Modules

- [Template Loaders](template_loading_and_caching.md) — `BaseLoader.load` is the primary consumer of the bytecode cache.
- [Compilation and Codegen](compilation_and_codegen.md) — Produces the `CodeType` objects that the cache stores.
- [Runtime Execution and API](runtime_execution_and_api.md) — The `Environment` class accepts the `bytecode_cache` configuration parameter.
