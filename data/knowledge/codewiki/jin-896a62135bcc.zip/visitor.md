# Visitor Module

## Introduction

The `visitor` module (`src/jinja2/visitor.py`) provides the foundational **AST traversal API** for Jinja2's template engine. It implements the classic [Visitor pattern](https://en.wikipedia.org/wiki/Visitor_pattern) over the abstract syntax tree (AST) defined in the [`nodes`](nodes.md) module.

The module exposes two core classes:

- **`NodeVisitor`** — walks the AST and dispatches to per-node-type visitor functions, forwarding return values.
- **`NodeTransformer`** — a subclass of `NodeVisitor` that additionally allows nodes to be **replaced or removed** during traversal.

These classes are the backbone of nearly every AST-consuming subsystem in Jinja2, including the compiler, the optimizer, identifier tracking, and meta-introspection. Rather than each subsystem re-implementing tree walking, they all subclass or instantiate these visitors.

> **Note:** This module is intentionally minimal and dependency-light. It only depends on the [`nodes`](nodes.md) module for the `Node` base class, making it a stable, low-level primitive that higher-level modules build upon.

---

## Architecture Overview

The visitor module sits at the bottom of the AST-processing stack. It is consumed by the compilation/codegen layer, which in turn feeds the runtime execution layer.

```mermaid
graph TD
    subgraph "AST Definition"
        NODES["nodes<br/>(Node, NodeType, Stmt, Expr, ...)"]
    end

    subgraph "visitor (this module)"
        NV["NodeVisitor"]
        NT["NodeTransformer"]
        VC["VisitCallable (Protocol)"]
    end

    subgraph "compilation_and_codegen"
        CG["CodeGenerator"]
        OPT["Optimizer"]
        DFV["DependencyFinderVisitor"]
        UNV["UndeclaredNameVisitor"]
        FSV["FrameSymbolVisitor"]
        RV["RootVisitor"]
        TCG["TrackingCodeGenerator"]
    end

    NODES --> NV
    NODES --> NT
    NV --> NT
    NV --> CG
    NT --> OPT
    NV --> DFV
    NV --> UNV
    NV --> FSV
    NV --> RV
    CG --> TCG

    style NV fill:#4a90d9,color:#fff
    style NT fill:#4a90d9,color:#fff
    style VC fill:#9bb8d3,color:#000
```

### Key Design Points

| Aspect | Description |
|--------|-------------|
| **Dispatch mechanism** | Visitor functions are resolved by name: `visit_<ClassName>` (e.g., `visit_For`, `visit_If`). |
| **Fallback** | If no specific visitor exists, `generic_visit` is invoked. |
| **Return forwarding** | `visit()` returns whatever the visitor function returns, enabling value-producing traversals. |
| **Mutation** | Only `NodeTransformer` mutates the tree; `NodeVisitor` is read-only by convention. |
| **Extensibility** | `get_visitor` can be overridden to change dispatch behavior. |

---

## Core Components

### `NodeVisitor`

The base class for read-only AST traversal.

```python
class NodeVisitor:
    def get_visitor(self, node: Node) -> "t.Optional[VisitCallable]":
        return getattr(self, f"visit_{type(node).__name__}", None)

    def visit(self, node: Node, *args, **kwargs) -> t.Any:
        f = self.get_visitor(node)
        if f is not None:
            return f(node, *args, **kwargs)
        return self.generic_visit(node, *args, **kwargs)

    def generic_visit(self, node: Node, *args, **kwargs) -> t.Any:
        for node in node.iter_child_nodes():
            self.visit(node, *args, **kwargs)
```

**Behavior:**

1. `visit(node)` looks up a method named `visit_<NodeClassName>`.
2. If found, it is called with the node and any extra `*args`/`**kwargs`.
3. If not found, `generic_visit` recursively visits all direct child nodes (via `Node.iter_child_nodes()`).
4. The return value of the visitor function is forwarded to the caller.

**Customization points:**

- Override `get_visitor` to change how visitor functions are resolved (e.g., a registry-based dispatch).
- Override `generic_visit` to change default recursion behavior.
- Extra positional/keyword arguments passed to `visit()` are threaded through to every visitor function — this is how the compiler passes its `frame` argument.

### `NodeTransformer`

A subclass of `NodeVisitor` that supports **in-place tree modification**.

```python
class NodeTransformer(NodeVisitor):
    def generic_visit(self, node: Node, *args, **kwargs) -> Node:
        for field, old_value in node.iter_fields():
            if isinstance(old_value, list):
                new_values = []
                for value in old_value:
                    if isinstance(value, Node):
                        value = self.visit(value, *args, **kwargs)
                        if value is None:
                            continue
                        elif not isinstance(value, Node):
                            new_values.extend(value)
                            continue
                    new_values.append(value)
                old_value[:] = new_values
            elif isinstance(old_value, Node):
                new_node = self.visit(old_value, *args, **kwargs)
                if new_node is None:
                    delattr(node, field)
                else:
                    setattr(node, field, new_node)
        return node

    def visit_list(self, node: Node, *args, **kwargs) -> t.List[Node]:
        rv = self.visit(node, *args, **kwargs)
        if not isinstance(rv, list):
            return [rv]
        return rv
```

**Replacement semantics** (the return value of a visitor function determines the outcome):

| Return value | Effect |
|--------------|--------|
| `None` | The node is **removed** from its parent (field deleted, or dropped from list). |
| A `Node` | The node is **replaced** with the returned node. |
| A `list` of nodes | The node is **expanded** into multiple nodes (only valid inside list fields). |
| The original node | No change. |

**`visit_list` helper:** Because transformers may legitimately return a list, `visit_list` normalizes the result to always be a list — useful when a caller expects a list regardless of the visitor's return type.

### `VisitCallable` (Protocol)

A `typing.Protocol` (only defined under `TYPE_CHECKING`) describing the callable signature of a visitor function:

```python
class VisitCallable(te.Protocol):
    def __call__(self, node: Node, *args: t.Any, **kwargs: t.Any) -> t.Any:
        ...
```

This is purely a type-checking aid; it has no runtime footprint.

---

## Data Flow

The following diagram illustrates how a traversal flows through the visitor API, including the dispatch decision and the transformer's mutation path.

```mermaid
flowchart TD
    START["visit(node, *args, **kwargs)"] --> GET["get_visitor(node)"]
    GET --> HAS{"visit_<ClassName><br/>exists?"}
    HAS -->|Yes| CALL["Call visitor function<br/>f(node, *args, **kwargs)"]
    HAS -->|No| GENERIC["generic_visit(node, ...)"]

    CALL --> RET["Return value forwarded"]

    GENERIC --> MODE{"NodeVisitor or<br/>NodeTransformer?"}
    MODE -->|NodeVisitor| RECURSE["For each child node:<br/>self.visit(child)"]
    MODE -->|NodeTransformer| FIELDS["For each field in node.iter_fields()"]

    FIELDS --> ISLIST{"Field is a list?"}
    ISLIST -->|Yes| LISTLOOP["Visit each Node in list"]
    LISTLOOP --> LNULL{"Returns None?"}
    LNULL -->|Yes| DROP["Drop from list"]
    LNULL -->|No| LEXPAND{"Returns list?"}
    LEXPAND -->|Yes| EXTEND["Extend list with result"]
    LEXPAND -->|No| KEEP["Keep/replace value"]
    ISLIST -->|No| SINGLE{"Field is a Node?"}
    SINGLE -->|Yes| SNULL{"Returns None?"}
    SNULL -->|Yes| DELATTR["delattr(node, field)"]
    SNULL -->|No| SETATTR["setattr(node, field, new_node)"]

    RECURSE --> RET
    DROP --> RET
    EXTEND --> RET
    KEEP --> RET
    DELATTR --> RET
    SETATTR --> RET
```

---

## Component Interaction

The visitor module is the shared traversal engine for the entire compilation and code-generation pipeline. Each consumer subclasses `NodeVisitor` or `NodeTransformer` and implements a focused set of `visit_*` methods.

```mermaid
classDiagram
    class NodeVisitor {
        +get_visitor(node)
        +visit(node, *args, **kwargs)
        +generic_visit(node, *args, **kwargs)
    }
    class NodeTransformer {
        +generic_visit(node, *args, **kwargs)
        +visit_list(node, *args, **kwargs)
    }
    class CodeGenerator {
        +visit_Template()
        +visit_For()
        +visit_If()
        +visit_Output()
        ...
    }
    class Optimizer {
        +generic_visit()
    }
    class DependencyFinderVisitor {
        +visit_Filter()
        +visit_Test()
        +visit_Block()
    }
    class UndeclaredNameVisitor {
        +visit_Name()
        +visit_Block()
    }
    class FrameSymbolVisitor {
        +visit_Name()
        +visit_If()
        +visit_For()
        ...
    }
    class RootVisitor {
        +visit_Template()
        +visit_For()
        ...
    }
    class TrackingCodeGenerator {
        +write()
        +enter_frame()
    }

    NodeVisitor <|-- NodeTransformer
    NodeVisitor <|-- CodeGenerator
    NodeTransformer <|-- Optimizer
    NodeVisitor <|-- DependencyFinderVisitor
    NodeVisitor <|-- UndeclaredNameVisitor
    NodeVisitor <|-- FrameSymbolVisitor
    NodeVisitor <|-- RootVisitor
    CodeGenerator <|-- TrackingCodeGenerator
```

### Consumers and Their Roles

| Consumer | Base class | Purpose | Documentation |
|----------|-----------|---------|---------------|
| `CodeGenerator` | `NodeVisitor` | Walks the AST and emits Python source code for each node. | [compiler.md](compiler.md) |
| `Optimizer` | `NodeTransformer` | Performs constant folding by transforming `Expr` nodes into `Const` nodes. | [optimizer.md](optimizer.md) |
| `DependencyFinderVisitor` | `NodeVisitor` | Collects all filter and test names used in a template. | [compiler.md](compiler.md) |
| `UndeclaredNameVisitor` | `NodeVisitor` | Detects names accessed without being declared (does not stop at closure frames). | [compiler.md](compiler.md) |
| `FrameSymbolVisitor` | `NodeVisitor` | Tracks symbol declarations, stores, and loads within a frame. | [idtracking.md](idtracking.md) |
| `RootVisitor` | `NodeVisitor` | Drives symbol analysis from the root of the template. | [idtracking.md](idtracking.md) |
| `TrackingCodeGenerator` | `CodeGenerator` | Abuses the code generator for introspection, recording undeclared identifiers. | [meta.md](meta.md) |

---

## Process Flow: A Typical Compilation Traversal

The following sequence diagram shows how the visitor API is exercised during a typical compilation pass, using `CodeGenerator` as the concrete example.

```mermaid
sequenceDiagram
    participant Caller as Compiler Driver
    participant CG as CodeGenerator (NodeVisitor)
    participant V as visit()
    participant GV as get_visitor()
    participant VF as visit_For()
    participant Node as Node (AST)

    Caller->>CG: visit_Template(template_node)
    CG->>V: visit(node, frame)
    V->>GV: get_visitor(node)
    GV-->>V: visit_For (bound method)
    V->>VF: visit_For(node, frame)
    VF->>V: visit(node.iter, frame)
    V->>GV: get_visitor(node.iter)
    GV-->>V: visit_Name
    V->>VF: visit_Name(node.iter, frame)
    VF-->>V: (writes code)
    VF-->>V: (writes code)
    VF-->>CG: returns
    CG-->>Caller: returns
```

### Transformer Flow: Constant Folding

The `Optimizer` demonstrates the mutation path of `NodeTransformer`:

```mermaid
sequenceDiagram
    participant OPT as Optimizer (NodeTransformer)
    participant GV as generic_visit()
    participant Node as Node (AST)

    OPT->>GV: generic_visit(node)
    GV->>GV: super().generic_visit(node)
    Note over GV: Recursively transform children
    GV->>GV: if isinstance(node, Expr)
    GV->>Node: node.as_const(eval_ctx)
    alt Constant-foldable
        Node-->>GV: constant value
        GV->>GV: return Const.from_untrusted(...)
    else Impossible
        Node-->>GV: raises Impossible
        GV->>GV: return node (unchanged)
    end
```

---

## Extending the Visitor

To build a custom AST pass, subclass the appropriate base class and implement `visit_<NodeType>` methods.

### Read-only traversal

```python
from jinja2.visitor import NodeVisitor
from jinja2 import nodes

class NameCollector(NodeVisitor):
    def __init__(self):
        self.names = set()

    def visit_Name(self, node: nodes.Name) -> None:
        self.names.add(node.name)
        # No need to call generic_visit for leaf nodes.
```

### Tree transformation

```python
from jinja2.visitor import NodeTransformer
from jinja2 import nodes

class ConstFolder(NodeTransformer):
    def visit_Add(self, node: nodes.Add, *args, **kwargs) -> nodes.Node:
        node = super().generic_visit(node, *args, **kwargs)
        # Return a Const to replace the Add node, or None to remove it.
        return node
```

### Passing context through traversal

Extra arguments passed to `visit()` are forwarded to every visitor function. This is how `CodeGenerator` threads its `frame` object:

```python
self.visit(node.body, frame)   # frame is forwarded to every visit_* call
```

---

## Relationship to Other Modules

```mermaid
graph LR
    VISITOR["visitor<br/>(this module)"]
    NODES["nodes"]
    COMPILER["compiler"]
    OPTIMIZER["optimizer"]
    IDTRACKING["idtracking"]
    META["meta"]
    NATIVETYPES["nativetypes"]

    NODES -->|"provides Node"| VISITOR
    VISITOR -->|"NodeVisitor"| COMPILER
    VISITOR -->|"NodeTransformer"| OPTIMIZER
    VISITOR -->|"NodeVisitor"| IDTRACKING
    VISITOR -->|"NodeVisitor"| META
    COMPILER -->|"CodeGenerator"| NATIVETYPES

    style VISITOR fill:#4a90d9,color:#fff
```

- **[nodes.md](nodes.md)** — Defines the `Node` hierarchy that the visitor traverses. The `iter_child_nodes()` and `iter_fields()` methods on `Node` are the primary interfaces the visitor relies on.
- **[compiler.md](compiler.md)** — `CodeGenerator` is the largest `NodeVisitor` subclass, emitting Python code for every node type.
- **[optimizer.md](optimizer.md)** — `Optimizer` is the primary `NodeTransformer` subclass, performing constant folding.
- **[idtracking.md](idtracking.md)** — `FrameSymbolVisitor` and `RootVisitor` use `NodeVisitor` to analyze variable scoping.
- **[meta.md](meta.md)** — `TrackingCodeGenerator` subclasses `CodeGenerator` to introspect undeclared identifiers.

---

## Summary

The `visitor` module is a small but foundational component of Jinja2. It provides:

1. **`NodeVisitor`** — a read-only, name-dispatch AST walker with a `generic_visit` fallback.
2. **`NodeTransformer`** — a mutating walker supporting node replacement, removal, and expansion.
3. **`VisitCallable`** — a typing protocol for visitor function signatures.

Its design — name-based dispatch, return-value forwarding, and a single generic recursion fallback — makes it both simple to use and powerful enough to support the entire compilation, optimization, and introspection pipeline of Jinja2.
