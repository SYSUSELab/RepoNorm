# Sandbox Module

## Introduction

The `sandbox` module (`src/jinja2/sandbox.py`) provides a security layer for Jinja2 that ensures unsafe operations cannot be performed when rendering templates. It is designed for scenarios where **the template itself comes from an untrusted source** — for example, user-supplied templates in a multi-tenant application, or templates stored in a database that could be modified by an attacker.

The sandbox works by subclassing the standard [`Environment`](runtime_execution_and_api.md) and overriding the methods that the compiler and runtime use to resolve attributes, items, and callables. When a template attempts to access something deemed insecure, a [`SecurityError`](runtime_execution_and_api.md) is raised instead of executing the operation.

> **Note:** The sandbox is a *defense-in-depth* mechanism, not a complete security boundary. It restricts what template code can do, but callers must still catch exceptions and treat template output as untrusted.

---

## Core Components

| Component | Role |
|-----------|------|
| `SandboxedEnvironment` | The primary sandboxed environment. Overrides attribute/item access and callable checks. |
| `ImmutableSandboxedEnvironment` | Extends `SandboxedEnvironment` to additionally block mutation of builtin mutable containers. |
| `SandboxedFormatter` | A `string.Formatter` subclass that routes field access through the sandbox's safe `getattr`/`getitem`. |
| `SandboxedEscapeFormatter` | Combines `SandboxedFormatter` with `markupsafe.EscapeFormatter` for autoescaped `str.format` calls. |

### Supporting Helpers

The module also exposes several module-level helpers that implement the security policy:

- `safe_range(*args)` — a replacement for the builtin `range` that caps output at `MAX_RANGE` (100,000) items.
- `unsafe(f)` — decorator marking a function/method as unsafe to call.
- `is_internal_attribute(obj, attr)` — detects internal Python attributes (e.g. `func_code`, `mro`, `gi_frame`).
- `modifies_known_mutable(obj, attr)` — detects attributes that would mutate builtin mutable containers.
- `inspect_format_method(callable)` — detects `str.format` / `str.format_map` bound methods so they can be routed through the sandbox.

---

## Architecture

The sandbox sits between the template compiler/runtime and the objects exposed to templates. It intercepts every attribute lookup, item subscription, and callable invocation.

```mermaid
graph TD
    subgraph "Runtime Execution & API"
        ENV["Environment"]
        CTX["Context"]
        UND["Undefined"]
        SEC["SecurityError"]
    end

    subgraph "Sandbox Module"
        SE["SandboxedEnvironment"]
        ISE["ImmutableSandboxedEnvironment"]
        SF["SandboxedFormatter"]
        SEF["SandboxedEscapeFormatter"]
        HELPERS["Helpers:<br/>safe_range, unsafe,<br/>is_internal_attribute,<br/>modifies_known_mutable"]
    end

    subgraph "External"
        MS["markupsafe<br/>EscapeFormatter / Markup"]
        FMT["string.Formatter"]
    end

    ENV -->|subclass| SE
    SE -->|subclass| ISE
    SE -->|uses| HELPERS
    ISE -->|uses| HELPERS
    SE -->|creates| SF
    SE -->|creates| SEF
    SF -->|subclass| FMT
    SEF -->|subclass| SF
    SEF -->|subclass| MS
    SE -->|raises| SEC
    SE -->|returns| UND
    SE -->|receives| CTX
```

---

## Component Relationships

```mermaid
classDiagram
    class Environment {
        +sandboxed: bool
        +getattr(obj, attribute)
        +getitem(obj, argument)
        +call(...)
        +format_string(...)
    }
    class SandboxedEnvironment {
        +sandboxed = True
        +default_binop_table
        +default_unop_table
        +intercepted_binops
        +intercepted_unops
        +is_safe_attribute(obj, attr, value)
        +is_safe_callable(obj)
        +call_binop(context, operator, left, right)
        +call_unop(context, operator, arg)
        +getitem(obj, argument)
        +getattr(obj, attribute)
        +unsafe_undefined(obj, attribute)
        +format_string(s, args, kwargs, format_func)
        +call(context, obj, *args, **kwargs)
    }
    class ImmutableSandboxedEnvironment {
        +is_safe_attribute(obj, attr, value)
    }
    class SandboxedFormatter {
        +get_field(field_name, args, kwargs)
    }
    class SandboxedEscapeFormatter

    Environment <|-- SandboxedEnvironment
    SandboxedEnvironment <|-- ImmutableSandboxedEnvironment
    SandboxedFormatter <|-- SandboxedEscapeFormatter
    SandboxedEnvironment ..> SandboxedFormatter : creates
    SandboxedEnvironment ..> SandboxedEscapeFormatter : creates
```

---

## Security Policy

The sandbox enforces security through a set of overridable policy methods. The default policy is conservative but designed to remain usable.

### Attribute Safety — `is_safe_attribute`

By default, an attribute is considered **unsafe** if:

1. It starts with an underscore (`_`), or
2. `is_internal_attribute(obj, attr)` returns `True`.

`is_internal_attribute` blocks dangerous attributes on specific object types:

| Object Type | Blocked Attributes |
|-------------|--------------------|
| `FunctionType` | `UNSAFE_FUNCTION_ATTRIBUTES` |
| `MethodType` | `UNSAFE_FUNCTION_ATTRIBUTES`, `UNSAFE_METHOD_ATTRIBUTES` |
| `type` | `mro` |
| `CodeType`, `TracebackType`, `FrameType` | *all* attributes |
| `GeneratorType` | `gi_frame`, `gi_code` |
| `CoroutineType` | `cr_frame`, `cr_code` |
| `AsyncGeneratorType` | `ag_code`, `ag_frame` |

Additionally, any attribute starting with `__` (dunder) is blocked.

### Callable Safety — `is_safe_callable`

A callable is considered unsafe if it has either:

- `unsafe_callable = True` (set via the `@unsafe` decorator), or
- `alters_data = True` (the Django convention).

### Mutable Object Protection — `ImmutableSandboxedEnvironment`

`ImmutableSandboxedEnvironment` extends the attribute check to also block methods that would mutate builtin mutable containers. The `_mutable_spec` table defines the blocked methods:

| Container Type | Blocked Methods |
|----------------|-----------------|
| `abc.MutableSet` | `add`, `clear`, `difference_update`, `discard`, `pop`, `remove`, `symmetric_difference_update`, `update` |
| `abc.MutableMapping` | `clear`, `pop`, `popitem`, `setdefault`, `update` |
| `abc.MutableSequence` | `append`, `reverse`, `insert`, `sort`, `extend`, `remove` |
| `deque` | `append`, `appendleft`, `clear`, `extend`, `extendleft`, `pop`, `popleft`, `remove`, `rotate` |

### Range Limiting

The builtin `range` is replaced in the environment globals with `safe_range`, which raises `OverflowError` if the resulting range would exceed `MAX_RANGE` (100,000) items. This prevents denial-of-service via huge range iterations.

---

## Data Flow: Attribute Access

When a template accesses `obj.attr` or `obj[arg]`, the sandbox intercepts the operation and applies the safety policy.

```mermaid
flowchart TD
    A["Template: obj.attr / obj[arg]"] --> B{getattr or getitem?}
    B -->|getattr| C["getattr(obj, attribute)"]
    B -->|getitem| D["getitem(obj, argument)"]

    C --> C1{"getattr succeeds?"}
    C1 -->|No| C2["try obj[attribute]"]
    C1 -->|Yes| C3{"is_safe_attribute?"}
    C3 -->|Yes| C4["return value"]
    C3 -->|No| C5["unsafe_undefined()"]
    C2 -->|fails| C6["undefined()"]
    C2 -->|succeeds| C4

    D --> D1{"obj[argument] succeeds?"}
    D1 -->|Yes| D2["return value"]
    D1 -->|No| D3{"argument is str?"}
    D3 -->|Yes| D4["getattr(obj, argument)"]
    D3 -->|No| D6["undefined()"]
    D4 -->|succeeds| D5{"is_safe_attribute?"}
    D5 -->|Yes| D2
    D5 -->|No| D7["unsafe_undefined()"]
    D4 -->|fails| D6

    C5 --> E["Undefined with SecurityError"]
    D7 --> E
```

`unsafe_undefined` returns an `Undefined` instance configured with `exc=SecurityError`, so that any attempt to *use* the unsafe value raises a `SecurityError` with a descriptive message.

---

## Data Flow: Callable Invocation

When a template calls a callable, the sandbox checks whether it is safe and whether it is a `str.format` method.

```mermaid
flowchart TD
    A["Template: obj(...)"] --> B["SandboxedEnvironment.call()"]
    B --> C{"inspect_format_method(obj)?"}
    C -->|Yes, format/format_map| D["format_string()"]
    C -->|No| E{"is_safe_callable(obj)?"}
    E -->|No| F["raise SecurityError"]
    E -->|Yes| G["context.call(obj, *args, **kwargs)"]

    D --> D1{"Markup instance?"}
    D1 -->|Yes| D2["SandboxedEscapeFormatter"]
    D1 -->|No| D3["SandboxedFormatter"]
    D2 --> D4["vformat()"]
    D3 --> D4
    D4 --> D5["return type(s)(rv)"]
```

### Format String Handling

`format_string` routes `str.format` and `str.format_map` calls through a `SandboxedFormatter`. This is important because the standard `string.Formatter` uses raw `getattr`/`getitem`, which would bypass the sandbox. The `SandboxedFormatter.get_field` method splits the field name and resolves each attribute/item access through `self._env.getattr` / `self._env.getitem`, ensuring the safety policy is applied.

For `Markup` (autoescaped) strings, `SandboxedEscapeFormatter` is used, which combines the sandbox's field resolution with `markupsafe`'s escaping behavior.

---

## Operator Interception

The sandbox supports intercepting binary and unary operators, allowing fine-grained control over arithmetic behavior. This is useful for limiting resource consumption or enforcing custom semantics.

- `intercepted_binops` — a frozenset of operators (`//`, `%`, `+`, `*`, `-`, `/`, `**`) to intercept.
- `intercepted_unops` — a frozenset of operators (`+`, `-`) to intercept.
- `binop_table` / `unop_table` — per-instance copies of the default operator callback tables.

When an operator is intercepted, the compiler generates a call to `call_binop` / `call_unop` instead of the native operator. Intercepted calls are always slower, so only intercept operators you actually need to control.

```mermaid
flowchart LR
    A["Template: a + b"] --> B{"'+' in intercepted_binops?"}
    B -->|Yes| C["call_binop(context, '+', a, b)"]
    B -->|No| D["native operator.add(a, b)"]
    C --> E["binop_table['+'](a, b)"]
```

---

## Usage Examples

### Basic Sandboxed Environment

```python
from jinja2.sandbox import SandboxedEnvironment

env = SandboxedEnvironment()
template = env.from_string("{{ obj.__class__ }}")
# Rendering raises SecurityError because __class__ is unsafe.
```

### Immutable Sandboxed Environment

```python
from jinja2.sandbox import ImmutableSandboxedEnvironment

env = ImmutableSandboxedEnvironment()
template = env.from_string("{{ mylist.append(1) }}")
# Rendering raises SecurityError because append() mutates the list.
```

### Marking a Callable as Unsafe

```python
from jinja2.sandbox import unsafe

@unsafe
def delete_everything():
    ...

# Passing delete_everything into a template and calling it raises SecurityError.
```

### Customizing the Policy

```python
from jinja2.sandbox import SandboxedEnvironment

class MySandbox(SandboxedEnvironment):
    def is_safe_attribute(self, obj, attr, value):
        # Allow a specific "safe" underscore attribute.
        if attr == "_public_api":
            return True
        return super().is_safe_attribute(obj, attr, value)
```

---

## Integration with the Broader System

The sandbox integrates with several other Jinja2 modules:

- **[Runtime Execution & API](runtime_execution_and_api.md)** — `SandboxedEnvironment` subclasses `Environment` and relies on `Context`, `Undefined`, and `SecurityError`. The `sandboxed = True` flag on the environment instructs the compiler to generate sandboxed code.
- **[Compilation & Codegen](compilation_and_codegen.md)** — The compiler reads `environment.sandboxed` and the `intercepted_binops` / `intercepted_unops` sets to decide whether to emit calls to `call_binop` / `call_unop` and to route attribute/item access through the sandbox methods.
- **[Extension & Customization](extension_and_customization.md)** — The sandbox is part of the customization layer, alongside extensions and filters. It can be combined with extensions (e.g. `DebugExtension`) but note that some extensions may expose additional surface area.

```mermaid
graph LR
    COMP["Compiler<br/>(compilation_and_codegen)"] -->|reads sandboxed flag| SE["SandboxedEnvironment"]
    SE -->|subclasses| ENV["Environment<br/>(runtime_execution_and_api)"]
    SE -->|raises| SEC["SecurityError"]
    SE -->|returns| UND["Undefined"]
    SE -->|uses| CTX["Context"]
    EXT["Extensions<br/>(extension_and_customization)"] -.->|may extend| SE
```

---

## Security Considerations

1. **Not a complete sandbox.** The sandbox restricts template-level operations but does not isolate the Python process. Untrusted templates should still be rendered in a restricted environment (e.g. a subprocess or container).
2. **Catch all exceptions.** Rendering a sandboxed template can raise `SecurityError` as well as other exceptions. Callers must catch them.
3. **`str.format` is a known bypass vector.** The sandbox explicitly routes `format`/`format_map` through `SandboxedFormatter` to prevent bypassing attribute checks.
4. **Mutable containers.** Use `ImmutableSandboxedEnvironment` if templates should not be able to mutate lists, dicts, sets, or deques.
5. **Resource limits.** `safe_range` limits range sizes, but other resource-exhaustion vectors (e.g. large string concatenation) are not addressed by the sandbox.
6. **Custom policy overrides.** When overriding `is_safe_attribute` or `is_safe_callable`, always call `super()` to preserve the default protections unless you have a specific reason not to.
