# Runtime Execution and API

## Purpose

The `runtime_execution_and_api` module is the execution core of Jinja2. It bridges the gap between compiled template code (produced by the compilation and codegen stage) and the user-facing API. Its responsibilities include:

- **Environment management** (`environment.py`): Provides the central `Environment` class that holds configuration, filters, tests, globals, and policies. It orchestrates template loading, compilation, and rendering, and exposes the primary public API (`from_string`, `get_template`, `render`, etc.).
- **Runtime execution** (`runtime.py`): Supplies the runtime context objects (`Context`, `TemplateReference`, `Macro`, `BlockReference`, `LoopContext`, `Undefined`, etc.) that compiled template code interacts with during rendering. It handles variable resolution, scoping, output buffering, and the semantics of undefined values.
- **Error handling** (`exceptions.py`): Defines the exception hierarchy (`TemplateError`, `TemplateNotFound`, `TemplateSyntaxError`, `UndefinedError`, `SecurityError`, etc.) used throughout parsing, compilation, and execution to report failures with template-aware context (line numbers, names).

Together these components form the layer that actually *runs* a template once it has been parsed and compiled, and that users interact with directly through the public API.

## Architecture

The module sits at the boundary between the compiled template artifacts and the end user. The `Environment` acts as the orchestrator, delegating to the runtime context during rendering and raising exceptions on failure.

```mermaid
graph TD
    User["User Code"] -->|"get_template / from_string / render"| Env["Environment<br/>(environment.py)"]
    Env -->|"loads & compiles"| Compiled["Compiled Template Code"]
    Env -->|"creates"| Ctx["Context<br/>(runtime.py)"]
    Compiled -->|"executes against"| Ctx
    Ctx -->|"resolves variables via"| Resolve["resolve / resolve_or_missing"]
    Ctx -->|"produces"| Output["Rendered Output"]
    Ctx -->|"uses"| Undef["Undefined / ChainableUndefined<br/>(runtime.py)"]
    Ctx -->|"uses"| Helpers["Macro, BlockReference,<br/>LoopContext, TemplateReference<br/>(runtime.py)"]
    Env -.->|"raises"| Exc["Exceptions<br/>(exceptions.py)"]
    Ctx -.->|"raises"| Exc
    Compiled -.->|"raises"| Exc
```

### Component relationships

```mermaid
graph LR
    subgraph "runtime_execution_and_api"
        Env["Environment"]
        Ctx["Context"]
        Exc["Exceptions"]
    end
    Env -->|"instantiates"| Ctx
    Env -->|"configures"| Ctx
    Ctx -->|"raises"| Exc
    Env -->|"raises"| Exc
    Env -->|"delegates rendering to"| Ctx
```

### Execution flow

```mermaid
sequenceDiagram
    participant U as User
    participant E as Environment
    participant T as Compiled Template
    participant C as Context
    participant X as Exceptions

    U->>E: get_template(name) / from_string(src)
    E->>E: load & compile (via loaders/compiler)
    U->>E: template.render(**vars)
    E->>C: new_context(vars, shared, locals)
    E->>T: root_render_func(context)
    T->>C: resolve(name) / getattr / call
    C-->>T: value or Undefined
    alt error during execution
        C->>X: raise UndefinedError / TemplateError
        X-->>U: propagate with context
    end
    T-->>E: output chunks
    E-->>U: concatenated string
```

## Core Components

The module is composed of three tightly coupled files, each documented separately:

- **[Environment](/workspace/repo/docs/codewiki/environment.md)** (`environment.py`) — The central configuration and orchestration object. Owns filters, tests, globals, policies (undefined behavior, autoescape, trimming), and the template loading/compilation pipeline. Exposes the public API used by applications.

- **[Runtime](/workspace/repo/docs/codewiki/runtime.md)** (`runtime.py`) — The execution-time context and helper objects. Includes `Context` (variable resolution and scoping), `Undefined` variants, `Macro`, `BlockReference`, `LoopContext`, `TemplateReference`, and output-buffer utilities used by generated code.

- **[Exceptions](/workspace/repo/docs/codewiki/exceptions.md)** (`exceptions.py`) — The exception hierarchy for template errors, including syntax errors, undefined-variable errors, and security errors, with support for attaching template source context.