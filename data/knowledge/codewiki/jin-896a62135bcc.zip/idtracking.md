# ID Tracking Module

## Introduction

The `idtracking` module (`src/jinja2/idtracking.py`) is a compile-time analysis component of Jinja2's template compilation pipeline. Its primary responsibility is **symbol resolution and scope tracking**: it determines, for every name referenced in a template's abstract syntax tree (AST), whether that name refers to a local variable, a parameter, an alias to an outer-scope variable, or an undefined value that must be resolved at runtime.

This analysis is a prerequisite for code generation. The [compiler](compiler.md) relies on the symbol information produced here to emit correct Python code that handles variable scoping, closures, loop variables, block variables, and undefined-name resolution.

The module exposes three core components:

| Component | Role |
|-----------|------|
| `Symbols` | Data structure holding the symbol table for a single scope (frame) |
| `RootVisitor` | AST visitor that walks scope-introducing nodes and delegates to the frame visitor |
| `FrameSymbolVisitor` | AST visitor that records loads, stores, and parameter declarations into a `Symbols` instance |

Two module-level helper functions, `find_symbols` and `symbols_for_node`, provide convenient entry points.

---

## Architecture Overview

The module sits between the [template parsing frontend](template_parsing_frontend.md) (which produces the AST) and the [compilation and codegen](compilation_and_codegen.md) stage (which consumes the symbol information).

```mermaid
graph TD
    subgraph "Parsing Frontend"
        Parser["Parser"]
        Nodes["nodes (AST)"]
    end

    subgraph "ID Tracking (this module)"
        find_symbols["find_symbols()"]
        symbols_for_node["symbols_for_node()"]
        Symbols["Symbols"]
        RootVisitor["RootVisitor"]
        FrameSymbolVisitor["FrameSymbolVisitor"]
    end

    subgraph "Compilation & Codegen"
        CodeGenerator["CodeGenerator"]
        Frame["Frame"]
    end

    Parser --> Nodes
    Nodes --> find_symbols
    Nodes --> symbols_for_node
    find_symbols --> Symbols
    symbols_for_node --> Symbols
    Symbols --> RootVisitor
    RootVisitor --> FrameSymbolVisitor
    FrameSymbolVisitor --> Symbols
    Symbols --> Frame
    Frame --> CodeGenerator
```

### Relationship to `Frame`

The `Symbols` class is tightly coupled with the `Frame` class in the [compiler](compiler.md). Each `Frame` owns a `Symbols` instance representing its lexical scope. When the compiler enters a new scope (a macro, loop, block, `with`, or `scope` tag), it creates an inner `Frame`, which in turn creates a child `Symbols` linked via the `parent` pointer. This parent chain forms the lexical scope hierarchy.

```mermaid
graph LR
    RootFrame["Frame (root)"] --> RootSymbols["Symbols (level 0)"]
    MacroFrame["Frame (macro)"] --> MacroSymbols["Symbols (level 1)"]
    LoopFrame["Frame (loop)"] --> LoopSymbols["Symbols (level 2)"]
    MacroSymbols -->|parent| RootSymbols
    LoopSymbols -->|parent| MacroSymbols
```

---

## Core Components

### `Symbols`

`Symbols` is the central data structure. It represents the symbol table for one lexical scope and tracks three categories of information:

- **`refs`** (`Dict[str, str]`): Maps a template-level name (e.g. `foo`) to a generated Python identifier (e.g. `l_1_foo`). The identifier encodes the scope level to guarantee uniqueness across nested scopes.
- **`loads`** (`Dict[str, Any]`): Maps a generated identifier to a *load instruction* — a tuple `(instruction, parameter)` describing how the variable should be initialized when the frame is entered.
- **`stores`** (`Set[str]`): The set of names assigned within this scope.

#### Load Instructions

The module defines four load instruction constants that drive code generation in `CodeGenerator.enter_frame`:

| Constant | Value | Meaning | Generated code |
|----------|-------|---------|----------------|
| `VAR_LOAD_PARAMETER` | `"param"` | Name is a function parameter | (no initialization; always defined) |
| `VAR_LOAD_RESOLVE` | `"resolve"` | Name must be resolved from the context | `target = resolve('name')` |
| `VAR_LOAD_ALIAS` | `"alias"` | Name aliases an outer-scope variable | `target = outer_target` |
| `VAR_LOAD_UNDEFINED` | `"undefined"` | Name is undefined | `target = missing` |

#### Key Methods

| Method | Purpose |
|--------|---------|
| `analyze_node(node, **kwargs)` | Runs a `RootVisitor` over a node to populate this symbol table |
| `_define_ref(name, load)` | Creates the generated identifier `l_{level}_{name}` and records the load instruction |
| `find_load(target)` | Looks up a load instruction, walking up the parent chain |
| `find_ref(name)` | Resolves a name to its generated identifier, walking up the parent chain |
| `ref(name)` | Like `find_ref` but raises `AssertionError` if unresolved |
| `copy()` | Shallow-copies the symbol table (used for branch analysis) |
| `store(name)` | Records an assignment; determines alias/undefined load if not yet referenced |
| `declare_parameter(name)` | Records a parameter declaration |
| `load(name)` | Records a name load; creates a `resolve` instruction if unknown |
| `branch_update(branches)` | Merges symbol tables from conditional branches |
| `dump_stores()` | Returns all stored names across the scope chain mapped to their refs |
| `dump_param_targets()` | Returns the set of parameter targets across the scope chain |

#### Scope Resolution

Name resolution walks the parent chain. When a name is stored but not yet referenced, `store()` checks whether an outer scope already defines it — if so, it creates an **alias** load; otherwise it creates an **undefined** load.

```mermaid
flowchart TD
    Start["store(name)"] --> AddStore["add name to stores"]
    AddStore --> CheckRef{"name in refs?"}
    CheckRef -->|yes| Done["done"]
    CheckRef -->|no| HasParent{"has parent?"}
    HasParent -->|yes| FindOuter{"parent.find_ref(name)?"}
    FindOuter -->|found| Alias["_define_ref(name, ALIAS, outer_ref)"]
    FindOuter -->|not found| Undef["_define_ref(name, UNDEFINED, None)"]
    HasParent -->|no| Undef
```

#### Branch Merging

Conditional constructs (`{% if %}`, `{% for %}` with `else`) require merging symbol tables from multiple branches. `branch_update()` handles this:

1. It counts how many branches store each name.
2. It merges all branch `refs`, `loads`, and `stores` into the current scope.
3. For names stored in *some but not all* branches, it reclassifies the load instruction:
   - If an outer scope defines the name → **alias** to the outer variable.
   - Otherwise → **resolve** from the context at runtime.

This ensures that a variable assigned only inside an `if` branch is correctly resolved when the branch is not taken.

```mermaid
flowchart TD
    BU["branch_update(branches)"] --> Count["count stores per name across branches"]
    Count --> Merge["merge refs/loads/stores from all branches"]
    Merge --> Loop{"for each name stored in<br/>some but not all branches"}
    Loop --> Outer{"parent defines name?"}
    Outer -->|yes| SetAlias["loads[target] = (ALIAS, outer_target)"]
    Outer -->|no| SetResolve["loads[target] = (RESOLVE, name)"]
    SetAlias --> Loop
    SetResolve --> Loop
```

### `RootVisitor`

`RootVisitor` is a `NodeVisitor` (from the [visitor module](template_parsing_frontend.md)) that handles the *structural* traversal of scope-introducing nodes. It decides which child nodes belong to the current scope and which introduce new scopes.

It delegates the actual symbol recording to a `FrameSymbolVisitor` instance.

| Node type | Handling |
|-----------|----------|
| `Template`, `Block`, `Macro`, `FilterBlock`, `Scope`, `If`, `ScopedEvalContextModifier` | `_simple_visit` — visit all child nodes |
| `AssignBlock` | Visit only the body |
| `CallBlock` | Visit all children except the `call` field |
| `OverlayScope` | Visit only the body |
| `For` | Branch-aware: visits `target` as a parameter for `body`/`test` branches, then the appropriate branch body |
| `With` | Visit targets, then body |
| (any other) | `generic_visit` raises `NotImplementedError` |

The `For` handling is notable: it accepts a `for_branch` keyword (`"body"`, `"else"`, or `"test"`) so the compiler can analyze each branch of a loop independently.

### `FrameSymbolVisitor`

`FrameSymbolVisitor` is the workhorse that records symbol operations. It is described in the source as "a visitor for `Frame.inspect`."

| Node type | Symbol operation |
|-----------|------------------|
| `Name` | `declare_parameter` (if `store_as_param` or `ctx == "param"`), `store` (if `ctx == "store"`), or `load` (if `ctx == "load"`) |
| `NSRef` | `load` |
| `If` | Visits test, then analyzes each branch (`body`, `elif_`, `else_`) on a *copy* of the symbols, then calls `branch_update` |
| `Macro` | `store` the macro name |
| `Import` | Visit children, then `store` the target |
| `FromImport` | Visit children, then `store` each imported name (handling aliases) |
| `Assign` | Visit the value *before* the target (correct evaluation order) |
| `For` | Visit only the iterable — the loop body is a separate scope |
| `CallBlock` | Visit only the call |
| `FilterBlock` | Visit only the filter |
| `With` | Visit the values |
| `AssignBlock` | Visit only the target |
| `Scope`, `Block`, `OverlayScope` | Stop visiting (scope boundaries) |

The `If` handling is the most complex, as it demonstrates the branch-copy-and-merge pattern:

```mermaid
sequenceDiagram
    participant FSV as FrameSymbolVisitor
    participant Orig as original Symbols
    participant Copy as branch copy
    participant Sym as Symbols

    FSV->>FSV: visit(node.test)
    FSV->>Orig: save reference
    loop for each branch (body, elif, else)
        FSV->>Copy: original_symbols.copy()
        FSV->>Copy: visit branch nodes
        FSV->>Orig: restore reference
    end
    FSV->>Sym: branch_update([body, elif, else])
```

---

## Data Flow

The following diagram shows how symbol information flows from the AST through the tracking module into generated code.

```mermaid
flowchart LR
    AST["AST Node"] -->|analyze_node| RV["RootVisitor"]
    RV -->|delegates| FSV["FrameSymbolVisitor"]
    FSV -->|store/load/declare_parameter| Sym["Symbols"]
    Sym -->|refs, loads, stores| Frame["Frame.symbols"]
    Frame -->|enter_frame| CG["CodeGenerator"]
    CG -->|emits| PyCode["Python source:<br/>l_1_foo = resolve('foo')"]
```

### Entry Points

Two module-level functions provide the public API:

- **`find_symbols(nodes, parent_symbols=None)`** — Creates a `Symbols` instance and runs a `FrameSymbolVisitor` over an iterable of nodes. Used when the caller already has a flat list of nodes to analyze.
- **`symbols_for_node(node, parent_symbols=None)`** — Creates a `Symbols` instance and calls `analyze_node`, which uses the `RootVisitor` for structural traversal. Used when analyzing a single scope-introducing node.

---

## Integration with the Compiler

The [compiler](compiler.md) uses this module extensively. Key integration points:

1. **Frame creation**: `Frame.__init__` creates a `Symbols` instance, chaining to the parent frame's symbols.
2. **Scope analysis**: `CodeGenerator` calls `frame.symbols.analyze_node(node)` when entering macros, loops, blocks, `with`, and `scope` constructs.
3. **Frame entry**: `CodeGenerator.enter_frame` iterates over `frame.symbols.loads` and emits initialization code based on the load instruction.
4. **Name resolution**: `CodeGenerator.visit_Name` calls `frame.symbols.ref(name)` and `frame.symbols.find_load(ref)` to emit either a direct reference or an undefined-check expression.
5. **Context dumping**: `CodeGenerator.dump_local_context` uses `frame.symbols.dump_stores()` to build the local context dictionary passed to derived contexts.
6. **Parameter tracking**: `CodeGenerator.push_parameter_definitions` uses `frame.symbols.dump_param_targets()` to track which parameters are still unassigned.

```mermaid
graph TD
    subgraph "CodeGenerator"
        enter_frame["enter_frame()"]
        visit_Name["visit_Name()"]
        dump_local_context["dump_local_context()"]
        push_param["push_parameter_definitions()"]
    end

    subgraph "Symbols"
        loads["loads"]
        refs["refs"]
        dump_stores["dump_stores()"]
        dump_param["dump_param_targets()"]
    end

    enter_frame --> loads
    visit_Name --> refs
    visit_Name --> loads
    dump_local_context --> dump_stores
    push_param --> dump_param
```

---

## Process Flow: Analyzing a Template

The complete flow for analyzing a template's symbols:

```mermaid
flowchart TD
    Start["Template AST"] --> CreateSym["Create root Symbols (level 0)"]
    CreateSym --> RootVisit["RootVisitor.visit(Template)"]
    RootVisit --> SimpleVisit["_simple_visit: iterate children"]
    SimpleVisit --> FrameVisit["FrameSymbolVisitor.visit(child)"]

    FrameVisit --> NodeType{"Node type?"}
    NodeType -->|Name| NameCtx{"ctx?"}
    NameCtx -->|store| Store["symbols.store(name)"]
    NameCtx -->|load| Load["symbols.load(name)"]
    NameCtx -->|param| Param["symbols.declare_parameter(name)"]

    NodeType -->|If| IfBranch["analyze branches on copies,<br/>then branch_update"]
    NodeType -->|Macro/Import| StoreName["symbols.store(name)"]
    NodeType -->|For| IterOnly["visit iterable only"]

    Store --> Done["Symbols populated"]
    Load --> Done
    Param --> Done
    IfBranch --> Done
    StoreName --> Done
    IterOnly --> Done
```

---

## Related Modules

- **[template_parsing_frontend](template_parsing_frontend.md)** — Produces the AST (`nodes`) and provides the `NodeVisitor` base class used by both visitors in this module.
- **[compilation_and_codegen](compilation_and_codegen.md)** — The primary consumer of this module; `CodeGenerator` and `Frame` use `Symbols` to emit correct scoping code.
- **[runtime_execution_and_api](runtime_execution_and_api.md)** — Provides the `Context`, `resolve_or_missing`, and `Undefined` machinery that the generated load instructions target.
