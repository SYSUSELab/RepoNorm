# Filters Module

## Introduction

The `filters` module (`src/jinja2/filters.py`) implements Jinja's built-in **template filters** — the functions invoked with the `|` operator inside templates (e.g. `{{ name|upper }}`). Filters transform a value into another value, and this module provides the complete standard library of filters that ship with Jinja, ranging from simple string manipulation (`upper`, `lower`, `trim`) to collection processing (`sort`, `groupby`, `map`, `select`), serialization (`tojson`), and HTML/URL handling (`escape`, `urlize`, `xmlattr`).

The module is a **leaf consumer** in the runtime layer: it depends on the environment, runtime context, utilities, and async helpers, but is itself consumed by the [`Environment`](environment.md) (which registers the `FILTERS` dictionary as its default filter set) and by the [`compiler`](compiler.md) (which emits calls to filters during code generation).

---

## Architecture Overview

The filters module sits at the boundary between the template author's syntax and the Python runtime. Filters are registered into an `Environment` and dispatched at render time through `Environment.call_filter`.

```mermaid
graph TD
    subgraph "Template Author"
        TPL["{{ value|filter(args) }}"]
    end

    subgraph "Parsing & Compilation"
        PARSER["Parser<br/>(parser.py)"]
        NODES["nodes.Filter<br/>(nodes.py)"]
        COMPILER["CodeGenerator<br/>(compiler.py)"]
    end

    subgraph "Runtime Execution"
        ENV["Environment<br/>(environment.py)"]
        CTX["Context<br/>(runtime.py)"]
        FILTERS["filters.py<br/>FILTERS registry"]
    end

    subgraph "Support"
        UTILS["utils.py<br/>pass_* decorators"]
        ASYNC["async_utils.py<br/>async_variant"]
        EXC["exceptions.py<br/>FilterArgumentError"]
    end

    TPL --> PARSER --> NODES --> COMPILER
    COMPILER -->|"call_filter(name, ...)"| ENV
    ENV -->|"lookup in env.filters"| FILTERS
    ENV --> CTX
    FILTERS --> UTILS
    FILTERS --> ASYNC
    FILTERS --> EXC
```

---

## Core Components

### `HasHTML` (Protocol)

A `typing.Protocol` (only defined under `TYPE_CHECKING`) describing objects that expose an `__html__()` method returning a string. This is the structural type used by filters such as `do_forceescape` and `do_striptags` to detect objects that already carry an HTML-safe representation (e.g. `markupsafe.Markup`).

```python
class HasHTML(te.Protocol):
    def __html__(self) -> str:
        pass
```

Filters that accept `t.Union[str, HasHTML]` use `hasattr(value, "__html__")` at runtime to decide whether to unwrap the HTML representation before processing.

### `_GroupTuple` (NamedTuple)

A `NamedTuple` subclass returned by the `groupby` filter. It carries two fields:

| Field | Type | Description |
|-------|------|-------------|
| `grouper` | `t.Any` | The attribute value shared by the group |
| `list` | `t.List` | The items belonging to that group |

```python
class _GroupTuple(t.NamedTuple):
    grouper: t.Any
    list: t.List

    def __repr__(self) -> str:
        return tuple.__repr__(self)

    def __str__(self) -> str:
        return tuple.__str__(self)
```

The custom `__repr__` and `__str__` deliberately delegate to the plain `tuple` implementation so that the subclass is **hidden** when users print or debug the value — the output looks like an ordinary `(grouper, list)` tuple. This preserves backward compatibility with the tuple-unpacking usage documented for `groupby`:

```jinja
{% for city, items in users|groupby("city") %}
```

---

## Filter Categories

The `FILTERS` dictionary at the bottom of the module maps filter names to their implementations. Filters fall into several functional categories:

```mermaid
graph LR
    subgraph "String Filters"
        S1[upper / lower]
        S2[capitalize / title]
        S3[trim / center / indent]
        S4[truncate / wordwrap / wordcount]
        S5[replace / format]
    end

    subgraph "Collection Filters"
        C1[sort / dictsort / unique]
        C2[groupby / batch / slice]
        C3[map / select / reject]
        C4[selectattr / rejectattr]
        C5[first / last / random]
        C6[min / max / sum / list]
    end

    subgraph "HTML / URL Filters"
        H1[escape / forceescape / safe]
        H2[striptags / xmlattr]
        H3[urlize / urlencode]
        H4[tojson]
    end

    subgraph "Type / Conversion"
        T1[int / float / string]
        T2[attr / items / default]
        T3[pprint / filesizeformat]
        T4[round / abs / reverse]
    end
```

### Attribute Access Helpers

Several collection filters share a common attribute-lookup mechanism built on three helper functions:

- **`make_attrgetter(environment, attribute, postprocess, default)`** — returns a callable that resolves a dotted attribute path (e.g. `"address.city"`) using `Environment.getitem`, applying an optional `postprocess` (such as `ignore_case`) and substituting a `default` when the result is `Undefined`.
- **`make_multi_attrgetter(environment, attribute, postprocess)`** — the multi-attribute variant used by `sort`, supporting comma-separated paths like `"age,name"`.
- **`_prepare_attribute_parts(attr)`** — splits a dotted string into parts, converting numeric segments to integers.

These helpers are the backbone of `sort`, `unique`, `min`, `max`, `groupby`, `map`, `selectattr`, and `rejectattr`.

---

## Data Flow: Filter Invocation

The following sequence diagram shows how a filter call flows from a template expression to the filter implementation, including the `pass_*` decorator injection mechanism.

```mermaid
sequenceDiagram
    participant T as Template
    participant C as Compiled Code
    participant E as Environment
    participant F as Filter Function
    participant U as utils (pass_*)

    T->>C: {{ value|sort(attribute="age") }}
    C->>E: call_filter("sort", value, args, kwargs, context)
    E->>E: _filter_test_common(...)
    E->>E: func = env.filters["sort"]
    E->>U: _PassArg.from_obj(func)
    U-->>E: _PassArg.environment
    E->>F: do_sort(environment, value, ...)
    F-->>E: sorted list
    E-->>C: result
    C-->>T: rendered output
```

### The `pass_*` Decorator Mechanism

Filters that need access to runtime state are decorated with one of three decorators from [`utils`](utils.md), which set a `jinja_pass_arg` attribute on the function:

| Decorator | Injected First Argument | Example Filters |
|-----------|------------------------|-----------------|
| `@pass_context` | `Context` | `do_random`, `do_map`, `do_select`, `do_reject`, `do_selectattr`, `do_rejectattr` |
| `@pass_environment` | `Environment` | `do_sort`, `do_unique`, `do_min`, `do_max`, `do_groupby`, `do_sum`, `do_attr`, `do_truncate`, `do_wordwrap` |
| `@pass_eval_context` | `EvalContext` | `do_replace`, `do_xmlattr`, `do_join`, `do_urlize`, `do_tojson` |

At call time, `Environment._filter_test_common` inspects the function via `_PassArg.from_obj(func)` and prepends the appropriate object to the argument list. This is why the filter implementations declare these objects as their first parameter even though template authors never pass them.

---

## Async Support

Many filters have both a synchronous and an asynchronous implementation. The async variants are produced by the `@async_variant(sync_func)` decorator from [`async_utils`](async_utils.md), which creates a wrapper that dispatches to the async implementation when the environment is in async mode (`env.is_async`) and to the sync implementation otherwise.

```mermaid
graph TD
    WRAPPER["async_variant wrapper"]
    WRAPPER -->|"is_async(args)?"| CHECK{env.is_async}
    CHECK -->|True| ASYNC["async implementation<br/>(e.g. do_join)"]
    CHECK -->|False| SYNC["sync implementation<br/>(e.g. sync_do_join)"]
    ASYNC --> HELPERS["auto_aiter / auto_await / auto_to_list"]
```

Filters with async variants include: `join`, `first`, `slice`, `groupby`, `sum`, `list`, `map`, `select`, `reject`, `selectattr`, `rejectattr`.

The async implementations rely on three helpers from `async_utils`:

- **`auto_aiter(iterable)`** — yields items from either a sync or async iterable.
- **`auto_await(value)`** — awaits a value only if it is awaitable.
- **`auto_to_list(value)`** — materializes a sync or async iterable into a list.

> **Note:** `do_last` intentionally has **no** async variant, because reversing an async iterable is not safe in async mode.

---

## Key Filter Implementations

### HTML Safety Filters

- **`do_forceescape`** — enforces HTML escaping, unwrapping `__html__` first. May double-escape already-safe values.
- **`do_mark_safe`** (`safe`) — wraps a value in `Markup` so it is not escaped.
- **`do_mark_unsafe`** — the reverse of `safe`, coercing to a plain `str`.
- **`do_striptags`** — strips SGML/XML tags via `Markup.striptags()`.
- **`do_xmlattr`** — builds an SGML/XML attribute string from a mapping, escaping keys and values and skipping `None`/`Undefined` values.

### Serialization

- **`do_tojson`** — serializes a value to HTML-safe JSON using `htmlsafe_json_dumps` from [`utils`](utils.md), honoring the `json.dumps_function` and `json.dumps_kwargs` policies. Marks the result as `Markup` when autoescaping is enabled.

### Collection Processing

- **`do_groupby`** — groups a sequence by an attribute, sorting first so each unique value yields exactly one group. Returns a list of `_GroupTuple` instances.
- **`do_sort`** — stable sort supporting reverse, case-sensitivity, and single or comma-separated attribute paths.
- **`do_map`** — applies either an attribute lookup or a named filter to each item, via `prepare_map`.
- **`do_select` / `do_reject` / `do_selectattr` / `do_rejectattr`** — filter sequences by applying a test, sharing the `select_or_reject` / `prepare_select_or_reject` machinery.

### Conversion

- **`do_int`** — converts to `int`, with a fallback that parses floats (so `"42.23"|int` yields `42`).
- **`do_float`** — converts to `float` with a default fallback.
- **`do_default`** — returns a default when the value is `Undefined` (or falsy when `boolean=True`).

---

## Dependencies

```mermaid
graph TD
    FILTERS["filters.py"]

    FILTERS -->|"escape, Markup, soft_str"| MARKUPSAFE["markupsafe"]
    FILTERS -->|"FilterArgumentError"| EXC["exceptions.py"]
    FILTERS -->|"Undefined"| RUNTIME["runtime.py"]
    FILTERS -->|"htmlsafe_json_dumps, pass_*, pformat, url_quote, urlize"| UTILS["utils.py"]
    FILTERS -->|"async_variant, auto_aiter, auto_await, auto_to_list"| ASYNC["async_utils.py"]
    FILTERS -.->|"TYPE_CHECKING only"| ENV["environment.py"]
    FILTERS -.->|"TYPE_CHECKING only"| NODES["nodes.py"]
    FILTERS -.->|"TYPE_CHECKING only"| SANDBOX["sandbox.py"]

    ENV -->|"registers FILTERS as defaults"| FILTERS
    COMPILER["compiler.py"] -->|"emits call_filter"| ENV
```

### Runtime Dependencies

| Dependency | Used For |
|------------|----------|
| [`markupsafe`](https://markupsafe.palletsprojects.com/) | `escape`, `Markup`, `soft_str` for HTML-safe output |
| [`exceptions.FilterArgumentError`](exceptions.md) | Raised on invalid filter arguments |
| [`runtime.Undefined`](runtime.md) | Detecting undefined values in `default`, `items`, `xmlattr`, etc. |
| [`utils`](utils.md) | `pass_context`/`pass_environment`/`pass_eval_context`, `htmlsafe_json_dumps`, `pformat`, `url_quote`, `urlize` |
| [`async_utils`](async_utils.md) | `async_variant`, `auto_aiter`, `auto_await`, `auto_to_list` |

### Type-Checking-Only Dependencies

`Environment`, `EvalContext`, `Context`, and `SandboxedEnvironment` are imported only under `if t.TYPE_CHECKING` to avoid circular imports at runtime. The `do_attr` filter interacts with `SandboxedEnvironment` at runtime through `environment.sandboxed` and `is_safe_attribute`/`unsafe_undefined` (see [`sandbox`](sandbox.md)).

---

## Integration Points

### With the Environment

The [`Environment`](environment.md) copies `FILTERS` into `self.filters` during initialization (`DEFAULT_FILTERS.copy()`). Filters are then dispatched through `Environment.call_filter`, which resolves the name, injects the appropriate `pass_*` argument, and invokes the function. The `map`, `select`, and `reject` filters call back into the environment via `call_filter` and `call_test`.

### With the Compiler

The [`compiler`](compiler.md) emits calls to `Environment.call_filter` for `nodes.Filter` nodes. The `map`/`select` family relies on `Environment.call_test` to resolve tests by name at runtime.

### With the Sandbox

The `do_attr` filter checks `environment.sandboxed` and delegates to `SandboxedEnvironment.is_safe_attribute` / `unsafe_undefined` when running in a sandboxed environment (see [`sandbox`](sandbox.md)).

---

## The `FILTERS` Registry

The module exposes a single public registry, `FILTERS`, a `dict[str, Callable]` mapping template-visible names to implementations. Notable aliases:

| Name | Implementation |
|------|----------------|
| `abs` | built-in `abs` |
| `count` / `length` | built-in `len` |
| `d` / `default` | `do_default` |
| `e` / `escape` | `markupsafe.escape` |
| `safe` | `do_mark_safe` |
| `string` | `markupsafe.soft_str` |

This registry is the canonical list of filters available to every template unless overridden or extended by an application.

---

## Related Documentation

- [environment.md](environment.md) — `Environment`, filter registration, and `call_filter` dispatch
- [runtime.md](runtime.md) — `Context` and `Undefined`
- [utils.md](utils.md) — `pass_*` decorators and shared helpers
- [async_utils.md](async_utils.md) — async variant machinery
- [exceptions.md](exceptions.md) — `FilterArgumentError` and related errors
- [compiler.md](compiler.md) — code generation for filter calls
- [sandbox.md](sandbox.md) — sandboxed attribute access used by `do_attr`
