# Exceptions Module

## Introduction

The `jinja2.exceptions` module defines the complete exception hierarchy used throughout the Jinja template engine. It provides a single, well-structured set of error types that are raised during every phase of template processing: **lexing**, **parsing**, **compilation**, **loading**, and **runtime execution**.

The module's central design principle is a single root exception, `TemplateError`, from which all other Jinja-specific errors derive. This allows applications to catch *any* template-related failure with one `except TemplateError` clause, while still permitting fine-grained handling of specific error categories (syntax errors, missing templates, undefined values, sandbox violations, etc.).

The exceptions defined here are consumed by nearly every other module in the engine:

- The [lexer](lexer.md) and [parser](parser.md) raise `TemplateSyntaxError` (and its subclass `TemplateAssertionError`) for malformed templates.
- The [loaders](loaders.md) and [environment](environment.md) raise `TemplateNotFound` / `TemplatesNotFound` when a template cannot be located.
- The [runtime](runtime.md) `Undefined` types raise `UndefinedError` when undefined values are used.
- The [sandbox](sandbox.md) environment raises `SecurityError` when unsafe operations are attempted.
- The [environment](environment.md) raises `TemplateRuntimeError` and `FilterArgumentError` for filter/test invocation problems.

## Exception Hierarchy

All exceptions in this module ultimately derive from Python's built-in `Exception` via the `TemplateError` base class. Several exceptions also inherit from standard Python exceptions (`IOError`, `LookupError`) to integrate naturally with Python's error-handling conventions.

```mermaid
classDiagram
    class Exception {
        <<builtin>>
    }
    class IOError {
        <<builtin>>
    }
    class LookupError {
        <<builtin>>
    }
    class TemplateError {
        +message: Optional[str]
    }
    class TemplateNotFound {
        +name
        +templates
        +message
    }
    class TemplatesNotFound {
        +templates
    }
    class TemplateSyntaxError {
        +lineno
        +name
        +filename
        +source
        +translated
    }
    class TemplateAssertionError
    class TemplateRuntimeError
    class UndefinedError
    class SecurityError
    class FilterArgumentError

    Exception <|-- TemplateError
    IOError <|-- TemplateNotFound
    LookupError <|-- TemplateNotFound
    TemplateError <|-- TemplateNotFound
    TemplateNotFound <|-- TemplatesNotFound
    TemplateError <|-- TemplateSyntaxError
    TemplateSyntaxError <|-- TemplateAssertionError
    TemplateError <|-- TemplateRuntimeError
    TemplateRuntimeError <|-- UndefinedError
    TemplateRuntimeError <|-- SecurityError
    TemplateRuntimeError <|-- FilterArgumentError
```

### Hierarchy Summary

| Exception | Parent(s) | Category | Raised When |
|-----------|-----------|----------|-------------|
| `TemplateError` | `Exception` | Base | Base class for all template errors |
| `TemplateNotFound` | `IOError`, `LookupError`, `TemplateError` | Loading | A single template cannot be found |
| `TemplatesNotFound` | `TemplateNotFound` | Loading | None of several candidate templates can be found |
| `TemplateSyntaxError` | `TemplateError` | Compile-time | The template source is malformed |
| `TemplateAssertionError` | `TemplateSyntaxError` | Compile-time | A non-syntax compile-time assertion fails |
| `TemplateRuntimeError` | `TemplateError` | Runtime | A generic runtime error occurs |
| `UndefinedError` | `TemplateRuntimeError` | Runtime | An `Undefined` value is operated on |
| `SecurityError` | `TemplateRuntimeError` | Runtime | The sandbox blocks an unsafe operation |
| `FilterArgumentError` | `TemplateRuntimeError` | Runtime | A filter is called with invalid arguments |

## Component Details

### `TemplateError`

The base class for all template errors. It provides a uniform `message` property that safely extracts the first positional argument passed to the constructor.

```python
class TemplateError(Exception):
    def __init__(self, message: t.Optional[str] = None) -> None:
        super().__init__(message)

    @property
    def message(self) -> t.Optional[str]:
        return self.args[0] if self.args else None
```

The `message` property is defensive: it returns `None` when no arguments were supplied, avoiding an `IndexError`. Subclasses that need to override the message (such as `TemplateNotFound`) redeclare `message` as a plain attribute.

### `TemplateNotFound`

Raised when a single named template does not exist. It is a **multiple-inheritance** exception, deriving from `IOError`, `LookupError`, and `TemplateError`, so it can be caught by code expecting any of those standard categories.

```python
class TemplateNotFound(IOError, LookupError, TemplateError):
    message: t.Optional[str] = None

    def __init__(self, name, message=None):
        IOError.__init__(self, name)
        if message is None:
            from .runtime import Undefined
            if isinstance(name, Undefined):
                name._fail_with_undefined_error()
            message = name
        self.message = message
        self.name = name
        self.templates = [name]
```

Key behaviors:

- **`name`** — the template name that was requested.
- **`templates`** — a list containing the single requested name (normalized so callers can treat `TemplateNotFound` and `TemplatesNotFound` uniformly).
- **Undefined handling** — if `name` is an `Undefined` instance and no explicit message is given, the exception delegates to `Undefined._fail_with_undefined_error()`, which raises an `UndefinedError` instead. This produces a more helpful diagnostic when a template name itself is undefined.

> **Note:** The `from .runtime import Undefined` import is performed lazily inside `__init__` to avoid a circular import between `exceptions` and `runtime`.

### `TemplatesNotFound`

A specialization of `TemplateNotFound` raised when *multiple* candidate templates are tried and none are found. Because it subclasses `TemplateNotFound`, catching the base class catches both cases.

```python
class TemplatesNotFound(TemplateNotFound):
    def __init__(self, names=(), message=None):
        if message is None:
            from .runtime import Undefined
            parts = []
            for name in names:
                if isinstance(name, Undefined):
                    parts.append(name._undefined_message)
                else:
                    parts.append(name)
            parts_str = ", ".join(map(str, parts))
            message = f"none of the templates given were found: {parts_str}"

        super().__init__(names[-1] if names else None, message)
        self.templates = list(names)
```

Key behaviors:

- **`templates`** — the full list of names that were attempted.
- **Undefined-aware messages** — any `Undefined` entries in `names` are rendered using their `_undefined_message` property, producing a descriptive message rather than an empty string.
- The parent constructor is called with the *last* name (or `None` for an empty list), but the `templates` attribute is overwritten with the complete list.

### `TemplateSyntaxError`

Raised when the template source cannot be parsed. It carries rich location information to help users pinpoint the problem.

```python
class TemplateSyntaxError(TemplateError):
    def __init__(self, message, lineno, name=None, filename=None):
        super().__init__(message)
        self.lineno = lineno
        self.name = name
        self.filename = filename
        self.source = None
        self.translated = False
```

Attributes:

| Attribute | Description |
|-----------|-------------|
| `lineno` | The line number where the error occurred |
| `name` | The template name (load name) |
| `filename` | The filesystem filename, if known |
| `source` | The full template source, set later for context display |
| `translated` | `True` if the debug machinery rewrote the traceback |

The `__str__` method builds a human-readable, multi-line message that includes the location and, when `source` is available, the offending source line:

```python
def __str__(self):
    if self.translated:
        return t.cast(str, self.message)
    location = f"line {self.lineno}"
    name = self.filename or self.name
    if name:
        location = f'File "{name}", {location}'
    lines = [t.cast(str, self.message), "  " + location]
    if self.source is not None:
        try:
            line = self.source.splitlines()[self.lineno - 1]
        except IndexError:
            pass
        else:
            lines.append("    " + line.strip())
    return "\n".join(lines)
```

The `__reduce__` method is implemented to support **pickling**. Because the constructor requires multiple positional arguments (`message`, `lineno`, ...), the default pickling protocol would fail with a `TypeError`. `__reduce__` explicitly supplies the constructor arguments:

```python
def __reduce__(self):
    return self.__class__, (self.message, self.lineno, self.name, self.filename)
```

### `TemplateAssertionError`

A direct subclass of `TemplateSyntaxError` with identical attributes and behavior. It is used for compile-time errors that are *not* strictly syntax errors — for example, importing a name that starts with an underscore, or a `required` block containing non-whitespace content. See the [parser](parser.md) for concrete usages.

### `TemplateRuntimeError`

A generic runtime error raised during template rendering. It serves as the parent for the more specific runtime errors below. The [environment](environment.md) raises it directly when, for example, a filter or test is invoked without the required context.

### `UndefinedError`

Raised when a template attempts to operate on an `Undefined` value. This is the exception produced by `Undefined._fail_with_undefined_error()` in the [runtime](runtime.md) module. The exact message depends on how the undefined value was accessed (attribute access, item access, or a bare name).

### `SecurityError`

Raised when a template attempts an insecure operation while running under a [sandboxed environment](sandbox.md). The sandbox's `unsafe_undefined` method constructs an `Undefined` whose `_undefined_exception` is `SecurityError`, so the error surfaces when the unsafe value is actually used.

### `FilterArgumentError`

Raised when a filter is called with inappropriate arguments. It is a runtime error specific to filter invocation.

## Exception Flow Through the Engine

The following diagram shows where each exception type is raised as a template moves through the processing pipeline.

```mermaid
flowchart TD
    Source[Template Source] --> Lex[Lexer]
    Lex -->|malformed token| TSE[TemplateSyntaxError]
    Lex --> Parse[Parser]
    Parse -->|bad syntax| TSE
    Parse -->|compile-time assertion| TAE[TemplateAssertionError]
    Parse --> Compile[Compiler]
    Compile --> Load[Loader / Environment]

    Load -->|template missing| TNF[TemplateNotFound]
    Load -->|all candidates missing| TSNF[TemplatesNotFound]

    Load --> Render[Runtime Rendering]
    Render -->|undefined value used| UE[UndefinedError]
    Render -->|unsafe operation| SE[SecurityError]
    Render -->|bad filter args| FAE[FilterArgumentError]
    Render -->|generic runtime issue| TRE[TemplateRuntimeError]

    TSE -.subclass.-> TAE
    TNF -.subclass.-> TSNF
    TRE -.subclass.-> UE
    TRE -.subclass.-> SE
    TRE -.subclass.-> FAE
```

## Dependency Relationships

The exceptions module has minimal dependencies, which keeps it low in the import graph and safe to import from anywhere. Its only runtime dependency is a **lazy** import of `Undefined` from the [runtime](runtime.md) module, performed inside `TemplateNotFound.__init__` and `TemplatesNotFound.__init__` to avoid a circular import.

```mermaid
graph LR
    subgraph "exceptions.py"
        TE[TemplateError]
        TNF[TemplateNotFound]
        TSNF[TemplatesNotFound]
        TSE[TemplateSyntaxError]
        TAE[TemplateAssertionError]
        TRE[TemplateRuntimeError]
        UE[UndefinedError]
        SE[SecurityError]
        FAE[FilterArgumentError]
    end

    subgraph "runtime.py"
        U[Undefined]
    end

    subgraph "Consumers"
        LEX[lexer.py]
        PAR[parser.py]
        ENV[environment.py]
        LOAD[loaders.py]
        SBX[sandbox.py]
        RT[runtime.py]
    end

    TNF -.lazy import.-> U
    TSNF -.lazy import.-> U

    LEX --> TSE
    PAR --> TSE
    PAR --> TAE
    ENV --> TNF
    ENV --> TSNF
    ENV --> TRE
    ENV --> FAE
    LOAD --> TNF
    SBX --> SE
    RT --> UE
```

## Usage Patterns

### Catching all template errors

```python
from jinja2 import TemplateError

try:
    template.render(context)
except TemplateError as e:
    log.error("Template failed: %s", e)
```

### Distinguishing error categories

```python
from jinja2 import TemplateNotFound, TemplateSyntaxError, UndefinedError

try:
    template = env.get_template(name)
    template.render(context)
except TemplateNotFound:
    # handle missing template
    ...
except TemplateSyntaxError as e:
    # e.lineno, e.filename, e.source available for diagnostics
    ...
except UndefinedError:
    # handle undefined value usage
    ...
```

### Catching missing templates via standard exceptions

Because `TemplateNotFound` inherits from `IOError` and `LookupError`, it can be caught by code that is unaware of Jinja:

```python
try:
    env.get_template(name)
except LookupError:
    # works because TemplateNotFound is a LookupError
    ...
```

## Related Modules

- [runtime.md](runtime.md) — Defines `Undefined` and its subclasses, which raise `UndefinedError` and interact with `TemplateNotFound` / `TemplatesNotFound`.
- [environment.md](environment.md) — Raises `TemplateNotFound`, `TemplatesNotFound`, `TemplateRuntimeError`, and `FilterArgumentError`; provides `handle_exception` for traceback rewriting.
- [loaders.md](loaders.md) — Raises `TemplateNotFound` when a template cannot be located.
- [lexer.md](lexer.md) — Raises `TemplateSyntaxError` via the `Failure` helper.
- [parser.md](parser.md) — Raises `TemplateSyntaxError` and `TemplateAssertionError` during parsing.
- [sandbox.md](sandbox.md) — Raises `SecurityError` for unsafe operations.
