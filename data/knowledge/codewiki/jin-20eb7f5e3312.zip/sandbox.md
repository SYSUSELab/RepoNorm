# Sandbox Module

## Introduction

The `sandbox` module (`src/jinja2/sandbox.py`) provides a security layer for Jinja2 that ensures unsafe operations cannot be performed when rendering templates. It is designed for scenarios where **the template itself comes from an untrusted source** — for example, user-supplied templates in a multi-tenant application, a CMS, or any system where template authors are not fully trusted.

The module works by subclassing the standard [`Environment`](environment.md) and instructing the compiler to generate *sandboxed* code. At runtime, the sandbox intercepts attribute access, item access, callable invocation, and string formatting, raising a [`SecurityError`](exceptions.md) whenever a template attempts to reach something deemed unsafe.

The core idea is simple: rather than trying to enumerate everything that is *dangerous*, the sandbox enumerates what is *safe* and blocks everything else. By default:

- Attributes starting with an underscore (`_`) are private and blocked.
- Internal Python attributes (e.g. `__class__`, `func_code`, `mro`) are blocked.
- Callables marked with `@unsafe` (or Django's `alters_data`) are blocked.
- Ranges larger than `MAX_RANGE` (100,000 items) are blocked to prevent memory exhaustion.
- In the immutable variant, mutating methods on `list`, `dict`, `set`, and `deque` are blocked.

## Core Components

| Component | Role |
| --- | --- |
| `SandboxedEnvironment` | The primary sandboxed environment. Overrides attribute/item access, callable checks, operator interception, and string formatting. |
| `ImmutableSandboxedEnvironment` | Extends `SandboxedEnvironment` to additionally block mutation of builtin mutable containers. |
| `SandboxedFormatter` | A `string.Formatter` subclass that routes field access through the sandbox's safe `getattr`/`getitem`. |
| `SandboxedEscapeFormatter` | Combines `SandboxedFormatter` with `markupsafe.EscapeFormatter` for autoescaped `Markup` strings. |

### Supporting Functions and Constants

The module also exposes several module-level helpers that form the safety policy:

- `safe_range(*args)` — a replacement for the builtin `range` that raises `OverflowError` if the resulting range exceeds `MAX_RANGE`.
- `unsafe(f)` — decorator that marks a function/method as unsafe by setting `unsafe_callable = True`.
- `is_internal_attribute(obj, attr)` — returns `True` for internal Python attributes (dunder attributes, code/frame/traceback attributes, generator/coroutine internals).
- `modifies_known_mutable(obj, attr)` — returns `True` if `attr` is a mutating method on a known mutable container.
- `inspect_format_method(callable)` — detects `str.format` / `str.format_map` bound methods so they can be routed through the sandbox.
- `MAX_RANGE`, `UNSAFE_FUNCTION_ATTRIBUTES`, `UNSAFE_METHOD_ATTRIBUTES`, `UNSAFE_GENERATOR_ATTRIBUTES`, `UNSAFE_COROUTINE_ATTRIBUTES`, `UNSAFE_ASYNC_GENERATOR_ATTRIBUTES`, `_mutable_spec` — configuration constants.

## Architecture

The sandbox sits between the template runtime and the objects a template interacts with. It is a subclass of `Environment`, so it inherits the full parsing/compilation pipeline but overrides the runtime access hooks.

```mermaid
graph TD
    subgraph "Template Environment and Loading"
        ENV["Environment<br/>(environment.py)"]
    end

    subgraph "Sandbox Module"
        SE["SandboxedEnvironment"]
        ISE["ImmutableSandboxedEnvironment"]
        SF["SandboxedFormatter"]
        SEF["SandboxedEscapeFormatter"]
    end

    subgraph "Runtime Execution Support"
        CTX["Context<br/>(runtime.py)"]
        UND["Undefined<br/>(runtime.py)"]
        SEC["SecurityError<br/>(exceptions.py)"]
    end

    subgraph "External"
        FMT["string.Formatter"]
        EFMT["markupsafe.EscapeFormatter"]
        MK["markupsafe.Markup"]
    end

    ENV --> SE
    SE --> ISE
    FMT --> SF
    SF --> SEF
    EFMT --> SEF

    SE -.uses.-> CTX
    SE -.creates.-> UND
    SE -.raises.-> SEC
    SE -.uses.-> MK
```

## Component Relationships

```mermaid
classDiagram
    class Environment {
        +sandboxed: bool
        +getattr(obj, attribute)
        +getitem(obj, argument)
        +call(...)
        +format_string(...)
    }
    class SandboxedEnvironment {
        +sandboxed = True
        +default_binop_table
        +default_unop_table
        +intercepted_binops
        +intercepted_unops
        +is_safe_attribute(obj, attr, value)
        +is_safe_callable(obj)
        +call_binop(context, operator, left, right)
        +call_unop(context, operator, arg)
        +getitem(obj, argument)
        +getattr(obj, attribute)
        +unsafe_undefined(obj, attribute)
        +format_string(s, args, kwargs, format_func)
        +call(context, obj, *args, **kwargs)
    }
    class ImmutableSandboxedEnvironment {
        +is_safe_attribute(obj, attr, value)
    }
    class Formatter
    class SandboxedFormatter {
        +get_field(field_name, args, kwargs)
    }
    class EscapeFormatter
    class SandboxedEscapeFormatter

    Environment <|-- SandboxedEnvironment
    SandboxedEnvironment <|-- ImmutableSandboxedEnvironment
    Formatter <|-- SandboxedFormatter
    SandboxedFormatter <|-- SandboxedEscapeFormatter
    EscapeFormatter <|-- SandboxedEscapeFormatter
```

## How the Sandbox Works

### 1. Compilation-Time Flag

`SandboxedEnvironment` sets the class attribute `sandboxed = True`. This flag is read by the [compiler](compiler.md) (`CodeGenerator`) to emit sandboxed code — specifically, it routes attribute/item access and calls through the environment's safe methods rather than using raw Python operations.

### 2. Runtime Access Interception

When a template accesses `obj.attr` or `obj[key]`, the generated code calls the environment's `getattr` / `getitem` methods. The sandbox overrides these to enforce the safety policy:

```mermaid
flowchart TD
    A["Template: obj.attr"] --> B["SandboxedEnvironment.getattr(obj, attr)"]
    B --> C{"getattr succeeds?"}
    C -->|Yes| D{"is_safe_attribute?"}
    D -->|Yes| E["Return value"]
    D -->|No| F["unsafe_undefined()"]
    C -->|No| G{"obj[attr] works?"}
    G -->|Yes| E
    G -->|No| H["undefined(obj, name)"]
    F --> I["Undefined with SecurityError"]
```

`is_safe_attribute` returns `False` when the attribute starts with `_` or is an internal Python attribute (via `is_internal_attribute`). The `ImmutableSandboxedEnvironment` additionally rejects attributes that would mutate a known mutable container (via `modifies_known_mutable`).

### 3. Callable Safety

When a template calls a function, `SandboxedEnvironment.call` first checks whether the object is a `str.format`/`format_map` method (routing it through `format_string`), then verifies `is_safe_callable`. Callables are considered safe unless decorated with `@unsafe` or carrying Django's `alters_data = True`.

### 4. String Formatting Sandbox

`str.format` and `str.format_map` are powerful because they allow attribute and item access via format field names (e.g. `"{0.__class__}"`). To prevent this from bypassing the sandbox, `format_string` uses `SandboxedFormatter`, whose `get_field` resolves each field component through the environment's safe `getattr`/`getitem`. For `Markup` strings, `SandboxedEscapeFormatter` adds escaping on top.

### 5. Operator Interception

The sandbox allows fine-grained interception of binary and unary operators. By adding an operator to `intercepted_binops` / `intercepted_unops`, the compiler emits a call to `call_binop` / `call_unop` instead of the native operator. The default behavior delegates to `binop_table` / `unop_table`, which map operators to the corresponding `operator` module functions. This is useful for limiting expensive operations (e.g. blocking `**` with huge exponents).

## Data Flow: Rendering an Untrusted Template

```mermaid
sequenceDiagram
    participant App as Application
    participant Env as SandboxedEnvironment
    participant Comp as Compiler
    participant Tpl as Template
    participant Ctx as Context
    participant Obj as Target Object

    App->>Env: from_string(untrusted_source)
    Env->>Comp: compile (sandboxed=True)
    Comp-->>Env: code object
    Env-->>App: Template
    App->>Tpl: render(**data)
    Tpl->>Ctx: create context
    Tpl->>Env: getattr(obj, "attr")
    Env->>Obj: getattr(obj, "attr")
    Obj-->>Env: value
    Env->>Env: is_safe_attribute(obj, attr, value)
    alt safe
        Env-->>Tpl: value
    else unsafe
        Env-->>Tpl: Undefined(SecurityError)
    end
    Tpl-->>App: rendered output
```

## Usage

### Basic Sandboxed Environment

```python
from jinja2.sandbox import SandboxedEnvironment

env = SandboxedEnvironment()
template = env.from_string("{{ obj.attr }}")
template.render(obj=some_object)
```

### Immutable Sandboxed Environment

```python
from jinja2.sandbox import ImmutableSandboxedEnvironment

env = ImmutableSandboxedEnvironment()
# Attempting {{ mylist.append(1) }} raises SecurityError
```

### Marking Custom Callables as Unsafe

```python
from jinja2.sandbox import unsafe

class MyObject:
    @unsafe
    def delete(self):
        ...
```

### Customizing the Safety Policy

Subclass `SandboxedEnvironment` and override `is_safe_attribute` and/or `is_safe_callable` to implement an allow-list policy:

```python
class MySandbox(SandboxedEnvironment):
    def is_safe_attribute(self, obj, attr, value):
        return attr in {"name", "title"}  # explicit allow-list
```

### Intercepting Operators

```python
class MySandbox(SandboxedEnvironment):
    intercepted_binops = frozenset(["**"])

    def call_binop(self, context, operator, left, right):
        if operator == "**" and right > 100:
            raise SecurityError("exponent too large")
        return super().call_binop(context, operator, left, right)
```

## Security Considerations

- **Catch all exceptions.** The sandbox raises `SecurityError` for blocked operations, but other exceptions (e.g. `OverflowError` from `safe_range`, `TypeError`) may also occur during rendering. Callers must catch all exceptions when rendering untrusted templates.
- **The sandbox is not a full Python sandbox.** It restricts what templates can reach through Jinja's expression language, but it does not isolate the process. Combine it with other defenses (resource limits, timeouts, separate processes) for defense in depth.
- **`MAX_RANGE` guards memory.** `safe_range` prevents templates from materializing enormous ranges.
- **Format strings are a known bypass vector.** The `SandboxedFormatter` / `SandboxedEscapeFormatter` classes exist specifically to close the `str.format` attribute-traversal hole.
- **`is_internal_attribute` is the core of attribute safety.** Overriding `is_safe_attribute` without calling `super()` risks re-opening access to internal attributes.

## Related Modules

- [environment.md](environment.md) — the base `Environment` class that the sandbox extends, including the `sandboxed` flag and the `getattr`/`getitem`/`call` hooks.
- [compiler.md](compiler.md) — the `CodeGenerator` that reads the `sandboxed` flag and emits sandboxed access code.
- [runtime.md](runtime.md) — `Context` (used by `call`/`call_binop`/`call_unop`) and `Undefined` (returned for unsafe access).
- [exceptions.md](exceptions.md) — `SecurityError`, raised when a template attempts an insecure operation.
- [ext.md](ext.md) — extensions that may interact with the environment; note that extensions run with full trust and are not sandboxed.
