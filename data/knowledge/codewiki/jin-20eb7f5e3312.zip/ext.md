# Extension API (`ext`)

## Introduction

The `ext` module (`src/jinja2/ext.py`) provides the **extension API** for Jinja. Extensions are the primary mechanism for adding custom tags, filters, and behavior to the template engine at the **parser level**. Unlike filters or tests (which operate on values at runtime), extensions hook into the lexing, parsing, and code-generation pipeline, allowing them to introduce entirely new template syntax.

The module defines the base `Extension` class that all custom extensions subclass, plus a set of **built-in extensions** that ship with Jinja:

| Extension | Tag(s) | Purpose |
|-----------|--------|---------|
| `InternationalizationExtension` (`i18n`) | `{% trans %}` | Adds gettext-based translation support |
| `ExprStmtExtension` (`do`) | `{% do %}` | Evaluates an expression without outputting it |
| `LoopControlExtension` (`loopcontrols`) | `{% break %}`, `{% continue %}` | Adds loop control statements |
| `DebugExtension` (`debug`) | `{% debug %}` | Dumps available context, filters, and tests |

The module also exposes the standalone `extract_from_ast` and `babel_extract` functions used by the Babel toolchain to extract translatable strings from templates.

---

## Architecture Overview

Extensions sit between the [`Environment`](environment.md) and the parsing pipeline. The environment loads and stores extensions, the [`Parser`](parser.md) dispatches matching tags to them, and the [`CodeGenerator`](compiler.md) emits code for the AST nodes they produce.

```mermaid
graph TD
    Env["Environment<br/>(environment.md)"]
    Ext["Extension<br/>(base class)"]
    Parser["Parser<br/>(parser.md)"]
    Lexer["Lexer / TokenStream<br/>(lexer.md)"]
    Nodes["AST Nodes<br/>(nodes.md)"]
    Compiler["CodeGenerator<br/>(compiler.md)"]
    Runtime["Context / runtime<br/>(runtime.md)"]

    Env -->|"load_extensions()"| Ext
    Env -->|"iter_extensions()"| Parser
    Ext -->|"preprocess()"| Lexer
    Ext -->|"filter_stream()"| Lexer
    Ext -->|"parse(parser)"| Parser
    Parser -->|"produces"| Nodes
    Nodes -->|"consumed by"| Compiler
    Ext -->|"attr() / call_method()"| Nodes
    Compiler -->|"generates calls into"| Runtime
```

### Extension Lifecycle

An extension participates in four distinct phases of template processing. Each phase corresponds to an overridable method on the `Extension` base class:

```mermaid
flowchart LR
    A["Source string"] --> B["preprocess()"]
    B --> C["Lexing"]
    C --> D["filter_stream()"]
    D --> E["Parsing"]
    E --> F["parse(parser)"]
    F --> G["AST nodes"]
    G --> H["Compilation"]
```

1. **`preprocess(source, name, filename)`** — Called before lexing. Can rewrite the raw source string (e.g., to normalize syntax).
2. **`filter_stream(stream)`** — Called after lexing. Receives a [`TokenStream`](lexer.md) and may yield a filtered iterable of tokens.
3. **`parse(parser)`** — Called when one of the extension's registered `tags` is encountered. Returns one or more AST [`nodes`](nodes.md).
4. **Code generation** — Handled indirectly: the nodes returned by `parse` are compiled by the [`CodeGenerator`](compiler.md).

---

## Core Components

### `Extension` (base class)

The abstract base class for all extensions. Key characteristics:

- **`identifier`** — A `ClassVar` automatically set in `__init_subclass__` to `f"{cls.__module__}.{cls.__name__}"`. This uniquely identifies the extension and is used by `ExtensionAttribute` nodes to reference extension state in generated code.
- **`tags`** — A `Set[str]` of tag names the extension listens for. The [`Parser`](parser.md) builds a dispatch table from these.
- **`priority`** — Defaults to `100`. Lower values run first. Used by `Environment.iter_extensions()` to order preprocessing and stream filtering.
- **`environment`** — The bound environment. Extensions **must not** store environment-specific data on `self`, because `bind()` creates copies for overlay environments.

Key methods:

| Method | Purpose |
|--------|---------|
| `bind(environment)` | Creates a shallow copy bound to a different environment (used for overlays). |
| `preprocess(source, name, filename)` | Source-level preprocessing hook. |
| `filter_stream(stream)` | Token-level filtering hook. |
| `parse(parser)` | Tag parsing hook (raises `NotImplementedError` by default). |
| `attr(name, lineno)` | Returns an `ExtensionAttribute` node referencing extension state. |
| `call_method(name, args, kwargs, ...)` | Shortcut for `attr()` + a `Call` node. |

> **Configuration note:** Extensions cannot accept constructor arguments because they are identified by import name. Configuration must be stored on the environment (via `Environment.extend()`), using well-namespaced attribute names to avoid collisions.

### `InternationalizationExtension` (`i18n`)

Adds gettext support via the `{% trans %}` tag. On construction it:

- Registers `_` as a global alias for `gettext` (`_gettext_alias`).
- Extends the environment with `install_gettext_translations`, `install_null_translations`, `install_gettext_callables`, `uninstall_gettext_translations`, `extract_translations`, and the `newstyle_gettext` flag.

The `parse()` method handles the full `{% trans %}` / `{% pluralize %}` / `{% endtrans %}` grammar, including variable binding, pluralization expressions, whitespace trimming, and context strings. It produces `Output` nodes wrapping calls to `gettext`/`ngettext`/`pgettext`/`npgettext`.

Two translation styles are supported:

- **Old style** — The generated node is wrapped in `MarkSafeIfAutoescape` and a `Mod` node applies `%`-formatting with the referenced variables.
- **New style** (`newstyle_gettext=True`) — The gettext callable itself handles variable expansion and autoescaping; variables are passed as keyword arguments.

The helper factories `_make_new_gettext`, `_make_new_ngettext`, `_make_new_pgettext`, and `_make_new_npgettext` wrap user-provided translation functions with `@pass_context` so they can access `eval_ctx.autoescape` and the active [`Context`](runtime.md).

### `ExprStmtExtension` (`do`)

Adds the `{% do %}` tag, which evaluates an expression (via `parser.parse_tuple()`) and discards the result. Produces an `ExprStmt` node.

### `LoopControlExtension` (`loopcontrols`)

Adds `{% break %}` and `{% continue %}` tags, producing `Break` and `Continue` nodes respectively. These are only meaningful inside loop bodies.

### `DebugExtension` (`debug`)

Adds the `{% debug %}` tag. It emits an `Output` node calling `_render(context)`, which pretty-prints a dict of the current context variables, available filters, and available tests. It uses `ContextReference` to obtain the active [`Context`](runtime.md) at runtime.

### `_CommentFinder`

A helper used by `babel_extract` to associate translator comments with gettext calls. It scans a token list backwards from a given line number to find comments prefixed with one of the configured `comment_tags`. It can only find comments *forwards* — once a comment for a later line is consumed, earlier comments are no longer available.

### `_TranslationsBasic` / `_TranslationsContext`

`typing.Protocol` definitions (only under `TYPE_CHECKING`) describing the interface a translations object must satisfy:

- `_TranslationsBasic` — requires `gettext(message)` and `ngettext(singular, plural, n)`.
- `_TranslationsContext` — extends the basic protocol with `pgettext(context, message)` and `npgettext(context, singular, plural, n)`.

These are combined into the `_SupportedTranslations` union used by the install methods.

---

## Translation Extraction

Two module-level functions support extracting translatable strings, primarily for the Babel toolchain.

### `extract_from_ast(ast, gettext_functions, babel_style)`

Walks an AST (a [`nodes.Template`](nodes.md)) and yields `(lineno, function, message)` tuples for every call to a recognized gettext function. In **babel style** (default), non-string arguments and keyword arguments are returned as `None`, letting Babel infer intent. With `babel_style=False`, only string arguments are returned and invalid calls are skipped.

```mermaid
flowchart TD
    A["nodes.Template AST"] --> B["ast.find_all(nodes.Call)"]
    B --> C{"node.node is Name<br/>and in gettext_functions?"}
    C -->|No| B
    C -->|Yes| D["Collect string args<br/>(None for non-strings)"]
    D --> E{"babel_style?"}
    E -->|Yes| F["Single string → str<br/>Multiple → tuple"]
    E -->|No| G["Filter out None values"]
    F --> H["yield (lineno, func, message)"]
    G --> H
```

### `babel_extract(fileobj, keywords, comment_tags, options)`

The Babel extraction entry point. It:

1. Builds an [`Environment`](environment.md) from the `options` dict (delimiters, trimming, extensions, etc.), always including `InternationalizationExtension`.
2. Reads and parses the source, then lexes it to obtain tokens.
3. Uses `_CommentFinder` to attach preceding translator comments to each extracted message.
4. Yields `(lineno, funcname, message, comments)` tuples.

Syntax errors are silently skipped unless the `silent` option is set to `False`.

---

## Data Flow: `{% trans %}` End-to-End

The following sequence diagram shows how the i18n extension processes a translation block from source to rendered output.

```mermaid
sequenceDiagram
    participant Src as Template Source
    participant Env as Environment
    participant Ext as InternationalizationExtension
    participant Parser as Parser
    participant CG as CodeGenerator
    participant Ctx as Context (runtime)

    Src->>Env: parse(source)
    Env->>Ext: preprocess(source)
    Ext-->>Env: (unchanged)
    Env->>Parser: Parser(env, source)
    Parser->>Ext: parse(parser)  [tag: trans]
    Ext->>Parser: parse_expression() / _parse_block()
    Ext-->>Parser: Output(Call(gettext, ...))
    Parser-->>Env: nodes.Template
    Env->>CG: generate(ast)
    CG-->>Env: Python code
    Note over Ctx: At render time
    Ctx->>Ctx: call gettext / ngettext
    Ctx-->>Src: translated string
```

---

## Component Interaction Map

```mermaid
classDiagram
    class Extension {
        +identifier: ClassVar[str]
        +tags: Set[str]
        +priority: int
        +environment: Environment
        +bind(environment) Extension
        +preprocess(source, name, filename) str
        +filter_stream(stream) TokenStream
        +parse(parser) Node
        +attr(name, lineno) ExtensionAttribute
        +call_method(name, ...) Call
    }
    class InternationalizationExtension {
        +tags = {trans}
        +parse(parser)
        +_install(translations)
        +_install_null()
        +_install_callables(...)
        +_uninstall(translations)
        +_extract(source)
    }
    class ExprStmtExtension {
        +tags = {do}
        +parse(parser) ExprStmt
    }
    class LoopControlExtension {
        +tags = {break, continue}
        +parse(parser) Break|Continue
    }
    class DebugExtension {
        +tags = {debug}
        +parse(parser) Output
        +_render(context) str
    }
    class _CommentFinder {
        +find_backwards(offset) List[str]
        +find_comments(lineno) List[str]
    }

    Extension <|-- InternationalizationExtension
    Extension <|-- ExprStmtExtension
    Extension <|-- LoopControlExtension
    Extension <|-- DebugExtension
    InternationalizationExtension ..> _CommentFinder : used by babel_extract
```

---

## Dependencies

The `ext` module depends on several other Jinja modules:

| Dependency | Used For | Reference |
|------------|----------|-----------|
| `environment.Environment` | Binding extensions, parsing, extending config | [environment.md](environment.md) |
| `parser.Parser` | Tag parsing dispatch | [parser.md](parser.md) |
| `lexer.TokenStream` / `Token` | Stream filtering and comment finding | [lexer.md](lexer.md) |
| `nodes.*` | Building AST nodes (`Output`, `Call`, `ExtensionAttribute`, etc.) | [nodes.md](nodes.md) |
| `runtime.Context` / `concat` / `Undefined` | Runtime context access and string concatenation | [runtime.md](runtime.md) |
| `exceptions.TemplateAssertionError` / `TemplateSyntaxError` | Error reporting during parsing | [exceptions.md](exceptions.md) |
| `utils.import_string` / `pass_context` | Dynamic extension loading and context injection | [utils.md](utils.md) |
| `defaults` | Default delimiter and policy values for `babel_extract` | — |

### Dependency Graph

```mermaid
graph LR
    ext["ext.py"]
    ext --> environment
    ext --> parser
    ext --> lexer
    ext --> nodes
    ext --> runtime
    ext --> exceptions
    ext --> utils
    ext --> defaults
    ext --> markupsafe["markupsafe.Markup"]
```

---

## Public API Summary

### Classes

- `Extension` — Base class for all extensions.
- `InternationalizationExtension` — gettext support (`i18n`).
- `ExprStmtExtension` — `{% do %}` tag (`do`).
- `LoopControlExtension` — `{% break %}` / `{% continue %}` (`loopcontrols`).
- `DebugExtension` — `{% debug %}` tag (`debug`).

### Functions

- `extract_from_ast(ast, gettext_functions, babel_style)` — Extract translatable strings from an AST.
- `babel_extract(fileobj, keywords, comment_tags, options)` — Babel extraction entry point.

### Aliases

```python
i18n = InternationalizationExtension
do = ExprStmtExtension
loopcontrols = LoopControlExtension
debug = DebugExtension
```

### Constants

- `GETTEXT_FUNCTIONS` — Tuple of recognized gettext function names: `("_", "gettext", "ngettext", "pgettext", "npgettext")`.

---

## Writing a Custom Extension

To create a custom extension:

1. Subclass `Extension` and set the `tags` class attribute.
2. Optionally override `preprocess()` and/or `filter_stream()`.
3. Implement `parse(parser)` to consume tokens and return AST nodes.
4. Use `self.attr()` and `self.call_method()` to reference extension state and methods from generated code.
5. Register the extension by passing its import path or class to the [`Environment`](environment.md) `extensions` parameter.

```python
from jinja2.ext import Extension
from jinja2 import nodes

class MyExtension(Extension):
    tags = {"mytag"}

    def parse(self, parser):
        lineno = next(parser.stream).lineno
        # ... parse arguments ...
        return nodes.Output([...], lineno=lineno)
```

> **Important:** Never store environment-specific data on `self`. Use `Environment.extend()` to register configuration, and `self.attr()` to access it from generated template code.
