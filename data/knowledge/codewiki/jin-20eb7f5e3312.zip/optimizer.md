# Optimizer Module

## Introduction

The `optimizer` module (`src/jinja2/optimizer.py`) is a compile-time AST transformation pass in Jinja's parsing and compilation pipeline. Its primary purpose is **constant folding**: it walks the abstract syntax tree (AST) produced by the parser and replaces any expression that can be evaluated to a constant value at compile time with a single `Const` node. This reduces the amount of work the generated Python code must perform at render time.

The module is intentionally small and focused. It exposes a single public helper function, `optimize`, and a single class, `Optimizer`, which is a specialized `NodeTransformer`. The optimizer is invoked by the compiler (see [compiler.md](compiler.md)) when the environment is configured with `optimized=True` (the default).

> **Design note:** The optimizer cannot perform all possible optimizations because the AST does not carry complete scoping information. For example, loop unrolling is not possible because unrolled loops would have a different scope. A second syntax tree storing scoping rules would be required to support such transformations.

---

## Architecture Overview

The optimizer sits between the parser and the compiler in the template processing pipeline. It is a *transformation* pass that mutates the AST in place before code generation.

```mermaid
flowchart LR
    Source["Template Source"] --> Lexer["Lexer"]
    Lexer --> Parser["Parser"]
    Parser --> AST["AST (nodes.Template)"]
    AST --> Optimizer["Optimizer\n(constant folding)"]
    Optimizer --> OptimizedAST["Optimized AST"]
    OptimizedAST --> Compiler["CodeGenerator"]
    Compiler --> Code["Python Code / Bytecode"]
```

The optimizer is optional and controlled by the `optimized` flag on the `Environment`. When enabled, the `CodeGenerator` constructs an `Optimizer` instance and applies it to the AST.

---

## Core Components

### `optimize(node, environment)`

A module-level convenience function that instantiates an `Optimizer` and applies it to the given node.

```python
def optimize(node: nodes.Node, environment: "Environment") -> nodes.Node:
    optimizer = Optimizer(environment)
    return t.cast(nodes.Node, optimizer.visit(node))
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `node` | `nodes.Node` | The root AST node to optimize (typically a `nodes.Template`). |
| `environment` | `Environment` | The environment, used to provide context for static optimization decisions. |

**Returns:** The optimized AST node (the same tree, mutated in place).

### `Optimizer`

A subclass of `NodeTransformer` (from [visitor.md](visitor.md)) that performs constant folding.

```python
class Optimizer(NodeTransformer):
    def __init__(self, environment: "t.Optional[Environment]") -> None:
        self.environment = environment
```

| Attribute | Type | Description |
|-----------|------|-------------|
| `environment` | `Optional[Environment]` | The environment used to resolve constants and inform optimization decisions. May be `None`. |

#### `generic_visit(node, *args, **kwargs)`

The heart of the optimizer. It overrides the base `NodeTransformer.generic_visit` to add constant-folding behavior after the standard recursive traversal.

```python
def generic_visit(self, node, *args, **kwargs):
    node = super().generic_visit(node, *args, **kwargs)

    # Do constant folding. Some other nodes besides Expr have
    # as_const, but folding them causes errors later on.
    if isinstance(node, nodes.Expr):
        try:
            return nodes.Const.from_untrusted(
                node.as_const(args[0] if args else None),
                lineno=node.lineno,
                environment=self.environment,
            )
        except nodes.Impossible:
            pass

    return node
```

**Behavior:**

1. **Recurse first** — calls the parent `generic_visit`, which visits all child nodes and applies any replacements. This ensures children are optimized before the parent is considered.
2. **Attempt folding** — if the (now-optimized) node is an `Expr`, it attempts to evaluate it to a constant via `node.as_const(...)`.
3. **Wrap in `Const`** — if evaluation succeeds, the result is wrapped in a `Const` node using `Const.from_untrusted`, preserving the original `lineno` and attaching the environment.
4. **Graceful fallback** — if `as_const` raises `nodes.Impossible`, the original node is returned unchanged.

> **Why only `Expr` nodes?** The comment in the source notes that some non-`Expr` nodes also implement `as_const`, but folding them causes errors later in the pipeline. Restricting folding to `Expr` nodes keeps the transformation safe.

---

## Constant Folding Process

The following sequence diagram illustrates how a single expression node is folded during traversal.

```mermaid
sequenceDiagram
    participant T as NodeTransformer.generic_visit
    participant O as Optimizer.generic_visit
    participant E as Expr node
    participant C as Const.from_untrusted

    O->>T: super().generic_visit(node)
    T->>E: visit children (recursive)
    T-->>O: optimized node
    O->>O: isinstance(node, nodes.Expr)?
    alt node is Expr
        O->>E: node.as_const(eval_ctx)
        alt evaluation succeeds
            E-->>O: constant value
            O->>C: Const.from_untrusted(value, lineno, environment)
            C-->>O: Const node
            O-->>O: return Const node
        else raises Impossible
            E-->>O: Impossible
            O-->>O: return original node
        end
    else node is not Expr
        O-->>O: return node unchanged
    end
```

### What Can Be Folded

Constant folding relies on the `as_const` method implemented by `Expr` subclasses (see [nodes.md](nodes.md)). Examples of foldable expressions include:

| Node Type | Example | Folded Result |
|-----------|---------|---------------|
| `BinExpr` (Add, Sub, Mul, etc.) | `1 + 2` | `Const(3)` |
| `UnaryExpr` (Neg, Not, Pos) | `-5` | `Const(-5)` |
| `Concat` | `"a" ~ "b"` | `Const("ab")` |
| `Const` | `42` | `Const(42)` (already constant) |

### What Cannot Be Folded

`as_const` raises `nodes.Impossible` in several situations, causing the optimizer to leave the node untouched:

- **Non-constant operands** — e.g., a `Name` node referencing a runtime variable.
- **Sandboxed intercepted operators** — when the environment is sandboxed and the operator is in `intercepted_binops` / `intercepted_unops`, folding is skipped to preserve sandbox semantics (see [sandbox.md](sandbox.md)).
- **Unsafe representations** — `Const.from_untrusted` raises `Impossible` if the value does not have a safe `repr` (checked via `has_safe_repr` in the compiler).

---

## Component Interaction

The optimizer interacts with several other modules in the pipeline.

```mermaid
flowchart TD
    subgraph "Parsing & Compilation Pipeline"
        Optimizer["Optimizer\n(optimizer.py)"]
        NodeTransformer["NodeTransformer\n(visitor.py)"]
        Nodes["nodes.Node / Expr / Const / Impossible\n(nodes.py)"]
        Compiler["CodeGenerator\n(compiler.py)"]
        Environment["Environment\n(environment.py)"]
    end

    Optimizer -->|inherits| NodeTransformer
    Optimizer -->|reads/writes| Nodes
    Optimizer -->|constructed by| Compiler
    Optimizer -->|uses| Environment
    Compiler -->|calls optimize| Optimizer
```

### Key Relationships

- **Inherits from `NodeTransformer`** ([visitor.md](visitor.md)) — provides the recursive AST traversal and node-replacement machinery. The optimizer only overrides `generic_visit`.
- **Operates on `nodes`** ([nodes.md](nodes.md)) — reads `Expr` nodes, calls `as_const`, and produces `Const` nodes. Uses `Impossible` as the control-flow signal for "cannot fold".
- **Constructed by the `CodeGenerator`** ([compiler.md](compiler.md)) — when `optimized=True`, the compiler creates an `Optimizer(environment)` and stores it in `self.optimizer`. The `optimized` property reflects whether an optimizer is present.
- **Uses the `Environment`** ([environment.md](environment.md)) — the environment is passed to `Const.from_untrusted` and is available for context-sensitive optimization decisions (e.g., sandbox interception checks performed inside `as_const`).

---

## Integration with the Compiler

The optimizer is wired into the compiler through the `CodeGenerator` constructor:

```python
class CodeGenerator(NodeVisitor):
    def __init__(self, environment, name, filename, stream=None,
                 defer_init=False, optimized=True):
        ...
        self.optimizer: t.Optional[Optimizer] = None
        if optimized:
            self.optimizer = Optimizer(environment)

    @property
    def optimized(self) -> bool:
        return self.optimizer is not None
```

The `optimized` flag originates from the `Environment.optimized` attribute (default `True`) and is threaded through `Environment._generate` into the `generate` function and ultimately the `CodeGenerator`.

```mermaid
flowchart LR
    Env["Environment.optimized\n(default True)"] --> Gen["Environment._generate"]
    Gen --> Generate["generate(...)"]
    Generate --> CG["CodeGenerator(optimized=...)"]
    CG -->|if optimized| Opt["Optimizer(environment)"]
```

---

## Process Flow: End-to-End

The following diagram shows where the optimizer fits in the full template compilation flow.

```mermaid
flowchart TD
    A["Environment.compile(source)"] --> B["Environment._parse"]
    B --> C["Parser.parse() → nodes.Template"]
    C --> D["Environment._generate"]
    D --> E["generate(..., optimized=env.optimized)"]
    E --> F["CodeGenerator.__init__"]
    F -->|optimized=True| G["Create Optimizer(environment)"]
    F --> H["CodeGenerator.visit_Template"]
    H --> I["Optimizer applied to AST\n(constant folding)"]
    I --> J["Generate Python source"]
    J --> K["Environment._compile → CodeType"]
```

---

## Summary

| Aspect | Detail |
|--------|--------|
| **Purpose** | Constant-fold expressions in the AST at compile time. |
| **Public API** | `optimize(node, environment)`, `Optimizer` |
| **Base class** | `NodeTransformer` ([visitor.md](visitor.md)) |
| **Key method** | `Optimizer.generic_visit` |
| **Trigger** | `Environment.optimized=True` (default) |
| **Failure mode** | `nodes.Impossible` → node left unchanged |
| **Limitation** | Cannot perform scope-dependent optimizations (e.g., loop unrolling) |

### Related Documentation

- [compiler.md](compiler.md) — The `CodeGenerator` that constructs and applies the optimizer.
- [nodes.md](nodes.md) — AST node definitions, including `Expr`, `Const`, and `Impossible`.
- [visitor.md](visitor.md) — `NodeVisitor` / `NodeTransformer` traversal infrastructure.
- [environment.md](environment.md) — The `Environment` and its `optimized` configuration.
- [sandbox.md](sandbox.md) — Sandboxed environments that intercept operators, preventing some folding.
