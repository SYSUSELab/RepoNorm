# Compiler Module

## Introduction

The **Compiler** module (`src/jinja2/compiler.py`) is the heart of Jinja's code generation pipeline. It transforms the abstract syntax tree (AST) produced by the [Parser](parser.md) into executable Python source code. This generated code, when compiled and executed, renders the template by yielding string fragments that are concatenated into the final output.

The compiler is responsible for:

- **Translating AST nodes into Python statements and expressions** via a visitor pattern.
- **Scope and identifier tracking** — deciding whether a name is a local variable, a parameter, a closure alias, or must be resolved from the runtime context.
- **Constant folding and optimization** — evaluating constant expressions at compile time.
- **Template inheritance** — generating the machinery for `{% extends %}`, `{% block %}`, `{% include %}`, and `{% import %}`.
- **Autoescaping and finalization** — wrapping output in the appropriate escaping/finalize calls.
- **Async support** — emitting `async`/`await` constructs when the environment is async-enabled.

The module is invoked by the [Environment](environment.md) through its `compile()` method, which calls the module-level `generate()` function.

---

## Architecture Overview

The compiler sits between the parsing stage and the runtime execution stage. It consumes the AST and produces Python source that imports from the [Runtime](runtime.md) module.

```mermaid
flowchart LR
    subgraph Parsing["Parsing & Compilation Pipeline"]
        LEX[Lexer] --> PAR[Parser]
        PAR --> AST[AST Nodes]
        AST --> OPT[Optimizer]
        OPT --> CG[CodeGenerator]
        CG --> SRC[Python Source]
    end

    subgraph Runtime["Runtime Execution Support"]
        SRC --> COMPILE[compile builtin]
        COMPILE --> CODE[Code Object]
        CODE --> RT[Runtime: Context, Macro, Undefined]
    end

    ENV[Environment] -.->|code_generator_class| CG
    ENV -.->|filters/tests/globals| CG
    IDT[idtracking: Symbols] -.->|scope info| CG
```

### Key Responsibilities by Component

| Component | Responsibility |
|-----------|----------------|
| `CodeGenerator` | Main visitor that emits Python source for every AST node |
| `Frame` | Holds compile-time scope information (symbols, buffer, block context) |
| `MacroRef` | Tracks metadata about a macro/call-block (caller, kwargs, varargs usage) |
| `DependencyFinderVisitor` | Collects filter and test names used in a template |
| `UndeclaredNameVisitor` | Detects names accessed without being declared |
| `CompilerExit` | Signals that further processing of a block is unnecessary |
| `VisitorExit` | Signals early termination of the undeclared-name scan |
| `CodeGenerator._FinalizeInfo` | Caches the finalize function configuration for output nodes |

---

## Component Relationships

```mermaid
classDiagram
    class NodeVisitor {
        +visit(node, *args, **kwargs)
        +generic_visit(node, *args, **kwargs)
        +get_visitor(node)
    }

    class CodeGenerator {
        +environment
        +stream
        +optimizer
        +blocks
        +filters
        +tests
        +visit_Template(node, frame)
        +visit_Block(node, frame)
        +visit_For(node, frame)
        +visit_Output(node, frame)
        +macro_body(node, frame)
        +write(x)
        +writeline(x, node, extra)
    }

    class Frame {
        +eval_ctx
        +parent
        +symbols
        +buffer
        +block
        +toplevel
        +rootlevel
        +loop_frame
        +block_frame
        +soft_frame
        +inner(isolated)
        +soft()
        +copy()
    }

    class MacroRef {
        +node
        +accesses_caller
        +accesses_kwargs
        +accesses_varargs
    }

    class DependencyFinderVisitor {
        +filters
        +tests
    }

    class UndeclaredNameVisitor {
        +names
        +undeclared
    }

    NodeVisitor <|-- CodeGenerator
    NodeVisitor <|-- DependencyFinderVisitor
    NodeVisitor <|-- UndeclaredNameVisitor
    CodeGenerator --> Frame : creates/manages
    CodeGenerator --> MacroRef : creates
    CodeGenerator --> DependencyFinderVisitor : uses
    CodeGenerator --> UndeclaredNameVisitor : uses
    Frame --> Symbols : owns
```

---

## The Code Generation Pipeline

The entry point is the module-level `generate()` function, called by `Environment._generate()`:

```mermaid
sequenceDiagram
    participant Env as Environment
    participant Gen as generate()
    participant CG as CodeGenerator
    participant Opt as Optimizer
    participant Sym as Symbols

    Env->>Gen: generate(node, env, name, filename, ...)
    Gen->>CG: code_generator_class(env, name, filename, ...)
    Gen->>CG: visit(node)
    CG->>CG: visit_Template(node)
    CG->>Sym: analyze_node(node)
    CG->>CG: pull_dependencies(node.body)
    CG->>CG: blockvisit(node.body, frame)
    loop For each expression node
        CG->>Opt: visit(node, eval_ctx)
        Opt-->>CG: folded Const or original node
    end
    CG-->>Gen: stream.getvalue()
    Gen-->>Env: Python source string
```

### Step-by-step

1. **Instantiation** — `generate()` creates a `CodeGenerator` using `environment.code_generator_class` (allowing subclasses like `NativeCodeGenerator` and `TrackingCodeGenerator` to override behavior).
2. **Template visit** — `visit_Template` sets up the root render function, collects blocks, resolves imports, and emits the module preamble.
3. **Dependency pulling** — `pull_dependencies` scans for filters/tests and emits runtime lookups with fallback error functions.
4. **Body traversal** — `blockvisit` walks the body, dispatching to per-node visitor methods.
5. **Optimization** — Expression visitors decorated with `@optimizeconst` attempt constant folding via the `Optimizer` before emitting code.
6. **Output** — The accumulated `StringIO` stream is returned as the Python source.

---

## Frame and Scope Management

The `Frame` class is the compiler's compile-time representation of a lexical scope. Frames form a tree mirroring the nesting of template constructs.

```mermaid
flowchart TD
    ROOT["Root Frame<br/>toplevel=True, rootlevel=True"]
    ROOT --> IF["Soft Frame (if/cond)<br/>soft_frame=True"]
    ROOT --> LOOP["Loop Frame<br/>loop_frame=True"]
    ROOT --> BLOCK["Block Frame<br/>block_frame=True"]
    ROOT --> INNER["Inner Frame (macro/with/scope)"]
    LOOP --> LOOPINNER["Inner Frame"]
    BLOCK --> BLOCKINNER["Inner Frame"]
```

### Frame kinds

| Method | Purpose |
|--------|---------|
| `Frame(eval_ctx)` | Creates a root frame with a fresh `Symbols` instance |
| `frame.inner(isolated=False)` | Creates a child frame; `isolated=True` creates a detached frame with a new symbol level |
| `frame.soft()` | Creates a copy that is no longer `rootlevel` and marked `soft_frame` — used for `if`/conditional expressions where errors should be deferred to runtime |
| `frame.copy()` | Shallow copy with a copied `Symbols` instance |

### Frame flags

- **`toplevel`** — root frame plus soft frames (e.g. `if` conditions).
- **`rootlevel`** — the outermost frame only; used to optimize inheritance.
- **`loop_frame`** — variables set here are tracked in `_loop_vars` rather than the context.
- **`block_frame`** — variables set here are tracked in `_block_vars`.
- **`soft_frame`** — errors for undefined filters/tests are deferred to runtime.
- **`buffer`** — when set, output is appended to a list buffer instead of yielded (used by macros, filter blocks, set blocks).
- **`require_output_check`** — wraps output in `if parent_template is None:` checks for inheritance.

### Identifier tracking

Each `Frame` owns a `Symbols` object (from [idtracking](idtracking.md)) that records:

- **`refs`** — mapping of template names to generated Python identifiers (`l_<level>_<name>`).
- **`loads`** — load instructions (`VAR_LOAD_PARAMETER`, `VAR_LOAD_RESOLVE`, `VAR_LOAD_ALIAS`, `VAR_LOAD_UNDEFINED`).
- **`stores`** — names assigned within the scope.

`enter_frame()` and `leave_frame()` emit the code that initializes and clears these variables, including the `missing` sentinel for undefined names.

---

## Node Visitor Dispatch

`CodeGenerator` extends `NodeVisitor`, dispatching to `visit_<NodeType>` methods. The following table summarizes the major visitor categories.

### Statement visitors

| Visitor | Emits |
|---------|-------|
| `visit_Template` | Module preamble, `root()` function, block functions, `blocks`/`debug_info` dicts |
| `visit_Block` | Call to `context.blocks[name][0](context)` |
| `visit_Extends` | `parent_template = environment.get_template(...)` and block merging |
| `visit_Include` | `environment.get_template/select_template` + render loop |
| `visit_Import` / `visit_FromImport` | Module loading and name binding |
| `visit_For` | Loop with optional `LoopContext`, filter function, and `else` branch |
| `visit_If` | `if`/`elif`/`else` using a soft frame |
| `visit_Macro` | Macro function definition + `Macro(...)` wrapper |
| `visit_CallBlock` | Caller macro + call forwarding |
| `visit_FilterBlock` | Buffered body passed through a filter |
| `visit_With` | Scoped assignments |
| `visit_Assign` / `visit_AssignBlock` | Assignment with tracking; block captures buffer |
| `visit_Output` | Constant folding + escaping/finalize wrapping |

### Expression visitors

| Visitor | Emits |
|---------|-------|
| `visit_Name` | Reference with undefined-check unless it's a known parameter |
| `visit_Const` / `visit_TemplateData` | Literal repr or runtime escape |
| `visit_Tuple` / `visit_List` / `visit_Dict` | Collection literals |
| `visit_Add` … `visit_Not` | Binary/unary operators (sandbox-aware) |
| `visit_Concat` | `markup_join`/`str_join` |
| `visit_Compare` / `visit_Operand` | Comparison chains |
| `visit_Getattr` / `visit_Getitem` / `visit_Slice` | Attribute/item access via environment |
| `visit_Filter` / `visit_Test` | Filter/test invocation with pass-arg injection |
| `visit_CondExpr` | Inline conditional with `cond_expr_undefined` fallback |
| `visit_Call` | Callable invocation with caller/loop/block kwargs |

### Extension-only visitors

`visit_MarkSafe`, `visit_MarkSafeIfAutoescape`, `visit_EnvironmentAttribute`, `visit_ExtensionAttribute`, `visit_ImportedName`, `visit_InternalName`, `visit_ContextReference`, `visit_DerivedContextReference`, `visit_Continue`, `visit_Break`, `visit_Scope`, `visit_OverlayScope`, `visit_EvalContextModifier`, `visit_ScopedEvalContextModifier`.

---

## Constant Folding and Optimization

The `@optimizeconst` decorator wraps expression visitors. When the frame's `EvalContext` is **not volatile**, the `Optimizer` attempts to reduce the node to a `Const`:

```mermaid
flowchart TD
    A[visit expression node] --> B{optimizer enabled<br/>and not volatile?}
    B -- No --> F[emit runtime code]
    B -- Yes --> C[Optimizer.visit node]
    C --> D{node.as_const succeeds?}
    D -- Yes --> E[emit folded Const]
    D -- No (Impossible) --> F
```

The `Optimizer` (from [optimizer](optimizer.md)) performs constant folding by calling `node.as_const()`. If folding raises `nodes.Impossible`, the original node is emitted for runtime evaluation.

### Output finalization

`visit_Output` performs a second layer of optimization. It groups consecutive constant children and emits them as a single joined literal, while non-constant children are wrapped in escaping/finalize calls:

- `_make_finalize()` builds and caches a `_FinalizeInfo` namedtuple containing a compile-time `const` function and runtime `src` string.
- `_output_child_to_const()` attempts compile-time conversion; `_output_child_pre`/`_output_child_post` emit the runtime escaping wrapper (`escape(...)`, `str(...)`, or the volatile ternary).

---

## Template Inheritance

Inheritance is handled by `visit_Template`, `visit_Extends`, and `visit_Block`:

```mermaid
flowchart TD
    T[visit_Template] --> H{have_extends?}
    H -- No --> R[emit root only]
    H -- Yes --> P[emit parent_template = None]
    P --> B[emit block functions]
    B --> C[emit blocks dict]
    C --> E[emit parent root_render_func call]
    E --> K{has_known_extends?}
    K -- Yes --> S[skip output checks]
    K -- No --> W[wrap output in if parent_template is None]
```

- **`has_known_extends`** — set when an `{% extends %}` appears at the root level, allowing the compiler to skip redundant runtime checks.
- **`extends_so_far`** — counts extends statements to detect and reject multiple inheritance.
- **`require_output_check`** — when true, top-level output is guarded so it only renders if no parent template is active.

---

## Macro Compilation

`macro_body()` generates the function definition for a macro or call block, and `macro_def()` wraps it in a runtime `Macro` object.

```mermaid
sequenceDiagram
    participant CG as CodeGenerator
    participant Frame
    participant Sym as Symbols

    CG->>Frame: frame.inner()
    CG->>Sym: analyze_node(node)
    CG->>CG: find_undeclared(body, caller/kwargs/varargs)
    CG->>Sym: declare_parameter(caller/kwargs/varargs)
    CG->>CG: emit def macro(...)
    CG->>Frame: buffer(frame)
    CG->>CG: enter_frame(frame)
    CG->>CG: emit default-value handling
    CG->>CG: blockvisit(body)
    CG->>CG: return_buffer_contents(force_unescaped=True)
    CG->>CG: leave_frame(with_python_scope=True)
    CG-->>CG: return (frame, MacroRef)
```

The `MacroRef` records whether the macro accesses `caller`, `kwargs`, or `varargs`, which is passed to the runtime `Macro` constructor (see [runtime](runtime.md)). The special `caller` argument must be omitted or given a default — otherwise a `TemplateAssertionError` is raised.

---

## Dependency Resolution

`pull_dependencies()` uses `DependencyFinderVisitor` to collect all filter and test names, then emits runtime lookups:

```python
try:
    t_1 = environment.filters['name']
except KeyError:
    @internalcode
    def t_1(*unused):
        raise TemplateRuntimeError("No filter named 'name' found.")
```

This defers missing-filter errors to runtime for filters used inside `if`/conditional expressions (where the branch may never execute), while still validating at compile time for unconditional usage.

---

## Async Support

When `environment.is_async` is true, the compiler emits async constructs:

- `choose_async()` selects between `async ` and empty prefixes.
- `func()` produces `async def` for render functions.
- Loops use `async for` and `auto_aiter(...)`.
- Calls are wrapped in `(await auto_await(...))`.
- `visit_Template` emits `async for event in parent_template.root_render_func(...)`.

---

## Error Handling

| Exception | Raised when |
|-----------|-------------|
| `TemplateAssertionError` | Compile-time errors: duplicate blocks, invalid `caller`, assignment to `loop`, non-top-level `extends`, missing filters/tests |
| `CompilerExit` | Internal signal to stop processing a block (e.g. after a known `extends`) |
| `VisitorExit` | Internal signal to stop the undeclared-name scan early |
| `TypeError` | `generate()` called with a non-`Template` node |

The `fail()` helper raises `TemplateAssertionError` with position information derived from `position()`.

---

## Integration with Other Modules

```mermaid
flowchart TD
    COMPILER[compiler.py]

    COMPILER -->|consumes AST| NODES[nodes.md]
    COMPILER -->|scope tracking| IDT[idtracking.md]
    COMPILER -->|constant folding| OPT[optimizer.md]
    COMPILER -->|visitor base| VIS[visitor.md]
    COMPILER -->|pass-arg detection| UTILS[utils.md]
    COMPILER -->|errors| EXC[exceptions.md]
    COMPILER -->|generated code imports| RT[runtime.md]
    COMPILER -->|invoked by| ENV[environment.md]
    COMPILER -->|subclassed by| META[meta.md]
    COMPILER -->|subclassed by| NATIVE[nativetypes.md]
    COMPILER -->|sandbox flags| SANDBOX[sandbox.md]
```

### Related documentation

- [nodes.md](nodes.md) — AST node definitions consumed by the compiler.
- [idtracking.md](idtracking.md) — `Symbols` and `FrameSymbolVisitor` for scope analysis.
- [optimizer.md](optimizer.md) — constant folding used by `@optimizeconst`.
- [visitor.md](visitor.md) — `NodeVisitor`/`NodeTransformer` base classes.
- [environment.md](environment.md) — invokes the compiler via `compile()`/`_generate()`.
- [runtime.md](runtime.md) — runtime classes (`Context`, `Macro`, `Undefined`) referenced by generated code.
- [meta.md](meta.md) — `TrackingCodeGenerator` subclass for introspection.
- [nativetypes.md](nativetypes.md) — `NativeCodeGenerator` subclass for native Python output.
- [sandbox.md](sandbox.md) — sandboxed environments that alter operator/call generation.
- [exceptions.md](exceptions.md) — `TemplateAssertionError` and related errors.
- [utils.md](utils.md) — `_PassArg` used to detect context/eval-context/environment injection.

---

## Summary

The Compiler module is the translation engine of Jinja. It walks the AST using a visitor pattern, maintaining a tree of `Frame` objects that track lexical scope and identifier resolution. It performs constant folding through the `Optimizer`, generates inheritance and macro machinery, and emits Python source that imports from the runtime module. Its design is highly extensible: subclasses such as `NativeCodeGenerator` and `TrackingCodeGenerator` override specific behaviors, and the `@optimizeconst` decorator cleanly separates optimization concerns from code emission.
