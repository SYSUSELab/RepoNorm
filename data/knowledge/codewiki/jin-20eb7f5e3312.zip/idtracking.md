# idtracking

## Introduction

The `idtracking` module is a core part of Jinja2's **Parsing and Compilation Pipeline**. It is responsible for **symbol (identifier) tracking** during template compilation. Before Jinja2 can generate Python source code from a template's abstract syntax tree (AST), it must know, for every scope, which names are:

- **stored** (assigned to),
- **loaded** (read), and
- **declared as parameters** (e.g. macro arguments, loop targets).

The module resolves each name to a unique, scope-qualified Python identifier (a *reference*) and records how that reference should be initialized at runtime (as a parameter, a resolved context lookup, an alias to an outer scope, or an undefined placeholder).

This information is consumed by the [compiler](compiler.md) module, which uses the resulting `Symbols` objects to emit correct Python code for variable access, assignment, and scope handling.

---

## Purpose and Core Functionality

The `idtracking` module answers the question: *"For a given AST node, what variables exist in its scope, and how should each be referenced in generated code?"*

Its responsibilities include:

1. **Scope-aware name resolution** — Each scope (template root, block, macro, loop, `with`, `if` branch, etc.) gets its own `Symbols` object, linked to a parent scope.
2. **Reference generation** — Names are mapped to unique identifiers of the form `l_<level>_<name>` to avoid collisions between nested scopes.
3. **Load instruction classification** — Every reference is tagged with how it must be initialized at runtime.
4. **Branch merging** — When control flow branches (e.g. `if`/`elif`/`else`), the symbol tables of each branch are merged, and names that are not assigned on *all* branches are downgraded to runtime resolution.
5. **Parameter tracking** — Macro/loop parameters are tracked so the compiler can skip undefined checks for them.

---

## Architecture

The module is built around three cooperating classes and two convenience functions.

```mermaid
graph TD
    subgraph "idtracking module"
        FS[find_symbols]
        SFN[symbols_for_node]
        S[Symbols]
        RV[RootVisitor]
        FSV[FrameSymbolVisitor]
    end

    FS --> S
    FS --> FSV
    SFN --> S
    S --> RV
    RV --> FSV
    FSV --> S

    RV -.inherits.-> NV[NodeVisitor]
    FSV -.inherits.-> NV
    NV -.defined in.-> VIS[visitor module]
    RV -.visits.-> NODES[nodes module]
    FSV -.visits.-> NODES
```

### Component Overview

| Component | Role |
|-----------|------|
| `Symbols` | The central data structure. Holds `refs`, `loads`, and `stores` for one scope, plus a link to its parent scope. |
| `RootVisitor` | A `NodeVisitor` that walks the *top level* of a scope, deciding which child nodes belong to the current scope and which introduce new scopes. |
| `FrameSymbolVisitor` | A `NodeVisitor` that walks *within* a scope, recording name loads/stores/parameters into a `Symbols` object. |
| `find_symbols()` | Convenience function: builds a `Symbols` for an iterable of nodes using a `FrameSymbolVisitor`. |
| `symbols_for_node()` | Convenience function: builds a `Symbols` for a single node using `Symbols.analyze_node`. |

---

## Core Components

### `Symbols`

`Symbols` is the heart of the module. Each instance represents the symbol table for a single lexical scope.

**Key attributes:**

- `level` — the nesting depth of the scope (root = 0).
- `parent` — the enclosing `Symbols` object (or `None` for the root).
- `refs: Dict[str, str]` — maps a template name to its generated Python reference (e.g. `"foo" -> "l_1_foo"`).
- `loads: Dict[str, Tuple[str, Optional[str]]]` — maps a reference to a *load instruction* describing how to initialize it.
- `stores: Set[str]` — the set of names assigned within this scope.

**Load instruction constants:**

| Constant | Value | Meaning |
|----------|-------|---------|
| `VAR_LOAD_PARAMETER` | `"param"` | The reference is a function parameter (always defined). |
| `VAR_LOAD_RESOLVE` | `"resolve"` | The reference must be resolved from the runtime context. |
| `VAR_LOAD_ALIAS` | `"alias"` | The reference aliases a variable in an outer scope. |
| `VAR_LOAD_UNDEFINED` | `"undefined"` | The reference starts as `missing`/undefined. |

**Key methods:**

- `analyze_node(node, **kwargs)` — runs a `RootVisitor` over a node to populate this scope.
- `_define_ref(name, load)` — creates the `l_<level>_<name>` identifier and records its load instruction.
- `find_load(target)` / `find_ref(name)` — look up a load instruction or reference, walking up the parent chain.
- `ref(name)` — resolve a name to its reference, raising `AssertionError` if unknown.
- `store(name)` — record an assignment. If the name is not yet referenced, it is aliased to an outer scope (if one exists) or marked undefined.
- `declare_parameter(name)` — record a parameter declaration.
- `load(name)` — record a read; if unknown, mark it for runtime resolution.
- `branch_update(branch_symbols)` — merge the symbol tables of sibling branches (see below).
- `copy()` — shallow-copy the symbol table (used for branch analysis).
- `dump_stores()` — collect all stored names across the scope chain, mapped to references.
- `dump_param_targets()` — collect all parameter references across the scope chain.

### `RootVisitor`

`RootVisitor` extends `NodeVisitor` (from the [visitor](visitor.md) module). It is responsible for **scope boundaries**: it decides which nodes are analyzed in the current scope and which are delegated to a `FrameSymbolVisitor`.

It defines specialized handling for nodes that introduce or partition scopes:

- `visit_Template`, `visit_Block`, `visit_Macro`, `visit_FilterBlock`, `visit_Scope`, `visit_If`, `visit_ScopedEvalContextModifier` — all use `_simple_visit`, which forwards each child to the `FrameSymbolVisitor`.
- `visit_AssignBlock` — only visits the block body.
- `visit_CallBlock` — visits all children except the `call` field.
- `visit_OverlayScope` — visits only the body.
- `visit_For` — handles the `body`, `else`, and `test` branches separately, treating the loop target as a parameter.
- `visit_With` — visits targets and body.
- `generic_visit` — raises `NotImplementedError` for any unhandled node type, ensuring new node types are explicitly considered.

### `FrameSymbolVisitor`

`FrameSymbolVisitor` extends `NodeVisitor` and performs the actual name recording within a scope. Its most important method is `visit_Name`, which dispatches based on the node's `ctx`:

```mermaid
flowchart TD
    A[visit_Name] --> B{store_as_param or ctx == param?}
    B -->|yes| C[declare_parameter]
    B -->|no| D{ctx == store?}
    D -->|yes| E[store]
    D -->|no| F{ctx == load?}
    F -->|yes| G[load]
```

Other notable visitors:

- `visit_If` — copies the symbol table for each branch (`body`, `elif_`, `else_`), analyzes each independently, then calls `branch_update` to merge them.
- `visit_Macro` — stores the macro name.
- `visit_Import` / `visit_FromImport` — stores imported names.
- `visit_Assign` — visits the value *before* the target (correct evaluation order).
- `visit_For` — stops at the loop body (the body is a new scope handled by `RootVisitor`), but visits the iterable.
- `visit_Scope`, `visit_Block`, `visit_OverlayScope` — deliberately stop visiting, as these introduce new scopes.

---

## Data Flow

The following diagram shows how a template AST flows through the idtracking module and into the compiler.

```mermaid
sequenceDiagram
    participant CG as CodeGenerator (compiler)
    participant Frame as Frame (compiler)
    participant Sym as Symbols
    participant RV as RootVisitor
    participant FSV as FrameSymbolVisitor

    CG->>Frame: create Frame(eval_ctx)
    Frame->>Sym: Symbols(level=0)
    CG->>Sym: analyze_node(template_node)
    Sym->>RV: RootVisitor(sym).visit(node)
    RV->>FSV: visit(child) for in-scope children
    FSV->>Sym: store() / load() / declare_parameter()
    Sym-->>CG: refs, loads, stores populated
    CG->>Sym: ref(name) / find_load(ref)
    CG->>CG: emit Python source using references
```

### Branch Merging (`branch_update`)

When an `if`/`elif`/`else` construct is analyzed, each branch is analyzed against a *copy* of the current symbol table. The results are then merged:

```mermaid
flowchart TD
    A[visit_If] --> B[copy symbols for body]
    A --> C[copy symbols for elif]
    A --> D[copy symbols for else]
    B --> E[branch_update]
    C --> E
    D --> E
    E --> F{Name stored in ALL branches?}
    F -->|yes| G[keep as-is]
    F -->|no| H{Exists in parent scope?}
    H -->|yes| I[mark as VAR_LOAD_ALIAS]
    H -->|no| J[mark as VAR_LOAD_RESOLVE]
```

This ensures that a variable assigned in only *some* branches is correctly resolved at runtime rather than assumed to be defined.

---

## Component Interaction

The idtracking module sits between the AST definition and the code generator.

```mermaid
graph LR
    subgraph "Parsing & Compilation Pipeline"
        LEX[lexer] --> PAR[parser]
        PAR --> NODES[nodes]
        NODES --> IDT[idtracking]
        IDT --> COMP[compiler]
        COMP --> OPT[optimizer]
        OPT --> META[meta]
    end
    VIS[visitor] -.provides NodeVisitor.-> IDT
    IDT -.provides Symbols.-> COMP
```

- **Input:** AST nodes from the [nodes](nodes.md) module, produced by the [parser](parser.md).
- **Base class:** `NodeVisitor` from the [visitor](visitor.md) module.
- **Output:** `Symbols` objects consumed by the [compiler](compiler.md) module's `Frame` and `CodeGenerator`.

### Relationship with `Frame` (compiler)

The compiler's `Frame` class owns a `Symbols` instance. When a new scope is entered, `Frame.inner()` creates a child `Frame` whose `Symbols` has the parent's `Symbols` as its `parent`. This is how scope nesting is represented:

```mermaid
graph TD
    RF[Root Frame<br/>Symbols level 0] --> BF[Block Frame<br/>Symbols level 1]
    RF --> MF[Macro Frame<br/>Symbols level 1]
    MF --> LF[Loop Frame<br/>Symbols level 2]
    BF --> IF[If Frame<br/>Symbols level 2]
```

The compiler then uses `frame.symbols.ref(name)` to emit the correct Python identifier, and `frame.symbols.loads` (via `enter_frame`) to emit initialization code such as:

```python
l_1_foo = resolve('foo')      # VAR_LOAD_RESOLVE
l_1_bar = l_0_bar             # VAR_LOAD_ALIAS
l_1_baz = missing             # VAR_LOAD_UNDEFINED
```

---

## Process Flow: Analyzing a Node

```mermaid
flowchart TD
    Start([analyze_node called]) --> CreateRV[Create RootVisitor]
    CreateRV --> Visit[RootVisitor.visit node]
    Visit --> Dispatch{Node type?}
    Dispatch -->|scope-introducing| Simple[_simple_visit: forward children to FrameSymbolVisitor]
    Dispatch -->|For| ForBranch[Handle body/else/test branches]
    Dispatch -->|With| WithBranch[Visit targets + body]
    Dispatch -->|unknown| Error[Raise NotImplementedError]
    Simple --> FSV[FrameSymbolVisitor records names]
    ForBranch --> FSV
    WithBranch --> FSV
    FSV --> Done([Symbols populated])
```

---

## Summary

The `idtracking` module is a focused but essential stage in Jinja2's compilation pipeline. By separating **scope boundary detection** (`RootVisitor`) from **name recording** (`FrameSymbolVisitor`) and centralizing state in `Symbols`, it provides the compiler with a precise, scope-aware map of every identifier in a template. This enables correct code generation for variable access, assignment, aliasing, and undefined-variable handling across arbitrarily nested scopes.

### Related Documentation

- [compiler](compiler.md) — consumes `Symbols` to generate Python source.
- [nodes](nodes.md) — defines the AST node types visited here.
- [visitor](visitor.md) — provides the `NodeVisitor` base class.
- [parser](parser.md) — produces the AST that this module analyzes.
- [meta](meta.md) — uses a related `TrackingCodeGenerator` for template introspection.
