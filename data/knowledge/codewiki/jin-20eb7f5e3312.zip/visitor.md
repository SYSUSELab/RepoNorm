# Visitor Module

## Introduction

The `visitor` module (`src/jinja2/visitor.py`) provides the foundational **Abstract Syntax Tree (AST) traversal API** used throughout Jinja2's parsing and compilation pipeline. It implements the classic [Visitor design pattern](https://en.wikipedia.org/wiki/Visitor_pattern), offering two complementary base classes:

- **`NodeVisitor`** — a read-only walker that dispatches to per-node-type handler methods.
- **`NodeTransformer`** — a mutating walker that can replace, remove, or expand nodes in place.

These classes are the backbone for nearly every stage that operates on the Jinja AST: optimization, dependency analysis, symbol tracking, and code generation. Rather than each subsystem re-implementing tree traversal, they all subclass these two classes and override only the node types they care about.

> **Related documentation:** The nodes being traversed are defined in the [nodes module](nodes.md). The primary consumers are the [compiler module](compiler.md), the [optimizer module](optimizer.md), the [meta module](meta.md), and the [idtracking module](idtracking.md).

---

## Purpose and Core Functionality

The module answers a single question: *"How do I walk a Jinja AST and act on specific node types?"*

It provides:

1. **Dynamic dispatch** — visitor methods are resolved by node class name (`visit_<ClassName>`), so adding a new node type requires no changes to the traversal engine.
2. **A generic fallback** — `generic_visit` recursively descends into child nodes when no specific handler exists.
3. **In-place mutation** — `NodeTransformer` uses the return value of handlers to replace or delete nodes.
4. **Extensibility hooks** — `get_visitor` can be overridden to change dispatch behavior.

---

## Architecture

The module is intentionally small and dependency-light. It depends only on the `Node` base class from the [nodes module](nodes.md).

```mermaid
graph TD
    subgraph visitor["visitor.py"]
        NV["NodeVisitor"]
        NT["NodeTransformer"]
        VC["VisitCallable (Protocol)"]
    end

    Node["nodes.Node"]

    NV -->|"uses"| Node
    NT -->|"extends"| NV
    VC -.->|"type hint for"| NV

    subgraph consumers["Consumers (other modules)"]
        OPT["optimizer.Optimizer"]
        DFV["compiler.DependencyFinderVisitor"]
        UNV["compiler.UndeclaredNameVisitor"]
        FSV["idtracking.FrameSymbolVisitor"]
        RV["idtracking.RootVisitor"]
    end

    OPT -->|"extends"| NT
    DFV -->|"extends"| NV
    UNV -->|"extends"| NV
    FSV -->|"extends"| NV
    RV -->|"extends"| NV
```

### Class Hierarchy

```mermaid
classDiagram
    class NodeVisitor {
        +get_visitor(node) VisitCallable
        +visit(node, *args, **kwargs) Any
        +generic_visit(node, *args, **kwargs) Any
    }
    class NodeTransformer {
        +generic_visit(node, *args, **kwargs) Node
        +visit_list(node, *args, **kwargs) List~Node~
    }
    class VisitCallable {
        <<Protocol>>
        +__call__(node, *args, **kwargs) Any
    }

    NodeVisitor <|-- NodeTransformer
    VisitCallable ..> NodeVisitor : type hint
```

---

## Core Components

### `NodeVisitor`

The read-only traversal base class. It walks the AST and invokes visitor functions for every node found. Visitor functions may return values, which are forwarded by the `visit` method.

**Dispatch convention:** For a node of class `TryFinally`, the handler is `visit_TryFinally`. This is resolved dynamically via `get_visitor`.

| Method | Responsibility |
| --- | --- |
| `get_visitor(node)` | Returns the handler for a node, or `None` if none exists. Default implementation looks up `visit_<ClassName>` via `getattr`. |
| `visit(node, *args, **kwargs)` | Entry point. Resolves the handler and calls it; falls back to `generic_visit` when no handler exists. |
| `generic_visit(node, *args, **kwargs)` | Default behavior: recursively visits every direct child node via `node.iter_child_nodes()`. |

**Key design points:**

- The `*args` / `**kwargs` are threaded through every call, allowing subclasses to pass contextual state (e.g., `store_as_param=True` in `FrameSymbolVisitor`).
- Overriding `get_visitor` allows alternative dispatch schemes (e.g., mapping multiple node types to one handler).
- Returning a value from a handler is meaningful only to the caller of `visit`; `NodeVisitor` itself does not use return values.

### `NodeTransformer`

A subclass of `NodeVisitor` that **modifies the AST in place**. It uses the return value of visitor functions to replace or remove nodes.

**Replacement semantics in `generic_visit`:**

| Handler return value | Effect on the node |
| --- | --- |
| `None` | Node is **removed** (deleted from its parent field or dropped from a list). |
| A `Node` | Node is **replaced** with the returned node. |
| The original node | No change (identity replacement). |
| A `list` of nodes (inside a list field) | The list is **spliced** into the parent list. |

The transformer iterates over `node.iter_fields()` and handles both list-valued fields and single-node fields:

```mermaid
flowchart TD
    Start["generic_visit(node)"] --> Loop{"For each field"}
    Loop -->|"field is list"| ListLoop["For each value in list"]
    ListLoop --> IsNode{"value is Node?"}
    IsNode -->|"yes"| Visit["value = self.visit(value)"]
    Visit --> IsNone{"value is None?"}
    IsNone -->|"yes"| Skip["skip (remove)"]
    IsNone -->|"no"| IsList{"value is list?"}
    IsList -->|"yes"| Extend["extend new_values"]
    IsList -->|"no"| Append["append value"]
    IsNode -->|"no"| Append
    Loop -->|"field is Node"| VisitSingle["new_node = self.visit(old_value)"]
    VisitSingle --> SingleNone{"new_node is None?"}
    SingleNone -->|"yes"| Del["delattr(node, field)"]
    SingleNone -->|"no"| Set["setattr(node, field, new_node)"]
    Skip --> ListLoop
    Extend --> ListLoop
    Append --> ListLoop
    Del --> Loop
    Set --> Loop
    Loop -->|"done"| Return["return node"]
```

**`visit_list` helper:** Because transformers may return lists in some places, `visit_list` normalizes the result of `visit` into a list, wrapping a single value if necessary. This is useful when a handler is expected to always produce a list of nodes.

### `VisitCallable`

A `typing.Protocol` (defined only under `TYPE_CHECKING`) describing the callable signature of a visitor function:

```python
def __call__(self, node: Node, *args: t.Any, **kwargs: t.Any) -> t.Any: ...
```

It exists purely for static type checking and has no runtime footprint.

---

## Data Flow

The visitor module sits at the center of the AST-processing pipeline. The following diagram shows how a parsed AST flows through the various visitor-based stages.

```mermaid
flowchart LR
    Parser["parser.Parser"] -->|"produces"| AST["AST (nodes.Node)"]
    AST --> Optimizer["optimizer.Optimizer\n(NodeTransformer)"]
    Optimizer -->|"optimized AST"| Compiler["compiler.CodeGenerator\n(NodeVisitor)"]
    AST --> Meta["meta.TrackingCodeGenerator\n(CodeGenerator)"]
    AST --> IdTrack["idtracking.RootVisitor\n(NodeVisitor)"]
    IdTrack --> FrameSym["idtracking.FrameSymbolVisitor\n(NodeVisitor)"]
    Compiler --> DepFind["compiler.DependencyFinderVisitor\n(NodeVisitor)"]
    Compiler --> Undecl["compiler.UndeclaredNameVisitor\n(NodeVisitor)"]
```

Each stage subclasses `NodeVisitor` or `NodeTransformer` and overrides only the handlers relevant to its task.

---

## Component Interaction

The table below summarizes how each consumer in the codebase uses the visitor API. This illustrates the module's role as a shared traversal framework.

| Consumer | Base class | Purpose | Notable overrides |
| --- | --- | --- | --- |
| [`optimizer.Optimizer`](optimizer.md) | `NodeTransformer` | Constant folding of expressions | `generic_visit` (folds `Expr` nodes into `Const`) |
| [`compiler.DependencyFinderVisitor`](compiler.md) | `NodeVisitor` | Collects filter and test names used | `visit_Filter`, `visit_Test`, `visit_Block` (stops at blocks) |
| [`compiler.UndeclaredNameVisitor`](compiler.md) | `NodeVisitor` | Detects names accessed without declaration | `visit_Name`, `visit_Block` |
| [`idtracking.FrameSymbolVisitor`](idtracking.md) | `NodeVisitor` | Tracks symbol load/store/param within a frame | `visit_Name`, `visit_If`, `visit_For`, `visit_Macro`, etc. |
| [`idtracking.RootVisitor`](idtracking.md) | `NodeVisitor` | Finds symbols at the root scope | `visit_Template`, `visit_For`, `visit_With`, etc. |
| [`meta.TrackingCodeGenerator`](meta.md) | `CodeGenerator` (→ `NodeVisitor`) | Introspects undeclared identifiers | `enter_frame` |

### Interaction Pattern

```mermaid
sequenceDiagram
    participant Client as "Client (e.g. Optimizer)"
    participant NT as "NodeTransformer"
    participant NV as "NodeVisitor"
    participant Node as "nodes.Node"

    Client->>NT: visit(root_node)
    NT->>NV: get_visitor(node)
    NV-->>NT: visit_<ClassName> or None
    alt handler exists
        NT->>Client: handler(node, *args, **kwargs)
        Client-->>NT: replacement / None / node
    else no handler
        NT->>NT: generic_visit(node)
        NT->>Node: iter_fields() / iter_child_nodes()
        Node-->>NT: child nodes
        NT->>NT: recurse into children
    end
    NT-->>Client: transformed node
```

---

## Process Flow: How a Node Is Visited

```mermaid
flowchart TD
    A["visit(node)"] --> B["get_visitor(node)"]
    B --> C{"handler found?"}
    C -->|"yes"| D["call handler(node, *args, **kwargs)"]
    C -->|"no"| E["generic_visit(node)"]
    D --> F["return handler result"]
    E --> G["iterate child nodes"]
    G --> H["visit(child) for each"]
    H --> F
```

For `NodeTransformer`, the `generic_visit` step additionally applies the replacement/removal semantics described above.

---

## Design Considerations

- **Separation of concerns:** The traversal engine knows nothing about Jinja semantics. All domain logic lives in the subclasses' handlers.
- **Performance:** Dispatch is a simple `getattr` lookup per node. Handlers that want to prune traversal (e.g., stop at block boundaries) simply override `generic_visit` or the relevant `visit_*` method without calling `super()`.
- **Mutation safety:** `NodeTransformer.generic_visit` mutates list fields in place (`old_value[:] = new_values`) and uses `delattr`/`setattr` for scalar fields, ensuring the tree structure stays consistent.
- **Type safety:** `VisitCallable` provides a typed contract for handler signatures without imposing runtime overhead.

---

## Summary

The `visitor` module is a compact but critical piece of Jinja2's infrastructure. By providing `NodeVisitor` and `NodeTransformer`, it enables every AST-processing stage — optimization, dependency analysis, symbol tracking, and code generation — to share a single, well-tested traversal mechanism. Understanding this module is a prerequisite for understanding the [compiler](compiler.md), [optimizer](optimizer.md), [meta](meta.md), and [idtracking](idtracking.md) modules, all of which build directly on top of it.
