# Meta Module

## Introduction

The `meta` module (`src/jinja2/meta.py`) provides **introspection utilities** for Jinja templates. It exposes information about a parsed template's abstract syntax tree (AST) that is useful for static analysis, dependency tracking, and tooling — without ever rendering the template.

The module answers two key questions about a template:

1. **Which variables will be looked up from the context at runtime?** — via `find_undeclared_variables`.
2. **Which other templates does this template reference?** — via `find_referenced_templates`.

These capabilities are essential for build systems, cache invalidation, IDE tooling, and any application that needs to understand template dependencies ahead of time.

> **Note:** The module is intentionally small. Its core trick is *abusing the compiler* — it subclasses the normal code generator and disables its output, using it purely as a traversal engine to collect information.

---

## Architecture Overview

The `meta` module sits at the boundary between the **Parsing & Compilation Pipeline** and external tooling. It reuses the compiler's AST traversal machinery rather than implementing its own walker.

```mermaid
graph TD
    subgraph "Parsing & Compilation Pipeline"
        Parser["Parser<br/>(parser.py)"]
        Nodes["AST Nodes<br/>(nodes.py)"]
        Compiler["CodeGenerator<br/>(compiler.py)"]
        IDTrack["Symbols / idtracking<br/>(idtracking.py)"]
        Visitor["NodeVisitor<br/>(visitor.py)"]
    end

    subgraph "Meta Module"
        TCG["TrackingCodeGenerator"]
        FUV["find_undeclared_variables()"]
        FRT["find_referenced_templates()"]
    end

    subgraph "Environment"
        Env["Environment<br/>(environment.py)"]
    end

    Env -->|"parse()"| Parser
    Parser -->|"produces"| Nodes
    Nodes -->|"input to"| FUV
    Nodes -->|"input to"| FRT

    FUV -->|"instantiates"| TCG
    TCG -->|"extends"| Compiler
    Compiler -->|"extends"| Visitor
    Compiler -->|"uses"| IDTrack
    TCG -->|"reads environment.globals"| Env

    FRT -->|"walks nodes via find_all()"| Nodes
```

### Key Design Principle

`TrackingCodeGenerator` **inherits from `CodeGenerator`** but overrides two methods:

- `write()` — becomes a no-op, so no Python source is ever emitted.
- `enter_frame()` — records every symbol that the compiler would have resolved from the context.

This means the meta module automatically stays in sync with the compiler's understanding of variable resolution. See [compiler.md](compiler.md) for the full compilation pipeline and [idtracking.md](idtracking.md) for how symbols and loads are tracked.

---

## Core Components

### `TrackingCodeGenerator`

A subclass of `CodeGenerator` that performs a "dry run" of compilation to collect undeclared identifiers.

```python
class TrackingCodeGenerator(CodeGenerator):
    """We abuse the code generator for introspection."""

    def __init__(self, environment: "Environment") -> None:
        super().__init__(environment, "<introspection>", "<introspection>")
        self.undeclared_identifiers: t.Set[str] = set()

    def write(self, x: str) -> None:
        """Don't write."""

    def enter_frame(self, frame: Frame) -> None:
        """Remember all undeclared identifiers."""
        super().enter_frame(frame)

        for _, (action, param) in frame.symbols.loads.items():
            if action == "resolve" and param not in self.environment.globals:
                self.undeclared_identifiers.add(param)
```

**Responsibilities:**

| Member | Purpose |
| --- | --- |
| `undeclared_identifiers` | Accumulates the set of names resolved from the context. |
| `write()` | Overridden to suppress all code output (introspection only). |
| `enter_frame()` | Inspects each frame's symbol loads; records `resolve` actions whose name is not a global. |

**How it works:**

1. The generator is constructed with a placeholder name/filename (`"<introspection>"`).
2. `visit(ast)` triggers the inherited `NodeVisitor` traversal over the AST.
3. As the compiler walks frames, `enter_frame` is called for each frame.
4. For every symbol load with action `"resolve"` (i.e., a name that must be looked up from the runtime context) that is **not** present in `environment.globals`, the name is added to `undeclared_identifiers`.

The `"resolve"` action corresponds to `VAR_LOAD_RESOLVE` in the compiler's symbol tracking. Names that are parameters, aliases, or undefined are ignored — only genuine context lookups are collected.

---

### `find_undeclared_variables(ast)`

Returns the set of all variables in the AST that will be looked up from the context at runtime.

```python
def find_undeclared_variables(ast: nodes.Template) -> t.Set[str]:
    codegen = TrackingCodeGenerator(ast.environment)
    codegen.visit(ast)
    return codegen.undeclared_identifiers
```

**Behavior:**

- Because the runtime execution path is unknown at compile time, **all** potentially-used variables are returned, regardless of which branch would actually execute.
- The function relies on `ast.environment` being set (the parser sets this automatically on every node).

**Example:**

```python
>>> from jinja2 import Environment, meta
>>> env = Environment()
>>> ast = env.parse('{% set foo = 42 %}{{ bar + foo }}')
>>> meta.find_undeclared_variables(ast) == {'bar'}
True
```

Note that `foo` is *not* returned — it is assigned within the template, so it is not looked up from the context.

> **Implementation caveat:** Internally the code generator is used, which means this function can raise a `TemplateAssertionError` during compilation (e.g., for duplicate blocks or invalid constructs). See [exceptions.md](exceptions.md).

---

### `find_referenced_templates(ast)`

Returns an iterator over all hardcoded template names referenced by `extends`, `include`, `import`, and `from import` statements. When a reference is dynamic (not a constant string), `None` is yielded.

```python
_ref_types = (nodes.Extends, nodes.FromImport, nodes.Import, nodes.Include)

def find_referenced_templates(ast: nodes.Template) -> t.Iterator[t.Optional[str]]:
    ...
```

**Behavior:**

- Walks the AST using `ast.find_all(_ref_types)` to locate all reference nodes.
- For each node, inspects the `template` field:
  - **Constant string** → yields the string.
  - **Tuple/List of constants** → yields each string element; yields `None` for non-string or dynamic elements.
  - **Dynamic expression** → yields `None`.

**Example:**

```python
>>> from jinja2 import Environment, meta
>>> env = Environment()
>>> ast = env.parse('{% extends "layout.html" %}{% include helper %}')
>>> list(meta.find_referenced_templates(ast))
['layout.html', None]
```

Here `"layout.html"` is a static reference, while `helper` is a dynamic variable, so `None` is yielded.

**Use case:** Dependency tracking. For example, rebuilding parts of a website when a layout template changes.

---

## Data Flow

The following diagram shows how a template source flows through parsing into the meta functions.

```mermaid
sequenceDiagram
    participant User
    participant Env as Environment
    participant Parser
    participant AST as nodes.Template
    participant Meta as meta module
    participant TCG as TrackingCodeGenerator

    User->>Env: parse(source)
    Env->>Parser: Parser(env, source).parse()
    Parser-->>AST: AST with environment set
    AST-->>User: return AST

    User->>Meta: find_undeclared_variables(ast)
    Meta->>TCG: TrackingCodeGenerator(ast.environment)
    Meta->>TCG: visit(ast)
    TCG->>TCG: enter_frame() per frame
    TCG-->>Meta: undeclared_identifiers
    Meta-->>User: set of names

    User->>Meta: find_referenced_templates(ast)
    Meta->>AST: find_all(Extends, Import, FromImport, Include)
    AST-->>Meta: reference nodes
    Meta-->>User: iterator of names / None
```

---

## Component Interaction

```mermaid
classDiagram
    class NodeVisitor {
        +visit(node)
        +generic_visit(node)
        +get_visitor(node)
    }
    class CodeGenerator {
        +environment
        +write(x)
        +enter_frame(frame)
        +visit_Template(node)
    }
    class TrackingCodeGenerator {
        +undeclared_identifiers: Set~str~
        +write(x)
        +enter_frame(frame)
    }
    class Frame {
        +symbols: Symbols
    }
    class Symbols {
        +loads: Dict
        +refs: Dict
        +stores: Set
    }

    NodeVisitor <|-- CodeGenerator
    CodeGenerator <|-- TrackingCodeGenerator
    CodeGenerator --> Frame
    Frame --> Symbols
```

The inheritance chain `NodeVisitor → CodeGenerator → TrackingCodeGenerator` is the backbone of the module. By overriding only `write` and `enter_frame`, the tracking generator reuses all of the compiler's AST traversal logic while collecting introspection data as a side effect.

---

## Process Flow: Finding Undeclared Variables

```mermaid
flowchart TD
    Start([find_undeclared_variables]) --> Create[Create TrackingCodeGenerator<br/>with ast.environment]
    Create --> Visit[codegen.visit ast]
    Visit --> Walk[Traverse AST via NodeVisitor]
    Walk --> Frame[enter_frame called per frame]
    Frame --> Loop{For each symbol load}
    Loop -->|action == resolve| Check{param in<br/>environment.globals?}
    Check -->|No| Add[Add param to<br/>undeclared_identifiers]
    Check -->|Yes| Skip[Skip - it's a global]
    Loop -->|other action| Skip2[Skip - param/alias/undefined]
    Add --> Done{More loads?}
    Skip --> Done
    Skip2 --> Done
    Done -->|Yes| Loop
    Done -->|No| Return([Return undeclared_identifiers])
```

---

## Relationship to Other Modules

| Module | Relationship |
| --- | --- |
| [compiler.md](compiler.md) | `TrackingCodeGenerator` subclasses `CodeGenerator` and reuses `Frame` and the `enter_frame` hook. |
| [idtracking.md](idtracking.md) | The `Symbols.loads` mapping (with `VAR_LOAD_RESOLVE` actions) is the source of undeclared-variable information. |
| [nodes.md](nodes.md) | `find_referenced_templates` walks `Extends`, `Import`, `FromImport`, and `Include` nodes via `Node.find_all`. |
| [visitor.md](visitor.md) | The traversal mechanism (`NodeVisitor.visit`) inherited by the code generator. |
| [parser.md](parser.md) | Produces the `nodes.Template` AST consumed by both meta functions. |
| [environment.md](environment.md) | Provides `parse()` to build the AST and `globals` used to filter undeclared names. |
| [exceptions.md](exceptions.md) | `find_undeclared_variables` may raise `TemplateAssertionError` during compilation. |

---

## Summary

The `meta` module is a compact but powerful introspection layer:

- **`TrackingCodeGenerator`** — a compiler subclass that suppresses output and records context-resolved names.
- **`find_undeclared_variables(ast)`** — returns the set of variables looked up from the context.
- **`find_referenced_templates(ast)`** — returns an iterator of statically-referenced template names (with `None` for dynamic references).

Its design philosophy is *reuse over reimplementation*: rather than writing a separate AST analyzer, it leverages the existing compiler pipeline, ensuring that introspection results stay consistent with actual compilation behavior.
