# Template Environment and Loading

## Purpose

The `Template_Environment_and_Loading` module is the configuration and resource-management layer of Jinja2. It is responsible for:

- **Centralizing configuration** through the `Environment` class, which holds all shared state (delimiters, filters, tests, globals, policies, extensions) used across template rendering.
- **Loading templates** from a variety of sources (filesystem, Python packages, dictionaries, functions, modules, and caches) via a pluggable loader abstraction.
- **Caching compiled templates** in memory and on disk (bytecode cache) to avoid repeated parsing and compilation.
- **Providing sandboxed execution** for untrusted templates by restricting attribute access and operator usage.
- **Supporting native Python types** in rendered output through the `NativeEnvironment` variant.

Together these components form the entry point for users of Jinja2: an `Environment` (or subclass) is instantiated, configured with a loader, and then used to `get_template()` / `from_string()` and render templates.

## Architecture

The module is composed of five cooperating submodules. The `Environment` acts as the hub, delegating template retrieval to a `BaseLoader` implementation, caching results through the bytecode cache, and optionally enforcing sandboxing or native-type semantics.

```mermaid
graph TD
    subgraph "Template_Environment_and_Loading"
        ENV["environment.py<br/>Environment, Template"]
        LOAD["loaders.py<br/>BaseLoader + implementations"]
        BCC["bccache.py<br/>BytecodeCache + backends"]
        SBX["sandbox.py<br/>SandboxedEnvironment"]
        NAT["nativetypes.py<br/>NativeEnvironment"]
    end

    ENV -->|"uses loader to fetch source"| LOAD
    ENV -->|"caches compiled code"| BCC
    ENV -->|"subclassed by"| SBX
    ENV -->|"subclassed by"| NAT
    SBX -->|"inherits config/loading"| ENV
    NAT -->|"inherits config/loading"| ENV
    LOAD -->|"returns source + metadata"| ENV
    BCC -->|"stores/retrieves bytecode"| ENV

    subgraph "Downstream consumers"
        PARSE["Parsing_and_Compilation_Pipeline"]
        RUNTIME["Runtime_Execution_Support"]
    end
    ENV -->|"compiles via"| PARSE
    ENV -->|"renders via"| RUNTIME
```

### Component Roles

| Component | Role |
|-----------|------|
| `environment.py` | Defines `Environment` (shared config, template compilation, rendering) and `Template` (a compiled template bound to an environment). |
| `loaders.py` | Defines `BaseLoader` and concrete loaders (`FileSystemLoader`, `PackageLoader`, `DictLoader`, `FunctionLoader`, `ModuleLoader`, `PrefixLoader`, `ChoiceLoader`, `DispatchingLoader`). |
| `bccache.py` | Defines `BytecodeCache` and backends (`FileSystemBytecodeCache`, `MemcachedBytecodeCache`) for persisting compiled template bytecode. |
| `sandbox.py` | Defines `SandboxedEnvironment` and `ImmutableSandboxedEnvironment`, restricting unsafe attribute/operator access. |
| `nativetypes.py` | Defines `NativeEnvironment` and `NativeTemplate`, which render to native Python objects instead of strings. |

## Core Components

- [Environment and Template](./environment.md) — the central configuration object and compiled template representation.
- [Loaders](./loaders.md) — pluggable template source resolution.
- [Bytecode Cache](./bccache.md) — persistent caching of compiled templates.
- [Sandbox](./sandbox.md) — restricted execution environment for untrusted templates.
- [Native Types](./nativetypes.md) — rendering to native Python data structures.