# Parser Module

## Introduction

The `parser` module (`src/jinja2/parser.py`) is the central component of Jinja's
**Parsing and Compilation Pipeline**. It consumes the flat stream of tokens
produced by the [lexer](lexer.md) and transforms them into a structured
**Abstract Syntax Tree (AST)** composed of [node](nodes.md) objects. This AST is
the intermediate representation that the [compiler](compiler.md) later turns into
executable Python code.

The module exposes a single public class, `Parser`, which is responsible for:

- Recognizing Jinja **statements** (`{% ... %}`) such as `for`, `if`, `block`,
  `macro`, `set`, `include`, `import`, `extends`, `with`, `autoescape`, etc.
- Recognizing Jinja **expressions** (`{{ ... }}`) including the full operator
  precedence hierarchy (conditional, boolean, comparison, math, unary, postfix,
  filters, and tests).
- Producing a `nodes.Template` root node that wraps the entire parsed body.
- Providing human-readable syntax error messages via `TemplateSyntaxError`.

The parser is invoked by the [Environment](environment.md) through
`Environment._parse`, which is called by `Environment.parse` and
`Environment.compile`.

---

## Architecture Overview

The parser sits between the lexer and the compiler in the pipeline. It is the
only stage that understands Jinja's grammar and produces the node tree.

```mermaid
flowchart LR
    Source["Template Source<br/>(str)"] --> Env["Environment._tokenize"]
    Env --> Lexer["Lexer<br/>(lexer.py)"]
    Lexer --> Stream["TokenStream"]
    Stream --> Parser["Parser<br/>(parser.py)"]
    Parser --> AST["nodes.Template<br/>(AST)"]
    AST --> Compiler["CodeGenerator<br/>(compiler.py)"]
    Compiler --> Code["Python Code / Bytecode"]

    Parser -. "uses" .-> Nodes["nodes.py<br/>(AST node classes)"]
    Parser -. "raises" .-> Exceptions["exceptions.py<br/>(TemplateSyntaxError)"]
    Parser -. "extensions" .-> Ext["ext.py<br/>(Extension.parse)"]
```

### Position in the Pipeline

| Stage | Module | Input | Output |
|-------|--------|-------|--------|
| Lexing | [lexer](lexer.md) | source string | `TokenStream` |
| **Parsing** | **parser** | `TokenStream` | `nodes.Template` (AST) |
| Optimization | [optimizer](optimizer.md) | AST | optimized AST |
| Compilation | [compiler](compiler.md) | AST | Python code object |

---

## Core Component: `Parser`

The `Parser` class is the sole component of this module. It is a recursive
descent parser that maintains a cursor over a `TokenStream` and builds nodes as
it consumes tokens.

### Construction

```python
Parser(
    environment: Environment,
    source: str,
    name: Optional[str] = None,
    filename: Optional[str] = None,
    state: Optional[str] = None,
)
```

During construction the parser:

1. Stores a reference to the `Environment`.
2. Obtains a `TokenStream` by calling `environment._tokenize(source, name,
   filename, state)`. This applies extension preprocessing and stream filters.
3. Collects **extension tags** by iterating `environment.iter_extensions()` and
   mapping each `extension.tags` entry to `extension.parse`. This allows
   extensions to register custom statement keywords.
4. Initializes internal bookkeeping:
   - `_last_identifier` — counter for generating free identifiers.
   - `_tag_stack` — stack of currently open statement tags (for error messages).
   - `_end_token_stack` — stack of expected end tokens (for error messages).

### Key Instance Attributes

| Attribute | Type | Purpose |
|-----------|------|---------|
| `environment` | `Environment` | Shared configuration, filters, tests, extensions |
| `stream` | `TokenStream` | The token cursor being consumed |
| `name` / `filename` | `Optional[str]` | Used in error messages |
| `closed` | `bool` | Whether parsing has finished |
| `extensions` | `Dict[str, Callable]` | Tag name → extension parse function |
| `_last_identifier` | `int` | Counter for `free_identifier` |
| `_tag_stack` | `List[str]` | Open statement tags |
| `_end_token_stack` | `List[Tuple[str, ...]]` | Expected end tokens |

---

## Parsing Flow

The entry point is `Parser.parse()`, which delegates to `subparse()` to build
the body and wraps it in a `nodes.Template`.

```mermaid
flowchart TD
    Start["Parser.parse()"] --> Sub["subparse()"]
    Sub --> Loop{"More tokens?"}
    Loop -->|"data"| Data["Append TemplateData"]
    Loop -->|"variable_begin"| Var["parse_tuple()<br/>expect variable_end"]
    Loop -->|"block_begin"| Block["flush_data()<br/>parse_statement()<br/>expect block_end"]
    Loop -->|"end token matched"| Return["return body"]
    Loop -->|"eof"| Flush["flush_data()"]
    Data --> Loop
    Var --> Loop
    Block --> Loop
    Flush --> Return
    Return --> Wrap["nodes.Template(body)<br/>set_environment()"]
```

### `subparse(end_tokens=None)`

The workhorse of the parser. It repeatedly inspects `self.stream.current`:

- **`data` tokens** are buffered as `nodes.TemplateData` and later flushed into
  a single `nodes.Output` node.
- **`variable_begin`** triggers `parse_tuple()` for the expression, followed by
  an `expect("variable_end")`.
- **`block_begin`** flushes buffered data, then either returns (if the current
  token matches an `end_tokens` entry) or calls `parse_statement()`.
- When the stream is exhausted, buffered data is flushed.

The `end_tokens` parameter is pushed onto `_end_token_stack` so that error
messages can report what the parser was looking for.

### `parse_statement()`

Dispatches a single statement based on the leading name token:

```mermaid
flowchart TD
    Tok["current token (name)"] --> KW{"in _statement_keywords?"}
    KW -->|yes| Dyn["getattr(self, 'parse_' + value)()"]
    KW -->|no| Call{"value == 'call'?"}
    Call -->|yes| CB["parse_call_block()"]
    Call -->|no| Filter{"value == 'filter'?"}
    Filter -->|yes| FB["parse_filter_block()"]
    Filter -->|no| Ext{"registered extension?"}
    Ext -->|yes| EP["extension.parse(self)"]
    Ext -->|no| Fail["fail_unknown_tag()"]
```

The set of built-in statement keywords is defined by `_statement_keywords`:

```
for, if, block, extends, print, macro, include, from, import, set, with, autoescape
```

Two additional block forms (`call`, `filter`) are handled explicitly because
they are not simple keyword statements.

---

## Statement Parsers

Each statement keyword maps to a dedicated `parse_*` method that returns one or
more [node](nodes.md) objects.

| Method | Produces | Notes |
|--------|----------|-------|
| `parse_set` | `nodes.Assign` / `nodes.AssignBlock` | Supports `{% set x = ... %}` and `{% set x %}...{% endset %}` |
| `parse_for` | `nodes.For` | Supports `else`, `if` filter, and `recursive` |
| `parse_if` | `nodes.If` | Builds a chain via `elif_` / `else_` |
| `parse_with` | `nodes.With` | Parses `target = value` pairs |
| `parse_autoescape` | `nodes.Scope` | Wraps a `ScopedEvalContextModifier` |
| `parse_block` | `nodes.Block` | Supports `scoped` / `required`; validates required bodies |
| `parse_extends` | `nodes.Extends` | |
| `parse_include` | `nodes.Include` | Supports `ignore missing` and `with/without context` |
| `parse_import` | `nodes.Import` | Supports `with/without context` |
| `parse_from` | `nodes.FromImport` | Supports aliases and `with/without context` |
| `parse_macro` | `nodes.Macro` | Uses `parse_signature` |
| `parse_call_block` | `nodes.CallBlock` | Optional signature + call expression |
| `parse_filter_block` | `nodes.FilterBlock` | |
| `parse_print` | `nodes.Output` | Comma-separated expressions |

### Statement Body Parsing

`parse_statements(end_tokens, drop_needle=False)` is the shared helper used by
all block statements. It:

1. Skips an optional leading `colon` (Python compatibility).
2. Expects `block_end`.
3. Calls `subparse(end_tokens)` to parse the body.
4. Fails with `fail_eof` if the template ended prematurely.
5. Optionally consumes the terminating token (`drop_needle`).

---

## Expression Parsing

Expressions are parsed using a classic **recursive descent** approach with one
method per precedence level. The precedence hierarchy (lowest to highest) is:

```mermaid
flowchart TD
    E["parse_expression"] --> C["parse_condexpr<br/>(a if b else c)"]
    C --> O["parse_or<br/>(or)"]
    O --> A["parse_and<br/>(and)"]
    A --> N["parse_not<br/>(not)"]
    N --> Cmp["parse_compare<br/>(eq, ne, lt, lteq, gt, gteq, in, not in)"]
    Cmp --> M1["parse_math1<br/>(+ -)"]
    M1 --> Cat["parse_concat<br/>(~)"]
    Cat --> M2["parse_math2<br/>(* / // %)"]
    M2 --> P["parse_pow<br/>(**)"]
    P --> U["parse_unary<br/>(- +)"]
    U --> Pri["parse_primary<br/>(literals, names, groups, lists, dicts)"]
    Pri --> Post["parse_postfix<br/>(. [] ())"]
    Post --> Filt["parse_filter_expr<br/>(| filter, is test)"]
```

### Operator-to-Node Mapping

The `_math_nodes` dictionary maps token types to node classes:

| Token type | Node class |
|------------|------------|
| `add` | `nodes.Add` |
| `sub` | `nodes.Sub` |
| `mul` | `nodes.Mul` |
| `div` | `nodes.Div` |
| `floordiv` | `nodes.FloorDiv` |
| `mod` | `nodes.Mod` |

Comparison operators are defined by `_compare_operators`:
`eq, ne, lt, lteq, gt, gteq` (plus `in` / `not in` handled inline).

### Primary Expressions

`parse_primary()` handles the atomic building blocks:

- **Names** — `true`/`false`/`True`/`False`/`none`/`None` become `nodes.Const`;
  other names become `nodes.Name` with `load` context.
- **Strings** — adjacent string tokens are concatenated into a single
  `nodes.Const`.
- **Numbers** — `integer` / `float` tokens become `nodes.Const`.
- **Parenthesized groups** — `parse_tuple(explicit_parentheses=True)`.
- **Lists** — `parse_list()` → `nodes.List`.
- **Dicts** — `parse_dict()` → `nodes.Dict` of `nodes.Pair`.

### Postfix and Filters

- `parse_postfix()` handles attribute access (`Getattr`), subscripting
  (`Getitem`), and calls (`Call`).
- `parse_filter_expr()` handles the pipe operator (`Filter`) and the `is`
  keyword (`Test`).
- `parse_subscript()` / `parse_subscribed()` handle dotted access, indexing, and
  slicing (`nodes.Slice`).
- `parse_call_args()` parses positional args, keyword args, `*args`, and
  `**kwargs`, returning a 4-tuple.

### Assignment Targets

`parse_assign_target()` parses the left-hand side of assignments. It supports:

- **Namespace references** (`ns.attr`) when `with_namespace=True` → `nodes.NSRef`.
- **Name-only** targets when `name_only=True` → `nodes.Name` with `store` ctx.
- **Tuples** (default) via `parse_tuple(simplified=True)`.
- **Primaries** when `with_tuple=False`.

After parsing, `target.set_ctx("store")` is applied and `can_assign()` is
validated.

---

## Error Handling

The parser produces precise, human-readable errors through a small set of
helpers. All errors are raised as `TemplateSyntaxError` (or a subclass such as
`TemplateAssertionError`).

| Method | Purpose |
|--------|---------|
| `fail(msg, lineno, exc)` | Raise `exc` with message, line number, name, filename |
| `fail_unknown_tag(name, lineno)` | Report an unrecognized tag with context |
| `fail_eof(end_tokens, lineno)` | Report unexpected end of template |
| `_fail_ut_eof(...)` | Shared logic that builds the detailed message |

The error messages leverage `_tag_stack` and `_end_token_stack` to explain
nesting mistakes, e.g.:

> "You probably made a nesting mistake. Jinja is expecting this tag, but
> currently looking for ..."

```mermaid
sequenceDiagram
    participant P as Parser
    participant S as TokenStream
    participant E as Environment
    P->>S: expect("name:endif")
    S-->>P: raises TemplateSyntaxError
    P->>P: fail() / fail_eof()
    P-->>E: TemplateSyntaxError propagates
    E->>E: handle_exception() rewrites traceback
```

---

## Extension Integration

Extensions can register custom statement tags. During `Parser.__init__`, the
parser iterates `environment.iter_extensions()` and builds the `extensions`
mapping:

```python
for extension in environment.iter_extensions():
    for tag in extension.tags:
        self.extensions[tag] = extension.parse
```

When `parse_statement()` encounters an unknown keyword, it checks this mapping
and calls `extension.parse(self)`. The extension may return a single node or a
list of nodes. See the [ext](ext.md) module for details on writing extensions.

---

## Free Identifiers

`free_identifier()` generates unique internal names (`fi1`, `fi2`, ...) as
`nodes.InternalName` objects. These are used internally (e.g. by the compiler
and extensions) to create temporary variables that cannot collide with
user-defined names.

---

## Component Interaction Summary

```mermaid
classDiagram
    class Parser {
        +Environment environment
        +TokenStream stream
        +Dict extensions
        +parse() Template
        +subparse(end_tokens) List~Node~
        +parse_statement() Node
        +parse_expression() Expr
        +parse_tuple() Expr
        +parse_assign_target() Expr
        +fail(msg, lineno, exc)
    }
    class TokenStream {
        +Token current
        +expect(expr) Token
        +skip_if(expr) bool
        +look() Token
    }
    class Environment {
        +_tokenize(source, ...) TokenStream
        +iter_extensions() Iterator
    }
    class Node {
        +set_ctx(ctx)
        +set_environment(env)
        +can_assign() bool
    }
    Parser --> TokenStream : consumes
    Parser --> Environment : configured by
    Parser --> Node : produces
```

---

## Related Modules

- [lexer](lexer.md) — Produces the `TokenStream` consumed by the parser.
- [nodes](nodes.md) — Defines all AST node classes the parser instantiates.
- [compiler](compiler.md) — Consumes the AST produced by the parser.
- [optimizer](optimizer.md) — Post-processes the AST before compilation.
- [environment](environment.md) — Owns the parser entry points (`parse`,
  `compile`, `compile_expression`).
- [exceptions](exceptions.md) — Defines `TemplateSyntaxError` and related errors.
- [ext](ext.md) — Extensions that register custom statement tags.
- [visitor](visitor.md) — Generic node traversal utilities used downstream.
