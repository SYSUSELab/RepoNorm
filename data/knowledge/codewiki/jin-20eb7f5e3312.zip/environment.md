# Environment Module

## Introduction

The **Environment module** is the central configuration and orchestration layer of Jinja2. It is responsible for:

- Holding shared configuration (delimiters, filters, tests, globals, policies).
- Loading templates through pluggable **loaders**.
- Driving the **parse → compile → render** pipeline.
- Producing `Template` objects that can be rendered, streamed, or imported as modules.
- Providing the base classes that specialized environments (sandboxed, native) extend.

The primary entry point is the `Environment` class in `src/jinja2/environment.py`. Almost every other subsystem in Jinja2 (lexer, parser, compiler, runtime, loaders, bytecode cache) is wired together through this module.

> **Note:** This document focuses on the environment module. For details on the compilation internals, see [Parsing and Compilation Pipeline](parsing_and_compilation_pipeline.md). For runtime evaluation semantics, see [Runtime Execution Support](runtime_execution_support.md). For extensions, see [ext](ext.md).

---

## Core Components

| Component | File | Responsibility |
|-----------|------|----------------|
| `Environment` | `environment.py` | Central configuration, template loading, compilation, and rendering orchestration. |
| `Template` | `environment.py` | A compiled, renderable template. Supports `render`, `stream`, `generate`, and module access. |
| `TemplateModule` | `environment.py` | Represents an imported template; exposes exported names as attributes. |
| `TemplateExpression` | `environment.py` | Wraps a compiled expression for `compile_expression`. |
| `TemplateStream` | `environment.py` | Buffered iterator over rendered template output. |

### Module-level helpers

- `get_spontaneous_environment` — LRU-cached factory for environments created implicitly by direct `Template(...)` usage.
- `create_cache` / `copy_cache` — Build the template cache (`None`, plain `dict`, or `LRUCache`).
- `load_extensions` — Instantiate and bind extensions to an environment.
- `_environment_config_check` — Sanity-checks delimiter and undefined configuration.

---

## Architecture Overview

The environment sits at the center of Jinja2, connecting configuration, loading, compilation, and runtime.

```mermaid
graph TD
    User["User Code"] -->|get_template / from_string| Env["Environment"]
    Env -->|uses| Loader["BaseLoader<br/>(loaders.py)"]
    Env -->|uses| BCC["BytecodeCache<br/>(bccache.py)"]
    Env -->|parse| Parser["Parser<br/>(parser.py)"]
    Env -->|compile| Compiler["CodeGenerator<br/>(compiler.py)"]
    Env -->|produces| Template["Template"]
    Template -->|render| Context["Context<br/>(runtime.py)"]
    Template -->|render| Runtime["Runtime helpers<br/>(runtime.py)"]
    Env -->|configures| Filters["Filters / Tests / Globals"]
    Env -->|extended by| Sandbox["SandboxedEnvironment<br/>(sandbox.py)"]
    Env -->|extended by| Native["NativeEnvironment<br/>(nativetypes.py)"]
    Env -->|extended by| Ext["Extensions<br/>(ext.py)"]
```

### Class hierarchy

```mermaid
classDiagram
    class Environment {
        +block_start_string
        +variable_start_string
        +filters
        +tests
        +globals
        +loader
        +cache
        +bytecode_cache
        +get_template()
        +select_template()
        +from_string()
        +compile()
        +parse()
        +overlay()
    }
    class SandboxedEnvironment {
        +sandboxed = True
        +is_safe_attribute()
        +is_safe_callable()
        +call_binop()
        +call_unop()
    }
    class ImmutableSandboxedEnvironment
    class NativeEnvironment {
        +code_generator_class = NativeCodeGenerator
        +concat = native_concat
    }
    class Template {
        +render()
        +render_async()
        +stream()
        +generate()
        +make_module()
        +module
    }
    class TemplateModule
    class TemplateExpression
    class TemplateStream

    Environment <|-- SandboxedEnvironment
    SandboxedEnvironment <|-- ImmutableSandboxedEnvironment
    Environment <|-- NativeEnvironment
    Environment --> Template : creates
    Template --> TemplateModule : make_module
    Template --> TemplateStream : stream
    Environment --> TemplateExpression : compile_expression
```

---

## The `Environment` Class

The `Environment` is the shared, long-lived configuration object. It should be created once and reused; modifying it after templates have been loaded leads to undefined behavior.

### Key configuration categories

| Category | Attributes | Purpose |
|----------|-----------|---------|
| **Lexer/Parser** | `block_start_string`, `block_end_string`, `variable_start_string`, `variable_end_string`, `comment_start_string`, `comment_end_string`, `line_statement_prefix`, `line_comment_prefix`, `trim_blocks`, `lstrip_blocks`, `newline_sequence`, `keep_trailing_newline` | Control how template syntax is tokenized and parsed. |
| **Runtime** | `undefined`, `optimized`, `finalize`, `autoescape`, `is_async` | Control evaluation semantics and output processing. |
| **Defaults** | `filters`, `tests`, `globals`, `policies` | Registries of callables and configuration policies. |
| **Loading** | `loader`, `cache`, `bytecode_cache`, `auto_reload` | Template discovery and caching. |
| **Extensions** | `extensions` | Registered `Extension` instances keyed by identifier. |

### Class-level hooks (overridable by subclasses)

- `code_generator_class` — the `CodeGenerator` used for compilation (overridden by `NativeEnvironment`).
- `context_class` — the `Context` class used at runtime.
- `template_class` — the `Template` class produced by the environment.
- `concat` — the string concatenation function (overridden by `NativeEnvironment`).
- `sandboxed` — flag controlling sandboxed code generation (set by `SandboxedEnvironment`).

### Template loading methods

```mermaid
flowchart TD
    A["get_template(name)"] --> B{name is Template?}
    B -->|yes| C[return name]
    B -->|no| D[join_path with parent]
    D --> E["_load_template(name, globals)"]
    E --> F{loader configured?}
    F -->|no| G[raise TypeError]
    F -->|yes| H{cache hit & up-to-date?}
    H -->|yes| I[update globals, return cached]
    H -->|no| J["loader.load(env, name, globals)"]
    J --> K[store in cache]
    K --> L[return Template]
```

- `get_template` — load a single template by name.
- `select_template` — try a list of names, raising `TemplatesNotFound` if none load.
- `get_or_select_template` — dispatch to the appropriate method based on input type.
- `from_string` — compile a template directly from a source string (no loader).
- `_load_template` — internal cache-aware loading used by the above.

### Compilation methods

- `parse(source, name, filename)` — produce an AST (`nodes.Template`) via the `Parser`.
- `lex(source, ...)` — yield raw tokens (no preprocessing).
- `preprocess(source, ...)` — run all extension preprocessors.
- `_tokenize(...)` — preprocess + tokenize + apply extension stream filters.
- `compile(source, name, filename, raw, defer_init)` — full pipeline to a Python code object (or source string if `raw=True`).
- `compile_expression(source, undefined_to_none)` — compile a standalone expression into a `TemplateExpression`.
- `compile_templates(target, ...)` — precompile all loader templates into a folder or zip.

### Extension and overlay support

- `add_extension(extension)` — register an extension after construction.
- `extend(**attributes)` — add attributes only if not already present (used by extensions).
- `overlay(...)` — create a linked environment sharing data but with overridden attributes and its own cache.
- `iter_extensions()` — iterate extensions ordered by priority.

### Filter/test invocation

- `call_filter(name, value, ...)` and `call_test(name, value, ...)` — invoke filters/tests exactly as the compiler does, honoring `@pass_context`, `@pass_eval_context`, and `@pass_environment` decorators via `_filter_test_common`.

---

## The `Template` Class

A `Template` is a compiled, immutable object. It is normally created through the environment, but can also be instantiated directly (which creates a shared "spontaneous" environment behind the scenes).

### Construction paths

```mermaid
flowchart LR
    A["Template(source, ...)"] --> B["get_spontaneous_environment()"]
    B --> C["env.from_string(source)"]
    D["Template.from_code(env, code, globals)"] --> E["_from_namespace()"]
    F["Template.from_module_dict(env, module_dict, globals)"] --> E
    E --> G[Template instance]
```

- `__new__` — direct construction using a cached spontaneous environment.
- `from_code` — build from compiled code (used by loaders).
- `from_module_dict` — build from a module dict (used by `ModuleLoader`).
- `_from_namespace` — shared initialization from a namespace dict.

### Rendering methods

| Method | Returns | Notes |
|--------|---------|-------|
| `render(*args, **kwargs)` | `str` | Synchronous full render. Delegates to async loop if `is_async`. |
| `render_async(*args, **kwargs)` | coroutine → `str` | Requires async mode. |
| `generate(*args, **kwargs)` | `Iterator[str]` | Yields output piece by piece. |
| `generate_async(...)` | `AsyncIterator[str]` | Async variant of `generate`. |
| `stream(*args, **kwargs)` | `TemplateStream` | Wraps `generate` in a buffered stream. |

### Context and module methods

- `new_context(vars, shared, locals)` — create a `Context` (see [Runtime Execution Support](runtime_execution_support.md)).
- `make_module(vars, shared, locals)` / `make_module_async(...)` — evaluate the template as a module.
- `module` (property) — cached default module; unavailable in async mode.
- `_get_default_module(ctx)` / `_get_default_module_async(ctx)` — internal module resolution with globals handling.

### Introspection

- `is_up_to_date` — whether the source has changed (drives `auto_reload`).
- `debug_info` — mapping of template lines to generated code lines.
- `get_corresponding_lineno(lineno)` — translate generated code line to template line.

---

## Supporting Classes

### `TemplateModule`

Represents an imported template. Exported names become attributes; `str()`/`__html__()` render the body. In async mode a `body_stream` must be supplied.

### `TemplateExpression`

Returned by `Environment.compile_expression`. Calling it evaluates the wrapped expression with keyword arguments as variables, optionally converting `Undefined` results to `None`.

### `TemplateStream`

A buffered iterator over rendered output. Supports:

- `enable_buffering(size)` / `disable_buffering()` — control output batching.
- `dump(fp, encoding, errors)` — write the full stream to a file or file-like object.

---

## Data Flow: From Source to Rendered Output

```mermaid
sequenceDiagram
    participant U as User
    participant E as Environment
    participant L as Loader
    participant P as Parser
    participant C as CodeGenerator
    participant T as Template
    participant X as Context

    U->>E: get_template("page.html")
    E->>L: load(env, name, globals)
    L->>L: get_source(env, name)
    L->>E: compile(source, name, filename)
    E->>P: parse(source)
    P-->>E: AST (nodes.Template)
    E->>C: generate(AST)
    C-->>E: Python source
    E->>E: _compile(source) -> code object
    E-->>L: code object
    L-->>E: Template.from_code(...)
    E-->>U: Template
    U->>T: render(**vars)
    T->>X: new_context(vars)
    T->>T: root_render_func(ctx)
    T-->>U: rendered string
```

---

## Dependencies

The environment module depends on nearly every other Jinja2 subsystem.

```mermaid
graph LR
    Env["environment.py"] --> Lexer["lexer.py"]
    Env --> Parser["parser.py"]
    Env --> Nodes["nodes.py"]
    Env --> Compiler["compiler.py"]
    Env --> Runtime["runtime.py"]
    Env --> Exceptions["exceptions.py"]
    Env --> Utils["utils.py"]
    Env --> Defaults["defaults.py"]
    Env --> Loaders["loaders.py"]
    Env --> BCC["bccache.py"]
    Env --> Ext["ext.py"]
    Env --> Debug["debug.py"]
    Env --> MarkupSafe["markupsafe"]
```

### Inbound dependencies (who uses the environment)

- **`loaders.py`** — `BaseLoader.load` calls `environment.compile` and `environment.template_class.from_code`.
- **`bccache.py`** — `BytecodeCache.get_bucket` receives the environment to compute cache keys.
- **`sandbox.py`** — `SandboxedEnvironment` subclasses `Environment`.
- **`nativetypes.py`** — `NativeEnvironment` subclasses `Environment`.
- **`ext.py`** — extensions receive and bind to the environment.
- **`runtime.py`** — `Context` holds a reference to its environment.

---

## Specialized Environments

### `SandboxedEnvironment` (sandbox.py)

A subclass that sets `sandboxed = True`, causing the compiler to emit sandboxed code. It overrides `getattr`, `getitem`, and `call` to enforce safety checks:

- `is_safe_attribute` — rejects private/internal attributes.
- `is_safe_callable` — rejects callables marked `unsafe_callable` or `alters_data`.
- `call_binop` / `call_unop` — intercept configured operators.
- `format_string` — routes `str.format` through a sandboxed formatter.

`ImmutableSandboxedEnvironment` further restricts mutation of built-in containers.

### `NativeEnvironment` (nativetypes.py)

A subclass that renders templates to native Python types rather than strings. It overrides `code_generator_class` with `NativeCodeGenerator` and `concat` with `native_concat`.

---

## Usage Examples

### Basic rendering

```python
from jinja2 import Environment, FileSystemLoader

env = Environment(loader=FileSystemLoader("templates"))
template = env.get_template("page.html")
print(template.render(title="Hello"))
```

### Direct template creation

```python
from jinja2 import Template

t = Template("Hello {{ name }}!")
print(t.render(name="World"))
```

### Compiling an expression

```python
env = Environment()
expr = env.compile_expression("foo == 42")
assert expr(foo=42) is True
```

### Overlay environment

```python
base = Environment(loader=FileSystemLoader("templates"))
overlay = base.overlay(autoescape=True)
```

### Streaming large output

```python
template = env.get_template("big.html")
stream = template.stream(items=range(10000))
stream.enable_buffering(20)
stream.dump("output.html")
```

---

## Related Documentation

- [Parsing and Compilation Pipeline](parsing_and_compilation_pipeline.md) — lexer, parser, nodes, compiler, optimizer, meta, visitor, idtracking.
- [Runtime Execution Support](runtime_execution_support.md) — `Context`, `Undefined`, exceptions, utils, filters.
- [ext](ext.md) — extension system that hooks into the environment.
