# Lexer Module

## Introduction

The `lexer` module (`src/jinja2/lexer.py`) implements a combined **Jinja / Python lexer** that transforms raw template source text into a stream of typed tokens. It is the very first stage of the [Parsing and Compilation Pipeline](parser.md), sitting between the raw template string and the [parser](parser.md).

The lexer's responsibilities are:

- **Separating template code from Python code** — it distinguishes literal template data (HTML/text) from expressions and statements embedded in Jinja delimiters.
- **Filtering out invalid operators** — operators that Jinja does not allow in templates (such as bitshift operators) are rejected.
- **Producing a `TokenStream`** — a pull-based, look-ahead-capable stream of `Token` objects consumed by the [parser](parser.md).
- **Handling whitespace control** — implementing `trim_blocks`, `lstrip_blocks`, and the `-`/`+` whitespace-control markers.
- **Normalizing values** — converting string literals, integers, floats, and operators into their Python equivalents.

The lexer is configured entirely by an [Environment](environment.md) instance and is cached per unique configuration, so multiple environments sharing the same syntax settings reuse the same lexer.

---

## Architecture Overview

The lexer is a **state-machine-based tokenizer**. It maintains a stack of lexing states (e.g. `root`, `block_begin`, `variable_begin`) and, for each state, a list of ordered regular-expression rules. The tokenizer loop repeatedly matches the current state's rules against the remaining source, emits tokens, and transitions between states.

```mermaid
graph TD
    Env["Environment<br/>(syntax config)"] -->|get_lexer| Cache["_lexer_cache<br/>(LRUCache)"]
    Cache -->|creates/caches| Lexer

    subgraph Lexer["Lexer"]
        Rules["rules: Dict[state, List[_Rule]]"]
        TokenIter["tokeniter()<br/>state machine loop"]
        Wrap["wrap()<br/>value conversion"]
        Tokenize["tokenize()"]
    end

    Lexer -->|tokeniter| RawTuples["(lineno, type, value)<br/>generator"]
    RawTuples -->|wrap| Tokens["Iterator[Token]"]
    Tokens -->|TokenStream| Stream["TokenStream"]
    Stream -->|consumed by| Parser["Parser<br/>(parser.md)"]

    Lexer -.->|raises| SyntaxError["TemplateSyntaxError<br/>(exceptions.md)"]
    Lexer -.->|uses| LRU["LRUCache<br/>(utils.md)"]
```

### Key Design Points

| Aspect | Description |
| --- | --- |
| **State machine** | A `stack` of state names drives which rule set is active. States are pushed/popped via `#pop`, `#bygroup`, or explicit names. |
| **Rule ordering** | Rules are sorted by delimiter length (longest first) so that multi-character delimiters like `<%=` are matched before `<%`. |
| **Caching** | `get_lexer()` keys the cache on all syntax-relevant environment attributes, so identical configurations share a lexer. |
| **Two-phase output** | `tokeniter()` yields raw `(lineno, type, value)` tuples; `wrap()` converts them into `Token` objects with Python-native values. |
| **Balance tracking** | A `balancing_stack` prevents premature closing of blocks/variables when braces or parentheses are unbalanced. |

---

## Core Components

### `Lexer`

The central class implementing the tokenizer. It is normally created automatically by the [Environment](environment.md) via `get_lexer()` and is **not bound to a single environment** — multiple environments can share one lexer instance.

**Construction** (`__init__`): Builds the rule tables from the environment's syntax configuration:

- **Tag rules** (`tag_rules`) — shared rules for whitespace, floats, integers, names, strings, and operators, applied inside blocks and variables.
- **Root rules** — match template data and detect the start of comments, blocks, variables, line statements, and raw blocks.
- **State-specific rules** — separate rule lists for `comment_begin`, `block_begin`, `variable_begin`, `raw_begin`, `linestatement_begin`, and `linecomment_begin`.

**Key methods:**

| Method | Purpose |
| --- | --- |
| `tokenize(source, name, filename, state)` | Public entry point. Wraps `tokeniter` + `wrap` into a `TokenStream`. |
| `tokeniter(source, name, filename, state)` | The core state-machine generator yielding `(lineno, type, value)` tuples. |
| `wrap(stream, name, filename)` | Converts raw tuples into `Token` objects, performing value conversion and filtering ignored tokens. |
| `_normalize_newlines(value)` | Replaces all newline variants with the configured `newline_sequence`. |

### `Token`

A `NamedTuple` of `(lineno, type, value)` representing a single lexical token.

- `__str__` returns a human-readable description via `describe_token`.
- `test(expr)` tests the token against a token expression — either a bare type (`"name"`) or a `"type:value"` pair.
- `test_any(*iterable)` tests against multiple expressions.

### `TokenStream`

A pull-based, look-ahead-capable stream of tokens. Unlike a plain iterator, the [parser](parser.md) drives it by calling `next()` to advance and reading `current` for the active token.

| Member | Description |
| --- | --- |
| `current` | The currently active `Token`. |
| `eos` | `True` when the stream is exhausted. |
| `push(token)` | Push a token back onto the stream. |
| `look()` | Peek at the next token without consuming it. |
| `skip(n)` | Advance `n` tokens. |
| `next_if(expr)` / `skip_if(expr)` | Conditionally consume a token matching an expression. |
| `expect(expr)` | Consume a token matching an expression or raise `TemplateSyntaxError`. |
| `close()` | Force the stream to EOF. |

### `TokenStreamIterator`

The iterator returned by `TokenStream.__iter__`. It yields tokens until the EOF token is reached, then closes the stream and raises `StopIteration`.

### `Failure`

A callable error marker used inside rule definitions. When the tokenizer encounters a `Failure` in a rule's token tuple, it invokes it, raising a `TemplateSyntaxError` (or a subclass) with the configured message. Used for known error conditions such as a missing end-of-comment tag or missing end-of-raw directive.

### `OptionalLStrip`

A special `tuple` subclass used to mark a rule whose matched text may have leading whitespace stripped (for `lstrip_blocks`). It carries the same members as a normal token tuple but signals the tokenizer to apply lstrip logic.

### `_Rule`

A `NamedTuple` describing a single lexing rule:

| Field | Type | Description |
| --- | --- | --- |
| `pattern` | `Pattern[str]` | The compiled regex to match. |
| `tokens` | `str \| Tuple[str, ...] \| Tuple[Failure]` | The token type(s) to emit, or `"#bygroup"` for dynamic resolution. |
| `command` | `Optional[str]` | A state transition command (`"#pop"`, `"#bygroup"`, or a state name). |

---

## Token Types

The module defines a comprehensive set of interned token type constants. They fall into several categories:

```mermaid
graph LR
    subgraph Delimiters
        BB["block_begin"]
        BE["block_end"]
        VB["variable_begin"]
        VE["variable_end"]
        CB["comment_begin"]
        CE["comment_end"]
        RB["raw_begin"]
        RE["raw_end"]
        LSB["linestatement_begin"]
        LSE["linestatement_end"]
        LCB["linecomment_begin"]
        LCE["linecomment_end"]
    end
    subgraph Literals
        NAME["name"]
        STR["string"]
        INT["integer"]
        FLOAT["float"]
    end
    subgraph Operators
        OP["operator"]
        ADD["add"]
        SUB["sub"]
        MUL["mul"]
        DIV["div"]
        EQ["eq"]
        LT["lt"]
        GT["gt"]
        PIPE["pipe"]
    end
    subgraph Special
        DATA["data"]
        WS["whitespace"]
        COMMENT["comment"]
        INITIAL["initial"]
        EOF["eof"]
    end
```

- **Delimiter tokens** — mark the boundaries of blocks, variables, comments, raw sections, line statements, and line comments.
- **Literal tokens** — `name`, `string`, `integer`, `float`.
- **Operator tokens** — a single `operator` token is emitted by the tokenizer, then mapped to a specific operator token (e.g. `add`, `eq`) during `wrap()`.
- **Special tokens** — `data` (template text), `whitespace`, `comment`, `initial` (stream start), and `eof`.

### Operator Mapping

The `operators` dict maps operator strings to token types, and `reverse_operators` provides the inverse. The `operator_re` regex is built by sorting operators by descending length so that `**` matches before `*`, and `//` before `/`.

### Ignored Tokens

- `ignored_tokens` — tokens dropped entirely during `wrap()` (comment delimiters, whitespace, line-comment delimiters).
- `ignore_if_empty` — tokens suppressed when their value is empty (`whitespace`, `data`, `comment`, `linecomment`).

---

## Tokenization Process

The following sequence diagram illustrates the full flow from source text to a `TokenStream`.

```mermaid
sequenceDiagram
    participant Env as Environment
    participant Lexer
    participant TokenIter as tokeniter()
    participant Wrap as wrap()
    participant Stream as TokenStream

    Env->>Lexer: get_lexer(env) [cached]
    Env->>Lexer: tokenize(source, name, filename, state)
    Lexer->>TokenIter: tokeniter(source, ...)
    Note over TokenIter: Split lines, normalize newlines,<br/>init state stack = ["root"]
    loop Until EOF
        TokenIter->>TokenIter: Match rules for current state
        TokenIter->>TokenIter: Handle whitespace control (lstrip/trim)
        TokenIter->>TokenIter: Track brace/paren balance
        TokenIter->>TokenIter: Apply state transitions
        TokenIter-->>Wrap: yield (lineno, type, value)
    end
    Wrap->>Wrap: Filter ignored tokens
    Wrap->>Wrap: Convert values (int, float, string, operator)
    Wrap-->>Stream: yield Token
    Lexer->>Stream: TokenStream(wrapped, name, filename)
    Stream-->>Env: TokenStream
```

### Step-by-Step

1. **Line splitting & newline normalization** — `tokeniter` splits the source on newline variants, optionally drops a trailing newline (unless `keep_trailing_newline`), and rejoins with `\n`.
2. **State initialization** — The state stack starts as `["root"]`. If an initial `state` is given (`"variable"` or `"block"`), the corresponding `_begin` state is pushed.
3. **Main loop** — For the current state, each rule is tried in order:
   - If a rule matches, its tokens are emitted (handling `Failure`, `#bygroup`, and normal groups).
   - Whitespace control is applied for `OptionalLStrip` rules.
   - Brace/parenthesis balance is tracked for operator tokens.
   - State transitions are applied based on the rule's `command`.
4. **Error handling** — Unbalanced braces, unexpected characters, and infinite-loop conditions raise `TemplateSyntaxError`.
5. **Wrapping** — `wrap()` filters ignored tokens, converts values, and yields `Token` objects.

### Whitespace Control

The lexer implements three whitespace-control mechanisms:

| Mechanism | Trigger | Effect |
| --- | --- | --- |
| `trim_blocks` | Environment flag | Removes the first newline after a block tag. |
| `lstrip_blocks` | Environment flag | Strips leading whitespace before a block tag (unless non-whitespace precedes it). |
| `-` / `+` markers | Inline in tags | `-` strips surrounding whitespace; `+` preserves it. |

The `lstrip_unless_re` regex (`[^ \t]`) is used to detect non-whitespace between a newline and a block, preventing lstrip in that case.

---

## Value Conversion

During `wrap()`, raw string values are converted to Python-native values:

| Token | Conversion |
| --- | --- |
| `data` | Newlines normalized to `newline_sequence`. |
| `name` | Validated as a Python identifier; raises `TemplateSyntaxError` otherwise. |
| `string` | Unescaped via `unicode-escape` after newline normalization. |
| `integer` | Parsed with `int(value, 0)` (supports binary/octal/hex, `_` separators). |
| `float` | Parsed with `ast.literal_eval` after removing `_` separators. |
| `operator` | Mapped to a specific operator token via the `operators` dict. |
| `linestatement_begin/end` | Remapped to `block_begin`/`block_end`. |
| `raw_begin/raw_end` | Dropped (not relevant to the parser). |

---

## Caching

The module maintains a module-level `_lexer_cache` (an `LRUCache` with capacity 50). The cache key is a tuple of all syntax-relevant [Environment](environment.md) attributes:

- `block_start_string`, `block_end_string`
- `variable_start_string`, `variable_end_string`
- `comment_start_string`, `comment_end_string`
- `line_statement_prefix`, `line_comment_prefix`
- `trim_blocks`, `lstrip_blocks`
- `newline_sequence`, `keep_trailing_newline`

`get_lexer(environment)` returns a cached lexer or creates and caches a new one. This allows multiple environments with identical syntax settings to share a single lexer instance.

---

## Helper Functions

| Function | Description |
| --- | --- |
| `get_lexer(environment)` | Returns a cached `Lexer` for the environment. |
| `compile_rules(environment)` | Compiles the environment's delimiter strings into ordered rule tuples. |
| `describe_token(token)` | Returns a human-readable description of a token. |
| `describe_token_expr(expr)` | Like `describe_token` but for token expressions. |
| `_describe_token_type(token_type)` | Maps a token type to a descriptive string. |
| `count_newlines(value)` | Counts newline characters; useful for extensions that filter streams. |

---

## Dependencies

```mermaid
graph TD
    Lexer["lexer.py"]
    Lexer -->|uses| Identifier["_identifier.pattern<br/>(name_re)"]
    Lexer -->|raises| Exceptions["TemplateSyntaxError<br/>(exceptions.md)"]
    Lexer -->|uses| Utils["LRUCache<br/>(utils.md)"]
    Lexer -->|configured by| Environment["Environment<br/>(environment.md)"]
    Lexer -->|produces| Parser["TokenStream consumed by Parser<br/>(parser.md)"]
```

- **`_identifier.pattern`** — the `name_re` regex used to match identifiers.
- **[`TemplateSyntaxError`](exceptions.md)** — raised for all lexical errors.
- **[`LRUCache`](utils.md)** — backs the lexer cache.
- **[`Environment`](environment.md)** — supplies all syntax configuration and owns the `lexer` property.
- **[`Parser`](parser.md)** — the primary consumer of the `TokenStream` produced by the lexer.

---

## Integration with the Pipeline

The lexer is the entry point of the [Parsing and Compilation Pipeline](parser.md):

```mermaid
graph LR
    Source["Template Source"] --> Lexer
    Lexer -->|TokenStream| Parser
    Parser -->|AST| Nodes["nodes.md"]
    Nodes --> Compiler["compiler.md"]
    Compiler --> Bytecode["Python Bytecode"]
```

The [Environment](environment.md) exposes two relevant methods:

- `Environment.lex(source, name, filename)` — returns a generator of raw `(lineno, type, value)` tuples (no preprocessing).
- `Environment._tokenize(source, name, filename, state)` — preprocesses the source through extensions, tokenizes it, and applies each extension's `filter_stream`, returning a `TokenStream` for the [parser](parser.md).

---

## Summary

The `lexer` module is a configuration-driven, state-machine tokenizer that converts Jinja template source into a `TokenStream` of typed tokens. Its key abstractions — `Lexer`, `Token`, `TokenStream`, `_Rule`, `Failure`, and `OptionalLStrip` — provide a robust foundation for the [parser](parser.md) to build the abstract syntax tree. By caching lexers per environment configuration and supporting rich whitespace control, it balances performance with the flexibility required by Jinja's configurable syntax.
