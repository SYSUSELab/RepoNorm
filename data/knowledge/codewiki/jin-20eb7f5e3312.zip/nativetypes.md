# Native Types Module

## Introduction

The `nativetypes` module extends Jinja's standard templating engine to render templates directly into **native Python types** rather than strings. While a normal Jinja template always produces a `str` (or `Markup`) result, the native types environment attempts to interpret the rendered output as a Python literal — returning `int`, `float`, `list`, `dict`, `tuple`, `bool`, `None`, and so on — whenever possible.

This is particularly useful for:

- **Configuration files** written in Jinja syntax that should yield Python data structures.
- **Data serialization** pipelines where templates generate structured values.
- **Expression evaluation** where the output should preserve its original type.

The module is intentionally small and is built almost entirely by *subclassing and overriding* the standard [`Environment`](environment.md), [`Template`](environment.md), and [`CodeGenerator`](compiler.md) components. It does not reimplement the parsing, compilation, or runtime machinery; instead it changes two key behaviors:

1. **Code generation** — output nodes are no longer wrapped in `str()`.
2. **Concatenation** — the final list of rendered fragments is passed through `ast.literal_eval` to recover a native type.

> **Note:** This module is part of the `Template_Environment_and_Loading` group. For the base environment and template machinery it builds upon, see [environment.md](environment.md). For the code generation pipeline it customizes, see [compiler.md](compiler.md).

---

## Core Components

The module defines three public classes and one module-level helper function:

| Component | Base Class | Purpose |
|-----------|-----------|---------|
| `native_concat` | *(function)* | Concatenates rendered fragments and attempts `literal_eval`. |
| `NativeCodeGenerator` | [`CodeGenerator`](compiler.md) | Emits code that preserves native types instead of stringifying. |
| `NativeEnvironment` | [`Environment`](environment.md) | Wires the native code generator and concat function together. |
| `NativeTemplate` | [`Template`](environment.md) | Renders to native types via `native_concat`. |

---

## Architecture Overview

The native types module is a thin specialization layer sitting on top of the standard Jinja pipeline. It overrides exactly three extension points.

```mermaid
graph TD
    subgraph "Standard Jinja Pipeline"
        ENV["Environment<br/>(environment.py)"]
        TMPL["Template<br/>(environment.py)"]
        CG["CodeGenerator<br/>(compiler.py)"]
        CONCAT["concat = ''.join"]
    end

    subgraph "nativetypes.py"
        NENV["NativeEnvironment"]
        NTMPL["NativeTemplate"]
        NCG["NativeCodeGenerator"]
        NCONCAT["native_concat()"]
    end

    ENV -->|subclassed by| NENV
    TMPL -->|subclassed by| NTMPL
    CG -->|subclassed by| NCG
    CONCAT -.->|replaced by| NCONCAT

    NENV -->|code_generator_class| NCG
    NENV -->|concat| NCONCAT
    NENV -->|template_class| NTMPL
    NTMPL -->|environment_class| NENV
```

The relationships are bidirectional by design: `NativeEnvironment` points to `NativeTemplate` via `template_class`, and `NativeTemplate` points back to `NativeEnvironment` via `environment_class`. This ensures that templates created directly (e.g. `NativeTemplate("...")`) and templates loaded through the environment both use the native pipeline.

---

## Component Details

### `native_concat`

```python
def native_concat(values: t.Iterable[t.Any]) -> t.Optional[t.Any]:
```

This is the heart of the native-type conversion. It replaces the default `Environment.concat` (which is `"".join`). Its algorithm is:

1. **Peek at the first two values** using `islice(values, 2)`.
2. **Empty input** → return `None`.
3. **Single value**:
   - If it is *not* a string, return it directly (already a native type).
   - If it *is* a string, fall through to parsing.
4. **Multiple values** → join them all as strings (re-chaining the generator if necessary).
5. **Parse** the resulting string with `ast.literal_eval`:
   - On success, return the parsed native Python object.
   - On `ValueError`, `SyntaxError`, or `MemoryError`, return the raw string unchanged.

A subtle detail: the function uses `ast.parse(raw, mode="eval")` rather than passing the string directly to `literal_eval`. This is a deliberate backwards-compatibility measure — Python 3.10+ `literal_eval` strips leading spaces/tabs, which would change behavior for templates that intentionally produce indented output.

```mermaid
flowchart TD
    A["values (iterable)"] --> B["head = first 2 items"]
    B --> C{"head empty?"}
    C -->|yes| D["return None"]
    C -->|no| E{"len(head) == 1?"}
    E -->|yes| F{"raw is str?"}
    F -->|no| G["return raw (native)"]
    F -->|yes| H["raw = head[0]"]
    E -->|no| I["re-chain generator if needed"]
    I --> J["raw = ''.join(str(v) for v in values)"]
    H --> K["ast.parse(raw, mode='eval')"]
    J --> K
    K --> L{"literal_eval succeeds?"}
    L -->|yes| M["return parsed native type"]
    L -->|no| N["return raw string"]
```

### `NativeCodeGenerator`

```python
class NativeCodeGenerator(CodeGenerator):
```

A subclass of [`CodeGenerator`](compiler.md) that changes how output nodes are compiled. The standard generator wraps every dynamic output in `str(...)` (or `escape(...)`), which forces the result to be a string. The native generator removes this wrapping so that the *actual Python object* flows through to the concat step.

It overrides four methods:

| Method | Standard Behavior | Native Behavior |
|--------|-------------------|-----------------|
| `_default_finalize` | `str(value)` | `value` (identity) |
| `_output_const_repr` | `repr(concat(group))` | `repr("".join(str(v) for v in group))` |
| `_output_child_to_const` | escapes / stringifies constants | returns the raw constant (no `str`) |
| `_output_child_pre` | writes `str(` / `escape(` | writes only the finalize source, if any |
| `_output_child_post` | writes `)` | writes `)` only if finalize source was written |

The net effect: a template like `{{ 1 + 2 }}` compiles to code that yields the integer `3` rather than the string `"3"`. When `native_concat` receives a single non-string value, it returns it directly.

`_output_child_to_const` also uses [`has_safe_repr`](compiler.md) to decide whether a constant can be safely embedded in generated source. If the constant cannot be safely represented, it raises `nodes.Impossible()` to defer evaluation to runtime.

### `NativeEnvironment`

```python
class NativeEnvironment(Environment):
    code_generator_class = NativeCodeGenerator
    concat = staticmethod(native_concat)
```

A subclass of [`Environment`](environment.md) that simply swaps in the two native overrides:

- `code_generator_class` → `NativeCodeGenerator`
- `concat` → `native_concat`

Everything else (lexing, parsing, loading, caching, extensions, async support) is inherited unchanged. This means all standard `Environment` configuration options — `loader`, `autoescape`, `undefined`, `extensions`, `enable_async`, etc. — work exactly as documented in [environment.md](environment.md).

### `NativeTemplate`

```python
class NativeTemplate(Template):
    environment_class = NativeEnvironment
```

A subclass of [`Template`](environment.md) that overrides `render` and `render_async` to use `native_concat` instead of the environment's default string concatenation.

- `render(*args, **kwargs)` — builds a context, calls `root_render_func`, and passes the resulting fragment iterator to `NativeEnvironment.concat` (i.e. `native_concat`).
- `render_async(*args, **kwargs)` — the async equivalent; raises `RuntimeError` if the environment was not created with `enable_async=True`.

Both methods wrap execution in a `try/except` that delegates to `environment.handle_exception()` for proper traceback rewriting (see [environment.md](environment.md)).

At the bottom of the module, the wiring is completed:

```python
NativeEnvironment.template_class = NativeTemplate
```

---

## Data Flow

The following diagram traces a value from template source to a native Python result.

```mermaid
sequenceDiagram
    participant User
    participant NT as NativeTemplate
    participant ENV as NativeEnvironment
    participant CG as NativeCodeGenerator
    participant RR as root_render_func
    participant NC as native_concat

    User->>NT: render(**context)
    NT->>NT: new_context(...)
    NT->>RR: root_render_func(ctx)
    Note over RR: yields native values<br/>(no str() wrapping)
    RR-->>NT: iterator of fragments
    NT->>NC: concat(fragments)
    NC->>NC: peek / join fragments
    NC->>NC: ast.literal_eval(raw)
    alt parse succeeds
        NC-->>NT: native Python object
    else parse fails
        NC-->>NT: raw string
    end
    NT-->>User: native result
```

The key insight is that `NativeCodeGenerator` ensures the fragments yielded by `root_render_func` are *already* native objects where possible. `native_concat` then only needs to handle the cases where multiple fragments must be combined (which necessarily produces a string) or where a single string fragment should be re-parsed.

---

## Component Interaction

```mermaid
classDiagram
    class Environment {
        +code_generator_class
        +concat
        +template_class
        +get_template()
        +from_string()
    }
    class Template {
        +environment_class
        +render()
        +render_async()
    }
    class CodeGenerator {
        +_default_finalize()
        +_output_child_pre()
        +_output_child_post()
        +_output_child_to_const()
    }
    class NativeEnvironment {
        +code_generator_class = NativeCodeGenerator
        +concat = native_concat
    }
    class NativeTemplate {
        +environment_class = NativeEnvironment
        +render()
        +render_async()
    }
    class NativeCodeGenerator {
        +_default_finalize()
        +_output_child_pre()
        +_output_child_post()
        +_output_child_to_const()
    }

    Environment <|-- NativeEnvironment
    Template <|-- NativeTemplate
    CodeGenerator <|-- NativeCodeGenerator
    NativeEnvironment --> NativeCodeGenerator : uses
    NativeEnvironment --> NativeTemplate : template_class
    NativeTemplate --> NativeEnvironment : environment_class
```

---

## Usage Example

```python
from jinja2.nativetypes import NativeEnvironment

env = NativeEnvironment()

# Single expression -> native type preserved
t = env.from_string("{{ 1 + 2 }}")
assert t.render() == 3          # int, not "3"

# Literal structures -> parsed back to native
t = env.from_string("{{ [1, 2, 3] }}")
assert t.render() == [1, 2, 3]  # list

# Non-parseable output -> falls back to string
t = env.from_string("hello {{ name }}")
assert t.render(name="world") == "hello world"
```

---

## Relationship to Other Modules

| Module | Relationship |
|--------|-------------|
| [environment.md](environment.md) | `NativeEnvironment` and `NativeTemplate` subclass `Environment` and `Template`. All configuration, loading, and context behavior is inherited. |
| [compiler.md](compiler.md) | `NativeCodeGenerator` subclasses `CodeGenerator` and reuses `has_safe_repr` and the `Frame`/`_FinalizeInfo` machinery. |
| [nodes.md](nodes.md) | Uses `nodes.Impossible`, `nodes.TemplateData`, and `nodes.Expr` during constant folding. |
| [runtime.md](runtime.md) | The generated `root_render_func` and `Context` come from the runtime; `native_concat` consumes their output. |
| [exceptions.md](exceptions.md) | `handle_exception` rewrites tracebacks; parse failures in `native_concat` are caught locally. |

---

## Design Considerations

- **Backwards compatibility with Python 3.10+**: The explicit `ast.parse(..., mode="eval")` call preserves leading whitespace behavior that `literal_eval` changed in newer Python versions.
- **Graceful degradation**: If the rendered output is not a valid Python literal, the raw string is returned rather than raising an error. This makes the environment safe for mixed content.
- **Minimal surface area**: By subclassing rather than forking, the module automatically inherits bug fixes and new features added to the base environment, template, and compiler.
- **Async support**: `render_async` mirrors the synchronous path and requires `enable_async=True` on the environment, consistent with the base [`Template`](environment.md).
