# Runtime Execution Support

## Purpose

The `Runtime_Execution_Support` module provides the foundational infrastructure that Jinja2 templates rely on **after** they have been parsed and compiled into Python code. While the parsing and compilation pipeline turns template source into executable Python functions, this module supplies everything those functions need at execution time: the runtime context and variable resolution machinery, the exception hierarchy used for error reporting, the shared utility helpers (escaping, hashing, LRU caches, etc.), and the built-in filter functions exposed to templates.

In short, this module is the "standard library" of the Jinja2 template engine — it is what makes compiled templates actually runnable and useful.

## Architecture

The module is composed of four cooperating components. `runtime.py` sits at the center, orchestrating execution and depending on the other three; `filters.py` and `exceptions.py` both build on `utils.py`, and `filters.py` additionally raises the exceptions defined in `exceptions.py`.

```mermaid
graph TD
    subgraph Runtime_Execution_Support
        R[runtime.py<br/>Context, variable resolution,<br/>output buffering, template references]
        F[filters.py<br/>Built-in template filters]
        E[exceptions.py<br/>Template error hierarchy]
        U[utils.py<br/>Escaping, hashing, LRU cache,<br/>shared helpers]
    end

    R -->|uses helpers| U
    R -->|raises| E
    F -->|uses helpers| U
    F -->|raises| E
    E -->|uses helpers| U

    C[Compiled template code] -->|executes against| R
    C -->|calls| F
```

### Component Roles

- **`runtime.py`** — The execution core. Defines `Context` (the variable-resolution scope chain), `TemplateReference`, output/loop helpers, and the machinery that compiled template functions call into while rendering.
- **`exceptions.py`** — The error hierarchy (`TemplateError`, `UndefinedError`, `TemplateNotFound`, `TemplateSyntaxError`, `TemplatesNotFound`, etc.) that gives users meaningful diagnostics when rendering fails.
- **`utils.py`** — Shared, dependency-light helpers used across the engine: HTML/XML escaping, `Markup` handling, `LRUCache`, `Cycler`, `Joiner`, `Namespace`, `soft_str`, and similar utilities.
- **`filters.py`** — The collection of built-in filters (`escape`, `join`, `default`, `map`, `select`, `sort`, `groupby`, etc.) that templates invoke via the `|` operator.

## Core Components

Detailed documentation for each component:

- [runtime.md](runtime.md) — Runtime context, variable resolution, and execution helpers.
- [exceptions.md](exceptions.md) — Exception hierarchy for template errors.
- [utils.md](utils.md) — Shared utility functions and data structures.
- [filters.md](filters.md) — Built-in template filters.