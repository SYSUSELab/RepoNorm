# Runtime Execution Support

## Introduction

The `runtime` module (`src/jinja2/runtime.py`) provides the **runtime functions and state used by compiled templates**. While the [Parsing and Compilation Pipeline](parsing_and_compilation_pipeline.md) transforms template source into Python code, the runtime module supplies the objects that this generated code interacts with during template evaluation.

Its responsibilities include:

- **Context management** — holding template variables, blocks, and the evaluation context (`Context`, `TemplateReference`, `BlockReference`).
- **Loop support** — wrapping iterables to expose loop metadata such as `index`, `first`, `last`, and recursion (`LoopContext`, `AsyncLoopContext`).
- **Macro wrapping** — adapting compiled macro functions into callable objects with argument binding and autoescape handling (`Macro`).
- **Undefined handling** — providing the family of `Undefined` types that control how missing variables behave (`Undefined`, `ChainableUndefined`, `DebugUndefined`, `StrictUndefined`).
- **Runtime helpers** — small utilities exported into the template namespace (`identity`, `markup_join`, `str_join`, `new_context`).

The module is tightly coupled with the [Template Environment and Loading](template_environment_and_loading.md) module (which selects the `context_class` and `undefined` class) and the [Parsing and Compilation Pipeline](parsing_and_compilation_pipeline.md) (whose generated code calls into these runtime objects).

---

## Architecture Overview

The runtime module sits between the compiled template code and the environment. The environment configures which runtime classes are used, and the compiled code instantiates and calls them.

```mermaid
graph TD
    subgraph Environment["Template Environment and Loading"]
        ENV[Environment]
        ENV -->|context_class| CTX
        ENV -->|undefined| UND
        ENV -->|is_async| LOOP
    end

    subgraph Runtime["Runtime Execution Support"]
        CTX[Context]
        TR[TemplateReference]
        BR[BlockReference]
        LOOP[LoopContext / AsyncLoopContext]
        MACRO[Macro]
        UND[Undefined family]
        HELPERS[identity / markup_join / str_join / new_context]
    end

    subgraph Pipeline["Parsing and Compilation Pipeline"]
        COMP[CodeGenerator]
        NODES[EvalContext]
    end

    COMP -->|generates code calling| CTX
    COMP -->|generates code calling| LOOP
    COMP -->|generates code calling| MACRO
    NODES -->|eval_ctx stored in| CTX
    CTX -->|creates| TR
    TR -->|creates| BR
    CTX -->|uses| UND
    LOOP -->|uses| UND
    MACRO -->|uses| UND
```

---

## Core Components

### Context

`Context` is the central runtime object holding the variables of a template. It is registered as an `abc.Mapping`, so it supports read-only dict operations (`get`, `keys`, `values`, `items`, `__getitem__`, `__contains__`).

Key characteristics:

- **Immutable by contract** — `parent` must not be modified; `vars` may only be modified by generated template code.
- **Two-layer lookup** — variables are resolved first from `vars` (template-local) then from `parent` (globals + passed vars).
- **`resolve` vs `resolve_or_missing`** — `resolve` returns an `Undefined` for missing keys, while `resolve_or_missing` returns the `missing` sentinel. Custom lookup behavior should override `resolve_or_missing`.
- **`call`** — invokes a callable while injecting the active context, eval context, or environment as the first argument, based on the `_PassArg` marker (see [utils](utils.md)).
- **`derived`** — creates an independent child context sharing the same template, used for loops and blocks so that variables set inside them do not mutate the parent context.
- **`super`** — resolves the parent block for template inheritance.

The `Context` is created via the `new_context` helper, which merges globals, vars, and locals into the `parent` mapping and instantiates `environment.context_class`.

```mermaid
flowchart TD
    A[resolve_or_missing key] --> B{key in vars?}
    B -->|yes| C[return vars key]
    B -->|no| D{key in parent?}
    D -->|yes| E[return parent key]
    D -->|no| F[return missing sentinel]
    F --> G[resolve wraps as Undefined]
```

### TemplateReference and BlockReference

- **`TemplateReference`** represents the `self` object available inside templates. Indexing it by block name (`self["blockname"]`) returns a `BlockReference`.
- **`BlockReference`** represents a single block on a template reference. It holds a *stack* of block implementations (populated during template inheritance) and a *depth* pointer. Calling it renders the block at the current depth; the `super` property returns a `BlockReference` one level deeper, enabling `{{ super() }}`.

Both support synchronous and asynchronous rendering, choosing the async path when `environment.is_async` is true.

### LoopContext and AsyncLoopContext

`LoopContext` wraps an iterable to expose rich loop metadata to templates:

| Attribute | Description |
|-----------|-------------|
| `index0` / `index` | Current iteration, 0-based / 1-based |
| `revindex0` / `revindex` | Iterations from the end, 0-based / 1-based |
| `first` / `last` | Whether this is the first / last iteration |
| `length` | Length of the iterable (eagerly evaluated for generators) |
| `previtem` / `nextitem` | Previous / next item (Undefined at boundaries) |
| `depth` / `depth0` | Recursion depth, 1-based / 0-based |
| `cycle(*args)` | Cycle through values based on `index0` |
| `changed(*value)` | Detect value changes between iterations |

`last` and `nextitem` peek one item ahead, caching the result in `_after`. This early advancement can interfere with `itertools.groupby`; the `groupby` filter works around this.

`AsyncLoopContext` subclasses `LoopContext` and overrides the iterator to use `auto_aiter`, making `length`, `revindex0`, `revindex`, `last`, and `nextitem` awaitable. It implements `__aiter__` / `__anext__` instead of `__iter__` / `__next__`.

```mermaid
classDiagram
    class LoopContext {
        +index0
        +length
        +depth
        +index
        +revindex0
        +revindex
        +first
        +last
        +previtem
        +nextitem
        +cycle()
        +changed()
        +__next__()
        +__call__()
    }
    class AsyncLoopContext {
        +length (async)
        +revindex0 (async)
        +revindex (async)
        +last (async)
        +nextitem (async)
        +__anext__()
    }
    LoopContext <|-- AsyncLoopContext
```

### Macro

`Macro` wraps a compiled macro function, handling:

- **Argument binding** — positional arguments are consumed first, then keyword arguments and defaults fill the remainder.
- **Caller handling** — the special `caller` argument is appended in a fixed order (caller, keyword arguments, positional arguments) that must match the compiler's `function_scoping` method.
- **Autoescape decision** — determined at *call time* from the passed `EvalContext` (falling back to the compile-time default), because whether a macro is safe depends on when it is used, not when it was defined.
- **`catch_kwargs` / `catch_varargs`** — control whether extra keyword/positional arguments are collected or raise `TypeError`.

Like blocks, macros dispatch to an async invocation path when `environment.is_async` is true.

### Undefined Family

The `Undefined` types control how missing variables behave. All share the same constructor signature (`hint`, `obj`, `name`, `exc`) and build a descriptive `_undefined_message`.

```mermaid
classDiagram
    class Undefined {
        +_undefined_message
        +_fail_with_undefined_error()
        +__str__() ""
        +__bool__() False
        +__iter__() empty
    }
    class ChainableUndefined {
        +__getattr__() self
        +__getitem__() self
    }
    class DebugUndefined {
        +__str__() debug info
    }
    class StrictUndefined {
        +__str__() raises
        +__iter__() raises
        +__bool__() raises
    }
    Undefined <|-- ChainableUndefined
    Undefined <|-- DebugUndefined
    Undefined <|-- StrictUndefined
```

| Type | Behavior |
|------|----------|
| `Undefined` | Printable and iterable (empty); all other operations raise `UndefinedError`. |
| `ChainableUndefined` | `__getattr__` and `__getitem__` return `self`, allowing chained access like `foo.bar['baz']`. |
| `DebugUndefined` | Prints debug info such as `{{ foo }}` instead of an empty string. |
| `StrictUndefined` | Raises on print, iteration, boolean tests, comparisons, and containment. |

The `make_logging_undefined` factory produces a subclass that logs warnings on print/iteration/boolean use and errors on failures, useful for debugging missing variables.

### Runtime Helpers

- **`identity(x)`** — returns its argument unchanged.
- **`markup_join(seq)`** — concatenates a sequence, escaping if any element has `__html__`.
- **`str_join(seq)`** — converts each element to `str` and concatenates.
- **`new_context(...)`** — internal helper that builds a `Context`, merging globals/vars/locals and handling the `shared` flag.

The module also defines two export lists consumed by the compiler:

- **`exported`** — names injected into the template runtime namespace (`LoopContext`, `TemplateReference`, `Macro`, `Markup`, `missing`, `escape`, `markup_join`, `str_join`, `identity`, `Namespace`, `Undefined`, etc.).
- **`async_exported`** — async-only names (`AsyncLoopContext`, `auto_aiter`, `auto_await`).

---

## Dependencies

The runtime module depends on several sibling modules. Refer to their documentation for details rather than duplicating information here.

```mermaid
graph LR
    RT[runtime.py]
    RT --> EX[exceptions.md<br/>UndefinedError, TemplateRuntimeError, TemplateNotFound]
    RT --> UT[utils.md<br/>_PassArg, concat, internalcode, missing, Namespace, object_type_repr, pass_eval_context]
    RT --> ND[nodes.md<br/>EvalContext]
    RT --> AU[async_utils.md<br/>auto_aiter, auto_await]
    RT --> MS[markupsafe<br/>Markup, escape, soft_str]
    RT -.->|TYPE_CHECKING| ENV[environment.md<br/>Environment]
```

| Dependency | Used For |
|------------|----------|
| [exceptions](exceptions.md) | `UndefinedError`, `TemplateRuntimeError`, `TemplateNotFound` raised by undefined values and re-exported. |
| [utils](utils.md) | `_PassArg` for argument injection, `concat` for joining, `internalcode` for marking internal functions, `missing` sentinel, `Namespace`, `object_type_repr`, `pass_eval_context`. |
| [nodes](nodes.md) | `EvalContext` stored on each `Context` and passed to macros. |
| [async_utils](async_utils.md) | `auto_aiter` for async loop iteration, `auto_await` for awaiting values. |
| `markupsafe` | `Markup`, `escape`, `soft_str` for safe string handling. |
| [environment](template_environment_and_loading.md) | `Environment` (type-checking only) supplies `context_class`, `undefined`, `autoescape`, and `is_async`. |

---

## Data Flow: Template Evaluation

The following sequence shows how the runtime objects participate when a compiled template is rendered.

```mermaid
sequenceDiagram
    participant Env as Environment
    participant NC as new_context
    participant Ctx as Context
    participant Code as Compiled Template Code
    participant Loop as LoopContext
    participant Und as Undefined

    Env->>NC: render(vars, globals)
    NC->>Ctx: instantiate context_class
    Ctx->>Ctx: build eval_ctx, blocks mapping
    Code->>Ctx: resolve_or_missing(name)
    alt variable found
        Ctx-->>Code: value
    else variable missing
        Ctx->>Und: environment.undefined(name)
        Und-->>Code: Undefined instance
    end
    Code->>Loop: wrap iterable for for-loop
    Loop-->>Code: (item, loop) per iteration
    Code->>Ctx: call(filter, args) with pass_arg injection
    Ctx-->>Code: result
```

---

## Process Flow: Context Derivation

When a loop or block needs an independent scope, the runtime derives a new context rather than mutating the existing one.

```mermaid
flowchart TD
    A[Context.derived locals] --> B[new_context with shared=True]
    B --> C[copy parent via get_all]
    C --> D[apply locals where value is not missing]
    D --> E[copy eval_ctx from parent]
    E --> F[copy blocks mapping]
    F --> G[return derived Context]
```

---

## Related Modules

- [Template Environment and Loading](template_environment_and_loading.md) — configures `context_class`, `undefined`, and `is_async`; provides loaders and bytecode caching.
- [Parsing and Compilation Pipeline](parsing_and_compilation_pipeline.md) — generates the code that calls runtime objects; defines `EvalContext` and the compiler's `function_scoping` contract that `Macro` must match.
- [exceptions](exceptions.md) — the exception hierarchy raised by undefined values and runtime errors.
- [utils](utils.md) — supporting utilities including `_PassArg`, `concat`, and `missing`.
- [async_utils](async_utils.md) — async iteration and awaiting helpers.
- [ext](ext.md) — extensions such as `LoopControlExtension` that interact with loop runtime behavior.
