# Utils Module

## Introduction

The `utils` module (`src/jinja2/utils.py`) provides a collection of foundational helper utilities that are shared across the entire Jinja2 templating engine. Unlike the higher-level modules that handle parsing, compilation, or runtime execution, this module contains low-level building blocks: caching primitives, template-facing helper objects, decorators for argument injection, and miscellaneous string/URL/JSON helpers.

These utilities are consumed by nearly every other subsystem. For example, the [`Environment`](environment.md) uses `LRUCache` for template caching and `select_autoescape` for autoescape configuration; the [`runtime`](runtime.md) module relies on `missing` and `is_undefined`; and the [`filters`](filters.md) module uses `pass_context`/`pass_environment` decorators and `htmlsafe_json_dumps`.

The module is intentionally dependency-light, importing only from the standard library and `markupsafe`, with lazy imports for Jinja2-internal modules to avoid circular dependencies.

---

## Architecture Overview

The `utils` module sits at the bottom of the Jinja2 dependency graph. It is a leaf module that other modules depend on, but it depends on almost nothing within Jinja2 itself (only lazy, function-local imports).

```mermaid
graph TD
    subgraph "utils.py (this module)"
        LRU[LRUCache]
        CY[Cycler]
        JN[Joiner]
        NS[Namespace]
        PA[_PassArg]
        PC[pass_context / pass_eval_context / pass_environment]
        SA[select_autoescape]
        HJ[htmlsafe_json_dumps]
        UZ[urlize]
        IS[is_undefined]
        MS[missing]
    end

    ENV[environment.py<br/>Environment]
    RT[runtime.py<br/>Undefined / Context]
    FLT[filters.py]
    LEX[lexer.py]
    EXT[ext.py]

    ENV -->|uses LRUCache, select_autoescape| LRU
    ENV -->|uses select_autoescape| SA
    ENV -->|uses _PassArg| PA
    RT -->|uses missing, is_undefined, object_type_repr| MS
    RT -->|uses is_undefined| IS
    FLT -->|uses pass_* decorators, htmlsafe_json_dumps, urlize| PC
    FLT -->|uses htmlsafe_json_dumps| HJ
    FLT -->|uses urlize| UZ
    LEX -->|uses internalcode| LRU
    EXT -->|uses pass_* decorators| PC

    style LRU fill:#e1f5ff
    style CY fill:#e1f5ff
    style JN fill:#e1f5ff
    style NS fill:#e1f5ff
    style PA fill:#e1f5ff
```

---

## Core Components

### `_PassArg` (Enum)

`_PassArg` is an enumeration that encodes *which* implicit argument should be injected into a decorated function when it is invoked during template rendering. It is the mechanism behind Jinja2's "pass argument" decorators.

```python
class _PassArg(enum.Enum):
    context = enum.auto()
    eval_context = enum.auto()
    environment = enum.auto()

    @classmethod
    def from_obj(cls, obj: F) -> t.Optional["_PassArg"]:
        if hasattr(obj, "jinja_pass_arg"):
            return obj.jinja_pass_arg
        return None
```

| Member | Meaning |
|--------|---------|
| `context` | Inject the `jinja2.runtime.Context` as the first argument. |
| `eval_context` | Inject the `jinja2.nodes.EvalContext` as the first argument. |
| `environment` | Inject the `jinja2.Environment` as the first argument. |

The `from_obj` classmethod inspects a callable for the `jinja_pass_arg` attribute (set by the decorators below) and returns the corresponding enum member, or `None` if the callable is not decorated.

**Consumers:** The [`Environment._filter_test_common`](environment.md) method calls `_PassArg.from_obj(func)` to decide which argument to prepend when invoking filters and tests.

---

### Pass-Argument Decorators

Three decorators attach a `_PassArg` marker to a function so that the runtime knows to inject the appropriate object:

```python
def pass_context(f: F) -> F:
    f.jinja_pass_arg = _PassArg.context
    return f

def pass_eval_context(f: F) -> F:
    f.jinja_pass_arg = _PassArg.eval_context
    return f

def pass_environment(f: F) -> F:
    f.jinja_pass_arg = _PassArg.environment
    return f
```

These can be applied to **functions, filters, and tests**. They replace the older `contextfunction`/`contextfilter`, `evalcontextfunction`/`evalcontextfilter`, and `environmentfunction`/`environmentfilter` decorators (deprecated since Jinja 3.0).

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant Dec as pass_context
    participant Fn as Custom Filter
    participant Env as Environment
    participant Ctx as Context

    Dev->>Dec: @pass_context
    Dec->>Fn: set jinja_pass_arg = _PassArg.context
    Note over Env: During rendering
    Env->>Env: _PassArg.from_obj(Fn)
    Env->>Ctx: retrieve Context
    Env->>Fn: Fn(context, value, ...)
```

---

### `LRUCache`

`LRUCache` is a simple, thread-safe Least-Recently-Used cache implementation. It is registered as a virtual subclass of `collections.abc.MutableMapping`.

```python
@abc.MutableMapping.register
class LRUCache:
    def __init__(self, capacity: int) -> None: ...
```

**Design notes:**
- Optimized for small capacities (below ~1000 entries), which is the typical use case for template caching.
- Uses a `dict` for storage (`_mapping`) and a `deque` for recency ordering (`_queue`).
- All mutating operations are guarded by a `threading.Lock` (`_wlock`).
- Queue methods are aliased in `_postinit` for faster attribute lookup.

**Key methods:**

| Method | Description |
|--------|-------------|
| `get(key, default=None)` | Return item or `default`. |
| `setdefault(key, default=None)` | Set and return `default` if key absent. |
| `clear()` | Empty the cache (thread-safe). |
| `copy()` | Return a shallow copy. |
| `__getitem__` / `__setitem__` / `__delitem__` | Mapping access; reads and writes move the key to the most-recent position. |
| `items()` / `values()` / `keys()` | Iterate in most-recently-used-first order. |
| `__iter__` / `__reversed__` | Iterate keys newest-first / oldest-first. |

**Pickling support:** `__getstate__`, `__setstate__`, and `__getnewargs__` are implemented so the cache can be serialized (the lock is recreated in `_postinit`).

```mermaid
flowchart LR
    A[__setitem__ key] --> B{key in mapping?}
    B -->|yes| C[remove from queue]
    B -->|no| D{len == capacity?}
    D -->|yes| E[evict popleft key]
    D -->|no| F[continue]
    C --> G[append key to queue]
    E --> G
    F --> G
    G --> H[mapping key = value]
```

**Consumers:** The [`Environment`](environment.md) uses `LRUCache` (via `create_cache`) to store compiled templates keyed by `(weakref(loader), name)`.

---

### `Cycler`

`Cycler` cycles through a fixed set of values, yielding them one at a time and restarting when the end is reached. It is exposed to templates as the `cycler` global.

```python
class Cycler:
    def __init__(self, *items: t.Any) -> None:
        if not items:
            raise RuntimeError("at least one item has to be provided")
        self.items = items
        self.pos = 0
```

| Member | Description |
|--------|-------------|
| `reset()` | Reset position to the first item. |
| `current` (property) | The item that will be returned by the next `next()` call. |
| `next()` / `__next__` | Return the current item and advance the position (wrapping around). |

Unlike `loop.cycle`, a `Cycler` can be used **outside loops** or **across multiple loops**, making it ideal for alternating row classes in a list.

```mermaid
stateDiagram-v2
    [*] --> Item0
    Item0 --> Item1: next()
    Item1 --> Item2: next()
    Item2 --> Item0: next() (wrap)
    Item0 --> Item0: reset()
```

---

### `Joiner`

`Joiner` is a small helper that returns an empty string on its first call and a separator on every subsequent call. It is exposed to templates as the `joiner` global and is useful for inserting separators between items without trailing separators.

```python
class Joiner:
    def __init__(self, sep: str = ", ") -> None:
        self.sep = sep
        self.used = False

    def __call__(self) -> str:
        if not self.used:
            self.used = True
            return ""
        return self.sep
```

---

### `Namespace`

`Namespace` is a mutable object that holds arbitrary attributes. It can be initialized from a dictionary or with keyword arguments and is exposed to templates as the `namespace` global. It is commonly used to carry state across loop iterations (since Jinja scoping otherwise prevents assignment to outer variables).

```python
class Namespace:
    def __init__(*args: t.Any, **kwargs: t.Any) -> None:
        self, args = args[0], args[1:]
        self.__attrs = dict(*args, **kwargs)

    def __getattribute__(self, name: str) -> t.Any:
        if name in {"_Namespace__attrs", "__class__"}:
            return object.__getattribute__(self, name)
        try:
            return self.__attrs[name]
        except KeyError:
            raise AttributeError(name) from None

    def __setitem__(self, name: str, value: t.Any) -> None:
        self.__attrs[name] = value
```

**Behavior notes:**
- Attribute access is redirected to the internal `__attrs` dict; missing names raise `AttributeError`.
- `__class__` is special-cased because it is required for the awaitable check in async mode.
- Supports item assignment via `__setitem__`.

---

## Supporting Utilities

Beyond the core components, the module provides a number of standalone helper functions and constants used throughout Jinja2.

### Sentinels and Markers

| Name | Purpose |
|------|---------|
| `missing` | A singleton representing a missing value for the runtime. Used as the default `obj` in `Undefined`. |
| `internal_code` | A mutable set of `CodeType` objects marked as internally used. |
| `concat` | Alias for `"".join`, used as the default concatenation function. |
| `internalcode(f)` | Decorator that registers a function's code object in `internal_code`. |

### Type / Value Helpers

| Function | Description |
|----------|-------------|
| `is_undefined(obj)` | Instance check against `jinja2.runtime.Undefined` (lazy import). |
| `object_type_repr(obj)` | Human-readable type name, with special handling for `None` and `Ellipsis`. |
| `consume(iterable)` | Exhaust an iterable without using its values. |
| `pformat(obj)` | Wrapper around `pprint.pformat`. |

### Import / File Helpers

| Function | Description |
|----------|-------------|
| `import_string(import_name, silent=False)` | Import an object from a dotted or colon-delimited path. |
| `open_if_exists(filename, mode="rb")` | Open a file if it exists, else return `None`. |
| `clear_caches()` | Clear Jinja's internal environment and lexer caches. |

### String / URL / JSON Helpers

| Function | Description |
|----------|-------------|
| `urlize(text, ...)` | Convert URLs and email addresses in text into clickable HTML links. |
| `url_quote(obj, charset="utf-8", for_qs=False)` | Quote a string/bytes for use in a URL. |
| `htmlsafe_json_dumps(obj, dumps=None, **kwargs)` | Serialize to JSON and escape HTML-unsafe characters, returning `Markup`. |
| `generate_lorem_ipsum(n=5, html=True, min=20, max=100)` | Generate lorem ipsum placeholder text. |
| `select_autoescape(...)` | Build an autoescape callable based on template filename extensions. |

#### `select_autoescape`

This factory returns a callable suitable for the `Environment(autoescape=...)` parameter. It decides whether autoescaping is enabled based on the template's filename extension, with separate defaults for string templates.

```mermaid
flowchart TD
    A[autoescape template_name] --> B{template_name is None?}
    B -->|yes| C[return default_for_string]
    B -->|no| D[lowercase name]
    D --> E{ends with enabled_extensions?}
    E -->|yes| F[return True]
    E -->|no| G{ends with disabled_extensions?}
    G -->|yes| H[return False]
    G -->|no| I[return default]
```

#### `htmlsafe_json_dumps`

Serializes an object with `json.dumps` (or a custom `dumps`), then replaces `<`, `>`, `&`, and `'` with their Unicode escape sequences and wraps the result in `markupsafe.Markup`. This makes the output safe to embed in HTML documents and `<script>` tags. It backs the `|tojson` template filter.

#### `urlize`

Uses two compiled regular expressions (`_http_re` and `_email_re`) to detect URLs and email addresses. It handles:
- `http://`, `https://`, `www.`, `mailto:`, and bare email addresses.
- Trailing/leading punctuation balancing (parentheses, brackets, periods).
- Optional `rel`, `target`, and `extra_schemes` parameters.
- URL trimming via `trim_url_limit`.

---

## Data Flow: Template Rendering Utilities

The following diagram shows how the utilities in this module participate in a typical template render, from environment setup through filter invocation.

```mermaid
sequenceDiagram
    participant User
    participant Env as Environment
    participant Cache as LRUCache
    participant Loader as BaseLoader
    participant Tmpl as Template
    participant Filter as Filter/Test

    User->>Env: get_template("page.html")
    Env->>Cache: get((loader_ref, name))
    alt cache hit
        Cache-->>Env: Template
    else cache miss
        Env->>Loader: load(env, name, globals)
        Loader-->>Env: Template
        Env->>Cache: __setitem__((loader_ref, name), Template)
    end
    Env-->>User: Template
    User->>Tmpl: render(context)
    Tmpl->>Env: call_filter(name, value, ...)
    Env->>Env: _PassArg.from_obj(func)
    alt pass_context
        Env->>Filter: func(context, value, ...)
    else pass_environment
        Env->>Filter: func(env, value, ...)
    else plain
        Env->>Filter: func(value, ...)
    end
    Filter-->>Tmpl: result
```

---

## Component Interaction Summary

```mermaid
graph LR
    subgraph "Template Globals"
        CY[Cycler]
        JN[Joiner]
        NS[Namespace]
    end

    subgraph "Decorators"
        PC[pass_context]
        PE[pass_eval_context]
        PEN[pass_environment]
        PA[_PassArg]
    end

    subgraph "Infrastructure"
        LRU[LRUCache]
        MS[missing]
        IC[internalcode]
    end

    PC --> PA
    PE --> PA
    PEN --> PA
    PA -->|from_obj| ENV[Environment]
    LRU -->|template cache| ENV
    MS -->|undefined sentinel| RT[runtime.Undefined]
    CY -->|cycler global| ENV
    JN -->|joiner global| ENV
    NS -->|namespace global| ENV
```

---

## Related Modules

- **[environment.md](environment.md)** — The `Environment` class, which consumes `LRUCache`, `select_autoescape`, and `_PassArg`.
- **[runtime.md](runtime.md)** — The `Undefined` type and `Context`, which rely on `missing`, `is_undefined`, and `object_type_repr`.
- **[filters.md](filters.md)** — Built-in filters and tests that use the pass-argument decorators, `htmlsafe_json_dumps`, and `urlize`.
- **[lexer.md](lexer.md)** — The lexer, which uses `internalcode` and `clear_caches`.
- **[ext.md](ext.md)** — Extensions that use the pass-argument decorators.
