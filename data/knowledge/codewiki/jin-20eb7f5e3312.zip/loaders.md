# Loaders Module

## Introduction

The `loaders` module (`src/jinja2/loaders.py`) provides the API and concrete implementations for **loading templates from different data sources**. It is the bridge between the [`Environment`](environment.md) and the raw template source code: whenever a template is requested by name, the environment delegates the actual retrieval of the source to a loader.

The module defines an abstract base class (`BaseLoader`) that establishes the loading contract, plus a family of concrete loaders covering the most common storage backends:

- **File system** directories (`FileSystemLoader`)
- **Python packages** (`PackageLoader`)
- **In-memory dictionaries** (`DictLoader`)
- **Arbitrary callables** (`FunctionLoader`)
- **Precompiled modules** (`ModuleLoader`)
- **Composition** of other loaders (`PrefixLoader`, `ChoiceLoader`)

This module belongs to the **Template Environment and Loading** subsystem. For the environment that consumes these loaders, see [environment.md](environment.md). For bytecode caching used during loading, see [bccache.md](bccache.md).

---

## Architecture Overview

The loaders module is built around a single abstract contract (`BaseLoader`) and a set of concrete implementations. Two of the loaders (`PrefixLoader`, `ChoiceLoader`) are *composite* loaders that delegate to other loaders, enabling flexible template resolution strategies.

```mermaid
classDiagram
    class BaseLoader {
        +bool has_source_access
        +get_source(environment, template)
        +list_templates()
        +load(environment, name, globals)
    }
    class FileSystemLoader {
        +searchpath
        +encoding
        +followlinks
    }
    class PackageLoader {
        +package_name
        +package_path
        +encoding
    }
    class DictLoader {
        +mapping
    }
    class FunctionLoader {
        +load_func
    }
    class ModuleLoader {
        +module
        +package_name
        +get_template_key(name)$
        +get_module_filename(name)$
    }
    class PrefixLoader {
        +mapping
        +delimiter
        +get_loader(template)
    }
    class ChoiceLoader {
        +loaders
    }
    class _TemplateModule {
        <<ModuleType>>
    }

    BaseLoader <|-- FileSystemLoader
    BaseLoader <|-- PackageLoader
    BaseLoader <|-- DictLoader
    BaseLoader <|-- FunctionLoader
    BaseLoader <|-- ModuleLoader
    BaseLoader <|-- PrefixLoader
    BaseLoader <|-- ChoiceLoader

    PrefixLoader o-- BaseLoader : delegates to
    ChoiceLoader o-- BaseLoader : delegates to
    ModuleLoader ..> _TemplateModule : creates
```

---

## Core Concepts

### The Loading Contract

Every loader must implement `get_source`, which returns a 3-tuple:

```
(source: str, filename: Optional[str], uptodate: Optional[Callable[[], bool]])
```

| Element | Meaning |
| --- | --- |
| `source` | The template source code as a string. |
| `filename` | The filesystem path (used for tracebacks), or `None` if not file-based. |
| `uptodate` | A zero-argument callable returning `True` if the template is still current. Used for auto-reload. May be `None` (always considered current). |

If a template cannot be located, the loader must raise [`TemplateNotFound`](exceptions.md).

### The `load` Method

`BaseLoader.load` is the high-level entry point invoked by the environment. It orchestrates the full loading pipeline: source retrieval → bytecode cache lookup → compilation → template construction. Subclasses should **not** override `load`; composite loaders call `get_source` (or `load`) on their children directly.

```mermaid
flowchart TD
    A[Environment.get_template] --> B[BaseLoader.load]
    B --> C[get_source]
    C --> D{Source found?}
    D -- No --> E[raise TemplateNotFound]
    D -- Yes --> F{bytecode_cache set?}
    F -- Yes --> G[get_bucket / read cached code]
    F -- No --> H[code = None]
    G --> I{code available?}
    H --> I
    I -- No --> J[environment.compile source]
    I -- Yes --> K[use cached code]
    J --> L[store code in bucket]
    K --> M[template_class.from_code]
    L --> M
    M --> N[Template instance]
```

---

## Component Reference

### `BaseLoader`

The abstract base class for all loaders. It defines:

- **`has_source_access`** (class attribute, default `True`): When `False`, the loader cannot expose template source (e.g. `ModuleLoader`). Calling `get_source` then raises `RuntimeError`.
- **`get_source(environment, template)`**: Must be overridden. Default implementation raises `TemplateNotFound`.
- **`list_templates()`**: Default raises `TypeError`; loaders that support enumeration override this.
- **`load(environment, name, globals)`**: Decorated with `@internalcode`. Implements the full loading pipeline described above.

### `FileSystemLoader`

Loads templates from one or more directories on the file system.

- **`searchpath`**: A single path or a sequence of paths. Directories are searched in order; the first match wins.
- **`encoding`**: Text encoding used to read template files (default `utf-8`).
- **`followlinks`**: Whether to follow symbolic links during directory walks.

Path traversal is guarded by `split_template_path`, which rejects `..` segments and path separators embedded in a template name, raising `TemplateNotFound` on suspicious input.

`list_templates` walks each search path and returns sorted, normalized (forward-slash) template names.

### `PackageLoader`

Loads templates from a directory inside an installed Python package.

- **`package_name`**: Import name of the package (e.g. `project.ui`).
- **`package_path`**: Subdirectory within the package (default `templates`).
- **`encoding`**: Text encoding (default `utf-8`).

The constructor imports the package and inspects its import spec to locate the template root. It supports:

- Regular packages installed as directories.
- Zip/egg packages (via `zipimport.zipimporter`).
- Limited [PEP 420](https://peps.python.org/pep-0420/) namespace packages (the template directory must live in a single namespace contributor).

For zip-based packages, `uptodate` is `None` (always considered current) because reloading the archive safely is not feasible.

### `DictLoader`

Loads templates from an in-memory mapping of name → source. Primarily useful for testing.

```python
loader = DictLoader({"index.html": "source here"})
```

The `uptodate` callable compares the current mapping value against the originally loaded source, so mutations to the dict are detected.

### `FunctionLoader`

Delegates loading to a user-supplied callable. The callable receives the template name and may return:

- A `str` (source only),
- A `(source, filename, uptodate)` tuple, or
- `None` (template not found → `TemplateNotFound`).

### `ModuleLoader`

Loads templates from **precompiled** Python modules. It sets `has_source_access = False`.

- Templates are precompiled via [`Environment.compile_templates`](environment.md).
- A synthetic module (`_TemplateModule`) is registered in `sys.modules` under a unique package name derived from the loader's `id`. The `sys.modules` entry is a `weakref.proxy`, so the module is garbage-collected once the loader is gone.
- `get_template_key(name)` produces a deterministic module name via `sha1` hashing.
- `get_module_filename(name)` returns the corresponding `.py` filename.
- `load` imports the compiled module and builds a template via `template_class.from_module_dict`.

### `PrefixLoader`

A composite loader mapping **prefixes** to child loaders. The prefix is separated from the template name by a delimiter (default `/`).

```python
loader = PrefixLoader({
    "app1": PackageLoader("mypackage.app1"),
    "app2": PackageLoader("mypackage.app2"),
})
# "app1/index.html" -> mypackage.app1
```

`get_loader` splits the name and resolves the child loader. Both `get_source` and `load` re-raise `TemplateNotFound` with the *prefixed* name so error messages remain accurate.

### `ChoiceLoader`

A composite loader that tries a sequence of loaders in order, returning the first successful result. Useful for overriding built-in templates with user-provided ones.

```python
loader = ChoiceLoader([
    FileSystemLoader("/path/to/user/templates"),
    FileSystemLoader("/path/to/system/templates"),
])
```

`list_templates` aggregates and de-duplicates results from all child loaders.

### `_TemplateModule`

A minimal `ModuleType` subclass that adds weak-reference support, used internally by `ModuleLoader`.

---

## Composite Loader Resolution Flow

```mermaid
flowchart TD
    subgraph ChoiceLoader
        C1[loader 1] --> C2{found?}
        C2 -- No --> C3[loader 2]
        C2 -- Yes --> CR[return result]
        C3 --> C4{found?}
        C4 -- No --> C5[...]
        C4 -- Yes --> CR
        C5 --> CF[raise TemplateNotFound]
    end

    subgraph PrefixLoader
        P0[template: prefix/name] --> P1[split on delimiter]
        P1 --> P2[lookup child loader by prefix]
        P2 --> P3[delegate to child]
        P3 --> PR[return result]
    end
```

---

## Dependencies

```mermaid
graph LR
    loaders[loaders.py]
    loaders --> exceptions[exceptions.py<br/>TemplateNotFound]
    loaders --> utils[utils.py<br/>internalcode, open_if_exists]
    loaders -.uses.-> environment[environment.py<br/>Environment, Template]
    loaders -.uses.-> bccache[bccache.py<br/>BytecodeCache]
    environment -.uses.-> loaders
```

| Dependency | Purpose |
| --- | --- |
| [`exceptions.TemplateNotFound`](exceptions.md) | Raised when a template cannot be located. |
| [`utils.internalcode`](utils.md) | Marks `load` methods as internal API. |
| [`utils.open_if_exists`](utils.md) | Safely opens a file, returning `None` if absent. |
| [`environment.Environment`](environment.md) | Provides `compile`, `bytecode_cache`, `template_class`, and `make_globals`. |
| [`bccache.BytecodeCache`](bccache.md) | Optional bytecode cache consulted during `load`. |

---

## Integration with the Environment

The loader is wired into the environment via the `loader` constructor argument. The environment's `_load_template` method:

1. Checks its own template cache (keyed by a weak reference to the loader plus the name).
2. On a miss, calls `self.loader.load(self, name, self.make_globals(globals))`.
3. Stores the resulting template in the cache.

```mermaid
sequenceDiagram
    participant App
    participant Env as Environment
    participant Loader as BaseLoader
    participant Cache as BytecodeCache

    App->>Env: get_template("index.html")
    Env->>Env: check template cache
    Env->>Loader: load(env, "index.html", globals)
    Loader->>Loader: get_source(env, "index.html")
    Loader->>Cache: get_bucket(...)
    Cache-->>Loader: bucket (maybe cached code)
    alt no cached code
        Loader->>Env: compile(source, name, filename)
        Env-->>Loader: code object
        Loader->>Cache: set_bucket(bucket)
    end
    Loader->>Env: template_class.from_code(...)
    Env-->>Loader: Template
    Loader-->>Env: Template
    Env-->>App: Template
```

---

## Security Considerations

- **Path traversal protection**: `split_template_path` rejects `..` and embedded path separators, preventing templates from escaping the configured root.
- **Sandboxing**: Loaders themselves do not sandbox template execution. For untrusted templates, combine a loader with a sandboxed environment — see [sandbox.md](sandbox.md).
- **Source access**: Loaders with `has_source_access = False` (e.g. `ModuleLoader`) cannot leak source code, which is useful when distributing precompiled templates.

---

## Related Modules

- [environment.md](environment.md) — The `Environment` that consumes loaders and drives compilation.
- [bccache.md](bccache.md) — Bytecode caching used during the loading pipeline.
- [exceptions.md](exceptions.md) — `TemplateNotFound` and related error types.
- [utils.md](utils.md) — Helper utilities (`internalcode`, `open_if_exists`).
- [sandbox.md](sandbox.md) — Sandboxed environments for untrusted templates.
