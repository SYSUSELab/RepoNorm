# Nodes Module

## Introduction

The `nodes` module (`src/jinja2/nodes.py`) defines the **Abstract Syntax Tree (AST)** used throughout Jinja's template compilation pipeline. Every template is parsed into a tree of `Node` instances, which are then optimized, analyzed, and finally compiled into Python source code.

This module is the **central data model** of the parsing and compilation pipeline. It provides:

- A base `Node` class with a metaclass-driven field/attribute inheritance system.
- A rich hierarchy of concrete node types covering statements, expressions, literals, operators, and extension helpers.
- Tree traversal utilities (`iter_fields`, `iter_child_nodes`, `find`, `find_all`).
- Tree mutation utilities (`set_ctx`, `set_lineno`, `set_environment`).
- Compile-time constant folding via `as_const()` on expression nodes.
- The `EvalContext` object that carries evaluation-time information (autoescape, volatility).

The module sits at the heart of the [Parsing and Compilation Pipeline](parser.md), acting as the shared contract between the [parser](parser.md), [compiler](compiler.md), [optimizer](optimizer.md), [visitor](visitor.md), [idtracking](idtracking.md), and [meta](meta.md) modules.

---

## Architecture Overview

The nodes module is consumed by nearly every stage of the compilation pipeline. The diagram below shows how the AST flows between modules.

```mermaid
graph TD
    subgraph "Source"
        SRC[Template Source]
    end

    subgraph "Parsing and Compilation Pipeline"
        LEX[lexer.py<br/>Tokenization]
        PAR[parser.py<br/>Parser]
        NODES[nodes.py<br/>AST Node Definitions]
        OPT[optimizer.py<br/>Optimizer]
        IDT[idtracking.py<br/>Symbols]
        VIS[visitor.py<br/>NodeVisitor / NodeTransformer]
        CMP[compiler.py<br/>CodeGenerator]
        META[meta.py<br/>TrackingCodeGenerator]
    end

    subgraph "Runtime"
        RT[runtime.py<br/>Context / Undefined]
    end

    SRC --> LEX --> PAR
    PAR -->|builds| NODES
    NODES -->|traversed by| OPT
    NODES -->|analyzed by| IDT
    NODES -->|walked by| VIS
    NODES -->|compiled by| CMP
    NODES -->|introspected by| META
    CMP -->|generates code referencing| RT
    OPT -.->|subclass of NodeTransformer| VIS
    CMP -.->|subclass of NodeVisitor| VIS
    META -.->|subclass of CodeGenerator| CMP
```

### Key Relationships

| Consumer | Relationship to `nodes` |
| --- | --- |
| [parser](parser.md) | Constructs `Node` instances while parsing tokens into an AST. |
| [compiler](compiler.md) | `CodeGenerator` is a `NodeVisitor` that emits Python code for each node type. |
| [optimizer](optimizer.md) | `Optimizer` is a `NodeTransformer` that folds constant expressions using `as_const()`. |
| [visitor](visitor.md) | Provides the generic `NodeVisitor`/`NodeTransformer` traversal machinery used by all consumers. |
| [idtracking](idtracking.md) | `Symbols` analyzes node trees to track variable loads/stores. |
| [meta](meta.md) | `TrackingCodeGenerator` subclasses the compiler to find undeclared identifiers. |
| [runtime](runtime.md) | Provides `Context`, `Undefined`, and `Markup` semantics referenced by node evaluation. |

---

## Node Class Hierarchy

All nodes derive from the abstract `Node` base class. The hierarchy is organized into four major categories: **statements** (`Stmt`), **expressions** (`Expr`), **helpers** (`Helper`), and the outermost **template** wrapper (`Template`).

```mermaid
classDiagram
    class Node {
        +fields: Tuple
        +attributes: Tuple
        +lineno: int
        +environment: Environment
        +iter_fields()
        +iter_child_nodes()
        +find(node_type)
        +find_all(node_type)
        +set_ctx(ctx)
        +set_lineno(lineno)
        +set_environment(env)
        +dump()
    }

    class Stmt
    class Expr {
        +as_const(eval_ctx)
        +can_assign()
    }
    class Helper
    class Template

    Node <|-- Stmt
    Node <|-- Expr
    Node <|-- Helper
    Node <|-- Template

    Stmt <|-- Output
    Stmt <|-- Extends
    Stmt <|-- For
    Stmt <|-- If
    Stmt <|-- Macro
    Stmt <|-- CallBlock
    Stmt <|-- FilterBlock
    Stmt <|-- With
    Stmt <|-- Block
    Stmt <|-- Include
    Stmt <|-- Import
    Stmt <|-- FromImport
    Stmt <|-- ExprStmt
    Stmt <|-- Assign
    Stmt <|-- AssignBlock
    Stmt <|-- Continue
    Stmt <|-- Break
    Stmt <|-- Scope
    Stmt <|-- OverlayScope
    Stmt <|-- EvalContextModifier

    Expr <|-- BinExpr
    Expr <|-- UnaryExpr
    Expr <|-- Name
    Expr <|-- NSRef
    Expr <|-- Literal
    Expr <|-- CondExpr
    Expr <|-- _FilterTestCommon
    Expr <|-- Call
    Expr <|-- Getitem
    Expr <|-- Getattr
    Expr <|-- Slice
    Expr <|-- Concat
    Expr <|-- Compare
    Expr <|-- EnvironmentAttribute
    Expr <|-- ExtensionAttribute
    Expr <|-- ImportedName
    Expr <|-- InternalName
    Expr <|-- MarkSafe
    Expr <|-- MarkSafeIfAutoescape
    Expr <|-- ContextReference
    Expr <|-- DerivedContextReference

    Literal <|-- Const
    Literal <|-- TemplateData
    Literal <|-- Tuple
    Literal <|-- List
    Literal <|-- Dict

    BinExpr <|-- Mul
    BinExpr <|-- Div
    BinExpr <|-- FloorDiv
    BinExpr <|-- Add
    BinExpr <|-- Sub
    BinExpr <|-- Mod
    BinExpr <|-- Pow
    BinExpr <|-- And
    BinExpr <|-- Or

    UnaryExpr <|-- Not
    UnaryExpr <|-- Neg
    UnaryExpr <|-- Pos

    _FilterTestCommon <|-- Filter
    _FilterTestCommon <|-- Test

    Helper <|-- Pair
    Helper <|-- Keyword
    Helper <|-- Operand

    EvalContextModifier <|-- ScopedEvalContextModifier
```

---

## The `NodeType` Metaclass

`NodeType` is the metaclass for all nodes. It implements **field and attribute inheritance**: when a subclass is created, the `fields` and `attributes` tuples from the parent class are automatically merged with those declared on the child.

```mermaid
flowchart TD
    A[New Node subclass defined] --> B[NodeType.__new__ invoked]
    B --> C[Collect 'fields' from base + child]
    B --> D[Collect 'attributes' from base + child]
    C --> E{Layout conflict?}
    D --> E
    E -->|duplicate entries| F[AssertionError: layout conflict]
    E -->|multiple bases| G[AssertionError: multiple inheritance not allowed]
    E -->|OK| H[Set merged tuples on class]
    H --> I[Set abstract=False by default]
    I --> J[Create class via type.__new__]
```

Key behaviors:

- **Single inheritance only** — multiple inheritance raises an assertion error.
- **No duplicate fields/attributes** — a "layout conflict" assertion guards against accidental shadowing.
- **`abstract` defaults to `False`** — subclasses are concrete unless explicitly marked abstract.
- **Custom nodes are forbidden** — at the end of the module, `NodeType.__new__` is replaced with `_failing_new`, which raises `TypeError("can't create custom node types")`. This prevents extensions from defining new node types after import.

---

## Core Concepts

### Fields vs. Attributes

Every node distinguishes between two kinds of data:

| Concept | Description | Constructor |
| --- | --- | --- |
| **Fields** | Structural children (other nodes, lists, or values). | Passed as positional arguments. |
| **Attributes** | Metadata: `lineno` and `environment`. | Passed as keyword arguments. |

The base `Node` declares `attributes = ("lineno", "environment")`. The constructor validates that the number of positional arguments matches `len(self.fields)` and that no unknown keyword attributes are supplied.

### `EvalContext`

`EvalContext` holds evaluation-time information used during constant folding and code generation:

- `environment` — the active `Environment`.
- `autoescape` — resolved from the environment (supports callables).
- `volatile` — set to `True` when a value cannot be determined at compile time (e.g., inside an `EvalContextModifier` with a dynamic value).

It supports `save()` / `revert()` for scoped modifications, used by `ScopedEvalContextModifier`.

### Constant Folding with `as_const()`

Expression nodes implement `as_const(eval_ctx)`, which returns the compile-time value of the expression or raises `Impossible`. This is the mechanism the [optimizer](optimizer.md) uses to fold constants.

```mermaid
flowchart TD
    A[Optimizer.generic_visit] --> B{node is Expr?}
    B -->|No| Z[Return node unchanged]
    B -->|Yes| C[Call node.as_const]
    C --> D{Impossible raised?}
    D -->|Yes| Z
    D -->|No| E[Const.from_untrusted value]
    E --> F{has_safe_repr?}
    F -->|No| G[Impossible]
    F -->|Yes| H[Return Const node]
```

Notable `as_const` behaviors:

- **`BinExpr` / `UnaryExpr`** — refuse to fold when the environment is sandboxed and the operator is intercepted.
- **`TemplateData`** — returns `Markup` when autoescape is active; raises `Impossible` when volatile.
- **`_FilterTestCommon`** — refuses to fold filters/tests that require context, are async, or are volatile.
- **`CondExpr`** — folds only when the test is constant; raises `Impossible` if the false branch is undefined.

### Assignment Context (`ctx`)

Nodes that can appear on the left-hand side of an assignment carry a `ctx` field with one of three values:

- `load` — read the value (default produced by the parser).
- `store` — write the value.
- `param` — like `store`, but for function parameters.

`Node.set_ctx()` recursively resets the context of a subtree, and `Expr.can_assign()` validates whether a node is a legal assignment target.

---

## Node Categories

### Statements (`Stmt`)

Statements represent template control flow and output. They are compiled by the `CodeGenerator`'s `visit_*` methods.

| Node | Purpose |
| --- | --- |
| `Template` | Outermost wrapper node passed to the compiler. |
| `Output` | Holds multiple expressions to be printed (template data + `{{ }}`). |
| `Extends` | Template inheritance (`{% extends %}`). |
| `For` | For loop with optional `else_`, `test` (filtered), and `recursive`. |
| `If` | Conditional with `elif_` chain and `else_`. |
| `Macro` | Macro definition. |
| `CallBlock` | `{% call %}` block (unnamed macro passed as `caller`). |
| `FilterBlock` | `{% filter %}` section. |
| `With` | `{% with %}` statement. |
| `Block` | Named block with `scoped` and `required` flags. |
| `Include` | `{% include %}` with `with_context` / `ignore_missing`. |
| `Import` / `FromImport` | `{% import %}` / `{% from %}`. |
| `ExprStmt` | Evaluate an expression and discard the result. |
| `Assign` / `AssignBlock` | `{% set %}` (simple and block form). |
| `Continue` / `Break` | Loop control. |
| `Scope` | Artificial scope. |
| `OverlayScope` | Extension scope introducing arbitrary variables. |
| `EvalContextModifier` | Modify the eval context (e.g., `autoescape`). |
| `ScopedEvalContextModifier` | Modify and revert the eval context for a body. |

### Expressions (`Expr`)

Expressions produce values. They implement `as_const()` for constant folding.

| Node | Purpose |
| --- | --- |
| `Name` | Variable lookup/store with `ctx`. |
| `NSRef` | Namespace attribute assignment target. |
| `Const` | Constant value with safe `repr`. |
| `TemplateData` | Constant template string. |
| `Tuple` / `List` / `Dict` | Collection literals. |
| `CondExpr` | Inline conditional (`a if b else c`). |
| `Filter` / `Test` | Apply a filter or test. |
| `Call` | Function call with args/kwargs/dyn args. |
| `Getitem` / `Getattr` | Subscript / attribute access. |
| `Slice` | Slice object for subscripts. |
| `Concat` | String concatenation (`~`). |
| `Compare` | Chained comparison with `Operand`s. |
| `BinExpr` subclasses | `Add`, `Sub`, `Mul`, `Div`, `FloorDiv`, `Mod`, `Pow`, `And`, `Or`. |
| `UnaryExpr` subclasses | `Not`, `Neg`, `Pos`. |
| `MarkSafe` / `MarkSafeIfAutoescape` | Wrap as `Markup`. |
| `ContextReference` / `DerivedContextReference` | Access the current context. |

### Helpers (`Helper`)

Helper nodes exist only in specific contexts and are not directly compiled as standalone output:

- `Pair` — key/value pair for dicts.
- `Keyword` — key/value pair for keyword arguments.
- `Operand` — operator + expression for comparisons.

### Extension Helpers

These nodes support the extension system (see [ext](ext.md)):

- `EnvironmentAttribute` — load an attribute from the environment.
- `ExtensionAttribute` — load an attribute from a bound extension.
- `ImportedName` — reference an imported name (optimized by the compiler).
- `InternalName` — compiler-generated identifier (created via `Parser.free_identifier`).

---

## Tree Traversal and Mutation

The `Node` base class provides the traversal primitives that all visitors rely on.

```mermaid
flowchart LR
    subgraph "Traversal"
        IF[iter_fields] --> ICN[iter_child_nodes]
        ICN --> FIND[find]
        ICN --> FINDALL[find_all]
    end
    subgraph "Mutation"
        SC[set_ctx]
        SL[set_lineno]
        SE[set_environment]
    end
    ICN -.->|used by| VIS[NodeVisitor.generic_visit]
    ICN -.->|used by| SC
    ICN -.->|used by| SL
    ICN -.->|used by| SE
```

- **`iter_fields(exclude, only)`** — yields `(name, value)` pairs for the node's fields.
- **`iter_child_nodes(exclude, only)`** — yields direct child `Node` instances (flattening lists).
- **`find(node_type)`** — returns the first matching descendant or `None`.
- **`find_all(node_type)`** — yields all matching descendants (accepts a tuple of types).
- **`set_ctx(ctx)`** — breadth-first reset of the `ctx` field across a subtree.
- **`set_lineno(lineno, override)`** — breadth-first line number assignment.
- **`set_environment(environment)`** — breadth-first environment assignment (called at the end of parsing).
- **`dump()`** — produces a reconstructable Python source representation of the tree.

### Equality and Hashing

`Node.__eq__` compares nodes by type and field values (via `iter_fields`). `__hash__` is set to `object.__hash__`, so nodes remain hashable by identity.

---

## Data Flow: From Source to Compiled Code

The following sequence diagram shows how nodes flow through the pipeline, highlighting the role of `as_const()` and the visitor pattern.

```mermaid
sequenceDiagram
    participant P as Parser
    participant N as nodes.Node
    participant O as Optimizer
    participant S as Symbols (idtracking)
    participant C as CodeGenerator

    P->>N: Construct AST (Template, Stmt, Expr)
    P->>N: set_environment(env)
    P->>N: set_lineno(...)
    O->>N: generic_visit (NodeTransformer)
    O->>N: as_const() for constant folding
    N-->>O: Const or Impossible
    S->>N: analyze_node (RootVisitor)
    N-->>S: loads / stores
    C->>N: visit_* per node type
    C->>N: as_const() for Output optimization
    N-->>C: constant value or Impossible
    C-->>C: emit Python source
```

---

## Integration with the Visitor Pattern

The [visitor](visitor.md) module provides `NodeVisitor` and `NodeTransformer`, which dispatch to `visit_<ClassName>` methods based on the node's type name. The nodes module is designed to work seamlessly with this pattern:

- `NodeVisitor.generic_visit` uses `node.iter_child_nodes()` to recurse.
- `NodeTransformer.generic_visit` uses `node.iter_fields()` to replace or remove nodes.
- The [compiler](compiler.md)'s `CodeGenerator` is a `NodeVisitor` with a `visit_*` method for every node type.
- The [optimizer](optimizer.md)'s `Optimizer` is a `NodeTransformer` that folds constants.

```mermaid
graph TD
    NV[NodeVisitor] -->|dispatch visit_ClassName| CG[CodeGenerator]
    NV -->|dispatch visit_ClassName| TCG[TrackingCodeGenerator]
    NT[NodeTransformer] -->|dispatch visit_ClassName| OPT[Optimizer]
    CG -.->|subclass| NV
    TCG -.->|subclass| CG
    OPT -.->|subclass| NT
```

---

## Extension Points

The nodes module exposes several mechanisms for extensions (see [ext](ext.md)):

1. **`EnvironmentAttribute`** — read a callback stored on the environment.
2. **`ExtensionAttribute`** — read an attribute from a bound extension (constructed via `Extension.attr()`).
3. **`ImportedName`** — reference an imported name; the compiler optimizes these into module-level imports.
4. **`InternalName`** — compiler-generated identifiers created via `Parser.free_identifier()`.
5. **`OverlayScope`** — introduce arbitrary variables into a sub-scope.
6. **`EvalContextModifier` / `ScopedEvalContextModifier`** — modify the eval context.

> **Note:** Extensions cannot define new node types. The `NodeType` metaclass is locked down at import time via `_failing_new`, ensuring the AST vocabulary remains fixed.

---

## Summary

The `nodes` module is the **shared AST contract** of Jinja's compilation pipeline. It:

- Defines the complete vocabulary of template constructs as a typed class hierarchy.
- Provides traversal, mutation, and constant-folding primitives.
- Bridges the [parser](parser.md), [optimizer](optimizer.md), [compiler](compiler.md), [idtracking](idtracking.md), and [meta](meta.md) modules through a common data model.
- Enforces structural invariants via the `NodeType` metaclass and the `Impossible` exception.

For details on how nodes are produced, see the [parser](parser.md) documentation. For how they are consumed, see the [compiler](compiler.md), [optimizer](optimizer.md), and [visitor](visitor.md) documentation.
