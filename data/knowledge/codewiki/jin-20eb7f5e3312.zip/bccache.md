# Bytecode Cache (`bccache`)

## Introduction

The `bccache` module implements Jinja's **optional bytecode cache system**. Its purpose is to avoid re-parsing and re-compiling templates on every application start or request. When a template is compiled, Jinja produces a Python code object (bytecode). The bytecode cache persists that code object so that subsequent loads can skip the expensive lexing, parsing, and compilation pipeline entirely.

This is especially valuable for:

- **Forking web applications** that are initialized on the first request.
- Applications with **many complex templates** where compilation time dominates startup latency.
- Deployments where templates rarely change but are loaded frequently.

The module provides a small, well-defined abstraction (`BytecodeCache` + `Bucket`) and two concrete implementations: a filesystem-backed cache and a memcached-backed cache.

> **Related documentation:** For how the cache is wired into template loading, see [loaders.md](loaders.md) and [environment.md](environment.md). For the compilation pipeline that produces the bytecode being cached, see [compiler.md](compiler.md).

---

## Architecture Overview

The bytecode cache sits between the template loader and the compilation pipeline. When a loader needs a template, it first asks the cache for a `Bucket`; if the bucket contains valid bytecode, compilation is skipped.

```mermaid
graph TD
    Env["Environment<br/>(bytecode_cache attr)"]
    Loader["BaseLoader.load()"]
    BCC["BytecodeCache"]
    Bucket["Bucket"]
    FS["FileSystemBytecodeCache"]
    MC["MemcachedBytecodeCache"]
    Compiler["Environment.compile()<br/>(compiler.md)"]
    Template["Template.from_code()"]

    Env -->|holds| BCC
    Loader -->|get_bucket / set_bucket| BCC
    BCC -->|creates| Bucket
    BCC -.subclass.-> FS
    BCC -.subclass.-> MC
    Loader -->|cache miss| Compiler
    Compiler -->|code object| Bucket
    Loader -->|code object| Template
```

### Component Responsibilities

| Component | Responsibility |
|-----------|----------------|
| `Bucket` | Holds the bytecode for **one** template. Manages serialization, magic-header validation, and checksum-based invalidation. |
| `BytecodeCache` | Abstract base class. Defines the cache contract (`load_bytecode`, `dump_bytecode`) and provides key/checksum generation plus the `get_bucket`/`set_bucket` orchestration. |
| `FileSystemBytecodeCache` | Concrete cache storing bytecode files on disk, with a configurable directory and filename pattern. |
| `MemcachedBytecodeCache` | Concrete cache storing bytecode in a memcached-compatible client. |
| `_MemcachedClient` | A `typing.Protocol` describing the minimal client interface required by `MemcachedBytecodeCache`. |

---

## Class Hierarchy

```mermaid
classDiagram
    class BytecodeCache {
        +load_bytecode(bucket)
        +dump_bytecode(bucket)
        +clear()
        +get_cache_key(name, filename)
        +get_source_checksum(source)
        +get_bucket(environment, name, filename, source)
        +set_bucket(bucket)
    }
    class FileSystemBytecodeCache {
        +directory
        +pattern
        +_get_default_cache_dir()
        +_get_cache_filename(bucket)
        +load_bytecode(bucket)
        +dump_bytecode(bucket)
        +clear()
    }
    class MemcachedBytecodeCache {
        +client
        +prefix
        +timeout
        +ignore_memcache_errors
        +load_bytecode(bucket)
        +dump_bytecode(bucket)
    }
    class Bucket {
        +environment
        +key
        +checksum
        +code
        +reset()
        +load_bytecode(f)
        +write_bytecode(f)
        +bytecode_from_string(string)
        +bytecode_to_string()
    }
    class _MemcachedClient {
        <<Protocol>>
        +get(key)
        +set(key, value, timeout)
    }

    BytecodeCache <|-- FileSystemBytecodeCache
    BytecodeCache <|-- MemcachedBytecodeCache
    BytecodeCache ..> Bucket : creates
    MemcachedBytecodeCache ..> _MemcachedClient : uses
```

---

## The `Bucket` Class

A `Bucket` is the unit of transfer between the cache and the loader. It is created and initialized by the cache (via `BytecodeCache.get_bucket`) and passed to the loading functions. Each bucket carries:

- `environment` — the owning `Environment`.
- `key` — a unique hash identifying the template (name + optional filename).
- `checksum` — a hash of the template source, used to detect changes.
- `code` — the compiled `CodeType` object, or `None` if not yet loaded.

### Cache Invalidation

Buckets handle invalidation automatically, so individual cache subclasses do not need to care about it. Two mechanisms protect against stale bytecode:

1. **Magic header (`bc_magic`)** — Every serialized bucket begins with a magic byte string that encodes the cache format version (`bc_version = 5`) and the Python major/minor version. This prevents loading bytecode produced by an incompatible Python interpreter or an older Jinja cache format.
2. **Source checksum** — The bucket stores the source checksum. If the template source changed, the checksum mismatch triggers a `reset()`.

### Serialization Format

`write_bytecode` produces a binary stream with the following layout:

```
+----------------+------------------+------------------+
| bc_magic       | pickled checksum | marshalled code  |
| (bytes)        | (pickle proto 2) | (marshal)        |
+----------------+------------------+------------------+
```

`load_bytecode` reverses this process and calls `reset()` on any failure (bad magic, checksum mismatch, or a `marshal` error such as `EOFError`, `ValueError`, or `TypeError`).

### Bucket Lifecycle

```mermaid
sequenceDiagram
    participant Loader
    participant Cache as BytecodeCache
    participant Bucket
    participant Storage as Storage (disk/memcached)

    Loader->>Cache: get_bucket(env, name, filename, source)
    Cache->>Cache: get_cache_key(name, filename)
    Cache->>Cache: get_source_checksum(source)
    Cache->>Bucket: new Bucket(env, key, checksum)
    Cache->>Cache: load_bytecode(bucket)
    Cache->>Storage: read raw bytes
    Storage-->>Cache: bytes
    Cache->>Bucket: load_bytecode(f)
    alt magic + checksum valid
        Bucket->>Bucket: code = marshal.load(f)
    else invalid
        Bucket->>Bucket: reset() (code = None)
    end
    Cache-->>Loader: bucket

    alt bucket.code is None (cache miss)
        Loader->>Loader: environment.compile(...)
        Loader->>Bucket: bucket.code = code
        Loader->>Cache: set_bucket(bucket)
        Cache->>Cache: dump_bytecode(bucket)
        Cache->>Storage: write raw bytes
    end
```

---

## The `BytecodeCache` Base Class

`BytecodeCache` defines the contract that all caches must fulfill. To implement a custom cache, subclass it and override `load_bytecode` and `dump_bytecode`.

### Key Methods

| Method | Description |
|--------|-------------|
| `load_bytecode(bucket)` | **Abstract.** Load bytecode into the bucket. Must do nothing if no cached code is found. |
| `dump_bytecode(bucket)` | **Abstract.** Persist the bucket's bytecode. Must raise on failure (never fail silently). |
| `clear()` | Optional. Clear the cache. Not used by Jinja internally but provided for applications. |
| `get_cache_key(name, filename)` | Returns a SHA-1 hex digest of the template name (and filename if provided). |
| `get_source_checksum(source)` | Returns a SHA-1 hex digest of the template source. |
| `get_bucket(environment, name, filename, source)` | Orchestrates key/checksum generation, bucket creation, and loading. |
| `set_bucket(bucket)` | Delegates to `dump_bytecode`. |

### Minimal Custom Cache Example

```python
from os import path

class MyCache(BytecodeCache):
    def __init__(self, directory):
        self.directory = directory

    def load_bytecode(self, bucket):
        filename = path.join(self.directory, bucket.key)
        if path.exists(filename):
            with open(filename, "rb") as f:
                bucket.load_bytecode(f)

    def dump_bytecode(self, bucket):
        filename = path.join(self.directory, bucket.key)
        with open(filename, "wb") as f:
            bucket.write_bytecode(f)
```

---

## `FileSystemBytecodeCache`

Stores bytecode as files on the local filesystem.

### Configuration

- **`directory`** — Where cache files are stored. If `None`, a default directory is chosen:
  - On Windows: the system temp directory.
  - On UNIX: a per-user directory `_jinja2-cache-{uid}` inside the system temp directory, created with `S_IRWXU` (owner-only) permissions.
- **`pattern`** — Filename template, default `"__jinja2_%s.cache"`. The `%s` is replaced with the bucket key. Multiple independent caches can share a directory by using different patterns.

```python
bcc = FileSystemBytecodeCache("/tmp/jinja_cache", "%s.cache")
```

### Security Considerations

`_get_default_cache_dir` performs careful validation on UNIX systems to avoid using an unsafe temp directory:

- It verifies the directory is owned by the current user (`st_uid == os.getuid()`).
- It verifies the path is actually a directory (`S_ISDIR`).
- It verifies the permissions are exactly `S_IRWXU` (owner read/write/execute only).
- If any check fails, it raises a `RuntimeError` instructing the user to provide an explicit directory.

This prevents symlink attacks and world-readable cache directories in shared temp locations.

### Clearing

`clear()` uses `fnmatch.filter` to find files matching the pattern and removes them, ignoring `OSError`. The `os.remove` import is deferred to the method body because Google App Engine does not support filesystem write access.

---

## `MemcachedBytecodeCache`

Stores bytecode in a memcached-compatible cache. It does **not** enforce a specific memcached library; instead it accepts any client implementing the minimal interface described by `_MemcachedClient`.

### Compatible Libraries

- [cachelib](https://github.com/pallets/cachelib)
- [python-memcached](https://pypi.org/project/python-memcached/)

> The Django cache interface is **not** directly compatible because it stores only text, not binary data. However, the underlying client (`django.core.cache.cache._client`) can be passed directly.

### Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `client` | — | A memcached-compatible client. |
| `prefix` | `"jinja2/bytecode/"` | Prefix prepended to every cache key. |
| `timeout` | `None` | Key expiry in seconds. A high or no timeout is recommended. |
| `ignore_memcache_errors` | `True` | If `True`, memcache errors are swallowed; if `False`, they propagate. |

### Error Handling

Both `load_bytecode` and `dump_bytecode` wrap client calls in `try/except`. When `ignore_memcache_errors` is `True` (the default), transient memcache failures are silently ignored so that a cache outage does not break template rendering. When `False`, exceptions propagate to the caller.

### Clearing

`MemcachedBytecodeCache` does **not** support clearing; `clear()` is a no-op (inherited from the base class).

---

## Integration with the Loading Pipeline

The bytecode cache is consumed by `BaseLoader.load` in [loaders.md](loaders.md). The relevant flow is:

```mermaid
flowchart TD
    A["BaseLoader.load(env, name, globals)"] --> B["get_source(env, name)"]
    B --> C{"env.bytecode_cache set?"}
    C -->|No| F["env.compile(source, name, filename)"]
    C -->|Yes| D["bcc.get_bucket(env, name, filename, source)"]
    D --> E{"bucket.code available?"}
    E -->|Yes| G["Use cached code"]
    E -->|No| F
    F --> H["bucket.code = code"]
    H --> I["bcc.set_bucket(bucket)"]
    G --> J["template_class.from_code(...)"]
    I --> J
```

Key points:

1. The loader always calls `get_source` first, because the source is needed to compute the checksum for cache validation.
2. If a `bytecode_cache` is configured on the `Environment` (see [environment.md](environment.md)), the loader obtains a bucket and checks for cached code.
3. On a cache miss, the template is compiled via `Environment.compile` (see [compiler.md](compiler.md)) and the resulting code is stored back into the cache.
4. The final `Template` object is always constructed via `template_class.from_code`, regardless of whether the code came from the cache or fresh compilation.

---

## Data Flow Summary

```mermaid
graph LR
    Source["Template Source"]
    Key["Cache Key<br/>(sha1 of name+filename)"]
    Checksum["Source Checksum<br/>(sha1 of source)"]
    Bucket["Bucket"]
    Storage["Storage<br/>(disk / memcached)"]
    Code["CodeType<br/>(bytecode)"]

    Source --> Checksum
    Source --> Key
    Key --> Bucket
    Checksum --> Bucket
    Bucket <--> Storage
    Bucket --> Code
```

---

## Versioning and Compatibility

- **`bc_version = 5`** — The internal cache format version. Bump this when the serialization format changes.
- **`bc_magic`** — Combines `bc_version` with the Python major/minor version (`(major << 24) | minor`). This ensures that bytecode compiled by one Python version is never loaded by another, avoiding subtle incompatibilities.

Both values are embedded in every serialized bucket, so cache files are self-describing and safely invalidated across upgrades.

---

## Summary

The `bccache` module provides a clean, extensible bytecode caching layer for Jinja:

- **`Bucket`** encapsulates per-template bytecode with automatic invalidation via magic headers and source checksums.
- **`BytecodeCache`** defines a minimal two-method contract (`load_bytecode` / `dump_bytecode`) for custom implementations.
- **`FileSystemBytecodeCache`** offers a secure, pattern-based on-disk cache.
- **`MemcachedBytecodeCache`** offers a distributed cache with configurable error tolerance.

By integrating with `BaseLoader.load` and `Environment.compile`, the cache transparently accelerates template loading without changing application code — simply pass a cache instance to the `Environment`'s `bytecode_cache` parameter.
