# Shell Completion Module

## Introduction

The `shell_completion` module provides the infrastructure for **tab completion** support in Click-based command line applications. It enables users to press `<TAB>` in their shell (Bash, Zsh, or Fish) and receive context-aware suggestions for commands, options, and parameter values.

The module works by generating a small shell script (the *source*) that the user installs into their shell configuration. When the user presses `<TAB>`, the shell script invokes the CLI program with a special environment variable set. The program detects this, computes the appropriate completions, and returns them in a format the shell understands.

This module is tightly integrated with the core command system. The actual completion logic for individual commands and parameters lives in [`core`](core.md) (`Command.shell_complete`, `Group.shell_complete`, `Parameter.shell_complete`) and [`types`](types.md) (`ParamType.shell_complete`). This module is responsible for the shell-specific plumbing: parsing the shell's environment variables, resolving the invocation context, and formatting the output.

---

## Architecture Overview

The module is organized around a base class (`ShellComplete`) and three concrete shell implementations. A registry maps shell names to their implementations, and a top-level entry point (`shell_complete`) dispatches based on the instruction received from the shell.

```mermaid
graph TD
    subgraph "Entry Point"
        SC["shell_complete()"]
    end

    subgraph "Registry"
        REG["_available_shells"]
        ADD["add_completion_class()"]
        GET["get_completion_class()"]
    end

    subgraph "Base"
        BASE["ShellComplete"]
    end

    subgraph "Shell Implementations"
        BASH["BashComplete"]
        ZSH["ZshComplete"]
        FISH["FishComplete"]
    end

    subgraph "Data"
        ITEM["CompletionItem"]
    end

    SC --> GET
    GET --> REG
    ADD --> REG
    REG --> BASH
    REG --> ZSH
    REG --> FISH
    BASH --> BASE
    ZSH --> BASE
    FISH --> BASE
    BASE --> ITEM
```

### Component Responsibilities

| Component | Responsibility |
|-----------|----------------|
| `shell_complete` | Top-level entry point. Parses the instruction, selects the shell class, and dispatches to `source()` or `complete()`. |
| `ShellComplete` | Base class defining the completion protocol: `source()`, `complete()`, `get_completion_args()`, `format_completion()`. |
| `BashComplete` | Bash-specific implementation, including version checking (requires Bash ≥ 4.4). |
| `ZshComplete` | Zsh-specific implementation with description support. |
| `FishComplete` | Fish-specific implementation with tab-separated help text. |
| `CompletionItem` | Value object representing a single completion suggestion plus metadata (`type`, `help`, arbitrary attributes). |
| `add_completion_class` / `get_completion_class` | Registry functions for registering and looking up shell implementations. |
| `split_arg_string` | Utility to split an argument string like `shlex.split` but tolerant of incomplete input. |

---

## Completion Flow

The completion process spans two phases: **installation** (generating the shell script) and **runtime** (computing completions when `<TAB>` is pressed).

### Phase 1: Source Generation

When the user runs the program with the completion instruction set to `source`, the module emits a shell script that defines the completion function.

```mermaid
sequenceDiagram
    participant User
    participant Shell
    participant CLI as CLI Program
    participant SC as shell_complete()
    participant Comp as ShellComplete subclass

    User->>Shell: eval "$(prog _PROG_COMPLETE=bash_source)"
    Shell->>CLI: run with _PROG_COMPLETE=bash_source
    CLI->>SC: shell_complete(cli, ..., "bash_source")
    SC->>SC: partition instruction -> ("bash", "source")
    SC->>Comp: get_completion_class("bash")
    SC->>Comp: comp.source()
    Comp->>Comp: source_template % source_vars()
    Comp-->>SC: shell script text
    SC-->>CLI: echo(script)
    CLI-->>Shell: script installed
```

### Phase 2: Runtime Completion

When the user presses `<TAB>`, the installed shell function invokes the program with the completion instruction set to `complete`.

```mermaid
sequenceDiagram
    participant User
    participant ShellFn as Shell Function
    participant CLI as CLI Program
    participant SC as shell_complete()
    participant Comp as ShellComplete subclass
    participant Core as Command/Parameter

    User->>ShellFn: press <TAB>
    ShellFn->>CLI: run with COMP_WORDS, COMP_CWORD, _PROG_COMPLETE=bash_complete
    CLI->>SC: shell_complete(cli, ..., "bash_complete")
    SC->>Comp: comp.complete()
    Comp->>Comp: get_completion_args()
    Note over Comp: reads COMP_WORDS / COMP_CWORD
    Comp->>Comp: get_completions(args, incomplete)
    Comp->>Core: _resolve_context() -> Context
    Comp->>Core: _resolve_incomplete() -> obj
    Core->>Core: obj.shell_complete(ctx, incomplete)
    Core-->>Comp: list[CompletionItem]
    Comp->>Comp: format_completion(item) for each
    Comp-->>SC: formatted string
    SC-->>CLI: echo(formatted)
    CLI-->>ShellFn: completion data
    ShellFn-->>User: suggestions displayed
```

---

## Core Components

### `shell_complete` (entry point)

The top-level function invoked by [`Command._main_shell_completion`](core.md) when the completion environment variable is present.

```python
def shell_complete(cli, ctx_args, prog_name, complete_var, instruction) -> int:
    shell, _, instruction = instruction.partition("_")
    comp_cls = get_completion_class(shell)
    if comp_cls is None:
        return 1
    comp = comp_cls(cli, ctx_args, prog_name, complete_var)
    if instruction == "source":
        echo(comp.source())
        return 0
    if instruction == "complete":
        echo(comp.complete())
        return 0
    return 1
```

The `instruction` string has the form `{shell}_{action}`, e.g. `bash_source` or `zsh_complete`. The function splits on the first underscore to determine the shell and the action.

### `CompletionItem`

A lightweight value object (`__slots__`-based) representing a single completion suggestion.

| Attribute | Type | Description |
|-----------|------|-------------|
| `value` | `Any` | The completion suggestion itself. |
| `type` | `str` | Special handling hint. Click uses `"plain"`, `"dir"`, and `"file"`. |
| `help` | `str \| None` | Help string shown next to the value (if the shell supports it). |
| `_info` | `dict` | Arbitrary metadata passed via `**kwargs`. |

Accessing an attribute that was not passed returns `None` via `__getattr__`. This allows custom type completions paired with custom shell support to attach extra metadata.

### `ShellComplete` (base class)

Defines the completion protocol. Subclasses must provide:

- `name` (class var) — the shell name used in instructions.
- `source_template` (class var) — the `%`-style template for the shell script.
- `get_completion_args()` — parse shell env vars into `(args, incomplete)`.
- `format_completion(item)` — format a `CompletionItem` for the shell.

The base class provides:

- `func_name` (property) — a sanitized shell function name derived from `prog_name`.
- `source_vars()` — dict of variables for the template (`complete_func`, `complete_var`, `prog_name`).
- `source()` — formats `source_template` with `source_vars()`.
- `get_completions(args, incomplete)` — resolves the context and delegates to the target object's `shell_complete`.
- `complete()` — orchestrates `get_completion_args` → `get_completions` → `format_completion`.

### Shell Implementations

| Class | `name` | Notes |
|-------|--------|-------|
| `BashComplete` | `"bash"` | Overrides `source()` to check the Bash version (requires ≥ 4.4 for `nosort`). Formats as `type,value`. |
| `ZshComplete` | `"zsh"` | Formats as `type\nvalue\nhelp` (help defaults to `_`). Supports descriptions via `_describe`. |
| `FishComplete` | `"fish"` | Removes the partial word from complete args (Fish stores it in both `COMP_WORDS` and `COMP_CWORD`). Formats as `type,value` or `type,value\thelp`. |

### Registry Functions

- `add_completion_class(cls, name=None)` — registers a `ShellComplete` subclass under a name (defaults to `cls.name`). Returns the class, so it can be used as a decorator.
- `get_completion_class(shell)` — looks up a registered class by name, returning `None` if not found.

---

## Context Resolution

The heart of runtime completion is resolving *which* object (command or parameter) should provide completions for the incomplete value. This is handled by three private helpers.

```mermaid
flowchart TD
    A["get_completions(args, incomplete)"] --> B["_resolve_context(cli, ctx_args, prog_name, args)"]
    B --> C["_resolve_incomplete(ctx, args, incomplete)"]
    C --> D{"incomplete looks like an option?"}
    D -->|yes, no '--' seen| E["return ctx.command"]
    D -->|no| F{"last arg is an option needing a value?"}
    F -->|yes| G["return that Option"]
    F -->|no| H{"an argument can still accept values?"}
    H -->|yes| I["return that Argument"]
    H -->|no| J["return ctx.command (group subcommands)"]
    E --> K["obj.shell_complete(ctx, incomplete)"]
    G --> K
    I --> K
    J --> K
```

### `_resolve_context`

Builds the context hierarchy by traversing the complete arguments. It sets `resilient_parsing=True` so that parsing never triggers prompts, callbacks, or errors. For `Group` commands it follows subcommands (including chained groups) to reach the deepest context.

### `_resolve_incomplete`

Determines the target object for completion:

1. **Normalize `=`** — shells treat `--opt=value` inconsistently, so the `=` is split and discarded.
2. **Option name completion** — if the incomplete value starts with an option prefix and `--` hasn't been seen, the command provides option-name completions.
3. **Option value completion** — if the last complete arg is an option name awaiting a value (`_is_incomplete_option`), that option provides value completions.
4. **Argument value completion** — the first argument that can still accept values (`_is_incomplete_argument`) provides value completions.
5. **Fallback** — the command itself (e.g. a group offering subcommand names).

### Helper Predicates

- `_is_incomplete_argument(ctx, param)` — true if `param` is an `Argument` that can still accept values (handles `nargs=-1`, multi-value `nargs`, and unparsed arguments).
- `_is_incomplete_option(ctx, args, param)` — true if `param` is an `Option` (not a flag/count) whose name appears as the last option in `args` and still needs a value.
- `_start_of_option(ctx, value)` — true if `value` begins with one of the context's option prefixes.

---

## Data Flow and Formatting

Each shell expects completion data in a different format. The `format_completion` method of each subclass handles this translation.

```mermaid
graph LR
    subgraph "CompletionItem"
        V["value"]
        T["type"]
        H["help"]
    end

    V --> BASH["Bash: type,value"]
    T --> BASH
    V --> ZSH["Zsh: type\\nvalue\\nhelp"]
    T --> ZSH
    H --> ZSH
    V --> FISH["Fish: type,value\\thelp"]
    T --> FISH
    H --> FISH
```

The shell scripts (defined as `_SOURCE_BASH`, `_SOURCE_ZSH`, `_SOURCE_FISH`) parse this output and translate the `type` field into shell-native behavior:

- `plain` → add the value to the completion list.
- `dir` → trigger directory completion (`compopt -o dirnames`, `_path_files -/`, `__fish_complete_directories`).
- `file` → trigger file completion (`compopt -o default`, `_path_files -f`, `__fish_complete_path`).

---

## Integration with the Core Module

The shell completion system is invoked automatically by [`Command.main`](core.md) via `_main_shell_completion`. When the completion environment variable (default `_{PROG_NAME}_COMPLETE`) is set, the program exits early with the completion result instead of running the command.

```mermaid
graph TD
    MAIN["Command.main()"] --> MSC["_main_shell_completion()"]
    MSC -->|"env var set"| SC["shell_complete()"]
    MSC -->|"env var not set"| NORMAL["normal invocation"]
    SC --> COMP["ShellComplete.complete()"]
    COMP --> RESOLVE["_resolve_context / _resolve_incomplete"]
    RESOLVE --> CORE["Command.shell_complete / Parameter.shell_complete"]
    CORE --> TYPE["ParamType.shell_complete"]
```

The actual completion candidates are produced by:

- [`Command.shell_complete`](core.md) — option names and chained subcommand names.
- [`Group.shell_complete`](core.md) — subcommand names plus the above.
- [`Parameter.shell_complete`](core.md) — delegates to a custom `shell_complete` callback or the parameter's type.
- [`ParamType.shell_complete`](types.md) — type-specific completions (e.g. `Choice` suggests its choices, `Path`/`File` suggest filesystem paths).

---

## Extending with Custom Shells

To add support for a new shell:

1. Subclass `ShellComplete`.
2. Set the `name` and `source_template` class attributes.
3. Implement `get_completion_args()` and `format_completion()`.
4. Register the class with `add_completion_class` (optionally as a decorator).

```python
from click.shell_completion import ShellComplete, add_completion_class

@add_completion_class
class MyShellComplete(ShellComplete):
    name = "myshell"
    source_template = _SOURCE_MY_SHELL

    def get_completion_args(self):
        ...

    def format_completion(self, item):
        ...
```

Once registered, the shell can be selected by setting the completion instruction to `myshell_source` or `myshell_complete`.

---

## Related Modules

- [core.md](core.md) — `Command`, `Group`, `Parameter`, `Context`, and `ParameterSource`; provides the `shell_complete` methods that produce completion candidates and the `_main_shell_completion` entry point.
- [types.md](types.md) — `ParamType` and its subclasses; provide type-specific value completions.
- [utils.md](utils.md) — `echo`, used to output the generated script and completion data.
- [parser.md](parser.md) — argument parsing utilities; `split_arg_string` was historically located here before moving to `shell_completion`.
