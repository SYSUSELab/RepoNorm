# Exceptions Module

## Introduction

The `exceptions` module (`src/click/exceptions.py`) defines the complete exception hierarchy used throughout Click to signal, format, and display errors to end users. It provides a layered set of exception classes that distinguish between:

- **User-facing errors** that Click catches and renders as formatted messages (e.g., `UsageError`, `BadParameter`, `FileError`).
- **Internal control-flow signals** that are not shown to users but instead drive program flow (e.g., `Abort`, `Exit`).

The module is central to Click's error-handling strategy: it standardizes how errors are formatted, how exit codes are assigned, and how contextual information (such as the offending parameter or command) is attached to an error. This ensures consistent, localized, and color-aware error output across the entire CLI framework.

---

## Architecture Overview

The exception classes form a small but carefully designed hierarchy. The root is Python's built-in `Exception` (for user-facing errors) and `RuntimeError` (for internal signals).

```mermaid
classDiagram
    Exception <|-- ClickException
    ClickException <|-- UsageError
    ClickException <|-- FileError
    UsageError <|-- BadParameter
    UsageError <|-- NoSuchOption
    UsageError <|-- BadOptionUsage
    UsageError <|-- BadArgumentUsage
    UsageError <|-- NoArgsIsHelpError
    BadParameter <|-- MissingParameter
    RuntimeError <|-- Abort
    RuntimeError <|-- Exit

    class ClickException {
        +int exit_code = 1
        +str message
        +format_message() str
        +show(file) None
    }
    class UsageError {
        +int exit_code = 2
        +Context ctx
        +Command cmd
        +show(file) None
    }
    class BadParameter {
        +Parameter param
        +str param_hint
        +format_message() str
    }
    class MissingParameter {
        +str param_type
        +format_message() str
    }
    class NoSuchOption {
        +str option_name
        +Sequence possibilities
        +format_message() str
    }
    class BadOptionUsage {
        +str option_name
    }
    class BadArgumentUsage
    class NoArgsIsHelpError {
        +show(file) None
    }
    class FileError {
        +str ui_filename
        +str filename
        +format_message() str
    }
    class Abort
    class Exit {
        +int exit_code
    }
```

### Two Categories of Exceptions

| Category | Base Class | Purpose | Shown to User? |
|----------|-----------|---------|----------------|
| **User-facing errors** | `ClickException` | Report problems with usage, parameters, or files | Yes, via `show()` |
| **Internal signals** | `RuntimeError` | Control program flow (abort / exit) | No |

---

## Core Components

### `ClickException`

The base class for all exceptions that Click can handle and display to the user.

- **`exit_code = 1`** — the default process exit code for this exception.
- **`message`** — the raw error message.
- **`format_message()`** — returns the message to be displayed; subclasses override this to add context.
- **`show(file=None)`** — writes a formatted `"Error: {message}"` line to the given file (defaults to stderr via `get_text_stderr()`).

This class establishes the contract that every user-facing exception must implement: a way to format itself and a way to display itself.

### `UsageError`

Signals an incorrect usage of the CLI. It carries an optional `Context` and derives the offending `Command` from it.

- **`exit_code = 2`** — usage errors use a distinct exit code from generic errors.
- **`show()`** — overrides the base implementation to prepend the command's usage string and a help hint (e.g., `Try 'cmd --help' for help.`) when a help option is available. It also respects the context's color setting.

This is the parent of all parameter- and option-related errors.

### `BadParameter`

Formats a standardized error message for a bad parameter value. It is typically raised from callbacks or type converters, and Click attaches contextual information automatically.

- **`param`** — the `Parameter` object that caused the error.
- **`param_hint`** — an alternative string (or list of strings) used to name the parameter when no `param` is available.
- **`format_message()`** — produces `"Invalid value for {param_hint}: {message}"`, resolving the hint from `param.get_error_hint(ctx)` when needed.

### `MissingParameter`

A specialization of `BadParameter` raised when a required option or argument is not provided.

- **`param_type`** — one of `'parameter'`, `'option'`, or `'argument'`; defaults to the parameter's own `param_type_name`.
- **`format_message()`** — builds a message such as `"Missing option '--foo'."`, incorporating any extra message from the parameter's type via `type.get_missing_message()`.

### `NoSuchOption`

Raised when an unknown option is encountered.

- **`option_name`** — the unrecognized option.
- **`possibilities`** — an optional sequence of candidate options used to generate a "Did you mean ...?" suggestion via `ngettext` (handling singular/plural forms).

### `BadOptionUsage`

Raised when an option is supplied but used incorrectly (e.g., wrong number of arguments). Stores the offending `option_name`.

### `BadArgumentUsage`

Raised when an argument is supplied but used incorrectly. It adds no extra state beyond `UsageError`.

### `NoArgsIsHelpError`

A specialized `UsageError` raised when a group is invoked with no arguments and should display its help text instead.

- Its message is the command's help text (`ctx.get_help()`).
- **`show()`** — writes the help text directly to stderr (or the given file) with the context's color, bypassing the standard `"Error:"` prefix.

### `FileError`

Raised when a file cannot be opened.

- **`filename`** — the original filename.
- **`ui_filename`** — a display-safe version produced by `format_filename()` (handles invalid bytes / surrogate escapes).
- **`format_message()`** — produces `"Could not open file {filename!r}: {message}"`.

### `Abort`

An internal signalling exception (subclass of `RuntimeError`) that tells Click to abort. It is not displayed to the user. Raised by `Context.abort()`.

### `Exit`

An internal signalling exception (subclass of `RuntimeError`) indicating the application should exit with a given status code.

- **`exit_code`** — the status code (default `0`).
- Uses `__slots__` for a lightweight instance.
- Raised by `Context.exit()`.

---

## Component Interaction

The exceptions module sits at the intersection of several other Click modules. It depends on utilities for output and formatting, and it is raised and consumed by the core and parser modules.

```mermaid
graph TD
    subgraph exceptions["exceptions.py"]
        CE[ClickException]
        UE[UsageError]
        BP[BadParameter]
        MP[MissingParameter]
        NSO[NoSuchOption]
        FE[FileError]
        AB[Abort]
        EX[Exit]
    end

    subgraph utils["utils.py"]
        ECHO[echo]
        FF[format_filename]
    end

    subgraph compat["_compat.py"]
        GTS[get_text_stderr]
    end

    subgraph core["core.py"]
        CTX[Context]
        PARAM[Parameter]
        CMD[Command]
    end

    CE -->|show uses| ECHO
    CE -->|show uses| GTS
    UE -->|show uses| ECHO
    UE -->|reads| CTX
    BP -->|reads| PARAM
    MP -->|reads| PARAM
    FE -->|uses| FF
    CTX -->|raises| UE
    CTX -->|raises| AB
    CTX -->|raises| EX
    PARAM -->|raises| BP
    PARAM -->|raises| MP
```

### Key Dependencies

- **`utils.echo`** — used by `ClickException.show()`, `UsageError.show()`, and `NoArgsIsHelpError.show()` to write color-aware, encoding-safe output. See [utils documentation](utils.md).
- **`utils.format_filename`** — used by `FileError` to produce a display-safe filename. See [utils documentation](utils.md).
- **`_compat.get_text_stderr`** — provides the default stderr stream for error output. See [compat documentation](compat.md).
- **`core.Context`** — supplies usage strings, help text, color settings, and command references used in error formatting. See [core documentation](core.md).
- **`core.Parameter`** — supplies error hints and missing-value messages via `get_error_hint()` and `type.get_missing_message()`. See [core documentation](core.md).

---

## Error Handling Flow

The following diagram illustrates how an error travels from being raised (often deep in parsing or parameter processing) to being displayed to the user.

```mermaid
sequenceDiagram
    participant User
    participant Parser as parser.py
    participant Param as Parameter
    participant Ctx as Context
    participant Exc as Exception
    participant CLI as CLI Entrypoint

    User->>Parser: invoke CLI with args
    Parser->>Param: process_value(ctx, value)
    Param->>Param: type_cast_value / validate
    alt value invalid
        Param->>Exc: raise BadParameter(ctx, param)
    else required value missing
        Param->>Exc: raise MissingParameter(ctx, param)
    end
    Exc-->>CLI: propagate up
    CLI->>Exc: show(file=stderr)
    Exc->>Ctx: get_usage() / get_help()
    Exc->>User: echo("Error: ...")
    CLI->>CLI: sys.exit(exc.exit_code)
```

### Exit Code Semantics

| Exception | Exit Code | Meaning |
|-----------|-----------|---------|
| `ClickException` (base) | `1` | Generic application error |
| `UsageError` and subclasses | `2` | Incorrect command-line usage |
| `Exit` | configurable (default `0`) | Explicit program exit |
| `Abort` | (handled by caller) | Internal abort signal |

---

## Process Flow: Raising and Displaying an Error

```mermaid
flowchart TD
    A[Error condition detected] --> B{Which kind?}
    B -->|Bad value| C[raise BadParameter]
    B -->|Missing required| D[raise MissingParameter]
    B -->|Unknown option| E[raise NoSuchOption]
    B -->|Wrong option usage| F[raise BadOptionUsage]
    B -->|File cannot open| G[raise FileError]
    B -->|Generic usage problem| H[raise UsageError]
    B -->|Abort requested| I[raise Abort]
    B -->|Exit requested| J[raise Exit]

    C --> K[Caught by CLI entrypoint]
    D --> K
    E --> K
    F --> K
    G --> K
    H --> K

    K --> L[Call exc.show file=stderr]
    L --> M[format_message builds text]
    M --> N[echo writes to stderr]
    N --> O[sys.exit exc.exit_code]

    I --> P[Handled internally, no display]
    J --> Q[Exit with exc.exit_code]
```

---

## Design Notes

- **Localization**: All user-facing strings are wrapped with `gettext` (`_`) and `ngettext` for pluralization, enabling translation.
- **Context attachment**: `UsageError` and its subclasses accept an optional `Context`, allowing Click to automatically enrich errors with usage strings, help hints, and color settings.
- **Separation of concerns**: `Abort` and `Exit` deliberately inherit from `RuntimeError` rather than `ClickException`, keeping internal control-flow signals distinct from displayable errors.
- **Safe filename display**: `FileError` uses `format_filename` to avoid encoding errors when printing filenames containing invalid bytes or surrogate escapes.

---

## Related Modules

- [core.md](core.md) — `Context`, `Command`, and `Parameter`, which raise and consume these exceptions.
- [parser.md](parser.md) — the option/argument parser that triggers many usage errors.
- [utils.md](utils.md) — `echo` and `format_filename` used for output and safe display.
- [compat.md](compat.md) — `get_text_stderr` and platform-specific stream handling.
- [types.md](types.md) — parameter types that raise `BadParameter` and provide missing-value messages.
