# Compat Module

## Introduction

The `compat` module (`src/click/_compat.py`) is Click's cross-platform compatibility layer. It abstracts away the differences between operating systems (notably Windows vs. POSIX), Python versions, and the various stream implementations that tools like Jupyter notebooks, PyPy, and colorama introduce. Its primary responsibilities are:

- **Stream normalization**: Converting arbitrary binary/text streams into well-behaved text streams with predictable encoding and error handling.
- **Standard stream access**: Providing reliable binary and text accessors for `stdin`, `stdout`, and `stderr`.
- **Atomic file writes**: Offering crash-safe file writing via temporary files and atomic renames.
- **ANSI handling**: Detecting terminal capabilities and stripping/wrapping ANSI escape codes as needed.
- **Windows console support**: Bridging to the Windows console implementation in the [`winconsole`](winconsole.md) module.

This module is foundational: nearly every other part of Click that touches I/O depends on it. It is consumed by [`utils`](utils.md) (via `LazyFile`/`open_stream`), [`termui_impl`](termui_impl.md), [`textwrap`](textwrap.md), and the core command machinery in [`core`](core.md).

---

## Architecture Overview

The module is organized around a small set of cooperating concerns. The diagram below shows the major functional areas and how they relate.

```mermaid
graph TD
    subgraph "Public API"
        open_stream["open_stream()"]
        get_text_stdin["get_text_stdin/stdout/stderr()"]
        get_binary_stdin["get_binary_stdin/stdout/stderr()"]
        strip_ansi["strip_ansi() / term_len()"]
        should_strip_ansi["should_strip_ansi()"]
        auto_wrap_for_ansi["auto_wrap_for_ansi()"]
    end

    subgraph "Stream Normalization"
        force_correct_text["_force_correct_text_stream()"]
        force_reader["_force_correct_text_reader()"]
        force_writer["_force_correct_text_writer()"]
        make_text_stream["_make_text_stream()"]
        find_binary_reader["_find_binary_reader()"]
        find_binary_writer["_find_binary_writer()"]
        is_binary_reader["_is_binary_reader()"]
        is_binary_writer["_is_binary_writer()"]
    end

    subgraph "Stream Wrappers"
        NonClosing["_NonClosingTextIOWrapper"]
        Fixup["_FixupStream"]
        AtomicFile["_AtomicFile"]
    end

    subgraph "Platform Detection"
        WIN["WIN / CYGWIN flags"]
        winconsole["_get_windows_console_stream()"]
        argv_encoding["_get_argv_encoding()"]
    end

    open_stream --> make_text_stream
    open_stream --> AtomicFile
    open_stream --> get_text_stdin
    open_stream --> get_binary_stdin

    get_text_stdin --> force_reader
    get_text_stdin --> winconsole
    get_text_stdout --> force_writer
    get_text_stdout --> winconsole

    force_reader --> force_correct_text
    force_writer --> force_correct_text
    force_correct_text --> make_text_stream
    force_correct_text --> find_binary_reader
    force_correct_text --> find_binary_writer
    find_binary_reader --> is_binary_reader
    find_binary_writer --> is_binary_writer

    make_text_stream --> NonClosing
    NonClosing --> Fixup

    auto_wrap_for_ansi --> should_strip_ansi
    auto_wrap_for_ansi --> winconsole
```

---

## Core Components

### `_NonClosingTextIOWrapper`

A subclass of `io.TextIOWrapper` that **does not close its underlying binary stream** when garbage-collected. This is critical because Click frequently wraps `sys.stdin`/`sys.stdout`/`sys.stderr`; closing those would break the interpreter.

Key behaviors:

- Wraps the incoming binary stream in a [`_FixupStream`](#_fixupstream) before passing it to `TextIOWrapper`.
- Overrides `__del__` to `detach()` rather than close, so the underlying stream survives.
- Overrides `isatty()` to delegate to the wrapped stream (working around a [PyPy issue](https://bitbucket.org/pypy/pypy/issue/1803)).

```mermaid
classDiagram
    class TextIOWrapper {
        <<stdlib>>
    }
    class _NonClosingTextIOWrapper {
        -_stream: BinaryIO
        +__del__()
        +isatty() bool
    }
    class _FixupStream {
        -_stream: BinaryIO
        -_force_readable: bool
        -_force_writable: bool
        +read1(size) bytes
        +readable() bool
        +writable() bool
        +seekable() bool
    }
    TextIOWrapper <|-- _NonClosingTextIOWrapper
    _NonClosingTextIOWrapper --> _FixupStream : wraps
```

### `_FixupStream`

A transparent proxy that adapts "badly patched" stream objects (e.g., those injected by certain Jupyter notebook versions) to the modern `io` interface. It forwards all attribute access to the wrapped stream via `__getattr__` but provides robust implementations of the capability-probing methods:

| Method | Behavior |
| --- | --- |
| `read1(size)` | Uses the stream's `read1` if present, otherwise falls back to `read`. |
| `readable()` | Honors `force_readable`; otherwise probes via `readable()` or a `read(0)` trial. |
| `writable()` | Honors `force_writable`; otherwise probes via `writable()` or a `write("")`/`write(b"")` trial. |
| `seekable()` | Probes via `seekable()` or a `seek(tell())` trial. |

The `force_readable`/`force_writable` flags exist specifically to work around tools that place objects on `sys` that misreport their capabilities.

### `_AtomicFile`

A file-like proxy that implements **atomic writes**. It writes to a temporary file in the same directory and, on `close()`, atomically replaces the target file using `os.replace`. This guarantees that readers never observe a partially written file.

```mermaid
sequenceDiagram
    participant Caller
    participant open_stream
    participant _AtomicFile
    participant Filesystem

    Caller->>open_stream: open_stream(path, "w", atomic=True)
    open_stream->>Filesystem: os.open(tmp_filename, O_CREAT|O_EXCL)
    open_stream->>open_stream: _wrap_io_open(fd, ...)
    open_stream->>_AtomicFile: _AtomicFile(f, tmp, real)
    open_stream-->>Caller: (af, True)
    Caller->>_AtomicFile: write(data)
    _AtomicFile->>Filesystem: write to tmp file
    Caller->>_AtomicFile: close()
    _AtomicFile->>Filesystem: os.replace(tmp, real)
    _AtomicFile-->>Caller: closed
```

Notable details:

- `name` property returns the **real** filename, not the temporary one.
- `__exit__` calls `close(delete=exc_type is not None)` — though note the current implementation always performs the replace regardless of the `delete` flag.
- All other attribute access is proxied to the underlying file via `__getattr__`.

---

## Stream Normalization Pipeline

The heart of the module is the logic that turns an arbitrary stream into a correctly-configured text stream. This is a multi-stage decision process.

```mermaid
flowchart TD
    Start["Input stream"] --> IsBinary{"_is_binary_reader/writer?"}
    IsBinary -->|Yes| UseBinary["Use stream as binary"]
    IsBinary -->|No| Compatible{"_is_compatible_text_stream?"}
    Compatible -->|Yes, and not misconfigured| ReturnAsIs["Return stream as-is"]
    Compatible -->|No| FindBinary{"_find_binary_reader/writer"}
    FindBinary -->|Found| UseBinary
    FindBinary -->|Not found| ReturnOriginal["Return original (mojibake)"]
    UseBinary --> MakeText["_make_text_stream()"]
    MakeText --> Wrap["_NonClosingTextIOWrapper + _FixupStream"]
    Wrap --> Done["Correct text stream"]
```

### Helper predicates

- `_is_binary_reader` / `_is_binary_writer`: Probe whether a stream yields/accepts `bytes` by attempting a zero-length read/write.
- `_find_binary_reader` / `_find_binary_writer`: Locate a binary stream, either the stream itself or its `.buffer` attribute (handling detached/closed streams).
- `_stream_is_misconfigured`: Detects streams whose encoding is ASCII (a common problem in unittest environments).
- `_is_compat_stream_attr` / `_is_compatible_text_stream`: Check whether a stream's `encoding`/`errors` already match the desired configuration.

### Encoding helpers

- `is_ascii_encoding(encoding)`: Uses `codecs.lookup` to determine if an encoding is ASCII.
- `get_best_encoding(stream)`: Returns the stream's encoding, falling back to the system default, and upgrading ASCII to UTF-8.

---

## Public API

### `open_stream(filename, mode, encoding, errors, atomic)`

The central file-opening function. Returns a tuple of `(stream, should_close)`.

Behavior by case:

| Case | Result |
| --- | --- |
| `filename == "-"` | Returns a standard stream (stdin for read modes, stdout for write modes). `should_close=False`. |
| Non-atomic | Delegates to `_wrap_io_open` (regular `open`). `should_close=True`. |
| Atomic (`atomic=True`) | Creates a temp file and returns an `_AtomicFile`. Requires `w` mode; rejects `a` and `x` modes. |

```mermaid
flowchart TD
    A["open_stream(filename, mode, ...)"] --> B{"filename == '-'?"}
    B -->|Yes| C{"write mode?"}
    C -->|Yes| D["get_text/binary_stdout"]
    C -->|No| E["get_text/binary_stdin"]
    B -->|No| F{"atomic?"}
    F -->|No| G["_wrap_io_open → open()"]
    F -->|Yes| H{"mode valid?"}
    H -->|"a or x"| I["ValueError"]
    H -->|"no w"| J["ValueError"]
    H -->|"w"| K["Create temp file + _AtomicFile"]
```

### Standard stream accessors

| Function | Returns |
| --- | --- |
| `get_binary_stdin()` | Binary reader for `sys.stdin` (raises `RuntimeError` if unavailable). |
| `get_binary_stdout()` | Binary writer for `sys.stdout`. |
| `get_binary_stderr()` | Binary writer for `sys.stderr`. |
| `get_text_stdin(encoding, errors)` | Text reader for `sys.stdin`, Windows-console-aware. |
| `get_text_stdout(encoding, errors)` | Text writer for `sys.stdout`, Windows-console-aware. |
| `get_text_stderr(encoding, errors)` | Text writer for `sys.stderr`, Windows-console-aware. |

The text accessors first attempt `_get_windows_console_stream` (a no-op on non-Windows) and otherwise fall back to the force-correct pipeline with `force_readable`/`force_writable` set.

### Cached stream functions

`_make_cached_stream_func` builds a memoized wrapper (using a `WeakKeyDictionary`) so that repeated calls for the same underlying stream return the same wrapped stream. This produces the module-level singletons:

- `_default_text_stdin`
- `_default_text_stdout`
- `_default_text_stderr`

### Stream registries

Two mappings expose the accessors by name for dynamic lookup:

```python
binary_streams = {"stdin": ..., "stdout": ..., "stderr": ...}
text_streams   = {"stdin": ..., "stdout": ..., "stderr": ...}
```

---

## ANSI and Terminal Handling

### `strip_ansi(value)` and `term_len(x)`

`strip_ansi` removes ANSI escape sequences using the compiled `_ansi_re` pattern. `term_len` returns the visible length of a string (its length after stripping ANSI codes), which is essential for correct terminal-width calculations in [`formatting`](formatting.md) and [`termui_impl`](termui_impl.md).

### `should_strip_ansi(stream, color)`

Determines whether ANSI codes should be stripped. When `color` is `None`, it strips unless the stream is a TTY or a Jupyter kernel output stream. When `color` is explicitly set, it returns `not color`.

### `auto_wrap_for_ansi(stream, color)`

On Windows, wraps a text stream with `colorama.AnsiToWin32` to translate ANSI codes into Win32 console calls. The wrapper is cached in a `WeakKeyDictionary` and its `write` method is patched to reset colorama state on failure. On non-Windows platforms, this is a no-op (the symbol is only defined inside the Windows branch).

```mermaid
flowchart LR
    subgraph Windows
        A["auto_wrap_for_ansi(stream)"] --> B["colorama.AnsiToWin32"]
        B --> C["cached wrapper"]
    end
    subgraph "Non-Windows"
        D["_get_windows_console_stream → None"]
    end
```

### `isatty(stream)`

A safe wrapper around `stream.isatty()` that returns `False` on any exception.

### `_is_jupyter_kernel_output(stream)`

Unwraps `_FixupStream`/`_NonClosingTextIOWrapper` layers and checks whether the underlying stream originates from the `ipykernel` module. Used by `should_strip_ansi` to avoid emitting ANSI codes into notebook output.

---

## Platform Detection

The module computes platform flags at import time:

```python
CYGWIN = sys.platform.startswith("cygwin")
WIN = sys.platform.startswith("win")
```

These drive conditional definitions:

- **On Windows**: `_get_windows_console_stream` is imported from [`winconsole`](winconsole.md), `_get_argv_encoding` uses `locale.getpreferredencoding()`, and `auto_wrap_for_ansi` is fully implemented.
- **On other platforms**: `_get_windows_console_stream` returns `None`, `_get_argv_encoding` uses `sys.stdin.encoding` or the filesystem encoding, and `auto_wrap_for_ansi` is `None`.

---

## Dependencies and Relationships

```mermaid
graph LR
    compat["compat (_compat.py)"]
    winconsole["winconsole (_winconsole.py)"]
    utils["utils (utils.py)"]
    termui["termui_impl (_termui_impl.py)"]
    textwrap["textwrap (_textwrap.py)"]
    core["core (core.py)"]
    formatting["formatting (formatting.py)"]

    compat -->|"imports _get_windows_console_stream (Windows)"| winconsole
    utils -->|"uses open_stream, LazyFile"| compat
    termui -->|"uses stream accessors, strip_ansi"| compat
    textwrap -->|"uses term_len"| compat
    core -->|"uses stream accessors"| compat
    formatting -->|"uses term_len, strip_ansi"| compat
```

### Downstream consumers

- **[`utils`](utils.md)**: `LazyFile` calls `open_stream` to defer file opening; `KeepOpenFile` and `PacifyFlushWrapper` complement the stream-wrapping strategy (the latter suppresses `BrokenPipeError` on flush, mirroring the robustness goals of this module).
- **[`winconsole`](winconsole.md)**: Provides `_get_windows_console_stream`, which this module imports on Windows to support native console I/O.
- **[`termui_impl`](termui_impl.md)**: Relies on stream accessors and ANSI utilities for progress bars and editors.
- **[`textwrap`](textwrap.md)**: Uses `term_len` for width-aware wrapping.
- **[`core`](core.md)** and **[`formatting`](formatting.md)**: Use stream accessors and ANSI helpers for output and help formatting.

---

## Design Notes and Edge Cases

1. **Never close standard streams**: `_NonClosingTextIOWrapper` and the `should_close` flag returned by `open_stream` ensure Click never accidentally closes `sys.stdin`/`stdout`/`stderr`.
2. **Graceful degradation**: When a binary stream cannot be found, the module returns the original text stream rather than raising, accepting mojibake over a crash.
3. **ASCII misconfiguration recovery**: Streams reporting ASCII encoding are transparently re-wrapped as UTF-8.
4. **Atomic write constraints**: Atomic writes only support `w` mode; `a` and `x` raise `ValueError` with explanatory messages.
5. **Weak caching**: Stream wrappers are cached weakly to avoid leaking references to streams that may be replaced (e.g., during testing).
6. **Jupyter awareness**: ANSI stripping accounts for notebook kernels, which render escape codes literally.
