# Textwrap Module

## Introduction

The `textwrap` module (`src/click/_textwrap.py`) provides a specialized text-wrapping utility for the Click CLI framework. It extends Python's standard library `textwrap.TextWrapper` with additional capabilities required for rendering help pages, usage strings, and other terminal-formatted output.

The module's single core component, `TextWrapper`, augments the standard wrapper with:

- **Long-word handling** that respects a minimum width of one character, ensuring words are never dropped when breaking is disabled.
- **Temporary indentation** via the `extra_indent` context manager, allowing nested indentation to be applied and cleanly reverted.
- **Indent-only formatting** via `indent_only`, which applies indentation to existing lines without re-wrapping them.

This module sits within the **terminal_and_platform_foundation** layer of Click and is consumed primarily by the help-formatting subsystem.

---

## Architecture

The `TextWrapper` class is a thin, focused subclass of the standard library's `textwrap.TextWrapper`. It does not introduce new state beyond what the parent class provides; instead, it overrides one method and adds two helpers.

```mermaid
classDiagram
    class TextWrapper {
        +_handle_long_word(reversed_chunks, cur_line, cur_len, width)
        +extra_indent(indent) Iterator
        +indent_only(text) str
    }
    class StdTextWrapper {
        <<stdlib textwrap.TextWrapper>>
        +initial_indent
        +subsequent_indent
        +break_long_words
        +wrap(text)
        +fill(text)
    }
    StdTextWrapper <|-- TextWrapper
```

### Key Attributes (inherited)

| Attribute | Purpose |
|-----------|---------|
| `initial_indent` | Prefix applied to the first line of wrapped output. |
| `subsequent_indent` | Prefix applied to all lines after the first. |
| `break_long_words` | Whether words longer than the width may be split. |
| `width` | Maximum line width for wrapping. |

---

## Component Reference

### `TextWrapper._handle_long_word`

```python
def _handle_long_word(
    self,
    reversed_chunks: list[str],
    cur_line: list[str],
    cur_len: int,
    width: int,
) -> None:
```

Overrides the standard library's long-word handling to guarantee that at least one character of space is always available.

- Computes `space_left = max(width - cur_len, 1)`, ensuring a minimum of one character even when the current line already exceeds the target width.
- When `break_long_words` is enabled, it splits the last chunk at `space_left`, appending the head to the current line and leaving the remainder in `reversed_chunks` for subsequent lines.
- When breaking is disabled and the current line is empty, it moves the entire chunk onto the line (preventing an infinite loop that could otherwise occur).

This behavior is critical for help rendering, where a single very long token (e.g., a long option name or path) must still be emitted rather than silently dropped.

### `TextWrapper.extra_indent`

```python
@contextmanager
def extra_indent(self, indent: str) -> cabc.Iterator[None]:
```

A context manager that temporarily prepends `indent` to both `initial_indent` and `subsequent_indent`. On exit, the original indentation values are restored in a `finally` block, guaranteeing correct state even if an exception occurs.

This enables nested formatting — for example, indenting a block of help text within an already-indented section — without manual save/restore bookkeeping.

### `TextWrapper.indent_only`

```python
def indent_only(self, text: str) -> str:
```

Applies indentation to each line of `text` **without** re-wrapping. The first line receives `initial_indent`; all subsequent lines receive `subsequent_indent`. Lines are rejoined with `\n`.

This is useful when text has already been wrapped (or must preserve its original line breaks) but still needs consistent indentation applied.

---

## Data Flow

The following diagram illustrates how `TextWrapper` is used during help-page generation. The `HelpFormatter` (see [formatting.md](formatting.md)) delegates text-wrapping to a `TextWrapper` instance.

```mermaid
flowchart TD
    A[HelpFormatter.write_text / write_dl] --> B[wrap_text helper]
    B --> C[TextWrapper instance]
    C --> D{Line exceeds width?}
    D -- No --> E[Emit line as-is]
    D -- Yes --> F[Wrap at word boundaries]
    F --> G{Word longer than width?}
    G -- Yes --> H[_handle_long_word]
    H --> I[Split word, keep remainder]
    G -- No --> J[Move word to next line]
    C --> K[extra_indent context]
    K --> L[Apply temporary indentation]
    C --> M[indent_only]
    M --> N[Indent existing lines without rewrap]
```

---

## Process Flow: Long-Word Handling

```mermaid
flowchart TD
    Start([_handle_long_word called]) --> Calc[space_left = max width - cur_len, 1]
    Calc --> Check{break_long_words?}
    Check -- Yes --> Split[cut = last chunk up to space_left]
    Split --> Append[Append cut to cur_line]
    Append --> Remain[Store remainder back in reversed_chunks]
    Check -- No --> Empty{cur_line empty?}
    Empty -- Yes --> Pop[Pop entire chunk onto cur_line]
    Empty -- No --> Skip[Do nothing]
    Remain --> End([Return])
    Pop --> End
    Skip --> End
```

---

## Module Relationships

The `textwrap` module is a low-level utility within the terminal and platform foundation. It has no dependencies on other Click modules and is consumed by higher-level formatting code.

```mermaid
flowchart LR
    subgraph Foundation[terminal_and_platform_foundation]
        TW[textwrap<br/>TextWrapper]
        COMPAT[compat<br/>_FixupStream]
        UTILS[utils<br/>PacifyFlushWrapper]
        TERMUI[termui_impl<br/>Editor, ProgressBar]
        WIN[winconsole<br/>ConsoleStream]
    end
    subgraph Formatting[cli_engine]
        FMT[formatting<br/>HelpFormatter]
    end
    FMT -->|uses wrap_text| TW
    FMT -.->|terminal width| COMPAT
```

### Related Documentation

- [formatting.md](formatting.md) — `HelpFormatter`, the primary consumer of `TextWrapper` for rendering help pages.
- [compat.md](compat.md) — Stream compatibility helpers used across the foundation layer.
- [utils.md](utils.md) — General utility wrappers (`PacifyFlushWrapper`, `LazyFile`, etc.).
- [termui_impl.md](termui_impl.md) — Terminal UI implementations (`Editor`, `ProgressBar`).
- [winconsole.md](winconsole.md) — Windows console stream handling.

---

## Design Notes

1. **Minimal surface area.** The class deliberately overrides only `_handle_long_word` and adds two small helpers, keeping behavior aligned with the standard library while fixing edge cases relevant to CLI output.

2. **State safety.** `extra_indent` uses a `try/finally` block to restore indentation, ensuring that exceptions during nested formatting do not corrupt the wrapper's state.

3. **No re-wrapping in `indent_only`.** By preserving existing line breaks, `indent_only` supports pre-formatted content (such as usage strings) that must not be reflowed.

4. **Foundation-layer placement.** Because it depends only on the standard library, `TextWrapper` can be safely reused by any higher-level module without introducing circular dependencies.
