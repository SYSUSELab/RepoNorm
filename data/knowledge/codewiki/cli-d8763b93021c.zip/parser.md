# Parser Module

## Introduction

The `parser` module (`src/click/parser.py`) is Click's low-level command-line tokenizer and argument dispatcher. It is responsible for taking a raw list of command-line tokens (e.g. `["--verbose", "-n", "3", "input.txt"]`) and splitting them into:

- **Options** — named flags/values such as `--verbose` or `-n 3`, keyed by their destination name.
- **Arguments** — positional values such as `input.txt`.
- **Order** — the sequence in which parameters appeared on the command line.

The module is a heavily simplified descendant of the standard library's `optparse` module. Features that Click implements at a higher level — type conversion, default handling, help formatting, prompting, and environment variable resolution — are deliberately **not** implemented here. The parser only performs *tokenization and dispatch*; the semantic interpretation of values is delegated to the [`core`](core.md) module (specifically `Parameter`, `Option`, and `Argument`).

> **Deprecation note:** As of Click 8.2, the public-facing names in this module (`OptionParser`, `Argument`, `Option`, `ParsingState`, `split_opt`, `normalize_opt`) are deprecated and will be removed in Click 9.0. The internal underscore-prefixed classes remain the implementation used by `core`. See [Deprecated Public API](#deprecated-public-api).

---

## Architecture Overview

The parser module sits between the raw command-line input and Click's high-level parameter objects. It is invoked by `Command.parse_args` in the [`core`](core.md) module.

```mermaid
graph TD
    CLI["Command-line tokens<br/>['--verbose', '-n', '3', 'file.txt']"]
    CMD["core.Command.parse_args"]
    PARSER["_OptionParser"]
    STATE["_ParsingState"]
    OPT["_Option"]
    ARG["_Argument"]
    COREOPT["core.Option"]
    COREARG["core.Argument"]
    CTX["core.Context"]
    EXC["exceptions<br/>(NoSuchOption, BadOptionUsage, ...)"]

    CLI --> CMD
    CMD -->|"add_option / add_argument"| PARSER
    CMD -->|"parse_args(args)"| PARSER
    PARSER --> STATE
    PARSER --> OPT
    PARSER --> ARG
    OPT -.->|"obj reference"| COREOPT
    ARG -.->|"obj reference"| COREARG
    PARSER -.->|"reads config"| CTX
    PARSER -.->|"raises"| EXC
    PARSER -->|"returns (opts, args, order)"| CMD
```

### Key Design Principles

| Principle | Description |
|-----------|-------------|
| **Separation of concerns** | The parser only tokenizes and dispatches; it never converts types or applies defaults. |
| **Object back-references** | Each `_Option`/`_Argument` holds a reference to its originating `core.Option`/`core.Argument` (`obj`), enabling the `order` list to report which high-level parameter was seen. |
| **Context-driven behavior** | Parsing behavior (`allow_interspersed_args`, `ignore_unknown_options`, `token_normalize_func`, `resilient_parsing`) is read from the `core.Context`. |
| **Resilient parsing** | When `ctx.resilient_parsing` is set, usage errors are swallowed so that completion/help generation can proceed. |

---

## Core Components

### `_ParsingState`

A lightweight mutable container that tracks the progress of a single parse operation.

```python
class _ParsingState:
    def __init__(self, rargs: list[str]) -> None:
        self.opts: dict[str, t.Any] = {}      # parsed option/argument values by dest
        self.largs: list[str] = []            # left args (positional tokens collected so far)
        self.rargs = rargs                    # right args (tokens not yet consumed)
        self.order: list[CoreParameter] = []  # parameters in the order they appeared
```

| Attribute | Purpose |
|-----------|---------|
| `opts` | Maps a parameter's destination name to its raw parsed value. |
| `largs` | Positional tokens accumulated on the left of the current cursor. |
| `rargs` | The remaining, unconsumed tokens on the right. |
| `order` | The list of `core.Parameter` objects in command-line order (duplicates preserved). |

The `largs`/`rargs` split is the classic `optparse` technique: tokens are popped from the front of `rargs`; options are consumed, while positional tokens are moved into `largs`.

---

### `_Option`

Represents a single registered option (one or more option strings sharing a destination).

```python
class _Option:
    def __init__(self, obj, opts, dest, action=None, nargs=1, const=None):
        ...
```

**Construction** splits each option string into a prefix and value via `_split_opt`, classifying them as short (`-v`) or long (`--verbose`) options and collecting the set of valid prefixes.

**Supported actions** (mirroring `optparse`):

| Action | Behavior |
|--------|----------|
| `store` | Store the value at `dest`. |
| `store_const` | Store `const` at `dest` (used for flags). |
| `append` | Append the value to a list at `dest`. |
| `append_const` | Append `const` to a list at `dest`. |
| `count` | Increment an integer counter at `dest`. |

The `takes_value` property returns `True` for `store` and `append` actions.

`process(value, state)` applies the action to the parsing state and appends `self.obj` to `state.order`.

---

### `_Argument`

Represents a positional argument.

```python
class _Argument:
    def __init__(self, obj, dest, nargs=1):
        ...
```

`process(value, state)` handles the `nargs` semantics:

- **`nargs > 1`**: validates that the tuple of values has no "holes" (missing values). If all values are `None`, the value becomes `None`; if only some are missing, a `BadArgumentUsage` is raised.
- **`nargs == -1`** (variadic): an empty tuple is converted to `None` so that an environment variable may still be consulted.
- Stores the value at `dest` and appends `self.obj` to `state.order`.

---

### `_OptionParser`

The central orchestrator. It is modelled after `optparse`'s `OptionParser` but with a vastly simplified API.

```python
class _OptionParser:
    def __init__(self, ctx: Context | None = None) -> None:
        ...
```

**Configuration attributes** (initialized from the context when provided):

| Attribute | Default | Description |
|-----------|---------|-------------|
| `allow_interspersed_args` | `True` | If `False`, parsing stops at the first non-option token (used for nested subcommands). |
| `ignore_unknown_options` | `False` | If `True`, unknown options are collected into `largs` instead of raising. |
| `_short_opt` | `{}` | Map of short option strings to `_Option`. |
| `_long_opt` | `{}` | Map of long option strings to `_Option`. |
| `_opt_prefixes` | `{"-", "--"}` | Set of recognized option prefixes. |
| `_args` | `[]` | Registered positional `_Argument` objects. |

**Public methods:**

- `add_option(obj, opts, dest, action, nargs, const)` — registers an option, normalizing each option string via `_normalize_opt`.
- `add_argument(obj, dest, nargs)` — registers a positional argument.
- `parse_args(args)` — the main entry point; returns `(opts, largs, order)`.

---

## Parsing Flow

The following sequence diagram shows how `parse_args` processes a token list.

```mermaid
sequenceDiagram
    participant CMD as core.Command
    participant P as _OptionParser
    participant S as _ParsingState
    participant O as _Option / _Argument

    CMD->>P: parse_args(args)
    P->>S: create _ParsingState(args)
    P->>P: _process_args_for_options(state)
    loop while rargs not empty
        P->>S: pop token from rargs
        alt token == "--"
            P->>P: stop option processing
        else token is an option (prefix match)
            P->>P: _process_opts(token, state)
            P->>O: option.process(value, state)
            O->>S: update opts + order
        else positional token
            P->>S: append to largs
        end
    end
    P->>P: _process_args_for_args(state)
    P->>O: argument.process(value, state)
    O->>S: update opts + order
    P-->>CMD: (state.opts, state.largs, state.order)
```

### Step-by-step

1. **`_process_args_for_options`** — iterates over `rargs`, dispatching each token:
   - `--` terminates option processing (everything after is positional).
   - Tokens starting with a known prefix are routed to `_process_opts`.
   - Other tokens are appended to `largs` (if interspersed args are allowed) or pushed back to stop parsing.

2. **`_process_opts`** — handles a single option token:
   - Splits on `=` to extract an explicit value (`--name=value`).
   - Attempts a **long option match** first (this also allows `-foo` to match as a long option).
   - On `NoSuchOption`, falls back to **short option matching** unless the token uses a two-character prefix.

3. **`_match_long_opt`** — looks up the option in `_long_opt`. If not found, uses `difflib.get_close_matches` to suggest alternatives and raises `NoSuchOption`. Otherwise, obtains the value (if the option takes one) and calls `option.process`.

4. **`_match_short_opt`** — iterates over each character in a combined short-option token (e.g. `-abc`):
   - Each character is matched against `_short_opt`.
   - If an option takes a value, the remainder of the token is treated as the value.
   - Unknown characters are either collected (when `ignore_unknown_options`) or raise `NoSuchOption`.

5. **`_get_value_from_state`** — extracts the value(s) for an option:
   - If insufficient tokens remain and the option allows omitting its value (`_flag_needs_value`), returns the sentinel `_flag_needs_value`.
   - If the next token looks like an option and omitting is allowed, returns the sentinel.
   - Otherwise pops `nargs` tokens (or a tuple for `nargs > 1`).

6. **`_process_args_for_args`** — uses `_unpack_args` to distribute remaining positional tokens across registered arguments according to their `nargs` specifications.

---

## Helper Functions

### `_unpack_args(args, nargs_spec)`

Distributes a flat sequence of positional tokens across arguments with varying `nargs` requirements. Returns a tuple of unpacked values plus the leftover tokens.

- `nargs == 1` → single value.
- `nargs > 1` → a tuple of that size (missing items filled with `None`).
- `nargs == -1` → a wildcard that consumes all remaining tokens (only one allowed).

### `_split_opt(opt)`

Splits an option string into `(prefix, value)`:

- `-v` → `("-", "v")`
- `--verbose` → `("--", "verbose")`
- `-` → `("-", "")`

### `_normalize_opt(opt, ctx)`

Applies the context's `token_normalize_func` (if any) to the option's value portion, enabling case-insensitive or otherwise normalized option matching.

### `_flag_needs_value` (sentinel)

A module-level sentinel object indicating that an option was passed as a flag without a value but is not a pure flag. `core.Option.consume_value` uses this to decide whether to prompt the user or fall back to `flag_value`.

---

## Dependencies

```mermaid
graph LR
    PARSER["parser.py"]
    EXC["exceptions.py"]
    CORE["core.py"]
    SHELL["shell_completion.py"]

    PARSER -->|"imports"| EXC
    PARSER -.->|"TYPE_CHECKING only"| CORE
    PARSER -.->|"lazy import (deprecated)"| SHELL
    CORE -->|"uses _OptionParser"| PARSER
```

| Dependency | Direction | Purpose |
|------------|-----------|---------|
| [`exceptions`](exceptions.md) | import | Raises `BadArgumentUsage`, `BadOptionUsage`, `NoSuchOption`, `UsageError`. |
| [`core`](core.md) | type-only | `Context`, `Option`, `Argument`, `Parameter` are referenced only under `TYPE_CHECKING` to avoid circular imports. |
| [`shell_completion`](shell_completion.md) | lazy | `split_arg_string` is re-exported for backward compatibility. |

> **Circular import avoidance:** `core` imports `_OptionParser` at runtime, while `parser` imports `core` types only under `t.TYPE_CHECKING`. This one-directional runtime dependency keeps the module graph acyclic.

---

## Integration with `core`

The parser is wired into Click's high-level API through two methods on `core.Parameter` subclasses:

- **`core.Option.add_to_parser(parser, ctx)`** — translates an option's configuration (`multiple`, `count`, `is_flag`, `secondary_opts`, `flag_value`) into one or more `parser.add_option(...)` calls with the appropriate `action`.
- **`core.Argument.add_to_parser(parser, ctx)`** — calls `parser.add_argument(dest, nargs, obj)`.

After parsing, `core.Command.parse_args` iterates over the returned `order` list and calls `Parameter.handle_parse_result` for each parameter, which performs type conversion, default resolution, environment variable lookup, and prompting. See the [`core`](core.md) documentation for details on that higher-level processing.

```mermaid
flowchart LR
    A["core.Option.add_to_parser"] -->|"action=store/append/count"| B["_OptionParser.add_option"]
    C["core.Argument.add_to_parser"] -->|"nargs"| D["_OptionParser.add_argument"]
    B --> E["_OptionParser.parse_args"]
    D --> E
    E -->|"opts, args, order"| F["core.Command.parse_args"]
    F -->|"for param in order"| G["Parameter.handle_parse_result"]
```

---

## Error Handling

The parser raises exceptions from the [`exceptions`](exceptions.md) module:

| Exception | Raised when |
|-----------|-------------|
| `NoSuchOption` | An unknown option is encountered (with close-match suggestions). |
| `BadOptionUsage` | An option is used incorrectly (e.g. a value is given to a flag, or required arguments are missing). |
| `BadArgumentUsage` | A positional argument receives an incorrect number of values. |
| `UsageError` | Base class for the above; carries the `Context` for usage display. |

When `ctx.resilient_parsing` is `True`, `parse_args` catches `UsageError` and returns whatever was parsed so far, allowing help/completion generation to proceed without failing.

---

## Deprecated Public API

The module exposes a `__getattr__` hook that emits `DeprecationWarning`s for legacy names, mapping them to their underscore-prefixed counterparts:

| Deprecated name | Maps to |
|-----------------|---------|
| `OptionParser` | `_OptionParser` |
| `Argument` | `_Argument` |
| `Option` | `_Option` |
| `ParsingState` | `_ParsingState` |
| `split_opt` | `_split_opt` |
| `normalize_opt` | `_normalize_opt` |
| `split_arg_string` | `shell_completion.split_arg_string` |

All of these will be removed in Click 9.0.

---

## Related Modules

- [core](core.md) — high-level `Command`, `Context`, `Parameter`, `Option`, and `Argument` classes that drive the parser.
- [exceptions](exceptions.md) — error types raised during parsing.
- [types](types.md) — parameter type conversion applied *after* parsing.
- [shell_completion](shell_completion.md) — provides `split_arg_string` and completion support that relies on resilient parsing.
