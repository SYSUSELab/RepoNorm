# Formatting Module

## Introduction

The `formatting` module is responsible for rendering text-based help pages for the Click CLI framework. It provides the low-level primitives that turn structured data (usage strings, option/command definition lists, headings, and paragraphs) into neatly wrapped, indented, terminal-friendly output.

The module's central component is the [`HelpFormatter`](#helpformatter) class, which accumulates formatted text into an in-memory buffer. Supporting it are a set of module-level helper functions — `wrap_text`, `measure_table`, `iter_rows`, and `join_options` — that handle text wrapping, column measurement, and option-string joining.

This module sits between the higher-level command/option model (see [core.md](core.md)) and the terminal/platform primitives (see [terminal_and_platform_foundation.md](terminal_and_platform_foundation.md)). It does not decide *what* to display; that responsibility belongs to the command and option classes. Instead, it decides *how* the content is laid out.

---

## Architecture

The formatting module is a leaf-level rendering utility. It depends on a small set of helpers from sibling modules and is consumed by the command/option layer.

```mermaid
graph TD
    subgraph "formatting module"
        HF[HelpFormatter]
        WT[wrap_text]
        MT[measure_table]
        IR[iter_rows]
        JO[join_options]
    end

    subgraph "terminal_and_platform_foundation"
        TW[TextWrapper<br/>_textwrap.py]
        TL[term_len<br/>_compat.py]
    end

    subgraph "parser"
        SO[_split_opt<br/>parser.py]
    end

    subgraph "core"
        CMD[Command / Option / Group]
    end

    HF --> WT
    HF --> MT
    HF --> IR
    HF --> TL
    WT --> TW
    WT --> TL
    JO --> SO
    CMD --> HF
    CMD --> JO
```

### Key Relationships

| Component | Depends On | Purpose |
|-----------|-----------|---------|
| `HelpFormatter` | `wrap_text`, `measure_table`, `iter_rows`, `term_len` | Accumulates and lays out help text |
| `wrap_text` | `TextWrapper` ([_textwrap.py](terminal_and_platform_foundation.md)), `term_len` | Wraps text with indentation and paragraph support |
| `join_options` | `_split_opt` ([parser.py](parser.md)) | Joins option strings into a display form |
| `measure_table` / `iter_rows` | — | Column width measurement and row normalization |

---

## Core Components

### HelpFormatter

`HelpFormatter` is the primary public class of the module. It writes formatted help text into an internal buffer (`self.buffer`) and exposes the result via `getvalue()`. It is typically used internally by the command layer, but is also exposed publicly so developers can build custom help output.

#### Construction

```python
HelpFormatter(indent_increment=2, width=None, max_width=None)
```

- **`indent_increment`** — the number of spaces added per indentation level (default `2`).
- **`width`** — the total text width. If `None`, it falls back to the module-level `FORCED_WIDTH` (used by the test system), and finally to the terminal width clamped to `max_width` and a minimum of `50`.
- **`max_width`** — the maximum width when auto-detecting from the terminal (default `80`).

The constructor uses `shutil.get_terminal_size()` to detect the terminal width, subtracting `2` columns for margins.

#### State

| Attribute | Description |
|-----------|-------------|
| `indent_increment` | Spaces added per indent level |
| `width` | Effective text width |
| `current_indent` | Current indentation level in spaces |
| `buffer` | List of strings accumulated for output |

#### Methods

```mermaid
classDiagram
    class HelpFormatter {
        +int indent_increment
        +int width
        +int current_indent
        +list buffer
        +write(string)
        +indent()
        +dedent()
        +write_usage(prog, args, prefix)
        +write_heading(heading)
        +write_paragraph()
        +write_text(text)
        +write_dl(rows, col_max, col_spacing)
        +section(name)
        +indentation()
        +getvalue() str
    }
```

- **`write(string)`** — appends a raw string to the buffer.
- **`indent()` / `dedent()`** — increase/decrease `current_indent` by `indent_increment`.
- **`write_usage(prog, args, prefix)`** — writes a usage line. If the prefix plus program name leaves at least 20 columns, arguments are wrapped to the right of the prefix; otherwise they are placed on the next line. The default prefix is the translated `"Usage: "`.
- **`write_heading(heading)`** — writes a heading followed by a colon, indented to the current level.
- **`write_paragraph()`** — writes a blank line if the buffer is non-empty (used to separate sections).
- **`write_text(text)`** — writes re-indented, re-wrapped text while preserving paragraphs.
- **`write_dl(rows, col_max, col_spacing)`** — writes a definition list (the standard format for options and commands). The first column is capped at `col_max` (default `30`) with `col_spacing` (default `2`) spaces between columns. Raises `TypeError` if the rows do not have exactly two columns.
- **`section(name)`** — a context manager that writes a paragraph break, a heading, and increases indentation for the duration of the block.
- **`indentation()`** — a context manager that increases indentation for the duration of the block.
- **`getvalue()`** — returns the joined buffer contents.

#### Usage Flow

```mermaid
sequenceDiagram
    participant CMD as Command/Option
    participant HF as HelpFormatter
    participant WT as wrap_text

    CMD->>HF: HelpFormatter(width=...)
    CMD->>HF: section("Options")
    HF->>HF: write_paragraph()
    HF->>HF: write_heading("Options")
    HF->>HF: indent()
    CMD->>HF: write_dl(rows)
    HF->>HF: measure_table(rows)
    HF->>WT: wrap_text(second, text_width)
    WT-->>HF: wrapped text
    HF->>HF: write(...)
    CMD->>HF: dedent()
    CMD->>HF: getvalue()
    HF-->>CMD: formatted help string
```

---

### Module-Level Helpers

#### `wrap_text(text, width=78, initial_indent="", subsequent_indent="", preserve_paragraphs=False)`

Intelligently wraps text using the custom [`TextWrapper`](terminal_and_platform_foundation.md) from `_textwrap.py`. By default it treats the input as a single paragraph. When `preserve_paragraphs=True`, it splits on blank lines and handles each paragraph separately.

A paragraph can be prefixed with a line containing the `\b` (backspace, `\x08`) character to indicate that **no rewrapping** should occur in that block — useful for pre-formatted content such as code samples.

The function expands tabs before wrapping and preserves leading indentation per paragraph.

#### `measure_table(rows)`

Computes the maximum width of each column across all rows, returning a tuple of column widths. Uses `term_len` so that ANSI escape sequences do not inflate the measured width.

#### `iter_rows(rows, col_count)`

Normalizes rows to a fixed number of columns by padding short rows with empty strings. This ensures consistent iteration when rendering definition lists.

#### `join_options(options)`

Given a sequence of option strings (e.g. `["-f", "--file"]`), joins them into a single display string, sorted by prefix length. Returns a tuple `(formatted_string, any_prefix_is_slash)` where the boolean indicates whether any option used a `/` prefix (relevant for Windows-style options). Uses `_split_opt` from [parser.py](parser.md) to determine each option's prefix.

---

## Data Flow

The following diagram shows how raw structured data flows through the formatting module to produce final help output.

```mermaid
flowchart LR
    A[Option/Command data] --> B[rows: list of tuples]
    B --> C{HelpFormatter}
    C --> D[measure_table]
    C --> E[iter_rows]
    C --> F[wrap_text]
    F --> G[TextWrapper]
    G --> H[buffer]
    C --> H
    H --> I[getvalue]
    I --> J[Final help string]
```

---

## Integration with Other Modules

- **[core.md](core.md)** — The `Command`, `Group`, and `Option` classes use `HelpFormatter` to render their help pages and `join_options` to format option strings. The formatter is the rendering backend for the command model.
- **[parser.md](parser.md)** — `join_options` relies on `_split_opt` to parse option prefixes.
- **[terminal_and_platform_foundation.md](terminal_and_platform_foundation.md)** — `wrap_text` delegates to the custom `TextWrapper`, and width measurement uses `term_len` from `_compat.py` to correctly handle ANSI-colored text.
- **[testing.md](testing.md)** — The module-level `FORCED_WIDTH` variable exists specifically so the test system can force a deterministic output width.

---

## Design Notes

- **In-memory buffering** — `HelpFormatter` always writes into memory (`self.buffer`) rather than directly to a stream, allowing callers to post-process or capture the output.
- **ANSI-aware measurement** — All width calculations go through `term_len`, which strips ANSI escape sequences, ensuring colored output does not break alignment.
- **Paragraph preservation** — The `\b` marker convention lets callers embed pre-formatted blocks (like code examples) that bypass rewrapping.
- **Deterministic testing** — `FORCED_WIDTH` provides a hook for tests to pin the output width regardless of the actual terminal.
