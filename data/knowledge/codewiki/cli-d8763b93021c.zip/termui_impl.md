# termui_impl Module

## Introduction

The `termui_impl` module (`src/click/_termui_impl.py`) contains the concrete implementations of Click's terminal user interface (TUI) features. To keep Click's import time low, infrequently used functionality is isolated in this module and imported lazily only when needed.

The module provides two primary public components:

- **`ProgressBar`** — a generic, iterable-aware progress bar that renders live progress to a terminal.
- **`Editor`** — a helper that launches the user's preferred text editor to edit a block of text.

In addition, the module contains a collection of supporting functions for paging long output (`pager`, `_pipepager`, `_tempfilepager`, `_nullpager`), opening URLs in the system browser (`open_url`), and reading raw characters from the terminal (`getchar`, `raw_terminal`).

This module sits within the **terminal_and_platform_foundation** layer of Click and depends heavily on the platform abstraction layer provided by [`compat`](compat.md) and the output helpers in [`utils`](utils.md).

---

## Architecture Overview

The module is a leaf-level implementation module: it consumes platform abstractions and output utilities, but is itself consumed by higher-level Click features (such as `click.progressbar`, `click.edit`, `click.echo_via_pager`, and `click.launch`).

```mermaid
graph TD
    subgraph "Higher-level Click API"
        CORE["core.py<br/>(Command, Context)"]
        TERMUI["termui.py<br/>(progressbar, edit, pager, launch)"]
    end

    subgraph "termui_impl (this module)"
        PB["ProgressBar"]
        ED["Editor"]
        PAGER["pager / _pipepager / _tempfilepager / _nullpager"]
        URL["open_url"]
        GETCHAR["getchar / raw_terminal"]
    end

    subgraph "terminal_and_platform_foundation"
        COMPAT["compat.py<br/>(isatty, term_len, strip_ansi,<br/>open_stream, get_best_encoding, WIN, CYGWIN)"]
        UTILS["utils.py<br/>(echo)"]
        WINCONSOLE["winconsole.py"]
    end

    subgraph "Other"
        EXC["exceptions.py<br/>(ClickException)"]
    end

    TERMUI --> PB
    TERMUI --> ED
    TERMUI --> PAGER
    TERMUI --> URL
    CORE --> TERMUI

    PB --> COMPAT
    PB --> UTILS
    ED --> COMPAT
    ED --> EXC
    PAGER --> COMPAT
    URL --> COMPAT
    GETCHAR --> COMPAT
    COMPAT --> WINCONSOLE
```

---

## Component Relationships

The following diagram shows how the public and private components within the module relate to one another and to their external dependencies.

```mermaid
graph LR
    subgraph "Public API"
        PB["ProgressBar"]
        ED["Editor"]
        PAGER["pager()"]
        URL["open_url()"]
        GETCHAR["getchar()"]
    end

    subgraph "Internal helpers"
        PIPEP["_pipepager()"]
        TMPP["_tempfilepager()"]
        NULLP["_nullpager()"]
        RAW["raw_terminal()"]
        TRANS["_translate_ch_to_exc()"]
    end

    PAGER --> PIPEP
    PAGER --> TMPP
    PAGER --> NULLP
    GETCHAR --> RAW
    GETCHAR --> TRANS
    RAW --> TRANS

    PB -.uses.-> ECHO["echo()"]
    PB -.uses.-> COMPAT["compat helpers"]
    ED -.uses.-> EXC["ClickException"]
    PAGER -.uses.-> COMPAT
    URL -.uses.-> COMPAT
```

---

## ProgressBar

`ProgressBar` is a generic class (`ProgressBar[V]`) that renders a live, updating progress indicator for an iterable or a fixed number of steps. It is designed to be used as a context manager and/or iterated directly.

### Key Responsibilities

- Track progress position (`pos`), total length (`length`), and completion state (`finished`).
- Compute derived metrics: percentage (`pct`), time per iteration (`time_per_iteration`), and estimated time of arrival (`eta`).
- Render a formatted progress line to a text stream, respecting terminal width and TTY detection.
- Support both **iterable mode** (wrap an iterable and yield its items) and **manual mode** (call `update()` explicitly).

### Construction Parameters

| Parameter | Type | Default | Purpose |
|-----------|------|---------|---------|
| `iterable` | `Iterable[V] \| None` | — | Items to iterate over. If `None`, `length` is required. |
| `length` | `int \| None` | `None` | Total number of steps. Inferred via `length_hint` when possible. |
| `fill_char` | `str` | `"#"` | Character used for the filled portion of the bar. |
| `empty_char` | `str` | `" "` | Character used for the empty portion of the bar. |
| `bar_template` | `str` | `"%(bar)s"` | Template for the rendered line (`%(label)s`, `%(bar)s`, `%(info)s`). |
| `info_sep` | `str` | `"  "` | Separator between info bits (pos, percent, ETA, item). |
| `hidden` | `bool` | `False` | Suppress all rendering. |
| `show_eta` | `bool` | `True` | Show estimated time remaining. |
| `show_percent` | `bool \| None` | `None` | Show percentage (auto-derived from `show_pos`). |
| `show_pos` | `bool` | `False` | Show current position / total. |
| `item_show_func` | `Callable[[V \| None], str \| None] \| None` | `None` | Render a description of the current item. |
| `label` | `str \| None` | `None` | Static label prefix. |
| `file` | `TextIO \| None` | `None` | Output stream (defaults to text stdout, or `StringIO`). |
| `color` | `bool \| None` | `None` | Force color on/off. |
| `update_min_steps` | `int` | `1` | Minimum steps before a re-render occurs. |
| `width` | `int` | `30` | Bar width; `0` enables auto-width. |

### Lifecycle and Usage

`ProgressBar` enforces that it is used within a `with` block. Entering the block renders the initial state; exiting renders the finish state.

```mermaid
stateDiagram-v2
    [*] --> Constructed
    Constructed --> Entered: __enter__() -> render_progress()
    Entered --> Iterating: __iter__() / generator()
    Entered --> Updating: update(n_steps)
    Iterating --> Iterating: yield item; update(1)
    Updating --> Updating: make_step() + render_progress()
    Iterating --> Finished: finish() + render_progress()
    Updating --> Finished: finish()
    Finished --> [*]: __exit__() -> render_finish()
```

### Iteration Model

The class supports two iteration interfaces that share a single generator:

- `__iter__()` returns `self.generator()`.
- `__next__()` calls `next(iter(self))`.

The `generator()` method is intentionally a simple generator that does not manage additional state, so that repeated calls to `next(self.generator())` remain safe. When the output is **not** a TTY, the generator simply yields items without rendering. When it **is** a TTY, it renders before each item and calls `update(1)` after each item is processed.

> **Warning:** The iterator interface relies on `generator()` being a stateless simple generator. Any change to `generator()` must be evaluated against both `iter(bar)` and `next(bar)`.

### Rendering Pipeline

Rendering is performed by `render_progress()`, which composes the output line from several formatting helpers:

```mermaid
flowchart TD
    RP["render_progress()"] --> HID{"hidden?"}
    HID -->|yes| STOP["return"]
    HID -->|no| TTY{"isatty(file)?"}
    TTY -->|no| LABEL["echo(label) once"]
    TTY -->|yes| AUTO{"autowidth?"}
    AUTO -->|yes| WIDTH["recompute width from terminal size"]
    AUTO -->|no| FMT
    WIDTH --> FMT["format_progress_line()"]
    FMT --> BAR["format_bar()"]
    FMT --> POS["format_pos()"]
    FMT --> PCT["format_pct()"]
    FMT --> ETA["format_eta()"]
    FMT --> ITEM["item_show_func(current_item)"]
    BAR --> LINE["assemble line + clear padding"]
    POS --> LINE
    PCT --> LINE
    ETA --> LINE
    ITEM --> LINE
    LINE --> DIFF{"line != _last_line?"}
    DIFF -->|yes| WRITE["echo(line, nl=False) + flush"]
    DIFF -->|no| STOP
```

### Formatting Helpers

| Method | Description |
|--------|-------------|
| `format_eta()` | Formats the ETA as `HH:MM:SS` or `Nd HH:MM:SS`. |
| `format_pos()` | Formats `pos` or `pos/length`. |
| `format_pct()` | Formats the percentage, right-aligned to 4 characters. |
| `format_bar()` | Builds the bar string. When length is unknown, renders a "bouncing" indicator using a cosine function. |
| `format_progress_line()` | Assembles the full line from the `bar_template`. |

### Progress Tracking

- `make_step(n_steps)` advances `pos`, marks `finished` when the length is reached, and updates the rolling average (`avg`, capped at 7 samples) used to compute `time_per_iteration` and `eta`. ETA updates are throttled to at most once per second.
- `update(n_steps, current_item=None)` accumulates steps and only triggers a render once `update_min_steps` is reached.
- `finish()` clears ETA state and marks the bar finished.

### Platform-Specific Rendering

The module defines platform-dependent control sequences at import time:

```python
if os.name == "nt":
    BEFORE_BAR = "\r"
    AFTER_BAR = "\n"
else:
    BEFORE_BAR = "\r\033[?25l"   # carriage return + hide cursor
    AFTER_BAR = "\033[?25h\n"    # show cursor + newline
```

On POSIX systems, the cursor is hidden while the bar is active and restored on finish.

---

## Editor

`Editor` launches the user's preferred text editor to edit a block of text, returning the edited content. It is the implementation behind `click.edit()`.

### Construction Parameters

| Parameter | Type | Default | Purpose |
|-----------|------|---------|---------|
| `editor` | `str \| None` | `None` | Explicit editor command; if `None`, auto-detected. |
| `env` | `Mapping[str, str] \| None` | `None` | Extra environment variables for the editor process. |
| `require_save` | `bool` | `True` | If `True`, return `None` when the file was not modified. |
| `extension` | `str` | `".txt"` | Suffix for the temporary file. |

### Editor Detection

`get_editor()` resolves the editor in the following priority order:

```mermaid
flowchart TD
    A["explicit self.editor?"] -->|yes| USE["use it"]
    A -->|no| B["$VISUAL"]
    B -->|set| USE
    B -->|unset| C["$EDITOR"]
    C -->|set| USE
    C -->|unset| D{"Windows?"}
    D -->|yes| NP["notepad"]
    D -->|no| E["sensible-editor / vim / nano (via which)"]
    E -->|found| USE
    E -->|none| VI["vi"]
```

### Editing Flow

```mermaid
sequenceDiagram
    participant Caller
    participant Editor
    participant TempFile as Temp File
    participant Process as Editor Process

    Caller->>Editor: edit(text)
    Editor->>Editor: normalize text (bytes/str, newline handling)
    Editor->>TempFile: mkstemp + write data
    Editor->>TempFile: backdate mtime by 2s (resolution workaround)
    Editor->>Editor: record timestamp
    Editor->>Process: edit_file(name) -> Popen(editor "name")
    Process-->>Editor: exit code
    alt exit code != 0
        Editor-->>Caller: raise ClickException
    end
    Editor->>TempFile: check mtime changed
    alt require_save and unchanged
        Editor-->>Caller: None
    else
        Editor->>TempFile: read content
        Editor-->>Caller: decoded text (or bytes)
    end
    Editor->>TempFile: unlink
```

### Text Normalization

`edit()` handles both `str` and `bytes` inputs:

- Empty/`None` input becomes empty bytes.
- `bytes`/`bytearray` input is written verbatim and returned as bytes.
- `str` input gets a trailing newline if missing; on Windows it is converted to CRLF and encoded as `utf-8-sig`; otherwise encoded as `utf-8`.
- On read-back, `utf-8-sig` decoding and CRLF→LF normalization are applied.

### Filesystem Resolution Workaround

Because some filesystems (e.g., macOS 10.12 Extended, FAT32) have coarse mtime resolution, the file's modification time is backdated by 2 seconds before editing. This ensures `require_save` detection works even when the editor closes very quickly.

### Error Handling

`edit_file()` raises a `ClickException` (from [`exceptions`](exceptions.md)) when the editor exits with a non-zero code or when the process cannot be started (`OSError`).

---

## Paging Support

The `pager()` function selects an appropriate paging strategy based on the environment and delegates to one of three internal implementations.

```mermaid
flowchart TD
    START["pager(generator, color)"] --> TTY{"stdin & stdout are TTYs?"}
    TTY -->|no| NULL["_nullpager()"]
    TTY -->|yes| PAGERENV{"$PAGER set?"}
    PAGERENV -->|yes| WIN1{"Windows?"}
    WIN1 -->|yes| TMP["_tempfilepager()"]
    WIN1 -->|no| PIPE["_pipepager()"]
    PAGERENV -->|no| TERM{"$TERM in dumb/emacs?"}
    TERM -->|yes| NULL
    TERM -->|no| WIN2{"Windows / OS2?"}
    WIN2 -->|yes| TMP2["_tempfilepager('more <')"]
    WIN2 -->|no| LESS{"less available?"}
    LESS -->|yes| PIPE2["_pipepager('less')"]
    LESS -->|no| MORE{"more available?"}
    MORE -->|yes| PIPE3["_pipepager('more')"]
    MORE -->|no| NULL
```

| Function | Strategy |
|----------|----------|
| `_pipepager` | Pipes text to an external pager process (e.g., `less`, `more`) via `subprocess.Popen`. Handles color support for `less` via the `LESS` environment variable. |
| `_tempfilepager` | Writes text to a temporary file and invokes a program on it via `os.system`. |
| `_nullpager` | Ultimate fallback: writes text directly to the stream. |

> **Note:** `_pipepager` includes special handling for `less` not respecting `^C`, looping on `c.wait()` until the process exits cleanly.

---

## URL Opening

`open_url(url, wait=False, locate=False)` opens a URL or file using the platform's native mechanism:

| Platform | Mechanism |
|----------|-----------|
| macOS (`darwin`) | `open` (with `-W` for wait, `-R` for locate) |
| Windows | `explorer /select,` for locate, otherwise `start` |
| Cygwin | `cygstart` |
| Other (Linux) | `xdg-open`, falling back to `webbrowser.open` for HTTP(S) URLs |

Returns the process exit code (or `0`/`1` on fallback paths).

---

## Raw Terminal Input

The module provides cross-platform raw character input used by interactive prompts.

### `getchar(echo)`

Reads a single character from the terminal, optionally echoing it.

- **Windows:** Uses `msvcrt.getwch`/`getwche`. Handles special-key prefixes (`\x00`, `\xe0`) by reading a second character.
- **POSIX:** Uses `raw_terminal()` to put the terminal in raw mode, then reads via `os.read`.

### `raw_terminal()`

A context manager that yields a file descriptor in raw mode.

- **Windows:** A no-op that yields `-1`.
- **POSIX:** Saves `termios` settings, sets the terminal to raw mode via `tty.setraw`, and restores settings on exit. Falls back to `/dev/tty` when stdin is not a TTY.

### `_translate_ch_to_exc(ch)`

Translates control characters into exceptions:

| Character | Platform | Exception |
|-----------|----------|-----------|
| `\x03` (Ctrl+C) | all | `KeyboardInterrupt` |
| `\x04` (Ctrl+D) | POSIX | `EOFError` |
| `\x1a` (Ctrl+Z) | Windows | `EOFError` |

---

## Dependencies

The module depends on the following components from other modules:

| Dependency | Source Module | Usage |
|------------|---------------|-------|
| `_default_text_stdout` | [`compat`](compat.md) | Default output stream for `ProgressBar` and `pager`. |
| `CYGWIN`, `WIN` | [`compat`](compat.md) | Platform detection for control sequences and URL opening. |
| `get_best_encoding` | [`compat`](compat.md) | Encoding selection for pager pipes and raw input. |
| `isatty` | [`compat`](compat.md) | TTY detection for rendering and paging decisions. |
| `open_stream` | [`compat`](compat.md) | Writing to temporary files in `_tempfilepager`. |
| `strip_ansi` | [`compat`](compat.md) | Removing ANSI codes when color is disabled. |
| `term_len` | [`compat`](compat.md) | Measuring visible line length for width calculations. |
| `echo` | [`utils`](utils.md) | Writing rendered progress lines to the output stream. |
| `ClickException` | [`exceptions`](exceptions.md) | Raised on editor failures. |

---

## Data Flow

The following diagram illustrates the data flow for the two primary use cases.

```mermaid
flowchart LR
    subgraph "ProgressBar flow"
        ITEMS["Iterable[V]"] --> PB["ProgressBar"]
        PB --> GEN["generator()"]
        GEN --> YIELD["yield item"]
        GEN --> UPD["update(1)"]
        UPD --> STEP["make_step()"]
        STEP --> RENDER["render_progress()"]
        RENDER --> ECHO["echo() -> file"]
    end

    subgraph "Editor flow"
        TEXT["text (str/bytes)"] --> ED["Editor.edit()"]
        ED --> TMP["temp file"]
        TMP --> PROC["editor process"]
        PROC --> READ["read back"]
        READ --> RESULT["edited text / None"]
    end
```

---

## Summary

The `termui_impl` module is a self-contained implementation layer for Click's terminal UI features. Its design goals are:

1. **Lazy loading** — kept separate from the main import path to minimize import time.
2. **Platform abstraction** — delegates all platform-specific behavior to [`compat`](compat.md).
3. **Robust rendering** — handles TTY vs. non-TTY output, terminal resizing, and ANSI stripping.
4. **Safe iteration** — the `ProgressBar` iterator interface is carefully designed to be re-entrant.

For details on the platform abstraction helpers used here, see [`compat`](compat.md). For the output helper, see [`utils`](utils.md). For the exception types raised, see [`exceptions`](exceptions.md).
