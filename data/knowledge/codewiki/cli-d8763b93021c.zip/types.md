# Types Module

## Introduction

The `types` module (`src/click/types.py`) defines the **parameter type system** for Click. A parameter type is responsible for validating and converting raw values (typically strings coming from the command line, environment variables, or prompts) into the correct Python type expected by a command.

Every `Parameter` (an `Option` or `Argument`) is associated with a `ParamType` instance. When Click parses input, it delegates the conversion and validation of each value to that type. This module provides:

- The abstract base class `ParamType` that all types derive from.
- A rich set of built-in types (`STRING`, `INT`, `FLOAT`, `BOOL`, `UUID`, `Choice`, `DateTime`, `File`, `Path`, `Tuple`, ranges, etc.).
- The `convert_type` factory that maps Python types to the appropriate `ParamType`.
- Support for shell completion via `shell_complete`.

This module sits at the heart of the `cli_engine` module group and is consumed primarily by the [core module](core.md) (parameters) and the [shell_completion module](shell_completion.md).

---

## Architecture Overview

The type system is organized around a single abstract base class with several layers of specialization.

```mermaid
classDiagram
    class ParamType {
        <<abstract>>
        +name: str
        +is_composite: bool
        +arity: int
        +envvar_list_splitter
        +__call__(value, param, ctx)
        +convert(value, param, ctx)
        +get_metavar(param)
        +get_missing_message(param)
        +split_envvar_value(rv)
        +fail(message, param, ctx)
        +shell_complete(ctx, param, incomplete)
        +to_info_dict()
    }

    class CompositeParamType {
        +is_composite = True
        +arity
    }

    class FuncParamType {
        +func
        +convert()
    }

    class UnprocessedParamType
    class StringParamType
    class Choice {
        +choices
        +case_sensitive
    }
    class DateTime {
        +formats
    }
    class _NumberParamTypeBase {
        +_number_class
    }
    class _NumberRangeBase {
        +min, max
        +min_open, max_open
        +clamp
    }
    class IntParamType
    class IntRange
    class FloatParamType
    class FloatRange
    class BoolParamType
    class UUIDParameterType
    class File {
        +mode, encoding
        +lazy, atomic
    }
    class Path {
        +exists, file_okay, dir_okay
    }
    class Tuple {
        +types
    }

    ParamType <|-- CompositeParamType
    ParamType <|-- FuncParamType
    ParamType <|-- UnprocessedParamType
    ParamType <|-- StringParamType
    ParamType <|-- Choice
    ParamType <|-- DateTime
    ParamType <|-- _NumberParamTypeBase
    ParamType <|-- BoolParamType
    ParamType <|-- UUIDParameterType
    ParamType <|-- File
    ParamType <|-- Path
    CompositeParamType <|-- Tuple
    _NumberParamTypeBase <|-- _NumberRangeBase
    _NumberParamTypeBase <|-- IntParamType
    _NumberParamTypeBase <|-- FloatParamType
    _NumberRangeBase <|-- IntRange
    _NumberRangeBase <|-- FloatRange
    IntParamType <|-- IntRange
    FloatParamType <|-- FloatRange
```

### Type Categories

| Category | Types | Purpose |
|----------|-------|---------|
| Scalar primitives | `StringParamType`, `IntParamType`, `FloatParamType`, `BoolParamType`, `UUIDParameterType` | Convert simple string values to Python scalars |
| Constrained | `Choice`, `IntRange`, `FloatRange`, `DateTime` | Validate against a set of allowed values or formats |
| Filesystem | `File`, `Path` | Open files or validate filesystem paths |
| Composite | `Tuple` | Apply different types to fixed-position items |
| Special | `UnprocessedParamType`, `FuncParamType` | Pass-through values or wrap arbitrary callables |

---

## Core Base Class: `ParamType`

`ParamType` is the abstract base for all parameter types. Custom types must subclass it and implement at least `convert`, and set the `name` class attribute.

### Key Class Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `name` | `str` | Descriptive name of the type (e.g. `"integer"`). |
| `is_composite` | `bool` | Whether the type consumes multiple values (default `False`). |
| `arity` | `int` | Number of values the type consumes (default `1`). |
| `envvar_list_splitter` | `str \| None` | Splitter used when a list value comes from an environment variable. `None` means whitespace. |

### Key Methods

- **`__call__(value, param, ctx)`** — Entry point. Returns `None` for `None` input, otherwise delegates to `convert`.
- **`convert(value, param, ctx)`** — The core conversion/validation hook. Must accept strings, already-converted values, and be callable with `param`/`ctx` set to `None` (e.g. during prompt input).
- **`get_metavar(param)`** — Returns the metavar shown in help text (e.g. `[a|b|c]`).
- **`get_missing_message(param)`** — Optional extra info shown when a value is missing.
- **`split_envvar_value(rv)`** — Splits an environment variable value using `envvar_list_splitter`.
- **`fail(message, param, ctx)`** — Raises a `BadParameter` exception (see [exceptions module](exceptions.md)).
- **`shell_complete(ctx, param, incomplete)`** — Returns a list of `CompletionItem` objects for shell completion (see [shell_completion module](shell_completion.md)).
- **`to_info_dict()`** — Produces a serializable dict for documentation tooling.

### Conversion Flow

```mermaid
flowchart TD
    A[Raw value from CLI / envvar / prompt] --> B{value is None?}
    B -- Yes --> C[Return None]
    B -- No --> D[ParamType.__call__]
    D --> E[ParamType.convert]
    E --> F{Valid?}
    F -- Yes --> G[Return converted value]
    F -- No --> H[fail]
    H --> I[Raise BadParameter]
```

---

## Built-in Types

### Scalar Types

#### `StringParamType` (`STRING`)
The implicit default type. Decodes `bytes` using the argv encoding, falling back to the filesystem encoding and finally UTF-8 with replacement. Non-bytes values are coerced with `str()`.

#### `IntParamType` (`INT`) and `FloatParamType` (`FLOAT`)
Both derive from `_NumberParamTypeBase`, which simply calls the configured `_number_class` (`int` or `float`) on the value and fails with a descriptive message on `ValueError`.

#### `BoolParamType` (`BOOL`)
Accepts Python booleans directly, and normalizes strings. Truthy tokens: `1, true, t, yes, y, on`. Falsy tokens: `0, false, f, no, n, off`.

#### `UUIDParameterType` (`UUID`)
Returns `uuid.UUID` instances, accepting either an existing `UUID` or a string.

#### `UnprocessedParamType` (`UNPROCESSED`)
A pass-through type that performs no conversion. Useful for values that may legitimately be `bytes` or `str` (e.g. file paths).

### Constrained Types

#### `Choice`
Validates a value against a fixed sequence of string choices. Supports:
- `case_sensitive` matching (default `True`).
- Interaction with `ctx.token_normalize_func` for normalization.
- Custom metavar generation (`{a|b|c}` for required arguments, `[a|b|c]` for options).
- Shell completion of matching choices.

The returned value is always one of the originally supplied choices.

#### `DateTime`
Parses date strings into `datetime` objects using an ordered list of `strptime` formats. Defaults to `%Y-%m-%d`, `%Y-%m-%dT%H:%M:%S`, and `%Y-%m-%d %H:%M:%S`. The first format that parses successfully wins.

#### `_NumberRangeBase`, `IntRange`, `FloatRange`
Restrict numeric values to a range. Configuration:
- `min` / `max` — bounds (either may be `None`).
- `min_open` / `max_open` — exclude the boundary.
- `clamp` — clamp out-of-range values to the boundary instead of failing.

`FloatRange` explicitly rejects combining `clamp` with open bounds. `_describe_range()` produces human-readable range descriptions for help text.

### Filesystem Types

#### `File`
Declares a parameter as a file for reading or writing. Key behaviors:
- The special value `-` maps to stdin/stdout depending on mode.
- `lazy` controls whether the file is opened immediately or on first IO (defaults to lazy for write modes).
- `atomic` writes go to a temporary file that is moved into place on close.
- Files are automatically closed (or flushed) when the `Context` tears down via `ctx.call_on_close`.
- Uses `LazyFile` and `open_stream` from the [utils module](utils.md) and [compat module](compat.md).
- `envvar_list_splitter` is `os.path.pathsep`.

#### `Path`
Similar to `File` but returns the filename rather than an open file. Validation options include `exists`, `file_okay`, `dir_okay`, `readable`, `writable`, `executable`, `resolve_path`, `allow_dash`, and `path_type` (e.g. `pathlib.Path`). The `name` attribute is dynamically set to `"file"`, `"directory"`, or `"path"` based on the allowed kinds.

### Composite Types

#### `CompositeParamType`
Base class for types that consume multiple values. Sets `is_composite = True` and requires subclasses to implement `arity`.

#### `Tuple`
Applies a distinct type to each item of a fixed-length value (requires `nargs` to be a fixed count). Validates the number of items and converts each element with its corresponding type. Its `name` is derived from the joined child type names, and `arity` equals the number of child types.

### Special Types

#### `FuncParamType`
Wraps an arbitrary callable as a type. The callable's `__name__` becomes the type name. On `ValueError`, the value is stringified and `fail` is called.

---

## The `convert_type` Factory

`convert_type(ty, default=None)` maps a Python type (or a default value) to the most appropriate `ParamType` instance.

```mermaid
flowchart TD
    A[convert_type ty, default] --> B{ty is None and default given?}
    B -- Yes --> C[Infer ty from default]
    B -- No --> D{ty is tuple?}
    C --> D
    D -- Yes --> E[Return Tuple]
    D -- No --> F{ty is ParamType instance?}
    F -- Yes --> G[Return ty]
    F -- No --> H{ty is str/None?}
    H -- Yes --> I[Return STRING]
    H -- No --> J{ty is int?}
    J -- Yes --> K[Return INT]
    J -- No --> L{ty is float?}
    L -- Yes --> M[Return FLOAT]
    L -- No --> N{ty is bool?}
    N -- Yes --> O[Return BOOL]
    N -- No --> P{guessed_type?}
    P -- Yes --> Q[Return STRING]
    P -- No --> R[Return FuncParamType ty]
```

When a default value is provided without an explicit type, the type is inferred from the default's Python type. Lists/tuples of defaults infer element types, and nested tuples produce a `Tuple` type.

---

## Module-Level Type Instances

The module exposes pre-instantiated singletons used throughout Click:

| Constant | Instance | Notes |
|----------|----------|-------|
| `UNPROCESSED` | `UnprocessedParamType()` | No conversion |
| `STRING` | `StringParamType()` | Default type |
| `INT` | `IntParamType()` | Integer |
| `FLOAT` | `FloatParamType()` | Float |
| `BOOL` | `BoolParamType()` | Boolean flags |
| `UUID` | `UUIDParameterType()` | UUID |

---

## `OptionHelpExtra`

`OptionHelpExtra` is a `TypedDict` (with `total=False`) describing optional extra fields used when rendering option help text:

| Key | Type | Description |
|-----|------|-------------|
| `envvars` | `tuple[str, ...]` | Environment variables that can supply the value |
| `default` | `str` | Default value shown in help |
| `range` | `str` | Range description (from `_describe_range`) |
| `required` | `str` | Required marker text |

---

## Dependencies

```mermaid
flowchart LR
    subgraph types[types module]
        PT[ParamType]
        CT[convert_type]
    end

    subgraph core[core module]
        PARAM[Parameter]
        CTX[Context]
    end

    subgraph exceptions[exceptions module]
        BP[BadParameter]
    end

    subgraph utils[utils module]
        LF[LazyFile]
        FF[format_filename]
        SC[safecall]
    end

    subgraph compat[compat module]
        OS[open_stream]
        GAE[_get_argv_encoding]
    end

    subgraph shell[shell_completion module]
        CI[CompletionItem]
    end

    PARAM --> PT
    CTX --> PT
    PT --> BP
    PT --> LF
    PT --> FF
    PT --> SC
    PT --> OS
    PT --> GAE
    PT --> CI
    CT --> PT
```

### Inbound Dependencies (who uses types)

- **[core module](core.md)** — `Parameter`, `Option`, and `Argument` hold a `ParamType` and invoke it during parsing. `Context` provides `token_normalize_func` and `call_on_close` used by `Choice` and `File`.
- **[shell_completion module](shell_completion.md)** — Consumes `CompletionItem` returned by `shell_complete`.

### Outbound Dependencies (what types uses)

- **[exceptions module](exceptions.md)** — `BadParameter` is raised by `ParamType.fail`.
- **[utils module](utils.md)** — `LazyFile`, `format_filename`, and `safecall` support the `File` type.
- **[compat module](compat.md)** — `open_stream` and `_get_argv_encoding` handle stream opening and encoding detection.

---

## Extension Points

To implement a custom type:

1. Subclass `ParamType`.
2. Set the `name` class attribute.
3. Implement `convert(value, param, ctx)` — accept strings, already-converted values, and handle `param`/`ctx` being `None`.
4. Optionally override `get_metavar`, `get_missing_message`, `shell_complete`, and `to_info_dict`.

For types that consume multiple values, subclass `CompositeParamType` and implement `arity`.

```python
class EvenInt(ParamType):
    name = "even integer"

    def convert(self, value, param, ctx):
        try:
            value = int(value)
        except ValueError:
            self.fail(f"{value!r} is not an integer.", param, ctx)
        if value % 2 != 0:
            self.fail(f"{value!r} is not even.", param, ctx)
        return value
```

---

## Related Documentation

- [core module](core.md) — Parameters, options, arguments, and context that use these types.
- [exceptions module](exceptions.md) — `BadParameter` and the error hierarchy raised by `fail`.
- [utils module](utils.md) — `LazyFile` and helpers used by the `File` type.
- [compat module](compat.md) — `open_stream` and encoding utilities.
- [shell_completion module](shell_completion.md) — `CompletionItem` and completion integration.
