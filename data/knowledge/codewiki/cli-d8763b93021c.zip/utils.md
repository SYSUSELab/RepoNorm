# Utils Module

## Introduction

The `utils` module (`src/click/utils.py`) provides a collection of low-level utility
functions and helper classes that form the foundation of Click's I/O, file handling,
and text-processing behavior. It sits within the **terminal_and_platform_foundation**
layer of Click and is responsible for:

- **Safe file handling** — lazy opening, atomic writes, and standard-stream protection.
- **Cross-platform output** — the `echo()` function that normalizes printing across
  Linux, macOS, and Windows consoles.
- **Stream access** — helpers to obtain binary and text standard streams.
- **Filename and path formatting** — display-safe filename rendering and
  platform-appropriate config directory resolution.
- **Argument expansion** — simulating Unix shell globbing/expansion on Windows.
- **Broken-pipe resilience** — suppressing `BrokenPipeError` during interpreter shutdown.

This module is a *foundation* dependency: higher-level modules such as
[core](core.md), [types](types.md), and [termui_impl](termui_impl.md) build upon the
primitives defined here. It in turn depends heavily on the
[compat](compat.md) module for platform-specific stream and ANSI handling.

---

## Architecture Overview

The module is organized into three functional groups: **file wrappers**, **stream &
output helpers**, and **path/argument utilities**.

```mermaid
graph TD
    subgraph "utils.py"
        LF[LazyFile]
        KOF[KeepOpenFile]
        PFW[PacifyFlushWrapper]
        ECHO[echo]
        GBS[get_binary_stream]
        GTS[get_text_stream]
        OF[open_file]
        FF[format_filename]
        GAD[get_app_dir]
        MDSH[make_default_short_help]
        MS[make_str]
        SC[safecall]
        POS[_posixify]
        DPN[_detect_program_name]
        EA[_expand_args]
    end

    subgraph "compat.py"
        OS[open_stream]
        AF[_AtomicFile]
        DTS[_default_text_stdout]
        DTSE[_default_text_stderr]
        FBW[_find_binary_writer]
        AWFA[auto_wrap_for_ansi]
        BS[binary_streams]
        TS[text_streams]
        SSA[should_strip_ansi]
        SA[strip_ansi]
        WIN[WIN]
    end

    subgraph "globals.py"
        RCD[resolve_color_default]
    end

    LF --> OS
    OF --> LF
    OF --> OS
    OF --> KOF
    OS --> AF
    ECHO --> DTS
    ECHO --> DTSE
    ECHO --> FBW
    ECHO --> AWFA
    ECHO --> SSA
    ECHO --> SA
    ECHO --> RCD
    GBS --> BS
    GTS --> TS
    GAD --> WIN
    GAD --> POS
```

---

## Core Components

### File Wrappers

These classes provide controlled, safe access to files and streams. They are the
building blocks used by `open_file()` and, transitively, by the
[`File` param type](types.md).

#### `LazyFile`

A file-like object that defers the actual opening of the file until it is first
accessed, while still performing early validation to catch obvious errors.

| Attribute / Method | Description |
| --- | --- |
| `__init__(filename, mode, encoding, errors, atomic)` | Stores configuration; for read modes, opens and immediately closes the file to surface access errors early. |
| `open()` | Opens the file on first access. Raises `FileError` (from [exceptions](exceptions.md)) on `OSError`. |
| `close()` | Closes the underlying file unconditionally. |
| `close_intelligently()` | Closes only if the wrapper opened the file (never closes `stdin`). |
| `__getattr__` | Proxies all other attribute access to the opened file. |
| `__enter__` / `__exit__` | Context-manager support; `__exit__` calls `close_intelligently()`. |
| `__iter__` | Opens the file and iterates over its lines. |

**Key behavior:** When `filename == "-"`, the file is opened immediately via
`open_stream()` and `should_close` is set based on whether it is a standard stream.
For non-`-` filenames in read mode, the file is opened and closed once to validate
access, then left unopened until `open()` is called.

#### `KeepOpenFile`

A transparent proxy that prevents a wrapped file (typically a standard stream) from
being closed when used as a context manager.

| Method | Description |
| --- | --- |
| `__getattr__` | Proxies all attribute access to the wrapped file. |
| `__enter__` | Returns `self`. |
| `__exit__` | **No-op** — deliberately does not close the file. |
| `__iter__` | Iterates over the wrapped file. |

This is used by `open_file()` when `open_stream()` reports that the stream should
*not* be closed (e.g., `stdout`/`stdin`).

#### `PacifyFlushWrapper`

A wrapper that catches and suppresses `BrokenPipeError` (specifically `errno.EPIPE`)
raised during `.flush()`. This is critical because Python always calls `.flush()` on
`sys.stdout` and `sys.stderr` during interpreter shutdown/final-GC, and a broken pipe
at that point would otherwise produce a spurious traceback.

| Method | Description |
| --- | --- |
| `flush()` | Calls `wrapped.flush()`, swallowing `OSError` with `errno == EPIPE`. |
| `__getattr__` | Proxies all other attributes to the wrapped stream. |

---

### Stream & Output Helpers

#### `echo(message, file, nl, err, color)`

The central output function of Click. It is the recommended replacement for
`print()` because it normalizes behavior across platforms and stream types.

**Capabilities:**

- Ensures correct output encoding on Linux.
- Supports Unicode on the Windows console.
- Writes to binary outputs and supports writing bytes to text outputs.
- Supports colors/styles on Windows (via `auto_wrap_for_ansi`).
- Strips ANSI codes when output is not an interactive terminal.
- Always flushes the output.

**Processing flow:**

```mermaid
flowchart TD
    A[echo called] --> B{file is None?}
    B -- yes --> C{err?}
    C -- yes --> D[file = _default_text_stderr]
    C -- no --> E[file = _default_text_stdout]
    D --> F{file is None?}
    E --> F
    F -- yes --> G[return - no stream]
    F -- no --> H[continue]
    B -- no --> H
    H --> I[Convert message to str/bytes]
    I --> J{nl?}
    J -- yes --> K[Append newline]
    J -- no --> L[skip]
    K --> M{out empty?}
    L --> M
    M -- yes --> N[file.flush; return]
    M -- no --> O{out is bytes?}
    O -- yes --> P[Find binary writer]
    P --> Q{binary_file found?}
    Q -- yes --> R[flush + write bytes + flush]
    Q -- no --> S[fall through]
    O -- no --> T[resolve_color_default]
    T --> U{should_strip_ansi?}
    U -- yes --> V[strip_ansi]
    U -- no --> W{WIN?}
    W -- yes --> X[auto_wrap_for_ansi or strip]
    W -- no --> Y[skip]
    V --> Z[file.write + flush]
    X --> Z
    Y --> Z
    S --> Z
```

#### `get_binary_stream(name)`

Returns a system binary stream (`stdin`, `stdout`, or `stderr`) by looking up the
opener in `binary_streams` (from [compat](compat.md)). Raises `TypeError` for unknown
names.

#### `get_text_stream(name, encoding, errors)`

Returns a system text stream, optionally overriding `encoding` and `errors`. Looks up
the opener in `text_streams` (from [compat](compat.md)). Raises `TypeError` for
unknown names.

#### `open_file(filename, mode, encoding, errors, lazy, atomic)`

A high-level file opener that combines the behaviors of the
[`File` param type](types.md):

- `'-'` maps to `stdin`/`stdout` and is wrapped in `KeepOpenFile` so context-manager
  usage does not close the standard stream.
- `lazy=True` returns a `LazyFile`.
- `atomic=True` writes to a temporary file and replaces the target on close (via
  `open_stream` → `_AtomicFile`).

```mermaid
flowchart LR
    A[open_file] --> B{lazy?}
    B -- yes --> C[return LazyFile]
    B -- no --> D[open_stream]
    D --> E{should_close?}
    E -- no --> F[wrap in KeepOpenFile]
    E -- yes --> G[return raw file]
    F --> H[return]
    G --> H
```

---

### Path & Argument Utilities

#### `format_filename(filename, shorten)`

Formats a filename for display, replacing invalid bytes or surrogate escapes with the
replacement character `�`. This prevents errors when writing to streams opened with
`errors="strict"`. Optionally shortens the path to its basename.

#### `get_app_dir(app_name, roaming, force_posix)`

Returns the platform-appropriate configuration directory for an application.

| Platform | Result |
| --- | --- |
| Windows (roaming) | `%APPDATA%\<app_name>` |
| Windows (not roaming) | `%LOCALAPPDATA%\<app_name>` |
| macOS | `~/Library/Application Support/<app_name>` |
| Unix | `$XDG_CONFIG_HOME/<posixified>` or `~/.config/<posixified>` |
| POSIX forced | `~/.<posixified>` |

The `_posixify()` helper converts a name to lowercase dash-separated form.

#### `_detect_program_name(path, _main)`

Determines the command used to run the program for help text. Returns the file name
for executed files, or `python -m <module>` for module execution. *(Private API.)*

#### `_expand_args(args, user, env, glob_recursive)`

Simulates Unix shell expansion (glob, `~`, environment variables) using Python
functions. Intended for Windows where the shell performs no expansion. Invalid glob
patterns are treated as empty expansions. *(Private API.)*

---

### Text & General Helpers

| Function | Purpose |
| --- | --- |
| `safecall(func)` | Wraps a function so it swallows all exceptions, returning `None` on failure. |
| `make_str(value)` | Converts any value to a valid string; decodes bytes using the filesystem encoding with UTF-8 fallback. |
| `make_default_short_help(help, max_length)` | Produces a condensed one-line summary of a help string, respecting sentence boundaries and a max length. |
| `_posixify(name)` | Converts a name to lowercase dash-separated form. *(Private.)* |

---

## Component Interaction

The following diagram shows how the utils module's components interact with each other
and with external modules during a typical file-output operation.

```mermaid
sequenceDiagram
    participant Caller
    participant open_file
    participant LazyFile
    participant open_stream as compat.open_stream
    participant AtomicFile as compat._AtomicFile
    participant KeepOpenFile

    Caller->>open_file: open_file("out.txt", "w", atomic=True)
    open_file->>open_stream: open_stream(..., atomic=True)
    open_stream->>AtomicFile: wrap temp file
    open_stream-->>open_file: (af, should_close=True)
    open_file-->>Caller: af

    Caller->>open_file: open_file("-", "w")
    open_file->>open_stream: open_stream("-", "w")
    open_stream-->>open_file: (stdout, should_close=False)
    open_file->>KeepOpenFile: wrap(stdout)
    open_file-->>Caller: KeepOpenFile
```

---

## Dependencies

### Internal Dependencies

| Module | Used For |
| --- | --- |
| [compat](compat.md) | `open_stream`, `_AtomicFile`, default streams, ANSI handling, binary/text stream registries, `WIN` flag. |
| [globals](globals.md) | `resolve_color_default` for the `echo()` color parameter. |
| [exceptions](exceptions.md) | `FileError` raised by `LazyFile.open()`. |

### Dependents

| Module | How it uses utils |
| --- | --- |
| [core](core.md) | Uses `echo`, `open_file`, `format_filename`, `PacifyFlushWrapper`, `_detect_program_name`, `_expand_args`. |
| [types](types.md) | The `File` param type delegates to `open_file`/`LazyFile`. |
| [termui_impl](termui_impl.md) | Uses stream helpers and `echo` for terminal UI output. |
| [testing](testing.md) | Relies on stream wrappers for capturing output. |

```mermaid
graph LR
    compat --> utils
    globals --> utils
    exceptions --> utils
    utils --> core
    utils --> types
    utils --> termui_impl
    utils --> testing
```

---

## Design Notes

- **Lazy vs. eager opening:** `LazyFile` balances early error detection (opening read
  files once to validate) against deferred resource acquisition (keeping write files
  closed until needed).
- **Standard-stream safety:** Both `KeepOpenFile` and `LazyFile.close_intelligently()`
  exist to prevent accidental closing of `stdin`/`stdout`/`stderr`.
- **Atomic writes:** Delegated to `compat.open_stream` and `compat._AtomicFile`, which
  write to a temporary file and `os.replace()` it on close. Appending and exclusive
  modes are explicitly rejected for atomic writes.
- **Broken-pipe resilience:** `PacifyFlushWrapper` is essential for clean shutdowns in
  pipelines (e.g., `click-app | head`).
- **Cross-platform output:** `echo()` centralizes all the platform quirks (Windows
  console Unicode, ANSI stripping, binary writers) so the rest of Click can call a
  single function.

---

## Related Documentation

- [compat](compat.md) — platform compatibility layer (streams, ANSI, atomic files).
- [core](core.md) — the command/context framework that consumes these utilities.
- [types](types.md) — parameter types including `File`, which builds on `open_file`.
- [exceptions](exceptions.md) — `FileError` and other Click exceptions.
- [globals](globals.md) — context and color-default resolution.
- [termui_impl](termui_impl.md) — terminal UI components (progress bars, editors).
- [testing](testing.md) — test runner and stream capture utilities.
