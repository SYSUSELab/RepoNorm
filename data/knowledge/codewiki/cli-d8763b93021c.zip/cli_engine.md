# `cli_engine` Module Overview

## Purpose

The `cli_engine` module (located at `src/click/`) is the heart of the Click command-line framework. It provides the machinery that turns decorated Python functions into fully-featured command-line interfaces: parsing raw `sys.argv` tokens, resolving commands and subcommands, validating and converting parameter values, invoking callbacks, and rendering help/usage output.

Its responsibilities can be summarized as:

- **Command modeling** — representing commands, groups, parameters, options, and arguments as objects (`core`).
- **Argument parsing** — tokenizing and interpreting the command line against the declared parameter set (`parser`).
- **Type conversion & validation** — coercing raw strings into Python values and validating them (`types`).
- **Error handling** — producing user-friendly, formatted error messages and exit codes (`exceptions`).
- **Help & usage rendering** — laying out and wrapping help text consistently (`formatting`).

Together these components form the "engine" that drives every Click application, independent of the terminal/platform layer (`terminal_and_platform_foundation`), shell completion (`shell_completion`), and testing utilities (`testing`).

## Architecture

The module is organized around a central command/parameter model that delegates parsing, type conversion, error reporting, and output formatting to specialized submodules.

```mermaid
graph TD
    subgraph cli_engine["cli_engine (src/click)"]
        CORE["core.py<br/>Command, Group, Parameter,<br/>Option, Argument, Context"]
        PARSER["parser.py<br/>OptionParser, Argument,<br/>ParsingState"]
        TYPES["types.py<br/>ParamType, STRING, INT,<br/>Choice, Path, etc."]
        EXC["exceptions.py<br/>ClickException, UsageError,<br/>BadParameter, Abort"]
        FMT["formatting.py<br/>HelpFormatter,<br/>wrap_text, measure_table"]
    end

    CORE -->|"delegates token parsing"| PARSER
    CORE -->|"converts & validates values"| TYPES
    CORE -->|"raises / formats errors"| EXC
    CORE -->|"renders help & usage"| FMT
    PARSER -->|"reports parse failures"| EXC
    TYPES -->|"reports conversion failures"| EXC
    EXC -->|"uses layout helpers"| FMT
```

### Data / control flow

```mermaid
sequenceDiagram
    participant User
    participant Core as core.Command
    participant Parser as parser.OptionParser
    participant Types as types.ParamType
    participant Fmt as formatting.HelpFormatter
    participant Exc as exceptions

    User->>Core: invoke(args)
    Core->>Parser: parse_args(args)
    Parser-->>Core: opts, args, order
    Core->>Types: convert(value, param, ctx)
    alt conversion fails
        Types-->>Exc: raise BadParameter
        Exc->>Fmt: format_message()
        Fmt-->>User: error output
    else success
        Types-->>Core: typed value
        Core->>Core: run callback
    end
    Core->>Fmt: format_help() / format_usage()
    Fmt-->>User: help text
```

## Core Components

The following submodules make up the `cli_engine` and are documented individually:

- **[core](./core.md)** — The central object model: `Command`, `Group`, `MultiCommand`, `Parameter`, `Option`, `Argument`, and `Context`. Defines how commands are declared, how parameters are attached, and how invocation, help, and usage are orchestrated.
- **[parser](./parser.md)** — The low-level command-line tokenizer and parser (`OptionParser`, `Argument`, `ParsingState`). Handles option/argument matching, prefix handling, and interspersed arguments.
- **[types](./types.md)** — The `ParamType` hierarchy and built-in types (`STRING`, `INT`, `FLOAT`, `BOOL`, `Choice`, `Path`, `File`, `DateTime`, etc.) responsible for converting and validating raw string values.
- **[exceptions](./exceptions.md)** — The exception hierarchy (`ClickException`, `UsageError`, `BadParameter`, `MissingParameter`, `Abort`, `Exit`) used to signal and format user-facing errors.
- **[formatting](./formatting.md)** — Help and usage text layout utilities (`HelpFormatter`, `wrap_text`, `measure_table`, `join_options`) that produce consistently wrapped, aligned output.

## Related Modules (outside `cli_engine`)

These modules are documented separately and provide supporting infrastructure:

- **`terminal_and_platform_foundation`** — `_compat`, `_winconsole`, `_termui_impl`, `_textwrap`, `utils`: cross-platform terminal I/O, ANSI handling, pager/editor integration, and text utilities.
- **`shell_completion`** — `shell_completion.py`: generation of Bash/Zsh/Fish completion scripts.
- **`testing`** — `testing.py`: `CliRunner` and helpers for testing Click applications.