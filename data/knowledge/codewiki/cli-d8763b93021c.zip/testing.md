# Testing Module

## Introduction

The `testing` module (`src/click/testing.py`) provides the infrastructure needed to invoke Click command-line applications in an **isolated, deterministic environment** for unit testing purposes. It is the backbone of Click's own test suite and is the recommended way for downstream applications to test their CLI behavior.

The module's central abstraction is the [`CliRunner`](#clirunner), which temporarily replaces global interpreter state (`sys.stdin`, `sys.stdout`, `sys.stderr`, `os.environ`, and several Click internals) so that a command can be executed as if it were a real terminal invocation — without touching the actual terminal. The captured output, exit code, return value, and any exception are wrapped in a [`Result`](#result) object for assertions.

> **Note:** Because the runner mutates global interpreter state, it only works in **single-threaded** systems without concurrency.

---

## Architecture Overview

The testing module sits at the top of the dependency stack. It orchestrates behavior from the core command engine, the terminal/platform foundation, and the formatting subsystem, while providing its own stream-capture primitives.

```mermaid
graph TD
    subgraph testing["testing (this module)"]
        CliRunner
        Result
        StreamMixer
        BytesIOCopy
        EchoingStdin
        NamedTextIOWrapper["_NamedTextIOWrapper"]
    end

    subgraph core["cli_engine / core"]
        Command
        Context
    end

    subgraph foundation["terminal_and_platform_foundation"]
        compat["_compat"]
        termui["_termui_impl"]
        utils["utils"]
    end

    subgraph formatting["cli_engine / formatting"]
        HelpFormatter
    end

    CliRunner -->|invokes| Command
    CliRunner -->|patches| termui
    CliRunner -->|patches| utils
    CliRunner -->|patches| compat
    CliRunner -->|sets FORCED_WIDTH| HelpFormatter
    CliRunner -->|produces| Result
    CliRunner -->|uses| StreamMixer
    StreamMixer --> BytesIOCopy
    CliRunner -->|uses| EchoingStdin
    CliRunner -->|uses| NamedTextIOWrapper
    Result -->|references| CliRunner
```

---

## Core Components

### CliRunner

The [`CliRunner`](src/click/testing.py::CliRunner) is the primary entry point. It is responsible for:

1. Setting up an isolated environment (streams, environment variables, Click internals).
2. Invoking the command via [`Command.main`](cli_engine.md).
3. Capturing and returning the outcome as a [`Result`](#result).

#### Construction

```python
CliRunner(charset="utf-8", env=None, echo_stdin=False)
```

| Parameter | Description |
|-----------|-------------|
| `charset` | Character set used to encode/decode input and output data. |
| `env` | A mapping of environment variable overrides applied during invocation. |
| `echo_stdin` | When `True`, data read from `<stdin>` is echoed to `<stdout>` (useful for demonstrating examples). Regular prompts always echo input regardless. |

> **Version note (8.2):** The `mix_stderr` parameter was removed. `<stdout>` and `<stderr>` are now always captured separately, and a combined `output` stream is provided.

#### Key Methods

| Method | Purpose |
|--------|---------|
| [`invoke`](src/click/testing.py::CliRunner.invoke) | Invokes a command in isolation and returns a [`Result`](#result). This is the method most tests use. |
| [`isolation`](src/click/testing.py::CliRunner.isolation) | Context manager that performs the actual environment patching. Used internally by `invoke`, but exposed for advanced use. |
| [`isolated_filesystem`](src/click/testing.py::CliRunner.isolated_filesystem) | Context manager that creates a temporary directory and `chdir`s into it, isolating tests that touch the CWD. |
| [`make_env`](src/click/testing.py::CliRunner.make_env) | Merges the runner's base `env` with per-invocation overrides. |
| [`get_default_prog_name`](src/click/testing.py::CliRunner.get_default_prog_name) | Returns the program name for a command (`cli.name` or `"root"`). |

---

### Result

The [`Result`](src/click/testing.py::Result) object holds everything captured from an invocation. It is returned by [`CliRunner.invoke`](src/click/testing.py::CliRunner.invoke).

| Attribute / Property | Type | Description |
|----------------------|------|-------------|
| `runner` | `CliRunner` | The runner that produced this result. |
| `stdout_bytes` | `bytes` | Raw standard output. |
| `stderr_bytes` | `bytes` | Raw standard error. |
| `output_bytes` | `bytes` | Interleaved mix of stdout and stderr, in write order. |
| `return_value` | `Any` | Value returned by the invoked command. |
| `exit_code` | `int` | Process exit code. |
| `exception` | `BaseException \| None` | The exception raised, if any. |
| `exc_info` | `tuple \| None` | Exception type, instance, and traceback. |
| `output` | `str` | Decoded, newline-normalized mix of stdout + stderr. |
| `stdout` | `str` | Decoded, newline-normalized stdout. |
| `stderr` | `str` | Decoded, newline-normalized stderr. |

> **Version note (8.2):** `output` is no longer a proxy for `stdout`; it now has its own independent stream that mixes `<stdout>` and `<stderr>` in the order they were written. `stderr` no longer raises an exception and always returns the captured string.

---

### Stream Capture Primitives

These helper classes implement the low-level stream plumbing used by [`CliRunner.isolation`](src/click/testing.py::CliRunner.isolation).

#### StreamMixer

[`StreamMixer`](src/click/testing.py::StreamMixer) provides three buffers:

- `stdout` — a [`BytesIOCopy`](#bytesiocopy) that mirrors writes into `output`.
- `stderr` — a [`BytesIOCopy`](#bytesiocopy) that mirrors writes into `output`.
- `output` — the shared `io.BytesIO` receiving the interleaved mix.

This is how the runner can present both separated and combined output from a single invocation.

#### BytesIOCopy

[`BytesIOCopy`](src/click/testing.py::BytesIOCopy) subclasses `io.BytesIO` and forwards every `write` (and `flush`) to a secondary `copy_to` buffer. It is the mechanism that lets `stdout`/`stderr` simultaneously feed the combined `output` stream.

#### EchoingStdin

[`EchoingStdin`](src/click/testing.py::EchoingStdin) wraps a binary input stream and echoes everything read to an output stream. It transparently proxies all other attributes to the wrapped input via `__getattr__`. Echoing can be temporarily suspended using the internal `_pause_echo` context manager (used so that prompt functions don't double-echo).

#### _NamedTextIOWrapper

[`_NamedTextIOWrapper`](src/click/testing.py::_NamedTextIOWrapper) is a thin `io.TextIOWrapper` subclass that overrides the `name` and `mode` properties. This allows the fake streams to report names like `<stdin>`, `<stdout>`, and `<stderr>` — matching what real terminal streams report.

---

## Invocation Flow

The following sequence diagram shows what happens when a test calls [`CliRunner.invoke`](src/click/testing.py::CliRunner.invoke).

```mermaid
sequenceDiagram
    participant Test
    participant Runner as CliRunner
    participant Isolation as isolation()
    participant Command
    participant Result

    Test->>Runner: invoke(cli, args, input, env, ...)
    Runner->>Isolation: enter isolation context
    Note over Isolation: Save & patch sys.stdin/stdout/stderr,<br/>os.environ, termui prompts,<br/>utils.should_strip_ansi, FORCED_WIDTH
    Isolation-->>Runner: (stdout, stderr, output) buffers
    Runner->>Runner: shlex.split(args) if str
    Runner->>Command: cli.main(args, prog_name, **extra)
    Command-->>Runner: return_value OR SystemExit OR Exception
    Runner->>Runner: flush stdout, read buffer values
    Isolation->>Isolation: restore all patched state
    Runner->>Result: construct Result(...)
    Result-->>Test: Result object
```

### Environment Patching Details

During [`isolation`](src/click/testing.py::CliRunner.isolation), the runner performs the following substitutions and restores them in a `finally` block:

| Global | Replacement |
|--------|-------------|
| `sys.stdin` | `_NamedTextIOWrapper` over the input bytes |
| `sys.stdout` | `_NamedTextIOWrapper` over `StreamMixer.stdout` |
| `sys.stderr` | `_NamedTextIOWrapper` over `StreamMixer.stderr` (with `errors="backslashreplace"`) |
| `os.environ` | Overridden with merged `env` values |
| `termui.visible_prompt_func` | `visible_input` (echoes prompt + input) |
| `termui.hidden_prompt_func` | `hidden_input` (no echo) |
| `termui._getchar` | `_getchar` (single-char read) |
| `utils.should_strip_ansi` | `should_strip_ansi` (respects `color` flag) |
| `_compat.should_strip_ansi` | `should_strip_ansi` |
| `formatting.FORCED_WIDTH` | `80` |

This is why the runner is **not thread-safe** — it mutates process-global state.

---

## Exit Code & Exception Handling

[`CliRunner.invoke`](src/click/testing.py::CliRunner.invoke) normalizes the many ways a Click command can terminate:

```mermaid
flowchart TD
    A[cli.main invoked] --> B{Outcome?}
    B -->|Returns normally| C[return_value set, exit_code = 0]
    B -->|SystemExit| D{code is None?}
    D -->|Yes| E[exit_code = 0]
    D -->|No, non-zero| F[exception = e, exit_code = code]
    D -->|Non-int code| G[write code to stdout, exit_code = 1]
    B -->|Other Exception| H{catch_exceptions?}
    H -->|True| I[exception = e, exit_code = 1, capture exc_info]
    H -->|False| J[re-raise]
    C --> K[Build Result]
    E --> K
    F --> K
    G --> K
    I --> K
```

- `catch_exceptions=True` (default) captures non-`SystemExit` exceptions and records them in the `Result`.
- `catch_exceptions=False` re-raises them so the test can assert on the traceback directly.
- Non-integer `SystemExit` codes are written to stdout and converted to exit code `1`.

---

## Filesystem Isolation

[`isolated_filesystem`](src/click/testing.py::CliRunner.isolated_filesystem) is a separate context manager for tests that read or write files relative to the current working directory.

```mermaid
flowchart LR
    A[Save cwd] --> B[tempfile.mkdtemp]
    B --> C[os.chdir to temp dir]
    C --> D[yield temp dir path]
    D --> E[os.chdir back to saved cwd]
    E --> F{temp_dir param given?}
    F -->|No| G[shutil.rmtree temp dir]
    F -->|Yes| H[leave directory in place]
```

- If `temp_dir` is provided, the temporary directory is created **under** it and is **not** removed on exit.
- Otherwise, a fresh directory is created and cleaned up automatically.

---

## Dependencies

The testing module depends on several other modules. Refer to their documentation for details rather than duplicating information here.

| Dependency | Used For |
|------------|----------|
| [`cli_engine`](cli_engine.md) (`core.Command`) | The command being invoked via `cli.main`. |
| [`cli_engine`](cli_engine.md) (`formatting.HelpFormatter`) | `FORCED_WIDTH` is set to `80` to make help output deterministic. |
| [`terminal_and_platform_foundation`](terminal_and_platform_foundation.md) (`_compat`) | `_find_binary_reader` for normalizing input streams; `should_strip_ansi` patching. |
| [`terminal_and_platform_foundation`](terminal_and_platform_foundation.md) (`_termui_impl`) | Prompt functions (`visible_prompt_func`, `hidden_prompt_func`, `_getchar`) are patched. |
| [`terminal_and_platform_foundation`](terminal_and_platform_foundation.md) (`utils`) | `should_strip_ansi` is patched to honor the `color` flag. |

```mermaid
graph LR
    testing --> cli_engine
    testing --> terminal_and_platform_foundation
    testing --> shell_completion
    cli_engine --> terminal_and_platform_foundation
    shell_completion --> cli_engine
```

---

## Usage Examples

### Basic Invocation

```python
from click.testing import CliRunner
from myapp import cli

def test_hello():
    runner = CliRunner()
    result = runner.invoke(cli, ["hello", "World"])
    assert result.exit_code == 0
    assert "Hello World" in result.output
```

### Providing Input

```python
def test_prompt():
    runner = CliRunner()
    result = runner.invoke(cli, ["login"], input="user\nsecret\n")
    assert result.exit_code == 0
```

### Isolated Filesystem

```python
def test_writes_file():
    runner = CliRunner()
    with runner.isolated_filesystem():
        result = runner.invoke(cli, ["generate", "output.txt"])
        assert result.exit_code == 0
        with open("output.txt") as f:
            assert f.read() == "generated"
```

### Asserting on Exceptions

```python
def test_raises():
    runner = CliRunner()
    result = runner.invoke(cli, ["boom"], catch_exceptions=False)
    # exception propagates to the test
```

### Environment Overrides

```python
def test_env():
    runner = CliRunner(env={"MY_VAR": "value"})
    result = runner.invoke(cli, ["show-env"], env={"MY_VAR": "override"})
    assert "override" in result.output
```

---

## Version History Highlights

| Version | Change |
|---------|--------|
| 8.2 | `mix_stderr` removed; `output_bytes`/`output` introduced as an interleaved stream; `stderr` always returned; `BytesIOCopy` and `StreamMixer` added. |
| 8.0 | `Result.return_value` added; `isolated_filesystem` gained `temp_dir`; `<stderr>` opened with `errors="backslashreplace"`. |
| 4.0 | `color` parameter added to `invoke` and `isolation`. |
| 3.0 | `catch_exceptions` parameter and `exc_info` attribute added. |

---

## Related Documentation

- [cli_engine.md](cli_engine.md) — Core command, context, and formatting engine.
- [terminal_and_platform_foundation.md](terminal_and_platform_foundation.md) — Compatibility, terminal UI, and utility helpers.
- [shell_completion.md](shell_completion.md) — Shell completion support (interacts with `Command.main`).
