# winconsole

## Introduction

The `winconsole` module (`src/click/_winconsole.py`) provides a Windows-specific
implementation for reading from and writing to the native Windows console using
the wide-character (`W`) Win32 APIs. It exists because the standard Python I/O
stack does not correctly handle the UTF-16-LE encoding used by the Windows
console, nor does it reliably support Unicode output on legacy consoles.

This module is part of the **terminal_and_platform_foundation** layer of Click.
It is a private, platform-gated module: it asserts `sys.platform == "win32"` at
import time and is only imported on Windows. Its public entry point,
`_get_windows_console_stream`, is consumed by the compatibility layer
(see [compat.md](compat.md)) to transparently replace `sys.stdin`, `sys.stdout`,
and `sys.stderr` with console-aware streams.

> **Note:** This module is based on the work by Adam Bartoš from the discussion
> of Python bug tracker issue 1602. Unlike the original patches, it does not
> patch the entire interpreter — it only operates within Click's "little world"
> of echo and prompt.

---

## Purpose and Core Functionality

The module solves three concrete problems on Windows:

1. **Unicode output** — Writing non-ASCII text to the Windows console requires
   the `WriteConsoleW` API rather than the byte-oriented `WriteFile`.
2. **Unicode input** — Reading from the console requires `ReadConsoleW`, which
   returns UTF-16-LE code units.
3. **Correct encoding semantics** — The console streams must be wrapped so that
   Python's text layer sees a consistent `utf-16-le` encoding.

To achieve this, the module builds a small I/O stack:

- Low-level `io.RawIOBase` subclasses that call the Win32 wide APIs.
- A `ConsoleStream` facade that presents a single object behaving as both a
  text stream and a binary stream.
- Factory functions that assemble the full stack for stdin, stdout, and stderr.

---

## Architecture

The module is organized into three conceptual layers: **Win32 bindings**,
**raw I/O primitives**, and **stream assembly**.

```mermaid
graph TD
    subgraph "Win32 Bindings (ctypes)"
        K32[kernel32 / windll]
        RCW[ReadConsoleW]
        WCW[WriteConsoleW]
        GCM[GetConsoleMode]
        GSH[GetStdHandle]
        PYBUF[PyObject_GetBuffer / PyBuffer_Release]
    end

    subgraph "Raw I/O Primitives"
        RAW[_WindowsConsoleRawIOBase]
        READER[_WindowsConsoleReader]
        WRITER[_WindowsConsoleWriter]
        PB[Py_buffer]
        GB[get_buffer]
    end

    subgraph "Stream Assembly"
        CS[ConsoleStream]
        FSTDIN[_get_text_stdin]
        FSTDOUT[_get_text_stdout]
        FSTDERR[_get_text_stderr]
        FACTORIES[_stream_factories]
        ISCON[_is_console]
        ENTRY[_get_windows_console_stream]
    end

    K32 --> RCW
    K32 --> WCW
    K32 --> GCM
    K32 --> GSH
    PYBUF --> GB
    GB --> PB

    RAW --> READER
    RAW --> WRITER
    READER --> RCW
    READER --> GB
    WRITER --> WCW
    WRITER --> GB

    READER --> FSTDIN
    WRITER --> FSTDOUT
    WRITER --> FSTDERR
    FSTDIN --> FACTORIES
    FSTDOUT --> FACTORIES
    FSTDERR --> FACTORIES
    FACTORIES --> ENTRY
    ISCON --> ENTRY
    ENTRY --> CS
```

### Component Responsibilities

| Component | Layer | Responsibility |
|-----------|-------|----------------|
| `Py_buffer` | Bindings | `ctypes.Structure` mirroring CPython's `Py_buffer` for zero-copy buffer access. |
| `get_buffer` | Bindings | Acquires a writable/readable buffer view over a Python object via the CPython buffer protocol. |
| `_WindowsConsoleRawIOBase` | Raw I/O | Base class holding a console `handle`; reports `isatty() == True`. |
| `_WindowsConsoleReader` | Raw I/O | Implements `readinto` using `ReadConsoleW`. |
| `_WindowsConsoleWriter` | Raw I/O | Implements `write` using `WriteConsoleW`. |
| `ConsoleStream` | Assembly | Facade combining a text stream and a binary buffer into one object. |
| `_get_text_stdin/stdout/stderr` | Assembly | Build the full text+binary stack for each standard stream. |
| `_is_console` | Assembly | Detects whether a file object is attached to a real console. |
| `_get_windows_console_stream` | Assembly | Public entry point; returns a `ConsoleStream` or `None`. |

---

## Component Interaction

The following diagram shows how the pieces cooperate at runtime when Click
requests a console-aware stream.

```mermaid
sequenceDiagram
    participant Compat as _compat (caller)
    participant Entry as _get_windows_console_stream
    participant IsCon as _is_console
    participant Factory as _stream_factories
    participant CS as ConsoleStream
    participant Reader as _WindowsConsoleReader
    participant Writer as _WindowsConsoleWriter

    Compat->>Entry: f, encoding, errors
    Entry->>Entry: check get_buffer, encoding, errors
    Entry->>IsCon: _is_console(f)
    IsCon->>IsCon: GetConsoleMode(handle)
    IsCon-->>Entry: True
    Entry->>Factory: func = factories[f.fileno()]
    Factory-->>Entry: _get_text_stdout
    Entry->>CS: build ConsoleStream(text, buffer)
    CS-->>Entry: ConsoleStream
    Entry-->>Compat: ConsoleStream

    Note over CS,Writer: On write(str) -> text_stream.write
    CS->>Writer: write(bytes) via buffer
    Writer->>Writer: WriteConsoleW(...)
```

---

## Data Flow

### Writing to the Console

When a string is written to a `ConsoleStream`, it is routed to the underlying
`_NonClosingTextIOWrapper`, which encodes it as UTF-16-LE and forwards bytes to
the `_WindowsConsoleWriter`. The writer converts the byte buffer into a
`Py_buffer` and calls `WriteConsoleW`.

```mermaid
flowchart LR
    A["str"] --> B["ConsoleStream.write"]
    B -->|isinstance str| C["_NonClosingTextIOWrapper.write"]
    C -->|encode utf-16-le| D["_WindowsConsoleWriter.write"]
    D --> E["get_buffer(b)"]
    E --> F["WriteConsoleW(handle, buf, ...)"]
    F --> G["bytes_written = 2 * code_units_written"]
```

### Reading from the Console

Reading is symmetric: `_WindowsConsoleReader.readinto` acquires a writable
buffer over the destination bytearray and calls `ReadConsoleW`, returning the
number of bytes read (twice the number of UTF-16 code units).

```mermaid
flowchart LR
    A["readinto(b)"] --> B["get_buffer(b, writable=True)"]
    B --> C["ReadConsoleW(handle, buffer, ...)"]
    C --> D{"GetLastError == ABORTED?"}
    D -->|yes| E["sleep(0.1) to allow KeyboardInterrupt"]
    D -->|no| F["check rv"]
    E --> F
    F --> G{"buffer[0] == EOF (0x1a)?"}
    G -->|yes| H["return 0"]
    G -->|no| I["return 2 * code_units_read"]
```

---

## Key Components

### `Py_buffer` and `get_buffer`

`Py_buffer` is a `ctypes.Structure` that mirrors CPython's internal
`Py_buffer` layout. It is used together with `PyObject_GetBuffer` and
`PyBuffer_Release` (from `ctypes.pythonapi`) to obtain a raw pointer to a
Python object's memory without copying.

```python
def get_buffer(obj, writable=False):
    buf = Py_buffer()
    flags = PyBUF_WRITABLE if writable else PyBUF_SIMPLE
    PyObject_GetBuffer(py_object(obj), byref(buf), flags)
    try:
        buffer_type = c_char * buf.len
        return buffer_type.from_address(buf.buf)
    finally:
        PyBuffer_Release(byref(buf))
```

> **PyPy limitation:** On PyPy, `ctypes.pythonapi` is unavailable, so
> `get_buffer` is set to `None`. When `get_buffer is None`, the entire
> console-stream mechanism is disabled and `_get_windows_console_stream`
> returns `None`.

### `_WindowsConsoleRawIOBase`

A minimal `io.RawIOBase` subclass that stores the Win32 `handle` and always
reports `isatty() == True`. It is the shared base for the reader and writer.

### `_WindowsConsoleReader`

Implements `readable()` and `readinto(b)`. Notable behaviors:

- Rejects odd byte counts, since UTF-16-LE data is always an even number of
  bytes.
- Handles `ERROR_OPERATION_ABORTED` by sleeping briefly so a pending
  `KeyboardInterrupt` can be delivered.
- Treats the `EOF` byte (`0x1a`) as end-of-input.

### `_WindowsConsoleWriter`

Implements `writable()` and `write(b)`. Notable behaviors:

- Caps each write at `MAX_BYTES_WRITTEN` (32767) bytes to respect the Win32
  API limit.
- Raises `OSError` with a human-readable message when zero bytes are written
  despite a non-empty input.

### `ConsoleStream`

A facade that presents a single object behaving as both a text stream and a
binary stream:

- `write(x)` dispatches to the text stream for `str` and to the binary buffer
  for bytes (flushing first).
- `buffer` exposes the underlying binary stream.
- `__getattr__` proxies all other attributes to the text stream.
- `isatty()` delegates to the binary buffer.

### `_get_windows_console_stream`

The module's public entry point. It returns a `ConsoleStream` only when **all**
of the following hold:

1. `get_buffer` is available (not PyPy).
2. `encoding` is `"utf-16-le"` or `None`.
3. `errors` is `"strict"` or `None`.
4. The file object is attached to a real console (`_is_console`).
5. The file descriptor maps to a known standard stream (0, 1, or 2).

Otherwise it returns `None`, signaling the caller to fall back to the default
stream handling.

---

## Dependencies

```mermaid
graph LR
    WC[_winconsole] --> COMPAT[_compat]
    COMPAT --> NCW[_NonClosingTextIOWrapper]
    COMPAT --> FIX[_FixupStream]
    WC --> STDLIB["stdlib: io, ctypes, msvcrt, sys, time"]
    COMPAT --> UTILS[utils]
    UTILS --> LKF[LazyFile]
    UTILS --> KOF[KeepOpenFile]
    UTILS --> PFW[PacifyFlushWrapper]
```

### Internal Dependencies

- **`_compat._NonClosingTextIOWrapper`** — The text wrapper used to build the
  console text streams. It wraps a binary stream with `_FixupStream` and
  detaches (rather than closes) on garbage collection. See
  [compat.md](compat.md) for details on `_FixupStream` and `_AtomicFile`.

### Standard Library Dependencies

- `io` — `RawIOBase`, `BufferedReader`, `BufferedWriter`, `TextIOWrapper`.
- `ctypes` / `ctypes.wintypes` — Win32 API bindings and structures.
- `msvcrt` — `get_osfhandle` for console detection.
- `sys`, `time`, `collections.abc`, `typing`.

### Related Modules

- [compat.md](compat.md) — The compatibility layer that consumes this module.
- [utils.md](utils.md) — Stream wrappers (`LazyFile`, `KeepOpenFile`,
  `PacifyFlushWrapper`) used elsewhere in the terminal foundation.
- [termui_impl.md](termui_impl.md) — Terminal UI implementation (`Editor`,
  `ProgressBar`) that relies on the same stream infrastructure.

---

## Platform and Runtime Constraints

| Constraint | Effect |
|------------|--------|
| `sys.platform == "win32"` | Module asserts this at import; cannot be imported elsewhere. |
| PyPy | `get_buffer` is `None`; console streams are disabled. |
| Encoding | Only `utf-16-le` (or `None`) is supported. |
| Error handling | Only `strict` (or `None`) is supported. |
| Write size | Each `WriteConsoleW` call is capped at 32767 bytes. |
| Read size | Byte counts must be even (UTF-16-LE). |

---

## Summary

The `winconsole` module is a focused, Windows-only shim that bridges Click's
text I/O needs to the native wide-character Win32 console APIs. It provides:

- Zero-copy buffer access via the CPython buffer protocol (`Py_buffer`,
  `get_buffer`).
- Raw reader/writer primitives over `ReadConsoleW`/`WriteConsoleW`.
- A unified `ConsoleStream` facade and factory functions for stdin/stdout/stderr.
- A guarded entry point (`_get_windows_console_stream`) that gracefully
  degrades to `None` when the environment does not support console streams.

It is consumed by the compatibility layer ([compat.md](compat.md)) and forms the
lowest level of Click's terminal and platform foundation.
