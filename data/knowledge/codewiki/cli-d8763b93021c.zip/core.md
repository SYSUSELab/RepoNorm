# Core Module

## Introduction

The **core** module (`src/click/core.py`) is the heart of the Click command-line framework. It defines the fundamental abstractions that every Click application is built upon: **commands**, **groups**, **parameters** (options and arguments), and the **context** object that carries state through an invocation.

This module is responsible for:

- Defining the command hierarchy (`Command`, `Group`, `CommandCollection`).
- Defining parameters (`Parameter`, `Option`, `Argument`) and how they are declared, parsed, and processed.
- Managing invocation state via `Context`, including parameter sources, resource cleanup, and nested command dispatch.
- Orchestrating the end-to-end lifecycle of a CLI invocation through `Command.main()`.

The core module sits at the center of the framework and depends on several sibling modules for parsing, error handling, formatting, and type conversion. Those modules are documented separately and referenced throughout this document.

---

## Architecture Overview

The core module is composed of four conceptual layers that interact during a CLI invocation:

1. **Command layer** — `Command`, `Group`, `CommandCollection` (and deprecated `_BaseCommand`, `_MultiCommand`).
2. **Parameter layer** — `Parameter`, `Option`, `Argument`, plus the `ParameterSource` enum.
3. **Context layer** — `Context`, which holds per-invocation state.
4. **Orchestration helpers** — module-level functions such as `iter_params_for_processing`, `augment_usage_errors`, and `_complete_visible_commands`.

```mermaid
graph TD
    subgraph "Command Layer"
        CMD[Command]
        GRP[Group]
        CC[CommandCollection]
        BC[_BaseCommand deprecated]
        MC[_MultiCommand deprecated]
    end

    subgraph "Parameter Layer"
        PARAM[Parameter]
        OPT[Option]
        ARG[Argument]
        PS[ParameterSource]
    end

    subgraph "Context Layer"
        CTX[Context]
    end

    GRP --> CMD
    CC --> GRP
    BC -.-> CMD
    MC -.-> GRP

    OPT --> PARAM
    ARG --> PARAM

    CMD --> CTX
    CTX --> PARAM
    PARAM --> PS
```

### Class Hierarchy

```mermaid
classDiagram
    class Command {
        +name
        +params
        +callback
        +context_class
        +make_context()
        +parse_args()
        +invoke()
        +main()
        +shell_complete()
    }
    class Group {
        +commands
        +chain
        +invoke_without_command
        +add_command()
        +command()
        +group()
        +resolve_command()
    }
    class CommandCollection {
        +sources
        +add_source()
        +get_command()
        +list_commands()
    }
    class Parameter {
        +name
        +type
        +required
        +nargs
        +multiple
        +consume_value()
        +process_value()
        +handle_parse_result()
    }
    class Option {
        +is_flag
        +flag_value
        +prompt
        +count
        +get_help_record()
    }
    class Argument {
        +make_metavar()
        +get_usage_pieces()
    }
    class Context {
        +command
        +parent
        +params
        +obj
        +invoke()
        +forward()
        +exit()
    }

    Group --|> Command
    CommandCollection --|> Group
    Option --|> Parameter
    Argument --|> Parameter
    Command ..> Context : creates
    Context ..> Parameter : processes
```

---

## Command Layer

### `Command`

`Command` is the base building block of every Click CLI. It encapsulates:

- A **name** and optional **callback**.
- A list of **parameters** (`Option` and `Argument` instances).
- Help text (`help`, `epilog`, `short_help`) and display flags (`hidden`, `deprecated`).
- Parsing behavior flags inherited by the `Context`: `allow_extra_args`, `allow_interspersed_args`, `ignore_unknown_options`.

Key responsibilities:

| Method | Purpose |
| --- | --- |
| `make_context()` | Builds a `Context` and parses arguments (without invoking the callback). |
| `parse_args()` | Runs the parser and processes each parameter via `handle_parse_result`. |
| `invoke()` | Calls the command callback with the parsed parameters. |
| `main()` | Full application entry point: handles completion, exceptions, and exit codes. |
| `get_help()` / `get_usage()` | Produce formatted help and usage strings. |
| `shell_complete()` | Provides shell completion candidates. |

The `context_class` attribute allows customizing the `Context` subclass used for invocations.

### `Group`

`Group` extends `Command` to support **nested subcommands**. It maintains a mapping of subcommand names to `Command` objects and supports:

- **`chain` mode** — multiple subcommands can be invoked in sequence.
- **`invoke_without_command`** — the group callback runs even without a subcommand.
- **`result_callback`** — a callback invoked with the subcommand's return value.
- **Decorators** `command()` and `group()` for registering subcommands inline.

`Group` overrides `parse_args()` to split remaining arguments into `_protected_args` (the subcommand name) and `args` (the subcommand's arguments), and overrides `invoke()` to resolve and dispatch to the correct subcommand.

> **Note:** `Group` merged with and replaced the deprecated `MultiCommand` base class in Click 8.2.

### `CommandCollection`

`CommandCollection` is a `Group` that **flattens** commands from multiple source groups. When a command is not found locally, each registered source is queried in order. This is useful for building a unified CLI from several independent groups.

### Deprecated Compatibility Classes

- `_BaseCommand` — deprecated alias for `Command` (removed in Click 9.0).
- `_MultiCommand` — deprecated alias for `Group` (removed in Click 9.0).
- `_FakeSubclassCheck` — a metaclass that makes the deprecated classes pass `issubclass`/`isinstance` checks against their modern replacements.

Accessing `BaseCommand` or `MultiCommand` via module `__getattr__` emits a `DeprecationWarning`.

---

## Parameter Layer

### `Parameter`

`Parameter` is the abstract base for `Option` and `Argument`. It handles the shared lifecycle of a parameter value:

```mermaid
flowchart LR
    A[consume_value] --> B[type_cast_value]
    B --> C[process_value]
    C --> D[callback]
    D --> E[store in ctx.params]
```

1. **`consume_value()`** — resolves the value from the command line, environment variable, `default_map`, or the parameter default, and records the `ParameterSource`.
2. **`type_cast_value()`** — converts and validates the raw value against the parameter's `type`, `multiple`, and `nargs`.
3. **`process_value()`** — validates required parameters, then invokes the user-supplied `callback`.
4. **`handle_parse_result()`** — wraps the above in `augment_usage_errors` and stores the value on the context if `expose_value` is set.

Subclasses must implement `_parse_decls()` and `add_to_parser()`.

### `Option`

`Option` adds command-line-specific features:

- **Flags** (`is_flag`, `flag_value`, `secondary_opts`) for boolean toggles.
- **Prompting** (`prompt`, `confirmation_prompt`, `hide_input`) for interactive input.
- **Counting** (`count`) for repeated flags like `-vvv`.
- **Help rendering** via `get_help_record()` and `get_help_extra()` (env vars, defaults, ranges, required markers).
- **Auto environment variables** via `allow_from_autoenv` and the context's `auto_envvar_prefix`.

### `Argument`

`Argument` represents positional parameters. It is required by default (unless a default is provided), supports infinite `nargs`, and does not support `multiple`. Its metavar rendering (`make_metavar()`) wraps optional arguments in brackets.

### `ParameterSource`

`ParameterSource` is an `enum.Enum` describing where a parameter's value came from:

| Value | Meaning |
| --- | --- |
| `COMMANDLINE` | Provided on the command line. |
| `ENVIRONMENT` | Provided via an environment variable. |
| `DEFAULT` | Taken from the parameter's default. |
| `DEFAULT_MAP` | Taken from `Context.default_map`. |
| `PROMPT` | Provided interactively via a prompt. |

Retrieve it with `Context.get_parameter_source(name)`.

---

## Context Layer

### `Context`

`Context` is the per-invocation state container. It is normally invisible to commands unless they opt in (e.g., via `@click.pass_context`). It carries:

- **Hierarchy** — `parent`, `command`, `info_name`, and the computed `command_path`.
- **Parsed state** — `params`, `args`, `_protected_args`, `_opt_prefixes`.
- **Configuration** — `default_map`, `auto_envvar_prefix`, `terminal_width`, `max_content_width`, `help_option_names`, `token_normalize_func`, `color`, `show_default`.
- **Parsing flags** — `resilient_parsing`, `allow_extra_args`, `allow_interspersed_args`, `ignore_unknown_options`.
- **Resource management** — `with_resource()`, `call_on_close()`, and `close()` backed by an `ExitStack`.

Key methods:

| Method | Purpose |
| --- | --- |
| `invoke()` | Invoke a callback or another `Command` with proper parameter filling. |
| `forward()` | Like `invoke()` but fills defaults from the current context. |
| `exit()` / `fail()` / `abort()` | Terminate execution with an exit code, usage error, or abort. |
| `find_object()` / `ensure_object()` | Locate or create a typed user object in the context chain. |
| `lookup_default()` | Resolve a default from `default_map`. |
| `scope()` | Push the context as the current thread-local context. |
| `to_info_dict()` | Serialize the CLI structure for documentation tooling. |

Contexts are pushed onto a thread-local stack via `push_context` / `pop_context` (see the [globals module](globals.md)), enabling `get_current_context()`.

---

## Invocation Lifecycle

The following sequence diagram shows how a CLI invocation flows through the core module:

```mermaid
sequenceDiagram
    participant User
    participant Command
    participant Context
    participant Parser as _OptionParser
    participant Parameter

    User->>Command: main(args)
    Command->>Command: _main_shell_completion()
    Command->>Command: make_context(prog_name, args)
    Command->>Context: __init__()
    Command->>Context: scope(cleanup=False)
    Command->>Command: parse_args(ctx, args)
    Command->>Parser: make_parser(ctx)
    Parser-->>Command: opts, args, param_order
    loop for each param
        Command->>Parameter: handle_parse_result(ctx, opts, args)
        Parameter->>Parameter: consume_value()
        Parameter->>Parameter: type_cast_value()
        Parameter->>Parameter: process_value()
        Parameter-->>Command: value, args
    end
    Command->>Context: __enter__()
    Command->>Command: invoke(ctx)
    Command->>Context: invoke(callback, **params)
    Context-->>Command: return value
    Command->>Context: exit()
```

### Step-by-step

1. **Entry** — `Command.main()` is called (directly or via `__call__`). It resolves `args` and `prog_name`, and checks for shell completion requests.
2. **Context creation** — `make_context()` instantiates the `context_class`, applies `context_settings`, and calls `parse_args()`.
3. **Parsing** — `make_parser()` builds an `_OptionParser` (see the [parser module](parser.md)) and each parameter registers itself via `add_to_parser()`. The parser returns parsed options, leftover args, and the invocation order.
4. **Parameter processing** — `iter_params_for_processing()` orders parameters (eager first, then declaration order), and each is processed via `handle_parse_result()`.
5. **Invocation** — `invoke()` calls the callback with `ctx.params`. For `Group`, this dispatches to the resolved subcommand.
6. **Teardown** — `Context.close()` runs registered cleanup callbacks and exits context managers. `main()` converts exceptions into exit codes.

---

## Error Handling

The core module integrates tightly with the [exceptions module](exceptions.md):

- `augment_usage_errors()` is a context manager that attaches the current `Context` and `Parameter` to `BadParameter` and `UsageError` exceptions as they propagate.
- `Context.fail()` raises a `UsageError`; `Context.abort()` raises `Abort`; `Context.exit()` raises `Exit`.
- `Command.main()` catches `ClickException`, `Abort`, `EOFError`, `KeyboardInterrupt`, and `OSError` (handling `EPIPE` gracefully) and converts them into appropriate exit codes.

```mermaid
flowchart TD
    A[Exception raised] --> B{Type?}
    B -->|ClickException| C[show + sys.exit exit_code]
    B -->|Abort| D[print Aborted + exit 1]
    B -->|EOFError/KeyboardInterrupt| E[raise Abort]
    B -->|OSError EPIPE| F[wrap stdout/stderr + exit 1]
    B -->|Exit| G[exit with code]
```

---

## Dependencies

The core module depends on the following sibling modules:

```mermaid
graph LR
    CORE[core.py]
    CORE --> PARSER[parser.py]
    CORE --> EXC[exceptions.py]
    CORE --> FMT[formatting.py]
    CORE --> TYPES[types.py]
    CORE --> GLOBALS[globals.py]
    CORE --> TERMUI[termui.py]
    CORE --> UTILS[utils.py]
    CORE --> SHELL[shell_completion.py]
    CORE --> DECO[decorators.py]
```

| Dependency | Role |
| --- | --- |
| [parser](parser.md) | `_OptionParser`, `_split_opt`, `_flag_needs_value` for low-level argument parsing. |
| [exceptions](exceptions.md) | `UsageError`, `BadParameter`, `Abort`, `Exit`, `MissingParameter`, `NoArgsIsHelpError`. |
| [formatting](formatting.md) | `HelpFormatter` and `join_options` for help/usage rendering. |
| [types](types.md) | `ParamType` and concrete types used by parameters. |
| [globals](globals.md) | `push_context` / `pop_context` for the thread-local context stack. |
| [termui](termui.md) | `confirm`, `prompt`, `style` for interactive input and styling. |
| [utils](utils.md) | `echo`, `make_str`, `_detect_program_name`, `_expand_args`, `PacifyFlushWrapper`. |
| [shell_completion](shell_completion.md) | `CompletionItem` and `shell_complete` for tab completion. |
| [decorators](decorators.md) | `command` and `group` decorators used by `Group.command()` / `Group.group()`. |

---

## Module-Level Helpers

| Helper | Purpose |
| --- | --- |
| `iter_params_for_processing()` | Orders parameters so eager ones run first, then by declaration order. |
| `augment_usage_errors()` | Attaches context/parameter info to usage errors. |
| `_complete_visible_commands()` | Yields non-hidden subcommands matching an incomplete value. |
| `_check_nested_chain()` | Prevents nesting groups inside chain-mode groups. |
| `batch()` | Groups an iterable into fixed-size tuples (used for `multiple` + `nargs`). |
| `_check_iter()` | Validates that a value is iterable but not a string. |

---

## Related Documentation

- [parser.md](parser.md) — Low-level option/argument parsing.
- [exceptions.md](exceptions.md) — Exception hierarchy and error formatting.
- [formatting.md](formatting.md) — Help and usage text formatting.
- [types.md](types.md) — Parameter type system and conversion.
- [globals.md](globals.md) — Thread-local context stack.
- [termui.md](termui.md) — Terminal UI helpers (prompts, confirmations, styling).
- [utils.md](utils.md) — Shared utilities (echo, file handling, program name detection).
- [shell_completion.md](shell_completion.md) — Shell completion support.
- [decorators.md](decorators.md) — Decorator-based command/option declaration.
- [testing.md](testing.md) — `CliRunner` and testing utilities.
