# Teleprompt Bootstrap Module

## Introduction

The **Teleprompt Bootstrap** module is a family of DSPy optimizers (teleprompters) that automatically improve a program's performance by generating and selecting **demonstrations** (few-shot examples) for its predictors. Rather than relying solely on hand-labeled examples, these optimizers *bootstrap* demonstrations by running a "teacher" program over the training set, capturing successful execution traces, and injecting those traces back into the student program's prompts.

The module provides several strategies built on a shared bootstrapping core:

- **`BootstrapFewShot`** — the foundational optimizer that bootstraps demonstrations and combines them with labeled examples.
- **`BootstrapFewShotWithRandomSearch`** — runs many candidate configurations of `BootstrapFewShot` and selects the best-scoring program.
- **`BootstrapFewShotWithOptuna`** — uses Optuna hyperparameter search to select the best subset of bootstrapped demos per predictor.
- **`InferRules`** — extends `BootstrapFewShot` by inducing natural-language rules from examples and appending them to predictor instructions.

All of these inherit from the base [`Teleprompter`](teleprompt_core.md) class and rely on [`Evaluate`](evaluate_orchestration.md) for scoring candidate programs.

---

## Architecture Overview

The module is organized around a shared bootstrapping engine (`BootstrapFewShot`) that the other optimizers compose or extend.

```mermaid
graph TD
    Teleprompter["Teleprompter (base)"]
    BFS["BootstrapFewShot"]
    BFSRS["BootstrapFewShotWithRandomSearch"]
    BFSO["BootstrapFewShotWithOptuna"]
    IR["InferRules"]
    RIP["RulesInductionProgram"]

    Teleprompter --> BFS
    Teleprompter --> BFSRS
    Teleprompter --> BFSO
    BFS --> IR
    BFSRS -.uses.-> BFS
    BFSO -.uses.-> BFS
    IR --> RIP

    BFS -.uses.-> LFS["LabeledFewShot"]
    BFSRS -.uses.-> LFS
    BFSRS -.uses.-> Eval["Evaluate"]
    BFSO -.uses.-> Eval
    IR -.uses.-> Eval
```

### Component Responsibilities

| Component | File | Role |
|-----------|------|------|
| `BootstrapFewShot` | `bootstrap.py` | Core bootstrapping engine; generates demos from teacher traces and assembles the student's demo set. |
| `BootstrapFewShotWithRandomSearch` | `random_search.py` | Generates multiple candidate programs (varying demo counts/seeds) and selects the best by validation score. |
| `BootstrapFewShotWithOptuna` | `teleprompt_optuna.py` | Uses Optuna to search over which bootstrapped demo to keep per predictor. |
| `InferRules` | `infer_rules.py` | Bootstraps demos, then induces natural-language rules and appends them to predictor instructions. |
| `RulesInductionProgram` | `infer_rules.py` | A `dspy.Module` that uses `ChainOfThought` to extract rules from formatted examples. |

---

## Core Component: `BootstrapFewShot`

`BootstrapFewShot` is the heart of the module. It composes a set of demonstrations for each predictor from two sources:

1. **Bootstrapped demos** — successful traces captured by running the teacher program.
2. **Labeled demos** — raw examples sampled from the training set.

### Configuration Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `metric` | `None` | Callable comparing expected vs. predicted values; determines whether a trace is accepted. |
| `metric_threshold` | `None` | If the metric returns a numeric value, accept the trace only when `metric_val >= metric_threshold`. |
| `teacher_settings` | `None` | Settings applied to the teacher model during bootstrapping. |
| `max_bootstrapped_demos` | `4` | Maximum number of bootstrapped demos per predictor. |
| `max_labeled_demos` | `16` | Maximum number of labeled demos per predictor. |
| `max_rounds` | `1` | Number of attempts to bootstrap each example (later rounds raise temperature). |
| `max_errors` | `None` | Error budget before aborting; inherits from `dspy.settings.max_errors` if `None`. |

### Compilation Flow

The `compile` method orchestrates the full optimization pipeline:

```mermaid
flowchart TD
    Start([compile student, teacher, trainset]) --> Prep["_prepare_student_and_teacher<br/>(reset_copy student, deepcopy teacher)"]
    Prep --> Label["If teacher uncompiled & max_labeled_demos:<br/>apply LabeledFewShot to teacher"]
    Label --> Map["_prepare_predictor_mappings<br/>(validate structure & signatures)"]
    Map --> Boot["_bootstrap<br/>(iterate trainset, capture traces)"]
    Boot --> Train["_train<br/>(assemble demos per predictor)"]
    Train --> Mark["Mark student._compiled = True<br/>set _assert_failures / _suggest_failures = 0"]
    Mark --> Done([return optimized student])
```

#### Step 1 — Prepare Student and Teacher (`_prepare_student_and_teacher`)

- The student is created via `student.reset_copy()` (fresh, uncompiled).
- The teacher is a `deepcopy` of the provided teacher, or a `deepcopy` of the student if none is given.
- If the teacher is uncompiled and `max_labeled_demos > 0`, a [`LabeledFewShot`](teleprompt_core.md) teleprompter seeds the teacher with labeled demos.

#### Step 2 — Prepare Predictor Mappings (`_prepare_predictor_mappings`)

Validates that student and teacher have:
- The same number of predictors,
- Matching predictor names and program structure,
- Matching signatures (via `Signature.equals` when available),
- Distinct predictor objects.

It builds two lookup dictionaries: `name2predictor` and `predictor2name` (keyed by object `id`), which are later used to map captured traces back to the correct student predictor.

#### Step 3 — Bootstrap (`_bootstrap` and `_bootstrap_one_example`)

For each training example (up to `max_bootstraps`), the optimizer attempts to capture a successful trace:

```mermaid
sequenceDiagram
    participant B as _bootstrap
    participant E as _bootstrap_one_example
    participant T as Teacher Program
    participant M as Metric

    B->>E: for each example, round
    E->>E: save & clear predictor demos (remove current example)
    E->>T: teacher(**example.inputs())
    T-->>E: prediction + trace
    E->>E: restore predictor demos
    E->>M: metric(example, prediction, trace)
    M-->>E: success (bool / threshold)
    alt success
        E->>E: build dspy.Example(augmented=True, **inputs, **outputs) per trace step
        E->>E: append demos to name2traces
    else failure
        E->>E: increment error_count (thread-safe)
    end
```

Key behaviors:
- **Temperature escalation**: On rounds `> 0`, the LM temperature is set to `0.7 + 0.001 * round_idx` to escape caching and encourage diversity.
- **Demo isolation**: The current example is temporarily removed from each predictor's demos during the teacher run to avoid leakage.
- **Trace capture**: Uses `dspy.settings.context(trace=[])` to collect `(predictor, inputs, outputs)` tuples.
- **Error handling**: Errors are counted under a `threading.Lock`; once `error_count >= max_errors`, the exception is re-raised.
- **Multi-trace sampling**: When a predictor produces multiple traces for one example, a deterministic 50/50 choice (seeded by `Hasher.hash`) selects between the first N-1 traces and the last trace.

After bootstrapping, examples that did **not** produce a successful trace become the `validation` set (shuffled with a fixed seed for reproducibility).

#### Step 4 — Train (`_train`)

For each student predictor, the final demo set is assembled as:

```
predictor.demos = augmented_demos[:max_bootstrapped_demos] + sampled_raw_demos
```

where `sampled_raw_demos` is drawn from the validation set, sized to fill up to `max_labeled_demos` total demos.

---

## `BootstrapFewShotWithRandomSearch`

This optimizer generates a diverse set of candidate programs and selects the best one by validation score. It is useful when the optimal number of demos is unknown.

### Candidate Generation Strategy

The `compile` method iterates over `seed` values from `-3` to `num_candidate_programs - 1`, producing distinct program variants:

| Seed | Strategy |
|------|----------|
| `-3` | **Zero-shot** — `student.reset_copy()` with no demos. |
| `-2` | **Labels only** — `LabeledFewShot` with `max_labeled_demos`. |
| `-1` | **Unshuffled few-shot** — `BootstrapFewShot` on the original trainset order. |
| `>= 0` | **Shuffled few-shot** — trainset shuffled by seed; random demo count between `min_num_samples` and `max_num_samples`. |

```mermaid
flowchart LR
    Seeds["seed in -3..N"] --> Gen["Generate candidate program"]
    Gen --> Eval["Evaluate on valset"]
    Eval --> Assert["Assertion-aware score adjustment"]
    Assert --> Track["Track best score & score_data"]
    Track --> Stop{"score >= stop_at_score?"}
    Stop -->|yes| Break["Early stop"]
    Stop -->|no| Seeds
    Break --> Attach["Attach sorted candidate_programs to best"]
```

### Assertion-Aware Scoring

After evaluation, scores are adjusted based on program assertion attributes:

```python
if hasattr(program, "_suggest_failures"):
    score = score - program._suggest_failures * 0.2
if hasattr(program, "_assert_failures"):
    score = 0 if program._assert_failures > 0 else score
```

### Output

The best program is returned with a `candidate_programs` attribute — a list of `{score, subscores, seed, program}` dicts sorted in descending score order.

### Key Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `num_candidate_programs` | `16` | Number of candidate sets to bootstrap. |
| `stop_at_score` | `None` | Early-stop threshold. |
| `metric_threshold` | `None` | Passed through to `BootstrapFewShot`. |
| `num_threads` | `None` | Threads for parallel evaluation. |
| `restrict` | `None` | Optional set of seeds to restrict the search to. |

---

## `BootstrapFewShotWithOptuna`

This optimizer uses [Optuna](https://optuna.org/) to search over **which single bootstrapped demo to keep per predictor**.

### Workflow

```mermaid
flowchart TD
    Start([compile]) --> BFS["Run BootstrapFewShot to gather all demos"]
    BFS --> Study["Create Optuna study (maximize)"]
    Study --> Obj["objective(trial):<br/>for each predictor, suggest demo_index<br/>build program2 with selected demos"]
    Obj --> Eval["Evaluate program2 on valset"]
    Eval --> Opt["study.optimize(n_trials=num_candidate_programs)"]
    Opt --> Best["Return best trial's program"]
```

The `objective` method:
1. Resets a copy of the student.
2. For each predictor, uses `trial.suggest_int` to pick a demo index from the compiled teleprompter's demos.
3. Sets the predictor's demos to the single selected demo.
4. Evaluates and stores the program in `trial.set_user_attr("program", program2)`.

The best program is retrieved from `study.trials[study.best_trial.number].user_attrs["program"]`.

> **Note**: `compile` requires a `max_demos` argument (unlike the other optimizers).

---

## `InferRules`

`InferRules` extends `BootstrapFewShot` to also **induce natural-language rules** from examples and append them to each predictor's instructions. This is useful for tasks where explicit guidance improves generalization.

### Compilation Flow

```mermaid
flowchart TD
    Start([compile]) --> Split["Split trainset into train/valset (50/50) if no valset"]
    Split --> Super["super().compile() — bootstrap demos"]
    Super --> Snapshot["Snapshot original instructions per predictor"]
    Snapshot --> Loop["For each of num_candidates:"]
    Loop --> Reset["Reset instructions to original"]
    Reset --> Induce["induce_natural_language_rules per predictor"]
    Induce --> Update["update_program_instructions (append rules)"]
    Update --> Score["evaluate_program on valset"]
    Score --> Best{"score > best_score?"}
    Best -->|yes| Keep["Keep as best_program"]
    Best -->|no| Loop
    Keep --> Loop
    Loop --> Done([return best_program])
```

### Rule Induction (`induce_natural_language_rules`)

- Formats the predictor's demos into a text block via `format_examples`.
- Calls `RulesInductionProgram` to generate rules.
- **Context-window fallback**: If the LM raises a `ValueError`, `BadRequestError`, or `ContextWindowExceededError`, it drops the last demo and retries. If only one demo remains and still fails, it raises a `RuntimeError`.

### `RulesInductionProgram`

A `dspy.Module` wrapping a `ChainOfThought` over a dynamically-defined `CustomRulesInduction` signature:

- **Input**: `examples_text` — formatted examples.
- **Output**: `natural_language_rules` — a list of `num_rules` concise, non-redundant rules.
- Uses a temperature sampled uniformly from `[0.9, 1.0]` for diversity.

### Key Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `num_candidates` | `10` | Number of candidate programs to evaluate. |
| `num_rules` | `10` | Number of rules to induce per predictor. |
| `num_threads` | `None` | Threads for parallel evaluation. |
| `teacher_settings` | `None` | Settings for the teacher model. |

---

## Dependencies and Integration

The module integrates with several other DSPy subsystems:

```mermaid
graph LR
    subgraph Bootstrap Module
        BFS["BootstrapFewShot"]
        BFSRS["BootstrapFewShotWithRandomSearch"]
        BFSO["BootstrapFewShotWithOptuna"]
        IR["InferRules"]
    end

    BFS --> Tele["Teleprompter"]
    BFS --> LFS["LabeledFewShot"]
    BFS --> Settings["dspy.settings"]
    BFS --> Example["dspy.Example"]
    BFSRS --> Eval["Evaluate"]
    BFSO --> Eval
    IR --> Eval
    IR --> CoT["ChainOfThought"]
    BFS --> Module["Module / Predict"]
```

### External Dependencies

| Dependency | Purpose | Reference |
|------------|---------|-----------|
| `Teleprompter` | Base class defining the `compile` interface. | [teleprompt_core.md](teleprompt_core.md) |
| `LabeledFewShot` | Seeds teacher/student with labeled demos. | [teleprompt_core.md](teleprompt_core.md) |
| `Evaluate` | Scores candidate programs on validation sets. | [evaluate_orchestration.md](evaluate_orchestration.md) |
| `Module` / `Predict` | The programs being optimized; provide `named_predictors`, `reset_copy`, `deepcopy`. | [primitives_module_system.md](primitives_module_system.md) |
| `Example` | Data container for demos and traces. | [primitives_data_containers.md](primitives_data_containers.md) |
| `Settings` | Global/thread-local config (`dspy.settings.context`, `trace`, `max_errors`). | [dsp_settings.md](dsp_settings.md) |
| `Signature` | Provides `equals` for structural validation and `instructions` for rule injection. | [signatures_core.md](signatures_core.md) |
| `ChainOfThought` | Used by `RulesInductionProgram` for rule generation. | [predict_strategies.md](predict_strategies.md) |

---

## Data Flow: From Trainset to Optimized Program

```mermaid
flowchart TD
    Trainset["Trainset (List[Example])"] --> Teacher["Teacher Program"]
    Teacher -->|"run per example"| Trace["Trace: (predictor, inputs, outputs)"]
    Trace -->|"metric passes"| Demo["Bootstrapped Demo<br/>Example(augmented=True)"]
    Demo --> Name2Traces["name2traces[predictor_name]"]
    Name2Traces --> Train["_train: assemble demos"]
    Trainset -->|"sampled raw demos"| Train
    Train --> Student["Student Predictors<br/>predictor.demos = augmented + raw"]
    Student --> Optimized["Optimized Program"]
```

---

## Common Patterns and Notes

- **Reproducibility**: All random operations use fixed seeds (`random.Random(0)`, seed-based shuffling) to ensure deterministic results.
- **Thread safety**: Error counting in `BootstrapFewShot` is protected by a `threading.Lock`.
- **Teacher vs. student**: The teacher generates traces; the student receives the resulting demos. They must share identical program structure and signatures.
- **Error budgets**: All optimizers respect `max_errors`, falling back to `dspy.settings.max_errors` when unset.
- **Assertion awareness**: `BootstrapFewShotWithRandomSearch` penalizes programs with `_suggest_failures` and zeroes scores for programs with `_assert_failures`.

---

## Related Modules

- [teleprompt_core.md](teleprompt_core.md) — Base `Teleprompter`, `LabeledFewShot`, and `Ensemble`.
- [teleprompt_instruction.md](teleprompt_instruction.md) — Instruction-focused optimizers (`COPRO`, `MIPROv2`, `SignatureOptimizer`).
- [teleprompt_finetune.md](teleprompt_finetune.md) — Fine-tuning-based optimizers (`BootstrapFinetune`, `GRPO`).
- [teleprompt_simba.md](teleprompt_simba.md) — `SIMBA` optimizer.
- [evaluate_orchestration.md](evaluate_orchestration.md) — The `Evaluate` class used for scoring.
- [primitives_module_system.md](primitives_module_system.md) — `Module` and `ProgramMeta`.
- [primitives_data_containers.md](primitives_data_containers.md) — `Example` and `Prediction`.
- [dsp_settings.md](dsp_settings.md) — Global configuration and context management.
