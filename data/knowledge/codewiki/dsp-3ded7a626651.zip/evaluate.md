# Evaluate Module

## Overview

The `evaluate` module provides the core evaluation infrastructure for DSPy programs. It allows developers to measure the performance of a DSPy program (a `dspy.Module`) against a labeled development set using a user-supplied metric function. In addition, it ships a collection of **automatic, LLM-based evaluation metrics** that can score free-form natural-language responses without hand-written ground-truth labels.

The module is composed of two primary concerns:

1. **Program evaluation orchestration** — running a program over a dataset in parallel, applying a metric, aggregating scores, and optionally rendering results as a table.
2. **Automatic evaluation metrics** — reusable `dspy.Module` / `dspy.Signature` implementations that use an LLM to judge semantic quality (recall, precision, F1, completeness, groundedness).

## Architecture

```mermaid
graph TD
    subgraph evaluate["evaluate module"]
        E["Evaluate<br/>(evaluate.py)"]
        AE["Auto-Evaluation Metrics<br/>(auto_evaluation.py)"]
    end

    E -->|"uses"| PE["ParallelExecutor<br/>(utils/parallelizer.py)"]
    E -->|"uses"| CB["with_callbacks<br/>(utils/callback.py)"]
    E -->|"consumes"| EX["Example<br/>(primitives/example.py)"]
    E -->|"produces"| PR["Prediction<br/>(primitives/prediction.py)"]

    AE -->|"built on"| SIG["Signature<br/>(signatures/signature.py)"]
    AE -->|"built on"| COT["ChainOfThought<br/>(predict/chain_of_thought.py)"]
    AE -->|"built on"| MOD["Module<br/>(primitives/module.py)"]

    E -.->|"metric can be"| AE
```

The `Evaluate` class is the entry point for running evaluations, while the auto-evaluation metrics are typically passed to `Evaluate` as the `metric` argument (or used standalone as DSPy modules).

## Sub-modules

### 1. Evaluation Orchestration (`Evaluate`)

The [`Evaluate`](evaluate_orchestration.md) class is the central component of this module. It:

- Accepts a development set (`List[dspy.Example]`) and a metric callable.
- Runs the target program over every example using a thread pool (`ParallelExecutor`) for parallel evaluation.
- Applies the metric to each `(example, prediction)` pair and aggregates the results into an average score.
- Supports configurable error tolerance (`max_errors`), failure scoring, progress bars, and result-table rendering.
- Returns results in several formats depending on `return_all_scores` / `return_outputs` flags.

See [evaluate_orchestration.md](evaluate_orchestration.md) for full details.

### 2. Automatic Evaluation Metrics

The [`auto_evaluation`](evaluate_auto_metrics.md) sub-module provides LLM-judged metrics for open-ended generation tasks:

- **`SemanticF1`** — computes an F1 score over semantic recall and precision between a system response and ground truth.
- **`CompleteAndGrounded`** — combines answer completeness (vs. ground truth) and groundedness (vs. retrieved context) into an F1 score.
- Supporting `dspy.Signature` definitions: `SemanticRecallPrecision`, `DecompositionalSemanticRecallPrecision`, `AnswerCompleteness`, `AnswerGroundedness`.

See [evaluate_auto_metrics.md](evaluate_auto_metrics.md) for full details.

## Data Flow

```mermaid
sequenceDiagram
    participant User
    participant Evaluate
    participant ParallelExecutor
    participant Program as dspy.Module
    participant Metric

    User->>Evaluate: __call__(program, metric, devset)
    Evaluate->>ParallelExecutor: execute(process_item, devset)
    loop for each example (parallel)
        ParallelExecutor->>Program: program(**example.inputs())
        Program-->>ParallelExecutor: prediction
        ParallelExecutor->>Metric: metric(example, prediction)
        Metric-->>ParallelExecutor: score
    end
    ParallelExecutor-->>Evaluate: results
    Evaluate->>Evaluate: aggregate average score
    Evaluate-->>User: score (+ optional scores/outputs/table)
```

## Relationship to Other Modules

- **`primitives`** — `Evaluate` operates on [`Example`](primitives.md) inputs and [`Prediction`](primitives.md) outputs. Auto-evaluation metrics are `dspy.Module` subclasses.
- **`predict`** — Auto-evaluation metrics are built on [`ChainOfThought`](predict.md) to elicit reasoning before scoring.
- **`signatures`** — Auto-evaluation metrics are defined as [`Signature`](signatures.md) classes.
- **`utils`** — `Evaluate` relies on [`ParallelExecutor`](utils.md) for concurrency and [`with_callbacks`](utils.md) for callback integration.
- **`teleprompt`** — Optimizers frequently use `Evaluate` (or its metric functions) to score candidate programs during optimization.

## Key Design Notes

- **Parallelism & isolation**: Each evaluation task runs in its own thread with thread-local `dspy.settings` overrides, so per-example state (e.g., usage tracking) does not leak between examples.
- **Error resilience**: Exceptions raised by the program or metric are caught by `ParallelExecutor`; failed examples receive `failure_score` and evaluation continues until `max_errors` is exceeded.
- **Metric flexibility**: A metric is any callable `(example, prediction) -> score`. It may be a plain function or a DSPy module such as `SemanticF1`.
