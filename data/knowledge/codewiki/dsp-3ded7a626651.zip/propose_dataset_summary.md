# Propose Dataset Summary

## Introduction

The **Propose Dataset Summary** module (`dspy/propose/dataset_summary_generator.py`) is responsible for automatically generating a concise, natural-language summary of a training dataset. This summary captures the most salient trends, topics, and characteristics that hold across the dataset's examples, and is used downstream to inform instruction generation for prompt optimization.

The module is a key building block of the [Grounded Proposer](propose_grounded.md) pipeline. When the `GroundedProposer` is configured with `use_dataset_summary=True`, it invokes `create_dataset_summary(...)` to produce a "data summary" string that is later injected into instruction-generation prompts, making the proposer *data-aware*.

The module is built entirely on top of DSPy's declarative [Signature](signatures.md) abstraction and the [Predict](predict_core.md) module, meaning it requires no custom model-calling logic — it simply defines the *shape* of the reasoning task and lets DSPy handle execution.

---

## Core Components

The module defines three DSPy `Signature` classes and one orchestration function.

| Component | Kind | Purpose |
|-----------|------|---------|
| `DatasetDescriptor` | `dspy.Signature` | Produce initial observations from a batch of dataset examples. |
| `DatasetDescriptorWithPriorObservations` | `dspy.Signature` | Extend existing observations with new ones, or signal `COMPLETE`. |
| `ObservationSummarizer` | `dspy.Signature` | Condense all accumulated observations into a 2–3 sentence summary. |
| `create_dataset_summary` | function | Orchestrates the iterative observation/summarization loop. |
| `order_input_keys_in_string` | helper | Normalizes the string representation of examples for stable prompting. |

---

## Architecture

The module follows a **map-reduce style** pattern over the dataset:

1. **Map phase** — Iterate over batches of examples, generating observations for each batch (conditioned on prior observations).
2. **Reduce phase** — Summarize all accumulated observations into a single concise summary.

```mermaid
flowchart TD
    subgraph Input
        TS[trainset]
        BS[view_data_batch_size]
        PM[prompt_model]
    end

    TS --> OIK[order_input_keys_in_string]
    OIK --> DD[DatasetDescriptor<br/>Predict]
    DD -->|initial observations| LOOP

    subgraph LOOP[Iterative Observation Loop]
        DDPO[DatasetDescriptorWithPriorObservations<br/>Predict]
        DDPO -->|new observations| ACC[Accumulate observations]
        ACC -->|COMPLETE x5| STOP[Stop early]
        ACC -->|else| DDPO
    end

    LOOP --> OS[ObservationSummarizer<br/>Predict]
    OS --> SP[strip_prefix]
    SP --> OUT[dataset summary string]
```

---

## Component Details

### `DatasetDescriptor`

A `dspy.Signature` that takes a batch of dataset examples and produces free-form observations about trends that hold for most or all samples.

- **Inputs:** `examples` — sample data points from the dataset.
- **Outputs:** `observations` — statements that hold true for most/all of the observed data.

The instructions explicitly encourage the model to consider *topics, content, syntax, conciseness*, and to make an educated guess about the nature of the task the dataset enables.

### `DatasetDescriptorWithPriorObservations`

An extension of `DatasetDescriptor` used for subsequent batches. It receives both the new batch of examples **and** the observations accumulated so far.

- **Inputs:** `examples`, `prior_observations`.
- **Outputs:** `observations` — new observations, or the literal token `COMPLETE` if nothing meaningful can be added.

The `COMPLETE` sentinel is the mechanism that allows the loop to terminate early once the dataset has been sufficiently characterized.

### `ObservationSummarizer`

A `dspy.Signature` that performs the reduce step.

- **Inputs:** `observations` — the full concatenation of all observations gathered.
- **Outputs:** `summary` — a 2–3 sentence summary highlighting only the most significant details.

### `create_dataset_summary`

The orchestration function. Its signature is:

```python
def create_dataset_summary(trainset, view_data_batch_size, prompt_model, log_file=None, verbose=False):
```

**Behavior:**

1. Resolves the prompt model, falling back to `dspy.settings.lm` if none is provided.
2. Runs `DatasetDescriptor` on the first batch (`trainset[0:upper_lim]`) to seed the observations.
3. Iterates over remaining batches (up to a hard cap of `max_calls = 10`), calling `DatasetDescriptorWithPriorObservations` for each.
4. Accumulates observations, breaking early when `COMPLETE` is returned **5 consecutive times** (`skips >= 5`).
5. Wraps the loop in a `try/except` so that any failure gracefully falls back to the observations gathered so far.
6. Runs `ObservationSummarizer` over the accumulated observations.
7. Returns `strip_prefix(summary.summary)` — a cleaned summary string.

**Parameters:**

| Parameter | Description |
|-----------|-------------|
| `trainset` | The dataset (list of `Example`s) to summarize. |
| `view_data_batch_size` | Number of examples shown to the model per batch. |
| `prompt_model` | The LM used for all internal `Predict` calls. Falls back to `dspy.settings.lm`. |
| `log_file` | Optional file handle for writing intermediate observations and the final summary. |
| `verbose` | If `True`, prints progress and the generated summary. |

### `order_input_keys_in_string`

A helper that uses a regex to find `input_keys={...}` substrings within an example's `repr()` and sorts the keys alphabetically. This ensures the string representation of examples is **deterministic**, which is important for prompt stability and caching.

---

## Data Flow

The following sequence diagram shows the interaction between the orchestration function, the DSPy `Predict` module, and the three signatures.

```mermaid
sequenceDiagram
    participant Caller as GroundedProposer
    participant Fn as create_dataset_summary
    participant P as dspy.Predict
    participant LM as prompt_model

    Caller->>Fn: create_dataset_summary(trainset, batch_size, model)
    Fn->>P: Predict(DatasetDescriptor)(examples=batch0)
    P->>LM: LM call
    LM-->>P: observations
    P-->>Fn: initial observations

    loop over remaining batches (max 10)
        Fn->>P: Predict(DatasetDescriptorWithPriorObservations)(prior, examples)
        P->>LM: LM call
        LM-->>P: observations or COMPLETE
        P-->>Fn: append / skip
    end

    Fn->>P: Predict(ObservationSummarizer)(observations)
    P->>LM: LM call
    LM-->>P: summary
    P-->>Fn: summary
    Fn->>Fn: strip_prefix(summary)
    Fn-->>Caller: dataset summary string
```

---

## Integration with the Grounded Proposer

The module is consumed by [`GroundedProposer`](propose_grounded.md). During its construction, when `use_dataset_summary=True`, the proposer calls `create_dataset_summary` and stores the result in `self.data_summary`:

```python
self.data_summary = None
if self.use_dataset_summary:
    try:
        self.data_summary = create_dataset_summary(
            trainset=trainset,
            view_data_batch_size=view_data_batch_size,
            prompt_model=prompt_model,
        )
    except Exception as e:
        print(f"Error getting data summary: {e}.\n\nRunning without data aware proposer.")
        self.use_dataset_summary = False
```

The resulting `data_summary` is then passed into `GenerateModuleInstruction.forward(...)` as the `data_summary` argument, where it grounds the generated instructions in the actual characteristics of the training data.

```mermaid
flowchart LR
    GP[GroundedProposer.__init__] -->|use_dataset_summary=True| CDS[create_dataset_summary]
    CDS --> DS[data_summary string]
    DS --> GMI[GenerateModuleInstruction.forward]
    GMI --> INST[proposed instruction]
```

> **Note:** If `create_dataset_summary` raises an exception, the proposer degrades gracefully by setting `use_dataset_summary = False` and continuing without data awareness.

---

## Dependencies

```mermaid
flowchart TD
    subgraph Module[dspy/propose/dataset_summary_generator.py]
        DD[DatasetDescriptor]
        DDPO[DatasetDescriptorWithPriorObservations]
        OS[ObservationSummarizer]
        CDS[create_dataset_summary]
        OIK[order_input_keys_in_string]
    end

    DD --> SIG[Signature]
    DDPO --> SIG
    OS --> SIG
    CDS --> PRED[Predict]
    CDS --> SET[Settings.context]
    CDS --> SP[strip_prefix]
    OIK --> RE[re]
```

| Dependency | Role |
|------------|------|
| [`dspy.Signature`](signatures.md) | Declarative task definitions for the three signatures. |
| [`dspy.Predict`](predict_core.md) | Executes each signature against the configured LM. |
| [`dspy.settings`](dsp_settings.md) | Provides the default LM and the `context(lm=...)` override used to pin the prompt model. |
| `dspy.propose.utils.strip_prefix` | Cleans leading prefixes (e.g., `"Summary:"`) from model output. |
| `re` | Used by `order_input_keys_in_string` for deterministic example formatting. |

---

## Error Handling & Robustness

- **Model fallback:** If `prompt_model` is `None`, the module uses `dspy.settings.lm`.
- **Loop cap:** The observation loop is bounded by `max_calls = 10` to prevent runaway LM usage.
- **Early termination:** Five consecutive `COMPLETE` responses stop the loop.
- **Exception safety:** The entire observation loop is wrapped in `try/except`; on failure, the module proceeds to summarize whatever observations were collected so far.
- **Deterministic formatting:** `order_input_keys_in_string` sorts input keys to stabilize prompts.

---

## Related Documentation

- [Grounded Proposer](propose_grounded.md) — the primary consumer of this module.
- [Proposer Base](propose_grounded.md) — the abstract base class for proposers.
- [Signatures](signatures.md) — the declarative signature system used here.
- [Predict](predict_core.md) — the module that executes signatures.
- [Settings](dsp_settings.md) — global/thread-local configuration and LM resolution.
