# Utils: Logging & Exceptions

## Introduction

The `utils_logging_exceptions` module provides two cross-cutting infrastructure concerns for DSPy:

1. **Logging** (`dspy/utils/logging_utils.py`) — A controllable, redirectable logging stream (`DSPyLoggingStream`) that lets DSPy emit event logs to `sys.stderr` while allowing users to globally silence or re-enable those logs. It also provides a helper (`configure_dspy_loggers`) to wire a consistent log format into the DSPy root logger.

2. **Exceptions** (`dspy/utils/exceptions.py`) — A specialized exception type (`AdapterParseError`) raised when an [Adapter](adapters_core.md) fails to parse an LM response into the output fields declared by a [Signature](signatures_core.md).

These utilities are intentionally small and dependency-light. They are consumed throughout the framework — logging by nearly every component that emits diagnostics, and `AdapterParseError` by the adapter layer during response parsing.

---

## Module Architecture

```mermaid
graph TD
    subgraph "utils_logging_exceptions"
        LS["DSPyLoggingStream<br/>(logging_utils.py)"]
        GLS["DSPY_LOGGING_STREAM<br/>(module-level singleton)"]
        DL["disable_logging()"]
        EL["enable_logging()"]
        CDL["configure_dspy_loggers()"]
        APE["AdapterParseError<br/>(exceptions.py)"]
    end

    GLS --> LS
    DL --> GLS
    EL --> GLS
    CDL --> GLS
    CDL -->|"StreamHandler(stream=...)"| LS

    APE -.->|"references"| SIG["Signature<br/>(signatures_core.md)"]
    APE -.->|"raised by"| ADAPTER["Adapter.parse()<br/>(adapters_core.md)"]
```

---

## Logging Utilities

### `DSPyLoggingStream`

A thin wrapper around `sys.stderr` used as the destination for DSPy event logs (e.g. `eprint()`, `logger.info()`). Its key design property is **late binding**: `write()` and `flush()` forward to whatever `sys.stderr` refers to *at the time of the call*, rather than capturing a reference at construction time. This makes it safe to use with test harnesses and tools that swap out `sys.stderr` (e.g. `pytest`'s capture, `contextlib.redirect_stderr`).

| Member | Type | Description |
| --- | --- | --- |
| `__init__()` | method | Initializes the stream in the enabled state (`self._enabled = True`). |
| `write(text)` | method | Forwards `text` to `sys.stderr.write()` when enabled; otherwise a no-op. |
| `flush()` | method | Forwards to `sys.stderr.flush()` when enabled; otherwise a no-op. |
| `enabled` | property | Getter/setter controlling whether the stream emits output. |

### Module-level singleton: `DSPY_LOGGING_STREAM`

A single shared `DSPyLoggingStream` instance created at import time. All DSPy logging flows through this object, which is why toggling its `enabled` flag affects the entire framework.

### `disable_logging()` / `enable_logging()`

Convenience functions that flip `DSPY_LOGGING_STREAM.enabled` to `False` / `True` respectively. They are the public API for globally silencing or restoring DSPy event logs.

```mermaid
stateDiagram-v2
    [*] --> Enabled: import (default)
    Enabled --> Disabled: disable_logging()
    Disabled --> Enabled: enable_logging()
    Enabled --> Enabled: write()/flush() forwarded to sys.stderr
    Disabled --> Disabled: write()/flush() suppressed
```

### `configure_dspy_loggers(root_module_name)`

Configures a `logging.Logger` for the given root module name so that DSPy logs are emitted with a consistent format and routed through `DSPY_LOGGING_STREAM`.

Behavior:
- Builds a `logging.Formatter` using `LOGGING_LINE_FORMAT` and `LOGGING_DATETIME_FORMAT`.
- Creates a `logging.StreamHandler` bound to `DSPY_LOGGING_STREAM`, names it `"dspy_handler"`, and attaches the formatter.
- Sets the logger level to `INFO` and disables propagation (`propagate = False`) to avoid duplicate output via ancestor loggers.
- **Idempotency:** removes any pre-existing handler named `"dspy_handler"` before adding the new one, so repeated calls do not stack handlers.

#### Format constants

| Constant | Value |
| --- | --- |
| `LOGGING_LINE_FORMAT` | `"%(asctime)s %(levelname)s %(name)s: %(message)s"` |
| `LOGGING_DATETIME_FORMAT` | `"%Y/%m/%d %H:%M:%S"` |

#### Logging configuration flow

```mermaid
sequenceDiagram
    participant Caller
    participant CDL as configure_dspy_loggers
    participant Logger as logging.Logger
    participant Handler as StreamHandler
    participant Stream as DSPY_LOGGING_STREAM

    Caller->>CDL: configure_dspy_loggers("dspy")
    CDL->>CDL: build Formatter(fmt, datefmt)
    CDL->>Handler: StreamHandler(stream=DSPY_LOGGING_STREAM)
    CDL->>Handler: setFormatter / set_name("dspy_handler")
    CDL->>Logger: getLogger("dspy")
    CDL->>Logger: setLevel(INFO), propagate=False
    CDL->>Logger: remove existing "dspy_handler" (if any)
    CDL->>Logger: addHandler(handler)
    Note over Stream: Later log records flow<br/>Logger -> Handler -> Stream -> sys.stderr
```

---

## Exceptions

### `AdapterParseError`

An `Exception` subclass raised when an [Adapter](adapters_core.md) cannot parse an LM response into the output fields declared by a [Signature](signatures_core.md). It captures rich diagnostic context to help users debug malformed or unexpected model output.

#### Constructor parameters

| Parameter | Type | Description |
| --- | --- | --- |
| `adapter_name` | `str` | Name of the adapter that failed (e.g. `"ChatAdapter"`, `"JSONAdapter"`). |
| `signature` | `Signature` | The signature whose output fields were expected. |
| `lm_response` | `str` | The raw LM response that could not be parsed. |
| `message` | `Optional[str]` | Optional custom prefix message prepended to the generated message. |
| `parsed_result` | `Optional[str]` | Optional dict of fields actually parsed, included in the message when provided. |

#### Stored attributes

`adapter_name`, `signature`, `lm_response`, and `parsed_result` are all stored on the instance for programmatic inspection.

#### Generated message

The exception builds a human-readable message that includes:
- The optional custom `message` prefix (followed by a blank line).
- The adapter name and a statement that parsing failed.
- The raw LM response.
- The list of **expected** output fields (from `signature.output_fields.keys()`).
- When `parsed_result` is provided, the list of **actually parsed** output fields.

```mermaid
flowchart TD
    A["Adapter.parse(signature, completion)"] --> B{"Parsing succeeds?"}
    B -->|Yes| C["Return dict of output fields"]
    B -->|No| D["Raise AdapterParseError"]
    D --> E["Message includes:<br/>- custom prefix (optional)<br/>- adapter name<br/>- raw LM response<br/>- expected output fields<br/>- parsed fields (optional)"]
```

---

## How the Module Fits into DSPy

```mermaid
graph LR
    subgraph "Cross-cutting utilities"
        LOG["DSPyLoggingStream / logging helpers"]
        EXC["AdapterParseError"]
    end

    subgraph "Consumers"
        ADAPTERS["Adapters<br/>(adapters_core.md)"]
        SIGS["Signatures<br/>(signatures_core.md)"]
        CALLBACKS["Callbacks<br/>(utils_callbacks.md)"]
        EVERY["All DSPy components<br/>emitting event logs"]
    end

    ADAPTERS -->|"raise on parse failure"| EXC
    EXC -->|"reads output_fields"| SIGS
    EVERY -->|"write()/flush()"| LOG
    CALLBACKS -.->|"diagnostic output"| LOG
```

- **Adapters** raise `AdapterParseError` from their `parse()` method when the LM response does not conform to the expected output structure. See [adapters_core.md](adapters_core.md) for the adapter lifecycle.
- **Signatures** supply the `output_fields` used to build the error message. See [signatures_core.md](signatures_core.md).
- **All components** that emit event logs route them through `DSPY_LOGGING_STREAM`, making `disable_logging()` / `enable_logging()` a global switch. Callback-based diagnostics are described in [utils_callbacks.md](utils_callbacks.md).

---

## Usage Examples

### Silencing and restoring DSPy logs

```python
from dspy.utils.logging_utils import disable_logging, enable_logging

disable_logging()   # suppress all subsequent DSPy event logs
# ... run noisy operations ...
enable_logging()    # restore logging
```

### Configuring the DSPy logger

```python
from dspy.utils.logging_utils import configure_dspy_loggers

configure_dspy_loggers("dspy")
# Logs now use the format:
# 2024/01/01 12:00:00 INFO dspy: <message>
```

### Catching a parse failure

```python
from dspy.utils.exceptions import AdapterParseError

try:
    result = adapter.parse(signature, lm_response)
except AdapterParseError as e:
    print(e.adapter_name)     # e.g. "ChatAdapter"
    print(e.lm_response)      # raw model output
    print(e.parsed_result)    # fields that were parsed, if any
```

---

## Related Modules

- [adapters_core.md](adapters_core.md) — Adapters that raise `AdapterParseError`.
- [signatures_core.md](signatures_core.md) — Signatures whose output fields are referenced in error messages.
- [utils_callbacks.md](utils_callbacks.md) — Callback system that may emit diagnostic output through the logging stream.
