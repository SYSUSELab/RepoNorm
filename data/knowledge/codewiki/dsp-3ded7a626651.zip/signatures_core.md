# Signatures Core

## Introduction

The **signatures_core** module provides the foundational abstraction for defining the input/output contract of a DSPy program. A *Signature* declares what a language-model-backed module takes as input and what it must produce as output, along with natural-language instructions that guide the model. It is the declarative "interface" that separates *what* a module should do from *how* it is executed.

This module is centered on two components in `dspy/signatures/signature.py`:

- **`Signature`** — the base class (and factory) that users subclass or construct dynamically to declare fields and instructions.
- **`SignatureMeta`** — the metaclass that powers the ergonomic behaviors of `Signature` (field ordering, default instructions, prefix inference, dynamic construction, and validation).

Together they build on top of Pydantic's `BaseModel` and integrate tightly with the field definitions in the [signatures_fields](signatures_fields.md) module (`InputField` / `OutputField`).

---

## Purpose and Core Functionality

A Signature answers three questions about a module:

1. **What are the inputs?** — declared via `InputField`.
2. **What are the outputs?** — declared via `OutputField`.
3. **What should the model do?** — expressed as natural-language *instructions* (the class docstring).

The module supports two equivalent authoring styles:

```python
# 1. Class-based (recommended)
class MySignature(dspy.Signature):
    """Answer the question given the context."""
    question: str = dspy.InputField(desc="The question to answer")
    context: list[str] = dspy.InputField(desc="Supporting passages")
    answer: int = dspy.OutputField(desc="The numeric answer")

# 2. String-based (dynamic)
sig = dspy.Signature("question, context -> answer")
```

Both styles ultimately produce a Pydantic model subclass of `Signature` with validated, ordered fields.

---

## Architecture

The module sits at the base of the DSPy type system. `Signature` is a Pydantic `BaseModel` whose behavior is customized by `SignatureMeta`. Field metadata is supplied by `InputField`/`OutputField` from the sibling `signatures_fields` module.

```mermaid
graph TD
    subgraph signatures_core["signatures_core (this module)"]
        Signature["Signature (BaseModel)"]
        SignatureMeta["SignatureMeta (metaclass)"]
    end

    subgraph signatures_fields["signatures_fields"]
        InputField["InputField"]
        OutputField["OutputField"]
        OldField["OldField / OldInputField / OldOutputField"]
    end

    Pydantic["pydantic.BaseModel"]
    FieldInfo["pydantic.fields.FieldInfo"]

    SignatureMeta -->|metaclass of| Signature
    Signature -->|inherits| Pydantic
    InputField -->|subclass of| FieldInfo
    OutputField -->|subclass of| FieldInfo
    OldField -->|legacy| FieldInfo

    Signature -.->|uses| InputField
    Signature -.->|uses| OutputField
    SignatureMeta -.->|reads| FieldInfo
```

### Component Responsibilities

| Component | Responsibility |
|-----------|----------------|
| `Signature` | Declares fields + instructions; provides class-level helpers (`with_instructions`, `insert`, `append`, `prepend`, `delete`, `equals`, `dump_state`, `load_state`). |
| `SignatureMeta` | Metaclass controlling class creation: field ordering, default instructions, prefix/desc inference, field validation, and dynamic construction via `__call__`. |
| Module-level helpers | `make_signature`, `ensure_signature`, `_parse_signature`, `_parse_field_string`, `_parse_type_node`, `infer_prefix`, `_default_instructions`. |

---

## SignatureMeta: The Metaclass

`SignatureMeta` extends `type(BaseModel)` and is responsible for the "magic" that makes Signatures ergonomic.

### Dynamic Construction (`__call__`)

When `Signature(...)` is invoked directly (rather than subclassed), the metaclass intercepts the call and delegates to `make_signature`. This enables the string-based syntax:

```python
Signature("input1, input2 -> output1, output2")
Signature("input -> output", "This is a test")
```

If the first argument is a string and no `custom_types` are supplied, it attempts to auto-detect custom types from the caller's frame via `_detect_custom_types_from_caller`.

### Class Creation (`__new__`)

During subclass creation, `SignatureMeta.__new__` performs several normalization steps:

1. **Field ordering** — collects fields in declaration order and rebuilds `__annotations__` to preserve it.
2. **Default type** — any field without an explicit annotation defaults to `str`.
3. **Instruction inheritance** — if no docstring is present, inherits from a base `Signature` subclass; otherwise falls back to `_default_instructions`.
4. **Field validation** — `_validate_fields` ensures every field is declared with `InputField` or `OutputField`.
5. **Prefix/desc inference** — fills in `prefix` (via `infer_prefix`) and `desc` defaults for any field missing them.

### Properties

| Property | Description |
|----------|-------------|
| `instructions` | Getter/setter for the cleaned docstring. |
| `input_fields` | Dict of fields with `__dspy_field_type == "input"`. |
| `output_fields` | Dict of fields with `__dspy_field_type == "output"`. |
| `fields` | Combined dict, inputs first then outputs. |
| `signature` | String form, e.g. `"question, context -> answer"`. |

---

## Signature: The Base Class

`Signature` is a `BaseModel` with `SignatureMeta` as its metaclass. It intentionally has an empty docstring so that subclasses without instructions fall back to the generated default.

### Class Methods

```mermaid
classDiagram
    class Signature {
        +with_instructions(instructions) Signature
        +with_updated_fields(name, type_, **kwargs) Signature
        +prepend(name, field, type_) Signature
        +append(name, field, type_) Signature
        +delete(name) Signature
        +insert(index, name, field, type_) Signature
        +equals(other) bool
        +dump_state() dict
        +load_state(state) Signature
    }
```

| Method | Purpose |
|--------|---------|
| `with_instructions(instructions)` | Returns a new Signature with replaced instructions. |
| `with_updated_fields(name, type_, **kwargs)` | Returns a new Signature with a field's metadata/type updated. |
| `prepend` / `append` / `insert` | Return a new Signature with a field added at a position. |
| `delete(name)` | Returns a new Signature with a field removed. |
| `equals(other)` | Compares instructions and field JSON schemas. |
| `dump_state()` / `load_state(state)` | Serialize/deserialize instructions and field prefixes/descriptions. |

All mutating helpers are **immutable** — they return new Signature classes rather than modifying in place.

---

## Dynamic Signature Construction Flow

The following diagram traces how a string-based signature becomes a concrete Pydantic model.

```mermaid
sequenceDiagram
    participant User
    participant Meta as SignatureMeta.__call__
    participant Make as make_signature
    participant Parse as _parse_signature
    participant AST as _parse_field_string / _parse_type_node
    participant Pyd as create_model

    User->>Meta: Signature("q: str, ctx: list[str] -> a: int")
    Meta->>Meta: _detect_custom_types_from_caller (optional)
    Meta->>Make: make_signature(signature, custom_types=...)
    Make->>Parse: _parse_signature(signature, names)
    Parse->>AST: parse inputs & outputs
    AST-->>Parse: {name: (type, FieldInfo)}
    Parse-->>Make: fields dict
    Make->>Make: validate & fix fields
    Make->>Pyd: create_model(base=Signature, __doc__=instructions, **fields)
    Pyd-->>User: new Signature subclass
```

### Type Parsing

`_parse_field_string` uses Python's `ast` module to parse the field string (e.g. `"x: int, y: str"`). `_parse_type_node` recursively resolves AST nodes into real Python types, handling:

- Simple names (`int`, `str`) via `resolve_name`
- Attribute access (`typing.List`, `MyModule.CustomType`)
- Subscripts / generics (`List[int]`, `Optional[int]`, `Union[...]`)
- Tuples and constants
- `Field(...)` calls

Unknown names raise a `ValueError` with guidance to use class-based Signatures.

---

## Helper Functions

| Function | Description |
|----------|-------------|
| `make_signature(signature, instructions, signature_name, custom_types)` | Core factory that builds a `Signature` subclass from a string or dict. |
| `ensure_signature(signature, instructions)` | Normalizes `None`/`str`/`Signature` inputs into a Signature class. |
| `_parse_signature(signature, names)` | Splits on `->` and builds the field dict. |
| `_parse_field_string(field_string, names)` | Parses a comma-separated field string via AST. |
| `_parse_type_node(node, names)` | Recursively converts AST nodes to Python types. |
| `infer_prefix(attribute_name)` | Converts field names to human-readable prefixes (e.g. `camelCase` → `Camel Case`). |
| `_default_instructions(cls)` | Generates default instructions from input/output field names. |

### Prefix Inference Examples

`infer_prefix` handles camelCase, snake_case, numbers, and acronyms:

| Input | Output |
|-------|--------|
| `camelCaseText` | `Camel Case Text` |
| `snake_case_text` | `Snake Case Text` |
| `text2number` | `Text 2 Number` |
| `HTMLParser` | `HTML Parser` |

---

## Relationship to Other Modules

```mermaid
graph LR
    signatures_core["signatures_core"]
    signatures_fields["signatures_fields"]
    predict_core["predict_core"]
    primitives_data["primitives_data_containers"]
    adapters_core["adapters_core"]
    teleprompt["teleprompt"]

    signatures_core -->|uses InputField/OutputField| signatures_fields
    predict_core -->|declares signatures| signatures_core
    primitives_data -->|Example fields mirror Signature fields| signatures_core
    adapters_core -->|renders fields & instructions| signatures_core
    teleprompt -->|optimizes instructions/fields| signatures_core
```

- **[signatures_fields](signatures_fields.md)** — supplies `InputField`/`OutputField` (and legacy `OldField` variants) used to declare fields.
- **[predict_core](predict_core.md)** — `Predict` consumes a Signature to know its inputs/outputs and instructions.
- **[primitives_data_containers](primitives_data_containers.md)** — `Example` objects carry data keyed by the field names declared in a Signature.
- **[adapters_core](adapters_core.md)** — adapters render Signature fields and instructions into model-specific prompts.
- **[teleprompt](teleprompt.md)** — optimizers mutate instructions and field descriptions via `with_instructions` / `with_updated_fields`.

---

## State Serialization

Signatures support round-tripping their mutable state (instructions and per-field prefix/description) for persistence and optimization:

```mermaid
flowchart LR
    A[Signature class] -->|dump_state| B["{instructions, fields:[{prefix, description}]}"]
    B -->|load_state| C[New Signature class]
    C -->|equals| A
```

`dump_state` captures only the fields that optimizers typically modify, while `load_state` reconstructs a copy with those values applied.

---

## Key Design Notes

- **Immutability** — All field/instruction modification helpers return new classes, supporting functional composition in optimizers.
- **Pydantic integration** — Signatures are real Pydantic models, so validation, JSON schema generation, and type coercion come for free.
- **Field ordering matters** — Input fields always precede output fields in `fields`, `signature`, and serialized state.
- **Frame introspection caveat** — `_detect_custom_types_from_caller` relies on Python frame inspection, which may fail under optimized interpreters; prefer explicit `custom_types` for reliability.
- **Legacy compatibility** — The `OldField`/`OldInputField`/`OldOutputField` classes in [signatures_fields](signatures_fields.md) provide backward compatibility with the legacy `dsp` format.
