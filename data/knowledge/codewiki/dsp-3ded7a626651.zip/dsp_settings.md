# DSP Settings Module

## Introduction

The `dsp_settings` module provides the **global configuration system** for DSPy. It exposes a thread-safe singleton (`settings`) that holds all runtime configuration — the active language model, adapter, retrieval model, callbacks, streaming listeners, usage tracking, and various behavioral flags.

The module is the central "control panel" that every other DSPy subsystem reads from. Rather than threading configuration through every function call, DSPy components consult `dspy.settings` (or `dspy.dsp.utils.settings.settings`) to discover the currently active LM, adapter, and behavioral options.

The core component is:

| Component | File | Role |
|-----------|------|------|
| `Settings` | `dspy/dsp/utils/settings.py` | Singleton configuration holder with global + thread-local state |

---

## Purpose and Core Functionality

The `Settings` class solves three distinct problems:

1. **Global configuration** — A single place to register the active LM, adapter, RM, and callbacks via `dspy.configure(...)`.
2. **Thread-local overrides** — Temporary, scoped configuration changes via `dspy.context(...)` that do not mutate global state.
3. **Thread-safety and ownership** — Only one "owner" thread may mutate the global configuration, preventing race conditions in multi-threaded programs.

### Key Design Principles

- **Singleton pattern** — `Settings.__new__` guarantees a single instance across the process.
- **Attribute-style access** — `settings.lm`, `settings.adapter`, etc., are resolved dynamically through `__getattr__`.
- **Layered resolution** — Thread-local overrides take precedence over global config.
- **Context propagation** — Overrides propagate to child threads spawned by DSPy primitives (e.g., `ParallelExecutor`).

---

## Architecture

The module is built around a layered configuration model with three tiers of state.

```mermaid
graph TD
    subgraph "Settings Singleton"
        S[settings instance]
    end

    subgraph "State Layers"
        D[DEFAULT_CONFIG<br/>dotdict of defaults]
        M[main_thread_config<br/>global mutable state]
        T[thread_local_overrides<br/>ContextVar]
    end

    subgraph "Access API"
        GA[__getattr__ / __getitem__]
        SA[__setattr__ / __setitem__]
        CFG[configure]
        CTX[context]
        CP[copy / config]
    end

    S --> GA
    S --> SA
    S --> CFG
    S --> CTX
    S --> CP

    GA --> T
    GA --> M
    SA --> CFG
    CFG --> M
    CTX --> T
    CP --> M
    CP --> T

    D -.->|deepcopy at init| M
```

### State Layers Explained

| Layer | Type | Scope | Mutability |
|-------|------|-------|------------|
| `DEFAULT_CONFIG` | `dotdict` | Module-level constant | Immutable template |
| `main_thread_config` | `dotdict` | Process-global | Mutated only by owner thread via `configure` |
| `thread_local_overrides` | `contextvars.ContextVar` | Per-thread / per-async-context | Mutated via `context` |

---

## Component Reference

### `Settings` Class

The singleton class. All access goes through the module-level `settings = Settings()` instance.

#### Attribute Access (`__getattr__`)

Resolution order when reading `settings.<name>`:

```mermaid
flowchart TD
    A[settings.name] --> B{name in<br/>thread_local_overrides?}
    B -->|Yes| C[Return override value]
    B -->|No| D{name in<br/>main_thread_config?}
    D -->|Yes| E[Return global value]
    D -->|No| F[Raise AttributeError]
```

#### Attribute Assignment (`__setattr__`)

Setting `settings.<name> = value` is routed through `configure(**{name: value})`, so it is subject to the same ownership rules as an explicit `configure` call. The only exception is the internal `_instance` attribute.

#### `configure(**kwargs)`

Updates the global `main_thread_config`. Before applying changes, it calls `_ensure_configure_allowed()`.

#### `context(**kwargs)`

A context manager that installs temporary thread-local overrides. On exit, the previous overrides are restored via the `ContextVar` token.

```python
with dspy.context(lm=my_lm, temperature=0.7):
    # settings.lm resolves to my_lm here
    ...
# settings.lm reverts to the global value
```

#### `copy()` / `config` property

Returns a merged `dotdict` of `main_thread_config` overlaid with the current thread-local overrides — a snapshot of the effective configuration.

#### `get(key, default=None)`

Safe accessor that returns `default` instead of raising `AttributeError`.

#### `__contains__`

Supports `"lm" in settings` checks across both override and global layers.

---

## Configuration Ownership Model

The most subtle aspect of the module is its **ownership enforcement**, implemented in `_ensure_configure_allowed()`.

```mermaid
flowchart TD
    A[configure called] --> B{config_owner_thread_id<br/>is None?}
    B -->|Yes| C[Set owner = current thread<br/>ALLOW]
    B -->|No| D{owner == current thread?}
    D -->|No| E[RuntimeError:<br/>only owner thread may configure]
    D -->|Yes| F{In async task?}
    F -->|No| G[ALLOW]
    F -->|Yes| H{In IPython?}
    H -->|Yes| G
    H -->|No| I[RuntimeError:<br/>use dspy.context instead]
```

### Rules

1. **First `configure` wins ownership.** The first thread to call `configure` becomes the owner (`config_owner_thread_id`).
2. **Only the owner may reconfigure.** Any other thread attempting `configure` raises `RuntimeError`.
3. **Async tasks must use `context`.** A second `configure` call from within an async task is rejected unless running inside IPython, where it is permitted for interactive convenience.
4. **`context` is always allowed.** Any thread may use `dspy.context(...)` to set scoped overrides.

---

## Data Flow: Configuration Resolution

The following diagram shows how a configuration value flows from definition to consumption by a DSPy component.

```mermaid
sequenceDiagram
    participant User
    participant Settings as settings (singleton)
    participant Overrides as thread_local_overrides
    participant Global as main_thread_config
    participant Component as DSPy Component (LM, Adapter, ...)

    User->>Settings: dspy.configure(lm=my_lm)
    Settings->>Global: main_thread_config["lm"] = my_lm

    User->>Settings: with dspy.context(adapter=my_adapter):
    Settings->>Overrides: set({**global, **overrides, adapter=my_adapter})

    Component->>Settings: settings.lm
    Settings->>Overrides: lookup "lm"
    Overrides-->>Settings: not found
    Settings->>Global: lookup "lm"
    Global-->>Settings: my_lm
    Settings-->>Component: my_lm

    Component->>Settings: settings.adapter
    Settings->>Overrides: lookup "adapter"
    Overrides-->>Settings: my_adapter
    Settings-->>Component: my_adapter

    User->>Settings: exit context
    Settings->>Overrides: reset(token)
```

---

## Default Configuration Keys

`DEFAULT_CONFIG` defines every recognized setting. Unknown keys raise `AttributeError` on read.

| Key | Default | Purpose |
|-----|---------|---------|
| `lm` | `None` | Active language model |
| `adapter` | `None` | Active adapter for formatting/parsing |
| `rm` | `None` | Active retrieval model |
| `branch_idx` | `0` | Branch index for multi-branch execution |
| `trace` | `[]` | Execution trace accumulator |
| `bypass_assert` | `False` | Skip assertion checks |
| `bypass_suggest` | `False` | Skip suggestion checks |
| `assert_failures` | `0` | Counter of assertion failures |
| `suggest_failures` | `0` | Counter of suggestion failures |
| `backoff_time` | `10` | Retry backoff duration (seconds) |
| `callbacks` | `[]` | Registered callbacks |
| `async_max_workers` | `8` | Max async worker concurrency |
| `send_stream` | `None` | Streaming sink |
| `disable_history` | `False` | Disable LM history recording |
| `track_usage` | `False` | Enable usage tracking |
| `usage_tracker` | `None` | Usage tracker instance |
| `caller_predict` | `None` | Current calling `Predict` |
| `caller_modules` | `None` | Current calling modules |
| `stream_listeners` | `[]` | Streaming listeners |
| `provide_traceback` | `False` | Include tracebacks in error logs |
| `num_threads` | `8` | Threads for parallel processing |
| `max_errors` | `10` | Max errors before halting |
| `allow_tool_async_sync_conversion` | `False` | Allow async tools in sync mode |

---

## Integration with Other Modules

The `settings` singleton is consumed throughout DSPy. The table below maps key consumers to the settings they read.

```mermaid
graph LR
    S[settings]

    S -->|lm, adapter, callbacks| PRED[predict module]
    S -->|lm, disable_history, caller_modules| LM[clients_lm_core]
    S -->|adapter| AD[adapters_core]
    S -->|num_threads, max_errors, provide_traceback| PE[ParallelExecutor]
    S -->|track_usage, usage_tracker| UT[usage_tracker]
    S -->|stream_listeners, send_stream| ST[streaming]
    S -->|callbacks| CB[utils_callback]
    S -->|rm| RET[retrievers]
```

### Notable Consumers

- **`clients_lm_core`** — `BaseLM` reads `settings.disable_history`, `settings.caller_modules`, and `settings.track_usage` when processing responses and recording history. See [clients_lm_core.md](clients_lm_core.md).
- **`adapters_core`** — Adapters are selected via `settings.adapter` and invoked during `Predict` calls. See [adapters_core.md](adapters_core.md).
- **`ParallelExecutor`** — Reads `settings.num_threads`, `settings.max_errors`, and `settings.provide_traceback`, and critically **propagates `thread_local_overrides`** to worker threads. See [utils.md](utils.md).
- **`predict`** — The `Predict` module resolves the active LM and adapter from settings at call time. See [predict.md](predict.md).
- **`streaming`** — Streaming listeners and sinks are registered through settings. See [streaming.md](streaming.md).

### Context Propagation to Child Threads

`ParallelExecutor` is the primary mechanism that carries thread-local overrides into spawned threads. Its `worker` function reads `thread_local_overrides`, merges the parent's overrides, and installs them in the child thread:

```python
from dspy.dsp.utils.settings import thread_local_overrides
original = thread_local_overrides.get()
token = thread_local_overrides.set({**original, **parent_overrides.copy()})
```

This is why `dspy.context(...)` blocks correctly scope configuration even when work is parallelized.

---

## Dependency on `dsp_utils`

The module depends on `dotdict` from the `dsp_utils` module (`dspy/dsp/utils/utils.py`), which provides attribute-style access to dictionary keys. See [dsp_utils.md](dsp_utils.md).

```mermaid
graph TD
    SET[dsp_settings<br/>Settings] --> DD[dotdict]
    SET --> CV[contextvars.ContextVar]
    SET --> TH[threading.Lock]
    SET --> AS[asyncio]
    SET --> IP[IPython.get_ipython]
```

`dotdict` is used for `DEFAULT_CONFIG`, `main_thread_config`, and `thread_local_overrides`, enabling `settings.lm` syntax instead of `settings["lm"]`.

---

## Usage Examples

### Global Configuration

```python
import dspy

lm = dspy.LM("openai/gpt-4o-mini")
dspy.configure(lm=lm)
```

### Scoped Overrides

```python
with dspy.context(lm=cheap_lm):
    result = my_program(question="...")  # uses cheap_lm
# reverts to the globally configured lm
```

### Reading Effective Config

```python
snapshot = dspy.settings.config  # merged dotdict of global + overrides
```

### Safe Access

```python
adapter = dspy.settings.get("adapter", default=my_default_adapter)
```

---

## Summary

The `dsp_settings` module is the configuration backbone of DSPy. Its `Settings` singleton provides:

- A **global, mutable configuration** guarded by a single-owner thread model.
- **Thread-local overrides** via `contextvars`, enabling safe scoped configuration.
- **Automatic propagation** of overrides into child threads through `ParallelExecutor`.
- A **well-defined default schema** (`DEFAULT_CONFIG`) that all DSPy subsystems read from.

Understanding this module is essential for reasoning about how DSPy resolves the active LM, adapter, and behavioral flags at runtime, and for writing thread-safe or async DSPy programs.
