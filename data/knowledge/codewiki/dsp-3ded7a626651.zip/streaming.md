# Streaming

## Overview

The **streaming** module provides DSPy's real-time output streaming capabilities. It allows applications to receive incremental tokens from language model (LM) responses as they are generated, rather than waiting for the complete response. This is essential for building responsive user interfaces (chatbots, agents, interactive tools) where users expect to see output appear progressively.

The module addresses two distinct streaming concerns:

1. **Field-level output streaming** — Capturing and yielding the incremental content of a *specific output field* of a predictor (e.g., the `answer` field of a `ChainOfThought`), correctly delimited from the surrounding structured response.
2. **Status message streaming** — Emitting human-readable progress messages (e.g., "Calling tool X...", "Querying the LLM...") at key lifecycle events such as module start/end, LM start/end, and tool start/end.

Both concerns are wired into the broader DSPy runtime through the global [`Settings`](dsp_settings.md) object (`settings.send_stream` and `settings.stream_listeners`) and the [`BaseCallback`](utils.md) callback system.

## Architecture

The streaming module is intentionally small and focused. It consists of two sub-modules that operate independently but share the same underlying stream transport.

```mermaid
graph TD
    subgraph "streaming module"
        SL["StreamListener<br/>(streaming_listener.py)"]
        SR["StreamResponse<br/>(messages.py)"]
        SM["StatusMessage<br/>(messages.py)"]
        SMP["StatusMessageProvider<br/>(messages.py)"]
        SSC["StatusStreamingCallback<br/>(messages.py)"]
    end

    subgraph "DSPy Runtime"
        SET["Settings<br/>(settings.send_stream,<br/>settings.stream_listeners)"]
        PRED["Predict<br/>(predict.py)"]
        ADAPT["ChatAdapter / JSONAdapter<br/>(adapters)"]
        CB["BaseCallback<br/>(utils/callback.py)"]
    end

    PRED -->|"reads stream_listeners"| SET
    PRED -->|"invokes adapter with stream"| ADAPT
    ADAPT -->|"yields ModelResponseStream chunks"| SL
    SL -->|"emits"| SR
    SR -->|"sent to"| SET

    CB -->|"subclass"| SSC
    SSC -->|"reads send_stream"| SET
    SSC -->|"emits"| SM
    SM -->|"sent to"| SET
    SMP -->|"provides messages to"| SSC
```

### Data Flow

The following diagram illustrates how a token flows from the LM provider through the streaming machinery to the consumer.

```mermaid
sequenceDiagram
    participant User
    participant Predict
    participant Adapter as ChatAdapter/JSONAdapter
    participant LM as LM Provider
    participant Listener as StreamListener
    participant Stream as send_stream

    User->>Predict: call(question=...)
    Predict->>Predict: _should_stream() checks settings
    Predict->>Adapter: format + call with stream enabled
    Adapter->>LM: streaming request
    loop For each token chunk
        LM-->>Adapter: ModelResponseStream chunk
        Adapter-->>Listener: receive(chunk)
        Listener->>Listener: detect start/end identifiers
        Listener-->>Stream: StreamResponse(field, chunk)
        Stream-->>User: yield incremental token
    end
    Listener->>Listener: flush() remaining buffer
    Stream-->>User: final tokens
```

## Sub-modules

### Stream Listener

The [`StreamListener`](streaming_listener.md) is the core of field-level output streaming. It listens to the raw token stream produced by an adapter and extracts the content belonging to a single, named output field. It handles the adapter-specific delimiters used to separate fields:

- **`ChatAdapter`** uses `[[ ## field_name ## ]]` section markers.
- **`JSONAdapter`** uses JSON key syntax (`"field_name":`).

The listener buffers tokens until it can confirm the start identifier, then yields tokens until it detects the start of the next field (the end identifier), at which point it flushes its buffer and stops. It also handles edge cases such as cache hits (where the entire response arrives in a single chunk) and multi-token chunks.

See [streaming_listener.md](streaming_listener.md) for full details.

### Streaming Messages

The [`messages.py`](streaming_messages.md) sub-module provides the data structures and callback machinery for **status message streaming**:

- **`StreamResponse`** — the dataclass emitted for each streamed output-field chunk.
- **`StatusMessage`** — a dataclass wrapping a human-readable status string.
- **`StatusMessageProvider`** — a customizable base class whose methods return status strings for each lifecycle event (tool, module, LM start/end).
- **`StatusStreamingCallback`** — a [`BaseCallback`](utils.md) subclass that hooks into DSPy's callback system and forwards status messages to the active stream.

See [streaming_messages.md](streaming_messages.md) for full details.

## Integration with the DSPy Runtime

The streaming module does not operate in isolation; it is tightly integrated with several other modules:

| Integration Point | Description | Reference |
| --- | --- | --- |
| `settings.send_stream` | The active stream object that receives `StreamResponse` and `StatusMessage` objects. When `None`, streaming is disabled. | [dsp_settings.md](dsp_settings.md) |
| `settings.stream_listeners` | The list of `StreamListener` instances registered for the current program. | [dsp_settings.md](dsp_settings.md) |
| `settings.adapter` | Determines which delimiter syntax the `StreamListener` uses (`ChatAdapter` vs `JSONAdapter`). | [adapters_core.md](adapters_core.md) |
| `Predict._should_stream()` | Decides whether a given predictor should stream based on the registered listeners. | [predict_core.md](predict_core.md) |
| `BaseCallback` | The base class that `StatusStreamingCallback` extends to receive lifecycle events. | [utils.md](utils.md) |
| `Module.named_predictors()` | Used by `find_predictor_for_stream_listeners` to auto-resolve which predictor a listener targets. | [primitives_module_system.md](primitives_module_system.md) |

### Adapter Compatibility

Streaming field extraction is **adapter-aware**. The `StreamListener` inspects `settings.adapter` at runtime and selects the appropriate start/end identifiers:

```mermaid
graph LR
    A["settings.adapter"] -->|is JSONAdapter| J["start: '\"field\":'<br/>end: regex \\w*\"(,|\\s*})"]
    A -->|is ChatAdapter or None| C["start: '[[ ## field ## ]]'<br/>end: regex '[[ ## (\\w+) ## ]]'"]
    A -->|other| E["raise ValueError<br/>(unsupported adapter)"]
```

Only `ChatAdapter` and `JSONAdapter` are supported for streaming. Any other adapter raises a `ValueError`.

## Key Concepts

### Start and End Identifiers

Because LM responses are structured (fields are wrapped in markers), the listener cannot simply yield every token. It must:

1. **Buffer** tokens until the *start identifier* for the target field is fully observed.
2. **Yield** tokens once streaming has started.
3. **Detect** the *end identifier* (the start of the next field) and stop, flushing any buffered tokens that belong to the target field.

### The Field-End Buffer

To avoid leaking the end identifier (e.g., `[[ ## next_field ## ]]`) into the streamed output, the listener keeps a rolling buffer of the last ~10 tokens. When the end identifier is detected, only the portion before the identifier is flushed to the consumer.

### Cache Hits and Single-Chunk Responses

Some models (e.g., Gemini) may return the entire response in a single chunk, and cached responses arrive whole. The listener detects this case by checking whether both the start and end identifiers appear in the same chunk, and if so, marks the stream as complete immediately.

## Related Documentation

- [streaming_listener.md](streaming_listener.md) — Detailed documentation of the `StreamListener` class.
- [streaming_messages.md](streaming_messages.md) — Detailed documentation of status message streaming.
- [dsp_settings.md](dsp_settings.md) — The global `Settings` object that holds `send_stream` and `stream_listeners`.
- [adapters_core.md](adapters_core.md) — The `ChatAdapter` and `JSONAdapter` whose output formats the listener parses.
- [predict_core.md](predict_core.md) — The `Predict` module that decides whether to stream.
- [utils.md](utils.md) — The `BaseCallback` class extended by `StatusStreamingCallback`.
