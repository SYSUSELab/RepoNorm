# Adapters Types

## Introduction

The **adapters_types** module defines the custom data types that DSPy uses to represent rich, non-textual content within signatures and LM interactions. These types extend the base `BaseType` class and provide a uniform mechanism for embedding multimodal content (images, audio), conversation history, and tool-calling information into the message payloads that adapters send to language models.

The module is a foundational dependency of the [adapters_core](adapters_core.md) module: adapters rely on these types to detect, serialize, and split custom content when formatting messages for the LM. The types are also consumed by higher-level modules such as [predict](predict.md) (e.g., `ReAct`, `CodeAct` for tool calling) and [signatures](signatures.md) (field annotations).

### Core Components

| Component | File | Purpose |
|-----------|------|---------|
| `BaseType` | `dspy/adapters/types/base_type.py` | Abstract base class for all custom DSPy types; defines the `format()` contract and serialization markers. |
| `Image` | `dspy/adapters/types/image.py` | Represents an image (URL, file, PIL object, or bytes) for multimodal input. |
| `Audio` | `dspy/adapters/types/audio.py` | Represents audio (URL, file, array, or bytes) for multimodal input. |
| `History` | `dspy/adapters/types/history.py` | Represents conversation history as a list of message dictionaries. |
| `Tool` | `dspy/adapters/types/tool.py` | Wraps a Python callable as a tool for LLM function calling. |
| `ToolCalls` / `ToolCalls.ToolCall` | `dspy/adapters/types/tool.py` | Represents the tool calls returned by an LM. |

---

## Architecture Overview

All custom types (except `History`) inherit from `BaseType`, which itself extends `pydantic.BaseModel`. This gives every type validation, immutability options, and a consistent serialization path.

```mermaid
classDiagram
    class BaseModel {
        <<pydantic>>
    }
    class BaseType {
        +format() list|str
        +description() str
        +extract_custom_type_from_annotation(annotation)
        +serialize_model()
    }
    class Image {
        +url: str
        +format()
        +from_url()
        +from_file()
        +from_PIL()
    }
    class Audio {
        +data: str
        +audio_format: str
        +format()
        +from_url()
        +from_file()
        +from_array()
    }
    class Tool {
        +func: Callable
        +name: str
        +desc: str
        +args: dict
        +arg_types: dict
        +format()
        +format_as_litellm_function_call()
        +__call__()
        +acall()
        +from_mcp_tool()
        +from_langchain()
    }
    class ToolCalls {
        +tool_calls: list~ToolCall~
        +from_dict_list()
        +description()
    }
    class ToolCall {
        +name: str
        +args: dict
    }
    class History {
        +messages: list~dict~
    }

    BaseModel <|-- BaseType
    BaseModel <|-- History
    BaseType <|-- Image
    BaseType <|-- Audio
    BaseType <|-- Tool
    BaseType <|-- ToolCalls
    ToolCalls *-- ToolCall
```

---

## The `BaseType` Contract

`BaseType` establishes the interface that every custom type must satisfy. Understanding it is essential because adapters interact with custom types exclusively through this contract.

### Key Responsibilities

1. **`format()`** — Returns either a list of content-part dictionaries (matching the OpenAI API "array of content parts" format) or a plain string. This is the method subclasses must implement.
2. **`description()`** — A classmethod returning a human-readable description used in prompts.
3. **`extract_custom_type_from_annotation()`** — Recursively scans a type annotation to find all nested custom types. For example, it detects `Tool` inside `list[dict[str, Tool]]`. This is how adapters discover which fields contain custom content.
4. **`serialize_model()`** — A Pydantic model serializer that wraps list-formatted output between reserved markers (`<<CUSTOM-TYPE-START-IDENTIFIER>>` and `<<CUSTOM-TYPE-END-IDENTIFIER>>`).

### Custom Type Serialization Markers

When a custom type's `format()` returns a list, `serialize_model()` wraps it in reserved sentinel strings:

```
<<CUSTOM-TYPE-START-IDENTIFIER>>[...formatted content...]<<CUSTOM-TYPE-END-IDENTIFIER>>
```

These markers allow the adapter to later locate and split the content back into structured content blocks.

### `split_message_content_for_custom_types()`

This module-level function is the counterpart to serialization. It scans user messages for the reserved markers, parses the JSON payload inside each marker, and replaces the flat string content with a list of structured content blocks. For example, a user message containing an image becomes:

```python
[
    {"type": "text", "text": "{text_before_image}"},
    {"type": "image_url", "image_url": {"url": "{image_url}"}},
    {"type": "text", "text": "{text_after_image}"},
]
```

It uses `json_repair` to tolerate slightly malformed JSON and falls back to a raw text block if parsing fails.

```mermaid
flowchart TD
    A[Adapter formats user input to string] --> B[Custom type serialized with markers]
    B --> C[split_message_content_for_custom_types]
    C --> D{Find marker pattern}
    D -->|Match found| E[Parse JSON inside markers]
    E --> F[Append structured content blocks]
    D -->|No match| G[Keep original message]
    F --> H[Return messages with content blocks]
    G --> H
```

---

## Type Reference

### `Image`

Represents an image for multimodal input. The `url` field may hold a remote URL, a local file path, or a base64 data URI.

- **Validation**: A `model_validator(mode="before")` accepts either a plain string (treated as a URL) or a dict with a single `url` key.
- **Constructors**: `from_url(url, download=False)`, `from_file(file_path)`, `from_PIL(pil_image)`.
- **`format()`**: Returns `[{"type": "image_url", "image_url": {"url": <encoded>}}]`.
- **Encoding helpers**: `encode_image()` dispatches based on input type (dict, data URI, file path, URL, PIL image, bytes). `_encode_image_from_file`, `_encode_image_from_url`, and `_encode_pil_image` produce base64 data URIs.
- **Optional dependency**: Pillow (`PIL`) is required for PIL objects and raw bytes; the module degrades gracefully when it is absent.

### `Audio`

Represents audio for multimodal input. Stores base64-encoded `data` and an `audio_format`.

- **Validation**: `validate_input` accepts an `Audio` instance or delegates to `encode_audio()`.
- **Constructors**: `from_url(url)`, `from_file(file_path)`, `from_array(array, sampling_rate, format="wav")`.
- **`format()`**: Returns `[{"type": "input_audio", "input_audio": {"data": ..., "format": ...}}]`.
- **`encode_audio()`**: Accepts a dict, `Audio` instance, data URI, file path, URL, numpy-like array, or raw bytes.
- **Optional dependency**: `soundfile` is required for array inputs.

### `History`

Represents conversation history as a list of message dictionaries. Unlike the other types, `History` extends `pydantic.BaseModel` directly (not `BaseType`) because it is not a multimodal content type — it is expanded into multiturn messages by the adapter.

- **Field**: `messages: list[dict[str, Any]]`.
- **Usage**: When a signature has an input field annotated as `History`, the adapter detects it via `_get_history_field_name()` and formats the messages into user/assistant turns. See [adapters_core](adapters_core.md) for the formatting flow.

### `Tool`

Wraps a Python callable so it can be exposed to an LLM for function calling.

- **Auto-inference**: On construction, `_parse_function()` inspects the function's signature and type hints to derive `name`, `desc`, `args` (JSON schema), and `arg_types`. User-supplied values take precedence.
- **Pydantic model args**: If an argument's type is a Pydantic `BaseModel`, its JSON schema is resolved (references expanded via `_resolve_json_schema_reference`).
- **`format_as_litellm_function_call()`**: Produces the LiteLLM/OpenAI function-calling schema.
- **Invocation**: `__call__` (sync) and `acall` (async) validate and coerce arguments via `_validate_and_parse_args()`, then invoke the wrapped function. Both are decorated with `@with_callbacks` to emit `on_tool_start`/`on_tool_end` events (see [utils](utils.md)).
- **Async handling**: If the wrapped function is a coroutine, `__call__` runs it synchronously only when `settings.allow_tool_async_sync_conversion` is enabled; otherwise it raises and directs the caller to `acall`.
- **Interop**: `from_mcp_tool()` and `from_langchain()` convert external tool definitions into DSPy tools.

### `ToolCalls` and `ToolCalls.ToolCall`

Represents the tool calls returned by an LM.

- **`ToolCall`**: A nested Pydantic model with `name: str` and `args: dict[str, Any]`.
- **`ToolCalls`**: Holds `tool_calls: list[ToolCall]`.
- **`from_dict_list()`**: Builds a `ToolCalls` instance from a list of `{"name": ..., "args": ...}` dictionaries.
- **`description()`**: Returns a description used in prompts, instructing the LM to provide arguments in JSON format.

### Helper: `convert_input_schema_to_tool_args()`

Converts a JSON input schema into the `(args, arg_types, arg_desc)` tuple expected by `Tool`. It maps JSON schema types to Python types via `_TYPE_MAPPING` and annotates required arguments.

---

## How Types Integrate with Adapters

The custom types are consumed by the adapter layer during message formatting and output parsing. The following sequence shows the end-to-end flow.

```mermaid
sequenceDiagram
    participant User
    participant Adapter as Adapter (adapters_core)
    participant BaseType as BaseType / Custom Types
    participant LM

    User->>Adapter: inputs (may contain Image, Audio, Tool, History)
    Adapter->>Adapter: _call_preprocess (detect Tool fields)
    Adapter->>BaseType: format() each custom type
    BaseType-->>Adapter: content parts / string
    Adapter->>BaseType: serialize_model() wraps with markers
    Adapter->>Adapter: split_message_content_for_custom_types()
    Adapter->>LM: messages with structured content blocks
    LM-->>Adapter: completion (text and/or tool_calls)
    Adapter->>BaseType: ToolCalls.from_dict_list() for tool calls
    Adapter-->>User: parsed outputs
```

### Detection of Custom Types in Signatures

Adapters locate custom types by inspecting field annotations:

- `_get_history_field_name()` — finds a field annotated as `History`.
- `_get_tool_call_input_field_name()` — finds a field annotated as `Tool` or `list[Tool]`.
- `_get_tool_call_output_field_name()` — finds a field annotated as `ToolCalls`.

These detection methods rely on the annotation structure that `BaseType.extract_custom_type_from_annotation()` is designed to traverse.

---

## Dependency Graph

```mermaid
graph TD
    subgraph adapters_types
        BaseType
        Image
        Audio
        History
        Tool
        ToolCalls
    end

    subgraph adapters_core
        Adapter
        ChatAdapter
        JSONAdapter
    end

    subgraph external
        Pydantic
        json_repair
        requests
        PIL
        soundfile
        jsonschema
    end

    subgraph dspy_internal
        Settings
        BaseCallback
    end

    Image --> BaseType
    Audio --> BaseType
    Tool --> BaseType
    ToolCalls --> BaseType
    BaseType --> Pydantic
    Image --> PIL
    Image --> requests
    Audio --> soundfile
    Audio --> requests
    Tool --> jsonschema
    Tool --> Settings
    Tool --> BaseCallback
    Adapter --> BaseType
    Adapter --> History
    Adapter --> Tool
    Adapter --> ToolCalls
    BaseType --> json_repair
```

---

## Related Modules

- **[adapters_core](adapters_core.md)** — The adapter classes (`ChatAdapter`, `JSONAdapter`, `XMLAdapter`, `TwoStepAdapter`) that format and parse messages using these types.
- **[signatures](signatures.md)** — Signatures annotate fields with these custom types (e.g., `dspy.Image`, `dspy.History`, `list[dspy.Tool]`).
- **[predict](predict.md)** — Modules such as `ReAct` and `CodeAct` use `Tool` and `ToolCalls` for tool calling.
- **[utils](utils.md)** — Provides `BaseCallback` (used by `Tool` via `@with_callbacks`) and `AdapterParseError`.
- **[dsp](dsp.md)** — Provides the global `Settings` object consulted by `Tool` for async/sync conversion behavior.
