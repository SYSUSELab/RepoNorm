# Datasets

## Overview

The **datasets** module provides the data infrastructure for DSPy. It supplies two complementary capabilities:

1. **A generic data-loading and splitting framework** — the `Dataset` base class and the `DataLoader` utility — that turns raw data from many sources (HuggingFace, CSV, JSON, Parquet, Pandas, retrieval modules) into standardized `dspy.Example` objects with reproducible train/dev/test splits.
2. **A collection of ready-to-use benchmark datasets** — `GSM8K`, `HotPotQA`, `MATH`, `Colors`, and `AlfWorld` — that are commonly used to evaluate and optimize DSPy programs.

All data flowing through this module is normalized into [`dspy.Example`](primitives.md) objects, which are the universal data primitive consumed by the rest of DSPy (predictors, teleprompters, and evaluators).

## Purpose and Core Functionality

- **Standardization**: Every dataset produces `dspy.Example` instances with consistent input/label separation via `with_inputs(...)`.
- **Reproducibility**: Splits are deterministic through seeded shuffling (`train_seed`, `eval_seed`), and each example is tagged with a `dspy_uuid` and `dspy_split`.
- **Flexibility**: `DataLoader` adapts arbitrary tabular/columnar sources into DSPy examples without requiring a custom dataset class.
- **Benchmark access**: Curated benchmark classes wrap HuggingFace datasets and apply the canonical preprocessing (e.g., extracting GSM8K's `####` answer, parsing MATH's `\boxed{}` answers, filtering HotPotQA to hard examples).

## Architecture

The module is organized into two layers: a **core infrastructure layer** and a **benchmark layer** that builds on top of it.

```mermaid
graph TD
    subgraph "datasets module"
        subgraph "Core Infrastructure"
            Dataset["Dataset<br/>(base class)"]
            DataLoader["DataLoader<br/>(source adapters)"]
        end

        subgraph "Benchmarks"
            GSM8K["GSM8K"]
            HotPotQA["HotPotQA"]
            MATH["MATH"]
            Colors["Colors"]
            AlfWorld["AlfWorld<br/>+ EnvPool / _EnvSession"]
        end
    end

    DataLoader -->|extends| Dataset
    Colors -->|extends| Dataset
    HotPotQA -->|extends| Dataset
    GSM8K -.->|standalone| GSM8K
    MATH -.->|standalone| MATH
    AlfWorld -.->|standalone| AlfWorld

    Dataset -->|produces| Example["dspy.Example"]
    DataLoader -->|produces| Example
    GSM8K -->|produces| Example
    HotPotQA -->|produces| Example
    MATH -->|produces| Example
    Colors -->|produces| Example
    AlfWorld -->|produces| Example

    Example -->|consumed by| Downstream["Predictors /<br/>Teleprompters /<br/>Evaluate"]
```

### Component Relationships

```mermaid
graph LR
    subgraph "External Sources"
        HF["HuggingFace Hub"]
        CSV["CSV / JSON / Parquet"]
        PD["Pandas DataFrame"]
        RM["Retrieval Module"]
    end

    HF --> DataLoader
    CSV --> DataLoader
    PD --> DataLoader
    RM --> DataLoader

    DataLoader --> Dataset
    Dataset --> Splits["train / dev / test<br/>(seeded, shuffled)"]
    Splits --> Example["dspy.Example"]
```

## Sub-modules

### Core Infrastructure — [datasets_core.md](datasets_core.md)

The foundation of the module. It contains:

- **`Dataset`** — the abstract base class that manages train/dev/test splits, seeded shuffling, lazy caching of splits, and per-example metadata (`dspy_uuid`, `dspy_split`). It also provides `prepare_by_seed` for multi-seed evaluation setups.
- **`DataLoader`** — a collection of adapters (`from_huggingface`, `from_csv`, `from_json`, `from_parquet`, `from_pandas`, `from_rm`) plus utilities (`sample`, `train_test_split`) that convert external data sources into lists of `dspy.Example`.

See [datasets_core.md](datasets_core.md) for full details.

### Benchmark Datasets — [datasets_benchmarks.md](datasets_benchmarks.md)

A set of ready-to-use benchmark datasets, each with canonical preprocessing:

- **`GSM8K`** — grade-school math word problems with a `gsm8k_metric` for answer comparison.
- **`HotPotQA`** — multi-hop question answering, filtered to hard examples.
- **`MATH`** — competition math problems with `\boxed{}` answer extraction and a `metric` method.
- **`Colors`** — a synthetic color-naming dataset with suffix-based sorting to avoid train/dev leakage.
- **`AlfWorld`** — an interactive text-based environment backed by a multiprocessing `EnvPool`.

See [datasets_benchmarks.md](datasets_benchmarks.md) for full details.

## Data Flow

The typical lifecycle of data through the module:

```mermaid
sequenceDiagram
    participant User
    participant Loader as DataLoader / Benchmark
    participant Dataset as Dataset (base)
    participant Example as dspy.Example
    participant Downstream as Predictors / Evaluate

    User->>Loader: load source (HF/CSV/JSON/...)
    Loader->>Example: build Example objects
    Loader->>Dataset: (optional) split via train_test_split
    Dataset->>Dataset: seeded shuffle + sample
    Dataset->>Example: tag dspy_uuid + dspy_split
    Dataset-->>User: train / dev / test splits
    User->>Downstream: pass Examples to programs
```

## Integration with Other Modules

- **[primitives.md](primitives.md)** — `dspy.Example` is the core data primitive produced by every dataset and consumed throughout DSPy.
- **[dsp.md](dsp.md)** — `dotdict` (from `dspy.dsp.utils`) is used for configuration passing (e.g., in `Dataset.prepare_by_seed`), and `Settings` provides the global `dspy.settings.rm` retrieval module used by `DataLoader.from_rm`.
- **[retrievers.md](retrievers.md)** — `DataLoader.from_rm` pulls examples from a configured retrieval module (`dspy.settings.rm`).
- **[evaluate.md](evaluate.md)** — benchmark metrics (e.g., `gsm8k_metric`, `MATH.metric`) are used by the evaluation framework.
- **[teleprompt.md](teleprompt.md)** — optimizers consume the train/dev splits produced by these datasets.

## Key Design Notes

- **Lazy split materialization**: `Dataset.train`, `.dev`, and `.test` are properties that compute and cache splits on first access, and are invalidated by `reset_seeds`.
- **Deterministic shuffling**: All shuffling uses `random.Random(seed)` instances rather than the global RNG, ensuring reproducibility.
- **Two dataset styles**: Some benchmarks (`GSM8K`, `MATH`, `AlfWorld`) are standalone classes that expose `.train`/`.dev`/`.test` directly, while others (`Colors`, `HotPotQA`) extend the `Dataset` base class to inherit seeded splitting behavior.
