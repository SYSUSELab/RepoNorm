# Retrievers Backends

## Introduction

The **Retrievers Backends** module provides concrete, production-ready retrieval backends that connect DSPy programs to external vector search and retrieval services. While the core retrieval abstractions (see [retrievers_core.md](retrievers_core.md)) define *what* a retriever is, this module defines *how* DSPy talks to specific third-party retrieval infrastructure.

This module currently ships two backend implementations:

- **`WeaviateRM`** — a retriever backed by a [Weaviate](https://weaviate.io/) vector database collection, supporting both the v3 (`Client`) and v4 (`WeaviateClient`) Python clients.
- **`DatabricksRM`** — a retriever backed by a [Databricks Mosaic AI Vector Search Index](https://docs.databricks.com/en/generative-ai/create-query-vector-search.html), supporting both the Databricks SDK and a raw HTTP `requests`-based query path.

Both backends subclass `dspy.Retrieve` and return `dspy.Prediction` objects, making them drop-in replacements for any other DSPy retriever.

---

## Architecture Overview

The backends sit between the DSPy retrieval abstraction layer and external vector stores. They translate DSPy's uniform `forward(query, k)` interface into provider-specific API calls.

```mermaid
graph TD
    subgraph "DSPy Core"
        Retrieve["Retrieve<br/>(retrievers_core)"]
        Prediction["Prediction<br/>(primitives_data_containers)"]
        Settings["Settings<br/>(dsp_settings)"]
    end

    subgraph "Retrievers Backends (this module)"
        WeaviateRM["WeaviateRM"]
        DatabricksRM["DatabricksRM"]
        Document["Document<br/>(dataclass)"]
    end

    subgraph "External Services"
        WeaviateDB["Weaviate<br/>Vector DB"]
        DatabricksVS["Databricks<br/>Vector Search Index"]
    end

    Retrieve --> WeaviateRM
    Retrieve --> DatabricksRM
    WeaviateRM --> Prediction
    DatabricksRM --> Prediction
    DatabricksRM --> Document
    Settings -.->|"rm=..."| Retrieve
    WeaviateRM --> WeaviateDB
    DatabricksRM --> DatabricksVS
```

### Component Relationships

```mermaid
classDiagram
    class Retrieve {
        +int k
        +forward(query, k) Prediction
        +__call__(query, k)
    }
    class WeaviateRM {
        -str _weaviate_collection_name
        -WeaviateClient _weaviate_client
        -str _client_type
        -str _tenant_id
        +forward(query_or_queries, k) Prediction
        +get_objects(num_samples, fields) List
        +insert(new_object_properties)
    }
    class DatabricksRM {
        -str databricks_index_name
        -str databricks_endpoint
        -str databricks_token
        -List columns
        -str docs_id_column_name
        -str text_column_name
        +forward(query, query_type, filters_json)
        -_query_via_databricks_sdk(...)
        -_query_via_requests(...)
    }
    class Document {
        +str page_content
        +Dict metadata
        +str type
        +to_dict() Dict
    }

    Retrieve <|-- WeaviateRM
    Retrieve <|-- DatabricksRM
    DatabricksRM ..> Document : creates
```

---

## WeaviateRM

`WeaviateRM` is a retrieval module that uses a Weaviate collection to return the top passages for a given query. It assumes the collection has been created and populated with a payload containing a text field (default key: `content`).

### Key Features

- **Dual client support**: Automatically detects and supports both the Weaviate v4 `WeaviateClient` (via `collections`) and the legacy v3 `Client` (via `query`).
- **Hybrid search**: Uses Weaviate's `hybrid` query mode, combining keyword and vector search.
- **Multi-tenancy**: Optional `tenant_id` scoping for both query and object operations.
- **Batch queries**: Accepts either a single query string or a list of queries.
- **Data management**: Supports `get_objects` (cursor-based iteration) and `insert` for v4 clients.

### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `weaviate_collection_name` | `str` | — | Name of the Weaviate collection. |
| `weaviate_client` | `WeaviateClient \| Client` | — | An instance of the Weaviate client (v3 or v4). |
| `weaviate_collection_text_key` | `Optional[str]` | `"content"` | The property key holding passage text. |
| `k` | `int` | `3` | Default number of top passages to retrieve. |
| `tenant_id` | `Optional[str]` | `None` | Tenant to retrieve objects from. |

### Client Type Detection

The constructor inspects the supplied client to determine which API surface to use:

```mermaid
flowchart TD
    A["weaviate_client supplied"] --> B{"hasattr(client, 'collections')?"}
    B -->|Yes| C["_client_type = 'WeaviateClient' (v4)"]
    B -->|No| D{"hasattr(client, 'query')?"}
    D -->|Yes| E["_client_type = 'Client' (v3)"]
    D -->|No| F["raise ValueError:<br/>Unsupported Weaviate client type"]
```

### Query Flow

```mermaid
sequenceDiagram
    participant Caller
    participant WeaviateRM
    participant Weaviate

    Caller->>WeaviateRM: forward(query_or_queries, k)
    WeaviateRM->>WeaviateRM: normalize to list of queries
    loop for each query
        alt v4 WeaviateClient
            WeaviateRM->>Weaviate: collection.query.hybrid(query, limit=k)
            Weaviate-->>WeaviateRM: results.objects
        else v3 Client
            WeaviateRM->>Weaviate: query.get(...).with_hybrid(...).do()
            Weaviate-->>WeaviateRM: results["data"]["Get"][collection]
        end
        WeaviateRM->>WeaviateRM: extract text key -> dotdict(long_text=...)
    end
    WeaviateRM-->>Caller: list of dotdict passages
```

> **Note:** `WeaviateRM.forward` returns a list of `dotdict` objects with a `long_text` attribute (not a `Prediction` directly). This is consumed by the core `Retrieve` wrapper, which extracts `psg.long_text` into a `Prediction(passages=...)`. See [retrievers_core.md](retrievers_core.md) for details.

### Data Management Methods

- **`get_objects(num_samples, fields)`** — Iterates the collection via the cursor API and returns up to `num_samples` objects containing only the requested `fields`. Only supported for v4 clients.
- **`insert(new_object_properties)`** — Inserts a new object with a generated UUID. Only supported for v4 clients.

### Usage Example

```python
import weaviate
import dspy

llm = dspy.Cohere(model="command-r-plus", api_key=api_key)
weaviate_client = weaviate.connect_to_local("your-path-here")
retriever_model = WeaviateRM("my_collection_name", weaviate_client=weaviate_client)
dspy.settings.configure(lm=llm, rm=retriever_model)

retrieve = dspy.Retrieve(k=1)
topK_passages = retrieve("what are the stages in planning...").passages
```

### Dependencies

Requires the `weaviate` extra: `pip install dspy-ai[weaviate]`. An `ImportError` is raised at import time if the package is missing.

---

## DatabricksRM

`DatabricksRM` is a retriever module that queries a Databricks Mosaic AI Vector Search Index to return the top-k embeddings for a given query. It supports both text and vector queries, ANN and hybrid search, and optional integration with the Databricks Mosaic Agent Framework.

### Key Features

- **Dual query paths**: Uses the `databricks-sdk` `WorkspaceClient` when installed, otherwise falls back to a raw HTTP `requests` call.
- **Flexible authentication**: Supports token-based auth (`DATABRICKS_TOKEN`/`DATABRICKS_HOST`) and service-principal auth (`DATABRICKS_CLIENT_ID`/`DATABRICKS_CLIENT_SECRET`).
- **Text or vector queries**: Accepts either a query string or a numeric query vector.
- **Query types**: Supports `ANN` (approximate nearest neighbor) and `HYBRID` search, with backwards-compatibility mapping for legacy `"vector"`/`"text"` values.
- **Filtering**: JSON-based query filters, configurable at construction or per-call.
- **Agent Framework compatibility**: Optionally returns `Document` dicts compatible with the Databricks Mosaic Agent Framework.

### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `databricks_index_name` | `str` | — | Name of the Vector Search Index to query. |
| `databricks_endpoint` | `Optional[str]` | `DATABRICKS_HOST` | Workspace URL. |
| `databricks_token` | `Optional[str]` | `DATABRICKS_TOKEN` | Auth token. |
| `databricks_client_id` | `Optional[str]` | `DATABRICKS_CLIENT_ID` | Service principal id. |
| `databricks_client_secret` | `Optional[str]` | `DATABRICKS_CLIENT_SECRET` | Service principal secret. |
| `columns` | `Optional[List[str]]` | `None` | Extra columns to include in the response. |
| `filters_json` | `Optional[str]` | `None` | Default JSON query filters. |
| `k` | `int` | `3` | Number of documents to retrieve. |
| `docs_id_column_name` | `str` | `"id"` | Column holding document IDs. |
| `docs_uri_column_name` | `Optional[str]` | `None` | Column holding document URIs. |
| `text_column_name` | `str` | `"text"` | Column holding document text. |
| `use_with_databricks_agent_framework` | `bool` | `False` | Return Agent-Framework-compatible `Document` dicts. |

### Query Path Selection

```mermaid
flowchart TD
    A["forward(query, query_type, filters_json)"] --> B{"query_type in ['vector','text']?"}
    B -->|Yes| C["map to 'ANN' (backwards compat)"]
    B -->|No| D["keep query_type"]
    C --> E{"query is str?"}
    D --> E
    E -->|Yes| F["query_text = query"]
    E -->|No, list| G["query_vector = query"]
    E -->|else| H["raise ValueError"]
    F --> I{"databricks-sdk installed?"}
    G --> I
    I -->|Yes| J["_query_via_databricks_sdk(...)"]
    I -->|No| K["_query_via_requests(...)"]
    J --> L["validate columns, parse results"]
    K --> L
    L --> M{"use_with_databricks_agent_framework?"}
    M -->|Yes| N["return List[Document.to_dict()]"]
    M -->|No| O["return Prediction(docs, doc_ids, doc_uris, extra_columns)"]
```

### Authentication Strategy

```mermaid
flowchart TD
    A["_query_via_databricks_sdk"] --> B{"client_id AND client_secret?"}
    B -->|Yes| C["WorkspaceClient(client_id, client_secret)<br/>service principal auth"]
    B -->|No| D["WorkspaceClient(host, token)<br/>token auth"]
    C --> E["vector_search_indexes.query_index(...)"]
    D --> E
```

### Result Processing

After querying, `DatabricksRM`:

1. Validates that `docs_id_column_name` and `text_column_name` exist in the index manifest columns (raising an exception otherwise).
2. Zips column names with each `data_array` row into dictionaries.
3. Sorts results by `score` in descending order and truncates to `k`.
4. Returns either Agent-Framework `Document` dicts or a `Prediction` with `docs`, `doc_ids`, `doc_uris`, and `extra_columns`.

### The `Document` Dataclass

`Document` is a lightweight dataclass used to shape results for the Databricks Mosaic Agent Framework:

```python
@dataclass
class Document:
    page_content: str
    metadata: Dict[str, Any]
    type: str

    def to_dict(self) -> Dict[str, Any]: ...
```

When `use_with_databricks_agent_framework=True`, the constructor calls `mlflow.models.set_retriever_schema(...)` to register the retriever schema, requiring the `mlflow` package.

### Usage Example

```python
from databricks.vector_search.client import VectorSearchClient
from dspy.retrievers import DatabricksRM

retriever = DatabricksRM(
    databricks_index_name="your_index_name",
    docs_id_column_name="id",
    text_column_name="field2",
    k=3,
)
retrieved_results = retriever(query="Example query text")
```

### Dependencies

- **Optional**: `databricks-sdk` — enables the SDK query path. If absent, either supply `databricks_token` + `databricks_endpoint` or set the corresponding environment variables, otherwise a `ValueError` is raised.
- **Optional**: `mlflow` — required only when `use_with_databricks_agent_framework=True`.

---

## Data Flow Summary

```mermaid
graph LR
    subgraph "Input"
        Q["query / queries"]
    end
    subgraph "Backend"
        RM["WeaviateRM / DatabricksRM"]
    end
    subgraph "Output"
        P["Prediction<br/>(passages / docs)"]
        D["List[Document dict]"]
    end
    Q --> RM
    RM --> P
    RM --> D
```

Both backends normalize their provider-specific responses into DSPy-native structures:

- `WeaviateRM` → list of `dotdict(long_text=...)` consumed by the core `Retrieve` wrapper.
- `DatabricksRM` → `Prediction` (default) or `List[Document dict]` (Agent Framework mode).

---

## Integration with DSPy

Backends are registered globally via `dspy.settings.configure(rm=...)` and consumed through `dspy.Retrieve`:

```mermaid
sequenceDiagram
    participant User
    participant Settings as dspy.settings
    participant Retrieve as dspy.Retrieve
    participant Backend as WeaviateRM / DatabricksRM

    User->>Settings: configure(rm=backend)
    User->>Retrieve: Retrieve(k=3)("query")
    Retrieve->>Settings: read settings.rm
    Retrieve->>Backend: rm(query, k=3)
    Backend-->>Retrieve: passages
    Retrieve-->>User: Prediction(passages=...)
```

For details on the `Retrieve` wrapper, `Embeddings`, and the retrieval abstraction, see [retrievers_core.md](retrievers_core.md). For the `Prediction` container, see [primitives_data_containers.md](primitives_data_containers.md). For global configuration, see [dsp_settings.md](dsp_settings.md).

---

## Related Modules

| Module | Relationship |
|--------|--------------|
| [retrievers_core.md](retrievers_core.md) | Defines the `Retrieve` base class and `Embeddings` retriever that these backends extend/complement. |
| [primitives_data_containers.md](primitives_data_containers.md) | Provides `Prediction`, the return type of `DatabricksRM.forward`. |
| [dsp_settings.md](dsp_settings.md) | Global `Settings` object used to register the active retriever (`rm`). |
| [dsp_utils.md](dsp_utils.md) | Provides `dotdict`, used by `WeaviateRM` for passage objects. |
| [clients_lm_core.md](clients_lm_core.md) | Language model clients typically paired with retrievers in RAG pipelines. |
