# DSP Utils Module

## Introduction

The `dsp_utils` module (`dspy/dsp/utils/utils.py`) provides a collection of low-level, general-purpose utility helpers used throughout the DSPy framework. These utilities are deliberately dependency-light and framework-agnostic, serving as the foundational "toolbox" that higher-level modules (retrieval, tokenization, settings, and prediction) build upon.

The module's core contributions are:

- **`dotdict`** — a dictionary subclass offering attribute-style (dot) access with strict key semantics.
- **`dotdict_lax`** — a lenient variant of `dotdict` that returns `None` for missing keys instead of raising.
- **`NullContextManager`** — a no-op context manager used as a placeholder when a real resource context is not required.

Beyond these core components, the file also contains a broad set of helper functions for batching, grouping, zipping, deduplication, directory creation, and progress reporting. These are used across the DSPy codebase but are not part of the public API surface documented here.

## Module Position in the System

The `dsp_utils` module sits at the bottom of the DSPy dependency hierarchy. It has no internal DSPy dependencies and is consumed by sibling modules within the `dsp` package as well as by higher-level modules.

```mermaid
graph TD
    subgraph "dsp package"
        dsp_utils["dsp_utils<br/>(utils.py)"]
        dsp_settings["dsp_settings<br/>(settings.py)"]
        dsp_tokenization["dsp_tokenization<br/>(dpr.py)"]
        dsp_retrieval["dsp_retrieval<br/>(colbertv2.py)"]
    end

    subgraph "Higher-level modules"
        predict["predict"]
        primitives["primitives"]
        clients["clients"]
        teleprompt["teleprompt"]
    end

    dsp_settings --> dsp_utils
    dsp_tokenization --> dsp_utils
    dsp_retrieval --> dsp_utils
    predict --> dsp_utils
    primitives --> dsp_utils
    clients --> dsp_utils
    teleprompt --> dsp_utils
```

The `dotdict` type is particularly important: it is used by the [`Settings`](dsp_settings.md) singleton to represent configuration snapshots and thread-local overrides, making it a shared data structure across the configuration subsystem.

## Core Components

### `dotdict`

`dotdict` is a subclass of the built-in `dict` that enables dot-notation access to dictionary keys while preserving strict, dictionary-like semantics.

**Key behaviors:**

| Operation | Behavior |
|-----------|----------|
| `obj.key` | Returns `self["key"]`; raises `AttributeError` if the key is missing. |
| `obj.key = value` | Sets `self["key"] = value`. |
| `del obj.key` | Deletes `self["key"]`. |
| Dunder keys (`__x__`) | Delegated to the base `dict`/`object` implementation to avoid breaking Python internals. |
| `copy.deepcopy(obj)` | Returns a new `dotdict` via `copy.deepcopy(dict(self), memo)`, avoiding infinite recursion. |

The strict `AttributeError` on missing keys is intentional — it makes typos in configuration access fail loudly rather than silently returning `None`.

```python
class dotdict(dict):
    def __getattr__(self, key):
        if key.startswith("__") and key.endswith("__"):
            return super().__getattr__(key)
        try:
            return self[key]
        except KeyError:
            raise AttributeError(f"'{type(self).__name__}' object has no attribute '{key}'")

    def __setattr__(self, key, value):
        if key.startswith("__") and key.endswith("__"):
            super().__setattr__(key, value)
        else:
            self[key] = value

    def __delattr__(self, key):
        if key.startswith("__") and key.endswith("__"):
            super().__delattr__(key)
        else:
            del self[key]

    def __deepcopy__(self, memo):
        return dotdict(copy.deepcopy(dict(self), memo))
```

**Design notes:**

- The dunder-key guard ensures that Python's internal attribute lookups (e.g., `__class__`, `__dict__`) are not intercepted by the dictionary access logic.
- The custom `__deepcopy__` is essential: without it, `copy.deepcopy` would recurse infinitely because `__getattr__` intercepts the `__deepcopy__` lookup itself.

### `dotdict_lax`

`dotdict_lax` is a permissive counterpart to `dotdict`. It uses `dict.get` for attribute reads, so accessing a missing key returns `None` instead of raising an exception.

```python
class dotdict_lax(dict):
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__
```

**When to use which:**

| Type | Missing key access | Use case |
|------|-------------------|----------|
| `dotdict` | Raises `AttributeError` | Configuration and structured data where typos should fail fast. |
| `dotdict_lax` | Returns `None` | Optional/exploratory access where absence is a valid state. |

### `NullContextManager`

`NullContextManager` is a minimal no-op context manager. It is used as a stand-in when code expects a context manager but no actual resource management is needed (e.g., a dummy resource that should simply be yielded and discarded).

```python
class NullContextManager:
    def __init__(self, dummy_resource=None):
        self.dummy_resource = dummy_resource

    def __enter__(self):
        return self.dummy_resource

    def __exit__(self, *args):
        pass
```

**Behavior:**

- `__enter__` returns the `dummy_resource` passed at construction (or `None`).
- `__exit__` does nothing and never suppresses exceptions.

This is functionally similar to Python's standard `contextlib.nullcontext`, but predates it and allows an arbitrary dummy resource to be returned.

## Component Interaction

The following diagram illustrates how the core components relate to each other and to the broader configuration subsystem.

```mermaid
classDiagram
    class dict {
        <<builtin>>
    }
    class dotdict {
        +__getattr__(key)
        +__setattr__(key, value)
        +__delattr__(key)
        +__deepcopy__(memo)
    }
    class dotdict_lax {
        +__getattr__ = dict.get
        +__setattr__ = dict.__setitem__
        +__delattr__ = dict.__delitem__
    }
    class NullContextManager {
        +dummy_resource
        +__enter__()
        +__exit__(*args)
    }
    class Settings {
        +configure(**kwargs)
        +context(**kwargs)
        +copy() dotdict
    }

    dict <|-- dotdict
    dict <|-- dotdict_lax
    Settings ..> dotdict : creates snapshots
```

## Data Flow: Configuration Snapshot via `dotdict`

The most significant cross-module usage of `dotdict` is within the [`Settings`](dsp_settings.md) singleton, which merges global configuration with thread-local overrides into a `dotdict` snapshot. This flow is shown below.

```mermaid
sequenceDiagram
    participant User
    participant Settings
    participant dotdict
    participant Consumer

    User->>Settings: settings.copy()
    Settings->>Settings: read main_thread_config
    Settings->>Settings: read thread_local_overrides
    Settings->>dotdict: dotdict({**global, **overrides})
    dotdict-->>Settings: snapshot
    Settings-->>User: snapshot
    User->>Consumer: pass snapshot
    Consumer->>dotdict: snapshot.some_key
    dotdict-->>Consumer: value (or AttributeError)
```

This pattern ensures that consumers receive an immutable-by-convention, attribute-accessible view of the effective configuration at a point in time.

## Process Flow: Attribute Access Resolution

The following flow describes how attribute access is resolved for both `dotdict` variants.

```mermaid
flowchart TD
    A[Access obj.key] --> B{Is key a dunder?}
    B -- Yes --> C[Delegate to base dict/object]
    B -- No --> D{Which type?}
    D -- dotdict --> E{Key in dict?}
    E -- Yes --> F[Return self key]
    E -- No --> G[Raise AttributeError]
    D -- dotdict_lax --> H[Return dict.get key]
```

## Related Modules

- [dsp_settings](dsp_settings.md) — The `Settings` singleton, which relies on `dotdict` for configuration snapshots and thread-local overrides.
- [dsp_tokenization](dsp_tokenization.md) — Tokenization utilities (`Tokenizer`, `SimpleTokenizer`, `Tokens`) that share the `dsp/utils` package.
- [dsp_retrieval](dsp_retrieval.md) — Retrieval components (`ColBERTv2` and local variants) that consume these utilities.
- [primitives](primitives.md) — Core DSPy primitives that use `dotdict` for structured data handling.
- [clients](clients.md) — LM clients and providers that depend on shared utility helpers.

## Summary

The `dsp_utils` module provides the foundational data structures and helpers for DSPy. Its three core components — `dotdict`, `dotdict_lax`, and `NullContextManager` — are small but widely used:

- `dotdict` offers strict, attribute-accessible dictionaries ideal for configuration.
- `dotdict_lax` offers lenient access for optional data.
- `NullContextManager` provides a lightweight no-op context for placeholder resource management.

Because the module has no internal DSPy dependencies, it is safe to import from anywhere in the framework, making it a reliable base layer for the entire system.
