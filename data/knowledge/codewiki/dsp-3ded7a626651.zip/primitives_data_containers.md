# Primitives Data Containers

## Introduction

The `primitives_data_containers` module provides the foundational data structures used throughout DSPy to represent **examples** (input/output pairs) and **predictions** (model outputs). These containers are the primary way data flows between datasets, modules, predictors, and evaluation logic.

The module consists of two core components:

- **`Example`** — a flexible, dict-like container for holding arbitrary key/value data (typically inputs and labels).
- **`Prediction`** — a subclass of `Example` that additionally carries model completions, LM usage metadata, and numeric-comparison behavior for scoring.

Together, these containers form the "data currency" of DSPy: datasets yield `Example` objects, modules consume them, and predictors return `Prediction` objects that can be compared, scored, and aggregated.

---

## Module Architecture

The module is intentionally small and self-contained. `Prediction` builds directly on top of `Example`, inheriting its storage and access semantics while layering on completion handling and numeric behavior.

```mermaid
graph TD
    subgraph primitives_data_containers
        Example["Example<br/>(dict-like container)"]
        Prediction["Prediction<br/>(extends Example)"]
        Completions["Completions<br/>(multi-completion wrapper)"]
    end

    Prediction -->|inherits| Example
    Prediction -->|holds| Completions
    Completions -->|indexes into| Prediction

    Dataset["datasets_core<br/>Dataset / DataLoader"] -->|produces| Example
    Predict["predict_core<br/>Predict"] -->|returns| Prediction
    Evaluate["evaluate_orchestration<br/>Evaluate"] -->|consumes| Example
    Evaluate -->|consumes| Prediction
```

### Component Relationships

| Component | Base | Purpose |
|-----------|------|---------|
| `Example` | `object` | Generic key/value data container with input/label splitting |
| `Prediction` | `Example` | Model output container with completions and numeric comparison |
| `Completions` | `object` | Wraps multiple parallel completions (e.g., `n>1` sampling) |

---

## `Example`

`Example` is a lightweight, attribute-accessible dictionary. It stores all data in an internal `_store` dict and exposes it through both attribute access (`example.question`) and item access (`example["question"]`).

### Design Principles

- **Dual access**: Data is reachable via attributes *and* dict-style indexing.
- **Reserved namespace**: Keys beginning with `dspy_` are treated as internal metadata and are hidden from `keys()`, `values()`, `items()`, `__len__`, and `__repr__` by default.
- **Input/label separation**: A subset of keys can be designated as "inputs" via `with_inputs()`, enabling clean splitting between inputs and labels.
- **Copy-on-write semantics**: Methods like `with_inputs`, `without`, and `copy` return new instances rather than mutating in place.

### Internal Storage

```mermaid
graph LR
    subgraph Example instance
        Store["_store: dict<br/>(all key/value data)"]
        Demos["_demos: list<br/>(few-shot demos)"]
        InputKeys["_input_keys: set | None<br/>(designated input keys)"]
    end
```

- `_store` — the backing dictionary for all user data.
- `_demos` — reserved for few-shot demonstration storage (used by the module system).
- `_input_keys` — the set of keys considered "inputs"; `None` until `with_inputs()` is called.

### Construction

`Example` can be constructed from nothing, from another `Example`, or from a plain `dict`:

```python
Example(question="...", answer="...")          # from kwargs
Example(base=other_example)                     # copy from another Example
Example(base={"question": "..."})               # from a dict
```

When `base` is an `Example`, its `_store` is shallow-copied. When `base` is a `dict`, the dict is copied. Any additional `kwargs` are merged on top.

### Attribute Access Mechanics

The class overrides `__getattr__` and `__setattr__` to route user data into `_store`:

- `__getattr__` raises `AttributeError` for dunder names, returns `_store[key]` if present, otherwise raises `AttributeError`.
- `__setattr__` routes names starting with `_` (or matching class attributes) to normal attribute assignment; everything else goes into `_store`.

This means `example.foo = 1` stores `foo` in `_store`, while `example._store` sets the real attribute.

### Input / Label Splitting

The `with_inputs(*keys)` method returns a copy with `_input_keys` set. From there:

- `inputs()` returns a new `Example` containing only the input keys (raises `ValueError` if `with_inputs` was never called).
- `labels()` returns a new `Example` containing everything *not* in the input keys.

```mermaid
flowchart LR
    Full["Example<br/>{question, answer, context}"]
    Full -->|with_inputs('question')| Tagged["Example<br/>_input_keys={'question'}"]
    Tagged -->|inputs()| In["Example<br/>{question}"]
    Tagged -->|labels()| Out["Example<br/>{answer, context}"]
```

### Key Methods

| Method | Description |
|--------|-------------|
| `keys(include_dspy=False)` | List of keys, excluding `dspy_`-prefixed keys by default |
| `values(include_dspy=False)` | List of values |
| `items(include_dspy=False)` | List of `(key, value)` tuples |
| `get(key, default=None)` | Dict-style lookup with default |
| `with_inputs(*keys)` | Return a copy with input keys designated |
| `inputs()` | Return a copy containing only input keys |
| `labels()` | Return a copy containing only non-input keys |
| `copy(**kwargs)` | Return a copy, optionally overriding values |
| `without(*keys)` | Return a copy with the given keys removed |
| `toDict()` | Return a shallow copy of the raw `_store` |

### Dunder Behavior

- `__getitem__` / `__setitem__` / `__delitem__` / `__contains__` — dict-style access to `_store`.
- `__len__` — counts non-`dspy_` keys.
- `__iter__` — iterates over keys.
- `__eq__` — two `Example`s are equal iff their `_store` dicts are equal.
- `__hash__` — hashes the tuple of `_store` items (so `Example`s are hashable).
- `__repr__` / `__str__` — show the non-`dspy_` data plus `input_keys`.

---

## `Prediction`

`Prediction` extends `Example` to represent the output of a model call. It removes the `_demos` and `_input_keys` attributes (which are irrelevant for outputs) and adds completion tracking plus numeric comparison operators.

### Additional State

```mermaid
graph LR
    subgraph Prediction instance
        Store["_store: dict<br/>(first completion's fields)"]
        Completions["_completions: Completions | None"]
        Usage["_lm_usage: dict | None<br/>(token usage)"]
    end
```

- `_completions` — a `Completions` object holding all sampled completions (or `None`).
- `_lm_usage` — token usage metadata, set via `set_lm_usage()`.

### Construction from Completions

`Prediction.from_completions(list_or_dict, signature=None)` builds a `Prediction` whose `_store` is populated from the **first** completion of each field:

```python
obj._completions = Completions(list_or_dict, signature=signature)
obj._store = {k: v[0] for k, v in obj._completions.items()}
```

This means the primary fields of a `Prediction` always reflect the first completion, while the full set remains accessible via `.completions`.

### Numeric Comparison Behavior

`Prediction` implements `__float__` by reading the `score` field from `_store`. This enables direct arithmetic and comparison against numbers and other `Prediction`s:

| Operator | Behavior |
|----------|----------|
| `float(pred)` | Returns `float(pred.score)`; raises `ValueError` if no `score` field |
| `+`, `radd` | Adds scores (or score + number) |
| `/`, `rtruediv` | Divides scores (or score / number) |
| `<`, `<=`, `>`, `>=` | Compares scores |

This makes `Prediction` objects usable directly in scoring and ranking code, e.g. `sorted(predictions)` or `sum(predictions) / len(predictions)`.

### LM Usage

- `get_lm_usage()` — returns the stored usage dict.
- `set_lm_usage(value)` — stores usage metadata (called by the module system when usage tracking is enabled).

### Repr Behavior

`__repr__` shows the primary fields. If more than one completion exists, it appends a note indicating how many completions were omitted.

---

## `Completions`

`Completions` wraps multiple parallel completions, where each field maps to a **list** of values (one per completion).

### Construction

It accepts either:

- A **list of dicts** — each dict is one completion; values are transposed into per-field lists.
- A **dict of lists** — already in columnar form.

All values must be lists of equal length (validated with assertions).

```mermaid
flowchart TD
    Input["list_or_dict"]
    Input -->|list of dicts| Transpose["Transpose into<br/>{field: [v0, v1, ...]}"]
    Input -->|dict of lists| Direct["Use as-is"]
    Transpose --> Store["_completions: dict[str, list]"]
    Direct --> Store
```

### Access Patterns

- `completions[key]` — returns the list of values for a field.
- `completions[i]` (integer index) — returns a `Prediction` built from the `i`-th value of every field.
- `completions.field` — attribute access to a field's list.
- `len(completions)` — number of completions (length of any field's list).
- `key in completions` — membership test over field names.
- `items()` — iterate over `(field, list)` pairs.

### Relationship to `Prediction`

`Completions` and `Prediction` are mutually referential: a `Prediction` holds a `Completions`, and indexing a `Completions` by integer produces a `Prediction`. This allows code to treat a multi-completion result either as a single primary prediction or as a collection of individual predictions.

---

## Data Flow

The following diagram shows how these containers flow through a typical DSPy program.

```mermaid
sequenceDiagram
    participant DS as Dataset
    participant M as Module
    participant P as Predict
    participant E as Evaluate

    DS->>M: Example (with_inputs)
    M->>P: example.inputs()
    P-->>M: Prediction (from_completions)
    M-->>E: Prediction
    E->>E: compare Prediction.score
    E-->>DS: metrics / scores
```

1. A `Dataset` yields `Example` objects, typically tagged with `with_inputs()`.
2. A `Module` receives an `Example` and passes `example.inputs()` to its predictors.
3. A `Predict` returns a `Prediction` built via `from_completions`.
4. `Evaluate` consumes `Example`/`Prediction` pairs and uses the numeric comparison behavior of `Prediction` for scoring.

---

## Integration with Other Modules

| Module | Relationship |
|--------|--------------|
| [datasets_core](datasets_core.md) | `Dataset` and `DataLoader` produce and iterate over `Example` objects. |
| [predict_core](predict_core.md) | `Predict` returns `Prediction` objects via `from_completions`. |
| [evaluate_orchestration](evaluate_orchestration.md) | `Evaluate` consumes `Example`/`Prediction` and relies on `Prediction`'s numeric operators. |
| [primitives_module_system](primitives_module_system.md) | `Module`/`BaseModule` use `Example` for inputs and `Prediction` for outputs; `_demos` on `Example` supports few-shot storage. |
| [predict_strategies](predict_strategies.md) | Strategies such as `ChainOfThought`, `ReAct`, and `BestOfN` produce and manipulate `Prediction` objects (e.g., `BestOfN` selects among completions). |

---

## Summary

The `primitives_data_containers` module provides two tightly coupled, dict-like containers:

- **`Example`** — a flexible, hashable, attribute-accessible data container with input/label splitting and `dspy_`-prefixed metadata hiding.
- **`Prediction`** — an `Example` subclass that carries completions and LM usage, and supports numeric comparison via a `score` field.

These containers are the universal data interface across DSPy, connecting datasets, modules, predictors, and evaluation. Their design emphasizes ergonomic dual access (attribute + dict), immutability-by-copy for transformations, and seamless numeric interoperability for scoring.
