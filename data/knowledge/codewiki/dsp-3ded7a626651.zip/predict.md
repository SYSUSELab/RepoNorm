# Predict Module

## Overview

The `predict` module is the **core reasoning and prediction layer** of DSPy. It provides the fundamental building blocks that turn declarative `Signature` definitions into executable programs that call language models (LMs). Every DSPy program ultimately bottoms out in a `Predict` instance, and the module also ships a rich library of higher-level *reasoning strategies* (Chain-of-Thought, ReAct, Program-of-Thought, CodeAct, etc.) that compose `Predict` into more capable agents.

The module answers three questions:

1. **How does a single LM call happen?** → [`Predict`](#core-prediction) orchestrates signature validation, adapter selection, LM invocation, and `Prediction` construction.
2. **How do we build richer reasoning on top of a single call?** → Strategy modules such as `ChainOfThought`, `ReAct`, `ProgramOfThought`, `CodeAct`, `MultiChainComparison`, `BestOfN`, `Refine`, and `Avatar`.
3. **How do we run many predictions efficiently?** → `Parallel` and `KNN` provide batching and retrieval utilities.

## Architecture Overview

```mermaid
graph TD
    subgraph "User Program"
        SIG[Signature]
    end

    subgraph "predict module"
        P[Predict]
        COT[ChainOfThought]
        COTH[ChainOfThoughtWithHint]
        REACT[ReAct]
        POT[ProgramOfThought]
        CODEACT[CodeAct]
        MCC[MultiChainComparison]
        BON[BestOfN]
        REFINE[Refine]
        AVATAR[Avatar]
        PARALLEL[Parallel]
        KNN[KNN]
        PARAM[Parameter]
    end

    subgraph "Dependencies"
        MOD[Module / BaseModule]
        PRED[Prediction]
        ADAPTER[Adapter / ChatAdapter]
        LM[LM / BaseLM]
        TOOL[Tool]
        INTERP[PythonInterpreter]
        EXEC[ParallelExecutor]
    end

    SIG --> P
    SIG --> COT
    COT --> P
    COTH --> COT
    REACT --> P
    REACT --> COT
    POT --> COT
    POT --> INTERP
    CODEACT --> REACT
    CODEACT --> POT
    MCC --> P
    BON --> MOD
    REFINE --> MOD
    AVATAR --> P
    PARALLEL --> EXEC
    KNN --> EMB[Embedder]

    P --> MOD
    P --> PRED
    P --> ADAPTER
    P --> LM
    REACT --> TOOL
    CODEACT --> TOOL
    AVATAR --> TOOL
```

## Module Composition

The `predict` module is organized into three logical groups, each documented in its own file. Together they cover the full lifecycle from a single LM call to multi-step agentic reasoning and large-scale batch execution.

### 1. Core Prediction — [predict_core.md](predict_core.md)

The foundation of the module. `Predict` is the atomic unit that binds a `Signature` to an LM through an `Adapter`, producing a `Prediction`. `Parameter` is the marker base class that lets the optimizer framework discover tunable predictors inside a program.

- `Predict` — single LM call, signature validation, streaming, sync/async, state dump/load.
- `Parameter` — marker class for optimizable parameters.

### 2. Reasoning Strategies — [predict_strategies.md](predict_strategies.md)

Higher-level modules that wrap one or more `Predict`/`ChainOfThought` calls to implement well-known prompting and agentic paradigms.

- `ChainOfThought` / `ChainOfThoughtWithHint` — step-by-step reasoning.
- `ReAct` — reasoning + tool use loop.
- `ProgramOfThought` — generate and execute Python to compute answers.
- `CodeAct` — ReAct + code interpreter hybrid.
- `MultiChainComparison` — compare multiple reasoning attempts.
- `BestOfN` / `Refine` — sample multiple times and pick/improve the best.
- `Avatar` — tool-using agent with dynamically growing signatures.

### 3. Execution & Retrieval Utilities — [predict_utilities.md](predict_utilities.md)

Supporting utilities for running predictions at scale and retrieving relevant examples.

- `Parallel` — thread-pool execution of a module over many examples.
- `KNN` — k-nearest-neighbor example retrieval using embeddings.

## Data Flow

The following diagram shows the end-to-end flow of a single `Predict` call, which is the shared backbone of every strategy module.

```mermaid
sequenceDiagram
    participant User
    participant Module as Module.__call__
    participant Predict
    participant Adapter
    participant LM
    participant Pred as Prediction

    User->>Module: module(**kwargs)
    Module->>Predict: forward(**kwargs)
    Predict->>Predict: _forward_preprocess (validate signature, pick LM, config)
    Predict->>Adapter: adapter(lm, signature, demos, inputs)
    Adapter->>LM: formatted prompt
    LM-->>Adapter: raw completions
    Adapter-->>Predict: completions
    Predict->>Pred: Prediction.from_completions(...)
    Predict->>Predict: _forward_postprocess (append trace)
    Pred-->>User: Prediction
```

## How the Module Fits into DSPy

```mermaid
graph LR
    SIG[signatures] --> PREDICT[predict]
    PREDICT --> PRIM[primitives]
    PREDICT --> ADAPT[adapters]
    PREDICT --> CLIENTS[clients]
    PREDICT --> EVAL[evaluate]
    PREDICT --> TELE[teleprompt]
    TELE --> PREDICT
    EVAL --> PREDICT
```

- **signatures** define the input/output contract consumed by `Predict`.
- **adapters** format signatures and parse LM responses.
- **clients** (`LM`, `BaseLM`, `Embedder`) provide the actual model and embedding backends.
- **primitives** (`Module`, `Prediction`, `PythonInterpreter`) supply the base classes and execution sandbox.
- **teleprompt** optimizers operate on the `Predict`/`Parameter` instances discovered inside programs.
- **evaluate** runs programs built from these modules to compute metrics.

## Key Design Notes

- **Signature polymorphism**: Every strategy module accepts any `Signature`, so reasoning strategies are composable and optimizer-friendly.
- **Trace integration**: `Predict` appends `(predictor, inputs, prediction)` tuples to `settings.trace`, enabling optimizers and `Refine` to inspect execution history.
- **Sync/async parity**: `Predict`, `ReAct`, and `ChainOfThought` expose both `forward`/`aforward` (and `__call__`/`acall`) paths.
- **Sandboxed execution**: `ProgramOfThought` and `CodeAct` rely on `PythonInterpreter` (Deno/Pyodide sandbox) for safe code execution.
