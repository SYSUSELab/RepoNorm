# Streaming Messages

## Introduction

The `streaming_messages` module (`dspy/streaming/messages.py`) provides the **status message streaming** infrastructure for DSPy programs. While the sibling [streaming_listener](streaming_listener.md) module handles streaming of *output field content* (the actual model-generated values), this module handles streaming of *human-readable status messages* that describe what the program is doing at each stage of execution — for example, "Calling tool X...", "Querying the LLM...", or "Module finished!".

The module is built around three cooperating pieces:

1. **`StatusMessageProvider`** — a customizable, subclassable source of status strings.
2. **`StatusStreamingCallback`** — a `BaseCallback` implementation that hooks into DSPy's lifecycle events and emits status messages to the active stream.
3. **`StreamResponse`** / **`StatusMessage`** — lightweight dataclasses that wrap the data sent over the stream.

Together they allow applications (e.g., chat UIs, CLIs, web frontends) to display live progress feedback while a DSPy program runs, without waiting for the final prediction.

---

## Architecture Overview

The module sits at the intersection of DSPy's **callback system**, the **global settings** singleton, and the **streaming** subsystem.

```mermaid
graph TD
    subgraph "streaming_messages module"
        SMP[StatusMessageProvider]
        SSC[StatusStreamingCallback]
        SM[StatusMessage]
        SR[StreamResponse]
        SS[sync_send_to_stream]
    end

    subgraph "DSPy Core"
        BC[BaseCallback<br/>dspy/utils/callback.py]
        SET[Settings<br/>dspy/dsp/utils/settings.py]
    end

    subgraph "Streaming Subsystem"
        SL[StreamListener<br/>streaming_listener.py]
    end

    subgraph "Execution Components"
        MOD[Module / Predict]
        LM[LM]
        TOOL[Tool]
    end

    BC -->|inherited by| SSC
    SSC -->|uses| SMP
    SSC -->|emits| SM
    SSC -->|calls| SS
    SS -->|sends to| SET
    SET -->|send_stream| STREAM[(Active Stream)]
    SL -->|produces| SR
    SR -->|sent to| STREAM

    MOD -.->|on_module_start/end| SSC
    LM -.->|on_lm_start/end| SSC
    TOOL -.->|on_tool_start/end| SSC
```

### Key Relationships

| Component | Role | Depends On |
|-----------|------|------------|
| `StatusMessageProvider` | Produces status strings for each lifecycle stage | — |
| `StatusStreamingCallback` | Bridges DSPy lifecycle events to the stream | `BaseCallback`, `StatusMessageProvider`, `Settings` |
| `StatusMessage` | Wraps a status string for transport | — |
| `StreamResponse` | Wraps a streamed output-field chunk | — |
| `sync_send_to_stream` | Sends messages from sync or async contexts | `asyncio` |

---

## Component Details

### `StreamResponse`

A dataclass representing a single streamed chunk of an **output field** value. It is the transport format produced by the [StreamListener](streaming_listener.md) and consumed by the streaming pipeline.

```python
@dataclass
class StreamResponse:
    predict_name: str
    signature_field_name: str
    chunk: str
```

| Field | Description |
|-------|-------------|
| `predict_name` | Name of the predictor that produced the chunk |
| `signature_field_name` | Name of the signature field being streamed |
| `chunk` | The incremental text content |

> **Note:** Although `StreamResponse` is defined in this module, it is primarily *produced* by `StreamListener` (see [streaming_listener.md](streaming_listener.md)). It is documented here because it is part of the shared streaming message vocabulary.

### `StatusMessage`

A minimal dataclass that wraps a human-readable status string for transport over the stream.

```python
@dataclass
class StatusMessage:
    """Dataclass that wraps a status message for status streaming."""
    message: str
```

This is the counterpart to `StreamResponse`: where `StreamResponse` carries model output, `StatusMessage` carries progress/status text.

### `StatusMessageProvider`

The **customization point** of the module. It defines a set of methods, each corresponding to a lifecycle stage, that return a status string (or `None`/`pass` to emit nothing).

```mermaid
classDiagram
    class StatusMessageProvider {
        +tool_start_status_message(instance, inputs) str
        +tool_end_status_message(outputs) str
        +module_start_status_message(instance, inputs) str
        +module_end_status_message(outputs) str
        +lm_start_status_message(instance, inputs) str
        +lm_end_status_message(outputs) str
    }
```

| Method | Triggered | Default Return |
|--------|-----------|----------------|
| `tool_start_status_message` | Before a `dspy.Tool` is called | `"Calling tool {name}..."` |
| `tool_end_status_message` | After a `dspy.Tool` is called | `"Tool calling finished! Querying the LLM with tool calling results..."` |
| `module_start_status_message` | Before a `dspy.Module`/`dspy.Predict` is called | `None` (no message) |
| `module_end_status_message` | After a `dspy.Module`/`dspy.Predict` is called | `None` (no message) |
| `lm_start_status_message` | Before a `dspy.LM` is called | `None` (no message) |
| `lm_end_status_message` | After a `dspy.LM` is called | `None` (no message) |

**Customization example:**

```python
class MyStatusMessageProvider(StatusMessageProvider):
    def lm_start_status_message(self, instance, inputs):
        return f"Calling LM with inputs {inputs}..."

    def module_end_status_message(self, outputs):
        return f"Module finished with output: {outputs}!"

program = dspy.streamify(
    dspy.Predict("q->a"),
    status_message_provider=MyStatusMessageProvider(),
)
```

### `StatusStreamingCallback`

A subclass of [`BaseCallback`](callback.md) that implements the lifecycle hooks and forwards status messages to the active stream. It is the engine that connects DSPy execution events to the streaming output.

```mermaid
classDiagram
    class BaseCallback {
        <<abstract>>
        +on_module_start(call_id, instance, inputs)
        +on_module_end(call_id, outputs, exception)
        +on_lm_start(call_id, instance, inputs)
        +on_lm_end(call_id, outputs, exception)
        +on_tool_start(call_id, instance, inputs)
        +on_tool_end(call_id, outputs, exception)
    }
    class StatusStreamingCallback {
        -status_message_provider: StatusMessageProvider
        +__init__(status_message_provider)
        +on_tool_start(...)
        +on_tool_end(...)
        +on_lm_start(...)
        +on_lm_end(...)
        +on_module_start(...)
        +on_module_end(...)
    }
    BaseCallback <|-- StatusStreamingCallback
    StatusStreamingCallback --> StatusMessageProvider : uses
```

**Constructor:**

```python
def __init__(self, status_message_provider: Optional[StatusMessageProvider] = None):
    self.status_message_provider = status_message_provider or StatusMessageProvider()
```

If no provider is supplied, a default `StatusMessageProvider` is used (which emits tool-related messages only).

**Handler behavior (common pattern):**

Each handler follows the same three-step pattern:

1. Read the active stream from `settings.send_stream`. If it is `None`, return early (streaming is disabled).
2. Ask the provider for a status message for the relevant stage.
3. If a non-empty message is returned, wrap it in a `StatusMessage` and send it via `sync_send_to_stream`.

```mermaid
flowchart TD
    A[Lifecycle event fires] --> B{settings.send_stream is None?}
    B -->|Yes| Z[Return - no streaming]
    B -->|No| C[Call provider method]
    C --> D{Message truthy?}
    D -->|No| Z
    D -->|Yes| E[Wrap in StatusMessage]
    E --> F[sync_send_to_stream]
    F --> G[Message delivered to stream]
```

**Special-case guards:**

- `on_tool_start` skips the `"finish"` tool (`instance.name == "finish"`), since that is an internal sentinel rather than a user tool.
- `on_tool_end` skips outputs equal to `"Completed."`, avoiding a redundant status message.

### `sync_send_to_stream`

A module-level helper that sends a message to a stream **regardless of whether the caller is running inside an async event loop or not**. This is necessary because DSPy callbacks may be invoked from synchronous code, asynchronous code, or threads.

```mermaid
flowchart TD
    A[sync_send_to_stream stream, message] --> B{Get running event loop}
    B -->|RuntimeError| C[Create new event loop]
    B -->|Loop found| D{loop.is_running?}
    C --> D
    D -->|Yes - async context| E[Spawn thread with new loop]
    E --> F[run_until_complete stream.send]
    D -->|No - sync context| G[loop.run_until_complete stream.send]
    F --> H[Return result]
    G --> H
```

**Logic:**

1. Attempt to obtain the current event loop via `asyncio.get_event_loop()`.
2. If none exists (`RuntimeError`), create and register a new one.
3. If the loop **is running** (async context), offload the coroutine to a fresh event loop running in a separate thread via `concurrent.futures.ThreadPoolExecutor`, then block on the result.
4. If the loop **is not running** (sync context), simply call `loop.run_until_complete(stream.send(message))`.

This dual-path design prevents the classic `RuntimeError: This event loop is already running` error when callbacks fire inside an async program.

---

## Data Flow

The following sequence diagram shows how a status message travels from a lifecycle event to the consumer.

```mermaid
sequenceDiagram
    participant Exec as DSPy Execution
    participant CB as StatusStreamingCallback
    participant Prov as StatusMessageProvider
    participant Sync as sync_send_to_stream
    participant Set as Settings
    participant Stream as Active Stream

    Exec->>CB: on_lm_start(call_id, instance, inputs)
    CB->>Set: read settings.send_stream
    Set-->>CB: stream (or None)
    alt stream is not None
        CB->>Prov: lm_start_status_message(instance, inputs)
        Prov-->>CB: "Calling LM..."
        CB->>Sync: sync_send_to_stream(stream, StatusMessage(...))
        Sync->>Stream: stream.send(StatusMessage)
    end
```

### Message Types on the Stream

The stream carries two distinct message types, both defined in the streaming subsystem:

| Type | Source | Purpose |
|------|--------|---------|
| `StreamResponse` | [StreamListener](streaming_listener.md) | Incremental output-field content |
| `StatusMessage` | `StatusStreamingCallback` | Human-readable progress/status text |

Consumers typically discriminate between them by type to render output chunks and status updates differently.

---

## Integration with the Broader System

```mermaid
graph LR
    subgraph "Configuration"
        SET[Settings singleton]
    end
    subgraph "Callbacks"
        BC[BaseCallback]
        SSC[StatusStreamingCallback]
    end
    subgraph "Streaming"
        SL[StreamListener]
        MSG[streaming_messages]
    end
    subgraph "Execution"
        PRED[Predict / Module]
        LM[LM]
        TOOL[Tool]
    end

    SET -->|send_stream| SSC
    SET -->|send_stream| SL
    BC --> SSC
    PRED -->|lifecycle events| SSC
    LM -->|lifecycle events| SSC
    TOOL -->|lifecycle events| SSC
    SL -->|StreamResponse| SET
    SSC -->|StatusMessage| SET
```

### How It Fits Together

- **`Settings`** ([settings.md](settings.md)) holds the `send_stream` attribute — the active stream object. Both `StatusStreamingCallback` and `StreamListener` read from it. If `send_stream` is `None`, streaming is effectively disabled.
- **`BaseCallback`** ([callback.md](callback.md)) defines the lifecycle hook interface. `StatusStreamingCallback` overrides the subset relevant to status streaming (`on_tool_*`, `on_lm_*`, `on_module_*`).
- **`StreamListener`** ([streaming_listener.md](streaming_listener.md)) handles the *content* streaming path and produces `StreamResponse` objects. It shares the `StreamResponse` dataclass defined in this module.
- **Execution components** (`Predict`, `Module`, `LM`, `Tool`) fire the lifecycle events that drive the callback.

---

## Usage

### Basic Usage

Status streaming is typically enabled through `dspy.streamify`, which wires up the callback and stream automatically:

```python
import dspy

program = dspy.streamify(
    dspy.Predict("q->a"),
    status_message_provider=MyStatusMessageProvider(),
)

async for value in program(q="What is 2+2?"):
    if isinstance(value, dspy.streaming.StatusMessage):
        print(f"[status] {value.message}")
    elif isinstance(value, dspy.streaming.StreamResponse):
        print(f"[{value.signature_field_name}] {value.chunk}")
```

### Custom Provider

Subclass `StatusMessageProvider` and override any of the six stage methods to emit custom status text. Returning a falsy value (e.g., `None`) suppresses the message for that stage.

---

## Summary

The `streaming_messages` module provides DSPy's **status message streaming** capability:

- **`StatusMessageProvider`** — the customizable source of status strings, with one method per lifecycle stage.
- **`StatusStreamingCallback`** — a `BaseCallback` that translates lifecycle events into streamed `StatusMessage` objects, guarded by the presence of an active stream.
- **`StatusMessage`** and **`StreamResponse`** — the two dataclasses that form the streaming message vocabulary (status text vs. output content).
- **`sync_send_to_stream`** — a robust helper that bridges sync and async execution contexts when sending to the stream.

It complements the content-streaming path in [streaming_listener.md](streaming_listener.md) and integrates with the global [settings.md](settings.md) singleton and the [callback.md](callback.md) system.
