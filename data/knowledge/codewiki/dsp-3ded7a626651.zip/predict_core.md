# predict_core

## Introduction

The `predict_core` module is the foundational execution layer of DSPy's prediction system. It provides the two most fundamental building blocks upon which every higher-level prediction strategy is built:

- **`Predict`** — the atomic, signature-driven module that turns a declarative `Signature` into an executable LM call. It orchestrates the full lifecycle of a prediction: preprocessing inputs, selecting an adapter, invoking a language model, and post-processing the raw completions into a structured `Prediction`.
- **`Parameter`** — a lightweight marker base class used to identify trainable/optimizable components within a DSPy program.

Every other prediction strategy in the `predict` package (e.g. `ChainOfThought`, `ReAct`, `ProgramOfThought`, `BestOfN`) is ultimately composed of one or more `Predict` instances. Understanding `predict_core` is therefore a prerequisite for understanding the entire prediction subsystem.

> For the higher-level strategies built on top of this module, see [predict_strategies.md](predict_strategies.md). For utility modules such as `Parallel` and `KNN`, see [predict_utilities.md](predict_utilities.md).

---

## Module Structure

```
predict_core
├── dspy/predict/predict.py    → Predict
└── dspy/predict/parameter.py  → Parameter
```

| Component | File | Role |
|-----------|------|------|
| `Predict` | `dspy/predict/predict.py` | Core executable module; performs the LM call |
| `Parameter` | `dspy/predict/parameter.py` | Marker base class for optimizable parameters |

---

## Architecture Overview

`Predict` sits at the intersection of several DSPy subsystems. It inherits from both `Module` (the program abstraction) and `Parameter` (the optimizable marker), and it delegates the actual LM interaction to an `Adapter`.

```mermaid
graph TD
    subgraph predict_core
        Predict["Predict<br/>(Module, Parameter)"]
        Parameter["Parameter"]
    end

    subgraph primitives
        Module["Module"]
        ProgramMeta["ProgramMeta"]
        Prediction["Prediction"]
    end

    subgraph signatures
        Signature["Signature"]
        SignatureMeta["SignatureMeta"]
    end

    subgraph adapters
        Adapter["Adapter"]
        ChatAdapter["ChatAdapter"]
    end

    subgraph clients
        BaseLM["BaseLM"]
        LM["LM"]
    end

    subgraph dsp_settings
        Settings["Settings"]
    end

    Predict -->|inherits| Module
    Predict -->|inherits| Parameter
    Module -->|metaclass| ProgramMeta
    Predict -->|uses| Signature
    Signature -->|metaclass| SignatureMeta
    Predict -->|creates| Prediction
    Predict -->|delegates to| Adapter
    Adapter -->|subclass| ChatAdapter
    Predict -->|calls| BaseLM
    BaseLM -->|subclass| LM
    Predict -->|reads config from| Settings
```

### Key Relationships

- **`Predict` → `Module`**: `Predict` is a `Module`, so it participates in the DSPy program graph, supports `named_predictors()`, `set_lm()`, `batch()`, and callback/usage-tracking machinery. See [primitives.md](primitives.md).
- **`Predict` → `Parameter`**: By inheriting `Parameter`, `Predict` instances are discoverable as optimizable parameters by teleprompters. See [teleprompt.md](teleprompt.md).
- **`Predict` → `Signature`**: The signature defines the input/output contract. `Predict` calls `ensure_signature()` to normalize string or class signatures. See [signatures.md](signatures.md).
- **`Predict` → `Adapter`**: The adapter converts the structured signature + inputs into LM messages and parses the response back. See [adapters_core.md](adapters_core.md).
- **`Predict` → `BaseLM`/`LM`**: The language model performs the actual generation. See [clients_lm_core.md](clients_lm_core.md).
- **`Predict` → `Settings`**: Global configuration (default LM, adapter, streaming, tracing) is read from the thread-safe `Settings` singleton. See [dsp_settings.md](dsp_settings.md).

---

## Component: `Predict`

`Predict` is the atomic executable unit of DSPy. Given a `Signature`, it produces a `Prediction` by calling a language model through an adapter.

### Class Definition

```python
class Predict(Module, Parameter):
    def __init__(self, signature, callbacks=None, **config):
        ...
```

### Construction

| Parameter | Description |
|-----------|-------------|
| `signature` | A `Signature` class, a string like `"question -> answer"`, or a callable. Normalized via `ensure_signature()`. |
| `callbacks` | Optional list of callbacks forwarded to the `Module` base. |
| `**config` | Default LM call configuration (e.g. `temperature`, `n`, `max_tokens`) stored on `self.config`. |

On construction, `Predict`:
1. Generates a random `stage` identifier (`random.randbytes(8).hex()`).
2. Normalizes the signature with `ensure_signature()`.
3. Stores `config` and calls `reset()`.

### Internal State

`reset()` initializes the mutable runtime state:

| Attribute | Purpose |
|-----------|---------|
| `self.lm` | The LM instance bound to this predictor (or `None` to fall back to `settings.lm`). |
| `self.traces` | Recorded execution traces. |
| `self.train` | Training examples. |
| `self.demos` | Few-shot demonstrations used during calls. |

### State Serialization

`Predict` supports full state round-tripping, which is essential for saving/loading compiled programs:

- **`dump_state()`** — Serializes `traces`, `train`, `demos` (with each field passed through `serialize_object`), the signature state, and the LM state.
- **`load_state(state)`** — Restores state, with special handling for `signature`, `extended_signature` (legacy, raises `NotImplementedError` in DSPy 2.6+), and `lm`.

The module-level helper `serialize_object()` recursively converts Pydantic models, lists, tuples, and dicts into JSON-compatible structures.

---

## Execution Flow

The core of `Predict` is its `forward` / `aforward` methods, which are split into a **preprocess**, **adapter invocation**, and **postprocess** phase.

```mermaid
flowchart TD
    Start([__call__ / acall]) --> PosCheck{Positional args?}
    PosCheck -->|Yes| Err[Raise ValueError]
    PosCheck -->|No| Pre[_forward_preprocess]

    Pre --> ExtractSig[Extract signature, demos, config]
    ExtractSig --> ResolveLM[Resolve LM: kwarg → self.lm → settings.lm]
    ResolveLM --> LMCheck{LM valid?}
    LMCheck -->|None| LMErr[Raise 'No LM loaded']
    LMCheck -->|str| StrErr[Raise 'LM must be BaseLM']
    LMCheck -->|Valid| TempAdjust[Adjust temperature if n>1 and temp<=0.15]
    TempAdjust --> WarnMissing[Warn on missing input fields]

    WarnMissing --> StreamCheck{_should_stream?}
    StreamCheck -->|Yes| StreamCall[adapter with caller_predict context]
    StreamCheck -->|No| NoStreamCall[adapter with send_stream=None]

    StreamCall --> Post[_forward_postprocess]
    NoStreamCall --> Post
    Post --> BuildPred[Prediction.from_completions]
    BuildPred --> TraceCheck{settings.trace set?}
    TraceCheck -->|Yes| AppendTrace[Append to trace]
    TraceCheck -->|No| Return
    AppendTrace --> Return([Return Prediction])
```

### Phase 1 — `_forward_preprocess(**kwargs)`

This method extracts the "privileged" keyword arguments and prepares the call:

1. **Signature** — Pops `signature` (defaults to `self.signature`), normalized via `ensure_signature()`. Asserts `new_signature` is not used (removed in DSPy 2.6+).
2. **Demos** — Pops `demos` (defaults to `self.demos`).
3. **Config** — Merges `self.config` with any `config` kwarg.
4. **LM resolution** — Resolves in priority order: `lm` kwarg → `self.lm` → `settings.lm`. Raises descriptive errors if no LM is loaded or if a string is passed instead of a `BaseLM` instance.
5. **Temperature adjustment** — If `temperature` is unset or `<= 0.15` and `n > 1`, sets `temperature = 0.7` to preserve sampling randomness.
6. **Predicted outputs** — If a `prediction` kwarg matches the OpenAI predicted-outputs format, it is moved from inputs into the LM config.
7. **Input validation** — Logs a warning if not all signature input fields are present.

### Phase 2 — Adapter Invocation

The adapter is selected from `settings.adapter` (falling back to `ChatAdapter()`). Streaming behavior is determined by `_should_stream()`:

- Streaming is enabled when `settings.send_stream` is set **and** either there are no stream listeners or at least one listener targets this predictor.
- When streaming, the call runs inside `settings.context(caller_predict=self)`.
- Otherwise, it runs inside `settings.context(send_stream=None)`.

The adapter is invoked as `adapter(lm, lm_kwargs=config, signature=signature, demos=demos, inputs=kwargs)` (or `await adapter.acall(...)` for the async path).

### Phase 3 — `_forward_postprocess(completions, signature, **kwargs)`

1. Builds a `Prediction` via `Prediction.from_completions(completions, signature=signature)`.
2. If `_trace` is truthy and `settings.trace` is set, appends `(self, kwargs, pred)` to the trace.

---

## Component: `Parameter`

```python
class Parameter:
    pass
```

`Parameter` is an intentionally empty marker base class. Its sole purpose is to serve as a type tag so that DSPy's introspection machinery (e.g. `Module.named_parameters()`, teleprompters) can identify which attributes of a program are optimizable parameters.

`Predict` inherits from `Parameter`, which is what makes every `Predict` instance discoverable as a trainable component. Higher-level strategies that wrap `Predict` (such as `ChainOfThought`) inherit this behavior transitively.

> For details on how parameters are discovered and optimized, see [primitives.md](primitives.md) and [teleprompt.md](teleprompt.md).

---

## Data Flow

The following diagram shows how data flows from a user call through `Predict` to the LM and back.

```mermaid
sequenceDiagram
    participant User
    participant Predict
    participant Settings
    participant Adapter
    participant LM
    participant Prediction

    User->>Predict: __call__(**inputs)
    Predict->>Predict: _forward_preprocess()
    Predict->>Settings: read settings.lm / settings.adapter
    Settings-->>Predict: lm, adapter
    Predict->>Adapter: adapter(lm, lm_kwargs, signature, demos, inputs)
    Adapter->>Adapter: format(signature, demos, inputs)
    Adapter->>LM: lm(messages=..., **lm_kwargs)
    LM-->>Adapter: raw completions
    Adapter->>Adapter: parse(signature, completion)
    Adapter-->>Predict: list[dict] outputs
    Predict->>Prediction: Prediction.from_completions(...)
    Prediction-->>Predict: Prediction object
    Predict-->>User: Prediction
```

### Inputs and Outputs

| Stage | Input | Output |
|-------|-------|--------|
| `_forward_preprocess` | Raw `**kwargs` | `(lm, config, signature, demos, kwargs)` |
| Adapter `format` | signature, demos, inputs | LM messages |
| LM call | messages, config | Raw completions |
| Adapter `parse` | signature, completion | `list[dict]` of output fields |
| `_forward_postprocess` | completions, signature | `Prediction` |

---

## Configuration and Context

`Predict` reads and writes configuration through the thread-safe `Settings` singleton (see [dsp_settings.md](dsp_settings.md)). The relevant settings are:

| Setting | Usage in `Predict` |
|---------|--------------------|
| `settings.lm` | Default LM when neither the `lm` kwarg nor `self.lm` is set. |
| `settings.adapter` | Adapter used for formatting/parsing (defaults to `ChatAdapter`). |
| `settings.trace` | If set, execution traces are appended. |
| `settings.send_stream` | Enables streaming mode. |
| `settings.stream_listeners` | Determines whether this predictor should stream. |
| `settings.track_usage` | Enables token usage tracking (handled by `Module.__call__`). |

### Per-call Configuration

`Predict` supports both persistent and per-call configuration:

- **`update_config(**kwargs)`** — Merges new defaults into `self.config`.
- **`get_config()`** — Returns the current default config.
- **Per-call overrides** — Passing `config={...}`, `lm=...`, `demos=...`, or `signature=...` as keyword arguments overrides defaults for that single call only.

---

## Async Support

`Predict` provides a fully asynchronous execution path via `acall` / `aforward`, mirroring the synchronous `__call__` / `forward`:

- `acall` rejects positional arguments identically to `__call__`.
- `aforward` uses `await adapter.acall(...)` instead of the synchronous adapter call.
- All preprocessing and postprocessing logic is shared between the sync and async paths.

This enables `Predict` to be used inside async programs and parallel executors. See [predict_utilities.md](predict_utilities.md) for `Parallel`.

---

## Error Handling

`Predict` raises descriptive errors for common misconfigurations:

| Condition | Error |
|-----------|-------|
| Positional arguments passed | `ValueError` with guidance to use keyword arguments matching input fields. |
| No LM loaded | `ValueError` suggesting `dspy.configure(lm=dspy.LM(...))`. |
| LM passed as a string | `ValueError` explaining the need for a `BaseLM` instance. |
| LM is not a `BaseLM` | `ValueError` reporting the received type. |
| `new_signature` kwarg used | `AssertionError` (removed in DSPy 2.6+). |
| Loading `extended_signature` | `NotImplementedError` (legacy, removed in DSPy 2.6+). |

---

## Integration with the Broader System

```mermaid
graph LR
    subgraph "Higher-level strategies"
        CoT[ChainOfThought]
        ReAct[ReAct]
        PoT[ProgramOfThought]
        BoN[BestOfN]
    end

    subgraph "predict_core"
        Predict[Predict]
        Parameter[Parameter]
    end

    subgraph "Optimization"
        Teleprompt[Teleprompters]
    end

    CoT -->|composes| Predict
    ReAct -->|composes| Predict
    PoT -->|composes| Predict
    BoN -->|composes| Predict
    Teleprompt -->|discovers via| Parameter
    Teleprompt -->|optimizes| Predict
```

### How Other Modules Use `predict_core`

- **`predict_strategies`** — Every strategy (`ChainOfThought`, `ReAct`, `ProgramOfThought`, `CodeAct`, `MultiChainComparison`, `BestOfN`, `Refine`, `Avatar`) is built by composing one or more `Predict` instances. See [predict_strategies.md](predict_strategies.md).
- **`predict_utilities`** — `Parallel` and `KNN` operate on `Predict`-based modules. See [predict_utilities.md](predict_utilities.md).
- **`teleprompt`** — Optimizers discover `Predict` instances through the `Parameter` marker and tune their signatures, demos, and configs. See [teleprompt.md](teleprompt.md).
- **`primitives`** — `Module` provides the program abstraction and `Prediction` the output container. See [primitives.md](primitives.md).
- **`adapters`** — Adapters handle the format/parse boundary between structured signatures and LM messages. See [adapters_core.md](adapters_core.md).
- **`clients`** — `BaseLM`/`LM` perform the actual generation. See [clients_lm_core.md](clients_lm_core.md).
- **`signatures`** — `Signature` defines the input/output contract. See [signatures.md](signatures.md).

---

## Summary

The `predict_core` module provides the minimal, composable execution primitive of DSPy:

- **`Predict`** is a `Module` + `Parameter` that binds a `Signature` to an LM call, handling preprocessing, adapter selection, streaming, tracing, and postprocessing into a `Prediction`.
- **`Parameter`** is a marker base class enabling parameter discovery by optimizers.

Because every prediction strategy is ultimately composed of `Predict` instances, this module is the bedrock of DSPy's prediction and optimization ecosystem. Its clean separation of concerns — signature (contract), adapter (formatting), LM (generation), and settings (configuration) — makes it both extensible and easy to reason about.
