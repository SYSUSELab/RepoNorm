# Adapter Types: History

## Introduction

The `adapter_types_history` module provides the `History` class, a specialized DSPy custom type used to represent **multi-turn conversation history** within a DSPy signature. It enables stateful, conversational interactions with language models by allowing prior exchanges (questions and answers) to be passed as structured input to a `Predict` module.

The `History` type is one of several custom types in the `dspy.adapters.types` package (alongside [`Image`](adapter_types_image.md), [`Audio`](adapter_types_audio.md), and [`Tool`/`ToolCalls`](adapter_types_tool.md)). It is consumed by the adapter layer (see [`adapters_core`](adapters_core.md)) to format conversation history into multi-turn messages for the LM.

---

## Core Component

### `History`

`History` is a frozen [Pydantic](https://docs.pydantic.dev/) `BaseModel` that wraps a list of message dictionaries.

```python
class History(pydantic.BaseModel):
    messages: list[dict[str, Any]]

    model_config = {
        "frozen": True,
        "str_strip_whitespace": True,
        "validate_assignment": True,
        "extra": "forbid",
    }
```

#### Fields

| Field      | Type                    | Description                                                                                          |
| ---------- | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| `messages` | `list[dict[str, Any]]`  | A list of message entities. Each dictionary's keys must correspond to the fields of the associated signature. |

#### Model Configuration

| Setting                 | Value    | Purpose                                                                 |
| ----------------------- | -------- | ----------------------------------------------------------------------- |
| `frozen`                | `True`   | Instances are immutable after creation.                                 |
| `str_strip_whitespace`  | `True`   | Leading/trailing whitespace is stripped from string values.             |
| `validate_assignment`   | `True`   | Values are re-validated on assignment (relevant for nested structures). |
| `extra`                 | `forbid` | Unknown fields raise a validation error.                                |

> **Note:** Unlike other custom types such as `Image`, `Audio`, and `Tool`, `History` does **not** subclass [`BaseType`](adapter_types_base_type.md). It is a plain Pydantic model. The adapter layer detects it by exact annotation match (`field.annotation == History`) rather than through the `BaseType` serialization mechanism.

---

## Usage

### Basic Conversation History

The `messages` list must contain dictionaries whose keys match the fields of the signature in which the history is used.

```python
import dspy

dspy.settings.configure(lm=dspy.LM("openai/gpt-4o-mini"))

class MySignature(dspy.Signature):
    question: str = dspy.InputField()
    history: dspy.History = dspy.InputField()
    answer: str = dspy.OutputField()

history = dspy.History(
    messages=[
        {"question": "What is the capital of France?", "answer": "Paris"},
        {"question": "What is the capital of Germany?", "answer": "Berlin"},
    ]
)

predict = dspy.Predict(MySignature)
outputs = predict(question="What is the capital of France?", history=history)
```

### Capturing History Dynamically

History can be built incrementally by combining prior outputs with new questions:

```python
predict = dspy.Predict(MySignature)
outputs = predict(question="What is the capital of France?")
history = dspy.History(messages=[{"question": "What is the capital of France?", **outputs}])
outputs_with_history = predict(question="Are you sure?", history=history)
```

---

## Architecture and Integration

### Position in the Type Hierarchy

```mermaid
classDiagram
    class BaseType {
        <<abstract>>
        +format() list|str
        +description() str
        +extract_custom_type_from_annotation(annotation)
        +serialize_model()
    }
    class History {
        +messages: list[dict[str, Any]]
    }
    class Image
    class Audio
    class Tool
    class ToolCalls

    BaseType <|-- Image
    BaseType <|-- Audio
    BaseType <|-- Tool
    BaseType <|-- ToolCalls
    note for History "Standalone Pydantic model\n(does NOT inherit BaseType)"
```

`History` is intentionally decoupled from `BaseType`. While `BaseType` subclasses are serialized into content parts (e.g., image URLs, audio data) via `serialize_model`, `History` is handled specially by the adapter's formatting pipeline.

### How the Adapter Consumes History

The [`Adapter`](adapters_core.md) base class detects a history field by exact annotation match and expands it into multi-turn messages.

```mermaid
flowchart TD
    A["Adapter.format(signature, demos, inputs)"] --> B{"_get_history_field_name(signature)"}
    B -->|"field.annotation == History"| C["signature.delete(history_field_name)"]
    C --> D["format_conversation_history(...)"]
    D --> E["For each message:<br/>user message + assistant message"]
    E --> F["Remove history field from inputs"]
    F --> G["Append current input as final user message"]
    B -->|"No history field"| H["Append current input only"]
    G --> I["split_message_content_for_custom_types(messages)"]
    H --> I
    I --> J["Return multiturn messages"]
```

The key detection logic in `Adapter`:

```python
def _get_history_field_name(self, signature: Type[Signature]) -> bool:
    for name, field in signature.input_fields.items():
        if field.annotation == History:
            return name
    return None
```

When a history field is found, `format_conversation_history` iterates over `inputs[history_field_name].messages` and produces alternating `user`/`assistant` messages, then removes the history field from the inputs so it is not duplicated in the current request.

### Message Flow Through the Adapter Pipeline

```mermaid
sequenceDiagram
    participant User
    participant Predict
    participant Adapter
    participant LM

    User->>Predict: predict(question, history=History(...))
    Predict->>Adapter: __call__(lm, lm_kwargs, signature, demos, inputs)
    Adapter->>Adapter: _call_preprocess(...)
    Adapter->>Adapter: format(signature, demos, inputs)
    Note over Adapter: Detect History field,<br/>expand into user/assistant turns
    Adapter->>LM: messages=[system, demos..., history turns..., current input]
    LM-->>Adapter: raw completion
    Adapter->>Adapter: _call_postprocess(...)
    Adapter->>Adapter: parse(signature, text)
    Adapter-->>Predict: parsed output dict
    Predict-->>User: Prediction
```

---

## Dependencies

```mermaid
graph LR
    History["History<br/>(history.py)"]
    Pydantic["pydantic.BaseModel"]
    Adapter["Adapter<br/>(adapters/base.py)"]
    ChatAdapter["ChatAdapter"]
    JSONAdapter["JSONAdapter"]
    Signature["Signature"]

    History --> Pydantic
    Adapter -->|"detects & formats"| History
    ChatAdapter --> Adapter
    JSONAdapter --> ChatAdapter
    Adapter --> Signature
```

| Dependency                | Relationship                                                                 |
| ------------------------- | ---------------------------------------------------------------------------- |
| `pydantic.BaseModel`      | Base class providing validation, immutability, and serialization.            |
| [`Adapter`](adapters_core.md) | Detects `History` fields and formats them into multi-turn messages.      |
| [`ChatAdapter`](adapters_core.md) | Inherits history formatting; produces `[[ ## field ## ]]` sections. |
| [`JSONAdapter`](adapters_core.md) | Inherits history formatting; produces JSON-structured messages.      |
| [`Signature`](signatures.md) | Defines the fields whose keys must match the history message dictionaries. |

---

## Design Considerations

1. **Immutability (`frozen=True`)** — History objects cannot be mutated after creation, ensuring that conversation state passed to a `Predict` call is not accidentally altered. To extend history, create a new `History` instance.

2. **Signature-coupled message keys** — The keys of each message dictionary must match the fields of the signature using the history. This tight coupling means the same `History` object is only valid for signatures with compatible field names.

3. **No `BaseType` inheritance** — Because `History` is not a `BaseType`, it does not participate in the `serialize_model` / `CUSTOM_TYPE_START_IDENTIFIER` content-part mechanism. Instead, the adapter expands it into discrete conversation turns, which is the semantically correct representation for multi-turn dialogue.

4. **Field removal during formatting** — The adapter deletes the history field from the signature and inputs before formatting the current request, preventing the raw history object from being serialized into the current user message.

---

## Related Modules

- [`adapter_types_base_type`](adapter_types_base_type.md) — The abstract base for custom types (`Image`, `Audio`, `Tool`).
- [`adapter_types_image`](adapter_types_image.md) — Image custom type.
- [`adapter_types_audio`](adapter_types_audio.md) — Audio custom type.
- [`adapter_types_tool`](adapter_types_tool.md) — `Tool` and `ToolCalls` custom types for function calling.
- [`adapters_core`](adapters_core.md) — The `Adapter`, `ChatAdapter`, `JSONAdapter`, `XMLAdapter`, and `TwoStepAdapter` implementations that consume `History`.
- [`signatures`](signatures.md) — Signature definitions that determine history message keys.
