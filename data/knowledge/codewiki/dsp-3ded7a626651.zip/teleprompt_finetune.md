# Teleprompt Finetune Module

## Introduction

The `teleprompt_finetune` module provides DSPy optimizers that improve programs by **fine-tuning the underlying language models** (weights), as opposed to only optimizing prompts or few-shot demonstrations. It is one of the optimization families within the broader [teleprompt](teleprompt_core.md) subsystem.

The module contains three core optimizers:

| Component | File | Purpose |
|-----------|------|---------|
| `FinetuneTeleprompter` | `dspy/teleprompt/bootstrap_finetune.py` | Base class that normalizes `train_kwargs`/`adapter` arguments into per-`LM` dictionaries. |
| `BootstrapFinetune` | `dspy/teleprompt/bootstrap_finetune.py` | Bootstraps traces from a teacher program and fine-tunes the student's LMs via supervised fine-tuning (SFT). |
| `GRPO` | `dspy/teleprompt/grpo.py` | Group Relative Policy Optimization — an online reinforcement-learning optimizer that updates LMs in place across training steps. |
| `BetterTogether` | `dspy/teleprompt/bettertogether.py` | Meta-optimizer that alternates between prompt optimization (`p`) and weight optimization (`w`) strategies. |

Supporting utilities (`bootstrap_trace_data`, `FailedPrediction`, `prepare_teacher`, `assert_structural_equivalency`, etc.) live in `bootstrap_finetune.py` and are shared across the optimizers.

---

## Architecture Overview

All optimizers in this module extend the abstract [`Teleprompter`](teleprompt_core.md) base class and ultimately rely on the [`LM`](clients_lm_core.md) client's fine-tuning / reinforcement interfaces.

```mermaid
graph TD
    Teleprompter["Teleprompter (abstract)"]
    FinetuneTeleprompter["FinetuneTeleprompter"]
    BootstrapFinetune["BootstrapFinetune"]
    GRPO["GRPO"]
    BetterTogether["BetterTogether"]

    Teleprompter --> FinetuneTeleprompter
    FinetuneTeleprompter --> BootstrapFinetune
    FinetuneTeleprompter --> GRPO
    Teleprompter --> BetterTogether

    BootstrapFinetune -->|uses| BootstrapFewShotWithRandomSearch
    BetterTogether -->|prompt_optimizer| BootstrapFewShotWithRandomSearch
    BetterTogether -->|weight_optimizer| BootstrapFinetune

    BootstrapFinetune -->|lm.finetune| TrainingJob
    GRPO -->|lm.reinforce| ReinforceJob
```

### Class Hierarchy

```mermaid
classDiagram
    class Teleprompter {
        +compile(student, trainset, teacher, valset)
        +get_params()
    }
    class FinetuneTeleprompter {
        +train_kwargs: Dict[LM, Any]
        +convert_to_lm_dict(arg)
    }
    class BootstrapFinetune {
        +metric
        +multitask
        +adapter: Dict[LM, Adapter]
        +exclude_demos
        +num_threads
        +compile(student, trainset, teacher)
        +finetune_lms(finetune_dict)
        +_prepare_finetune_data(...)
    }
    class GRPO {
        +num_train_steps
        +num_rollouts_per_grpo_step
        +num_dspy_examples_per_grpo_step
        +compile(student, trainset, teacher, valset)
        +report_validation_metrics(...)
        +select_training_sample_and_update_shuffled_trainset(...)
    }
    class BetterTogether {
        +prompt_optimizer
        +weight_optimizer
        +compile(student, trainset, strategy, valset_ratio)
    }

    Teleprompter <|-- FinetuneTeleprompter
    FinetuneTeleprompter <|-- BootstrapFinetune
    FinetuneTeleprompter <|-- GRPO
    Teleprompter <|-- BetterTogether
```

---

## Component Details

### `FinetuneTeleprompter`

The base class for all fine-tuning optimizers. Its primary responsibility is to normalize the `train_kwargs` argument so that it can be either:

- a single `dict` applied to **all** LMs, or
- a `Dict[LM, dict]` mapping each specific `LM` to its own training kwargs.

```python
class FinetuneTeleprompter(Teleprompter):
    def __init__(self, train_kwargs=None):
        self.train_kwargs = self.convert_to_lm_dict(train_kwargs or {})

    @staticmethod
    def convert_to_lm_dict(arg) -> Dict[LM, Any]:
        # If arg is a dict keyed by LM, keep it; otherwise default to all LMs.
        ...
```

`convert_to_lm_dict` returns a `defaultdict` when the argument is not already keyed by `LM`, so any LM lookup returns the same shared value.

---

### `BootstrapFinetune`

`BootstrapFinetune` performs **supervised fine-tuning (SFT)**. It:

1. Validates that all predictors have LMs.
2. Bootstraps trace data by running the teacher program(s) over the training set.
3. Filters traces using the optional `metric`.
4. Converts traces into adapter-specific fine-tuning data.
5. Launches one fine-tuning job per unique `(LM, data_key)` pair.
6. Replaces the student's predictor LMs with the fine-tuned LMs.

#### Constructor Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `metric` | `Optional[Callable]` | Filters bootstrapped traces; only traces with a truthy score are kept. |
| `multitask` | `bool` | If `True`, a single fine-tuning job is shared across all predictors using the same LM. If `False`, one job per predictor. |
| `train_kwargs` | `dict` or `Dict[LM, dict]` | Provider-specific training hyperparameters. |
| `adapter` | `Adapter` or `Dict[LM, Adapter]` | Adapter used to format fine-tuning data. Defaults to `ChatAdapter`. |
| `exclude_demos` | `bool` | If `True`, few-shot demos are stripped from the training data. |
| `num_threads` | `Optional[int]` | Number of concurrent fine-tuning jobs; must be ≥ number of jobs. |

#### Compilation Flow

```mermaid
flowchart TD
    A[compile student, trainset, teacher] --> B[all_predictors_have_lms]
    B --> C[prepare_teacher for each teacher]
    C --> D[bootstrap_trace_data per teacher]
    D --> E[Group traces by LM + data_key]
    E --> F[_prepare_finetune_data per group]
    F --> G{num jobs > num_threads?}
    G -->|Yes| H[Raise ValueError]
    G -->|No| I[finetune_lms: launch jobs]
    I --> J[Replace predictor LMs with finetuned LMs]
    J --> K[Set student._compiled = True]
```

#### Key Methods

- **`finetune_lms(finetune_dict)`** — Calls `lm.kill()` to free resources, then `lm.finetune(...)` for each job. Blocks on `job.result()` and joins each job thread.
- **`_prepare_finetune_data(trace_data, lm, pred_ind)`** — Filters traces by metric, builds call data via `build_call_data_from_trace`, shuffles deterministically (`random.Random(0)`), and infers the data format via `infer_data_format`.

> **Note:** `BootstrapFinetune` creates **new** LM instances after training (via `LM.copy`), unlike `GRPO` which updates LMs in place.

---

### `GRPO` (Group Relative Policy Optimization)

`GRPO` is an **online reinforcement-learning** optimizer. Instead of a single supervised pass, it runs a training loop where, at each step, it:

1. Samples a batch of training examples.
2. Generates multiple rollouts per example (a "GRPO group") using the teacher(s).
3. Scores each rollout with the metric.
4. Sends the grouped rollouts to the LM's `reinforce` job for a policy update.

#### Constructor Parameters (selected)

| Parameter | Default | Description |
|-----------|---------|-------------|
| `num_train_steps` | `100` | Number of GRPO training iterations. |
| `num_dspy_examples_per_grpo_step` | `1` | Examples sampled per training step. |
| `num_rollouts_per_grpo_step` | `1` | Rollouts (group size) per example. |
| `use_train_as_val` | `False` | Use the training set as the validation set. |
| `num_steps_for_val` | `5` | Frequency (in steps) of validation reporting. |
| `report_train_scores` | `False` | Report training scores during validation. |
| `failure_score` | `0` | Reward for a failed (but parseable) prediction. |
| `format_failure_score` | `-1` | Reward for a formatting failure. |
| `variably_invoked_predictor_grouping_mode` | `"truncate"` | How to align groups when predictors are invoked a variable number of times (`truncate`, `fill`, `ragged`). |
| `variably_invoked_predictor_fill_strategy` | `None` | Fill strategy (`randint` or `max`) when mode is `fill`. |

#### Constraints

- `failure_score > format_failure_score` (the range is used to interpolate formatting rewards).
- `exclude_demos` must be `True` (demos not yet supported).
- `multitask` must be `True` (independent per-predictor jobs not yet supported).
- The student program must use a **single** LM across all predictors.
- The student program must be included in the `teachers` list.
- `num_rollouts_per_grpo_step` must be divisible by the number of teachers.

#### Training Loop

```mermaid
flowchart TD
    A[compile student, trainset, teacher, valset] --> B[Validate inputs & structure]
    B --> C[Disable LM cache for all programs]
    C --> D[Create ReinforceJob per unique LM]
    D --> E[Report pre-training validation metrics]
    E --> F[For each train_step]
    F --> G[Select training sample & update shuffled trainset]
    G --> H[bootstrap_trace_data per teacher]
    H --> I[validate_trace_data_and_log_issues]
    I --> J[Build GRPOGroup batches per predictor]
    J --> K[Handle variably-invoked predictors]
    K --> L[job.step train_data, GRPO_CHAT]
    L --> M[Report validation metrics]
    M --> F
    F --> N[Terminate jobs]
    N --> O[Recover LM caches]
    O --> P[student._compiled = True]
```

#### Key Methods

- **`report_validation_metrics(student, trainset, valset, logger, step_idx)`** — Evaluates the student on the validation set (or train set) at configurable intervals using [`Evaluate`](evaluate_orchestration.md).
- **`update_shuffled_trainset(original_trainset)`** — Reshuffles example IDs each epoch and pads the set so its length is divisible by `num_dspy_examples_per_grpo_step`, favoring least-frequently-used examples.
- **`select_training_sample_and_update_shuffled_trainset(...)`** — Returns the batch of examples for the current step, advancing epochs as needed.
- **`validate_trace_data_and_log_issues(...)`** — Asserts the shape of bootstrapped trace data and logs warnings for empty/malformed traces.

#### Cache Handling

GRPO disables the LM cache during training (via `disable_lm_cache`) to ensure diverse rollouts, then restores the original cache state with `recover_lm_cache`.

---

### `BetterTogether`

`BetterTogether` is an **experimental** meta-optimizer (requires `dspy.settings.experimental = True`). It alternates between prompt optimization and weight optimization according to a strategy string such as `"p -> w -> p"`.

- `p` → prompt optimization (default: [`BootstrapFewShotWithRandomSearch`](teleprompt_bootstrap.md))
- `w` → weight optimization (default: `BootstrapFinetune`)

#### Compilation Flow

```mermaid
flowchart TD
    A[compile student, trainset, strategy, valset_ratio] --> B[Parse strategy string]
    B --> C[prepare_student + all_predictors_have_lms]
    C --> D[For each step in strategy]
    D --> E[Shuffle trainset]
    E --> F{step == p?}
    F -->|Yes| G[_compile_prompt_optimizer]
    F -->|No| H[_compile_weight_optimizer]
    G --> I[Record candidate program]
    H --> I
    I --> D
    D --> J[Attach candidate_programs to student]
```

#### Key Methods

- **`_compile_prompt_optimizer(student, trainset, valset_ratio)`** — Splits the trainset into a prompt validation set and prompt training set, drops `hint` inputs, and runs the prompt optimizer. It manually restores predictor LMs afterward (a workaround for BFRS resetting them).
- **`_compile_weight_optimizer(student, trainset)`** — Runs the weight optimizer and propagates `train_kwargs` from the original LMs to the newly created fine-tuned LMs.

---

## Shared Utilities (`bootstrap_finetune.py`)

These module-level functions are reused by `BootstrapFinetune`, `GRPO`, and `BetterTogether`.

| Function | Description |
|----------|-------------|
| `bootstrap_trace_data(program, dataset, metric, ...)` | Runs a program over a dataset, capturing `(example, prediction, trace, score)` dicts. Handles `AdapterParseError` by producing `FailedPrediction` entries with interpolated format rewards. |
| `build_call_data_from_trace(trace, pred_ind, adapter, exclude_demos)` | Extracts a single predictor's call data from a trace and formats it via `adapter.format_finetune_data`. |
| `all_predictors_have_lms(program)` | Returns `True` if every predictor has an LM. |
| `prepare_student(student)` | Validates the student is not already compiled. |
| `prepare_teacher(student, teacher)` | Validates structural equivalency and no shared predictors. |
| `assert_structural_equivalency(program1, program2)` | Asserts matching predictor counts and names. |
| `assert_no_shared_predictor(program1, program2)` | Asserts the two programs share no predictor instances. |
| `get_unique_lms(program)` / `launch_lms` / `kill_lms` | LM lifecycle helpers. |
| `copy_program_with_lms(program)` | Deep-copies a program while preserving predictor LMs. |

### `FailedPrediction`

A dataclass capturing a malformed LM response:

```python
@dataclass
class FailedPrediction:
    completion_text: str
    format_reward: Union[float, None] = None
```

When the adapter fails to parse an LM response, `bootstrap_trace_data` records a `FailedPrediction` with a `format_reward` interpolated between `format_failure_score` and `failure_score` based on how many expected output fields were present.

---

## Data Flow

The following diagram shows how data flows from a training set through bootstrapping into fine-tuning data.

```mermaid
flowchart LR
    TS[trainset: List Example] --> BT[bootstrap_trace_data]
    Teacher[teacher program] --> BT
    BT -->|trace_data| Filter{metric filter}
    Filter -->|scored traces| BCD[build_call_data_from_trace]
    BCD --> Adapter[adapter.format_finetune_data]
    Adapter --> FD[finetune data: messages]
    FD --> Job[LM.finetune / ReinforceJob.step]
    Job --> NewLM[finetuned LM]
    NewLM --> Student[student program]
```

### Fine-tuning Data Formats

The data format is inferred by `infer_data_format` and represented by the `TrainDataFormat` enum:

| Format | Value | Used By |
|--------|-------|---------|
| `CHAT` | `"chat"` | `BootstrapFinetune` (via `ChatAdapter`) |
| `COMPLETION` | `"completion"` | Text-completion fine-tuning |
| `GRPO_CHAT` | `"grpo_chat"` | `GRPO` |

For GRPO, each training group is a list of `GRPOChatData`:

```python
class GRPOChatData(TypedDict):
    messages: List[Message]
    completion: MessageAssistant
    reward: float
```

---

## Dependencies

```mermaid
graph TD
    subgraph teleprompt_finetune
        BF[bootstrap_finetune.py]
        GR[grpo.py]
        BT[bettertogether.py]
    end

    BF --> Adapters[adapters]
    BF --> LM[clients/lm.py]
    BF --> UtilsFinetune[clients/utils_finetune.py]
    BF --> Evaluate[evaluate/evaluate.py]
    BF --> Predict[predict/predict.py]
    BF --> Primitives[primitives]
    BF --> TelepromptCore[teleprompt/teleprompt.py]

    GR --> BF
    GR --> UtilsFinetune
    GR --> Evaluate

    BT --> BF
    BT --> RandomSearch[teleprompt/random_search.py]
    BT --> TelepromptCore
```

### External Module References

- **[adapters](adapters_core.md)** — `Adapter`, `ChatAdapter` provide `format_finetune_data` and `format` used to build training data.
- **[clients_lm_core](clients_lm_core.md)** — `LM.finetune()` and `LM.reinforce()` are the entry points to provider training jobs.
- **[clients_finetune_utils](clients_finetune_utils.md)** — `TrainDataFormat`, `GRPOChatData`, `Message`, `infer_data_format`.
- **[clients_providers](clients_providers.md)** — `TrainingJob` (a `Future`) and `ReinforceJob` abstract interfaces.
- **[evaluate_orchestration](evaluate_orchestration.md)** — `Evaluate` is used for bootstrapping and validation.
- **[teleprompt_core](teleprompt_core.md)** — `Teleprompter` base class.
- **[teleprompt_bootstrap](teleprompt_bootstrap.md)** — `BootstrapFewShotWithRandomSearch` used by `BetterTogether`.

---

## Component Interaction Summary

```mermaid
sequenceDiagram
    participant User
    participant BF as BootstrapFinetune
    participant Teacher
    participant Eval as Evaluate
    participant LM
    participant Job as TrainingJob

    User->>BF: compile(student, trainset, teacher)
    BF->>Teacher: run over trainset
    Teacher->>Eval: bootstrap_trace_data
    Eval-->>BF: trace_data (with scores)
    BF->>BF: _prepare_finetune_data (filter + format)
    BF->>LM: kill()
    BF->>LM: finetune(train_data, format, kwargs)
    LM->>Job: start thread
    Job-->>LM: finetuned LM
    LM-->>BF: new LM
    BF->>BF: replace predictor LMs
    BF-->>User: compiled student
```

---

## Usage Notes & Limitations

- **`BootstrapFinetune`** requires `num_threads >= number of fine-tuning jobs`, otherwise it raises a `ValueError`.
- **`GRPO`** currently only supports `multitask=True`, `exclude_demos=True`, and a single LM across the student program.
- **`BetterTogether`** is experimental and only supports `BootstrapFewShotWithRandomSearch` (prompt) and `BootstrapFinetune` (weight) optimizers.
- Both `BootstrapFinetune` and `GRPO` set `student._compiled = True` upon completion.
- GRPO updates LMs **in place**, while BootstrapFinetune creates **new** LM instances — a known inconsistency noted in the source.
