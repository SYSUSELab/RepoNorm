# Evaluate Auto Metrics

## Introduction

The **Evaluate Auto Metrics** module (`dspy/evaluate/auto_evaluation.py`) provides a collection of **LLM-as-a-judge** metric functions for evaluating the quality of a DSPy program's responses. Unlike deterministic metrics (exact match, string similarity), these metrics use a language model to reason about semantic properties of a response — such as how much of the ground truth it covers, how precise it is, and whether it is grounded in retrieved context.

These metrics are designed to be passed directly as the `metric` argument to the [`Evaluate`](evaluate_orchestration.md) class, or used as reward/feedback signals during optimization (e.g., in teleprompters).

The module exposes two categories of metrics:

1. **Recall/Precision-based metrics** — `SemanticRecallPrecision`, `DecompositionalSemanticRecallPrecision`, and the `SemanticF1` module that combines them.
2. **Completeness/Groundedness metrics** — `AnswerCompleteness`, `AnswerGroundedness`, and the `CompleteAndGrounded` module that combines them.

---

## Architecture Overview

The module is built on top of three core DSPy abstractions:

- [`Signature`](signatures.md) — declaratively defines the input/output contract for each judge task.
- [`ChainOfThought`](predict.md) — wraps a signature so the judge reasons step-by-step before producing scores.
- [`Module`](primitives.md) — packages a signature + predictor into a callable metric with a `forward(example, pred, trace)` interface.

```mermaid
graph TD
    subgraph "auto_evaluation.py"
        SRP[SemanticRecallPrecision<br/>Signature]
        DSRP[DecompositionalSemanticRecallPrecision<br/>Signature]
        SF1[SemanticF1<br/>Module]
        AC[AnswerCompleteness<br/>Signature]
        AG[AnswerGroundedness<br/>Signature]
        CAG[CompleteAndGrounded<br/>Module]
        F1[f1_score<br/>helper]
    end

    SF1 -->|uses| SRP
    SF1 -->|uses| DSRP
    SF1 -->|uses| F1
    CAG -->|uses| AC
    CAG -->|uses| AG
    CAG -->|uses| F1

    SRP -->|wrapped by| CoT1[ChainOfThought]
    DSRP -->|wrapped by| CoT1
    AC -->|wrapped by| CoT2[ChainOfThought]
    AG -->|wrapped by| CoT2

    SF1 -->|is a| Module
    CAG -->|is a| Module
    CoT1 -->|is a| Module
    CoT2 -->|is a| Module
```

---

## Component Reference

### Signatures

All signatures follow the same pattern: they take a `question`, a reference (`ground_truth` or `retrieved_context`), and the `system_response`, and emit one or more reasoning fields plus a final numeric score in the range `[0.0, 1.0]`.

#### `SemanticRecallPrecision`

Compares a system response against the ground truth and computes recall and precision directly.

| Field | Type | Direction | Description |
|-------|------|-----------|-------------|
| `question` | `str` | Input | The original question. |
| `ground_truth` | `str` | Input | The reference answer. |
| `system_response` | `str` | Input | The response being evaluated. |
| `recall` | `float` | Output | Fraction (out of 1.0) of ground truth covered by the response. |
| `precision` | `float` | Output | Fraction (out of 1.0) of response covered by the ground truth. |

#### `DecompositionalSemanticRecallPrecision`

A more explicit variant that first enumerates key ideas in each response, discusses their overlap, and *then* reports recall and precision. This decomposition tends to produce more reliable judgments for complex answers.

| Field | Type | Direction | Description |
|-------|------|-----------|-------------|
| `question` | `str` | Input | The original question. |
| `ground_truth` | `str` | Input | The reference answer. |
| `system_response` | `str` | Input | The response being evaluated. |
| `ground_truth_key_ideas` | `str` | Output | Enumeration of key ideas in the ground truth. |
| `system_response_key_ideas` | `str` | Output | Enumeration of key ideas in the response. |
| `discussion` | `str` | Output | Discussion of the overlap between the two. |
| `recall` | `float` | Output | Fraction of ground truth covered. |
| `precision` | `float` | Output | Fraction of response covered by ground truth. |

#### `AnswerCompleteness`

Estimates how completely the system response covers the ground truth, using the same decompositional reasoning pattern.

| Field | Type | Direction | Description |
|-------|------|-----------|-------------|
| `question` | `str` | Input | The original question. |
| `ground_truth` | `str` | Input | The reference answer. |
| `system_response` | `str` | Input | The response being evaluated. |
| `ground_truth_key_ideas` | `str` | Output | Enumeration of key ideas in the ground truth. |
| `system_response_key_ideas` | `str` | Output | Enumeration of key ideas in the response. |
| `discussion` | `str` | Output | Discussion of the overlap. |
| `completeness` | `float` | Output | Fraction of ground truth covered by the response. |

#### `AnswerGroundedness`

Estimates whether the system response is supported by retrieved context (rather than hallucinated). It enumerates check-worthy claims and discusses how well the retrieved context supports them.

| Field | Type | Direction | Description |
|-------|------|-----------|-------------|
| `question` | `str` | Input | The original question. |
| `retrieved_context` | `str` | Input | The retrieved documents (written by people). |
| `system_response` | `str` | Input | The response being evaluated. |
| `system_response_claims` | `str` | Output | Enumeration of non-trivial / check-worthy claims. |
| `discussion` | `str` | Output | Discussion of how supported the claims are. |
| `groundedness` | `float` | Output | Fraction of response supported by the context. |

### Helper Function

#### `f1_score(precision, recall)`

Computes the harmonic mean of precision and recall, clamping both inputs to `[0.0, 1.0]`:

```python
def f1_score(precision, recall):
    precision, recall = max(0.0, min(1.0, precision)), max(0.0, min(1.0, recall))
    return 0.0 if precision + recall == 0 else 2 * (precision * recall) / (precision + recall)
```

Returns `0.0` when both inputs are zero to avoid division by zero.

### Metric Modules

Both modules implement the standard DSPy metric interface `forward(example, pred, trace=None)`, returning a float score when `trace is None` (used for evaluation) or a boolean when a `trace` is provided (used for optimization, where the score is thresholded).

#### `SemanticF1`

```python
class SemanticF1(dspy.Module):
    def __init__(self, threshold=0.66, decompositional=False):
        ...
```

- **`threshold`** (default `0.66`): the cutoff used when the metric is invoked with a `trace` (i.e., during optimization).
- **`decompositional`** (default `False`): when `True`, uses `DecompositionalSemanticRecallPrecision`; otherwise uses `SemanticRecallPrecision`.

The `forward` method calls the underlying `ChainOfThought` module with `example.question`, `example.response` (as ground truth), and `pred.response` (as the system response), then returns `f1_score(scores.precision, scores.recall)`.

#### `CompleteAndGrounded`

```python
class CompleteAndGrounded(dspy.Module):
    def __init__(self, threshold=0.66):
        ...
```

- **`threshold`** (default `0.66`): the cutoff used when invoked with a `trace`.

The `forward` method runs two judges:
- `completeness_module` using `example.question`, `example.response`, and `pred.response`.
- `groundedness_module` using `example.question`, `pred.context`, and `pred.response`.

It then returns `f1_score(groundedness.groundedness, completeness.completeness)`.

---

## Data Flow

The following diagram shows how a metric module processes an `(example, pred)` pair into a final score.

```mermaid
sequenceDiagram
    participant Eval as Evaluate
    participant Metric as SemanticF1 / CompleteAndGrounded
    participant CoT as ChainOfThought
    participant LM as Language Model

    Eval->>Metric: forward(example, pred, trace=None)
    Metric->>CoT: call with question, ground_truth/context, system_response
    CoT->>LM: prompt (with reasoning prefix)
    LM-->>CoT: reasoning + numeric scores
    CoT-->>Metric: Prediction (recall/precision or completeness/groundedness)
    Metric->>Metric: f1_score(...)
    alt trace is None
        Metric-->>Eval: float score
    else trace provided
        Metric-->>Eval: bool (score >= threshold)
    end
```

---

## Integration with the Evaluation Pipeline

These metrics are consumed by the [`Evaluate`](evaluate_orchestration.md) class, which runs a program over a devset in parallel and aggregates the per-example scores.

```mermaid
graph LR
    Devset[devset: List[Example]] --> Eval[Evaluate]
    Program[dspy.Module] --> Eval
    Metric[SemanticF1 / CompleteAndGrounded] --> Eval
    Eval -->|per example| Program
    Eval -->|example, pred| Metric
    Metric -->|score| Eval
    Eval --> Result[Overall score / per-example scores / outputs]
```

Because each metric is a `dspy.Module`, it can also be used as a reward signal in optimizers such as [`MIPROv2`](teleprompt.md) or [`BootstrapFewShot`](teleprompt.md), where the `trace` argument is supplied and the boolean thresholded output is used.

---

## Design Notes

- **Reasoning before scoring.** Every signature is wrapped in `ChainOfThought`, which prepends a `reasoning` output field. This forces the judge to articulate its reasoning before emitting numeric scores, improving reliability.
- **Decompositional reasoning.** The `DecompositionalSemanticRecallPrecision`, `AnswerCompleteness`, and `AnswerGroundedness` signatures explicitly enumerate key ideas/claims and discuss overlap before scoring. This makes the judgments more transparent and auditable.
- **Thresholded dual-mode output.** The `trace` parameter toggles between a continuous float (for evaluation) and a boolean (for optimization), matching the convention used throughout DSPy metrics.
- **Clamped F1.** `f1_score` clamps inputs to `[0.0, 1.0]` to guard against out-of-range values produced by the LM.

---

## Related Modules

- [Evaluate Orchestration](evaluate_orchestration.md) — the `Evaluate` class that runs these metrics over a dataset.
- [Predict](predict.md) — `ChainOfThought` and `Predict`, used to wrap the judge signatures.
- [Signatures](signatures.md) — the `Signature` base class and field definitions.
- [Primitives](primitives.md) — the `Module` base class and `Example`/`Prediction` types.
- [Teleprompt](teleprompt.md) — optimizers that consume these metrics as reward signals.
