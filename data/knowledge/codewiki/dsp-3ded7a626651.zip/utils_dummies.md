# Utils Dummies Module

## Introduction

The `utils_dummies` module provides lightweight, deterministic stand-ins for expensive or non-deterministic components in the DSPy framework. Its primary purpose is to enable **fast, reproducible unit testing** of DSPy programs without requiring network access, API keys, or real model inference.

The module exposes two core components:

- **`DummyLM`** — A fake language model that returns pre-configured responses instead of calling a real LLM.
- **`DummyVectorizer`** — A simple n-gram based vectorizer used for retrieval-style tests (paired with the `dummy_rm` helper).

These dummies are designed to be drop-in replacements for their real counterparts (`dspy.LM` and embedding/retrieval backends), so existing DSPy programs can be tested by simply reconfiguring `dspy.settings`.

---

## Architecture Overview

`DummyLM` subclasses the real [`LM`](clients_lm_core.md) class, inheriting its interface (history tracking, callbacks, `__call__`/`acall` semantics) while overriding the actual inference logic. It reuses the [`ChatAdapter`](adapters_core.md) formatting utilities to produce responses that look exactly like real model outputs, ensuring downstream parsing works identically.

```mermaid
graph TD
    subgraph "utils_dummies"
        DLM[DummyLM]
        DV[DummyVectorizer]
        DRM[dummy_rm helper]
    end

    subgraph "clients_lm_core"
        LM[LM]
    end

    subgraph "adapters_core"
        CA[ChatAdapter]
        FIWN[FieldInfoWithName]
    end

    subgraph "utils_callbacks"
        WC[with_callbacks]
    end

    subgraph "dsp_utils"
        DD[dotdict]
    end

    subgraph "signatures_fields"
        OF[OutputField]
    end

    DLM -->|inherits| LM
    DLM -->|uses formatting| CA
    DLM -->|uses| FIWN
    DLM -->|decorated by| WC
    DLM -->|uses| OF
    DRM -->|uses| DV
    DRM -->|returns| DD
```

---

## Component Details

### DummyLM

`DummyLM` is a subclass of [`LM`](clients_lm_core.md) that returns canned responses. It supports **three modes of operation**, selected based on the type of the `answers` argument and the `follow_examples` flag.

#### Constructor

```python
DummyLM(
    answers: Union[list[dict[str, str]], dict[str, dict[str, str]]],
    follow_examples: bool = False,
)
```

The constructor calls `super().__init__("dummy", "chat", 0.0, 1000, True)`, configuring a chat-type model with zero temperature. If `answers` is a list, it is converted into an iterator so successive calls consume responses in order.

#### Operating Modes

| Mode | Trigger | Behavior |
|------|---------|----------|
| **1. List of dictionaries** | `answers` is a `list[dict]` | Returns the next dictionary in the list on each request. |
| **2. Dictionary of dictionaries** | `answers` is a `dict[str, dict]` | Matches a key against the final message content and returns the corresponding dictionary. |
| **3. Follow examples** | `follow_examples=True` | If the prompt matches an example input, returns that example's output. |

**Mode 1 — List of dictionaries**

```python
lm = DummyLM([{"answer": "red"}, {"answer": "blue"}])
dspy.settings.configure(lm=lm)
predictor("What color is the sky?")  # -> [[## answer ##]]\nred
predictor("What color is the sky?")  # -> [[## answer ##]]\nblue
```

**Mode 2 — Dictionary of dictionaries**

```python
lm = DummyLM({"What color is the sky?": {"answer": "blue"}})
dspy.settings.configure(lm=lm)
predictor("What color is the sky?")  # -> [[## answer ##]]\nblue
```

**Mode 3 — Follow examples**

```python
lm = DummyLM([{"answer": "red"}], follow_examples=True)
dspy.settings.configure(lm=lm)
predictor("What color is the sky?",
          demos=dspy.Example(input="What color is the sky?", output="blue"))
# -> [[## answer ##]]\nblue
```

#### Key Methods

- **`__call__(prompt=None, messages=None, **kwargs)`** — Decorated with [`with_callbacks`](utils_callbacks.md). Builds `n` outputs (default 1), formats each answer using `ChatAdapter.format_field_with_value`, appends an entry to `self.history`, and updates the global history. API-key-like kwargs are stripped from the logged entry, and `cost`/`usage` are set to `0`.
- **`acall(...)`** — Async wrapper that delegates to `__call__`.
- **`_use_example(messages)`** — Implements Mode 3. It scans message headers to identify output fields (those appearing fewer times than the max), then finds the last turn whose content contains the output fields and whose preceding input matches the final input.
- **`get_convo(index)`** — Returns the `(messages, outputs)` tuple for the `index`-th history entry.

#### Response Formatting

All responses are formatted through `ChatAdapter().format_field_with_value(...)`, producing the standard DSPy chat-adapter field markers:

```
[[## answer ##]]
red
```

This guarantees that the output is parseable by the same [`ChatAdapter`](adapters_core.md) used in production, making `DummyLM` a faithful test double.

#### Execution Flow

```mermaid
sequenceDiagram
    participant P as Predictor
    participant D as DummyLM
    participant C as ChatAdapter
    participant H as history

    P->>D: __call__(prompt/messages, n)
    D->>D: resolve mode (list / dict / examples)
    alt follow_examples
        D->>D: _use_example(messages)
    else dict mode
        D->>D: match key in last message
    else list mode
        D->>D: next(self.answers)
    end
    D->>C: format_field_with_value(fields)
    C-->>D: "[[## field ##]]\nvalue"
    D->>H: append entry (outputs, usage=0, cost=0)
    D-->>P: [formatted_output]
```

---

### DummyVectorizer

`DummyVectorizer` is a deterministic, dependency-free text vectorizer based on **n-gram hashing**. It is used to build simple retrieval test doubles.

#### Constructor

```python
DummyVectorizer(max_length=100, n_gram=2)
```

- `max_length` — Dimensionality of the output vectors.
- `n_gram` — Size of the character n-grams extracted from each text.
- Uses a fixed random seed (`random.seed(123)`) and a large prime modulus (`10**9 + 7`) to generate stable polynomial-hash coefficients, ensuring reproducibility across runs.

#### Key Methods

- **`_hash(gram)`** — Polynomial rolling hash of an n-gram, mapped into `[0, max_length)`.
- **`__call__(texts: list[str]) -> np.ndarray`** — For each text, extracts character n-grams, increments the corresponding histogram bins, then returns an L2-normalized, mean-centered `float32` array of shape `(len(texts), max_length)`. An epsilon (`1e-10`) is added to the norm to avoid division by zero.

#### `dummy_rm` Helper

`dummy_rm(passages=())` returns a callable retrieval function compatible with DSPy's retrieval module interface:

- If no passages are provided, the returned function raises `ValueError("No passages defined")`.
- Otherwise, it vectorizes all passages once, and on each query computes cosine-style scores (`passage_vecs @ query_vec`), returning the top-`k` passages as [`dotdict`](dsp_utils.md) objects with a `long_text` attribute.

```mermaid
flowchart LR
    Q[query] --> V[DummyVectorizer]
    P[passages] --> V
    V --> S[score = passage_vecs @ query_vec]
    S --> T[top-k indices]
    T --> R[list of dotdict long_text]
```

---

## Data Flow

The following diagram shows how `DummyLM` and `DummyVectorizer` integrate into a typical test setup.

```mermaid
graph LR
    Test[Test Code] -->|configure| Settings[dspy.settings]
    Settings -->|lm| DLM[DummyLM]
    Settings -->|rm| DRM[dummy_rm]
    Program[DSPy Program] -->|predict| DLM
    Program -->|retrieve| DRM
    DLM -->|formatted output| Program
    DRM -->|dotdict passages| Program
```

---

## Dependencies

| Dependency | Purpose |
|------------|---------|
| [`LM`](clients_lm_core.md) | Base class providing the LM interface, history, and callbacks. |
| [`ChatAdapter`](adapters_core.md) / `FieldInfoWithName` | Formats dummy answers into standard chat-adapter field markers. |
| [`with_callbacks`](utils_callbacks.md) | Decorator enabling callback dispatch on `DummyLM.__call__`. |
| [`OutputField`](signatures_fields.md) | Wraps field metadata when formatting answers. |
| [`dotdict`](dsp_utils.md) | Attribute-accessible dict returned by `dummy_rm`. |
| `numpy` | Vector math for `DummyVectorizer`. |

---

## Usage Notes

- **Determinism**: Both dummies are fully deterministic, making them ideal for reproducible tests.
- **Drop-in replacement**: Configure via `dspy.settings.configure(lm=DummyLM(...))` — no changes to program code are required.
- **Exhaustion behavior**: When a list of answers is exhausted, `DummyLM` returns `{"answer": "No more responses"}`; when no dict key matches, it returns the string `"No more responses"`.
- **Cost/usage**: All dummy calls record `cost=0` and `usage=0` in history, so usage-tracking assertions remain predictable.

---

## Related Modules

- [clients_lm_core](clients_lm_core.md) — The real `LM` class that `DummyLM` extends.
- [adapters_core](adapters_core.md) — `ChatAdapter` used for response formatting.
- [utils_callbacks](utils_callbacks.md) — Callback infrastructure used by `DummyLM`.
- [dsp_utils](dsp_utils.md) — `dotdict` used by `dummy_rm`.
- [signatures_fields](signatures_fields.md) — `OutputField` used in answer formatting.
