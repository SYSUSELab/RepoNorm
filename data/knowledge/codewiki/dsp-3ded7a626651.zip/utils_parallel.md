# Utils Parallel Module

## Introduction

The `utils_parallel` module provides the concurrency and batching primitives that power DSPy's parallel execution model. It contains two core components:

- **`ParallelExecutor`** — a thread-pool based executor that runs a function over a collection of items in parallel, with per-thread isolation of DSPy settings, error tolerance, straggler timeouts, and progress reporting.
- **`Unbatchify`** — a batching adapter that converts a single-item callable interface into batched calls, transparently accumulating concurrent requests into batches for efficient batch-processing backends.

Together, these utilities form the low-level execution layer used by higher-level DSPy constructs such as [`Parallel`](predict_utilities.md) and various teleprompters that need to evaluate or run modules over many examples concurrently.

---

## Module Architecture

The module sits at the bottom of the DSPy stack, providing execution primitives consumed by the prediction and optimization layers.

```mermaid
graph TD
    subgraph "utils_parallel (current module)"
        PE[ParallelExecutor]
        UB[Unbatchify]
    end

    subgraph "Consumers"
        P[Parallel<br/>predict/parallel.py]
        TP[Teleprompters<br/>evaluate, bootstrap, etc.]
    end

    subgraph "Dependencies"
        S[Settings<br/>dsp/colbertv2.py]
        UT[UsageTracker<br/>utils/usage_tracker.py]
        TQDM[tqdm]
    end

    P --> PE
    TP --> PE
    PE --> S
    PE --> UT
    PE --> TQDM
    UB -.->|batch_fn| P
```

### Component Responsibilities

| Component | Responsibility |
|-----------|----------------|
| `ParallelExecutor` | Runs a user function over a list of items using a thread pool; isolates DSPy settings per thread; handles errors, cancellation, and straggler timeouts. |
| `Unbatchify` | Wraps a batch-processing function so it can be called one item at a time; accumulates items into batches on a background worker thread. |

---

## ParallelExecutor

`ParallelExecutor` is the workhorse for concurrent execution in DSPy. It is designed to be safe with respect to DSPy's global/thread-local configuration model (see [`Settings`](dsp_settings.md)) and robust against slow or failing tasks.

### Constructor Parameters

```python
ParallelExecutor(
    num_threads=None,
    max_errors=None,
    disable_progress_bar=False,
    provide_traceback=None,
    compare_results=False,
    timeout=120,
    straggler_limit=3,
)
```

| Parameter | Default | Description |
|-----------|---------|-------------|
| `num_threads` | `settings.num_threads` | Number of worker threads in the pool. |
| `max_errors` | `settings.max_errors` | Maximum number of errors tolerated before cancelling all remaining jobs. |
| `disable_progress_bar` | `False` | Whether to suppress the `tqdm` progress bar. |
| `provide_traceback` | `settings.provide_traceback` | Whether to log full tracebacks on task failure. |
| `compare_results` | `False` | If `True`, the progress bar reports an average metric instead of a processed count. |
| `timeout` | `120` | Per-task timeout (seconds) used for straggler detection. Set to `0` to disable. |
| `straggler_limit` | `3` | Only check for stragglers when this few tasks remain outstanding. |

### Key Methods

#### `execute(function, data)`

The primary entry point. Wraps `function` with error handling and runs it over every item in `data`, returning a list of results in the **same order** as the input.

```python
executor = ParallelExecutor(num_threads=8)
results = executor.execute(my_function, my_items)
```

#### `_wrap_function(user_function)`

Returns a `safe_func` closure that:
1. Short-circuits (returns `None`) if cancellation has been requested.
2. Catches any exception, increments the shared error counter under a lock, and triggers cancellation once `max_errors` is reached.
3. Logs the error (with or without traceback based on `provide_traceback`).

#### `_execute_parallel(function, data)`

The core scheduling loop. It:
- Submits one future per item to a `ThreadPoolExecutor`.
- Applies the parent thread's `thread_local_overrides` to each worker (deep-copying the `usage_tracker` so each thread tracks usage independently).
- Installs a `SIGINT` handler (in the main thread only) that sets the cancellation event.
- Polls completed futures with `wait(..., return_when=FIRST_COMPLETED)` and updates the progress bar.
- Detects **stragglers**: when few tasks remain and a task has exceeded `timeout`, it is resubmitted once (tracked via the `resubmitted` set).

#### `_update_progress(pbar, nresults, ntotal)`

Updates the `tqdm` description. In `compare_results` mode it shows `Average Metric: X / N (P%)`; otherwise it shows `Processed X / N examples`.

### Execution Flow

```mermaid
flowchart TD
    A[execute function, data] --> B[Clear tqdm instances]
    B --> C[_wrap_function]
    C --> D[_execute_parallel]
    D --> E[Create ThreadPoolExecutor]
    E --> F[Install SIGINT handler]
    F --> G[Capture parent thread_local_overrides]
    G --> H[Submit one future per item]
    H --> I{Wait for completions}
    I --> J[Collect results by index]
    J --> K{All done or cancelled?}
    K -->|No| L{Stragglers?}
    L -->|Yes| M[Resubmit timed-out task once]
    M --> I
    L -->|No| I
    K -->|Yes| N[Close progress bar]
    N --> O{Cancelled?}
    O -->|Yes| P[Raise Exception]
    O -->|No| Q[Return ordered results]
```

### Error Handling & Cancellation

```mermaid
stateDiagram-v2
    [*] --> Running
    Running --> Running: task succeeds
    Running --> ErrorCounted: task raises
    ErrorCounted --> Running: error_count < max_errors
    ErrorCounted --> Cancelled: error_count >= max_errors
    Running --> Cancelled: SIGINT received
    Cancelled --> [*]: raise Exception
    Running --> [*]: all results collected
```

- **Error tolerance**: individual task failures return `None` for that item and do not abort the run until `max_errors` is exceeded.
- **Cancellation**: triggered either by exceeding `max_errors` or by a `SIGINT` (Ctrl-C). Once cancelled, remaining workers short-circuit and the executor raises an `Exception`.
- **Graceful shutdown**: `executor.shutdown(wait=False)` avoids blocking on leftover tasks that no longer matter.

### Thread Isolation & Settings Propagation

A critical design feature is the interaction with [`Settings`](dsp_settings.md):

- The parent thread's `thread_local_overrides` are captured before submission and re-applied inside each worker via a `contextvars` token.
- The `usage_tracker` override is **deep-copied** per thread so that concurrent tasks do not corrupt each other's usage accounting (see [`UsageTracker`](utils_usage_tracking.md)).
- This ensures that `dspy.context(...)` blocks propagate correctly into threads spawned by the executor.

---

## Unbatchify

`Unbatchify` solves the inverse problem of batching: it lets callers invoke a **batch-only** function one item at a time, while a background worker transparently groups concurrent calls into batches.

### Constructor Parameters

```python
Unbatchify(
    batch_fn: Callable[[List[Any]], List[Any]],
    max_batch_size: int = 32,
    max_wait_time: float = 0.1,
)
```

| Parameter | Default | Description |
|-----------|---------|-------------|
| `batch_fn` | — | The batch-processing function: takes a list of inputs, returns a list of outputs (same length). |
| `max_batch_size` | `32` | Maximum number of items per batch. |
| `max_wait_time` | `0.1` | Maximum seconds to wait for a batch to fill before flushing. |

### Key Methods

#### `__call__(input_item)`

Thread-safe single-item interface. Enqueues `(input_item, future)` onto the internal queue and blocks on the future's result. Exceptions from `batch_fn` are re-raised to the caller.

#### `_worker()`

The background daemon thread loop:
1. Accumulates items from the queue until `max_batch_size` is reached or `max_wait_time` elapses.
2. Calls `batch_fn(batch)` and distributes outputs to the corresponding futures.
3. On exception, propagates the exception to **all** futures in the batch.
4. On shutdown, drains remaining queued items and fails their futures with `RuntimeError("Unbatchify is closed")`.

#### `close()` / Context Manager

`close()` sets the stop event and joins the worker thread. `Unbatchify` supports the context-manager protocol (`__enter__`/`__exit__`) and also cleans up in `__del__`.

### Batching Flow

```mermaid
sequenceDiagram
    participant C1 as Caller 1
    participant C2 as Caller 2
    participant Q as input_queue
    participant W as Worker Thread
    participant BF as batch_fn

    C1->>Q: put(item1, future1)
    C2->>Q: put(item2, future2)
    W->>Q: get() until max_batch_size or max_wait_time
    Q-->>W: [item1, item2]
    W->>BF: batch_fn([item1, item2])
    BF-->>W: [out1, out2]
    W->>C1: future1.set_result(out1)
    W->>C2: future2.set_result(out2)
```

### Lifecycle

```mermaid
stateDiagram-v2
    [*] --> Running: __init__ starts worker
    Running --> Running: batch processed
    Running --> Closing: close() / __exit__ / __del__
    Closing --> [*]: worker joined, pending futures failed
```

---

## Relationship to Higher-Level Components

`ParallelExecutor` is the engine behind the [`Parallel`](predict_utilities.md) prediction utility, which wraps it to run a module over a list of `Example`/`dict`/`tuple` inputs:

```mermaid
graph LR
    User[User code] --> Parallel
    Parallel -->|creates| PE[ParallelExecutor]
    PE -->|execute| Module[Module.forward]
    Module -->|uses| Settings
    PE -->|deep-copies| UT[UsageTracker]
```

`Parallel` translates each execution pair into a module call and delegates the actual concurrency, error handling, and progress reporting to `ParallelExecutor`. This separation keeps the concurrency logic reusable across the codebase (e.g., in evaluation and teleprompting workflows).

---

## Design Considerations

- **Order preservation**: `ParallelExecutor` writes results back by original index, so output order always matches input order regardless of completion order.
- **Single resubmission**: stragglers are resubmitted at most once to avoid infinite retry loops.
- **Daemon threads**: `Unbatchify`'s worker is a daemon thread, ensuring it does not block interpreter shutdown.
- **Resource cleanup**: both components provide explicit cleanup paths (`shutdown(wait=False)` for the executor; `close()`/context manager for `Unbatchify`).

---

## Related Documentation

- [`Settings`](dsp_settings.md) — thread-local configuration and `context()` propagation.
- [`UsageTracker`](utils_usage_tracking.md) — per-thread usage accounting deep-copied by the executor.
- [`Parallel`](predict_utilities.md) — the prediction utility built on top of `ParallelExecutor`.
- [`Evaluate`](evaluate_orchestration.md) — a major consumer of parallel execution for metric evaluation.
