# Datasets Core

## Introduction

The `datasets_core` module provides the foundational abstractions for loading, sampling, and splitting datasets within DSPy. It consists of two primary components:

- **`Dataset`** — An abstract base class that defines the standard interface for train/dev/test splits, deterministic shuffling, and seed-based reproducibility.
- **`DataLoader`** — A concrete utility class that loads data from a wide variety of sources (HuggingFace, CSV, JSON, Parquet, Pandas, and retrieval modules) and converts them into DSPy `Example` objects.

Together, these components form the backbone that benchmark datasets (see [datasets_benchmarks](datasets_benchmarks.md)) build upon, and they integrate tightly with the `Example` primitive (see [primitives](primitives.md)) and the `dotdict` utility (see [dsp](dsp.md)).

---

## Architecture Overview

The module sits between raw data sources and the higher-level benchmark datasets. `DataLoader` inherits from `Dataset`, reusing its split-management machinery while adding source-specific loading methods.

```mermaid
graph TD
    subgraph datasets_core["datasets_core"]
        Dataset["Dataset<br/>(base class)"]
        DataLoader["DataLoader<br/>(extends Dataset)"]
    end

    subgraph benchmarks["datasets_benchmarks"]
        GSM8K["GSM8K"]
        HotPotQA["HotPotQA"]
        MATH["MATH"]
        Colors["Colors"]
        AlfWorld["AlfWorld"]
    end

    subgraph primitives["primitives"]
        Example["Example"]
    end

    subgraph dsp["dsp"]
        dotdict["dotdict"]
    end

    subgraph external["External Sources"]
        HF["HuggingFace datasets"]
        CSV["CSV / JSON / Parquet"]
        Pandas["Pandas DataFrame"]
        RM["Retrieval Module"]
    end

    DataLoader -->|inherits| Dataset
    GSM8K -->|inherits| Dataset
    HotPotQA -->|inherits| Dataset
    MATH -->|inherits| Dataset
    Colors -->|inherits| Dataset
    AlfWorld -->|inherits| Dataset

    Dataset -->|produces| Example
    DataLoader -->|produces| Example
    Dataset -->|uses| dotdict

    DataLoader -->|loads from| HF
    DataLoader -->|loads from| CSV
    DataLoader -->|loads from| Pandas
    DataLoader -->|loads from| RM
```

---

## Component Relationships

`DataLoader` is a subclass of `Dataset`. It overrides `__init__` (to skip the base-class configuration) and adds a suite of `from_*` loading methods. The base `Dataset` supplies the `train`/`dev`/`test` properties and the `_shuffle_and_sample` logic that all subclasses rely on.

```mermaid
classDiagram
    class Dataset {
        +int train_size
        +int train_seed
        +int dev_size
        +int dev_seed
        +int test_size
        +int test_seed
        +list input_keys
        +bool do_shuffle
        +str name
        +reset_seeds(...)
        +train() property
        +dev() property
        +test() property
        +_shuffle_and_sample(split, data, size, seed)
        +prepare_by_seed(...) classmethod
    }

    class DataLoader {
        +from_huggingface(...)
        +from_csv(...)
        +from_pandas(...)
        +from_json(...)
        +from_parquet(...)
        +from_rm(...)
        +sample(dataset, n, ...)
        +train_test_split(dataset, train_size, test_size, random_state)
    }

    Dataset <|-- DataLoader
```

---

## Dataset

`Dataset` is the abstract base class for all DSPy datasets. It manages three standard splits — **train**, **dev**, and **test** — each with its own size and seed, and lazily materializes each split on first access.

### Configuration Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `train_seed` | `0` | Random seed used when shuffling the train split. |
| `train_size` | `None` | Number of examples to include in the train split. |
| `eval_seed` | `0` | Seed used for both the dev and test splits. |
| `dev_size` | `None` | Number of examples to include in the dev split. |
| `test_size` | `None` | Number of examples to include in the test split. |
| `input_keys` | `None` | Keys to mark as inputs on every produced `Example`. |

### Lazy Split Properties

The `train`, `dev`, and `test` properties are computed lazily and cached in `_train_`, `_dev_`, and `_test_` respectively. On first access, each property delegates to `_shuffle_and_sample`, which:

1. Converts the raw split data into a list.
2. Shuffles it using a `random.Random(seed)` instance (if `do_shuffle` is `True`).
3. Truncates to the requested `size`.
4. Wraps each record in an `Example`, attaching a unique `dspy_uuid` and the `dspy_split` name.
5. Applies `with_inputs(*input_keys)` when `input_keys` is configured.

```mermaid
flowchart TD
    A["Access dataset.train / .dev / .test"] --> B{"Cached attribute<br/>_train_ / _dev_ / _test_ exists?"}
    B -->|Yes| C["Return cached split"]
    B -->|No| D["Call _shuffle_and_sample(split, data, size, seed)"]
    D --> E["Convert data to list"]
    E --> F{"do_shuffle?"}
    F -->|Yes| G["Shuffle with random.Random(seed)"]
    F -->|No| H["Skip shuffle"]
    G --> I["Truncate to size"]
    H --> I
    I --> J["Wrap each record in Example<br/>+ dspy_uuid + dspy_split"]
    J --> K{"input_keys set?"}
    K -->|Yes| L["example.with_inputs(*input_keys)"]
    K -->|No| M["Keep example as-is"]
    L --> N["Cache and return split"]
    M --> N
```

### Seed Reset

`reset_seeds(...)` updates the size/seed configuration and invalidates the cached splits by deleting `_train_`, `_dev_`, and `_test_`. This forces the next property access to recompute the splits with the new configuration. Note that `eval_seed` is applied to both `dev_seed` and `test_seed`.

### `prepare_by_seed` Class Method

`prepare_by_seed` is a convenience factory for producing multiple train/eval splits across a list of seeds. It is commonly used for multi-seed evaluation experiments.

```mermaid
flowchart TD
    A["prepare_by_seed(train_seeds, train_size, dev_size, ...)"] --> B["Instantiate dataset with data_args"]
    B --> C["Compute eval_set = dataset.dev"]
    C --> D["examples_per_seed = dev_size // len(train_seeds)<br/>(if divide_eval_per_seed)"]
    D --> E["For each train_seed"]
    E --> F["reset_seeds(train_seed=...)"]
    F --> G["Append dataset.train to train_sets"]
    G --> H["Slice eval_set[eval_offset : eval_offset + examples_per_seed]"]
    H --> I["Append to eval_sets"]
    I --> J{"divide_eval_per_seed?"}
    J -->|Yes| K["eval_offset += examples_per_seed"]
    J -->|No| E
    K --> E
    E --> L["Return dotdict(train_sets, eval_sets)"]
```

The method returns a `dotdict` with two keys: `train_sets` and `eval_sets`, each a list aligned by seed.

---

## DataLoader

`DataLoader` extends `Dataset` and provides static-style loading utilities that convert external data sources into lists (or mappings of split name to lists) of `dspy.Example` objects. Its `__init__` is intentionally a no-op, so it is typically used as a collection of loading methods rather than as a stateful dataset.

### Loading Methods

| Method | Source | Returns |
|--------|--------|---------|
| `from_huggingface` | HuggingFace Hub dataset | `Mapping[str, List[Example]]` or `List[Example]` |
| `from_csv` | CSV file | `List[Example]` |
| `from_json` | JSON file | `List[Example]` |
| `from_parquet` | Parquet file | `List[Example]` |
| `from_pandas` | Pandas `DataFrame` | `List[Example]` |
| `from_rm` | Configured retrieval module | `List[Example]` |

All loading methods accept an `input_keys` tuple and (where applicable) a `fields` list/tuple to select which columns to include. Each produced `Example` is created via `dspy.Example({...}).with_inputs(*input_keys)`.

### `from_huggingface`

Loads a dataset via `datasets.load_dataset`. It supports both single-split and multi-split datasets:

- If the loaded dataset is a mapping of split names, it returns a `dict` mapping each split name to a list of `Example`s.
- If it is a single dataset (list-like), it returns a flat `List[Example]`.

It validates that `fields` (if provided) is a tuple and that `input_keys` is a tuple, raising `ValueError` otherwise.

### `from_rm`

Retrieves examples from the retrieval module configured in `dspy.settings.rm`. It calls `rm.get_objects(num_samples, fields)` and raises descriptive `ValueError`s if the retrieval module is missing or does not implement `get_objects`.

### `sample`

A thin wrapper around `random.sample` that validates the input is a list of `dspy.Example`s before sampling `n` items.

### `train_test_split`

Splits a list of examples into train and test portions with flexible sizing:

- `train_size` may be a **float** in `(0, 1)` (proportion) or an **int** (absolute count).
- `test_size` follows the same rules; if omitted, it defaults to the remainder after the train split.
- `random_state` seeds the shuffle for reproducibility.
- Raises `ValueError` for invalid sizes or when `train_size + test_size` exceeds the dataset length.

```mermaid
flowchart TD
    A["train_test_split(dataset, train_size, test_size, random_state)"] --> B{"random_state set?"}
    B -->|Yes| C["random.seed(random_state)"]
    B -->|No| D["Continue"]
    C --> D
    D --> E["Copy and shuffle dataset"]
    E --> F{"train_size type?"}
    F -->|float in (0,1)| G["train_end = len * train_size"]
    F -->|int| H["train_end = train_size"]
    F -->|invalid| I["Raise ValueError"]
    G --> J{"test_size provided?"}
    H --> J
    J -->|Yes| K{"test_size type?"}
    K -->|float in (0,1)| L["test_end = len * test_size"]
    K -->|int| M["test_end = test_size"]
    K -->|invalid| N["Raise ValueError"]
    J -->|No| O["test_end = len - train_end"]
    L --> P{"train_end + test_end > len?"}
    M --> P
    O --> Q["Slice train and test"]
    P -->|Yes| R["Raise ValueError"]
    P -->|No| Q
    Q --> S["Return {'train': ..., 'test': ...}"]
```

---

## Data Flow

The following diagram illustrates the end-to-end flow from a raw data source to a usable DSPy dataset split.

```mermaid
sequenceDiagram
    participant User
    participant DataLoader
    participant Source as External Source
    participant Example
    participant Dataset

    User->>DataLoader: from_huggingface("dataset_name", input_keys=("q",))
    DataLoader->>Source: load_dataset(...)
    Source-->>DataLoader: raw rows
    loop For each row
        DataLoader->>Example: Example({...}).with_inputs("q")
        Example-->>DataLoader: Example instance
    end
    DataLoader-->>User: List[Example] / Mapping[split, List[Example]]

    User->>Dataset: dataset.train
    Dataset->>Dataset: _shuffle_and_sample("train", ...)
    Dataset->>Example: Example(**record, dspy_uuid=..., dspy_split="train")
    Example-->>Dataset: Example instance
    Dataset-->>User: List[Example]
```

---

## Integration with Other Modules

- **[primitives](primitives.md)** — Every record produced by `Dataset` and `DataLoader` is a `dspy.Example`. The `with_inputs` mechanism and `dspy_uuid`/`dspy_split` metadata are central to how downstream modules (e.g., `Predict`, `Evaluate`) distinguish inputs from labels.
- **[dsp](dsp.md)** — `Dataset.prepare_by_seed` returns a `dotdict`, enabling attribute-style access to `train_sets` and `eval_sets`.
- **[datasets_benchmarks](datasets_benchmarks.md)** — Benchmark datasets such as `GSM8K`, `HotPotQA`, `MATH`, `Colors`, and `AlfWorld` subclass `Dataset` and rely on its split-management and shuffling behavior.
- **[evaluate](evaluate.md)** — Evaluation workflows consume the `dev`/`test` splits produced by `Dataset`.
- **[teleprompt](teleprompt.md)** — Optimizers (e.g., `BootstrapFewShot`, `MIPROv2`) consume `train`/`dev` splits for compiling and validating programs.

---

## Summary

The `datasets_core` module provides:

1. **`Dataset`** — a reproducible, lazily-evaluated base class for managing train/dev/test splits with deterministic shuffling and seed-based regeneration.
2. **`DataLoader`** — a flexible loader that ingests data from HuggingFace, CSV, JSON, Parquet, Pandas, and retrieval modules, normalizing everything into `dspy.Example` objects.

These two components establish the standard contract that all DSPy benchmark datasets and training/evaluation pipelines depend on.
