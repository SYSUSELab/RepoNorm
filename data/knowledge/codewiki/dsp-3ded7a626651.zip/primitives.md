# Primitives

## Overview

The `primitives` module provides the **foundational data structures and base classes** that the entire DSPy framework is built upon. These primitives define how data flows through DSPy programs, how modules are composed and executed, and how code is safely executed in a sandboxed environment.

The module is intentionally low-level: it has minimal dependencies on the rest of DSPy and is imported by nearly every other module. Understanding these primitives is essential to understanding how DSPy programs are constructed, executed, saved, and loaded.

## Purpose and Core Functionality

The `primitives` module delivers four core capabilities:

1. **Data containers** — `Example` and `Prediction` provide dict-like, attribute-accessible containers for inputs, labels, and model outputs.
2. **Module system** — `BaseModule` and `Module` (aliased as `Program`) define the composable, nestable building blocks of DSPy programs, including parameter discovery, state management, and serialization.
3. **Execution orchestration** — `Module.__call__` / `Module.acall` handle callback dispatch, usage tracking, and caller-module context propagation.
4. **Sandboxed code execution** — `PythonInterpreter` runs untrusted Python code in a Deno/Pyodide sandbox.

## Architecture

```mermaid
graph TD
    subgraph primitives["dspy.primitives"]
        Example["Example<br/>(dict-like container)"]
        Prediction["Prediction<br/>(extends Example)"]
        Completions["Completions<br/>(multi-completion wrapper)"]
        BaseModule["BaseModule<br/>(parameter & state mgmt)"]
        Module["Module / Program<br/>(executable unit)"]
        ProgramMeta["ProgramMeta<br/>(metaclass)"]
        PythonInterpreter["PythonInterpreter<br/>(sandboxed exec)"]
        InterpreterError["InterpreterError"]
    end

    Prediction -->|inherits| Example
    Prediction -->|holds| Completions
    Module -->|inherits| BaseModule
    ProgramMeta -->|metaclass of| Module
    PythonInterpreter -->|raises| InterpreterError

    Module -->|produces| Prediction
    Module -->|consumes| Example
```

### Component Relationships

```mermaid
graph LR
    subgraph Data["Data Layer"]
        Example
        Prediction
    end
    subgraph Execution["Execution Layer"]
        BaseModule
        Module
    end
    subgraph Sandbox["Sandbox Layer"]
        PythonInterpreter
    end

    Module -->|"forward() returns"| Prediction
    Module -->|"batch() takes"| Example
    BaseModule -->|"named_parameters()"| Parameter["dspy.Parameter"]
    Module -->|"uses"| Settings["dspy.settings"]
    Module -->|"uses"| Callbacks["with_callbacks"]
    Module -->|"uses"| UsageTracker["track_usage"]
```

## Sub-Modules

The `primitives` module is organized into three logical sub-modules, each documented in detail:

### 1. Data Containers — [primitives_data_containers.md](primitives_data_containers.md)

The data layer consists of `Example`, `Prediction`, and `Completions`. These provide the flexible, dict-like containers that carry inputs, labels, and model outputs throughout a DSPy program.

- **`Example`** — a dict-like container with attribute access, input/label separation via `with_inputs()`, and copy/transform helpers.
- **`Prediction`** — extends `Example` with multi-completion support, LM usage tracking, and numeric comparison operators (enabling `Prediction` objects to be used directly in metric computations).
- **`Completions`** — wraps multiple completions of the same signature, supporting indexing and attribute access.

### 2. Module System — [primitives_module_system.md](primitives_module_system.md)

The execution layer defines how DSPy programs are composed and run.

- **`BaseModule`** — the base class providing parameter discovery (`named_parameters`, `named_sub_modules`), deep copying, state dump/load, and serialization (`save`/`load`).
- **`Module` / `Program`** — the executable unit, adding `__call__`/`acall`, callback dispatch, usage tracking, predictor management, batching, and history inspection.
- **`ProgramMeta`** — a metaclass that guarantees every `Module` instance is properly initialized even if a subclass forgets to call `super().__init__()`.

### 3. Python Interpreter — [primitives_python_interpreter.md](primitives_python_interpreter.md)

The sandbox layer provides safe execution of untrusted Python code.

- **`PythonInterpreter`** — runs Python code inside a Deno + Pyodide sandbox with configurable file, environment, and network access controls.
- **`InterpreterError`** — the exception raised for sandbox execution failures.

## How the Primitives Fit Into DSPy

```mermaid
graph TD
    User["User Program"] -->|"subclasses"| Module
    Module -->|"calls"| Predict["dspy.Predict"]
    Predict -->|"returns"| Prediction
    Module -->|"batch over"| Example
    Module -->|"save/load"| Disk["Disk (.json/.pkl)"]
    CodeAct["dspy.CodeAct"] -->|"executes code via"| PythonInterpreter
    Evaluate["dspy.Evaluate"] -->|"scores"| Prediction
```

- **`dspy.Predict`** and all predictors return `Prediction` objects.
- **`dspy.Evaluate`** and metrics operate on `Example`/`Prediction` objects, leveraging `Prediction`'s numeric operators.
- **`dspy.CodeAct`** and **`dspy.ProgramOfThought`** use `PythonInterpreter` to execute generated code.
- **Teleprompters** (optimizers) manipulate `Module` parameters discovered via `named_parameters()`.
- **`dspy.load`** reconstructs saved `Module` instances using the serialization logic in `BaseModule`.

## Related Modules

- [predict.md](predict.md) — predictors that produce `Prediction` objects and subclass `Module`.
- [evaluate.md](evaluate.md) — evaluation harness that consumes `Example`/`Prediction`.
- [dsp.md](dsp.md) — `Settings` singleton used by `Module` for context and usage tracking.
- [utils.md](utils.md) — callbacks, usage tracking, and saving utilities used by `Module`.
- [signatures.md](signatures.md) — signatures that define the input/output fields of `Example`/`Prediction`.
