# Clients

## Overview

The `clients` module is the **model-interaction layer** of DSPy. It provides a unified, provider-agnostic interface for:

- **Language model inference** — chat and text-completion requests against any LiteLLM-supported provider (OpenAI, Anthropic, local SGLang servers, etc.).
- **Embeddings** — hosted or custom embedding functions for retrieval and similarity tasks.
- **Response caching** — a two-level (in-memory + on-disk) cache that dramatically reduces cost and latency for repeated requests.
- **Fine-tuning & reinforcement learning** — a pluggable *provider* abstraction that lets DSPy launch, kill, fine-tune, and reinforce models across OpenAI, Databricks, local SGLang, and Arbor backends.

The module sits between the higher-level DSPy primitives (e.g. [`Predict`](predict.md), [`Module`](primitives.md)) and the underlying model APIs. Every DSPy program ultimately routes its model calls through an object defined here.

## Architecture

The module is organized into three cooperating layers:

```mermaid
graph TD
    subgraph "DSPy Programs"
        P[Predict / Module / Teleprompters]
    end

    subgraph "clients module"
        subgraph "LM Core"
            BLM[BaseLM]
            LM[LM]
            EMB[Embedder]
            CACHE[Cache]
        end
        subgraph "Providers"
            PROV[Provider]
            OAI[OpenAIProvider]
            DBX[DatabricksProvider]
            LOCAL[LocalProvider]
            ARBOR[ArborProvider]
        end
        subgraph "Finetune Utils"
            UTIL[utils_finetune]
        end
    end

    subgraph "External"
        LITELLM[LiteLLM]
        APIS[Model APIs / Servers]
    end

    P --> LM
    P --> EMB
    LM --> BLM
    LM --> CACHE
    EMB --> CACHE
    LM --> PROV
    PROV --> OAI
    PROV --> DBX
    PROV --> LOCAL
    PROV --> ARBOR
    OAI --> UTIL
    DBX --> UTIL
    LOCAL --> UTIL
    ARBOR --> UTIL
    LM --> LITELLM
    EMB --> LITELLM
    LITELLM --> APIS
    OAI --> APIS
    DBX --> APIS
    LOCAL --> APIS
    ARBOR --> APIS
```

### Request Flow

A typical inference request flows through the module as follows:

```mermaid
sequenceDiagram
    participant Prog as DSPy Program
    participant LM as LM
    participant Cache as Cache
    participant LiteLLM as LiteLLM
    participant API as Model API

    Prog->>LM: __call__(prompt/messages)
    LM->>LM: forward() builds request
    LM->>Cache: get(request)
    alt Cache hit
        Cache-->>LM: cached response
    else Cache miss
        LM->>LiteLLM: completion(request)
        LiteLLM->>API: HTTP request
        API-->>LiteLLM: response
        LiteLLM-->>LM: response
        LM->>Cache: put(request, response)
    end
    LM->>LM: _process_lm_response() + history
    LM-->>Prog: outputs
```

## Sub-modules

### 1. LM Core (`clients_lm_core.md`)

The heart of the module. It defines the base abstraction for all language models and the concrete LiteLLM-backed implementation, plus embeddings and caching.

- **`BaseLM`** — abstract base class defining the `forward`/`aforward` contract, response post-processing, history tracking, and `copy()` semantics. Custom providers can subclass this directly.
- **`LM`** — the primary user-facing class (`dspy.LM`). Wraps LiteLLM for chat/text completion, handles retries, streaming, usage tracking, and provider inference.
- **`Embedder`** — unified interface for hosted (LiteLLM) or custom callable embedding models, with batching and caching.
- **`Cache`** — two-level (LRU in-memory + `diskcache` on-disk) cache with a `request_cache` decorator used across the module.

See [clients_lm_core.md](clients_lm_core.md) for details.

### 2. Providers (`clients_providers.md`)

A pluggable abstraction for model lifecycle management — launching/killing inference servers and running fine-tuning or reinforcement-learning jobs.

- **`Provider`** — base class defining the provider contract (`is_provider_model`, `launch`, `kill`, `finetune`).
- **`TrainingJob` / `ReinforceJob`** — job abstractions (the former is a `Future`) for asynchronous training workflows.
- **`OpenAIProvider`** — fine-tuning against OpenAI's API.
- **`DatabricksProvider`** — fine-tuning and deployment on Databricks Model Serving / Unity Catalog.
- **`LocalProvider`** — launching local SGLang servers and local SFT training via TRL.
- **`ArborProvider`** — inference server management plus GRPO reinforcement learning.

See [clients_providers.md](clients_providers.md) for details.

### 3. Finetune Utilities (`clients_finetune_utils.md`)

Shared data types and helpers used by all providers for preparing, validating, and persisting training data.

- **`TrainDataFormat`** / **`TrainingStatus`** — enums for data formats and job states.
- **`Message` / `MessageAssistant` / `GRPOChatData`** — typed dictionaries describing training examples.
- Data validation and serialization helpers (`save_data`, `validate_data_format`, `get_finetune_directory`).

See [clients_finetune_utils.md](clients_finetune_utils.md) for details.

## Component Relationships

```mermaid
classDiagram
    class BaseLM {
        +model
        +model_type
        +kwargs
        +history
        +forward()
        +aforward()
        +copy()
        +inspect_history()
    }
    class LM {
        +provider
        +num_retries
        +finetuning_model
        +launch()
        +kill()
        +finetune()
        +reinforce()
        +infer_provider()
    }
    class Embedder {
        +model
        +batch_size
        +__call__()
        +acall()
    }
    class Cache {
        +get()
        +put()
        +cache_key()
    }
    class Provider {
        +finetunable
        +reinforceable
        +is_provider_model()
        +launch()
        +kill()
        +finetune()
    }
    class TrainingJob {
        +status()
        +cancel()
    }
    class ReinforceJob {
        +initialize()
        +step()
        +terminate()
    }

    BaseLM <|-- LM
    LM --> Provider : uses
    LM --> Cache : uses
    Embedder --> Cache : uses
    Provider --> TrainingJob : creates
    Provider --> ReinforceJob : creates
```

## Integration with Other Modules

- **`dspy.dsp.utils.settings`** — the global `settings` object provides `disable_history`, `caller_modules`, `usage_tracker`, and streaming hooks consumed by `BaseLM` and `LM`.
- **`dspy.utils.callback`** — the `with_callbacks` decorator wraps `BaseLM.__call__`/`acall` to fire user callbacks.
- **`dspy.utils.usage_tracker`** — `LM` reports token usage to the global usage tracker.
- **`dspy.adapters`** — adapters format prompts/messages that are passed into `LM`; `utils_finetune.infer_data_format` inspects adapters to determine training data format.
- **`dspy.teleprompt`** — optimizers such as `BootstrapFinetune` and `GRPO` drive the `finetune()` and `reinforce()` workflows exposed by `LM`.
- **`dspy.retrievers`** — retrieval modules consume `Embedder` for vector generation.

## Key Design Principles

1. **Provider-agnostic inference** — `LM` delegates to LiteLLM, so any supported model string works without code changes.
2. **Pluggable providers** — fine-tuning and server lifecycle are abstracted behind `Provider`, allowing new backends to be added without touching `LM`.
3. **Transparent caching** — caching is applied via a decorator and a shared `Cache` instance, so it works uniformly across LMs and embedders.
4. **Extensibility** — users can subclass `BaseLM` to inject custom logic while keeping the standard response format.
