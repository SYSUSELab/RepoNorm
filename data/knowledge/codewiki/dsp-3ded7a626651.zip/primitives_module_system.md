# Primitives Module System

## Introduction

The **Primitives Module System** is the foundational abstraction layer of DSPy that defines how programs are structured, composed, and executed. It provides the `BaseModule` and `Module` classes that serve as the base for every DSPy program — from simple `Predict` calls to complex multi-stage pipelines.

This module answers three core questions:

1. **How are DSPy programs structured?** — Through a tree of nested modules and parameters (`BaseModule`).
2. **How are programs executed?** — Through a `forward`/`aforward` contract wrapped by `__call__`/`acall` with callbacks, usage tracking, and settings propagation (`Module`).
3. **How are programs persisted?** — Through state serialization (`dump_state`/`load_state`) and full-program pickling (`save`/`load`).

> **Related documentation:**
> - Data containers used by modules: [primitives_data_containers.md](primitives_data_containers.md)
> - The `Predict` primitive that subclasses `Module`: [predict_core.md](predict_core.md)
> - Global configuration and thread-local overrides: [dsp_settings.md](dsp_settings.md)
> - Callback infrastructure: [utils.md](utils.md)

---

## Architecture Overview

The module system is built on a two-layer class hierarchy. `BaseModule` provides the structural machinery (parameter discovery, traversal, copying, serialization), while `Module` adds the execution contract (calling, callbacks, batching, LM management).

```mermaid
graph TD
    subgraph "primitives_module_system"
        BaseModule["BaseModule<br/>(structural layer)"]
        Module["Module<br/>(execution layer)"]
        ProgramMeta["ProgramMeta<br/>(metaclass)"]
        Program["Program<br/>(alias of Module)"]
    end

    subgraph "External Dependencies"
        Parameter["Parameter<br/>(predict_core)"]
        Predict["Predict<br/>(predict_core)"]
        Settings["Settings<br/>(dsp_settings)"]
        Callbacks["with_callbacks<br/>(utils)"]
        Parallel["Parallel<br/>(predict_utilities)"]
        UsageTracker["track_usage<br/>(utils)"]
        Saving["get_dependency_versions<br/>(utils)"]
    end

    ProgramMeta -.->|"creates"| Module
    Module -->|"inherits"| BaseModule
    Program -.->|"alias"| Module

    BaseModule -->|"discovers"| Parameter
    Module -->|"uses"| Settings
    Module -->|"decorated by"| Callbacks
    Module -->|"delegates batch to"| Parallel
    Module -->|"tracks via"| UsageTracker
    BaseModule -->|"serializes with"| Saving
    Predict -->|"inherits"| Module
    Predict -->|"inherits"| Parameter
```

### Key Design Principles

| Principle | Implementation |
|-----------|----------------|
| **Composition over inheritance** | Modules nest other modules/parameters in `__dict__`, lists, tuples, and dicts. |
| **Non-recursive parameter handling** | Unlike PyTorch, `named_parameters` traverses lists/dicts of parameters. |
| **Frozen sub-modules** | Pre-compiled sub-modules (`_compiled=True`) are skipped during traversal. |
| **Shallow-copy-friendly deepcopy** | `deepcopy` only deep-copies parameters; other attributes fall back gracefully. |
| **Version-aware persistence** | Saved state records dependency versions and warns on mismatch at load time. |

---

## Component Reference

### `BaseModule` — Structural Layer

`BaseModule` is the root of the module hierarchy. It knows nothing about execution; it only understands *structure*: what parameters and sub-modules exist, how to traverse them, and how to serialize them.

#### Parameter & Sub-module Discovery

```mermaid
flowchart TD
    Start["named_parameters()"] --> CheckSelf{"is self a Parameter?"}
    CheckSelf -->|yes| AddSelf["add_parameter('self', self)"]
    CheckSelf -->|no| Iterate["iterate self.__dict__"]
    AddSelf --> Iterate
    Iterate --> TypeCheck{"value type?"}
    TypeCheck -->|Parameter| AddParam["add_parameter(name, value)"]
    TypeCheck -->|Module| CheckCompiled{"_compiled?"}
    TypeCheck -->|list/tuple| RecurseList["recurse with name[i]"]
    TypeCheck -->|dict| RecurseDict["recurse with name['key']"]
    CheckCompiled -->|no| RecurseModule["recurse into sub-module"]
    CheckCompiled -->|yes| Skip["skip (frozen)"]
    AddParam --> Dedup["dedupe by id()"]
    RecurseList --> Dedup
    RecurseDict --> Dedup
    RecurseModule --> Dedup
    Dedup --> Result["list of (name, Parameter)"]
```

**`named_parameters()`** — Returns a list of `(name, Parameter)` tuples. It handles:
- Direct `Parameter` attributes.
- Nested `Module` attributes (recursively, unless `_compiled`).
- Lists/tuples of parameters (indexed as `name[0]`, `name[1]`, ...).
- Dicts of parameters (keyed as `name['key']`).
- Deduplication via `id()` to avoid returning the same parameter twice.

**`named_sub_modules(type_=None, skip_compiled=False)`** — A generator that performs a breadth-first traversal (using a `deque`) yielding `(name, sub_module)` tuples. It builds dotted paths like `children[4][key].sub_module`. If a sub-module is reachable via multiple paths, only the first path is yielded (tracked via a `seen` set of `id()`s).

**`parameters()`** — Convenience method returning just the parameter objects (dropping names).

#### Copying & Resetting

| Method | Behavior |
|--------|----------|
| `deepcopy()` | Attempts a full `copy.deepcopy`; on failure, creates a new instance and copies attributes one-by-one, deep-copying `BaseModule` attributes and falling back to shallow/reference copy for un-copyable attributes. |
| `reset_copy()` | Deep-copies the module, then calls `reset()` on every parameter. Useful for creating a fresh, untrained copy of a compiled program. |

#### State Serialization

```mermaid
sequenceDiagram
    participant User
    participant Module as BaseModule
    participant FS as File System
    participant Cloudpickle

    Note over User,Module: State-only save (save_program=False)
    User->>Module: save("model.json")
    Module->>Module: dump_state()
    Module->>Module: attach metadata (dependency_versions)
    Module->>FS: write JSON (ujson)

    Note over User,Module: Full-program save (save_program=True)
    User->>Module: save("dir/", save_program=True)
    Module->>Cloudpickle: register_pickle_by_value(modules_to_serialize)
    Module->>Cloudpickle: dump(self)
    Cloudpickle->>FS: write program.pkl
    Module->>FS: write metadata.json

    Note over User,Module: Load
    User->>Module: load("model.json")
    Module->>FS: read state
    Module->>Module: compare dependency versions
    Module->>Module: load_state(state)
```

**`dump_state()`** — Returns `{name: param.dump_state()}` for all named parameters.

**`load_state(state)`** — Calls `param.load_state(state[name])` for each named parameter.

**`save(path, save_program=False, modules_to_serialize=None)`** — Two modes:
- **State-only** (`save_program=False`): Writes to `.json` (via `ujson`) or `.pkl` (via `cloudpickle`). Includes dependency version metadata.
- **Full-program** (`save_program=True`): Writes the entire module to a directory via `cloudpickle`, including `program.pkl` and `metadata.json`. `modules_to_serialize` registers custom modules for by-value serialization.

**`load(path)`** — Reads a `.json` or `.pkl` state file, compares saved dependency versions against the current environment, logs warnings on mismatch, and calls `load_state`.

> **Note:** `save`/`load` operate on *state* for an existing program. To load an entire program (architecture + state), use `dspy.load`.

---

### `Module` — Execution Layer

`Module` extends `BaseModule` with the runtime contract. Every DSPy program subclasses `Module` and implements `forward` (and optionally `aforward`).

#### The `ProgramMeta` Metaclass

`ProgramMeta` guarantees that every `Module` instance is properly initialized, even if a subclass forgets to call `super().__init__()`:

```mermaid
flowchart TD
    Call["Module(...)"] --> New["obj = cls.__new__(cls)"]
    New --> BaseInit["Module._base_init(obj)<br/>sets _compiled, callbacks, history"]
    BaseInit --> Init["cls.__init__(obj, ...)"]
    Init --> Guard1{"has callbacks?"}
    Guard1 -->|no| SetCb["obj.callbacks = []"]
    Guard1 -->|yes| Guard2
    SetCb --> Guard2{"has history?"}
    Guard2 -->|no| SetHist["obj.history = []"]
    Guard2 -->|yes| Return
    SetHist --> Return["return obj"]
```

This ensures critical attributes (`_compiled`, `callbacks`, `history`) always exist, preventing `AttributeError` in downstream code.

#### Execution Contract

The `__call__` / `acall` methods are the public entry points. They wrap `forward` / `aforward` with cross-cutting concerns:

```mermaid
sequenceDiagram
    participant Caller
    participant Module
    participant Callbacks as with_callbacks
    participant Settings
    participant UsageTracker
    participant Forward as forward()

    Caller->>Module: module(**inputs)
    Module->>Callbacks: enter callback context
    Module->>Settings: read caller_modules
    Module->>Settings: context(caller_modules=[...self])
    alt track_usage enabled
        Module->>UsageTracker: track_usage()
        Module->>Forward: forward(**inputs)
        Forward-->>Module: output
        Module->>Module: output.set_lm_usage(tokens)
    else
        Module->>Forward: forward(**inputs)
        Forward-->>Module: output
    end
    Module->>Callbacks: exit callback context
    Module-->>Caller: output
```

Key behaviors:
- **Caller tracking**: Each call appends `self` to `settings.caller_modules`, enabling nested modules to know their call chain.
- **Usage tracking**: When `settings.track_usage` is enabled and no tracker is active, a `track_usage()` context wraps the call and attaches total token usage to the output.
- **Callbacks**: The `@with_callbacks` decorator (from [utils.md](utils.md)) fires `on_start`/`on_end` handlers around the call.
- **Async support**: `acall` mirrors `__call__` for `aforward`.

#### Predictor Management

| Method | Purpose |
|--------|---------|
| `named_predictors()` | Returns `(name, Predict)` pairs by filtering `named_parameters()` for `Predict` instances. |
| `predictors()` | Returns just the `Predict` objects. |
| `set_lm(lm)` | Assigns an LM to every predictor in the module. |
| `get_lm()` | Returns the unique LM used by all predictors; raises `ValueError` if multiple LMs are in use. |
| `map_named_predictors(func)` | Applies `func` to each predictor and writes the result back via `set_attribute_by_name`. |

#### Batching

`batch(...)` processes a list of `Example` instances in parallel by delegating to the `Parallel` module (see [predict_utilities.md](predict_utilities.md)):

```mermaid
flowchart LR
    Examples["List[Example]"] --> Pairs["exec_pairs = [(self, ex.inputs())]"]
    Pairs --> Parallel["Parallel.forward(exec_pairs)"]
    Parallel --> Results["List[Prediction]"]
    Parallel -.->|optional| Failed["failed_examples, exceptions"]
```

Parameters: `num_threads`, `max_errors`, `return_failed_examples`, `provide_traceback`, `disable_progress_bar`.

#### Direct `forward` Guard

`__getattribute__` intercepts access to `forward`. If `forward` is called directly (not through `__call__`), it logs a warning encouraging users to call the module itself. This preserves the callback/usage-tracking guarantees.

---

## Component Interaction Map

```mermaid
graph TB
    subgraph "Module System"
        BaseModule
        Module
    end

    subgraph "Data Flow"
        Example["Example<br/>(inputs)"]
        Prediction["Prediction<br/>(outputs)"]
    end

    subgraph "Execution"
        Predict["Predict"]
        Adapter["Adapter"]
        LM["LM"]
    end

    subgraph "Infrastructure"
        Settings
        Callbacks
        UsageTracker
        Parallel
    end

    Example -->|"inputs()"| Module
    Module -->|"forward()"| Predict
    Predict -->|"adapter()"| Adapter
    Adapter -->|"calls"| LM
    LM -->|"completions"| Predict
    Predict -->|"from_completions"| Prediction
    Module -->|"returns"| Prediction

    Module -.->|"reads config"| Settings
    Module -.->|"fires"| Callbacks
    Module -.->|"tracks"| UsageTracker
    Module -.->|"batch via"| Parallel
```

---

## Data Flow: A Complete Module Call

The following diagram traces a full execution from a user call through to a `Prediction` result, showing how the module system orchestrates the various subsystems.

```mermaid
sequenceDiagram
    participant User
    participant Module
    participant Settings
    participant Predict
    participant Adapter
    participant LM
    participant Prediction

    User->>Module: module(question="...")
    Module->>Settings: context(caller_modules=[module])
    Module->>Module: forward(question="...")
    Module->>Predict: predictor(question="...")
    Predict->>Settings: read lm, adapter, demos
    Predict->>Adapter: adapter(lm, signature, demos, inputs)
    Adapter->>LM: __call__(messages)
    LM-->>Adapter: completions
    Adapter-->>Predict: completions
    Predict->>Prediction: from_completions(completions)
    Prediction-->>Predict: pred
    Predict-->>Module: pred
    Module->>Module: output.set_lm_usage(tokens)
    Module-->>User: Prediction
```

---

## Persistence & Versioning

The module system records dependency versions at save time and validates them at load time to protect against silent incompatibilities.

```mermaid
flowchart TD
    Save["save(path)"] --> Meta["metadata.dependency_versions =<br/>get_dependency_versions()"]
    Meta --> Write["write state + metadata"]
    Write --> Load["load(path)"]
    Load --> Compare{"versions match?"}
    Compare -->|yes| LoadState["load_state(state)"]
    Compare -->|no| Warn["log warning about mismatch"]
    Warn --> LoadState
```

Tracked dependencies (via `get_dependency_versions`): `python`, `dspy`, and `cloudpickle`.

---

## Relationship to Other Modules

| Module | Relationship |
|--------|--------------|
| [primitives_data_containers.md](primitives_data_containers.md) | `Example` provides inputs; `Prediction` (a subclass of `Example`) is the standard output type. |
| [predict_core.md](predict_core.md) | `Predict` inherits from both `Module` and `Parameter`, making it both a composable module and a discoverable parameter. |
| [predict_strategies.md](predict_strategies.md) | Higher-level strategies (`ChainOfThought`, `ReAct`, etc.) subclass `Module` and compose `Predict` instances. |
| [predict_utilities.md](predict_utilities.md) | `Parallel` powers `Module.batch` for concurrent execution. |
| [dsp_settings.md](dsp_settings.md) | `Settings` provides global config and thread-local overrides consumed by `Module.__call__`. |
| [utils.md](utils.md) | `with_callbacks`, `track_usage`, and `get_dependency_versions` provide cross-cutting infrastructure. |
| [adapters_core.md](adapters_core.md) | Adapters are invoked by `Predict.forward` to format LM interactions. |
| [clients_lm_core.md](clients_lm_core.md) | `LM` instances are assigned to predictors via `set_lm`. |

---

## Summary

The **Primitives Module System** is the backbone of DSPy program composition:

- **`BaseModule`** handles *structure*: discovering parameters and sub-modules, copying, resetting, and serializing state.
- **`Module`** handles *execution*: the `__call__`/`forward` contract, callbacks, usage tracking, settings propagation, predictor management, and batching.
- **`ProgramMeta`** guarantees robust initialization of every module instance.
- **`Program`** is a backward-compatible alias for `Module`.

Together, these components enable DSPy programs to be composed recursively, executed with consistent cross-cutting behavior, and persisted with version-aware safety.
