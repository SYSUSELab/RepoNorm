# Adapters Core

## Introduction

The **Adapters Core** module provides the foundational abstraction layer that bridges DSPy's structured `Signature`-based programs and the raw text/chat interfaces of Large Language Models (LMs). Adapters are responsible for two critical transformations:

1. **Formatting** — converting a DSPy `Signature`, few-shot demonstrations, and input values into the multiturn message format expected by an LM.
2. **Parsing** — converting the LM's raw text response back into a structured dictionary of typed output fields.

This module defines the abstract `Adapter` base class and a family of concrete adapters (`ChatAdapter`, `JSONAdapter`, `XMLAdapter`, `TwoStepAdapter`) that implement different serialization strategies. It also handles advanced concerns such as native function/tool calling, conversation history, and structured output enforcement.

> **Related modules:** For the custom types used within signatures (e.g. `Image`, `Tool`, `History`), see [adapters_types](adapters_types.md). For the LM client that adapters invoke, see [clients](clients.md). For the `Signature` definition itself, see [signatures](signatures.md).

---

## Architecture Overview

The adapters module is organized around a single abstract base class with a hierarchy of concrete implementations. Each adapter specializes in a particular wire format for communicating with the LM.

```mermaid
graph TD
    Adapter["Adapter (abstract base)<br/>dspy/adapters/base.py"]
    ChatAdapter["ChatAdapter<br/>dspy/adapters/chat_adapter.py"]
    JSONAdapter["JSONAdapter<br/>dspy/adapters/json_adapter.py"]
    XMLAdapter["XMLAdapter<br/>dspy/adapters/xml_adapter.py"]
    TwoStepAdapter["TwoStepAdapter<br/>dspy/adapters/two_step_adapter.py"]

    Adapter --> ChatAdapter
    Adapter --> TwoStepAdapter
    ChatAdapter --> JSONAdapter
    ChatAdapter --> XMLAdapter

    ChatAdapter -. "fallback on error" .-> JSONAdapter
    TwoStepAdapter -. "uses for extraction" .-> ChatAdapter
```

### Adapter Responsibilities at a Glance

| Adapter | Wire Format | Key Characteristic |
|---------|-------------|--------------------|
| `Adapter` | *(abstract)* | Defines the `format`/`parse` contract and shared orchestration logic |
| `ChatAdapter` | `[[ ## field ## ]]` section markers | Default chat-based format; falls back to `JSONAdapter` on failure |
| `JSONAdapter` | JSON object | Uses OpenAI Structured Outputs when supported; robust JSON repair |
| `XMLAdapter` | `<field>...</field>` tags | XML-tagged output fields |
| `TwoStepAdapter` | Natural language + extraction | Uses a second, smaller LM to extract structured data from free-form output |

---

## The `Adapter` Base Class

`Adapter` (in `dspy/adapters/base.py`) is the abstract foundation for all adapters. It defines the complete lifecycle of an LM interaction and provides shared utilities that concrete adapters reuse.

### Core Lifecycle

The `__call__` (and `acall`) method orchestrates the full request/response cycle:

```mermaid
sequenceDiagram
    participant Caller as Predict / Module
    participant Adapter
    participant LM

    Caller->>Adapter: __call__(lm, lm_kwargs, signature, demos, inputs)
    Adapter->>Adapter: _call_preprocess(...)
    Note over Adapter: Handle native function calling,<br/>strip tool-call output field
    Adapter->>Adapter: format(signature, demos, inputs)
    Note over Adapter: Build system + few-shot + user messages
    Adapter->>LM: lm(messages=..., **lm_kwargs)
    LM-->>Adapter: raw outputs
    Adapter->>Adapter: _call_postprocess(signature, outputs)
    Note over Adapter: parse() each output, attach tool calls & logprobs
    Adapter-->>Caller: list[dict[str, Any]]
```

### Key Methods

| Method | Purpose |
|--------|---------|
| `__call__` / `acall` | Synchronous/asynchronous entry point orchestrating preprocess → format → LM call → postprocess |
| `_call_preprocess` | Configures native function calling; removes the tool-call output field from the signature when tools are supplied |
| `_call_postprocess` | Parses each LM output, attaches `ToolCalls` and logprobs |
| `format` | Builds the multiturn message list (system, demos, history, current input) |
| `parse` | *(abstract)* Converts raw LM text into a typed output dictionary |
| `format_field_description` | *(abstract)* Renders input/output field descriptions for the system message |
| `format_field_structure` | *(abstract)* Renders the expected input/output structure |
| `format_task_description` | *(abstract)* Renders the task instructions |
| `format_user_message_content` | *(abstract)* Renders a user message from inputs |
| `format_assistant_message_content` | *(abstract)* Renders an assistant message from outputs |
| `format_demos` | Formats few-shot examples as multiturn messages |
| `format_conversation_history` | Formats `History`-typed fields into multiturn messages |

### Callback Integration

The base class uses `__init_subclass__` to automatically decorate every subclass's `format` and `parse` methods with the `with_callbacks` decorator (from [utils](utils.md)). This ensures that all adapters emit start/end callback events without requiring each subclass to implement this manually.

```python
def __init_subclass__(cls, **kwargs) -> None:
    super().__init_subclass__(**kwargs)
    cls.format = with_callbacks(cls.format)
    cls.parse = with_callbacks(cls.parse)
```

### Native Function Calling

When `use_native_function_calling=True`, `_call_preprocess` inspects the signature for:

- An **input field** annotated as `list[dspy.Tool]` or `dspy.Tool` (the tool definitions).
- An **output field** annotated as `ToolCalls` (where the model's tool calls are captured).

If tools are provided, they are converted to LiteLLM function-call format via `Tool.format_as_litellm_function_call()`, and the tool-call output field is removed from the signature passed to the LM. See [adapters_types](adapters_types.md) for details on `Tool` and `ToolCalls`.

### Conversation History Handling

The base `format` method detects a `History`-typed input field via `_get_history_field_name`. When present, it:

1. Removes the history field from the signature.
2. Formats the history messages into alternating user/assistant turns via `format_conversation_history`.
3. Appends the current input as the final user message.

### Few-Shot Demo Handling

`format_demos` separates demos into **complete** (all fields present and non-`None`) and **incomplete** (at least one input and one output field). Incomplete demos are prefixed with a clarifying message, and missing fields are filled with a placeholder message.

---

## Concrete Adapters

### `ChatAdapter`

The default adapter. It structures interactions using section markers of the form `[[ ## field_name ## ]]`.

- **Field structure:** Each input and output field is rendered in its own section, terminated by a `[[ ## completed ## ]]` marker.
- **Parsing:** Uses the regex `field_header_pattern = re.compile(r"\[\[ ## (\w+) ## \]\]")` to split the completion into sections, then casts each value via `parse_value`.
- **Fallback behavior:** If the call raises any exception (other than `ContextWindowExceededError`), `ChatAdapter.__call__` transparently retries using `JSONAdapter`. This makes it resilient to models that struggle with the marker format.
- **Finetune support:** Implements `format_finetune_data` to produce OpenAI-style `{"messages": [...]}` training data.

The `FieldInfoWithName` `NamedTuple` pairs a field's name with its Pydantic `FieldInfo`, used throughout the formatting helpers.

### `JSONAdapter`

Extends `ChatAdapter` to produce and consume JSON.

- **Structured Outputs:** When the model supports the `response_format` parameter, it builds a Pydantic model from the signature's output fields via `_get_structured_outputs_response_format` and enforces OpenAI Structured Outputs constraints (all properties required, `additionalProperties: false`).
- **Open-ended mappings:** If any output field is a `dict[...]` type (detected by `_has_open_ended_mapping`), structured outputs are skipped in favor of plain `{"type": "json_object"}` mode.
- **Graceful degradation:** If structured output fails, it falls back to JSON mode, and finally raises a descriptive `RuntimeError` if both fail.
- **Parsing:** Extracts the first balanced JSON object using a recursive regex, then repairs and loads it with `json_repair`.
- **Native function calling:** Overrides `_call_preprocess` to default `use_native_function_calling=True`.

### `XMLAdapter`

Extends `ChatAdapter` to use XML tags (`<field>...</field>`) instead of section markers.

- **Field structure:** Overrides `format_field_with_value` to wrap each field in XML tags.
- **Parsing:** Uses the regex `<(?P<name>\w+)>((?P<content>.*?))</\1>` to extract tagged content, then casts values via `parse_value`.

### `TwoStepAdapter`

A specialized adapter for reasoning models (e.g. OpenAI o-series) that struggle with structured outputs.

- **Two-stage design:**
  1. The **main LM** receives a natural-language prompt (no rigid structure required).
  2. A smaller **extraction LM** (passed to the constructor) uses `ChatAdapter` to extract structured fields from the main LM's free-form response.
- **Extractor signature:** `_create_extractor_signature` dynamically builds a `text -> {original output fields}` signature.
- **Async support:** Provides a dedicated `acall` implementation that mirrors the two-step logic asynchronously.

> **Note:** The second step's signature is created on the fly and invoked with a fresh `ChatAdapter` with no demonstrations, meaning it cannot be optimized/learned. This is a known limitation documented in the source.

---

## Data Flow

The following diagram illustrates how data flows through an adapter during a typical prediction.

```mermaid
flowchart LR
    subgraph Input
        Sig["Signature<br/>(input/output fields)"]
        Demos["Demos<br/>(few-shot examples)"]
        In["Inputs<br/>(dict)"]
    end

    subgraph Adapter["Adapter.format()"]
        Sys["System message<br/>(field desc + structure + task)"]
        FewShot["Few-shot messages"]
        Hist["History messages"]
        User["Current user message"]
    end

    subgraph LM["LM Call"]
        Raw["Raw LM response"]
    end

    subgraph Parse["Adapter.parse()"]
        Typed["Typed output dict"]
    end

    Sig --> Sys
    Sig --> FewShot
    Sig --> User
    Demos --> FewShot
    In --> User
    In --> Hist

    Sys --> LM
    FewShot --> LM
    Hist --> LM
    User --> LM
    LM --> Raw
    Raw --> Typed
```

---

## Dependencies

The adapters module depends on several other DSPy subsystems:

```mermaid
graph LR
    Adapters["adapters_core"]
    Types["adapters_types<br/>(BaseType, Tool, ToolCalls, History)"]
    Utils["adapters/utils<br/>(format_field_value, parse_value, ...)"]
    Signatures["signatures<br/>(Signature)"]
    Clients["clients<br/>(LM)"]
    Callbacks["utils/callback<br/>(with_callbacks)"]
    Exceptions["utils/exceptions<br/>(AdapterParseError)"]

    Adapters --> Types
    Adapters --> Utils
    Adapters --> Signatures
    Adapters --> Clients
    Adapters --> Callbacks
    Adapters --> Exceptions
```

| Dependency | Role |
|------------|------|
| [adapters_types](adapters_types.md) | Provides `BaseType`, `Tool`, `ToolCalls`, `History` used in signatures and formatting |
| `adapters/utils` | Shared helpers: `format_field_value`, `parse_value`, `get_field_description_string`, `translate_field_type`, `get_annotation_name`, `serialize_for_json` |
| [signatures](signatures.md) | The `Signature` class that adapters format and parse against |
| [clients](clients.md) | The `LM` class that adapters invoke via `lm(messages=..., **kwargs)` |
| [utils](utils.md) | `with_callbacks` decorator and `AdapterParseError` exception |
| External | `litellm` (function calling, structured outputs), `json_repair`, `pydantic`, `regex` |

---

## Error Handling

Adapters raise `AdapterParseError` (from [utils](utils.md)) when the LM response cannot be parsed into the expected output fields. This exception captures:

- The adapter name
- The signature
- The raw LM response
- The parsed result (if any)

`ChatAdapter` additionally implements a **fallback chain**: on any non-context-window error, it retries with `JSONAdapter`. `JSONAdapter` itself falls back from structured outputs → JSON mode → `RuntimeError`.

---

## Extension Guide

To create a custom adapter, subclass `Adapter` and implement the abstract methods:

1. `format_field_description(signature)` — describe input/output fields.
2. `format_field_structure(signature)` — describe the expected wire format.
3. `format_task_description(signature)` — describe the task (usually wraps `signature.instructions`).
4. `format_user_message_content(signature, inputs, ...)` — render user messages.
5. `format_assistant_message_content(signature, outputs, ...)` — render assistant messages.
6. `parse(signature, completion)` — parse the LM response into a typed dict.

The base class automatically handles callbacks, native function calling, conversation history, and few-shot demo formatting, so subclasses only need to focus on the wire format.

---

## Summary

The **Adapters Core** module is the translation layer between DSPy's structured programming model and the unstructured text interface of LLMs. Its layered design — an abstract `Adapter` base with specialized `ChatAdapter`, `JSONAdapter`, `XMLAdapter`, and `TwoStepAdapter` implementations — provides flexibility across model capabilities while sharing common orchestration logic for callbacks, tool calling, history, and demos. Robust fallback chains and structured error reporting make it resilient to the inherent variability of LM outputs.
