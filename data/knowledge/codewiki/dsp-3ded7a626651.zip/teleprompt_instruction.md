# Teleprompt Instruction Module

## Introduction

The **Teleprompt Instruction** module provides optimizers that automatically improve the *instructions* (and optionally the few-shot demonstrations) of a DSPy program. Unlike optimizers that only select demonstrations, these teleprompters rewrite the natural-language instructions attached to each predictor's `Signature`, using a separate "prompt model" to propose and refine candidate instructions, and a task metric to score them.

The module contains three optimizers:

| Optimizer | Strategy | Status |
|-----------|----------|--------|
| `COPRO` | Iterative breadth/depth search over generated instructions | Active |
| `MIPROv2` | Bayesian (Optuna/TPE) optimization over instructions + demos | Active |
| `SignatureOptimizer` | Thin deprecated wrapper around `COPRO` | Deprecated |

All three inherit from the base [`Teleprompter`](teleprompt_core.md) class and follow the same `compile(student, *, trainset, ...)` contract.

---

## Module Architecture

The module sits within the broader `teleprompt` package and depends on several other subsystems (proposers, evaluation, signatures, and the LM clients).

```mermaid
graph TD
    subgraph "teleprompt_instruction"
        COPRO[COPRO]
        MIPRO[MIPROv2]
        SIGOPT[SignatureOptimizer]
        BGI[BasicGenerateInstruction]
        GIGA[GenerateInstructionGivenAttempts]
    end

    subgraph "teleprompt_core"
        TP[Teleprompter]
    end

    subgraph "propose"
        GP[GroundedProposer]
    end

    subgraph "evaluate"
        EV[Evaluate]
    end

    subgraph "signatures"
        SIG[Signature]
    end

    subgraph "clients"
        LM[LM / BaseLM]
    end

    SIGOPT -->|extends| COPRO
    COPRO -->|extends| TP
    MIPRO -->|extends| TP
    COPRO -->|uses| BGI
    COPRO -->|uses| GIGA
    COPRO -->|uses| EV
    MIPRO -->|uses| GP
    MIPRO -->|uses| EV
    COPRO -->|mutates| SIG
    MIPRO -->|mutates| SIG
    GP -->|uses| LM
    COPRO -->|uses| LM
```

---

## Component Overview

### `COPRO`

`COPRO` (Coordinate-ascent Prompt Optimization) is a breadth/depth search optimizer. It generates a batch of candidate instructions (`breadth`), evaluates each against the task metric, keeps the best, and then uses the history of attempts to generate a new batch (`depth` iterations).

**Key parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `prompt_model` | `None` | LM used to generate instructions. Falls back to `dspy.settings.lm`. |
| `metric` | `None` | Task metric used to score candidate programs. |
| `breadth` | `10` | Number of new prompts generated per iteration (must be `> 1`). |
| `depth` | `3` | Number of refinement iterations. |
| `init_temperature` | `1.4` | Sampling temperature for instruction generation. |
| `track_stats` | `False` | Whether to record per-depth statistics on the returned program. |

**Internal helper methods:**

- `_get_signature` / `_set_signature` — read and replace a predictor's `Signature`.
- `_check_candidates_equal` — compares two candidate programs by instruction and output-field prefix.
- `_drop_duplicates` — removes duplicate candidates that share the same score.
- `_print_signature` — debug logging of a predictor's instruction and prefix.

### `BasicGenerateInstruction` (Signature)

A DSPy `Signature` used to seed the search. Given an initial `basic_instruction`, it proposes an improved `proposed_instruction` and a `proposed_prefix_for_output_field` (the string that primes the model's output).

### `GenerateInstructionGivenAttempts` (Signature)

A DSPy `Signature` used during refinement. Given a list of `attempted_instructions` (with their scores), it proposes a new, better instruction and output prefix.

### `MIPROv2`

`MIPROv2` (Multi-prompt Instruction PRoposal Optimizer v2) combines instruction proposal with few-shot demonstration bootstrapping and uses **Bayesian optimization** (Optuna's TPE sampler) to jointly search over instruction and demo combinations.

**Key parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `metric` | required | Task metric. |
| `prompt_model` | `None` | LM for instruction proposal. |
| `task_model` | `None` | LM for task execution. |
| `max_bootstrapped_demos` | `4` | Max bootstrapped demos per predictor. |
| `max_labeled_demos` | `4` | Max labeled demos per predictor. |
| `auto` | `"light"` | Preset run mode: `"light"`, `"medium"`, `"heavy"`, or `None`. |
| `num_candidates` | `None` | Number of instruction/demo candidates (when `auto=None`). |
| `num_threads` | `None` | Parallel evaluation threads. |
| `seed` | `9` | Random seed. |
| `init_temperature` | `0.5` | Instruction proposal temperature. |
| `track_stats` | `True` | Attach trial logs and candidate programs to the result. |
| `metric_threshold` | `None` | Threshold passed to demo bootstrapping. |

**Auto run settings** (`AUTO_RUN_SETTINGS`):

| Mode | `n` (candidates) | `val_size` |
|------|------------------|------------|
| light | 6 | 100 |
| medium | 12 | 300 |
| heavy | 18 | 1000 |

### `SignatureOptimizer` (Deprecated)

A backward-compatible subclass of `COPRO`. It emits a deprecation warning on construction and simply forwards `compile(student, *, devset, eval_kwargs)` to `COPRO.compile(student, trainset=devset, eval_kwargs=eval_kwargs)`. **Use `COPRO` instead.**

---

## COPRO Process Flow

COPRO performs a coordinate-ascent search: for each predictor it generates candidates, evaluates them, keeps the best, and iterates.

```mermaid
flowchart TD
    Start([compile student, trainset, eval_kwargs]) --> Copy[Deep-copy student into module]
    Copy --> Seed[For each predictor: seed with BasicGenerateInstruction<br/>generate breadth-1 candidates + original]
    Seed --> DepthLoop{depth iterations}

    DepthLoop -->|for each predictor| EvalCandidates[For each candidate:<br/>set instruction + prefix on clone]
    EvalCandidates --> Score[Evaluate clone on trainset via Evaluate]
    Score --> Track[Record score in evaluated_candidates]
    Track --> Best[Set predictor to best-scoring candidate]
    Best --> MorePred{More predictors?}
    MorePred -->|yes| EvalCandidates
    MorePred -->|no| LastDepth{Last depth?}

    LastDepth -->|yes| Collect[Collect all evaluated candidates]
    LastDepth -->|no| Refine[Build attempts history from best candidates]
    Refine --> GenNew[GenerateInstructionGivenAttempts<br/>generate breadth new candidates]
    GenNew --> DepthLoop

    Collect --> Sort[Sort by score, drop duplicates]
    Sort --> Return([Return best program with candidate_programs])
```

### COPRO Data Flow

```mermaid
sequenceDiagram
    participant User
    participant COPRO
    participant PromptLM as Prompt Model
    participant Eval as Evaluate
    participant TaskLM as Task Model

    User->>COPRO: compile(student, trainset, eval_kwargs)
    COPRO->>PromptLM: BasicGenerateInstruction(basic_instruction)
    PromptLM-->>COPRO: breadth candidate instructions
    loop depth iterations
        loop each candidate
            COPRO->>Eval: evaluate(clone, trainset)
            Eval->>TaskLM: run program on examples
            TaskLM-->>Eval: predictions
            Eval-->>COPRO: score
        end
        COPRO->>COPRO: keep best candidate per predictor
        COPRO->>PromptLM: GenerateInstructionGivenAttempts(attempts)
        PromptLM-->>COPRO: new candidate batch
    end
    COPRO-->>User: best_program (with candidate_programs, total_calls)
```

---

## MIPROv2 Process Flow

MIPROv2 runs a three-step pipeline followed by Bayesian optimization.

```mermaid
flowchart TD
    Start([compile student, trainset, valset]) --> Validate[Validate auto / num_candidates / num_trials]
    Validate --> Seeds[Set random seeds]
    Seeds --> Datasets[Split & validate trainset/valset]
    Datasets --> Hyper[Set hyperparams from run mode]
    Hyper --> Confirm{requires_permission_to_run?}
    Confirm -->|yes| Ask[Estimate LM calls & ask user]
    Confirm -->|no| Step1
    Ask -->|abort| ReturnStudent([Return original student])
    Ask -->|proceed| Step1

    Step1[Step 1: Bootstrap few-shot examples] --> Step2[Step 2: Propose instruction candidates<br/>via GroundedProposer]
    Step2 --> Zero{zeroshot?}
    Zero -->|yes| DropDemos[Discard demo candidates]
    Zero -->|no| Step3
    DropDemos --> Step3[Step 3: Optimize prompt parameters<br/>Optuna TPE]
    Step3 --> Return([Return best program])
```

### MIPROv2 Optimization Loop

```mermaid
flowchart TD
    Init[Evaluate default program] --> Study[Create Optuna study with TPE sampler]
    Study --> AddDefault[Add default program as baseline trial]
    AddDefault --> TrialLoop{num_trials}

    TrialLoop --> Select[Select instruction + demo indices per predictor]
    Select --> EvalCand[Evaluate candidate on minibatch or full valset]
    EvalCand --> Update{score > best?}
    Update -->|yes| NewBest[Update best program]
    Update -->|no| Log
    NewBest --> Log[Log trial results]
    Log --> FullEval{minibatch & interval reached?}
    FullEval -->|yes| DoFull[Full eval on top-averaging program<br/>add as Optuna trial]
    FullEval -->|no| TrialLoop
    DoFull --> TrialLoop

    TrialLoop -->|done| Attach[Attach trial_logs, candidate_programs,<br/>mb_candidate_programs to best program]
    Attach --> Return([Return best program])
```

### MIPROv2 Data Flow

```mermaid
sequenceDiagram
    participant User
    participant MIPRO as MIPROv2
    participant GP as GroundedProposer
    participant Optuna
    participant Eval as Evaluate
    participant TaskLM as Task Model

    User->>MIPRO: compile(student, trainset, valset)
    MIPRO->>MIPRO: bootstrap few-shot demo candidates
    MIPRO->>GP: propose_instructions_for_program(...)
    GP-->>MIPRO: instruction_candidates
    MIPRO->>Optuna: create_study(TPE)
    loop num_trials
        Optuna->>MIPRO: suggest instruction/demo indices
        MIPRO->>Eval: evaluate(candidate_program, valset)
        Eval->>TaskLM: run program
        TaskLM-->>Eval: predictions
        Eval-->>MIPRO: score
        MIPRO->>Optuna: report score
    end
    MIPRO-->>User: best_program (with trial_logs)
```

---

## Component Interaction

The following diagram shows how the core components interact at runtime.

```mermaid
graph LR
    subgraph Optimizers
        COPRO
        MIPRO
    end

    subgraph "Instruction Generation"
        BGI[BasicGenerateInstruction]
        GIGA[GenerateInstructionGivenAttempts]
        GP[GroundedProposer]
    end

    subgraph "Scoring"
        EV[Evaluate]
        METRIC[metric callable]
    end

    subgraph "Program Mutation"
        SIG[Signature.with_instructions]
        SIGF[Signature.with_updated_fields]
    end

    COPRO --> BGI
    COPRO --> GIGA
    COPRO --> EV
    COPRO --> SIG
    COPRO --> SIGF
    MIPRO --> GP
    MIPRO --> EV
    MIPRO --> SIG
    EV --> METRIC
```

---

## Dependencies

| Dependency | Purpose | Documentation |
|------------|---------|---------------|
| `Teleprompter` | Base class defining the `compile` contract | [teleprompt_core.md](teleprompt_core.md) |
| `Evaluate` | Scores candidate programs against a metric | [evaluate_orchestration.md](evaluate_orchestration.md) |
| `GroundedProposer` | Generates grounded instruction candidates (MIPROv2) | [propose_grounded.md](propose_grounded.md) |
| `Signature` | Holds instructions and fields that are mutated | [signatures_core.md](signatures_core.md) |
| `LM` / `BaseLM` | Prompt and task models | [clients_lm_core.md](clients_lm_core.md) |
| `Module` / `BaseModule` | The program being optimized | [primitives_module_system.md](primitives_module_system.md) |
| `Example` | Training/validation data items | [primitives_data_containers.md](primitives_data_containers.md) |
| `optuna` | Bayesian optimization backend (MIPROv2) | external |

---

## Usage Examples

### COPRO

```python
from dspy.teleprompt import COPRO

teleprompter = COPRO(
    prompt_model=prompt_model,
    metric=metric,
    breadth=10,
    depth=3,
    init_temperature=1.4,
)
kwargs = dict(num_threads=8, display_progress=True, display_table=0)
compiled = teleprompter.compile(program.deepcopy(), trainset=trainset, eval_kwargs=kwargs)
```

### MIPROv2

```python
from dspy.teleprompt import MIPROv2

teleprompter = MIPROv2(
    metric=metric,
    auto="light",          # or "medium"/"heavy", or None with num_candidates
    num_threads=8,
)
compiled = teleprompter.compile(
    program,
    trainset=trainset,
    valset=valset,
    requires_permission_to_run=False,
)
```

### SignatureOptimizer (Deprecated)

```python
from dspy.teleprompt import SignatureOptimizer

# Deprecated — use COPRO instead
teleprompter = SignatureOptimizer(prompt_model=prompt_model, metric=metric)
compiled = teleprompter.compile(program.deepcopy(), devset=devset, eval_kwargs=kwargs)
```

---

## Choosing an Optimizer

```mermaid
flowchart TD
    Q1{Need joint instruction + demo optimization?}
    Q1 -->|yes| MIPRO[MIPROv2]
    Q1 -->|no| Q2{Want simple breadth/depth search?}
    Q2 -->|yes| COPRO[COPRO]
    Q2 -->|no| SIGOPT[SignatureOptimizer - deprecated, use COPRO]
```

- **Use `MIPROv2`** when you want the strongest optimization and can afford more LM calls. It jointly optimizes instructions and few-shot demos using Bayesian search and supports `auto` presets.
- **Use `COPRO`** when you want a lightweight, transparent instruction-only search with controllable breadth/depth.
- **Avoid `SignatureOptimizer`** — it is deprecated and simply wraps `COPRO`.

---

## Related Modules

- [teleprompt_core.md](teleprompt_core.md) — Base `Teleprompter`, `LabeledFewShot`, `Ensemble`.
- [teleprompt_bootstrap.md](teleprompt_bootstrap.md) — Demonstration-based bootstrapping optimizers.
- [teleprompt_finetune.md](teleprompt_finetune.md) — Fine-tuning based optimizers.
- [propose_grounded.md](propose_grounded.md) — The `GroundedProposer` used by MIPROv2.
- [evaluate_orchestration.md](evaluate_orchestration.md) — The `Evaluate` class used for scoring.
- [signatures_core.md](signatures_core.md) — `Signature` mutation APIs.
