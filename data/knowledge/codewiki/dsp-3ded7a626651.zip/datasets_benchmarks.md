# Datasets & Benchmarks Module

## Introduction

The `datasets_benchmarks` module provides a collection of **ready-to-use benchmark datasets** for evaluating and optimizing DSPy programs. Each benchmark wraps a well-known academic dataset (GSM8K, HotPotQA, MATH, etc.) or a synthetic task (Colors, AlfWorld) and exposes it through a consistent interface of `train` / `dev` / `test` splits composed of [`dspy.Example`](primitives.md) objects.

These benchmarks are the standard entry points used throughout DSPy for:
- **Few-shot demonstration selection** during optimization (e.g., [`BootstrapFewShot`](teleprompt.md), [`MIPROv2`](teleprompt.md)).
- **Evaluation** of compiled programs via [`Evaluate`](evaluate.md).
- **Reproducible experimentation** through deterministic seeding and shuffling.

The module builds on top of the core dataset abstractions in the [`datasets_core`](datasets_core.md) module (`Dataset` and `DataLoader`), which handle splitting, shuffling, sampling, and conversion of raw records into `dspy.Example` instances.

---

## Architecture Overview

The benchmarks fall into two categories:

1. **`Dataset`-derived benchmarks** — subclasses of the core [`Dataset`](datasets_core.md) base class (`HotPotQA`, `Colors`). These inherit the lazy `train`/`dev`/`test` properties, seed management, and `prepare_by_seed` utilities.
2. **Standalone benchmarks** — self-contained classes that build their own splits (`GSM8K`, `MATH`, `AlfWorld`). These do not inherit from `Dataset` but follow the same `train`/`dev`/`test` attribute convention.

```mermaid
graph TD
    subgraph "datasets_core"
        Dataset["Dataset<br/>(base class)"]
        DataLoader["DataLoader"]
    end

    subgraph "datasets_benchmarks"
        HotPotQA["HotPotQA"]
        Colors["Colors"]
        GSM8K["GSM8K"]
        MATH["MATH"]
        AlfWorld["AlfWorld"]
        EnvPool["EnvPool"]
        EnvSession["_EnvSession"]
    end

    subgraph "primitives"
        Example["Example"]
    end

    subgraph "External"
        HF["HuggingFace datasets"]
        AlfLib["alfworld library"]
    end

    Dataset --> HotPotQA
    Dataset --> Colors
    Dataset --> DataLoader

    HotPotQA --> HF
    GSM8K --> HF
    MATH --> HF
    Colors --> Example
    HotPotQA --> Example
    GSM8K --> Example
    MATH --> Example

    AlfWorld --> EnvPool
    EnvPool --> EnvSession
    AlfWorld --> AlfLib
    AlfWorld --> Example
```

---

## Component Relationships

```mermaid
classDiagram
    class Dataset {
        +train
        +dev
        +test
        +reset_seeds()
        +prepare_by_seed()
    }
    class HotPotQA {
        +only_hard_examples
        +keep_details
        +unofficial_dev
    }
    class Colors {
        +sort_by_suffix
        +sorted_by_suffix()
    }
    class GSM8K {
        +train
        +dev
        +test
    }
    class MATH {
        +subset
        +metric()
    }
    class AlfWorld {
        +POOL
        +trainset
        +devset
    }
    class EnvPool {
        +session()
        +close_all()
    }
    class _EnvSession {
        +init(idx)
        +step(action)
    }

    Dataset <|-- HotPotQA
    Dataset <|-- Colors
    AlfWorld --> EnvPool
    EnvPool --> _EnvSession
```

---

## Benchmark Reference

### GSM8K

**File:** `dspy/datasets/gsm8k.py`

A grade-school math word-problem benchmark. It loads the `gsm8k` (`main` configuration) dataset from HuggingFace and parses each record into a `question`, `gold_reasoning` (the chain-of-thought), and a normalized integer `answer`.

| Split | Size | Source |
|-------|------|--------|
| `train` | 200 | First 200 of shuffled official train |
| `dev` | 300 | Next 300 of shuffled official train |
| `test` | full | Entire official test set |

**Key behaviors:**
- Uses `random.Random(0)` for deterministic shuffling of both train and test.
- Each example is wrapped as `dspy.Example(...).with_inputs("question")`.
- The answer is extracted by splitting on the `####` delimiter and stripping commas.

**Metric:** `gsm8k_metric(gold, pred, trace=None)` compares the parsed integer answer of the gold and prediction. The helper `parse_integer_answer` extracts the last numeric token from a string, tolerating multi-line outputs.

```mermaid
flowchart LR
    A["HuggingFace gsm8k/main"] --> B["Parse answer<br/>split on '####'"]
    B --> C["gold_reasoning + answer"]
    C --> D["Shuffle (seed=0)"]
    D --> E["train[:200]"]
    D --> F["dev[200:500]"]
    D --> G["test (all)"]
    E & F & G --> H["dspy.Example.with_inputs('question')"]
```

---

### HotPotQA

**File:** `dspy/datasets/hotpotqa.py`

A multi-hop question-answering benchmark. Subclasses [`Dataset`](datasets_core.md) and loads the `hotpot_qa` (`fullwiki`) dataset.

**Constructor parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `only_hard_examples` | `True` | Must remain `True`; asserts that only hard examples are used so dev matches the official dev set. |
| `keep_details` | `"dev_titles"` | Controls which fields are retained. `True` keeps all fields; `"dev_titles"` keeps `question`, `answer`, `supporting_facts`; otherwise only `question`, `answer`. |
| `unofficial_dev` | `True` | If `True`, the dev split is carved from the tail of the official train set. |

**Key behaviors:**
- Filters training examples to `level == "hard"`.
- Converts `supporting_facts` into a `gold_titles` set.
- Splits official train 75% / 25% into train / (unofficial) dev.
- The official validation split becomes the test set.

---

### MATH

**File:** `dspy/datasets/math.py`

A competition-level mathematics benchmark. Loads `DigitalLearningGmbH/MATH-lighteval` for a given `subset` (e.g., `"algebra"`, `"geometry"`).

**Key behaviors:**
- The dataset's `test` split is sub-split into train/dev/test (since LMs are typically trained on MATH's train split).
- Each split has size `min(350, len(dataset) // 3)`.
- `extract_answer` parses the `\boxed{...}` content, handling nested braces and stripping `\text{}` and `\!` formatting.

**Metric:** `MATH.metric(example, pred, trace=None)` uses the external `math_equivalence.is_equiv` function. This requires installing the official MATH package:

```bash
pip install git+https://github.com/hendrycks/math.git
```

> **Note:** The official `math_equivalence.is_equiv` does not have perfect recall for some reference values (e.g., interval notation).

---

### Colors

**File:** `dspy/datasets/colors.py`

A synthetic benchmark built from a curated list of ~140 color names (originally from matplotlib). Subclasses [`Dataset`](datasets_core.md).

**Key behaviors:**
- `sort_by_suffix=True` (default) sorts colors by their reversed string, so colors sharing a suffix (e.g., "sky blue", "navy blue") are grouped together.
- Splits 60% / 40% into train / dev, chosen so similar colors do not repeat across splits.
- Each example is a simple `{"color": color}` dict, shuffled with `random.Random(0)`.

This benchmark is commonly used for classification-style tasks where the model must map a color name to a category.

---

### AlfWorld

**File:** `dspy/datasets/alfworld/alfworld.py`

An interactive, text-based embodied-agent benchmark built on the external `alfworld` library. Unlike the other benchmarks, AlfWorld provides **environment sessions** rather than static examples.

**Components:**

| Component | Role |
|-----------|------|
| `AlfWorld` | Top-level benchmark; owns an `EnvPool` and exposes `trainset` (3000) / `devset` (500) of `dspy.Example(idx=...)`. |
| `EnvPool` | A pool of worker processes, each hosting an independent AlfredTWEnv instance. |
| `_EnvSession` | A context manager that acquires a worker and exposes `.init(idx)` / `.step(action)`. |
| `env_worker` | The worker-process entry point that handles `init`, `step`, and `close` commands. |

**Requirements:**
```bash
pip install alfworld==0.3.5
alfworld-download
pip install multiprocess
```

**Key behaviors:**
- Uses `multiprocess` with the `spawn` start method (required for compatibility).
- `AlfWorld(max_threads=20)` creates a pool of 20 workers by default.
- Examples are indexed `0..3499`, shuffled with `random.Random(0)`, then split into train (first 3000) and dev (last 500).
- `__del__` closes all pool processes.

```mermaid
sequenceDiagram
    participant User
    participant AlfWorld
    participant EnvPool
    participant _EnvSession
    participant env_worker

    User->>AlfWorld: __init__(max_threads)
    AlfWorld->>EnvPool: EnvPool(size)
    EnvPool->>env_worker: spawn N processes
    User->>EnvPool: session()
    EnvPool-->>_EnvSession: acquire worker
    User->>_EnvSession: init(idx)
    _EnvSession->>env_worker: ("init", idx)
    env_worker-->>_EnvSession: (task_def, info)
    User->>_EnvSession: step(action)
    _EnvSession->>env_worker: ("step", action)
    env_worker-->>_EnvSession: (obs, rew, done, info)
    User->>_EnvSession: __exit__
    _EnvSession->>EnvPool: release worker
```

---

## Data Flow

The following diagram illustrates how raw external data flows through the benchmarks into DSPy programs.

```mermaid
flowchart TD
    subgraph External Sources
        HF["HuggingFace datasets"]
        ALF["alfworld library"]
    end

    subgraph "datasets_benchmarks"
        GSM["GSM8K"]
        HPQ["HotPotQA"]
        MATH["MATH"]
        COL["Colors"]
        AW["AlfWorld"]
    end

    subgraph "datasets_core"
        DS["Dataset base"]
        DL["DataLoader"]
    end

    subgraph "primitives"
        EX["Example"]
    end

    subgraph Consumers
        EV["Evaluate"]
        TP["Teleprompters"]
    end

    HF --> GSM
    HF --> HPQ
    HF --> MATH
    ALF --> AW

    HPQ --> DS
    COL --> DS
    DS --> EX
    GSM --> EX
    MATH --> EX
    AW --> EX

    EX --> EV
    EX --> TP
    DL --> EX
```

---

## Common Usage Pattern

All benchmarks expose a consistent interface, allowing them to be used interchangeably:

```python
import dspy

# Static benchmarks
gsm8k = dspy.datasets.GSM8K()
trainset, devset, testset = gsm8k.train, gsm8k.dev, gsm8k.test

# Dataset-derived benchmarks support seed management
hotpot = dspy.datasets.HotPotQA(train_seed=1, train_size=16, dev_size=200)
trainset = hotpot.train

# MATH requires a subset
math = dspy.datasets.MATH(subset="algebra")

# AlfWorld provides interactive sessions
alfworld = dspy.datasets.AlfWorld(max_threads=20)
with alfworld.POOL.session() as sess:
    task_def, info = sess.init(5)
    obs, rew, done, info = sess.step("go north")
```

---

## Dependencies

| Dependency | Used By | Purpose |
|------------|---------|---------|
| [`datasets_core`](datasets_core.md) (`Dataset`, `DataLoader`) | HotPotQA, Colors | Base class for splitting, seeding, and sampling. |
| [`primitives`](primitives.md) (`Example`) | All benchmarks | Uniform example container with input/label separation. |
| `datasets` (HuggingFace) | GSM8K, HotPotQA, MATH | Loading raw benchmark data. |
| `alfworld` | AlfWorld | Interactive text environment. |
| `multiprocess` | AlfWorld | Process pool for parallel environments. |
| `math_equivalence` | MATH | Answer equivalence metric. |
| `tqdm` | GSM8K | Progress bars during parsing. |

---

## Related Modules

- [**datasets_core**](datasets_core.md) — The `Dataset` base class and `DataLoader` utilities that benchmarks build upon.
- [**primitives**](primitives.md) — The `Example` class used to represent every benchmark record.
- [**evaluate**](evaluate.md) — Consumes benchmark splits to score compiled programs.
- [**teleprompt**](teleprompt.md) — Optimizers that use benchmark train/dev splits for few-shot learning and instruction tuning.
