# DSP Module

## Introduction

The **DSP** (Demonstrate-Search-Predict) module is the foundational utility layer of the DSPy framework. It provides the low-level building blocks that the rest of the framework depends on: retrieval wrappers, tokenization utilities, the global thread-safe configuration system (`Settings`), and a collection of general-purpose helper data structures.

Unlike higher-level modules such as [predict](predict.md), [teleprompt](teleprompt.md), or [signatures](signatures.md), the `dsp` module does not implement prompting or optimization logic. Instead, it supplies the shared infrastructure — configuration, retrieval, and text-processing primitives — that those modules consume.

## Purpose and Core Functionality

The module is organized around three concerns:

1. **Retrieval** — Wrappers around ColBERTv2 retrieval servers (remote HTTP and local index-based) used by retrieval-augmented programs.
2. **Configuration** — A singleton, thread-safe `Settings` object that holds global DSPy state (LM, adapter, RM, callbacks, etc.) and supports thread-local overrides via context managers.
3. **Utilities** — Tokenization (DPR-style), and general-purpose helpers such as `dotdict`, batching, grouping, and context managers.

## Architecture Overview

```mermaid
graph TD
    subgraph dsp["dsp module"]
        subgraph retrieval["Retrieval"]
            ColBERTv2["ColBERTv2<br/>(remote HTTP)"]
            ColBERTv2RetrieverLocal["ColBERTv2RetrieverLocal<br/>(local index)"]
            ColBERTv2RerankerLocal["ColBERTv2RerankerLocal<br/>(local reranker)"]
        end
        subgraph config["Configuration"]
            Settings["Settings<br/>(singleton)"]
        end
        subgraph utils["Utilities"]
            dotdict["dotdict / dotdict_lax"]
            NullContextManager["NullContextManager"]
            dpr["Tokenizer / SimpleTokenizer / Tokens"]
        end
    end

    ColBERTv2 -->|uses| request_cache["request_cache<br/>(clients.cache)"]
    ColBERTv2 -->|returns| dotdict
    ColBERTv2RetrieverLocal -->|returns| dotdict
    Settings -->|uses| dotdict
    Settings -->|uses| NullContextManager

    Settings -.->|global config consumed by| predict["predict module"]
    Settings -.->|global config consumed by| clients["clients module"]
    ColBERTv2 -.->|used by| retrievers["retrievers module"]
```

## Sub-modules

The `dsp` module is split into the following sub-modules. Each has its own detailed documentation:

| Sub-module | Description | Documentation |
| --- | --- | --- |
| **Retrieval** | ColBERTv2 remote and local retrieval/reranking wrappers. | [dsp_retrieval.md](dsp_retrieval.md) |
| **Settings** | Thread-safe singleton global configuration with context overrides. | [dsp_settings.md](dsp_settings.md) |
| **Utilities** | `dotdict`, `NullContextManager`, and general helper functions. | [dsp_utils.md](dsp_utils.md) |
| **Tokenization** | DPR-style tokenizer and `Tokens` container. | [dsp_tokenization.md](dsp_tokenization.md) |

## How the Module Fits into the System

```mermaid
graph LR
    dsp["dsp module"]
    dsp -->|Settings consumed by| predict["predict"]
    dsp -->|Settings consumed by| clients["clients"]
    dsp -->|Settings consumed by| primitives["primitives"]
    dsp -->|ColBERTv2 used by| retrievers["retrievers"]
    dsp -->|dotdict used across| all["all modules"]
    dsp -->|Tokenizer used by| datasets["datasets"]
```

- **`Settings`** is the single source of truth for runtime configuration. Modules such as [predict](predict.md), [clients](clients.md), and [primitives](primitives.md) read from `dspy.settings` to obtain the active LM, adapter, and retrieval model.
- **`ColBERTv2`** retrieval wrappers are consumed by the [retrievers](retrievers.md) module (e.g., `Retrieve`) and by retrieval-augmented programs.
- **`dotdict`** is a ubiquitous lightweight attribute-accessible dictionary used throughout the framework (e.g., as the return type of retrieval results and as the base for `DEFAULT_CONFIG`).
- **`request_cache`** (from [clients](clients.md)) is applied to the ColBERTv2 HTTP request functions to avoid redundant network calls.

## Key Design Notes

- **Thread safety**: `Settings` enforces that only the first thread to call `configure` may mutate global state; other threads must use `context(...)` for temporary overrides.
- **Caching**: Remote ColBERTv2 requests are memoized via the `request_cache` decorator, which delegates to the two-level (memory + disk) `Cache` in the [clients](clients.md) module.
- **Optional dependencies**: Local ColBERTv2 retrieval and reranking require the `colbert-ai` package; the code degrades gracefully with an informative message if it is missing.
