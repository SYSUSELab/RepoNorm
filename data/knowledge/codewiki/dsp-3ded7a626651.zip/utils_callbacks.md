# Utils Callbacks

## Introduction

The `utils_callbacks` module provides DSPy's **callback and instrumentation system**. It defines a single, extensible base class — `BaseCallback` — along with the `with_callbacks` decorator that transparently wires callback handlers into the lifecycle of core DSPy components (modules, language models, adapters, tools, and evaluation).

The module's purpose is to let developers observe, log, trace, and instrument the execution of DSPy programs without modifying the components themselves. Callbacks can be registered **globally** (via `dspy.settings.configure`) or **locally** (per component instance), and they fire at well-defined *start* and *end* points around each instrumented operation.

This module is a foundational utility: it is consumed by the [clients](clients.md) (`LM`), [adapters](adapters.md) (`Adapter`), [predict](predict.md) strategies, [evaluate](evaluate.md) (`Evaluate`), and the [primitives](primitives.md) module system.

---

## Core Components

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `BaseCallback` | Class | Defines the full set of lifecycle hook methods that users subclass and override. |
| `with_callbacks` | Decorator | Wraps instance methods so that start/end callbacks are invoked around execution. |
| `_get_on_start_handler` | Helper | Selects the correct `on_*_start` handler based on the instance type and method name. |
| `_get_on_end_handler` | Helper | Selects the correct `on_*_end` handler based on the instance type and method name. |
| `ACTIVE_CALL_ID` | `ContextVar` | Tracks the currently active call id, enabling parent/child call nesting. |

---

## Architecture Overview

The callback system is built around three cooperating layers: **registration**, **dispatch**, and **handler selection**.

```mermaid
graph TD
    subgraph Registration
        G["dspy.settings.configure(callbacks=[...])<br/>(global)"]
        L["Component constructor<br/>callbacks=[...] (local)"]
    end

    subgraph Dispatch["with_callbacks decorator"]
        W["sync_wrapper / async_wrapper"]
        S["_execute_start_callbacks"]
        E["_execute_end_callbacks"]
        A["_get_active_callbacks"]
    end

    subgraph Selection["Handler selection"]
        HS["_get_on_start_handler"]
        HE["_get_on_end_handler"]
    end

    subgraph Handlers["BaseCallback hooks"]
        M["on_module_start / on_module_end"]
        LM["on_lm_start / on_lm_end"]
        AF["on_adapter_format_start / _end"]
        AP["on_adapter_parse_start / _end"]
        T["on_tool_start / on_tool_end"]
        EV["on_evaluate_start / on_evaluate_end"]
    end

    G --> A
    L --> A
    W --> A
    W --> S
    W --> E
    S --> HS
    E --> HE
    HS --> M & LM & AF & AP & T & EV
    HE --> M & LM & AF & AP & T & EV
```

---

## Component Relationships

`BaseCallback` is the extension point; `with_callbacks` is the mechanism that connects it to the runtime. The decorator is applied to methods on the components that participate in the callback lifecycle.

```mermaid
classDiagram
    class BaseCallback {
        +on_module_start(call_id, instance, inputs)
        +on_module_end(call_id, outputs, exception)
        +on_lm_start(call_id, instance, inputs)
        +on_lm_end(call_id, outputs, exception)
        +on_adapter_format_start(call_id, instance, inputs)
        +on_adapter_format_end(call_id, outputs, exception)
        +on_adapter_parse_start(call_id, instance, inputs)
        +on_adapter_parse_end(call_id, outputs, exception)
        +on_tool_start(call_id, instance, inputs)
        +on_tool_end(call_id, outputs, exception)
        +on_evaluate_start(call_id, instance, inputs)
        +on_evaluate_end(call_id, outputs, exception)
    }

    class with_callbacks {
        <<decorator>>
        +sync_wrapper(instance, *args, **kwargs)
        +async_wrapper(instance, *args, **kwargs)
    }

    class LM
    class Adapter
    class Tool
    class Evaluate
    class BaseModule

    with_callbacks ..> BaseCallback : invokes handlers
    LM ..> with_callbacks : decorated methods
    Adapter ..> with_callbacks : format()/parse()
    Tool ..> with_callbacks : __call__()/acall()
    Evaluate ..> with_callbacks : __call__()
    BaseModule ..> with_callbacks : forward()
```

### Where callbacks are wired in

| Component | Instrumented method(s) | Handler family |
|-----------|------------------------|----------------|
| `dspy.Module` (subclass of `BaseModule`) | `forward()` | `on_module_*` |
| `dspy.LM` | `__call__()` / `acall()` | `on_lm_*` |
| `dspy.Adapter` | `format()`, `parse()` | `on_adapter_format_*`, `on_adapter_parse_*` |
| `dspy.Tool` | `__call__()`, `acall()` | `on_tool_*` |
| `dspy.Evaluate` | `__call__()` | `on_evaluate_*` |

> **Note:** `Adapter` applies `with_callbacks` automatically to `format` and `parse` in `__init_subclass__`, so every adapter subclass is instrumented without extra work. See [adapters](adapters.md) for details.

---

## Callback Registration

Callbacks are resolved at call time by `_get_active_callbacks`, which merges two sources:

```mermaid
graph LR
    A["dspy.settings.get('callbacks', [])<br/>(global)"] --> C["Combined callback list"]
    B["getattr(instance, 'callbacks', [])<br/>(instance-level)"] --> C
    C --> D["Executed in order:<br/>global first, then local"]
```

- **Global callbacks** are configured once via `dspy.settings.configure(callbacks=[...])`. See [dsp_settings](dsp_settings.md) for the `Settings` singleton and its thread-local `context()` overrides.
- **Local callbacks** are passed to a component constructor (e.g., `dspy.LM(..., callbacks=[...])`).

If the combined list is empty, the decorator short-circuits and calls the wrapped function directly with **zero overhead**.

---

## Execution Flow

The `with_callbacks` decorator wraps both synchronous and asynchronous methods. The flow is identical in both cases, differing only in `await` usage.

```mermaid
sequenceDiagram
    participant Caller
    participant Wrapper as with_callbacks wrapper
    participant Start as _execute_start_callbacks
    participant Fn as Wrapped function
    participant End as _execute_end_callbacks

    Caller->>Wrapper: call(instance, *args, **kwargs)
    Wrapper->>Wrapper: callbacks = _get_active_callbacks(instance)
    alt no callbacks
        Wrapper->>Fn: fn(instance, *args, **kwargs)
        Fn-->>Wrapper: result
        Wrapper-->>Caller: result
    else callbacks present
        Wrapper->>Wrapper: call_id = uuid4().hex
        Wrapper->>Start: execute start handlers
        Start->>Start: inspect.getcallargs -> inputs (drop self/instance)
        Start-->>Wrapper: done
        Wrapper->>Wrapper: parent = ACTIVE_CALL_ID.get(); ACTIVE_CALL_ID.set(call_id)
        Wrapper->>Fn: fn(instance, *args, **kwargs)
        alt success
            Fn-->>Wrapper: results
        else exception
            Fn-->>Wrapper: raise exception
        end
        Wrapper->>Wrapper: ACTIVE_CALL_ID.set(parent)
        Wrapper->>End: execute end handlers (outputs, exception)
        End-->>Wrapper: done
        Wrapper-->>Caller: results / re-raised exception
    end
```

### Key behaviors

1. **Unique call id** — Each invocation generates a `uuid4().hex` `call_id`, passed to both start and end handlers so they can be correlated.
2. **Input extraction** — `inspect.getcallargs` captures the bound arguments; the `self`/`instance` key is removed so handlers receive only the meaningful inputs.
3. **Nesting via `ACTIVE_CALL_ID`** — Before invoking the wrapped function, the current `call_id` is pushed onto the `ACTIVE_CALL_ID` `ContextVar`, and the previous value is restored in the `finally` block. This lets nested calls (e.g., a module calling an LM) discover their parent call id.
4. **Exception safety** — End handlers always run in a `finally` block. If the wrapped function raises, the exception is captured, passed to end handlers, and then re-raised.
5. **Callback isolation** — Each handler invocation is wrapped in `try/except`; a failing callback logs a warning but never breaks the instrumented operation.

---

## Handler Selection Logic

The helpers `_get_on_start_handler` and `_get_on_end_handler` map an `(instance, fn)` pair to the correct `BaseCallback` method. The selection is based on the instance type, with a special case for adapter methods.

```mermaid
flowchart TD
    Start["_get_on_start_handler(callback, instance, fn)"] --> IsLM{"isinstance(instance, dspy.LM)?"}
    IsLM -->|Yes| LM["callback.on_lm_start"]
    IsLM -->|No| IsEval{"isinstance(instance, dspy.Evaluate)?"}
    IsEval -->|Yes| EV["callback.on_evaluate_start"]
    IsEval -->|No| IsAdapter{"isinstance(instance, dspy.Adapter)?"}
    IsAdapter -->|Yes| Fmt{"fn.__name__?"}
    Fmt -->|format| AF["callback.on_adapter_format_start"]
    Fmt -->|parse| AP["callback.on_adapter_parse_start"]
    Fmt -->|other| Err["raise ValueError"]
    IsAdapter -->|No| IsTool{"isinstance(instance, dspy.Tool)?"}
    IsTool -->|Yes| T["callback.on_tool_start"]
    IsTool -->|No| M["callback.on_module_start<br/>(default)"]
```

The end-handler selection mirrors this exactly, returning the corresponding `on_*_end` method. Any instance that is not an `LM`, `Evaluate`, `Adapter`, or `Tool` is treated as a **module** and routed to `on_module_start` / `on_module_end`.

---

## Usage Examples

### Global callback

```python
import dspy
from dspy.utils.callback import BaseCallback

class LoggingCallback(BaseCallback):
    def on_lm_start(self, call_id, instance, inputs):
        print(f"LM called with inputs: {inputs}")

    def on_lm_end(self, call_id, outputs, exception):
        print(f"LM finished with outputs: {outputs}")

dspy.settings.configure(callbacks=[LoggingCallback()])

cot = dspy.ChainOfThought("question -> answer")
cot(question="What is the meaning of life?")
```

### Local callback

```python
lm_1 = dspy.LM("gpt-3.5-turbo", callbacks=[LoggingCallback()])
lm_1(question="What is the meaning of life?")  # logs

lm_2 = dspy.LM("gpt-3.5-turbo")
lm_2(question="What is the meaning of life?")  # no logging
```

---

## Integration with the Broader System

```mermaid
graph TD
    CB["utils_callbacks<br/>(BaseCallback, with_callbacks)"]

    CB -->|instruments| LM["clients<br/>LM"]
    CB -->|instruments| AD["adapters<br/>Adapter.format/parse"]
    CB -->|instruments| TL["adapters/types<br/>Tool"]
    CB -->|instruments| EV["evaluate<br/>Evaluate"]
    CB -->|instruments| MOD["primitives<br/>Module.forward"]

    SET["dsp_settings<br/>Settings.configure / context"] -->|provides global callbacks| CB
    LM -->|local callbacks| CB
    AD -->|local callbacks| CB
```

- **Global configuration** flows from the [dsp_settings](dsp_settings.md) `Settings` singleton, which stores the `callbacks` list and supports thread-local overrides via `context()`.
- **Local configuration** is stored on each component instance (e.g., `LM.callbacks`, `Adapter.callbacks`).
- The decorator is applied at the component level, so callbacks integrate seamlessly with [predict](predict.md) strategies, [evaluate](evaluate.md) orchestration, and the [primitives](primitives.md) module system.

---

## Design Considerations

- **Zero-overhead when unused** — If no callbacks are registered, the wrapper delegates directly to the original function.
- **Async-aware** — `inspect.iscoroutinefunction` determines whether to emit an `async_wrapper` or `sync_wrapper`, preserving the coroutine nature of the wrapped method.
- **Context propagation** — `ACTIVE_CALL_ID` is a `ContextVar`, so it is safe across threads and async tasks, and correctly nests parent/child calls.
- **Fault tolerance** — Callback exceptions are caught and logged, ensuring instrumentation never disrupts program execution.
- **Extensibility** — New component types can be supported by extending the handler-selection helpers; new event types require adding matching `on_*_start`/`on_*_end` methods to `BaseCallback`.

---

## Related Modules

- [dsp_settings](dsp_settings.md) — Global configuration and thread-local context for callbacks.
- [clients](clients.md) — `LM` and provider classes that accept local callbacks.
- [adapters](adapters.md) — `Adapter` base class that auto-instruments `format`/`parse`.
- [adapter_types](adapter_types.md) — `Tool` and related types instrumented by callbacks.
- [evaluate](evaluate.md) — `Evaluate` class with `on_evaluate_*` hooks.
- [primitives](primitives.md) — `Module`/`BaseModule` whose `forward()` triggers `on_module_*` hooks.
