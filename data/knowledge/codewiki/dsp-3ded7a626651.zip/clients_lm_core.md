# Clients LM Core

## Introduction

The `clients_lm_core` module provides the foundational abstractions for interacting with Large Language Models (LLMs) and embedding models within DSPy. It defines the core language model interface (`BaseLM`), the primary LiteLLM-backed implementation (`LM`), a unified embedding interface (`Embedder`), and a two-tier caching system (`Cache`) that dramatically reduces cost and latency by reusing prior model responses.

This module is the backbone of all model interactions in DSPy. Every `dspy.Predict`, `dspy.ChainOfThought`, or other module ultimately routes its model calls through an `LM` instance. The module is designed to be extensible: users can subclass `BaseLM` to support custom providers, or rely on the built-in `LM` class which supports hundreds of providers via [LiteLLM](https://github.com/BerriAI/litellm).

### Core Components

| Component | File | Responsibility |
|-----------|------|----------------|
| `BaseLM` | `dspy/clients/base_lm.py` | Abstract base class defining the LM interface, history tracking, and response processing |
| `LM` | `dspy/clients/lm.py` | Concrete LiteLLM-backed implementation supporting chat/text completion, streaming, fine-tuning, and reinforcement learning |
| `Embedder` | `dspy/clients/embedding.py` | Unified interface for hosted and custom embedding models |
| `Cache` | `dspy/clients/cache.py` | Two-level (in-memory + on-disk) caching system with a `request_cache` decorator |

---

## Architecture Overview

The module is organized around a layered design where `LM` extends `BaseLM`, and both rely on the `Cache` subsystem. The `LM` class delegates provider-specific behavior (fine-tuning, launching, reinforcement learning) to the provider abstraction documented in [clients_providers.md](clients_providers.md).

```mermaid
graph TD
    subgraph "clients_lm_core"
        BaseLM["BaseLM<br/>(abstract interface)"]
        LM["LM<br/>(LiteLLM implementation)"]
        Embedder["Embedder<br/>(embeddings)"]
        Cache["Cache<br/>(2-level cache)"]
        RequestCache["request_cache<br/>(decorator)"]
    end

    subgraph "External Dependencies"
        LiteLLM["LiteLLM"]
        Settings["dspy.dsp.utils.settings"]
        Callbacks["BaseCallback"]
        UsageTracker["UsageTracker"]
    end

    subgraph "Related Modules"
        Providers["clients_providers<br/>(Provider, OpenAIProvider, ...)"]
        FinetuneUtils["clients_finetune_utils<br/>(TrainDataFormat, TrainingJob)"]
    end

    LM -->|extends| BaseLM
    LM -->|uses| Cache
    LM -->|uses| RequestCache
    LM -->|delegates to| Providers
    LM -->|uses| FinetuneUtils
    Embedder -->|uses| RequestCache
    RequestCache -->|operates on| Cache
    BaseLM -->|uses| Settings
    BaseLM -->|uses| Callbacks
    LM -->|uses| LiteLLM
    LM -->|reports to| UsageTracker
    Embedder -->|uses| LiteLLM
```

---

## Component Details

### BaseLM

`BaseLM` is the abstract base class that defines the contract for all language models in DSPy. It handles cross-cutting concerns so that subclasses only need to implement the actual model call.

**Key responsibilities:**

- **Interface definition**: Subclasses must implement `forward()` (and optionally `aforward()` for async support). The response must conform to the [OpenAI response format](https://platform.openai.com/docs/api-reference/responses/object).
- **Response processing**: `_process_lm_response()` normalizes provider responses into a consistent output format, extracting text, logprobs, and tool calls. It collapses outputs to a plain list of strings when every output contains only text.
- **History tracking**: Maintains a per-instance `history` list and a module-level `GLOBAL_HISTORY` (capped at `MAX_HISTORY_SIZE = 10_000` entries). History entries include the prompt, messages, kwargs, response, usage, cost, timestamp, and a UUID.
- **Callback integration**: The `__call__` and `acall` methods are decorated with `@with_callbacks`, triggering `on_lm_start`/`on_lm_end` handlers (see [BaseCallback](utils.md)).
- **Copying**: `copy()` performs a deep copy with optional parameter overrides, resetting history — essential for creating fine-tuned model variants.

**Constructor parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `model` | — | Model identifier |
| `model_type` | `"chat"` | Either `"chat"` or `"text"` |
| `temperature` | `0.0` | Sampling temperature |
| `max_tokens` | `1000` | Maximum tokens to generate |
| `cache` | `True` | Whether to enable caching |
| `**kwargs` | — | Additional provider-specific arguments |

**Custom LM example:**

```python
from openai import OpenAI
import dspy

class MyLM(dspy.BaseLM):
    def forward(self, prompt, messages=None, **kwargs):
        client = OpenAI()
        return client.chat.completions.create(
            model=self.model,
            messages=messages or [{"role": "user", "content": prompt}],
            **self.kwargs,
        )

lm = MyLM(model="gpt-4o-mini")
dspy.configure(lm=lm)
```

---

### LM

`LM` is the primary, production-ready implementation of `BaseLM`, built on top of LiteLLM. It supports hundreds of providers through a single `"provider/model"` string format (e.g., `"openai/gpt-4o"`).

**Key features:**

1. **Chat and text completion**: Dispatches to `litellm_completion`/`alitellm_completion` for chat models, or `litellm_text_completion`/`alitellm_text_completion` for text models. Text completion converts messages into a single prompt string.

2. **Reasoning model handling**: Detects OpenAI reasoning models (`o1`, `o3`, `o4`, optionally `-mini`) via regex and automatically translates `max_tokens` to `max_completion_tokens`, enforcing `temperature=1.0` and `max_tokens >= 20_000`.

3. **Streaming support**: `_get_stream_completion_fn()` integrates with DSPy's streaming infrastructure by reading `dspy.settings.send_stream` and `dspy.settings.caller_predict`. It tags each chunk with a `predict_id` so the stream listener can attribute chunks to the correct prediction. See [streaming.md](streaming.md).

4. **Caching integration**: `_get_cached_completion_fn()` wraps the completion function with `request_cache`, honoring both the DSPy-level cache and LiteLLM's native cache. API credentials (`api_key`, `api_base`, `base_url`) are excluded from cache keys.

5. **Usage tracking**: When `dspy.settings.usage_tracker` is set and the response is not a cache hit, usage data is recorded via `UsageTracker.add_usage()`.

6. **Truncation warnings**: Logs a warning when any choice has `finish_reason == "length"`, suggesting a larger `max_tokens`.

7. **Provider delegation**: `launch()`, `kill()`, `finetune()`, and `reinforce()` delegate to the configured `Provider` (see [clients_providers.md](clients_providers.md)). Fine-tuning runs in a background thread via `_run_finetune_job()`.

8. **State serialization**: `dump_state()` returns a serializable snapshot of the LM configuration for persistence.

**Constructor parameters (beyond `BaseLM`):**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `max_tokens` | `4000` | Maximum tokens to generate |
| `cache_in_memory` | `True` | Enable additional in-memory LRU caching (deprecated) |
| `callbacks` | `None` | List of `BaseCallback` instances |
| `num_retries` | `3` | Retry count with exponential backoff |
| `provider` | `None` | Explicit provider; inferred from model if omitted |
| `finetuning_model` | `None` | Model to fine-tune (may differ from inference model) |
| `launch_kwargs` | `None` | Arguments for provider launch/kill |
| `train_kwargs` | `None` | Arguments for fine-tuning |

**Provider inference**: `infer_provider()` returns an `OpenAIProvider` if the model matches OpenAI's model list, otherwise a generic `Provider`.

---

### Embedder

`Embedder` provides a unified interface for computing text embeddings, supporting both hosted models (via LiteLLM) and custom callables.

**Key features:**

- **Dual model support**: Accepts either a model string (e.g., `"openai/text-embedding-3-small"`) or a callable that maps a list of strings to embeddings.
- **Batching**: Automatically splits inputs into batches of `batch_size` (default 200) for efficient processing.
- **Caching**: Hosted model responses are cached via the `request_cache` decorator (with API credentials excluded from cache keys).
- **Sync and async**: Provides both `__call__` and `acall` methods.
- **Flexible output**: Returns a 1D numpy array for a single string input, or a 2D array for a list of inputs.

**Usage examples:**

```python
import dspy

# Hosted model
embedder = dspy.Embedder("openai/text-embedding-3-small", batch_size=100)
embeddings = embedder(["hello", "world"])  # shape (2, 1536)

# Custom callable
import numpy as np
def my_embedder(texts):
    return np.random.rand(len(texts), 10)

embedder = dspy.Embedder(my_embedder)
embeddings = embedder(["hello", "world"])  # shape (2, 10)
```

---

### Cache

`Cache` implements a two-level caching strategy to minimize redundant model calls:

1. **In-memory cache** — an `LRUCache` (from `cachetools`) for fast access, bounded by `memory_max_entries`.
2. **On-disk cache** — a `FanoutCache` (from `diskcache`) for persistence across processes, bounded by `disk_size_limit_bytes`.

**Key methods:**

| Method | Description |
|--------|-------------|
| `cache_key(request, ignored_args)` | Generates a SHA-256 hash of the JSON-serialized request, transforming non-JSON-serializable values (Pydantic models, callables) |
| `get(request, ignored_args)` | Retrieves a cached response, promoting disk hits into memory; clears `usage` on cache hits |
| `put(request, value, ignored_args, enable_memory_cache)` | Stores a response in memory and/or disk |
| `reset_memory_cache()` | Clears the in-memory cache |
| `save_memory_cache(filepath)` / `load_memory_cache(filepath)` | Persists/restores the memory cache via cloudpickle |

**Cache key generation** handles several value types specially:
- Pydantic model classes → JSON schema
- Pydantic instances → `model_dump()`
- Callables → source code (or name for lambdas)
- Nested dicts → recursively transformed

**The `request_cache` decorator** wraps functions to apply caching automatically. It incorporates a fully-qualified function identifier into the cache key to avoid collisions between different functions. It supports both sync and async functions, and accepts `enable_memory_cache` at call time to control memory cache writes.

```mermaid
flowchart TD
    A["Function call<br/>(e.g., litellm_completion)"] --> B["request_cache wrapper"]
    B --> C["Build modified request<br/>+ fn_identifier"]
    C --> D{"cache.get()"}
    D -->|Hit| E["Return cached result"]
    D -->|Miss| F["Execute function"]
    F --> G["cache.put()"]
    G --> H["Return result"]
    E --> I["Clear usage on hit"]
```

---

## Data Flow

The following diagram illustrates the end-to-end flow of a model call through the module, from a DSPy module down to the provider and back.

```mermaid
sequenceDiagram
    participant Module as DSPy Module
    participant LM as LM
    participant BaseLM as BaseLM
    participant Cache as Cache
    participant LiteLLM as LiteLLM
    participant Provider as Provider

    Module->>LM: __call__(prompt/messages, **kwargs)
    LM->>BaseLM: __call__ (with_callbacks)
    BaseLM->>LM: forward()
    LM->>LM: _get_cached_completion_fn()
    LM->>Cache: get(request)
    alt Cache Hit
        Cache-->>LM: cached response
    else Cache Miss
        LM->>LiteLLM: completion(request)
        LiteLLM-->>LM: response
        LM->>Cache: put(request, response)
    end
    LM->>Provider: (optional) launch/finetune/reinforce
    LM-->>BaseLM: response
    BaseLM->>BaseLM: _process_lm_response()
    BaseLM->>BaseLM: append to history
    BaseLM-->>Module: outputs
```

---

## Component Interaction

```mermaid
classDiagram
    class BaseLM {
        +model
        +model_type
        +cache
        +kwargs
        +history
        +__call__(prompt, messages, **kwargs)
        +acall(prompt, messages, **kwargs)
        +forward(prompt, messages, **kwargs)*
        +aforward(prompt, messages, **kwargs)*
        +copy(**kwargs)
        +inspect_history(n)
        +update_global_history(entry)
    }

    class LM {
        +provider
        +callbacks
        +num_retries
        +finetuning_model
        +launch_kwargs
        +train_kwargs
        +forward(prompt, messages, **kwargs)
        +aforward(prompt, messages, **kwargs)
        +launch(launch_kwargs)
        +kill(launch_kwargs)
        +finetune(train_data, train_data_format, train_kwargs)
        +reinforce(train_kwargs)
        +infer_provider()
        +dump_state()
    }

    class Embedder {
        +model
        +batch_size
        +caching
        +__call__(inputs, batch_size, caching, **kwargs)
        +acall(inputs, batch_size, caching, **kwargs)
    }

    class Cache {
        +enable_disk_cache
        +enable_memory_cache
        +memory_cache
        +disk_cache
        +cache_key(request, ignored_args)
        +get(request, ignored_args)
        +put(request, value, ignored_args, enable_memory_cache)
        +reset_memory_cache()
        +save_memory_cache(filepath)
        +load_memory_cache(filepath)
    }

    BaseLM <|-- LM
    LM ..> Cache : uses
    Embedder ..> Cache : uses
```

---

## Integration with the Broader System

The `clients_lm_core` module sits at the boundary between DSPy's high-level modules and external LLM providers.

- **DSPy Modules** (`dspy.Predict`, `dspy.ChainOfThought`, etc.) invoke `LM` instances to generate predictions. See [predict.md](predict.md).
- **Settings** (`dspy.dsp.utils.settings`) control global behavior such as `disable_history`, `caller_modules`, `send_stream`, `caller_predict`, and `usage_tracker`. See [dsp.md](dsp.md).
- **Providers** (`clients_providers`) handle provider-specific fine-tuning, launching, and reinforcement learning. See [clients_providers.md](clients_providers.md).
- **Fine-tuning utilities** (`clients_finetune_utils`) define `TrainDataFormat`, `TrainingJob`, and related types used by `LM.finetune()`. See [clients_finetune_utils.md](clients_finetune_utils.md).
- **Callbacks** (`BaseCallback`) enable observability hooks around LM calls. See [utils.md](utils.md).
- **Streaming** infrastructure consumes the streamed chunks produced by `LM`'s streaming completion functions. See [streaming.md](streaming.md).
- **Usage tracking** (`UsageTracker`) aggregates token usage across LM calls. See [utils.md](utils.md).

---

## Summary

The `clients_lm_core` module provides:

1. **`BaseLM`** — a clean, extensible abstract interface for LLMs with built-in history tracking, response normalization, and callback support.
2. **`LM`** — a feature-rich LiteLLM-backed implementation supporting chat/text completion, streaming, caching, usage tracking, fine-tuning, and reinforcement learning.
3. **`Embedder`** — a unified embedding interface for hosted and custom models with batching and caching.
4. **`Cache`** — a robust two-level caching system with a convenient `request_cache` decorator that reduces cost and latency across all model interactions.

Together, these components form the reliable, performant foundation upon which all DSPy model interactions are built.
