# Clients Providers

## Introduction

The **Clients Providers** module defines the abstraction layer that allows DSPy to interact with different model providers for two advanced capabilities beyond standard inference:

1. **Fine-tuning** — training a model on collected trace data (supervised fine-tuning, SFT).
2. **Reinforcement learning** — iteratively improving a model using reward signals (GRPO-style training).

The module provides a common `Provider` interface and a set of concrete provider implementations (OpenAI, Databricks, Local/SGLang, and Arbor). Each provider encapsulates the provider-specific mechanics of uploading data, launching remote training jobs, polling for status, and retrieving the resulting model. The `LM` class (see [clients_lm_core](clients_lm_core.md)) delegates to these providers through its `finetune()` and `reinforce()` methods.

> **Scope note:** This document covers the *provider* layer only. For the core LM abstraction and caching, see [clients_lm_core](clients_lm_core.md). For the data structures and helpers used to serialize training data, see [clients_finetune_utils](clients_finetune_utils.md).

---

## Module Structure

The module is organized around a base abstraction (`provider.py`) and four concrete provider implementations:

| Component | File | Role |
|-----------|------|------|
| `Provider` | `dspy/clients/provider.py` | Abstract base class defining the provider interface |
| `TrainingJob` | `dspy/clients/provider.py` | Base class for supervised fine-tuning jobs (a `Future`) |
| `ReinforceJob` | `dspy/clients/provider.py` | Base class for reinforcement-learning jobs |
| `OpenAIProvider` | `dspy/clients/openai.py` | Fine-tuning via the OpenAI fine-tuning API |
| `TrainingJobOpenAI` | `dspy/clients/openai.py` | OpenAI-specific training job |
| `DatabricksProvider` | `dspy/clients/databricks.py` | Fine-tuning + deployment via Databricks |
| `TrainingJobDatabricks` | `dspy/clients/databricks.py` | Databricks-specific training job |
| `LocalProvider` | `dspy/clients/lm_local.py` | Local inference (SGLang) + local SFT training |
| `ArborProvider` | `dspy/clients/lm_local_arbor.py` | Fine-tuning + GRPO reinforcement learning via Arbor |
| `ArborTrainingJob` | `dspy/clients/lm_local_arbor.py` | Arbor-specific training job |
| `ArborReinforceJob` | `dspy/clients/lm_local_arbor.py` | Arbor-specific GRPO job |
| `GRPOTrainKwargs` | `dspy/clients/lm_local_arbor.py` | TypedDict for GRPO training kwargs |

---

## Architecture

The provider layer sits between the `LM` abstraction and external training/inference backends. The `LM` selects a provider (either explicitly or via auto-discovery) and delegates fine-tuning and reinforcement operations to it.

```mermaid
graph TD
    LM["LM (clients_lm_core)"]
    Provider["Provider (abstract)"]
    TrainingJob["TrainingJob (Future)"]
    ReinforceJob["ReinforceJob (abstract)"]

    OpenAI["OpenAIProvider"]
    Databricks["DatabricksProvider"]
    Local["LocalProvider"]
    Arbor["ArborProvider"]

    TJOpenAI["TrainingJobOpenAI"]
    TJDatabricks["TrainingJobDatabricks"]
    TJArbor["ArborTrainingJob"]
    RJArbor["ArborReinforceJob"]

    Utils["utils_finetune<br/>(TrainDataFormat, TrainingStatus, save_data)"]

    LM -->|"finetune() / reinforce()"| Provider
    LM -->|"launch() / kill()"| Provider

    Provider --> TrainingJob
    Provider --> ReinforceJob

    OpenAI -.->|extends| Provider
    Databricks -.->|extends| Provider
    Local -.->|extends| Provider
    Arbor -.->|extends| Provider

    TJOpenAI -.->|extends| TrainingJob
    TJDatabricks -.->|extends| TrainingJob
    TJArbor -.->|extends| TrainingJob
    RJArbor -.->|extends| ReinforceJob

    OpenAI --> TJOpenAI
    Databricks --> TJDatabricks
    Arbor --> TJArbor
    Arbor --> RJArbor

    Provider --> Utils
    OpenAI --> Utils
    Databricks --> Utils
    Local --> Utils
    Arbor --> Utils
```

### Provider Capability Matrix

Each provider advertises its capabilities through the `finetunable` and `reinforceable` flags set in its constructor:

| Provider | `finetunable` | `reinforceable` | Auto-discovered | Backend |
|----------|:-------------:|:---------------:|:---------------:|---------|
| `Provider` (base) | ❌ | ❌ | — | none |
| `OpenAIProvider` | ✅ | ❌ | ✅ | OpenAI fine-tuning API |
| `DatabricksProvider` | ✅ | ❌ | ❌ | Databricks Foundation Model Training |
| `LocalProvider` | ✅ | ❌ | ❌ | SGLang + TRL (local) |
| `ArborProvider` | ✅ | ✅ | ❌ | Arbor server (HTTP) |

---

## Core Abstractions

### `Provider`

The `Provider` base class defines the interface every provider must implement. It is intentionally minimal and resilient — `launch` and `kill` are no-ops by default because they may be called even when no LM is running.

Key members:

- **`finetunable` / `reinforceable`** — capability flags checked by `LM.finetune()` and `LM.reinforce()` before delegating.
- **`TrainingJob` / `ReinforceJob`** — class attributes pointing to the provider-specific job classes, allowing `LM` to instantiate the correct job type.
- **`is_provider_model(model)`** — static method used for auto-discovery. Returns `False` by default; subclasses override it to claim ownership of model name patterns.
- **`launch(lm, launch_kwargs)` / `kill(lm, launch_kwargs)`** — static lifecycle hooks for spinning up/down inference servers.
- **`finetune(job, model, train_data, train_data_format, train_kwargs)`** — static method that performs the actual fine-tuning and returns the resulting model identifier.

### `TrainingJob`

`TrainingJob` extends `concurrent.futures.Future`, so a fine-tuning job can be awaited via `.result()`. It carries the training context:

- `thread` — the background thread running the job.
- `model` — the model being fine-tuned.
- `train_data` / `train_data_format` / `train_kwargs` — the training inputs.
- `cancel()` — subclasses override to cancel the remote job, then call `super().cancel()`.
- `status()` — abstract; returns a `TrainingStatus`.

### `ReinforceJob`

`ReinforceJob` is the abstract interface for reinforcement-learning jobs (currently only implemented by Arbor). It maintains a `checkpoints` dictionary and a `last_checkpoint` reference, and defines the lifecycle:

- `initialize()` — set up the RL session.
- `step(train_data, train_data_format)` — run one training step.
- `terminate()` — finalize and retrieve the final model.
- `update_model()` — refresh the underlying model reference.
- `save_checkpoint(checkpoint_name)` — persist a checkpoint.
- `cancel()` / `status()` — control and observe the job.

---

## Provider Implementations

### OpenAIProvider

Fine-tunes models through the OpenAI fine-tuning API. It is the only provider with **auto-discovery** enabled: `is_provider_model()` matches against a hard-coded list of base OpenAI models (`_OPENAI_MODELS`) and fine-tuned model names matching the `ft:<base>:` pattern.

The fine-tuning flow (`finetune`) is a linear pipeline:

```mermaid
sequenceDiagram
    participant LM
    participant OP as OpenAIProvider
    participant OAI as OpenAI API
    participant Job as TrainingJobOpenAI

    LM->>OP: finetune(job, model, train_data, ...)
    OP->>OP: validate_data_format()
    OP->>OP: save_data() -> local .jsonl
    OP->>OAI: files.create(purpose="fine-tune")
    OAI-->>OP: provider_file_id
    OP->>Job: job.provider_file_id = ...
    OP->>OAI: fine_tuning.jobs.create(...)
    OAI-->>OP: provider_job_id
    OP->>Job: job.provider_job_id = ...
    OP->>OP: wait_for_job() (poll events + status)
    OP->>OAI: fine_tuning.jobs.retrieve()
    OAI-->>OP: fine_tuned_model
    OP-->>LM: finetuned model name
```

Notable behaviors:
- Supports `TrainDataFormat.CHAT` and `TrainDataFormat.COMPLETION` only.
- `wait_for_job` polls the job's events and reports the estimated finish time.
- `TrainingJobOpenAI.cancel()` cancels the remote job and deletes the uploaded file before calling `super().cancel()`.

### DatabricksProvider

Fine-tunes models on Databricks and optionally deploys them to a Databricks model-serving endpoint. It is **not** auto-discovered (`is_provider_model` always returns `False`).

Key characteristics:
- Requires `train_kwargs["train_data_path"]` (a Unity Catalog path) and `train_kwargs["register_to"]`.
- `upload_data()` validates the Unity Catalog path format (`/Volumes/<catalog>/<schema>/<volume>/...`), creates the directory if needed, and uploads the serialized data.
- After training completes, `deploy_finetuned_model()` creates or updates a serving endpoint and polls until it is ready (unless `skip_deploy=True`).
- Returns a model name of the form `databricks/<endpoint_name>`.
- Requires the optional `databricks_genai` and `databricks-sdk` packages.

### LocalProvider

Handles both **local inference** (via SGLang) and **local supervised fine-tuning** (via HuggingFace `transformers` + `trl`).

- `launch()` starts an SGLang server on a free port, streams its logs into a buffer, and waits for readiness by polling `/v1/models`. It attaches `process`, `thread`, and `get_logs` to the LM.
- `kill()` terminates the SGLang process and cleans up the attached attributes.
- `finetune()` saves the data, builds a default set of training kwargs, and runs `train_sft_locally()`, which:
  - Loads the model and tokenizer, sets up the chat format, and adds a pad token if missing.
  - Tokenizes the dataset with `encode_sft_example` (masking non-assistant tokens with `-100`).
  - Optionally applies LoRA/PEFT and merges the adapter after training.
  - Returns a model name of the form `openai/local:<output_dir>`.
- Only supports `TrainDataFormat.CHAT`.

### ArborProvider

The most feature-complete provider, supporting both fine-tuning and **GRPO reinforcement learning** over an HTTP-based Arbor server. It is **not** auto-discovered.

- `launch()` / `kill()` POST to the Arbor server's `chat/launch` and `chat/kill` endpoints.
- `finetune()` mirrors the OpenAI flow (validate → save → upload → start → wait → retrieve) but routes all OpenAI SDK calls through the Arbor base URL by temporarily swapping `openai.base_url`.
- Supports `CHAT`, `COMPLETION`, and `GRPO_CHAT` data formats.
- `ArborReinforceJob` implements the RL lifecycle by POSTing to `fine_tuning/grpo/{initialize,step,checkpoint,terminate}` endpoints. Each `step` runs one GRPO step per group and updates `lm.model` in place.
- Requires `dspy.settings.arbor_api_base` to be configured.

---

## Data Flow

The following diagram shows how training data flows from a teleprompter through the provider layer to a backend, and how the resulting model is returned.

```mermaid
flowchart LR
    subgraph Teleprompters
        BF["BootstrapFinetune"]
        GRPO["GRPO"]
    end

    subgraph LM
        LMF["LM.finetune()"]
        LMR["LM.reinforce()"]
    end

    subgraph Providers
        P["Provider.finetune()"]
        RJ["ReinforceJob.step()"]
    end

    subgraph Utils
        SD["save_data()"]
        TDF["TrainDataFormat"]
        TS["TrainingStatus"]
    end

    subgraph Backend
        Remote["Remote / Local Training Backend"]
    end

    BF -->|"train_data, format, kwargs"| LMF
    GRPO -->|"GRPOGroup batches"| LMR

    LMF -->|"TrainingJob"| P
    LMR -->|"ReinforceJob"| RJ

    P --> SD
    P --> TDF
    P -->|"upload + start job"| Remote
    Remote -->|"status"| TS
    Remote -->|"finetuned model"| P

    RJ -->|"step / checkpoint / terminate"| Remote
    Remote -->|"current_model"| RJ
```

### Fine-tuning vs. Reinforcement Learning

| Aspect | Fine-tuning (`finetune`) | Reinforcement Learning (`reinforce`) |
|--------|--------------------------|--------------------------------------|
| Entry point | `LM.finetune()` | `LM.reinforce()` |
| Job type | `TrainingJob` (a `Future`) | `ReinforceJob` |
| Data | `List[Dict]` in `CHAT`/`COMPLETION` format | `List[GRPOGroup]` in `GRPO_CHAT` format |
| Result | A new `LM` (via `job.set_result(lm)`) | In-place update of `lm.model` |
| Providers | OpenAI, Databricks, Local, Arbor | Arbor only |
| Teleprompter | `BootstrapFinetune` | `GRPO` |

---

## Component Interaction

The `LM` class is the primary consumer of this module. It selects a provider and delegates operations:

```mermaid
classDiagram
    class LM {
        +model
        +provider
        +finetune(train_data, train_data_format, train_kwargs) TrainingJob
        +reinforce(train_kwargs) ReinforceJob
        +launch(launch_kwargs)
        +kill(launch_kwargs)
        +infer_provider() Provider
    }

    class Provider {
        +finetunable
        +reinforceable
        +TrainingJob
        +ReinforceJob
        +is_provider_model(model) bool
        +launch(lm, launch_kwargs)
        +kill(lm, launch_kwargs)
        +finetune(job, model, train_data, ...) str
    }

    class TrainingJob {
        +thread
        +model
        +train_data
        +train_data_format
        +train_kwargs
        +cancel()
        +status() TrainingStatus
    }

    class ReinforceJob {
        +lm
        +train_kwargs
        +checkpoints
        +last_checkpoint
        +initialize()
        +step(train_data, train_data_format)
        +terminate()
        +update_model()
        +save_checkpoint(name)
    }

    LM --> Provider : uses
    Provider --> TrainingJob : creates
    Provider --> ReinforceJob : creates
```

### Provider Selection

`LM.infer_provider()` performs auto-discovery by iterating over known providers and calling `is_provider_model()`. Currently only `OpenAIProvider` participates in auto-discovery; all other providers must be passed explicitly via the `provider` argument to `LM(...)`.

---

## Process Flows

### Fine-tuning Job Lifecycle

```mermaid
stateDiagram-v2
    [*] --> Created: LM.finetune() creates TrainingJob
    Created --> Running: thread.start() -> provider.finetune()
    Running --> Uploading: save_data() + upload
    Uploading --> Training: start remote job
    Training --> Polling: wait_for_job()
    Polling --> Training: not terminal
    Polling --> Succeeded: status == succeeded
    Polling --> Failed: status == failed
    Polling --> Cancelled: cancel() called
    Succeeded --> [*]: job.set_result(new LM)
    Failed --> [*]: job.set_result(err)
    Cancelled --> [*]
```

### GRPO Reinforcement Learning Lifecycle (Arbor)

```mermaid
stateDiagram-v2
    [*] --> Initialized: job.initialize()
    Initialized --> Stepping: job.step(train_data)
    Stepping --> Stepping: more steps
    Stepping --> Checkpointed: job.save_checkpoint(name)
    Checkpointed --> Stepping: continue
    Stepping --> Terminated: job.terminate()
    Terminated --> [*]: lm.model updated in place
```

---

## Dependencies

### Internal Dependencies

- **[clients_lm_core](clients_lm_core.md)** — `LM` and `BaseLM` are the primary consumers; `LM` delegates to providers via `finetune()`, `reinforce()`, `launch()`, and `kill()`.
- **[clients_finetune_utils](clients_finetune_utils.md)** — provides `TrainDataFormat`, `TrainingStatus`, `save_data()`, `get_finetune_directory()`, `GRPOChatData`, and related message types used throughout the provider implementations.
- **[teleprompt](teleprompt.md)** — `BootstrapFinetune` and `GRPO` teleprompters drive the fine-tuning and RL workflows respectively.

### External Dependencies

| Provider | Required Packages |
|----------|-------------------|
| `OpenAIProvider` | `openai` |
| `DatabricksProvider` | `databricks_genai`, `databricks-sdk`, `requests`, `ujson` |
| `LocalProvider` | `sglang` (inference), `torch`, `transformers`, `trl`, `peft` (training) |
| `ArborProvider` | `openai`, `requests` |

---

## Summary

The Clients Providers module provides a clean, extensible abstraction for model training and reinforcement learning in DSPy. By defining a common `Provider` interface with `TrainingJob` and `ReinforceJob` base classes, it allows new backends to be added without changing the `LM` abstraction or the teleprompters that drive training. The four concrete providers cover the spectrum from fully-managed cloud APIs (OpenAI, Databricks) to local execution (SGLang/TRL) and specialized RL servers (Arbor).
