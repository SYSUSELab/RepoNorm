# Utils Module

## Introduction

The **utils** module (`dspy/utils`) is the cross-cutting support layer of the DSPy framework. It provides the shared, framework-wide infrastructure that every other module relies on but that does not itself implement prompting, optimization, or retrieval logic. Its responsibilities span:

- **Observability** — a callback system for instrumenting module, LM, adapter, tool, and evaluation execution.
- **Testing** — deterministic dummy LM and vectorizer implementations for unit tests.
- **Concurrency** — thread-pool based parallel execution and dynamic request batching.
- **Cost accounting** — token/usage tracking across LM calls.
- **Diagnostics** — a controllable logging stream and a structured adapter-parse exception.

These utilities are deliberately decoupled from the higher-level modules. They are consumed by [predict](predict.md), [evaluate](evaluate.md), [teleprompt](teleprompt.md), [clients](clients.md), [adapters](adapters.md), and [primitives](primitives.md), and they in turn depend on the low-level [dsp](dsp.md) configuration layer (notably `Settings` and `dotdict`).

## Architecture Overview

The module is organized into five cohesive sub-modules, each addressing a distinct concern:

```mermaid
graph TD
    subgraph utils["utils module (dspy/utils)"]
        subgraph callbacks["Callbacks"]
            BaseCallback["BaseCallback<br/>(callback.py)"]
            with_callbacks["with_callbacks<br/>(decorator)"]
        end
        subgraph dummies["Testing Dummies"]
            DummyLM["DummyLM"]
            DummyVectorizer["DummyVectorizer"]
        end
        subgraph parallel["Concurrency"]
            ParallelExecutor["ParallelExecutor"]
            Unbatchify["Unbatchify"]
        end
        subgraph usage["Usage Tracking"]
            UsageTracker["UsageTracker"]
            track_usage["track_usage()"]
        end
        subgraph diag["Logging & Exceptions"]
            DSPyLoggingStream["DSPyLoggingStream"]
            AdapterParseError["AdapterParseError"]
        end
    end

    BaseCallback --> with_callbacks
    DummyLM -->|subclass of| LM["clients.LM"]
    DummyLM -->|uses| ChatAdapter["adapters.ChatAdapter"]
    ParallelExecutor -->|reads| Settings["dsp.Settings"]
    Unbatchify -->|batches calls to| LM
    UsageTracker -->|stored in| Settings
    track_usage -->|context override| Settings
    AdapterParseError -->|references| Signature["signatures.Signature"]
```

## Sub-modules

The `utils` module is split into the following sub-modules. Each has its own detailed documentation:

| Sub-module | Description | Documentation |
| --- | --- | --- |
| **Callbacks** | `BaseCallback` handler interface and the `with_callbacks` decorator that wires callbacks into module/LM/adapter/tool/evaluate execution. | [utils_callbacks.md](utils_callbacks.md) |
| **Testing Dummies** | `DummyLM` (deterministic LM for tests) and `DummyVectorizer` (n-gram hashing vectorizer). | [utils_dummies.md](utils_dummies.md) |
| **Concurrency** | `ParallelExecutor` (thread-pool execution with straggler timeouts) and `Unbatchify` (dynamic request batching). | [utils_parallel.md](utils_parallel.md) |
| **Usage Tracking** | `UsageTracker` and the `track_usage()` context manager for aggregating LM token usage. | [utils_usage_tracking.md](utils_usage_tracking.md) |
| **Logging & Exceptions** | `DSPyLoggingStream` (controllable event-log stream) and `AdapterParseError` (structured parse failure). | [utils_logging_exceptions.md](utils_logging_exceptions.md) |

## How the Module Fits into the System

The `utils` module sits between the low-level [dsp](dsp.md) configuration layer and the higher-level functional modules. It is a *consumer* of `Settings` and a *provider* of shared services to nearly every other module.

```mermaid
graph LR
    dsp["dsp<br/>(Settings, dotdict)"]
    utils["utils module"]

    dsp -->|config source| utils

    utils -->|callbacks instrument| predict["predict"]
    utils -->|callbacks instrument| evaluate["evaluate"]
    utils -->|ParallelExecutor drives| evaluate
    utils -->|ParallelExecutor drives| teleprompt["teleprompt"]
    utils -->|DummyLM used by| tests["unit tests"]
    utils -->|UsageTracker aggregates| clients["clients"]
    utils -->|AdapterParseError raised by| adapters["adapters"]
    utils -->|DSPyLoggingStream used by| all["all modules"]
```

### Key integration points

- **Callbacks** are invoked by the `with_callbacks` decorator applied to `LM.__call__`, `Adapter.format`/`parse`, `Tool.__call__`, `Evaluate.__call__`, and module `forward` methods. This makes the callback system the primary observability hook across the framework. See [utils_callbacks.md](utils_callbacks.md).
- **`ParallelExecutor`** is the execution engine behind parallel evaluation and optimization. It reads `num_threads`, `max_errors`, and `provide_traceback` from [`Settings`](dsp_settings.md) and isolates thread-local configuration overrides per task. See [utils_parallel.md](utils_parallel.md).
- **`UsageTracker`** is stored inside [`Settings`](dsp_settings.md) via the `track_usage()` context manager, and is deep-copied per thread by `ParallelExecutor` so each worker tracks its own usage. See [utils_usage_tracking.md](utils_usage_tracking.md).
- **`DummyLM`** subclasses [`LM`](clients_lm_core.md) and reuses [`ChatAdapter`](adapters_core.md) formatting, making it a faithful stand-in for real LMs in tests. See [utils_dummies.md](utils_dummies.md).
- **`AdapterParseError`** is raised by adapters when an LM response cannot be parsed, and references a [`Signature`](signatures_core.md) to report expected output fields. See [utils_logging_exceptions.md](utils_logging_exceptions.md).

## Cross-cutting Design Notes

- **Thread-local isolation**: Both `ParallelExecutor` and `UsageTracker` cooperate with the thread-local override mechanism in [`Settings`](dsp_settings.md) to ensure that concurrent tasks do not leak configuration or usage state into one another.
- **Graceful degradation**: The callback decorator swallows and logs exceptions raised inside user callbacks so that instrumentation never breaks the underlying execution path.
- **Determinism for tests**: `DummyLM` and `DummyVectorizer` are seeded/deterministic, enabling reproducible unit tests without network access.
- **No heavy dependencies**: The module avoids importing optional heavy packages at module load time, keeping the base framework lightweight.

## Related Modules

- [dsp](dsp.md) — Provides `Settings` and `dotdict`, the configuration primitives that `utils` builds upon.
- [dsp_settings](dsp_settings.md) — The `Settings` singleton that stores callbacks, usage trackers, and thread-local overrides.
- [clients](clients.md) — LM clients that `DummyLM` subclasses and that `UsageTracker` aggregates.
- [adapters](adapters.md) — Adapters instrumented by callbacks and the source of `AdapterParseError`.
- [evaluate](evaluate.md) — Evaluation orchestration that uses `ParallelExecutor` and callbacks.
- [teleprompt](teleprompt.md) — Optimizers that rely on parallel execution and usage tracking.
- [signatures](signatures.md) — `Signature` referenced by `AdapterParseError`.

## Summary

The `utils` module is the shared services layer of DSPy. It provides:

- **Callbacks** for framework-wide observability.
- **Dummies** for deterministic testing.
- **Concurrency** primitives for parallel and batched execution.
- **Usage tracking** for cost accounting.
- **Logging and exceptions** for diagnostics.

Because these utilities are consumed across the entire framework, they form a stable, low-level contract that higher-level modules depend on without needing to reimplement common infrastructure.
