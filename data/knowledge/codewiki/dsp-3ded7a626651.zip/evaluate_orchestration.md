# Evaluate Orchestration

## Introduction

The **Evaluate Orchestration** module provides the core evaluation engine for DSPy programs. Its central component, the `Evaluate` class, orchestrates the process of running a DSPy program over a dataset, applying a metric function to each prediction, and aggregating the results into a single performance score.

The module is responsible for:

- **Parallel execution** of a program over an evaluation dataset.
- **Metric application** to each `(example, prediction)` pair.
- **Error handling** with configurable failure thresholds and fallback scores.
- **Result aggregation** into an overall percentage score.
- **Result presentation** via progress bars and optional tabular output.
- **Flexible return formats** (scores only, per-example scores, or full result triples).

This module is the orchestration layer of the broader `evaluate` package. For the LLM-based automatic metrics that can be plugged in as the `metric` argument, see [evaluate_auto_metrics](evaluate_auto_metrics.md).

---

## Architecture Overview

The `Evaluate` class sits between the user's DSPy program and the underlying execution infrastructure. It delegates parallelization to `ParallelExecutor`, uses `Settings` for global configuration, and produces results built on `Example`/`Prediction` primitives.

```mermaid
graph TD
    User["User / Optimizer"] -->|"Evaluate(devset, metric)"| Eval["Evaluate"]
    Eval -->|"__call__(program)"| Exec["ParallelExecutor"]
    Exec -->|"process_item(example)"| Program["dspy.Module (program)"]
    Program -->|"prediction"| Metric["metric(example, prediction)"]
    Metric -->|"score"| Exec
    Exec -->|"results list"| Eval
    Eval -->|"aggregate"| Score["Overall Score (%)"]
    Eval -->|"optional"| Table["Result Table (pandas)"]

    Eval -.->|"reads config"| Settings["Settings"]
    Eval -.->|"callbacks"| Callbacks["with_callbacks"]
    Program -.->|"produces"| Prediction["Prediction"]
    Eval -.->|"consumes"| Example["Example"]
```

---

## Core Component: `Evaluate`

The `Evaluate` class is the sole core component of this module. It is designed to be instantiated once with a dataset and metric, then called with a program to evaluate.

### Construction

```python
Evaluate(
    *,
    devset: List[dspy.Example],
    metric: Optional[Callable] = None,
    num_threads: Optional[int] = None,
    display_progress: bool = False,
    display_table: Union[bool, int] = False,
    max_errors: Optional[int] = None,
    return_all_scores: bool = False,
    return_outputs: bool = False,
    provide_traceback: Optional[bool] = None,
    failure_score: float = 0.0,
    **kwargs,
)
```

| Parameter | Purpose |
|-----------|---------|
| `devset` | The evaluation dataset (list of `dspy.Example`). |
| `metric` | Callable `(example, prediction) -> score` used to score each prediction. |
| `num_threads` | Number of threads for parallel evaluation. Falls back to `Settings.num_threads`. |
| `display_progress` | Whether to render a `tqdm` progress bar. |
| `display_table` | Whether to render a results table; an integer truncates the displayed rows. |
| `max_errors` | Maximum errors before aborting. Falls back to `Settings.max_errors`. |
| `return_all_scores` | Return per-example scores alongside the overall score. |
| `return_outputs` | Return `(example, prediction, score)` triples. |
| `provide_traceback` | Include tracebacks in error logs. |
| `failure_score` | Score assigned to examples that raise exceptions. |

All constructor arguments are stored as instance attributes and can be **overridden per-call** in `__call__`.

### Invocation

The `__call__` method is decorated with `@with_callbacks`, enabling start/end callback hooks (see [Callbacks & Instrumentation](#callbacks--instrumentation)).

```python
evaluate = Evaluate(devset=devset, metric=metric)
score = evaluate(program)
```

Each argument passed to `__call__` overrides the corresponding constructor value when not `None`:

```python
metric = metric if metric is not None else self.metric
devset = devset if devset is not None else self.devset
# ... and so on for num_threads, display_progress, display_table,
#     return_all_scores, return_outputs
```

---

## Evaluation Process Flow

The following diagram captures the end-to-end evaluation lifecycle, from setup through parallel execution to result aggregation and presentation.

```mermaid
flowchart TD
    Start([evaluate(program)]) --> Resolve["Resolve effective config<br/>(per-call overrides > constructor)"]
    Resolve --> Clear["Clear tqdm instances"]
    Clear --> BuildExec["Build ParallelExecutor<br/>(num_threads, max_errors,<br/>provide_traceback, compare_results=True)"]
    BuildExec --> ExecLoop["executor.execute(process_item, devset)"]

    subgraph PerExample["process_item(example) — per example"]
        P1["prediction = program(**example.inputs())"]
        P2["score = metric(example, prediction)"]
        P3["Accumulate _assert_failures /<br/>_suggest_failures on program"]
        P1 --> P2 --> P3
    end

    ExecLoop --> PerExample
    PerExample --> Collect["Collect results list"]
    Collect --> Fill["Replace None with<br/>(Prediction(), failure_score)"]
    Fill --> Zip["Zip devset with results →<br/>(example, prediction, score) triples"]
    Zip --> Aggregate["ncorrect = sum(scores)<br/>ntotal = len(devset)"]
    Aggregate --> Log["Log average metric"]
    Log --> TableCheck{"display_table?"}
    TableCheck -->|Yes| Render["_construct_result_table →<br/>_display_result_table"]
    TableCheck -->|No| Return
    Render --> Return["Return based on flags"]
```

### Step-by-step

1. **Configuration resolution** — Per-call arguments override constructor defaults.
2. **Executor construction** — A `ParallelExecutor` is created with `compare_results=True`, which makes the progress bar report the running average metric. `max_errors` falls back to `dspy.settings.max_errors` when unset.
3. **Per-example processing** — `process_item` runs the program on `example.inputs()`, applies the metric, and increments the program's `_assert_failures` / `_suggest_failures` counters from `dspy.settings`.
4. **Result collection** — Failed items (returned as `None` by the executor) are replaced with a default `Prediction()` and the configured `failure_score`.
5. **Aggregation** — The overall score is `round(100 * ncorrect / ntotal, 2)`.
6. **Presentation** — If `display_table` is set, a pandas DataFrame is built and displayed.
7. **Return** — The return shape depends on the flags (see below).

---

## Return Value Formats

The return value varies based on `return_all_scores` and `return_outputs`:

```mermaid
graph TD
    R["Evaluate.__call__ returns"] --> A{"return_all_scores?"}
    A -->|No| B{"return_outputs?"}
    A -->|Yes| C{"return_outputs?"}
    B -->|No| B1["float: overall score"]
    B -->|Yes| B2["(score, result_triples)"]
    C -->|No| C1["(score, individual_scores)"]
    C -->|Yes| C2["(score, result_triples, individual_scores)"]
```

| `return_all_scores` | `return_outputs` | Return value |
|:---:|:---:|--------------|
| `False` | `False` | `float` — overall percentage score |
| `False` | `True` | `(float, List[(example, prediction, score)])` |
| `True` | `False` | `(float, List[float])` |
| `True` | `True` | `(float, List[(example, prediction, score)], List[float])` |

---

## Result Table Construction & Display

When `display_table` is enabled, the module builds a pandas DataFrame from the result triples and renders it.

### `_construct_result_table`

- Merges each `example` and `prediction` into a single row.
- Uses `merge_dicts` to disambiguate overlapping keys: keys present in both are prefixed with `example_` and `pred_`.
- If the prediction is dict-like (has a callable `items()`), it is merged; otherwise it is stored under a `prediction` column.
- Adds a `correct` column holding the score, then renames it to the metric's name.
- Truncates every cell to 25 words via `truncate_cell`.

### `_display_result_table`

- If `display_table` is a `bool`, the full table is shown; if an `int`, only the first N rows are shown and a "... N more rows not displayed ..." message is rendered.
- Applies `stylize_metric_name` to render scores with a ✔️ prefix.
- Delegates to `display_dataframe`, which detects IPython notebook environments and configures pandas display options accordingly.

### Helper Functions

| Function | Responsibility |
|----------|----------------|
| `prediction_is_dictlike` | Checks whether a prediction exposes a callable `items()`. |
| `merge_dicts` | Merges example/prediction dicts with `example_`/`pred_` prefixes for collisions. |
| `truncate_cell` | Truncates cell content to 25 words. |
| `stylize_metric_name` | Formats the metric column with ✔️ markers. |
| `display_dataframe` | Renders the DataFrame (notebook-aware). |
| `configure_dataframe_for_ipython_notebook_display` | Sets pandas display options for notebooks. |
| `is_in_ipython_notebook_environment` | Detects an IPython kernel environment. |

---

## Dependencies

The module relies on several other DSPy subsystems. The diagram below shows the dependency relationships.

```mermaid
graph LR
    Eval["Evaluate"] --> PE["ParallelExecutor<br/>(utils/parallelizer)"]
    Eval --> WC["with_callbacks<br/>(utils/callback)"]
    Eval --> Settings["Settings<br/>(dsp/utils/settings)"]
    Eval --> Example["Example<br/>(primitives/example)"]
    Eval --> Prediction["Prediction<br/>(primitives/prediction)"]
    Eval --> Module["Module<br/>(primitives/program)"]
    Eval --> TQDM["tqdm"]
    Eval --> Pandas["pandas (optional)"]
    Eval --> IPython["IPython (optional)"]
```

| Dependency | Role | Reference |
|------------|------|-----------|
| `ParallelExecutor` | Thread-pool execution with error isolation, straggler timeouts, and progress reporting. | [utils](utils.md) |
| `with_callbacks` | Decorator injecting start/end callback hooks into `__call__`. | [utils](utils.md) |
| `Settings` | Global/thread-local configuration (`max_errors`, `num_threads`, `provide_traceback`, `callbacks`). | [dsp](dsp.md) |
| `Example` | Input/label container; `example.inputs()` supplies program inputs. | [primitives](primitives.md) |
| `Prediction` | Program output container; default used for failed examples. | [primitives](primitives.md) |
| `Module` | The DSPy program being evaluated. | [primitives](primitives.md) |
| `tqdm` | Progress bar rendering. | external |
| `pandas` | Optional; required only for `display_table`. | external |
| `IPython` | Optional; enables rich notebook display. | external |

---

## Component Interaction

The sequence diagram below shows how the components interact during a single evaluation call.

```mermaid
sequenceDiagram
    participant U as User
    participant E as Evaluate
    participant S as Settings
    participant PE as ParallelExecutor
    participant P as Program (Module)
    participant M as Metric

    U->>E: __call__(program, ...)
    E->>E: resolve effective config
    E->>S: read max_errors / num_threads
    E->>PE: new ParallelExecutor(...)
    E->>PE: execute(process_item, devset)
    loop for each example (parallel)
        PE->>P: program(**example.inputs())
        P-->>PE: prediction
        PE->>M: metric(example, prediction)
        M-->>PE: score
    end
    PE-->>E: results list
    E->>E: fill failures, zip, aggregate
    E-->>U: score (and optional scores/outputs)
```

---

## Callbacks & Instrumentation

The `__call__` method is wrapped with `@with_callbacks`, which:

- Collects active callbacks from both `dspy.settings["callbacks"]` and the instance's own `callbacks` attribute.
- Fires **start** callbacks with the resolved inputs before execution.
- Fires **end** callbacks with outputs and any exception after execution.
- Assigns a unique `call_id` and manages the active call-ID context.

The `callback_metadata` argument passed to `__call__` is logged at debug level and is available to callback handlers. For details on the callback system, see [utils](utils.md).

---

## Error Handling

Error handling is delegated to `ParallelExecutor`:

- Each example is wrapped in a `safe_func` that catches exceptions.
- On exception, the error count is incremented under a lock; once `max_errors` is reached, all jobs are cancelled.
- Failed items return `None`, which `Evaluate` replaces with `(Prediction(), failure_score)`.
- If `provide_traceback` is enabled, full tracebacks are logged; otherwise a concise message is logged.
- If execution is cancelled (errors or SIGINT), the executor raises an exception.

This design ensures a single failing example does not abort the entire evaluation unless the error budget is exhausted.

---

## Usage Example

```python
import dspy
from dspy.evaluate import Evaluate

# Define a metric
def exact_match(example, pred, trace=None):
    return example.answer.lower() == pred.answer.lower()

# Create the evaluator
evaluate = Evaluate(
    devset=my_devset,
    metric=exact_match,
    num_threads=8,
    display_progress=True,
    display_table=5,
)

# Run evaluation
score = evaluate(my_program)
print(f"Accuracy: {score}%")

# Get detailed results
score, results, scores = evaluate(
    my_program,
    return_outputs=True,
    return_all_scores=True,
)
```

---

## Related Modules

- [evaluate_auto_metrics](evaluate_auto_metrics.md) — LLM-based automatic metrics (`SemanticF1`, `CompleteAndGrounded`, etc.) that can be supplied as the `metric` argument.
- [utils](utils.md) — `ParallelExecutor` and the callback system used for execution and instrumentation.
- [primitives](primitives.md) — `Example`, `Prediction`, and `Module` primitives consumed and produced during evaluation.
- [dsp](dsp.md) — `Settings` for global configuration.
