# Streaming Listener Module

## Introduction

The `streaming_listener` module provides the core mechanism for **token-level streaming** of individual output fields from DSPy predictors. Its central component, `StreamListener`, taps into the raw token stream produced by a language model and extracts the content belonging to a specific signature output field, emitting it incrementally as `StreamResponse` objects.

This module is the low-level engine that powers DSPy's streaming experience. It is responsible for:

- Detecting the **start** of a target output field within a stream of tokens.
- Buffering and emitting tokens that belong to that field.
- Detecting the **end** of the field (i.e., the start of the next field or the end of the response).
- Handling adapter-specific formatting (ChatAdapter vs. JSONAdapter).
- Automatically resolving which predictor a listener should attach to.

For the higher-level streaming orchestration (status messages, callbacks, and the `streamify` API), see the [streaming_messages](streaming_messages.md) module.

---

## Architecture Overview

The `StreamListener` sits between the language model's raw token stream and the consumer of streamed field values. It relies on the active adapter (via `settings.adapter`) to know how fields are delimited in the model output.

```mermaid
graph TD
    LM["Language Model<br/>(ModelResponseStream chunks)"]
    SL["StreamListener"]
    SR["StreamResponse"]
    Settings["settings.adapter"]
    ChatAdapter["ChatAdapter"]
    JSONAdapter["JSONAdapter"]
    Consumer["Stream Consumer<br/>(streamify / user code)"]

    LM -->|"receive(chunk)"| SL
    Settings -->|"determines delimiters"| SL
    ChatAdapter -.->|"[[ ## field ## ]]"| SL
    JSONAdapter -.->|'"field":'| SL
    SL -->|"yields"| SR
    SR --> Consumer
```

### Key Responsibilities

| Responsibility | Description |
| --- | --- |
| Field start detection | Identifies the delimiter that marks the beginning of the target field. |
| Token buffering | Buffers tokens to avoid emitting partial delimiters. |
| Field end detection | Detects the delimiter of the next field (or end of response) to stop streaming. |
| Adapter awareness | Switches delimiter patterns based on the active adapter. |
| Predictor resolution | Maps listeners to predictors automatically via `find_predictor_for_stream_listeners`. |

---

## Core Component: `StreamListener`

The `StreamListener` class is the heart of the module. It is instantiated per output field that the user wants to stream.

### Constructor

```python
StreamListener(
    signature_field_name: str,
    predict: Any = None,
    predict_name: Optional[str] = None,
)
```

| Parameter | Description |
| --- | --- |
| `signature_field_name` | The name of the output field to listen to (e.g., `"answer"`). |
| `predict` | The predictor instance to listen to. If `None`, it is resolved automatically by `find_predictor_for_stream_listeners`. |
| `predict_name` | The name of the predictor. If `None`, resolved automatically. |

### Internal State

The listener maintains several pieces of state to track its position within the stream:

| Attribute | Purpose |
| --- | --- |
| `field_start_queue` | Buffers tokens while searching for the field's start identifier. |
| `field_end_queue` | A bounded `Queue` (max ~10 tokens) buffering tokens near the field's end. |
| `stream_start` | Boolean flag indicating the target field's stream has begun. |
| `stream_end` | Boolean flag indicating the target field's stream has ended. |
| `cache_hit` | Boolean flag indicating the entire response arrived in a single chunk (cache hit or single-chunk model). |
| `json_adapter_start_identifier` | `"field_name":` — start delimiter for JSONAdapter. |
| `json_adapter_end_identifier` | Regex `\w*\"(,|\s*})` — end delimiter for JSONAdapter. |
| `chat_adapter_start_identifier` | `[[ ## field_name ## ]]` — start delimiter for ChatAdapter. |
| `chat_adapter_end_identifier` | Regex `\[\[ ## (\w+) ## \]\]` — end delimiter for ChatAdapter. |

---

## Adapter-Specific Delimiters

The listener's behavior is driven by the active adapter, accessed through `settings.adapter`. Two adapters are supported for streaming:

```mermaid
graph LR
    subgraph ChatAdapter
        C1["Start: [[ ## field ## ]]"]
        C2["End: [[ ## next_field ## ]]"]
    end
    subgraph JSONAdapter
        J1['Start: "field":']
        J2['End: ", or "}']
    end
```

| Adapter | Start Identifier | End Identifier | Start Indicator |
| --- | --- | --- | --- |
| `ChatAdapter` (or `None`) | `[[ ## {field} ## ]]` | `\[\[ ## (\w+) ## \]\]` | `[` |
| `JSONAdapter` | `"{field}":` | `\w*\"(,|\s*})` | `{` |

> **Note:** Any other adapter raises a `ValueError`. Only `ChatAdapter` and `JSONAdapter` are supported for streaming. See [adapters_core](adapters_core.md) for details on these adapters.

---

## Streaming Process Flow

The `receive` method is called once per streamed chunk. It implements a state machine that transitions through the phases of field extraction.

```mermaid
flowchart TD
    Start([receive chunk]) --> Ended{stream_end?}
    Ended -->|Yes| Return1([return None])
    Ended -->|No| Extract[Extract chunk_message from delta.content]
    Extract --> Null{message is None?}
    Null -->|Yes| Return2([return None])
    Null -->|No| CacheCheck{start_identifier in message<br/>AND end_identifier after it?}

    CacheCheck -->|Yes| CacheHit[Set cache_hit, stream_start, stream_end]
    CacheHit --> Return3([return None])

    CacheCheck -->|No| StartSearch{field_start_queue empty<br/>AND not stream_start<br/>AND start_indicator present?}
    StartSearch -->|Yes| QueueStart[Append to field_start_queue]
    QueueStart --> Return4([return None])

    StartSearch -->|No| Buffering{field_start_queue non-empty<br/>AND not stream_start?}
    Buffering -->|Yes| Concat[Append & concat buffered tokens]
    Concat --> Match{start_identifier in concat?}
    Match -->|Yes| BeginStream[Set stream_start, clear queue,<br/>extract value after identifier]
    Match -->|Partial| Return5([return None - keep buffering])
    Match -->|No| Reset[Reset field_start_queue]
    Reset --> Return6([return None])

    Buffering -->|No| Streaming{stream_start?}
    BeginStream --> Streaming
    Streaming -->|Yes| EndQueue[Put token in field_end_queue]
    EndQueue --> SizeCheck{qsize > 10?}
    SizeCheck -->|Yes| PopToken[Pop oldest token as output]
    SizeCheck -->|No| NoToken[token = None]
    PopToken --> EndCheck
    NoToken --> EndCheck{end_identifier in concat?}
    EndCheck -->|Yes| Flush[Set stream_end, flush buffer,<br/>rstrip trailing newlines]
    EndCheck -->|No| Emit
    Flush --> Emit{token present?}
    Emit -->|Yes| Yield[return StreamResponse]
    Emit -->|No| Return7([return None])
```

### Phase Descriptions

1. **Guard Phase** — If `stream_end` is already set, or the chunk has no content, the method returns immediately.

2. **Cache-Hit Detection** — If the start identifier and an end identifier appear in the *same* chunk, the entire response arrived at once (cache hit or single-chunk model like Gemini). The listener marks `cache_hit`, `stream_start`, and `stream_end` all at once.

3. **Start Search** — The listener waits for the `start_indicator` (`[` or `{`) to appear, then begins buffering tokens into `field_start_queue`.

4. **Start Identifier Matching** — Buffered tokens are concatenated and checked against the full `start_identifier`. If matched, streaming begins and the value portion after the identifier is extracted. For `JSONAdapter`, a leading `"` is stripped.

5. **Streaming & End Detection** — Once streaming, tokens are placed into `field_end_queue`. The queue is bounded to ~10 tokens so that the listener can look ahead for the end identifier without emitting it. When the end identifier is found, the stream ends and the buffer is flushed.

---

## The `flush` Method

When the stream ends, the `field_end_queue` still holds the last few tokens (which may include the end identifier). The `flush` method extracts only the valid content, discarding the delimiter.

```mermaid
flowchart TD
    Flush([flush]) --> Adapter{settings.adapter?}
    Adapter -->|JSONAdapter| JMatch[Search for '\",' or '\" }']
    JMatch --> JBound[Return content before boundary]
    Adapter -->|ChatAdapter / None| CFind[Find '[[']
    CFind --> CBound[Return content before '[[']
    Adapter -->|Other| Err[Raise ValueError]
```

| Adapter | Boundary Detection | Returned Content |
| --- | --- | --- |
| `JSONAdapter` | Regex `",` or `" }` | Everything before the boundary. |
| `ChatAdapter` / `None` | First occurrence of `[[` | Everything before `[[`. |

---

## Predictor Resolution: `find_predictor_for_stream_listeners`

When a `StreamListener` is created without an explicit `predict` or `predict_name`, this utility function automatically determines which predictor in a program the listener should attach to.

```mermaid
flowchart TD
    Start([find_predictor_for_stream_listeners]) --> Collect[Collect listeners without predict]
    Collect --> Iterate[Iterate program.named_predictors]
    Iterate --> MatchField{field in output_fields<br/>AND in target set?}
    MatchField -->|Already assigned| DupErr[Raise: field not unique]
    MatchField -->|Not str type| TypeErr[Raise: field must be str]
    MatchField -->|OK| Assign[Assign name + predictor]
    Assign --> BuildMap[Build predict_id -> listeners map]
    BuildMap --> Missing{field not found in any predictor?}
    Missing -->|Yes| MissErr[Raise: field not in program]
    Missing -->|No| Done([return map])
```

### Validation Rules

The function enforces several constraints:

1. **Uniqueness** — If a `signature_field_name` appears in more than one predictor, an error is raised because the target is ambiguous.
2. **String-only fields** — Stream listeners can only be applied to output fields annotated as `str`. Non-string fields raise a `ValueError`.
3. **Existence** — If a field name does not exist in any predictor's output fields, an error is raised.

The function returns a `defaultdict(list)` mapping `id(predictor)` to the list of listeners targeting that predictor.

---

## Component Interaction

The following diagram shows how `StreamListener` interacts with the broader DSPy ecosystem.

```mermaid
graph TD
    subgraph "streaming module"
        SL["StreamListener"]
        FPSL["find_predictor_for_stream_listeners"]
        SR["StreamResponse"]
    end

    subgraph "adapters"
        CA["ChatAdapter"]
        JA["JSONAdapter"]
    end

    subgraph "dsp core"
        Settings["settings"]
    end

    subgraph "primitives"
        Module["Module / named_predictors"]
    end

    subgraph "external"
        LiteLLM["litellm.ModelResponseStream"]
    end

    FPSL -->|"reads"| Module
    FPSL -->|"assigns predict to"| SL
    SL -->|"reads settings.adapter"| Settings
    Settings -->|"is instance of"| CA
    Settings -->|"is instance of"| JA
    SL -->|"consumes"| LiteLLM
    SL -->|"produces"| SR
```

---

## Data Flow

```mermaid
sequenceDiagram
    participant LM as Language Model
    participant SL as StreamListener
    participant Adapter as settings.adapter
    participant Out as StreamResponse

    LM->>SL: receive(chunk)
    SL->>Adapter: check adapter type
    Adapter-->>SL: delimiters
    SL->>SL: detect start identifier
    SL->>SL: buffer tokens (field_start_queue)
    SL->>SL: begin stream
    loop For each subsequent chunk
        LM->>SL: receive(chunk)
        SL->>SL: buffer in field_end_queue
        SL->>SL: check for end identifier
        SL->>Out: yield StreamResponse(predict_name, field, token)
    end
    SL->>SL: detect end identifier
    SL->>SL: flush() remaining tokens
    SL->>Out: yield final StreamResponse
```

---

## Usage Example

```python
from dspy.streaming.streaming_listener import StreamListener

# Listen to the "answer" field of a predictor
listener = StreamListener(signature_field_name="answer")

# The listener is fed chunks from the LM stream
for chunk in lm_stream:
    response = listener.receive(chunk)
    if response is not None:
        print(response.chunk, end="")
```

When the predictor is not specified, `find_predictor_for_stream_listeners` resolves it automatically:

```python
from dspy.streaming.streaming_listener import find_predictor_for_stream_listeners

listeners = [StreamListener(signature_field_name="answer")]
predict_id_to_listeners = find_predictor_for_stream_listeners(program, listeners)
```

---

## Related Modules

- [streaming_messages](streaming_messages.md) — Defines `StreamResponse`, `StatusMessage`, and `StatusStreamingCallback` used alongside the listener.
- [adapters_core](adapters_core.md) — `ChatAdapter` and `JSONAdapter`, whose output formats define the streaming delimiters.
- [dsp_settings](dsp_settings.md) — The `settings` object that holds the active adapter.
- [primitives_module_system](primitives_module_system.md) — `Module` and `named_predictors`, used for automatic predictor resolution.
