# Teleprompt Avatar Optimizer

## Introduction

The `teleprompt_avatar` module provides **`AvatarOptimizer`**, a DSPy teleprompter that automatically optimizes the *instruction* of an [`Avatar`](predict_strategies.md) program. The `Avatar` program is a tool-using agent that iteratively selects and invokes tools to accomplish a goal. The optimizer improves the agent's behavior by analyzing which inputs succeed and which fail, generating natural-language feedback, and rewriting the agent's instruction accordingly.

Unlike optimizers that tune few-shot demonstrations or model weights, `AvatarOptimizer` performs **instruction-level optimization** driven by a comparator/feedback loop. It is conceptually similar to other instruction optimizers such as [`COPRO`](teleprompt_instruction.md) and [`MIPROv2`](teleprompt_instruction.md), but is specialized for tool-using agents.

---

## Module Overview

The module consists of a single file, `dspy/teleprompt/avatar_optimizer.py`, containing four core components:

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `AvatarOptimizer` | Teleprompter | Orchestrates the optimization loop over an `Avatar` program. |
| `Comparator` | `dspy.Signature` | Analyzes positive vs. negative inputs and produces feedback. |
| `FeedbackBasedInstruction` | `dspy.Signature` | Rewrites the agent instruction using the generated feedback. |
| `EvalResult` | Pydantic `BaseModel` | Data container holding an example, its score, and the actions taken. |

---

## Architecture

The optimizer sits on top of the [`Avatar`](predict_strategies.md) program and the [`Teleprompter`](teleprompt_core.md) base class. It uses two internal DSPy signatures (`Comparator` and `FeedbackBasedInstruction`) to drive instruction refinement.

```mermaid
graph TD
    subgraph "teleprompt_avatar"
        AO[AvatarOptimizer]
        CMP[Comparator<br/>dspy.Signature]
        FBI[FeedbackBasedInstruction<br/>dspy.Signature]
        ER[EvalResult<br/>BaseModel]
    end

    subgraph "External Dependencies"
        TP[Teleprompter<br/>teleprompt_core]
        AV[Avatar<br/>predict_strategies]
        AO_OUT[ActionOutput<br/>predict_strategies]
        TPred[dspy.TypedPredictor]
        Pred[dspy.Predict]
    end

    AO -->|inherits| TP
    AO -->|optimizes| AV
    AO -->|uses| CMP
    AO -->|uses| FBI
    AO -->|produces| ER
    CMP -->|wrapped by| TPred
    FBI -->|wrapped by| Pred
    ER -->|contains| AO_OUT
```

### Component Relationships

- **`AvatarOptimizer`** inherits from [`Teleprompter`](teleprompt_core.md) and implements the `compile` method.
- **`Comparator`** is wrapped in a `dspy.TypedPredictor`, which enforces the structured `EvalResult` types on its inputs.
- **`FeedbackBasedInstruction`** is wrapped in a plain `dspy.Predict`.
- **`EvalResult`** is used as the typed input to `Comparator` and carries `ActionOutput` objects from the [`Avatar`](predict_strategies.md) program.

---

## Core Components

### `AvatarOptimizer`

The main teleprompter class. It is constructed with a metric function and several bounds that define what counts as a "positive" or "negative" example.

```python
AvatarOptimizer(
    metric: Callable,
    max_iters: int = 10,
    lower_bound: int = 0,
    upper_bound: int = 1,
    max_positive_inputs: Optional[int] = None,
    max_negative_inputs: Optional[int] = None,
    optimize_for: str = "max",
)
```

| Parameter | Description |
|-----------|-------------|
| `metric` | Required. A callable `metric(example, prediction) -> float` used to score each example. |
| `max_iters` | Number of optimization iterations to run. |
| `lower_bound` | Scores `<= lower_bound` are classified as **negative** examples. |
| `upper_bound` | Scores `>= upper_bound` are classified as **positive** examples. |
| `max_positive_inputs` | Cap on positive examples sampled per iteration (defaults to `DEFAULT_MAX_EXAMPLES = 10`). |
| `max_negative_inputs` | Cap on negative examples sampled per iteration (defaults to `DEFAULT_MAX_EXAMPLES = 10`). |
| `optimize_for` | Either `"max"` or `"min"`, indicating the direction of optimization. |

#### Key Methods

- **`process_example(actor, example, return_outputs)`** — Deep-copies the actor, runs it on a single example, and computes the metric score. Exceptions are caught and scored as `0`.
- **`thread_safe_evaluator(devset, actor, return_outputs, num_threads)`** — Evaluates the actor across the devset using a `ThreadPoolExecutor`, returning the average metric (and optionally per-example results).
- **`_get_pos_neg_results(actor, trainset)`** — Runs the evaluator and partitions results into positive and negative `EvalResult` lists based on the bounds. Raises `ValueError` if either list is empty.
- **`compile(student, *, trainset)`** — The main optimization loop (see below).

### `Comparator` (Signature)

A DSPy signature that instructs the LM to:
1. Identify patterns distinguishing good inputs from bad ones.
2. Review the computational logic for inconsistencies.
3. Specify tool-usage modifications to improve negative inputs.

**Inputs:** `instruction`, `actions`, `pos_input_with_metrics`, `neg_input_with_metrics`
**Output:** `feedback`

### `FeedbackBasedInstruction` (Signature)

A DSPy signature that takes the previous instruction and the feedback, and produces a new, refined instruction (no more than 3 paragraphs) that retains the general guidelines of the previous instruction.

**Inputs:** `previous_instruction`, `feedback`
**Output:** `new_instruction`

### `EvalResult` (BaseModel)

A Pydantic model used as a structured data container:

```python
class EvalResult(BaseModel):
    example: dict
    score: float
    actions: Optional[List[ActionOutput]] = None
```

---

## Optimization Process Flow

The `compile` method implements an iterative feedback loop. Each iteration evaluates the current best actor, samples positive/negative examples, generates feedback, and produces a new instruction.

```mermaid
flowchart TD
    Start([compile student, trainset]) --> Init[best_actor = deepcopy student<br/>best_score = -999 or 999]
    Init --> Loop{For i in max_iters}

    Loop --> Eval[_get_pos_neg_results<br/>thread_safe_evaluator]
    Eval --> Partition[Partition into<br/>pos_inputs / neg_inputs]
    Partition --> Check{pos and neg<br/>non-empty?}
    Check -->|No| Error[Raise ValueError]
    Check -->|Yes| Sample[Sample up to<br/>max_positive/negative_inputs]

    Sample --> Compare[Comparator<br/>generate feedback]
    Compare --> Rewrite[FeedbackBasedInstruction<br/>generate new_instruction]

    Rewrite --> Improve{Score improved<br/>vs best_score?}
    Improve -->|Yes| Update[Update actor signature<br/>with new_instruction<br/>best_score = score]
    Improve -->|No| Skip[Keep current best]
    Update --> Loop
    Skip --> Loop

    Loop -->|Done| Return([Return best_actor])
```

### Step-by-Step Description

1. **Initialization** — `best_actor` is a deep copy of the student; `best_score` is initialized to `-999` (for `"max"`) or `999` (for `"min"`).
2. **Evaluation** — `_get_pos_neg_results` evaluates the current `best_actor` on the trainset and partitions results using `upper_bound`/`lower_bound`.
3. **Sampling** — If there are more positive/negative examples than the configured caps, a random `sample` is taken.
4. **Feedback Generation** — The `Comparator` receives the current instruction, the tool list, and the sampled positive/negative examples, and returns `feedback`.
5. **Instruction Rewriting** — `FeedbackBasedInstruction` combines the previous instruction with the feedback to produce `new_instruction`.
6. **Improvement Check** — If the new score improves on `best_score` (respecting `optimize_for`), the actor's signature is updated via `with_instructions(new_instruction)` and `best_score` is updated.
7. **Return** — After `max_iters` iterations, the optimized `best_actor` is returned.

---

## Data Flow

The following diagram shows how data flows between the optimizer, the `Avatar` program, and the internal signatures.

```mermaid
sequenceDiagram
    participant AO as AvatarOptimizer
    participant AV as Avatar (actor)
    participant M as metric
    participant CMP as Comparator
    participant FBI as FeedbackBasedInstruction

    AO->>AV: actor(**example.inputs())
    AV-->>AO: prediction (with .actions)
    AO->>M: metric(example, prediction)
    M-->>AO: score

    Note over AO: Partition into pos/neg EvalResults

    AO->>CMP: instruction, actions, pos_inputs, neg_inputs
    CMP-->>AO: feedback

    AO->>FBI: previous_instruction, feedback
    FBI-->>AO: new_instruction

    Note over AO: If improved, update actor signature
```

---

## Dependencies

```mermaid
graph LR
    subgraph "teleprompt_avatar"
        AO[AvatarOptimizer]
    end

    AO -->|imports| TP[Teleprompter<br/>teleprompt_core.md]
    AO -->|imports| AV[ActionOutput<br/>predict_strategies.md]
    AO -->|uses| DSPY[dspy core<br/>TypedPredictor, Predict, Signature]
    AO -->|optimizes| AVATAR[Avatar program<br/>predict_strategies.md]
```

| Dependency | Module Documentation | Purpose |
|------------|----------------------|---------|
| `Teleprompter` | [teleprompt_core.md](teleprompt_core.md) | Base class providing the `compile` interface. |
| `ActionOutput` | [predict_strategies.md](predict_strategies.md) | Carries tool execution results from the `Avatar` program. |
| `Avatar` | [predict_strategies.md](predict_strategies.md) | The program being optimized. |
| `dspy.TypedPredictor` / `dspy.Predict` | [predict_core.md](predict_core.md) | Wrap the internal signatures for structured/plain prediction. |
| `dspy.Signature` | [signatures_core.md](signatures_core.md) | Defines the `Comparator` and `FeedbackBasedInstruction` interfaces. |

---

## Relationship to Other Teleprompters

`AvatarOptimizer` belongs to the `teleprompt` family. It is an **instruction optimizer** specialized for tool-using agents, distinguishing it from:

- **[teleprompt_core.md](teleprompt_core.md)** — Base `Teleprompter`, `LabeledFewShot`, `Ensemble`.
- **[teleprompt_bootstrap.md](teleprompt_bootstrap.md)** — Demonstration-based bootstrapping (`BootstrapFewShot`, etc.).
- **[teleprompt_instruction.md](teleprompt_instruction.md)** — General instruction optimizers (`COPRO`, `MIPROv2`, `SignatureOptimizer`).
- **[teleprompt_finetune.md](teleprompt_finetune.md)** — Weight-level optimization (`BootstrapFinetune`, `GRPO`).
- **[teleprompt_simba.md](teleprompt_simba.md)** — `SIMBA` stochastic optimization.

---

## Usage Example

```python
import dspy
from dspy.teleprompt.avatar_optimizer import AvatarOptimizer
from dspy.predict.avatar import Avatar

# Define a metric that scores the agent's output
def metric(example, prediction):
    return float(prediction.answer == example.answer)

# Build the Avatar program with tools
avatar = Avatar(signature=MyTaskSignature, tools=[my_tool])

# Configure the optimizer
optimizer = AvatarOptimizer(
    metric=metric,
    max_iters=5,
    lower_bound=0.0,
    upper_bound=1.0,
    optimize_for="max",
)

# Optimize the agent's instruction
optimized_avatar = optimizer.compile(avatar, trainset=trainset)
```

---

## Notes and Constraints

- **Non-empty partitions required:** `_get_pos_neg_results` raises `ValueError` if no positive or no negative examples are found. Adjust `lower_bound`/`upper_bound` or provide more training data.
- **Metric is mandatory:** The constructor asserts that `metric` is not `None`.
- **Thread safety:** Evaluation uses a `ThreadPoolExecutor` with `dspy.settings.num_threads` workers; each example is processed on a deep copy of the actor.
- **Instruction length:** `FeedbackBasedInstruction` is instructed to keep the new instruction to no more than 3 paragraphs while retaining prior general guidelines.
