# Python Interpreter Module

## Introduction

The `primitives_python_interpreter` module provides a secure, sandboxed Python execution environment for DSPy. It enables DSPy programs to generate and execute arbitrary Python code safely by running it inside a WebAssembly-based sandbox powered by [Deno](https://deno.land/) and [Pyodide](https://pyodide.org/).

This module is the execution backbone for code-generating DSPy strategies such as [`ProgramOfThought`](predict_strategies.md) and [`CodeAct`](predict_strategies.md), which rely on running model-generated Python to compute answers or interact with tools.

The module exposes two core components:

| Component | Purpose |
|-----------|---------|
| `PythonInterpreter` | Manages a persistent Deno/Pyodide subprocess, injects variables, executes code, and synchronizes files. |
| `InterpreterError` | A `RuntimeError` subclass raised for sandbox-related failures (missing Deno, invalid variables, execution errors, etc.). |

---

## Architecture Overview

The interpreter is a thin Python client that communicates with a long-lived Deno subprocess over stdin/stdout using newline-delimited JSON messages. The Deno process hosts a Pyodide (CPython compiled to WebAssembly) runtime that actually executes the user's code.

```mermaid
graph TB
    subgraph "Host (Python)"
        PI[PythonInterpreter]
        Caller["Caller<br/>(ProgramOfThought / CodeAct)"]
    end

    subgraph "Deno Runtime (Subprocess)"
        Runner[runner.js]
        Pyodide[Pyodide / CPython WASM]
        FS[Pyodide Virtual FS<br/>/sandbox/...]
    end

    subgraph "Host Filesystem"
        HostFiles[Read/Write Paths]
    end

    Caller -->|execute code| PI
    PI -->|JSON over stdin| Runner
    Runner -->|JSON over stdout| PI
    Runner --> Pyodide
    Pyodide --> FS
    Runner -->|mount / sync| HostFiles
```

### Key Design Principles

1. **Process Isolation**: Code runs in a separate Deno process, not in the host Python interpreter.
2. **Capability-Based Permissions**: Read, write, environment, and network access are explicitly granted via Deno permission flags.
3. **Persistent Session**: The Deno process is reused across multiple `execute()` calls, preserving state (imports, variables) between executions.
4. **JSON Protocol**: All communication uses newline-delimited JSON, making the protocol simple and debuggable.

---

## Component Details

### `PythonInterpreter`

The main class responsible for managing the sandbox lifecycle and executing code.

#### Constructor

```python
PythonInterpreter(
    deno_command: Optional[List[str]] = None,
    enable_read_paths: Optional[List[Union[PathLike, str]]] = None,
    enable_write_paths: Optional[List[Union[PathLike, str]]] = None,
    enable_env_vars: Optional[List[str]] = None,
    enable_network_access: Optional[List[str]] = None,
    sync_files: bool = True,
)
```

| Parameter | Description |
|-----------|-------------|
| `deno_command` | Custom command list to launch Deno. If omitted, a default command is constructed with the appropriate permission flags. |
| `enable_read_paths` | Files/directories the sandbox may read. Mounted into the virtual FS at `/sandbox/<basename>`. |
| `enable_write_paths` | Files/directories the sandbox may write. Mounted and synced back to the host after execution. |
| `enable_env_vars` | Environment variable names to expose inside the sandbox. |
| `enable_network_access` | Domains/IPs the sandbox may access over the network. |
| `sync_files` | If `True`, changes made to write paths inside the sandbox are synced back to the host filesystem. |

When `deno_command` is not provided, the constructor builds a command of the form:

```
deno run --allow-read [--allow-env=...] [--allow-net=...] [--allow-write=...] <runner.js> [env_arg]
```

> **Note**: `--allow-run` is intentionally not supported yet. Proxying `subprocess.run` through `Deno.run()` is a planned future enhancement to work around the "emscripten does not support processes" limitation.

#### Public Methods

| Method | Description |
|--------|-------------|
| `execute(code, variables=None)` | Injects variables, ensures the Deno process is running, mounts files, sends the code, and returns the result. |
| `__call__(code, variables=None)` | Alias for `execute`, allowing `interp(code)` syntax. |
| `shutdown()` | Gracefully terminates the Deno subprocess by sending a `{"shutdown": true}` message. |
| `__enter__` / `__exit__` | Context manager support; `__exit__` calls `shutdown()`. |

#### Private Methods

| Method | Description |
|--------|-------------|
| `_get_runner_path()` | Resolves the absolute path to `runner.js` located alongside the module. |
| `_mount_files()` | Sends `mount_file` messages to copy host files into the Pyodide virtual FS. Creates empty files for write paths that don't exist. |
| `_sync_files()` | Sends `sync_file` messages to copy modified virtual files back to the host. |
| `_ensure_deno_process()` | Lazily starts the Deno subprocess if not running; raises `InterpreterError` with install instructions if Deno is missing. |
| `_inject_variables(code, variables)` | Prepends Python assignments for each provided variable to the code. |
| `_serialize_value(value)` | Safely serializes supported value types (`str`, `int`, `float`, `bool`, `None`, `list`, `dict`) into Python literals. |

### `InterpreterError`

A subclass of `RuntimeError` raised for sandbox-related failures, including:

- Deno executable not found (includes installation instructions).
- Invalid variable names passed to `_inject_variables`.
- Unsupported value types passed to `_serialize_value`.
- Non-syntax execution errors returned by the sandbox.
- No output received from the Deno subprocess.

---

## Execution Flow

The following sequence diagram illustrates a typical `execute()` call, including variable injection, file mounting, and result handling.

```mermaid
sequenceDiagram
    participant Caller
    participant PI as PythonInterpreter
    participant Deno as Deno (runner.js)
    participant Py as Pyodide

    Caller->>PI: execute(code, variables)
    PI->>PI: _inject_variables(code, variables)
    PI->>PI: _ensure_deno_process()
    PI->>PI: _mount_files()
    PI->>Deno: {"code": "..."} (stdin)
    Deno->>Py: loadPackagesFromImports(code)
    Deno->>Py: override stdout/stderr
    Deno->>Py: runPythonAsync(code)
    Py-->>Deno: result / exception
    Deno-->>PI: {"output": ...} or {"error": ...} (stdout)
    PI->>PI: parse JSON result
    alt errorType == "FinalAnswer"
        PI->>PI: use errorArgs as output
    else errorType == "SyntaxError"
        PI->>Caller: raise SyntaxError
    else other error
        PI->>Caller: raise InterpreterError
    end
    PI->>PI: _sync_files()
    PI-->>Caller: output
```

### Result Handling Rules

The sandbox returns a JSON object on stdout. The interpreter interprets it as follows:

1. **`FinalAnswer` error type**: The `final_answer()` function (preloaded in the sandbox) raises a `FinalAnswer` exception to simulate a non-local exit. The interpreter treats `errorArgs` as the output value. This is the mechanism used by [`ProgramOfThought`](predict_strategies.md) to return computed answers.
2. **`SyntaxError` error type**: Re-raised as a Python `SyntaxError`.
3. **Other error types**: Re-raised as `InterpreterError`.
4. **No error**: Returns the `output` field.

Inside the sandbox, the output rule is:
- If the final statement evaluates to `None`, the captured `stdout` is returned.
- Otherwise, the final expression's value is returned.

---

## The Sandbox Runner (`runner.js`)

The `runner.js` file is the Deno-side counterpart. It is adapted from [Simon Willison's Pyodide sandbox TIL](https://til.simonwillison.net/deno/pyodide-sandbox).

### Responsibilities

```mermaid
flowchart TD
    Start[Read line from stdin] --> Parse{Parse JSON}
    Parse -->|Invalid| ErrJSON[Return ValueError]
    Parse -->|mount_file| Mount[Read host file, write to Pyodide FS]
    Parse -->|sync_file| Sync[Read Pyodide FS, write to host]
    Parse -->|shutdown| Exit[Break loop]
    Parse -->|code| Exec[Execute code]
    Exec --> LoadPkg[loadPackagesFromImports]
    LoadPkg --> Capture[Override stdout/stderr]
    Capture --> Run[runPythonAsync]
    Run --> Result{Result None?}
    Result -->|Yes| OutStdout[Return captured stdout]
    Result -->|No| OutValue[Return result value]
    Run -->|Exception| ErrHandler[Return error + errorType + errorArgs]
```

### Message Protocol

All messages are newline-delimited JSON objects. The runner recognizes four message types:

| Message | Direction | Purpose |
|---------|-----------|---------|
| `{"code": "..."}` | Host → Sandbox | Execute Python code. |
| `{"mount_file": "...", "virtual_path": "..."}` | Host → Sandbox | Copy a host file into the virtual FS. |
| `{"sync_file": "...", "host_file": "..."}` | Host → Sandbox | Copy a virtual FS file back to the host. |
| `{"shutdown": true}` | Host → Sandbox | Terminate the runner loop. |

Responses are single JSON lines:

| Response | Meaning |
|----------|---------|
| `{"output": ...}` | Successful execution. |
| `{"error": "...", "errorType": "...", "errorArgs": [...]}` | Execution failure. |

### Environment Variable Propagation

Environment variables are passed as the first CLI argument (comma-separated names). The runner reads each from `Deno.env` and injects it into `os.environ` inside Pyodide.

---

## File Mounting and Synchronization

The interpreter supports bidirectional file access between the host and the sandbox.

```mermaid
flowchart LR
    subgraph Host
        HP[Host Path]
    end
    subgraph Sandbox
        VP["/sandbox/basename"]
    end
    HP -->|mount_file| VP
    VP -->|sync_file| HP
```

- **Mounting** (`_mount_files`): For each read/write path, the host file is read and written into the Pyodide virtual FS at `/sandbox/<basename>`. Intermediate directories are created automatically. If a write path does not exist on the host, an empty file is created.
- **Syncing** (`_sync_files`): After successful execution, files in write paths are copied from the virtual FS back to the host, but only if `sync_files=True`.

> **Important**: Mounting happens once per interpreter instance (guarded by `_mounted_files`). If you need to re-mount after host-side changes, create a new interpreter instance.

---

## Integration with DSPy

The `PythonInterpreter` is consumed by code-generating DSPy strategies. The diagram below shows how it fits into the broader prediction layer.

```mermaid
graph LR
    subgraph "predict module"
        POT[ProgramOfThought]
        CA[CodeAct]
    end
    subgraph "primitives module"
        PI[PythonInterpreter]
        IE[InterpreterError]
    end
    POT -->|execute / shutdown| PI
    CA -->|execute / shutdown| PI
    PI -.raises.-> IE
```

- **[`ProgramOfThought`](predict_strategies.md)** generates Python code, executes it via the interpreter, and retries on errors up to `max_iters`. It uses the `final_answer()` mechanism to extract results.
- **[`CodeAct`](predict_strategies.md)** combines reasoning with tool use, defining tool functions inside the interpreter and iteratively executing generated code.

Both strategies call `interpreter.shutdown()` when finished to release the Deno subprocess.

---

## Usage Examples

### Basic Execution

```python
from dspy.primitives.python_interpreter import PythonInterpreter

code_string = "print('Hello'); 1 + 2"
with PythonInterpreter() as interp:
    output = interp(code_string)
    # If the final statement is non-None, prints the numeric result;
    # otherwise prints captured output.
```

### Passing Variables

```python
with PythonInterpreter() as interp:
    result = interp("x + y", variables={"x": 3, "y": 4})
    # result == 7
```

### Granting File and Network Access

```python
interp = PythonInterpreter(
    enable_read_paths=["/data/input.csv"],
    enable_write_paths=["/data/output.csv"],
    enable_env_vars=["API_KEY"],
    enable_network_access=["api.example.com"],
    sync_files=True,
)
output = interp("import os; print(os.environ['API_KEY'])")
interp.shutdown()
```

---

## Error Handling

```mermaid
flowchart TD
    Exec[execute] --> CheckDeno{Deno running?}
    CheckDeno -->|No| StartDeno[Start subprocess]
    StartDeno -->|FileNotFoundError| RaiseInstall[raise InterpreterError<br/>with install instructions]
    CheckDeno -->|Yes| Send[Send code]
    Send --> ReadOut[Read stdout]
    ReadOut -->|Empty| RaiseNoOut[raise InterpreterError<br/>No output from Deno]
    ReadOut -->|JSON| ParseResult{Has error?}
    ParseResult -->|FinalAnswer| ReturnArgs[Return errorArgs]
    ParseResult -->|SyntaxError| RaiseSyntax[raise SyntaxError]
    ParseResult -->|Other| RaiseInterp[raise InterpreterError]
    ParseResult -->|No| ReturnOut[Return output]
```

### Common Errors

| Error | Cause | Resolution |
|-------|-------|------------|
| `InterpreterError` (install instructions) | Deno not installed or not on `PATH`. | Install Deno via `curl -fsSL https://deno.land/install.sh \| sh` or `brew install deno`. |
| `InterpreterError: Invalid variable name` | A variable key is not a valid Python identifier. | Use valid identifier names. |
| `InterpreterError: Unsupported value type` | A variable value is not a supported serializable type. | Convert to `str`, `int`, `float`, `bool`, `None`, `list`, or `dict`. |
| `InterpreterError: No output from Deno subprocess` | The subprocess died or produced no output. | Check stderr (included in the error message). |
| `SyntaxError` | Generated code has invalid Python syntax. | Fix the generated code. |

---

## Prerequisites

- **Deno** must be installed and available on the system `PATH`. See the [Deno installation guide](https://docs.deno.com/runtime/getting_started/installation/).
- The `runner.js` file must be present alongside `python_interpreter.py` (it ships with the package).

---

## Related Modules

- [predict_strategies.md](predict_strategies.md) — `ProgramOfThought` and `CodeAct`, the primary consumers of this interpreter.
- [primitives_module_system.md](primitives_module_system.md) — The `Module` base class used by code-generating strategies.
- [primitives_data_containers.md](primitives_data_containers.md) — `Prediction` and `Example` containers used to return interpreter results.
