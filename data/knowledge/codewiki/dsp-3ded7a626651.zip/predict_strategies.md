# Predict Strategies Module

## Introduction

The **Predict Strategies** module (`dspy/predict/`) is a collection of high-level reasoning and orchestration strategies built on top of the core [`Predict`](predict_core.md) primitive. While `Predict` provides the fundamental "signature → LM call → prediction" mechanism, the strategies in this module compose, iterate, and refine that primitive to implement well-known prompting and agentic paradigms.

These strategies include:

- **Chain-of-thought reasoning** (`ChainOfThought`, `ChainOfThoughtWithHint`)
- **Tool-using agents** (`ReAct`, `CodeAct`, `Avatar`)
- **Code generation and execution** (`ProgramOfThought`, `CodeAct`)
- **Ensembling and self-consistency** (`MultiChainComparison`, `BestOfN`)
- **Reward-driven refinement** (`Refine`, `OfferFeedback`)

Each strategy is a [`Module`](primitives.md) that wraps one or more `Predict` instances (or other modules) and exposes a `forward`/`aforward` interface. This design allows strategies to be composed arbitrarily and optimized by teleprompters.

---

## Architecture Overview

All strategies inherit from the base `Module` class and ultimately delegate to `Predict` for LM interaction. The diagram below shows the inheritance and composition relationships.

```mermaid
graph TD
    Module["Module (primitives/program.py)"]
    Predict["Predict (predict_core)"]

    Module --> Predict
    Module --> CoT["ChainOfThought"]
    Module --> CoTH["ChainOfThoughtWithHint"]
    Module --> ReAct["ReAct"]
    Module --> PoT["ProgramOfThought"]
    Module --> MCC["MultiChainComparison"]
    Module --> BoN["BestOfN"]
    Module --> Refine["Refine"]
    Module --> Avatar["Avatar"]

    ReAct --> CodeAct["CodeAct"]
    PoT --> CodeAct

    CoT --> Predict
    CoTH --> CoT
    ReAct --> Predict
    PoT --> CoT
    MCC --> Predict
    BoN --> Module
    Refine --> Predict
    Avatar --> TypedPredictor["TypedPredictor"]

    PoT --> Interpreter["PythonInterpreter"]
    CodeAct --> Interpreter
    ReAct --> Tool["Tool (adapters/types/tool.py)"]
    CodeAct --> Tool
    Avatar --> AvatarModels["avatar/models.py"]
```

### Key Design Principles

1. **Composition over inheritance**: Most strategies wrap a `Predict` (or another strategy) rather than reimplementing LM interaction. For example, `ChainOfThought` internally creates a `Predict` with an extended signature.
2. **Signature polymorphism**: Strategies accept any `Signature` and dynamically extend it (e.g., prepending a `reasoning` field, appending `trajectory`/`next_thought` fields).
3. **Sync/async parity**: Strategies that perform iterative work (`ReAct`, `CodeAct`) provide both `forward` and `aforward` implementations.
4. **Trace management**: Strategies that internally invoke sub-modules carefully manage `dspy.settings.trace` to keep the optimization trace clean (see `ChainOfThoughtWithHint`, `BestOfN`, `Refine`).

---

## Strategy Categories

### 1. Reasoning Strategies

#### ChainOfThought

`ChainOfThought` implements the classic "think step by step" paradigm. It extends the user's signature by **prepending** a `reasoning` output field, then delegates to a `Predict`.

```mermaid
flowchart LR
    A["Input Signature<br/>(question -> answer)"] --> B["prepend reasoning field"]
    B --> C["Extended Signature<br/>(question -> reasoning, answer)"]
    C --> D["Predict"]
    D --> E["Prediction"]
```

- **Constructor**: `ChainOfThought(signature, rationale_field=None, rationale_field_type=str, **config)`
- **Default rationale field**: `OutputField(prefix="Reasoning: Let's think step by step in order to", desc="${reasoning}")`
- **Delegation**: `forward` → `self.predict(**kwargs)`; `aforward` → `self.predict.acall(**kwargs)`

#### ChainOfThoughtWithHint

`ChainOfThoughtWithHint` wraps a `ChainOfThought` and injects an optional "secret hint" into the **last input field** of the signature. It carefully restores the original (hint-free) kwargs in the trace so that optimizers do not learn from hint-augmented inputs.

```mermaid
sequenceDiagram
    participant Caller
    participant CoTH as ChainOfThoughtWithHint
    participant CoT as ChainOfThought
    Caller->>CoTH: forward(hint=..., **kwargs)
    CoTH->>CoTH: append hint to last input field
    CoTH->>CoT: call with hint-augmented kwargs (trace=[])
    CoT-->>CoTH: pred
    CoTH->>CoTH: replace trace entry with original kwargs
    CoTH-->>Caller: pred
```

#### MultiChainComparison

`MultiChainComparison` aggregates `M` independent reasoning attempts and asks the LM to holistically produce a corrected rationale and final answer. It **appends** `reasoning_attempt_1..M` input fields and **prepends** a `rationale` output field.

- **Constructor**: `MultiChainComparison(signature, M=3, temperature=0.7, **config)`
- **Input**: `completions` — a list of prior predictions (each with a `rationale`/`reasoning` and the last output key).
- **Validation**: Asserts `len(attempts) == M`.

---

### 2. Agentic / Tool-Using Strategies

#### ReAct

`ReAct` ("Reasoning and Acting") builds a tool-using agent that iteratively interleaves `next_thought`, `next_tool_name`, and `next_tool_args`. It uses two sub-modules:

- `self.react`: a `Predict` over a dynamically constructed signature with `trajectory`, `next_thought`, `next_tool_name`, and `next_tool_args` fields.
- `self.extract`: a `ChainOfThought` over a fallback signature that extracts the final outputs from the trajectory.

```mermaid
flowchart TD
    Start["forward(**input_args)"] --> Loop{"idx < max_iters"}
    Loop -->|yes| Call["react(trajectory, **inputs)"]
    Call --> Thought["record thought_idx"]
    Thought --> ToolCall["execute tool_name_idx(**tool_args_idx)"]
    ToolCall --> Obs["record observation_idx"]
    Obs --> Finish{"tool == finish?"}
    Finish -->|no| Loop
    Finish -->|yes| Extract
    Loop -->|no| Extract["extract(trajectory, **inputs)"]
    Extract --> Return["Prediction(trajectory=..., **extract)"]
```

Key features:

- **Tool normalization**: Accepts functions, callables, or `dspy.Tool` instances; converts all to `Tool` and indexes by name.
- **`finish` tool**: A synthetic tool automatically added to signal task completion.
- **Context-window handling**: `_call_with_potential_trajectory_truncation` retries up to 3 times, calling `truncate_trajectory` (overridable) to drop the oldest tool call (4 keys) when `ContextWindowExceededError` is raised.
- **Error resilience**: Invalid tool selection ends the trajectory gracefully; tool execution errors are captured as observations.
- **Async support**: `aforward` mirrors `forward` using `acall` and `Tool.acall`.

#### CodeAct

`CodeAct` combines `ReAct` and `ProgramOfThought` (multiple inheritance) to build an agent that writes and executes Python code, with access to predefined tools injected into the interpreter.

```mermaid
graph TD
    CodeAct["CodeAct(ReAct, ProgramOfThought)"]
    CodeAct --> CodeActPredict["self.codeact: Predict"]
    CodeAct --> Extractor["self.extractor: ChainOfThought"]
    CodeAct --> Interpreter["self.interpreter: PythonInterpreter"]
    CodeAct --> Tools["self.tools: dict[str, Tool]"]
```

- **Tool injection**: At the start of `forward`, each tool's source is executed inside the interpreter via `inspect.getsource(tool.func)`.
- **Restriction**: Only accepts plain functions (not callable objects) — enforced via `inspect.isfunction`.
- **Loop**: Generates code, parses it (`_parse_code`), executes it (`_execute_code`), and records `generated_code_idx`/`code_output_idx`/`observation_idx` in the trajectory until `finished=True` or `max_iters` is reached.
- **Extraction**: Uses `_call_with_potential_trajectory_truncation` (inherited from `ReAct`) to extract final outputs.

#### Avatar

`Avatar` is a tool-using agent that uses a `TypedPredictor` (`Actor`) to select tools iteratively. Unlike `ReAct`, it uses structured `Action`/`ActionOutput` Pydantic models and dynamically grows the actor's signature with `action_idx`/`result_idx` fields.

```mermaid
flowchart TD
    Start["forward(**kwargs)"] --> Init["build args: goal, tools, inputs"]
    Init --> Loop{"tool_name != Finish"}
    Loop -->|yes| Actor["actor(**args) -> action_idx"]
    Actor --> Check{"tool == Finish?"}
    Check -->|no| Exec["_call_tool -> ActionOutput"]
    Exec --> Update["_update_signature(idx)"]
    Update --> Loop
    Check -->|yes| Omit["_update_signature(idx, omit_action=True)"]
    Omit --> Final["actor(**args) -> final_answer"]
    Loop -->|no| Final
    Final --> Reset["restore actor from clone"]
    Reset --> Return["Prediction(**outputs, actions=...)"]
```

- **Finish tool**: A synthetic `Tool(name="Finish")` appended to the tool list.
- **State reset**: `self.actor_clone` is a deep copy used to restore the actor's signature after each `forward` call.
- **Models**: `Action`, `ActionOutput`, and `Tool` are defined in `avatar/models.py`; the `Actor` signature lives in `avatar/signatures.py`.

---

### 3. Code Execution Strategy

#### ProgramOfThought

`ProgramOfThought` (PoT) generates Python code to solve a problem, executes it in a sandboxed `PythonInterpreter`, and extracts the final answer. It uses three `ChainOfThought` sub-modules:

| Sub-module | Purpose |
|------------|---------|
| `code_generate` | Generate initial Python code |
| `code_regenerate` | Fix code given `previous_code` and `error` |
| `generate_answer` | Extract final outputs from `final_generated_code` and `code_output` |

```mermaid
flowchart TD
    Start["forward(**kwargs)"] --> Gen["code_generate -> code_data"]
    Gen --> Parse["_parse_code"]
    Parse --> Exec["_execute_code (PythonInterpreter)"]
    Exec --> Check{"error?"}
    Check -->|yes, hop < max_iters| Regen["code_regenerate(previous_code, error)"]
    Regen --> Parse
    Check -->|yes, hop == max_iters| Fail["shutdown + RuntimeError"]
    Check -->|no| Answer["generate_answer(final_generated_code, code_output)"]
    Answer --> Shutdown["interpreter.shutdown()"]
    Shutdown --> Return["answer_gen_result"]
```

- **Code parsing** (`_parse_code`): Strips fenced code blocks, fixes common formatting issues (e.g., multiple assignments on one line), and returns `(code, error)`.
- **Execution** (`_execute_code`): Serializes the interpreter result to JSON; returns `(output, error)`.
- **Interpreter**: Requires [Deno](https://docs.deno.com/runtime/getting_started/installation/) to be installed. See [`PythonInterpreter`](primitives.md) for sandboxing details.

---

### 4. Ensembling & Refinement Strategies

#### BestOfN

`BestOfN` runs a module up to `N` times with varying temperatures and returns the best prediction according to a `reward_fn`, stopping early when the reward meets `threshold`.

```mermaid
flowchart TD
    Start["forward(**kwargs)"] --> Temps["compute temperature schedule"]
    Temps --> Loop{"for each temperature"}
    Loop --> Copy["deepcopy module, set LM with temp"]
    Copy --> Run["run module (trace=[])"]
    Run --> Reward["reward = reward_fn(kwargs, pred)"]
    Reward --> Best{"reward > best_reward?"}
    Best -->|yes| Update["update best_pred/best_trace/best_reward"]
    Best -->|no| Threshold
    Update --> Threshold{"reward >= threshold?"}
    Threshold -->|yes| Break["break"]
    Threshold -->|no| Loop
    Break --> Extend["extend settings.trace with best_trace"]
    Loop -->|done| Extend
    Extend --> Return["best_pred"]
```

- **Temperature schedule**: Starts with the LM's current temperature, then adds `0.5 + i * (0.5 / N)` values, deduplicated and truncated to `N`.
- **Failure handling**: `fail_count` (defaults to `N`) limits tolerated exceptions before re-raising.
- **Trace isolation**: Each attempt runs under `dspy.context(trace=[])`; only the best trace is merged back.

#### Refine

`Refine` extends the `BestOfN` idea by generating **feedback** (`OfferFeedback`) when no attempt meets the threshold, then re-running with per-module advice injected as a `hint_` input field.

```mermaid
flowchart TD
    Start["forward(**kwargs)"] --> Loop{"for each temperature"}
    Loop --> Advice{"advice available?"}
    Advice -->|no| Run["run module"]
    Advice -->|yes| Wrap["run module with WrapperAdapter injecting hint_"]
    Run --> Reward["reward = reward_fn(kwargs, outputs)"]
    Wrap --> Reward
    Reward --> Best{"reward > best_reward?"}
    Best -->|yes| Update["update best_*"]
    Best -->|no| Threshold
    Update --> Threshold{"reward >= threshold?"}
    Threshold -->|yes| Break["break"]
    Threshold -->|no| Last{"idx == N-1?"}
    Last -->|yes| Break
    Last -->|no| Feedback["OfferFeedback -> advice"]
    Feedback --> Loop
    Break --> Extend["extend trace"]
    Loop -->|done| Extend
    Extend --> Return["best_pred"]
```

- **`OfferFeedback`**: A `Signature` that takes program code, module definitions, trajectory, outputs, reward code, and module names, and produces a `discussion` and per-module `advice` dict.
- **`WrapperAdapter`**: A dynamically-created adapter subclass that appends a `hint_` input field to each signature and injects the corresponding advice.
- **Helper functions**:
  - `inspect_modules(program)`: Produces a human-readable description of each predictor's I/O and instructions.
  - `recursive_mask(o)`: Recursively replaces non-serializable objects with placeholder strings for JSON serialization.

---

## Component Interaction & Data Flow

The following diagram shows how a typical strategy call flows through the DSPy stack, from the user call down to the LM and back.

```mermaid
sequenceDiagram
    participant User
    participant Strategy as Strategy (e.g. ChainOfThought)
    participant Predict as Predict
    participant Adapter as ChatAdapter
    participant LM as LM
    participant Settings as Settings

    User->>Strategy: __call__(**kwargs)
    Strategy->>Strategy: forward(**kwargs)
    Strategy->>Predict: __call__(**kwargs)
    Predict->>Settings: read lm, adapter, trace
    Predict->>Adapter: __call__(lm, signature, demos, inputs)
    Adapter->>LM: format + invoke
    LM-->>Adapter: completions
    Adapter-->>Predict: parsed fields
    Predict->>Settings: append to trace
    Predict-->>Strategy: Prediction
    Strategy-->>User: Prediction
```

### Shared Infrastructure

All strategies rely on the following shared components:

| Component | Role | Documentation |
|-----------|------|---------------|
| `Module` | Base class providing `__call__`, `acall`, `named_predictors`, `deepcopy`, `set_lm` | [primitives.md](primitives.md) |
| `Predict` | Core LM-calling primitive | [predict_core.md](predict_core.md) |
| `Signature` | Declarative I/O specification, dynamically extended by strategies | [signatures.md](signatures.md) |
| `Prediction` | Output container | [primitives.md](primitives.md) |
| `Settings` | Global/thread-local config (`lm`, `adapter`, `trace`) | [dsp_settings.md](dsp_settings.md) |
| `Tool` | Function-calling wrapper | [adapters_types.md](adapters_types.md) |
| `PythonInterpreter` | Sandboxed code execution (Deno/Pyodide) | [primitives.md](primitives.md) |
| `ChatAdapter` | Default adapter for formatting/parsing | [adapters_core.md](adapters_core.md) |

---

## Strategy Comparison

| Strategy | Base | Iterative | Uses Tools | Executes Code | Uses Reward | Async |
|----------|------|-----------|------------|---------------|-------------|-------|
| `ChainOfThought` | `Module` | No | No | No | No | Yes |
| `ChainOfThoughtWithHint` | `Module` | No | No | No | No | No |
| `ReAct` | `Module` | Yes | Yes | No | No | Yes |
| `CodeAct` | `ReAct`, `ProgramOfThought` | Yes | Yes | Yes | No | No |
| `ProgramOfThought` | `Module` | Yes | No | Yes | No | No |
| `MultiChainComparison` | `Module` | No | No | No | No | No |
| `BestOfN` | `Module` | Yes | No | No | Yes | No |
| `Refine` | `Module` | Yes | No | No | Yes | No |
| `Avatar` | `Module` | Yes | Yes | No | No | No |

---

## Extending the Module

To add a new strategy:

1. Subclass `Module` (or an existing strategy for reuse).
2. In `__init__`, build one or more `Predict`/`ChainOfThought` sub-modules, extending the signature as needed via `Signature.prepend`/`append`/`insert`.
3. Implement `forward` (and optionally `aforward` for async support).
4. If the strategy runs sub-modules in a loop, isolate traces with `dspy.context(trace=[])` and merge only the relevant trace back into `dspy.settings.trace` to keep optimization clean.
5. If the strategy executes code, use `PythonInterpreter` and ensure `shutdown()` is called.

### Trace Management Pattern

Strategies that internally invoke sub-modules multiple times should follow this pattern to avoid polluting the optimization trace:

```python
with dspy.context(trace=[]):
    pred = self.module(**kwargs)
    trace = dspy.settings.trace.copy()
# ... select best trace ...
dspy.settings.trace.extend(best_trace)
```

This pattern is used by `BestOfN`, `Refine`, and `ChainOfThoughtWithHint`.

---

## Related Documentation

- [predict_core.md](predict_core.md) — The `Predict` primitive and `Parameter`
- [predict_utilities.md](predict_utilities.md) — `Parallel` and `KNN` utilities
- [primitives.md](primitives.md) — `Module`, `Prediction`, `PythonInterpreter`
- [signatures.md](signatures.md) — `Signature` and field definitions
- [adapters_core.md](adapters_core.md) — `ChatAdapter`, `JSONAdapter`, and other adapters
- [adapters_types.md](adapters_types.md) — `Tool`, `ToolCalls`, and other adapter types
- [dsp_settings.md](dsp_settings.md) — Global `Settings` and `dspy.context`
- [clients_lm_core.md](clients_lm_core.md) — `LM` and `BaseLM`
