# Propose Module

## Overview

The **propose** module is responsible for automatically generating and proposing new **instructions** (prompts) for the predictors within a DSPy program. It is a foundational building block used by instruction-optimization teleprompters such as `MIPROv2` and `COPRO`. Rather than hand-crafting prompts, the propose module uses a language model to *reason about* a program, its dataset, and its prior optimization history, and then synthesizes improved natural-language instructions for each predictor.

The module is **grounded**: its proposals are informed by concrete context, including:

- A **dataset summary** describing the task the program is meant to solve.
- The **program source code** and a description of each module's role.
- **Task demonstrations** (few-shot examples) drawn from candidate demo sets.
- **Instruction history** — previously tried instructions and their associated scores.
- Optional **tips** that steer the style of the generated instruction (e.g., creative, concise, persona-based).

## Purpose and Core Functionality

The propose module answers the question: *"Given this program, this data, and what we've tried before, what instruction should each predictor use next?"*

Its key responsibilities are:

1. **Define a proposer interface** — an abstract contract (`Proposer`) that any instruction-proposal strategy must implement.
2. **Summarize the dataset** — distill a training set into a short, human-readable description of the task.
3. **Generate grounded instructions** — produce new instructions for individual predictors using program-aware, data-aware, and history-aware context.
4. **Orchestrate proposals across a program** — iterate over every predictor and demo set to produce a full set of candidate instructions.

## Architecture Overview

The module is composed of three cooperating layers: an abstract base, a dataset-summarization layer, and a grounded instruction-generation layer.

```mermaid
graph TD
    subgraph "Propose Module"
        PB["Proposer<br/>(abstract base)"]
        GP["GroundedProposer<br/>(concrete implementation)"]
        GMI["GenerateModuleInstruction<br/>(per-predictor generator)"]
        DSG["create_dataset_summary<br/>(dataset summarizer)"]
    end

    subgraph "Signatures"
        DP["DescribeProgram"]
        DM["DescribeModule"]
        GSI["GenerateSingleModuleInstruction<br/>(dynamic)"]
        DD["DatasetDescriptor"]
        DDPO["DatasetDescriptorWithPriorObservations"]
        OS["ObservationSummarizer"]
    end

    subgraph "External Dependencies"
        PRED["dspy.Predict"]
        SET["dspy.settings"]
        UTIL["propose.utils"]
        TP["teleprompt.utils"]
    end

    PB --> GP
    GP --> GMI
    GP --> DSG
    GMI --> DP
    GMI --> DM
    GMI --> GSI
    DSG --> DD
    DSG --> DDPO
    DSG --> OS
    GMI --> UTIL
    GP --> TP
    GMI --> PRED
    DSG --> SET
```

### Data Flow

The following diagram illustrates how a `GroundedProposer` produces instructions for a program.

```mermaid
sequenceDiagram
    participant User
    participant GP as GroundedProposer
    participant DSG as create_dataset_summary
    participant GMI as GenerateModuleInstruction
    participant LM as Prompt Model

    User->>GP: __init__(program, trainset, ...)
    GP->>GP: get_dspy_source_code(program)
    GP->>DSG: create_dataset_summary(trainset)
    DSG->>LM: DatasetDescriptor / WithPriorObservations
    DSG->>LM: ObservationSummarizer
    DSG-->>GP: data_summary

    User->>GP: propose_instructions_for_program(...)
    loop for each predictor
        loop for each demo set
            GP->>GMI: forward(demo_candidates, pred_i, ...)
            GMI->>LM: DescribeProgram
            GMI->>LM: DescribeModule
            GMI->>LM: GenerateSingleModuleInstruction
            GMI-->>GP: proposed_instruction
        end
    end
    GP-->>User: proposed_instructions
```

## Sub-modules

The propose module is organized into two logical sub-modules, each documented in detail:

### 1. Dataset Summary Generation

The dataset-summary sub-module converts a training set into a concise natural-language description of the task. It uses an iterative observation-and-summarization loop driven by three signatures.

- **Core components:** `DatasetDescriptor`, `DatasetDescriptorWithPriorObservations`, `ObservationSummarizer`, `create_dataset_summary`
- **Detailed documentation:** [propose_dataset_summary.md](propose_dataset_summary.md)

### 2. Grounded Instruction Proposal

The grounded-proposal sub-module is the heart of the module. It defines the abstract `Proposer` contract and the concrete `GroundedProposer` implementation, which orchestrates per-predictor instruction generation using program-aware, data-aware, and history-aware context.

- **Core components:** `Proposer`, `GroundedProposer`, `GenerateModuleInstruction`, `DescribeProgram`, `DescribeModule`, `generate_instruction_class`
- **Detailed documentation:** [propose_grounded.md](propose_grounded.md)

## Component Relationships

```mermaid
classDiagram
    class Proposer {
        <<abstract>>
        +propose_instructions_for_program()
        +propose_instruction_for_predictor()
    }
    class GroundedProposer {
        +program_aware
        +use_dataset_summary
        +use_task_demos
        +use_instruct_history
        +use_tip
        +propose_instructions_for_program()
        +propose_instruction_for_predictor()
    }
    class GenerateModuleInstruction {
        +forward(demo_candidates, pred_i, ...)
    }
    class DescribeProgram {
        <<Signature>>
    }
    class DescribeModule {
        <<Signature>>
    }
    class DatasetDescriptor {
        <<Signature>>
    }
    class DatasetDescriptorWithPriorObservations {
        <<Signature>>
    }
    class ObservationSummarizer {
        <<Signature>>
    }

    Proposer <|-- GroundedProposer
    GroundedProposer --> GenerateModuleInstruction : creates
    GroundedProposer ..> DatasetDescriptor : uses
    GroundedProposer ..> DatasetDescriptorWithPriorObservations : uses
    GroundedProposer ..> ObservationSummarizer : uses
    GenerateModuleInstruction --> DescribeProgram : uses
    GenerateModuleInstruction --> DescribeModule : uses
```

## How the Module Fits into the System

The propose module sits between the **primitives** (programs, modules, predictors) and the **teleprompt** optimizers. It consumes a `dspy.Module` program and a training set, and produces candidate instructions that optimizers evaluate and select from.

```mermaid
graph LR
    subgraph "Inputs"
        PROG["dspy.Module<br/>(program)"]
        DATA["trainset"]
        LOGS["trial_logs"]
    end

    subgraph "Propose Module"
        GP["GroundedProposer"]
    end

    subgraph "Consumers"
        MIPRO["MIPROv2"]
        COPRO["COPRO"]
    end

    subgraph "Foundations"
        PRED["predict module"]
        PRIM["primitives module"]
        SIG["signatures module"]
    end

    PROG --> GP
    DATA --> GP
    LOGS --> GP
    GP --> MIPRO
    GP --> COPRO
    GP -.uses.-> PRED
    GP -.uses.-> PRIM
    GP -.uses.-> SIG
```

### Key Dependencies

| Dependency | Role |
| --- | --- |
| [predict.md](predict.md) | Provides `dspy.Predict` and `dspy.Module` used to build the proposer's internal signatures and modules. |
| [primitives.md](primitives.md) | Supplies `Module`, `Prediction`, and `Parameter` types used throughout the proposer. |
| [signatures.md](signatures.md) | Provides the `Signature` base class for all proposer signatures. |
| [dsp_settings.md](dsp_settings.md) | `dspy.settings.context(lm=...)` is used to scope the prompt model during generation. |
| [teleprompt.md](teleprompt.md) | `get_prompt_model` and `get_signature` helpers are reused; `MIPROv2`/`COPRO` are the primary consumers. |

## Configuration Options

The `GroundedProposer` exposes a rich set of configuration flags that control how grounded each proposal is:

| Option | Default | Description |
| --- | --- | --- |
| `use_dataset_summary` | `True` | Include a dataset summary in the generation context. |
| `program_aware` | `True` | Include program source code and module descriptions. |
| `use_task_demos` | `True` | Include few-shot task demonstrations. |
| `num_demos_in_context` | `3` | Number of demos to include per proposal. |
| `use_instruct_history` | `True` | Include previously tried instructions and their scores. |
| `use_tip` | `True` | Include a stylistic tip to steer generation. |
| `set_tip_randomly` | `True` | Randomly select a tip each round. |
| `set_history_randomly` | `True` | Randomly toggle history usage each round. |
| `view_data_batch_size` | `10` | Batch size for dataset summarization. |

## Summary

The propose module provides a grounded, context-rich mechanism for generating new instructions for DSPy programs. Its two sub-modules — [dataset summary generation](propose_dataset_summary.md) and [grounded instruction proposal](propose_grounded.md) — work together to turn raw training data and program structure into actionable prompt improvements, which are then consumed by instruction-optimization teleprompters.
