# Adapter Types: Tool

## Introduction

The `adapter_types_tool` module provides the `Tool` and `ToolCalls` custom types used by DSPy adapters to support **tool calling (function calling)** in Large Language Models. These types bridge the gap between Python callables and the structured schemas that LLM providers expect, enabling DSPy programs to expose functions to models and to parse the tool invocations the models return.

The module is part of the broader [adapter types](adapter_types.md) family, which defines custom types (such as `Image`, `Audio`, and `History`) that adapters know how to serialize into provider-specific message formats. `Tool` and `ToolCalls` extend the shared [`BaseType`](adapter_types_base_type.md) contract.

---

## Core Components

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `Tool` | Class (extends `BaseType`) | Wraps a Python callable, infers its name/description/argument schema, validates and parses arguments, and executes the function (sync or async). |
| `ToolCalls` | Class (extends `BaseType`) | Container for a list of `ToolCall` objects parsed from an LLM response. |
| `ToolCalls.ToolCall` | Nested `BaseModel` | Represents a single tool invocation with a `name` and `args` dictionary. |
| `convert_input_schema_to_tool_args` | Function | Converts a JSON input schema into DSPy-compatible `(args, arg_types, arg_desc)` tuples. |
| `_resolve_json_schema_reference` | Function | Recursively resolves `$ref`/`$defs` references in JSON schemas. |

---

## Architecture

The module sits between user-defined Python functions and the adapter layer that formats prompts for LLMs.

```mermaid
graph TD
    subgraph "User Code"
        F["Python function<br/>(with type hints)"]
    end

    subgraph "adapter_types_tool"
        T["Tool"]
        TC["ToolCalls"]
        TCall["ToolCalls.ToolCall"]
        CIS["convert_input_schema_to_tool_args"]
        RJS["_resolve_json_schema_reference"]
    end

    subgraph "Base"
        BT["BaseType"]
    end

    subgraph "Adapters"
        CA["ChatAdapter"]
        JA["JSONAdapter"]
        XA["XMLAdapter"]
        TSA["TwoStepAdapter"]
    end

    subgraph "External Integrations"
        MCP["MCP Tools"]
        LC["LangChain Tools"]
    end

    F -->|wrapped by| T
    T -->|extends| BT
    TC -->|extends| BT
    TC -->|contains| TCall
    T -->|uses| RJS
    CIS -->|uses| RJS
    CIS -->|produces args for| T
    MCP -->|from_mcp_tool| T
    LC -->|from_langchain| T
    T -->|formatted by| CA
    T -->|formatted by| JA
    T -->|formatted by| XA
    T -->|formatted by| TSA
    TC -->|parsed by| CA
    TC -->|parsed by| JA
```

---

## Component Relationships

```mermaid
classDiagram
    class BaseType {
        +format() list|str
        +description() str
        +extract_custom_type_from_annotation(annotation)
        +serialize_model()
    }

    class Tool {
        +Callable func
        +str name
        +str desc
        +dict args
        +dict arg_types
        +dict arg_desc
        +bool has_kwargs
        +__init__(func, name, desc, args, arg_types, arg_desc)
        +_parse_function(func, arg_desc)
        +_validate_and_parse_args(**kwargs)
        +format() str
        +format_as_litellm_function_call() dict
        +__call__(**kwargs)
        +acall(**kwargs)
        +from_mcp_tool(session, tool)$ Tool
        +from_langchain(tool)$ Tool
    }

    class ToolCalls {
        +list~ToolCall~ tool_calls
        +from_dict_list(dicts)$ ToolCalls
        +description() str
    }

    class ToolCall {
        +str name
        +dict args
    }

    BaseType <|-- Tool
    BaseType <|-- ToolCalls
    ToolCalls *-- ToolCall
```

---

## Tool: Function Wrapping and Schema Inference

The `Tool` class is the primary entry point. When instantiated with a Python callable, it automatically infers metadata unless the user explicitly provides it.

### Inference Flow

```mermaid
flowchart TD
    A["Tool(func, ...)"] --> B["_parse_function(func, arg_desc)"]
    B --> C["inspect.signature + get_type_hints"]
    C --> D{"For each parameter"}
    D --> E{"Type is Pydantic<br/>BaseModel?"}
    E -->|Yes| F["model_json_schema()<br/>+ resolve $refs"]
    E -->|No| G["TypeAdapter(v).json_schema()"]
    F --> H["Attach default & description"]
    G --> H
    H --> I["Populate args, arg_types"]
    I --> J["Detect **kwargs (has_kwargs)"]
    J --> K["Set name/desc if not user-provided"]
```

Key behaviors:
- **Name**: defaults to `func.__name__` (or the class name for callables).
- **Description**: defaults to `func.__doc__`.
- **Args schema**: derived from type hints; Pydantic models are expanded inline via `_resolve_json_schema_reference` so nested `$ref`s are flattened.
- **`has_kwargs`**: set to `True` when the function accepts `**kwargs`, allowing extra arguments to pass through validation.

### Argument Validation and Parsing

`_validate_and_parse_args` performs two stages:

1. **Validation** — each argument is checked against its JSON schema using `jsonschema.validate`. Unknown arguments raise `ValueError` unless `has_kwargs` is set.
2. **Parsing** — arguments are coerced to their declared Python types using a dynamically created Pydantic wrapper model (`create_model("Wrapper", value=(type, ...))`). This handles complex nested types such as `list[list[MyPydanticModel]]`.

### Execution: `__call__` vs `acall`

```mermaid
flowchart TD
    Start["Tool invocation"] --> V["_validate_and_parse_args"]
    V --> R["result = func(**parsed_kwargs)"]
    R --> C{"iscoroutine(result)?"}
    C -->|No| Ret["return result"]
    C -->|Yes| Mode{"Calling __call__<br/>or acall?"}
    Mode -->|acall| Await["await result"]
    Mode -->|__call__| Allow{"settings.allow_tool_async_sync_conversion?"}
    Allow -->|Yes| Run["_run_async_in_sync(result)"]
    Allow -->|No| Err["raise ValueError<br/>(use acall instead)"]
```

- `__call__` is decorated with [`with_callbacks`](utils_callback.md), so tool executions emit start/end callback events.
- `acall` is the async counterpart and can also invoke synchronous tools.
- `_run_async_in_sync` safely runs a coroutine whether or not an event loop is already running.

### Formatting for LLMs

- `format()` returns the string representation (`__str__`).
- `format_as_litellm_function_call()` produces an OpenAI/LiteLLM-compatible function-call schema:

```python
{
    "type": "function",
    "function": {
        "name": self.name,
        "description": self.desc,
        "parameters": {
            "type": "object",
            "properties": self.args,
            "required": list(self.args.keys()),
        },
    },
}
```

### External Integrations

| Method | Source | Delegates To |
|--------|--------|--------------|
| `from_mcp_tool(session, tool)` | MCP tools | `dspy.utils.mcp.convert_mcp_tool` |
| `from_langchain(tool)` | LangChain `BaseTool` | `dspy.utils.langchain_tool.convert_langchain_tool` |

Both are classmethods that lazily import their conversion utilities, keeping optional dependencies out of the import path.

---

## ToolCalls: Parsing Model Responses

`ToolCalls` represents the tool invocations returned by an LLM. It wraps a list of `ToolCall` objects, each carrying a `name` and an `args` dictionary.

```mermaid
sequenceDiagram
    participant LLM
    participant Adapter
    participant ToolCalls
    participant Tool

    LLM->>Adapter: Raw response with tool calls
    Adapter->>ToolCalls: from_dict_list([{name, args}, ...])
    ToolCalls-->>Adapter: ToolCalls instance
    Adapter->>Tool: __call__(**args) per ToolCall
    Tool-->>Adapter: Execution result
```

- `from_dict_list` converts a list of `{"name": ..., "args": {...}}` dictionaries into a `ToolCalls` instance.
- `description()` returns a human-readable description used by adapters when generating prompts, instructing the model to provide arguments in JSON format.

---

## Schema Conversion Utilities

### `convert_input_schema_to_tool_args`

Converts a JSON input schema (e.g., from an MCP tool definition) into the `(args, arg_types, arg_desc)` tuple expected by `Tool`. It:
- Reads `properties`, `required`, and `$defs` from the schema.
- Resolves nested references via `_resolve_json_schema_reference`.
- Maps JSON types to Python types using `_TYPE_MAPPING` (`string→str`, `integer→int`, `number→float`, `boolean→bool`, `array→list`, `object→dict`).
- Appends `" (Required)"` to descriptions of required arguments.

### `_resolve_json_schema_reference`

Recursively expands `$ref` pointers against `$defs`/`definitions`, producing a self-contained schema with no external references. This is essential for flattening Pydantic model schemas into a form LLM providers accept.

---

## Data Flow Summary

```mermaid
flowchart LR
    subgraph Input
        PY["Python function"]
        MCP["MCP tool"]
        LC["LangChain tool"]
    end

    subgraph "Tool Construction"
        T["Tool"]
    end

    subgraph "LLM Interaction"
        FMT["format_as_litellm_function_call()"]
        LLM["LLM"]
        TC["ToolCalls"]
    end

    subgraph "Execution"
        VAL["_validate_and_parse_args"]
        EXE["func(**kwargs)"]
    end

    PY --> T
    MCP --> T
    LC --> T
    T --> FMT --> LLM
    LLM --> TC
    TC --> VAL --> EXE
```

---

## Related Modules

- [adapter_types](adapter_types.md) — Overview of all custom adapter types.
- [adapter_types_base_type](adapter_types_base_type.md) — The `BaseType` contract that `Tool` and `ToolCalls` implement.
- [adapter_types_image](adapter_types_image.md), [adapter_types_audio](adapter_types_audio.md), [adapter_types_history](adapter_types_history.md) — Sibling custom types.
- [adapters_core](adapters_core.md) — Adapters (`ChatAdapter`, `JSONAdapter`, `XMLAdapter`, `TwoStepAdapter`) that format and parse these types.
- [utils_callback](utils_callback.md) — The `with_callbacks` decorator applied to tool execution methods.
