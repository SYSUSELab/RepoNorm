# Propose Grounded Module

## Introduction

The `propose_grounded` module implements **grounded instruction proposal** for DSPy programs. It is responsible for generating new, high-quality natural-language *instructions* for the predictors (modules) inside a DSPy program, using rich contextual signals ("grounding") such as:

- A **summary of the training dataset** (data-aware proposal)
- A **description of the program's source code** (program-aware proposal)
- **Task demonstrations** (few-shot examples) drawn from bootstrapped candidate sets
- A **history of previously attempted instructions** and their scores
- A randomly selected **prompting tip** (e.g. "be creative", "use a persona")

The module is the concrete implementation of the abstract [`Proposer`](#proposer-base-class) interface and is the instruction-generation engine used by optimizers such as [`MIPROv2`](teleprompt.md). It does **not** evaluate or select instructions — it only *proposes* candidates, which downstream optimizers then score and select.

> **Scope note:** This document covers `dspy/propose/propose_base.py` and `dspy/propose/grounded_proposer.py`. The dataset-summary generation used as a grounding signal is documented in [propose_dataset_summary.md](propose_dataset_summary.md).

---

## Architecture Overview

The module is composed of a small class hierarchy plus a set of helper signatures and utility functions.

```mermaid
graph TD
    subgraph "propose_grounded"
        Proposer["Proposer (ABC)<br/>propose_base.py"]
        GroundedProposer["GroundedProposer<br/>grounded_proposer.py"]
        GMI["GenerateModuleInstruction<br/>(dspy.Module)"]
        DescribeProgram["DescribeProgram<br/>(dspy.Signature)"]
        DescribeModule["DescribeModule<br/>(dspy.Signature)"]
        GenInstrClass["generate_instruction_class()<br/>→ dspy.Predict"]
    end

    subgraph "propose_dataset_summary"
        create_dataset_summary["create_dataset_summary()"]
    end

    subgraph "propose.utils"
        create_example_string["create_example_string()"]
        create_history["create_predictor_level_history_string()"]
        get_source["get_dspy_source_code()"]
        strip_prefix["strip_prefix()"]
    end

    subgraph "teleprompt.utils"
        get_prompt_model["get_prompt_model()"]
        get_signature["get_signature()"]
    end

    GroundedProposer -- inherits --> Proposer
    GroundedProposer -- creates --> GMI
    GMI -- uses --> DescribeProgram
    GMI -- uses --> DescribeModule
    GMI -- uses --> GenInstrClass
    GroundedProposer -- uses --> create_dataset_summary
    GMI -- uses --> create_example_string
    GroundedProposer -- uses --> create_history
    GroundedProposer -- uses --> get_source
    GMI -- uses --> strip_prefix
    GroundedProposer -- uses --> get_prompt_model
    GMI -- uses --> get_signature
```

### Component Responsibilities

| Component | Type | Responsibility |
|-----------|------|----------------|
| `Proposer` | Abstract base class | Defines the `propose_instructions_for_program` contract. |
| `GroundedProposer` | Concrete `Proposer` | Orchestrates proposal across all predictors; manages grounding signals, tips, history, and temperature. |
| `GenerateModuleInstruction` | `dspy.Module` | Generates a single instruction for a single predictor using all configured grounding signals. |
| `DescribeProgram` | `dspy.Signature` | Produces a natural-language summary of what the whole program does. |
| `DescribeModule` | `dspy.Signature` | Produces a natural-language description of one module's role in the program. |
| `generate_instruction_class()` | Factory function | Dynamically builds a `dspy.Predict` signature whose input fields depend on the enabled grounding options. |

---

## Class Hierarchy

```mermaid
classDiagram
    class Proposer {
        <<abstract>>
        +propose_instructions_for_program()
        +propose_instruction_for_predictor()
    }
    class GroundedProposer {
        +prompt_model
        +program_aware
        +use_dataset_summary
        +use_task_demos
        +use_instruct_history
        +use_tip
        +set_tip_randomly
        +set_history_randomly
        +rng
        +propose_instructions_for_program(trainset, program, demo_candidates, trial_logs, N, T)
        +propose_instruction_for_predictor(...)
    }
    class GenerateModuleInstruction {
        +forward(demo_candidates, pred_i, demo_set_i, program, previous_instructions, data_summary, num_demos_in_context, tip)
    }
    Proposer <|-- GroundedProposer
    GroundedProposer ..> GenerateModuleInstruction : creates
```

---

## Proposer Base Class

`Proposer` (`dspy/propose/propose_base.py`) is a minimal abstract base class that establishes the interface all proposers must implement.

```python
class Proposer(ABC):
    @abstractmethod
    def propose_instructions_for_program(self):
        pass

    def propose_instruction_for_predictor(self):
        pass
```

- `propose_instructions_for_program` is **abstract** — subclasses must return the full set of new instructions for the program.
- `propose_instruction_for_predictor` is a non-abstract hook for generating a single predictor's instruction.

This separation allows alternative proposer strategies to be plugged into optimizers without changing the optimizer code.

---

## GroundedProposer

`GroundedProposer` is the concrete implementation. It is constructed once per optimization run and then asked to propose instructions.

### Constructor Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `prompt_model` | — | The LM used to generate instructions. Falls back to `dspy.settings.lm` via `get_prompt_model`. |
| `program` | — | The DSPy program whose predictors will receive new instructions. |
| `trainset` | — | Training examples, used to build the dataset summary. |
| `view_data_batch_size` | `10` | Number of examples shown to the dataset summarizer per batch. |
| `use_dataset_summary` | `True` | Enable data-aware grounding. |
| `program_aware` | `True` | Enable program-source-code grounding. |
| `use_task_demos` | `True` | Include few-shot task demonstrations as grounding. |
| `num_demos_in_context` | `3` | Max demos included per instruction generation. |
| `use_instruct_history` | `True` | Include previously attempted instructions and scores. |
| `use_tip` | `True` | Include a prompting tip. |
| `set_tip_randomly` | `True` | Randomly choose a tip each proposal round. |
| `set_history_randomly` | `True` | Randomly toggle history usage each round. |
| `verbose` | `False` | Print intermediate grounding artifacts. |
| `rng` | `random` | Random source (allows deterministic seeding). |

### Initialization Flow

During construction, `GroundedProposer` eagerly prepares the two most expensive grounding signals, each guarded by a try/except that gracefully degrades the proposer if the signal cannot be produced:

```mermaid
flowchart TD
    Start([__init__]) --> PM[Resolve prompt_model via get_prompt_model]
    PM --> PA{program_aware?}
    PA -- yes --> SRC[get_dspy_source_code program]
    SRC -- success --> SRCok[store program_code_string]
    SRC -- error --> PAoff[set program_aware = False]
    PA -- no --> DS
    SRCok --> DS{use_dataset_summary?}
    PAoff --> DS
    DS -- yes --> SUM[create_dataset_summary trainset]
    SUM -- success --> SUMok[store data_summary]
    SUM -- error --> DSoff[set use_dataset_summary = False]
    DS -- no --> Done([ready])
    SUMok --> Done
    DSoff --> Done
```

This "fail-soft" design means a proposer can still run even if source-code extraction or dataset summarization fails — it simply drops the corresponding grounding signal.

---

## Instruction Proposal Process

### Top-Level Flow: `propose_instructions_for_program`

This method returns a dictionary mapping each predictor index to a list of proposed instruction strings.

```mermaid
flowchart TD
    Start([propose_instructions_for_program]) --> Hist{set_history_randomly?}
    Hist -- yes --> RandHist[Randomly toggle use_instruct_history]
    Hist -- no --> Demos
    RandHist --> Demos{demo_candidates provided?}
    Demos -- no --> NoDemos[use_task_demos = False; num_demos = N]
    Demos -- yes --> HasDemos[num_demos = max len demo_candidates 0, 1]
    NoDemos --> Loop
    HasDemos --> Loop
    Loop[For each predictor pred_i] --> InnerLoop[For each demo_set_i in range num_demos, capped at N]
    InnerLoop --> Tip{set_tip_randomly?}
    Tip -- yes --> PickTip[Randomly pick a TIP]
    Tip -- no --> Gen
    PickTip --> Gen[propose_instruction_for_predictor]
    Gen --> Append[Append instruction to proposed_instructions pred_i]
    Append --> InnerLoop
    InnerLoop --> Return([Return proposed_instructions])
```

Key behaviors:

- **Randomized history:** When `set_history_randomly` is enabled, each call flips a coin to decide whether instruction history is used for this round, adding diversity across proposal rounds.
- **Randomized tips:** When `set_tip_randomly` is enabled, a tip is drawn from the `TIPS` dictionary (see below) for each generated instruction.
- **Demo-set iteration:** For each predictor, the proposer generates up to `min(N, num_demos)` instructions, one per demo set, so that different few-shot contexts yield different instruction candidates.

### The `TIPS` Dictionary

A hardcoded set of prompting strategies used to steer instruction generation:

| Key | Tip |
|-----|-----|
| `none` | `""` (no tip) |
| `creative` | "Don't be afraid to be creative when creating the new instruction!" |
| `simple` | "Keep the instruction clear and concise." |
| `description` | "Make sure your instruction is very informative and descriptive." |
| `high_stakes` | "The instruction should include a high stakes scenario in which the LM must solve the task!" |
| `persona` | 'Include a persona that is relevant to the task in the instruction (ie. "You are a ...")' |

### Per-Predictor Flow: `propose_instruction_for_predictor`

For a single predictor, this method:

1. Builds an **instruction history string** via `create_predictor_level_history_string` (top `MAX_INSTRUCT_IN_HISTORY = 5` scored instructions).
2. Instantiates a fresh `GenerateModuleInstruction` configured with the currently active grounding flags.
3. Temporarily sets the prompt model's temperature to `T + ε` (where `ε` is a small random jitter in `[0.01, 0.05]`) inside a `dspy.settings.context(lm=...)` block, then restores the original temperature.
4. Returns the stripped proposed instruction.

```mermaid
sequenceDiagram
    participant GP as GroundedProposer
    participant Hist as create_predictor_level_history_string
    participant GMI as GenerateModuleInstruction
    participant LM as prompt_model

    GP->>Hist: build history (top 5)
    Hist-->>GP: instruction_history string
    GP->>GMI: instantiate with active flags
    GP->>LM: save original temperature
    GP->>LM: set temperature = T + ε
    GP->>GMI: forward(...)
    GMI->>LM: generate instruction
    LM-->>GMI: proposed_instruction
    GMI-->>GP: Prediction(proposed_instruction)
    GP->>LM: restore original temperature
    GP-->>GP: strip_prefix + return
```

> **Note:** The temperature is mutated on the shared `prompt_model` object and restored afterward. This is not thread-safe; concurrent proposal calls on the same model instance could interfere.

---

## GenerateModuleInstruction

`GenerateModuleInstruction` is a `dspy.Module` that produces exactly one instruction for one predictor. It is the component that actually assembles the grounding context and calls the LM.

### Internal Sub-modules

- `self.describe_program` — a `dspy.Predict(DescribeProgram)` used to summarize the whole program.
- `self.describe_module` — a `dspy.Predict(DescribeModule)` used to describe the target module.
- `self.generate_module_instruction` — the dynamically-built `dspy.Predict` from `generate_instruction_class(...)`.

### `forward` Flow

```mermaid
flowchart TD
    Start([forward]) --> Basic[Read basic_instruction from signature]
    Basic --> Demos{use_task_demos?}
    Demos -- yes --> Gather[Gather up to num_demos_in_context augmented examples<br/>from current + adjacent demo sets]
    Demos -- no --> NoDemo
    Gather --> DemoCheck{task_demos empty or demo_set_i == 0?}
    NoDemo --> DemoCheck
    DemoCheck -- yes --> SetNoDemo[task_demos = 'No task demos provided.']
    DemoCheck -- no --> ProgAware
    SetNoDemo --> ProgAware{program_aware?}
    ProgAware -- yes --> Describe[describe_program → program_description]
    Describe --> ModuleCode[Build module_code from input/output fields]
    ModuleCode --> DescribeMod[describe_module → module_description]
    DescribeMod --> Gen
    ProgAware -- no --> Gen[generate_module_instruction]
    Gen --> Strip[strip_prefix proposed_instruction]
    Strip --> Return([Prediction proposed_instruction])
```

Notable details:

- **Example gathering** (`gather_examples_from_sets`): iterates over the current demo set and adjacent sets (wrapping around), yielding only examples that contain an `"augmented"` key, formatted via `create_example_string` using the predictor's signature fields.
- **Module code synthesis:** The module is rendered as `ClassName(input1, input2) -> output1, output2` by inspecting each field's `__dspy_field_type` metadata.
- **Graceful degradation:** If program description fails, `self.program_aware` is set to `False` and generation continues without program grounding.

---

## Helper Signatures

### `DescribeProgram`

Summarizes the entire program given its pseudocode and an example of use.

| Field | Direction | Description |
|-------|-----------|-------------|
| `program_code` | Input | Pseudocode for the LM program. |
| `program_example` | Input | An example of the program in use. |
| `program_description` | Output | What task the program solves and how. |

### `DescribeModule`

Describes a single module's role within the broader program.

| Field | Direction | Description |
|-------|-----------|-------------|
| `program_code` | Input | Pseudocode for the LM program. |
| `program_example` | Input | An example of the program in use. |
| `program_description` | Input | Summary of the program (from `DescribeProgram`). |
| `module` | Input | The module to describe. |
| `module_description` | Output | Description of the module's role. |

### `generate_instruction_class(...)`

A factory that returns a `dspy.Predict` wrapping a dynamically-defined signature. The signature's input fields are conditionally included based on the flags:

| Flag | Adds Input Field(s) |
|------|---------------------|
| `use_dataset_summary` | `dataset_description` |
| `program_aware` | `program_code`, `program_description`, `module`, `module_description` |
| `use_task_demos` | `task_demos` (always present) |
| `use_instruct_history` | `previous_instructions` |
| `use_tip` | `tip` |

Always-present fields: `task_demos`, `basic_instruction` (input) and `proposed_instruction` (output).

This dynamic construction ensures the LM prompt only contains the grounding signals that are actually enabled, keeping prompts focused and reducing token usage.

---

## Data Flow and Dependencies

```mermaid
graph LR
    subgraph Inputs
        Trainset[trainset]
        Program[program]
        DemoCands[demo_candidates]
        TrialLogs[trial_logs]
    end

    subgraph "propose_grounded"
        GP[GroundedProposer]
        GMI[GenerateModuleInstruction]
    end

    subgraph "Grounding Signals"
        DS[data_summary]
        SRC[program_code_string]
        HIST[instruction_history]
        DEMOS[task_demos]
        TIP[tip]
    end

    subgraph "External Modules"
        DSG["propose_dataset_summary<br/>create_dataset_summary"]
        UTILS["propose.utils"]
        TP["teleprompt.utils"]
        PRED["predict.Predict"]
        MOD["primitives.Module"]
    end

    Trainset --> DSG --> DS
    Program --> UTILS --> SRC
    TrialLogs --> UTILS --> HIST
    DemoCands --> GMI --> DEMOS
    GP --> TIP

    DS --> GMI
    SRC --> GMI
    HIST --> GMI
    DEMOS --> GMI
    TIP --> GMI

    GMI --> PRED
    GMI --> MOD
    GP --> TP
```

### External Dependencies

| Dependency | Source Module | Purpose |
|------------|---------------|---------|
| `create_dataset_summary` | [propose_dataset_summary.md](propose_dataset_summary.md) | Builds the dataset summary grounding signal. |
| `create_example_string` | `propose.utils` | Formats a demo example into a prompt string. |
| `create_predictor_level_history_string` | `propose.utils` | Aggregates and ranks prior instructions by score. |
| `get_dspy_source_code` | `propose.utils` | Extracts program source code for program-aware grounding. |
| `strip_prefix` | `propose.utils` | Removes leading labels/prefixes from generated text. |
| `get_prompt_model` | [teleprompt.md](teleprompt.md) | Resolves the LM used for proposal. |
| `get_signature` | [teleprompt.md](teleprompt.md) | Retrieves a predictor's signature. |
| `dspy.Predict` | [predict_core.md](predict_core.md) | Underlying LM-calling primitive. |
| `dspy.Module` | [primitives_module_system.md](primitives_module_system.md) | Base class for `GenerateModuleInstruction`. |

---

## Integration with Optimizers

`GroundedProposer` is consumed by instruction optimizers. The primary consumer is [`MIPROv2`](teleprompt.md), which instantiates it during its "Step 2: Propose instruction candidates" phase.

```mermaid
sequenceDiagram
    participant MIPRO as MIPROv2
    participant GP as GroundedProposer
    participant GMI as GenerateModuleInstruction
    participant LM as prompt_model

    MIPRO->>GP: __init__(program, trainset, prompt_model, flags...)
    GP->>LM: create_dataset_summary (data grounding)
    GP->>GP: get_dspy_source_code (program grounding)
    MIPRO->>GP: propose_instructions_for_program(trainset, program, demo_candidates, N, T, trial_logs)
    loop each predictor, each demo set
        GP->>GMI: forward(...)
        GMI->>LM: generate instruction
        LM-->>GMI: proposed_instruction
        GMI-->>GP: instruction
    end
    GP-->>MIPRO: {pred_i: [instructions]}
    MIPRO->>MIPRO: evaluate & select via Bayesian optimization
```

In `MIPROv2._propose_instructions`, the proposer is configured with:

- `program_aware=program_aware_proposer`
- `use_dataset_summary=data_aware_proposer`
- `use_task_demos=fewshot_aware_proposer`
- `use_tip=tip_aware_proposer`, `set_tip_randomly=tip_aware_proposer`
- `use_instruct_history=False`, `set_history_randomly=False` (history is disabled during the initial proposal phase)

The returned `instruction_candidates` dictionary is then fed into the optimizer's Optuna-based search, where each predictor's instruction is treated as a categorical parameter.

> **Related optimizers:** [`COPRO`](teleprompt.md) performs a similar instruction-optimization role but uses its own `BasicGenerateInstruction` / `GenerateInstructionGivenAttempts` signatures rather than `GroundedProposer`.

---

## Configuration Summary

The proposer's behavior is fully controlled by the boolean flags passed to `GroundedProposer` and propagated to `GenerateModuleInstruction`. The following table summarizes how each flag affects the generated prompt:

| Flag | Effect when `True` |
|------|--------------------|
| `program_aware` | Adds program source code + program/module descriptions to the prompt. |
| `use_dataset_summary` | Adds a dataset summary to the prompt. |
| `use_task_demos` | Adds few-shot task demonstrations to the prompt. |
| `use_instruct_history` | Adds previously attempted instructions with scores. |
| `use_tip` | Adds a prompting tip to the prompt. |
| `set_tip_randomly` | Randomly selects a tip per instruction. |
| `set_history_randomly` | Randomly toggles history usage per proposal round. |

---

## Error Handling and Robustness

The module is designed to **fail soft** at every grounding step:

- **Source-code extraction failure** → `program_aware` is disabled; proposal continues.
- **Dataset-summary failure** → `use_dataset_summary` is disabled; proposal continues.
- **Program-description failure** (inside `GenerateModuleInstruction.forward`) → `program_aware` is disabled for that instance; generation continues.
- **No demo candidates** → `use_task_demos` is disabled and `num_demos` defaults to `N`.

This ensures that instruction proposal never hard-fails due to a missing optional grounding signal.

---

## Constants

| Constant | Value | Location | Purpose |
|----------|-------|----------|---------|
| `MAX_INSTRUCT_IN_HISTORY` | `5` | `grounded_proposer.py` | Max prior instructions included in history. |
| `TIPS` | dict | `grounded_proposer.py` | Prompting strategies for tip-based grounding. |

---

## See Also

- [propose_dataset_summary.md](propose_dataset_summary.md) — Dataset summary generation used as a grounding signal.
- [teleprompt.md](teleprompt.md) — Optimizers (`MIPROv2`, `COPRO`) that consume the proposer.
- [predict_core.md](predict_core.md) — The `Predict` primitive used for LM calls.
- [primitives_module_system.md](primitives_module_system.md) — The `Module` base class.
- [signatures.md](signatures.md) — Signature definitions used by the helper signatures.
