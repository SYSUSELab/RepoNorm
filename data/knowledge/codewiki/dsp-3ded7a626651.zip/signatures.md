# Signatures Module

## Overview

The **signatures** module is the foundational declarative layer of DSPy. It defines the *interface contract* between a DSPy program and a language model: what inputs a module expects, what outputs it should produce, and the natural-language instructions that guide the model.

A `Signature` is a typed, Pydantic-backed specification of a task. Rather than writing raw prompts, developers declare fields with `InputField` / `OutputField` and let DSPy handle prompt construction, parsing, and validation. Signatures are consumed throughout the framework — by [predict](predict.md) modules, [adapters](adapters.md), [teleprompt](teleprompt.md) optimizers, and [propose](propose.md) instruction generators.

### Key Responsibilities

- **Declare task interfaces** — typed input/output fields with descriptions, prefixes, and formatting hints.
- **Carry instructions** — the natural-language prompt that describes the task to the LM.
- **Provide field metadata** — descriptions, prefixes, and Pydantic constraints translated into human-readable form.
- **Support dynamic construction** — build signatures from strings (`"question -> answer"`), dictionaries, or class definitions.
- **Enable introspection & mutation** — inspect, clone, and modify signatures programmatically (used heavily by optimizers).

## Architecture

The module is split into two cooperating layers: a **field layer** that defines individual fields, and a **core layer** that assembles fields into a `Signature` class via a metaclass.

```mermaid
graph TD
    subgraph "signatures module"
        subgraph "signatures_fields (field.py)"
            IF["InputField()"]
            OF["OutputField()"]
            OF2["OldField / OldInputField / OldOutputField"]
            MK["move_kwargs()"]
            TP["_translate_pydantic_field_constraints()"]
        end
        subgraph "signatures_core (signature.py)"
            SM["SignatureMeta (metaclass)"]
            SIG["Signature (BaseModel)"]
            MS["make_signature()"]
            PS["_parse_signature() / _parse_field_string()"]
            PT["_parse_type_node()"]
            IP["infer_prefix()"]
        end
    end

    IF --> MK
    OF --> MK
    MK --> TP
    IF --> SM
    OF --> SM
    SM --> SIG
    SM --> MS
    MS --> PS
    PS --> PT
    SM --> IP
    OF2 -.legacy.-> SIG
```

### Data Flow: From Declaration to Signature Class

```mermaid
sequenceDiagram
    participant User
    participant SignatureMeta
    participant make_signature
    participant _parse_signature
    participant Signature

    User->>SignatureMeta: Signature("question -> answer")
    SignatureMeta->>SignatureMeta: _detect_custom_types_from_caller()
    SignatureMeta->>make_signature: make_signature("question -> answer", custom_types)
    make_signature->>_parse_signature: parse string
    _parse_signature->>_parse_signature: _parse_field_string() via AST
    _parse_signature-->>make_signature: {field: (type, FieldInfo)}
    make_signature->>Signature: create_model(__base__=Signature)
    Signature-->>User: new Signature subclass
```

## Sub-modules

### [signatures_fields](signatures_fields.md)

Defines the field primitives used to declare inputs and outputs. It provides the modern `InputField` / `OutputField` helpers (thin wrappers over `pydantic.Field` that stash DSPy-specific metadata in `json_schema_extra`), the `move_kwargs` translation utility, and the legacy `OldField` / `OldInputField` / `OldOutputField` classes retained for backward compatibility.

**Core components:** `OldField`, `OldInputField`, `OldOutputField`, plus the `InputField` / `OutputField` factory functions.

### [signatures_core](signatures_core.md)

The heart of the module. `SignatureMeta` is a metaclass that intercepts class creation and instantiation to validate fields, infer prefixes, default instructions, and dynamically build signature classes from strings or dicts. `Signature` is the Pydantic `BaseModel` subclass that exposes introspection properties (`input_fields`, `output_fields`, `fields`, `signature`, `instructions`) and mutation helpers (`with_instructions`, `with_updated_fields`, `prepend`, `append`, `insert`, `delete`, `equals`, `dump_state`, `load_state`).

**Core components:** `Signature`, `SignatureMeta`, plus module-level helpers `make_signature`, `ensure_signature`, `_parse_signature`, `_parse_field_string`, `_parse_type_node`, `infer_prefix`.

## How the Module Fits into DSPy

Signatures are the declarative backbone consumed across the framework:

```mermaid
graph LR
    SIG["signatures"]
    PRED["predict"]
    ADP["adapters"]
    TP["teleprompt"]
    PROP["propose"]
    PRIM["primitives"]

    SIG --> PRED
    SIG --> ADP
    SIG --> TP
    SIG --> PROP
    SIG --> PRIM
```

- **[predict](predict.md)** — `Predict` and its strategies (`ChainOfThought`, `ReAct`, etc.) wrap a `Signature` and execute it against an LM.
- **[adapters](adapters.md)** — `ChatAdapter`, `JSONAdapter`, `XMLAdapter` render a `Signature`'s fields and instructions into provider-specific prompt formats.
- **[teleprompt](teleprompt.md)** — optimizers mutate signatures (instructions, field descriptions) via `with_instructions` / `with_updated_fields`.
- **[propose](propose.md)** — instruction proposers generate new instructions for signatures.
- **[primitives](primitives.md)** — `Example` and `Prediction` mirror signature fields as data containers.

## Design Notes

- **Pydantic-backed:** Every `Signature` is a Pydantic model, giving free validation, serialization, and JSON-schema generation.
- **Metadata in `json_schema_extra`:** DSPy-specific field attributes (`desc`, `prefix`, `format`, `parser`, `__dspy_field_type`) are stored in Pydantic's `json_schema_extra` to avoid name clashes with standard `Field` arguments.
- **String-based signatures:** `Signature("a, b -> c")` uses Python's AST to parse field names and type annotations, with optional frame introspection to resolve custom types.
- **Immutability by convention:** Mutation helpers return *new* `Signature` classes rather than modifying in place, which is essential for optimizer workflows.
