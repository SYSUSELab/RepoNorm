# Adapters

## Overview

The **Adapters** module is the translation layer between DSPy's structured, typed programming model and the raw
message-based interface of Large Language Models (LMs). A DSPy program is defined by a
[`Signature`](signatures.md) — a typed declaration of input and output fields — but LMs only understand lists of
chat messages. Adapters bridge this gap in both directions:

- **Formatting (DSPy → LM):** Convert a signature, few-shot demonstrations, conversation history, and the current
  inputs into a list of chat messages that instruct the LM how to respond.
- **Parsing (LM → DSPy):** Convert the LM's raw text (or native tool-call payloads) back into a dictionary of typed
  output fields, raising a structured error when parsing fails.

Adapters are invoked by the [`Predict`](predict.md) module (and its subclasses such as `ChainOfThought` and `ReAct`)
through the [`LM`](clients.md) client. They are also the mechanism that enables **custom types** (images, audio,
tools, conversation history) to be embedded inside signatures and serialized into LM-native content parts.

## Architecture

The module is organized into two cooperating layers:

1. **Core adapters** — the `Adapter` base class and its concrete implementations (`ChatAdapter`, `JSONAdapter`,
   `XMLAdapter`, `TwoStepAdapter`). These own the format/parse lifecycle.
2. **Adapter types** — the `BaseType` hierarchy (`Image`, `Audio`, `History`, `Tool`, `ToolCalls`) that defines
   custom field types and how they serialize into LM content.

```mermaid
graph TD
    subgraph "Core Adapters"
        A[Adapter<br/>base.py]
        CA[ChatAdapter<br/>chat_adapter.py]
        JA[JSONAdapter<br/>json_adapter.py]
        XA[XMLAdapter<br/>xml_adapter.py]
        TSA[TwoStepAdapter<br/>two_step_adapter.py]
    end

    subgraph "Adapter Types"
        BT[BaseType<br/>base_type.py]
        IMG[Image]
        AUD[Audio]
        HIST[History]
        TOOL[Tool]
        TC[ToolCalls]
    end

    A --> CA
    CA --> JA
    CA --> XA
    A --> TSA

    BT --> IMG
    BT --> AUD
    BT --> TOOL
    BT --> TC
    HIST -.->|pydantic model| BT

    CA -.->|uses| BT
    A -.->|uses| HIST
    A -.->|uses| TOOL
    A -.->|uses| TC
```

### Call Lifecycle

Every adapter implements the same high-level lifecycle, orchestrated by `Adapter.__call__` / `Adapter.acall`:

```mermaid
sequenceDiagram
    participant P as Predict
    participant Ad as Adapter
    participant LM as LM Client

    P->>Ad: __call__(lm, lm_kwargs, signature, demos, inputs)
    Ad->>Ad: _call_preprocess()<br/>(native function calling setup)
    Ad->>Ad: format()<br/>(signature + demos + inputs → messages)
    Ad->>LM: lm(messages=..., **lm_kwargs)
    LM-->>Ad: raw outputs (text / tool_calls / logprobs)
    Ad->>Ad: _call_postprocess()<br/>(parse() each output)
    Ad-->>P: list[dict] of typed output fields
```

Key extension points that concrete adapters override:

| Method | Responsibility |
| --- | --- |
| `format_field_description` | Describe input/output fields in the system message |
| `format_field_structure` | Specify the wire format the LM must follow |
| `format_task_description` | Emit the task instructions (usually from `signature.instructions`) |
| `format_user_message_content` | Render input fields into a user message |
| `format_assistant_message_content` | Render output fields into an assistant message |
| `parse` | Extract typed output fields from the LM response |

## Sub-modules

### Core Adapters

The core adapters implement the format/parse contract and provide several interchangeable wire formats. See
**[adapters_core.md](adapters_core.md)** for full details.

- **`Adapter`** — abstract base class defining the lifecycle, callback decoration, native function-calling
  preprocessing, conversation-history handling, and demo formatting.
- **`ChatAdapter`** — the default adapter. Uses `[[ ## field_name ## ]]` section markers and falls back to
  `JSONAdapter` on failure.
- **`JSONAdapter`** — extends `ChatAdapter` to request JSON output, preferring provider-native *structured outputs*
  (Pydantic-derived JSON schema) and falling back to JSON mode.
- **`XMLAdapter`** — extends `ChatAdapter` to wrap fields in XML tags (`<field>...</field>`).
- **`TwoStepAdapter`** — uses a natural-language prompt for a (reasoning) main LM, then a smaller extraction LM with
  `ChatAdapter` to recover structured fields.

### Adapter Types

The adapter types define custom field types and their serialization into LM-native content. See
**[adapters_types.md](adapters_types.md)** for full details.

- **`BaseType`** — parent class for all custom types; subclasses implement `format()` to emit OpenAI-style content
  parts.
- **`Image`** — encodes images (URL, file, PIL) as base64 image content parts.
- **`Audio`** — encodes audio (URL, file, numpy array) as base64 input-audio content parts.
- **`History`** — a frozen Pydantic model holding conversation history messages.
- **`Tool` / `ToolCalls`** — wrap Python callables for function calling and represent the LM's tool-call responses.

## How Adapters Fit Into the System

```mermaid
graph LR
    SIG[Signature<br/>signatures.md] --> PRED[Predict<br/>predict.md]
    PRED --> AD[Adapter]
    AD --> LM[LM Client<br/>clients.md]
    LM --> PROV[Provider<br/>clients.md]
    AD --> TYPES[Adapter Types]
    AD --> EXC[AdapterParseError<br/>utils.md]
    AD --> CB[BaseCallback<br/>utils.md]
```

- **Signatures** ([signatures.md](signatures.md)) supply the field definitions and instructions that adapters
  format.
- **Predict** ([predict.md](predict.md)) selects and invokes the configured adapter.
- **LM clients** ([clients.md](clients.md)) receive the formatted messages and return raw completions.
- **Callbacks** ([utils.md](utils.md)) are attached to `format` and `parse` via `with_callbacks`, enabling
  observability.
- **`AdapterParseError`** ([utils.md](utils.md)) is raised when parsing fails, carrying the LM response and the
  expected/actual fields for debugging.

## Configuration

Adapters are configured globally or per-module via `dspy.configure(adapter=...)`:

```python
import dspy

# Default chat-based adapter
dspy.configure(lm=dspy.LM("openai/gpt-4o-mini"), adapter=dspy.ChatAdapter())

# JSON structured outputs
dspy.configure(adapter=dspy.JSONAdapter())

# Two-step for reasoning models
dspy.configure(
    lm=dspy.LM("openai/o3-mini"),
    adapter=dspy.TwoStepAdapter(dspy.LM("openai/gpt-4o-mini")),
)
```

## Related Documentation

- [adapters_core.md](adapters_core.md) — Detailed documentation of the adapter implementations.
- [adapters_types.md](adapters_types.md) — Detailed documentation of custom field types.
- [signatures.md](signatures.md) — Signature definitions consumed by adapters.
- [predict.md](predict.md) — The module that invokes adapters.
- [clients.md](clients.md) — LM clients that adapters call.
- [utils.md](utils.md) — Callbacks and the `AdapterParseError` exception.
