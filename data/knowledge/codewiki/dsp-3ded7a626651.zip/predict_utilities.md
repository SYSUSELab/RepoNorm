# Predict Utilities

## Introduction

The `predict_utilities` module provides two foundational utility components used across DSPy's prediction strategies:

- **`Parallel`** — a concurrency orchestrator that runs a module over many inputs in parallel using a thread pool, with error tolerance, cancellation, and optional failed-example reporting.
- **`KNN`** — a k-nearest-neighbors retriever that finds the most similar examples from a training set based on embedding similarity.

These utilities are deliberately lightweight and composable. They are not prediction strategies themselves (see [predict_strategies.md](predict_strategies.md)), but rather building blocks that strategies and optimizers rely on for batch execution and example retrieval.

---

## Module Architecture

The module sits between the higher-level prediction strategies and the lower-level infrastructure (settings, parallel execution, embeddings, and primitives).

```mermaid
graph TD
    subgraph "predict_utilities"
        Parallel["Parallel<br/>(parallel.py)"]
        KNN["KNN<br/>(knn.py)"]
    end

    subgraph "Infrastructure"
        ParallelExecutor["ParallelExecutor<br/>(utils/parallelizer.py)"]
        Settings["Settings<br/>(dsp/utils/settings.py)"]
        Embedder["Embedder<br/>(clients/embedding.py)"]
        Example["Example<br/>(primitives/example.py)"]
    end

    subgraph "Consumers"
        Strategies["Prediction Strategies<br/>(predict_strategies.md)"]
        Optimizers["Teleprompters / Optimizers"]
    end

    Parallel --> ParallelExecutor
    Parallel --> Settings
    Parallel --> Example
    KNN --> Embedder
    KNN --> Example

    Strategies --> Parallel
    Strategies --> KNN
    Optimizers --> Parallel
    Optimizers --> KNN
```

---

## Component Overview

| Component | File | Responsibility |
|-----------|------|----------------|
| `Parallel` | `dspy/predict/parallel.py` | Executes a module over a list of `(module, example)` pairs concurrently. |
| `KNN` | `dspy/predict/knn.py` | Retrieves the `k` most similar training examples for a given input. |

---

## Parallel

`Parallel` is a callable wrapper that distributes the execution of a module across multiple threads. It is the primary mechanism for batch inference in DSPy.

### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `num_threads` | `Optional[int]` | `settings.num_threads` | Number of worker threads. Falls back to the global setting. |
| `max_errors` | `Optional[int]` | `settings.max_errors` | Maximum number of errors tolerated before cancelling all jobs. |
| `access_examples` | `bool` | `True` | If `True`, `Example` inputs are unpacked via `example.inputs()` and passed as keyword arguments. |
| `return_failed_examples` | `bool` | `False` | If `True`, returns a tuple of `(results, failed_examples, exceptions)`. |
| `provide_traceback` | `Optional[bool]` | `None` | Whether to log full tracebacks on errors. Falls back to settings. |
| `disable_progress_bar` | `bool` | `False` | Suppresses the `tqdm` progress bar. |

### Internal State

- `error_count` / `error_lock` — thread-safe error accounting.
- `cancel_jobs` — a `threading.Event` used to signal cancellation across threads.
- `failed_examples` / `exceptions` — collected when `return_failed_examples=True`.

### Input Handling

The `forward` method accepts a list of `(module, example)` tuples. Each `example` is dispatched based on its type:

```mermaid
flowchart TD
    Start["process_pair((module, example))"] --> TypeCheck{"Type of example?"}
    TypeCheck -->|Example| AccessCheck{"access_examples?"}
    AccessCheck -->|True| Kwargs["module(**example.inputs())"]
    AccessCheck -->|False| Positional["module(example)"]
    TypeCheck -->|dict| DictCall["module(**example)"]
    TypeCheck -->|list & module is Parallel| Nested["module(example)"]
    TypeCheck -->|tuple| TupleCall["module(*example)"]
    TypeCheck -->|other| Error["raise ValueError"]
```

This flexible dispatch allows `Parallel` to be nested (a `Parallel` inside a `Parallel`) and to accept raw dictionaries, tuples, or DSPy `Example` objects.

### Execution Flow

```mermaid
sequenceDiagram
    participant Caller
    participant Parallel
    participant ParallelExecutor
    participant WorkerThreads

    Caller->>Parallel: forward(exec_pairs, num_threads)
    Parallel->>ParallelExecutor: __init__(num_threads, max_errors, ...)
    Parallel->>ParallelExecutor: execute(process_pair, exec_pairs)
    ParallelExecutor->>WorkerThreads: submit(worker, ...) per item
    WorkerThreads-->>ParallelExecutor: results / errors
    ParallelExecutor-->>Parallel: results list
    alt return_failed_examples
        Parallel-->>Caller: (results, failed_examples, exceptions)
    else
        Parallel-->>Caller: results
    end
```

### Relationship to `ParallelExecutor`

`Parallel` is a thin, DSPy-aware facade over [`ParallelExecutor`](utils.md). The executor handles the low-level concerns:

- Thread pool management (`ThreadPoolExecutor`).
- Thread-local settings isolation (via `thread_local_overrides`).
- Straggler detection and resubmission (timeout-based).
- `SIGINT` (Ctrl-C) handling and graceful cancellation.
- Progress bar updates.

`Parallel` adds the DSPy-specific input dispatch logic and the failed-example collection interface. See [utils.md](utils.md) for details on `ParallelExecutor`.

### Settings Integration

`Parallel` reads defaults from the global [`Settings`](dsp_settings.md) singleton:

- `settings.num_threads`
- `settings.max_errors`
- `settings.provide_traceback`

Because `ParallelExecutor` copies thread-local overrides into worker threads, any `dspy.context(...)` block active when `Parallel` is invoked propagates its configuration to all worker threads.

---

## KNN

`KNN` is a k-nearest-neighbors retriever that, given an input, returns the most similar examples from a training set. It is commonly used for few-shot example selection (e.g., by `KNNFewShot` in the teleprompt module).

### Constructor Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `k` | `int` | Number of nearest neighbors to retrieve. |
| `trainset` | `list[Example]` | The pool of training examples to search. |
| `vectorizer` | `Embedder` | The embedding model used to vectorize examples and queries. |

### Initialization Behavior

During construction, `KNN` pre-computes embeddings for the entire training set:

1. Each `Example` is serialized into a string of the form `"key1: value1 | key2: value2 | ..."`, using only the example's **input keys** (`example._input_keys`).
2. The serialized strings are embedded in a single batch via the `vectorizer`.
3. The resulting vectors are stored as `trainset_vectors` (cast to `np.float32`).

### Query Flow

```mermaid
flowchart TD
    Query["__call__(**kwargs)"] --> Serialize["Serialize kwargs to 'key: val | ...'"]
    Serialize --> Embed["vectorizer([serialized_query])"]
    Embed --> Dot["scores = dot(trainset_vectors, query_vector.T)"]
    Dot --> Sort["argsort(scores)[-k:][::-1]"]
    Sort --> Return["Return top-k trainset Examples"]
```

The similarity metric is the **dot product** between the query embedding and each training-set embedding. The top `k` indices (highest scores) are selected and the corresponding `Example` objects are returned.

### Dependencies

- [`Embedder`](clients_lm_core.md) — provides the unified embedding interface (hosted models via litellm or custom callables).
- [`Example`](primitives.md) — the data primitive whose `_input_keys` and `items()` drive serialization.

### Usage Example

```python
import dspy
from sentence_transformers import SentenceTransformer

trainset = [
    dspy.Example(input="hello", output="world"),
    # ... more examples ...
]

knn = KNN(
    k=3,
    trainset=trainset,
    vectorizer=dspy.Embedder(SentenceTransformer("all-MiniLM-L6-v2").encode),
)

similar_examples = knn(input="hello")
```

---

## Component Interaction Summary

```mermaid
graph LR
    subgraph "Parallel path"
        P["Parallel"] --> PE["ParallelExecutor"]
        PE --> TL["thread_local_overrides"]
        P --> S["Settings"]
    end

    subgraph "KNN path"
        K["KNN"] --> E["Embedder"]
        K --> NP["numpy"]
    end

    P --> EX["Example"]
    K --> EX
```

Both utilities share a dependency on the [`Example`](primitives.md) primitive, but serve orthogonal purposes:

- `Parallel` is about **throughput** — running many predictions concurrently.
- `KNN` is about **retrieval** — selecting relevant examples for in-context learning.

---

## Design Notes

- **Error tolerance**: `Parallel` never raises on individual item failures unless `max_errors` is exceeded or cancellation is triggered. Failed items yield `None` in the results list.
- **Nesting**: `Parallel` supports nested `Parallel` instances, enabling hierarchical batch execution.
- **Thread safety**: Both the error counter and cancellation event in `Parallel` are guarded by locks/events, making it safe under concurrent execution.
- **Determinism**: `KNN` uses a stable dot-product ranking; ties are broken by `argsort` ordering.

---

## Related Documentation

- [predict_strategies.md](predict_strategies.md) — prediction strategies that consume these utilities.
- [predict_core.md](predict_core.md) — the core `Predict` and `Parameter` primitives.
- [utils.md](utils.md) — `ParallelExecutor` and other general utilities.
- [dsp_settings.md](dsp_settings.md) — the global `Settings` singleton.
- [clients_lm_core.md](clients_lm_core.md) — `Embedder`, `LM`, and `BaseLM`.
- [primitives.md](primitives.md) — `Example`, `Prediction`, and other data primitives.
