# SIMBA (Stochastic Introspective Mini-Batch Ascent)

## Introduction

The **SIMBA** module (`dspy/teleprompt/simba.py`) implements the *Stochastic Introspective Mini-Batch Ascent* optimizer, a DSPy teleprompter that iteratively improves a program by:

1. **Sampling trajectories** of the current program pool on mini-batches of training data using multiple language models at varying temperatures.
2. **Introspecting** on the best and worst trajectories within each mini-batch to generate natural-language *advice* (rules) or to append successful *demonstrations*.
3. **Ascending** by building new candidate programs from the best-performing buckets and registering them into a growing global program pool.

Unlike gradient-based optimizers, SIMBA operates entirely through prompt-level modifications (instructions and demos) and uses a stochastic, score-weighted selection process to balance exploration and exploitation. It is a member of the [teleprompt](teleprompt_core.md) family and builds on the shared `Teleprompter` base class.

---

## Module Structure

The module consists of two files:

| File | Core Components | Responsibility |
|------|-----------------|----------------|
| `dspy/teleprompt/simba.py` | `SIMBA` | Orchestrates the optimization loop, program pool management, and candidate selection. |
| `dspy/teleprompt/simba_utils.py` | `OfferFeedback`, `append_a_demo`, `append_a_rule`, `wrap_program`, `prepare_models_for_resampling`, `inspect_modules`, `recursive_mask` | Provides the strategy functions, trajectory wrapping, model resampling, and the introspection signature. |

---

## Architecture Overview

```mermaid
graph TD
    subgraph "SIMBA Module"
        SIMBA["SIMBA<br/>(Teleprompter)"]
        OfferFeedback["OfferFeedback<br/>(Signature)"]
        append_demo["append_a_demo<br/>(strategy)"]
        append_rule["append_a_rule<br/>(strategy)"]
        wrap["wrap_program"]
        prep_models["prepare_models_for_resampling"]
        inspect["inspect_modules"]
        mask["recursive_mask"]
    end

    subgraph "DSPy Core"
        Teleprompter["Teleprompter"]
        Module["Module"]
        Example["Example"]
        Parallel["Parallel"]
        LM["LM"]
        Settings["Settings"]
        Predict["Predict"]
    end

    SIMBA -->|inherits| Teleprompter
    SIMBA -->|uses| append_demo
    SIMBA -->|uses| append_rule
    SIMBA -->|uses| wrap
    SIMBA -->|uses| prep_models
    SIMBA -->|runs| Parallel
    SIMBA -->|operates on| Module
    SIMBA -->|evaluates on| Example

    append_rule -->|invokes| Predict
    append_rule -->|uses| OfferFeedback
    append_rule -->|uses| inspect
    append_rule -->|uses| mask
    prep_models -->|copies| LM
    wrap -->|reads| Settings
```

---

## Component Relationships

```mermaid
classDiagram
    class Teleprompter {
        +compile(student, trainset, ...)
        +get_params()
    }
    class SIMBA {
        +metric: Callable
        +bsize: int
        +num_candidates: int
        +max_steps: int
        +max_demos: int
        +strategies: list
        +compile(student, trainset, seed)
    }
    class OfferFeedback {
        <<Signature>>
        +program_code
        +modules_defn
        +better_program_trajectory
        +worse_program_trajectory
        +module_advice: dict
    }

    Teleprompter <|-- SIMBA
    SIMBA ..> OfferFeedback : uses via append_a_rule
```

---

## The `SIMBA` Class

### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `metric` | `Callable` | *required* | Function `(example, prediction) -> float` used to score program outputs. |
| `bsize` | `int` | `32` | Mini-batch size for each optimization step. |
| `num_candidates` | `int` | `6` | Number of new candidate programs produced per iteration. |
| `max_steps` | `int` | `8` | Number of optimization steps (batches) to run. |
| `max_demos` | `int` | `4` | Maximum demos a predictor may hold before some are dropped. If `0`, only rule-based strategies are used. |
| `demo_input_field_maxlen` | `int` | `100_000` | Max characters retained in an input field when building a demo (longer values are truncated). |
| `num_threads` | `int` | `None` | Threads for parallel execution (defaults to `dspy.settings.num_threads`). |
| `temperature_for_sampling` | `float` | `0.2` | Softmax temperature for selecting programs during trajectory sampling. |
| `temperature_for_candidates` | `float` | `0.2` | Softmax temperature for selecting the source program when building candidates. |

### Strategy Selection

The set of strategies is determined at construction time:

```python
if self.max_demos > 0:
    self.strategies = [append_a_demo(demo_input_field_maxlen), append_a_rule]
else:
    self.strategies = [append_a_rule]
```

- **`append_a_demo`** — adds a successful demonstration to each predictor.
- **`append_a_rule`** — generates natural-language advice via the `OfferFeedback` signature and appends it to predictor instructions.

---

## The `compile` Method

`compile(student, *, trainset, seed=0)` is the main entry point. It returns the best program found, annotated with `candidate_programs` (a sorted list of `{"score", "program"}` dicts) and `trial_logs`.

### High-Level Process Flow

```mermaid
flowchart TD
    Start([compile]) --> Check["Assert len(trainset) >= bsize"]
    Check --> Init["Initialize RNG, program pool<br/>baseline program idx=0"]
    Init --> Loop{"For each batch<br/>(max_steps)"}

    Loop --> GetBatch["STEP 1: Get next mini-batch<br/>(shuffle when exhausted)"]
    GetBatch --> PrepModels["Prepare LMs at varied temperatures<br/>+ top-k programs"]
    PrepModels --> Sample["Softmax-sample program per (model, example)<br/>wrap_program -> exec_pairs"]
    Sample --> Exec1["STEP 2: Execute in parallel"]
    Exec1 --> Bucket["STEP 3: Bucket by example,<br/>sort by (max-min gap, max, max-avg gap)"]
    Bucket --> Build["STEP 4: Build candidates<br/>drop demos + apply strategy"]
    Build --> Exec2["STEP 5: Evaluate candidates on mini-batch"]
    Exec2 --> Score["STEP 6: Compute avg scores"]
    Score --> Win["STEP 7: Record best candidate as winning"]
    Win --> Register["STEP 8: Register candidates in global pool"]
    Register --> Loop

    Loop -->|done| Select["Select evenly-spaced winning programs"]
    Select --> Validate["Validate on full trainset"]
    Validate --> Return["Return best program<br/>+ candidate_programs + trial_logs"]
    Return --> End([end])
```

### Step-by-Step Detail

#### Step 1 — Mini-Batch Selection
Data indices are shuffled once and consumed sequentially. When the remaining data is smaller than `bsize`, the indices are reshuffled and iteration restarts from the beginning.

#### Step 2 — Trajectory Sampling
For each of the `num_candidates` models (produced by `prepare_models_for_resampling`) and each example in the batch, a program is chosen from the top-k pool via **softmax sampling** weighted by average score. The chosen program is deep-copied, assigned the model, wrapped with `wrap_program`, and executed in parallel.

#### Step 3 — Bucketing & Sorting
Outputs are grouped by example (each bucket has `num_candidates` entries) and sorted by a composite key `(max_to_min_gap, max_score, max_to_avg_gap)` in descending order. This prioritizes examples with the largest performance spread — the most informative for learning.

#### Step 4 — Candidate Construction
For each top bucket:
1. A source program is softmax-sampled from the top-k pool.
2. A Poisson-distributed number of demos is dropped from each predictor (controlled by `max_demos`).
3. A strategy (`append_a_demo` or `append_a_rule`) is randomly chosen and applied.

#### Steps 5–8 — Evaluation, Selection, Registration
Candidates are evaluated on the same mini-batch, scored, and the best is recorded as a "winning" program. All candidates are registered into the global pool with their per-example scores, expanding the pool for future softmax sampling.

### Final Selection & Validation
After all steps, `num_candidates + 1` winning programs are selected at evenly-spaced indices, deep-copied, and evaluated on the **full trainset**. The highest-scoring program is returned.

---

## Strategy Functions (`simba_utils.py`)

### `wrap_program(program, metric)`

Wraps a program so that executing it on an example returns a dict containing the `prediction`, the execution `trace`, the `score`, and the original `example`. It captures the trace via `dspy.context(trace=[])` and gracefully handles exceptions from both the program and the metric.

```mermaid
sequenceDiagram
    participant SIMBA
    participant wrap_program
    participant Program
    participant Metric
    SIMBA->>wrap_program: wrapped_program(example)
    wrap_program->>Program: program(**example.inputs())
    Program-->>wrap_program: prediction
    wrap_program->>wrap_program: capture dspy.settings.trace
    wrap_program->>Metric: metric(example, prediction)
    Metric-->>wrap_program: score
    wrap_program-->>SIMBA: {prediction, trace, score, example}
```

### `prepare_models_for_resampling(program, n)`

Creates `n` copies of the program's LM with distinct temperatures: the original temperature plus a spread from `0.5` to `1.0`. This diversity drives exploration during trajectory sampling.

### `append_a_demo(demo_input_field_maxlen)`

Returns a strategy that extracts the trace of the best trajectory in a bucket and appends one demonstration per predictor. Input fields exceeding `demo_input_field_maxlen` are truncated with a `<TRUNCATED FOR BREVITY>` marker.

### `append_a_rule`

A strategy that generates natural-language advice by contrasting a **better** and **worse** trajectory:

1. **Guard clause** — skips rule generation if the good score is below the batch's 10th percentile or the bad score is above the 90th percentile (i.e., the contrast is not informative).
2. **Trajectory serialization** — converts both traces into structured dicts keyed by module name.
3. **Introspection** — invokes `dspy.Predict(OfferFeedback)` with program code, module definitions, inputs, oracle metadata, and both trajectories.
4. **Instruction update** — appends the returned per-module advice to each predictor's signature instructions.

```mermaid
flowchart LR
    Bucket["Bucket (sorted)"] --> Good["good = bucket[0]"]
    Bucket --> Bad["bad = bucket[-1]"]
    Good --> Guard{"good < 10p<br/>OR bad > 90p?"}
    Bad --> Guard
    Guard -->|yes| Skip["Skip (return False)"]
    Guard -->|no| Serialize["Serialize trajectories"]
    Serialize --> Predict["dspy.Predict(OfferFeedback)"]
    Predict --> Advice["module_advice dict"]
    Advice --> Update["Append advice to<br/>predictor instructions"]
```

### `OfferFeedback` Signature

A `dspy.Signature` that instructs the LM to analyze two trajectories and produce:
- `discussion` — blame analysis of where each module went wrong.
- `module_advice` — a `dict[str, str]` mapping each module name to concrete, generalizable advice.

Inputs include `program_code`, `modules_defn`, `program_inputs`, `oracle_metadata`, both trajectories and their outputs, both reward values, and `module_names`.

### Helper Functions

- **`inspect_modules(program)`** — produces a formatted string describing each predictor's input/output fields and original instructions, using `get_field_description_string` from the [adapters](adapters_core.md) module.
- **`recursive_mask(o)`** — recursively replaces non-JSON-serializable objects with placeholder strings so trajectories can be safely serialized via `ujson`.

---

## Dependencies

```mermaid
graph LR
    SIMBA --> simba_utils
    SIMBA --> Teleprompter["Teleprompter<br/>(teleprompt_core)"]
    SIMBA --> Parallel["Parallel<br/>(predict_utilities)"]
    SIMBA --> Module["Module<br/>(primitives_module_system)"]
    SIMBA --> Example["Example<br/>(primitives_data_containers)"]
    simba_utils --> LM["LM<br/>(clients_lm_core)"]
    simba_utils --> Settings["Settings<br/>(dsp_settings)"]
    simba_utils --> Predict["Predict<br/>(predict_core)"]
    simba_utils --> Signature["Signature<br/>(signatures_core)"]
    simba_utils --> AdapterUtils["get_field_description_string<br/>(adapters_core)"]
```

| Dependency | Purpose |
|------------|---------|
| [`Teleprompter`](teleprompt_core.md) | Base class defining the `compile` interface. |
| [`Parallel`](predict_utilities.md) | Parallel execution of `(program, example)` pairs. |
| [`Module`](primitives_module_system.md) | Program abstraction; provides `named_predictors`, `deepcopy`, `set_lm`, `get_lm`. |
| [`Example`](primitives_data_containers.md) | Data container for training instances and demos. |
| [`LM`](clients_lm_core.md) | Language model; copied with varied temperatures for resampling. |
| [`Settings`](dsp_settings.md) | Global/thread-local configuration, including trace capture. |
| [`Predict`](predict_core.md) | Runs the `OfferFeedback` signature. |
| [`Signature`](signatures_core.md) | Defines the `OfferFeedback` introspection interface. |
| [`get_field_description_string`](adapters_core.md) | Formats field descriptions for module introspection. |

---

## Usage Example

```python
import dspy
from dspy.teleprompt import SIMBA

# Define a metric
def metric(example, prediction, trace=None):
    return float(prediction.answer == example.answer)

# Configure the LM
lm = dspy.LM("openai/gpt-4o-mini", temperature=0.0)
dspy.configure(lm=lm)

# Instantiate and compile
optimizer = SIMBA(
    metric=metric,
    bsize=32,
    num_candidates=6,
    max_steps=8,
    max_demos=4,
)
optimized_program = optimizer.compile(student=my_program, trainset=trainset, seed=0)

# Inspect results
print(optimized_program.candidate_programs)  # sorted [{score, program}]
print(optimized_program.trial_logs)          # per-step train scores
```

---

## Key Design Notes

- **Stochastic exploration** — Softmax sampling over program scores (with configurable temperatures) balances exploitation of high-scoring programs with exploration of the broader pool.
- **Introspective learning** — The `OfferFeedback` signature converts trajectory contrasts into reusable, module-specific natural-language rules, avoiding boilerplate.
- **Mini-batch ascent** — Bucketing by performance spread focuses optimization effort on the most informative examples.
- **Pool growth** — Every candidate is registered in the global pool, so the search space expands over time.
- **Robustness** — Both `wrap_program` and the strategy invocation are wrapped in try/except blocks, logging errors rather than aborting the run.

---

## Related Modules

- [teleprompt_core](teleprompt_core.md) — Base `Teleprompter` and other core optimizers.
- [teleprompt_instruction](teleprompt_instruction.md) — Instruction-focused optimizers (COPRO, MIPROv2).
- [teleprompt_bootstrap](teleprompt_bootstrap.md) — Bootstrap-based few-shot optimizers.
- [predict_core](predict_core.md) — The `Predict` module used for introspection.
- [signatures_core](signatures_core.md) — Signature definitions.
- [clients_lm_core](clients_lm_core.md) — Language model clients.
