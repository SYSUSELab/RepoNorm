# Adapter Types

## Overview

The **adapter_types** module provides the foundational type system used by DSPy's adapters to represent rich, non-textual data (images, audio, conversation history, and tool calls) within signatures and LM interactions. These types bridge the gap between Python objects and the structured content formats expected by language model APIs (e.g., OpenAI's multimodal message format).

The module is centered around a single extensible base class, `BaseType`, which defines a uniform contract (`format()`) that all custom types implement. Concrete types such as `Image`, `Audio`, `History`, and `Tool`/`ToolCalls` build on this contract to enable multimodal inputs, conversation memory, and function calling.

## Architecture

The module is organized into a small set of cohesive files, each responsible for one category of custom type:

```mermaid
graph TD
    BaseType["BaseType<br/>(base_type.py)"]
    Image["Image<br/>(image.py)"]
    Audio["Audio<br/>(audio.py)"]
    History["History<br/>(history.py)"]
    Tool["Tool / ToolCalls<br/>(tool.py)"]

    Image -->|extends| BaseType
    Audio -->|extends| BaseType
    Tool -->|extends| BaseType
    History -.->|standalone pydantic model| History

    BaseType -->|serialize_model / split_message_content_for_custom_types| Adapters["Adapters<br/>(ChatAdapter, JSONAdapter, ...)"]
    Tool -->|with_callbacks| Callbacks["Callback System<br/>(utils/callback.py)"]
    Tool -->|settings| Settings["Settings<br/>(dsp/utils/settings.py)"]
```

### Key Design Principles

1. **Uniform formatting contract**: Every `BaseType` subclass implements `format()`, returning either a list of content-part dictionaries (matching the OpenAI content array format) or a plain string.
2. **Sentinel-based serialization**: `BaseType.serialize_model()` wraps list-formatted output in reserved sentinel identifiers (`<<CUSTOM-TYPE-START-IDENTIFIER>>` / `<<CUSTOM-TYPE-END-IDENTIFIER>>`), allowing adapters to later split a flattened string back into structured content blocks.
3. **Pydantic-native**: All types are Pydantic models, giving them validation, immutability (`frozen`), and serialization for free.

## Core Components

### BaseType — the type system foundation

`BaseType` is the abstract parent of all DSPy custom types. It defines:

- `format()` — the abstract method subclasses must implement to produce API-ready content.
- `description()` — an optional human-readable description used in prompts.
- `extract_custom_type_from_annotation()` — recursively discovers custom types nested arbitrarily deep within a field annotation (e.g., `list[dict[str, Tool]]`).
- `serialize_model()` — a Pydantic model serializer that wraps list output in sentinel markers.
- `split_message_content_for_custom_types()` — a module-level helper that reverses the sentinel wrapping, splitting a user message's string content into a list of content blocks around embedded custom types.

See [adapter_types_base_type.md](adapter_types_base_type.md) for full details.

### Image — multimodal image inputs

`Image` wraps an image reference (URL, file path, data URI, PIL image, or raw bytes) and formats it as an OpenAI-style `image_url` content part. It provides convenient constructors (`from_url`, `from_file`, `from_PIL`) and a robust `encode_image()` helper that handles base64 encoding and MIME detection.

See [adapter_types_image.md](adapter_types_image.md) for full details.

### Audio — multimodal audio inputs

`Audio` wraps base64-encoded audio data plus a format string, formatting it as an `input_audio` content part. It supports construction from URLs, files, and numpy-like arrays (via `soundfile`), with the `encode_audio()` helper normalizing many input shapes.

See [adapter_types_audio.md](adapter_types_audio.md) for full details.

### History — conversation memory

`History` is a standalone Pydantic model (not a `BaseType`) representing a list of prior conversation messages. Each message is a dictionary whose keys correspond to the fields of the associated signature, enabling multi-turn conversational programs.

See [adapter_types_history.md](adapter_types_history.md) for full details.

### Tool & ToolCalls — function calling

`Tool` wraps a Python callable and automatically infers its name, description, and JSON-schema arguments from type hints and docstrings. It supports synchronous and asynchronous invocation, argument validation/coercion, and conversion from MCP and LangChain tools. `ToolCalls` represents a list of tool invocations returned by an LM.

See [adapter_types_tool.md](adapter_types_tool.md) for full details.

## How the Module Fits into the System

```mermaid
flowchart LR
    subgraph Signatures
        Sig["Signature fields<br/>typed with custom types"]
    end
    subgraph adapter_types
        BT["BaseType"]
        Types["Image / Audio / Tool / History"]
    end
    subgraph Adapters
        CA["ChatAdapter"]
        JA["JSONAdapter"]
        XA["XMLAdapter"]
    end
    subgraph Clients
        LM["LM / BaseLM"]
    end

    Sig --> Types
    Types --> BT
    BT -->|format + serialize_model| CA
    BT -->|format + serialize_model| JA
    BT -->|format + serialize_model| XA
    CA --> LM
    JA --> LM
    XA --> LM
```

- **Signatures** ([signatures.md](signatures.md)) may declare fields typed with these custom types.
- **Adapters** ([adapters_core.md](adapters_core.md)) call `format()` and `serialize_model()` to render these types into LM-ready content, then use `split_message_content_for_custom_types()` to reconstruct structured content blocks.
- **Clients** ([clients.md](clients.md)) receive the final formatted messages and send them to the underlying LM provider.
- **Tool** integrates with the callback system ([utils.md](utils.md)) via `with_callbacks` and reads configuration from `settings` ([dsp.md](dsp.md)).

## Sub-module Documentation

| Sub-module | Description |
| --- | --- |
| [adapter_types_base_type.md](adapter_types_base_type.md) | The `BaseType` foundation and custom-type serialization/splitting helpers |
| [adapter_types_image.md](adapter_types_image.md) | The `Image` custom type and image encoding utilities |
| [adapter_types_audio.md](adapter_types_audio.md) | The `Audio` custom type and audio encoding utilities |
| [adapter_types_history.md](adapter_types_history.md) | The `History` conversation-memory model |
| [adapter_types_tool.md](adapter_types_tool.md) | The `Tool` and `ToolCalls` types for function calling |
