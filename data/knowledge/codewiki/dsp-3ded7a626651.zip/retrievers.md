# Retrievers

## Overview

The **retrievers** module provides DSPy's retrieval abstraction layer. It defines the base `Retrieve` module — a `Parameter` subclass that acts as the standard interface for fetching relevant passages from a corpus — along with several concrete retriever implementations that connect DSPy programs to external vector stores and search backends.

Retrievers are the "R" in RAG (Retrieval-Augmented Generation). A DSPy program typically calls `dspy.Retrieve` (or a concrete retriever such as `WeaviateRM` or `DatabricksRM`) to obtain context passages, which are then fed into a language model via a `Predict` module.

The module contains four core components:

| Component | File | Role |
|-----------|------|------|
| `Retrieve` | `dspy/retrievers/retrieve.py` | Base retriever module; delegates to the globally configured retrieval model (`dspy.settings.rm`). |
| `Embeddings` | `dspy/retrievers/embeddings.py` | In-memory, embedding-based retriever with optional FAISS indexing. |
| `WeaviateRM` | `dspy/retrievers/weaviate_rm.py` | Retriever backed by a Weaviate vector database (v3 and v4 clients). |
| `DatabricksRM` / `Document` | `dspy/retrievers/databricks_rm.py` | Retriever backed by a Databricks Mosaic AI Vector Search Index. |

## Architecture

All concrete retrievers build on the base `Retrieve` module, which itself extends `Parameter` (from the [predict](predict.md) module) so that retrievers can participate in DSPy's parameter/optimization machinery. Retrieval results are returned as `Prediction` objects (from the [primitives](primitives.md) module).

```mermaid
graph TD
    Parameter["Parameter<br/>(predict module)"]
    Retrieve["Retrieve<br/>(base retriever)"]
    Embeddings["Embeddings"]
    WeaviateRM["WeaviateRM"]
    DatabricksRM["DatabricksRM"]

    Parameter --> Retrieve
    Retrieve --> WeaviateRM
    Retrieve --> DatabricksRM
    Embeddings -.->|"standalone,<br/>not a Retrieve subclass"| Embeddings

    Retrieve -->|"reads"| Settings["dspy.settings.rm"]
    Retrieve -->|"returns"| Prediction["Prediction<br/>(primitives module)"]
    Embeddings -->|"returns"| Prediction
    WeaviateRM -->|"returns"| Prediction
    DatabricksRM -->|"returns"| Prediction

    Embeddings -->|"uses"| Unbatchify["Unbatchify<br/>(utils module)"]
    Retrieve -->|"decorated by"| Callbacks["with_callbacks<br/>(utils module)"]
    WeaviateRM -->|"uses"| dotdict["dotdict<br/>(dsp module)"]
```

### Retrieval Flow

The base `Retrieve.forward` method is the canonical entry point. It resolves the number of passages `k`, checks that a retrieval model is configured in `dspy.settings.rm`, delegates the query to that model, and normalizes the result into a `Prediction`.

```mermaid
sequenceDiagram
    participant Program as DSPy Program
    participant Retrieve as Retrieve (base)
    participant Settings as dspy.settings.rm
    participant RM as Concrete Retriever
    participant Pred as Prediction

    Program->>Retrieve: __call__(query, k)
    Retrieve->>Retrieve: forward(query, k)
    Retrieve->>Settings: check rm is loaded
    Retrieve->>RM: rm(query, k=k, **kwargs)
    RM-->>Retrieve: passages (list of dotdict)
    Retrieve->>Retrieve: extract .long_text from each passage
    Retrieve->>Pred: Prediction(passages=[...])
    Pred-->>Program: Prediction
```

## Sub-modules

The retrievers module is organized into the following sub-modules. Each is documented in detail in its own file:

- **[retrievers_core](retrievers_core.md)** — The base `Retrieve` module and the in-memory `Embeddings` retriever. Covers the standard retriever interface, the `dspy.settings.rm` delegation pattern, and the FAISS-backed embedding search.
- **[retrievers_backends](retrievers_backends.md)** — External vector-store integrations: `WeaviateRM` (Weaviate) and `DatabricksRM`/`Document` (Databricks Mosaic AI Vector Search).

## Relationship to Other Modules

- **[predict](predict.md)** — `Retrieve` subclasses `Parameter`, so retrievers are first-class DSPy parameters that can be optimized.
- **[primitives](primitives.md)** — All retrievers return `Prediction` objects, the standard DSPy output container.
- **[dsp](dsp.md)** — `WeaviateRM` uses `dotdict` from `dspy.dsp.utils`; `dspy.settings` (also in the dsp module) holds the globally configured retrieval model.
- **[utils](utils.md)** — `Embeddings` uses `Unbatchify` for automatic query batching; `Retrieve.__call__` is wrapped by the `with_callbacks` decorator for observability.
- **[clients](clients.md)** — The `Embedder` client (in the clients module) is the typical `embedder` passed to `Embeddings`.

## Common Usage Pattern

```python
import dspy

# Configure a retrieval model globally
retriever = WeaviateRM("my_collection_name", weaviate_client=weaviate_client)
dspy.settings.configure(lm=llm, rm=retriever)

# Use the base Retrieve module to query the configured RM
retrieve = dspy.Retrieve(k=3)
passages = retrieve("what are the stages in planning public works").passages
```

Alternatively, a concrete retriever can be used directly inside a module's `forward`:

```python
self.retrieve = DatabricksRM(
    databricks_index_name="your_index_name",
    docs_id_column_name="id",
    text_column_name="field2",
    k=3,
)
```
