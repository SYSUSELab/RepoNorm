# Adapter Types: Image

## Introduction

The `adapter_types_image` module provides the `Image` custom type for DSPy signatures, enabling multimodal
signatures to accept image inputs. It is one of the concrete implementations of the
[`BaseType`](adapter_types_base_type.md) abstraction, alongside [`Audio`](adapter_types_audio.md),
[`History`](adapter_types_history.md), and [`Tool`](adapter_types_tool.md).

The module is responsible for:

- Representing an image as a validated, immutable Pydantic model (`Image`).
- Normalizing many input forms (URLs, local file paths, raw bytes, PIL images, data URIs, dicts) into a
  single canonical `url` field.
- Encoding images into base64 data URIs when required by the downstream LM provider.
- Producing the OpenAI-style content-part payload consumed by DSPy adapters.

## Core Component

### `Image`

`Image` is a frozen Pydantic model that subclasses [`BaseType`](adapter_types_base_type.md). It exposes a
single field, `url`, which holds either a remote URL or a base64 data URI.

```python
class Image(BaseType):
    url: str

    model_config = {
        "frozen": True,
        "str_strip_whitespace": True,
        "validate_assignment": True,
        "extra": "forbid",
    }
```

| Member | Kind | Description |
| --- | --- | --- |
| `url` | field | The image location: a remote URL or a `data:` URI. |
| `format()` | method | Returns the OpenAI content-part list `[{"type": "image_url", "image_url": {"url": ...}}]`. |
| `validate_input()` | validator | Coerces strings, dicts, and `Image` instances into the canonical form. |
| `from_url(url, download=False)` | classmethod | Builds an `Image` from a URL, optionally downloading and encoding it. |
| `from_file(file_path)` | classmethod | Builds an `Image` from a local file path (base64-encoded). |
| `from_PIL(pil_image)` | classmethod | Builds an `Image` from a PIL image object. |
| `__str__` / `__repr__` | dunder | Serializes the model; `__repr__` truncates base64 payloads for readability. |

## Architecture

The module sits within the `adapters/types` package. `Image` depends on `BaseType` for the serialization
contract and on a set of module-level helper functions for encoding.

```mermaid
graph TD
    subgraph "adapters/types"
        BaseType["BaseType<br/>(base_type.py)"]
        Image["Image<br/>(image.py)"]
        Audio["Audio<br/>(audio.py)"]
        History["History<br/>(history.py)"]
        Tool["Tool<br/>(tool.py)"]
    end

    Image -->|subclasses| BaseType
    Audio -->|subclasses| BaseType
    Tool -->|subclasses| BaseType

    subgraph "External"
        Pydantic["pydantic"]
        Requests["requests"]
        PIL["PIL (optional)"]
    end

    Image --> Pydantic
    Image --> Requests
    Image -.->|optional| PIL
```

## Component Relationships

The `Image` class delegates all encoding work to module-level helper functions. This separation keeps the
model itself thin and makes the encoding logic independently testable.

```mermaid
graph LR
    Image["Image"]

    Image -->|format| encode_image
    Image -->|from_url| encode_image
    Image -->|from_file| encode_image
    Image -->|from_PIL| encode_image

    encode_image --> is_url
    encode_image --> _encode_image_from_file
    encode_image --> _encode_image_from_url
    encode_image --> _encode_pil_image

    _encode_image_from_file --> mimetypes
    _encode_image_from_url --> requests
    _encode_pil_image --> PILImage

    is_image --> is_url
    is_image --> PILImage
```

### Helper Functions

| Function | Purpose |
| --- | --- |
| `is_url(string)` | Validates whether a string is an `http`, `https`, or `gs` URL. |
| `encode_image(image, download_images=False)` | Central dispatcher that normalizes any supported input into a URL or data URI. |
| `_encode_image_from_file(file_path)` | Reads a local file and returns a base64 data URI with a guessed MIME type. |
| `_encode_image_from_url(image_url)` | Downloads a remote image and returns a base64 data URI. |
| `_encode_pil_image(image)` | Serializes a PIL image to a base64 data URI. |
| `_get_file_extension(path_or_url)` | Extracts a file extension from a path or URL (defaults to `png`). |
| `is_image(obj)` | Predicate used to detect image-like objects (PIL images, data URIs, files, URLs). |

## Data Flow

The following diagram shows how an arbitrary image input flows through validation, encoding, and formatting
into the payload consumed by DSPy adapters.

```mermaid
flowchart TD
    A["Input: str / dict / bytes / PIL / Image"] --> B{"validate_input"}
    B -->|str| C["wrap as {'url': str}"]
    B -->|dict with 'url'| D["pass through"]
    B -->|Image instance| E["model_dump()"]
    B -->|other| F["raise TypeError"]

    C --> G["Image(url=...)"]
    D --> G
    E --> G

    G --> H{"format()"}
    H --> I["encode_image(url)"]
    I --> J{"input kind?"}
    J -->|data URI| K["return as-is"]
    J -->|file path| L["_encode_image_from_file"]
    J -->|URL| M{"download?"}
    M -->|yes| N["_encode_image_from_url"]
    M -->|no| O["return URL"]
    J -->|PIL/bytes| P["_encode_pil_image"]

    K --> Q["content part list"]
    L --> Q
    N --> Q
    O --> Q
    P --> Q
    Q --> R["[{'type': 'image_url', 'image_url': {'url': ...}}]"]
```

## Process Flow: `encode_image` Dispatch

`encode_image` is the heart of the module. It inspects the input type and routes to the appropriate encoder.

```mermaid
flowchart TD
    Start["encode_image(image, download_images)"] --> T1{"dict with 'url'?"}
    T1 -->|yes| R1["return image['url']"]
    T1 -->|no| T2{"str?"}
    T2 -->|yes| S1{"starts with 'data:'?"}
    S1 -->|yes| R2["return as-is"]
    S1 -->|no| S2{"is file?"}
    S2 -->|yes| R3["_encode_image_from_file"]
    S2 -->|no| S3{"is_url?"}
    S3 -->|yes| S4{"download_images?"}
    S4 -->|yes| R4["_encode_image_from_url"]
    S4 -->|no| R5["return URL"]
    S3 -->|no| E1["raise ValueError"]
    T2 -->|no| T3{"PIL Image?"}
    T3 -->|yes| R6["_encode_pil_image"]
    T3 -->|no| T4{"bytes?"}
    T4 -->|yes| R7["open via PIL then encode"]
    T4 -->|no| T5{"Image instance?"}
    T5 -->|yes| R8["return image.url"]
    T5 -->|no| E2["raise ValueError"]
```

## Integration with the Adapter System

`Image` participates in the broader adapter pipeline. When a signature field is annotated with `Image`,
the adapter detects it via [`BaseType.extract_custom_type_from_annotation`](adapter_types_base_type.md) and
calls `format()` to produce the content parts that are embedded into the LM request. The serialization
contract (`serialize_model`) wraps list-formatted output in custom-type identifiers so adapters can
distinguish structured content from plain text.

```mermaid
sequenceDiagram
    participant User
    participant Signature
    participant Adapter as Adapter (chat/json/xml)
    participant Image
    participant LM as LM Provider

    User->>Signature: provide Image input
    Signature->>Adapter: field annotated with Image
    Adapter->>Image: format()
    Image->>Image: encode_image(url)
    Image-->>Adapter: [{"type": "image_url", ...}]
    Adapter->>LM: request with image content part
    LM-->>Adapter: response
```

## Dependencies

| Dependency | Required | Role |
| --- | --- | --- |
| `pydantic` | Yes | Model definition, validators, serialization. |
| `requests` | Yes | Downloading remote images in `_encode_image_from_url`. |
| `PIL` (Pillow) | Optional | Handling PIL images and raw bytes; guarded by `PIL_AVAILABLE`. |
| `base64`, `io`, `mimetypes`, `os`, `urllib.parse` | Yes | Standard-library encoding and MIME detection utilities. |
| [`BaseType`](adapter_types_base_type.md) | Yes | Parent class providing the `format`/serialization contract. |

## Related Modules

- [adapter_types_base_type.md](adapter_types_base_type.md) — The `BaseType` parent class and serialization contract.
- [adapter_types_audio.md](adapter_types_audio.md) — The sibling `Audio` custom type.
- [adapter_types_history.md](adapter_types_history.md) — The `History` custom type for conversation state.
- [adapter_types_tool.md](adapter_types_tool.md) — The `Tool` and `ToolCalls` custom types.
- [adapters_core.md](adapters_core.md) — The adapters that consume formatted custom types.
