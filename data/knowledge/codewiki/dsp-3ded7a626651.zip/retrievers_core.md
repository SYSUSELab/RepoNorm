# Retrievers Core

## Introduction

The **retrievers_core** module provides the foundational retrieval abstractions in DSPy. It defines the two primary mechanisms for fetching relevant passages from a corpus:

- **`Retrieve`** — a thin, configurable wrapper around a pluggable *retrieval model* (RM) registered in the global DSPy settings. It delegates the actual search to whatever backend the user has configured.
- **`Embeddings`** — a self-contained, in-memory semantic retriever that embeds a corpus and performs nearest-neighbor search, optionally accelerated with a FAISS index for large corpora.

Together, these components form the retrieval layer that downstream modules (e.g., `ReAct`, `KNN`, RAG-style programs) rely on to ground predictions in external knowledge. Backend-specific implementations (Weaviate, Databricks) are documented separately in [retrievers_backends](retrievers_backends.md).

---

## Architecture Overview

The core module sits between high-level prediction strategies and concrete retrieval backends. `Retrieve` acts as an indirection layer that reads the active RM from global settings, while `Embeddings` is a standalone retriever that owns its own corpus and index.

```mermaid
graph TD
    subgraph "retrievers_core"
        Retrieve["Retrieve<br/>(Parameter)"]
        Embeddings["Embeddings"]
    end

    subgraph "Global Configuration"
        Settings["Settings<br/>(dspy.settings)"]
        RM["rm<br/>(retrieval model)"]
    end

    subgraph "Backends"
        Weaviate["WeaviateRM"]
        Databricks["DatabricksRM"]
    end

    subgraph "Supporting Primitives"
        Parameter["Parameter"]
        Prediction["Prediction"]
        Unbatchify["Unbatchify"]
        Callbacks["with_callbacks"]
    end

    Retrieve -->|reads| Settings
    Settings -->|holds| RM
    RM -->|implemented by| Weaviate
    RM -->|implemented by| Databricks

    Retrieve -->|extends| Parameter
    Retrieve -->|returns| Prediction
    Retrieve -->|decorated by| Callbacks

    Embeddings -->|returns| Prediction
    Embeddings -->|uses| Unbatchify
    Embeddings -->|uses| Embedder

    style Retrieve fill:#4a90d9,color:#fff
    style Embeddings fill:#4a90d9,color:#fff
```

---

## Component Details

### `Retrieve`

`Retrieve` is a DSPy `Parameter` subclass that represents a search operation. It does **not** implement retrieval itself; instead, it forwards the query to the retrieval model configured in `dspy.settings.rm`.

| Attribute | Value | Description |
|-----------|-------|-------------|
| `name` | `"Search"` | Human-readable name used in prompts/signatures |
| `input_variable` | `"query"` | The input field name |
| `desc` | `"takes a search query and returns one or more potentially relevant passages from a corpus"` | Description used in prompt construction |
| `k` | `3` (default) | Number of passages to retrieve |
| `stage` | random hex | Unique identifier for the instance |
| `callbacks` | `[]` | Instance-level callbacks |

#### Key Methods

- **`__init__(k=3, callbacks=None)`** — Initializes the retriever with a default top-`k` and optional callbacks.
- **`forward(query, k=None, **kwargs)`** — The core retrieval logic:
  1. Resolves `k` (falls back to `self.k`).
  2. Asserts that `dspy.settings.rm` is configured.
  3. Calls `dspy.settings.rm(query, k=k, **kwargs)`.
  4. Normalizes the result into an iterable and extracts `long_text` from each passage.
  5. Returns a `Prediction(passages=...)`.
- **`__call__`** — Decorated with `@with_callbacks`, wrapping `forward` with start/end callback hooks.
- **`dump_state()` / `load_state(state)`** — Serialize/deserialize the `k` parameter for saving and loading programs.
- **`reset()`** — No-op (present for interface compatibility).

#### Retrieval Flow

```mermaid
sequenceDiagram
    participant Caller
    participant Retrieve
    participant Callbacks as with_callbacks
    participant Settings as dspy.settings
    participant RM as settings.rm

    Caller->>Retrieve: __call__(query, k)
    Retrieve->>Callbacks: start callbacks
    Callbacks->>Settings: read rm
    alt rm not configured
        Settings-->>Retrieve: None
        Retrieve-->>Caller: AssertionError("No RM is loaded.")
    else rm configured
        Retrieve->>RM: rm(query, k=k, **kwargs)
        RM-->>Retrieve: passages
        Retrieve->>Retrieve: extract long_text
        Retrieve-->>Caller: Prediction(passages=[...])
    end
    Retrieve->>Callbacks: end callbacks
```

> **Note:** The module also defines a helper `single_query_passage(passages)` that transposes a list of passage dicts into a column-oriented `Prediction`, renaming `long_text` to `passages`. This is a utility for batch-style passage handling.

---

### `Embeddings`

`Embeddings` is a self-contained semantic retriever. It embeds an entire corpus at construction time and answers queries via cosine similarity (when normalized) over either a brute-force scan or a FAISS approximate index.

#### Constructor Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `corpus` | — | List of strings to index |
| `embedder` | — | Callable mapping a list of strings to embeddings |
| `k` | `5` | Number of results to return |
| `callbacks` | `None` | Optional callbacks |
| `cache` | `False` | Must be `False`; caching is unsupported |
| `brute_force_threshold` | `20_000` | Corpus size at/above which a FAISS index is built |
| `normalize` | `True` | Whether to L2-normalize embeddings |

#### Key Methods

- **`__init__`** — Embeds the corpus, optionally normalizes, builds a FAISS index if the corpus is large enough, and wraps `_batch_forward` in an `Unbatchify` for automatic batching.
- **`forward(query)`** — Runs the search and returns `dspy.Prediction(passages=..., indices=...)`.
- **`_batch_forward(queries)`** — Embeds queries, retrieves candidate indices (via FAISS or all indices), and reranks.
- **`_build_faiss()`** — Builds an `IndexIVFPQ` FAISS index with `2 * sqrt(N)` partitions. Raises `ImportError` if `faiss` is unavailable.
- **`_faiss_search(query_embeddings, num_candidates)`** — Returns candidate indices from the FAISS index.
- **`_rerank_and_predict(q_embeds, candidate_indices)`** — Computes dot-product scores and selects the top-`k` per query.
- **`_normalize(embeddings)`** — L2-normalizes embeddings with a small epsilon guard.

#### Search Flow

```mermaid
flowchart TD
    A["forward(query)"] --> B["Unbatchify.__call__"]
    B --> C["_batch_forward(queries)"]
    C --> D["embedder(queries)"]
    D --> E{"normalize?"}
    E -->|yes| F["_normalize"]
    E -->|no| G["raw embeddings"]
    F --> H{"FAISS index built?"}
    G --> H
    H -->|yes| I["_faiss_search<br/>(k*10 candidates)"]
    H -->|no| J["all corpus indices"]
    I --> K["_rerank_and_predict"]
    J --> K
    K --> L["top-k by dot product"]
    L --> M["Prediction(passages, indices)"]
```

#### Batching with `Unbatchify`

Because embedding models are far more efficient when processing batches, `Embeddings` wraps its batch function with `Unbatchify`. This utility transparently collects individual `forward` calls into batches (up to `max_batch_size`, waiting at most `max_wait_time`) and dispatches them to `_batch_forward` on a background worker thread. See [utils](utils.md) for details on `Unbatchify`.

---

## Dependencies

```mermaid
graph LR
    subgraph "retrievers_core"
        Retrieve
        Embeddings
    end

    Retrieve --> Parameter["Parameter<br/>(predict_core)"]
    Retrieve --> Prediction["Prediction<br/>(primitives_data_containers)"]
    Retrieve --> with_callbacks["with_callbacks<br/>(utils)"]
    Retrieve --> Settings["Settings<br/>(dsp_settings)"]

    Embeddings --> Prediction
    Embeddings --> Unbatchify["Unbatchify<br/>(utils)"]
    Embeddings --> Embedder["Embedder<br/>(clients_lm_core)"]
    Embeddings --> FAISS["faiss (optional)"]
    Embeddings --> NumPy["numpy"]
```

| Dependency | Module | Purpose |
|------------|--------|---------|
| `Parameter` | [predict_core](predict_core.md) | Base class for `Retrieve` |
| `Prediction` | [primitives_data_containers](primitives_data_containers.md) | Return type for both retrievers |
| `with_callbacks` | [utils](utils.md) | Callback instrumentation for `Retrieve.__call__` |
| `Settings` | [dsp_settings](dsp_settings.md) | Global config holding the active `rm` |
| `Unbatchify` | [utils](utils.md) | Automatic batching for `Embeddings` |
| `Embedder` | [clients_lm_core](clients_lm_core.md) | Embedding function used by `Embeddings` |
| `faiss` | external (optional) | Approximate nearest-neighbor index |

---

## How the Module Fits into the System

The retrievers_core module is the **abstraction boundary** between retrieval *consumers* and retrieval *providers*:

- **Consumers** — Prediction strategies such as `ReAct` ([predict_strategies](predict_strategies.md)) and `KNN` ([predict_utilities](predict_utilities.md)) invoke `Retrieve` to fetch context. Because `Retrieve` reads from `dspy.settings.rm`, consumers remain agnostic to the concrete backend.
- **Providers** — Backend implementations like `WeaviateRM` and `DatabricksRM` ([retrievers_backends](retrievers_backends.md)) conform to the RM callable interface (`rm(query, k=...) -> passages`) and are registered via `dspy.configure(rm=...)`.
- **Standalone path** — `Embeddings` bypasses the global RM entirely, offering a lightweight, dependency-free semantic search suitable for small-to-medium corpora or offline use.

```mermaid
graph TD
    subgraph Consumers
        ReAct["ReAct"]
        KNN["KNN"]
        RAG["RAG-style Programs"]
    end

    subgraph "retrievers_core"
        Retrieve
        Embeddings
    end

    subgraph Providers
        WeaviateRM
        DatabricksRM
        CustomRM["Custom RM"]
    end

    ReAct --> Retrieve
    KNN --> Retrieve
    RAG --> Retrieve
    RAG --> Embeddings

    Retrieve -.->|via dspy.settings.rm| WeaviateRM
    Retrieve -.->|via dspy.settings.rm| DatabricksRM
    Retrieve -.->|via dspy.settings.rm| CustomRM
```

---

## Design Notes & Constraints

- **Single RM indirection:** `Retrieve` deliberately holds no backend reference. Swapping backends is a matter of reconfiguring `dspy.settings.rm`, which keeps programs portable and serializable (only `k` is persisted via `dump_state`).
- **No caching for `Embeddings`:** The constructor asserts `cache is False`; caching is explicitly unsupported for embeddings-based retrieval.
- **FAISS is optional:** Corpora below `brute_force_threshold` use exact brute-force search. Larger corpora require `faiss-cpu`; otherwise an `ImportError` is raised with guidance to install it or raise the threshold.
- **Normalization default:** Embeddings are L2-normalized by default so that dot-product scoring is equivalent to cosine similarity.
- **Callback integration:** `Retrieve.__call__` is wrapped with `with_callbacks`, enabling observability hooks consistent with the rest of DSPy. See [utils](utils.md) for the callback mechanism.

---

## Related Documentation

- [retrievers_backends](retrievers_backends.md) — Weaviate and Databricks retrieval backends
- [predict_core](predict_core.md) — `Parameter` base class
- [primitives_data_containers](primitives_data_containers.md) — `Prediction` and `Example`
- [dsp_settings](dsp_settings.md) — Global `Settings` and `rm` configuration
- [clients_lm_core](clients_lm_core.md) — `Embedder` and LM clients
- [utils](utils.md) — `Unbatchify`, callbacks, and other utilities
