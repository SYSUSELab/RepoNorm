# Adapter Types: Audio

## Introduction

The `adapter_types_audio` module provides the `Audio` custom type for DSPy signatures. It enables developers to attach audio content (local files, remote URLs, data URIs, raw bytes, or numpy-like arrays) to DSPy signature fields. The type handles encoding audio into base64 and formatting it into the content-part structure expected by multimodal language model APIs (e.g., OpenAI's `input_audio` content part).

This module is one of several sibling custom types under the `adapter_types` family. For the shared contract that all custom types implement, see [adapter_types_base_type.md](adapter_types_base_type.md). For the analogous image type, see [adapter_types_image.md](adapter_types_image.md).

---

## Module Overview

The module exposes two public symbols:

| Symbol | Kind | Purpose |
| --- | --- | --- |
| `Audio` | Pydantic model (subclass of `BaseType`) | Represents an audio payload with base64 `data` and an `audio_format`. |
| `encode_audio` | Module-level function | Normalizes many input forms into a `{"data", "audio_format"}` dict. |

The `Audio` class is a frozen, strict Pydantic model. It inherits from `BaseType`, which defines the `format()` contract and the serialization behavior used by DSPy adapters.

---

## Architecture

The `Audio` type sits within the broader adapter type hierarchy. It depends on `BaseType` for its interface contract and is consumed by the adapters that serialize signature fields into LM messages.

```mermaid
graph TD
    BaseType["BaseType<br/>(base_type.py)"]
    Audio["Audio<br/>(audio.py)"]
    Image["Image<br/>(image.py)"]
    History["History<br/>(history.py)"]
    Tool["Tool / ToolCalls<br/>(tool.py)"]
    encode_audio["encode_audio()"]

    BaseType --> Audio
    BaseType --> Image
    BaseType --> History
    BaseType --> Tool
    encode_audio --> Audio

    Audio -. "format() -> input_audio part" .-> Adapters["Adapters<br/>(chat_adapter, json_adapter, ...)"]
```

### Key Relationships

- **Inheritance**: `Audio` extends `BaseType`, inheriting `serialize_model()`, `description()`, and `extract_custom_type_from_annotation()`.
- **Sibling types**: `Image`, `History`, and `Tool`/`ToolCalls` follow the same `BaseType` pattern. See [adapter_types_image.md](adapter_types_image.md), [adapter_types_history.md](adapter_types_history.md), and [adapter_types_tool.md](adapter_types_tool.md).
- **Consumers**: Adapters (see [adapters_core.md](adapters_core.md)) call `format()` on custom types to build the content parts of LM messages.

---

## The `Audio` Class

### Fields

| Field | Type | Description |
| --- | --- | --- |
| `data` | `str` | Base64-encoded audio bytes. |
| `audio_format` | `str` | Audio format identifier (e.g., `"wav"`, `"mp3"`). |

### Model Configuration

```python
model_config = {
    "frozen": True,
    "extra": "forbid",
}
```

- `frozen=True`: Instances are immutable after creation.
- `extra="forbid"`: Unknown fields raise validation errors, enforcing a strict schema.

### Methods

| Method | Description |
| --- | --- |
| `format()` | Returns a list containing a single `input_audio` content part. |
| `validate_input(values)` | Pydantic `before` validator that normalizes inputs via `encode_audio`. |
| `from_url(url)` | Downloads audio from a URL and base64-encodes it. |
| `from_file(file_path)` | Reads a local audio file and base64-encodes it. |
| `from_array(array, sampling_rate, format="wav")` | Encodes a numpy-like array using `soundfile`. |
| `__str__()` | Returns the serialized model string. |
| `__repr__()` | Returns a compact representation hiding the base64 payload. |

---

## Input Normalization Flow

The `validate_input` validator delegates to `encode_audio`, which accepts a wide variety of input forms and produces a canonical `{"data", "audio_format"}` dict. This is the central dispatch logic of the module.

```mermaid
flowchart TD
    Start([Input to Audio]) --> IsAudioInstance{"Is it an Audio<br/>instance?"}
    IsAudioInstance -->|Yes| Extract["Extract data + audio_format"]
    IsAudioInstance -->|No| Encode["encode_audio()"]

    Encode --> IsDict{"dict with<br/>data + audio_format?"}
    IsDict -->|Yes| ReturnDict["Return as-is"]
    IsDict -->|No| IsDataURI{"str starting with<br/>'data:audio/'?"}
    IsDataURI -->|Yes| ParseURI["Parse header + b64 payload"]
    IsDataURI -->|No| IsFile{"str that is an<br/>existing file path?"}
    IsFile -->|Yes| FromFile["Audio.from_file()"]
    IsFile -->|No| IsURL{"str starting with<br/>'http'?"}
    IsURL -->|Yes| FromURL["Audio.from_url()"]
    IsURL -->|No| IsArray{"has 'shape' attr<br/>and soundfile available?"}
    IsArray -->|Yes| FromArray["Audio.from_array()"]
    IsArray -->|No| IsBytes{"bytes?"}
    IsBytes -->|Yes| EncodeBytes["base64 encode bytes"]
    IsBytes -->|No| RaiseError["Raise ValueError:<br/>Unsupported type"]

    Extract --> Done([Canonical dict])
    ReturnDict --> Done
    ParseURI --> Done
    FromFile --> Done
    FromURL --> Done
    FromArray --> Done
    EncodeBytes --> Done
```

### Accepted Input Types

`encode_audio` accepts the following, in priority order:

1. **`dict`** with both `data` and `audio_format` keys — returned unchanged.
2. **`Audio` instance** — its `data` and `audio_format` are extracted.
3. **Data URI string** (`data:audio/...;base64,...`) — parsed into format and payload.
4. **Local file path** — read and encoded via `Audio.from_file`.
5. **HTTP URL** — downloaded and encoded via `Audio.from_url`.
6. **Numpy-like array** (has a `shape` attribute) — encoded via `Audio.from_array` (requires `soundfile`).
7. **`bytes`** — base64-encoded directly using the provided `format`.
8. Anything else raises `ValueError`.

---

## Formatting for Language Models

The `format()` method produces the content-part structure consumed by multimodal LM APIs:

```python
def format(self) -> list[dict[str, Any]]:
    return [{
        "type": "input_audio",
        "input_audio": {
            "data": self.data,
            "format": self.audio_format
        }
    }]
```

This mirrors the OpenAI `input_audio` content part. The `BaseType.serialize_model()` serializer wraps the formatted list in custom-type start/end identifiers when serializing, allowing adapters to detect and handle custom types embedded in signature fields.

```mermaid
sequenceDiagram
    participant User
    participant Audio
    participant BaseType
    participant Adapter

    User->>Audio: Audio(data=..., audio_format="wav")
    Audio->>Audio: validate_input -> encode_audio
    Audio-->>User: Frozen Audio instance
    Adapter->>Audio: format()
    Audio-->>Adapter: [{"type": "input_audio", ...}]
    Adapter->>BaseType: serialize_model()
    BaseType-->>Adapter: Wrapped custom-type string
```

---

## Construction Examples

### From a local file

```python
audio = Audio.from_file("speech.wav")
```

### From a URL

```python
audio = Audio.from_url("https://example.com/clip.mp3")
```

### From a numpy-like array

```python
import numpy as np

samples = np.random.randn(16000).astype("float32")
audio = Audio.from_array(samples, sampling_rate=16000, format="wav")
```

### Directly via the validator

```python
# Passing a file path, URL, data URI, bytes, or dict all work
audio = Audio(data="speech.wav", audio_format="wav")  # normalized by encode_audio
```

---

## Dependencies

| Dependency | Required? | Purpose |
| --- | --- | --- |
| `pydantic` | Yes | Model definition, validators, serializers. |
| `requests` | Yes | Downloading audio from URLs (`from_url`). |
| `soundfile` (`sf`) | Optional | Encoding numpy-like arrays (`from_array`). Guarded by `SF_AVAILABLE`. |
| `base64`, `io`, `mimetypes`, `os` | Yes (stdlib) | Encoding, buffering, MIME detection, file checks. |
| `BaseType` | Yes | Parent class defining the custom-type contract. |

> **Note**: If `soundfile` is not installed, `SF_AVAILABLE` is `False` and `from_array` raises `ImportError`. Array inputs to `encode_audio` are also skipped in that case.

---

## Error Handling

| Condition | Error |
| --- | --- |
| `format()` fails to access `data` | `ValueError("Failed to format audio for DSPy: ...")` |
| `from_url` receives non-audio MIME type | `ValueError("Unsupported MIME type for audio: ...")` |
| `from_file` path does not exist | `ValueError("File not found: ...")` |
| `from_file` MIME type is not audio | `ValueError("Unsupported MIME type for audio: ...")` |
| `from_array` without `soundfile` | `ImportError("soundfile is required to process audio arrays.")` |
| Malformed data URI | `ValueError("Malformed audio data URI: ...")` |
| Unsupported input type to `encode_audio` | `ValueError("Unsupported type for encode_audio: ...")` |

---

## Related Documentation

- [adapter_types_base_type.md](adapter_types_base_type.md) — The `BaseType` contract implemented by `Audio`.
- [adapter_types_image.md](adapter_types_image.md) — The analogous `Image` custom type.
- [adapter_types_history.md](adapter_types_history.md) — The `History` custom type.
- [adapter_types_tool.md](adapter_types_tool.md) — The `Tool` / `ToolCalls` custom types.
- [adapters_core.md](adapters_core.md) — Adapters that consume `format()` output to build LM messages.
