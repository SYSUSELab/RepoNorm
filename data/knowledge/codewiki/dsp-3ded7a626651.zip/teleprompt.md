# Teleprompt Module

## Overview

The **teleprompt** module is DSPy's **optimizer** (a.k.a. *compiler*) library. A teleprompter takes an uncompiled `dspy.Module` (the *student*), a training set, and a metric, and returns an optimized version of that program. Optimization can take several forms:

- **Prompt optimization** — selecting or generating better natural-language instructions for each predictor.
- **Few-shot optimization** — selecting, bootstrapping, or retrieving demonstrations (demos) to place in each predictor's prompt.
- **Weight optimization** — fine-tuning the underlying language model(s) attached to the predictors.
- **Ensembling / composition** — combining multiple programs or chaining prompt and weight optimizers.

Every optimizer implements the same interface, defined by the abstract [`Teleprompter`](teleprompt_core.md) base class, whose central method is `compile(student, *, trainset, teacher=None, valset=None, **kwargs) -> Module`.

## Purpose and Core Functionality

The teleprompt module answers the question: *"Given a program, some data, and a metric, how do I make this program perform better?"*

Its key responsibilities are:

1. **Define a uniform optimizer contract** — the `Teleprompter` base class that all optimizers subclass.
2. **Bootstrap demonstrations** — run a *teacher* program over the training set, keep the traces that pass the metric, and use them as few-shot demos.
3. **Search over candidate programs** — generate many candidate programs (different demo sets, instructions, or hyperparameters) and select the best by validation score.
4. **Generate instructions** — use an LLM to propose improved instructions for predictors (see the [propose module](propose.md)).
5. **Fine-tune models** — convert bootstrapped traces into training data and fine-tune the LMs attached to predictors.
6. **Compose optimizers** — chain prompt and weight optimizers into a single pipeline.

## Architecture Overview

The module is organized around a small abstract base and a large family of concrete optimizers, grouped by the *kind* of optimization they perform.

```mermaid
graph TD
    TP["Teleprompter<br/>(abstract base)"]

    subgraph "Few-shot / Bootstrap"
        LFS["LabeledFewShot"]
        BFS["BootstrapFewShot"]
        BFRS["BootstrapFewShotWithRandomSearch"]
        BFO["BootstrapFewShotWithOptuna"]
        IR["InferRules"]
        KNNFS["KNNFewShot"]
    end

    subgraph "Instruction Optimization"
        COPRO["COPRO"]
        SIGOPT["SignatureOptimizer<br/>(deprecated)"]
        MIPRO["MIPROv2"]
    end

    subgraph "Weight / Fine-tuning"
        FT["FinetuneTeleprompter"]
        BFT["BootstrapFinetune"]
        GRPO["GRPO"]
        BT["BetterTogether"]
    end

    subgraph "Other"
        SIMBA["SIMBA"]
        AVATAR["AvatarOptimizer"]
        ENS["Ensemble"]
    end

    TP --> LFS
    TP --> BFS
    TP --> BFRS
    TP --> BFO
    TP --> IR
    TP --> KNNFS
    TP --> COPRO
    TP --> MIPRO
    TP --> FT
    TP --> SIMBA
    TP --> AVATAR
    TP --> ENS

    BFS --> BFRS
    BFS --> BFO
    BFS --> IR
    BFS --> KNNFS
    COPRO --> SIGOPT
    FT --> BFT
    FT --> GRPO
    BFT --> BT
    BFRS --> BT
```

### Optimization Taxonomy

| Category | Optimizers | What it optimizes |
| --- | --- | --- |
| Few-shot / Bootstrap | `LabeledFewShot`, `BootstrapFewShot`, `BootstrapFewShotWithRandomSearch`, `BootstrapFewShotWithOptuna`, `InferRules`, `KNNFewShot` | The set of demonstrations placed in each predictor's prompt. |
| Instruction | `COPRO`, `MIPROv2`, `SignatureOptimizer` | The natural-language instructions of each predictor's signature. |
| Weight / Fine-tuning | `BootstrapFinetune`, `GRPO`, `BetterTogether` | The parameters of the LM(s) attached to predictors. |
| Other | `SIMBA`, `AvatarOptimizer`, `Ensemble` | Mixed strategies (introspective ascent, tool-use feedback, ensembling). |

## Sub-modules

The teleprompt module is organized into the following logical sub-modules, each documented in detail:

### 1. Core Teleprompter Interface

Defines the abstract `Teleprompter` base class and the simplest optimizers: `LabeledFewShot` (attach labeled demos) and `Ensemble` (combine multiple programs).

- **Core components:** `Teleprompter`, `LabeledFewShot`, `Ensemble`
- **Detailed documentation:** [teleprompt_core.md](teleprompt_core.md)

### 2. Bootstrap Optimizers

The bootstrap family runs a teacher program over the training set, keeps successful traces as demos, and (for the search variants) evaluates many candidate programs to pick the best.

- **Core components:** `BootstrapFewShot`, `BootstrapFewShotWithRandomSearch`, `BootstrapFewShotWithOptuna`, `InferRules`, `RulesInductionProgram`
- **Detailed documentation:** [teleprompt_bootstrap.md](teleprompt_bootstrap.md)

### 3. Instruction Optimizers

These optimizers generate and search over natural-language instructions for predictors, using the [propose module](propose.md) and Bayesian optimization.

- **Core components:** `COPRO`, `BasicGenerateInstruction`, `GenerateInstructionGivenAttempts`, `MIPROv2`, `SignatureOptimizer`
- **Detailed documentation:** [teleprompt_instruction.md](teleprompt_instruction.md)

### 4. Fine-tuning Optimizers

These optimizers convert bootstrapped traces into training data and fine-tune the LMs attached to predictors, including reinforcement-learning-style training (GRPO) and chained prompt+weight optimization (BetterTogether).

- **Core components:** `FinetuneTeleprompter`, `BootstrapFinetune`, `FailedPrediction`, `GRPO`, `BetterTogether`
- **Detailed documentation:** [teleprompt_finetune.md](teleprompt_finetune.md)

### 5. SIMBA Optimizer

`SIMBA` (Stochastic Introspective Mini-Batch Ascent) is a self-improving optimizer that samples program trajectories on mini-batches and uses introspective feedback to add demos or rules.

- **Core components:** `SIMBA`, `OfferFeedback`, `append_a_demo`, `append_a_rule`, `wrap_program`
- **Detailed documentation:** [teleprompt_simba.md](teleprompt_simba.md)

### 6. Avatar Optimizer

`AvatarOptimizer` optimizes the instruction of an [`Avatar`](predict.md) (tool-using) program by comparing positive and negative inputs and generating feedback-based instructions.

- **Core components:** `AvatarOptimizer`, `Comparator`, `EvalResult`, `FeedbackBasedInstruction`
- **Detailed documentation:** [teleprompt_avatar.md](teleprompt_avatar.md)

### 7. KNN Few-Shot

`KNNFewShot` attaches the k nearest neighbors of each test input as demos at inference time, using an in-memory KNN retriever.

- **Core components:** `KNNFewShot`
- **Detailed documentation:** [teleprompt_knn.md](teleprompt_knn.md)

## Data Flow

The following diagram illustrates the general flow shared by most optimizers: a student program and training set are compiled into an optimized program, with the metric driving selection.

```mermaid
sequenceDiagram
    participant User
    participant Optimizer as Teleprompter
    participant Teacher as Teacher Program
    participant Student as Student Program
    participant Eval as Evaluate
    participant Metric

    User->>Optimizer: compile(student, trainset, metric)
    Optimizer->>Teacher: run over trainset (bootstrap)
    Teacher-->>Optimizer: traces / demos
    Optimizer->>Student: attach demos / instructions / fine-tuned LMs
    Optimizer->>Eval: evaluate candidate programs
    Eval->>Metric: metric(example, prediction)
    Metric-->>Eval: score
    Eval-->>Optimizer: validation scores
    Optimizer->>Optimizer: select best candidate
    Optimizer-->>User: optimized program
```

## How the Module Fits into the System

The teleprompt module sits at the top of the DSPy stack. It consumes programs built from the [predict](predict.md) and [primitives](primitives.md) modules, uses the [evaluate](evaluate.md) module to score candidates, and (for instruction optimizers) delegates instruction generation to the [propose](propose.md) module. Fine-tuning optimizers interact with the [clients](clients.md) module to train LMs.

```mermaid
graph LR
    subgraph "Foundations"
        PRED["predict module"]
        PRIM["primitives module"]
        SIG["signatures module"]
    end

    subgraph "Teleprompt Module"
        OPT["Optimizers"]
    end

    subgraph "Supporting Modules"
        EVAL["evaluate module"]
        PROP["propose module"]
        CLI["clients module"]
        DS["datasets module"]
    end

    PRED --> OPT
    PRIM --> OPT
    SIG --> OPT
    OPT --> EVAL
    OPT --> PROP
    OPT --> CLI
    DS --> OPT
```

### Key Dependencies

| Dependency | Role |
| --- | --- |
| [predict.md](predict.md) | Provides `Predict`, `ChainOfThought`, `Avatar`, `KNN`, and `Parallel` used by optimizers. |
| [primitives.md](primitives.md) | Supplies `Module`, `Example`, `Prediction`, and `Parameter` types. |
| [signatures.md](signatures.md) | Provides the `Signature` base class for optimizer-internal signatures. |
| [evaluate.md](evaluate.md) | `Evaluate` scores candidate programs during optimization. |
| [propose.md](propose.md) | `GroundedProposer` generates instructions for `MIPROv2`. |
| [clients.md](clients.md) | `LM`, `Embedder`, and fine-tuning utilities used by weight optimizers. |
| [datasets.md](datasets.md) | Provides `Example` datasets used as training/validation sets. |
| [dsp_settings.md](dsp_settings.md) | `dspy.settings` provides global LM, adapter, and thread configuration. |

## Common Concepts

### Student, Teacher, and Traces

- **Student** — the program being optimized. It must be *uncompiled* (`_compiled == False`) when passed to `compile`.
- **Teacher** — an optional program used to generate demonstrations. If not provided, the student is used as its own teacher. The teacher is typically pre-populated with labeled demos via `LabeledFewShot`.
- **Trace** — the sequence of `(predictor, inputs, outputs)` tuples recorded while running a program. Traces that pass the metric become bootstrapped demos.

### The Metric

A metric is any callable `(example, prediction, trace=None) -> score`. It may return a boolean (pass/fail) or a numeric score. Optimizers use it both to *filter* bootstrapped demos and to *rank* candidate programs.

### Candidate Programs

Most optimizers attach a `candidate_programs` attribute to the returned program — a list of `{"score", "program", ...}` dicts sorted by descending score, so users can inspect the search trajectory.

## Summary

The teleprompt module is DSPy's optimizer library. It provides a uniform `Teleprompter` interface and a rich family of concrete optimizers spanning few-shot bootstrapping, instruction generation, model fine-tuning, and composition. Its sub-modules — [core](teleprompt_core.md), [bootstrap](teleprompt_bootstrap.md), [instruction](teleprompt_instruction.md), [fine-tuning](teleprompt_finetune.md), [SIMBA](teleprompt_simba.md), [Avatar](teleprompt_avatar.md), and [KNN](teleprompt_knn.md) — each target a different optimization strategy while sharing the same compile-time contract.
