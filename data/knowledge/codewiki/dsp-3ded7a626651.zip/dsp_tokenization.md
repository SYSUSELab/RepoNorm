# DSP Tokenization Module

## Introduction

The `dsp_tokenization` module provides the text tokenization infrastructure used within DSPy's `dsp` (DSP primitives) subsystem. It is a port of the tokenization utilities from Facebook Research's [Dense Passage Retrieval (DPR)](https://github.com/facebookresearch/DPR) project, adapted for use in retrieval and answer-matching workflows.

The module's primary responsibility is to convert raw text into structured, annotated token sequences that preserve character offsets and whitespace information. This enables downstream components — most notably retrieval modules such as [ColBERTv2](dsp_retrieval.md) — to perform answer localization, span matching, and n-gram extraction over documents and queries.

The core components live in `dspy/dsp/utils/dpr.py`:

| Component | Role |
|-----------|------|
| `Tokenizer` | Abstract base class defining the tokenizer interface |
| `SimpleTokenizer` | Concrete regex-based tokenizer implementation |
| `Tokens` | Container representing a tokenized text with annotations |

---

## Architecture Overview

The module is intentionally small and self-contained. It exposes a base abstraction (`Tokenizer`), a concrete implementation (`SimpleTokenizer`), and a data container (`Tokens`) that carries the tokenization result. Module-level helper functions provide convenience wrappers around a shared singleton tokenizer instance.

```mermaid
graph TD
    subgraph "dsp_tokenization module"
        Tokenizer["Tokenizer<br/>(abstract base)"]
        SimpleTokenizer["SimpleTokenizer<br/>(regex-based)"]
        Tokens["Tokens<br/>(data container)"]
        STokenizer["STokenizer<br/>(module singleton)"]
        Helpers["DPR_tokenize / DPR_normalize<br/>has_answer / locate_answers<br/>strip_accents"]
    end

    Tokenizer -->|inherits| SimpleTokenizer
    SimpleTokenizer -->|produces| Tokens
    STokenizer -->|instance of| SimpleTokenizer
    Helpers -->|uses| STokenizer
    Helpers -->|operates on| Tokens
```

### Component Relationships

- **`Tokenizer`** defines the contract: a `tokenize(text)` method that must return a `Tokens` object, plus lifecycle hooks (`shutdown`, `__del__`).
- **`SimpleTokenizer`** implements the contract using a Unicode-aware regular expression. It is the only concrete tokenizer shipped in this module.
- **`Tokens`** is the value object returned by tokenization. It stores a list of token tuples and a set of annotators, and exposes methods for extracting words, offsets, POS tags, lemmas, NER tags, n-grams, and entity groups.
- **`STokenizer`** is a module-level singleton instance of `SimpleTokenizer`, reused by the helper functions to avoid recompiling the regex on every call.

---

## Core Components

### `Tokenizer` (Abstract Base)

The base class establishes the tokenizer interface. It is deliberately minimal:

```python
class Tokenizer:
    def tokenize(self, text):
        raise NotImplementedError

    def shutdown(self):
        pass

    def __del__(self):
        self.shutdown()
```

- `tokenize(text)` — must be overridden; returns a `Tokens` instance.
- `shutdown()` — optional cleanup hook, called automatically on garbage collection via `__del__`.

This design allows alternative tokenizers (e.g., spaCy- or Stanza-backed) to be plugged in without changing consumers, as long as they return a compatible `Tokens` object.

### `SimpleTokenizer`

A regex-based tokenizer that splits text into alphanumeric tokens and non-whitespace symbols. It does **not** perform linguistic annotation (POS, lemma, NER) — if annotators are requested, it logs a warning and ignores them.

**Regex patterns:**

| Constant | Pattern | Meaning |
|----------|---------|---------|
| `ALPHA_NUM` | `[\p{L}\p{N}\p{M}]+` | Letters, numbers, and combining marks |
| `NON_WS` | `[^\p{Z}\p{C}]` | Any character that is not a separator or control char |

The combined pattern `(ALPHA_NUM)|(NON_WS)` is compiled with `IGNORECASE`, `UNICODE`, and `MULTILINE` flags.

**Tokenization algorithm:**

For each regex match, the tokenizer records a 3-tuple `(token, whitespace_span, char_span)`:

1. `token` — the matched text.
2. `whitespace_span` — the text from the start of this token to the start of the next token (or to the end of the token for the final match). This preserves inter-token whitespace so the original text can be reconstructed.
3. `char_span` — the `(start, end)` character offsets of the token.

```mermaid
flowchart LR
    A["Input text"] --> B["regex.finditer()"]
    B --> C["For each match"]
    C --> D["Extract token text"]
    C --> E["Compute whitespace span<br/>(to next match start)"]
    C --> F["Record char span"]
    D & E & F --> G["Append tuple to data"]
    G --> H["Return Tokens(data, annotators)"]
```

### `Tokens`

The `Tokens` class is the structured representation of tokenized text. Internally, `data` is a list of tuples indexed by class-level constants:

| Index | Constant | Contents |
|-------|----------|----------|
| 0 | `TEXT` | Token text |
| 1 | `TEXT_WS` | Token text plus trailing whitespace |
| 2 | `SPAN` | `(start, end)` character offsets |
| 3 | `POS` | Part-of-speech tag (if annotated) |
| 4 | `LEMMA` | Lemma (if annotated) |
| 5 | `NER` | Named-entity tag (if annotated) |

**Key methods:**

| Method | Description |
|--------|-------------|
| `__len__()` | Number of tokens |
| `slice(i, j)` | Shallow view of tokens in range `[i, j)` |
| `untokenize()` | Reconstruct original text by joining `TEXT_WS` values and stripping |
| `words(uncased=False)` | List of token texts, optionally lowercased |
| `offsets()` | List of `[start, end)` character offsets |
| `pos()` / `lemmas()` / `entities()` | Annotation lists, or `None` if not annotated |
| `ngrams(n, uncased, filter_fn, as_strings)` | All n-grams up to length `n`, optionally filtered |
| `entity_groups()` | Consecutive same-tag entity spans as `(text, tag)` tuples |

The `slice` method uses `copy.copy` to create a lightweight view sharing the same annotators and options while replacing the `data` list — an efficient way to operate on sub-sequences.

---

## Module-Level Helpers

The module exposes several convenience functions built on the shared `STokenizer` singleton:

```mermaid
graph TD
    STokenizer["STokenizer<br/>(SimpleTokenizer instance)"]
    DPR_tokenize["DPR_tokenize(text)"]
    DPR_normalize["DPR_normalize(text)"]
    has_answer["has_answer(tokenized_answers, text)"]
    locate_answers["locate_answers(tokenized_answers, text)"]
    strip_accents["strip_accents(text)"]

    DPR_tokenize --> STokenizer
    DPR_normalize --> DPR_tokenize
    has_answer --> DPR_normalize
    locate_answers --> DPR_tokenize
    locate_answers --> strip_accents
```

| Function | Purpose |
|----------|---------|
| `DPR_tokenize(text)` | Normalizes text to NFD form and tokenizes it via `STokenizer` |
| `DPR_normalize(text)` | Returns lowercased token words (used for case-insensitive matching) |
| `has_answer(tokenized_answers, text)` | Checks whether any tokenized answer appears as a contiguous subsequence in the normalized text |
| `locate_answers(tokenized_answers, text)` | Returns character-level `(offset, endpos)` occurrences of each answer in the text |
| `strip_accents(text)` | Removes combining marks (Unicode category `Mn`) from text |

These helpers are the primary integration surface for retrieval and evaluation workflows that need to verify whether a retrieved passage contains a known answer.

---

## Data Flow

The following diagram illustrates the end-to-end flow from raw text to answer localization, which is the module's most common usage pattern.

```mermaid
sequenceDiagram
    participant Caller as Caller (e.g. retrieval/eval)
    participant DPR as DPR_tokenize
    participant ST as STokenizer
    participant Tok as Tokens
    participant Loc as locate_answers

    Caller->>DPR: DPR_tokenize(text)
    DPR->>ST: tokenize(NFD-normalized text)
    ST->>Tok: Tokens(data, annotators)
    Tok-->>DPR: Tokens instance
    DPR-->>Caller: Tokens instance

    Caller->>Loc: locate_answers(answers, text)
    Loc->>DPR: DPR_tokenize(text)
    Loc->>Tok: words(uncased=True), offsets()
    Loc-->>Caller: [(offset, endpos), ...]
```

---

## Integration with the Broader System

The `dsp_tokenization` module sits within the `dsp` subsystem alongside retrieval and configuration utilities. It has no dependencies on higher-level DSPy modules, making it a low-level leaf utility.

```mermaid
graph LR
    subgraph "dsp subsystem"
        Tokenization["dsp_tokenization<br/>(this module)"]
        Retrieval["dsp_retrieval<br/>(ColBERTv2)"]
        Settings["dsp_settings<br/>(Settings)"]
        Utils["dsp_utils<br/>(dotdict, etc.)"]
    end

    Retrieval -.->|may use tokenization<br/>for answer matching| Tokenization
    Tokenization -.->|uses dotdict-style<br/>containers| Utils
```

### Related Modules

- **[dsp_retrieval](dsp_retrieval.md)** — The `ColBERTv2` retriever returns passages as `dotdict` objects; tokenization helpers are used to verify answer presence within retrieved passages.
- **[dsp_settings](dsp_settings.md)** — Global configuration singleton; tokenization itself is stateless and does not read settings, but operates within the same `dsp` subsystem.
- **[dsp_utils](dsp_utils.md)** — Provides `dotdict` and related container utilities used throughout the `dsp` subsystem.

---

## Design Notes and Constraints

1. **No linguistic annotation.** `SimpleTokenizer` only tokenizes. Requesting annotators (POS, lemma, NER) triggers a warning and is silently ignored. The `Tokens` annotation accessors (`pos()`, `lemmas()`, `entities()`) return `None` when the corresponding annotator is absent.

2. **Unicode normalization.** `DPR_tokenize` applies NFD normalization before tokenizing, and `strip_accents` removes combining marks. This ensures robust matching across accented characters.

3. **Whitespace preservation.** Each token tuple stores the whitespace span up to the next token, enabling faithful `untokenize()` reconstruction of the original text.

4. **Singleton reuse.** `STokenizer` is instantiated once at module load, so the compiled regex is shared across all helper calls — an important performance consideration for high-volume retrieval workloads.

5. **Upstream provenance.** The implementation is derived from Facebook Research's DPR project; the original license applies to the ported code.

---

## Summary

The `dsp_tokenization` module is a compact, dependency-light utility that provides:

- A pluggable `Tokenizer` abstraction,
- A Unicode-aware `SimpleTokenizer` implementation,
- A rich `Tokens` container with offset, n-gram, and entity-group support,
- Convenience helpers for answer detection and localization.

It serves as the foundational text-processing layer for retrieval and evaluation workflows within DSPy's `dsp` subsystem, and is designed to be reused via a shared singleton without external configuration.
