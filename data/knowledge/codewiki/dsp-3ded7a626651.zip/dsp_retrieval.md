# DSP Retrieval Module

## Introduction

The `dsp_retrieval` module provides the core retrieval primitives for DSPy, centered around **ColBERTv2** — a state-of-the-art late-interaction retrieval model. This module offers three complementary capabilities:

1. **Remote retrieval** via a hosted ColBERTv2 server (`ColBERTv2`).
2. **Local retrieval** by building and searching a ColBERT index over a local passage collection (`ColBERTv2RetrieverLocal`).
3. **Local reranking** of candidate passages using ColBERT scoring (`ColBERTv2RerankerLocal`).

These components act as the retrieval backend that plugs into DSPy's higher-level retrieval abstractions (such as `dspy.Retrieve` and the `dspy.settings.rm` configuration), enabling programs like `ReAct` and `KNN` to fetch relevant passages from a corpus.

---

## Module Architecture

The module is composed of three primary classes, each targeting a different retrieval scenario. All three return results as `dotdict` objects (or lists thereof), providing attribute-style access to passage fields such as `long_text`, `score`, and `pid`.

```mermaid
graph TD
    subgraph "dsp_retrieval"
        CB2["ColBERTv2<br/>(remote HTTP)"]
        CB2RL["ColBERTv2RetrieverLocal<br/>(local index + search)"]
        CB2RR["ColBERTv2RerankerLocal<br/>(local reranking)"]
    end

    subgraph "External Dependencies"
        REQ["requests"]
        COLBERT["colbert (colbert-ai)"]
        TORCH["torch"]
        NUMPY["numpy"]
    end

    subgraph "DSPy Internals"
        CACHE["dspy.clients.cache::request_cache"]
        DOTDICT["dspy.dsp.utils::dotdict"]
        SETTINGS["dspy.dsp.utils.settings::Settings"]
    end

    CB2 --> REQ
    CB2 --> CACHE
    CB2 --> DOTDICT

    CB2RL --> COLBERT
    CB2RL --> TORCH
    CB2RL --> DOTDICT

    CB2RR --> COLBERT
    CB2RR --> TORCH
    CB2RR --> NUMPY

    CB2 -.->|"configured via"| SETTINGS
    CB2RL -.->|"configured via"| SETTINGS
```

---

## Core Components

### ColBERTv2 (Remote Retrieval)

`ColBERTv2` is a lightweight wrapper around a **hosted ColBERTv2 HTTP server**. It is the simplest way to add retrieval to a DSPy program when an external ColBERT server is available.

**Key characteristics:**

- Constructed with a `url` and optional `port`; the final endpoint is `f"{url}:{port}"` when a port is supplied.
- Supports both **GET** and **POST** request modes via the `post_requests` flag.
- The `__call__` method accepts a `query`, a `k` (number of passages), and a `simplify` flag.
  - When `simplify=True`, it returns a plain `list[str]` of passage texts.
  - Otherwise, it returns a `list[dotdict]` with full passage metadata.

**Caching:** Both the GET and POST request helpers (`colbertv2_get_request`, `colbertv2_post_request`) are decorated with `@request_cache()`, so identical queries are served from DSPy's cache rather than re-hitting the network. See [clients_lm_core](clients_lm_core.md) for details on the caching subsystem.

**Constraints:** The hosted server supports `k <= 100`; larger values raise an assertion error.

```mermaid
sequenceDiagram
    participant User
    participant CB2 as ColBERTv2
    participant Cache as request_cache
    participant Server as ColBERTv2 Server

    User->>CB2: __call__(query, k, simplify)
    alt post_requests
        CB2->>Cache: colbertv2_post_request(url, query, k)
    else
        CB2->>Cache: colbertv2_get_request(url, query, k)
    end
    Cache->>Cache: check cache
    alt cache hit
        Cache-->>CB2: cached topk
    else cache miss
        Cache->>Server: HTTP request
        Server-->>Cache: JSON topk
        Cache-->>CB2: topk
    end
    CB2-->>User: list[dotdict] or list[str]
```

### ColBERTv2RetrieverLocal (Local Index + Search)

`ColBERTv2RetrieverLocal` builds and searches a **local ColBERT index** over a provided list of passages. It is intended for offline or self-hosted retrieval scenarios.

**Construction requirements:**

- A valid `colbert_config` (e.g., `colbert.infra.config.ColBERTConfig`) must be passed.
- The config must define a `checkpoint` (e.g., `colbert-ir/colbertv2.0`) and an `index_name`.
- A `load_only` flag controls whether to skip index building and only load an existing index.

**Lifecycle:**

1. If `load_only=False`, `build_index()` is invoked, which uses `colbert.Indexer` within a `Run` context to index the passage collection.
2. `get_index()` loads a `colbert.Searcher` for the configured index.

**Search (`forward`):**

- Accepts a `query` and `k` (default 7).
- Supports an optional `filtered_pids` keyword argument to restrict results to a specific set of passage IDs. When provided, a `filter_fn` is passed to the searcher, using CUDA if available.
- Returns a list of `dotdict` objects containing `long_text`, `score`, and `pid`.

```mermaid
flowchart TD
    A[ColBERTv2RetrieverLocal.__init__] --> B{load_only?}
    B -- No --> C[build_index]
    B -- Yes --> D[get_index]
    C --> D
    D --> E[Searcher ready]
    E --> F[forward query, k, filtered_pids?]
    F --> G{filtered_pids provided?}
    G -- Yes --> H[search with filter_fn]
    G -- No --> I[search plain]
    H --> J[build dotdict results]
    I --> J
    J --> K[return list of dotdict]
```

### ColBERTv2RerankerLocal (Local Reranking)

`ColBERTv2RerankerLocal` performs **reranking** of a candidate passage list against a query using ColBERT's late-interaction scoring. Unlike the retriever, it does not maintain an index; instead it scores a given set of passages directly.

**Construction:**

- Takes an optional `colbert_config` and a `checkpoint` (default `bert-base-uncased`).
- The checkpoint is written back into `colbert_config.checkpoint`.

**Reranking (`forward`):**

1. Asserts that `passages` is non-empty.
2. Sets `colbert_config.nway` to the number of passages.
3. Tokenizes the query and documents using `QueryTokenizer` and `DocTokenizer`.
4. Runs the `ColBERT` model to produce query and document embeddings.
5. Computes scores via `col.score(...)` and returns a NumPy array of passage scores.

```mermaid
flowchart LR
    Q[query] --> QT[QueryTokenizer]
    P[passages] --> DT[DocTokenizer]
    QT --> QE[ColBERT.query embeddings]
    DT --> DE[ColBERT.doc embeddings]
    QE --> SCORE[col.score]
    DE --> SCORE
    SCORE --> ARR[numpy score array]
```

---

## Component Interaction & Data Flow

The following diagram illustrates how the retrieval components integrate with the broader DSPy retrieval pipeline. The `ColBERTv2` instance is typically registered as the retrieval model (`rm`) in `dspy.settings`, which is then consumed by `dspy.Retrieve`.

```mermaid
graph LR
    subgraph "Configuration"
        SET["dspy.settings<br/>(rm = ColBERTv2(...))"]
    end

    subgraph "Retrieval Pipeline"
        RET["dspy.Retrieve"]
        RM["rm(query, k)"]
    end

    subgraph "dsp_retrieval"
        CB2["ColBERTv2"]
        CB2RL["ColBERTv2RetrieverLocal"]
        CB2RR["ColBERTv2RerankerLocal"]
    end

    SET --> RET
    RET --> RM
    RM --> CB2
    RM --> CB2RL
    CB2RR -.->|"rerank candidates"| RM
```

**Typical flow:**

1. A retrieval model is configured globally via `dspy.settings.configure(rm=...)` (see [dsp_settings](dsp_settings.md)).
2. `dspy.Retrieve` (see [retrievers](retrievers.md)) calls the configured `rm` with a query and `k`.
3. The `rm` — one of the `dsp_retrieval` components — returns passages as `dotdict` objects.
4. `Retrieve` extracts `long_text` from each passage and wraps them in a `Prediction`.

---

## Dependencies

| Dependency | Purpose | Used By |
|------------|---------|---------|
| `requests` | HTTP communication with hosted ColBERT server | `ColBERTv2` |
| `colbert` (colbert-ai) | Indexing, searching, and scoring | `ColBERTv2RetrieverLocal`, `ColBERTv2RerankerLocal` |
| `torch` | Tensor operations and CUDA device selection | `ColBERTv2RetrieverLocal`, `ColBERTv2RerankerLocal` |
| `numpy` | Score array construction | `ColBERTv2RerankerLocal` |
| `dspy.clients.cache::request_cache` | Response caching for HTTP requests | `ColBERTv2` |
| `dspy.dsp.utils::dotdict` | Attribute-accessible result containers | All components |
| `dspy.dsp.utils.settings::Settings` | Global retrieval model configuration | Indirectly, via `dspy.Retrieve` |

> **Note:** The `colbert` package is an optional dependency. Both local components attempt to import it and print an installation hint (`pip install colbert-ai[faiss-gpu,torch]`) if it is missing.

---

## Related Modules

- [dsp_settings](dsp_settings.md) — Global configuration singleton used to register the retrieval model.
- [dsp_utils](dsp_utils.md) — Provides `dotdict`, the result container used throughout this module.
- [dsp_tokenization](dsp_tokenization.md) — Tokenization utilities (DPR tokenizers) related to retrieval text processing.
- [clients_lm_core](clients_lm_core.md) — Caching subsystem (`request_cache`) used by remote retrieval.
- [retrievers](retrievers.md) — Higher-level retrieval abstractions (`Retrieve`, `Embeddings`, etc.) that consume these backends.
- [predict](predict.md) — Programs such as `ReAct` and `KNN` that leverage retrieval.

---

## Summary

The `dsp_retrieval` module delivers three focused ColBERTv2-based retrieval capabilities:

- **`ColBERTv2`** — remote, cached HTTP retrieval for quick integration.
- **`ColBERTv2RetrieverLocal`** — local index building and searching for self-hosted corpora.
- **`ColBERTv2RerankerLocal`** — local reranking of candidate passages.

Together they form the retrieval backbone that DSPy programs use to ground predictions in external knowledge, integrating cleanly with the global settings system and the higher-level `Retrieve` abstraction.
