# Teleprompt KNN Module

## Introduction

The `teleprompt_knn` module provides the **`KNNFewShot`** optimizer, a dynamic few-shot learning teleprompter for DSPy programs. Unlike static few-shot optimizers that attach a fixed set of demonstrations to a program, `KNNFewShot` performs **retrieval at inference time**: for every input example passed to a forward call, it retrieves the `k` most semantically similar examples from a training set and uses them as demonstrations for that specific call.

This makes `KNNFewShot` particularly well-suited for tasks where the optimal demonstrations vary significantly depending on the input — for example, question answering over heterogeneous domains, or classification tasks with many distinct categories.

The module is a thin orchestration layer that composes three existing DSPy subsystems:

- **`KNN`** ([predict_utilities](predict_utilities.md)) — an in-memory k-nearest-neighbors retriever.
- **`BootstrapFewShot`** ([teleprompt_bootstrap](teleprompt_bootstrap.md)) — a teleprompter that bootstraps demonstrations.
- **`Embedder`** ([clients_lm_core](clients_lm_core.md)) — a unified embedding interface.

---

## Architecture Overview

`KNNFewShot` extends the abstract `Teleprompter` base class and delegates its core responsibilities to the `KNN` retriever and the `BootstrapFewShot` optimizer.

```mermaid
graph TD
    subgraph "teleprompt_knn"
        KNNFewShot["KNNFewShot<br/>(Teleprompter)"]
    end

    subgraph "predict_utilities"
        KNN["KNN<br/>(retriever)"]
    end

    subgraph "teleprompt_bootstrap"
        BFS["BootstrapFewShot"]
    end

    subgraph "clients_lm_core"
        Embedder["Embedder"]
    end

    subgraph "primitives_data_containers"
        Example["Example"]
    end

    subgraph "teleprompt_core"
        Teleprompter["Teleprompter<br/>(abstract base)"]
    end

    KNNFewShot -->|extends| Teleprompter
    KNNFewShot -->|owns| KNN
    KNNFewShot -->|instantiates per call| BFS
    KNN -->|uses| Embedder
    KNN -->|returns| Example
    BFS -->|uses| Example
```

### Component Responsibilities

| Component | Role |
|-----------|------|
| `KNNFewShot` | Orchestrates retrieval + bootstrapping; overrides the student's `forward` method. |
| `KNN` | Vectorizes the trainset once, then retrieves the `k` nearest examples per query. |
| `BootstrapFewShot` | Bootstraps demonstrations from the retrieved neighbor set for the student program. |
| `Embedder` | Computes embeddings for both the trainset and incoming query inputs. |
| `Teleprompter` | Abstract base class defining the `compile` contract. |

---

## Core Component: `KNNFewShot`

### Constructor

```python
KNNFewShot(
    k: int,
    trainset: list[Example],
    vectorizer: Embedder,
    **few_shot_bootstrap_args,
)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `k` | `int` | Number of nearest neighbors to attach as demonstrations. |
| `trainset` | `list[Example]` | The training set used for few-shot retrieval. |
| `vectorizer` | `Embedder` | The embedder used to vectorize examples and queries. |
| `**few_shot_bootstrap_args` | `dict` | Forwarded to `BootstrapFewShot` (e.g. `metric`, `max_bootstrapped_demos`, `max_labeled_demos`, `max_rounds`). |

During construction, the optimizer immediately instantiates an internal `KNN` retriever, which eagerly vectorizes the entire `trainset` (see [Data Flow](#data-flow)).

### `compile(student, *, teacher=None)`

The `compile` method returns a **copy** of the student whose `forward` method has been replaced with a dynamic retrieval-and-bootstrap routine.

```python
def compile(self, student, *, teacher=None):
    student_copy = student.reset_copy()

    def forward_pass(_, **kwargs):
        knn_trainset = self.KNN(**kwargs)
        few_shot_bootstrap = BootstrapFewShot(**self.few_shot_bootstrap_args)
        compiled_program = few_shot_bootstrap.compile(
            student,
            teacher=teacher,
            trainset=knn_trainset,
        )
        return compiled_program(**kwargs)

    student_copy.forward = types.MethodType(forward_pass, student_copy)
    return student_copy
```

Key behaviors:

1. **Non-destructive**: The original `student` is never mutated; a `reset_copy()` is returned.
2. **Per-call retrieval**: Every invocation of the compiled program triggers a fresh `KNN` lookup using the call's keyword arguments.
3. **Per-call bootstrapping**: A new `BootstrapFewShot` instance is created and compiled against the retrieved neighbor set on each call.
4. **Method binding**: The custom `forward_pass` is bound to the copy via `types.MethodType`, so `self` refers to the student copy.

> **Note on performance**: Because bootstrapping runs on every forward call, `KNNFewShot` trades inference latency for input-adaptive demonstrations. For latency-sensitive workloads, consider caching or a static optimizer such as [teleprompt_bootstrap](teleprompt_bootstrap.md).

---

## Data Flow

The following diagram illustrates the end-to-end flow from construction through inference.

```mermaid
sequenceDiagram
    participant User
    participant KNNFewShot
    participant KNN
    participant Embedder
    participant BootstrapFewShot
    participant Student

    Note over KNNFewShot,KNN: Construction phase
    User->>KNNFewShot: __init__(k, trainset, vectorizer)
    KNNFewShot->>KNN: KNN(k, trainset, vectorizer)
    KNN->>Embedder: embed(trainset strings)
    Embedder-->>KNN: trainset_vectors (float32)
    KNN-->>KNNFewShot: retriever ready

    Note over KNNFewShot,Student: Compile phase
    User->>KNNFewShot: compile(student, teacher)
    KNNFewShot->>Student: reset_copy()
    KNNFewShot->>Student: bind forward_pass
    KNNFewShot-->>User: student_copy

    Note over User,Student: Inference phase (per call)
    User->>Student: student_copy(**kwargs)
    Student->>KNN: __call__(**kwargs)
    KNN->>Embedder: embed(query string)
    Embedder-->>KNN: query vector
    KNN->>KNN: cosine similarity + argsort
    KNN-->>Student: k nearest Examples
    Student->>BootstrapFewShot: compile(student, trainset=knn_trainset)
    BootstrapFewShot-->>Student: compiled_program
    Student->>Student: compiled_program(**kwargs)
    Student-->>User: Prediction
```

### Retrieval Mechanics

The `KNN` retriever performs the following steps:

1. **Trainset vectorization (once, at construction)**: Each `Example` is serialized into a string of the form `"key1: value1 | key2: value2"` using only its `_input_keys`, then embedded into a `float32` matrix.
2. **Query vectorization (per call)**: The incoming `kwargs` are serialized the same way and embedded.
3. **Similarity scoring**: A dot product between the trainset matrix and the query vector yields similarity scores.
4. **Top-k selection**: `scores.argsort()[-k:][::-1]` selects the `k` highest-scoring examples, returned as a list of `Example` objects.

```mermaid
flowchart LR
    A["trainset Examples"] -->|serialize input keys| B["'key: value | ...' strings"]
    B -->|Embedder| C["trainset_vectors<br/>(N x D float32)"]
    Q["query kwargs"] -->|serialize| R["query string"]
    R -->|Embedder| S["query vector (D)"]
    C -->|dot product| T["similarity scores"]
    S --> T
    T -->|argsort top-k| U["k nearest Examples"]
```

---

## Component Interaction

```mermaid
classDiagram
    class Teleprompter {
        <<abstract>>
        +compile(student, trainset, teacher, valset)
        +get_params()
    }
    class KNNFewShot {
        +KNN KNN
        +dict few_shot_bootstrap_args
        +__init__(k, trainset, vectorizer, **args)
        +compile(student, teacher)
    }
    class KNN {
        +int k
        +list trainset
        +Embedder embedding
        +ndarray trainset_vectors
        +__call__(**kwargs) list
    }
    class BootstrapFewShot {
        +compile(student, teacher, trainset)
    }
    class Embedder {
        +__call__(inputs, batch_size, caching)
        +acall(inputs, batch_size, caching)
    }

    Teleprompter <|-- KNNFewShot
    KNNFewShot --> KNN : owns
    KNNFewShot ..> BootstrapFewShot : instantiates per call
    KNN --> Embedder : uses
```

---

## Usage Example

```python
import dspy
from sentence_transformers import SentenceTransformer

# Define a QA module with chain of thought
qa = dspy.ChainOfThought("question -> answer")

# Create a training dataset with examples
trainset = [
    dspy.Example(question="What is the capital of France?", answer="Paris").with_inputs("question"),
    # ... more examples ...
]

# Initialize KNNFewShot with a sentence transformer model
knn_few_shot = dspy.KNNFewShot(
    k=3,
    trainset=trainset,
    vectorizer=dspy.Embedder(SentenceTransformer("all-MiniLM-L6-v2").encode),
)

# Compile the QA module with few-shot learning
compiled_qa = knn_few_shot.compile(qa)

# Use the compiled module
result = compiled_qa("What is the capital of Belgium?")
```

---

## Design Considerations

### Strengths

- **Input-adaptive demonstrations**: Each query receives demonstrations tailored to its semantics.
- **Composable**: Reuses the battle-tested `BootstrapFewShot` pipeline, so all its arguments (`metric`, `max_rounds`, etc.) are available.
- **Non-destructive compilation**: The original student module is preserved.

### Trade-offs

- **Inference cost**: Bootstrapping runs on every forward call, which can be expensive. The `KNN` retriever itself is cheap (a single dot product), but the `BootstrapFewShot.compile` step is not.
- **Eager vectorization**: The entire trainset is embedded at construction time, which may be costly for very large training sets.
- **Serialization dependency**: Retrieval quality depends on how `Example` input keys are stringified; examples with complex or non-string input values may not serialize meaningfully.

### Related Modules

- [predict_utilities](predict_utilities.md) — the `KNN` retriever used internally.
- [teleprompt_bootstrap](teleprompt_bootstrap.md) — the `BootstrapFewShot` optimizer used internally.
- [teleprompt_core](teleprompt_core.md) — the `Teleprompter` base class and other core optimizers.
- [clients_lm_core](clients_lm_core.md) — the `Embedder` interface.
- [primitives_data_containers](primitives_data_containers.md) — the `Example` data container.
