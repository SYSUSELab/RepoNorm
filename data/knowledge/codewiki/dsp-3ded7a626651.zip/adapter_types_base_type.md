# Adapter Types Base Type

## Introduction

The `adapter_types_base_type` module provides the foundational abstraction for **custom types** in DSPy signatures. At its core is the `BaseType` class, a Pydantic-based base class that enables developers to define rich, non-primitive data types (such as images, audio, tools, and conversation history) that can be embedded within DSPy signatures and correctly serialized/deserialized when communicating with Language Models (LMs).

The module also provides the `split_message_content_for_custom_types` utility, which post-processes formatted LM messages to split custom-type content into structured content blocks compatible with the OpenAI chat completions API.

This module is the parent of all concrete custom types in the `adapter_types` package:
- [Image](adapter_types_image.md)
- [Audio](adapter_types_audio.md)
- [History](adapter_types_history.md)
- [Tool](adapter_types_tool.md)

---

## Core Components

### `BaseType`

`BaseType` extends `pydantic.BaseModel` and serves as the contract that every DSPy custom type must fulfill. It defines:

| Member | Kind | Purpose |
|--------|------|---------|
| `format()` | instance method | Returns either a `list[dict[str, Any]]` (OpenAI content parts) or a `str`. Must be implemented by subclasses. |
| `description()` | classmethod | Returns a human-readable description of the custom type (defaults to empty string). |
| `extract_custom_type_from_annotation(annotation)` | classmethod | Recursively scans a type annotation to find all nested occurrences of the custom type. |
| `serialize_model()` | Pydantic model serializer | Wraps the `format()` output with reserved sentinel identifiers so it can be detected and split later. |

#### The `format()` Contract

Subclasses must implement `format()` to return a list of dictionaries matching the **Array of content parts** structure used in the OpenAI API user message `content` field. For example:

```python
class Image(BaseType):
    url: str

    def format(self) -> list[dict[str, Any]]:
        return [{"type": "image_url", "image_url": {"url": self.url}}]
```

#### Annotation Extraction

`extract_custom_type_from_annotation` is critical for signature introspection. It walks arbitrarily nested annotations (e.g., `list[dict[str, Tool]]`) and returns every concrete subclass of the custom type found. This allows adapters to discover which fields contain custom types without hardcoding type names.

```mermaid
flowchart TD
    A[Annotation] --> B{isinstance type and issubclass of cls?}
    B -- Yes --> C[Return annotation]
    B -- No --> D{get_origin is None?}
    D -- Yes --> E[Return empty list]
    D -- No --> F[Iterate get_args]
    F --> G[Recurse into each arg]
    G --> H[Aggregate results]
```

#### Serialization with Sentinel Identifiers

When a `BaseType` instance is serialized (e.g., during message formatting), `serialize_model()` wraps the `format()` output between two reserved sentinel strings:

```
<<CUSTOM-TYPE-START-IDENTIFIER>> ... <<CUSTOM-TYPE-END-IDENTIFIER>>
```

These sentinels act as markers that the `split_message_content_for_custom_types` utility later uses to locate and extract custom-type content from a flattened string message.

### `split_message_content_for_custom_types`

This function transforms a list of LM messages so that any user message containing custom-type content is split into a list of structured content blocks. This is required because DSPy adapters first flatten user input into a single string, and the custom-type content must be re-expanded into the OpenAI content-parts format for optimal model quality.

**Input:** A list of messages in OpenAI chat format (`role` / `content`).

**Output:** The same list, where user messages containing custom types have their `content` replaced by a list of content blocks.

Example transformation:

```python
# Before
{"role": "user", "content": "Describe this: <<CUSTOM-TYPE-START-IDENTIFIER>>[{"type": "image_url", ...}]<<CUSTOM-TYPE-END-IDENTIFIER>>"}

# After
{"role": "user", "content": [
    {"type": "text", "text": "Describe this: "},
    {"type": "image_url", "image_url": {"url": "..."}},
]}
```

---

## Architecture

The following diagram shows how `BaseType` sits at the center of the custom-type subsystem and how it interacts with the adapters and concrete types.

```mermaid
classDiagram
    class BaseType {
        +format() list|str
        +description() str
        +extract_custom_type_from_annotation(annotation) list
        +serialize_model() str|list
    }
    class Image {
        +url: str
        +format() list
    }
    class Audio {
        +data: str
        +audio_format: str
        +format() list
    }
    class Tool {
        +func: Callable
        +name: str
        +format() str
    }
    class History {
        +messages: list
    }

    BaseType <|-- Image
    BaseType <|-- Audio
    BaseType <|-- Tool
    pydantic.BaseModel <|-- BaseType
    pydantic.BaseModel <|-- History
```

> **Note:** `History` inherits directly from `pydantic.BaseModel` rather than `BaseType`, because it is a structural container for conversation turns rather than a content-part-producing type. See [History](adapter_types_history.md) for details.

---

## Data Flow

The end-to-end flow of a custom type from signature definition to LM-ready message is illustrated below.

```mermaid
sequenceDiagram
    participant User
    participant Signature
    participant Adapter as ChatAdapter
    participant BaseType
    participant Splitter as split_message_content_for_custom_types
    participant LM

    User->>Signature: Provide input with custom type (e.g., Image)
    Signature->>Adapter: format(signature, demos, inputs)
    Adapter->>BaseType: serialize_model() / format()
    BaseType-->>Adapter: sentinel-wrapped content
    Adapter->>Splitter: split_message_content_for_custom_types(messages)
    Splitter->>Splitter: regex match sentinels
    Splitter->>Splitter: json_repair.loads(inner content)
    Splitter-->>Adapter: messages with content blocks
    Adapter->>LM: Send structured messages
```

### Splitting Process Flow

```mermaid
flowchart TD
    A[Iterate messages] --> B{role == user?}
    B -- No --> A
    B -- Yes --> C[Build regex for sentinels]
    C --> D[Find all sentinel matches]
    D --> E{Match found?}
    E -- No --> A
    E -- Yes --> F[Append preceding text block]
    F --> G[Parse JSON inside sentinel]
    G --> H{Valid JSON?}
    H -- Yes --> I[Append each parsed content part]
    H -- No --> J[Append as raw text block]
    I --> K[Append trailing text block]
    J --> K
    K --> L[Replace message content with blocks]
    L --> A
```

---

## Component Interaction

`BaseType` is consumed primarily by the DSPy adapters, which are responsible for translating signatures and inputs into LM messages. The relationship is shown below.

```mermaid
flowchart LR
    subgraph Adapters
        CA[ChatAdapter]
        JA[JSONAdapter]
        XA[XMLAdapter]
        TSA[TwoStepAdapter]
    end
    subgraph Types
        BT[BaseType]
        IMG[Image]
        AUD[Audio]
        TL[Tool]
        HIST[History]
    end
    CA --> BT
    JA --> BT
    XA --> BT
    TSA --> BT
    BT --> IMG
    BT --> AUD
    BT --> TL
    HIST -.-> CA
```

- **Adapters** call `format()` / `serialize_model()` on custom types when building messages, and use `extract_custom_type_from_annotation` to detect custom-typed fields.
- **Concrete types** (`Image`, `Audio`, `Tool`) implement the `format()` contract to produce OpenAI-compatible content parts.
- **`split_message_content_for_custom_types`** is invoked by adapters (notably `ChatAdapter`) to re-expand flattened custom-type content into structured blocks.

For more on how adapters orchestrate this, see the adapter documentation:
- [ChatAdapter](adapters_core.md)
- [JSONAdapter](adapters_core.md)
- [XMLAdapter](adapters_core.md)
- [TwoStepAdapter](adapters_core.md)

---

## Dependencies

| Dependency | Role |
|------------|------|
| `pydantic` | Provides `BaseModel`, `model_serializer`, and validation infrastructure. |
| `json_repair` | Leniently parses JSON embedded within sentinel markers, tolerating malformed output. |
| `re` | Used to locate sentinel-delimited custom-type content. |
| `typing` (`get_args`, `get_origin`) | Enables recursive annotation traversal. |

---

## Key Design Considerations

1. **Sentinel-based serialization.** Because adapters flatten messages into strings, custom types are serialized with unique sentinel markers. This decouples the type definition from the message-splitting logic and keeps the format extensible.

2. **Recursive annotation extraction.** `extract_custom_type_from_annotation` handles arbitrary nesting, so custom types can appear inside `list`, `dict`, `Optional`, and other generic containers without special-casing.

3. **Python version compatibility.** The direct-match branch in `extract_custom_type_from_annotation` wraps `issubclass` in a `try/except TypeError` to accommodate behavioral differences between Python 3.10 and 3.11+ regarding `isinstance` on parameterized generics.

4. **Graceful JSON fallback.** When the content inside a sentinel is not valid JSON, `split_message_content_for_custom_types` falls back to treating it as a plain text block rather than raising an error.

5. **Separation of concerns.** `BaseType` defines *what* a custom type is and *how* it formats itself; the splitting utility defines *how* formatted content is re-expanded for the LM. Concrete types (Image, Audio, Tool) only need to implement `format()`.

---

## Related Modules

- [Image](adapter_types_image.md) — Image custom type producing `image_url` content parts.
- [Audio](adapter_types_audio.md) — Audio custom type producing `input_audio` content parts.
- [History](adapter_types_history.md) — Conversation history container.
- [Tool](adapter_types_tool.md) — Function-calling tool wrapper.
- [Adapters Core](adapters_core.md) — Adapters that consume custom types.
- [Signature](signatures.md) — Signatures whose fields may carry custom types.
