# Usage Tracking (`utils_usage_tracking`)

## Introduction

The `utils_usage_tracking` module provides a lightweight, context-scoped mechanism for
accumulating and aggregating Language Model (LM) token usage across a DSPy program
execution. Its central component, `UsageTracker`, records per-model usage entries
(prompt tokens, completion tokens, and any nested token-detail dictionaries) and can
compute merged totals on demand.

The module is intentionally decoupled from the LM call sites: it exposes a
`track_usage()` context manager that installs a fresh `UsageTracker` into the global
[`Settings`](dsp_settings.md) context. LM implementations (such as
[`LM`](clients_lm_core.md)) then read `settings.usage_tracker` and push usage data into
it after each non-cached completion. This design keeps usage accounting opt-in and
thread-local, avoiding any global mutable state outside of the existing settings
infrastructure.

---

## Module Architecture

The module consists of a single file, `dspy/utils/usage_tracker.py`, exporting two
public symbols:

| Symbol | Kind | Responsibility |
| --- | --- | --- |
| `UsageTracker` | class | Stores and aggregates usage entries keyed by LM name. |
| `track_usage` | context manager | Installs a `UsageTracker` into the active settings context and yields it. |

```mermaid
graph TD
    subgraph "utils_usage_tracking"
        UT["UsageTracker"]
        TU["track_usage()"]
    end

    subgraph "dsp_settings"
        S["Settings"]
    end

    subgraph "clients_lm_core"
        LM["LM / BaseLM"]
    end

    TU -->|"settings.context(usage_tracker=...)"| S
    TU -->|"creates"| UT
    LM -->|"reads settings.usage_tracker"| S
    LM -->|"add_usage(model, usage)"| UT
    UT -->|"get_total_tokens()"| Consumer["Caller / User Code"]
```

---

## Core Component: `UsageTracker`

`UsageTracker` is a plain Python object (no inheritance) that maintains an internal
mapping from LM name to a list of usage entries.

### Internal State

```python
self.usage_data = defaultdict(list)
```

The structure is a `defaultdict` keyed by the LM identifier string (e.g.
`"openai/gpt-4o-mini"`), where each value is a list of usage dictionaries:

```python
{
    "openai/gpt-4o-mini": [
        {"prompt_tokens": 100, "completion_tokens": 200},
        {"prompt_tokens": 300, "completion_tokens": 400},
    ],
}
```

### Methods

#### `add_usage(lm: str, usage_entry: dict)`

Appends a usage entry for the given LM. Empty entries are silently ignored, and each
entry is normalized via `_flatten_usage_entry` before storage.

```python
def add_usage(self, lm: str, usage_entry: dict):
    if len(usage_entry) > 0:
        self.usage_data[lm].append(self._flatten_usage_entry(usage_entry))
```

#### `get_total_tokens() -> dict[str, dict[str, Any]]`

Iterates over every tracked LM and folds its list of entries into a single merged
dictionary using `_merge_usage_entries`. Returns a mapping of LM name to aggregated
usage.

```python
def get_total_tokens(self) -> dict[str, dict[str, Any]]:
    total_usage_by_lm = {}
    for lm, usage_entries in self.usage_data.items():
        total_usage = {}
        for usage_entry in usage_entries:
            total_usage = self._merge_usage_entries(total_usage, usage_entry)
        total_usage_by_lm[lm] = total_usage
    return total_usage_by_lm
```

#### `_flatten_usage_entry(usage_entry)` *(private)*

Produces a shallow copy of the entry and converts the nested
`completion_tokens_details` and `prompt_tokens_details` fields (if present) into plain
`dict` objects. This guards against provider-specific mapping types (e.g. LiteLLM
response objects) leaking into the tracker's stored state.

#### `_merge_usage_entries(usage_entry1, usage_entry2)` *(private)*

Recursively merges two usage dictionaries:

- If either side is empty/`None`, the other is returned (as a copy).
- For each key, if either value is a `dict`, the merge recurses.
- Otherwise, numeric values are summed, treating `None` as `0`.

This recursion is what allows nested detail dictionaries (such as
`completion_tokens_details.reasoning_tokens`) to be aggregated correctly rather than
overwritten.

---

## Core Component: `track_usage()`

`track_usage` is a `@contextmanager` that wires a new `UsageTracker` into the active
[`Settings`](dsp_settings.md) context:

```python
@contextmanager
def track_usage():
    tracker = UsageTracker()
    with settings.context(usage_tracker=tracker):
        yield tracker
```

Because it uses `settings.context(...)`, the tracker is scoped to the current thread
(and any child threads spawned through DSPy's parallel primitives that inherit the
context). When the `with` block exits, the override is reset and the tracker is no
longer visible to LM calls.

### Usage Example

```python
import dspy

lm = dspy.LM("openai/gpt-4o-mini")
dspy.configure(lm=lm)

with dspy.utils.usage_tracker.track_usage() as tracker:
    dspy.Predict("q->a")(q="What is the capital of France?")

print(tracker.get_total_tokens())
# {"openai/gpt-4o-mini": {"prompt_tokens": ..., "completion_tokens": ..., ...}}
```

---

## Data Flow

The following sequence diagram shows how usage data flows from an LM call into the
tracker and out to the caller.

```mermaid
sequenceDiagram
    participant User
    participant TU as track_usage()
    participant S as Settings
    participant LM as LM.forward()
    participant UT as UsageTracker

    User->>TU: enter `with track_usage() as tracker`
    TU->>UT: UsageTracker()
    TU->>S: settings.context(usage_tracker=tracker)
    User->>LM: invoke program / LM call
    LM->>S: read settings.usage_tracker
    S-->>LM: tracker instance
    LM->>UT: add_usage(model, results.usage)
    User->>UT: get_total_tokens()
    UT-->>User: aggregated usage by LM
    User->>TU: exit context
    TU->>S: reset context override
```

### Integration with LM Call Sites

The tracker is populated by the LM layer. In
[`LM.forward` / `LM.aforward`](clients_lm_core.md), after a successful completion the
following guard runs:

```python
if not getattr(results, "cache_hit", False) and dspy.settings.usage_tracker and hasattr(results, "usage"):
    settings.usage_tracker.add_usage(self.model, dict(results.usage))
```

Key behaviors:

- **Cache-aware**: Usage is only recorded on cache misses (`cache_hit` is falsy), so
  repeated identical requests do not inflate token counts.
- **Opt-in**: If no `usage_tracker` is present in the settings context, nothing is
  recorded.
- **Provider-agnostic**: The raw `results.usage` mapping is passed through; the tracker
  normalizes nested detail fields itself.

---

## Component Interaction Overview

```mermaid
graph LR
    subgraph "Settings (thread-local context)"
        C["context(usage_tracker=...)"]
    end

    subgraph "UsageTracker"
        AU["add_usage()"]
        GTT["get_total_tokens()"]
        FU["_flatten_usage_entry()"]
        MU["_merge_usage_entries()"]
    end

    C --> AU
    AU --> FU
    GTT --> MU
    AU -.->|"stores entries"| DATA[("usage_data defaultdict")]
    GTT -.->|"reads entries"| DATA
```

---

## Design Notes

- **No global state**: The tracker is created per `track_usage()` invocation and lives
  only inside the settings context, so concurrent programs on different threads do not
  interfere with each other.
- **Recursive merging**: `_merge_usage_entries` handles arbitrarily nested numeric
  dictionaries, which is important because modern providers report token breakdowns
  (e.g. cached tokens, reasoning tokens) as nested objects.
- **Defensive flattening**: `_flatten_usage_entry` converts nested detail objects to
  plain dicts to avoid retaining references to provider response objects.
- **Empty-entry tolerance**: Both `add_usage` and `_merge_usage_entries` gracefully
  handle empty or `None` inputs.

---

## Related Modules

- [dsp_settings](dsp_settings.md) — the `Settings` singleton that hosts the
  `usage_tracker` context override.
- [clients_lm_core](clients_lm_core.md) — the `LM` / `BaseLM` classes that populate the
  tracker after each non-cached completion.
- [utils_parallel](utils_parallel.md) — parallel execution primitives that propagate
  settings context (and therefore the tracker) to child threads.
