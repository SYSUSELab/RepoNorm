# Teleprompt Core

## Introduction

The **Teleprompt Core** module provides the foundational abstractions for DSPy's program optimization (compilation) system. In DSPy, a *teleprompter* is an optimizer that takes a `Module` (a DSPy program) and a training set, and produces an optimized version of that program — typically by selecting demonstrations (few-shot examples), refining instructions, or ensembling multiple programs.

This module defines:

- **`Teleprompter`** — the abstract base class that establishes the `compile()` contract all optimizers must follow.
- **`LabeledFewShot`** — a minimal, deterministic optimizer that attaches labeled examples as demonstrations to every predictor.
- **`Ensemble`** — an optimizer that wraps multiple programs and combines their outputs via a reduction function (e.g., majority voting).

These three components form the *core* of the teleprompt family. More sophisticated optimizers (bootstrap, instruction optimization, finetuning, etc.) build on top of the `Teleprompter` interface defined here. See the related modules listed at the end of this document for those advanced optimizers.

---

## Architecture Overview

The teleprompt_core module sits between the **primitives** layer (which defines `Module`, `Example`, and `Prediction`) and the higher-level optimizer families. Every optimizer in DSPy ultimately inherits from `Teleprompter`.

```mermaid
graph TD
    subgraph "Primitives Layer"
        Module["Module<br/>(dspy/primitives/program.py)"]
        Example["Example<br/>(dspy/primitives/example.py)"]
        Prediction["Prediction<br/>(dspy/primitives/prediction.py)"]
    end

    subgraph "Teleprompt Core"
        Teleprompter["Teleprompter<br/>(abstract base)"]
        LabeledFewShot["LabeledFewShot"]
        Ensemble["Ensemble"]
    end

    subgraph "Advanced Optimizers (other modules)"
        Bootstrap["BootstrapFewShot"]
        COPRO["COPRO"]
        MIPRO["MIPROv2"]
        Finetune["BootstrapFinetune"]
    end

    Teleprompter --> LabeledFewShot
    Teleprompter --> Ensemble
    Teleprompter --> Bootstrap
    Teleprompter --> COPRO
    Teleprompter --> MIPRO
    Teleprompter --> Finetune

    LabeledFewShot -.uses.-> Module
    LabeledFewShot -.uses.-> Example
    Ensemble -.uses.-> Module
    Ensemble -.uses.-> Prediction
```

### Component Relationships

```mermaid
classDiagram
    class Teleprompter {
        +compile(student, trainset, teacher, valset, **kwargs) Module
        +get_params() dict
    }

    class LabeledFewShot {
        +int k
        +compile(student, trainset, sample) Module
    }

    class Ensemble {
        +reduce_fn
        +int size
        +bool deterministic
        +compile(programs) Module
    }

    Teleprompter <|-- LabeledFewShot
    Teleprompter <|-- Ensemble
```

---

## Core Components

### `Teleprompter` (Abstract Base Class)

**File:** `dspy/teleprompt/teleprompt.py`

`Teleprompter` is the abstract base class for all DSPy optimizers. It defines the interface that every optimizer must implement, most importantly the `compile()` method.

#### Interface

| Method | Signature | Description |
|--------|-----------|-------------|
| `compile` | `compile(student, *, trainset, teacher=None, valset=None, **kwargs) -> Module` | Optimizes the student program. Must be overridden by subclasses. |
| `get_params` | `get_params() -> dict[str, Any]` | Returns the teleprompter's configuration parameters (defaults to `self.__dict__`). |

#### `compile()` Contract

The `compile()` method is the central entry point for optimization. Its parameters are:

- **`student`** (`Module`): The program to be optimized. Optimizers typically operate on a *copy* of the student (via `reset_copy()` or `deepcopy()`) so the original is not mutated.
- **`trainset`** (`list[Example]`): The training examples used to guide optimization.
- **`teacher`** (`Optional[Module]`): An optional teacher program used to generate demonstrations or guidance. When `None`, the student itself often serves as the teacher.
- **`valset`** (`Optional[list[Example]]`): An optional validation set for evaluating candidate programs.
- **`**kwargs`**: Optimizer-specific configuration.

The base implementation raises `NotImplementedError`, enforcing that subclasses provide their own logic.

```mermaid
sequenceDiagram
    participant User
    participant Teleprompter
    participant Student as Student Module
    participant Trainset

    User->>Teleprompter: compile(student, trainset=...)
    Teleprompter->>Student: reset_copy() / deepcopy()
    Teleprompter->>Trainset: iterate examples
    Teleprompter->>Student: attach demos / update instructions
    Teleprompter-->>User: optimized Module
```

---

### `LabeledFewShot`

**File:** `dspy/teleprompt/vanilla.py`

`LabeledFewShot` is the simplest concrete optimizer. It attaches a fixed number of labeled examples from the training set directly as demonstrations (`demos`) to every predictor in the student program. It performs **no bootstrapping** and **no instruction optimization** — it is a "vanilla" few-shot setup.

#### Constructor

```python
LabeledFewShot(k=16)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `k` | `int` | `16` | Maximum number of demonstrations to attach to each predictor. |

#### `compile()` Behavior

```python
compile(student, *, trainset, sample=True)
```

1. Creates a fresh copy of the student via `student.reset_copy()`.
2. If the training set is empty, returns the student unchanged.
3. Uses a **seeded RNG** (`random.Random(0)`) for reproducibility.
4. For each predictor in the student:
   - If `sample=True`: randomly samples `min(k, len(trainset))` examples.
   - If `sample=False`: takes the first `min(k, len(trainset))` examples.
   - Assigns them to `predictor.demos`.

#### Process Flow

```mermaid
flowchart TD
    Start([compile called]) --> Copy["student.reset_copy()"]
    Copy --> Empty{"trainset empty?"}
    Empty -->|Yes| Return["return student"]
    Empty -->|No| RNG["rng = random.Random(0)"]
    RNG --> Loop{"for each predictor"}
    Loop --> Sample{"sample=True?"}
    Sample -->|Yes| Rand["rng.sample(trainset, min(k, len))"]
    Sample -->|No| First["trainset[:min(k, len)]"]
    Rand --> Assign["predictor.demos = ..."]
    First --> Assign
    Assign --> Loop
    Loop -->|done| Return2["return student"]
```

> **Note:** Because `LabeledFewShot` relies on downstream code to handle the demos, the sampling may be sub-sampled further. The `sample` flag controls whether examples are drawn randomly or taken sequentially.

---

### `Ensemble`

**File:** `dspy/teleprompt/ensemble.py`

`Ensemble` combines the outputs of multiple programs into a single program. It is useful for improving robustness by aggregating predictions — for example, using `dspy.majority` as the reduction function to perform majority voting.

#### Constructor

```python
Ensemble(*, reduce_fn=None, size=None, deterministic=False)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `reduce_fn` | `Callable` | `None` | Function that reduces a list of outputs into a single output. A common choice is `dspy.majority`. |
| `size` | `int` | `None` | Number of programs to sample per forward call. If `None`, all programs are used. |
| `deterministic` | `bool` | `False` | Reserved for deterministic ensembling (currently must be `False`). |

> **Note:** `deterministic=True` is not yet implemented and will raise an assertion error. The TODO comment indicates that example hashing is required for deterministic ensembling.

#### `compile()` Behavior

Unlike other optimizers, `Ensemble.compile()` takes a **list of programs** rather than a single student:

```python
compile(programs)
```

It returns an `EnsembledProgram` — a dynamically created `dspy.Module` subclass whose `forward()` method:

1. Samples `size` programs (or uses all if `size` is `None`).
2. Runs each program on the same inputs.
3. Applies `reduce_fn` to the list of outputs (if provided), otherwise returns the raw list.

#### Process Flow

```mermaid
flowchart TD
    Start([compile programs]) --> Create["Create EnsembledProgram(programs)"]
    Create --> Return["return EnsembledProgram instance"]

    subgraph "forward(*args, **kwargs)"
        FStart([forward called]) --> Sample{"size set?"}
        Sample -->|Yes| Rand["random.sample(programs, size)"]
        Sample -->|No| All["use all programs"]
        Rand --> Run["outputs = [prog(*args, **kwargs) for prog in programs]"]
        All --> Run
        Run --> Reduce{"reduce_fn set?"}
        Reduce -->|Yes| Apply["return reduce_fn(outputs)"]
        Reduce -->|No| Raw["return outputs"]
    end
```

> **TODO (from source):** The `EnsembledProgram` should ideally imitate the structure of the individual programs (if they are all compatible). This would allow compiling with an ensemble program as a singular teacher — the top majority-compatible trace would be used when `dspy.majority` is the `reduce_fn`.

---

## Data Flow

The following diagram illustrates how data flows through a typical teleprompt_core optimization cycle, from raw examples to an optimized program.

```mermaid
flowchart LR
    subgraph Inputs
        TS["trainset<br/>(list[Example])"]
        ST["student<br/>(Module)"]
        TE["teacher<br/>(Module, optional)"]
    end

    subgraph "Teleprompter.compile()"
        CP["Copy student<br/>(reset_copy / deepcopy)"]
        OPT["Optimization logic<br/>(attach demos / update instructions)"]
    end

    subgraph Outputs
        OP["Optimized Module<br/>(with demos / instructions)"]
    end

    TS --> OPT
    ST --> CP
    TE --> OPT
    CP --> OPT
    OPT --> OP
```

### Example Lifecycle

`Example` objects (from the [primitives module](primitives_data_containers.md)) are the currency of optimization:

1. **Inputs** are extracted via `example.inputs()` (requires `with_inputs()` to have been called).
2. **Labels** are extracted via `example.labels()`.
3. Optimizers attach examples to `predictor.demos` as demonstrations.
4. Bootstrapped examples (in advanced optimizers) are created with `dspy.Example(augmented=True, **inputs, **outputs)`.

---

## How the Module Fits into the System

The teleprompt_core module is the **root of the optimizer hierarchy**. All other teleprompt submodules extend `Teleprompter`:

```mermaid
graph TD
    Teleprompter["Teleprompter<br/>(teleprompt_core)"]

    Teleprompter --> Bootstrap["BootstrapFewShot<br/>BootstrapFewShotWithRandomSearch<br/>BootstrapFewShotWithOptuna<br/>InferRules<br/>(teleprompt_bootstrap)"]
    Teleprompter --> Instruction["COPRO<br/>MIPROv2<br/>SignatureOptimizer<br/>(teleprompt_instruction)"]
    Teleprompter --> Finetune["BootstrapFinetune<br/>GRPO<br/>BetterTogether<br/>(teleprompt_finetune)"]
    Teleprompter --> Simba["SIMBA<br/>(teleprompt_simba)"]
    Teleprompter --> Avatar["AvatarOptimizer<br/>(teleprompt_avatar)"]
    Teleprompter --> KNN["KNNFewShot<br/>(teleprompt_knn)"]

    LabeledFewShot["LabeledFewShot<br/>(teleprompt_core)"] -.used by.-> Bootstrap
    Ensemble["Ensemble<br/>(teleprompt_core)"] -.composed with.-> Finetune
```

### Key Integration Points

| Integration | Description |
|-------------|-------------|
| **`Module`** | The unit being optimized. Optimizers call `reset_copy()`, `deepcopy()`, `predictors()`, and `named_predictors()`. See [primitives_module_system.md](primitives_module_system.md). |
| **`Example`** | The training data unit. Optimizers read `inputs()`/`labels()` and attach examples as `demos`. See [primitives_data_containers.md](primitives_data_containers.md). |
| **`Predict` / `Parameter`** | The optimizable parameters. `LabeledFewShot` sets `predictor.demos`; instruction optimizers set `predictor.signature`. See [predict_core.md](predict_core.md). |
| **`Evaluate`** | Used by advanced optimizers (e.g., `COPRO`) to score candidate programs. See [evaluate_orchestration.md](evaluate_orchestration.md). |
| **`LabeledFewShot`** | Reused internally by `BootstrapFewShot` to seed the teacher with labeled demos. See [teleprompt_bootstrap.md](teleprompt_bootstrap.md). |

---

## Usage Examples

### LabeledFewShot

```python
import dspy
from dspy.teleprompt import LabeledFewShot

# Assume `program` is a dspy.Module and `trainset` is a list of dspy.Example
teleprompter = LabeledFewShot(k=8)
optimized_program = teleprompter.compile(program, trainset=trainset)
```

### Ensemble

```python
import dspy
from dspy.teleprompt import Ensemble

# Combine multiple programs with majority voting
ensemble = Ensemble(reduce_fn=dspy.majority)
ensembled_program = ensemble.compile([program_a, program_b, program_c])

result = ensembled_program(question="What is the capital of France?")
```

### Custom Teleprompter

```python
from dspy.teleprompt import Teleprompter

class MyOptimizer(Teleprompter):
    def __init__(self, my_param=1):
        self.my_param = my_param

    def compile(self, student, *, trainset, teacher=None, valset=None, **kwargs):
        optimized = student.reset_copy()
        # ... custom optimization logic ...
        return optimized
```

---

## Summary

| Component | Role | Key Method |
|-----------|------|------------|
| `Teleprompter` | Abstract base defining the optimizer contract | `compile()` |
| `LabeledFewShot` | Attaches labeled examples as demos | `compile(student, trainset, sample)` |
| `Ensemble` | Combines multiple programs via a reduce function | `compile(programs)` |

The teleprompt_core module establishes the **interface and simplest implementations** of DSPy's optimization system. Advanced optimizers in sibling modules inherit from `Teleprompter` and reuse `LabeledFewShot` and `Ensemble` as building blocks.

---

## Related Modules

- [primitives_module_system.md](primitives_module_system.md) — `Module`, `BaseModule`, `ProgramMeta`
- [primitives_data_containers.md](primitives_data_containers.md) — `Example`, `Prediction`, `Completions`
- [predict_core.md](predict_core.md) — `Predict`, `Parameter` (the optimizable units)
- [teleprompt_bootstrap.md](teleprompt_bootstrap.md) — `BootstrapFewShot` and variants
- [teleprompt_instruction.md](teleprompt_instruction.md) — `COPRO`, `MIPROv2`, `SignatureOptimizer`
- [teleprompt_finetune.md](teleprompt_finetune.md) — `BootstrapFinetune`, `GRPO`, `BetterTogether`
- [teleprompt_simba.md](teleprompt_simba.md) — `SIMBA`
- [teleprompt_avatar.md](teleprompt_avatar.md) — `AvatarOptimizer`
- [teleprompt_knn.md](teleprompt_knn.md) — `KNNFewShot`
- [evaluate_orchestration.md](evaluate_orchestration.md) — `Evaluate`
