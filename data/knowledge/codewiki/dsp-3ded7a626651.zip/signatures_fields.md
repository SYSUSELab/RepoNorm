# Signatures Fields

## Introduction

The `signatures_fields` module provides the field-level primitives used to declare the inputs and outputs of a DSPy [`Signature`](signatures_core.md). It defines the legacy field classes (`OldField`, `OldInputField`, `OldOutputField`) along with the helper functions (`InputField`, `OutputField`, `move_kwargs`, `new_to_old_field`) that bridge DSPy's field semantics with Pydantic's `Field` machinery.

At its core, this module answers a single question: **how does a developer annotate a field so that DSPy knows whether it is an input or an output, and how should that field be rendered into a prompt?** The answer is encoded in the `__dspy_field_type` marker and a set of DSPy-specific metadata keys (`desc`, `prefix`, `format`, `parser`) that are smuggled into Pydantic's `json_schema_extra` dictionary.

> **Note:** The `Old*` classes are retained for backward compatibility. New code should prefer the `InputField` / `OutputField` functions, which integrate directly with Pydantic v2 and are consumed by [`SignatureMeta`](signatures_core.md).

---

## Architecture Overview

The module sits between the user-facing signature declaration API and Pydantic's validation/serialization layer. It is a dependency of the [`signatures_core`](signatures_core.md) module, which reads the metadata produced here.

```mermaid
graph TD
    User["User code<br/>class MySig(Signature):<br/>  q = InputField()<br/>  a = OutputField()"]
    Fields["signatures_fields<br/>(this module)"]
    Pydantic["Pydantic Field / FieldInfo"]
    Core["signatures_core<br/>Signature, SignatureMeta"]

    User -->|calls| Fields
    Fields -->|move_kwargs + pydantic.Field| Pydantic
    Pydantic -->|FieldInfo with json_schema_extra| Core
    Core -->|reads __dspy_field_type, prefix, desc| Fields
```

### Key Responsibilities

| Responsibility | Implementation |
| --- | --- |
| Mark a field as input or output | `InputField`, `OutputField` set `__dspy_field_type` |
| Separate DSPy args from Pydantic args | `move_kwargs` |
| Translate Pydantic constraints to human-readable text | `_translate_pydantic_field_constraints` |
| Provide ergonomic legacy field objects | `OldField`, `OldInputField`, `OldOutputField` |
| Convert new-style fields back to legacy objects | `new_to_old_field` |

---

## Component Reference

### Constants

#### `DSPY_FIELD_ARG_NAMES`

```python
DSPY_FIELD_ARG_NAMES = ["desc", "prefix", "format", "parser", "__dspy_field_type"]
```

The list of argument names that belong to DSPy rather than Pydantic. Any keyword argument matching one of these names is routed into `json_schema_extra` instead of being passed directly to `pydantic.Field`. This avoids name clashes with Pydantic's own reserved arguments.

#### `PYDANTIC_CONSTRAINT_MAP`

```python
PYDANTIC_CONSTRAINT_MAP = {
    "gt": "greater than: ",
    "ge": "greater than or equal to: ",
    "lt": "less than: ",
    "le": "less than or equal to: ",
    "min_length": "minimum length: ",
    "max_length": "maximum length: ",
    "multiple_of": "a multiple of the given number: ",
    "allow_inf_nan": "allow 'inf', '-inf', 'nan' values: ",
}
```

Maps Pydantic constraint keywords to human-readable phrases. These phrases are injected into the field's `desc` metadata so that the language model receives explicit guidance about the constraint (e.g., "greater than: 0").

---

### Functions

#### `move_kwargs(**kwargs)`

The central translation function. It splits incoming keyword arguments into two buckets:

- **DSPy arguments** (those in `DSPY_FIELD_ARG_NAMES`) → placed into `json_schema_extra`.
- **Pydantic arguments** (everything else) → passed through to `pydantic.Field`.

It also performs two convenience behaviors:

1. If a Pydantic `description` is supplied but no DSPy `desc`, the description is copied into `desc`.
2. Pydantic constraints are translated via `_translate_pydantic_field_constraints` and stored under `json_schema_extra["constraints"]`.

```python
def move_kwargs(**kwargs):
    pydantic_kwargs = {}
    json_schema_extra = {}
    for k, v in kwargs.items():
        if k in DSPY_FIELD_ARG_NAMES:
            json_schema_extra[k] = v
        else:
            pydantic_kwargs[k] = v
    if "description" in kwargs and "desc" not in json_schema_extra:
        json_schema_extra["desc"] = kwargs["description"]
    constraints = _translate_pydantic_field_constraints(**kwargs)
    if constraints:
        json_schema_extra["constraints"] = constraints
    pydantic_kwargs["json_schema_extra"] = json_schema_extra
    return pydantic_kwargs
```

#### `_translate_pydantic_field_constraints(**kwargs)`

A private helper that iterates over the keyword arguments, looks each up in `PYDANTIC_CONSTRAINT_MAP`, and joins the matching human-readable phrases with commas.

```python
def _translate_pydantic_field_constraints(**kwargs):
    constraints = []
    for key, value in kwargs.items():
        if key in PYDANTIC_CONSTRAINT_MAP:
            constraints.append(f"{PYDANTIC_CONSTRAINT_MAP[key]}{value}")
    return ", ".join(constraints)
```

#### `InputField(**kwargs)`

Public factory that produces a Pydantic field marked as an **input**. It delegates to `move_kwargs` with `__dspy_field_type="input"`.

```python
def InputField(**kwargs):
    return pydantic.Field(**move_kwargs(**kwargs, __dspy_field_type="input"))
```

#### `OutputField(**kwargs)`

Public factory that produces a Pydantic field marked as an **output**. It delegates to `move_kwargs` with `__dspy_field_type="output"`.

```python
def OutputField(**kwargs):
    return pydantic.Field(**move_kwargs(**kwargs, __dspy_field_type="output"))
```

#### `new_to_old_field(field)`

Converts a new-style Pydantic `FieldInfo` (produced by `InputField`/`OutputField`) into the corresponding legacy `OldInputField` or `OldOutputField`, preserving `prefix`, `desc`, and `format`.

```python
def new_to_old_field(field):
    return (OldInputField if field.json_schema_extra["__dspy_field_type"] == "input" else OldOutputField)(
        prefix=field.json_schema_extra["prefix"],
        desc=field.json_schema_extra["desc"],
        format=field.json_schema_extra.get("format"),
    )
```

---

### Classes

#### `OldField`

> **Legacy.** A more ergonomic datatype that infers `prefix` and `desc` if omitted.

```python
class OldField:
    def __init__(self, *, prefix=None, desc=None, input, format=None):
        self.prefix = prefix  # This can be None initially and set later
        self.desc = desc
        self.format = format
```

| Attribute | Type | Description |
| --- | --- | --- |
| `prefix` | `str \| None` | The prompt prefix for the field. May be `None` until `finalize` is called. |
| `desc` | `str \| None` | The field description. May be `None` until `finalize` is called. |
| `format` | `str \| None` | Optional format hint for the field. |

**Methods:**

- `finalize(key, inferred_prefix)` — Sets `prefix` to `inferred_prefix + ":"` if not provided, and sets `desc` to `f"${{{key}}}"` if not provided.
- `__repr__` — Returns `OldField(prefix=..., desc=...)`.
- `__eq__` — Compares instances by their `__dict__`.

#### `OldInputField(OldField)`

A subclass of `OldField` that fixes `input=True`. Constructed with `prefix`, `desc`, and `format`.

```python
class OldInputField(OldField):
    def __init__(self, *, prefix=None, desc=None, format=None):
        super().__init__(prefix=prefix, desc=desc, input=True, format=format)
```

#### `OldOutputField(OldField)`

A subclass of `OldField` that fixes `input=False`. Constructed with `prefix`, `desc`, and `format`.

```python
class OldOutputField(OldField):
    def __init__(self, *, prefix=None, desc=None, format=None):
        super().__init__(prefix=prefix, desc=desc, input=False, format=format)
```

---

## Data Flow

The following diagram shows how a field declaration flows from user code, through this module, into Pydantic, and finally into the signature metadata consumed by [`SignatureMeta`](signatures_core.md).

```mermaid
sequenceDiagram
    participant U as User
    participant F as signatures_fields
    participant P as Pydantic
    participant S as SignatureMeta (signatures_core)

    U->>F: InputField(desc="question", gt=0)
    F->>F: move_kwargs(desc="question", gt=0, __dspy_field_type="input")
    F->>F: _translate_pydantic_field_constraints(gt=0)
    Note over F: constraints = "greater than: 0"
    F->>P: pydantic.Field(json_schema_extra={desc, __dspy_field_type, constraints})
    P-->>S: FieldInfo
    S->>S: _validate_fields() reads __dspy_field_type
    S->>S: infer prefix / desc if missing
```

---

## Field Metadata Contract

The metadata written into `json_schema_extra` is the contract between this module and [`signatures_core`](signatures_core.md). The table below summarizes the keys.

| Key | Set by | Consumed by | Purpose |
| --- | --- | --- | --- |
| `__dspy_field_type` | `InputField` / `OutputField` | `SignatureMeta._validate_fields`, `_get_fields_with_type` | Distinguishes input vs. output fields |
| `desc` | `move_kwargs` (or copied from `description`) | `SignatureMeta` (defaults to `${name}`) | Human-readable field description |
| `prefix` | `move_kwargs` (or inferred by `SignatureMeta`) | `SignatureMeta` (defaults to `infer_prefix(name) + ":"`) | Prompt prefix for the field |
| `format` | `move_kwargs` | Adapters / `new_to_old_field` | Optional formatting hint |
| `parser` | `move_kwargs` | Adapters | Optional custom parser |
| `constraints` | `_translate_pydantic_field_constraints` | Prompt rendering | Human-readable constraint text |

---

## Relationship to Other Modules

- **[signatures_core](signatures_core.md)** — The primary consumer of this module. `SignatureMeta` validates that every field carries a valid `__dspy_field_type`, infers missing `prefix`/`desc` values, and exposes `input_fields` / `output_fields` by filtering on the marker set here.
- **adapters** — Adapters (e.g., `ChatAdapter`, `JSONAdapter`) read the `prefix`, `desc`, `format`, and `parser` metadata to render fields into prompts and parse model outputs.
- **predict** — Predictors such as `Predict` and `ChainOfThought` rely on signatures whose fields were declared using `InputField` / `OutputField`.

---

## Usage Example

```python
import dspy
from dspy.signatures.field import InputField, OutputField

class QA(dspy.Signature):
    """Answer a question given some context."""

    context = InputField(desc="Relevant background information")
    question = InputField(desc="The question to answer")
    answer = OutputField(desc="A concise answer", max_length=100)
```

In this example:

- `context` and `question` are marked as inputs via `__dspy_field_type="input"`.
- `answer` is marked as an output, and its `max_length=100` constraint is translated into the human-readable text `"maximum length: 100"` stored under `json_schema_extra["constraints"]`.

---

## Summary

The `signatures_fields` module is a thin but essential translation layer. It:

1. Provides the `InputField` / `OutputField` factories that developers use to declare signature fields.
2. Separates DSPy-specific metadata from Pydantic arguments via `move_kwargs`.
3. Encodes field semantics in `json_schema_extra` for downstream consumption by [`signatures_core`](signatures_core.md) and adapters.
4. Retains the legacy `OldField` hierarchy for backward compatibility and provides `new_to_old_field` for migration.
