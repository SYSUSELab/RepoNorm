# Clients Finetune Utils

## Introduction

The `clients_finetune_utils` module (`dspy/clients/utils_finetune.py`) provides the shared data contracts, enumerations, and validation utilities that underpin DSPy's fine-tuning and reinforcement-learning (GRPO) workflows. It defines the canonical data formats exchanged between DSPy teleprompters (e.g., `BootstrapFinetune`, `GRPO`) and the various model providers (OpenAI, Databricks, Arbor), and it offers helpers for persisting and validating training data on disk.

This module is a foundational dependency for the [clients_providers](clients_providers.md) module, whose `TrainingJob` and `ReinforceJob` implementations consume the types defined here.

---

## Module Purpose

The module serves three primary responsibilities:

1. **Type Contracts** — Defines the `TypedDict` structures (`Message`, `MessageAssistant`, `GRPOChatData`) and enumerations (`TrainDataFormat`, `TrainingStatus`) that standardize how training data and job states are represented across providers.
2. **Data Validation** — Provides `validate_data_format` and its helper functions to verify that training data conforms to the expected schema before being sent to a provider.
3. **Data Persistence** — Provides `save_data`, `write_lines`, and `get_finetune_directory` to serialize training data to JSONL files in a deterministic, content-addressed manner.

---

## Core Components

### Enumerations

#### `TrainingStatus`

A `str`-based `Enum` describing the lifecycle state of a fine-tuning job. Because it inherits from `str`, its values can be compared directly against provider-returned status strings.

| Value | Meaning |
|-------|---------|
| `not_started` | Job has been created but not yet submitted |
| `pending` | Job is queued at the provider |
| `running` | Job is actively training |
| `succeeded` | Job completed successfully |
| `failed` | Job terminated with an error |
| `cancelled` | Job was cancelled by the user |

This enum is returned by the `status()` method of every `TrainingJob` subclass (see [clients_providers](clients_providers.md)).

#### `TrainDataFormat`

A `str`-based `Enum` describing the schema of the training data payload.

| Value | Description |
|-------|-------------|
| `chat` | OpenAI-style chat data: a dict with a `messages` key holding a list of role/content messages |
| `completion` | Legacy completion data: a dict with `prompt` and `completion` string keys |
| `grpo_chat` | Group-relative policy optimization data: a list of `GRPOChatData` groups |

The format is typically inferred from the adapter in use via `infer_data_format`.

### TypedDicts

#### `Message`

```python
class Message(TypedDict):
    role: Union[Literal["user"], Literal["assistant"], Literal["system"]]
    content: str
```

A single chat message with a constrained `role` and string `content`.

#### `MessageAssistant`

```python
class MessageAssistant(TypedDict):
    role: Literal["assistant"]
    content: str
```

A specialization of `Message` where the role is fixed to `"assistant"`. Used to represent the model's target completion in GRPO data.

#### `GRPOChatData`

```python
class GRPOChatData(TypedDict):
    messages: List[Message]
    completion: MessageAssistant
    reward: float
```

A single GRPO training sample: the conversation context (`messages`), the assistant's `completion`, and the scalar `reward` assigned to that completion. A `GRPOGroup` (a type alias for `List[GRPOChatData]`) represents a set of completions sampled for the same prompt, which is the unit of a GRPO training step.

### Functions

#### `infer_data_format(adapter: Adapter) -> str`

Infers the appropriate `TrainDataFormat` from a DSPy [Adapter](adapters_core.md). Currently only `ChatAdapter` is recognized, mapping to `TrainDataFormat.CHAT`. Any other adapter raises a `ValueError`.

#### `get_finetune_directory() -> str`

Resolves and creates the directory used to store fine-tuning artifacts. It honors the `DSPY_FINETUNEDIR` environment variable, falling back to `<DSPY_CACHEDIR>/finetune`. The directory is created if it does not exist, and the absolute path is returned.

#### `write_lines(file_path, data)`

Writes an iterable of objects to a file, one JSON-serialized object per line (JSONL), using `ujson` for fast serialization.

#### `save_data(data: List[Dict[str, Any]]) -> str`

Persists a list of training records to a JSONL file whose name is derived from a content hash (`datasets.fingerprint.Hasher`). This content-addressing ensures identical data maps to the same file, avoiding redundant writes. Returns the absolute path to the written file.

#### `validate_data_format(data, data_format: TrainDataFormat)`

The primary validation entry point. It:

1. Selects the appropriate per-record error-finding function based on `data_format`.
2. Verifies `data` is a list.
3. Iterates over each record, collecting errors.
4. If any errors are found, writes them to `data_format_errors.log` in the fine-tune directory and raises a `ValueError` pointing to that log.

#### `find_data_errors_completion(data_dict) -> Optional[str]`

Validates a single completion-format record, requiring exactly the keys `prompt` and `completion`, both of type `str`.

#### `find_data_error_chat(messages) -> Optional[str]`

Validates a single chat-format record, requiring exactly a `messages` key whose value is a list. Delegates per-message validation to `find_data_error_chat_message`.

#### `find_data_error_chat_message(message) -> Optional[str]`

Validates a single chat message, requiring exactly `role` and `content` keys, a `role` in `{assistant, system, user}`, and a string `content`. (Adapted from the OpenAI cookbook's chat fine-tuning data prep.)

---

## Architecture

The module sits at the boundary between DSPy's optimization layer and its provider layer. Teleprompters produce training data, this module validates and persists it, and providers consume it.

```mermaid
graph TD
    subgraph "Optimization Layer"
        BF[BootstrapFinetune]
        GRPO[GRPO]
    end

    subgraph "clients_finetune_utils"
        TDF[TrainDataFormat]
        TS[TrainingStatus]
        MSG[Message / MessageAssistant]
        GCD[GRPOChatData]
        VAL[validate_data_format]
        SAVE[save_data]
        INFER[infer_data_format]
    end

    subgraph "Provider Layer"
        PROV[Provider]
        TJ[TrainingJob]
        RJ[ReinforceJob]
    end

    subgraph "Adapters"
        CA[ChatAdapter]
    end

    BF --> INFER
    INFER --> CA
    BF --> VAL
    GRPO --> GCD
    GRPO --> VAL
    VAL --> TDF
    SAVE --> TDF
    PROV --> TDF
    TJ --> TS
    RJ --> GCD
    TJ --> TDF
```

---

## Data Flow

The following diagram illustrates how training data flows from a teleprompter through validation and persistence to a provider.

```mermaid
sequenceDiagram
    participant TP as Teleprompter (BootstrapFinetune/GRPO)
    participant U as clients_finetune_utils
    participant FS as Filesystem (finetune dir)
    participant P as Provider

    TP->>U: infer_data_format(adapter)
    U-->>TP: TrainDataFormat.CHAT
    TP->>U: validate_data_format(data, format)
    alt data invalid
        U->>FS: write data_format_errors.log
        U-->>TP: raise ValueError
    else data valid
        U-->>TP: (no error)
    end
    TP->>U: save_data(data)
    U->>FS: write <hash>.jsonl
    U-->>TP: file_path
    TP->>P: finetune(job, model, data, format, kwargs)
    P-->>TP: TrainingJob
    TP->>P: job.status()
    P-->>TP: TrainingStatus
```

---

## Component Relationships

```mermaid
classDiagram
    class TrainDataFormat {
        <<enum>>
        CHAT
        COMPLETION
        GRPO_CHAT
    }
    class TrainingStatus {
        <<enum>>
        not_started
        pending
        running
        succeeded
        failed
        cancelled
    }
    class Message {
        <<TypedDict>>
        role
        content
    }
    class MessageAssistant {
        <<TypedDict>>
        role = "assistant"
        content
    }
    class GRPOChatData {
        <<TypedDict>>
        messages: List[Message]
        completion: MessageAssistant
        reward: float
    }

    GRPOChatData --> Message
    GRPOChatData --> MessageAssistant
    MessageAssistant --|> Message
```

---

## Integration with Providers

The types defined here are consumed directly by the provider layer:

- **`TrainDataFormat`** is passed as `train_data_format` to `Provider.finetune(...)` and to `ReinforceJob.step(...)`. See [clients_providers](clients_providers.md).
- **`TrainingStatus`** is the return type of `TrainingJob.status()` across all provider implementations (`TrainingJobOpenAI`, `TrainingJobDatabricks`, `ArborTrainingJob`).
- **`GRPOChatData` / `GRPOGroup`** are the payload types for `ArborReinforceJob.step(...)`, which asserts `train_data_format == TrainDataFormat.GRPO_CHAT`.

```mermaid
graph LR
    subgraph clients_finetune_utils
        TDF[TrainDataFormat]
        TS[TrainingStatus]
        GCD[GRPOChatData]
    end
    subgraph clients_providers
        OAI[TrainingJobOpenAI]
        DBX[TrainingJobDatabricks]
        ARB[ArborTrainingJob]
        ARBR[ArborReinforceJob]
    end
    TDF --> OAI
    TDF --> DBX
    TDF --> ARB
    TDF --> ARBR
    TS --> OAI
    TS --> DBX
    TS --> ARB
    GCD --> ARBR
```

---

## Validation Process Flow

```mermaid
flowchart TD
    A[validate_data_format] --> B{data is list?}
    B -- No --> E[raise ValueError]
    B -- Yes --> C[Select find_err_func by format]
    C --> D[Iterate records]
    D --> F{record is dict?}
    F -- No --> G[Record type error]
    F -- Yes --> H[Run format-specific validator]
    H --> I{error found?}
    I -- Yes --> G
    I -- No --> J[Next record]
    G --> J
    J --> K{any errors?}
    K -- Yes --> L[write data_format_errors.log]
    L --> M[raise ValueError with log path]
    K -- No --> N[Validation passes]
```

---

## Related Modules

- [clients_providers](clients_providers.md) — Provider implementations (`Provider`, `TrainingJob`, `ReinforceJob`) that consume these types.
- [adapters_core](adapters_core.md) — The `Adapter` base class and `ChatAdapter` used by `infer_data_format`.
- [teleprompt](teleprompt.md) — `BootstrapFinetune` and `GRPO` teleprompters that generate the training data validated here.
