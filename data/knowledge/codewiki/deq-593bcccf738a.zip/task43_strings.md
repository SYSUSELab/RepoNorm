# task43_strings Module

## Introduction

The `task43_strings` module provides a family of *dirty-equals* comparison types for validating `str` and `bytes` values. These types allow expressive, constraint-based assertions such as "is this a string of at least 5 characters matching a regex?" without writing imperative validation code.

The module is built around a single flexible base class, [`IsAnyStr`](#isanytr), which is specialized into two concrete types:

- [`IsStr`](#isstr) — restricts comparison to `str` objects.
- [`IsBytes`](#isbytes) — restricts comparison to `bytes` objects.

All three types inherit the core comparison machinery from [`DirtyEquals`](task43_core.md), which is documented separately in the core module.

---

## Architecture

The module follows a simple inheritance hierarchy where a single generic base class captures all shared logic, and two thin subclasses narrow the accepted types.

```mermaid
classDiagram
    class DirtyEquals {
        <<abstract>>
        +equals(other) bool
        +__eq__(other) bool
        +value T
    }
    class IsAnyStr {
        +expected_types = (str, bytes)
        +min_length: Optional[int]
        +max_length: Optional[int]
        +case: Literal['upper','lower',None]
        +regex: Union[None, T, Pattern[T]]
        +regex_flags: int
        +equals(other) bool
        +_prepare_regex(regex, flags)
    }
    class IsStr {
        +expected_types = (str,)
    }
    class IsBytes {
        +expected_types = (bytes,)
    }

    DirtyEquals <|-- IsAnyStr
    IsAnyStr <|-- IsStr
    IsAnyStr <|-- IsBytes
```

### Key Design Points

| Aspect | Description |
| --- | --- |
| **Generic base** | `IsAnyStr[T]` is parameterized over `T` (`str` or `bytes`) so subclasses can be statically typed. |
| **Type narrowing** | Subclasses override only the `expected_types` class attribute to restrict accepted input types. |
| **Flexible regex** | The `_flex` flag (set when more than one expected type exists) enables automatic `str`/`bytes` conversion for regex matching. |
| **Repr integration** | Constructor arguments are forwarded to `DirtyEquals.__init__` using the `Omit` sentinel so that only meaningful arguments appear in `__repr__`. |

---

## Component Reference

### IsAnyStr

`IsAnyStr` is the base comparison type for both `str` and `bytes`. It accepts the following keyword-only arguments:

| Argument | Type | Description |
| --- | --- | --- |
| `min_length` | `Optional[int]` | Minimum length of the value. |
| `max_length` | `Optional[int]` | Maximum length of the value. |
| `case` | `Literal['upper', 'lower', None]` | Enforce that the value is entirely upper- or lower-case. |
| `regex` | `Union[None, T, Pattern[T]]` | A regex (compiled or raw) matched with `re.fullmatch`. |
| `regex_flags` | `int` | Optional flags applied to the regex. |

#### Comparison Logic

The `equals` method performs checks in the following order, short-circuiting on the first failure:

```mermaid
flowchart TD
    A[equals other] --> B{type in expected_types?}
    B -- No --> F[return False]
    B -- Yes --> C{regex set?}
    C -- Yes --> C1[convert str to bytes if flex]
    C1 --> C2{re.fullmatch matches?}
    C2 -- No --> F
    C2 -- Yes --> D
    C -- No --> D{min_length set?}
    D -- Yes --> D1{len >= min_length?}
    D1 -- No --> F
    D1 -- Yes --> E
    D -- No --> E{max_length set?}
    E -- Yes --> E1{len <= max_length?}
    E1 -- No --> F
    E1 -- Yes --> G
    E -- No --> G{case == upper?}
    G -- Yes --> G1{other.isupper?}
    G1 -- No --> F
    G1 -- Yes --> H[return True]
    G -- No --> H2{case == lower?}
    H2 -- Yes --> H3{other.islower?}
    H3 -- No --> F
    H3 -- Yes --> H
    H2 -- No --> H
```

#### Regex Preparation

The `_prepare_regex` helper normalizes the supplied regex so that a single comparison path works for both `str` and `bytes`:

- If a **compiled** `re.Pattern` is supplied and the type is flexible (`_flex`), the pattern is unwrapped to its raw `.pattern` and the `re.UNICODE` flag is stripped (since `bytes` patterns cannot use it).
- If a **raw string** is supplied and the type is flexible, it is encoded to `bytes` so it can match against `bytes` inputs.

#### Example

```py title="IsAnyStr"
from dirty_equals import IsAnyStr

assert 'foobar' == IsAnyStr()
assert b'foobar' == IsAnyStr()
assert 123 != IsAnyStr()
assert 'foobar' == IsAnyStr(regex='foo...')
assert 'foobar' == IsAnyStr(regex=b'foo...')  # regex may be str or bytes

assert 'foobar' == IsAnyStr(min_length=6)
assert 'foobar' != IsAnyStr(min_length=8)

assert 'foobar' == IsAnyStr(case='lower')
assert 'Foobar' != IsAnyStr(case='lower')
```

---

### IsStr

`IsStr` is a subclass of `IsAnyStr[str]` that restricts comparison to `str` objects only. It accepts all the same arguments as `IsAnyStr`.

```py title="IsStr"
from dirty_equals import IsStr

assert 'foobar' == IsStr()
assert b'foobar' != IsStr()
assert 'foobar' == IsStr(regex='foo...')

assert 'FOOBAR' == IsStr(min_length=5, max_length=10, case='upper')
```

---

### IsBytes

`IsBytes` is a subclass of `IsAnyStr[bytes]` that restricts comparison to `bytes` objects only. It accepts all the same arguments as `IsAnyStr`.

```py title="IsBytes"
from dirty_equals import IsBytes

assert b'foobar' == IsBytes()
assert 'foobar' != IsBytes()
assert b'foobar' == IsBytes(regex=b'foo...')

assert b'FOOBAR' == IsBytes(min_length=5, max_length=10, case='upper')
```

---

## Dependencies

The module depends on a small set of internal components and standard-library modules.

```mermaid
graph LR
    subgraph task43_strings
        IsAnyStr
        IsStr
        IsBytes
    end
    subgraph task43_core
        DirtyEquals
    end
    subgraph task43_core_utils
        Omit
        plain_repr
        PlainRepr
    end
    subgraph stdlib
        re
        typing
    end

    IsStr --> IsAnyStr
    IsBytes --> IsAnyStr
    IsAnyStr --> DirtyEquals
    IsAnyStr --> Omit
    IsAnyStr --> plain_repr
    plain_repr --> PlainRepr
    IsAnyStr --> re
    IsAnyStr --> typing
```

| Dependency | Purpose |
| --- | --- |
| [`DirtyEquals`](task43_core.md) | Base class providing `__eq__`, `__ne__`, `value`, and repr machinery. |
| `Omit` | Sentinel used to exclude unset arguments from the generated `__repr__`. |
| `plain_repr` / `PlainRepr` | Utility to render the `regex_flags` repr without extra quoting. |
| `re` | Standard-library regex engine used for `re.fullmatch`. |
| `typing` | Type hints, with a fallback to `typing_extensions` for `Literal`. |

---

## Integration with the Broader System

`IsStr`, `IsBytes`, and `IsAnyStr` are part of the larger *dirty-equals* family of comparison types. They share the same base contract as the other modules and can be freely combined using the logical operators provided by [`DirtyEquals`](task43_core.md):

```mermaid
graph TD
    A[DirtyEquals base] --> B[task43_strings]
    A --> C[task43_numeric]
    A --> D[task43_datetime]
    A --> E[task43_sequence]
    A --> F[task43_dict]
    A --> G[task43_inspection]
    A --> H[task43_other]

    B --> B1[IsAnyStr]
    B --> B2[IsStr]
    B --> B3[IsBytes]
```

Because every type derives from `DirtyEquals`, string checks can be composed with other checks:

```py
from dirty_equals import IsStr, IsInt

# Combine with logical operators inherited from DirtyEquals
assert 'abc' == (IsStr(min_length=2) & IsStr(max_length=5))
assert 'abc' == (IsStr() | IsInt())
```

For details on the composition operators (`|`, `&`, `~`) and the `value` property, see the [core module documentation](task43_core.md).

---

## Summary

The `task43_strings` module delivers three focused comparison types for textual data:

- **`IsAnyStr`** — the flexible base supporting both `str` and `bytes`, with length, case, and regex constraints.
- **`IsStr`** — a `str`-only specialization.
- **`IsBytes`** — a `bytes`-only specialization.

Its design leverages a single generic base class, type-narrowing subclasses, and the shared [`DirtyEquals`](task43_core.md) machinery to keep the implementation compact while offering a rich, composable assertion API.
