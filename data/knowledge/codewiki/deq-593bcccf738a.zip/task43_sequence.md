# task43_sequence Module

## Introduction

The `task43_sequence` module provides a set of **dirty-equals** comparison types for validating the structure, length, and contents of sequence-like objects (lists, tuples, strings, and other containers). These types allow developers to write expressive assertions such as "this value must be a list of length 3 starting with `1, 2, 3`" without needing to construct the exact expected object.

The module is built on top of the core [`DirtyEquals`](task43_core.md) base class and exposes five public comparison types:

| Type | Purpose |
| --- | --- |
| [`HasLen`](#haslen) | Check that an object has a given length or a length within a range. |
| [`Contains`](#contains) | Check that a container contains one or more values. |
| [`IsListOrTuple`](#islistortuple) | Check that an object is a list or tuple and optionally validate its members. |
| [`IsList`](#islist) | Same as `IsListOrTuple`, but restricted to `list`. |
| [`IsTuple`](#istuple) | Same as `IsListOrTuple`, but restricted to `tuple`. |

All types are exported via `__all__`:

```python
__all__ = 'HasLen', 'Contains', 'IsListOrTuple', 'IsList', 'IsTuple'
```

---

## Architecture

The module is a thin, focused layer that specialises the generic comparison machinery provided by the core module. Every public type subclasses `DirtyEquals` and implements the abstract `equals` method.

```mermaid
graph TD
    subgraph core["task43_core"]
        DE["DirtyEquals&lt;T&gt;"]
        DEM["DirtyEqualsMeta"]
        AT["AnyThing"]
        Omit["Omit (sentinel)"]
        PR["plain_repr / PlainRepr"]
    end

    subgraph sequence["task43_sequence"]
        HL["HasLen"]
        CT["Contains"]
        ILT["IsListOrTuple&lt;T&gt;"]
        IL["IsList"]
        IT["IsTuple"]
    end

    DE --> HL
    DE --> CT
    DE --> ILT
    ILT --> IL
    ILT --> IT

    DEM -.metaclass.-> DE
    AT -.used in examples.-> ILT
    Omit -.repr control.-> HL
    Omit -.repr control.-> ILT
    PR -.repr control.-> HL
    PR -.repr control.-> ILT
```

### Key design points

- **Generic base**: `DirtyEquals[T]` is parameterised by the type of object the comparison expects (`Sized`, `Container[Any]`, `List[Any]`, `Tuple[Any, ...]`).
- **Metaclass magic**: `DirtyEqualsMeta` allows the *class itself* (not just an instance) to participate in `==` comparisons, so `[1, 2, 3] == IsList` style usage works where applicable.
- **Repr control via `Omit`**: Constructor arguments passed to `super().__init__` are used purely to build a human-readable `__repr__`. The `Omit` sentinel suppresses arguments that should not appear in the repr, and `plain_repr` renders the ellipsis `...` without quotes.
- **Composability**: Because every type derives from `DirtyEquals`, they can be combined with `|` (OR), `&` (AND), and `~` (NOT) operators — see [task43_core.md](task43_core.md).

---

## Component Reference

### HasLen

`HasLen` checks that an object has a given length, or a length within a given range. It works on any `Sized` object (lists, tuples, strings, dicts, sets, etc.).

**Signature**

```python
HasLen(length: int)
HasLen(min_length: int, max_length: Union[int, Any])
```

**Behaviour**

- With a single `length` argument, the object's length must equal that value exactly.
- With two arguments, the length must be between `min_length` and `max_length` inclusive.
- Passing `...` (Ellipsis) as `max_length` means "no upper bound".

**Examples**

```py
from dirty_equals import HasLen

assert [1, 2, 3] == HasLen(3)        # exact length
assert '123' == HasLen(3, ...)       # length >= 3
assert (1, 2, 3) == HasLen(3, 5)     # 3 <= length <= 5
assert (1, 2, 3) == HasLen(0, ...)   # any length
```

**Internal flow**

```mermaid
flowchart LR
    A["HasLen(min, max)"] --> B{"max is None?"}
    B -- yes --> C["self.length = min"]
    B -- no --> D["self.length = (min, max)"]
    C --> E["super().__init__(length)"]
    D --> F["super().__init__(*_length_repr(length))"]
    E --> G["equals(other)"]
    F --> G
    G --> H["_length_correct(self.length, other)"]
```

The `equals` method delegates to the shared helper [`_length_correct`](#shared-helpers).

---

### Contains

`Contains` checks that a container contains one or more values. It works on any `Container` (lists, tuples, strings, dicts, sets, etc.).

**Signature**

```python
Contains(contained_value: Any, *more_contained_values: Any)
```

**Behaviour**

- Stores all required values in `self.contained_values`.
- `equals` returns `True` only if **every** required value is present in `other` (using the `in` operator).

**Examples**

```py
from dirty_equals import Contains

assert [1, 2, 3] == Contains(1)
assert [1, 2, 3] == Contains(1, 2)
assert (1, 2, 3) == Contains(1)
assert 'abc' == Contains('b')
assert {'a': 1, 'b': 2} == Contains('a')   # checks keys
assert [1, 2, 3] != Contains(10)
```

> **Note:** `Contains` only checks membership — it does not enforce length or ordering. Combine it with [`HasLen`](#haslen) if you need both.

---

### IsListOrTuple

`IsListOrTuple` is the most feature-rich type in the module. It checks that an object is a `list` or `tuple` and optionally validates its members, ordering, and length.

**Signature (two initialisation modes)**

```python
# Mode 1: positional items
IsListOrTuple(*items: Any, check_order: bool = True, length: LengthType = None)

# Mode 2: explicit positions
IsListOrTuple(positions: Dict[int, Any], length: LengthType = None)
```

Where `LengthType = Union[None, int, Tuple[int, Union[int, Any]]]`.

**Parameters**

| Parameter | Description |
| --- | --- |
| `*items` | Positional members to check, starting from index 0. |
| `positions` | A mapping of index → expected value. Mutually exclusive with `*items`. |
| `check_order` | Whether the order of items must match. Not compatible with `positions`. |
| `length` | Length constraint: an `int`, a `(min, max)` tuple, or `...` for "any length". |

**Behaviour**

- `allowed_type` defaults to `(list, tuple)` and is overridden by subclasses.
- If `positions` is provided, `*items` must be empty and `check_order` must be `True`.
- `length` is normalised: `...` becomes `(0, ...)`, and any non-int iterable is converted to a tuple.
- The `equals` method performs the following checks in order:
  1. Type check against `allowed_type`.
  2. Length check via [`_length_correct`](#shared-helpers).
  3. Order-sensitive comparison (either positional items or explicit positions).
  4. Order-insensitive comparison (multiset-style removal of items).

**Examples**

```py
from dirty_equals import IsListOrTuple, AnyThing

assert [1, 2, 3] == IsListOrTuple(1, 2, 3)
assert (1, 3, 2) == IsListOrTuple(1, 2, 3, check_order=False)
assert [{'a': 1}, {'a': 2}] == IsListOrTuple({'a': 2}, {'a': 1}, check_order=False)
assert [1, 2, 3, 3] != IsListOrTuple(1, 2, 3, check_order=False)   # duplicates matter

assert [1, 2, 3, 4, 5] == IsListOrTuple(1, 2, 3, length=...)
assert [1, 2, 3, 4, 5] != IsListOrTuple(1, 2, 3, length=(8, 10))

assert ['a', 'b', 'c', 'd'] == IsListOrTuple(positions={2: 'c', 3: 'd'})
assert ['a', 'b', 'c', 'd'] == IsListOrTuple(positions={2: 'c', 3: 'd'}, length=4)

assert [1, 2, 3, 4] == IsListOrTuple(3, check_order=False, length=(0, ...))
assert [1, 2, 3] == IsListOrTuple(AnyThing, AnyThing, 3)
```

**Comparison flow**

```mermaid
flowchart TD
    A["equals(other)"] --> B{"isinstance(other, allowed_type)?"}
    B -- no --> Z["return False"]
    B -- yes --> C{"_length_correct(length, other)?"}
    C -- no --> Z
    C -- yes --> D{"check_order?"}
    D -- yes --> E{"positions is None?"}
    E -- yes --> F{"length is None?"}
    F -- yes --> G["list(items) == list(other)"]
    F -- no --> H["list(items) == list(other[:len(items)])"]
    E -- no --> I["all(v == other[k] for k, v in positions)"]
    D -- no --> J{"length is None and len(other) != len(items)?"}
    J -- yes --> Z
    J -- no --> K["copy other; remove each item"]
    K --> L{"all items removed?"}
    L -- yes --> M["return True"]
    L -- no --> Z
```

---

### IsList

`IsList` is a convenience subclass of [`IsListOrTuple`](#islistortuple) that restricts the compared value to a `list`. It inherits all constructor arguments and behaviour.

```py
from dirty_equals import IsList

assert [1, 2, 3] == IsList(1, 2, 3)
assert [1, 2, 3] == IsList(positions={2: 3})
assert [1, 2, 3] == IsList(1, 2, 3, check_order=False)
assert [1, 2, 3, 4] == IsList(1, 2, 3, length=4)
assert [1, 2, 3, 4] == IsList(1, 2, 3, length=(4, 5))
assert [1, 2, 3, 4] == IsList(1, 2, 3, length=...)

assert (1, 2, 3) != IsList(1, 2, 3)   # tuples are rejected
```

The only difference from the parent is:

```python
class IsList(IsListOrTuple[List[Any]]):
    allowed_type = list
```

---

### IsTuple

`IsTuple` is the tuple-restricted counterpart of [`IsList`](#islist). It inherits all constructor arguments and behaviour from [`IsListOrTuple`](#islistortuple).

```py
from dirty_equals import IsTuple

assert (1, 2, 3) == IsTuple(1, 2, 3)
assert (1, 2, 3) == IsTuple(positions={2: 3})
assert (1, 2, 3) == IsTuple(1, 2, 3, check_order=False)
assert (1, 2, 3, 4) == IsTuple(1, 2, 3, length=4)
assert (1, 2, 3, 4) == IsTuple(1, 2, 3, length=(4, 5))
assert (1, 2, 3, 4) == IsTuple(1, 2, 3, length=...)

assert [1, 2, 3] != IsTuple(1, 2, 3)   # lists are rejected
```

The only difference from the parent is:

```python
class IsTuple(IsListOrTuple[Tuple[Any, ...]]):
    allowed_type = tuple
```

---

## Shared Helpers

Two module-private helpers are shared between `HasLen` and `IsListOrTuple`.

### `_length_repr(length)`

Normalises a `LengthType` into a value suitable for the `__repr__` machinery.

- `None` → `Omit` (suppressed from repr).
- `int` → returned unchanged.
- A 2-tuple → `(min, max)` where a non-int `max` is rendered via `plain_repr('...')` so the ellipsis appears without quotes.
- Any other tuple length raises `TypeError`.

### `_length_correct(length, other)`

The single source of truth for length validation, used by both `HasLen.equals` and `IsListOrTuple.equals`.

```mermaid
flowchart TD
    A["_length_correct(length, other)"] --> B{"length is int?"}
    B -- yes --> C{"len(other) == length?"}
    C -- no --> Z["return False"]
    C -- yes --> Y["return True"]
    B -- no --> D{"length is tuple?"}
    D -- yes --> E{"len(other) < min_length?"}
    E -- yes --> Z
    E -- no --> F{"max is int and len(other) > max?"}
    F -- yes --> Z
    F -- no --> Y
    D -- no --> Y
```

---

## Data Flow

The following diagram shows how a comparison flows from a user assertion through the module's types into the core comparison machinery.

```mermaid
sequenceDiagram
    participant User
    participant Type as "Sequence Type (e.g. IsList)"
    participant Base as "DirtyEquals.__eq__"
    participant Equals as "Type.equals"
    participant Helper as "_length_correct"

    User->>Type: construct with args
    Type->>Base: super().__init__(*repr_args)
    User->>Base: other == instance
    Base->>Equals: equals(other)
    Equals->>Helper: _length_correct(length, other)
    Helper-->>Equals: bool
    Equals-->>Base: bool
    Base-->>User: bool (and stores .value)
```

---

## Relationship to Other Modules

The `task43_sequence` module is one of several sibling modules that all build on the shared core. The table below summarises how it relates to the rest of the library.

| Module | Relationship |
| --- | --- |
| [task43_core](task43_core.md) | Provides `DirtyEquals`, `DirtyEqualsMeta`, `AnyThing`, and the `Omit`/`plain_repr` utilities used throughout this module. |
| [task43_numeric](task43_numeric.md) | Sibling module for numeric comparisons; can be nested inside `IsListOrTuple` items. |
| [task43_datetime](task43_datetime.md) | Sibling module for datetime comparisons. |
| [task43_strings](task43_strings.md) | Sibling module for string/bytes comparisons; `Contains` and `HasLen` also work on strings. |
| [task43_dict](task43_dict.md) | Sibling module for dict comparisons; `Contains` works on dict keys. |
| [task43_inspection](task43_inspection.md) | Sibling module for object inspection comparisons. |
| [task43_other](task43_other.md) | Sibling module for miscellaneous comparisons. |

### Cross-module composition

Because all types derive from `DirtyEquals`, sequence types compose naturally with types from other modules. For example, `AnyThing` (from [task43_core](task43_core.md)) is frequently used as a placeholder inside `IsListOrTuple`:

```py
from dirty_equals import IsListOrTuple, AnyThing

assert [1, 2, 3] == IsListOrTuple(AnyThing, AnyThing, 3)
```

---

## Summary

The `task43_sequence` module delivers five focused comparison types for sequence-like objects:

- **`HasLen`** — length-only validation for any `Sized` object.
- **`Contains`** — membership validation for any `Container`.
- **`IsListOrTuple`** — the workhorse for list/tuple validation with support for positional items, explicit positions, order-insensitive matching, and length constraints.
- **`IsList`** / **`IsTuple`** — thin subclasses that restrict the accepted type.

All types share the `_length_correct` and `_length_repr` helpers and integrate seamlessly with the core `DirtyEquals` comparison protocol, including operator-based composition (`|`, `&`, `~`) and the `.value` property.
