# task43_core Module

## Introduction

The `task43_core` module is the foundational layer of the **dirty-equals** library. It provides the base
abstractions, metaclass machinery, and logical composition primitives that every other module in the library
builds upon. All concrete "dirty" comparison types (numeric, datetime, string, sequence, dict, inspection, and
other) inherit from the `DirtyEquals` base class defined here.

The module is responsible for three core concerns:

1. **The comparison contract** — the `DirtyEquals` base class and its `DirtyEqualsMeta` metaclass define how
   dirty-equals objects compare against arbitrary values.
2. **Logical composition** — `DirtyOr`, `DirtyAnd`, and `DirtyNot` allow combining multiple dirty types using
   the `|`, `&`, and `~` operators.
3. **Utility primitives** — `AnyThing`, `IsOneOf`, and the `PlainRepr` helper provide reusable building blocks
   for other modules.

## Architecture Overview

The module is split across two files:

| File | Responsibility |
| --- | --- |
| `dirty_equals/_base.py` | Core base class, metaclass, logical operators, and generic matchers |
| `dirty_equals/_utils.py` | Low-level helpers (`PlainRepr`, `Omit`, `get_dict_arg`) |

```mermaid
graph TD
    subgraph task43_core
        DE[DirtyEquals]
        DEM[DirtyEqualsMeta]
        OR[DirtyOr]
        AND[DirtyAnd]
        NOT[DirtyNot]
        AT[AnyThing]
        IOO[IsOneOf]
        PR[PlainRepr]
        OM[Omit]
        GDA[get_dict_arg]
    end

    DEM -->|metaclass of| DE
    DE -->|subclass| OR
    DE -->|subclass| AND
    DE -->|subclass| NOT
    DE -->|subclass| AT
    DE -->|subclass| IOO
    OR -->|uses| PR
    AND -->|uses| PR
    NOT -->|uses| PR
    DE -->|uses| OM
    PR -.->|helper| DE
```

## Core Components

### `DirtyEqualsMeta`

`DirtyEqualsMeta` is an `ABCMeta` subclass that acts as the metaclass for `DirtyEquals` and all its subclasses.
It enables **class-level comparison and composition**, which is what allows expressions like `IsStr | IsInt` to
work directly on the *types* rather than on instances.

Key behaviors:

- **`__eq__`** — allows a dirty type *class* to be compared directly to a value. It guards against recursion
  when `self is DirtyEquals`, `other is Generic`, or `other is Protocol`, and swallows `TypeError` so that
  pytest's internal `type(a) == type(b)` checks do not raise.
- **`__or__` / `__and__` / `__invert__`** — return `DirtyOr`, `DirtyAnd`, and `DirtyNot` respectively, enabling
  operator-based composition at the class level.
- **`__hash__`** — hashes on `__name__` so dirty types remain usable as dict keys / set members.
- **`__repr__`** — returns the bare class name (e.g. `IsStr`) for readable error messages.

### `DirtyEquals`

`DirtyEquals` is the abstract base class for every dirty-equals type. It is generic over `T`, the type of value
it is expected to match.

```mermaid
classDiagram
    class DirtyEquals {
        +__init__(*repr_args, **repr_kwargs)
        +equals(other) bool
        +value T
        +__eq__(other) bool
        +__ne__(other) bool
        +__or__(other) DirtyOr
        +__and__(other) DirtyAnd
        +__invert__() DirtyNot
        +_repr_ne() str
        +__repr__() str
    }
    class DirtyOr
    class DirtyAnd
    class DirtyNot
    class AnyThing
    class IsOneOf
    DirtyEquals <|-- DirtyOr
    DirtyEquals <|-- DirtyAnd
    DirtyEquals <|-- DirtyNot
    DirtyEquals <|-- AnyThing
    DirtyEquals <|-- IsOneOf
```

**Comparison contract.** Subclasses must implement the abstract `equals(other)` method. The base class wraps
this in `__eq__`, which:

1. Stores `other` in `self._other`.
2. Calls `self.equals(other)`.
3. Catches `TypeError` and `ValueError` (signalling "not equal") and records `_was_equal = False`.

`__ne__` is implemented separately and deliberately does **not** set `_was_equal`, avoiding strange errors in
pytest.

**The `value` property.** After a successful comparison, `value` returns the value that was compared. It raises
`AttributeError` if accessed before a successful `__eq__` call.

**Repr behavior.** `__repr__` is context-sensitive: if the last comparison succeeded it returns `repr(self._other)`
(to aid in diffs), otherwise it returns `_repr_ne()`, a human-readable description of the matcher. Subclasses
override `_repr_ne()` to customize this description, and pass `repr_args` / `repr_kwargs` to `__init__` to
control the rendered arguments. The `Omit` sentinel can be used to hide specific arguments from the repr.

### Logical Composition Types

These three types implement the boolean algebra of dirty matching. They are produced by the operators on
`DirtyEquals` and `DirtyEqualsMeta`.

| Type | Operator | Semantics |
| --- | --- | --- |
| `DirtyOr` | `\|` | Matches if **any** of the wrapped matchers match |
| `DirtyAnd` | `&` | Matches if **all** of the wrapped matchers match |
| `DirtyNot` | `~` | Matches if the wrapped matcher does **not** match |

Each stores its operands in `self.dirties` (or `self.subject` for `DirtyNot`) and delegates to `equals`. Their
`_repr_ne()` methods render the operands joined by the corresponding operator symbol, using the module-level
`_repr_ne` helper which handles both class-level and instance-level operands.

```mermaid
flowchart LR
    A[Value to compare] --> B{Composition type}
    B -->|DirtyOr| C[any operand matches?]
    B -->|DirtyAnd| D[all operands match?]
    B -->|DirtyNot| E[operand does not match?]
    C --> F[Result]
    D --> F
    E --> F
```

### `AnyThing`

`AnyThing` is a matcher that matches **any** value — its `equals` always returns `True`. It is rarely useful on
its own but is valuable as a placeholder inside composite matchers such as `IsList` or `IsStrictDict`.

```py
from dirty_equals import AnyThing, IsList, IsStrictDict

assert 1 == AnyThing
assert [1, 2, 3] == IsList(AnyThing, 2, 3)
assert {'a': 1, 'b': 2, 'c': 3} == IsStrictDict(a=1, b=AnyThing, c=3)
```

### `IsOneOf`

`IsOneOf` matches a value if it equals **any** of a set of expected values. It is especially useful in
combination with boolean operators.

```py
from dirty_equals import IsOneOf, Contains

assert 1 == IsOneOf(1, 2, 3)
assert 4 != IsOneOf(1, 2, 3)
assert [1, 2, 3] == Contains(1) | IsOneOf([])
```

### `PlainRepr` (in `_utils.py`)

`PlainRepr` is a small hack that allows a string to be rendered by `repr()` **without quotes**. It is used by
matchers that want to display a raw, unquoted representation in their `_repr_ne()` output. The `plain_repr`
factory function constructs one.

### Supporting Utilities (in `_utils.py`)

- **`Omit`** — a sentinel object used to omit specific arguments from a matcher's repr.
- **`get_dict_arg`** — enforces `dict(...)`-style initialization logic (single positional dict argument *or*
  keyword arguments, but not both) for dict-based matchers. It is consumed by the dict module.

## Data Flow

The following diagram shows the lifecycle of a comparison against a dirty-equals object.

```mermaid
sequenceDiagram
    participant User
    participant DE as DirtyEquals instance
    participant Sub as Subclass.equals()

    User->>DE: value == dirty_obj
    DE->>DE: store self._other = value
    DE->>Sub: equals(value)
    alt equals returns True
        Sub-->>DE: True
        DE->>DE: _was_equal = True
        DE-->>User: True
    else equals returns False / raises TypeError|ValueError
        Sub-->>DE: False (or exception)
        DE->>DE: _was_equal = False
        DE-->>User: False
    end
    Note over DE: repr() now reflects the outcome
```

## Relationship to Other Modules

`task43_core` is the root dependency for every other module. All concrete matchers inherit from `DirtyEquals`
and rely on `DirtyEqualsMeta` for class-level operators. The table below summarizes how each sibling module
builds on the core.

```mermaid
graph TD
    CORE[task43_core]
    CORE --> NUM[task43_numeric]
    CORE --> DT[task43_datetime]
    CORE --> STR[task43_strings]
    CORE --> SEQ[task43_sequence]
    CORE --> DICT[task43_dict]
    CORE --> INSP[task43_inspection]
    CORE --> OTHER[task43_other]
```

| Module | How it uses `task43_core` |
| --- | --- |
| [task43_numeric](task43_numeric.md) | Numeric matchers subclass `DirtyEquals`; `IsApprox` etc. use the comparison contract |
| [task43_datetime](task43_datetime.md) | Datetime matchers subclass `DirtyEquals` |
| [task43_strings](task43_strings.md) | String/bytes matchers subclass `DirtyEquals` |
| [task43_sequence](task43_sequence.md) | Sequence matchers subclass `DirtyEquals`; `Contains` composes with `DirtyOr`/`IsOneOf` |
| [task43_dict](task43_dict.md) | Dict matchers subclass `DirtyEquals` and use `get_dict_arg` from `_utils` |
| [task43_inspection](task43_inspection.md) | Inspection matchers subclass `DirtyEquals` |
| [task43_other](task43_other.md) | Miscellaneous matchers subclass `DirtyEquals` |

## Summary

`task43_core` defines the entire comparison and composition model of the dirty-equals library:

- **`DirtyEquals`** — the abstract base class implementing the `__eq__`/`equals` contract and the `value`
  property.
- **`DirtyEqualsMeta`** — the metaclass enabling class-level comparison and operator composition.
- **`DirtyOr` / `DirtyAnd` / `DirtyNot`** — boolean composition of matchers.
- **`AnyThing` / `IsOneOf`** — generic reusable matchers.
- **`PlainRepr` / `Omit` / `get_dict_arg`** — low-level utilities shared across modules.

Every other module in the library depends on these primitives, making `task43_core` the essential foundation
for understanding the rest of the codebase.
