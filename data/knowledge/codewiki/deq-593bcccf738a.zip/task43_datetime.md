# task43_datetime Module

## Introduction

The `task43_datetime` module provides a set of *dirty-equals* comparison types for **date and datetime values**. It allows developers to write expressive, flexible assertions in tests without needing to know the exact value being compared — instead, they can assert that a value is *approximately* correct, falls within a range, is "now", or is "today".

The module is built on top of the numeric comparison infrastructure (see [task43_numeric](task43_numeric.md)) and the core dirty-equals base classes (see [task43_core](task43_core.md)). It exposes four public types:

| Type | Purpose |
|------|---------|
| `IsDatetime` | Match a `datetime` against approximate values, bounds, or parsed representations. |
| `IsNow` | Match a `datetime` that is close to the current moment. |
| `IsDate` | Match a `date` against approximate values, bounds, or parsed representations. |
| `IsToday` | Match a `date` that equals today's date. |

---

## Architecture

The module follows the same inheritance pattern used throughout *dirty-equals*: a generic numeric base class (`IsNumeric`) provides approximate and inequality comparison logic, and the datetime-specific classes extend it with type-specific parsing and timezone handling.

```mermaid
classDiagram
    class DirtyEquals {
        <<abstract>>
        +equals(other) bool
        +__eq__(other) bool
        +value
    }
    class IsNumeric~N~ {
        +approx
        +delta
        +gt, lt, ge, le
        +prepare(other) N
        +bounds_checks(other) bool
        +approx_equals(other, delta) bool
    }
    class IsDatetime {
        +unix_number
        +iso_string
        +format_string
        +enforce_tz
        +prepare(other) datetime
        +approx_equals(other, delta) bool
    }
    class IsNow {
        +tz
        +_get_now() datetime
        +prepare(other) datetime
    }
    class IsDate {
        +iso_string
        +format_string
        +prepare(other) date
    }
    class IsToday {
        +prepare(other) date
    }

    DirtyEquals <|-- IsNumeric
    IsNumeric <|-- IsDatetime
    IsDatetime <|-- IsNow
    IsNumeric <|-- IsDate
    IsDate <|-- IsToday
```

### Key Design Points

- **`IsDatetime` extends `IsNumeric[datetime]`** — it inherits all approximate/bounds comparison machinery and only overrides `prepare()` (to coerce inputs into `datetime`) and `approx_equals()` (to add timezone enforcement).
- **`IsNow` extends `IsDatetime`** — it dynamically recomputes the `approx` value on every comparison so that "now" is always evaluated at comparison time.
- **`IsDate` extends `IsNumeric[date]`** — it mirrors `IsDatetime` but for `date` objects, without timezone handling.
- **`IsToday` extends `IsDate`** — it fixes `approx` to `date.today()`.

---

## Component Reference

### `IsDatetime`

Checks that a value is a `datetime` and matches the given conditions.

**Constructor parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `approx` | `datetime` | Value to approximately compare to. |
| `delta` | `timedelta \| int \| float` | Allowable difference from `approx`. Ints/floats are treated as seconds. Defaults to 2 seconds. |
| `gt` / `lt` / `ge` / `le` | `datetime` | Bounds the compared value must satisfy. |
| `unix_number` | `bool` | Allow Unix timestamp numbers as input. |
| `iso_string` | `bool` | Allow ISO-formatted strings as input. |
| `format_string` | `str` | `strptime` format used to parse string inputs. |
| `enforce_tz` | `bool` | Whether timezone must match `approx` (default `True`). |

**Behavior:**

1. `prepare()` coerces the incoming value into a `datetime`:
   - `datetime` → used directly.
   - `int`/`float` → converted via `datetime.fromtimestamp()` **only if** `unix_number=True`, otherwise raises `TypeError`.
   - `str` → parsed via `datetime.fromisoformat()` (if `iso_string`) or `datetime.strptime()` (if `format_string`), otherwise raises `ValueError`.
   - Any other type → raises `ValueError`.
2. When `enforce_tz=False` and `approx` is naive while the input is aware, the input's tzinfo is stripped before comparison.
3. `approx_equals()` first delegates to the numeric base, then (when `enforce_tz=True`) verifies that the UTC offsets of `approx` and the input match.

```py title="IsDatetime"
from dirty_equals import IsDatetime
from datetime import datetime

y2k = datetime(2000, 1, 1)
assert datetime(2000, 1, 1) == IsDatetime(approx=y2k)
assert 946684800.123 == IsDatetime(approx=y2k, unix_number=True)
assert datetime(2000, 1, 1, 0, 0, 9) == IsDatetime(approx=y2k, delta=10)
assert '2000-01-01T00:00' == IsDatetime(approx=y2k, iso_string=True)
assert datetime(2000, 1, 2) == IsDatetime(gt=y2k)
```

### `IsNow`

Checks that a `datetime` is close to the current moment. Equivalent to `IsDatetime(approx=datetime.now())` but recomputes "now" on each comparison.

**Additional parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `tz` | `str \| tzinfo \| None` | Timezone to convert "now" into. Strings are resolved via `pytz.timezone`. |

**Behavior:**

- `_get_now()` returns the current time, optionally converted to `tz`.
- `prepare()` **overwrites `self.approx`** with a fresh `_get_now()` before delegating to `IsDatetime.prepare()`, ensuring the comparison is always against the live current time.

```py title="IsNow"
from dirty_equals import IsNow
from datetime import datetime, timezone

now = datetime.now()
assert now == IsNow
assert now.timestamp() == IsNow(unix_number=True)
assert now.isoformat() == IsNow(iso_string=True)

utc_now = datetime.utcnow().replace(tzinfo=timezone.utc)
assert utc_now == IsNow(tz=timezone.utc)
```

### `IsDate`

Checks that a value is a `date` and matches the given conditions. Mirrors `IsDatetime` but without timezone or Unix-number support.

**Constructor parameters:** `approx`, `delta`, `gt`, `lt`, `ge`, `le`, `iso_string`, `format_string`.

**Behavior:**

- `delta` defaults to `timedelta()` (zero) when not provided.
- `prepare()` coerces inputs:
  - `date` (exact type) → used directly.
  - `str` → parsed via `date.fromisoformat()` (if `iso_string`) or `datetime.strptime(...).date()` (if `format_string`), otherwise raises `ValueError`.
  - Any other type → raises `ValueError`.

```py title="IsDate"
from dirty_equals import IsDate
from datetime import date

y2k = date(2000, 1, 1)
assert date(2000, 1, 1) == IsDate(approx=y2k)
assert '2000-01-01' == IsDate(approx=y2k, iso_string=True)
assert date(2000, 1, 2) == IsDate(gt=y2k)
```

### `IsToday`

Checks that a `date` equals today's date. Equivalent to `IsDate(approx=date.today())`.

**Constructor parameters:** `iso_string`, `format_string`.

```py title="IsToday"
from dirty_equals import IsToday
from datetime import date, timedelta

today = date.today()
assert today == IsToday
assert today.isoformat() == IsToday(iso_string=True)
assert today + timedelta(days=1) != IsToday
assert today.strftime('%Y/%m/%d') == IsToday(format_string='%Y/%m/%d')
```

---

## Data Flow

The following diagram shows how a comparison flows through the datetime types, from the `==` operator down to the underlying numeric bounds check.

```mermaid
flowchart TD
    A["value == IsDatetime(...)"] --> B["DirtyEquals.__eq__"]
    B --> C["IsNumeric.equals(other)"]
    C --> D["IsDatetime.prepare(other)"]
    D --> D1{"input type?"}
    D1 -->|datetime| E["use directly"]
    D1 -->|int/float| D2{"unix_number?"}
    D2 -->|yes| E2["fromtimestamp()"]
    D2 -->|no| X1["raise TypeError"]
    D1 -->|str| D3{"iso_string / format_string?"}
    D3 -->|iso_string| E3["fromisoformat()"]
    D3 -->|format_string| E4["strptime()"]
    D3 -->|neither| X2["raise ValueError"]
    D1 -->|other| X3["raise ValueError"]
    E --> F["bounds_checks(other)"]
    E2 --> F
    E3 --> F
    E4 --> F
    F --> G{"approx set?"}
    G -->|yes| H["approx_equals(other, delta)"]
    H --> H1["IsNumeric.approx_equals"]
    H1 --> H2["IsDatetime.approx_equals: tz check"]
    G -->|no| I["gt/lt/ge/le checks"]
    H2 --> J["bool result"]
    I --> J
```

---

## Component Interaction

`IsNow` and `IsToday` are thin specializations that inject a dynamic "current time" value into their parent's `approx` parameter.

```mermaid
sequenceDiagram
    participant Test as Test Code
    participant Now as IsNow
    participant DT as IsDatetime
    participant Num as IsNumeric

    Test->>Now: __eq__(value)
    Now->>Now: prepare(value)
    Now->>Now: _get_now()  (refresh approx)
    Now->>DT: prepare(value)
    DT->>DT: coerce value to datetime
    DT-->>Now: datetime
    Now->>Num: equals(datetime)
    Num->>Num: bounds_checks(datetime)
    Num->>DT: approx_equals(datetime, delta)
    DT->>DT: timezone enforcement
    DT-->>Num: bool
    Num-->>Now: bool
    Now-->>Test: bool
```

---

## Dependencies

```mermaid
graph LR
    subgraph task43_datetime
        IsDatetime
        IsNow
        IsDate
        IsToday
    end
    subgraph task43_numeric
        IsNumeric
    end
    subgraph task43_core
        DirtyEquals
        Omit
    end
    IsDatetime --> IsNumeric
    IsDate --> IsNumeric
    IsNow --> IsDatetime
    IsToday --> IsDate
    IsNumeric --> DirtyEquals
    IsDatetime --> Omit
    IsDate --> Omit
```

- **`IsNumeric`** ([task43_numeric](task43_numeric.md)) — provides `approx`, `delta`, `gt`, `lt`, `ge`, `le` handling, `bounds_checks()`, and the default `approx_equals()`.
- **`DirtyEquals`** ([task43_core](task43_core.md)) — provides the `__eq__`/`__ne__` protocol, the `value` property, and the `_repr_kwargs` mechanism used to build readable representations.
- **`Omit`** ([task43_core](task43_core.md)) — sentinel used to hide default-valued keyword arguments from `__repr__`.

---

## Timezone Handling

Timezone behavior is the most subtle aspect of this module and is controlled by `enforce_tz`:

| Scenario | `enforce_tz=True` (default) | `enforce_tz=False` |
|----------|-----------------------------|--------------------|
| `approx` naive, input naive | Match if within delta | Match if within delta |
| `approx` naive, input aware | **No match** (tzinfo differs) | Input tzinfo stripped, then compared |
| `approx` aware, input aware | Match only if UTC offsets equal | Match if within delta regardless of offset |

When `enforce_tz=False` and `approx` is naive while the input is aware, `prepare()` strips the input's tzinfo via `dt.replace(tzinfo=None)` so the numeric comparison can proceed.

---

## Related Modules

- [task43_core](task43_core.md) — base `DirtyEquals` class, `Omit` sentinel, and logical combinators (`DirtyOr`, `DirtyAnd`, `DirtyNot`).
- [task43_numeric](task43_numeric.md) — the `IsNumeric` base class and numeric comparison types.
- [task43_strings](task43_strings.md) — string comparison types.
- [task43_sequence](task43_sequence.md) — sequence comparison types.
- [task43_dict](task43_dict.md) — dictionary comparison types.
- [task43_inspection](task43_inspection.md) — object inspection types.
- [task43_other](task43_other.md) — miscellaneous comparison types.
