# task43_numeric Module

## Introduction

The `task43_numeric` module (implemented in `dirty_equals/_numeric.py`) provides a family of
["dirty-equals"](task43_core.md) comparison types for **numeric values** — integers, floats,
`Decimal`s, and (via the base class) `date`/`datetime` objects. These types let you write
expressive assertions such as "this value is approximately 200", "this value is positive", or
"this value is an integer" without hard-coding exact expected values.

The module is built around a single powerful base class, [`IsNumeric`](#isnumeric), which
implements approximate comparison, inequality bounds, and type checking. All other classes in the
module are thin, intention-revealing subclasses that constrain the allowed type and/or pre-set a
comparison bound.

> **Note:** This module is one of several sibling modules in the `dirty_equals` package. For the
> shared comparison machinery (`__eq__`, `__or__`, `__and__`, `__invert__`, `value`, `repr`), see
> the [task43_core module](task43_core.md). For datetime-specific helpers, see
> [task43_datetime](task43_datetime.md).

---

## Module Architecture

The module is organized as a class hierarchy rooted at `IsNumeric`. Subclasses either narrow the
allowed types (e.g. `IsInt`, `IsFloat`) or pre-configure a bound (e.g. `IsPositive`, `IsNegative`).

```mermaid
classDiagram
    class DirtyEquals {
        <<abstract>>
        +equals(other) bool
        +value
        +__eq__(other) bool
        +__or__(other) DirtyOr
        +__and__(other) DirtyAnd
        +__invert__() DirtyNot
    }

    class IsNumeric {
        +allowed_types
        +approx
        +delta
        +gt, lt, ge, le
        +has_bounds_checks
        +prepare(other)
        +equals(other) bool
        +bounds_checks(other) bool
        +approx_equals(other, delta) bool
    }

    class IsNumber {
        +allowed_types = (int, float, Decimal)
    }

    class IsApprox {
        +__init__(approx, delta)
    }

    class IsPositive
    class IsNegative
    class IsNonNegative
    class IsNonPositive

    class IsInt {
        +allowed_types = int
    }
    class IsPositiveInt
    class IsNegativeInt

    class IsFloat {
        +allowed_types = float
    }
    class IsPositiveFloat
    class IsNegativeFloat

    DirtyEquals <|-- IsNumeric
    IsNumeric <|-- IsNumber
    IsNumeric <|-- IsInt
    IsNumeric <|-- IsFloat
    IsNumber <|-- IsApprox
    IsNumber <|-- IsPositive
    IsNumber <|-- IsNegative
    IsNumber <|-- IsNonNegative
    IsNumber <|-- IsNonPositive
    IsInt <|-- IsPositiveInt
    IsInt <|-- IsNegativeInt
    IsFloat <|-- IsPositiveFloat
    IsFloat <|-- IsNegativeFloat
```

### Class Hierarchy Summary

| Class | Parent | Allowed types | Pre-set bound |
|---|---|---|---|
| `IsNumeric` | `DirtyEquals` | `int, float, Decimal, date, datetime` | — (configurable) |
| `IsNumber` | `IsNumeric` | `int, float, Decimal` | — (configurable) |
| `IsApprox` | `IsNumber` | `int, float, Decimal` | `approx` (required) |
| `IsPositive` | `IsNumber` | `int, float, Decimal` | `gt=0` |
| `IsNegative` | `IsNumber` | `int, float, Decimal` | `lt=0` |
| `IsNonNegative` | `IsNumber` | `int, float, Decimal` | `ge=0` |
| `IsNonPositive` | `IsNumber` | `int, float, Decimal` | `le=0` |
| `IsInt` | `IsNumeric` | `int` | — (configurable) |
| `IsPositiveInt` | `IsInt` | `int` | `gt=0` |
| `IsNegativeInt` | `IsInt` | `int` | `lt=0` |
| `IsFloat` | `IsNumeric` | `float` | — (configurable) |
| `IsPositiveFloat` | `IsFloat` | `float` | `gt=0` |
| `IsNegativeFloat` | `IsFloat` | `float` | `lt=0` |

---

## Core Component: `IsNumeric`

`IsNumeric` is the foundation of the module. It is a generic class parameterized by the numeric
type `N` and implements three orthogonal capabilities:

1. **Type checking** — via the `allowed_types` class attribute and the `prepare` method.
2. **Approximate comparison** — via `approx` and `delta`.
3. **Inequality bounds** — via `gt`, `lt`, `ge`, and `le`.

### Constructor Arguments

| Argument | Type | Description |
|---|---|---|
| `approx` | `Optional[N]` | A value to approximately compare to. |
| `delta` | `Optional[N]` | The allowable difference when comparing to `approx`. If omitted, `value / 100` is used (or 2 seconds for datetimes). |
| `gt` | `Optional[N]` | The compared value must be **greater than** this. |
| `lt` | `Optional[N]` | The compared value must be **less than** this. |
| `ge` | `Optional[N]` | The compared value must be **greater than or equal to** this. |
| `le` | `Optional[N]` | The compared value must be **less than or equal to** this. |

If **no** arguments are provided, only the type is checked. If `approx` is combined with any of
`gt`, `lt`, `ge`, or `le`, a `TypeError` is raised.

### Key Attributes

- `allowed_types` — a class attribute defining the accepted types. Defaults to
  `(int, float, Decimal, date, datetime)`.
- `has_bounds_checks` — a boolean computed in `__init__` indicating whether any comparison bound
  was supplied. When `False`, `equals` only performs a type check.

### Comparison Flow

The comparison logic is split across three methods, invoked in sequence by the inherited
`DirtyEquals.__eq__`:

```mermaid
flowchart TD
    A["__eq__(other)"] --> B["equals(other)"]
    B --> C["prepare(other)"]
    C -->|"other is bool"| D["raise TypeError"]
    C -->|"not isinstance(other, allowed_types)"| D
    C -->|"valid"| E{"has_bounds_checks?"}
    E -->|"False"| F["return True (type check only)"]
    E -->|"True"| G["bounds_checks(other)"]
    G --> H{"approx set?"}
    H -->|"yes"| I["approx_equals(other, delta)"]
    H -->|"no"| J{"gt / lt / ge / le"}
    J --> K["return bound comparison result"]
    I --> L["abs(approx - other) <= delta"]
```

### `prepare(other)`

Validates and normalizes the incoming value:

- Raises `TypeError` if `other` is a boolean (`True`/`False`), since booleans are technically
  sub-types of `int` but should not be treated as numbers.
- Raises `TypeError` if `other` is not an instance of `allowed_types`.
- Otherwise returns `other` unchanged.

Because `DirtyEquals.__eq__` catches `TypeError` and `ValueError`, these exceptions translate into
a `False` comparison result rather than propagating.

### `bounds_checks(other)`

Applies the configured comparison. When `approx` is set, it computes the effective `delta`
(defaulting to `abs(other / 100)`, or `timedelta(seconds=2)` for `date` values) and delegates to
`approx_equals`. Otherwise it evaluates the inequality bounds in order (`gt`, `lt`, `ge`, `le`).

### `approx_equals(other, delta)`

Returns `abs(self.approx - other) <= delta`.

### Example

```py title="IsNumeric"
from dirty_equals import IsNumeric
from datetime import datetime

assert 1.0 == IsNumeric
assert 4 == IsNumeric(gt=3)
d = datetime(2020, 1, 1, 12, 0, 0)
assert d == IsNumeric(approx=datetime(2020, 1, 1, 12, 0, 1))
```

---

## Number-Only Classes

### `IsNumber`

`IsNumber` narrows `allowed_types` to `(int, float, Decimal)`, excluding `date` and `datetime`.
It inherits all constructor arguments from `IsNumeric` and serves as the base for the
approximate and sign-based number classes.

### `IsApprox`

A simplified subclass of `IsNumber` that **only** supports approximate comparison. Its constructor
takes a positional `approx` value and an optional `delta` keyword.

```py title="IsApprox"
from dirty_equals import IsApprox

assert 1.0 == IsApprox(1)
assert 123 == IsApprox(120, delta=4)
assert 201 == IsApprox(200)
assert 201 != IsApprox(200, delta=0.1)
```

### Sign-Based Classes

These classes pre-configure a single bound and clear their repr kwargs so they render cleanly
(e.g. `IsPositive` rather than `IsPositive(gt=0)`).

| Class | Bound | Meaning |
|---|---|---|
| `IsPositive` | `gt=0` | value is strictly positive |
| `IsNegative` | `lt=0` | value is strictly negative |
| `IsNonNegative` | `ge=0` | value is zero or positive |
| `IsNonPositive` | `le=0` | value is zero or negative |

```py title="Sign checks"
from decimal import Decimal
from dirty_equals import IsPositive, IsNegative, IsNonNegative, IsNonPositive

assert 1.0 == IsPositive
assert Decimal('3.14') == IsPositive
assert 0 != IsPositive

assert -1 == IsNegative
assert Decimal('-3.14') == IsNegative

assert 0 == IsNonNegative
assert -1 != IsNonNegative

assert 0 == IsNonPositive
assert 1 != IsNonPositive
```

---

## Type-Constrained Classes

### Integer Classes

`IsInt` sets `allowed_types = int`. Booleans are explicitly excluded by the `prepare` method even
though they are sub-types of `int`.

- `IsPositiveInt` — `IsInt` with `gt=0`.
- `IsNegativeInt` — `IsInt` with `lt=0`.

```py title="Integer checks"
from dirty_equals import IsInt, IsPositiveInt, IsNegativeInt

assert 1 == IsInt
assert 1.0 != IsInt
assert True != IsInt

assert 1 == IsPositiveInt
assert 1.0 != IsPositiveInt

assert -1 == IsNegativeInt
assert -1.0 != IsNegativeInt
```

### Float Classes

`IsFloat` sets `allowed_types = float`.

- `IsPositiveFloat` — `IsFloat` with `gt=0`.
- `IsNegativeFloat` — `IsFloat` with `lt=0`.

```py title="Float checks"
from dirty_equals import IsFloat, IsPositiveFloat, IsNegativeFloat

assert 1.0 == IsFloat
assert 1 != IsFloat

assert 1.0 == IsPositiveFloat
assert 1 != IsPositiveFloat

assert -1.0 == IsNegativeFloat
assert -1 != IsNegativeFloat
```

---

## Dependencies

The module depends on the shared comparison infrastructure and a small set of standard-library
types.

```mermaid
graph LR
    subgraph "task43_numeric"
        NUM["_numeric.py"]
    end

    subgraph "task43_core"
        BASE["_base.py::DirtyEquals"]
        UTILS["_utils.py::Omit"]
    end

    subgraph "stdlib"
        DT["datetime (date, datetime, timedelta)"]
        DEC["decimal.Decimal"]
        TYP["typing"]
    end

    NUM --> BASE
    NUM --> UTILS
    NUM --> DT
    NUM --> DEC
    NUM --> TYP
```

| Dependency | Purpose |
|---|---|
| [`DirtyEquals`](task43_core.md) | Base class providing `__eq__`, `__ne__`, `__or__`, `__and__`, `__invert__`, `value`, and `__repr__`. |
| `Omit` (from `_utils`) | Sentinel used to omit unset constructor arguments from the generated `repr`. |
| `datetime` | Provides `date`, `datetime`, and `timedelta` for datetime-aware approximate comparison. |
| `decimal.Decimal` | Supported numeric type. |
| `typing` | Generic type parameters (`TypeVar`, `Union`, `Optional`, `Tuple`, `Type`). |

---

## Integration with the Broader System

`IsNumeric` and its subclasses integrate with the rest of `dirty_equals` through the shared
`DirtyEquals` base class. This means every numeric type automatically supports:

- **Logical composition** — `IsPositive | IsNegative`, `IsInt & IsPositive`, `~IsPositive`
  (see [task43_core](task43_core.md) for `DirtyOr`, `DirtyAnd`, `DirtyNot`).
- **Value capture** — after a successful comparison, the matched value is available via the
  `.value` property.
- **Smart repr** — on success, the repr shows the actual matched value; on failure, it shows the
  descriptive form (e.g. `IsPositive`).

```mermaid
sequenceDiagram
    participant Test as Test / Assertion
    participant Num as IsNumeric subclass
    participant Base as DirtyEquals.__eq__
    participant Prep as prepare()
    participant Bounds as bounds_checks()

    Test->>Num: value == IsPositive
    Num->>Base: __eq__(value)
    Base->>Num: equals(value)
    Num->>Prep: prepare(value)
    Prep-->>Num: validated value
    Num->>Bounds: bounds_checks(value)
    Bounds-->>Num: bool
    Num-->>Base: bool
    Base-->>Test: bool (and stores .value)
```

---

## Related Modules

- [task43_core](task43_core.md) — `DirtyEquals` base class, logical operators, and shared utilities.
- [task43_datetime](task43_datetime.md) — `IsDatetime`, `IsNow`, `IsDate`, `IsToday` for datetime-specific checks.
- [task43_strings](task43_strings.md) — string and bytes comparison types.
- [task43_sequence](task43_sequence.md) — sequence comparison types (`HasLen`, `Contains`, etc.).
- [task43_dict](task43_dict.md) — dictionary comparison types.
- [task43_inspection](task43_inspection.md) — object inspection types (`IsInstance`, `HasName`, etc.).
- [task43_other](task43_other.md) — miscellaneous types (`IsUUID`, `IsJson`, `FunctionCheck`, booleans).
