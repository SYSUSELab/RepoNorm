# task43 — `dirty_equals`

## Introduction

`dirty_equals` is a Python library that provides **"dirty" equality types** — special objects that compare equal to a *range* of values rather than a single exact value. They are designed primarily for use in **tests**, where asserting against dynamic or partially-known data (timestamps, UUIDs, generated IDs, large nested structures) is otherwise awkward.

Instead of writing brittle assertions like:

```python
assert response.json() == {'id': 'edf9f29e-45c7-431c-99db-28ea44df9785', 'created': '2020-01-01T12:00:00'}
```

you can write flexible, self-documenting assertions:

```python
from dirty_equals import IsUUID, IsDatetime

assert response.json() == {'id': IsUUID, 'created': IsDatetime(iso_string=True)}
```

Every dirty type is an instance (or subclass) of the base [`DirtyEquals`](task43_core.md) class, which implements the comparison protocol (`__eq__`, `__ne__`) and the boolean composition operators (`|`, `&`, `~`).

### Key characteristics

- **Composable** — dirty types can be combined with `|` (OR), `&` (AND) and `~` (NOT), and nested inside one another.
- **Self-describing** — when a comparison fails, the `repr()` of the dirty type explains what was expected, producing readable pytest diffs.
- **Type-safe** — the library is fully typed and supports generic parameterisation (e.g. `IsInstance[Foo]`, `IsJson[IsStrictDict(...)]`).
- **Zero runtime dependencies** — only the standard library is required (with optional `pytz` support for timezones).

## Architecture Overview

The library is organised as a flat package of private modules, each grouping a family of related dirty types. All types ultimately derive from the single base class `DirtyEquals` defined in `_base.py`.

```mermaid
graph TD
    subgraph Core["Core Foundation"]
        Base["_base.py<br/>DirtyEquals / DirtyEqualsMeta<br/>DirtyOr / DirtyAnd / DirtyNot<br/>AnyThing / IsOneOf"]
        Utils["_utils.py<br/>PlainRepr / Omit / get_dict_arg"]
    end

    subgraph Families["Dirty Type Families"]
        Numeric["_numeric.py<br/>IsNumeric & subclasses"]
        Datetime["_datetime.py<br/>IsDatetime / IsNow / IsDate / IsToday"]
        Strings["_strings.py<br/>IsAnyStr / IsStr / IsBytes"]
        Sequence["_sequence.py<br/>HasLen / Contains / IsList / IsTuple"]
        Dict["_dict.py<br/>IsDict & subclasses"]
        Inspection["_inspection.py<br/>IsInstance / HasName / HasRepr / HasAttributes"]
        Other["_other.py<br/>IsUUID / IsJson / FunctionCheck"]
        Boolean["_boolean.py<br/>IsTrueLike / IsFalseLike"]
    end

    Base --> Numeric
    Base --> Datetime
    Base --> Strings
    Base --> Sequence
    Base --> Dict
    Base --> Inspection
    Base --> Other
    Base --> Boolean

    Utils --> Base
    Utils --> Numeric
    Utils --> Strings
    Utils --> Sequence
    Utils --> Dict
    Utils --> Other
    Utils --> Boolean

    Numeric --> Datetime
    Strings --> Inspection
```

### Inheritance hierarchy

The dirty types form a shallow inheritance tree rooted at `DirtyEquals`. Several families share a common base to reuse comparison logic:

```mermaid
classDiagram
    class DirtyEquals {
        <<abstract>>
        +equals(other) bool
        +__eq__(other) bool
        +__or__ / __and__ / __invert__
        +value
    }

    DirtyEquals <|-- AnyThing
    DirtyEquals <|-- IsOneOf
    DirtyEquals <|-- DirtyOr
    DirtyEquals <|-- DirtyAnd
    DirtyEquals <|-- DirtyNot

    DirtyEquals <|-- IsNumeric
    IsNumeric <|-- IsNumber
    IsNumeric <|-- IsInt
    IsNumeric <|-- IsFloat
    IsNumeric <|-- IsDatetime
    IsNumeric <|-- IsDate
    IsNumber <|-- IsApprox
    IsNumber <|-- IsPositive
    IsNumber <|-- IsNegative
    IsNumber <|-- IsNonNegative
    IsNumber <|-- IsNonPositive
    IsInt <|-- IsPositiveInt
    IsInt <|-- IsNegativeInt
    IsFloat <|-- IsPositiveFloat
    IsFloat <|-- IsNegativeFloat
    IsDatetime <|-- IsNow
    IsDate <|-- IsToday

    DirtyEquals <|-- IsAnyStr
    IsAnyStr <|-- IsStr
    IsAnyStr <|-- IsBytes

    DirtyEquals <|-- IsListOrTuple
    IsListOrTuple <|-- IsList
    IsListOrTuple <|-- IsTuple

    DirtyEquals <|-- IsDict
    IsDict <|-- IsPartialDict
    IsDict <|-- IsStrictDict
    IsDict <|-- IsIgnoreDict

    DirtyEquals <|-- IsInstance
    DirtyEquals <|-- HasName
    DirtyEquals <|-- HasRepr
    DirtyEquals <|-- HasAttributes

    DirtyEquals <|-- IsUUID
    DirtyEquals <|-- IsJson
    DirtyEquals <|-- FunctionCheck
    DirtyEquals <|-- IsTrueLike
    DirtyEquals <|-- IsFalseLike
```

## Core Foundation

The foundation of the library is documented in **[task43_core.md](task43_core.md)**. It covers:

- **`DirtyEquals`** — the abstract base class implementing the comparison protocol, the `value` property, and the `|`, `&`, `~` operators.
- **`DirtyEqualsMeta`** — the metaclass enabling class-level comparisons (e.g. `Foo == IsInstance[Foo]`) and operator support on the class itself.
- **`DirtyOr` / `DirtyAnd` / `DirtyNot`** — the boolean composition types produced by the operators.
- **`AnyThing`** — a wildcard that matches any value.
- **`IsOneOf`** — matches any of a set of values.
- **`PlainRepr` / `Omit` / `get_dict_arg`** — shared utilities for repr formatting and argument parsing.

## Dirty Type Families

Each family below is documented in its own file. They all build on the core foundation and share the same comparison protocol.

### Numeric Comparisons — [task43_numeric.md](task43_numeric.md)

Provides `IsNumeric` and its subclasses for comparing numbers with approximate (`approx`/`delta`) and inequality (`gt`, `lt`, `ge`, `le`) constraints, plus type-specific variants (`IsInt`, `IsFloat`, `IsPositive`, `IsNegative`, etc.). This family is the base for datetime comparisons.

### Datetime Comparisons — [task43_datetime.md](task43_datetime.md)

Extends the numeric family to `date` and `datetime` values. Includes `IsDatetime`, `IsDate`, and the "relative to now" types `IsNow` and `IsToday`, with support for unix timestamps, ISO strings, custom format strings, and timezone enforcement.

### String & Bytes Comparisons — [task43_strings.md](task43_strings.md)

`IsAnyStr`, `IsStr`, and `IsBytes` check string/bytes values against length constraints, case, and regular expressions. `IsStr` is reused by the inspection family.

### Sequence Comparisons — [task43_sequence.md](task43_sequence.md)

`HasLen`, `Contains`, `IsListOrTuple`, `IsList`, and `IsTuple` validate the length, membership, and positional/order-insensitive contents of lists and tuples.

### Dictionary Comparisons — [task43_dict.md](task43_dict.md)

`IsDict` and its subclasses `IsPartialDict`, `IsStrictDict`, and `IsIgnoreDict` provide partial, order-sensitive, and value-ignoring dictionary comparisons, configurable via `.settings(...)`.

### Object Inspection — [task43_inspection.md](task43_inspection.md)

`IsInstance`, `HasName`, `HasRepr`, and `HasAttributes` inspect the type, name, repr, and attributes of arbitrary objects.

### Miscellaneous Types — [task43_other.md](task43_other.md)

`IsUUID`, `IsJson`, `FunctionCheck`, `IsTrueLike`, and `IsFalseLike` cover UUIDs, JSON payloads, custom predicate functions, and truthiness checks.

## Comparison Data Flow

The following diagram shows how a comparison flows through the base class and into a concrete dirty type:

```mermaid
sequenceDiagram
    participant Test as Test / Assertion
    participant DE as DirtyEquals.__eq__
    participant Sub as Concrete Type.equals()
    participant Util as _utils helpers

    Test->>DE: dirty == other
    DE->>DE: store self._other = other
    DE->>Sub: equals(other)
    Sub->>Util: (optional) parse/format helpers
    Sub-->>DE: bool result
    Note over DE: TypeError / ValueError<br/>are caught and treated as False
    DE->>DE: store self._was_equal
    DE-->>Test: bool result
    Note over DE: __repr__ returns repr(other)<br/>on success, else the expectation
```

## How the Module Fits Into the System

`dirty_equals` is a **standalone, dependency-free library**. It does not depend on any other module in the system; instead, it is consumed by test suites and applications that need flexible equality assertions. Its only external integration point is the optional `pytz` package, used by `IsNow` when a string timezone is supplied.

```mermaid
graph LR
    App["Application / Test Suite"] -->|imports| DE["dirty_equals"]
    DE -->|optional| Pytz["pytz"]
    DE -->|stdlib only| Std["json / re / uuid / datetime / decimal"]
```

## Summary

| Sub-module | Documentation | Purpose |
| --- | --- | --- |
| Core Foundation | [task43_core.md](task43_core.md) | Base class, metaclass, composition operators, utilities |
| Numeric | [task43_numeric.md](task43_numeric.md) | Numeric comparisons with bounds and approximation |
| Datetime | [task43_datetime.md](task43_datetime.md) | Date/datetime comparisons and "now"/"today" checks |
| Strings | [task43_strings.md](task43_strings.md) | String/bytes comparisons with regex and length |
| Sequence | [task43_sequence.md](task43_sequence.md) | List/tuple length, membership, and content checks |
| Dict | [task43_dict.md](task43_dict.md) | Partial/strict/ignore dictionary comparisons |
| Inspection | [task43_inspection.md](task43_inspection.md) | Type, name, repr, and attribute inspection |
| Other | [task43_other.md](task43_other.md) | UUID, JSON, function checks, truthiness |
