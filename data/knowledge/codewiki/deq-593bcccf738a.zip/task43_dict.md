# task43_dict Module

## Introduction

The `task43_dict` module provides a family of comparison types for dictionaries within the `dirty-equals` library. These types allow developers to write expressive, flexible assertions about dictionary contents — supporting partial matching, strict key ordering, and value ignoring — without writing verbose manual comparison logic.

The module is built around a single configurable base class, [`IsDict`](#isdict), which can be customized either through subclassing or via the fluent `.settings(...)` API. Three convenience subclasses — [`IsPartialDict`](#ispartialdict), [`IsStrictDict`](#isstrictdict), and [`IsIgnoreDict`](#isignoredict) — provide pre-configured shortcuts for the most common comparison modes.

> **Note:** This module is one of several comparison-type modules in the library. For the shared comparison machinery (equality protocol, boolean composition, repr handling), see [task43_core](task43_core.md). For other comparison domains, see [task43_numeric](task43_numeric.md), [task43_datetime](task43_datetime.md), [task43_strings](task43_strings.md), [task43_sequence](task43_sequence.md), [task43_inspection](task43_inspection.md), and [task43_other](task43_other.md).

---

## Architecture Overview

All dictionary comparison types inherit from `IsDict`, which itself extends the library-wide base class `DirtyEquals`. The three convenience subclasses only override the `_post_init` hook to set default flags, keeping the comparison logic centralized in `IsDict.equals`.

```mermaid
classDiagram
    class DirtyEquals {
        <<abstract>>
        +equals(other) bool
        +__eq__(other) bool
        +__ne__(other) bool
        +settings(...)
        +value
    }
    class IsDict {
        +expected_values: Dict
        +strict: bool
        +partial: bool
        +ignore: Container|Callable|None
        +__init__(*args, **kwargs)
        +settings(strict, partial, ignore) IsDict
        +equals(other) bool
        +_post_init()
        +_filter_dict(d) Dict
        +_ignore_value(v) bool
        +_repr_ne() str
    }
    class IsPartialDict {
        +_post_init()
    }
    class IsStrictDict {
        +_post_init()
    }
    class IsIgnoreDict {
        +_post_init()
    }

    DirtyEquals <|-- IsDict
    IsDict <|-- IsPartialDict
    IsDict <|-- IsStrictDict
    IsDict <|-- IsIgnoreDict
```

### Component Responsibilities

| Component | Responsibility |
|-----------|----------------|
| [`IsDict`](#isdict) | Configurable base class; holds all comparison logic and the `.settings(...)` fluent API. |
| [`IsPartialDict`](#ispartialdict) | Pre-configured `IsDict` with `partial=True`. |
| [`IsStrictDict`](#isstrictdict) | Pre-configured `IsDict` with `strict=True`. |
| [`IsIgnoreDict`](#isignoredict) | Pre-configured `IsDict` with `ignore={None}`. |

---

## Dependencies

The module depends on shared infrastructure from the core module and a utility helper.

```mermaid
graph LR
    subgraph task43_dict
        IsDict
        IsPartialDict
        IsStrictDict
        IsIgnoreDict
    end
    subgraph task43_core
        DirtyEquals
        DirtyEqualsMeta
    end
    subgraph _utils
        get_dict_arg
    end

    IsDict --> DirtyEquals
    IsDict --> get_dict_arg
    IsPartialDict --> IsDict
    IsStrictDict --> IsDict
    IsIgnoreDict --> IsDict
    DirtyEquals -.metaclass.-> DirtyEqualsMeta
```

- **`DirtyEquals`** ([task43_core](task43_core.md)) — provides the `__eq__`/`__ne__` protocol, the `value` property, boolean composition operators (`|`, `&`, `~`), and repr handling. `IsDict` implements the abstract `equals` method.
- **`get_dict_arg`** — a utility that enforces `dict(...)`-style initialization semantics (either a single dict argument or keyword arguments, never both).
- **`DirtyEqualsMeta`** ([task43_core](task43_core.md)) — the metaclass enabling class-level equality and composition.

---

## Comparison Modes

`IsDict` supports three orthogonal comparison modifiers, each controlled by an attribute:

| Modifier | Attribute | Effect |
|----------|-----------|--------|
| **Partial** | `partial=True` | Only keys present in the expected dict are checked; extra keys in `other` are ignored. |
| **Strict** | `strict=True` | The order of key/value pairs must match exactly. |
| **Ignore** | `ignore=<container or callable>` | Values matching the ignore specification are omitted from comparison on both sides. |

> **Constraint:** `partial` and `ignore` cannot be combined — attempting to do so raises a `TypeError` in `.settings(...)`.

---

## Data Flow: The `equals` Process

The following diagram illustrates how `IsDict.equals` processes a comparison, applying each modifier in sequence.

```mermaid
flowchart TD
    A[equals other] --> B{isinstance other, dict?}
    B -- No --> Z[return False]
    B -- Yes --> C{partial?}
    C -- Yes --> D[Filter other to keys in expected]
    C -- No --> E
    D --> E{ignore set?}
    E -- Yes --> F[Filter expected and other via _filter_dict]
    E -- No --> G
    F --> G{other == expected?}
    G -- No --> Z
    G -- Yes --> H{strict?}
    H -- No --> Y[return True]
    H -- Yes --> I{key order matches?}
    I -- No --> Z
    I -- Yes --> Y
```

### Step-by-step

1. **Type guard** — If `other` is not a `dict`, return `False` immediately.
2. **Partial filtering** — When `partial=True`, `other` is reduced to only the keys present in `expected_values`.
3. **Ignore filtering** — When `ignore` is set, both `expected_values` and `other` are passed through `_filter_dict`, which drops any key whose value satisfies `_ignore_value`.
4. **Equality check** — The (possibly filtered) dicts are compared with `!=`.
5. **Strict ordering** — When `strict=True`, the key sequences must match in order.

---

## Core Components

### IsDict

The configurable base class for all dictionary comparisons. On its own it behaves much like a plain `dict`, but it can be subclassed or modified with `.settings(...)` to enable powerful comparison behavior.

**Initialization** accepts either a single dictionary argument or keyword arguments (mirroring `dict()`), enforced by `get_dict_arg`:

```py
from dirty_equals import IsDict

assert {'a': 1, 'b': 2} == IsDict(a=1, b=2)
assert {1: 2, 3: 4} == IsDict({1: 2, 3: 4})
```

**Instance attributes:**

| Attribute | Type | Default | Description |
|-----------|------|---------|-------------|
| `expected_values` | `Dict[Any, Any]` | — | The dictionary to compare against. |
| `strict` | `bool` | `False` | Enforce key ordering. |
| `partial` | `bool` | `False` | Only check keys in `expected_values`. |
| `ignore` | `None \| Container \| Callable` | `None` | Values to omit from comparison. |

#### `.settings(...)`

Returns a **new** `IsDict` instance (allowing chaining) with the specified modifiers applied. Because it returns a new object, the original is never mutated.

| Argument | Type | Description |
|----------|------|-------------|
| `strict` | `Optional[bool]` | If `True`, key/value order must match. |
| `partial` | `Optional[bool]` | If `True`, only keys in the wrapped dict are checked. |
| `ignore` | `None \| Container \| Callable` | Values to omit. A `Container` (e.g. `set`, `list`) of values, or a predicate function returning `True` to ignore a value. |

```py
from dirty_equals import IsDict

assert {'a': 1, 'b': 2, 'c': None} == IsDict(a=1, b=2).settings(partial=True)
assert {'b': 2, 'a': 1} != IsDict(a=1, b=2).settings(strict=True)

# combining partial and strict
assert {'a': 1, 'b': None, 'c': 3} == IsDict(a=1, c=3).settings(strict=True, partial=True)
```

> **Raises:** `TypeError` if both `partial=True` and a truthy `ignore` are set.

#### Internal helpers

- **`_post_init()`** — Hook called at the end of `__init__`; overridden by subclasses to set default flags.
- **`_filter_dict(d)`** — Returns a copy of `d` with keys removed where `_ignore_value(v)` is `True`.
- **`_ignore_value(v)`** — Determines whether a value should be ignored. Handles `DirtyEquals` instances specially (never ignored), callable predicates, and container membership (with a `TypeError` fallback for unhashable values).
- **`_repr_ne()`** — Builds a repr that includes only the modifiers that differ from the class defaults, producing concise output such as `IsDict[partial=True](a=1)`.

---

### IsPartialDict

Equivalent to `IsDict(...).settings(partial=True)`. Only the keys present in the expected dict are checked; extra keys in the compared dict are permitted.

```py
from dirty_equals import IsPartialDict

assert {'a': 1, 'b': 2, 'c': 3} == IsPartialDict(a=1, b=2)
assert {'a': 1, 'b': 2, 'c': 3} != IsPartialDict(a=1, b=3)
assert {'a': 1, 'b': 2, 'd': 3} != IsPartialDict(a=1, b=2, c=3)

# combining partial and strict
assert {'a': 1, 'b': None, 'c': 3} == IsPartialDict(a=1, c=3).settings(strict=True)
```

---

### IsStrictDict

Equivalent to `IsDict(...).settings(strict=True)`. The order of key/value pairs must match exactly.

```py
from dirty_equals import IsStrictDict

assert {'a': 1, 'b': 2} == IsStrictDict(a=1, b=2)
assert {'a': 1, 'b': 2, 'c': 3} != IsStrictDict(a=1, b=2)
assert {'b': 2, 'a': 1} != IsStrictDict(a=1, b=2)

# combining partial and strict
assert {'a': 1, 'b': None, 'c': 3} == IsStrictDict(a=1, c=3).settings(partial=True)
```

---

### IsIgnoreDict

Equivalent to `IsDict(...).settings(ignore={None})`. Values equal to `None` are ignored on both sides of the comparison. The `.settings(...)` API can further customize which values are ignored.

```py
from dirty_equals import IsIgnoreDict

assert {'a': 1, 'b': 2, 'c': None} == IsIgnoreDict(a=1, b=2)
assert {'a': 1, 'b': 2, 'c': None, 'c': 'ignore'} == (
    IsIgnoreDict(a=1, b=2).settings(ignore={None, 'ignore'})
)

def is_even(v: int) -> bool:
    return v % 2 == 0

assert {'a': 1, 'b': 2, 'c': 3, 'd': 4} == (
    IsIgnoreDict(a=1, c=3).settings(ignore=is_even)
)
```

---

## Component Interaction: Settings and Subclassing

The following sequence diagram shows how `.settings(...)` produces a new configured instance and how subclass defaults interact with it.

```mermaid
sequenceDiagram
    participant User
    participant IsDict
    participant NewIsDict as New IsDict instance

    User->>IsDict: IsDict(a=1, b=2)
    IsDict->>IsDict: get_dict_arg(...)
    IsDict->>IsDict: _post_init() (no-op)
    User->>IsDict: .settings(partial=True)
    IsDict->>NewIsDict: __class__(expected_values)
    IsDict->>NewIsDict: copy __dict__
    IsDict->>NewIsDict: set partial=True
    IsDict->>NewIsDict: validate partial/ignore conflict
    NewIsDict-->>User: configured instance
```

### Subclass default behavior

Each convenience subclass overrides `_post_init` to set a single flag:

```mermaid
graph TD
    A[IsDict._post_init: no-op] --> B[IsPartialDict._post_init: partial=True]
    A --> C[IsStrictDict._post_init: strict=True]
    A --> D[IsIgnoreDict._post_init: ignore={None}]
```

Because `.settings(...)` copies the instance `__dict__` and only overrides explicitly provided arguments, subclass defaults are preserved unless explicitly changed. The `_repr_ne` method uses the class name to decide which modifiers are "default" and therefore omitted from the repr.

---

## Relationship to Other Modules

The `task43_dict` module is a peer of the other comparison-type modules. All of them share the same base protocol and composition operators.

```mermaid
graph TD
    Core[task43_core: DirtyEquals]
    Dict[task43_dict: IsDict family]
    Numeric[task43_numeric]
    Datetime[task43_datetime]
    Strings[task43_strings]
    Sequence[task43_sequence]
    Inspection[task43_inspection]
    Other[task43_other]

    Core --> Dict
    Core --> Numeric
    Core --> Datetime
    Core --> Strings
    Core --> Sequence
    Core --> Inspection
    Core --> Other
```

- For the shared equality protocol, `value` property, and boolean composition (`|`, `&`, `~`), see [task43_core](task43_core.md).
- Dictionary values may themselves be other comparison types (e.g. `IsDict(a=IsInt)`), enabling nested comparisons. See [task43_numeric](task43_numeric.md), [task43_strings](task43_strings.md), and [task43_inspection](task43_inspection.md).

---

## Summary

The `task43_dict` module delivers a flexible, composable dictionary comparison system:

- **`IsDict`** — the configurable core with `partial`, `strict`, and `ignore` modifiers exposed via `.settings(...)`.
- **`IsPartialDict`**, **`IsStrictDict`**, **`IsIgnoreDict`** — convenience subclasses for common modes.
- All types integrate with the library-wide `DirtyEquals` protocol, supporting boolean composition and nested comparisons.
