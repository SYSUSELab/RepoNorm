# Inspection Module (`task43_inspection`)

## Introduction

The `task43_inspection` module provides a set of **inspection-based** dirty-equals types. Unlike the numeric, string, or sequence modules that validate the *value* of an object, these types validate **structural and introspective properties** of an object:

- Its **type** (`IsInstance`)
- Its **name** (`HasName`)
- Its **string representation** (`HasRepr`)
- Its **attributes** (`HasAttributes`)

These types are especially useful in tests where you receive an object whose exact identity is unknown or irrelevant, but whose *shape* (type, name, repr, or attributes) must be asserted.

All types in this module are implemented in `dirty_equals/_inspection.py` and inherit from the shared [`DirtyEquals`](task43_core.md) base class.

---

## Core Components

| Component | Purpose |
|-----------|---------|
| `IsInstance` | Checks that a value is an instance of an expected type (or tuple of types). |
| `HasName` | Checks that a value has a given `__name__` attribute (or is an instance of a class with that name). |
| `HasRepr` | Checks that `repr(value)` matches an expected string. |
| `HasAttributes` | Performs a partial check that a value has the given attributes with matching values. |

---

## Architecture

The module builds on the shared foundation provided by [`task43_core`](task43_core.md). Each inspection type subclasses `DirtyEquals` and implements the abstract `equals()` method.

```mermaid
graph TD
    subgraph core["task43_core"]
        DE["DirtyEquals&lt;T&gt;"]
        DEM["DirtyEqualsMeta"]
        UTIL["get_dict_arg()"]
    end

    subgraph strings["task43_strings"]
        ISSTR["IsStr"]
    end

    subgraph inspection["task43_inspection"]
        II["IsInstance"]
        HN["HasName"]
        HR["HasRepr"]
        HA["HasAttributes"]
    end

    DE --> II
    DE --> HN
    DE --> HR
    DE --> HA
    DEM -.metaclass.-> DE
    UTIL --> HA
    ISSTR --> HN
    ISSTR --> HR

    classDef coreStyle fill:#e1f5ff,stroke:#0288d1
    classDef strStyle fill:#fff3e0,stroke:#f57c00
    classDef inspStyle fill:#e8f5e9,stroke:#388e3c
    class DE,DEM,UTIL coreStyle
    class ISSTR strStyle
    class II,HN,HR,HA inspStyle
```

### Dependency Summary

- **`DirtyEquals`** (`task43_core`) — provides the `__eq__`/`__ne__` protocol, the `value` property, logical operators (`|`, `&`, `~`), and the `__repr__` behavior. See [task43_core.md](task43_core.md).
- **`get_dict_arg`** (`task43_core`) — used by `HasAttributes` to normalize constructor arguments in the same way `dict(...)` does.
- **`IsStr`** (`task43_strings`) — used as the type annotation for the `expected_name` and `expected_repr` arguments, allowing regex/constraint-based matching. See [task43_strings.md](task43_strings.md).

---

## Component Details

### `IsInstance`

Checks that a value is an instance of the expected type.

```python
class IsInstance(DirtyEquals[ExpectedType]):
    def __init__(self, expected_type, *, only_direct_instance: bool = False): ...
```

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `expected_type` | `type` or tuple of types | — | The type(s) to check against. |
| `only_direct_instance` | `bool` | `False` | When `True`, subclasses are **not** considered equal. |

**Behavior:**

- When `only_direct_instance=False` (default), uses `isinstance(other, expected_type)`.
- When `only_direct_instance=True`, uses `type(other) == expected_type`, excluding subclasses.

**Parameterization:** `IsInstance[Foo]` is exactly equivalent to `IsInstance(Foo)`, enabled by `__class_getitem__`.

```python
from dirty_equals import IsInstance

class Foo: pass
class Bar(Foo): pass

assert Foo() == IsInstance[Foo]
assert Bar() == IsInstance[Foo]
assert Bar() != IsInstance(Foo, only_direct_instance=True)
```

---

### `HasName`

Checks that a value has the given `__name__` attribute.

```python
class HasName(DirtyEquals[T]):
    def __init__(self, expected_name: Union[IsStr, str], *, allow_instances: bool = True): ...
```

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `expected_name` | `str` or `IsStr` | — | The name to check against. Supports `IsStr` for regex/constraint matching. |
| `allow_instances` | `bool` | `True` | When `True`, instances of classes with the matching name are also considered equal. |

**Behavior:**

1. First checks `getattr(other, '__name__', None) == expected_name` (matches classes/functions directly).
2. If `allow_instances=True`, additionally checks `other.__class__.__name__ == expected_name` (matches instances).

**Parameterization:** `HasName['Foo']` is equivalent to `HasName('Foo')`.

```python
from dirty_equals import HasName, IsStr

class Foo: pass

assert Foo == HasName('Foo')
assert Foo() == HasName('Foo')
assert Foo() != HasName('Foo', allow_instances=False)
assert Foo == HasName(IsStr(regex='F..'))
```

---

### `HasRepr`

Checks that `repr(value)` matches an expected string.

```python
class HasRepr(DirtyEquals[T]):
    def __init__(self, expected_repr: Union[IsStr, str]): ...
```

**Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `expected_repr` | `str` or `IsStr` | The expected `repr()` value. Supports `IsStr` for regex/constraint matching. |

**Behavior:** Compares `repr(other) == self.expected_repr` directly.

**Parameterization:** `HasRepr['...']` is equivalent to `HasRepr('...')`.

```python
from dirty_equals import HasRepr, IsStr

class Foo:
    def __repr__(self):
        return 'This is a Foo'

assert Foo() == HasRepr('This is a Foo')
assert Foo == HasRepr(IsStr(regex='<class.+'))
assert 42 == HasRepr('42')
```

---

### `HasAttributes`

Performs a **partial** check that a value has the given attributes with matching values. The provided attributes do not need to be exhaustive.

```python
class HasAttributes(DirtyEquals[Any]):
    def __init__(self, *expected_args: Dict[Any, Any], **expected_kwargs: Any): ...
```

**Constructor forms** (mirrors `dict(...)`):

- `HasAttributes(a=1, b=2)` — keyword arguments.
- `HasAttributes({'a': 1, 'b': 2})` — a single dictionary argument.

Mixing both forms raises a `TypeError` (enforced by [`get_dict_arg`](task43_core.md)).

**Behavior:** Iterates over `expected_attrs`; for each attribute, retrieves it via `getattr(other, attr)`. Returns `False` if any attribute is missing (`AttributeError`) or its value does not equal the expected value.

```python
from dirty_equals import HasAttributes, IsInt, IsStr, AnyThing

class Foo:
    def __init__(self, a, b):
        self.a = a
        self.b = b
    def spam(self): pass

assert Foo(1, 2) == HasAttributes(a=1, b=2)
assert Foo(1, 2) == HasAttributes(a=1)          # partial check
assert Foo(1, 's') == HasAttributes(a=IsInt, b=IsStr)
assert Foo(1, 2) == HasAttributes(a=1, b=2, spam=AnyThing)
```

> **Note:** The `equals` implementation deliberately uses `getattr` inside a `try/except AttributeError` block to avoid issues where `AnyThing` could equal `None` or a default attribute value.

---

## Data Flow

The following diagram shows how an equality comparison flows through an inspection type, leveraging the shared `DirtyEquals.__eq__` protocol.

```mermaid
sequenceDiagram
    participant Test as Test Code
    participant DE as DirtyEquals.__eq__
    participant Insp as Inspection Type (e.g. HasName)
    participant Obj as Object Under Test

    Test->>DE: obj == HasName('Foo')
    DE->>DE: store self._other = obj
    DE->>Insp: equals(obj)
    alt IsInstance
        Insp->>Obj: isinstance(obj, expected_type)
    else HasName
        Insp->>Obj: getattr(obj, '__name__')
        Insp->>Obj: obj.__class__.__name__
    else HasRepr
        Insp->>Obj: repr(obj)
    else HasAttributes
        loop each expected attr
            Insp->>Obj: getattr(obj, attr)
        end
    end
    Obj-->>Insp: value(s)
    Insp-->>DE: bool result
    DE->>DE: self._was_equal = result
    DE-->>Test: bool
```

---

## Component Interaction

```mermaid
graph LR
    subgraph "Comparison Protocol (task43_core)"
        EQ["__eq__ / __ne__"]
        VAL["value property"]
        LOGIC["| & ~ operators"]
    end

    subgraph "Inspection Types"
        II["IsInstance"]
        HN["HasName"]
        HR["HasRepr"]
        HA["HasAttributes"]
    end

    EQ --> II
    EQ --> HN
    EQ --> HR
    EQ --> HA
    VAL -.reads.-> EQ
    LOGIC -.composes.-> II
    LOGIC -.composes.-> HN
    LOGIC -.composes.-> HR
    LOGIC -.composes.-> HA
```

All inspection types can be **composed** using the logical operators inherited from `DirtyEquals`:

```python
from dirty_equals import HasName, HasRepr

# Combine inspection checks
assert Foo() == (HasName('Foo') & HasRepr('This is a Foo'))
```

---

## Process Flow: Choosing an Inspection Type

```mermaid
flowchart TD
    Start["Need to assert a structural property?"] --> Q1{"What property?"}
    Q1 -->|Type| II["IsInstance(expected_type)"]
    Q1 -->|Name| HN["HasName(name)"]
    Q1 -->|repr string| HR["HasRepr(repr_str)"]
    Q1 -->|Attributes| HA["HasAttributes(**attrs)"]

    II --> Q2{"Exclude subclasses?"}
    Q2 -->|Yes| II2["only_direct_instance=True"]
    Q2 -->|No| II1["default"]

    HN --> Q3{"Match instances too?"}
    Q3 -->|No| HN2["allow_instances=False"]
    Q3 -->|Yes| HN1["default"]

    HN1 --> Q4{"Regex/constraints?"}
    HR --> Q4
    Q4 -->|Yes| IS["Use IsStr(...)"]
    Q4 -->|No| PLAIN["Use plain str"]
```

---

## Relationship to Other Modules

| Module | Relationship |
|--------|--------------|
| [task43_core.md](task43_core.md) | Provides `DirtyEquals` base class, `get_dict_arg` helper, and the comparison protocol. |
| [task43_strings.md](task43_strings.md) | Provides `IsStr`, used for `expected_name` and `expected_repr` arguments. |
| [task43_numeric.md](task43_numeric.md) | Numeric types (e.g. `IsInt`) are commonly used as expected attribute values in `HasAttributes`. |
| [task43_other.md](task43_other.md) | `AnyThing` is frequently used as a wildcard attribute value in `HasAttributes`. |

---

## Summary

The `task43_inspection` module extends dirty-equals with **introspection-based matchers**. Each type focuses on a single structural aspect of an object — its type, name, repr, or attributes — and integrates seamlessly with the shared `DirtyEquals` protocol for equality, negation, and logical composition. By delegating common behavior to [`task43_core`](task43_core.md) and reusing [`IsStr`](task43_strings.md) for flexible string matching, the module stays small, focused, and composable.
