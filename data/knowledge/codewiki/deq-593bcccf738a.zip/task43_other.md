# task43_other Module

## Introduction

The `task43_other` module provides a collection of miscellaneous "dirty-equals" types that don't fit neatly into the numeric, datetime, string, sequence, dict, or inspection categories. It contains two source files:

- **`dirty_equals/_other.py`** — `IsUUID`, `IsJson`, and `FunctionCheck`
- **`dirty_equals/_boolean.py`** — `IsTrueLike` and `IsFalseLike`

These types follow the same core contract as every other dirty-equals type: they subclass [`DirtyEquals`](task43_core.md) and implement an `equals(other)` method that returns a boolean. They are designed to be used on the **right-hand side** of an equality comparison, allowing flexible, semantic assertions such as `assert value == IsUUID(4)`.

This module is a leaf module in the dependency graph — it depends on the core module but is not depended upon by other dirty-equals modules.

---

## Architecture

### Position in the Module Tree

The `task43_other` module builds directly on the shared foundation provided by [`task43_core`](task43_core.md). It does not depend on any of the specialized sibling modules (numeric, datetime, strings, sequence, dict, inspection), though its types can be **composed** with them at runtime.

```mermaid
graph TD
    subgraph core["task43_core"]
        DE[DirtyEquals]
        DEM[DirtyEqualsMeta]
        PR[PlainRepr]
        OM[Omit]
    end

    subgraph other["task43_other (current)"]
        UUID[IsUUID]
        JSON[IsJson]
        FC[FunctionCheck]
        TL[IsTrueLike]
        FL[IsFalseLike]
    end

    DE --> UUID
    DE --> JSON
    DE --> FC
    DE --> TL
    DE --> FL
    PR --> UUID
    PR --> JSON
    PR --> FC
    OM --> FL

    JSON -.->|composes with| SIBLINGS["Sibling types<br/>(IsStrictDict, IsPositiveInt, ...)"]
```

### Component Overview

| Component | File | Purpose |
|-----------|------|---------|
| `IsUUID` | `_other.py` | Validates UUID strings/objects, optionally by version |
| `IsJson` | `_other.py` | Validates and compares JSON content |
| `FunctionCheck` | `_other.py` | Delegates equality to a user-supplied predicate |
| `IsTrueLike` | `_boolean.py` | Truthiness check (`bool(other)`) |
| `IsFalseLike` | `_boolean.py` | Falsiness check (`not bool(other)`) |

---

## Core Components

### IsUUID

`IsUUID` checks whether a value is a valid UUID, with optional version filtering.

**Constructor:** `IsUUID(version: Literal[None, 1, 2, 3, 4, 5] = None)`

- Accepts both `UUID` objects and string representations (with or without hyphens).
- When `version` is provided, only UUIDs of that version match.
- The `version` argument is passed to the base class as a repr argument (using `plain_repr('*')` when omitted) so that `repr()` renders cleanly.

**Equality logic:**

```mermaid
flowchart TD
    A[equals other] --> B{isinstance UUID?}
    B -->|yes| C[uuid = other]
    B -->|no| D{isinstance str?}
    D -->|no| E[return False]
    D -->|yes| F[uuid = UUID other]
    F --> G{version set and mismatch?}
    G -->|yes| E
    G -->|no| H{version set?}
    C --> H
    H -->|yes| I[return uuid.version == version]
    H -->|no| J[return True]
```

**Example:**

```py
import uuid
from dirty_equals import IsUUID

assert 'edf9f29e-45c7-431c-99db-28ea44df9785' == IsUUID
assert 'edf9f29e-45c7-431c-99db-28ea44df9785' == IsUUID(4)
assert 'edf9f29e45c7431c99db28ea44df9785' == IsUUID(4)
assert 'edf9f29e-45c7-431c-99db-28ea44df9785' != IsUUID(5)
assert uuid.uuid4() == IsUUID(4)
```

> **Note:** Invalid UUID strings raise `ValueError` inside `equals`. This is caught by the base class `__eq__`, which treats it as "not equal" rather than propagating the exception.

---

### IsJson

`IsJson` checks that a value is a JSON document and optionally compares its parsed contents.

**Constructors (overloaded):**

- `IsJson(expected_value=AnyJson)` — compare against a single expected value.
- `IsJson(**expected_kwargs)` — compare against a dict built from keyword arguments.

`expected_value` and `expected_kwargs` are mutually exclusive; supplying both raises `TypeError`.

**Parameterization:** Like [`IsInstance`](task43_inspection.md), `IsJson` supports the `IsJson[xyz]` syntax via `__class_getitem__`, which is exactly equivalent to `IsJson(xyz)`.

**Equality logic:**

```mermaid
flowchart TD
    A[equals other] --> B{isinstance str or bytes?}
    B -->|no| C[return False]
    B -->|yes| D[v = json.loads other]
    D --> E{expected_value is AnyJson?}
    E -->|yes| F[return True]
    E -->|no| G[return v == expected_value]
```

Because the parsed value is compared with `==`, **nested dirty-equals types work naturally** — the comparison delegates to their `__eq__` methods.

**Example:**

```py
from dirty_equals import IsJson, IsStrictDict, IsPositiveInt

assert '{"a": 1, "b": 2}' == IsJson
assert '{"a": 1, "b": 2}' == IsJson(a=1, b=2)
assert '{"a": 1}' != IsJson(a=2)
assert 'invalid json' != IsJson
assert '{"a": 1}' == IsJson(a=IsPositiveInt)
assert '"just a quoted string"' == IsJson('just a quoted string')

assert '{"a": 1, "b": 2}' == IsJson[IsStrictDict(a=1, b=2)]
assert '{"b": 2, "a": 1}' != IsJson[IsStrictDict(a=1, b=2)]
```

> **Note:** `json.loads` may raise `json.JSONDecodeError` (a subclass of `ValueError`) for malformed input. This is caught by the base class and treated as "not equal".

---

### FunctionCheck

`FunctionCheck` is the most flexible type in the module — it delegates the equality decision entirely to a user-supplied callable.

**Constructor:** `FunctionCheck(func: Callable[[Any], bool])`

- `func` receives the value being compared and must return a boolean.
- The function's `__name__` is used as the repr argument.

**Equality logic:** `return self.func(other)` — a direct delegation.

**Example:**

```py
from dirty_equals import FunctionCheck

def is_even(x):
    return x % 2 == 0

assert 2 == FunctionCheck(is_even)
assert 3 != FunctionCheck(is_even)
```

---

### IsTrueLike

`IsTrueLike` checks truthiness using `bool(other)`. It accepts any value.

**Equality logic:** `return bool(other)`

**Example:**

```py
from dirty_equals import IsTrueLike

assert True == IsTrueLike
assert 1 == IsTrueLike
assert 'true' == IsTrueLike
assert 'foobar' == IsTrueLike   # any non-empty string is "True"
assert '' != IsTrueLike
assert [1] == IsTrueLike
assert {} != IsTrueLike
assert None != IsTrueLike
```

---

### IsFalseLike

`IsFalseLike` checks falsiness using `not bool(other)`, with optional string handling.

**Constructor:** `IsFalseLike(*, allow_strings: bool = False)`

- When `allow_strings=True`, string values are additionally checked case-insensitively against `'false'`, `''`, and any string where `float(other) == 0` (e.g. `'0'`).
- The `allow_strings` flag is passed to the base class as a repr kwarg, using `Omit` when `False` so it is hidden from the repr.

**Equality logic:**

```mermaid
flowchart TD
    A[equals other] --> B{isinstance str and allow_strings?}
    B -->|yes| C[make_string_check other]
    B -->|no| D[return not bool other]
    C --> E{lower in false, empty?}
    E -->|yes| F[return True]
    E -->|no| G{float other == 0?}
    G -->|yes| F
    G -->|no| H[return False]
```

**Example:**

```py
from dirty_equals import IsFalseLike

assert False == IsFalseLike
assert 0 == IsFalseLike
assert 'false' == IsFalseLike(allow_strings=True)
assert '0' == IsFalseLike(allow_strings=True)
assert 'foobar' != IsFalseLike(allow_strings=True)
assert 'false' != IsFalseLike
assert 'True' != IsFalseLike(allow_strings=True)
assert [1] != IsFalseLike
assert {} == IsFalseLike
assert None == IsFalseLike
assert '' == IsFalseLike(allow_strings=True)
assert '' == IsFalseLike
```

---

## Data Flow

All types in this module follow the same comparison lifecycle inherited from [`DirtyEquals`](task43_core.md):

```mermaid
sequenceDiagram
    participant User as Test Code
    participant DE as DirtyEquals.__eq__
    participant Sub as Subclass.equals

    User->>DE: value == IsX(...)
    DE->>DE: store self._other = value
    DE->>Sub: equals(value)
    alt equals returns bool
        Sub-->>DE: True / False
    else equals raises TypeError/ValueError
        Sub--xDE: exception
        DE->>DE: _was_equal = False
    end
    DE-->>User: bool result
```

Key behaviors inherited from the base class:

1. **Exception tolerance** — `TypeError` and `ValueError` raised inside `equals` are swallowed and treated as "not equal". This is why `IsUUID` and `IsJson` can safely call `UUID(...)` / `json.loads(...)` on arbitrary input.
2. **Value capture** — after a successful comparison, the matched value is available via the `.value` property.
3. **Repr behavior** — `repr()` returns the actual matched value when equal (aiding pytest diffs), otherwise a descriptive representation built from the repr args/kwargs.
4. **Composition operators** — `|` (OR), `&` (AND), and `~` (NOT) are inherited, enabling combinations like `IsUUID(4) | IsUUID(5)`.

---

## Component Interaction & Composition

The types in this module are frequently composed with types from sibling modules. The most notable interaction is `IsJson` nesting other dirty-equals types inside its expected value:

```mermaid
graph LR
    JSON[IsJson] -->|expected_value| SD[IsStrictDict]
    JSON -->|expected_value| PI[IsPositiveInt]
    JSON -->|expected_value| ANY["any DirtyEquals type"]
    SD -.->|from| DICT["task43_dict"]
    PI -.->|from| NUM["task43_numeric"]
```

Because `IsJson.equals` compares the parsed JSON with `==`, any nested `DirtyEquals` instance on the right-hand side of that comparison is evaluated through its own `__eq__`. This makes `IsJson` a powerful tool for validating structured API responses.

---

## Dependencies

### Internal Dependencies

| Dependency | Source Module | Used By |
|------------|---------------|---------|
| `DirtyEquals` | [`task43_core`](task43_core.md) | All types in this module |
| `plain_repr` / `PlainRepr` | [`task43_core`](task43_core.md) | `IsUUID`, `IsJson`, `FunctionCheck` |
| `Omit` | [`task43_core`](task43_core.md) | `IsFalseLike` |

### External Dependencies

| Dependency | Used By |
|------------|---------|
| `json` (stdlib) | `IsJson` |
| `uuid.UUID` (stdlib) | `IsUUID` |
| `typing` / `typing_extensions` (`Literal`, `overload`, `TypeVar`) | `IsUUID`, `IsJson` |

---

## Summary

The `task43_other` module rounds out the dirty-equals type library with:

- **`IsUUID`** — UUID validation with optional version constraints.
- **`IsJson`** — JSON parsing and content comparison, composable with other dirty-equals types.
- **`FunctionCheck`** — arbitrary predicate-based equality.
- **`IsTrueLike` / `IsFalseLike`** — truthiness/falsiness checks with optional string handling.

All five types are thin, focused subclasses of [`DirtyEquals`](task43_core.md) that implement only the `equals` method, relying on the core module for comparison lifecycle, exception handling, repr generation, and composition operators. For details on the shared base behavior, see the [task43_core documentation](task43_core.md).
