# Adapter Types Base (`adapter_types_base`)

## Introduction

The `adapter_types_base` module provides the foundational `Type` class that serves as the parent class for all DSPy custom types. It defines the contract that custom types must follow to be properly formatted, serialized, and embedded within LM messages by DSPy adapters.

The module also provides the `split_message_content_for_custom_types` utility, which is responsible for transforming serialized custom-type markers inside user messages into structured content blocks (e.g., OpenAI-style multimodal content parts).

This module is the root of the `adapter_types` family. Concrete custom types such as `Image`, `Audio`, `Code`, `History`, `Tool`, and `ToolCalls` all inherit from `Type` and are documented in their respective modules:

- [adapter_types_media](adapter_types_media.md) — `Image`, `Audio`
- [adapter_types_code](adapter_types_code.md) — `Code`
- [adapter_types_history](adapter_types_history.md) — `History`
- [adapter_types_tool](adapter_types_tool.md) — `Tool`, `ToolCalls`

---

## Core Components

### `Type` (base class)

`Type` is a `pydantic.BaseModel` subclass that acts as the base class for all DSPy custom types. It defines the interface and serialization behavior that adapters rely on.

**Key responsibilities:**

1. **Formatting contract** — Subclasses must implement `format()`, which returns either a list of content-part dictionaries (matching the OpenAI API user message `content` array format) or a plain string.
2. **Description contract** — Subclasses may override `description()` to provide a human-readable description used in prompts.
3. **Custom-type extraction** — `extract_custom_type_from_annotation()` recursively scans a type annotation (including arbitrarily nested generics such as `list[dict[str, Tool]]`) to discover all custom types present.
4. **Serialization** — The `serialize_model` pydantic model serializer wraps the formatted output in reserved sentinel identifiers so that adapters can later locate and split custom-type content.

**Reserved sentinel identifiers:**

```python
CUSTOM_TYPE_START_IDENTIFIER = "<<CUSTOM-TYPE-START-IDENTIFIER>>"
CUSTOM_TYPE_END_IDENTIFIER = "<<CUSTOM-TYPE-END-IDENTIFIER>>"
```

When `format()` returns a list, the serializer wraps it as:

```
<<CUSTOM-TYPE-START-IDENTIFIER>>[{...content parts...}]<<CUSTOM-TYPE-END-IDENTIFIER>>
```

When `format()` returns a string, the string is returned as-is (no sentinels). This allows types like `Code` to bypass the sentinel mechanism entirely by overriding `serialize_model`.

#### Method Reference

| Method | Type | Purpose |
| --- | --- | --- |
| `format()` | instance | Returns `list[dict[str, Any]] \| str`. Must be implemented by subclasses. Raises `NotImplementedError` by default. |
| `description()` | classmethod | Returns a description string for the custom type. Defaults to `""`. |
| `extract_custom_type_from_annotation(annotation)` | classmethod | Recursively extracts all custom types (subclasses of `cls`) from a possibly nested annotation. |
| `serialize_model()` | pydantic serializer | Wraps `format()` output in sentinel identifiers when it is a list. |

#### Example: Defining a Custom Type

```python
class Image(Type):
    url: str

    def format(self) -> list[dict[str, Any]]:
        return [{"type": "image_url", "image_url": {"url": self.url}}]
```

### `split_message_content_for_custom_types`

A module-level utility function that post-processes the messages produced by an adapter. It scans each **user** message's string content for the sentinel-delimited custom-type blocks and replaces them with structured content blocks.

**Behavior:**

- Only processes messages whose `role` is `"user"`.
- Uses a regex (`CUSTOM_TYPE_START_IDENTIFIER(.*?)CUSTOM_TYPE_END_IDENTIFIER`, with `re.DOTALL`) to find custom-type blocks.
- Text before/after each block is emitted as `{"type": "text", "text": ...}` parts.
- The block content is parsed as JSON. It first attempts `json.loads` after replacing single quotes with double quotes; on failure it falls back to `json_repair.loads`; on further failure it falls back to a raw text part.
- If no custom type is found in a message, the message is left unchanged.

**Example transformation:**

Given a user message containing an `Image`, the content is split into:

```python
[
    {"type": "text", "text": "{text_before_image}"},
    {"type": "image_url", "image_url": {"url": "{image_url}"}},
    {"type": "text", "text": "{text_after_image}"},
]
```

---

## Architecture

The `Type` base class sits at the intersection of DSPy signatures, adapters, and LM clients. Adapters format signatures into messages; custom types serialize themselves into sentinel-wrapped content; the splitter then converts those sentinels into structured multimodal content blocks before the messages are sent to the LM.

```mermaid
graph TD
    subgraph "adapter_types_base"
        Type["Type (base class)"]
        Split["split_message_content_for_custom_types"]
    end

    subgraph "Concrete Custom Types"
        Image["Image"]
        Audio["Audio"]
        Code["Code"]
        History["History"]
        Tool["Tool"]
        ToolCalls["ToolCalls"]
    end

    subgraph "Adapters"
        Adapter["Adapter (base)"]
        ChatAdapter["ChatAdapter"]
        JSONAdapter["JSONAdapter"]
    end

    subgraph "Clients"
        LM["LM"]
    end

    Image --> Type
    Audio --> Type
    Code --> Type
    History --> Type
    Tool --> Type
    ToolCalls --> Type

    Adapter --> Split
    ChatAdapter --> Adapter
    JSONAdapter --> Adapter
    Adapter --> LM
    Type -. "serialize_model()" .-> Split
```

---

## Component Relationships

The following diagram shows how the `Type` base class and the splitter interact with the broader adapter pipeline.

```mermaid
classDiagram
    class Type {
        +format() list|str
        +description() str
        +extract_custom_type_from_annotation(annotation) list
        +serialize_model() str
    }

    class Image {
        +url: str
        +format() list
    }
    class Audio {
        +data: str
        +audio_format: str
        +format() list
    }
    class Code {
        +code: str
        +language: str
        +format() str
    }
    class History {
        +messages: list
    }
    class Tool {
        +func: Callable
        +name: str
        +format() str
    }
    class ToolCalls {
        +tool_calls: list
        +format() list
    }

    Type <|-- Image
    Type <|-- Audio
    Type <|-- Code
    Type <|-- History
    Type <|-- Tool
    Type <|-- ToolCalls
```

---

## Data Flow

The end-to-end flow of a custom type from a signature field to an LM-ready message:

```mermaid
sequenceDiagram
    participant Sig as Signature
    participant Adapter as Adapter.format()
    participant Type as Type.serialize_model()
    participant Split as split_message_content_for_custom_types()
    participant LM as LM

    Sig->>Adapter: input fields (may contain custom types)
    Adapter->>Type: format_field_value() invokes format()
    Type-->>Adapter: sentinel-wrapped content string
    Adapter->>Adapter: build messages (system/user/assistant)
    Adapter->>Split: messages with sentinel markers
    Split->>Split: regex match sentinel blocks
    Split->>Split: parse JSON / json_repair
    Split-->>Adapter: messages with structured content blocks
    Adapter->>LM: messages (multimodal content parts)
```

---

## Serialization Process Flow

```mermaid
flowchart TD
    Start([format called on custom type]) --> IsList{format returns list?}
    IsList -->|Yes| Wrap["Wrap in CUSTOM_TYPE_START/END identifiers"]
    IsList -->|No| Raw["Return string as-is"]
    Wrap --> InMessage["Embedded in user message content"]
    Raw --> InMessage
    InMessage --> Split["split_message_content_for_custom_types"]
    Split --> Find{"Sentinel found?"}
    Find -->|No| Unchanged["Message unchanged"]
    Find -->|Yes| Parse["Parse JSON block"]
    Parse --> ParseOK{"Valid JSON?"}
    ParseOK -->|Yes| Emit["Emit content parts"]
    ParseOK -->|No| Repair["json_repair fallback"]
    Repair --> RepairOK{"Repaired?"}
    RepairOK -->|Yes| Emit
    RepairOK -->|No| TextFallback["Emit raw text part"]
    Emit --> Done([Structured content blocks])
    TextFallback --> Done
    Unchanged --> Done
```

---

## Integration with Adapters

The `Type` base class is consumed by the adapter layer. The base `Adapter` class (see [adapters_implementations](adapters_implementations.md)) is responsible for:

- Detecting custom types in signature fields (via `extract_custom_type_from_annotation`).
- Formatting field values, which triggers each custom type's `format()` and `serialize_model()`.
- Calling `split_message_content_for_custom_types` at the end of `Adapter.format()` to convert sentinel markers into structured content blocks.

The `ChatAdapter` and `JSONAdapter` both inherit this behavior. `ChatAdapter` additionally falls back to `JSONAdapter` on parse failures (except for context-window-exceeded errors).

---

## Design Notes

- **Sentinel-based serialization** decouples custom-type formatting from message assembly. Adapters can treat custom types as opaque strings during formatting and defer structural splitting to a single post-processing step.
- **String-returning types** (e.g., `Code`) bypass the sentinel mechanism by overriding `serialize_model`, allowing them to be embedded directly without content-block splitting.
- **Robust JSON parsing** in the splitter (using `json_repair` and a raw-text fallback) ensures that malformed or non-JSON custom-type content does not break message construction.
- **Recursive annotation extraction** supports deeply nested generics, enabling custom types to appear inside containers such as `list[dict[str, Tool]]`.

---

## Related Modules

- [adapters_implementations](adapters_implementations.md) — Adapter base class and concrete adapters that consume custom types.
- [adapter_types_media](adapter_types_media.md) — `Image` and `Audio` custom types.
- [adapter_types_code](adapter_types_code.md) — `Code` custom type.
- [adapter_types_history](adapter_types_history.md) — `History` custom type.
- [adapter_types_tool](adapter_types_tool.md) — `Tool` and `ToolCalls` custom types.
- [signatures](signatures.md) — Signature and field definitions that reference custom types.
- [clients_core](clients_core.md) — LM clients that receive the formatted messages.
