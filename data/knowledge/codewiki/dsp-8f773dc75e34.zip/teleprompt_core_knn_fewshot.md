# KNNFewShot

## Overview

The `KNNFewShot` module provides a DSPy teleprompter (optimizer) that performs **dynamic, test-time few-shot learning** using k-nearest-neighbor retrieval. Unlike static few-shot optimizers that select a fixed set of demonstrations during compilation, `KNNFewShot` retrieves the `k` most similar training examples *at inference time* for each individual input, then bootstraps those examples into the student module's prompts.

This makes it particularly well-suited for tasks where the optimal demonstrations vary significantly depending on the query — for example, question answering over heterogeneous domains, or classification with many distinct categories.

The module is defined in `dspy/teleprompt/knn_fewshot.py` and exposes a single core class: `KNNFewShot`.

---

## Purpose and Core Functionality

`KNNFewShot` combines two complementary mechanisms:

1. **Retrieval (KNN)** — An in-memory k-nearest-neighbor index over the training set, built using an `Embedder` vectorizer. For each input, it finds the `k` most semantically similar training examples.
2. **Bootstrapping (BootstrapFewShot)** — The retrieved neighbors are passed as the `trainset` to a `BootstrapFewShot` optimizer, which generates high-quality demonstrations (including bootstrapped traces) and attaches them to the student module.

The key insight is that the retrieval step is deferred to *forward-call time*: the compiled program re-runs the KNN lookup and re-bootstraps for every new input, producing input-specific demonstrations.

---

## Architecture

`KNNFewShot` is a thin orchestration layer that composes three other components. It inherits from `Teleprompter` and delegates the heavy lifting to `KNN` and `BootstrapFewShot`.

```mermaid
graph TD
    subgraph "teleprompt_core_knn_fewshot"
        KNNFewShot["KNNFewShot<br/>(Teleprompter)"]
    end

    subgraph "predict_advanced_retrieval"
        KNN["KNN"]
    end

    subgraph "teleprompt_core_bootstrap"
        BFS["BootstrapFewShot"]
    end

    subgraph "teleprompt_core_base"
        TP["Teleprompter"]
    end

    subgraph "clients_core_embedder"
        Embedder["Embedder"]
    end

    subgraph "primitives_example"
        Example["Example"]
    end

    KNNFewShot -->|inherits| TP
    KNNFewShot -->|creates & calls| KNN
    KNNFewShot -->|creates & calls| BFS
    KNN -->|uses| Embedder
    KNN -->|returns| Example
    BFS -->|consumes| Example
```

### Component Responsibilities

| Component | Role in `KNNFewShot` |
|-----------|----------------------|
| `KNNFewShot` | Orchestrates retrieval + bootstrapping; overrides the student's `forward` method. |
| [`KNN`](predict_advanced_retrieval.md) | Builds an embedding index over the trainset and retrieves the `k` nearest neighbors for a given input. |
| [`BootstrapFewShot`](teleprompt_core_bootstrap.md) | Generates bootstrapped demonstrations from the retrieved neighbors and attaches them to the student. |
| [`Teleprompter`](teleprompt_core_base.md) | Base class defining the `compile` interface. |
| [`Embedder`](clients_core_embedder.md) | Computes vector representations of text for similarity search. |
| [`Example`](primitives_example.md) | The data primitive representing training examples and demonstrations. |

---

## Class Reference

### `KNNFewShot`

```python
class KNNFewShot(Teleprompter):
    def __init__(
        self,
        k: int,
        trainset: list[Example],
        vectorizer: Embedder,
        **few_shot_bootstrap_args: dict[str, Any],
    ):
```

#### Constructor Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `k` | `int` | Number of nearest neighbors to retrieve and attach as demonstrations. |
| `trainset` | `list[Example]` | The training set used for few-shot prompting and retrieval. |
| `vectorizer` | `Embedder` | The embedder used to vectorize both the trainset and incoming inputs. |
| `**few_shot_bootstrap_args` | `dict[str, Any]` | Forwarded to `BootstrapFewShot` (e.g. `metric`, `max_bootstrapped_demos`, `max_labeled_demos`, `max_rounds`). |

During construction, the trainset is immediately vectorized and indexed by an internal `KNN` instance:

```python
self.KNN = KNN(k, trainset, vectorizer=vectorizer)
self.few_shot_bootstrap_args = few_shot_bootstrap_args
```

#### `compile(student, *, teacher=None)`

The `compile` method returns a *copy* of the student whose `forward` method has been replaced with a dynamic retrieval-and-bootstrap routine.

```python
def compile(self, student, *, teacher=None):
    student_copy = student.reset_copy()

    def forward_pass(_, **kwargs):
        knn_trainset = self.KNN(**kwargs)
        few_shot_bootstrap = BootstrapFewShot(**self.few_shot_bootstrap_args)
        compiled_program = few_shot_bootstrap.compile(
            student,
            teacher=teacher,
            trainset=knn_trainset,
        )
        return compiled_program(**kwargs)

    student_copy.forward = types.MethodType(forward_pass, student_copy)
    return student_copy
```

Key behaviors:

- **`student.reset_copy()`** — Produces a fresh, uncompiled copy of the student so the original is not mutated.
- **Per-call retrieval** — On every forward call, `self.KNN(**kwargs)` retrieves the `k` nearest neighbors for the current input.
- **Per-call bootstrapping** — A new `BootstrapFewShot` is instantiated and compiled against the retrieved neighbors, then invoked with the original input.
- **Method binding** — The custom `forward_pass` is bound to the student copy via `types.MethodType`, effectively turning the compiled module into a retrieval-augmented program.

---

## Data Flow

The following diagram illustrates the end-to-end flow from compilation through a single inference call.

```mermaid
sequenceDiagram
    participant User
    participant KNNFewShot
    participant KNN
    participant Embedder
    participant BootstrapFewShot
    participant Student

    Note over KNNFewShot,KNN: Construction time
    User->>KNNFewShot: __init__(k, trainset, vectorizer)
    KNNFewShot->>KNN: KNN(k, trainset, vectorizer)
    KNN->>Embedder: embed(trainset inputs)
    Embedder-->>KNN: trainset_vectors
    Note over KNN: Index built in memory

    Note over KNNFewShot,Student: Compile time
    User->>KNNFewShot: compile(student, teacher)
    KNNFewShot->>Student: reset_copy()
    KNNFewShot->>Student: bind forward_pass
    KNNFewShot-->>User: compiled student_copy

    Note over User,Student: Inference time (per call)
    User->>Student: __call__(**kwargs)
    Student->>KNN: __call__(**kwargs)
    KNN->>Embedder: embed(input)
    Embedder-->>KNN: input_vector
    KNN-->>Student: k nearest Examples
    Student->>BootstrapFewShot: compile(student, trainset=knn_trainset)
    BootstrapFewShot-->>Student: compiled_program
    Student->>Student: compiled_program(**kwargs)
    Student-->>User: Prediction
```

### Step-by-step

1. **Construction** — The trainset is vectorized once and stored as a matrix of embeddings inside `KNN`.
2. **Compilation** — `compile` returns a copy of the student with a patched `forward` method. No retrieval or bootstrapping happens yet.
3. **Inference** — Each call to the compiled module:
   - Vectorizes the input and computes cosine-style similarity (dot product) against the trainset vectors.
   - Selects the top-`k` indices.
   - Bootstraps a fresh program using those neighbors as the trainset.
   - Executes the bootstrapped program on the original input.

---

## Process Flow: Retrieval and Bootstrapping

```mermaid
flowchart TD
    A[Input kwargs] --> B[Vectorize input via Embedder]
    B --> C[Compute dot product with trainset vectors]
    C --> D[Argsort scores, take top-k]
    D --> E[k nearest Examples]
    E --> F[Instantiate BootstrapFewShot]
    F --> G[Compile student with knn_trainset]
    G --> H[Run compiled program on input]
    H --> I[Return Prediction]
```

---

## Dependencies

```mermaid
graph LR
    KNNFewShot --> types["types (stdlib)"]
    KNNFewShot --> typing["typing (stdlib)"]
    KNNFewShot --> Embedder
    KNNFewShot --> KNN
    KNNFewShot --> Example
    KNNFewShot --> BootstrapFewShot
    KNNFewShot --> Teleprompter
```

| Dependency | Source | Purpose |
|------------|--------|---------|
| `types` | stdlib | Binds `forward_pass` as a method on the student copy. |
| `typing.Any` | stdlib | Type hints for bootstrap args. |
| [`Embedder`](clients_core_embedder.md) | `dspy.clients` | Vectorization of trainset and inputs. |
| [`KNN`](predict_advanced_retrieval.md) | `dspy.predict.knn` | Nearest-neighbor retrieval. |
| [`Example`](primitives_example.md) | `dspy.primitives` | Training example primitive. |
| [`BootstrapFewShot`](teleprompt_core_bootstrap.md) | `dspy.teleprompt` | Demonstration bootstrapping. |
| [`Teleprompter`](teleprompt_core_base.md) | `dspy.teleprompt.teleprompt` | Base optimizer interface. |

---

## Usage Example

```python
import dspy
from sentence_transformers import SentenceTransformer

# Define a QA module with chain of thought
qa = dspy.ChainOfThought("question -> answer")

# Create a training dataset with examples
trainset = [
    dspy.Example(question="What is the capital of France?", answer="Paris").with_inputs("question"),
    # ... more examples ...
]

# Initialize KNNFewShot with a sentence transformer model
knn_few_shot = dspy.KNNFewShot(
    k=3,
    trainset=trainset,
    vectorizer=dspy.Embedder(SentenceTransformer("all-MiniLM-L6-v2").encode),
)

# Compile the QA module with few-shot learning
compiled_qa = knn_few_shot.compile(qa)

# Use the compiled module
result = compiled_qa("What is the capital of Belgium?")
```

---

## Design Considerations

- **Cost vs. quality trade-off** — Because retrieval and bootstrapping run on *every* forward call, `KNNFewShot` is more expensive at inference time than static few-shot optimizers. It trades compute for input-specific demonstration quality.
- **Embedding quality matters** — The relevance of retrieved neighbors depends entirely on the `Embedder`. A domain-appropriate embedding model yields better demonstrations.
- **Trainset vectorization is one-time** — The trainset is embedded once during construction, so repeated inference calls only pay the cost of embedding the single input.
- **Bootstrap arguments are reused** — The same `few_shot_bootstrap_args` are applied on every call, so metrics and demo limits remain consistent across inputs.

---

## Related Modules

- [predict_advanced_retrieval](predict_advanced_retrieval.md) — `KNN` retriever and other retrieval-based predictors.
- [teleprompt_core_bootstrap](teleprompt_core_bootstrap.md) — `BootstrapFewShot` optimizer used internally.
- [teleprompt_core_base](teleprompt_core_base.md) — `Teleprompter` base class.
- [clients_core_embedder](clients_core_embedder.md) — `Embedder` for vectorization.
- [primitives_example](primitives_example.md) — `Example` data primitive.
- [teleprompt_core_labeled_fewshot](teleprompt_core_labeled_fewshot.md) — `LabeledFewShot`, a static alternative used by `BootstrapFewShot`.
