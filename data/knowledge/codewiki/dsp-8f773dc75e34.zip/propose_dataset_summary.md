# Propose Dataset Summary

## Introduction

The **Propose Dataset Summary** module (`dspy/propose/dataset_summary_generator.py`) is responsible for automatically generating a concise, human-readable summary of a training dataset. This summary captures the most salient trends, topics, and characteristics of the data, and is used downstream to inform instruction generation for prompt optimization.

The module answers the question: *"What is this dataset about, and what task does it enable?"* — without requiring a human to manually inspect the data. It does so by iteratively prompting a language model to produce observations about batches of examples, then condensing those observations into a short summary.

This module is a supporting component of the broader [propose](propose_grounded.md) subsystem, and its output is consumed by the `GroundedProposer` to make instruction proposals *data-aware*.

---

## Purpose and Core Functionality

The module provides three core capabilities:

1. **Observation generation** — Given a batch of dataset examples, produce observations about trends that hold across most or all samples.
2. **Iterative refinement** — Given prior observations plus a new batch, either add new observations or declare the observations `COMPLETE`.
3. **Summarization** — Condense the accumulated observations into a brief 2–3 sentence summary.

These capabilities are exposed through three DSPy `Signature` classes and a top-level orchestration function, `create_dataset_summary`.

---

## Architecture

The module is built on top of DSPy's signature/predict abstraction. Each signature defines a prompt template and input/output fields, and is executed via `dspy.Predict`.

```mermaid
graph TD
    subgraph "propose_dataset_summary"
        CDS["create_dataset_summary()"]
        DD["DatasetDescriptor<br/>(Signature)"]
        DDPO["DatasetDescriptorWithPriorObservations<br/>(Signature)"]
        OS["ObservationSummarizer<br/>(Signature)"]
        OIK["order_input_keys_in_string()"]
    end

    subgraph "External Dependencies"
        PRED["dspy.Predict"]
        SET["dspy.settings.context"]
        SP["strip_prefix()<br/>(propose/utils.py)"]
    end

    CDS --> DD
    CDS --> DDPO
    CDS --> OS
    CDS --> OIK
    CDS --> PRED
    CDS --> SET
    CDS --> SP

    DD -.executed by.-> PRED
    DDPO -.executed by.-> PRED
    OS -.executed by.-> PRED
```

### Component Overview

| Component | Type | Responsibility |
|-----------|------|----------------|
| `DatasetDescriptor` | `dspy.Signature` | Generates initial observations from a batch of examples. |
| `DatasetDescriptorWithPriorObservations` | `dspy.Signature` | Extends prior observations with new ones, or signals `COMPLETE`. |
| `ObservationSummarizer` | `dspy.Signature` | Condenses accumulated observations into a 2–3 sentence summary. |
| `order_input_keys_in_string` | Helper function | Normalizes the string representation of examples for stable prompting. |
| `create_dataset_summary` | Orchestration function | Drives the full observation → refinement → summary pipeline. |

---

## Component Details

### `DatasetDescriptor` (Signature)

Defines the prompt for generating observations from a fresh batch of examples.

- **Inputs:**
  - `examples` — Sample data points from the dataset.
- **Outputs:**
  - `observations` — Statements that hold true for most or all of the observed data.

The prompt encourages the model to consider topics, content, syntax, and conciseness, and to make an educated guess about the nature of the task the dataset enables.

### `DatasetDescriptorWithPriorObservations` (Signature)

An extension of `DatasetDescriptor` that accepts previously generated observations, enabling incremental refinement.

- **Inputs:**
  - `examples` — A new batch of sample data points.
  - `prior_observations` — Observations already made about the data.
- **Outputs:**
  - `observations` — New observations, or the literal string `COMPLETE` if nothing remains to add.

### `ObservationSummarizer` (Signature)

Condenses the full set of accumulated observations into a short summary.

- **Inputs:**
  - `observations` — All observations made about the dataset.
- **Outputs:**
  - `summary` — A 2–3 sentence summary highlighting only the most significant details.

### `order_input_keys_in_string` (Helper)

A regex-based utility that finds `input_keys={...}` structures within a string representation of examples and sorts the keys alphabetically. This ensures deterministic, stable prompt content regardless of the order in which keys were defined, improving reproducibility of the generated summary.

### `create_dataset_summary` (Orchestration Function)

The main entry point. Its signature is:

```python
def create_dataset_summary(
    trainset,
    view_data_batch_size,
    prompt_model,
    log_file=None,
    verbose=False,
) -> str
```

It returns the final summary string (with any leading label prefix stripped via `strip_prefix`).

---

## Process Flow

The following diagram illustrates the iterative pipeline executed by `create_dataset_summary`.

```mermaid
flowchart TD
    START([Start]) --> INIT["Determine upper_lim = min(len(trainset), view_data_batch_size)"]
    INIT --> RESOLVE["Resolve prompt_model<br/>(fallback to dspy.settings.lm)"]
    RESOLVE --> FIRST["Predict DatasetDescriptor<br/>on trainset[0:upper_lim]"]
    FIRST --> OBS["observations = output['observations']"]
    OBS --> LOOP{"More batches?<br/>b < len(trainset)<br/>and calls < max_calls(10)"}

    LOOP -- Yes --> BATCH["Predict DatasetDescriptorWithPriorObservations<br/>on trainset[b:upper_lim]"]
    BATCH --> CHECK{"observations start<br/>with 'COMPLETE'?"}
    CHECK -- Yes --> SKIP["skips += 1"]
    SKIP --> SKIPCHK{"skips >= 5?"}
    SKIPCHK -- Yes --> SUMMARY
    SKIPCHK -- No --> LOOP
    CHECK -- No --> APPEND["observations += new observations"]
    APPEND --> LOOP

    LOOP -- No --> SUMMARY["Predict ObservationSummarizer<br/>on accumulated observations"]
    SUMMARY --> STRIP["strip_prefix(summary.summary)"]
    STRIP --> END([Return summary string])

    BATCH -. exception .-> CATCH["Log error, reuse<br/>past observations"]
    CATCH --> SUMMARY
```

### Key Control-Flow Behaviors

- **Batching:** The dataset is processed in chunks of `view_data_batch_size`. The first chunk seeds the initial observations; subsequent chunks refine them.
- **Early termination via `COMPLETE`:** If the model responds with `COMPLETE` (case-insensitive, first 8 characters), the batch is skipped. After **5 consecutive** `COMPLETE` responses, the loop terminates early.
- **Call cap:** A hard limit of `max_calls = 10` batches prevents runaway LLM usage on very large datasets.
- **Fault tolerance:** If any batch prediction raises an exception, the pipeline catches it and proceeds to summarization using whatever observations have been accumulated so far.
- **Model context:** All predictions run inside `dspy.settings.context(lm=prompt_model)` to ensure the correct LM is used, with `n=1` and `temperature=1.0` for diversity.

---

## Data Flow

```mermaid
sequenceDiagram
    participant Caller as Caller (GroundedProposer)
    participant CDS as create_dataset_summary
    participant LM as prompt_model (LM)
    participant Log as log_file

    Caller->>CDS: trainset, batch_size, prompt_model
    CDS->>LM: DatasetDescriptor(examples=batch_0)
    LM-->>CDS: observations
    CDS->>Log: "PRODUCING DATASET SUMMARY"

    loop For each subsequent batch (max 10)
        CDS->>LM: DatasetDescriptorWithPriorObservations(examples, prior_observations)
        LM-->>CDS: new observations OR "COMPLETE"
        CDS->>Log: observations
    end

    CDS->>LM: ObservationSummarizer(observations)
    LM-->>CDS: summary
    CDS->>Log: summary
    CDS-->>Caller: strip_prefix(summary)
```

---

## Integration with the Propose Subsystem

The dataset summary is a key input to the **GroundedProposer**, which uses it to generate *data-aware* instructions. The relationship is shown below.

```mermaid
graph LR
    subgraph "propose_dataset_summary"
        CDS["create_dataset_summary()"]
    end

    subgraph "propose_grounded"
        GP["GroundedProposer.__init__()"]
        GMI["GenerateModuleInstruction"]
    end

    subgraph "propose_base"
        PB["Proposer (ABC)"]
    end

    PB --> GP
    GP -->|"use_dataset_summary=True"| CDS
    CDS -->|"data_summary string"| GP
    GP -->|"data_summary"| GMI
```

### How It Is Used

In `GroundedProposer.__init__`, when `use_dataset_summary=True`, the proposer calls:

```python
self.data_summary = create_dataset_summary(
    trainset=trainset,
    view_data_batch_size=view_data_batch_size,
    prompt_model=prompt_model,
)
```

The resulting `data_summary` string is later passed into `GenerateModuleInstruction` during instruction proposal. If summary generation fails, the proposer gracefully degrades by setting `use_dataset_summary = False` and continuing without data awareness.

For more details on how the summary feeds into instruction generation, see the [propose_grounded](propose_grounded.md) documentation.

---

## Dependencies

| Dependency | Source | Purpose |
|------------|--------|---------|
| `dspy.Signature` | [signatures](signatures.md) | Base class for the three prompt signatures. |
| `dspy.Predict` | [predict_core](predict_core.md) | Executes signatures against the LM. |
| `dspy.settings.context` | [dsp_utils](dsp_utils.md) | Scopes the LM used for predictions. |
| `strip_prefix` | `dspy/propose/utils.py` | Removes leading label prefixes (e.g., `"summary:"`) from model output. |
| `re` | Python stdlib | Regex used by `order_input_keys_in_string`. |

---

## Error Handling and Robustness

The module is designed to be resilient in the face of LLM failures:

- **Batch-level exceptions** are caught and logged; the pipeline falls back to previously accumulated observations.
- **`COMPLETE` detection** prevents redundant LLM calls once the model has nothing new to add.
- **Call capping** (`max_calls = 10`) bounds cost and latency on large datasets.
- **Graceful degradation** at the integration layer: `GroundedProposer` disables dataset summarization if this module raises.

---

## Summary

The `propose_dataset_summary` module provides an automated, LLM-driven mechanism for characterizing a training dataset. Through an iterative observe-then-refine loop followed by a final summarization step, it produces a compact textual summary that makes downstream instruction proposal *data-aware*. Its design emphasizes robustness (fault tolerance, early termination, call caps) and reproducibility (deterministic key ordering), and it integrates cleanly with the [propose_grounded](propose_grounded.md) subsystem.
