# DSP Retrieval Module

## Introduction

The `dsp_retrieval` module provides the low-level retrieval and text-processing primitives used by DSPy's retrieval-augmented pipelines. It contains two distinct concerns:

1. **ColBERTv2 retrieval backends** — wrappers around the ColBERTv2 late-interaction retrieval model, supporting both a remote HTTP server and a fully local index build/search/rerank workflow.
2. **DPR tokenization utilities** — a lightweight, dependency-free tokenizer and text-normalization toolkit derived from Facebook Research's Dense Passage Retrieval (DPR) implementation, used for answer matching and passage processing.

These primitives are consumed by higher-level retrieval abstractions such as the [`Retrieve`](retrievers.md) module and the [`Settings`](dsp_utils.md) runtime configuration, which wires a retrieval model (`dspy.settings.rm`) into the pipeline.

## Purpose and Core Functionality

| Concern | Responsibility |
| --- | --- |
| Remote retrieval | Query a hosted ColBERTv2 server over HTTP (GET or POST) and return ranked passages. |
| Local retrieval | Build a ColBERT index from a passage collection, search it, and optionally filter by passage IDs. |
| Local reranking | Score a set of candidate passages against a query using a ColBERT model checkpoint. |
| Tokenization | Split text into tokens with whitespace/offset metadata for downstream matching. |
| Answer matching | Locate and verify answer spans within passages using normalized token comparison. |

## Architecture Overview

The module is organized into two sub-modules that operate at different layers of the retrieval stack:

```mermaid
graph TD
    subgraph dsp_retrieval["dsp_retrieval"]
        subgraph colbert["ColBERTv2 Retrieval"]
            CB2["ColBERTv2<br/>(remote HTTP)"]
            CBL["ColBERTv2RetrieverLocal<br/>(local index)"]
            CBR["ColBERTv2RerankerLocal<br/>(local rerank)"]
        end
        subgraph dpr["DPR Tokenization"]
            TOK["Tokenizer / SimpleTokenizer"]
            TOKS["Tokens"]
            MATCH["has_answer / locate_answers"]
        end
    end

    CB2 -->|HTTP GET/POST| SERVER["ColBERTv2 Server"]
    CBL -->|build/search| INDEX["ColBERT Index"]
    CBR -->|score| MODEL["ColBERT Checkpoint"]
    TOK --> TOKS
    TOKS --> MATCH

    CB2 -.->|request_cache| CACHE["Cache"]
    CBL -.->|dotdict| UTILS["dotdict"]
    CBR -.->|dotdict| UTILS
```

### Data Flow

```mermaid
sequenceDiagram
    participant Caller
    participant ColBERTv2
    participant Cache
    participant Server

    Caller->>ColBERTv2: __call__(query, k)
    alt post_requests
        ColBERTv2->>Cache: colbertv2_post_request(url, query, k)
    else
        ColBERTv2->>Cache: colbertv2_get_request(url, query, k)
    end
    Cache->>Server: HTTP request (on miss)
    Server-->>Cache: topk passages
    Cache-->>ColBERTv2: topk passages
    ColBERTv2-->>Caller: list[dotdict] or list[str]
```

## Sub-modules

### ColBERTv2 Retrieval

The ColBERTv2 retrieval sub-module wraps the ColBERTv2 late-interaction model in three complementary classes:

- **`ColBERTv2`** — a thin client for a hosted ColBERTv2 HTTP server. Supports GET and POST request modes, optional result simplification, and transparent request caching.
- **`ColBERTv2RetrieverLocal`** — builds and searches a local ColBERT index over a provided passage collection, with support for filtering results by passage IDs.
- **`ColBERTv2RerankerLocal`** — reranks a candidate list of passages against a query using a ColBERT checkpoint, returning per-passage scores.

See [dsp_retrieval_colbertv2.md](dsp_retrieval_colbertv2.md) for full details.

### DPR Tokenization

The DPR tokenization sub-module provides a self-contained tokenizer and text-matching toolkit:

- **`Tokenizer` / `SimpleTokenizer`** — base and concrete tokenizers that split text into tokens while preserving whitespace and character offsets.
- **`Tokens`** — a container for tokenized text exposing words, offsets, n-grams, POS/lemma/NER annotations, and entity grouping.
- **`has_answer` / `locate_answers`** — utilities for verifying and locating answer spans within passages using normalized token comparison.

See [dsp_retrieval_dpr.md](dsp_retrieval_dpr.md) for full details.

## Integration with the Broader System

The `dsp_retrieval` module sits at the bottom of DSPy's retrieval stack. It does not depend on the higher-level prediction or optimization machinery; instead, it is consumed by them:

```mermaid
graph LR
    subgraph Higher["Higher-level modules"]
        RET["retrievers<br/>(Retrieve, Embeddings)"]
        SET["dsp_utils<br/>(Settings)"]
    end
    subgraph Lower["dsp_retrieval"]
        CB["ColBERTv2"]
        DPR["DPR Tokenizer"]
    end
    subgraph Infra["Infrastructure"]
        CACHE["clients_core<br/>(Cache)"]
        UTILS["dsp_utils<br/>(dotdict)"]
    end

    RET -->|uses rm| CB
    SET -->|configures rm| CB
    CB --> CACHE
    CB --> UTILS
    DPR --> UTILS
```

- **`dspy.clients.cache.Cache`** — the `@request_cache()` decorator wraps the ColBERTv2 HTTP request functions, providing two-level (memory + disk) caching. See [clients_core.md](clients_core.md).
- **`dspy.dsp.utils.dotdict`** — used to return passages as attribute-accessible dictionaries. See [dsp_utils.md](dsp_utils.md).
- **`dspy.retrievers.retrieve.Retrieve`** — the high-level retrieval parameter that delegates to `dspy.settings.rm`, which is typically a `ColBERTv2` instance. See [retrievers.md](retrievers.md).

## Key Design Notes

- **Caching is transparent.** All remote ColBERTv2 request functions are decorated with `@request_cache()`, so repeated identical queries avoid network round-trips.
- **Local vs. remote parity.** Both `ColBERTv2` and `ColBERTv2RetrieverLocal` return passages as `dotdict` objects with a `long_text` field, allowing downstream code to treat them uniformly.
- **Optional heavy dependencies.** The local retriever and reranker import `colbert`, `torch`, and `numpy` lazily, so the remote client can be used without installing the full ColBERT stack.
- **DPR tokenizer is dependency-light.** It relies only on `regex` and `unicodedata`, making it suitable for lightweight answer-matching tasks.
