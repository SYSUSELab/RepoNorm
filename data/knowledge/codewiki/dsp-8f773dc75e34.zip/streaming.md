# Streaming

## Overview

The **Streaming** module provides incremental, real-time output delivery for DSPy programs. Instead of waiting for a program to finish and returning a complete `Prediction`, streaming lets consumers observe:

- **Field-level token chunks** — the partial text of specific output fields (e.g. `answer`, `reasoning`) as the language model generates them.
- **Status messages** — human-readable progress updates emitted around tool calls, module execution, and LM calls.
- **The final prediction** — the fully parsed `Prediction` object, optionally included at the end of the stream.

The module is built around the `dspy.streamify()` wrapper, which turns any DSPy program into a function returning an async (or sync) generator of streamed values. It integrates tightly with the [adapters](adapters.md) layer (to know how fields are delimited in the raw LM output) and the [clients](clients_core.md) layer (which produces the raw `ModelResponseStream` chunks).

## Architecture

The streaming subsystem is composed of three cooperating layers:

1. **`streamify` orchestration** (`dspy/streaming/streamify.py`) — wraps a program, sets up an in-memory stream, and dispatches incoming values to listeners or directly to the consumer.
2. **Stream listeners** (`dspy/streaming/streaming_listener.py`) — parse the raw LM token stream to extract the content of a specific output field. See [streaming_listener.md](streaming_listener.md).
3. **Status messages** (`dspy/streaming/messages.py`) — a callback-driven mechanism that emits progress messages. See [streaming_messages.md](streaming_messages.md).

```mermaid
graph TD
    User["User code<br/>async for value in program(...)"]
    Streamify["streamify()<br/>dspy/streaming/streamify.py"]
    Program["Wrapped DSPy Program<br/>(Module / Predict)"]
    LM["dspy.LM<br/>dspy/clients/lm.py"]
    Adapter["Adapter<br/>ChatAdapter / JSONAdapter / XMLAdapter"]
    SendStream["MemoryObjectSendStream<br/>(settings.send_stream)"]
    Listener["StreamListener<br/>streaming_listener.py"]
    StatusCb["StatusStreamingCallback<br/>messages.py"]
    Provider["StatusMessageProvider<br/>messages.py"]

    User --> Streamify
    Streamify --> Program
    Program --> LM
    Program --> Adapter
    LM -->|ModelResponseStream chunks| SendStream
    Adapter -.->|field delimiters| Listener
    StatusCb -->|StatusMessage| SendStream
    Provider -.->|custom messages| StatusCb
    SendStream --> Streamify
    Streamify -->|StreamResponse / StatusMessage / Prediction| User
    Streamify --> Listener
```

### Data Flow

```mermaid
sequenceDiagram
    participant U as User
    participant S as streamify
    participant P as Program
    participant LM as dspy.LM
    participant L as StreamListener
    participant C as StatusStreamingCallback

    U->>S: program(args, kwargs)
    S->>P: await program(...)  (in task group)
    P->>C: on_module_start / on_lm_start
    C-->>S: StatusMessage (via send_stream)
    P->>LM: completion request (stream=True)
    loop each token chunk
        LM-->>S: ModelResponseStream
        S->>L: listener.receive(chunk)
        L-->>S: StreamResponse (when inside target field)
    end
    P->>C: on_lm_end / on_module_end
    C-->>S: StatusMessage
    P-->>S: Prediction
    S-->>U: yields StreamResponse / StatusMessage / Prediction
```

## Core Components

### `streamify()` — the entry point

`dspy.streaming.streamify(program, ...)` is the primary public API. It:

- Optionally resolves which predictor each `StreamListener` targets via `find_predictor_for_stream_listeners`.
- Wraps the program with `asyncify` (sync programs) or uses `acall` (async programs).
- Registers a `StatusStreamingCallback` into the active callbacks so status messages flow into the stream.
- Runs the program inside an `anyio` task group, feeding a `MemoryObjectSendStream` that the LM and callbacks write to.
- Dispatches each received value:
  - `ModelResponseStream` → routed to the matching `StreamListener`(s) by `predict_id`.
  - `StatusMessage` → yielded directly.
  - `Prediction` → yielded (subject to `include_final_prediction_in_output_stream`) and terminates the stream.

Key parameters:

| Parameter | Purpose |
|-----------|---------|
| `status_message_provider` | Custom `StatusMessageProvider` for progress messages. |
| `stream_listeners` | List of `StreamListener` objects selecting which fields to stream. |
| `include_final_prediction_in_output_stream` | Whether to emit the final `Prediction`. |
| `is_async_program` | Whether the wrapped program is async. |
| `async_streaming` | Return an async generator (`True`) or a sync generator (`False`). |

### Sync streaming adapter

`apply_sync_streaming(async_generator)` converts the async generator into a synchronous generator by running the async producer in a background thread and buffering items through a `queue.Queue`. This enables use in synchronous contexts (e.g. notebooks, Flask handlers).

### OpenAI-compatible response formatting

`streaming_response(streamer)` transforms the DSPy output stream into Server-Sent-Events (SSE) chunks compatible with OpenAI-style streaming APIs, emitting `data: {...}\n\n` lines and terminating with `data: [DONE]\n\n`. It handles `Prediction`, `litellm.ModelResponseStream`, and pre-formatted `data:` strings.

## Sub-modules

### Stream Listener

The `StreamListener` class captures the streaming output of a specific output field of a predictor. It understands the field delimiters used by each supported adapter (`ChatAdapter`, `JSONAdapter`, `XMLAdapter`) and buffers tokens to detect field start/end boundaries, emitting `StreamResponse` objects for the field's content.

→ See [streaming_listener.md](streaming_listener.md) for full details.

### Status Messages

The status-message subsystem provides `StatusMessage`, `StatusMessageProvider`, `StatusStreamingCallback`, and `StreamResponse`. It lets users customize progress messages emitted around tool, module, and LM lifecycle events, and delivers them into the stream via a callback.

→ See [streaming_messages.md](streaming_messages.md) for full details.

## Integration Points

- **[adapters](adapters.md)** — `StreamListener` relies on adapter-specific field delimiters (`[[ ## field ## ]]` for `ChatAdapter`, `"field":` for `JSONAdapter`, `<field>` for `XMLAdapter`). Only `ChatAdapter`, `XMLAdapter`, and `JSONAdapter` support streaming.
- **[clients_core](clients_core.md)** — `dspy.LM` produces the raw `ModelResponseStream` chunks that flow into `settings.send_stream`.
- **[utils](utils.md)** — `StatusStreamingCallback` extends `BaseCallback`; `settings.send_stream` and `settings.stream_listeners` are read from the global `Settings` singleton.
- **[primitives](primitives.md)** — the final `Prediction` object is yielded at the end of the stream.

## Usage Example

```python
import asyncio
import dspy

dspy.settings.configure(lm=dspy.LM("openai/gpt-4o-mini", cache=False))

predict = dspy.Predict("question->answer, reasoning")
stream_listeners = [
    dspy.streaming.StreamListener(signature_field_name="answer"),
    dspy.streaming.StreamListener(signature_field_name="reasoning"),
]
stream_predict = dspy.streamify(predict, stream_listeners=stream_listeners)

async def main():
    output = stream_predict(question="why did a chicken cross the kitchen?")
    async for value in output:
        if isinstance(value, dspy.Prediction):
            print("FINAL:", value)
        else:
            print(value)  # StreamResponse or StatusMessage

asyncio.run(main())
```

## Public API Summary

| Symbol | Source | Description |
|--------|--------|-------------|
| `streamify` | `streamify.py` | Wrap a program for incremental streaming. |
| `apply_sync_streaming` | `streamify.py` | Convert async stream to sync generator. |
| `streaming_response` | `streamify.py` | Format stream as OpenAI-compatible SSE. |
| `StreamListener` | `streaming_listener.py` | Capture a specific output field's tokens. |
| `StreamResponse` | `messages.py` | Dataclass for a streamed field chunk. |
| `StatusMessage` | `messages.py` | Dataclass wrapping a status message. |
| `StatusMessageProvider` | `messages.py` | Base class for custom status messages. |
| `StatusStreamingCallback` | `messages.py` | Callback that emits status messages. |
