# Teleprompt Optimizers

## Overview

The **Teleprompt Optimizers** module (`dspy/teleprompt/`) provides a collection of advanced optimization algorithms ("teleprompters") that automatically improve DSPy programs. Unlike the simpler optimizers in [teleprompt_core](teleprompt_core.md), these optimizers employ sophisticated search strategies — Bayesian optimization, stochastic mini-batch ascent, instruction induction, and rule inference — to jointly optimize a program's **instructions** (natural-language prompts) and **few-shot demonstrations**.

All optimizers in this module inherit from the base `Teleprompter` class (see [teleprompt_core](teleprompt_core.md)) and expose a common `compile(student, *, trainset, ...)` interface that returns an optimized copy of the input program.

### Purpose

- **Instruction optimization**: Rewrite the natural-language instructions of each predictor to improve task performance.
- **Demonstration optimization**: Select or bootstrap the best few-shot examples for each predictor.
- **Joint optimization**: Search over combinations of instructions and demonstrations to find the best-performing configuration.
- **Rule induction**: Derive explicit natural-language rules from training examples and inject them into prompts.

## Architecture

The module is organized around a shared base class and a set of optimization strategies. The following diagram shows the main components and their relationships:

```mermaid
graph TD
    Teleprompter["Teleprompter (base)"]
    COPRO["COPRO"]
    MIPROv2["MIPROv2"]
    SIMBA["SIMBA"]
    SignatureOptimizer["SignatureOptimizer (deprecated)"]
    BootstrapFewShotWithOptuna["BootstrapFewShotWithOptuna"]
    InferRules["InferRules"]

    Teleprompter --> COPRO
    Teleprompter --> MIPROv2
    Teleprompter --> SIMBA
    Teleprompter --> BootstrapFewShotWithOptuna
    COPRO --> SignatureOptimizer
    BootstrapFewShot --> InferRules

    MIPROv2 -.uses.-> GroundedProposer["GroundedProposer (propose)"]
    MIPROv2 -.uses.-> Optuna["Optuna (Bayesian search)"]
    BootstrapFewShotWithOptuna -.uses.-> BootstrapFewShot["BootstrapFewShot (core)"]
    BootstrapFewShotWithOptuna -.uses.-> Optuna
    InferRules -.extends.-> BootstrapFewShot
    SIMBA -.uses.-> SIMBAUtils["simba_utils"]
```

### Shared Optimization Pipeline

Most optimizers follow a common high-level pipeline, illustrated below:

```mermaid
flowchart LR
    A[Student Program] --> B[Generate Candidates]
    B --> C[Evaluate Candidates]
    C --> D[Select Best]
    D --> E[Optimized Program]
    B -.instructions.-> B
    B -.demos.-> B
```

## Sub-Modules

The module is decomposed into the following sub-modules, each documented separately:

| Sub-Module | Description | Documentation |
| --- | --- | --- |
| **Instruction Optimizers** | `COPRO` and its deprecated alias `SignatureOptimizer` — iterative instruction proposal and refinement. | [teleprompt_optimizers_instruction.md](teleprompt_optimizers_instruction.md) |
| **Bayesian Optimizers** | `MIPROv2` and `BootstrapFewShotWithOptuna` — Bayesian search over instructions and demos. | [teleprompt_optimizers_bayesian.md](teleprompt_optimizers_bayesian.md) |
| **SIMBA** | `SIMBA` and its utilities — stochastic introspective mini-batch ascent. | [teleprompt_optimizers_simba.md](teleprompt_optimizers_simba.md) |
| **Rule Induction** | `InferRules` and `RulesInductionProgram` — natural-language rule induction. | [teleprompt_optimizers_rules.md](teleprompt_optimizers_rules.md) |

## Component Interaction

The following diagram shows how the optimizers interact with the broader DSPy ecosystem:

```mermaid
graph LR
    subgraph Optimizers
        COPRO
        MIPROv2
        SIMBA
        InferRules
        BootstrapFewShotWithOptuna
    end

    subgraph Core
        Teleprompter
        BootstrapFewShot
        LabeledFewShot
    end

    subgraph Evaluation
        Evaluate["Evaluate (evaluate)"]
    end

    subgraph Proposal
        GroundedProposer
    end

    subgraph Primitives
        Module["Module / Predict"]
        Example["Example"]
    end

    COPRO --> Teleprompter
    MIPROv2 --> Teleprompter
    SIMBA --> Teleprompter
    InferRules --> BootstrapFewShot
    BootstrapFewShotWithOptuna --> Teleprompter

    COPRO --> Evaluate
    MIPROv2 --> Evaluate
    MIPROv2 --> GroundedProposer
    SIMBA --> Evaluate
    InferRules --> Evaluate

    COPRO --> Module
    MIPROv2 --> Module
    SIMBA --> Module
    InferRules --> Module
    BootstrapFewShotWithOptuna --> Module

    COPRO --> Example
    MIPROv2 --> Example
    SIMBA --> Example
```

## Shared Utilities

The optimizers rely on a set of shared helper functions defined in `dspy/teleprompt/utils.py`:

- `create_minibatch` — samples a random mini-batch from a dataset.
- `create_n_fewshot_demo_sets` — generates multiple candidate few-shot demonstration sets (used by `MIPROv2`).
- `eval_candidate_program` — evaluates a candidate program on a batch or the full set.
- `get_program_with_highest_avg_score` — selects the best program by average score (used by Bayesian + minibatch optimizers).
- `get_signature` / `set_signature` — access and update a predictor's signature.
- `save_candidate_program` — persists candidate programs to a log directory.
- `print_full_program` — prints instructions and prefixes for debugging.

## Choosing an Optimizer

| Optimizer | Best For | Search Strategy | Optimizes |
| --- | --- | --- | --- |
| `COPRO` | Instruction-only optimization | Iterative proposal + refinement | Instructions |
| `MIPROv2` | Joint instruction + demo optimization | Bayesian (TPE) + minibatching | Instructions + Demos |
| `SIMBA` | Large programs, self-improvement | Stochastic mini-batch ascent | Instructions + Demos |
| `InferRules` | Rule-based task guidance | Rule induction from examples | Instructions (rules) |
| `BootstrapFewShotWithOptuna` | Demo selection | Bayesian (Optuna) | Demos |

## Related Modules

- [teleprompt_core](teleprompt_core.md) — base `Teleprompter`, `BootstrapFewShot`, `LabeledFewShot`, and other foundational optimizers.
- [teleprompt_gepa](teleprompt_gepa.md) — GEPA reflective prompt evolution optimizer.
- [teleprompt_finetune](teleprompt_finetune.md) — fine-tuning based optimizers (`BootstrapFinetune`, `GRPO`).
- [teleprompt_avatar](teleprompt_avatar.md) — `AvatarOptimizer`.
- [propose](propose.md) — `GroundedProposer` used by `MIPROv2`.
- [evaluate](evaluate.md) — `Evaluate` used for scoring candidate programs.
- [primitives](primitives.md) — `Module`, `Predict`, and `Example` building blocks.
