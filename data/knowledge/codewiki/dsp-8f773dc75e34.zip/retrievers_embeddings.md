# Retrievers: Embeddings

## Introduction

The `retrievers_embeddings` module provides the `Embeddings` retriever, a lightweight, in-memory semantic search component for DSPy. It embeds an entire corpus of text passages into dense vectors, then retrieves the top-`k` most relevant passages for a given query using cosine-style similarity (via normalized dot products).

The retriever is designed to be simple and dependency-light: for small corpora it performs an exact brute-force search, while for large corpora it automatically builds a FAISS approximate nearest-neighbor index to keep retrieval fast. It integrates with DSPy's `Embedder` client for computing embeddings and returns results as a `dspy.Prediction`.

> **Note:** This module is one of several retriever implementations. For the general retrieval abstraction, see [retrievers_core](retrievers_core.md). For other backends, see [retrievers_databricks](retrievers_databricks.md) and [retrievers_weaviate](retrievers_weaviate.md).

---

## Core Component

### `Embeddings`

Located in `dspy/retrievers/embeddings.py`, the `Embeddings` class is the sole public component of this module.

#### Constructor

```python
Embeddings(
    corpus: list[str],
    embedder,
    k: int = 5,
    callbacks: list[Any] | None = None,
    cache: bool = False,
    brute_force_threshold: int = 20_000,
    normalize: bool = True,
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `corpus` | `list[str]` | — | The list of text passages to be indexed and searched. |
| `embedder` | callable | — | An embedding function (typically a `dspy.Embedder` instance) that maps a list of strings to a 2D array of embeddings. |
| `k` | `int` | `5` | Number of top passages to return per query. |
| `callbacks` | `list[Any] \| None` | `None` | Optional callbacks (reserved for future use). |
| `cache` | `bool` | `False` | Caching is **not supported**; must remain `False` (asserted in constructor). |
| `brute_force_threshold` | `int` | `20_000` | Corpus size at or above which a FAISS index is built instead of brute-force search. |
| `normalize` | `bool` | `True` | Whether to L2-normalize embeddings before similarity computation. |

**Initialization behavior:**

1. Stores the corpus, embedder, `k`, and normalization flag.
2. Computes `corpus_embeddings` by calling `self.embedder(self.corpus)`.
3. Optionally L2-normalizes the corpus embeddings.
4. Builds a FAISS index **only if** `len(corpus) >= brute_force_threshold`; otherwise `self.index` is `None`.
5. Wraps `_batch_forward` in an `Unbatchify` instance (`self.search_fn`) to enable efficient batched query processing.

#### Methods

| Method | Description |
|--------|-------------|
| `__call__(query)` | Convenience alias that delegates to `forward`. |
| `forward(query)` | Runs retrieval for a single query and returns a `dspy.Prediction(passages=..., indices=...)`. |
| `_batch_forward(queries)` | Core batched retrieval logic: embeds queries, optionally searches FAISS, then reranks. |
| `_build_faiss()` | Builds and trains an `IndexIVFPQ` FAISS index over the corpus embeddings. |
| `_faiss_search(query_embeddings, num_candidates)` | Performs approximate nearest-neighbor search, returning candidate indices. |
| `_rerank_and_predict(q_embeds, candidate_indices)` | Computes exact similarity scores over candidates and selects the top-`k`. |
| `_normalize(embeddings)` | L2-normalizes embeddings (with a small epsilon to avoid division by zero). |

---

## Architecture

The `Embeddings` retriever sits between the DSPy retrieval abstraction and the embedding client. It relies on `Unbatchify` for concurrency and `Prediction` for output.

```mermaid
graph TD
    User["User / DSPy Module"] -->|"query"| Emb["Embeddings"]
    Emb -->|"embed corpus"| Embedder["Embedder (clients_core)"]
    Emb -->|"batched queries"| Unbatch["Unbatchify (utils)"]
    Unbatch -->|"batch_fn"| BatchFwd["_batch_forward"]
    BatchFwd -->|"embed queries"| Embedder
    BatchFwd -->|"large corpus"| FAISS["FAISS IndexIVFPQ"]
    BatchFwd -->|"rerank"| Rerank["_rerank_and_predict"]
    Rerank -->|"passages + indices"| Pred["Prediction (primitives)"]
    Pred --> User

    subgraph "retrievers_embeddings"
        Emb
        BatchFwd
        FAISS
        Rerank
    end
```

---

## Dependencies

```mermaid
graph LR
    Emb["Embeddings"] --> Unbatch["dspy.utils.unbatchify.Unbatchify"]
    Emb --> Embedder["dspy.clients.embedding.Embedder"]
    Emb --> Pred["dspy.primitives.prediction.Prediction"]
    Emb -.->|"optional"| FAISS["faiss (faiss-cpu)"]
    Emb --> Numpy["numpy"]
```

| Dependency | Module | Purpose |
|------------|--------|---------|
| `Unbatchify` | [utils](utils.md) | Batches concurrent single-query calls into efficient batch calls. |
| `Embedder` | [clients_core](clients_core.md) | Computes embeddings for corpus and queries. |
| `Prediction` | [primitives](primitives.md) | Wraps retrieval results (`passages`, `indices`). |
| `numpy` | external | Vector math, similarity computation, array manipulation. |
| `faiss` | external (optional) | Approximate nearest-neighbor index for large corpora. |

---

## Data Flow

The following diagram illustrates the end-to-end flow from a query to retrieved passages.

```mermaid
sequenceDiagram
    participant U as User
    participant E as Embeddings
    participant UB as Unbatchify
    participant BF as _batch_forward
    participant EM as Embedder
    participant F as FAISS (optional)
    participant P as Prediction

    U->>E: forward(query)
    E->>UB: search_fn(query)
    UB->>BF: _batch_forward([query])
    BF->>EM: embedder(queries)
    EM-->>BF: q_embeds
    BF->>BF: normalize(q_embeds)
    alt index exists (large corpus)
        BF->>F: search(q_embeds, k*10)
        F-->>BF: candidate indices
    else brute force
        BF->>BF: tile all corpus indices
    end
    BF->>BF: _rerank_and_predict(q_embeds, pids)
    BF-->>UB: [(passages, indices)]
    UB-->>E: (passages, indices)
    E->>P: Prediction(passages, indices)
    P-->>U: Prediction
```

### Retrieval Process Flow

```mermaid
flowchart TD
    Start([Query received]) --> Embed["Embed query via Embedder"]
    Embed --> Norm{"normalize?"}
    Norm -->|Yes| NormYes["L2-normalize query embedding"]
    Norm -->|No| SkipNorm["Use raw embedding"]
    NormYes --> IndexCheck{"FAISS index built?"}
    SkipNorm --> IndexCheck
    IndexCheck -->|Yes| FaissSearch["FAISS search for k*10 candidates"]
    IndexCheck -->|No| BruteForce["Use all corpus indices"]
    FaissSearch --> Rerank["Compute dot-product scores"]
    BruteForce --> Rerank
    Rerank --> TopK["Select top-k by score"]
    TopK --> Build["Build passages + indices lists"]
    Build --> Return([Return Prediction])
```

---

## Component Interaction Details

### `Unbatchify` Integration

`Embeddings` wraps its internal `_batch_forward` method with `Unbatchify`, which runs a background worker thread. When `forward(query)` is called, the single query is placed on a queue; the worker collects queries up to `max_batch_size` (default 32) or until `max_wait_time` (default 0.1s) elapses, then invokes `_batch_forward` on the batch. This allows concurrent callers to share embedding and search work efficiently.

For more details on the batching mechanism, see [utils](utils.md).

### Embedding Computation

The `embedder` is expected to be a `dspy.Embedder` (or any compatible callable) that accepts a list of strings and returns a 2D `numpy` array of embeddings. See [clients_core](clients_core.md) for the `Embedder` interface, including hosted models (via litellm) and custom callables.

### FAISS Indexing

When the corpus size meets or exceeds `brute_force_threshold` (default 20,000), `_build_faiss` constructs an `IndexIVFPQ`:

- **Quantizer:** `IndexFlatL2` over the embedding dimension.
- **Partitions:** `int(2 * sqrt(len(corpus)))`.
- **PQ bytes:** 32 (`nbytes`), with 8 sub-quantizers.
- **`nprobe`:** `min(16, partitions)`.

The index is trained and populated with `corpus_embeddings`. During search, `k * 10` candidates are retrieved and then exactly reranked, balancing speed and accuracy.

> **Requirement:** FAISS is optional. If the corpus is large but `faiss` is not installed, an `ImportError` is raised instructing the user to `pip install faiss-cpu` or increase `brute_force_threshold`.

### Reranking and Scoring

`_rerank_and_predict` computes similarity scores using `np.einsum("qd,qkd->qk", q_embeds, candidate_embeddings)`. When embeddings are normalized, this is equivalent to cosine similarity. The top-`k` indices per query are selected via `np.argsort(-scores, axis=1)[:, :k]`, and the corresponding passages and indices are returned.

---

## Usage Example

```python
import dspy

# Create an embedder (hosted or custom)
embedder = dspy.Embedder("openai/text-embedding-3-small")

# Build the retriever over a corpus
corpus = ["The cat sat on the mat.", "Dogs are loyal companions.", "Birds can fly."]
retriever = dspy.retrievers.Embeddings(corpus=corpus, embedder=embedder, k=2)

# Retrieve
result = retriever("What do pets do?")
print(result.passages)  # top-2 passages
print(result.indices)   # their corpus indices
```

---

## Design Notes and Limitations

- **No persistence:** The module contains a `TODO` for `.save` and `.load` methods; the index and corpus embeddings are not persisted.
- **No caching:** `cache` must be `False`; passing `True` raises an `AssertionError`.
- **In-memory only:** The entire corpus and its embeddings are held in memory.
- **Optional FAISS:** Large corpora require `faiss-cpu`; otherwise, increase `brute_force_threshold` to force brute-force search (at the cost of speed).

---

## Related Modules

- [retrievers_core](retrievers_core.md) — The `Retrieve` abstraction and general retrieval interface.
- [retrievers_databricks](retrievers_databricks.md) — Databricks-backed retriever.
- [retrievers_weaviate](retrievers_weaviate.md) — Weaviate-backed retriever.
- [clients_core](clients_core.md) — The `Embedder` client used for computing embeddings.
- [utils](utils.md) — The `Unbatchify` utility for batched query processing.
- [primitives](primitives.md) — The `Prediction` object returned by retrieval.
