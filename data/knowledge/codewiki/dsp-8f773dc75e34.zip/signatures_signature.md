# Signatures: Signature & SignatureMeta

## Introduction

The `signatures_signature` module is the **foundational type system** of DSPy. It defines `Signature` and its metaclass `SignatureMeta`, which together provide a declarative way to specify the *input/output contract* of a language-model-powered module. A `Signature` describes:

- **What fields** a module consumes (inputs) and produces (outputs).
- **The type** of each field (e.g., `str`, `int`, `list[str]`, custom types).
- **The instructions** (natural-language task description) that guide the LM.
- **Field metadata** such as prefixes and descriptions used when formatting prompts.

Every `Predict`-based module (see [predict_core.md](predict_core.md)) is built on top of a `Signature`, and every adapter (see [adapters_implementations.md](adapters_implementations.md)) consumes a `Signature` to format prompts and parse LM responses. As such, this module sits at the very center of the DSPy data flow.

> **Note:** This module is the modern, Pydantic-backed implementation. The legacy `OldField`/`OldInputField`/`OldOutputField` classes live in [signatures_field.md](signatures_field.md).

---

## Architecture Overview

`Signature` is a subclass of Pydantic's `BaseModel`, and its behavior is heavily customized by the `SignatureMeta` metaclass. The metaclass intercepts class creation and class instantiation to enforce DSPy-specific semantics.

```mermaid
classDiagram
    class BaseModel {
        <<pydantic>>
    }
    class SignatureMeta {
        <<metaclass>>
        +__call__(cls, *args, **kwargs)
        +__new__(mcs, name, bases, namespace)
        +_detect_custom_types_from_caller(sig_str)
        +_validate_fields(cls)
        +instructions : str
        +input_fields : dict
        +output_fields : dict
        +fields : dict
        +signature : str
    }
    class Signature {
        +with_instructions(instructions)
        +with_updated_fields(name, type_, **kwargs)
        +prepend(name, field, type_)
        +append(name, field, type_)
        +delete(name)
        +insert(index, name, field, type_)
        +equals(other)
        +dump_state()
        +load_state(state)
    }
    class FieldInfo {
        <<pydantic>>
    }

    BaseModel <|-- Signature
    SignatureMeta ..> Signature : creates & configures
    Signature o-- FieldInfo : model_fields
```

### Key Design Decisions

| Concern | Mechanism |
| --- | --- |
| Declarative field definition | Subclass `Signature` and annotate fields with `InputField()` / `OutputField()` |
| String-based shorthand | `Signature("question -> answer")` triggers `make_signature` via the metaclass |
| Field ordering | `SignatureMeta.__new__` reorders `__annotations__` to preserve declaration order |
| Default instructions | `_default_instructions` generates a fallback prompt from field names |
| Field validation | `_validate_fields` ensures every field is an input or output |
| Prefix/description inference | `infer_prefix` + defaults applied in `__new__` |

---

## Core Components

### `SignatureMeta`

The metaclass (subclass of `type(BaseModel)`) is responsible for two distinct behaviors:

1. **Class creation** (`__new__`): When a user subclasses `Signature`, the metaclass:
   - Collects fields in declaration order and rebuilds `__annotations__` to preserve that order.
   - Defaults untyped fields to `str`.
   - Inherits `__doc__` (instructions) from base classes for generic subclasses.
   - Falls back to `_default_instructions` when no docstring is provided.
   - Calls `_validate_fields()` to ensure every field is declared with `InputField`/`OutputField`.
   - Injects default `prefix` (via `infer_prefix`) and `desc` into each field's `json_schema_extra`.

2. **Class instantiation** (`__call__`): When `Signature(...)` is invoked directly, the metaclass does **not** create an instance. Instead it delegates to `make_signature`, producing a *new Signature subclass*. This is what enables the string shorthand.

```mermaid
flowchart TD
    A["Signature('q -> a')"] --> B{cls is Signature?}
    B -- Yes --> C[Pop custom_types]
    C --> D{custom_types None<br/>and args[0] is str?}
    D -- Yes --> E[_detect_custom_types_from_caller]
    D -- No --> F[make_signature]
    E --> F
    F --> G[New Signature subclass]
    B -- No --> H[super().__call__<br/>create instance]
```

#### `_detect_custom_types_from_caller`

When a signature string references a custom type (e.g., `"input: MyType -> output"`), this static method walks the Python call stack (up to 100 frames) to resolve the type name from the caller's local or global namespace. This is a best-effort convenience; the docstring explicitly recommends passing `custom_types` explicitly for reliability.

> **Limitations:** Frame introspection may fail under optimized Python builds, only searches a bounded number of frames, and cannot find types that are imported but not present in the caller's namespace.

#### Metaclass Properties

| Property | Returns | Description |
| --- | --- | --- |
| `instructions` | `str` | Cleaned docstring (settable). |
| `input_fields` | `dict[str, FieldInfo]` | Fields with `__dspy_field_type == "input"`. |
| `output_fields` | `dict[str, FieldInfo]` | Fields with `__dspy_field_type == "output"`. |
| `fields` | `dict[str, FieldInfo]` | Inputs followed by outputs. |
| `signature` | `str` | `"input1, input2 -> output1, output2"`. |

---

### `Signature`

The base class users subclass. It provides a rich set of classmethods for **immutably deriving new Signature classes** (each returns a *new class*, never mutating the original).

```mermaid
flowchart LR
    S[Signature] --> WI[with_instructions]
    S --> WUF[with_updated_fields]
    S --> P[prepend]
    S --> A[append]
    S --> D[delete]
    S --> I[insert]
    S --> EQ[equals]
    S --> DS[dump_state]
    S --> LS[load_state]
```

#### Field Manipulation Methods

| Method | Purpose |
| --- | --- |
| `with_instructions(instructions)` | Returns a new Signature with replaced instructions. |
| `with_updated_fields(name, type_=None, **kwargs)` | Returns a new Signature with `fields[name].json_schema_extra` merged with `kwargs` and optionally a new type. |
| `prepend(name, field, type_=None)` | Inserts a field at the beginning of its input/output group. |
| `append(name, field, type_=None)` | Inserts a field at the end of its input/output group. |
| `delete(name)` | Returns a new Signature without the named field. |
| `insert(index, name, field, type_=None)` | Inserts a field at a specific index within its group (supports negative indices). |

#### Serialization Methods

| Method | Purpose |
| --- | --- |
| `equals(other)` | Compares instructions and per-field `json_schema_extra` against another Signature. |
| `dump_state()` | Serializes instructions and per-field `prefix`/`description` to a dict. |
| `load_state(state)` | Reconstructs a Signature from a previously dumped state. |

These are used by `Predict.dump_state` / `Predict.load_state` (see [predict_core.md](predict_core.md)) to persist module configuration.

---

## Module-Level Functions

The module exposes several helper functions that operate on signatures.

```mermaid
flowchart TD
    subgraph Public API
        ES[ensure_signature]
        MS[make_signature]
        IP[infer_prefix]
    end
    subgraph Internal Parsing
        PS[_parse_signature]
        PFS[_parse_field_string]
        PTN[_parse_type_node]
        DI[_default_instructions]
    end
    ES --> MS
    MS --> PS
    MS --> DI
    PS --> PFS
    PFS --> PTN
```

### `ensure_signature(signature, instructions=None)`

Normalizes a `str` or `Signature` into a `Signature` class. Raises if `instructions` is provided alongside an existing Signature. Used pervasively by `Predict` and adapters.

### `make_signature(signature, instructions=None, signature_name="StringSignature", custom_types=None)`

The workhorse factory. Accepts either:
- A **string** like `"question, context -> answer"`, or
- A **dict** mapping field names to `(type, FieldInfo)` tuples.

It validates field names/types, defaults missing types to `str`, generates default instructions when none are supplied, and finally calls Pydantic's `create_model` with `Signature` as the base.

### `infer_prefix(attribute_name)`

Converts a field name into a human-readable prefix. Examples:

| Input | Output |
| --- | --- |
| `camelCaseText` | `Camel Case Text` |
| `snake_case_text` | `Snake Case Text` |
| `text2number` | `Text 2 Number` |
| `HTMLParser` | `HTML Parser` |

### Internal Parsing Helpers

- **`_parse_signature`** — Splits on `->` (must appear exactly once) and builds the field dict.
- **`_parse_field_string`** — Uses Python's `ast` module to parse `"x: int, y: str"` into `(name, type)` pairs.
- **`_parse_type_node`** — Recursively converts AST nodes into real Python types, handling:
  - Simple names (`int`, `str`)
  - Attribute access (`typing.List`, `dspy.Image`)
  - Subscripts (`list[int]`, `Optional[int]`)
  - PEP 604 unions (`int | None`)
  - `Field(...)` calls embedded in annotations
  - Dynamic module imports for module-qualified names

---

## Data Flow

The following diagram shows how a `Signature` flows through the DSPy pipeline, from user definition to LM call and back.

```mermaid
sequenceDiagram
    participant User
    participant Predict
    participant Adapter
    participant LM

    User->>Predict: define Signature (class or string)
    User->>Predict: call with input kwargs
    Predict->>Predict: ensure_signature(signature)
    Predict->>Adapter: adapter(lm, signature, demos, inputs)
    Adapter->>Adapter: format(signature, demos, inputs)
    Note over Adapter: uses signature.instructions,<br/>input_fields, output_fields,<br/>field prefixes/descs
    Adapter->>LM: messages
    LM-->>Adapter: completions
    Adapter->>Adapter: parse(signature, completion)
    Adapter-->>Predict: list[dict] outputs
    Predict-->>User: Prediction
```

### Signature Lifecycle

```mermaid
flowchart LR
    A[Class definition<br/>or string] --> B[SignatureMeta.__new__<br/>or make_signature]
    B --> C[Field validation<br/>+ prefix/desc defaults]
    C --> D[Signature class]
    D --> E[ensure_signature]
    E --> F[Adapter.format]
    F --> G[LM call]
    G --> H[Adapter.parse]
    H --> I[Prediction]
    D -.dump_state/load_state.-> J[Persistence]
```

---

## Relationships to Other Modules

| Module | Relationship |
| --- | --- |
| [signatures_field.md](signatures_field.md) | Provides `InputField`/`OutputField` (modern) and legacy `OldField` variants used to declare fields. |
| [predict_core.md](predict_core.md) | `Predict` wraps a `Signature` and drives the LM call; uses `ensure_signature`, `dump_state`, `load_state`. |
| [adapters_implementations.md](adapters_implementations.md) | Adapters consume `Signature` to format prompts and parse outputs; rely on `input_fields`, `output_fields`, `instructions`, and field metadata. |
| [adapter_types.md](adapter_types.md) | Custom field types (e.g., `Image`, `Tool`, `History`) are referenced in Signature annotations and resolved by `_parse_type_node`. |
| [primitives_prediction.md](primitives_prediction.md) | `Prediction.from_completions` builds results keyed by the Signature's output fields. |
| [primitives_example.md](primitives_example.md) | `Example` objects (demos) are validated against `signature.fields` by adapters. |
| [propose_grounded.md](propose_grounded.md) | Proposers generate and mutate instructions/fields on Signatures during optimization. |
| [teleprompt_core.md](teleprompt_core.md) | Teleprompters optimize demos and instructions associated with Signatures. |

---

## Usage Examples

### Class-based Signature

```python
import dspy

class QA(dspy.Signature):
    """Answer the question given the context."""
    context: list[str] = dspy.InputField(desc="Relevant passages")
    question: str = dspy.InputField()
    answer: int = dspy.OutputField(desc="The numeric answer")
```

### String-based Signature

```python
sig = dspy.Signature("question, context -> answer")
# Equivalent to make_signature("question, context -> answer")
```

### Custom Types

```python
class MyType:
    pass

sig = dspy.Signature("input: MyType -> output", custom_types={"MyType": MyType})
```

### Deriving New Signatures

```python
new_sig = QA.with_instructions("Be concise.")
new_sig = QA.append("confidence", dspy.OutputField(), type_=float)
new_sig = QA.delete("context")
```

---

## Summary

The `signatures_signature` module defines the **contract layer** of DSPy. `SignatureMeta` enforces structure and enables the string shorthand, while `Signature` provides immutable derivation and serialization. Together with the field helpers in [signatures_field.md](signatures_field.md), they form the interface that every predictor, adapter, and optimizer in DSPy depends upon.
