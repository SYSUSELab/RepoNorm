# predict_advanced

## Overview

The `predict_advanced` module is a collection of **advanced prediction strategies** in DSPy that go beyond the basic `Predict` and `ChainOfThought` modules (see [predict_core](predict_core.md)). While the core prediction modules perform a single (or chained) LM call, the modules in `predict_advanced` implement higher-level reasoning patterns such as:

- **Iterative sampling and refinement** — run a module multiple times and pick or improve the best result.
- **Tool-using agents** — interleave reasoning with tool calls (ReAct) or code execution (CodeAct).
- **Program synthesis** — generate and execute Python programs to compute answers (ProgramOfThought).
- **Retrieval and ensemble comparison** — retrieve similar examples (KNN) or compare multiple reasoning attempts (MultiChainComparison).

All modules in this package are built on top of the DSPy primitives (`Module`, `Predict`, `Prediction`, `Signature`) and reuse the adapter, client, and interpreter infrastructure provided by other modules.

## Architecture

The module is organized around four conceptual groups of functionality. Each group is documented in its own sub-module page.

```mermaid
graph TD
    subgraph predict_advanced
        BestOfN
        Refine
        ReAct
        CodeAct
        ProgramOfThought
        KNN
        MultiChainComparison
    end

    subgraph "Sampling & Refinement"
        BestOfN
        Refine
    end

    subgraph "Tool-Using Agents"
        ReAct
        CodeAct
    end

    subgraph "Program Synthesis"
        ProgramOfThought
        CodeAct
    end

    subgraph "Retrieval & Comparison"
        KNN
        MultiChainComparison
    end

    BestOfN -->|wraps| Module
    Refine -->|wraps| Module
    ReAct -->|uses| Tool
    CodeAct -->|extends| ReAct
    CodeAct -->|extends| ProgramOfThought
    ProgramOfThought -->|uses| PythonInterpreter
    KNN -->|uses| Embedder
    MultiChainComparison -->|uses| Predict
```

### Dependency Overview

```mermaid
graph LR
    subgraph "predict_advanced"
        BestOfN
        Refine
        ReAct
        CodeAct
        ProgramOfThought
        KNN
        MultiChainComparison
    end

    subgraph "predict_core"
        Predict
        ChainOfThought
        Module
    end

    subgraph "primitives"
        PythonInterpreter
        Prediction
    end

    subgraph "adapters"
        Tool
    end

    subgraph "clients_core"
        Embedder
    end

    BestOfN --> Module
    Refine --> Module
    ReAct --> Module
    ReAct --> Tool
    ReAct --> Predict
    ReAct --> ChainOfThought
    CodeAct --> ReAct
    CodeAct --> ProgramOfThought
    CodeAct --> PythonInterpreter
    ProgramOfThought --> ChainOfThought
    ProgramOfThought --> PythonInterpreter
    KNN --> Embedder
    MultiChainComparison --> Predict
```

## Sub-modules

The `predict_advanced` module is split into four sub-modules, each covering a distinct family of advanced prediction strategies:

| Sub-module | Description | Core Components |
|------------|-------------|-----------------|
| [predict_advanced_sampling](predict_advanced_sampling.md) | Sampling and refinement strategies that run a module multiple times and select or improve the best result. | `BestOfN`, `Refine`, `OfferFeedback` |
| [predict_advanced_agents](predict_advanced_agents.md) | Tool-using agent paradigms that interleave reasoning with tool calls or code execution. | `ReAct`, `CodeAct` |
| [predict_advanced_program_synthesis](predict_advanced_program_synthesis.md) | Program synthesis that generates and executes Python code to compute answers. | `ProgramOfThought` |
| [predict_advanced_retrieval](predict_advanced_retrieval.md) | Retrieval and ensemble-comparison utilities. | `KNN`, `MultiChainComparison` |

### Sampling & Refinement — [predict_advanced_sampling](predict_advanced_sampling.md)

`BestOfN` and `Refine` both wrap an arbitrary `Module` and run it up to `N` times with varying temperatures, using a user-supplied `reward_fn` to score each attempt. `BestOfN` simply returns the best-scoring prediction (or the first one that passes a threshold), while `Refine` additionally generates **per-module feedback** via the `OfferFeedback` signature and injects it as a hint into subsequent attempts.

### Tool-Using Agents — [predict_advanced_agents](predict_advanced_agents.md)

`ReAct` implements the "Reasoning and Acting" paradigm: the LM iteratively produces a thought, selects a tool, and receives an observation until it calls the `finish` tool. `CodeAct` extends both `ReAct` and `ProgramOfThought`, letting the agent write and execute Python code (with access to user-provided tools) instead of only calling tools directly.

### Program Synthesis — [predict_advanced_program_synthesis](predict_advanced_program_synthesis.md)

`ProgramOfThought` generates Python code to solve a problem, executes it in a sandboxed `PythonInterpreter` (Deno/Pyodide), and regenerates the code on error up to `max_iters` times before extracting the final answer.

### Retrieval & Comparison — [predict_advanced_retrieval](predict_advanced_retrieval.md)

`KNN` is a lightweight k-nearest-neighbors retriever over a training set using an `Embedder`. `MultiChainComparison` takes multiple reasoning attempts and asks the LM to holistically produce a corrected rationale and answer.

## Common Patterns

All modules in this package share several design conventions:

- **Composition over inheritance** — most modules wrap or compose `Predict`/`ChainOfThought` sub-modules rather than reimplementing LM calls.
- **Signature polymorphism** — modules accept either a string signature (e.g. `"question -> answer"`) or a `Signature` type, normalized via `ensure_signature`.
- **Trace management** — modules that run sub-modules inside `dspy.context(trace=[])` capture and re-extend the global trace so that optimizers can observe the full execution.
- **Deep-copy isolation** — sampling modules (`BestOfN`, `Refine`) deep-copy the wrapped module and set a per-attempt LM to avoid state leakage between attempts.

## Related Modules

- [predict_core](predict_core.md) — the base `Predict`, `ChainOfThought`, `Parameter`, and `Parallel` modules that `predict_advanced` builds upon.
- [primitives](primitives.md) — `Module`, `Prediction`, and `PythonInterpreter` used throughout.
- [adapters](adapters.md) — the `Tool` type and adapters used for tool calling and formatting.
- [clients_core](clients_core.md) — the `Embedder` used by `KNN`.
- [predict_avatar](predict_avatar.md) — another advanced agent-style module for comparison.
