# AlfWorld Dataset Module

## Introduction

The `datasets_datasets_alfworld` module provides integration between DSPy and the [ALFWorld](https://alfworld.github.io/) benchmark — a text-based interactive environment where an agent must complete household tasks (e.g., "put a hot apple in the fridge") by navigating rooms and manipulating objects through natural-language actions.

Unlike static datasets such as [GSM8K](datasets_builtin.md) or [HotPotQA](datasets_builtin.md), ALFWorld is an **interactive, stateful environment**. Each example is identified by an `idx`, and the actual task is executed by stepping through the environment with actions. This module therefore focuses on:

1. **Managing a pool of isolated environment processes** so that many ALFWorld tasks can be run in parallel without state leakage.
2. **Exposing a DSPy-friendly dataset** (`trainset` / `devset`) of task indices that can be fed into DSPy programs (e.g., [ReAct](predict_advanced.md), [CodeAct](predict_advanced.md)).

The module lives at `dspy/datasets/alfworld/alfworld.py` and defines three core components: `AlfWorld`, `EnvPool`, and `_EnvSession`.

---

## Architecture Overview

The module is built around a **process-pool architecture**. Because ALFWorld environments are heavy, stateful, and not thread-safe, each environment runs in its own spawned process. A pool of such processes is managed by `EnvPool`, and callers borrow a worker for the duration of a task via the `_EnvSession` context manager. The top-level `AlfWorld` class wires this pool together with a DSPy dataset of task indices.

```mermaid
graph TD
    subgraph "Main Process"
        AW["AlfWorld<br/>(max_threads=20)"]
        POOL["EnvPool<br/>(size=N)"]
        SESS["_EnvSession<br/>(context manager)"]
        DS["trainset / devset<br/>(dspy.Example list)"]
    end

    subgraph "Worker Process 1"
        W1["env_worker<br/>AlfredTWEnv"]
    end
    subgraph "Worker Process 2"
        W2["env_worker<br/>AlfredTWEnv"]
    end
    subgraph "Worker Process N"
        WN["env_worker<br/>AlfredTWEnv"]
    end

    AW --> POOL
    AW --> DS
    POOL -->|"session()"| SESS
    SESS -->|"init(idx) / step(action)"| W1
    SESS -->|"init(idx) / step(action)"| W2
    SESS -->|"init(idx) / step(action)"| WN
    W1 -.->|"task_def, info, obs, rew, done"| SESS
    W2 -.->|"task_def, info, obs, rew, done"| SESS
    WN -.->|"task_def, info, obs, rew, done"| SESS
```

### Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Multiprocessing with `spawn`** | ALFWorld environments are stateful and not picklable/thread-safe. `spawn` ensures a clean interpreter per worker, avoiding fork-related issues with native libraries. |
| **Queue-based IPC** | Each worker communicates over a pair of `multiprocess.Queue` objects (`inq` for commands, `outq` for results), keeping the protocol simple and synchronous. |
| **Context-manager sessions** | `_EnvSession` guarantees a worker is always released back to the pool, even if an exception occurs during a task. |
| **Index-based dataset** | The dataset stores only `idx` values; the actual environment state is created lazily when a task is initialized. |

---

## Component Reference

### `AlfWorld`

The public entry point of the module. It constructs the environment pool and prepares the DSPy dataset.

```python
class AlfWorld:
    def __init__(self, max_threads=20):
        self.POOL = EnvPool(size=max_threads)

        import dspy
        dataset = [dspy.Example(idx=idx).with_inputs("idx") for idx in range(3500)]
        random.Random(0).shuffle(dataset)

        trainset, devset = dataset[:3000], dataset[-500:]
        self.trainset = trainset
        self.devset = devset

    def __del__(self):
        self.POOL.close_all()
```

**Responsibilities:**

- **Pool creation** — Instantiates an `EnvPool` with `max_threads` worker processes (default `20`).
- **Dataset construction** — Builds 3,500 `dspy.Example` objects, each carrying a single `idx` field marked as an input via `.with_inputs("idx")`. The list is deterministically shuffled with seed `0`.
- **Split** — The first 3,000 examples form `trainset`; the last 500 form `devset`.
- **Cleanup** — `__del__` calls `POOL.close_all()` to terminate all worker processes.

> **Note:** The `idx` values range over `0..3499`, which must correspond to valid ALFWorld task indices available in the installed environment.

**Attributes:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `POOL` | `EnvPool` | The pool of environment worker processes. |
| `trainset` | `list[dspy.Example]` | 3,000 training examples (each with `idx`). |
| `devset` | `list[dspy.Example]` | 500 development examples (each with `idx`). |

---

### `EnvPool`

Manages a fixed-size pool of worker processes, each hosting an independent ALFWorld environment.

```python
class EnvPool:
    def __init__(self, size=2):
        ...
        mp.set_start_method("spawn", force=True)
        ctx = mp.get_context("spawn")
        for i in range(size):
            inq = ctx.Queue()
            outq = ctx.Queue()
            p = ctx.Process(target=env_worker, args=(inq, outq), daemon=True)
            p.start()
            self.workers.append((inq, outq, p))
            self.available.put(i)
```

**Responsibilities:**

- **Process lifecycle** — Spawns `size` daemon processes running `env_worker`, each with its own `inq`/`outq` queues.
- **Availability tracking** — A `queue.Queue` (`self.available`) holds the IDs of idle workers.
- **Acquire / release** — `_acquire()` blocks until a worker is free and returns its ID and queues; `_release(wid)` returns the worker to the available set.
- **Session factory** — `session()` returns an `_EnvSession` context manager.
- **Shutdown** — `close_all()` sends a `"close"` command to every worker, waits for the `"CLOSED"` acknowledgement, closes the queues, and joins the processes.

**Methods:**

| Method | Description |
|--------|-------------|
| `_acquire()` | Blocks until a worker is available; returns `(wid, inq, outq)`. |
| `_release(wid)` | Marks worker `wid` as available again. |
| `close_all()` | Gracefully terminates all worker processes. |
| `session()` | Returns a new `_EnvSession` bound to this pool. |

> **Important:** `multiprocess` (not the standard `multiprocessing`) is required. The start method is forced to `"spawn"` before any process is created.

---

### `_EnvSession`

A context manager that borrows a single worker from the pool for the duration of one task.

```python
class _EnvSession:
    def __enter__(self):
        self.wid, self.inq, self.outq = self.pool._acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.pool._release(self.wid)

    def init(self, idx):
        self.inq.put(("init", idx))
        return self.outq.get()  # (task_def, info)

    def step(self, action):
        self.inq.put(("step", action))
        return self.outq.get()  # (obs, rew, done, info)
```

**Responsibilities:**

- **Acquire on enter** — `__enter__` blocks until a worker is free and stores its queues.
- **Release on exit** — `__exit__` always returns the worker to the pool, even on exceptions.
- **Task initialization** — `init(idx)` sends an `"init"` command and returns `(task_def, info)`.
- **Stepping** — `step(action)` sends a `"step"` command and returns `(obs, rew, done, info)`.

**Methods:**

| Method | Returns | Description |
|--------|---------|-------------|
| `init(idx)` | `(task_def, info)` | Initializes the environment for task `idx`. |
| `step(action)` | `(obs, rew, done, info)` | Executes `action` and returns the resulting observation, reward, done flag, and info. |

---

### `env_worker` (module-level function)

The target function executed in each worker process. It is not part of the public API but is central to the module's behavior.

```python
def env_worker(inq, outq):
    import alfworld.agents.environment as environment
    import yaml
    ...
    base_env = environment.AlfredTWEnv(config, train_eval="train")
    env = None
    while True:
        cmd, data = inq.get()
        if cmd == "init":
            env = base_env.init_env(batch_size=1)
            env.skip(data)
            task_def, info = env.reset()
            outq.put((task_def[0], info))
        elif cmd == "step":
            obs, rew, done, info = env.step([data])
            outq.put((obs, rew, done, info))
        elif cmd == "close":
            outq.put("CLOSED")
            break
```

**Responsibilities:**

- **Lazy imports** — Imports `alfworld` and `yaml` inside the function so that the main process does not require them until a worker starts. Raises a helpful `ImportError` if `alfworld` is missing.
- **Config loading** — Loads `base_config.yml` from the module directory.
- **Environment creation** — Creates a single `AlfredTWEnv` (train/eval mode `"train"`), suppressing stdout/stderr into a buffer.
- **Command loop** — Handles three commands:
  - `"init"` — creates a batch-size-1 env, skips to task `data`, resets, and returns `(task_def[0], info)`.
  - `"step"` — steps the env with `[data]` and returns `(obs, rew, done, info)`.
  - `"close"` — acknowledges with `"CLOSED"` and exits the loop.

---

## Data Flow

The following sequence diagram shows a complete task lifecycle, from acquiring a worker to releasing it.

```mermaid
sequenceDiagram
    participant User as DSPy Program
    participant AW as AlfWorld
    participant Pool as EnvPool
    participant Sess as _EnvSession
    participant Worker as env_worker (subprocess)

    User->>AW: AlfWorld(max_threads=20)
    AW->>Pool: EnvPool(size=20)
    Pool->>Worker: spawn N processes
    AW-->>User: trainset / devset

    User->>Pool: session()
    Pool-->>User: _EnvSession
    User->>Sess: __enter__()
    Sess->>Pool: _acquire()
    Pool-->>Sess: (wid, inq, outq)

    User->>Sess: init(idx)
    Sess->>Worker: ("init", idx)
    Worker-->>Sess: (task_def, info)
    Sess-->>User: (task_def, info)

    loop Until done
        User->>Sess: step(action)
        Sess->>Worker: ("step", action)
        Worker-->>Sess: (obs, rew, done, info)
        Sess-->>User: (obs, rew, done, info)
    end

    User->>Sess: __exit__()
    Sess->>Pool: _release(wid)
```

---

## Usage Example

```python
from dspy.datasets.alfworld.alfworld import AlfWorld

# Create the dataset and environment pool
alfworld = AlfWorld(max_threads=4)

# Inspect the splits
print(len(alfworld.trainset), len(alfworld.devset))  # 3000 500
print(alfworld.trainset[0].idx)                       # some task index

# Run a single task interactively
with alfworld.POOL.session() as sess:
    task_def, info = sess.init(alfworld.trainset[0].idx)
    print(task_def)  # task description

    done = False
    action = "look"
    while not done:
        obs, rew, done, info = sess.step(action)
        print(obs, rew, done)
        action = input("> ")  # or an agent policy
```

---

## Dependencies

```mermaid
graph LR
    AlfWorld --> EnvPool
    EnvPool --> _EnvSession
    EnvPool --> env_worker
    AlfWorld --> Example["dspy.Example<br/>(primitives)"]
    env_worker --> alfworld["alfworld.agents.environment"]
    env_worker --> yaml
    EnvPool --> multiprocess
```

| Dependency | Purpose | Install |
|------------|---------|---------|
| `alfworld` | The ALFWorld environment (`AlfredTWEnv`). | `pip install alfworld==0.3.5` then `alfworld-download` |
| `multiprocess` | Cross-platform process pool with `spawn` support. | `pip install multiprocess` |
| `yaml` | Loads `base_config.yml`. | (bundled with ALFWorld) |
| [`dspy.Example`](primitives.md) | Wraps task indices as DSPy examples. | part of DSPy |

> **Note:** `alfworld` and `multiprocess` are optional dependencies. They are imported lazily and raise descriptive `ImportError`s if missing.

---

## Relationship to Other Dataset Modules

The ALFWorld module is one of several dataset integrations in DSPy. It differs from the static datasets in that it exposes an **interactive environment** rather than pre-computed question/answer pairs.

| Module | Type | Description |
|--------|------|-------------|
| [datasets_core](datasets_core.md) | Base classes | `Dataset` and `DataLoader` provide the common dataset abstractions. |
| [datasets_builtin](datasets_builtin.md) | Static datasets | `GSM8K`, `HotPotQA`, `MATH`, `Colors` — pre-loaded Q&A pairs. |
| **datasets_datasets_alfworld** (this module) | Interactive environment | `AlfWorld` — task indices backed by a process pool of live environments. |

Unlike `GSM8K` (which subclasses nothing and directly assigns `self.train`/`self.dev`/`self.test`), `AlfWorld` does **not** inherit from [`Dataset`](datasets_core.md); it manages its own `trainset`/`devset` attributes and pool lifecycle.

---

## Lifecycle & Resource Management

```mermaid
stateDiagram-v2
    [*] --> Constructed: AlfWorld(max_threads)
    Constructed --> PoolReady: EnvPool spawns N workers
    PoolReady --> InUse: session().__enter__()
    InUse --> PoolReady: session().__exit__() releases worker
    PoolReady --> Closed: close_all() / __del__
    Closed --> [*]
```

**Best practices:**

- Always use the `with pool.session() as sess:` context manager to guarantee worker release.
- Call `close_all()` explicitly when done if you want deterministic cleanup rather than relying on `__del__`.
- Choose `max_threads` based on available CPU/memory; each worker holds a full ALFWorld environment.

---

## Summary

The `datasets_datasets_alfworld` module bridges DSPy and the ALFWorld interactive benchmark through a robust multiprocessing architecture:

- **`AlfWorld`** — the public API, exposing `trainset`/`devset` of task indices and owning the environment pool.
- **`EnvPool`** — a spawn-based pool of isolated environment processes with acquire/release semantics.
- **`_EnvSession`** — a context manager providing `init(idx)` and `step(action)` for a single borrowed worker.
- **`env_worker`** — the per-process command loop that drives the underlying `AlfredTWEnv`.

This design enables safe, parallel execution of many stateful ALFWorld tasks, making it suitable for training and evaluating interactive DSPy agents such as [ReAct](predict_advanced.md) and [CodeAct](predict_advanced.md).
