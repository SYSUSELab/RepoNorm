# DSP Utils Settings

## Introduction

The `dsp_utils_settings` module provides the **global configuration system** for DSPy. It exposes a thread-safe, singleton `Settings` object (imported throughout the codebase as `dspy.settings`) that holds all runtime configuration values — such as the active language model (`lm`), retrieval model (`rm`), adapter, callbacks, streaming listeners, and various operational limits.

The module solves a fundamental problem in DSPy: many components (predictors, adapters, retrievers, teleprompters) need access to shared configuration without passing it explicitly through every function call. At the same time, DSPy must support concurrent execution (threads and async tasks) where different execution contexts may need *different* configuration. The `Settings` class addresses both needs through a two-tier configuration model:

1. **Global configuration** — set once via `dspy.configure(...)` by a single "owner" thread/task, visible to all threads.
2. **Context-local overrides** — set via `dspy.context(...)`, scoped to the current thread and propagated to child threads spawned by DSPy primitives.

This module is a foundational dependency used across nearly every other DSPy module. For the helper data structures it relies on, see [dsp_utils_helpers](dsp_utils_helpers.md).

---

## Architecture Overview

The module consists of a single core class, `Settings`, backed by module-level global state and a helper `dotdict` type.

```mermaid
graph TD
    subgraph "dsp_utils_settings module"
        S[Settings singleton]
        D[DEFAULT_CONFIG]
        MTC[main_thread_config]
        TLO[thread_local_overrides<br/>ContextVar]
        LOCK[global_lock]
        OWNER[config_owner_thread_id<br/>config_owner_async_task]
    end

    subgraph "dsp_utils_helpers"
        DD[dotdict]
    end

    S -->|reads/writes| MTC
    S -->|reads/writes| TLO
    S -->|uses| LOCK
    S -->|tracks| OWNER
    D -->|deepcopy initializes| MTC
    D -->|built with| DD
    MTC -->|built with| DD
    TLO -->|built with| DD
```

### Key Design Decisions

| Concern | Mechanism |
|---------|-----------|
| Single source of truth | Singleton pattern via `__new__` |
| Global config visibility | `main_thread_config` (module-level `dotdict`) |
| Per-thread/per-context isolation | `thread_local_overrides` (`contextvars.ContextVar`) |
| Thread safety | `global_lock` (`threading.Lock`) |
| Ownership enforcement | `config_owner_thread_id` / `config_owner_async_task` |
| Attribute-style access | `dotdict` from [dsp_utils_helpers](dsp_utils_helpers.md) |

---

## Core Component: `Settings`

`Settings` is a singleton class that behaves like a dictionary but supports attribute access. It is instantiated once at module load as the module-level `settings` object.

### Singleton Behavior

```python
class Settings:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
```

Every call to `Settings()` returns the same instance, ensuring a single global configuration object.

### Attribute and Item Access

`Settings` supports both attribute (`settings.lm`) and item (`settings["lm"]`) access, delegating to `__getattr__` / `__setattr__`:

```mermaid
flowchart LR
    A["settings.lm"] --> B{__getattr__}
    B --> C{in thread_local_overrides?}
    C -->|yes| D[return override]
    C -->|no| E{in main_thread_config?}
    E -->|yes| F[return global value]
    E -->|no| G[raise AttributeError]
```

- **Reads** (`__getattr__`, `__getitem__`): check thread-local overrides first, then fall back to the global config.
- **Writes** (`__setattr__`, `__setitem__`): route through `configure(...)`, which enforces ownership rules.
- **Membership** (`__contains__`): checks both overrides and global config.
- **`get(key, default)`**: safe access returning a default on `AttributeError`.

### Configuration Methods

| Method | Purpose |
|--------|---------|
| `configure(**kwargs)` | Update the global configuration (owner-restricted). |
| `context(**kwargs)` | Context manager for temporary, thread-local overrides. |
| `copy()` | Return a merged `dotdict` of global config + current overrides. |
| `config` (property) | Alias for `copy()`. |
| `lock` (property) | Exposes the global `threading.Lock`. |

---

## Configuration Model

### Two-Tier Resolution

Configuration values are resolved with a clear precedence: **thread-local overrides take priority over global config**.

```mermaid
flowchart TD
    START[Read settings.X] --> OV{thread_local_overrides<br/>contains X?}
    OV -->|yes| RET1[Return override value]
    OV -->|no| GL{main_thread_config<br/>contains X?}
    GL -->|yes| RET2[Return global value]
    GL -->|no| ERR[Raise AttributeError]
```

### Default Configuration

`DEFAULT_CONFIG` defines all recognized keys and their initial values. It is deep-copied into `main_thread_config` at import time.

| Key | Default | Description |
|-----|---------|-------------|
| `lm` | `None` | Active language model. |
| `adapter` | `None` | Active adapter for formatting prompts/responses. |
| `rm` | `None` | Active retrieval model. |
| `branch_idx` | `0` | Branch index for multi-branch execution. |
| `trace` | `[]` | Execution trace accumulator. |
| `callbacks` | `[]` | Registered callbacks. |
| `async_max_workers` | `8` | Max workers for async execution. |
| `send_stream` | `None` | Streaming sink. |
| `disable_history` | `False` | Disable history tracking. |
| `track_usage` | `False` | Enable usage tracking. |
| `usage_tracker` | `None` | Usage tracker instance. |
| `caller_predict` | `None` | Current calling predictor. |
| `caller_modules` | `None` | Current calling modules. |
| `stream_listeners` | `[]` | Registered stream listeners. |
| `provide_traceback` | `False` | Include tracebacks in error logs. |
| `num_threads` | `8` | Threads for parallel processing. |
| `max_errors` | `10` | Max errors before halting. |
| `allow_tool_async_sync_conversion` | `False` | Allow async tools in sync mode. |
| `max_history_size` | `10000` | Max history entries. |
| `max_trace_size` | `10000` | Max trace entries. |

---

## Ownership and Thread-Safety Rules

The `Settings` class enforces strict rules about *who* may mutate global configuration, preventing race conditions and inconsistent state.

```mermaid
flowchart TD
    CALL[configure called] --> T1{owner thread<br/>set?}
    T1 -->|no| SET[Set owner = current thread]
    T1 -->|yes| T2{current == owner?}
    T2 -->|no| ERR1[RuntimeError:<br/>only owner thread can configure]
    T2 -->|yes| T3{in async task?}
    SET --> T3
    T3 -->|no| OK[Apply config]
    T3 -->|yes| T4{owner async task set?}
    T4 -->|no| SETA[Set owner async task]
    T4 -->|yes| T5{in IPython?}
    SETA --> OK
    T5 -->|yes| OK
    T5 -->|no| T6{current task == owner task?}
    T6 -->|yes| OK
    T6 -->|no| ERR2[RuntimeError:<br/>use dspy.context instead]
```

### The Three Rules

1. **Only one thread may call `dspy.configure`.** The first thread to call it becomes the owner (`config_owner_thread_id`). Any other thread attempting to configure raises a `RuntimeError`.
2. **Global state is visible to all threads.** User threads can *read* the global config freely, but should not be mixed with concurrent `configure` calls from the owner.
3. **Any thread may use `dspy.context`.** Context overrides propagate to child threads created by DSPy primitives (e.g., `Parallel`, `asyncify`).

### Async Task Restrictions

Within an async context, `configure` is further restricted:
- The first async task to call `configure` becomes the owner (`config_owner_async_task`).
- Other async tasks must use `dspy.context(...)` instead.
- **IPython exception**: calls from an IPython environment are permitted regardless of task ownership, to support interactive notebooks.

---

## Context Manager: `dspy.context`

The `context` method provides temporary, thread-local configuration overrides without mutating global state.

```python
@contextmanager
def context(self, **kwargs):
    original_overrides = thread_local_overrides.get().copy()
    new_overrides = dotdict({**main_thread_config, **original_overrides, **kwargs})
    token = thread_local_overrides.set(new_overrides)
    try:
        yield
    finally:
        thread_local_overrides.reset(token)
```

### Behavior

- **Merges** the global config, existing overrides, and new `kwargs` (new values win).
- **Sets** the merged result into the `thread_local_overrides` `ContextVar`.
- **Restores** the previous state on exit via the `ContextVar` token, guaranteeing cleanup even on exceptions.

### Propagation to Child Threads

```mermaid
sequenceDiagram
    participant Main as Main Thread
    participant Ctx as ContextVar
    participant Child as Child Thread (ParallelExecutor)

    Main->>Ctx: context(lm=lm_a) sets overrides
    Main->>Child: spawn via ParallelExecutor
    Note over Child: copies overrides from ContextVar
    Child->>Child: reads settings.lm -> lm_a
    Main->>Ctx: exit context, reset token
    Note over Main: overrides cleared
```

Overrides propagate to child threads **only when** those threads are spawned using a `ParallelExecutor` that copies overrides. This is a deliberate design choice to avoid leaking context into unrelated threads.

---

## Data Flow

The following diagram illustrates how configuration flows from user calls into the global and context-local stores, and how components read it back.

```mermaid
flowchart LR
    subgraph User Code
        CONF["dspy.configure(lm=...)"]
        CTX["with dspy.context(lm=...):"]
        READ["settings.lm"]
    end

    subgraph Settings
        CFG[configure]
        CTXM[context]
        GET[__getattr__]
    end

    subgraph Storage
        MTC[main_thread_config]
        TLO[thread_local_overrides]
    end

    CONF --> CFG --> MTC
    CTX --> CTXM --> TLO
    READ --> GET
    GET --> TLO
    GET --> MTC
```

---

## Integration with the Broader System

`Settings` is consumed by virtually every DSPy subsystem. The table below maps key consumers to the configuration they read.

| Consumer Module | Configuration Used |
|-----------------|--------------------|
| [clients_core](clients_core.md) | `lm`, `rm`, `cache`-related settings |
| [adapters](adapters.md) | `adapter`, `callbacks` |
| [predict_core](predict_core.md) | `lm`, `adapter`, `trace`, `caller_predict` |
| [streaming](streaming.md) | `stream_listeners`, `send_stream` |
| [utils](utils.md) | `callbacks`, `usage_tracker`, `num_threads`, `max_errors` |
| [evaluate](evaluate.md) | `lm`, `num_threads` |
| [teleprompt_core](teleprompt_core.md) | `lm`, `trace`, `max_errors` |

### Dependency Diagram

```mermaid
graph TD
    SETTINGS[dsp_utils_settings]
    HELPERS[dsp_utils_helpers]
    CLIENTS[clients_core]
    ADAPTERS[adapters]
    PREDICT[predict_core]
    STREAM[streaming]
    UTILS[utils]
    EVAL[evaluate]
    TELE[teleprompt_core]

    SETTINGS --> HELPERS
    CLIENTS --> SETTINGS
    ADAPTERS --> SETTINGS
    PREDICT --> SETTINGS
    STREAM --> SETTINGS
    UTILS --> SETTINGS
    EVAL --> SETTINGS
    TELE --> SETTINGS
```

---

## Usage Examples

### Global Configuration

```python
import dspy

# First call establishes the owner thread.
dspy.configure(lm=dspy.LM("openai/gpt-4o"), num_threads=16)

# Read back
assert dspy.settings.lm is not None
```

### Temporary Context Override

```python
import dspy

with dspy.context(lm=dspy.LM("openai/gpt-4o-mini")):
    # Only this block sees the mini model.
    result = dspy.Predict("question -> answer")(question="...")

# Outside the block, the global lm is restored.
```

### Inspecting the Effective Config

```python
# Returns a merged dotdict of global config + current overrides.
effective = dspy.settings.config
print(effective["num_threads"])
```

---

## Summary

The `dsp_utils_settings` module is the configuration backbone of DSPy. Its `Settings` singleton provides:

- **A single, globally accessible configuration object** with attribute and item access.
- **A two-tier resolution model** where thread-local overrides shadow global values.
- **Strict ownership rules** ensuring only one thread/task mutates global state, while any thread may use scoped `context` overrides.
- **Safe propagation** of context overrides to child threads via DSPy's parallel primitives.

For the underlying `dotdict` data structure and other helpers, see [dsp_utils_helpers](dsp_utils_helpers.md).
