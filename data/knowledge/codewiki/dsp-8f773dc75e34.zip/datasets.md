# Datasets

## Overview

The **datasets** module provides the data-handling foundation for DSPy. It supplies:

- A base abstraction (`Dataset`) for defining train/dev/test splits with deterministic, seed-controlled shuffling and sampling.
- A flexible `DataLoader` for ingesting data from many external sources (HuggingFace Hub, CSV, JSON, Parquet, pandas, and retrieval modules) and converting them into DSPy `Example` objects.
- A collection of ready-to-use benchmark datasets (`Colors`, `GSM8K`, `HotPotQA`, `MATH`) with their associated metrics.
- An interactive, multi-process environment dataset (`AlfWorld`) for agentic/embodied tasks.

All datasets ultimately produce lists of [`Example`](primitives.md) objects — the universal data container in DSPy — which are consumed by [predictors](predict_core.md), [evaluation](evaluate.md), and [optimizers](teleprompt_core.md).

## Architecture

The module is organized into three layers: a **core infrastructure** layer, a set of **built-in benchmark datasets**, and a specialized **interactive environment** dataset.

```mermaid
graph TD
    subgraph Core["Core Infrastructure"]
        Dataset["Dataset<br/>(base class)"]
        DataLoader["DataLoader<br/>(ingestion)"]
    end

    subgraph Builtin["Built-in Datasets"]
        Colors["Colors"]
        GSM8K["GSM8K"]
        HotPotQA["HotPotQA"]
        MATH["MATH"]
    end

    subgraph Interactive["Interactive Environment"]
        AlfWorld["AlfWorld"]
        EnvPool["EnvPool"]
        EnvSession["_EnvSession"]
    end

    Dataset --> Colors
    Dataset --> HotPotQA
    DataLoader -.inherits.-> Dataset

    AlfWorld --> EnvPool
    EnvPool --> EnvSession

    Colors --> Example["dspy.Example"]
    GSM8K --> Example
    HotPotQA --> Example
    MATH --> Example
    DataLoader --> Example
    AlfWorld --> Example

    Example --> Downstream["Predictors /<br/>Evaluate /<br/>Optimizers"]
```

### Data Flow

The typical lifecycle of data through the module:

```mermaid
flowchart LR
    Source["External Source<br/>(HF Hub, CSV, JSON,<br/>Parquet, pandas, RM)"] --> Loader["DataLoader"]
    Loader --> Examples["list[dspy.Example]"]
    Examples --> Split["train_test_split /<br/>Dataset splits"]
    Split --> Consumer["Predictors,<br/>Evaluate,<br/>Optimizers"]
```

## Sub-modules

### Core Infrastructure — [datasets_core.md](datasets_core.md)

The backbone of the module.

- **`Dataset`** — the abstract base class. It manages `train`/`dev`/`test` splits, deterministic shuffling via seeds, lazy caching of splits, and the `prepare_by_seed` helper for multi-seed experiments. Subclasses only need to populate the private `_train`, `_dev`, and `_test` lists.
- **`DataLoader`** — a utility class (subclassing `Dataset`) offering `from_huggingface`, `from_csv`, `from_json`, `from_parquet`, `from_pandas`, and `from_rm` methods, plus `sample` and `train_test_split` helpers. It normalizes heterogeneous sources into `dspy.Example` objects.

See [datasets_core.md](datasets_core.md) for full details.

### Built-in Datasets — [datasets_builtin.md](datasets_builtin.md)

A set of ready-to-use benchmark datasets, each with its own loading logic and (where applicable) metric:

- **`Colors`** — a synthetic color-naming task built from a curated list of color names, split by suffix to avoid train/dev leakage.
- **`GSM8K`** — grade-school math word problems, with a `gsm8k_metric` for answer comparison.
- **`HotPotQA`** — multi-hop question answering over Wikipedia, restricted to "hard" examples.
- **`MATH`** — competition mathematics problems with boxed-answer extraction and a `metric` using `math_equivalence`.

See [datasets_builtin.md](datasets_builtin.md) for full details.

### Interactive Environment — [datasets_datasets_alfworld.md](datasets_datasets_alfworld.md)

- **`AlfWorld`** — an embodied, text-based environment dataset backed by a pool of worker processes.
- **`EnvPool`** / **`_EnvSession`** — a process pool and context-manager session abstraction that safely acquire, initialize, and step environments in parallel.

See [datasets_datasets_alfworld.md](datasets_datasets_alfworld.md) for full details.

## Component Relationships

```mermaid
classDiagram
    class Dataset {
        +train_size
        +train_seed
        +dev_size
        +test_size
        +train
        +dev
        +test
        +reset_seeds()
        +prepare_by_seed()
        +_shuffle_and_sample()
    }
    class DataLoader {
        +from_huggingface()
        +from_csv()
        +from_json()
        +from_parquet()
        +from_pandas()
        +from_rm()
        +sample()
        +train_test_split()
    }
    class Colors
    class HotPotQA
    class GSM8K
    class MATH
    class AlfWorld
    class EnvPool
    class _EnvSession

    DataLoader --|> Dataset
    Colors --|> Dataset
    HotPotQA --|> Dataset
    AlfWorld --> EnvPool
    EnvPool --> _EnvSession
```

## Integration with the Broader System

- **`dspy.Example`** ([primitives.md](primitives.md)) is the universal output type of every dataset and loader. `Dataset._shuffle_and_sample` attaches `dspy_uuid` and `dspy_split` metadata to each example.
- **`dotdict`** ([dsp_utils.md](dsp_utils.md)) is used by `Dataset.prepare_by_seed` to pass configuration as attribute-accessible dictionaries.
- Datasets feed directly into [predictors](predict_core.md), the [evaluate](evaluate.md) module, and [optimizers](teleprompt_core.md) such as `BootstrapFewShot` and `MIPROv2`.
- `DataLoader.from_rm` integrates with retrieval modules configured via `dspy.settings.rm` (see [retrievers.md](retrievers.md)).
