# dsp_utils

## Overview

The `dsp_utils` module provides the foundational, low-level utilities that the rest of DSPy relies on. It is intentionally small and dependency-light, and it is split into two concerns:

1. **Global configuration management** — a thread-safe, singleton-based settings system (`Settings`) that holds the active language model, adapter, retrieval model, callbacks, and many runtime knobs.
2. **General-purpose helpers** — a collection of small utilities including attribute-accessible dictionaries (`dotdict`, `dotdict_lax`), a no-op context manager (`NullContextManager`), and a variety of data-manipulation helpers (batching, grouping, zipping, flattening, etc.).

Because almost every other DSPy module reads configuration through `dspy.settings` and uses `dotdict` for ergonomic access to configuration values, `dsp_utils` sits at the very bottom of the dependency graph.

## Architecture

The module is composed of two files, each with a distinct responsibility:

```mermaid
graph TD
    subgraph dsp_utils
        Settings["settings.py<br/>Settings (singleton)"]
        Utils["utils.py<br/>dotdict / dotdict_lax / NullContextManager<br/>+ helper functions"]
    end

    Settings -->|uses dotdict for config| Utils

    subgraph Consumers
        Predict["predict_core"]
        Clients["clients_core"]
        Adapters["adapters"]
        Parallel["utils (ParallelExecutor)"]
        Everything["... all other DSPy modules"]
    end

    Everything -->|reads/writes config| Settings
    Everything -->|attribute access| Utils
    Parallel -->|propagates context overrides| Settings
```

### Key design principles

- **Singleton configuration**: `Settings` is a singleton (`settings = Settings()`), so all parts of DSPy share one configuration object.
- **Thread ownership**: Only the first thread (and first async task) that calls `configure` may mutate the global configuration. All other threads must use `context(...)` for temporary, thread-local overrides.
- **Context propagation**: `context(...)` uses `contextvars.ContextVar`, so overrides propagate to child threads/tasks spawned by DSPy primitives such as `ParallelExecutor` (see [utils](utils.md)).
- **Ergonomic access**: Configuration is stored in `dotdict` instances, allowing both `settings["lm"]` and `settings.lm` access styles.

## Sub-modules

### Configuration (`settings.py`)

The `Settings` singleton is the central configuration registry for DSPy. It exposes:

- `configure(**kwargs)` — set global configuration values (owner thread only).
- `context(**kwargs)` — a context manager for temporary, thread-local overrides.
- Attribute/item access (`settings.lm`, `settings["lm"]`), `get`, `copy`, `config`, and `__contains__`.

See [dsp_utils_settings](dsp_utils_settings.md) for full details on the singleton, thread/async ownership rules, and the default configuration schema.

### Utilities (`utils.py`)

A grab-bag of helpers. The most important are the attribute-accessible dictionaries and the no-op context manager, but the file also contains many data-manipulation helpers used across DSPy (batching, grouping, zipping, flattening, file progress bars, etc.).

See [dsp_utils_helpers](dsp_utils_helpers.md) for the full catalog of helper functions and the `dotdict` / `dotdict_lax` / `NullContextManager` classes.

## How the module fits into the system

```mermaid
flowchart LR
    subgraph Foundation
        Settings
        dotdict
    end

    Settings -->|provides lm, adapter, rm, callbacks| Predict["predict_core"]
    Settings -->|provides lm, cache, provider| Clients["clients_core"]
    Settings -->|provides adapter| Adapters["adapters"]
    Settings -->|provides stream_listeners, callbacks| Streaming["streaming"]
    Settings -->|provides usage_tracker| Utils2["utils (UsageTracker)"]

    dotdict -->|config storage| Settings
    dotdict -->|ergonomic dicts| Everything["all modules"]
```

- **`predict_core`** reads `settings.lm`, `settings.adapter`, and `settings.caller_predict` to drive prediction.
- **`clients_core`** reads `settings.lm`, `settings.cache`, and provider configuration.
- **`adapters`** reads `settings.adapter` and `settings.provide_traceback`.
- **`streaming`** reads `settings.stream_listeners` and `settings.send_stream`.
- **`utils`** (`ParallelExecutor`) relies on `Settings.context` to propagate overrides to worker threads.

## Related documentation

- [dsp_utils_settings](dsp_utils_settings.md) — the `Settings` singleton and configuration system.
- [dsp_utils_helpers](dsp_utils_helpers.md) — `dotdict`, `dotdict_lax`, `NullContextManager`, and helper functions.
- [utils](utils.md) — higher-level utilities such as `ParallelExecutor` that build on `Settings.context`.
- [predict_core](predict_core.md) — primary consumer of the configuration.
- [clients_core](clients_core.md) — language model and provider clients configured via `Settings`.
