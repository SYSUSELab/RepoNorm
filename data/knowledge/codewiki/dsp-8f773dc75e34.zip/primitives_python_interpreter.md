# Python Interpreter Module

## Introduction

The `primitives_python_interpreter` module provides a secure, sandboxed Python execution environment for DSPy. It is built on top of [Deno](https://docs.deno.com/runtime/getting_started/installation/) and [Pyodide](https://pyodide.org/), allowing DSPy programs to generate and execute arbitrary Python code while enforcing fine-grained security policies around file system access, environment variables, and network connectivity.

This module is a foundational primitive used by code-generating DSPy modules such as [`ProgramOfThought`](predict_advanced_program_synthesis.md) and [`CodeAct`](predict_advanced_agents.md), which rely on it to run LLM-generated Python programs safely.

**Core components:**

| Component | Description |
|-----------|-------------|
| `PythonInterpreter` | A context-manager class that launches and communicates with a Deno/Pyodide sandbox subprocess to execute Python code. |
| `InterpreterError` | A `RuntimeError` subclass raised for sandbox-related failures (missing Deno, invalid variables, execution errors, etc.). |

---

## Architecture Overview

The interpreter acts as a bridge between the host Python process and an isolated Deno runtime that hosts a Pyodide (WebAssembly Python) environment. Communication happens over the subprocess's standard input/output using newline-delimited JSON messages.

```mermaid
graph TD
    subgraph Host["Host Python Process"]
        PI["PythonInterpreter"]
        User["Caller<br/>(ProgramOfThought / CodeAct / user code)"]
    end

    subgraph Sandbox["Deno Sandbox Subprocess"]
        Runner["runner.js"]
        Pyodide["Pyodide<br/>(WASM Python)"]
        VFS["Virtual File System<br/>/sandbox/*"]
    end

    User -->|"execute(code, variables)"| PI
    PI -->|"stdin: JSON {code}"| Runner
    Runner -->|"eval"| Pyodide
    Pyodide -->|"stdout: JSON {output/error}"| PI
    PI -->|"mount_file / sync_file"| VFS
    VFS -.->|"sync back"| Host
```

### Key Design Points

- **Process isolation**: Code runs in a separate Deno subprocess, not in the host interpreter.
- **JSON line protocol**: Each request/response is a single JSON line, enabling simple, robust IPC.
- **Lazy process lifecycle**: The Deno subprocess is started on first use and can be reused across multiple `execute` calls.
- **Opt-in capabilities**: File read/write, environment variables, and network access are all disabled by default and must be explicitly enabled.

---

## Component Details

### `InterpreterError`

A lightweight exception type (`RuntimeError` subclass) used to signal all interpreter-level failures, including:

- Deno executable not found
- Invalid variable names passed to `execute`
- Unsupported value types during serialization
- Sandbox execution errors (non-`SyntaxError`)

`SyntaxError` from the sandbox is re-raised as a native Python `SyntaxError` so callers can distinguish syntax problems from runtime problems.

### `PythonInterpreter`

The main class. It is designed to be used as a context manager:

```python
code_string = "print('Hello'); 1 + 2"
with PythonInterpreter() as interp:
    output = interp(code_string)
```

#### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `deno_command` | `list[str] \| None` | `None` | Custom command list to launch Deno. If omitted, a default command is constructed. |
| `enable_read_paths` | `list[PathLike \| str] \| None` | `None` | Files/directories the sandbox may read. |
| `enable_write_paths` | `list[PathLike \| str] \| None` | `None` | Files/directories the sandbox may write (and sync back to host). |
| `enable_env_vars` | `list[str] \| None` | `None` | Environment variable names exposed to the sandbox. |
| `enable_network_access` | `list[str] \| None` | `None` | Domains/IPs the sandbox may access over the network. |
| `sync_files` | `bool` | `True` | Whether to sync sandbox file changes back to the host after execution. |

When `deno_command` is not provided, the interpreter builds a Deno invocation with the appropriate `--allow-*` flags based on the enabled capabilities, then appends the path to `runner.js`.

#### Public Methods

| Method | Description |
|--------|-------------|
| `execute(code, variables=None)` | Injects `variables` as Python assignments, sends `code` to the sandbox, and returns the result. |
| `__call__(code, variables=None)` | Alias for `execute`, allowing `interp(code)` usage. |
| `__enter__` / `__exit__` | Context-manager support; `__exit__` calls `shutdown()`. |
| `shutdown()` | Gracefully terminates the Deno subprocess. |

#### Internal Methods

| Method | Purpose |
|--------|---------|
| `_get_runner_path()` | Resolves the path to the bundled `runner.js`. |
| `_mount_files()` | Sends `mount_file` messages to expose host files at `/sandbox/<basename>` inside the sandbox. |
| `_sync_files()` | Sends `sync_file` messages to copy sandbox changes back to host files. |
| `_ensure_deno_process()` | Lazily starts (or restarts) the Deno subprocess; raises `InterpreterError` with install instructions if Deno is missing. |
| `_inject_variables()` | Prepends `name = value` assignments for each provided variable. |
| `_serialize_value()` | Safely serializes supported value types (`str`, `int`, `float`, `bool`, `None`, `list`, `dict`) into Python literals. |

---

## Execution Flow

The following sequence diagram illustrates a typical `execute` call, including file mounting and syncing.

```mermaid
sequenceDiagram
    participant U as Caller
    participant PI as PythonInterpreter
    participant D as Deno Subprocess

    U->>PI: execute(code, variables)
    PI->>PI: _inject_variables(code, variables)
    PI->>PI: _ensure_deno_process()
    PI->>D: (spawn if needed)
    PI->>PI: _mount_files()
    PI->>D: {"mount_file": ..., "virtual_path": ...}
    PI->>D: {"code": "<injected code>"}
    D->>D: Run code in Pyodide
    D-->>PI: {"output": ...} or {"error": ..., "errorType": ...}
    alt errorType == "FinalAnswer"
        PI->>PI: result["output"] = errorArgs
    else errorType == "SyntaxError"
        PI->>U: raise SyntaxError
    else other error
        PI->>U: raise InterpreterError
    end
    PI->>PI: _sync_files()
    PI->>D: {"sync_file": ..., "host_file": ...}
    PI-->>U: result["output"]
```

### The `FinalAnswer` Convention

The sandbox uses a special mechanism to return structured results. When generated code calls a preloaded `final_answer(...)` function, the sandbox reports it as an `error` with `errorType == "FinalAnswer"`. The interpreter detects this and extracts the actual return value from `errorArgs`, treating it as the successful output. This convention is what allows modules like `ProgramOfThought` to retrieve computed answers from executed code.

---

## Security Model

The interpreter follows a **deny-by-default** security posture. All capabilities must be explicitly granted at construction time.

```mermaid
graph LR
    subgraph Default["Default (Deno flags)"]
        R["--allow-read"]
    end
    subgraph OptIn["Opt-in Capabilities"]
        W["--allow-write=<paths>"]
        E["--allow-env=<vars>"]
        N["--allow-net=<domains>"]
    end
    Default --> Sandbox["Deno Sandbox"]
    OptIn --> Sandbox
```

| Capability | Flag | Notes |
|------------|------|-------|
| Read | `--allow-read` | Always enabled by default. |
| Write | `--allow-write=<paths>` | Only the listed paths are writable. |
| Env vars | `--allow-env=<vars>` | Only the listed variable names are exposed. |
| Network | `--allow-net=<domains>` | Only the listed domains/IPs are reachable. |
| Run | *(not supported)* | `--allow-run` is intentionally omitted; see the TODO in the source regarding proxying `subprocess.run` through `Deno.run()`. |

> **Note:** File paths are mounted into the sandbox at `/sandbox/<basename>`. Only the basename is used, so files with the same basename in different directories would collide.

---

## Integration with DSPy Modules

`PythonInterpreter` is consumed by higher-level code-generating modules. These modules instantiate an interpreter (or accept one via their `interpreter` parameter) and call `execute` on LLM-generated code.

```mermaid
graph TD
    POT["ProgramOfThought<br/>(predict_advanced_program_synthesis)"]
    CA["CodeAct<br/>(predict_advanced_agents)"]
    PI["PythonInterpreter"]

    POT -->|"interpreter.execute(code)"| PI
    CA -->|"interpreter(code)"| PI
    POT -->|"interpreter.shutdown()"| PI
    CA -->|"interpreter.shutdown()"| PI
```

- **[`ProgramOfThought`](predict_advanced_program_synthesis.md)** generates Python code to solve a problem, executes it via the interpreter, and retries on error up to `max_iters`. It calls `interpreter.shutdown()` when finished.
- **[`CodeAct`](predict_advanced_agents.md)** combines code generation with tool use, injecting tool source code into the interpreter and iteratively executing generated snippets.

Both modules accept an optional `interpreter` argument, enabling interpreter reuse and shared configuration (e.g., enabling specific file paths or network access).

---

## Usage Examples

### Basic Execution

```python
from dspy.primitives.python_interpreter import PythonInterpreter

with PythonInterpreter() as interp:
    result = interp("print('Hello'); 1 + 2")
    print(result)
```

### Passing Variables

```python
with PythonInterpreter() as interp:
    result = interp("x + y", variables={"x": 3, "y": 4})
    # result == 7
```

### Enabling File and Network Access

```python
with PythonInterpreter(
    enable_read_paths=["/data/input.csv"],
    enable_write_paths=["/data/output.csv"],
    enable_env_vars=["API_KEY"],
    enable_network_access=["api.example.com"],
) as interp:
    interp("import os; print(os.environ['API_KEY'])")
```

### Reusing an Interpreter Across Modules

```python
interp = PythonInterpreter(enable_network_access=["api.example.com"])
pot = dspy.ProgramOfThought("question -> answer", interpreter=interp)
```

---

## Error Handling

| Scenario | Raised Exception |
|----------|------------------|
| Deno not installed | `InterpreterError` (with install instructions) |
| Invalid variable name | `InterpreterError` |
| Unsupported variable value type | `InterpreterError` |
| Sandbox syntax error | `SyntaxError` |
| Sandbox runtime error | `InterpreterError` |
| No output from subprocess | `InterpreterError` (includes stderr) |

Callers should generally catch `InterpreterError` for sandbox failures and `SyntaxError` for code-generation syntax problems. Modules like `ProgramOfThought` catch broad `Exception` during execution and feed the error message back into a regeneration loop.

---

## Prerequisites

- **Deno** must be installed and available on `PATH`. Installation:
  - `curl -fsSL https://deno.land/install.sh | sh`
  - or, on macOS with Homebrew: `brew install deno`
  - See the [Deno installation guide](https://docs.deno.com/runtime/getting_started/installation/).

The interpreter bundles a `runner.js` file (located alongside `python_interpreter.py`) that bootstraps Pyodide and implements the JSON line protocol.

---

## Related Modules

- [predict_advanced_program_synthesis.md](predict_advanced_program_synthesis.md) — `ProgramOfThought`, a primary consumer of the interpreter.
- [predict_advanced_agents.md](predict_advanced_agents.md) — `CodeAct`, which combines the interpreter with tool use.
- [primitives_module.md](primitives_module.md) — `Module` / `BaseModule`, the base classes for DSPy modules.
- [primitives_prediction.md](primitives_prediction.md) — `Prediction`, the output type returned by code-generating modules.
