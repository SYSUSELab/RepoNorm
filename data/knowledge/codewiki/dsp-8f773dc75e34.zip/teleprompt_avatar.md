# Teleprompt Avatar

## Introduction

The `teleprompt_avatar` module provides **`AvatarOptimizer`**, a teleprompter (optimizer) that automatically improves the instructions of an [`Avatar`](predict_avatar.md) agent. The `Avatar` agent is a tool-using DSPy module that iteratively decides which tool to call and with what input to accomplish a goal.

Unlike optimizers that tune few-shot demonstrations or model weights, `AvatarOptimizer` performs **instruction optimization**: it evaluates the agent on a training set, separates the inputs into "positive" (high-scoring) and "negative" (low-scoring) groups, asks an LLM to compare the two groups and produce feedback, and then rewrites the agent's instruction based on that feedback. This loop repeats for a configurable number of iterations, keeping the best-performing instruction.

This module is part of the broader [teleprompt](teleprompt_core.md) family of optimizers and builds directly on top of the [predict_avatar](predict_avatar.md) module.

---

## Core Components

The module is implemented in a single file, `dspy/teleprompt/avatar_optimizer.py`, and consists of four core components:

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `AvatarOptimizer` | Class (subclass of `Teleprompter`) | Orchestrates the optimization loop. |
| `Comparator` | `dspy.Signature` | LLM signature that contrasts positive vs. negative inputs and produces feedback. |
| `FeedbackBasedInstruction` | `dspy.Signature` | LLM signature that rewrites the instruction using the feedback. |
| `EvalResult` | Pydantic `BaseModel` | Structured container for a single evaluated example (inputs, score, actions). |

---

## Architecture

`AvatarOptimizer` sits between the user's training data and the `Avatar` agent. It uses two LLM-backed signatures (`Comparator` and `FeedbackBasedInstruction`) as its "reasoning engine" and delegates execution to the `Avatar` agent.

```mermaid
graph TD
    User[User / Caller] -->|compile student, trainset| AO[AvatarOptimizer]
    AO -->|deepcopy + evaluate| Avatar[Avatar Agent]
    Avatar -->|uses| Tools[Tools + Finish]
    Avatar -->|returns| Pred[Prediction + actions]
    AO -->|metric example, prediction| Metric[metric function]
    AO -->|pos/neg EvalResults| Comparator[Comparator Signature]
    Comparator -->|feedback| FBI[FeedbackBasedInstruction Signature]
    FBI -->|new_instruction| AO
    AO -->|with_instructions| Avatar
    AO -->|best_actor| User

    subgraph "LLM-backed reasoning"
        Comparator
        FBI
    end
```

### Component Relationships

```mermaid
classDiagram
    class Teleprompter {
        +compile(student, trainset, ...)
        +get_params()
    }
    class AvatarOptimizer {
        +metric: Callable
        +max_iters: int
        +lower_bound: int
        +upper_bound: int
        +max_positive_inputs: int
        +max_negative_inputs: int
        +optimize_for: str
        +comparator: TypedPredictor
        +feedback_instruction: Predict
        +process_example(actor, example, return_outputs)
        +thread_safe_evaluator(devset, actor, ...)
        +_get_pos_neg_results(actor, trainset)
        +compile(student, trainset)
    }
    class Comparator {
        <<Signature>>
        +instruction: str
        +actions: list~str~
        +pos_input_with_metrics: list~EvalResult~
        +neg_input_with_metrics: list~EvalResult~
        +feedback: str
    }
    class FeedbackBasedInstruction {
        <<Signature>>
        +previous_instruction: str
        +feedback: str
        +new_instruction: str
    }
    class EvalResult {
        +example: dict
        +score: float
        +actions: list~ActionOutput~
    }

    Teleprompter <|-- AvatarOptimizer
    AvatarOptimizer --> Comparator : uses
    AvatarOptimizer --> FeedbackBasedInstruction : uses
    Comparator ..> EvalResult : consumes
    FeedbackBasedInstruction ..> Comparator : consumes feedback
```

---

## Optimization Process Flow

The `compile` method implements the main optimization loop. Each iteration evaluates the current best agent, samples positive and negative examples, generates feedback, and produces a new instruction.

```mermaid
flowchart TD
    Start([compile student, trainset]) --> Init[best_actor = deepcopy student<br/>best_score = -999 or 999]
    Init --> Loop{iteration < max_iters?}
    Loop -->|yes| Eval[_get_pos_neg_results<br/>thread_safe_evaluator]
    Eval --> Split[Split results into<br/>pos_inputs / neg_inputs]
    Split --> Check{pos and neg<br/>non-empty?}
    Check -->|no| Error[Raise ValueError<br/>adjust bounds or data]
    Check -->|yes| Sample[Sample up to<br/>max_positive/negative_inputs]
    Sample --> Compare[Comparator<br/>instruction, actions, pos, neg]
    Compare --> Feedback[feedback]
    Feedback --> Rewrite[FeedbackBasedInstruction<br/>previous_instruction, feedback]
    Rewrite --> NewInstr[new_instruction]
    NewInstr --> Improve{score improves<br/>best_score?}
    Improve -->|yes| Update[best_actor.actor.signature =<br/>with_instructions new_instruction<br/>best_score = score]
    Improve -->|no| Skip[Keep current best]
    Update --> Loop
    Skip --> Loop
    Loop -->|no| Return([return best_actor])
```

### Step-by-step

1. **Initialize** — `best_actor` is a deep copy of the student `Avatar`; `best_score` is set to `-999` (for `optimize_for="max"`) or `999` (for `optimize_for="min"`).
2. **Evaluate** — `_get_pos_neg_results` runs `thread_safe_evaluator` over the training set, computing a metric score for each example.
3. **Classify** — Examples scoring `>= upper_bound` become positive inputs; examples scoring `<= lower_bound` become negative inputs. Both are wrapped in `EvalResult` objects.
4. **Sample** — If there are more positive/negative inputs than the configured maxima, a random sample is taken to keep the LLM prompt bounded.
5. **Compare** — The `Comparator` signature receives the current instruction, the list of tools, and the positive/negative inputs, and returns textual `feedback`.
6. **Rewrite** — The `FeedbackBasedInstruction` signature takes the previous instruction plus the feedback and produces a `new_instruction`.
7. **Accept/Reject** — If the new score improves on `best_score` (respecting `optimize_for`), the agent's signature is updated with the new instruction and `best_score` is updated.
8. **Repeat** — Steps 2–7 repeat for `max_iters` iterations, then the best agent is returned.

---

## Data Flow

```mermaid
sequenceDiagram
    participant U as User
    participant AO as AvatarOptimizer
    participant AV as Avatar Agent
    participant M as metric
    participant C as Comparator
    participant F as FeedbackBasedInstruction

    U->>AO: compile(student, trainset)
    loop max_iters
        AO->>AV: actor(**example.inputs())
        AV-->>AO: prediction (with actions)
        AO->>M: metric(example, prediction)
        M-->>AO: score
        AO->>AO: split into pos/neg EvalResults
        AO->>C: instruction, actions, pos, neg
        C-->>AO: feedback
        AO->>F: previous_instruction, feedback
        F-->>AO: new_instruction
        AO->>AV: with_instructions(new_instruction) [if improved]
    end
    AO-->>U: best_actor
```

---

## Component Details

### `AvatarOptimizer`

The main teleprompter class, subclassing [`Teleprompter`](teleprompt_core.md).

**Constructor parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `metric` | `Callable` | *(required)* | Scoring function `metric(example, prediction) -> float`. Cannot be `None`. |
| `max_iters` | `int` | `10` | Number of optimization iterations. |
| `lower_bound` | `int` | `0` | Scores `<= lower_bound` are classified as negative. |
| `upper_bound` | `int` | `1` | Scores `>= upper_bound` are classified as positive. |
| `max_positive_inputs` | `int \| None` | `None` (→ `10`) | Cap on positive examples passed to the comparator. |
| `max_negative_inputs` | `int \| None` | `None` (→ `10`) | Cap on negative examples passed to the comparator. |
| `optimize_for` | `str` | `"max"` | Whether to maximize (`"max"`) or minimize (`"min"`) the metric. |

**Key methods:**

- **`process_example(actor, example, return_outputs)`** — Deep-copies the actor, runs it on a single example, and computes the metric. Exceptions are caught and yield a score of `0` (or `(example, None, 0)` when `return_outputs=True`).
- **`thread_safe_evaluator(devset, actor, return_outputs=False, num_threads=None)`** — Evaluates the actor over the devset in parallel using a `ThreadPoolExecutor` (defaulting to `dspy.settings.num_threads`). Returns the average metric, optionally with per-example results.
- **`_get_pos_neg_results(actor, trainset)`** — Runs the evaluator and partitions results into positive/negative `EvalResult` lists. Raises `ValueError` if either list is empty.
- **`compile(student, *, trainset)`** — The main optimization entry point (see process flow above).

### `Comparator` (Signature)

An LLM signature that performs three tasks: (1) contrast patterns between good and bad inputs, (2) review the computational logic of prior actions for inconsistencies, and (3) specify tool-usage modifications to improve negative inputs.

- **Inputs:** `instruction`, `actions` (list of tool strings), `pos_input_with_metrics`, `neg_input_with_metrics` (both `list[EvalResult]`).
- **Output:** `feedback`.

### `FeedbackBasedInstruction` (Signature)

An LLM signature that incorporates the comparator's feedback into a new, detailed instruction (max 3 paragraphs) while retaining the general guidelines of the previous instruction.

- **Inputs:** `previous_instruction`, `feedback`.
- **Output:** `new_instruction`.

### `EvalResult` (Pydantic Model)

A structured record of a single evaluated example:

- `example: dict` — the input fields of the example.
- `score: float` — the metric score.
- `actions: list[ActionOutput] | None` — the actions the agent took (from [`predict_avatar`](predict_avatar.md)).

---

## Dependencies

```mermaid
graph LR
    AO[avatar_optimizer.py] --> TP[teleprompt.Teleprompter]
    AO --> AV[dspy.predict.avatar.ActionOutput]
    AO --> DSPY[dspy core: Signature, InputField, OutputField, TypedPredictor, Predict, Module, Example, settings]
    AO --> PYD[pydantic.BaseModel]
    AO --> TQDM[tqdm]
    AO --> CONC[concurrent.futures.ThreadPoolExecutor]
```

| Dependency | Purpose |
|------------|---------|
| [`Teleprompter`](teleprompt_core.md) | Base class defining the `compile` interface. |
| [`ActionOutput`](predict_avatar.md) | Captures the tool name, input query, and output for each action. |
| `dspy.Signature`, `dspy.InputField`, `dspy.OutputField` | Define the `Comparator` and `FeedbackBasedInstruction` signatures. |
| `dspy.TypedPredictor`, `dspy.Predict` | Instantiate the signatures as callable predictors. |
| `dspy.settings.num_threads` | Default thread count for parallel evaluation. |
| `pydantic.BaseModel` | Backs `EvalResult`. |
| `tqdm` | Progress bar during evaluation. |
| `ThreadPoolExecutor` | Parallel example processing. |

---

## Usage Example

```python
import dspy
from dspy.teleprompt.avatar_optimizer import AvatarOptimizer
from dspy.predict.avatar import Avatar, Tool

# Define tools and an Avatar agent
tools = [Tool(tool=search, name="Search", desc="Search the web")]
agent = Avatar("Answer the question using tools.", tools=tools)

# Define a metric
def metric(example, prediction):
    return float(example.answer.lower() in prediction.answer.lower())

# Optimize the agent's instruction
optimizer = AvatarOptimizer(
    metric=metric,
    max_iters=5,
    lower_bound=0,
    upper_bound=1,
    optimize_for="max",
)
optimized_agent = optimizer.compile(agent, trainset=trainset)
```

---

## Related Modules

- [predict_avatar](predict_avatar.md) — The `Avatar` agent, `Tool`, `Action`, and `ActionOutput` types that this optimizer targets.
- [teleprompt_core](teleprompt_core.md) — The `Teleprompter` base class and other core optimizers.
- [teleprompt_optimizers](teleprompt_optimizers.md) — Other instruction/demonstration optimizers (COPRO, MIPROv2, SIMBA, etc.).
- [evaluate](evaluate.md) — Evaluation utilities that can supply metrics for optimization.
- [primitives](primitives.md) — `Module`, `Example`, and `Prediction` primitives used throughout.
