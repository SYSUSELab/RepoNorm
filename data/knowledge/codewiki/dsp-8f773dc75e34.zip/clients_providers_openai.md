# OpenAI Provider Module

## Introduction

The `clients_providers_openai` module implements DSPy's integration with OpenAI's platform, providing two core capabilities:

1. **Model discovery** — Detecting whether a given model string refers to an OpenAI-hosted model (including fine-tuned variants).
2. **Fine-tuning orchestration** — Managing the full lifecycle of an OpenAI fine-tuning job: data validation, file upload, remote training, status polling, and retrieval of the resulting fine-tuned model.

This module is one of several provider implementations in the `clients_providers` family. It specializes the abstract [`Provider`](clients_core_provider.md) and [`TrainingJob`](clients_core_provider.md) contracts defined in the core clients layer.

**Core components:**

| Component | File | Role |
|-----------|------|------|
| `OpenAIProvider` | `dspy/clients/openai.py` | Static provider implementation for OpenAI models and fine-tuning |
| `TrainingJobOpenAI` | `dspy/clients/openai.py` | OpenAI-specific training job with provider file/job tracking and cancellation |

---

## Architecture

The module sits between DSPy's generic client/provider abstraction and the official `openai` Python SDK. It inherits shared behavior from the core provider layer and delegates all network operations to the SDK.

```mermaid
graph TD
    subgraph "Core Clients Layer"
        Provider["Provider<br/>(abstract)"]
        TrainingJob["TrainingJob<br/>(abstract Future)"]
        TrainDataFormat["TrainDataFormat"]
        TrainingStatus["TrainingStatus"]
        save_data["save_data()"]
    end

    subgraph "clients_providers_openai"
        OpenAIProvider["OpenAIProvider"]
        TrainingJobOpenAI["TrainingJobOpenAI"]
    end

    subgraph "External"
        SDK["openai SDK"]
        API["OpenAI API"]
    end

    Provider --> OpenAIProvider
    TrainingJob --> TrainingJobOpenAI
    TrainDataFormat --> OpenAIProvider
    TrainingStatus --> OpenAIProvider
    save_data --> OpenAIProvider

    OpenAIProvider --> SDK
    TrainingJobOpenAI --> SDK
    SDK --> API
```

### Class Relationships

```mermaid
classDiagram
    class Provider {
        +bool finetunable
        +bool reinforceable
        +TrainingJob TrainingJob
        +is_provider_model(model) bool
        +finetune(job, model, train_data, train_data_format, train_kwargs) str
    }
    class TrainingJob {
        +Thread thread
        +str model
        +list train_data
        +TrainDataFormat train_data_format
        +dict train_kwargs
        +cancel()
        +status() TrainingStatus
    }
    class OpenAIProvider {
        +bool finetunable = True
        +TrainingJobOpenAI TrainingJob
        +is_provider_model(model) bool
        +finetune(job, model, train_data, train_data_format, train_kwargs) str
        +does_job_exist(job_id) bool
        +does_file_exist(file_id) bool
        +is_terminal_training_status(status) bool
        +get_training_status(job_id) TrainingStatus
        +validate_data_format(data_format)
        +upload_data(data_path) str
        +wait_for_job(job, poll_frequency)
        +get_trained_model(job) str
    }
    class TrainingJobOpenAI {
        +str provider_file_id
        +str provider_job_id
        +cancel()
        +status() TrainingStatus
    }

    Provider <|-- OpenAIProvider
    TrainingJob <|-- TrainingJobOpenAI
    OpenAIProvider ..> TrainingJobOpenAI : creates
```

---

## OpenAIProvider

`OpenAIProvider` is a stateless (all-static-methods) implementation of the [`Provider`](clients_core_provider.md) interface. Its constructor sets `finetunable = True` and binds `TrainingJob = TrainingJobOpenAI`, signaling to DSPy that this provider supports fine-tuning.

### Model Detection

`is_provider_model(model)` determines whether a model string belongs to OpenAI:

1. Strips the optional `openai/` provider prefix via `_remove_provider_prefix`.
2. Checks membership in the hard-coded `_OPENAI_MODELS` list (GPT-4 family, GPT-3.5, o1 models, embeddings, TTS, DALL·E, Whisper, etc.).
3. Matches fine-tuned model names using the RegEx pattern `ft:([^:]+):`, verifying the base model is a known OpenAI model.

> **Note:** The model list is static. The code comments flag a future enhancement to query `openai.models.list()` instead, which would require an API key.

### Fine-Tuning Pipeline

The `finetune` static method orchestrates the end-to-end training flow:

```mermaid
sequenceDiagram
    participant Caller
    participant OpenAIProvider
    participant save_data
    participant SDK as openai SDK
    participant API as OpenAI API

    Caller->>OpenAIProvider: finetune(job, model, train_data, format, kwargs)
    OpenAIProvider->>OpenAIProvider: _remove_provider_prefix(model)
    OpenAIProvider->>OpenAIProvider: validate_data_format(format)
    OpenAIProvider->>save_data: save_data(train_data)
    save_data-->>OpenAIProvider: data_path (.jsonl)
    OpenAIProvider->>SDK: files.create(purpose="fine-tune")
    SDK->>API: upload file
    API-->>SDK: file id
    SDK-->>OpenAIProvider: provider_file_id
    OpenAIProvider->>OpenAIProvider: job.provider_file_id = id
    OpenAIProvider->>SDK: fine_tuning.jobs.create(...)
    SDK->>API: start job
    API-->>SDK: job id
    SDK-->>OpenAIProvider: provider_job_id
    OpenAIProvider->>OpenAIProvider: job.provider_job_id = id
    OpenAIProvider->>OpenAIProvider: wait_for_job(job)
    OpenAIProvider->>OpenAIProvider: get_trained_model(job)
    OpenAIProvider-->>Caller: finetuned_model_name
```

**Steps in detail:**

| Step | Method | Description |
|------|--------|-------------|
| 1 | `validate_data_format` | Ensures the format is `CHAT` or `COMPLETION`; raises `ValueError` otherwise |
| 2 | `save_data` | Serializes training data to a hashed `.jsonl` file (see [clients_finetune_utils](clients_finetune_utils.md)) |
| 3 | `upload_data` | Uploads the file with `purpose="fine-tune"`, returns the file ID |
| 4 | `_start_remote_training` | Creates the fine-tuning job with model, training file, and hyperparameters |
| 5 | `wait_for_job` | Polls job events and status until a terminal state is reached |
| 6 | `get_trained_model` | Retrieves the fine-tuned model name (only if status is `succeeded`) |

### Status & Lifecycle Helpers

- **`get_training_status(job_id)`** — Maps OpenAI's provider statuses to DSPy's [`TrainingStatus`](clients_finetune_utils.md) enum:

  | OpenAI status | DSPy `TrainingStatus` |
  |---------------|----------------------|
  | `validating_files` | `pending` |
  | `queued` | `pending` |
  | `running` | `running` |
  | `succeeded` | `succeeded` |
  | `failed` | `failed` |
  | `cancelled` | `cancelled` |

  Returns `not_started` when `job_id` is `None`.

- **`is_terminal_training_status(status)`** — Returns `True` for `succeeded`, `failed`, or `cancelled`.
- **`does_job_exist(job_id)`** / **`does_file_exist(file_id)`** — Probe the API via `retrieve` calls, returning `False` on any exception.
- **`wait_for_job(job, poll_frequency=20)`** — Polls every 20 seconds, printing estimated finish time (once) and new job events as they arrive.

---

## TrainingJobOpenAI

`TrainingJobOpenAI` extends the abstract [`TrainingJob`](clients_core_provider.md) (itself a `Future`) to track OpenAI-specific identifiers and implement cancellation.

### State

| Attribute | Description |
|-----------|-------------|
| `provider_file_id` | ID of the uploaded training file on OpenAI |
| `provider_job_id` | ID of the remote fine-tuning job on OpenAI |

### Cancellation Flow

`cancel()` performs a two-phase cleanup before delegating to the parent `Future.cancel()`:

```mermaid
flowchart TD
    Start([cancel called]) --> JobExists{provider_job_id<br/>exists?}
    JobExists -- Yes --> Terminal{status is<br/>terminal?}
    Terminal -- Yes --> Raise[Raise Exception:<br/>cannot cancel completed job]
    Terminal -- No --> CancelJob[openai.fine_tuning.jobs.cancel]
    CancelJob --> ClearJob[provider_job_id = None]
    JobExists -- No --> FileCheck
    ClearJob --> FileCheck{provider_file_id<br/>exists?}
    FileCheck -- Yes --> DeleteFile[openai.files.delete]
    DeleteFile --> ClearFile[provider_file_id = None]
    FileCheck -- No --> Super
    ClearFile --> Super[super().cancel]
    Super --> End([done])
```

### Status

`status()` delegates to `OpenAIProvider.get_training_status(self.provider_job_id)`, returning the mapped [`TrainingStatus`](clients_finetune_utils.md).

---

## Dependencies

```mermaid
graph LR
    subgraph "This Module"
        openai_py["dspy/clients/openai.py"]
    end
    subgraph "Internal"
        provider["dspy/clients/provider.py"]
        utils_finetune["dspy/clients/utils_finetune.py"]
        hasher["dspy/utils/hasher.py"]
    end
    subgraph "External"
        openai_sdk["openai"]
        stdlib["re, time, datetime, typing"]
    end

    openai_py --> provider
    openai_py --> utils_finetune
    utils_finetune --> hasher
    openai_py --> openai_sdk
    openai_py --> stdlib
```

| Dependency | Purpose |
|------------|---------|
| [`dspy.clients.provider`](clients_core_provider.md) | Base `Provider` and `TrainingJob` contracts |
| [`dspy.clients.utils_finetune`](clients_finetune_utils.md) | `TrainDataFormat`, `TrainingStatus`, `save_data` |
| `dspy.utils.hasher` | Content-based hashing for training file naming (via `save_data`) |
| `openai` | Official OpenAI Python SDK for all API calls |

---

## Integration with the Broader System

The OpenAI provider is auto-discovered by DSPy's client layer through the `is_provider_model` hook. When a user configures an [`LM`](clients_core_lm.md) with an OpenAI model name, the framework can route fine-tuning requests to this provider.

```mermaid
graph TD
    LM["LM / BaseLM<br/>(clients_core)"]
    Provider["Provider registry"]
    OpenAI["OpenAIProvider"]
    Databricks["DatabricksProvider"]
    Local["LocalProvider"]
    Arbor["ArborProvider"]

    LM --> Provider
    Provider --> OpenAI
    Provider --> Databricks
    Provider --> Local
    Provider --> Arbor

    OpenAI -.->|is_provider_model| LM
```

### Related Modules

- [clients_core_provider](clients_core_provider.md) — Abstract `Provider`, `TrainingJob`, `ReinforceJob` contracts
- [clients_finetune_utils](clients_finetune_utils.md) — `TrainDataFormat`, `TrainingStatus`, `save_data`, and data structures
- [clients_core_lm](clients_core_lm.md) — The `LM` client that consumes providers
- [clients_providers_databricks](clients_providers_databricks.md) — Sibling provider implementation
- [clients_providers_local](clients_providers_local.md) — Local model provider
- [clients_providers_arbor](clients_providers_arbor.md) — Arbor provider with reinforcement learning support
- [teleprompt_finetune](teleprompt_finetune.md) — Optimizers (e.g., `BootstrapFinetune`) that drive fine-tuning jobs

---

## Key Design Notes

1. **Stateless provider** — `OpenAIProvider` uses only static methods, so no instance state is required; the constructor merely declares capabilities.
2. **Job state lives on the job** — Provider file/job IDs are stored on `TrainingJobOpenAI`, keeping the provider reusable across concurrent jobs.
3. **Static model list** — Model detection relies on a hard-coded list plus a RegEx for fine-tuned models; this is a known limitation flagged for future enhancement.
4. **Resilient existence checks** — `does_job_exist` and `does_file_exist` swallow all exceptions, which is convenient but may mask unrelated API errors (noted in code TODOs).
5. **Polling-based progress** — `wait_for_job` uses a simple sleep-poll loop rather than streaming, with a TODO to explore streaming OpenAI logs.
