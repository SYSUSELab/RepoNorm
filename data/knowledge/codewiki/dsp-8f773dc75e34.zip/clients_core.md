# Clients Core

## Overview

The **`clients_core`** module is the foundational layer of DSPy responsible for interacting with
Large Language Models (LLMs) and embedding models. It provides a unified, provider-agnostic
interface for:

- **Making LLM calls** (chat and text completion) through a single `LM` abstraction.
- **Computing text embeddings** through the `Embedder` class.
- **Caching** expensive model responses at both in-memory and on-disk levels.
- **Extending to custom providers** via the `Provider` abstraction, including fine-tuning and
  reinforcement-learning (RL) training jobs.
- **Tracking call history** for debugging and inspection.

This module sits at the bottom of the DSPy stack: higher-level modules such as
[`predict_core`](predict_core.md), [`signatures`](signatures.md), and [`adapters`](adapters.md)
all ultimately route their model calls through the abstractions defined here.

## Architecture

The module is organized around a small set of cooperating classes. `BaseLM` defines the
contract for any language model, `LM` is the concrete LiteLLM-backed implementation, `Cache`
provides transparent response caching, `Embedder` handles vector embeddings, and `Provider`
(plus its subclasses) encapsulates provider-specific behavior such as launching local servers
and fine-tuning.

```mermaid
graph TD
    subgraph "clients_core"
        BaseLM["BaseLM<br/>(abstract contract)"]
        LM["LM<br/>(LiteLLM-backed)"]
        Cache["Cache<br/>(memory + disk)"]
        Embedder["Embedder<br/>(embeddings)"]
        Provider["Provider<br/>(base)"]
        TrainingJob["TrainingJob"]
        ReinforceJob["ReinforceJob"]
    end

    subgraph "clients_providers"
        OpenAIProvider["OpenAIProvider"]
        LocalProvider["LocalProvider"]
        DatabricksProvider["DatabricksProvider"]
        ArborProvider["ArborProvider"]
    end

    subgraph "External"
        LiteLLM["litellm"]
        Settings["dspy.settings"]
        Callbacks["BaseCallback"]
    end

    LM -->|extends| BaseLM
    LM -->|uses| Cache
    LM -->|delegates to| Provider
    LM -->|reads| Settings
    LM -->|notifies| Callbacks
    LM -->|calls| LiteLLM
    Embedder -->|uses| Cache
    Embedder -->|calls| LiteLLM

    Provider --> TrainingJob
    Provider --> ReinforceJob
    OpenAIProvider -->|extends| Provider
    LocalProvider -->|extends| Provider
    DatabricksProvider -->|extends| Provider
    ArborProvider -->|extends| Provider
```

## Core Components

### `BaseLM` — Language Model Contract

`BaseLM` (`dspy/clients/base_lm.py`) is the abstract base class for all language models. It
defines the calling convention (`__call__` / `acall`), response post-processing, history
tracking, and copying semantics. Subclasses only need to implement `forward` (and optionally
`aforward`) and return a response in the
[OpenAI response format](https://platform.openai.com/docs/api-reference/responses/object).

Key responsibilities:

- **Call lifecycle**: `__call__`/`acall` invoke `forward`/`aforward`, then normalize the
  response via `_process_lm_response`.
- **History tracking**: maintains a per-instance `history`, a global `GLOBAL_HISTORY`, and
  per-module histories, all bounded by `settings.max_history_size`.
- **Inspection**: `inspect_history(n)` pretty-prints recent interactions.
- **Copying**: `copy(**kwargs)` produces a deep copy with updated parameters, used heavily by
  fine-tuning flows.

See [clients_core_base_lm](clients_core_base_lm.md) for details.

### `LM` — The Default Language Model

`LM` (`dspy/clients/lm.py`) is the concrete, LiteLLM-backed implementation of `BaseLM` and the
class most users interact with directly (`dspy.LM(...)`). It supports:

- **Chat and text completion** modes (`model_type="chat"` or `"text"`).
- **Automatic provider inference** via `infer_provider()`.
- **Caching** through the `request_cache` decorator and LiteLLM's own cache.
- **Streaming** support via `_get_stream_completion_fn`.
- **Fine-tuning and RL** entry points (`finetune`, `reinforce`, `launch`, `kill`).
- **Usage tracking** integration with `dspy.settings.usage_tracker`.

See [clients_core_lm](clients_core_lm.md) for details.

### `Cache` — Two-Level Response Cache

`Cache` (`dspy/clients/cache.py`) provides transparent caching of model responses with two
levels:

1. **In-memory** cache (`cachetools.LRUCache`).
2. **On-disk** cache (`diskcache.FanoutCache`).

It exposes a `request_cache` decorator that wraps completion/embedding functions, computing a
stable cache key from the request (ignoring sensitive fields like API keys) and short-circuiting
repeated calls. Cache hits clear `usage` data since no real call is made.

See [clients_core_cache](clients_core_cache.md) for details.

### `Embedder` — Text Embeddings

`Embedder` (`dspy/clients/embedding.py`) computes embeddings for text inputs. It supports both
hosted models (via LiteLLM, e.g. `"openai/text-embedding-3-small"`) and arbitrary custom
callables (e.g. a `SentenceTransformer.encode` method). It handles batching, caching, and
returns NumPy arrays.

See [clients_core_embedder](clients_core_embedder.md) for details.

### `Provider` — Provider Abstraction

`Provider` (`dspy/clients/provider.py`) is the base class for provider-specific behavior. It
declares the interface for:

- **Launching/killing** local model servers (`launch`, `kill`).
- **Fine-tuning** (`finetune`) via a `TrainingJob`.
- **Reinforcement learning** via a `ReinforceJob`.

It also defines the `TrainingJob` (a `Future` subclass) and `ReinforceJob` base classes.
Concrete providers live in the [`clients_providers`](clients_providers.md) module
(`OpenAIProvider`, `LocalProvider`, `DatabricksProvider`, `ArborProvider`).

See [clients_core_provider](clients_core_provider.md) for details.

## Data Flow

The following diagram shows the typical flow of a single LLM call through the module.

```mermaid
sequenceDiagram
    participant Caller as "DSPy Module / Predict"
    participant LM as "LM"
    participant Cache as "Cache"
    participant LiteLLM as "litellm"
    participant BaseLM as "BaseLM"

    Caller->>LM: __call__(prompt/messages, **kwargs)
    LM->>LM: forward() builds request
    LM->>Cache: request_cache lookup
    alt cache hit
        Cache-->>LM: cached response
    else cache miss
        LM->>LiteLLM: completion(request)
        LiteLLM-->>LM: response
        LM->>Cache: put(request, response)
    end
    LM-->>BaseLM: response
    BaseLM->>BaseLM: _process_lm_response()
    BaseLM->>BaseLM: update_history()
    BaseLM-->>Caller: outputs
```

## Relationship to Other Modules

- **[`clients_providers`](clients_providers.md)** — Concrete `Provider` subclasses
  (`OpenAIProvider`, `LocalProvider`, `DatabricksProvider`, `ArborProvider`) that plug into the
  `Provider` interface defined here.
- **[`clients_finetune_utils`](clients_finetune_utils.md)** — Data-format and message types
  (`TrainDataFormat`, `GRPOChatData`, etc.) consumed by fine-tuning and RL jobs.
- **[`predict_core`](predict_core.md)** — Higher-level modules that call `LM` instances.
- **[`adapters`](adapters.md)** — Format prompts/messages before they reach the `LM`.
- **[`utils`](utils.md)** — Provides `BaseCallback` (used by `BaseLM` via `with_callbacks`) and
  `UsageTracker`.
- **[`dsp_utils`](dsp_utils.md)** — Provides the global `Settings` singleton that `LM` and
  `BaseLM` read for configuration (history limits, usage tracking, streaming streams).

## Sub-module Documentation

| Sub-module | Description |
| --- | --- |
| [clients_core_base_lm](clients_core_base_lm.md) | The `BaseLM` abstract contract: call lifecycle, history, and copying. |
| [clients_core_lm](clients_core_lm.md) | The `LM` LiteLLM-backed implementation, streaming, and fine-tune/RL entry points. |
| [clients_core_cache](clients_core_cache.md) | The two-level `Cache` and the `request_cache` decorator. |
| [clients_core_embedder](clients_core_embedder.md) | The `Embedder` class for hosted and custom embeddings. |
| [clients_core_provider](clients_core_provider.md) | The `Provider`, `TrainingJob`, and `ReinforceJob` abstractions. |
