# Signatures Module

## Overview

The **signatures** module is the declarative backbone of DSPy. A *Signature* is a lightweight, typed specification of what a language-model-powered module should do: it declares the **input fields**, the **output fields**, and the **instructions** (the natural-language task description). Signatures are the contract that every `Predict`, `ChainOfThought`, adapter, and optimizer in DSPy operates against.

The module provides two complementary capabilities:

1. **Signature definition & introspection** — a metaclass-driven class system (`Signature` / `SignatureMeta`) that lets developers declare signatures either as Python classes or as compact strings (`"question -> answer"`), and then introspects them (fields, types, prefixes, instructions) at runtime.
2. **Field declaration** — the `InputField` / `OutputField` helpers (built on Pydantic `Field`) plus the legacy `OldField` family used for backward compatibility.

Because signatures are the shared vocabulary of the framework, this module is a foundational dependency for nearly every other module (predictors, adapters, teleprompters, evaluation, and retrieval).

## Architecture

The module is intentionally small and split into two files, each with a distinct responsibility:

```mermaid
graph TD
    subgraph signatures["signatures module"]
        SIG["signature.py<br/>Signature, SignatureMeta"]
        FLD["field.py<br/>OldField, OldInputField, OldOutputField"]
    end

    SIG -->|"uses InputField / OutputField"| FLD
    SIG -->|"subclasses"| PYD["pydantic.BaseModel"]
    FLD -->|"wraps"| PYDF["pydantic.Field"]

    subgraph consumers["Downstream consumers"]
        PRED["predict_core<br/>Predict, ChainOfThought"]
        ADAPT["adapters<br/>ChatAdapter, JSONAdapter, ..."]
        TELE["teleprompt_*<br/>optimizers"]
        EVAL["evaluate"]
    end

    SIG --> PRED
    SIG --> ADAPT
    SIG --> TELE
    SIG --> EVAL
```

### Component relationships

```mermaid
classDiagram
    class SignatureMeta {
        +__call__(cls, *args, **kwargs)
        +__new__(mcs, name, bases, namespace)
        +_detect_custom_types_from_caller(str)
        +_validate_fields()
        +instructions : str
        +input_fields : dict
        +output_fields : dict
        +fields : dict
        +signature : str
    }
    class Signature {
        +with_instructions(str)
        +with_updated_fields(name, type_, **kwargs)
        +prepend(name, field, type_)
        +append(name, field, type_)
        +insert(index, name, field, type_)
        +delete(name)
        +equals(other)
        +dump_state()
        +load_state(state)
    }
    class OldField {
        +prefix
        +desc
        +format
        +finalize(key, inferred_prefix)
    }
    class OldInputField
    class OldOutputField

    SignatureMeta --> Signature : metaclass of
    Signature --> OldField : legacy interop
    OldField <|-- OldInputField
    OldField <|-- OldOutputField
```

## Sub-modules

The module is documented through two focused sub-module pages:

| Sub-module | Responsibility | Documentation |
| --- | --- | --- |
| **Signature definition & metaclass** | The `Signature` base class and `SignatureMeta` metaclass: class/string construction, field introspection, mutation helpers, and state serialization. | [signatures_signature.md](signatures_signature.md) |
| **Field declarations** | The `InputField`/`OutputField` Pydantic helpers and the legacy `OldField`/`OldInputField`/`OldOutputField` classes. | [signatures_field.md](signatures_field.md) |

## How Signatures Fit Into the System

A signature is created once and then consumed across the framework:

```mermaid
flowchart LR
    DEV["Developer"] -->|"class MySig(dspy.Signature)"| SIG["Signature class"]
    DEV -->|"Signature('q -> a')"| SIG
    SIG -->|"input_fields / output_fields / instructions"| PRED["Predict / ChainOfThought"]
    PRED -->|"formats prompt"| ADAPT["Adapter"]
    ADAPT -->|"parses output"| PRED
    SIG -->|"dump_state / load_state"| TELE["Teleprompters"]
    SIG -->|"field metadata"| EVAL["Evaluate"]
```

- **Predictors** ([predict_core.md](predict_core.md), [predict_advanced.md](predict_advanced.md)) read `input_fields`, `output_fields`, and `instructions` to build prompts and validate outputs.
- **Adapters** ([adapters.md](adapters.md)) translate signature field metadata (prefixes, descriptions, types) into provider-specific prompt formats.
- **Teleprompters** ([teleprompt_core.md](teleprompt_core.md), [teleprompt_optimizers.md](teleprompt_optimizers.md)) mutate signatures via `with_instructions`, `with_updated_fields`, and serialize them with `dump_state`/`load_state`.
- **Evaluation** ([evaluate.md](evaluate.md)) relies on signature field structure to compare predictions against references.

## Key Design Notes

- **Metaclass magic**: `SignatureMeta.__call__` intercepts `Signature(...)` so that calling the base class *creates a new signature class* rather than an instance. This is what enables the string-based `Signature("q -> a")` syntax.
- **Pydantic foundation**: Signatures are Pydantic models, so field types, validation, and JSON schema come for free. DSPy-specific metadata (`desc`, `prefix`, `format`, `parser`, `__dspy_field_type`) is stored in `json_schema_extra`.
- **Custom type resolution**: When a signature string references a non-builtin type, `SignatureMeta` walks the caller's stack frames to resolve it, with an explicit `custom_types` escape hatch for reliability.
- **Legacy compatibility**: The `OldField` family preserves the pre-Pydantic field API and is bridged via `new_to_old_field`.
