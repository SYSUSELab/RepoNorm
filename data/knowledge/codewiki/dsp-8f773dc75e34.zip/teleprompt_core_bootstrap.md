# Teleprompt Core Bootstrap

## Introduction

The `teleprompt_core_bootstrap` module provides the **`BootstrapFewShot`** optimizer, one of the foundational
teleprompters (optimizers) in DSPy. Its purpose is to automatically construct high-quality few-shot
demonstrations for a DSPy program by *bootstrapping*: running a "teacher" program over a training set,
capturing the intermediate traces of successful executions, and converting those traces into
`dspy.Example` demonstrations that are attached to the student program's predictors.

This module is the workhorse behind several higher-level optimizers. It is the base building block used by
[`BootstrapFewShotWithRandomSearch`](teleprompt_core_random_search.md),
[`BootstrapFewShotWithOptuna`](teleprompt_optimizers.md), [`KNNFewShot`](teleprompt_core_knn_fewshot.md),
and [`BootstrapFinetune`](teleprompt_finetune.md).

> **Key idea:** Instead of hand-writing demonstrations, let the program *demonstrate itself* by recording
> successful reasoning traces and replaying them as few-shot examples.

---

## Module Position in the System

`BootstrapFewShot` sits in the `teleprompt_core` family of optimizers. It depends on the core primitives
(`Module`, `Example`), the base `Teleprompter` interface, and the `LabeledFewShot` optimizer for seeding
the teacher with labeled demonstrations.

```mermaid
graph TD
    subgraph teleprompt_core
        TP[Teleprompter<br/>teleprompt_core_base]
        LFS[LabeledFewShot<br/>teleprompt_core_labeled_fewshot]
        BFS[BootstrapFewShot<br/>teleprompt_core_bootstrap]
        RS[BootstrapFewShotWithRandomSearch<br/>teleprompt_core_random_search]
        ENS[Ensemble<br/>teleprompt_core_ensemble]
        KNN[KNNFewShot<br/>teleprompt_core_knn_fewshot]
    end

    subgraph primitives
        MOD[Module]
        EX[Example]
    end

    subgraph utils
        HASH[Hasher]
    end

    subgraph dsp_utils
        SET[Settings]
    end

    TP --> BFS
    LFS --> BFS
    BFS --> RS
    BFS --> KNN
    MOD --> BFS
    EX --> BFS
    HASH --> BFS
    SET --> BFS
```

---

## Core Component: `BootstrapFewShot`

`BootstrapFewShot` is a subclass of `Teleprompter` (see [teleprompt_core_base](teleprompt_core_base.md)).
It implements the `compile(student, *, teacher=None, trainset)` interface.

### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `metric` | `Callable` | `None` | Compares expected vs. predicted values; returns a score or boolean. |
| `metric_threshold` | `float` | `None` | If the metric returns a number, accept a bootstrap example only when `metric >= threshold`. |
| `teacher_settings` | `dict` | `None` | Settings applied to the teacher model during bootstrapping (e.g. a different LM). |
| `max_bootstrapped_demos` | `int` | `4` | Maximum number of bootstrapped demonstrations per predictor. |
| `max_labeled_demos` | `int` | `16` | Maximum number of labeled demonstrations per predictor. |
| `max_rounds` | `int` | `1` | Number of attempts to generate a successful trace per example. |
| `max_errors` | `int` | `None` | Maximum errors before aborting; inherits `dspy.settings.max_errors` if `None`. |

The constructor also initializes `self.error_count = 0` and a `threading.Lock` (`self.error_lock`) to make
error counting thread-safe.

---

## Compilation Pipeline

The `compile` method orchestrates the entire optimization in four phases:

```mermaid
flowchart TD
    A[compile student, teacher, trainset] --> B[_prepare_student_and_teacher]
    B --> C[_prepare_predictor_mappings]
    C --> D[_bootstrap]
    D --> E[_train]
    E --> F[Return compiled student]

    B --> B1[student = student.reset_copy]
    B --> B2[teacher = teacher.deepcopy or student.deepcopy]
    B --> B3[Seed teacher with LabeledFewShot if uncompiled]

    C --> C1[Map predictor names to objects]
    C --> C2[Validate matching structure & signatures]

    D --> D1[For each example, attempt bootstrap]
    D --> D2[Record successful traces into name2traces]
    D --> D3[Collect unbootstrapped examples as validation]

    E --> E1[Attach augmented + raw demos per predictor]
```

### Phase 1 — `_prepare_student_and_teacher`

- Creates a fresh copy of the student via `student.reset_copy()`.
- Creates the teacher: uses `teacher.deepcopy()` if provided, otherwise `student.deepcopy()`.
- Asserts the student is **uncompiled** (`_compiled is False`).
- If `max_labeled_demos > 0` and the teacher is uncompiled, it seeds the teacher with labeled
  demonstrations using [`LabeledFewShot`](teleprompt_core_labeled_fewshot.md).

### Phase 2 — `_prepare_predictor_mappings`

Builds two lookup dictionaries:

- `name2predictor`: predictor name → placeholder (used to track traces by name).
- `predictor2name`: `id(predictor)` → predictor name (used to resolve traces back to predictors).

It validates that the student and teacher have:
1. The same number of predictors.
2. The same predictor names (program structure).
3. Matching signatures (via `signature.equals()` when available, else `==`).
4. Distinct predictor objects (`id(predictor1) != id(predictor2)`).

### Phase 3 — `_bootstrap`

Iterates over the training set (with a `tqdm` progress bar) and attempts to bootstrap each example:

```mermaid
flowchart TD
    S[Start _bootstrap] --> L{len bootstrapped >= max_bootstraps?}
    L -- yes --> END[Stop]
    L -- no --> R[For round_idx in max_rounds]
    R --> BO[_bootstrap_one_example]
    BO --> OK{success?}
    OK -- yes --> MARK[Mark example bootstrapped, break]
    OK -- no --> NEXT[Next round]
    MARK --> L
    NEXT --> R
    END --> VAL[validation = unbootstrapped examples, shuffled with seed 0]
```

After bootstrapping, the examples that were **not** successfully bootstrapped are collected into
`self.validation` and shuffled deterministically with `random.Random(0)`.

### Phase 4 — `_train`

For each predictor in the student:

1. Take up to `max_bootstrapped_demos` augmented (bootstrapped) demos from `self.name2traces[name]`.
2. Sample `min(max_labeled_demos - len(augmented_demos), len(raw_demos))` raw labeled demos.
3. Assign `predictor.demos = augmented_demos + raw_demos`.

The result is a student program whose predictors carry a mix of bootstrapped and labeled demonstrations.

---

## Bootstrapping a Single Example

`_bootstrap_one_example(example, round_idx)` is the heart of the algorithm:

```mermaid
sequenceDiagram
    participant B as _bootstrap_one_example
    participant S as dspy.settings
    participant T as Teacher
    participant M as metric

    B->>S: context(trace=[], **teacher_settings)
    Note over B: If round_idx > 0, copy LM with temperature 0.7 + 0.001*round_idx
    B->>T: Temporarily remove `example` from each predictor's demos
    B->>T: prediction = teacher(**example.inputs())
    B->>S: trace = dspy.settings.trace
    B->>T: Restore original demos
    B->>M: metric_val = metric(example, prediction, trace)
    alt metric_threshold set
        M-->>B: success = metric_val >= threshold
    else
        M-->>B: success = metric_val
    end
    alt success
        B->>B: Convert each trace step into dspy.Example(augmented=True, **inputs, **outputs)
        B->>B: Append to name2traces[predictor_name]
    end
```

### Key behaviors

- **Temperature escalation:** On retry rounds (`round_idx > 0`), the LM is copied with a slightly higher
  temperature (`0.7 + 0.001 * round_idx`) to encourage diverse traces.
- **Demo isolation:** The current `example` is temporarily removed from every predictor's demos so the
  teacher does not "cheat" by seeing the answer it is being asked to produce.
- **Trace capture:** `dspy.settings.trace` records `(predictor, inputs, outputs)` tuples for each step.
- **Demo construction:** Each trace step becomes `dspy.Example(augmented=True, **inputs, **outputs)`.
- **Duplicate handling:** If a predictor produces multiple traces for the same example, a deterministic
  `random.Random(Hasher.hash(tuple(demos)))` chooses 50/50 between the last trace and one of the earlier
  traces. This uses the [`Hasher`](utils.md) utility for reproducibility.
- **Error handling:** Exceptions increment `self.error_count` under `self.error_lock`. If the count reaches
  the effective `max_errors` (explicit or from `dspy.settings.max_errors`), the exception is re-raised;
  otherwise it is logged and the example is skipped.

---

## Data Flow Overview

```mermaid
flowchart LR
    TS[trainset: list of Example] --> BOOT[_bootstrap]
    BOOT -->|successful traces| N2T[name2traces: name -> list of Example]
    BOOT -->|failed examples| VAL[validation: list of Example]
    N2T --> TRAIN[_train]
    VAL --> TRAIN
    TRAIN --> DEMOS[predictor.demos = augmented + labeled]
    DEMOS --> STUDENT[compiled student Module]
```

---

## Relationship to Other Optimizers

`BootstrapFewShot` is a reusable primitive. The following optimizers build on top of it:

| Optimizer | How it uses `BootstrapFewShot` |
|-----------|-------------------------------|
| [`BootstrapFewShotWithRandomSearch`](teleprompt_core_random_search.md) | Runs `BootstrapFewShot` across many shuffled candidate sets and selects the best by validation score. |
| [`BootstrapFewShotWithOptuna`](teleprompt_optimizers.md) | Uses `BootstrapFewShot` to produce a pool of demos, then uses Optuna to select the best demo per predictor. |
| [`KNNFewShot`](teleprompt_core_knn_fewshot.md) | At test time, retrieves k nearest neighbors and runs `BootstrapFewShot` on that dynamic trainset. |
| [`BootstrapFinetune`](teleprompt_finetune.md) | Shares the bootstrapping concept but converts traces into fine-tuning data instead of demos. |

```mermaid
graph LR
    BFS[BootstrapFewShot]
    BFS --> RS[BootstrapFewShotWithRandomSearch]
    BFS --> OPT[BootstrapFewShotWithOptuna]
    BFS --> KNN[KNNFewShot]
    BFS -.concept.-> FT[BootstrapFinetune]
```

---

## Usage Example

```python
import dspy
from dspy.teleprompt import BootstrapFewShot

# Define a metric
def validate_answer(example, pred, trace=None):
    return example.answer.lower() == pred.answer.lower()

# Create the optimizer
optimizer = BootstrapFewShot(
    metric=validate_answer,
    max_bootstrapped_demos=4,
    max_labeled_demos=16,
    max_rounds=1,
)

# Compile the student program
compiled_program = optimizer.compile(student=my_program, trainset=trainset)
```

---

## Dependencies

| Dependency | Role |
|------------|------|
| [`Teleprompter`](teleprompt_core_base.md) | Base class defining the `compile` interface. |
| [`LabeledFewShot`](teleprompt_core_labeled_fewshot.md) | Seeds the teacher with labeled demos. |
| [`Module`](primitives.md) | Provides `reset_copy`, `deepcopy`, `named_predictors`, `predictors`. |
| [`Example`](primitives.md) | Container for inputs/outputs and bootstrapped demos. |
| [`Hasher`](utils.md) | Deterministic hashing for duplicate-trace selection. |
| [`Settings`](dsp_utils.md) | Provides `dspy.settings.context`, `trace`, `lm`, and `max_errors`. |

---

## Design Notes & Caveats

- **Determinism:** Shuffling and duplicate selection use fixed seeds (`random.Random(0)` and
  `Hasher.hash(...)`) to make runs reproducible.
- **Thread safety:** Error counting is guarded by a lock, allowing parallel bootstrapping scenarios.
- **Student-as-teacher:** Since Oct 28, 2024, when no teacher is provided, the student is **deep-copied**
  (not reset-copied) to serve as the teacher.
- **Cache bypass:** The `max_rounds` mechanism increases temperature to bypass LM caching and obtain
  diverse traces.
- **Unbootstrapped examples:** Examples that fail to bootstrap are retained in `self.validation` for
  downstream use (e.g. by random search).
