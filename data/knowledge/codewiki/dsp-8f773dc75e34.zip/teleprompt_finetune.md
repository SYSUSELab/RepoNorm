# Teleprompt Finetune

## Overview

The `teleprompt_finetune` module provides DSPy optimizers that improve programs by **fine-tuning the underlying language models** (weight optimization), as opposed to only optimizing prompts or few-shot demonstrations. It contains three complementary optimizers:

- **`BootstrapFinetune`** — Bootstraps traces from a (teacher) program, converts them into supervised fine-tuning (SFT) datasets, and fine-tunes the student's LMs.
- **`GRPO`** — Performs reinforcement-learning fine-tuning using Group Relative Policy Optimization, using a metric as the reward signal.
- **`BetterTogether`** — An experimental meta-optimizer that alternates between prompt optimization (`p`) and weight optimization (`w`) strategies.

All three build on the shared `FinetuneTeleprompter` base class and the `Teleprompter` interface, and they rely on the LM/provider fine-tuning and reinforcement-learning interfaces defined in the [clients_core](clients_core.md) and [clients_providers](clients_providers.md) modules.

## Purpose

Traditional DSPy optimizers (see [teleprompt_core](teleprompt_core.md) and [teleprompt_optimizers](teleprompt_optimizers.md)) tune *prompts* and *demonstrations*. This module instead tunes the *model weights*:

| Optimizer | Optimization target | Signal | Requires |
|-----------|--------------------|--------|----------|
| `BootstrapFinetune` | LM weights (SFT) | Bootstrapped traces, optionally filtered by a metric | A finetunable provider |
| `GRPO` | LM weights (RL) | Metric reward over sampled rollouts | A reinforceable provider |
| `BetterTogether` | Prompts **and** weights | Metric | Experimental flag + both optimizers |

## Architecture

```mermaid
graph TD
    Teleprompter["Teleprompter<br/>(teleprompt_core)"]
    FinetuneTeleprompter["FinetuneTeleprompter"]
    BootstrapFinetune["BootstrapFinetune"]
    GRPO["GRPO"]
    BetterTogether["BetterTogether"]

    Teleprompter --> FinetuneTeleprompter
    FinetuneTeleprompter --> BootstrapFinetune
    FinetuneTeleprompter --> GRPO
    Teleprompter --> BetterTogether

    BootstrapFinetune -->|uses| BootstrapTrace["bootstrap_trace_data"]
    GRPO -->|uses| BootstrapTrace
    GRPO -->|uses| FailedPrediction
    BetterTogether -->|uses| BootstrapFinetune
    BetterTogether -->|uses| BFRS["BootstrapFewShotWithRandomSearch<br/>(teleprompt_core)"]

    BootstrapFinetune -->|LM.finetune| LM["LM / Provider<br/>(clients_core, clients_providers)"]
    GRPO -->|LM.reinforce| LM
```

## Sub-modules

The module is organized into three sub-modules, each documented separately:

### 1. [Bootstrap Finetune](teleprompt_finetune_bootstrap.md)
The core supervised fine-tuning optimizer. Defines `FinetuneTeleprompter` (shared base), `BootstrapFinetune`, the `bootstrap_trace_data` data-collection routine, and the `FailedPrediction` / `TraceData` data structures. It also provides shared helper functions (`prepare_student`, `prepare_teacher`, `all_predictors_have_lms`, `launch_lms`, `kill_lms`, etc.) reused by the other optimizers.

### 2. [GRPO](teleprompt_finetune_grpo.md)
The reinforcement-learning optimizer. Implements `GRPO`, which samples multiple rollouts per example, scores them with a metric, groups them, and drives the provider's `ReinforceJob` interface to update the model weights in place.

### 3. [BetterTogether](teleprompt_finetune_bettertogether.md)
The experimental meta-optimizer. Implements `BetterTogether`, which runs a user-specified sequence of prompt (`p`) and weight (`w`) optimization steps, tracking each intermediate program as a candidate.

## Component Relationships

```mermaid
graph LR
    subgraph "teleprompt_finetune"
        FT["FinetuneTeleprompter"]
        BF["BootstrapFinetune"]
        GRPO["GRPO"]
        BT["BetterTogether"]
    end

    subgraph "Shared data structures"
        TD["TraceData"]
        FP["FailedPrediction"]
    end

    subgraph "External dependencies"
        Eval["Evaluate<br/>(evaluate)"]
        Adapter["Adapter / ChatAdapter<br/>(adapters)"]
        LM["LM<br/>(clients_core)"]
        Utils["infer_data_format<br/>(clients_finetune_utils)"]
    end

    BF --> FT
    GRPO --> FT
    BF --> TD
    GRPO --> TD
    BF --> FP
    GRPO --> FP
    BF --> Eval
    GRPO --> Eval
    BF --> Adapter
    GRPO --> Adapter
    BF --> LM
    GRPO --> LM
    BF --> Utils
```

## Data Flow

The following diagram shows the high-level data flow shared by the fine-tuning optimizers:

```mermaid
flowchart TD
    A["Student program + trainset"] --> B["Bootstrap traces<br/>(bootstrap_trace_data)"]
    B --> C{"Metric provided?"}
    C -->|Yes| D["Filter traces by score"]
    C -->|No| E["Keep all traces"]
    D --> F["Convert traces to training data<br/>(adapter.format_finetune_data)"]
    E --> F
    F --> G{"Optimizer"}
    G -->|BootstrapFinetune| H["LM.finetune() -> TrainingJob"]
    G -->|GRPO| I["LM.reinforce() -> ReinforceJob.step()"]
    H --> J["Update student predictors with fine-tuned LMs"]
    I --> J
    J --> K["Compiled student program"]
```

## How It Fits Into the System

- **Base interface**: All optimizers extend `Teleprompter` from [teleprompt_core](teleprompt_core.md), implementing the `compile(student, trainset, teacher, valset)` contract.
- **LM & providers**: Fine-tuning and reinforcement learning are delegated to the `LM` class and its `Provider` implementations. See [clients_core](clients_core.md) and [clients_providers](clients_providers.md) for the `finetune`, `reinforce`, `TrainingJob`, and `ReinforceJob` interfaces.
- **Data formats**: Training data formats (`TrainDataFormat`, `GRPOChatData`) and helpers (`infer_data_format`) live in [clients_finetune_utils](clients_finetune_utils.md).
- **Adapters**: Traces are converted to training data using adapters from the [adapters](adapters.md) module (`ChatAdapter` is required for GRPO).
- **Evaluation**: Bootstrapping and validation use `Evaluate` from the [evaluate](evaluate.md) module.
- **Prompt optimization**: `BetterTogether` composes `BootstrapFewShotWithRandomSearch` from [teleprompt_core](teleprompt_core.md) with `BootstrapFinetune`.

## Key Concepts

- **Trace**: A list of `(Predictor, inputs, outputs)` tuples captured during a program invocation, used as the raw material for training data.
- **Multitask**: When `True`, a single fine-tuning job is shared across all predictors using the same LM; when `False`, each predictor gets its own job.
- **FailedPrediction**: A placeholder for model outputs that failed to parse, carrying a `format_reward` used to penalize malformed generations during training.
- **In-place LM updates (GRPO)**: Unlike `BootstrapFinetune` (which creates new LM instances), `GRPO` updates the model field of the existing LM in place.
