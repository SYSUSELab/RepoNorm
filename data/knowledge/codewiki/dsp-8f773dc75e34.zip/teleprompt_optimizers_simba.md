# SIMBA Optimizer

## Introduction

The **SIMBA** (Stochastic Introspective Mini-Batch Ascent) module is a DSPy teleprompter that optimizes a `dspy.Module` program by iteratively improving its prompts (instructions) and few-shot demonstrations. Unlike gradient-based optimizers, SIMBA operates through a stochastic, introspective search process: it samples program trajectories on mini-batches, contrasts high-scoring against low-scoring executions, and uses an LLM to generate targeted advice for each sub-module.

The module lives in `dspy/teleprompt/simba.py` and is supported by helper utilities in `dspy/teleprompt/simba_utils.py`. It is one of several optimizers under the [teleprompt_optimizers](teleprompt_optimizers.md) family, sitting alongside instruction-based optimizers (COPRO, SignatureOptimizer), Bayesian optimizers (MIPROv2, Optuna), and rule-induction optimizers (InferRules).

The core idea is simple but powerful:

1. **Sample** many program trajectories on a mini-batch using varied temperatures.
2. **Rank** examples by the *gap* between their best and worst outcomes.
3. **Introspect** on the most informative examples by asking an LLM to compare a "better" trajectory against a "worse" one.
4. **Mutate** candidate programs by appending demos and/or injecting generated rules into module instructions.
5. **Ascend** by keeping the best-performing candidates and repeating.

---

## Architecture Overview

SIMBA is composed of two files with a clear separation of concerns:

- **`simba.py`** — the `SIMBA` teleprompter class that orchestrates the optimization loop.
- **`simba_utils.py`** — helper functions (`prepare_models_for_resampling`, `wrap_program`, `append_a_demo`, `append_a_rule`, `inspect_modules`, `recursive_mask`) and the `OfferFeedback` signature used for introspection.

```mermaid
graph TD
    subgraph "simba.py"
        SIMBA["SIMBA (Teleprompter)"]
    end

    subgraph "simba_utils.py"
        PMR["prepare_models_for_resampling"]
        WP["wrap_program"]
        AAD["append_a_demo"]
        AAR["append_a_rule"]
        IM["inspect_modules"]
        RM["recursive_mask"]
        OF["OfferFeedback (Signature)"]
    end

    subgraph "DSPy Core"
        TP["Teleprompter"]
        MOD["Module"]
        EX["Example"]
        PAR["Parallel"]
        PRED["Predict"]
    end

    SIMBA -->|inherits| TP
    SIMBA -->|uses| PMR
    SIMBA -->|uses| WP
    SIMBA -->|uses| AAD
    SIMBA -->|uses| AAR
    SIMBA -->|uses| PAR
    SIMBA -->|optimizes| MOD

    AAR -->|uses| OF
    AAR -->|uses| IM
    AAR -->|uses| RM
    AAR -->|uses| PRED
    WP -->|uses| EX
    AAD -->|uses| EX
```

---

## Component Relationships

### `SIMBA` (Teleprompter)

`SIMBA` extends the abstract [`Teleprompter`](teleprompt_core.md) base class and implements the `compile` method. It holds configuration parameters and a list of mutation **strategies** that are applied to candidate programs.

| Parameter | Type | Default | Purpose |
|---|---|---|---|
| `metric` | `Callable` | — | Scoring function `(example, prediction) -> float`. |
| `bsize` | `int` | `32` | Mini-batch size for each optimization step. |
| `num_candidates` | `int` | `6` | New candidate programs produced per iteration. |
| `max_steps` | `int` | `8` | Number of optimization steps (batches). |
| `max_demos` | `int` | `4` | Max demos a predictor may hold before dropping some. |
| `demo_input_field_maxlen` | `int` | `100_000` | Truncation length for demo input fields. |
| `num_threads` | `int \| None` | `None` | Threads for parallel execution. |
| `temperature_for_sampling` | `float` | `0.2` | Temperature for softmax program selection during sampling. |
| `temperature_for_candidates` | `float` | `0.2` | Temperature for softmax source-program selection. |

The `strategies` list is built in `__init__`:
- If `max_demos > 0`: `[append_a_demo(...), append_a_rule]`
- Otherwise: `[append_a_rule]`

### `OfferFeedback` (Signature)

`OfferFeedback` is a DSPy [`Signature`](signatures.md) that defines the introspection prompt. Given a **better** and a **worse** program trajectory (plus program code, module definitions, inputs, and oracle metadata), it produces:

- `discussion` — a blame analysis of where modules went wrong.
- `module_advice` — a `dict[str, str]` mapping each module name to concrete, generalizable advice.

This signature is the "introspective" heart of SIMBA: it converts observed behavioral differences into natural-language instructions that are appended to module signatures.

### Helper Functions

| Function | Role |
|---|---|
| `prepare_models_for_resampling(program, n)` | Clones the program's LM into `n` variants with increasing temperatures for diverse sampling. |
| `wrap_program(program, metric)` | Wraps a program so it returns `{prediction, trace, score, example}` and captures the execution trace. |
| `append_a_demo(maxlen)` | Strategy factory: appends one demo per predictor from the best trajectory in a bucket. |
| `append_a_rule(bucket, system, ...)` | Strategy: generates LLM advice via `OfferFeedback` and appends it to module instructions. |
| `inspect_modules(program)` | Renders a human-readable description of each module's I/O and instructions. |
| `recursive_mask(o)` | Recursively replaces non-JSON-serializable objects with placeholders for safe serialization. |

---

## Optimization Process Flow

The `compile` method implements the full SIMBA loop. The following diagram captures the eight steps executed per batch.

```mermaid
flowchart TD
    Start([compile student, trainset, seed]) --> Init["Initialize RNG, baseline program (idx=0),<br/>shuffle data, create Parallel runner"]
    Init --> Loop{"For each batch<br/>(max_steps)"}

    Loop --> S1["STEP 1: Get next mini-batch of bsize examples"]
    S1 --> S2["STEP 2: Sample trajectories<br/>num_candidates models x bsize examples<br/>via softmax over top programs"]
    S2 --> S3["STEP 3: Bucket outputs by example,<br/>sort by (max-min gap, max score, max-avg gap)"]
    S3 --> S4["STEP 4: Build candidates<br/>drop demos + apply strategy<br/>(append_a_demo / append_a_rule)"]
    S4 --> S5["STEP 5: Evaluate candidates on same mini-batch"]
    S5 --> S6["STEP 6: Compute avg mini-batch scores"]
    S6 --> S7["STEP 7: Record best candidate as winning program"]
    S7 --> S8["STEP 8: Register all candidates in global pool"]
    S8 --> Loop

    Loop -->|done| Final["Select evenly-spaced winning programs<br/>Evaluate on full trainset"]
    Final --> Best["Return best program with<br/>candidate_programs & trial_logs attached"]
    Best --> End([Optimized program])
```

### Step-by-step Detail

1. **Batch selection** — Data indices are shuffled once; each step consumes the next `bsize` examples, reshuffling when the trainset is exhausted.

2. **Trajectory sampling** — `prepare_models_for_resampling` produces `num_candidates` LMs at different temperatures. For each (model, example) pair, a source program is chosen via **softmax sampling** over the top-`k` programs (with the baseline always included). Each execution is wrapped by `wrap_program` to capture the trace and score.

3. **Bucketing & ranking** — Outputs are grouped per example. Each bucket is sorted by score, and buckets are ranked by a tuple `(max_to_min_gap, max_score, max_to_avg_gap)`. This prioritizes examples where the program's behavior varies most — the most informative signals for introspection.

4. **Candidate construction** — For each top bucket, a source program is softmax-sampled, some demos are dropped (Poisson-distributed count), and a random strategy is applied:
   - `append_a_demo` adds one demo per predictor from the best trajectory.
   - `append_a_rule` calls `OfferFeedback` to generate per-module advice and appends it to instructions.

5. **Candidate evaluation** — All new candidates are evaluated on the same mini-batch in parallel.

6. **Scoring** — Average mini-batch scores are computed per candidate.

7. **Winning record** — The best candidate is appended to `winning_programs`.

8. **Registration** — All candidates are registered in the global program pool with their scores, becoming eligible for future softmax selection.

### Final Selection

After all batches, SIMBA selects `num_candidates + 1` evenly-spaced programs from the `winning_programs` history, evaluates them on the **full trainset**, and returns the highest-scoring one. The returned program carries:

- `candidate_programs` — a sorted list of `{"score", "program"}` dicts.
- `trial_logs` — per-step training scores.

---

## Data Flow

The following diagram shows how data flows through the system, from the trainset to the optimized program.

```mermaid
sequenceDiagram
    participant U as User
    participant S as SIMBA
    participant P as Parallel
    participant M as Module (candidate)
    participant L as LM
    participant F as OfferFeedback

    U->>S: compile(student, trainset, seed)
    S->>S: deepcopy baseline, shuffle data
    loop Each batch
        S->>P: exec_pairs (wrapped programs x examples)
        P->>M: program(**example.inputs())
        M->>L: LM calls (varied temperatures)
        L-->>M: predictions
        M-->>P: {prediction, trace, score, example}
        P-->>S: outputs
        S->>S: bucket, rank, select source programs
        S->>F: OfferFeedback(better/worse trajectories)
        F-->>S: module_advice
        S->>M: append demos / instructions
        S->>P: evaluate candidates
        P-->>S: candidate scores
    end
    S->>P: evaluate finalists on full trainset
    P-->>S: final scores
    S-->>U: best_program
```

---

## Dependencies

SIMBA depends on several other DSPy modules. Rather than duplicating their documentation, refer to the linked pages.

```mermaid
graph LR
    SIMBA["SIMBA"] --> TP["Teleprompter<br/>(teleprompt_core.md)"]
    SIMBA --> PAR["Parallel<br/>(predict_core.md)"]
    SIMBA --> MOD["Module<br/>(primitives.md)"]
    SIMBA --> EX["Example<br/>(primitives.md)"]
    SIMBA --> PRED["Predict<br/>(predict_core.md)"]
    SIMBA --> SIG["Signature<br/>(signatures.md)"]
    SIMBA --> SET["Settings / dspy.context<br/>(dsp_utils.md)"]
```

| Dependency | Used For |
|---|---|
| [`Teleprompter`](teleprompt_core.md) | Base class providing the `compile` interface. |
| [`Parallel`](predict_core.md) | Parallel execution of program/example pairs. |
| [`Module`](primitives.md) | The program being optimized; provides `named_predictors`, `deepcopy`, `set_lm`. |
| [`Example`](primitives.md) | Training instances; provides `inputs()`, `labels()`. |
| [`Predict`](predict_core.md) | Used inside `append_a_rule` to invoke `OfferFeedback`. |
| [`Signature`](signatures.md) | Defines `OfferFeedback` with `InputField`/`OutputField`. |
| [`dspy.context` / settings](dsp_utils.md) | Trace capture (`trace=[]`) and LM configuration. |

---

## Key Design Considerations

- **Trace capture** — `wrap_program` runs the program inside `dspy.context(trace=[])` so the full execution trace (each predictor's inputs/outputs) is available for introspection and demo construction.
- **Softmax exploration** — Both trajectory sampling and source-program selection use temperature-controlled softmax, balancing exploitation of high-scoring programs with exploration of diverse ones.
- **Baseline preservation** — The baseline program (index 0) is always included in the top-`k` pool, preventing premature convergence.
- **Robustness** — Strategy failures are caught and logged (`continue`), and metric/prediction exceptions are swallowed inside `wrap_program`, ensuring the optimization loop never crashes on a single bad example.
- **Serialization safety** — `recursive_mask` ensures that arbitrary Python objects in trajectories are converted to placeholders before being passed to the LLM.

---

## Related Modules

- [teleprompt_optimizers](teleprompt_optimizers.md) — Parent family of optimizers.
- [teleprompt_core](teleprompt_core.md) — Base `Teleprompter` and simpler optimizers.
- [predict_core](predict_core.md) — `Predict` and `Parallel`.
- [primitives](primitives.md) — `Module`, `Example`, `Prediction`.
- [signatures](signatures.md) — `Signature`, `InputField`, `OutputField`.
- [dsp_utils](dsp_utils.md) — `Settings` and context management.
