# Utils Exceptions Module

## Introduction

The `utils_exceptions` module provides the exception types used across DSPy's adapter layer. Its primary (and currently sole) component is `AdapterParseError`, a specialized exception raised when an adapter fails to parse a Language Model (LM) response into the structured output fields defined by a DSPy `Signature`.

This module sits at the boundary between the [adapters](adapters.md) layer and the [signatures](signatures.md) layer: adapters invoke parsing logic, and when parsing fails, they raise `AdapterParseError` to communicate a structured, diagnostic-rich failure back to the caller.

---

## Core Component: `AdapterParseError`

`AdapterParseError` is a subclass of Python's built-in `Exception`. It is designed to carry rich contextual information about a parsing failure so that developers can quickly diagnose why an LM response could not be converted into the expected output fields.

### Class Definition

```python
class AdapterParseError(Exception):
    """Exception raised when adapter cannot parse the LM response."""
```

### Constructor Signature

```python
def __init__(
    self,
    adapter_name: str,
    signature: Signature,
    lm_response: str,
    message: str | None = None,
    parsed_result: str | None = None,
):
```

### Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `adapter_name` | `str` | Yes | The name of the adapter that failed (e.g., `"ChatAdapter"`, `"JSONAdapter"`). |
| `signature` | `Signature` | Yes | The DSPy `Signature` describing the expected input/output fields. Used to list the expected output fields in the error message. |
| `lm_response` | `str` | Yes | The raw, unparsed response returned by the language model. |
| `message` | `str \| None` | No | An optional custom message prepended to the generated error message. Useful for adding field-specific context. |
| `parsed_result` | `str \| None` | No | The partial result that was successfully parsed (if any). When provided, the keys of this result are included in the error message to show what was actually parsed. |

### Instance Attributes

After construction, the following attributes are available on the exception instance:

- `adapter_name` — the name of the failing adapter.
- `signature` — the `Signature` associated with the failed parse.
- `lm_response` — the raw LM response string.
- `parsed_result` — the partially parsed result, or `None`.

### Generated Error Message

The constructor builds a human-readable, multi-section error message. The structure is:

```
{message}

Adapter {adapter_name} failed to parse the LM response.

LM Response: {lm_response}

Expected to find output fields in the LM response: [{expected_fields}]

Actual output fields parsed from the LM response: [{parsed_fields}]
```

Where:
- `{message}` is the optional custom message (followed by a blank line) if provided.
- `{expected_fields}` is a comma-separated list of `signature.output_fields.keys()`.
- `{parsed_fields}` is a comma-separated list of `parsed_result.keys()`, included **only** when `parsed_result` is not `None`.

---

## Architecture and Relationships

The `AdapterParseError` is raised by adapter implementations during their `parse()` step. The diagram below shows how the exception fits into the adapter call flow.

```mermaid
graph TD
    subgraph Signatures
        SIG[Signature]
    end

    subgraph Adapters
        BASE[Adapter]
        CHAT[ChatAdapter]
        JSON[JSONAdapter]
        XML[XMLAdapter]
    end

    subgraph Utils
        APE[AdapterParseError]
    end

    BASE -->|defines parse contract| CHAT
    BASE -->|defines parse contract| JSON
    BASE -->|defines parse contract| XML

    CHAT -->|raises on failure| APE
    JSON -->|raises on failure| APE
    XML -->|raises on failure| APE

    APE -->|reads output_fields| SIG
```

### Dependency Diagram

`AdapterParseError` depends on the `Signature` class from the [signatures](signatures.md) module to enumerate the expected output fields. It is consumed by all adapter implementations in the [adapters](adapters.md) module.

```mermaid
graph LR
    SIG[signatures.signature.Signature] --> APE[utils.exceptions.AdapterParseError]
    APE --> CHAT[adapters.chat_adapter.ChatAdapter]
    APE --> JSON[adapters.json_adapter.JSONAdapter]
    APE --> XML[adapters.xml_adapter.XMLAdapter]
    APE --> BAML[adapters.baml_adapter.BAMLAdapter]
```

---

## Usage Flow

The following sequence diagram illustrates a typical parse failure and how `AdapterParseError` is constructed and propagated.

```mermaid
sequenceDiagram
    participant Caller
    participant Adapter as ChatAdapter
    participant Parse as parse()
    participant APE as AdapterParseError

    Caller->>Adapter: __call__(lm, signature, ...)
    Adapter->>Parse: parse(signature, completion)
    Parse->>Parse: extract fields from completion
    alt fields missing or unparseable
        Parse->>APE: raise AdapterParseError(adapter_name, signature, lm_response, ...)
        APE->>APE: build diagnostic message
        APE-->>Parse: exception instance
        Parse-->>Adapter: propagate exception
        Adapter-->>Caller: propagate exception
    else all fields parsed successfully
        Parse-->>Adapter: return parsed dict
        Adapter-->>Caller: return outputs
    end
```

---

## Example Usage

### Raising the Exception

Adapters raise `AdapterParseError` in two common scenarios:

**1. A specific field fails to parse:**

```python
raise AdapterParseError(
    adapter_name="ChatAdapter",
    signature=signature,
    lm_response=completion,
    message=f"Failed to parse field {k} with value {v} from the LM response. Error message: {e}",
)
```

**2. The set of parsed fields does not match the expected output fields:**

```python
if fields.keys() != signature.output_fields.keys():
    raise AdapterParseError(
        adapter_name="ChatAdapter",
        signature=signature,
        lm_response=completion,
        parsed_result=fields,
    )
```

### Catching the Exception

```python
from dspy.utils.exceptions import AdapterParseError

try:
    outputs = adapter(lm, lm_kwargs, signature, demos, inputs)
except AdapterParseError as e:
    print(f"Adapter '{e.adapter_name}' failed.")
    print(f"Raw LM response: {e.lm_response}")
    print(f"Partially parsed: {e.parsed_result}")
```

---

## Integration with the Adapter Layer

The `AdapterParseError` is a key part of the adapter error-handling strategy. Notably, the `ChatAdapter` implements a **fallback mechanism**: when its own parsing fails (raising an exception, including `AdapterParseError`), it retries the call using the `JSONAdapter` — unless the error is a `ContextWindowExceededError` or the adapter is already a `JSONAdapter`.

```mermaid
flowchart TD
    A[ChatAdapter.__call__] --> B{super().__call__ succeeds?}
    B -->|Yes| C[Return outputs]
    B -->|No, exception raised| D{ContextWindowExceededError<br/>or already JSONAdapter?}
    D -->|Yes| E[Re-raise exception]
    D -->|No| F[Retry with JSONAdapter]
    F --> C
```

This means `AdapterParseError` frequently acts as the trigger for adapter fallback behavior, making it central to DSPy's resilience when parsing LM responses.

---

## Related Modules

- [adapters](adapters.md) — The adapter implementations (`ChatAdapter`, `JSONAdapter`, `XMLAdapter`, `BAMLAdapter`, etc.) that raise `AdapterParseError`.
- [signatures](signatures.md) — The `Signature` class whose `output_fields` are used to build the diagnostic error message.
- [utils](utils.md) — The parent utilities module containing callbacks, dummies, concurrency helpers, and other shared utilities.
