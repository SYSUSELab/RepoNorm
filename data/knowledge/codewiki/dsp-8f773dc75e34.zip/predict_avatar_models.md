# predict_avatar_models

## Introduction

The `predict_avatar_models` module defines the core data models used by the **Avatar** agentic prediction system in DSPy. It provides lightweight, Pydantic-based schemas that describe:

- **Tools** available to an agent (their name, description, and expected input type).
- **Actions** the agent decides to take (which tool to invoke and with what query).
- **ActionOutputs** that record the result of executing an action.

These models act as the structured "vocabulary" that the [`Avatar`](predict_avatar_core.md) module and its [`Actor`](predict_avatar_signatures.md) signature use to reason about tool use, drive the iterative agent loop, and return a trace of executed actions to the caller.

> **Scope note:** This module contains only the data models. The orchestration logic lives in [`predict_avatar_core`](predict_avatar_core.md), and the LLM-facing signature lives in [`predict_avatar_signatures`](predict_avatar_signatures.md).

---

## Module Structure

The module is a single file, `dspy/predict/avatar/models.py`, exporting three Pydantic models:

| Component | Kind | Purpose |
|-----------|------|---------|
| `Tool` | `pydantic.BaseModel` | Describes a callable tool exposed to the agent. |
| `Action` | `pydantic.BaseModel` | Represents a decision to invoke a tool with a query. |
| `ActionOutput` | `pydantic.BaseModel` | Records the executed action and its resulting output. |

```mermaid
classDiagram
    class Tool {
        +Any tool
        +str name
        +str|None desc
        +str|None input_type
        +__str__() str
        +__repr__() str
    }

    class Action {
        +Any tool_name
        +Any tool_input_query
    }

    class ActionOutput {
        +str tool_name
        +str tool_input_query
        +str tool_output
    }

    Tool ..> Action : "referenced by name"
    Action ..> ActionOutput : "executed into"
```

---

## Component Reference

### `Tool`

A Pydantic model describing a tool that the agent may invoke.

| Field | Type | Description |
|-------|------|-------------|
| `tool` | `Any` | The underlying callable/object implementing the tool. May be `None` for the special `Finish` tool. |
| `name` | `str` | Human-readable identifier used to select the tool. |
| `desc` | `str \| None` | Description of what the tool does. |
| `input_type` | `str \| None` | Optional description of the expected input (e.g., a schema hint). Defaults to `None`. |

**Behavior:**

- `__str__` renders a compact, LLM-friendly representation:
  - With input type: `name(valid_input: <input_type>): <desc>`
  - Without input type: `name: <desc>`
- `__repr__` delegates to `__str__`, so tools print consistently in logs and prompts.

**Usage in the agent loop:** The [`Avatar`](predict_avatar_core.md) module builds a list of `Tool` objects from user-supplied tools and appends a synthetic `Finish` tool (`tool=None`, `name="Finish"`) that signals task completion. Tool names are passed to the actor as the `tools` input field, and `_call_tool` matches on `Tool.name` to dispatch execution.

### `Action`

A Pydantic model representing the agent's decision about which tool to use and what to pass to it.

| Field | Type | Description |
|-------|------|-------------|
| `tool_name` | `Any` | Name of the tool to use. |
| `tool_input_query` | `Any` | Query/input to pass to the selected tool. |

Both fields are required (`Field(...)`) and carry descriptions that are surfaced to the LLM through the signature schema. `Action` is used as the type of the dynamically generated `action_{idx}` fields on the [`Actor`](predict_avatar_signatures.md) signature, so the model's field descriptions directly guide the model's structured output.

### `ActionOutput`

A Pydantic model capturing the result of executing an `Action`. It is the record type accumulated into the `actions` list returned by the agent.

| Field | Type | Description |
|-------|------|-------------|
| `tool_name` | `str` | Name of the tool that was invoked. |
| `tool_input_query` | `str` | The query that was passed to the tool. |
| `tool_output` | `str` | The string result returned by the tool. |

Unlike `Action`, the fields here are strictly typed as `str`, reflecting that outputs are serialized back into the actor's context as text.

---

## Data Flow

The models participate in the iterative agent loop implemented by [`Avatar.forward`](predict_avatar_core.md). The flow below shows how an `Action` produced by the actor is executed and recorded as an `ActionOutput`.

```mermaid
sequenceDiagram
    participant Caller
    participant Avatar
    participant Actor as Actor (TypedPredictor)
    participant Tool
    participant ActionOutput

    Caller->>Avatar: forward(**kwargs)
    Avatar->>Actor: actor(goal, tools, ...)
    Actor-->>Avatar: action_{idx} (Action)
    Avatar->>Avatar: read action.tool_name / action.tool_input_query
    alt tool_name != "Finish"
        Avatar->>Tool: tool.run(tool_input_query)
        Tool-->>Avatar: tool_output
        Avatar->>ActionOutput: create(tool_name, query, output)
        Avatar->>Actor: update signature with result_{idx}
    else tool_name == "Finish"
        Avatar->>Avatar: break loop
    end
    Avatar-->>Caller: Prediction(outputs..., actions=[ActionOutput])
```

### Lifecycle of the models

1. **Setup** — `Avatar.__init__` wraps each user tool in a `Tool` and appends the `Finish` tool.
2. **Decision** — The `Actor` signature emits an `Action` (as `action_{idx}`) describing the next step.
3. **Execution** — `Avatar._call_tool` matches `Action.tool_name` against `Tool.name` and invokes `Tool.tool.run(Action.tool_input_query)`.
4. **Recording** — The result is stored as an `ActionOutput` and appended to `action_results`.
5. **Return** — `Avatar.forward` returns a `dspy.Prediction` whose `actions` attribute is the list of `ActionOutput` records.

---

## Dependencies

```mermaid
graph TD
    subgraph predict_avatar_models
        Tool
        Action
        ActionOutput
    end

    Tool -->|pydantic| Pydantic[BaseModel, Field]
    Action -->|pydantic| Pydantic
    ActionOutput -->|pydantic| Pydantic

    Avatar[predict_avatar_core: Avatar] -->|constructs & consumes| Tool
    Avatar -->|reads| Action
    Avatar -->|creates| ActionOutput
    Actor[predict_avatar_signatures: Actor] -->|types action fields as| Action
```

- **External:** `pydantic` (`BaseModel`, `Field`) and `typing.Any`.
- **Internal consumers:**
  - [`predict_avatar_core`](predict_avatar_core.md) — constructs `Tool` instances, reads `Action` fields, and produces `ActionOutput` records.
  - [`predict_avatar_signatures`](predict_avatar_signatures.md) — uses `Action` as the type for the dynamically appended `action_{idx}` output fields.

---

## Design Notes

- **Pydantic-based:** All three models inherit from `pydantic.BaseModel`, giving automatic validation, serialization, and JSON-schema generation. This is important because `Action`'s schema is embedded into the actor's signature and used to constrain the LLM's structured output.
- **Loose typing on `Action`:** `tool_name` and `tool_input_query` are typed as `Any` to accommodate the variety of values an LLM may emit before validation/normalization downstream.
- **Strict typing on `ActionOutput`:** Outputs are normalized to `str`, since they are fed back into the actor's context as plain text.
- **`Finish` sentinel:** The `Tool` model supports `tool=None`, enabling the synthetic `Finish` tool that terminates the loop without executing anything.

---

## Related Documentation

- [`predict_avatar_core`](predict_avatar_core.md) — The `Avatar` module that orchestrates the agent loop using these models.
- [`predict_avatar_signatures`](predict_avatar_signatures.md) — The `Actor` signature that emits `Action` objects.
- [`predict_core`](predict_core.md) — Core `Predict`/`Parameter` primitives underlying the actor.
- [`primitives`](primitives.md) — `Prediction` and `Module` base classes used for return values.
