# Adapters Types Module

## Introduction

The `adapters_types` module defines the **custom type system** used by DSPy adapters to represent rich, non-textual data within signatures. While standard Python types (`str`, `int`, `list`, etc.) cover most cases, real-world LLM applications frequently need to pass images, audio, code, conversation history, and tool definitions through the adapter pipeline.

This module provides:

- A common base class (`Type`) that all custom types inherit from.
- Concrete implementations for multimodal and structured data: `Image`, `Audio`, `Code`, `History`, `Tool`, and `ToolCalls`.
- A serialization/deserialization protocol that lets adapters embed custom types into LM messages and split them back into structured content blocks.

These types are consumed by the [adapters implementations](adapters_implementations.md) (e.g., `ChatAdapter`, `JSONAdapter`) and are referenced by [signatures](signatures.md) as field annotations.

---

## Architecture Overview

The module is organized around a single base class with a small family of concrete subclasses. Each subclass knows how to `format()` itself into a list of content parts compatible with the OpenAI-style message content schema.

```mermaid
graph TD
    Type["Type (base_type.py)<br/>pydantic.BaseModel"]
    Image["Image<br/>url: str"]
    Audio["Audio<br/>data, audio_format"]
    Code["Code<br/>code, language"]
    Tool["Tool<br/>func, name, desc, args"]
    ToolCalls["ToolCalls<br/>tool_calls: list[ToolCall]"]
    History["History<br/>messages: list[dict]"]

    Type --> Image
    Type --> Audio
    Type --> Code
    Type --> Tool
    Type --> ToolCalls
    History -.->|"standalone pydantic model<br/>(not a Type subclass)"| History

    subgraph "Helper functions"
        split["split_message_content_for_custom_types()"]
        encode_img["encode_image()"]
        encode_aud["encode_audio()"]
        resolve["_resolve_json_schema_reference()"]
    end

    split -.-> Type
    encode_img -.-> Image
    encode_aud -.-> Audio
    resolve -.-> Tool
```

> **Note:** `History` is a standalone `pydantic.BaseModel` rather than a `Type` subclass, because it is handled specially by the adapter's conversation-history formatting logic (see [adapters implementations](adapters_implementations.md)).

---

## Core Component: `Type`

**File:** `dspy/adapters/types/base_type.py`

`Type` is the parent class of all DSPy custom types. It extends `pydantic.BaseModel` and defines the contract that every custom type must fulfill.

### Key Responsibilities

| Member | Purpose |
|--------|---------|
| `format()` | Returns a `list[dict]` of content parts (OpenAI content-block schema) or a plain string. Must be implemented by subclasses. |
| `description()` | Class method returning a human-readable description used in prompts. Defaults to `""`. |
| `extract_custom_type_from_annotation()` | Recursively walks a (possibly nested) type annotation to find all custom `Type` subclasses, e.g. detecting `Tool` inside `list[dict[str, Tool]]`. |
| `serialize_model()` | Pydantic model serializer that wraps the `format()` output between reserved sentinel identifiers. |

### Serialization Protocol

When a `Type` is serialized, its `format()` output is wrapped with two reserved sentinel strings:

```
<<CUSTOM-TYPE-START-IDENTIFIER>> ... <<CUSTOM-TYPE-END-IDENTIFIER>>
```

This allows the adapter to later locate and split embedded custom-type content out of a flattened string message. The `split_message_content_for_custom_types()` helper performs the reverse operation: it scans **user** messages for the sentinels, parses the JSON payload inside, and replaces the flat string content with a list of structured content blocks.

```mermaid
sequenceDiagram
    participant Sig as Signature field
    participant Type as Type.serialize_model()
    participant Adapter as Adapter.format()
    participant Split as split_message_content_for_custom_types()
    participant LM as LM

    Sig->>Type: value with custom type
    Type->>Type: format() -> list[dict]
    Type-->>Adapter: "<<START>>[...]<<END>>"
    Adapter->>Split: messages (flat string content)
    Split->>Split: regex find sentinels, parse JSON
    Split-->>LM: messages with content blocks
```

### Example

```python
class Image(Type):
    url: str

    def format(self) -> list[dict[str, Any]]:
        return [{"type": "image_url", "image_url": {"url": self.url}}]
```

---

## Concrete Types

### `Image`

**File:** `dspy/adapters/types/image.py`

Represents an image, stored as a `url` field that may be a remote URL, a local file path, or a base64 data URI.

- **`format()`** → `[{"type": "image_url", "image_url": {"url": <encoded>}}]`
- **Constructors:** `from_url(url, download=False)`, `from_file(file_path)`, `from_PIL(pil_image)`
- **Validation:** accepts a plain string (treated as URL) or a `{"url": ...}` dict.
- **Helpers:** `encode_image()` normalizes strings, bytes, PIL images, and dicts into a data URI or URL. `is_url()` and `is_image()` provide lightweight type checks.
- **Optional dependency:** Pillow (`PIL`) is required for PIL images and raw bytes.

### `Audio`

**File:** `dspy/adapters/types/audio.py`

Represents audio data with two fields: `data` (base64-encoded) and `audio_format` (e.g. `"wav"`).

- **`format()`** → `[{"type": "input_audio", "input_audio": {"data": ..., "format": ...}}]`
- **Constructors:** `from_url(url)`, `from_file(file_path)`, `from_array(array, sampling_rate, format="wav")`
- **Validation:** the `encode_audio()` helper accepts file paths, URLs, data URIs, dicts, `Audio` instances, numpy arrays, and raw bytes.
- **Optional dependency:** `soundfile` is required for array-based encoding.

### `Code`

**File:** `dspy/adapters/types/code.py`

Represents source code with a `code: str` field and a class-level `language` attribute (default `"python"`).

- **`format()`** → returns the raw code string (no content blocks).
- **`serialize_model()`** is overridden to **bypass** the sentinel wrapping, since code is emitted as plain text.
- **`description()`** instructs the LM to emit code in markdown fenced blocks.
- **Validation:** `_filter_code()` strips markdown fences and language identifiers from incoming strings.
- **Parameterized syntax:** `dspy.Code["java"]` is supported via a patched `__class_getitem__` that dynamically creates a subclass with the given `language`.

```python
class CodeGeneration(dspy.Signature):
    question: str = dspy.InputField()
    code: dspy.Code["java"] = dspy.OutputField()
```

### `History`

**File:** `dspy/adapters/types/history.py`

Represents conversation history as `messages: list[dict[str, Any]]`, where each dict contains keys matching the signature's fields.

- Not a `Type` subclass; it is a frozen `pydantic.BaseModel`.
- Detected by the adapter via `_get_history_field_name()` (checks `field.annotation == History`).
- When present, the adapter removes the history field from the signature and expands the messages into alternating user/assistant turns.

### `Tool`

**File:** `dspy/adapters/types/tool.py`

Wraps a Python callable so it can be exposed to LLMs for function/tool calling.

- **Fields:** `func`, `name`, `desc`, `args` (JSON schema per arg), `arg_types`, `arg_desc`, `has_kwargs`.
- **`_parse_function()`** introspects the function's signature and type hints to auto-generate the JSON schema, resolving Pydantic `$ref`s via `_resolve_json_schema_reference()`.
- **`format_as_litellm_function_call()`** produces the LiteLLM/OpenAI function-calling schema.
- **Invocation:** `__call__` (sync) and `acall` (async), both decorated with `with_callbacks`. Async tools can be run synchronously when `settings.allow_tool_async_sync_conversion` is enabled.
- **Interop:** `from_mcp_tool()` and `from_langchain()` convert external tool definitions.
- **Arg validation:** `_validate_and_parse_args()` validates against the JSON schema and coerces values using a dynamically created Pydantic wrapper model.

### `ToolCalls`

**File:** `dspy/adapters/types/tool.py`

Represents the tool calls returned by an LM.

- **Nested `ToolCall`** model: `name: str`, `args: dict[str, Any]`.
- **`from_dict_list()`** builds an instance from a list of `{"name", "args"}` dicts.
- **`format()`** → `[{"type": "tool_calls", "tool_calls": [...]}]`, compatible with OpenAI's tool-call schema.
- Used as the output field type when native function calling is enabled (see `Adapter._call_postprocess`).

---

## Component Interaction

The following diagram shows how custom types flow through the adapter lifecycle. The `Adapter` base class (in [adapters implementations](adapters_implementations.md)) orchestrates formatting and parsing, while the types module supplies the serialization primitives.

```mermaid
flowchart LR
    subgraph Signature
        InFields["Input fields<br/>(may include Image, Audio, Tool, History)"]
        OutFields["Output fields<br/>(may include Code, ToolCalls)"]
    end

    subgraph Adapter["Adapter (base.py)"]
        Pre["_call_preprocess()<br/>detect Tool/ToolCalls"]
        Fmt["format()"]
        Post["_call_postprocess()<br/>parse outputs"]
    end

    subgraph Types["adapters_types"]
        T["Type.format()"]
        Split["split_message_content_for_custom_types()"]
        TC["ToolCalls.from_dict_list()"]
    end

    InFields --> Pre --> Fmt
    Fmt --> T --> Split
    Split --> LM["LM call"]
    LM --> Post --> TC --> OutFields
```

### Type Detection Helpers

The `Adapter` base class relies on the types module to identify special fields:

| Adapter helper | Detects |
|----------------|---------|
| `_get_history_field_name()` | `History` annotation |
| `_get_tool_call_input_field_name()` | `Tool` or `list[Tool]` annotation |
| `_get_tool_call_output_field_name()` | `ToolCalls` annotation |

---

## Dependencies

```mermaid
graph TD
    types["adapters_types"]
    base_type["base_type.Type"]
    settings["dsp_utils.Settings"]
    callbacks["utils.BaseCallback"]
    exceptions["utils.AdapterParseError"]
    pydantic["pydantic"]
    jsonschema["jsonschema"]
    jsonrepair["json_repair"]
    requests["requests"]
    PIL["PIL (optional)"]
    sf["soundfile (optional)"]

    types --> base_type
    types --> settings
    types --> callbacks
    types --> pydantic
    types --> jsonschema
    types --> jsonrepair
    types --> requests
    types --> PIL
    types --> sf
    base_type --> pydantic
    base_type --> jsonrepair
```

| Dependency | Used by | Purpose |
|------------|---------|---------|
| `pydantic` | All types | Model definition, validation, serialization |
| `json_repair` | `base_type`, `tool` | Lenient JSON parsing of LM output |
| `jsonschema` | `tool` | Validate tool arguments against schema |
| `requests` | `image`, `audio` | Download remote media |
| `PIL` (optional) | `image` | Encode PIL images / raw bytes |
| `soundfile` (optional) | `audio` | Encode numpy arrays to audio |
| [Settings](dsp_utils.md) | `tool` | `allow_tool_async_sync_conversion` flag |
| [BaseCallback](utils.md) | `tool` | `with_callbacks` decorator |

---

## Process Flow: Custom Type Round-Trip

```mermaid
sequenceDiagram
    participant User
    participant Predict as Predict
    participant Adapter as Adapter
    participant Type as Type subclass
    participant LM

    User->>Predict: call with Image/Audio/Tool inputs
    Predict->>Adapter: __call__(lm, kwargs, signature, demos, inputs)
    Adapter->>Adapter: _call_preprocess (detect Tool/ToolCalls)
    Adapter->>Type: serialize_model() -> sentinel-wrapped string
    Adapter->>Adapter: split_message_content_for_custom_types()
    Adapter->>LM: messages with content blocks
    LM-->>Adapter: raw completion
    Adapter->>Adapter: _call_postprocess -> parse()
    Adapter->>Type: construct Code / ToolCalls from output
    Adapter-->>Predict: parsed output dict
    Predict-->>User: Prediction
```

---

## Related Modules

- [adapters implementations](adapters_implementations.md) — `Adapter`, `ChatAdapter`, `JSONAdapter`, `XMLAdapter`, `TwoStepAdapter`, `BAMLAdapter` that consume these types.
- [signatures](signatures.md) — where custom types appear as field annotations.
- [predict core](predict_core.md) — `Predict` and related modules that invoke adapters.
- [utils](utils.md) — `AdapterParseError`, `BaseCallback`, and other shared utilities.
- [dsp utils](dsp_utils.md) — `Settings` used by `Tool` for async/sync conversion.
