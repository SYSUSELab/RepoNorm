# Clients Core Provider

## Introduction

The `clients_core_provider` module defines the **provider abstraction layer** for DSPy's language model clients. It establishes a uniform interface that decouples the core `LM` client from the concrete backends (OpenAI, Databricks, local servers, Arbor, etc.) that actually serve models, run fine-tuning jobs, and execute reinforcement-learning (RL) training loops.

The module is intentionally lightweight and contains only three classes:

- **`Provider`** — the base class that every concrete provider subclasses. It declares the capabilities (fine-tuning, reinforcement learning), lifecycle hooks (launch/kill), and the fine-tuning entry point.
- **`TrainingJob`** — a `Future` subclass representing an asynchronous fine-tuning job, carrying training data, format, and provider-specific state.
- **`ReinforceJob`** — an abstract base class representing a stateful reinforcement-learning training session (initialize → step → checkpoint → terminate).

Together these classes form the contract that the [`clients_core_lm`](clients_core_lm.md) module relies on to support `LM.finetune(...)`, `LM.reinforce(...)`, `LM.launch(...)`, and `LM.kill(...)`.

---

## Architecture Overview

The provider layer sits between the high-level `LM` client and the concrete provider implementations. The `LM` object holds a reference to a `Provider` instance and delegates all backend-specific operations to it.

```mermaid
graph TD
    subgraph "Core Client Layer"
        LM["LM (clients_core_lm)"]
        BaseLM["BaseLM (clients_core_base_lm)"]
        LM --> BaseLM
    end

    subgraph "Provider Abstraction (this module)"
        Provider["Provider"]
        TrainingJob["TrainingJob (Future)"]
        ReinforceJob["ReinforceJob"]
    end

    subgraph "Concrete Providers"
        OpenAI["OpenAIProvider"]
        Databricks["DatabricksProvider"]
        Local["LocalProvider"]
        Arbor["ArborProvider"]
    end

    subgraph "Job Implementations"
        TJOpenAI["TrainingJobOpenAI"]
        TJArbor["ArborTrainingJob"]
        RJArbor["ArborReinforceJob"]
    end

    LM -->|"holds instance of"| Provider
    LM -->|"creates via provider.TrainingJob"| TrainingJob
    LM -->|"creates via provider.ReinforceJob"| ReinforceJob

    Provider --> OpenAI
    Provider --> Databricks
    Provider --> Local
    Provider --> Arbor

    TrainingJob --> TJOpenAI
    TrainingJob --> TJArbor
    ReinforceJob --> RJArbor

    OpenAI --> TJOpenAI
    Arbor --> TJArbor
    Arbor --> RJArbor
```

### Key Design Principles

1. **Capability flags** — `Provider.finetunable` and `Provider.reinforceable` advertise what a provider supports. The `LM` client asserts on these flags before attempting an operation, producing clear error messages.
2. **Class-level job factories** — `Provider.TrainingJob` and `Provider.ReinforceJob` are class attributes pointing to the job classes a provider uses. This lets `LM` instantiate the correct job type without knowing the provider's internals.
3. **Static methods for stateless operations** — `is_provider_model`, `launch`, `kill`, and `finetune` are static methods, allowing provider auto-discovery and invocation without instantiating the provider.
4. **Future-based async jobs** — `TrainingJob` extends `concurrent.futures.Future`, so fine-tuning runs on a background thread and callers can `job.result()` to block until completion.

---

## Core Components

### `Provider`

The base class for all model providers. It defines the interface and default (no-op or unsupported) behavior.

| Member | Type | Purpose |
| --- | --- | --- |
| `finetunable` | `bool` (instance attr) | Whether the provider supports fine-tuning. Defaults to `False`. |
| `reinforceable` | `bool` (instance attr) | Whether the provider supports RL training. Defaults to `False`. |
| `TrainingJob` | class attr | The `TrainingJob` subclass this provider uses. Defaults to `TrainingJob`. |
| `ReinforceJob` | class attr | The `ReinforceJob` subclass this provider uses. Defaults to `ReinforceJob`. |
| `is_provider_model(model)` | static | Returns `True` if the provider can serve the given model string. Used for auto-discovery. Defaults to `False`. |
| `launch(lm, launch_kwargs)` | static | Launches a model server for the given `LM`. Default is a no-op. |
| `kill(lm, launch_kwargs)` | static | Tears down a launched model server. Default is a no-op. |
| `finetune(job, model, train_data, train_data_format, train_kwargs)` | static | Runs a fine-tuning job and returns the resulting model identifier. Raises `NotImplementedError` by default. |

**Notes on `launch`/`kill`:** These methods may be called even when no model is launched (or when one is already running), so implementations must be resilient to such cases. The `launch_kwargs` argument is reused for `kill` because the `LM.launch_kwargs` dictionary is assumed to contain all information needed for both operations.

### `TrainingJob`

A `concurrent.futures.Future` subclass representing an asynchronous fine-tuning job.

```python
class TrainingJob(Future):
    def __init__(self, thread=None, model=None, train_data=None,
                 train_data_format=None, train_kwargs=None):
        ...
```

| Attribute | Description |
| --- | --- |
| `thread` | The background `Thread` executing the fine-tuning work. |
| `model` | The model identifier to be fine-tuned. |
| `train_data` | The list of training examples. |
| `train_data_format` | A [`TrainDataFormat`](clients_finetune_utils.md) value describing the data layout. |
| `train_kwargs` | Provider-specific training hyperparameters. |

**Methods:**

- `cancel()` — Calls `super().cancel()` to mark the future as cancelled. Subclasses should override this to first cancel the remote job (and clean up uploaded files), then call `super().cancel()`.
- `status()` — Abstract; returns a [`TrainingStatus`](clients_finetune_utils.md). Must be implemented by subclasses.

Because `TrainingJob` is a `Future`, the `LM` client sets its result (either a new `LM` instance or an exception) once the background thread finishes.

### `ReinforceJob`

An abstract base class representing a stateful reinforcement-learning training session. Unlike `TrainingJob`, it is not a `Future`; it is driven imperatively by a teleprompter (e.g., [`GRPO`](teleprompt_finetune.md)).

```python
class ReinforceJob:
    def __init__(self, lm, train_kwargs=None):
        self.lm = lm
        self.train_kwargs = train_kwargs or {}
        self.checkpoints = {}
        self.last_checkpoint = None
```

| Attribute | Description |
| --- | --- |
| `lm` | The `LM` instance being trained. |
| `train_kwargs` | RL hyperparameters (e.g., `num_generations`, `beta`, `learning_rate`). |
| `checkpoints` | Mapping of checkpoint name → metadata (e.g., model path, score). |
| `last_checkpoint` | The most recently saved checkpoint name. |

**Abstract lifecycle methods:**

| Method | Purpose |
| --- | --- |
| `initialize()` | Set up the RL session on the provider (e.g., create a remote job). |
| `step(train_data, train_data_format)` | Run one training step over a batch of data. |
| `terminate()` | Finalize the session and release resources. |
| `update_model()` | Update the underlying model reference. |
| `save_checkpoint(checkpoint_name)` | Persist the current model state. |
| `cancel()` | Cancel the RL job. |
| `status()` | Return the current [`TrainingStatus`](clients_finetune_utils.md). |

---

## Component Interaction & Data Flow

### Fine-Tuning Flow

The following sequence shows how a fine-tuning request flows from the user through the `LM` client, the `Provider`, and a concrete provider implementation.

```mermaid
sequenceDiagram
    participant User
    participant LM as LM (clients_core_lm)
    participant Provider as Provider
    participant Job as TrainingJob
    participant Thread as Background Thread
    participant Remote as Remote Provider API

    User->>LM: lm.finetune(train_data, format, kwargs)
    LM->>LM: assert provider.finetunable
    LM->>Job: provider.TrainingJob(...)
    LM->>Thread: thread.start()
    LM-->>User: return job (Future)
    Thread->>Provider: provider.finetune(job, model, ...)
    Provider->>Remote: upload data / start job / poll
    Remote-->>Provider: trained model id
    Provider-->>Thread: model id
    Thread->>Job: job.set_result(lm.copy(model=model))
    User->>Job: job.result()
    Job-->>User: new LM instance
```

### Reinforcement-Learning Flow

```mermaid
sequenceDiagram
    participant Teleprompter as GRPO Teleprompter
    participant LM as LM (clients_core_lm)
    participant RJ as ReinforceJob
    participant Remote as Remote Provider API

    Teleprompter->>LM: lm.reinforce(train_kwargs)
    LM->>LM: assert provider.reinforceable
    LM->>RJ: provider.ReinforceJob(lm, train_kwargs)
    LM->>RJ: job.initialize()
    RJ->>Remote: POST /grpo/initialize
    Remote-->>RJ: current_model, job_id
    loop training iterations
        Teleprompter->>RJ: job.step(train_data, format)
        RJ->>Remote: POST /grpo/step
        Remote-->>RJ: current_model
    end
    Teleprompter->>RJ: job.save_checkpoint(name, score)
    RJ->>Remote: POST /grpo/checkpoint
    Teleprompter->>RJ: job.terminate()
    RJ->>Remote: POST /grpo/terminate
    Remote-->>RJ: current_model
```

---

## Provider Discovery

When an `LM` is constructed without an explicit `provider`, it calls `infer_provider()`, which iterates over known providers and asks each `is_provider_model(model)`. The first provider that returns `True` is used; otherwise the base `Provider` (which supports nothing) is returned.

```mermaid
flowchart TD
    A["LM(model='openai/gpt-4o')"] --> B{"provider passed?"}
    B -- yes --> C["use given provider"]
    B -- no --> D["infer_provider()"]
    D --> E{"OpenAIProvider.is_provider_model(model)?"}
    E -- yes --> F["OpenAIProvider()"]
    E -- no --> G["Provider() (base, no capabilities)"]
```

Concrete providers override `is_provider_model` to match their model naming conventions. For example, `OpenAIProvider` matches base OpenAI models and fine-tuned models with the `ft:<base>:` prefix.

---

## Relationship to Other Modules

| Module | Relationship |
| --- | --- |
| [`clients_core_lm`](clients_core_lm.md) | The `LM` client holds a `Provider` instance and delegates `finetune`, `reinforce`, `launch`, and `kill` to it. `LM.infer_provider()` performs provider auto-discovery. |
| [`clients_core_base_lm`](clients_core_base_lm.md) | `LM` extends `BaseLM`; the provider layer is orthogonal to the base LM interface. |
| [`clients_finetune_utils`](clients_finetune_utils.md) | Defines `TrainDataFormat` and `TrainingStatus`, which are used throughout `TrainingJob`, `ReinforceJob`, and provider implementations. |
| [`clients_providers`](clients_providers.md) | Contains the concrete provider implementations (`OpenAIProvider`, `DatabricksProvider`, `LocalProvider`, `ArborProvider`) and their job subclasses. |
| [`teleprompt_finetune`](teleprompt_finetune.md) | Teleprompters such as `BootstrapFinetune` and `GRPO` drive `TrainingJob` and `ReinforceJob` instances respectively. |

---

## Extending the Provider Layer

To add support for a new backend, subclass `Provider` and (optionally) `TrainingJob` / `ReinforceJob`:

```python
class MyProvider(Provider):
    def __init__(self):
        super().__init__()
        self.finetunable = True          # advertise capability
        self.TrainingJob = MyTrainingJob  # wire up the job class

    @staticmethod
    def is_provider_model(model: str) -> bool:
        return model.startswith("myprovider/")

    @staticmethod
    def finetune(job, model, train_data, train_data_format, train_kwargs=None) -> str:
        # upload data, start remote job, poll, return trained model id
        ...
```

For RL support, additionally set `self.reinforceable = True` and `self.ReinforceJob = MyReinforceJob`, implementing the full `initialize`/`step`/`terminate`/`save_checkpoint` lifecycle.

### Implementation Checklist

- [ ] Set `finetunable` / `reinforceable` flags accurately.
- [ ] Assign `TrainingJob` / `ReinforceJob` class attributes.
- [ ] Implement `is_provider_model` for auto-discovery (if desired).
- [ ] Implement `finetune` to return the trained model identifier.
- [ ] Override `TrainingJob.cancel()` to cancel the remote job and clean up files, then call `super().cancel()`.
- [ ] Implement `TrainingJob.status()` returning a `TrainingStatus`.
- [ ] For RL: implement the full `ReinforceJob` lifecycle.
- [ ] Make `launch`/`kill` resilient to being called in any state.
