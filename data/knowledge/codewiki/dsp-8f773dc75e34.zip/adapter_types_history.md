# Adapter Types: History

## Introduction

The `History` type is a core DSPy custom type that represents **conversation history** within a DSPy signature. It enables multi-turn conversational interactions by allowing a signature to declare a field that carries prior exchanges between the user and the language model. When an adapter formats a signature for an LM call, the `History` field is detected and expanded into proper multi-turn `user`/`assistant` message pairs, rather than being serialized as a single field value.

This module (`dspy/adapters/types/history.py`) contains a single core component: the `History` class. It is part of the broader [adapter types](adapter_types.md) family, which also includes `Image`, `Audio`, `Code`, and `Tool`.

---

## Core Component: `History`

`History` is a Pydantic `BaseModel` subclass that holds a list of message dictionaries. Each message dictionary is expected to contain keys matching the fields of the associated signature (e.g., `question` and `answer`).

```python
class History(pydantic.BaseModel):
    messages: list[dict[str, Any]]

    model_config = {
        "frozen": True,
        "str_strip_whitespace": True,
        "validate_assignment": True,
        "extra": "forbid",
    }
```

### Fields

| Field | Type | Description |
|-------|------|-------------|
| `messages` | `list[dict[str, Any]]` | A list of message dictionaries. Each dictionary's keys should correspond to the fields of the signature in which the `History` is used. |

### Model Configuration

The `model_config` enforces strict, immutable semantics:

| Setting | Value | Effect |
|---------|-------|--------|
| `frozen` | `True` | Instances are immutable after creation; assignment to attributes raises an error. |
| `str_strip_whitespace` | `True` | Leading/trailing whitespace is stripped from string values. |
| `validate_assignment` | `True` | Validation runs on attribute assignment (relevant only when not frozen). |
| `extra` | `"forbid"` | Unknown fields are rejected, preventing accidental typos or schema drift. |

> **Note:** Unlike other custom types such as `Image`, `Audio`, and `Code`, `History` does **not** subclass the base [`Type`](adapter_types_base.md) class and does **not** implement a `format()` method. This is intentional: `History` is not serialized into a single content part. Instead, it is handled specially by the adapter layer, which expands it into multiple messages.

---

## How `History` Fits into the Type System

The DSPy custom type hierarchy is rooted at [`Type`](adapter_types_base.md). Most custom types implement `format()` to produce OpenAI-style content parts. `History` is a special case that participates in the type system through **adapter-level detection** rather than serialization.

```mermaid
classDiagram
    class Type {
        +format() list~dict~ | str
        +description() str
        +extract_custom_type_from_annotation(annotation)
        +serialize_model()
    }
    class Image {
        +url: str
        +format()
    }
    class Audio {
        +data: str
        +audio_format: str
        +format()
    }
    class Code {
        +code: str
        +language: ClassVar~str~
        +format()
    }
    class Tool {
        +func: Callable
        +name: str
        +format()
    }
    class History {
        +messages: list~dict~
    }

    Type <|-- Image
    Type <|-- Audio
    Type <|-- Code
    Type <|-- Tool
    History ..> Type : special-cased (not a subclass)
```

---

## Usage

### Declaring a `History` Field in a Signature

A `History` field is declared as an input field of a signature. The message dictionaries should use the same keys as the signature's fields.

```python
import dspy

dspy.settings.configure(lm=dspy.LM("openai/gpt-4o-mini"))

class MySignature(dspy.Signature):
    question: str = dspy.InputField()
    history: dspy.History = dspy.InputField()
    answer: str = dspy.OutputField()

history = dspy.History(
    messages=[
        {"question": "What is the capital of France?", "answer": "Paris"},
        {"question": "What is the capital of Germany?", "answer": "Berlin"},
    ]
)

predict = dspy.Predict(MySignature)
outputs = predict(question="What is the capital of France?", history=history)
```

### Capturing Conversation History

A common pattern is to capture the outputs of a prediction and append them to the history for the next turn.

```python
predict = dspy.Predict(MySignature)
outputs = predict(question="What is the capital of France?")
history = dspy.History(messages=[{"question": "What is the capital of France?", **outputs}])
outputs_with_history = predict(question="Are you sure?", history=history)
```

---

## Integration with the Adapter Layer

The `History` type is consumed by the [`Adapter`](adapters_implementations.md) base class during message formatting. The adapter performs the following steps:

1. **Detection** — `Adapter._get_history_field_name()` scans the signature's input fields for any field annotated with `History`.
2. **Signature transformation** — The history field is removed from the signature (`signature.delete(history_field_name)`) so it is not treated as a regular input field.
3. **Expansion** — `Adapter.format_conversation_history()` iterates over `History.messages` and converts each message dictionary into a `user` message (via `format_user_message_content`) followed by an `assistant` message (via `format_assistant_message_content`).
4. **Assembly** — The expanded history messages are inserted between the few-shot demos and the current user request in the final message list.

### Message Assembly Flow

```mermaid
flowchart TD
    A[Adapter.format called] --> B{History field in signature?}
    B -- No --> C[Build system message]
    C --> D[Append demos]
    D --> E[Append current user input]
    E --> F[Return messages]
    B -- Yes --> G[Delete history field from signature]
    G --> H[format_conversation_history]
    H --> I[For each message in History.messages]
    I --> J[Append user message]
    J --> K[Append assistant message]
    K --> I
    I --> L[Build system message]
    L --> M[Append demos]
    M --> N[Append expanded history messages]
    N --> O[Append current user input]
    O --> F
```

### Resulting Message Structure

When a `History` field is present, the final message list passed to the LM follows this structure:

```
[
    {"role": "system",    "content": <field description + structure + task>},
    # few-shot demos
    {"role": "user",      "content": <demo 1 input>},
    {"role": "assistant", "content": <demo 1 output>},
    ...
    # expanded conversation history
    {"role": "user",      "content": <history message 1 input>},
    {"role": "assistant", "content": <history message 1 output>},
    {"role": "user",      "content": <history message 2 input>},
    {"role": "assistant", "content": <history message 2 output>},
    ...
    # current request
    {"role": "user",      "content": <current input>},
]
```

---

## Component Interaction Diagram

The following diagram shows how `History` interacts with the adapter and signature subsystems.

```mermaid
sequenceDiagram
    participant User
    participant Predict as dspy.Predict
    participant Adapter as Adapter (ChatAdapter/JSONAdapter)
    participant Signature
    participant LM

    User->>Predict: predict(question=..., history=History(...))
    Predict->>Adapter: __call__(lm, signature, inputs)
    Adapter->>Signature: _get_history_field_name(signature)
    Signature-->>Adapter: "history"
    Adapter->>Signature: delete("history")
    Signature-->>Adapter: signature_without_history
    Adapter->>Adapter: format_conversation_history(...)
    Note over Adapter: Expand History.messages into<br/>user/assistant pairs
    Adapter->>LM: messages=[system, demos, history..., current]
    LM-->>Adapter: completion
    Adapter-->>Predict: parsed outputs
    Predict-->>User: Prediction
```

---

## Design Rationale

| Aspect | Rationale |
|--------|-----------|
| **Not a `Type` subclass** | `History` represents multiple messages, not a single content part. Serializing it via `format()` would lose the turn structure. |
| **Frozen model** | Conversation history is treated as an immutable snapshot, preventing accidental mutation across turns. |
| **`extra="forbid"`** | Ensures message dictionaries conform exactly to the expected schema, catching errors early. |
| **Adapter-level handling** | Keeps the type definition minimal while allowing each adapter to render history in its own message format. |

---

## Related Documentation

- [Adapter Types Overview](adapter_types.md) — The full family of DSPy custom types.
- [Adapter Types: Base Type](adapter_types_base.md) — The `Type` base class and its `format()` contract.
- [Adapter Types: Tool](adapter_types_tool.md) — Tool calling types (`Tool`, `ToolCalls`).
- [Adapter Types: Media](adapter_types_media.md) — `Image` and `Audio` types.
- [Adapter Types: Code](adapter_types_code.md) — The `Code` type.
- [Adapter Implementations](adapters_implementations.md) — `ChatAdapter`, `JSONAdapter`, `XMLAdapter`, and the `Adapter` base class that consumes `History`.
