# Utils Hasher Module

## Introduction

The `utils_hasher` module provides a lightweight, deterministic hashing utility for arbitrary Python objects. Its core component, the `Hasher` class, converts Python objects into stable hexadecimal digest strings using the fast [xxHash](https://github.com/Cyan4973/xxHash) algorithm (`xxh64`).

The primary purpose of this module is to generate **stable, content-based fingerprints** for Python objects. These fingerprints are used throughout DSPy for tasks such as:

- Generating cache keys for language model requests (see [clients_core](clients_core.md)).
- Producing deterministic identifiers for examples, signatures, and other data structures.
- Supporting reproducible behavior in tests and optimizers.

The implementation is **vendored** from the Hugging Face `datasets` package (Apache License 2.0) to avoid a hard dependency on the large `datasets` package, which is unnecessary for the majority of DSPy use cases.

---

## Architecture Overview

The module is intentionally minimal, consisting of a single class with class-level and instance-level hashing capabilities.

```mermaid
graph TD
    subgraph "utils_hasher module"
        H[Hasher]
    end

    subgraph "External Dependencies"
        XX[xxhash.xxh64]
        PK[pickle.dumps]
    end

    H -->|uses| XX
    H -->|uses| PK

    subgraph "Consumers"
        C[Cache<br/>clients_core]
        D[DummyVectorizer<br/>utils_dummies]
        O[Optimizers / Teleprompters]
    end

    C -.->|content fingerprints| H
    D -.->|n-gram hashing pattern| H
    O -.->|object identity| H
```

---

## Core Component: `Hasher`

The `Hasher` class accepts arbitrary Python objects as inputs and produces deterministic hash digests. It supports two usage patterns:

1. **Class-level (stateless) hashing** — one-shot hashing of a value via `Hasher.hash(...)` or `Hasher.hash_bytes(...)`.
2. **Instance-level (stateful) hashing** — incremental accumulation of multiple values via `update(...)`, finalized with `hexdigest()`.

### Class Diagram

```mermaid
classDiagram
    class Hasher {
        +dict dispatch
        +xxh64 m
        +__init__()
        +hash_bytes(value: bytes | list[bytes]) str
        +hash(value: Any) str
        +update(value: Any) None
        +hexdigest() str
    }
```

### Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `dispatch` | `dict` | Class-level registry reserved for custom type-specific hashing dispatch. Currently empty; present for extensibility and compatibility with the upstream `datasets` implementation. |
| `m` | `xxhash.xxh64` | Instance-level incremental hasher state, initialized in `__init__`. Used by `update()` and `hexdigest()`. |

### Methods

#### `__init__(self)`

Initializes a new incremental hasher instance by creating an `xxhash.xxh64()` object stored in `self.m`.

```python
def __init__(self):
    self.m = xxhash.xxh64()
```

#### `hash_bytes(cls, value: bytes | list[bytes]) -> str` *(classmethod)*

Hashes raw bytes (or a list of byte chunks) and returns the hexadecimal digest. This is the lowest-level hashing primitive.

- If a single `bytes` object is passed, it is wrapped in a list.
- Each chunk is fed into a fresh `xxh64` hasher via `update`.
- Returns the hex digest string.

```python
@classmethod
def hash_bytes(cls, value: bytes | list[bytes]) -> str:
    value = [value] if isinstance(value, bytes) else value
    m = xxhash.xxh64()
    for x in value:
        m.update(x)
    return m.hexdigest()
```

#### `hash(cls, value: Any) -> str` *(classmethod)*

Hashes an arbitrary Python object by first serializing it with `pickle.dumps`, then delegating to `hash_bytes`. This makes the method applicable to nearly any picklable Python object.

```python
@classmethod
def hash(cls, value: Any) -> str:
    return cls.hash_bytes(dumps(value))
```

> **Note:** Because `pickle` is used, the resulting hash is sensitive to the object's pickled byte representation. Objects that are not picklable will raise an exception.

#### `update(self, value: Any) -> None`

Incrementally adds a value to the instance's running hash state. To avoid collisions between values of different types that may serialize identically, a **type header** (`==<type>==`) is prepended before the value's hash.

```python
def update(self, value: Any) -> None:
    header_for_update = f"=={type(value)}=="
    value_for_update = self.hash(value)
    self.m.update(header_for_update.encode("utf8"))
    self.m.update(value_for_update.encode("utf-8"))
```

#### `hexdigest(self) -> str`

Returns the hexadecimal digest of the accumulated instance state.

```python
def hexdigest(self) -> str:
    return self.m.hexdigest()
```

---

## Data Flow

The following diagram illustrates how a Python object flows through the hashing pipeline for both the stateless and stateful APIs.

```mermaid
flowchart TD
    A[Python Object] --> B{API Style}

    B -->|Stateless| C["Hasher.hash(value)"]
    C --> D["pickle.dumps(value)"]
    D --> E["Hasher.hash_bytes(bytes)"]
    E --> F["xxh64.update(chunks)"]
    F --> G["hexdigest()"]

    B -->|Stateful| H["Hasher().update(value)"]
    H --> I["type header: ==<type>=="]
    H --> J["Hasher.hash(value)"]
    I --> K["m.update(header)"]
    J --> L["m.update(value_hash)"]
    K --> M["Hasher().hexdigest()"]
    L --> M
```

---

## Usage Examples

### Stateless Hashing

```python
from dspy.utils.hasher import Hasher

# Hash an arbitrary object
digest = Hasher.hash({"question": "What is 2+2?", "answer": "4"})
print(digest)  # e.g. "a1b2c3d4e5f6..."

# Hash raw bytes
digest = Hasher.hash_bytes(b"hello world")
```

### Stateful / Incremental Hashing

```python
from dspy.utils.hasher import Hasher

hasher = Hasher()
hasher.update("first value")
hasher.update({"key": "second value"})
hasher.update([1, 2, 3])

combined_digest = hasher.hexdigest()
```

The type header ensures that, for example, the string `"1"` and the integer `1` produce different contributions to the running hash.

---

## Integration with the Broader System

The `Hasher` is a foundational utility consumed by several other DSPy modules. The table below summarizes key relationships.

| Consumer | Relationship | Reference |
|----------|--------------|-----------|
| `Cache` | Uses content-based fingerprints to build cache keys for LM requests. | [clients_core](clients_core.md) |
| `DummyVectorizer` | Uses a polynomial hashing scheme (conceptually similar) to map n-grams to vector indices. | [utils_dummies](utils_dummies.md) |
| Optimizers / Teleprompters | May use stable object fingerprints for reproducibility. | [teleprompt_core](teleprompt_core.md) |

```mermaid
graph LR
    Hasher --> Cache
    Hasher --> DummyVectorizer
    Hasher --> Optimizers

    Cache --> LM[LM / BaseLM]
    LM --> Predict[Predict / Modules]
```

> **Note:** The `Cache` class in [clients_core](clients_core.md) uses `sha256` over a JSON representation for its cache keys, while `Hasher` uses `xxh64` over pickled bytes. Both serve the goal of deterministic content fingerprinting but are optimized for different input types (JSON-serializable request dicts vs. arbitrary Python objects).

---

## Design Considerations

### Why xxHash?

`xxhash` (`xxh64`) is an extremely fast, non-cryptographic hash algorithm. It is well-suited for fingerprinting and caching where speed matters more than cryptographic collision resistance.

### Why pickle?

Using `pickle.dumps` allows the `Hasher` to accept arbitrary Python objects without requiring callers to pre-serialize them. The trade-off is that the hash depends on the pickled representation, which can vary across Python versions or object definitions.

### Type Headers in `update()`

The `==<type>==` header in `update()` prevents cross-type collisions where two distinct objects might otherwise serialize to the same bytes. This is important for incremental hashing where multiple heterogeneous values are combined.

### Vendoring Rationale

The class is vendored from Hugging Face's `datasets` package to avoid a hard dependency on a large library. Only the minimal hashing functionality is retained, reformatted to DSPy style.

---

## Related Modules

- [clients_core](clients_core.md) — Caching layer that relies on deterministic fingerprints.
- [utils_dummies](utils_dummies.md) — Test utilities including `DummyVectorizer`, which uses a related hashing approach.
- [utils](utils.md) — The parent utilities package.
