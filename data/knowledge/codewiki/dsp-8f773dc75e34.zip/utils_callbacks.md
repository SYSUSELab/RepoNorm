# Utils Callbacks

## Introduction

The `utils_callbacks` module provides DSPy's **callback and instrumentation framework**. It defines the `BaseCallback` class — a base class that developers subclass to hook into the lifecycle of core DSPy components (modules, language models, adapters, tools, and evaluation). The module also provides the `with_callbacks` decorator, which transparently wraps component methods so that registered callbacks are invoked before and after execution.

This module is the foundation for observability, logging, tracing, and monitoring across DSPy. It is consumed by nearly every core component, including [clients_core](clients_core.md) (`LM`), [adapters](adapters.md) (`Adapter`), [evaluate](evaluate.md) (`Evaluate`), [adapter_types](adapter_types.md) (`Tool`), and [primitives](primitives.md) (`Module`).

---

## Core Components

| Component | Location | Description |
|-----------|----------|-------------|
| `BaseCallback` | `dspy/utils/callback.py` | Base class defining all lifecycle handler hooks. |
| `with_callbacks` | `dspy/utils/callback.py` | Decorator that wraps instance methods to fire start/end callbacks. |
| `ACTIVE_CALL_ID` | `dspy/utils/callback.py` | A `ContextVar` tracking the currently active call ID for nesting. |
| `_get_on_start_handler` / `_get_on_end_handler` | `dspy/utils/callback.py` | Internal dispatchers that select the correct handler based on instance type. |

---

## Architecture Overview

The callback system is built around three cooperating pieces:

1. **`BaseCallback`** — the user-facing extension point. Users subclass it and override the handlers they care about.
2. **`with_callbacks`** — a decorator applied to component methods (e.g., `LM.__call__`, `Adapter.format`, `Tool.__call__`, `Evaluate.__call__`). It intercepts the call, resolves the active callbacks, and fires the appropriate start/end handlers.
3. **`ACTIVE_CALL_ID`** — a context variable that tracks the call ID of the currently executing component, enabling parent/child call correlation across nested invocations.

```mermaid
graph TD
    User["User-defined Callback<br/>(subclass of BaseCallback)"]
    Settings["dspy.settings<br/>(global callbacks)"]
    Instance["Component instance<br/>(instance-level callbacks)"]

    User --> Settings
    User --> Instance

    Settings --> WC["with_callbacks decorator"]
    Instance --> WC

    WC --> Dispatcher["_get_on_start_handler /<br/>_get_on_end_handler"]
    Dispatcher --> Handlers["on_*_start / on_*_end handlers"]

    WC --> CtxVar["ACTIVE_CALL_ID<br/>(ContextVar)"]
```

---

## Component Interaction

The `with_callbacks` decorator is applied to methods of several core components. When such a method is invoked, the decorator resolves the union of **global** callbacks (from `dspy.settings`) and **instance-level** callbacks (from the instance's `callbacks` attribute), then dispatches to the correct handler.

```mermaid
graph LR
    subgraph "Instrumented Components"
        LM["LM.__call__ / acall<br/>(clients_core)"]
        Adapter["Adapter.format / parse<br/>(adapters)"]
        Tool["Tool.__call__ / acall<br/>(adapter_types)"]
        Evaluate["Evaluate.__call__<br/>(evaluate)"]
        Module["Module.forward<br/>(primitives)"]
    end

    LM --> WC["with_callbacks"]
    Adapter --> WC
    Tool --> WC
    Evaluate --> WC
    Module --> WC

    WC --> CB["BaseCallback handlers"]
```

### Handler Dispatch Table

The internal dispatchers `_get_on_start_handler` and `_get_on_end_handler` map the runtime instance type (and, for adapters, the method name) to the correct handler:

| Instance Type | Method | Start Handler | End Handler |
|---------------|--------|---------------|-------------|
| `dspy.LM` | any | `on_lm_start` | `on_lm_end` |
| `dspy.Evaluate` | any | `on_evaluate_start` | `on_evaluate_end` |
| `dspy.Adapter` | `format` | `on_adapter_format_start` | `on_adapter_format_end` |
| `dspy.Adapter` | `parse` | `on_adapter_parse_start` | `on_adapter_parse_end` |
| `dspy.Tool` | any | `on_tool_start` | `on_tool_end` |
| anything else | any | `on_module_start` | `on_module_end` |

> **Note:** Any instance that is not one of the recognized types is treated as a module, so `on_module_start` / `on_module_end` act as the default handlers.

---

## Callback Lifecycle

Every instrumented method call follows the same lifecycle, regardless of whether it is synchronous or asynchronous:

```mermaid
sequenceDiagram
    participant Caller
    participant Wrapper as with_callbacks wrapper
    participant Ctx as ACTIVE_CALL_ID
    participant Start as on_*_start handlers
    participant Fn as Wrapped function
    participant End as on_*_end handlers

    Caller->>Wrapper: invoke method(*args, **kwargs)
    Wrapper->>Wrapper: resolve active callbacks
    alt no callbacks
        Wrapper->>Fn: call directly
        Fn-->>Caller: return result
    else callbacks present
        Wrapper->>Wrapper: generate call_id (uuid4)
        Wrapper->>Start: on_*_start(call_id, instance, inputs)
        Wrapper->>Ctx: save parent_call_id, set call_id
        Wrapper->>Fn: call function
        alt success
            Fn-->>Wrapper: results
        else exception
            Fn-->>Wrapper: raise exception
        end
        Wrapper->>Ctx: restore parent_call_id
        Wrapper->>End: on_*_end(call_id, outputs, exception)
        Wrapper-->>Caller: return results / re-raise
    end
```

### Key Lifecycle Behaviors

- **Fast path:** If no callbacks are registered (neither global nor instance-level), the wrapper calls the underlying function directly with zero overhead.
- **Unique call IDs:** Each invocation generates a `uuid4().hex` `call_id`, allowing start/end handlers to be correlated.
- **Nesting support:** `ACTIVE_CALL_ID` is set *immediately before* the wrapped function executes (not before the start callbacks), and restored in a `finally` block. This lets nested calls (e.g., a `Module` calling an `LM`) be correlated as parent/child.
- **Exception safety:** The end handlers always run via `finally`, receiving the captured `exception` (or `None`). Exceptions are re-raised after end handlers complete.
- **Error isolation:** Errors raised *inside* a callback handler are caught and logged as warnings, so a faulty callback never breaks the instrumented component.

---

## Data Flow

The following diagram shows how inputs and outputs flow through the callback system for a typical `LM` call:

```mermaid
flowchart TD
    A["Component method invoked"] --> B["inspect.getcallargs<br/>extract inputs"]
    B --> C["Remove 'self'/'instance'<br/>from inputs"]
    C --> D["on_*_start(call_id, instance, inputs)"]
    D --> E["Execute wrapped function"]
    E --> F{"Exception?"}
    F -->|No| G["outputs = results"]
    F -->|Yes| H["outputs = None<br/>exception = e"]
    G --> I["on_*_end(call_id, outputs, exception)"]
    H --> I
    I --> J["Return results / re-raise"]
```

---

## Usage Patterns

### Global Callbacks

Register a callback for all components via `dspy.settings.configure`:

```python
import dspy
from dspy.utils.callback import BaseCallback

class LoggingCallback(BaseCallback):
    def on_lm_start(self, call_id, instance, inputs):
        print(f"LM called with inputs: {inputs}")

    def on_lm_end(self, call_id, outputs, exception):
        print(f"LM finished with outputs: {outputs}")

dspy.settings.configure(callbacks=[LoggingCallback()])

cot = dspy.ChainOfThought("question -> answer")
cot(question="What is the meaning of life?")
```

### Instance-Level Callbacks

Pass callbacks directly to a component constructor for scoped instrumentation:

```python
lm_1 = dspy.LM("gpt-3.5-turbo", callbacks=[LoggingCallback()])
lm_1(question="What is the meaning of life?")  # Logged

lm_2 = dspy.LM("gpt-3.5-turbo")
lm_2(question="What is the meaning of life?")  # Not logged
```

> **Resolution order:** Active callbacks are the concatenation of global callbacks (`dspy.settings.get("callbacks", [])`) followed by instance-level callbacks (`instance.callbacks`). Both sets are invoked for every call.

---

## Available Handlers

`BaseCallback` defines the following overridable handlers. All handlers default to no-ops (`pass`).

| Handler | Triggered When |
|---------|----------------|
| `on_module_start` / `on_module_end` | `forward()` of a `dspy.Module` subclass is called. |
| `on_lm_start` / `on_lm_end` | `__call__` of a `dspy.LM` instance is called. |
| `on_adapter_format_start` / `on_adapter_format_end` | `format()` of a `dspy.Adapter` is called. |
| `on_adapter_parse_start` / `on_adapter_parse_end` | `parse()` of a `dspy.Adapter` is called. |
| `on_tool_start` / `on_tool_end` | A `dspy.Tool` is called. |
| `on_evaluate_start` / `on_evaluate_end` | `dspy.Evaluate.__call__` is invoked. |

### Handler Signatures

**Start handlers** receive:
- `call_id: str` — unique identifier for the call.
- `instance: Any` — the component instance.
- `inputs: dict[str, Any]` — the arguments passed to the method (with `self`/`instance` removed).

**End handlers** receive:
- `call_id: str` — the same identifier as the corresponding start handler.
- `outputs: Any | None` — the method's return value, or `None` if an exception occurred.
- `exception: Exception | None` — the raised exception, or `None` on success.

---

## Integration with Other Modules

The callback framework is a cross-cutting concern woven into the core of DSPy. The table below summarizes where `with_callbacks` is applied and links to the relevant module documentation.

| Module | Instrumented Method(s) | Documentation |
|--------|------------------------|---------------|
| `clients_core` | `LM.__call__`, `LM.acall` | [clients_core.md](clients_core.md) |
| `adapters` | `Adapter.format`, `Adapter.parse` (applied via `__init_subclass__`) | [adapters.md](adapters.md) |
| `adapter_types` | `Tool.__call__`, `Tool.acall` | [adapter_types.md](adapter_types.md) |
| `evaluate` | `Evaluate.__call__` | [evaluate.md](evaluate.md) |
| `primitives` | `Module.forward` | [primitives.md](primitives.md) |
| `dsp_utils` | `Settings` provides global callback storage | [dsp_utils.md](dsp_utils.md) |

### Dependency Diagram

```mermaid
graph TD
    Callbacks["utils_callbacks<br/>(BaseCallback, with_callbacks)"]

    Settings["dsp_utils<br/>(Settings)"]
    LM["clients_core<br/>(LM)"]
    Adapter["adapters<br/>(Adapter)"]
    Tool["adapter_types<br/>(Tool)"]
    Evaluate["evaluate<br/>(Evaluate)"]
    Module["primitives<br/>(Module)"]

    Settings -->|"stores global callbacks"| Callbacks
    Callbacks -->|"decorates methods"| LM
    Callbacks -->|"decorates methods"| Adapter
    Callbacks -->|"decorates methods"| Tool
    Callbacks -->|"decorates methods"| Evaluate
    Callbacks -->|"decorates methods"| Module
```

---

## Design Considerations

- **Zero-overhead when unused:** The wrapper short-circuits to a direct call when no callbacks are registered, keeping the common case fast.
- **Context-aware nesting:** `ACTIVE_CALL_ID` uses `contextvars`, making it safe for both synchronous and asynchronous execution contexts, including thread pools and async tasks.
- **Fault tolerance:** Callback handler exceptions are logged but never propagated, ensuring instrumentation cannot break application logic.
- **Adapter method dispatch:** Because adapters have two distinct instrumented methods (`format` and `parse`), the dispatcher inspects `fn.__name__` to select the correct handler and raises a `ValueError` for unsupported adapter methods.
- **Decorator application:** For adapters, `with_callbacks` is applied automatically in `Adapter.__init_subclass__`, so all adapter subclasses are instrumented without manual decoration.

---

## Related Documentation

- [clients_core.md](clients_core.md) — `LM` and `BaseLM`, primary consumers of LM callbacks.
- [adapters.md](adapters.md) — `Adapter` base class and format/parse instrumentation.
- [adapter_types.md](adapter_types.md) — `Tool` and tool-calling types.
- [evaluate.md](evaluate.md) — `Evaluate` and evaluation callbacks.
- [primitives.md](primitives.md) — `Module` and `forward` instrumentation.
- [dsp_utils.md](dsp_utils.md) — `Settings` global configuration, including callback storage.
- [streaming.md](streaming.md) — `StatusStreamingCallback`, a specialized callback for streaming status messages.
