# Arbor Provider (`clients_providers_arbor`)

## Introduction

The `clients_providers_arbor` module implements DSPy's integration with the **Arbor** training and inference server. It provides a concrete [`Provider`](clients_core_provider.md) implementation that supports:

- **Model lifecycle management** — launching and killing remote inference servers.
- **Supervised fine-tuning (SFT)** — uploading training data and running remote fine-tuning jobs.
- **Reinforcement learning (GRPO)** — running Group Relative Policy Optimization training steps against a remote server.

The module is the RL-capable sibling of the local provider ([`clients_providers_local`](clients_providers_local.md)) and shares the same provider abstraction used by [`clients_core`](clients_core.md). It is consumed by the [`LM`](clients_core_lm.md) client and driven by teleprompters such as [`GRPO`](teleprompt_finetune.md).

**Core components:**

| Component | Role |
|-----------|------|
| `ArborProvider` | Provider implementation: launch/kill, finetune, GRPO orchestration, status polling. |
| `ArborTrainingJob` | A [`TrainingJob`](clients_core_provider.md) subclass tracking a remote SFT job. |
| `ArborReinforceJob` | A [`ReinforceJob`](clients_core_provider.md) subclass driving GRPO training steps. |
| `GRPOTrainKwargs` | TypedDict describing the required GRPO training kwargs. |

---

## Architecture

The Arbor provider plugs into DSPy's provider abstraction. The [`LM`](clients_core_lm.md) client delegates lifecycle and training operations to the provider, which in turn communicates with a remote Arbor HTTP server.

```mermaid
graph TD
    LM["LM (clients_core_lm)"]
    Provider["Provider (clients_core_provider)"]
    ArborProvider["ArborProvider"]
    ArborTrainingJob["ArborTrainingJob"]
    ArborReinforceJob["ArborReinforceJob"]
    GRPOTrainKwargs["GRPOTrainKwargs"]
    Utils["utils_finetune<br/>(TrainDataFormat, TrainingStatus, save_data)"]
    Server["Arbor HTTP Server<br/>(api_base)"]
    OpenAI["openai SDK<br/>(fine_tuning, files)"]

    LM -->|"provider="| ArborProvider
    ArborProvider -.->|"extends"| Provider
    ArborProvider -->|"TrainingJob ="| ArborTrainingJob
    ArborProvider -->|"ReinforceJob ="| ArborReinforceJob
    ArborReinforceJob -->|"uses"| GRPOTrainKwargs
    ArborTrainingJob -.->|"extends"| Provider
    ArborReinforceJob -.->|"extends"| Provider
    ArborProvider --> Utils
    ArborProvider -->|"requests.post"| Server
    ArborProvider -->|"openai.*"| OpenAI
    OpenAI --> Server
```

### Class hierarchy

```mermaid
classDiagram
    class Provider {
        +finetunable: bool
        +reinforceable: bool
        +TrainingJob
        +ReinforceJob
        +launch(lm, launch_kwargs)
        +kill(lm, launch_kwargs)
        +finetune(job, model, train_data, ...)
    }
    class TrainingJob {
        <<Future>>
        +provider_file_id
        +provider_job_id
        +cancel()
        +status()
    }
    class ReinforceJob {
        +lm
        +train_kwargs
        +checkpoints
        +initialize()
        +step(train_data, train_data_format)
        +save_checkpoint(name, score)
        +terminate()
        +cancel()
        +status()
    }
    class ArborProvider {
        +finetunable = True
        +reinforceable = True
        +launch()
        +kill()
        +finetune()
        +wait_for_job()
        +get_trained_model()
    }
    class ArborTrainingJob
    class ArborReinforceJob {
        +DEFAULT_TRAIN_KWARGS
        +initialize()
        +step()
        +save_checkpoint()
        +terminate()
    }

    Provider <|-- ArborProvider
    TrainingJob <|-- ArborTrainingJob
    ReinforceJob <|-- ArborReinforceJob
```

---

## Component Reference

### `ArborProvider`

The central class. It extends [`Provider`](clients_core_provider.md) and sets `finetunable = True` and `reinforceable = True`, wiring in `ArborTrainingJob` and `ArborReinforceJob` as the job factories.

#### Model lifecycle

| Method | Description |
|--------|-------------|
| `launch(lm, launch_kwargs)` | POSTs to `{api_base}chat/launch` to start a remote inference server for the model. |
| `kill(lm, launch_kwargs)` | POSTs to `{api_base}chat/kill` to stop the inference server. |

#### Model name prefixing

Arbor models use the `openai/arbor:` prefix so that LiteLLM routes requests through the OpenAI-compatible client.

| Method | Description |
|--------|-------------|
| `_remove_provider_prefix(model)` | Strips `openai/` and `arbor:` prefixes. |
| `_add_provider_prefix(model)` | Ensures the model is prefixed with `openai/arbor:`. |

#### Fine-tuning (SFT)

`finetune(job, model, train_data, train_data_format, train_kwargs)` orchestrates the full remote SFT workflow:

```mermaid
sequenceDiagram
    participant LM
    participant AP as ArborProvider
    participant FS as Local FS
    participant Server as Arbor Server

    LM->>AP: finetune(job, model, train_data, ...)
    AP->>AP: _get_arbor_base_api()
    AP->>AP: validate_data_format()
    AP->>FS: save_data(train_data)
    AP->>Server: upload_data() (openai.files.create)
    Server-->>AP: provider_file_id
    AP->>Server: _start_remote_training() (openai.fine_tuning.jobs.create)
    Server-->>AP: provider_job_id
    AP->>Server: wait_for_job() (poll events + status)
    Server-->>AP: terminal status
    AP->>Server: get_trained_model()
    Server-->>AP: fine_tuned_model
    AP-->>LM: "openai/arbor:<model>"
```

Supporting methods:

| Method | Description |
|--------|-------------|
| `validate_data_format(data_format)` | Ensures the format is `CHAT`, `COMPLETION`, or `GRPO_CHAT`. |
| `upload_data(data_path, training_kwargs)` | Uploads the saved data file via `openai.files.create`. |
| `_start_remote_training(train_file_id, model, train_kwargs)` | Creates a remote fine-tuning job. |
| `wait_for_job(job, training_kwargs, poll_frequency=20)` | Polls job events and status until terminal; reports estimated finish time. |
| `get_trained_model(job, training_kwargs)` | Retrieves the fine-tuned model name (requires `succeeded` status). |

#### Status & existence helpers

| Method | Description |
|--------|-------------|
| `does_job_exist(job_id, training_kwargs)` | Checks job existence via `openai.fine_tuning.jobs.retrieve`. |
| `does_file_exist(file_id, training_kwargs)` | Checks file existence via `openai.files.retrieve`. |
| `is_terminal_training_status(status)` | True for `succeeded`, `failed`, `cancelled`. |
| `get_training_status(job_id, training_kwargs)` | Maps provider status strings to [`TrainingStatus`](clients_finetune_utils.md). |
| `_get_arbor_base_api()` | Reads `dspy.settings.arbor_api_base`; raises if unset. |

> **Note:** Several methods temporarily swap `openai.base_url` to the Arbor API base and restore it afterward. This is a known pattern that will be refactored once the `LM` object is passed directly to `finetune`.

---

### `ArborTrainingJob`

Extends [`TrainingJob`](clients_core_provider.md) (a `Future`). Tracks `provider_file_id` and `provider_job_id`.

| Method | Description |
|--------|-------------|
| `cancel()` | Cancels the remote job (if not terminal) and deletes the uploaded file, then calls `super().cancel()`. |
| `status()` | Returns the current [`TrainingStatus`](clients_finetune_utils.md). |

---

### `ArborReinforceJob`

Extends [`ReinforceJob`](clients_core_provider.md) and implements the GRPO training loop against the Arbor server.

#### `DEFAULT_TRAIN_KWARGS`

A comprehensive set of TRL-style defaults, including `temperature=0.9`, `beta=0.04`, `num_iterations=1`, `per_device_train_batch_size=8`, `learning_rate=1e-6`, `gradient_checkpointing=True`, `scale_rewards=True`, `max_grad_norm=1.0`, `lora=False`, and more.

#### Methods

| Method | Description |
|--------|-------------|
| `initialize()` | POSTs to `{api_base}fine_tuning/grpo/initialize` with merged kwargs; updates `lm.model` and stores `provider_job_id`. Requires `num_generations`. |
| `step(train_data, train_data_format)` | Iterates over GRPO groups, calling `_run_grpo_step_one_group` for each. Only supports `GRPO_CHAT`. |
| `_run_grpo_step_one_group(train_group, ...)` | POSTs a single group to `{api_base}fine_tuning/grpo/step`; updates `lm.model` to the returned `current_model`. |
| `save_checkpoint(checkpoint_name, score=None)` | POSTs to `{api_base}fine_tuning/grpo/checkpoint`; records checkpoint path and score. |
| `terminate()` | POSTs to `{api_base}fine_tuning/grpo/terminate`; updates `lm.model` to the final model. |
| `cancel()` | Cancels the remote job if not terminal. |
| `status()` | Returns the current [`TrainingStatus`](clients_finetune_utils.md). |

---

### `GRPOTrainKwargs`

A `TypedDict` declaring the required GRPO training kwargs:

```python
class GRPOTrainKwargs(TypedDict):
    num_generations: int
```

`num_generations` is mandatory; `ArborReinforceJob.__init__` raises `ValueError` if it is missing.

---

## Data Flow

The GRPO training loop is driven by a teleprompter (e.g. [`GRPO`](teleprompt_finetune.md)) that produces groups of [`GRPOChatData`](clients_finetune_utils.md) and calls `step` repeatedly.

```mermaid
flowchart LR
    TP["Teleprompter (GRPO)"] -->|"reinforce(train_kwargs)"| LM["LM"]
    LM -->|"ReinforceJob(lm, train_kwargs)"| ARJ["ArborReinforceJob"]
    ARJ -->|"initialize()"| Init["POST /grpo/initialize"]
    TP -->|"step(groups, GRPO_CHAT)"| ARJ
    ARJ -->|"per group"| Step["POST /grpo/step"]
    Step -->|"current_model"| ARJ
    ARJ -->|"updates lm.model"| LM
    TP -->|"save_checkpoint(name, score)"| ARJ
    ARJ -->|"POST /grpo/checkpoint"| CP["checkpoints dict"]
    TP -->|"terminate()"| ARJ
    ARJ -->|"POST /grpo/terminate"| LM
```

---

## Dependencies

```mermaid
graph LR
    subgraph "clients_providers_arbor"
        AP[ArborProvider]
        ATJ[ArborTrainingJob]
        ARJ[ArborReinforceJob]
        GTK[GRPOTrainKwargs]
    end
    subgraph "clients_core"
        Provider[Provider]
        TrainingJob[TrainingJob]
        ReinforceJob[ReinforceJob]
        LM[LM]
    end
    subgraph "clients_finetune_utils"
        TDF[TrainDataFormat]
        TS[TrainingStatus]
        GRPO[GRPOGroup / GRPOChatData]
        SaveData[save_data]
    end
    subgraph "External"
        OpenAI[openai SDK]
        Requests[requests]
        Settings[dspy.settings]
    end

    AP --> Provider
    ATJ --> TrainingJob
    ARJ --> ReinforceJob
    AP --> TDF
    AP --> TS
    AP --> SaveData
    ARJ --> GRPO
    ARJ --> TDF
    AP --> OpenAI
    ARJ --> OpenAI
    AP --> Requests
    ARJ --> Requests
    AP --> Settings
    LM --> AP
```

### Internal dependencies

- [`clients_core`](clients_core.md) — `Provider`, `TrainingJob`, `ReinforceJob`, `LM`.
- [`clients_finetune_utils`](clients_finetune_utils.md) — `GRPOGroup`, `TrainDataFormat`, `TrainingStatus`, `save_data`.

### External dependencies

- `openai` — used for `fine_tuning.jobs` and `files` operations against the Arbor server.
- `requests` — used for the GRPO and launch/kill HTTP endpoints.
- `dspy.settings` — provides `arbor_api_base`.

---

## Configuration

The Arbor API base URL must be configured before fine-tuning or GRPO operations:

```python
import dspy

dspy.settings.arbor_api_base = "http://localhost:8000/v1/"
```

`ArborProvider._get_arbor_base_api()` raises a `ValueError` with guidance if this is unset.

---

## Related Modules

- [`clients_core`](clients_core.md) — base provider, job, and LM abstractions.
- [`clients_core_provider`](clients_core_provider.md) — `Provider`, `TrainingJob`, `ReinforceJob` base classes.
- [`clients_core_lm`](clients_core_lm.md) — the `LM` client that delegates to providers.
- [`clients_finetune_utils`](clients_finetune_utils.md) — data formats, statuses, and serialization helpers.
- [`clients_providers_local`](clients_providers_local.md) — the local (SGLang) provider counterpart.
- [`clients_providers_openai`](clients_providers_openai.md) — the OpenAI provider counterpart.
- [`teleprompt_finetune`](teleprompt_finetune.md) — teleprompters (`GRPO`, `BootstrapFinetune`) that drive these jobs.
