# predict_core_predict

## Overview

The `predict_core_predict` module is the foundational execution unit of DSPy. It contains the `Predict` class — the atomic building block that wraps a `Signature` and orchestrates a single language model (LM) call — along with the `Parameter` marker base class that identifies trainable/optimizable components within a DSPy program.

Every higher-level DSPy module (e.g., `ChainOfThought`, `ReAct`, `ProgramOfThought`) ultimately delegates its LM interaction to one or more `Predict` instances. As such, this module sits at the very center of the DSPy execution pipeline: it bridges **signatures** (what to do), **adapters** (how to format/parse), **LMs** (who does it), and **predictions** (the result).

### Core Components

| Component | File | Responsibility |
|-----------|------|----------------|
| `Predict` | `dspy/predict/predict.py` | Wraps a signature and performs a single LM call, handling preprocessing, adapter invocation, streaming, tracing, and state serialization. |
| `Parameter` | `dspy/predict/parameter.py` | An empty marker base class used by `BaseModule.named_parameters()` to discover optimizable sub-components. |

---

## Architecture

`Predict` is a multiple-inheritance class combining `Module` (execution/lifecycle) and `Parameter` (optimization discovery). It is the concrete realization of the abstract `Module.forward` contract.

```mermaid
classDiagram
    class BaseModule {
        +named_parameters()
        +named_sub_modules()
        +dump_state()
        +load_state()
        +save()
        +load()
    }
    class Module {
        +__call__()
        +acall()
        +forward()
        +aforward()
        +batch()
        +named_predictors()
    }
    class Parameter {
        <<marker>>
    }
    class Predict {
        +signature
        +config
        +lm
        +demos
        +traces
        +forward()
        +aforward()
        +_forward_preprocess()
        +_forward_postprocess()
        +dump_state()
        +load_state()
        +update_config()
    }

    BaseModule <|-- Module
    Module <|-- Predict
    Parameter <|-- Predict
```

### Component Relationships

```mermaid
graph TD
    Predict -->|wraps| Signature
    Predict -->|uses| Adapter
    Predict -->|calls| BaseLM
    Predict -->|produces| Prediction
    Predict -->|reads/writes| Settings
    Predict -->|inherits| Module
    Predict -->|inherits| Parameter
    Adapter -->|default| ChatAdapter
    Adapter -->|fallback| JSONAdapter
    BaseLM -->|subclass| LM
    Module -->|inherits| BaseModule
```

---

## The `Predict` Class

### Construction

```python
Predict(signature: str | type[Signature], callbacks: list[BaseCallback] | None = None, **config)
```

- `signature` is normalized via `ensure_signature`, accepting either a string shorthand (e.g., `"question -> answer"`) or a `Signature` subclass.
- A random `stage` hex string is generated for identification.
- `**config` stores per-instance LM configuration (e.g., `temperature`, `n`).
- `reset()` initializes `lm=None`, `traces=[]`, `train=[]`, and `demos=[]`.

### Execution Flow

The `forward` (sync) and `aforward` (async) methods share the same three-phase pipeline:

```mermaid
flowchart TD
    A["__call__(**kwargs)"] --> B["_forward_preprocess(**kwargs)"]
    B --> B1["Resolve signature (override or self.signature)"]
    B --> B2["Resolve demos (override or self.demos)"]
    B --> B3["Merge config (self.config + call config)"]
    B --> B4["Resolve LM (call lm > self.lm > settings.lm)"]
    B --> B5["Validate LM is a BaseLM instance"]
    B --> B6["Adjust temperature when n > 1"]
    B --> C{"_should_stream()?"}
    C -->|Yes| D["adapter(lm, ..., caller_predict=self)"]
    C -->|No| E["adapter(lm, ..., send_stream=None)"]
    D --> F["_forward_postprocess(completions)"]
    E --> F
    F --> F1["Prediction.from_completions(...)"]
    F --> F2["Append to settings.trace"]
    F --> F3["Return Prediction"]
```

#### Phase 1 — `_forward_preprocess`

Extracts privileged keyword arguments and resolves the effective execution context:

| Keyword | Purpose | Fallback |
|---------|---------|----------|
| `signature` | Override the instance signature | `self.signature` |
| `demos` | Few-shot examples | `self.demos` |
| `config` | Per-call LM config | merged with `self.config` |
| `lm` | LM to use | `self.lm` → `settings.lm` |

It also performs important validation and normalization:

- **LM validation**: Raises a descriptive error if no LM is configured, if a string is passed instead of a `BaseLM` instance, or if the object is not a `BaseLM`.
- **Temperature adjustment**: If `temperature` is unset or `<= 0.15` and `n > 1`, temperature is bumped to `0.7` to preserve sampling randomness.
- **Predicted outputs**: A `prediction` kwarg in OpenAI predicted-outputs format is moved from inputs into the LM config.
- **Missing input warning**: Logs a warning if not all signature input fields are supplied.

#### Phase 2 — Adapter Invocation

The adapter (defaulting to `ChatAdapter`, or `settings.adapter` if configured) is invoked with the resolved LM, config, signature, demos, and inputs. The adapter handles message formatting and response parsing. See [adapters](adapters.md) for details.

Streaming is conditionally enabled via `_should_stream()`, which checks `settings.send_stream` and whether any registered `StreamListener` targets this predictor. See [streaming](streaming.md).

#### Phase 3 — `_forward_postprocess`

Converts raw completions into a `Prediction` object via `Prediction.from_completions`, and appends a trace entry `(self, kwargs, pred)` to `settings.trace` (respecting `settings.max_trace_size`). See [primitives](primitives.md) for `Prediction`.

### Positional Argument Guard

`__call__` and `acall` explicitly reject positional arguments, raising a helpful error that lists the expected input field names. This enforces the keyword-only calling convention required by signatures.

### State Management

`Predict` participates in the DSPy serialization protocol:

- **`dump_state()`** — serializes `traces`, `train`, `demos` (with `BaseModel` fields converted via `serialize_object`), the signature state, and the LM state.
- **`load_state(state)`** — restores all fields, reloads the signature and LM, and raises `NotImplementedError` for the legacy `extended_signature` key (removed in DSPy 2.6+).

The `serialize_object` helper recursively converts Pydantic models, lists, tuples, and dicts into JSON-compatible structures.

### Configuration Helpers

- `update_config(**kwargs)` — merges new values into `self.config`.
- `get_config()` — returns the current config.

---

## The `Parameter` Class

```python
class Parameter:
    pass
```

`Parameter` is a deliberately empty marker class. Its sole purpose is to be a type that `BaseModule.named_parameters()` can detect when recursively walking a module's attributes. Because `Predict` inherits from `Parameter`, every `Predict` instance is automatically discovered as an optimizable parameter by teleprompters and optimizers.

```mermaid
graph LR
    A["BaseModule.named_parameters()"] -->|"isinstance(value, Parameter)"| B["Collect Predict instances"]
    B --> C["Teleprompters / Optimizers"]
    C -->|"set_lm / update demos"| B
```

This design enables the entire optimization ecosystem (see [teleprompt_core](teleprompt_core.md) and [teleprompt_optimizers](teleprompt_optimizers.md)) to locate and mutate predictors without knowing their concrete types.

---

## Integration with the Broader System

### Module Lifecycle

`Predict` inherits `__call__`/`acall` from `Module`, which wraps `forward`/`aforward` with:

- **Callback dispatch** (`with_callbacks`) — see [utils](utils.md).
- **Caller module tracking** — appends `self` to `settings.caller_modules`.
- **Usage tracking** — when `settings.track_usage` is enabled, wraps execution in a usage tracker and attaches token counts to the resulting `Prediction`.

### Settings-Driven Behavior

`Predict` reads extensively from the global `Settings` singleton (see [dsp_utils](dsp_utils.md)):

| Setting | Effect |
|---------|--------|
| `settings.lm` | Default LM when none is set on the instance |
| `settings.adapter` | Adapter override (defaults to `ChatAdapter`) |
| `settings.trace` / `settings.max_trace_size` | Trace recording |
| `settings.send_stream` / `settings.stream_listeners` | Streaming activation |
| `settings.track_usage` | Token usage accounting |

### Relationship to Higher-Level Modules

```mermaid
graph TD
    subgraph "predict_core"
        Predict
        Parameter
    end
    subgraph "predict_core_chain_of_thought"
        CoT["ChainOfThought"]
    end
    subgraph "predict_core_parallel"
        Parallel
    end
    subgraph "predict_advanced"
        ReAct
        PoT["ProgramOfThought"]
        BestOfN
    end
    CoT -->|"wraps a single"| Predict
    ReAct -->|"composes multiple"| Predict
    PoT -->|"composes multiple"| Predict
    BestOfN -->|"composes multiple"| Predict
    Parallel -->|"executes modules in parallel"| Predict
```

- **`ChainOfThought`** (see [predict_core_chain_of_thought](predict_core_chain_of_thought.md)) prepends a `reasoning` output field to the signature and delegates to a single internal `Predict`.
- **`Parallel`** (see [predict_core_parallel](predict_core_parallel.md)) executes many `Predict`-based modules concurrently; `Module.batch()` uses it under the hood.
- **Advanced modules** (see [predict_advanced](predict_advanced.md)) compose multiple `Predict` instances to implement reasoning strategies.

---

## Data Flow Summary

```mermaid
sequenceDiagram
    participant User
    participant Predict
    participant Settings
    participant Adapter
    participant LM
    participant Prediction

    User->>Predict: __call__(**inputs)
    Predict->>Settings: read lm, adapter, trace, stream
    Predict->>Predict: _forward_preprocess
    Predict->>Adapter: format(signature, demos, inputs)
    Adapter->>LM: messages + lm_kwargs
    LM-->>Adapter: raw completions
    Adapter->>Adapter: parse(completion)
    Adapter-->>Predict: parsed outputs
    Predict->>Prediction: from_completions(...)
    Predict->>Settings: append trace
    Predict-->>User: Prediction
```

---

## Key Design Notes

1. **Single Responsibility**: `Predict` performs exactly one LM call. Complex reasoning is achieved by composing multiple `Predict` instances.
2. **Adapter Decoupling**: All prompt formatting and response parsing is delegated to adapters, allowing `Predict` to remain agnostic to LM-specific formats.
3. **Graceful Fallback**: The default `ChatAdapter` automatically falls back to `JSONAdapter` on parse failures (except for context-window-exceeded errors).
4. **Optimization-Ready**: Inheriting from `Parameter` makes every `Predict` discoverable and mutable by the optimization subsystem.
5. **Thread-Safe Configuration**: All configuration flows through the thread-safe `Settings` singleton, supporting `dspy.context(...)` overrides.

---

## Related Documentation

- [adapters](adapters.md) — Adapter implementations and type system
- [clients_core](clients_core.md) — `BaseLM`, `LM`, and provider abstractions
- [primitives](primitives.md) — `Module`, `BaseModule`, `Prediction`, `Example`
- [signatures](signatures.md) — `Signature` definition and manipulation
- [dsp_utils](dsp_utils.md) — `Settings` and helper utilities
- [streaming](streaming.md) — Streaming listeners and callbacks
- [predict_core_chain_of_thought](predict_core_chain_of_thought.md) — Step-by-step reasoning module
- [predict_core_parallel](predict_core_parallel.md) — Parallel execution
- [predict_advanced](predict_advanced.md) — Advanced reasoning modules
- [teleprompt_core](teleprompt_core.md) / [teleprompt_optimizers](teleprompt_optimizers.md) — Optimization that operates on `Predict` parameters
