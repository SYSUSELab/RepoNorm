# Clients Core Embedder

## Introduction

The `clients_core_embedder` module provides DSPy's unified embedding interface through the `Embedder` class. It abstracts over two fundamentally different embedding backends:

1. **Hosted embedding models** (e.g., OpenAI's `text-embedding-3-small`) accessed via the `litellm` integration.
2. **Custom embedding functions** supplied by the user as Python callables (e.g., a local `sentence-transformers` model).

The module handles batching, caching, synchronous and asynchronous execution, and normalization of outputs into NumPy arrays. It is the foundational embedding primitive used by retrieval components such as [`Embeddings`](retrievers.md) and is closely tied to the caching infrastructure in [`clients_core_cache`](clients_core_cache.md).

---

## Architecture

The module is intentionally small and focused. Its public surface is a single class (`Embedder`) backed by four module-level helper functions that implement the actual compute logic (sync/async, cached/uncached).

```mermaid
graph TD
    subgraph "clients_core_embedder"
        E["Embedder<br/>(public API)"]
        CE["_compute_embeddings"]
        CCE["_cached_compute_embeddings"]
        ACE["_acompute_embeddings"]
        CACE["_cached_acompute_embeddings"]
    end

    subgraph "External"
        LL["litellm<br/>(hosted models)"]
        CB["User Callable<br/>(custom models)"]
        NP["numpy"]
    end

    subgraph "DSPy Internals"
        RC["request_cache<br/>(clients_core_cache)"]
        CACHE["dspy.cache<br/>(Cache)"]
    end

    E -->|sync| CE
    E -->|sync + cache| CCE
    E -->|async| ACE
    E -->|async + cache| CACE

    CE --> LL
    CE --> CB
    ACE --> LL
    ACE --> CB

    CCE -.->|decorated by| RC
    CACE -.->|decorated by| RC
    RC --> CACHE

    E --> NP
```

### Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Single class, four helpers** | Keeps the public API minimal while separating sync/async and cached/uncached code paths for clarity. |
| **`litellm` for hosted models** | Reuses DSPy's existing provider abstraction and caching integration rather than reimplementing provider-specific HTTP clients. |
| **Callable support** | Allows any local or custom embedding model (HuggingFace, custom math, etc.) without requiring a hosted API. |
| **`request_cache` decorator** | Reuses the shared DSPy cache layer so embeddings benefit from the same in-memory + on-disk caching as LM calls. |
| **NumPy output** | Provides a consistent, vectorized output format regardless of backend. |

---

## Core Component: `Embedder`

The `Embedder` class is the sole public entry point of this module.

### Constructor

```python
Embedder(
    model: str | Callable,
    batch_size: int = 200,
    caching: bool = True,
    **kwargs: dict[str, Any],
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `model` | `str \| Callable` | — | Either a litellm-supported hosted embedding model name (e.g. `"openai/text-embedding-3-small"`) or a callable that maps a list of strings to embeddings. |
| `batch_size` | `int` | `200` | Default number of inputs processed per batch. |
| `caching` | `bool` | `True` | Whether to cache responses for hosted models. |
| `**kwargs` | `dict` | `{}` | Default keyword arguments forwarded to the embedding backend. |

### Methods

#### `__call__(inputs, batch_size=None, caching=None, **kwargs) -> np.ndarray`

Synchronous embedding computation.

- **`inputs`**: A single string or a list of strings.
- **`batch_size`**: Overrides the constructor default for this call.
- **`caching`**: Overrides the constructor default for this call.
- **`**kwargs`**: Merged over the constructor's default kwargs (call-time values win).
- **Returns**: A 1D NumPy array for a single string input, or a 2D NumPy array (one row per input) for a list.

#### `acall(inputs, batch_size=None, caching=None, **kwargs) -> np.ndarray`

Asynchronous counterpart to `__call__`. Uses `litellm.aembedding` for hosted models and awaits the callable for custom models. Returns the same shape semantics as `__call__`.

### Internal Pipeline

Both `__call__` and `acall` follow the same three-stage pipeline:

```mermaid
flowchart LR
    A["inputs<br/>(str or list[str])"] --> P["_preprocess"]
    P --> B["input_batches<br/>caching flag<br/>merged kwargs<br/>is_single_input"]
    B --> C{"caching?"}
    C -->|Yes| CC["_cached_*compute_embeddings"]
    C -->|No| UC["_*compute_embeddings"]
    CC --> L["embeddings_list"]
    UC --> L
    L --> PP["_postprocess"]
    PP --> O["np.ndarray<br/>(1D or 2D)"]
```

#### `_preprocess(inputs, batch_size, caching, **kwargs)`

1. Normalizes a single string into a one-element list and records `is_single_input`.
2. Validates that **all** inputs are strings (raises `ValueError` otherwise).
3. Resolves `batch_size` and `caching` (call-time value or constructor default).
4. Merges constructor `default_kwargs` with call-time `kwargs`.
5. Splits inputs into batches of `batch_size`.

Returns a tuple: `(input_batches, caching, merged_kwargs, is_single_input)`.

#### `_postprocess(embeddings_list, is_single_input)`

Converts the accumulated embeddings into a `float32` NumPy array. If the original input was a single string, returns the first row (1D array); otherwise returns the full 2D array.

---

## Backend Dispatch Logic

The four helper functions implement the actual compute. The dispatch is identical across all of them:

```mermaid
flowchart TD
    Start["compute(model, batch_inputs, **kwargs)"] --> Check{"isinstance(model, str)?"}
    Check -->|Yes| Hosted["litellm.embedding / litellm.aembedding<br/>caching = caching AND litellm.cache is not None"]
    Check -->|No, callable| Custom["model(batch_inputs, **kwargs)"]
    Check -->|No, other| Err["raise ValueError"]
    Hosted --> Extract["Extract data['embedding']<br/>from response.data"]
    Custom --> Return["Return embeddings"]
    Extract --> Return
```

| Helper | Sync/Async | Cached | Backend call |
|--------|-----------|--------|--------------|
| `_compute_embeddings` | Sync | No | `litellm.embedding` / callable |
| `_cached_compute_embeddings` | Sync | Yes | Wraps `_compute_embeddings` with `@request_cache` |
| `_acompute_embeddings` | Async | No | `litellm.aembedding` / callable |
| `_cached_acompute_embeddings` | Async | Yes | Wraps `_acompute_embeddings` with `@request_cache` |

> **Note:** For hosted models, caching is only active when both the `caching` flag is `True` **and** `litellm.cache` is configured. The `request_cache` decorator additionally ignores `api_key`, `api_base`, and `base_url` when computing cache keys, so credentials do not invalidate cached results.

---

## Caching Integration

The cached helpers are decorated with `request_cache` from [`clients_core_cache`](clients_core_cache.md):

```python
@request_cache(ignored_args_for_cache_key=["api_key", "api_base", "base_url"])
def _cached_compute_embeddings(model, batch_inputs, caching=True, **kwargs):
    return _compute_embeddings(model, batch_inputs, caching=caching, **kwargs)
```

This means embedding requests participate in DSPy's two-level cache (in-memory LRU + on-disk `diskcache`). The cache key is derived from the function identifier plus the request arguments, with sensitive/irrelevant arguments excluded.

```mermaid
sequenceDiagram
    participant U as User
    participant E as Embedder
    participant CC as _cached_compute_embeddings
    participant RC as request_cache
    participant C as dspy.cache
    participant LL as litellm

    U->>E: embedder(["hello", "world"])
    E->>CC: batch call
    CC->>RC: wrapper invoked
    RC->>C: cache.get(request)
    alt Cache hit
        C-->>RC: cached embeddings
        RC-->>E: embeddings
    else Cache miss
        RC->>LL: litellm.embedding(...)
        LL-->>RC: response
        RC->>C: cache.put(request, result)
        RC-->>E: embeddings
    end
    E-->>U: np.ndarray
```

---

## Data Flow

The following diagram shows the complete data flow from user input to NumPy output, including the branching between hosted and custom backends.

```mermaid
flowchart TD
    In["User input:<br/>str | list[str]"] --> Pre["_preprocess"]
    Pre --> Batches["Batched inputs"]
    Batches --> Loop{"For each batch"}
    Loop --> Dispatch{"model type"}
    Dispatch -->|str| Hosted["litellm.embedding / aembedding"]
    Dispatch -->|callable| Custom["model(batch)"]
    Hosted --> Collect["Collect embeddings"]
    Custom --> Collect
    Collect --> Loop
    Loop -->|done| Post["_postprocess<br/>np.array(dtype=float32)"]
    Post --> Out["1D or 2D np.ndarray"]
```

---

## Usage Examples

### Hosted Model

```python
import dspy

embedder = dspy.Embedder("openai/text-embedding-3-small", batch_size=100)
embeddings = embedder(["hello", "world"])

assert embeddings.shape == (2, 1536)
```

### Local Model via Callable

```python
# pip install sentence_transformers
import dspy
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("sentence-transformers/static-retrieval-mrl-en-v1", device="cpu")

embedder = dspy.Embedder(model.encode)
embeddings = embedder(["hello", "world"], batch_size=1)

assert embeddings.shape == (2, 1024)
```

### Custom Function

```python
import dspy
import numpy as np

def my_embedder(texts):
    return np.random.rand(len(texts), 10)

embedder = dspy.Embedder(my_embedder)
embeddings = embedder(["hello", "world"], batch_size=1)

assert embeddings.shape == (2, 10)
```

### Asynchronous Usage

```python
import asyncio
import dspy

embedder = dspy.Embedder("openai/text-embedding-3-small")

async def main():
    embeddings = await embedder.acall(["hello", "world"])
    return embeddings

asyncio.run(main())
```

---

## Component Relationships

```mermaid
graph LR
    subgraph "clients_core"
        EMB["Embedder<br/>(this module)"]
        CACHE["Cache<br/>(clients_core_cache)"]
        LM["LM<br/>(clients_core_lm)"]
    end

    subgraph "retrievers"
        RET["Embeddings<br/>(retrievers)"]
    end

    subgraph "utils"
        DV["DummyVectorizer<br/>(utils)"]
    end

    subgraph "External"
        LL["litellm"]
    end

    EMB -->|uses request_cache| CACHE
    EMB -->|uses| LL
    RET -->|consumes| EMB
    DV -.->|alternative vectorizer| RET
    LM -.->|shares cache infra| CACHE
```

### Related Modules

- **[clients_core_cache](clients_core_cache.md)** — Provides the `Cache` class and `request_cache` decorator used by the cached embedding helpers.
- **[clients_core_lm](clients_core_lm.md)** — The language-model counterpart that shares the same caching infrastructure and litellm integration.
- **[retrievers](retrievers.md)** — The `Embeddings` retriever consumes an `Embedder` instance to build a searchable corpus index (with optional FAISS acceleration).
- **[utils](utils.md)** — Contains `DummyVectorizer`, a lightweight n-gram vectorizer useful for testing retrieval pipelines without a real embedding model.

---

## Error Handling

| Condition | Behavior |
|-----------|----------|
| Non-string input in the list | `ValueError("All inputs must be strings.")` raised in `_preprocess`. |
| `model` is neither `str` nor callable | `ValueError` raised in the compute helper. |
| Cache key generation fails | Logged at debug level; caching is skipped (returns `None` from `Cache.get`). |
| Disk cache write fails (e.g., unpicklable value) | Logged at debug level; the operation continues. |

---

## Summary

The `clients_core_embedder` module delivers a compact yet flexible embedding abstraction for DSPy. By unifying hosted (litellm) and custom (callable) backends behind a single `Embedder` class, it enables consistent batching, caching, and NumPy-based output across diverse embedding sources. Its tight integration with the shared cache layer ensures that repeated embedding requests are cheap, while its sync/async duality supports both simple scripts and high-throughput pipelines.
