# predict_advanced_retrieval

## Introduction

The `predict_advanced_retrieval` module provides advanced prediction strategies that leverage **retrieval** and **comparison** mechanisms to improve the quality of language model outputs. Unlike the core prediction primitives (see [predict_core.md](predict_core.md)), these modules operate on collections of candidate outputs or training examples rather than a single forward pass.

This module contains two complementary components:

| Component | Purpose |
|-----------|---------|
| **`KNN`** | A k-nearest-neighbors retriever that finds the most similar training examples to a given input using embedding-based similarity. |
| **`MultiChainComparison`** | A reasoning aggregator that takes multiple independent reasoning attempts and synthesizes a single, more accurate answer. |

Together, these components support retrieval-augmented and ensemble-style prediction workflows within DSPy.

---

## Architecture Overview

The module sits within the broader `predict_advanced` family, which extends the core prediction primitives with specialized strategies.

```mermaid
graph TD
    subgraph "predict_advanced"
        subgraph "predict_advanced_retrieval (current)"
            KNN["KNN<br/>(knn.py)"]
            MCC["MultiChainComparison<br/>(multi_chain_comparison.py)"]
        end
        subgraph "predict_advanced_sampling"
            BON["BestOfN"]
            REF["Refine / OfferFeedback"]
        end
        subgraph "predict_advanced_agents"
            REACT["ReAct"]
            CODEACT["CodeAct"]
        end
        subgraph "predict_advanced_program_synthesis"
            POT["ProgramOfThought"]
        end
    end

    subgraph "predict_core"
        PREDICT["Predict"]
        COT["ChainOfThought"]
        PARALLEL["Parallel"]
    end

    subgraph "clients_core"
        EMBEDDER["Embedder"]
    end

    subgraph "primitives"
        EXAMPLE["Example"]
        MODULE["Module"]
    end

    subgraph "signatures"
        SIG["Signature"]
    end

    KNN --> EMBEDDER
    KNN --> EXAMPLE
    MCC --> PREDICT
    MCC --> MODULE
    MCC --> SIG
    PREDICT --> MODULE
```

---

## Component Details

### KNN — K-Nearest Neighbors Retriever

`KNN` is a lightweight, embedding-based retriever that finds the `k` most similar examples from a training set given a query input. It is commonly used to build few-shot demonstrations dynamically at inference time.

#### Key Characteristics

- **Not a `Module`**: `KNN` is a plain class with a `__call__` method. It does not participate in DSPy's module/predictor hierarchy, LM configuration, or tracing.
- **Embedding-based similarity**: Uses cosine-like similarity via dot product on normalized embeddings.
- **Input-key aware**: Only the fields marked as input keys (`example._input_keys`) are serialized for vectorization.

#### Constructor

```python
KNN(k: int, trainset: list[Example], vectorizer: Embedder)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `k` | `int` | Number of nearest neighbors to retrieve. |
| `trainset` | `list[Example]` | Training examples to search through. |
| `vectorizer` | `Embedder` | The embedder used to vectorize examples and queries. |

During initialization, the training set is serialized into strings of the form `"key: value | key: value"` (restricted to input keys) and embedded into a `float32` matrix stored as `self.trainset_vectors`.

#### Call Behavior

```python
similar_examples = knn(input="hello")
```

1. The query `kwargs` are serialized into a single string using the same `"key: value | ..."` format.
2. The query is embedded via the `Embedder`.
3. Similarity scores are computed as the dot product between the training vectors and the query vector.
4. The indices of the top-`k` scores are returned in descending order.
5. The corresponding `Example` objects are returned as a list.

#### Data Flow

```mermaid
sequenceDiagram
    participant User
    participant KNN
    participant Embedder
    participant Trainset

    Note over KNN: __init__
    KNN->>Trainset: serialize input keys
    KNN->>Embedder: embed serialized trainset
    Embedder-->>KNN: trainset_vectors (float32)

    Note over KNN: __call__(**kwargs)
    User->>KNN: query kwargs
    KNN->>KNN: serialize query
    KNN->>Embedder: embed query
    Embedder-->>KNN: query vector
    KNN->>KNN: dot product + argsort top-k
    KNN-->>User: list[Example]
```

#### Usage Example

```python
import dspy
from sentence_transformers import SentenceTransformer

trainset = [
    dspy.Example(input="hello", output="world"),
    # ... more examples ...
]

knn = KNN(
    k=3,
    trainset=trainset,
    vectorizer=dspy.Embedder(SentenceTransformer("all-MiniLM-L6-v2").encode),
)

similar_examples = knn(input="hello")
```

> **Note:** `KNN` relies on the `Embedder` abstraction. See [clients_core.md](clients_core.md) for details on hosted vs. custom embedding models.

---

### MultiChainComparison — Multi-Attempt Reasoning Aggregator

`MultiChainComparison` is a `Module` that aggregates `M` independent reasoning attempts into a single, more accurate answer. It is inspired by the "multi-chain comparison" technique, where a model is asked to holistically compare several candidate rationales and produce a corrected reasoning chain.

#### Key Characteristics

- **Subclass of `Module`**: Participates in DSPy's module hierarchy, supports LM configuration, tracing, and callbacks. See [primitives.md](primitives.md).
- **Dynamic signature construction**: The signature is programmatically extended with `M` input fields (one per reasoning attempt) and a prepended `rationale` output field.
- **Delegates to `Predict`**: Internally wraps a `Predict` instance configured with the augmented signature.

#### Constructor

```python
MultiChainComparison(signature, M=3, temperature=0.7, **config)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `signature` | `str \| type[Signature]` | — | The base signature describing the task. |
| `M` | `int` | `3` | Number of reasoning attempts expected. |
| `temperature` | `float` | `0.7` | Sampling temperature for the internal `Predict`. |
| `**config` | `dict` | — | Additional configuration passed to `Predict`. |

#### Signature Transformation

The constructor performs the following transformations on the base signature:

1. **Capture the last output key** (`self.last_key`) — this is the field holding the final answer in each attempt.
2. **Append `M` input fields** named `reasoning_attempt_1` … `reasoning_attempt_M`, each with prefix `"Student Attempt #N:"`.
3. **Prepend a `rationale` output field** with the prefix `"Accurate Reasoning: Thank you everyone. Let's now holistically"`.

```mermaid
graph LR
    subgraph "Base Signature"
        IN["input fields"]
        OUT["... last_key"]
    end
    subgraph "Augmented Signature"
        IN2["input fields"]
        RA["reasoning_attempt_1 ... M"]
        RAT["rationale (prepended output)"]
        OUT2["... last_key"]
    end
    IN --> IN2
    OUT --> OUT2
    IN2 --> RA
    RA --> RAT
    RAT --> OUT2
```

#### Forward Behavior

```python
def forward(self, completions, **kwargs):
    ...
```

1. Iterates over the provided `completions` (a list of candidate predictions).
2. For each completion, extracts the `rationale` (or `reasoning`) and the final answer (`self.last_key`), taking only the first line of each.
3. Formats each attempt as: `«I'm trying to {rationale} I'm not sure but my prediction is {answer}»`.
4. Asserts that the number of attempts equals `M`.
5. Passes the formatted attempts as `reasoning_attempt_N` kwargs to the internal `Predict`.

#### Process Flow

```mermaid
flowchart TD
    A["completions (list of M predictions)"] --> B{For each completion}
    B --> C["Extract rationale (first line)"]
    B --> D["Extract answer = last_key (first line)"]
    C --> E["Format attempt string"]
    D --> E
    E --> F["Collect M attempts"]
    F --> G{"len(attempts) == M?"}
    G -- No --> H["AssertionError"]
    G -- Yes --> I["Build kwargs: reasoning_attempt_1..M"]
    I --> J["self.predict(**kwargs)"]
    J --> K["Prediction with corrected rationale + answer"]
```

#### Usage Example

```python
import dspy

# Assume `completions` is a list of M candidate predictions
mcc = MultiChainComparison(signature=MySignature, M=3, temperature=0.7)
result = mcc(completions=completions, **inputs)
```

> **Important:** The number of `completions` passed at call time **must** equal `M`. A mismatch raises an `AssertionError`.

---

## Component Interaction

The two components serve distinct but complementary roles in a retrieval-augmented pipeline:

```mermaid
graph TD
    subgraph "Retrieval Stage"
        Q["Query input"] --> KNN
        KNN --> DEMOS["Similar examples (demos)"]
    end
    subgraph "Generation Stage"
        DEMOS --> GEN["Generate M candidate predictions"]
        GEN --> COMPLETIONS["completions"]
    end
    subgraph "Aggregation Stage"
        COMPLETIONS --> MCC["MultiChainComparison"]
        MCC --> FINAL["Final corrected prediction"]
    end
```

- **`KNN`** supplies relevant few-shot demonstrations by retrieving similar training examples.
- **`MultiChainComparison`** consumes multiple candidate generations and synthesizes a single, higher-quality answer.

---

## Dependencies

| Dependency | Used By | Purpose |
|------------|---------|---------|
| [`Embedder`](clients_core.md) | `KNN` | Vectorizes text into embeddings. |
| [`Example`](primitives.md) | `KNN` | Represents training examples and input keys. |
| [`Predict`](predict_core.md) | `MultiChainComparison` | Executes the augmented signature against an LM. |
| [`Module`](primitives.md) | `MultiChainComparison` | Base class providing module semantics. |
| [`Signature`](signatures.md) | `MultiChainComparison` | Defines and transforms the task signature. |

---

## Related Modules

- [predict_core.md](predict_core.md) — Core `Predict`, `ChainOfThought`, and `Parallel` primitives.
- [predict_advanced.md](predict_advanced.md) — Overview of all advanced prediction strategies.
- [clients_core.md](clients_core.md) — `Embedder`, `LM`, and other client abstractions.
- [primitives.md](primitives.md) — `Module`, `Example`, and `Prediction` primitives.
- [signatures.md](signatures.md) — `Signature` definition and manipulation.
- [teleprompt_core.md](teleprompt_core.md) — Optimizers such as `KNNFewShot` that build on retrieval.
