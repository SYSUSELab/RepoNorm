# Adapter Types: Code

## Introduction

The `adapter_types_code` module provides the `dspy.Code` custom type, a specialized field type used within DSPy signatures to represent source code. It is part of the broader [adapter types](adapter_types.md) family, which extends the base [`Type`](adapter_types_base.md) class to support rich, structured data in LLM inputs and outputs.

`dspy.Code` is designed for two primary use cases:

1. **Code generation** — as an output field, where the LLM produces code in a specified programming language.
2. **Code analysis** — as an input field, where existing source code is passed to the LLM for inspection, explanation, or transformation.

The type handles the common real-world problem of LLMs wrapping generated code in Markdown code fences (e.g., ` ```python ... ``` `), automatically extracting the raw code content and stripping language identifiers.

---

## Core Component

### `Code`

`Code` is a subclass of [`Type`](adapter_types_base.md) (which itself extends `pydantic.BaseModel`). It represents a single piece of source code along with an associated programming language.

| Attribute | Type | Description |
|-----------|------|-------------|
| `code` | `str` | The source code content. |
| `language` | `ClassVar[str]` | The programming language. Defaults to `"python"`. |

#### Key Methods

| Method | Kind | Purpose |
|--------|------|---------|
| `format()` | instance | Returns the raw code string. |
| `serialize_model()` | Pydantic serializer | Overrides base serialization to bypass the `<<CUSTOM-TYPE-START-IDENTIFIER>>` / `<<CUSTOM-TYPE-END-IDENTIFIER>>` tags used by the base `Type`. |
| `description()` | classmethod | Returns a human-readable description used in prompt construction, including the language and Markdown code-block formatting guidance. |
| `validate_input()` | Pydantic validator (`mode="before"`) | Normalizes inputs from `Code` instances, raw strings, or dicts into a `{"code": ...}` mapping. |

#### Input Validation Behavior

The `validate_input` validator accepts several input shapes and normalizes them:

- **`Code` instance** → returned as-is.
- **`str`** → wrapped as `{"code": _filter_code(data)}`.
- **`dict`** → must contain a `"code"` key whose value is a string; otherwise a `ValueError` is raised.
- **Anything else** → raises `ValueError`.

---

## Language Parameterization

`dspy.Code` supports a generic-style subscript syntax to bind a specific programming language at the type level:

```python
code: dspy.Code["java"] = dspy.OutputField(...)
```

This is implemented by patching `__class_getitem__` on the class via `_code_class_getitem`. When subscripted, it dynamically creates a new Pydantic model subclass (using `create_model`) named `Code_<language>` that inherits from `Code` and sets its `language` class variable accordingly.

```mermaid
flowchart LR
    A["dspy.Code"] -->|"__class_getitem__('java')"| B["create_model('Code_java', __base__=Code)"]
    B --> C["Code_java.language = 'java'"]
    C --> D["New subclass with language bound"]
```

This allows the same base type to produce language-specific descriptions and serialization behavior without duplicating code.

---

## Code Extraction (`_filter_code`)

The module-level helper `_filter_code` extracts raw code from Markdown code blocks. It applies the following strategies in order:

1. **Fenced block with language** — matches ` ```<lang>\n{code}``` ` and returns the inner content (stripped).
2. **Simple fenced block** — matches ` ```{code}``` ` (no language, possibly single-line) and returns the inner content (stripped).
3. **Fallback** — returns the input unchanged if no fences are found.

```mermaid
flowchart TD
    A["Input string"] --> B{"Matches ```lang\\n...``` ?"}
    B -->|Yes| C["Return inner code (stripped)"]
    B -->|No| D{"Matches ```...``` ?"}
    D -->|Yes| C
    D -->|No| E["Return input unchanged"]
```

---

## Architecture and Relationships

`Code` sits within the `adapter_types` family. It inherits shared behavior from the base `Type` and is consumed by the adapter implementations that serialize signatures into LLM prompts.

```mermaid
classDiagram
    class Type {
        +format() list|str
        +description() str
        +extract_custom_type_from_annotation(annotation)
        +serialize_model()
    }
    class Code {
        +str code
        +ClassVar~str~ language
        +format() str
        +description() str
        +validate_input(data)
        +serialize_model()
    }
    class Image
    class Audio
    class History
    class Tool
    class ToolCalls

    Type <|-- Code
    Type <|-- Image
    Type <|-- Audio
    Type <|-- Tool
    Type <|-- ToolCalls
    Type <|-- History
```

> **Note:** `History` extends `pydantic.BaseModel` directly rather than `Type`, but is grouped with the adapter types for organizational purposes.

### Relationship to Other Adapter Types

| Type | Documentation | Relationship to `Code` |
|------|---------------|------------------------|
| `Type` | [adapter_types_base.md](adapter_types_base.md) | Base class providing `format`, `description`, and serialization contract. |
| `Image` | [adapter_types_media.md](adapter_types_media.md) | Sibling type for image content parts. |
| `Audio` | [adapter_types_media.md](adapter_types_media.md) | Sibling type for audio content parts. |
| `History` | [adapter_types_history.md](adapter_types_history.md) | Sibling type for conversation history. |
| `Tool` / `ToolCalls` | [adapter_types_tool.md](adapter_types_tool.md) | Sibling types for function/tool calling. |

---

## Data Flow

The following diagram illustrates how a `Code` field flows through a DSPy program, from signature definition to LLM interaction and back.

```mermaid
sequenceDiagram
    participant User
    participant Signature as dspy.Signature
    participant Adapter as Adapter (e.g. ChatAdapter)
    participant LM as Language Model
    participant Code as dspy.Code

    User->>Signature: Define field `code: dspy.Code["python"]`
    Signature->>Adapter: Provide field type + description()
    Adapter->>LM: Build prompt with Code.description()
    LM-->>Adapter: Return raw text (possibly fenced)
    Adapter->>Code: validate_input(raw_text)
    Code->>Code: _filter_code() strips fences
    Code-->>Adapter: Code instance
    Adapter-->>User: result.code (raw source)
```

### Serialization Flow

When a `Code` instance is serialized (e.g., as an input field), the overridden `serialize_model` returns the plain code string rather than the tagged format used by the base `Type`:

```mermaid
flowchart LR
    A["Code instance"] --> B["serialize_model()"]
    B --> C["format()"]
    C --> D["Raw code string (no custom-type tags)"]
```

This differs from base `Type` behavior, where list-formatted content is wrapped in `<<CUSTOM-TYPE-START-IDENTIFIER>>` and `<<CUSTOM-TYPE-END-IDENTIFIER>>` markers.

---

## Usage Examples

### Code Generation (Output Field)

```python
import dspy

dspy.configure(lm=dspy.LM("openai/gpt-4o-mini"))


class CodeGeneration(dspy.Signature):
    """Generate python code to answer the question."""

    question: str = dspy.InputField(description="The question to answer")
    code: dspy.Code["java"] = dspy.OutputField(description="The code to execute")


predict = dspy.Predict(CodeGeneration)
result = predict(question="Given an array, find if any of the two numbers sum up to 10")
print(result.code)
```

### Code Analysis (Input Field)

```python
import dspy
import inspect

dspy.configure(lm=dspy.LM("openai/gpt-4o-mini"))


class CodeAnalysis(dspy.Signature):
    """Analyze the time complexity of the function."""

    code: dspy.Code["python"] = dspy.InputField(description="The function to analyze")
    result: str = dspy.OutputField(description="The time complexity of the function")


predict = dspy.Predict(CodeAnalysis)


def sleepsort(x):
    import time

    for i in x:
        time.sleep(i)
        print(i)


result = predict(code=inspect.getsource(sleepsort))
print(result.result)
```

---

## Integration Points

- **Signatures** — `Code` is used as a field type in [`dspy.Signature`](signatures.md) definitions, both as input and output fields.
- **Adapters** — Adapter implementations (e.g., `ChatAdapter`, `JSONAdapter`, `XMLAdapter`) consume `Code.description()` to build prompts and invoke `validate_input` to parse model responses. See [adapters_implementations.md](adapters_implementations.md).
- **Base Type** — Inherits the custom-type extraction mechanism (`extract_custom_type_from_annotation`) from [`Type`](adapter_types_base.md), enabling `Code` to be detected within nested annotations such as `list[Code]`.

---

## Summary

The `adapter_types_code` module delivers a focused, single-purpose type for representing source code in DSPy signatures. Its key design decisions are:

1. **Language parameterization** via `__class_getitem__` for ergonomic, type-level language binding.
2. **Robust input normalization** that accepts strings, dicts, and instances.
3. **Markdown fence extraction** to handle the common LLM output pattern.
4. **Custom serialization** that bypasses base-type tagging for clean code output.

For related types, see the sibling documentation files listed in the [Architecture and Relationships](#architecture-and-relationships) section.
