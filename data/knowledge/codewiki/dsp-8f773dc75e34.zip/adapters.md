# Adapters

## Overview

The **Adapters** module is the translation layer between DSPy's structured, typed programming model and the raw text-based interface of Large Language Models (LMs). DSPy programs are defined using [`Signature`](signatures.md) classes with typed input and output fields, but LMs only understand and produce text (or, increasingly, structured JSON / native function calls). Adapters bridge this gap in both directions:

- **Formatting (DSPy → LM):** Convert a signature, few-shot demonstrations, conversation history, and current inputs into a list of chat messages (system/user/assistant) that the LM can consume.
- **Parsing (LM → DSPy):** Convert the LM's raw text response back into a dictionary of typed output field values, validating and casting each value against the signature's field annotations.

Adapters also handle advanced concerns such as **native function/tool calling**, **structured output modes** (OpenAI Structured Outputs), **custom DSPy types** (images, audio, code, tools, history), and **conversation history** formatting.

## Architecture

The module is organized into two cooperating sub-modules:

1. **Adapter Implementations** — the concrete adapter classes that perform formatting and parsing, all deriving from a common `Adapter` base class.
2. **Adapter Types** — the custom DSPy types (`Image`, `Audio`, `Code`, `History`, `Tool`, `ToolCalls`) that adapters know how to serialize into LM-native content parts.

```mermaid
graph TD
    subgraph "Adapters Module"
        Base["Adapter (base.py)"]
        Chat["ChatAdapter"]
        JSON["JSONAdapter"]
        XML["XMLAdapter"]
        TwoStep["TwoStepAdapter"]
        BAML["BAMLAdapter"]

        Base --> Chat
        Chat --> JSON
        Chat --> XML
        JSON --> BAML
        Base --> TwoStep
    end

    subgraph "Adapter Types"
        Type["Type (base_type.py)"]
        Image["Image"]
        Audio["Audio"]
        Code["Code"]
        Tool["Tool"]
        ToolCalls["ToolCalls"]
        History["History"]

        Type --> Image
        Type --> Audio
        Type --> Code
        Type --> Tool
        Type --> ToolCalls
    end

    subgraph "External Dependencies"
        Sig["Signature (signatures.md)"]
        LM["LM (clients_core.md)"]
        Utils["adapters/utils.py"]
        Callback["BaseCallback (utils.md)"]
        Exc["AdapterParseError (utils.md)"]
    end

    Base -.uses.-> Sig
    Base -.uses.-> LM
    Base -.uses.-> Callback
    Chat -.uses.-> Utils
    JSON -.uses.-> Utils
    Base -.uses.-> Type
    Base -.uses.-> Tool
    Base -.uses.-> ToolCalls
    Base -.uses.-> History
    Chat -.raises.-> Exc
    JSON -.raises.-> Exc
    XML -.raises.-> Exc
```

## Core Functionality

### Adapter Implementations

The adapter implementations sub-module contains the `Adapter` base class and its concrete subclasses. The base class defines the full lifecycle of an LM call — `__call__` / `acall` orchestrate preprocessing (native function calling setup), formatting, the LM invocation, and postprocessing (parsing + tool-call extraction). Concrete adapters override the formatting and parsing hooks to produce different wire formats.

| Adapter | Wire Format | Key Characteristics |
| --- | --- | --- |
| `Adapter` | (abstract) | Base class; defines `format`/`parse` contract, history & tool-call handling, callback decoration |
| `ChatAdapter` | `[[ ## field ## ]]` section markers | Default adapter; falls back to `JSONAdapter` on parse failure |
| `JSONAdapter` | JSON object | Uses OpenAI Structured Outputs / JSON mode; native function calling by default |
| `XMLAdapter` | `<field>...</field>` tags | XML-tagged output fields |
| `TwoStepAdapter` | Free-form + extraction | Main LM produces natural text; a smaller LM extracts structured fields |
| `BAMLAdapter` | BAML-style schema | Renders nested Pydantic models as compact, human-readable schemas |

See [adapters_implementations.md](adapters_implementations.md) for full details on each adapter, the formatting/parsing lifecycle, and the fallback mechanisms.

### Adapter Types

The adapter types sub-module defines DSPy's custom field types. Each type knows how to `format()` itself into LM-native content parts (e.g., an `Image` becomes an `image_url` content part) and how to describe itself to the LM. Adapters use these types to detect special fields (e.g., a `History` input field triggers conversation-history formatting; a `ToolCalls` output field triggers native function-calling handling).

See [adapters_types.md](adapters_types.md) for full details on each custom type.

## Call Lifecycle

The following diagram shows how a single LM call flows through an adapter:

```mermaid
sequenceDiagram
    participant P as Predict / Module
    participant A as Adapter
    participant LM as LM
    participant U as adapters/utils

    P->>A: __call__(lm, lm_kwargs, signature, demos, inputs)
    A->>A: _call_preprocess() (native function calling setup)
    A->>A: format(signature, demos, inputs)
    A->>U: format_field_value / translate_field_type
    U-->>A: formatted strings
    A-->>A: build system + user + assistant messages
    A->>LM: lm(messages=..., **lm_kwargs)
    LM-->>A: raw outputs (text / tool_calls / logprobs)
    A->>A: _call_postprocess()
    A->>A: parse(signature, text)
    A->>U: parse_value (cast to field annotations)
    U-->>A: typed field values
    A-->>P: list[dict] of output field values
```

## Relationship to Other Modules

- **[signatures.md](signatures.md):** Adapters consume `Signature` classes to know the input/output fields, their annotations, descriptions, and instructions. Adapters also manipulate signatures (e.g., deleting the history field or tool-call fields before formatting).
- **[clients_core.md](clients_core.md):** Adapters invoke `LM` / `BaseLM` instances (`lm(messages=..., **lm_kwargs)`), passing the formatted messages and any adapter-injected kwargs such as `tools` or `response_format`.
- **[predict_core.md](predict_core.md):** `Predict` and other predictors delegate the formatting/parsing of LM interactions to the configured adapter.
- **[utils.md](utils.md):** Adapters use `BaseCallback` (via the `with_callbacks` decorator) for observability and raise `AdapterParseError` when parsing fails.
- **[streaming.md](streaming.md):** Streaming listeners consume the same message structures produced by adapters.

## Sub-module Documentation

- **[adapters_implementations.md](adapters_implementations.md)** — Detailed documentation of the `Adapter` base class and all concrete adapters (`ChatAdapter`, `JSONAdapter`, `XMLAdapter`, `TwoStepAdapter`, `BAMLAdapter`), including the formatting/parsing lifecycle, native function calling, and structured output handling.
- **[adapters_types.md](adapters_types.md)** — Detailed documentation of the custom DSPy types (`Type`, `Image`, `Audio`, `Code`, `History`, `Tool`, `ToolCalls`) and how they serialize into LM-native content parts.
