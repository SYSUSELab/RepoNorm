# Propose Grounded Module

## Introduction

The `propose_grounded` module implements **grounded instruction proposal** for DSPy programs. It is responsible for generating new, high-quality natural-language instructions for the predictors (modules) inside a DSPy program by grounding the generation process in concrete context: the program's source code, a summary of the training dataset, few-shot task demonstrations, prior instruction attempts with their scores, and randomly selected prompting "tips".

The central class, `GroundedProposer`, is a concrete implementation of the abstract [`Proposer`](propose.md) interface. It is primarily consumed by the [`MIPROv2`](teleprompt_optimizers.md) optimizer during its *instruction proposal* step, where it produces a pool of candidate instructions that are later searched over via Bayesian optimization.

The module's design philosophy is that an LLM generates better instructions when it is *grounded* in the actual task context rather than being asked to invent instructions in a vacuum. Each of the grounding signals can be independently enabled or disabled, allowing the proposer to degrade gracefully when a signal is unavailable.

---

## Architecture Overview

The module is composed of four core components plus a set of supporting signatures and utilities.

```mermaid
graph TD
    subgraph "propose_grounded"
        GP[GroundedProposer]
        GMI[GenerateModuleInstruction]
        DP[DescribeProgram]
        DM[DescribeModule]
        GIC[generate_instruction_class]
    end

    subgraph "propose (sibling)"
        PB[Proposer - abstract base]
        DSG[dataset_summary_generator]
        PU[propose/utils]
    end

    subgraph "External dependencies"
        PRED[Predict]
        SIG[Signature]
        MOD[Module]
        TU[teleprompt/utils]
    end

    GP -->|inherits| PB
    GP -->|creates| GMI
    GP -->|uses| DSG
    GP -->|uses| PU
    GP -->|uses| TU

    GMI -->|uses| DP
    GMI -->|uses| DM
    GMI -->|creates via| GIC

    DP -->|is a| SIG
    DM -->|is a| SIG
    GIC -->|returns| PRED
    GMI -->|is a| MOD
    GP -->|is a| MOD
```

### Component Responsibilities

| Component | Type | Responsibility |
|-----------|------|----------------|
| `GroundedProposer` | `Module` / `Proposer` | Orchestrates the full instruction-proposal process across all predictors and demo sets. Manages grounding configuration, randomness, and temperature control. |
| `GenerateModuleInstruction` | `Module` | Generates a single instruction for one predictor, assembling all grounding context (program description, module description, demos, history, tip). |
| `DescribeProgram` | `Signature` | Prompts the LM to describe what task a program solves and how it works. |
| `DescribeModule` | `Signature` | Prompts the LM to describe the role of a specific module within the broader program. |
| `generate_instruction_class` | factory function | Dynamically builds a `Predict` whose signature includes only the grounding fields that are enabled. |

---

## Component Details

### `GroundedProposer`

The top-level orchestrator. It is constructed with a `prompt_model`, the target `program`, and the `trainset`, along with a large set of configuration flags.

**Key configuration flags:**

- `program_aware` — include the program's source code and a generated program/module description.
- `use_dataset_summary` — include a summary of the training dataset.
- `use_task_demos` — include few-shot task demonstrations.
- `use_instruct_history` — include previously attempted instructions and their scores.
- `use_tip` — include a randomly selected prompting tip.
- `set_tip_randomly` / `set_history_randomly` — randomize the tip and history usage per proposal round.
- `num_demos_in_context` — number of demos to include.
- `rng` — random number generator (defaults to the `random` module).

**Initialization behavior:** During `__init__`, the proposer eagerly prepares two expensive grounding artifacts, each guarded by a try/except that disables the corresponding feature on failure:

1. **Program source code** — obtained via `get_dspy_source_code(program)` when `program_aware` is set.
2. **Dataset summary** — obtained via `create_dataset_summary(...)` when `use_dataset_summary` is set.

This graceful degradation ensures the proposer still functions even if source introspection or dataset summarization fails.

**Main entry point — `propose_instructions_for_program`:**

```mermaid
flowchart TD
    Start([propose_instructions_for_program]) --> Hist{set_history_randomly?}
    Hist -->|yes| RandHist[Randomly enable/disable instruction history]
    Hist -->|no| DemoCheck
    RandHist --> DemoCheck{demo_candidates provided?}
    DemoCheck -->|no| NoDemos[Disable task demos; num_demos = N]
    DemoCheck -->|yes| HasDemos[num_demos = max len of demo_candidates 0]
    NoDemos --> Loop
    HasDemos --> Loop
    Loop[For each predictor pred_i] --> DemoLoop[For each demo_set_i up to min N, num_demos]
    DemoLoop --> Tip{set_tip_randomly?}
    Tip -->|yes| PickTip[Randomly select a tip from TIPS]
    Tip -->|no| Call
    PickTip --> Call[propose_instruction_for_predictor]
    Call --> DemoLoop
    DemoLoop --> Loop
    Loop --> Return([Return dict pred_i -> list of instructions])
```

The method returns a dictionary mapping each predictor index to a list of proposed instruction strings.

**Per-predictor proposal — `propose_instruction_for_predictor`:**

For each individual instruction, the method:

1. Builds an instruction-history string via `create_predictor_level_history_string` (capped at `MAX_INSTRUCT_IN_HISTORY = 5`).
2. Instantiates a fresh `GenerateModuleInstruction` configured for the current round.
3. Applies a **temperature jitter**: it reads the prompt model's current temperature, adds a small random epsilon (`uniform(0.01, 0.05)`), and runs generation within a `dspy.settings.context(lm=self.prompt_model)` block. The original temperature is restored afterward.
4. Strips any leading field prefix from the output via `strip_prefix`.

### `GenerateModuleInstruction`

A `Module` that produces a single instruction. Its `forward` method assembles the grounding context:

- **Task demos** — gathered from the current and adjacent demo sets using `gather_examples_from_sets`, which only yields examples containing an `"augmented"` key. Falls back to `"No task demos provided."` when none are found or when using the first demo set.
- **Program description** — generated by `DescribeProgram` when `program_aware` is enabled. On any exception, it logs (if verbose) and disables `program_aware` for the remainder of the call.
- **Module code & description** — the module's input/output signature is reconstructed as `ClassName(inputs) -> outputs` by inspecting each field's `__dspy_field_type` metadata, then described by `DescribeModule`.
- **Final generation** — delegates to the dynamically-built `generate_module_instruction` predictor with all assembled fields.

### `generate_instruction_class`

A factory that returns a `dspy.Predict` wrapping a dynamically-defined `GenerateSingleModuleInstruction` signature. The signature's input fields are conditionally included based on the flags `use_dataset_summary`, `program_aware`, `use_task_demos`, `use_instruct_history`, and `use_tip`. This keeps the prompt minimal and avoids sending irrelevant context to the LM.

### `DescribeProgram` and `DescribeModule`

Two static `Signature` classes used for program-aware grounding. `DescribeProgram` takes program code and an example of use, and outputs a description. `DescribeModule` additionally takes the program description and a specific module, and outputs that module's role. Both use `prefix` metadata on their fields so that generated prompts are clearly labeled.

---

## Data Flow

The following diagram shows how grounding signals flow from their sources into a final proposed instruction.

```mermaid
flowchart LR
    subgraph Sources
        TS[trainset]
        PC[program source code]
        DC[demo_candidates]
        TL[trial_logs]
        TIPS[TIPS dict]
    end

    subgraph "GroundedProposer"
        DS[data_summary]
        PCS[program_code_string]
        IH[instruction_history]
        TIP[selected tip]
    end

    subgraph "GenerateModuleInstruction"
        TD[task_demos]
        PD[program_description]
        MD[module_description]
        BI[basic_instruction]
    end

    OUT[proposed_instruction]

    TS -->|create_dataset_summary| DS
    PC -->|get_dspy_source_code| PCS
    DC -->|gather_examples_from_sets| TD
    TL -->|create_predictor_level_history_string| IH
    TIPS -->|random choice| TIP

    DS --> OUT
    PCS --> PD
    PCS --> MD
    TD --> PD
    TD --> MD
    PD --> MD
    IH --> OUT
    TIP --> OUT
    TD --> OUT
    BI --> OUT
    MD --> OUT
```

---

## Interaction with MIPROv2

`GroundedProposer` is instantiated by [`MIPROv2`](teleprompt_optimizers.md) in its `_propose_instructions` step (Step 2 of compilation). MIPROv2 maps its own user-facing flags onto the proposer's configuration:

| MIPROv2 flag | GroundedProposer flag |
|--------------|-----------------------|
| `program_aware_proposer` | `program_aware` |
| `data_aware_proposer` | `use_dataset_summary` |
| `fewshot_aware_proposer` | `use_task_demos` |
| `tip_aware_proposer` | `use_tip` and `set_tip_randomly` |

MIPROv2 calls `propose_instructions_for_program` with `N = num_instruct_candidates`, `T = init_temperature`, and an empty `trial_logs` dict. The returned candidate instructions are then searched over by Optuna in Step 3.

```mermaid
sequenceDiagram
    participant M as MIPROv2
    participant GP as GroundedProposer
    participant GMI as GenerateModuleInstruction
    participant LM as Prompt Model

    M->>GP: __init__(program, trainset, flags...)
    GP->>LM: create_dataset_summary (if data_aware)
    GP->>GP: get_dspy_source_code (if program_aware)
    M->>GP: propose_instructions_for_program(N, T, trial_logs)
    loop each predictor, each demo set
        GP->>GMI: propose_instruction_for_predictor(...)
        GMI->>LM: DescribeProgram (if program_aware)
        GMI->>LM: DescribeModule (if program_aware)
        GMI->>LM: GenerateSingleModuleInstruction
        GMI-->>GP: proposed_instruction
    end
    GP-->>M: {pred_i: [instructions]}
```

---

## Dependencies

### Internal Dependencies

- **[`Proposer`](propose.md)** (`dspy/propose/propose_base.py`) — abstract base class defining `propose_instructions_for_program` and `propose_instruction_for_predictor`.
- **[`dataset_summary_generator`](propose_dataset_summary.md)** (`dspy/propose/dataset_summary_generator.py`) — provides `create_dataset_summary`, which uses the `DatasetDescriptor`, `DatasetDescriptorWithPriorObservations`, and `ObservationSummarizer` signatures to build the dataset summary.
- **`propose/utils`** (`dspy/propose/utils.py`) — helper functions:
  - `create_example_string` — formats an example into a labeled string using field prefixes.
  - `create_predictor_level_history_string` — aggregates and ranks prior instructions by average score.
  - `get_dspy_source_code` — introspects a module's source code and its nested signatures/modules.
  - `strip_prefix` — removes leading field-label prefixes from generated text.

### External Dependencies

- **[`Predict`](predict_core.md)** (`dspy/predict/predict.py`) — the underlying LM-calling primitive used by all signatures.
- **[`Signature`](signatures.md)** (`dspy/signatures/signature.py`) — base class for `DescribeProgram`, `DescribeModule`, and the dynamically generated instruction signature.
- **[`Module`](primitives.md)** (`dspy/primitives/module.py`) — base class for `GroundedProposer` and `GenerateModuleInstruction`.
- **`teleprompt/utils`** (`dspy/teleprompt/utils.py`) — `get_prompt_model` (resolves the prompt LM) and `get_signature` (extracts a predictor's signature).

---

## Key Constants and Configuration

| Name | Value | Purpose |
|------|-------|---------|
| `MAX_INSTRUCT_IN_HISTORY` | `5` | Maximum number of prior instructions included in the history string. |
| `TIPS` | dict | Named prompting tips (`none`, `creative`, `simple`, `description`, `high_stakes`, `persona`) used to diversify instruction generation. |

---

## Error Handling and Graceful Degradation

The module is designed to remain functional when grounding signals are unavailable:

- **Source code introspection failure** → `program_aware` is set to `False` and a message is printed.
- **Dataset summary failure** → `use_dataset_summary` is set to `False` and a message is printed.
- **Program description failure inside `GenerateModuleInstruction`** → `program_aware` is disabled for that call and the proposer runs without program awareness.
- **No demo candidates** → `use_task_demos` is disabled and `num_demos` defaults to `N`.

This layered fallback ensures that instruction proposal never hard-fails due to a missing optional grounding signal.

---

## Related Documentation

- [Propose Base](propose.md) — the abstract `Proposer` interface.
- [Dataset Summary Generator](propose_dataset_summary.md) — dataset summarization used for data-aware grounding.
- [MIPROv2 Optimizer](teleprompt_optimizers.md) — the primary consumer of this module.
- [Predict Core](predict_core.md) — the `Predict` primitive underlying all signatures.
- [Signatures](signatures.md) — the `Signature` system used to define grounding prompts.
- [Primitives](primitives.md) — `Module` and related base classes.
