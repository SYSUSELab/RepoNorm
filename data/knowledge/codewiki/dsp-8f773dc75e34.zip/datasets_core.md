# Datasets Core

## Introduction

The **Datasets Core** module provides the foundational abstractions for loading, splitting, and managing datasets within DSPy. It consists of two primary components:

- **`Dataset`** — An abstract base class that defines the standard interface for train/dev/test splitting, deterministic shuffling, and seed-based reproducibility.
- **`DataLoader`** — A concrete utility class that loads data from a wide variety of sources (HuggingFace, CSV, JSON, Parquet, Pandas, and retrieval modules) and converts them into DSPy `Example` objects.

Together, these components form the data-handling backbone used by built-in datasets (e.g., `GSM8K`, `HotPotQA`, `MATH`, `Colors`) and by user code that needs to prepare training and evaluation sets for optimizers and evaluation workflows.

---

## Architecture Overview

The module sits at the boundary between raw data sources and DSPy's core primitives. `DataLoader` inherits from `Dataset`, reusing its splitting and sampling machinery while adding source-specific loading methods.

```mermaid
graph TD
    subgraph "Datasets Core"
        Dataset["Dataset<br/>(abstract base)"]
        DataLoader["DataLoader<br/>(concrete loader)"]
        DataLoader -->|inherits| Dataset
    end

    subgraph "DSPy Primitives"
        Example["Example"]
        dotdict["dotdict"]
    end

    subgraph "Built-in Datasets"
        Colors["Colors"]
        GSM8K["GSM8K"]
        HotPotQA["HotPotQA"]
        MATH["MATH"]
    end

    subgraph "External Sources"
        HF["HuggingFace Hub"]
        CSV["CSV / JSON / Parquet"]
        Pandas["Pandas DataFrame"]
        RM["Retrieval Module"]
    end

    Colors -->|extends| Dataset
    GSM8K -.->|uses| Example
    HotPotQA -.->|uses| Example
    MATH -.->|uses| Example

    DataLoader -->|loads from| HF
    DataLoader -->|loads from| CSV
    DataLoader -->|loads from| Pandas
    DataLoader -->|loads from| RM

    Dataset -->|produces| Example
    Dataset -->|uses| dotdict
```

---

## Component Relationships

```mermaid
classDiagram
    class Dataset {
        +int train_size
        +int train_seed
        +int dev_size
        +int dev_seed
        +int test_size
        +int test_seed
        +list input_keys
        +bool do_shuffle
        +str name
        +reset_seeds(...)
        +train() property
        +dev() property
        +test() property
        +_shuffle_and_sample(split, data, size, seed)
        +prepare_by_seed(...) classmethod
    }

    class DataLoader {
        +from_huggingface(...)
        +from_csv(...)
        +from_pandas(...)
        +from_json(...)
        +from_parquet(...)
        +from_rm(...)
        +sample(dataset, n)
        +train_test_split(dataset, train_size, test_size, random_state)
    }

    class Example {
        +with_inputs(*keys)
        +inputs()
        +labels()
        +copy()
        +toDict()
    }

    DataLoader --|> Dataset : inherits
    Dataset ..> Example : creates
```

---

## Core Component: `Dataset`

The `Dataset` class is the abstract base for all DSPy datasets. It manages three logical splits — **train**, **dev**, and **test** — each with its own size and seed, and exposes them as lazily-computed properties.

### Key Responsibilities

| Responsibility | Mechanism |
| --- | --- |
| Deterministic shuffling | `random.Random(seed)` per split |
| Lazy split materialization | Cached `_train_`, `_dev_`, `_test_` attributes |
| Reproducibility | Separate seeds for train/dev/test |
| Example construction | Wraps raw dicts into `Example` objects with `dspy_uuid` and `dspy_split` metadata |
| Input key tagging | Applies `with_inputs(*input_keys)` when configured |

### Constructor Parameters

| Parameter | Default | Description |
| --- | --- | --- |
| `train_seed` | `0` | Seed used to shuffle the train split |
| `train_size` | `None` | Number of training examples to sample |
| `eval_seed` | `0` | Seed used for both dev and test splits |
| `dev_size` | `None` | Number of dev examples to sample |
| `test_size` | `None` | Number of test examples to sample |
| `input_keys` | `None` | Keys to mark as inputs on each `Example` |

### Split Properties

Each split is exposed via a property that lazily calls `_shuffle_and_sample` on first access and caches the result:

```mermaid
flowchart LR
    A["dataset.train"] --> B{"_train_ cached?"}
    B -->|No| C["_shuffle_and_sample('train', self._train, train_size, train_seed)"]
    C --> D["Cache in _train_"]
    B -->|Yes| E["Return _train_"]
    D --> E
```

### `_shuffle_and_sample`

This internal method performs the core transformation:

1. Converts the raw split data into a list.
2. Shuffles it using a `random.Random(seed)` instance (only if `do_shuffle` is `True`).
3. Truncates to the requested `size`.
4. Wraps each record into an `Example`, injecting `dspy_uuid` (a fresh UUID) and `dspy_split` metadata.
5. Optionally restricts inputs via `with_inputs(*input_keys)`.

> **Note:** The `dspy_uuid` is currently generated per-example but is not yet used for deduplication. The code comments indicate a future need for a `group_uuid` concept to handle overlapping examples (e.g., in convQA and Colors datasets).

### `reset_seeds`

Allows reconfiguration of seeds and sizes at runtime. It also invalidates the cached splits (`_train_`, `_dev_`, `_test_`) so they are recomputed on next access. This is essential for the multi-seed workflow described below.

### `prepare_by_seed` (classmethod)

A convenience factory for generating **multiple train/eval splits** across a set of seeds — commonly used for cross-validation-style experiments.

```mermaid
flowchart TD
    Start["prepare_by_seed(train_seeds, train_size, dev_size, ...)"] --> Init["Instantiate dataset with data_args"]
    Init --> EvalSet["eval_set = dataset.dev"]
    EvalSet --> Loop{"For each train_seed"}
    Loop --> Reset["dataset.reset_seeds(train_seed=...)"]
    Reset --> Slice["Slice eval_set into per-seed chunk"]
    Slice --> Collect["Append to eval_sets and train_sets"]
    Collect --> Loop
    Loop -->|Done| Return["Return dotdict(train_sets, eval_sets)"]
```

Key behaviors:
- The dev set is computed **once** and then partitioned across seeds.
- When `divide_eval_per_seed=True`, each seed receives `dev_size // len(train_seeds)` evaluation examples.
- Asserts guarantee each split has the expected size.

---

## Core Component: `DataLoader`

`DataLoader` extends `Dataset` and provides a suite of `from_*` methods that load data from external sources and normalize it into `list[dspy.Example]` (or a mapping of split name → examples).

### Loading Methods

| Method | Source | Returns |
| --- | --- | --- |
| `from_huggingface` | HuggingFace Hub dataset | `Mapping[str, list[Example]]` or `list[Example]` |
| `from_csv` | CSV file | `list[Example]` |
| `from_json` | JSON file | `list[Example]` |
| `from_parquet` | Parquet file | `list[Example]` |
| `from_pandas` | Pandas `DataFrame` | `list[Example]` |
| `from_rm` | Configured retrieval module | `list[Example]` |

All methods accept `fields` (to select a subset of columns) and `input_keys` (to mark which fields are inputs via `with_inputs`).

### Data Flow

```mermaid
flowchart LR
    subgraph Sources
        HF["HuggingFace"]
        File["CSV / JSON / Parquet"]
        DF["Pandas DataFrame"]
        RM["Retrieval Module"]
    end

    subgraph DataLoader
        Load["load_dataset / iterrows / get_objects"]
        Select["Select fields"]
        Wrap["Wrap in dspy.Example"]
        Inputs["with_inputs(*input_keys)"]
    end

    HF --> Load
    File --> Load
    DF --> Load
    RM --> Load
    Load --> Select --> Wrap --> Inputs
    Inputs --> Out["list[Example]"]
```

### `from_huggingface`

The most flexible loader. It supports:
- Multiple splits (returns a dict keyed by split name).
- A list of splits passed via `kwargs["split"]`.
- Optional `fields` filtering (must be a tuple).
- `input_keys` must be a tuple, otherwise a `ValueError` is raised.

It gracefully handles both `DatasetDict`-like objects (with `.keys()`) and plain lists via a `try/except AttributeError` fallback.

### `from_rm`

Loads examples from the retrieval module configured in `dspy.settings.rm`. It requires the module to implement `get_objects(num_samples, fields)`. Two distinct error paths are handled:

- **No retrieval module configured** → `ValueError` prompting the user to configure one.
- **Module lacks `get_objects`** → `ValueError` suggesting a different retrieval module.

### Utility Methods

#### `sample(dataset, n)`

Returns `n` random examples from a list. Validates that the input is a list of `Example`s.

#### `train_test_split(dataset, train_size, test_size, random_state)`

Splits a list of examples into train/test partitions.

| Parameter | Type | Behavior |
| --- | --- | --- |
| `train_size` | `float` (0–1) or `int` | Proportion or absolute count for train |
| `test_size` | `float` (0–1), `int`, or `None` | Proportion/count for test; defaults to remainder |
| `random_state` | `int` or `None` | Seeds `random` for reproducible shuffling |

Validation rules:
- `train_size` must be a float in `(0, 1)` or a positive int.
- `test_size` (if provided) must be a float in `(0, 1)` or a positive int.
- `train_size + test_size` cannot exceed the dataset length.

```mermaid
flowchart TD
    Start["train_test_split(dataset, train_size, test_size)"] --> Seed{"random_state set?"}
    Seed -->|Yes| SetSeed["random.seed(random_state)"]
    Seed -->|No| Skip
    SetSeed --> Shuffle
    Skip --> Shuffle["Shuffle a copy of dataset"]
    Shuffle --> ComputeTrain["Compute train_end from train_size"]
    ComputeTrain --> TestProvided{"test_size provided?"}
    TestProvided -->|Yes| ComputeTest["Compute test_end from test_size"]
    TestProvided -->|No| Remainder["test_end = len - train_end"]
    ComputeTest --> Validate{"train_end + test_end <= len?"}
    Remainder --> Slice
    Validate -->|No| Error["Raise ValueError"]
    Validate -->|Yes| Slice["Slice into train/test"]
    Slice --> Return["Return {'train': ..., 'test': ...}"]
```

---

## Integration with Built-in Datasets

Built-in datasets either extend `Dataset` or produce `Example` lists directly:

- **`Colors`** extends `Dataset`, populating `self._train` and `self._dev` with color records and relying on the base class for shuffling/sampling. See [datasets_builtin.md](datasets_builtin.md).
- **`GSM8K`**, **`HotPotQA`**, and **`MATH`** are standalone classes that download data from HuggingFace and construct `dspy.Example` objects with `with_inputs(...)`. See [datasets_builtin.md](datasets_builtin.md).

---

## Dependencies

| Dependency | Module | Purpose |
| --- | --- | --- |
| `Example` | [primitives.md](primitives.md) | The unit of data produced by all loaders |
| `dotdict` | [dsp_utils.md](dsp_utils.md) | Attribute-accessible dict used for `prepare_by_seed` results and data args |
| `dspy.settings.rm` | [dsp_utils.md](dsp_utils.md) | Retrieval module source for `from_rm` |
| `datasets` (HuggingFace) | external | Backend for `from_huggingface`, `from_csv`, `from_json`, `from_parquet` |
| `pandas` | external | Input type for `from_pandas` |

---

## Usage Examples

### Loading from HuggingFace

```python
from dspy.datasets import DataLoader

dl = DataLoader()
dataset = dl.from_huggingface(
    "gsm8k",
    "main",
    split="train",
    input_keys=("question",),
)
```

### Splitting a Dataset

```python
splits = dl.train_test_split(dataset, train_size=0.8, random_state=42)
train, test = splits["train"], splits["test"]
```

### Multi-Seed Preparation

```python
from dspy.datasets import Dataset

result = Dataset.prepare_by_seed(
    train_seeds=[1, 2, 3],
    train_size=16,
    dev_size=300,
)
train_sets, eval_sets = result.train_sets, result.eval_sets
```

---

## Summary

The **Datasets Core** module provides a clean separation between *data acquisition* (`DataLoader`) and *data partitioning* (`Dataset`). Its design emphasizes:

- **Reproducibility** through explicit, per-split seeds.
- **Flexibility** via a broad set of source loaders.
- **Consistency** by normalizing everything into `dspy.Example` objects with input-key tagging.
- **Reusability** through inheritance, allowing built-in datasets like `Colors` to leverage the base splitting logic.

For details on the concrete datasets built on top of this module, see [datasets_builtin.md](datasets_builtin.md).
