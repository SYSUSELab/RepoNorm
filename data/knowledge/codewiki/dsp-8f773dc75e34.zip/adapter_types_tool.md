# Adapter Types: Tool

## Introduction

The `adapter_types_tool` module provides the core abstractions for **tool calling (function calling)** in DSPy. It defines two primary types:

- **`Tool`** — a wrapper around a Python callable that exposes it to LLMs as a callable function, complete with an auto-inferred JSON schema for its arguments.
- **`ToolCalls`** — a container representing one or more tool invocations (name + arguments) produced by an LLM, formatted to be compatible with OpenAI's tool-call schema.

These types are part of the broader [adapter types](adapter_types.md) family and are consumed by the [adapters implementations](adapters_implementations.md) (e.g., `ChatAdapter`, `JSONAdapter`) when serializing/deserializing signatures that involve tool use.

---

## Module Structure

The module lives at `dspy/adapters/types/tool.py` and contains the following core components:

| Component | Kind | Purpose |
|-----------|------|---------|
| `Tool` | Class (extends `Type`) | Wraps a Python function as an LLM-callable tool with schema inference and validation. |
| `ToolCalls` | Class (extends `Type`) | Container for a list of tool invocations. |
| `ToolCalls.ToolCall` | Nested `BaseModel` | A single tool invocation (`name`, `args`). |
| `_resolve_json_schema_reference` | Helper function | Recursively expands `$ref`/`$defs` in JSON schemas. |
| `convert_input_schema_to_tool_args` | Helper function | Converts a JSON input schema into DSPy `Tool` args/arg_types/arg_desc. |

---

## Architecture

Both `Tool` and `ToolCalls` inherit from the base [`Type`](adapter_types_base.md) class, which is a Pydantic `BaseModel` that supports custom serialization via a `format()` method. This makes them first-class citizens in DSPy signatures.

```mermaid
classDiagram
    class Type {
        <<abstract>>
        +format() list|str
        +description() str
        +extract_custom_type_from_annotation(annotation)
        +serialize_model()
    }

    class Tool {
        +Callable func
        +str name
        +str desc
        +dict args
        +dict arg_types
        +dict arg_desc
        +bool has_kwargs
        +__init__(func, name, desc, args, arg_types, arg_desc)
        +_parse_function(func, arg_desc)
        +_validate_and_parse_args(**kwargs)
        +format() str
        +format_as_litellm_function_call() dict
        +__call__(**kwargs)
        +acall(**kwargs)
        +from_mcp_tool(session, tool)$ Tool
        +from_langchain(tool)$ Tool
    }

    class ToolCalls {
        +list~ToolCall~ tool_calls
        +from_dict_list(dicts)$ ToolCalls
        +description() str
        +format() list
    }

    class ToolCall {
        +str name
        +dict args
    }

    Type <|-- Tool
    Type <|-- ToolCalls
    ToolCalls *-- ToolCall
```

---

## Component Details

### `Tool`

`Tool` simplifies exposing Python functions to LLMs. It automatically infers the tool's `name`, `desc`, `args`, and `arg_types` from the wrapped function's signature and type hints, unless the user explicitly provides them.

#### Key Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `func` | `Callable` | The wrapped function. |
| `name` | `str \| None` | Tool name (defaults to function `__name__`). |
| `desc` | `str \| None` | Tool description (defaults to function docstring). |
| `args` | `dict[str, Any] \| None` | JSON schema per argument. |
| `arg_types` | `dict[str, Any] \| None` | Python type per argument. |
| `arg_desc` | `dict[str, str] \| None` | Description per argument. |
| `has_kwargs` | `bool` | Whether the function accepts `**kwargs`. |

#### Schema Inference (`_parse_function`)

When a `Tool` is constructed, `_parse_function` inspects the callable:

1. Resolves the callable to inspect (`func` itself or `func.__call__` for callable objects).
2. Extracts the name and docstring.
3. Uses `inspect.signature` and `get_type_hints` to build a per-argument type map.
4. For each argument, generates a JSON schema:
   - If the type is a Pydantic `BaseModel` subclass, uses `model_json_schema()`.
   - Otherwise, uses `TypeAdapter(v).json_schema()`.
   - Resolves `$ref`/`$defs` references via `_resolve_json_schema_reference`.
   - Attaches `default` values and `description` (from `arg_desc`).
5. Detects `**kwargs` via `VAR_KEYWORD` parameters.

#### Argument Validation & Parsing (`_validate_and_parse_args`)

Before invoking the wrapped function, arguments are:

1. **Validated** against the JSON schema using `jsonschema.validate`. Unknown args raise `ValueError` unless `has_kwargs` is set.
2. **Parsed** into the correct Python types using a dynamically created Pydantic wrapper model (`create_model`). This handles nested models such as `list[list[MyPydanticModel]]`.

#### Invocation

- **`__call__(**kwargs)`** — Synchronous invocation. Decorated with `@with_callbacks` for observability. If the underlying function is a coroutine, it either runs it synchronously (when `settings.allow_tool_async_sync_conversion` is enabled) or raises a `ValueError` directing the user to `acall`.
- **`acall(**kwargs)`** — Asynchronous invocation. Awaits coroutine results; sync functions are returned directly.

#### Formatting

- **`format()`** — Returns the string representation (`str(self)`).
- **`format_as_litellm_function_call()`** — Produces a dict compatible with LiteLLM/OpenAI function-calling format, including `name`, `description`, and a `parameters` object with `properties` and `required`.

#### Interoperability

- **`from_mcp_tool(session, tool)`** — Builds a DSPy `Tool` from an MCP tool + client session (delegates to `dspy.utils.mcp.convert_mcp_tool`).
- **`from_langchain(tool)`** — Builds a DSPy `Tool` from a LangChain `BaseTool` (delegates to `dspy.utils.langchain_tool.convert_langchain_tool`).

### `ToolCalls`

`ToolCalls` represents the output of an LLM that requests one or more tool invocations.

- **`ToolCall`** (nested `BaseModel`) — holds `name: str` and `args: dict[str, Any]`.
- **`from_dict_list(dicts)`** — Constructs a `ToolCalls` from a list of `{"name": ..., "args": ...}` dicts.
- **`description()`** — Returns a human-readable description used in signature prompts.
- **`format()`** — Returns a list of dicts matching OpenAI's tool-call schema (`type: "tool_calls"` with nested `function` entries).

### Helper Functions

- **`_resolve_json_schema_reference(schema)`** — Recursively expands `$ref` references using `$defs`/`definitions`, then removes the `$defs` key. Used to flatten Pydantic-generated schemas.
- **`convert_input_schema_to_tool_args(schema)`** — Converts a JSON input schema into the `(args, arg_types, arg_desc)` tuple expected by `Tool`. Maps JSON types to Python types via `_TYPE_MAPPING` and appends `" (Required)"` to required argument descriptions.

---

## Data Flow

The following diagram shows how a `Tool` is created, exposed to an LLM, and invoked.

```mermaid
flowchart TD
    A[Python function] --> B[Tool.__init__]
    B --> C[_parse_function]
    C --> D[Inspect signature + type hints]
    D --> E[Generate JSON schema per arg]
    E --> F[_resolve_json_schema_reference]
    F --> G[Tool with args/arg_types/arg_desc]

    G --> H[format_as_litellm_function_call]
    H --> I[LLM receives tool definition]

    I --> J[LLM returns ToolCalls]
    J --> K[ToolCalls.from_dict_list]
    K --> L[ToolCalls.format]

    L --> M[Tool.__call__ / Tool.acall]
    M --> N[_validate_and_parse_args]
    N --> O[jsonschema.validate]
    O --> P[Pydantic type parsing]
    P --> Q[func invoked]
    Q --> R[Result returned]
```

---

## Dependencies

```mermaid
flowchart LR
    subgraph tool_module[adapter_types_tool]
        Tool
        ToolCalls
    end

    Tool --> Type[adapter_types_base: Type]
    ToolCalls --> Type
    Tool --> Settings[dsp_utils: settings]
    Tool --> Callbacks[utils: with_callbacks]
    Tool --> MCP[dspy.utils.mcp]
    Tool --> LangChain[dspy.utils.langchain_tool]

    Tool -.consumed by.-> Adapters[adapters_implementations]
    ToolCalls -.consumed by.-> Adapters
```

| Dependency | Role |
|------------|------|
| [`Type`](adapter_types_base.md) | Base class providing `format()`/serialization contract. |
| [`settings`](dsp_utils.md) | Provides `allow_tool_async_sync_conversion` flag. |
| [`with_callbacks`](utils.md) | Adds callback/observability hooks to `__call__`/`acall`. |
| `jsonschema` | Validates arguments against inferred schemas. |
| `pydantic` | Type parsing, model creation, and schema generation. |
| `dspy.utils.mcp` | MCP tool conversion. |
| `dspy.utils.langchain_tool` | LangChain tool conversion. |

---

## Integration with the Broader System

`Tool` and `ToolCalls` are custom [`Type`](adapter_types_base.md) subclasses, so they can be embedded in DSPy signatures and are automatically detected by `Type.extract_custom_type_from_annotation` even when nested (e.g., `list[dict[str, Tool]]`). The [adapters implementations](adapters_implementations.md) use their `format()` methods to serialize them into LLM prompts and parse them back from LLM responses.

```mermaid
sequenceDiagram
    participant User
    participant Signature
    participant Adapter as Adapter (ChatAdapter/JSONAdapter)
    participant Tool
    participant LLM

    User->>Signature: Define signature with Tool field
    Signature->>Adapter: Serialize signature
    Adapter->>Tool: format_as_litellm_function_call()
    Tool-->>Adapter: Tool definition dict
    Adapter->>LLM: Send prompt + tool definitions
    LLM-->>Adapter: Tool call response
    Adapter->>Tool: Invoke via __call__/acall
    Tool-->>Adapter: Result
    Adapter-->>User: Prediction
```

---

## Usage Example

```python
import dspy

def get_weather(city: str, unit: str = "celsius"):
    """Get the current weather for a city."""
    return f"Weather in {city}: 22 {unit}"

tool = dspy.Tool(get_weather)
print(tool.name)   # "get_weather"
print(tool.desc)   # "Get the current weather for a city."
print(tool.args)
# {'city': {'type': 'string'}, 'unit': {'type': 'string', 'default': 'celsius'}}

# Synchronous invocation
result = tool(city="Paris")

# Asynchronous invocation
result = await tool.acall(city="Paris")
```

---

## Related Documentation

- [adapter_types](adapter_types.md) — Overview of all adapter custom types.
- [adapter_types_base](adapter_types_base.md) — The `Type` base class.
- [adapter_types_media](adapter_types_media.md) — `Image` and `Audio` types.
- [adapter_types_code](adapter_types_code.md) — The `Code` type.
- [adapter_types_history](adapter_types_history.md) — The `History` type.
- [adapters_implementations](adapters_implementations.md) — Adapters that consume these types.
- [utils](utils.md) — Callback and utility infrastructure.
- [dsp_utils](dsp_utils.md) — Settings and DSP utilities.
