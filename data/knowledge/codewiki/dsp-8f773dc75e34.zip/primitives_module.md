# Primitives Module (`primitives_module`)

## Introduction

The `primitives_module` is the foundational building block of DSPy programs. It provides the
`BaseModule` and `Module` classes that serve as the base for every DSPy program, along with the
`ProgramMeta` metaclass that guarantees correct initialization of all modules.

A DSPy `Module` is analogous to a `torch.nn.Module`: it is a composable, nestable unit that
encapsulates parameters (predictors), sub-modules, and a `forward` method defining its behavior.
Modules support:

- **Composition** — modules can contain other modules, lists, tuples, and dicts of modules.
- **Parameter discovery** — recursive traversal of nested parameters and sub-modules.
- **State management** — saving/loading state, deep copying, and resetting parameters.
- **Execution** — synchronous (`__call__`) and asynchronous (`acall`) invocation with callback
  and usage-tracking integration.
- **Batching** — parallel execution over lists of examples.

This module is the parent of the other primitives: [`Example`](primitives_example.md),
[`Prediction`](primitives_prediction.md), and
[`PythonInterpreter`](primitives_python_interpreter.md).

---

## Architecture Overview

The module consists of two core classes and one metaclass:

| Component | File | Responsibility |
|-----------|------|----------------|
| `BaseModule` | `dspy/primitives/base_module.py` | Parameter/sub-module traversal, state serialization, deep copy |
| `Module` | `dspy/primitives/module.py` | Execution (`__call__`/`acall`), batching, LM management, callbacks |
| `ProgramMeta` | `dspy/primitives/module.py` | Metaclass ensuring every module instance is properly initialized |

```mermaid
classDiagram
    class BaseModule {
        +named_parameters()
        +named_sub_modules(type_, skip_compiled)
        +parameters()
        +deepcopy()
        +reset_copy()
        +dump_state()
        +load_state(state)
        +save(path, save_program, modules_to_serialize)
        +load(path)
    }

    class Module {
        +_compiled: bool
        +callbacks: list
        +history: list
        +_base_init()
        +__call__(*args, **kwargs)
        +acall(*args, **kwargs)
        +named_predictors()
        +predictors()
        +set_lm(lm)
        +get_lm()
        +map_named_predictors(func)
        +inspect_history(n)
        +batch(examples, ...)
    }

    class ProgramMeta {
        +__call__(cls, *args, **kwargs)
    }

    BaseModule <|-- Module
    ProgramMeta ..> Module : instantiates
```

---

## Component Relationships

`Module` extends `BaseModule`, inheriting all traversal and serialization capabilities while
adding execution semantics. The `ProgramMeta` metaclass wraps instantiation of every `Module`
subclass.

```mermaid
graph TD
    ProgramMeta["ProgramMeta (metaclass)"]
    Module["Module"]
    BaseModule["BaseModule"]

    ProgramMeta -->|"__call__ creates & initializes"| Module
    Module -->|"inherits"| BaseModule

    BaseModule -->|"uses"| Parameter["Parameter (dspy.predict.parameter)"]
    BaseModule -->|"uses"| Saving["get_dependency_versions (dspy.utils.saving)"]
    Module -->|"uses"| Settings["Settings (dspy.dsp.utils.settings)"]
    Module -->|"uses"| Callbacks["with_callbacks (dspy.utils.callback)"]
    Module -->|"uses"| UsageTracker["track_usage (dspy.utils.usage_tracker)"]
    Module -->|"uses"| Parallel["Parallel (dspy.predict.parallel)"]
    Module -->|"uses"| Example["Example (dspy.primitives.example)"]
```

---

## `BaseModule`

`BaseModule` provides the structural backbone for DSPy programs. It knows how to walk the object
graph to find parameters and sub-modules, and how to serialize/deserialize state.

### Parameter and Sub-module Discovery

Two traversal methods exist, with intentionally different behaviors:

- **`named_parameters()`** — Returns a flat list of `(name, Parameter)` tuples. It recurses into
  sub-modules (unless they are `_compiled`), and also handles non-recursive lists, tuples, and
  dicts of parameters. Names use dotted/bracketed paths such as
  `children[4]['key'].sub_module`.
- **`named_sub_modules(type_=None, skip_compiled=False)`** — A generator yielding
  `(name, BaseModule)` tuples for all reachable sub-modules. It uses a BFS queue with a `seen`
  set so that a sub-module reachable via multiple paths is yielded only once.

> **Note:** `named_parameters` and `named_sub_modules` deliberately differ in behavior (a
> temporary design decision). `named_parameters` is non-recursive for lists/dicts of parameters,
> while `named_sub_modules` recurses through containers.

```mermaid
flowchart TD
    Start["named_parameters()"] --> CheckSelf{"self is Parameter?"}
    CheckSelf -->|yes| AddSelf["add 'self'"]
    CheckSelf -->|no| Iterate["iterate self.__dict__"]
    AddSelf --> Iterate
    Iterate --> TypeCheck{"value type?"}
    TypeCheck -->|Parameter| AddParam["add (name, param)"]
    TypeCheck -->|Module| CheckCompiled{"_compiled?"}
    CheckCompiled -->|no| Recurse["recurse named_parameters()"]
    CheckCompiled -->|yes| Skip["skip (frozen)"]
    TypeCheck -->|list/tuple| IterateList["add name[i]"]
    TypeCheck -->|dict| IterateDict["add name['key']"]
```

### State Management

| Method | Purpose |
|--------|---------|
| `parameters()` | Returns just the parameter objects (drops names). |
| `deepcopy()` | Deep copies `self.parameters()`; other attributes are shallow-copied. Falls back gracefully if deep copy fails. |
| `reset_copy()` | Deep copies the module and resets all parameters. |
| `dump_state()` | Returns `{name: param.dump_state()}` for all named parameters. |
| `load_state(state)` | Loads state into each named parameter. |
| `save(path, save_program, modules_to_serialize)` | Persists state (`.json`/`.pkl`) or the whole program (directory via cloudpickle). |
| `load(path)` | Loads saved state and warns on dependency version mismatches. |

#### Save Modes

```mermaid
flowchart TD
    Save["save(path, save_program)"] --> Mode{"save_program?"}
    Mode -->|True| Prog["Require directory path"]
    Prog --> Register["register_pickle_by_value(modules_to_serialize)"]
    Register --> Dump["cloudpickle.dump(self) -> program.pkl"]
    Dump --> Meta["write metadata.json (dependency versions)"]
    Mode -->|False| State["state = dump_state() + metadata"]
    State --> Ext{"path suffix?"}
    Ext -->|.json| Json["ujson.dump(state)"]
    Ext -->|.pkl| Pkl["cloudpickle.dump(state)"]
    Ext -->|other| Err["ValueError"]
```

When `save_program=True`, the entire module (architecture + state) is serialized with
`cloudpickle`. The `modules_to_serialize` argument registers custom modules for
`register_pickle_by_value`, ensuring they are serialized by value rather than by reference.

When `save_program=False`, only the state is saved. Dependency versions (Python, DSPy,
cloudpickle) are embedded in the metadata so that `load()` can warn about version mismatches.

---

## `Module`

`Module` is the user-facing base class for all DSPy programs. Subclasses implement a `forward`
method; users invoke the module via `__call__`.

### Initialization via `ProgramMeta`

`ProgramMeta.__call__` intercepts instantiation to guarantee that critical attributes exist even
if a subclass forgets to call `super().__init__()`:

```mermaid
sequenceDiagram
    participant User
    participant ProgramMeta
    participant Module
    participant Subclass

    User->>ProgramMeta: Subclass(args, kwargs)
    ProgramMeta->>Subclass: cls.__new__(cls)
    ProgramMeta->>Module: _base_init(obj)
    Note over Module: sets _compiled, callbacks, history
    ProgramMeta->>Subclass: cls.__init__(obj, args, kwargs)
    ProgramMeta->>ProgramMeta: ensure callbacks & history exist
    ProgramMeta-->>User: obj
```

`_base_init` sets `_compiled = False`, `callbacks = []`, and `history = []`. After `__init__`
runs, the metaclass re-checks that `callbacks` and `history` exist and creates them if missing.

### Execution Flow

Both `__call__` and `acall` are decorated with `with_callbacks` (see
[utils module](utils.md)) and manage the caller-module stack and usage tracking.

```mermaid
flowchart TD
    Call["module(*args, **kwargs)"] --> CB["with_callbacks wrapper"]
    CB --> Stack["append self to settings.caller_modules"]
    Stack --> Context["settings.context(caller_modules=...)"]
    Context --> Track{"settings.track_usage AND no active tracker?"}
    Track -->|yes| Usage["track_usage() context"]
    Usage --> Forward["self.forward(*args, **kwargs)"]
    Forward --> SetUsage["output.set_lm_usage(total_tokens)"]
    SetUsage --> Return["return output"]
    Track -->|no| Forward2["self.forward(*args, **kwargs)"]
    Forward2 --> Return
```

- **`__call__`** — Synchronous entry point. Maintains a `caller_modules` list in settings so
  nested modules can be tracked, and optionally wraps execution in a usage tracker.
- **`acall`** — Asynchronous counterpart calling `aforward`.
- **`__getattribute__`** — Warns when `forward` is called directly instead of via `module(...)`.

### Predictor Management

| Method | Purpose |
|--------|---------|
| `named_predictors()` | Returns `(name, Predict)` tuples for all `Predict` parameters. |
| `predictors()` | Returns just the `Predict` objects. |
| `set_lm(lm)` | Assigns an LM to every predictor. |
| `get_lm()` | Returns the unique LM used, or raises if multiple LMs are in use. |
| `map_named_predictors(func)` | Applies `func` to each predictor and reassigns via `set_attribute_by_name`. |
| `inspect_history(n)` | Pretty-prints the last `n` LM calls from `self.history`. |

### Batching

`batch()` processes a list of `Example` instances in parallel using the
[`Parallel`](predict_core.md) module. It builds `(self, example.inputs())` execution pairs and
delegates to `Parallel.forward`.

```mermaid
flowchart LR
    Examples["list[Example]"] --> Pairs["exec_pairs = [(self, ex.inputs())]"]
    Pairs --> Parallel["Parallel.forward(exec_pairs)"]
    Parallel --> Results["list[Prediction]"]
    Parallel -.->|return_failed_examples| Failed["(results, failed, exceptions)"]
```

### Pickling Behavior

`Module` customizes pickling via `__getstate__`/`__setstate__`, excluding `history` and
`callbacks` from the serialized state and recreating them (as empty lists) on unpickling. This
keeps serialized programs lightweight and avoids pickling non-serializable callback objects.

---

## Data Flow: A Module Invocation

```mermaid
sequenceDiagram
    participant User
    participant Module
    participant Callbacks as with_callbacks
    participant Settings
    participant Forward as forward()
    participant Predictor as Predict

    User->>Module: module(**inputs)
    Module->>Callbacks: start callbacks
    Callbacks->>Settings: read callbacks
    Module->>Settings: context(caller_modules += self)
    Module->>Forward: forward(**inputs)
    Forward->>Predictor: predictor(**inputs)
    Predictor-->>Forward: Prediction
    Forward-->>Module: Prediction
    Module->>Callbacks: end callbacks
    Module-->>User: Prediction
```

---

## Integration with the Broader System

The `primitives_module` sits at the center of DSPy's execution model:

- **Predictors** ([`predict_core`](predict_core.md)) — `Predict` and its variants are the
  `Parameter` subclasses discovered by `named_parameters`/`named_predictors`.
- **Settings** ([`dsp_utils`](dsp_utils.md)) — `Module.__call__` reads and mutates
  `settings.caller_modules`, `settings.track_usage`, and thread-local overrides.
- **Callbacks** ([`utils`](utils.md)) — `with_callbacks` provides start/end hooks around every
  module invocation.
- **Usage Tracking** ([`utils`](utils.md)) — `track_usage` aggregates token usage across nested
  module calls.
- **Parallelism** ([`predict_core`](predict_core.md)) — `batch()` delegates to `Parallel` for
  concurrent execution.
- **Examples/Predictions** ([`primitives_example`](primitives_example.md),
  [`primitives_prediction`](primitives_prediction.md)) — `batch()` consumes `Example` inputs and
  produces `Prediction` outputs.
- **Optimizers** ([`teleprompt_core`](teleprompt_core.md),
  [`teleprompt_optimizers`](teleprompt_optimizers.md)) — Teleprompters operate on modules by
  discovering and mutating their predictors via `named_predictors`/`map_named_predictors`.

---

## Key Design Considerations

1. **Frozen sub-modules** — Sub-modules marked `_compiled = True` are skipped during parameter
   traversal, allowing pre-compiled modules to be treated as fixed components.
2. **Graceful deep copy** — `deepcopy()` attempts a full `copy.deepcopy`, then falls back to
   per-attribute copying with progressively weaker strategies (deep → shallow → reference).
3. **Version-aware loading** — `load()` compares saved dependency versions against the current
   environment and logs warnings on mismatch.
4. **Metaclass safety net** — `ProgramMeta` ensures modules are always usable even when
   subclasses omit `super().__init__()`.
5. **Direct `forward` warning** — Calling `forward` directly (bypassing `__call__`) triggers a
   warning, since it skips callback and usage-tracking machinery.
