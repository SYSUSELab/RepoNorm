# Teleprompt Optimizers: Instruction Optimization

## Introduction

The **Instruction Optimization** module provides teleprompters that automatically improve the *instructions* (and output field prefixes) of a DSPy program's predictors. Rather than optimizing demonstrations (few-shot examples), these optimizers focus on the natural-language task description that guides the language model.

The module is centered on **COPRO** (Coordinate-ascent Prompt Optimization), a breadth/depth search algorithm that iteratively proposes, evaluates, and refines instructions using a dedicated *prompt model*. A deprecated alias, `SignatureOptimizer`, is retained for backward compatibility.

This module is one of several optimizer families under the `teleprompt_optimizers` umbrella. For related approaches, see:

- [Bayesian optimizers](teleprompt_optimizers_bayesian.md) — `MIPROv2`, `BootstrapFewShotWithOptuna`
- [SIMBA optimizer](teleprompt_optimizers_simba.md) — `SIMBA`
- [Rules induction](teleprompt_optimizers_rules.md) — `InferRules`
- [Core teleprompters](teleprompt_core.md) — `BootstrapFewShot`, `LabeledFewShot`, `Ensemble`, etc.

---

## Module Purpose

The instruction optimizers solve a specific problem: **given a program with a fixed structure, what is the best natural-language instruction for each predictor?**

Key characteristics:

| Aspect | Description |
| --- | --- |
| **Optimization target** | `Signature.instructions` and the output field `prefix` of each predictor |
| **Search strategy** | Coordinate ascent over predictors, with breadth/depth exploration |
| **Feedback signal** | Task metric evaluated on a training set via `Evaluate` |
| **Prompt generation** | A separate `prompt_model` proposes new instructions |
| **Program structure** | Unchanged — only instructions/prefixes are modified |

---

## Core Components

### `COPRO`

The primary optimizer class. It extends `Teleprompter` and implements the coordinate-ascent instruction search.

**Constructor parameters:**

| Parameter | Default | Description |
| --- | --- | --- |
| `prompt_model` | `None` | LM used to *generate* candidate instructions. Falls back to `dspy.settings.lm` when unset. |
| `metric` | `None` | Task metric used to score candidates. |
| `breadth` | `10` | Number of new prompts generated per iteration. Must be `> 1`. |
| `depth` | `3` | Number of refinement rounds, each using prior attempts as context. |
| `init_temperature` | `1.4` | Sampling temperature for prompt generation (higher = more creative). |
| `track_stats` | `False` | When `True`, records score statistics on the returned program. |

**Key methods:**

- `compile(student, *, trainset, eval_kwargs)` — Runs the optimization loop and returns the best program.
- `_check_candidates_equal(c1, c2)` — Compares two candidate programs by instruction and prefix.
- `_drop_duplicates(candidates)` — Removes duplicate candidates that share the same score.
- `_get_signature` / `_set_signature` — Accessors for a predictor's signature.
- `_print_signature(predictor)` — Debug helper that logs instructions and prefix.

### `BasicGenerateInstruction`

A `Signature` used to seed the search. Given the *initial* instruction, the prompt model proposes an improved instruction and an output prefix.

```
Input:  basic_instruction
Output: proposed_instruction
        proposed_prefix_for_output_field
```

### `GenerateInstructionGivenAttempts`

A `Signature` used in subsequent depth iterations. It receives a history of attempted instructions paired with their validation scores (ordered by increasing score) and proposes a better instruction.

```
Input:  attempted_instructions
Output: proposed_instruction
        proposed_prefix_for_output_field
```

### `SignatureOptimizer` (Deprecated)

A thin subclass of `COPRO` retained for backward compatibility. It emits a deprecation warning on construction and maps its `devset` argument to `COPRO.compile`'s `trainset`. **Use `COPRO` instead.**

---

## Architecture

```mermaid
graph TD
    subgraph "Instruction Optimizers"
        COPRO["COPRO<br/>(Teleprompter)"]
        SO["SignatureOptimizer<br/>(deprecated)"]
        BGI["BasicGenerateInstruction<br/>(Signature)"]
        GIGA["GenerateInstructionGivenAttempts<br/>(Signature)"]
    end

    subgraph "Core Dependencies"
        TP["Teleprompter<br/>(base class)"]
        EV["Evaluate"]
        SIG["Signature"]
        PRED["Predict"]
        MOD["Module"]
        EX["Example"]
        SET["Settings"]
    end

    SO -->|subclass| COPRO
    COPRO -->|extends| TP
    COPRO -->|uses| BGI
    COPRO -->|uses| GIGA
    COPRO -->|scores via| EV
    COPRO -->|mutates| SIG
    COPRO -->|generates with| PRED
    COPRO -->|optimizes| MOD
    EV -->|evaluates on| EX
    PRED -->|reads config from| SET
```

---

## Component Interaction

The optimizer coordinates three distinct roles:

1. **The student program** (`Module`) — the program being optimized. Its predictors' signatures are mutated in place (on a deep copy).
2. **The prompt model** (`prompt_model`) — generates candidate instructions via `Predict` over the two generation signatures.
3. **The task metric + `Evaluate`** — scores each candidate program on the training set.

```mermaid
sequenceDiagram
    participant User
    participant COPRO
    participant PromptModel as prompt_model (LM)
    participant Student as student (Module)
    participant Eval as Evaluate

    User->>COPRO: compile(student, trainset, eval_kwargs)
    COPRO->>Student: deepcopy()
    COPRO->>Eval: Evaluate(devset=trainset, metric)

    Note over COPRO,PromptModel: Seed phase
    loop for each predictor
        COPRO->>PromptModel: Predict(BasicGenerateInstruction, n=breadth-1)
        PromptModel-->>COPRO: candidate instructions + prefixes
    end

    Note over COPRO,Eval: Depth iterations
    loop depth times
        loop for each predictor
            loop for each candidate
                COPRO->>Student: set signature (instruction, prefix)
                COPRO->>Eval: evaluate(module_clone)
                Eval-->>COPRO: score
            end
            COPRO->>Student: set best candidate
        end
        COPRO->>PromptModel: Predict(GenerateInstructionGivenAttempts)
        PromptModel-->>COPRO: next batch of candidates
    end

    COPRO->>COPRO: sort + drop duplicates
    COPRO-->>User: best_program
```

---

## Optimization Process Flow

The `compile` method follows a coordinate-ascent strategy with breadth/depth exploration:

```mermaid
flowchart TD
    Start([compile]) --> Copy[Deep-copy student program]
    Copy --> Seed[Seed phase: generate BREADTH candidates<br/>per predictor via BasicGenerateInstruction]
    Seed --> DepthLoop{depth iterations}

    DepthLoop -->|for each predictor| EvalCandidates[Evaluate each candidate<br/>by setting signature & scoring]
    EvalCandidates --> TrackLatest[Track latest-batch stats<br/>if track_stats]
    TrackLatest --> SetBest[Set predictor to best-scoring candidate]
    SetBest --> MorePredictors{More predictors?}
    MorePredictors -->|yes| EvalCandidates
    MorePredictors -->|no| LastDepth{Last depth?}

    LastDepth -->|yes| Finalize
    LastDepth -->|no| GenNext[Generate next batch via<br/>GenerateInstructionGivenAttempts<br/>using sorted attempts]
    GenNext --> DepthLoop

    Finalize[Collect all evaluated candidates] --> Sort[Sort by score descending]
    Sort --> Dedup[Drop duplicates]
    Dedup --> Return[Return best program<br/>+ candidate_programs, total_calls, stats]
    Return --> End([best_program])
```

### Detailed Steps

1. **Initialization** — The student is deep-copied so the original is untouched. An `Evaluate` instance is created with the training set and metric.

2. **Seed phase** — For each predictor, the current instruction is used as input to `BasicGenerateInstruction`, producing `breadth - 1` new candidates. The original instruction is appended as an additional candidate, yielding `breadth` total.

3. **Depth iterations** — For each of `depth` rounds:
   - Each predictor's candidates are evaluated by temporarily setting the candidate's instruction/prefix on a clone and scoring it.
   - For multi-predictor programs, *all* candidates are re-evaluated (since changing one predictor affects the others).
   - The best-scoring candidate is committed to the predictor before moving on.
   - If not the final round, `GenerateInstructionGivenAttempts` produces a fresh batch of candidates, conditioned on the sorted history of attempts and their scores.

4. **Finalization** — All evaluated candidates across predictors are collected, sorted by score, de-duplicated, and the top candidate's program is returned. The full candidate list is attached as `candidate_programs`.

### Statistics Tracking

When `track_stats=True`, the returned program carries:

- `results_best` — min/max/avg/stddev of the top-10 scores per predictor per depth.
- `results_latest` — min/max/avg/stddev of the newest batch's scores per predictor per depth.
- `total_calls` — total number of task-metric evaluations performed.

---

## Data Flow

```mermaid
graph LR
    subgraph Inputs
        TS[trainset: list of Example]
        MET[metric: Callable]
        PM[prompt_model: LM]
    end

    subgraph "COPRO.compile"
        SEED[Seed candidates]
        EVAL[Evaluate candidates]
        REFINE[Refine via attempts]
        SELECT[Select best]
    end

    subgraph Outputs
        BP[best_program: Module]
        CP[candidate_programs]
        STATS[results_best / results_latest / total_calls]
    end

    TS --> EVAL
    MET --> EVAL
    PM --> SEED
    PM --> REFINE
    SEED --> EVAL
    EVAL --> REFINE
    EVAL --> SELECT
    REFINE --> EVAL
    SELECT --> BP
    SELECT --> CP
    EVAL --> STATS
```

---

## Usage Example

```python
import dspy
from dspy.teleprompt import COPRO

teleprompter = COPRO(
    prompt_model=prompt_model,
    metric=metric,
    breadth=10,
    depth=3,
    init_temperature=1.4,
)

kwargs = dict(num_threads=8, display_progress=True, display_table=0)
compiled = teleprompter.compile(
    program.deepcopy(),
    trainset=trainset[:DEV_NUM],
    eval_kwargs=kwargs,
)

eval_score = evaluate(compiled, devset=evalset[:EVAL_NUM], **kwargs)
```

> **Note:** `prompt_model` defaults to the LM configured via `dspy.settings.configure(lm=...)` when unspecified. See [Settings](dsp_utils_settings.md) for configuration details.

---

## Dependencies

| Dependency | Role | Documentation |
| --- | --- | --- |
| `Teleprompter` | Base class defining the `compile` interface | [teleprompt_core](teleprompt_core.md) |
| `Evaluate` | Scores candidate programs on the training set | [evaluate](evaluate.md) |
| `Signature` | Holds instructions and field prefixes that are mutated | [signatures](signatures.md) |
| `Predict` | Invokes the prompt model to generate candidates | [predict_core](predict_core.md) |
| `Module` | The student program being optimized | [primitives](primitives.md) |
| `Example` | Training/evaluation data items | [primitives](primitives.md) |
| `Settings` | Provides the default LM and context management | [dsp_utils_settings](dsp_utils_settings.md) |

---

## Design Notes & Caveats

- **Coordinate ascent, not joint optimization** — Predictors are optimized one at a time. For multi-predictor programs, candidates are re-evaluated after each predictor update to account for interactions, which increases the number of metric calls.
- **Breadth must exceed 1** — The constructor raises `ValueError` if `breadth <= 1`.
- **Cost** — Total metric calls scale roughly with `depth × breadth × num_predictors` (and more for multi-predictor re-evaluation). Use `track_stats` to monitor `total_calls`.
- **Prompt model separation** — Using a distinct, often stronger `prompt_model` for generation while the task model executes the program is a common and recommended pattern.
- **Deprecation** — `SignatureOptimizer` is deprecated; migrate to `COPRO` with the `trainset` keyword argument.
