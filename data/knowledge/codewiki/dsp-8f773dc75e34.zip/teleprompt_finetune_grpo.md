# GRPO (Group Relative Policy Optimization)

## Overview

The `teleprompt_finetune_grpo` module provides the **`GRPO`** teleprompter, a DSPy optimizer that fine-tunes a student program's language model using **Group Relative Policy Optimization (GRPO)** — a reinforcement learning algorithm that improves a model by comparing multiple sampled completions ("rollouts") for the same input and reinforcing those that score higher relative to their group.

Unlike supervised fine-tuning approaches (see [teleprompt_finetune_bootstrap](teleprompt_finetune_bootstrap.md)), GRPO does not require ground-truth target completions. Instead, it relies on a **metric** to score sampled outputs and uses the relative ranking within a group of rollouts as the learning signal. This makes it well-suited for tasks where a reward signal is available but labeled demonstrations are not.

The module is part of the broader fine-tuning family of teleprompters and builds directly on the shared infrastructure in [teleprompt_finetune_bootstrap](teleprompt_finetune_bootstrap.md) (`FinetuneTeleprompter`, `bootstrap_trace_data`, `FailedPrediction`).

---

## Key Concepts

| Concept | Description |
| --- | --- |
| **Rollout** | A single sampled completion produced by the model for a given input. |
| **GRPO Group** | A set of `num_rollouts_per_grpo_step` rollouts for the same input, scored and compared relative to one another. |
| **Teacher** | A program used to generate rollouts. The student program itself is always one of the teachers. |
| **Student** | The program whose LM is being trained. Its LM is updated **in place** during training. |
| **Multitask** | When `True`, a single GRPO job trains all predictors of the student program jointly. |
| **Format reward** | A reward assigned to outputs that fail to parse into the expected DSPy format, interpolated between `format_failure_score` and `failure_score`. |

---

## Architecture

The `GRPO` class extends `FinetuneTeleprompter` and orchestrates a training loop that bootstraps trace data, builds GRPO groups, and drives a remote reinforcement-learning job through the LM's provider.

```mermaid
graph TD
    GRPO["GRPO<br/>(FinetuneTeleprompter)"]
    FT["FinetuneTeleprompter<br/>(bootstrap_finetune)"]
    TP["Teleprompter<br/>(teleprompt_core)"]

    GRPO --> FT --> TP

    GRPO -->|uses| BTD["bootstrap_trace_data"]
    GRPO -->|uses| FP["FailedPrediction"]
    GRPO -->|uses| APHL["all_predictors_have_lms"]
    GRPO -->|uses| ASE["assert_structural_equivalency"]

    GRPO -->|calls| LM["LM.reinforce()"]
    LM -->|creates| RJ["ReinforceJob"]
    RJ -->|implemented by| ARJ["ArborReinforceJob"]

    GRPO -->|evaluates with| EV["Evaluate"]
    GRPO -->|formats via| AD["ChatAdapter"]

    ARJ -->|HTTP| SRV["Arbor GRPO Server"]
```

### Component Relationships

```mermaid
graph LR
    subgraph "teleprompt_finetune"
        GRPO["GRPO"]
        BF["BootstrapFinetune"]
        BT["BetterTogether"]
    end

    subgraph "clients"
        LM["LM"]
        RJ["ReinforceJob"]
        ARJ["ArborReinforceJob"]
        UFT["utils_finetune<br/>GRPOChatData, TrainDataFormat"]
    end

    subgraph "evaluate"
        EV["Evaluate"]
    end

    GRPO -.shares infra.-> BF
    GRPO --> LM
    LM --> RJ
    RJ --> ARJ
    GRPO --> UFT
    GRPO --> EV
```

---

## The `GRPO` Class

### Constructor Parameters

| Parameter | Type | Default | Description |
| --- | --- | --- | --- |
| `metric` | `Callable \| None` | `None` | Scoring function `(example, prediction, trace) -> float`. Used to score rollouts. |
| `multitask` | `bool` | `True` | Train all predictors jointly in a single job. Only `True` is currently supported. |
| `train_kwargs` | `dict` | `None` | Training hyperparameters, either global or keyed by `LM`. |
| `adapter` | `Adapter \| dict[LM, Adapter]` | `None` | Adapter used to format training messages. Must resolve to a `ChatAdapter`. |
| `exclude_demos` | `bool` | `False` | Whether to exclude demos from training data. Only `True` is currently supported. |
| `num_threads` | `int` | `6` | Threads used for bootstrapping and evaluation. |
| `num_train_steps` | `int` | `100` | Number of GRPO training steps. |
| `seed` | `int` | `0` | Seed for the internal RNG (shuffling, fill strategy). |
| `num_dspy_examples_per_grpo_step` | `int` | `1` | Number of DSPy examples sampled per training step. |
| `num_rollouts_per_grpo_step` | `int` | `1` | Total rollouts per group (must be divisible by the number of teachers). |
| `use_train_as_val` | `bool` | `False` | Use the training set as the validation set. |
| `num_steps_for_val` | `int` | `5` | Frequency (in steps) of validation evaluation. |
| `report_train_scores` | `bool` | `False` | Report training scores alongside validation scores. |
| `failure_score` | `float` | `0` | Reward for a fully-formed but incorrect prediction. |
| `format_failure_score` | `float` | `-1` | Reward for a prediction that fails to parse. |
| `variably_invoked_predictor_grouping_mode` | `Literal["truncate", "fill", "ragged"]` | `"truncate"` | How to handle predictors invoked a variable number of times within an example. |
| `variably_invoked_predictor_fill_strategy` | `Literal["randint", "max"] \| None` | `None` | Fill strategy when grouping mode is `"fill"`. |

> **Constraint:** `failure_score` must be strictly greater than `format_failure_score`, since the range `[format_failure_score, failure_score]` is used to interpolate DSPy formatting rewards.

### Validation Rules

The constructor enforces several invariants:

- `exclude_demos` must be `True` (demos are not yet supported in training data).
- `multitask` must be `True` (independent per-predictor jobs are not yet supported).
- If `use_train_as_val` is `True`, then `report_train_scores` must also be `True`.
- If `variably_invoked_predictor_grouping_mode == "fill"`, then `variably_invoked_predictor_fill_strategy` must be set to `"randint"` or `"max"`.

---

## Training Workflow

The `compile()` method is the entry point. It validates inputs, prepares the student and teacher programs, then runs the GRPO training loop.

```mermaid
flowchart TD
    Start([compile student, trainset, teacher, valset]) --> Validate[Validate inputs &<br/>program structure]
    Validate --> PrepStudent[Prepare student program<br/>all_predictors_have_lms]
    PrepStudent --> PrepTeacher[Prepare teacher program(s)<br/>assert_structural_equivalency]
    PrepTeacher --> DisableCache[Disable LM cache<br/>for student & teachers]
    DisableCache --> SetKwargs[Set num_generations<br/>in train_kwargs]
    SetKwargs --> CreateJobs[Create GRPO training jobs<br/>lm.reinforce]
    CreateJobs --> PreVal[Report validation metrics<br/>step_idx = -1]
    PreVal --> Loop{For each<br/>train_step}

    Loop --> Sample[Select training sample &<br/>update shuffled trainset]
    Sample --> Bootstrap[Bootstrap trace data<br/>per teacher]
    Bootstrap --> ValidateTrace[Validate trace data]
    ValidateTrace --> BuildBatch[Build GRPO groups<br/>per predictor]
    BuildBatch --> Grouping[Apply grouping mode<br/>truncate/fill/ragged]
    Grouping --> Format[Format messages via<br/>ChatAdapter]
    Format --> Step[job.step<br/>GRPO_CHAT]
    Step --> Val[Report validation metrics]
    Val --> Loop

    Loop -->|done| Terminate[Terminate jobs]
    Terminate --> RecoverCache[Recover LM cache]
    RecoverCache --> Done([Return compiled student])
```

### Step-by-Step Breakdown

1. **Input validation** — Ensures the trainset is non-empty, the student has exactly one LM, and the teacher list contains the student. If the trainset is smaller than `num_dspy_examples_per_grpo_step`, it is repeated to fill the step (with a warning about overfitting).

2. **Program preparation** — Verifies all predictors have LMs and that teachers are structurally equivalent to the student (same number and names of predictors).

3. **Cache disabling** — LM caching is disabled for all programs during training to ensure diverse rollouts, then restored afterward via `disable_lm_cache` / `recover_lm_cache`.

4. **Job creation** — For each unique `(LM, data_key)` pair, a `ReinforceJob` is created via `lm.reinforce(train_kwargs)`. The `num_generations` kwarg is set to `num_rollouts_per_grpo_step`.

5. **Training loop** — For each step:
   - A subsample of the training set is selected from a shuffled, epoch-aware index list.
   - `bootstrap_trace_data` collects rollouts from each teacher.
   - Trace data is validated and grouped per predictor.
   - GRPO groups are built and formatted into chat messages.
   - `job.step(train_data, TrainDataFormat.GRPO_CHAT)` runs the remote GRPO update.

6. **Cleanup** — Jobs are terminated and LM caches restored.

---

## Data Flow

The core data transformation pipeline converts raw rollouts into GRPO training groups.

```mermaid
flowchart LR
    TS["Trainset<br/>list[Example]"] --> Sub["Subsample<br/>num_dspy_examples_per_grpo_step"]
    Sub --> BTD["bootstrap_trace_data<br/>(per teacher)"]
    BTD --> Trace["trace_data<br/>[example][teacher][sample]<br/>{example, prediction, trace, score}"]
    Trace --> Group["Group per predictor<br/>filter by signature hash"]
    Group --> Mode["Grouping mode<br/>truncate / fill / ragged"]
    Mode --> Fmt["ChatAdapter.format_finetune_data"]
    Fmt --> GRPOGroup["GRPOGroup<br/>list[GRPOChatData]"]
    GRPOGroup --> Step["job.step<br/>GRPO_CHAT"]
```

### Trace Data Shape

```
trace_data: list[example_idx -> list[teacher_idx -> [num_samples_per_input * Dict]]]
```

Each `Dict` contains:
- `example` — the input `Example`
- `prediction` — the module-level `Prediction`
- `trace` — list of `(Predictor, PredictorInputs, Prediction)` tuples
- `example_ind` — index into the subsample
- `score` — metric score

### GRPO Group Construction

For each predictor, invocations are collected across all teachers and rollouts. Because a predictor may be invoked a variable number of times within a single example, the module applies a **grouping mode**:

| Mode | Behavior |
| --- | --- |
| `truncate` | Truncate all invocations to the minimum length. |
| `fill` | Pad shorter invocations to the maximum length using `randint` (random choice) or `max` (last element). |
| `ragged` | Leave invocations at their natural lengths (no padding/truncation). |

Each resulting group is a `GRPOGroup` — a list of `GRPOChatData` dicts:

```python
{
    "messages": [...],          # formatted input messages
    "completion": {             # the sampled assistant response
        "role": "assistant",
        "content": "...",
    },
    "reward": float,            # metric score or format reward
}
```

---

## Format Failure Handling

When a model produces output that does not conform to the DSPy response format, `bootstrap_trace_data` captures a `FailedPrediction` instead of raising. The `GRPO` module then assigns a **format reward** interpolated between `format_failure_score` and `failure_score`:

```mermaid
flowchart TD
    Resp[Model response] --> Parse{Parseable?}
    Parse -->|Yes| Score[Use metric score]
    Parse -->|No| FP[FailedPrediction]
    FP --> Interp["format_reward =<br/>format_failure_score +<br/>(failure_score - format_failure_score) *<br/>(present / expected)"]
    Interp --> Group[Add to GRPO group]
    Score --> Group
```

This graceful degradation allows training to continue even when some rollouts are malformed, while still penalizing them relative to well-formed outputs.

---

## Validation & Reporting

`report_validation_metrics` is invoked before training (`step_idx = -1`) and at intervals defined by `num_steps_for_val`. It supports three configurations:

| Configuration | Condition | Behavior |
| --- | --- | --- |
| **User-provided valset** | `valset is not None` | Evaluates on `valset` (and optionally `trainset` if `report_train_scores`). |
| **Train-as-val** | `valset is None`, `report_train_scores=True` | Evaluates on the training set. |
| **No validation** | `valset is None`, `report_train_scores=False` | Skips evaluation. |

Evaluation uses the [Evaluate](evaluate_evaluation_engine.md) engine with `failure_score` as the fallback for failed predictions.

---

## Integration with Providers

GRPO training is executed remotely through a provider's `ReinforceJob`. The primary implementation is `ArborReinforceJob` in the [clients_providers_arbor](clients_providers_arbor.md) module.

```mermaid
sequenceDiagram
    participant GRPO
    participant LM
    participant Job as ArborReinforceJob
    participant Server as Arbor GRPO Server

    GRPO->>LM: reinforce(train_kwargs)
    LM->>Job: ArborReinforceJob(lm, train_kwargs)
    Job->>Server: POST /fine_tuning/grpo/initialize
    Server-->>Job: current_model, job_id
    loop Each training step
        GRPO->>Job: step(train_data, GRPO_CHAT)
        Job->>Server: POST /fine_tuning/grpo/step
        Server-->>Job: current_model
        Job->>LM: update lm.model
    end
    GRPO->>Job: terminate()
    Job->>Server: POST /fine_tuning/grpo/terminate
    Server-->>Job: current_model
```

### In-Place LM Updates

A key design characteristic: the `ReinforceJob` holds a reference to the **same `LM` object** attached to the student program. When the job updates `lm.model` after each step, the student program's LM is updated in place. This is noted in the code as inconsistent with `BootstrapFinetune`, which creates new LM instances post-training.

### Default Training Hyperparameters

`ArborReinforceJob.DEFAULT_TRAIN_KWARGS` provides sensible defaults, including `temperature=0.9`, `beta=0.04`, `learning_rate=1e-6`, and `scale_rewards=True`. See [clients_providers_arbor](clients_providers_arbor.md) for the full list.

---

## Dependencies

```mermaid
graph TD
    GRPO["GRPO"]

    GRPO -->|inherits| FT["FinetuneTeleprompter<br/>teleprompt_finetune_bootstrap"]
    GRPO -->|uses| BTD["bootstrap_trace_data<br/>teleprompt_finetune_bootstrap"]
    GRPO -->|uses| FP["FailedPrediction<br/>teleprompt_finetune_bootstrap"]
    GRPO -->|uses| EV["Evaluate<br/>evaluate_evaluation_engine"]
    GRPO -->|uses| CA["ChatAdapter<br/>adapters_implementations"]
    GRPO -->|uses| LM["LM<br/>clients_core_lm"]
    GRPO -->|uses| UFT["GRPOChatData, TrainDataFormat<br/>clients_finetune_utils"]
    GRPO -->|uses| EX["Example<br/>primitives_example"]
    GRPO -->|uses| MOD["Module<br/>primitives_module"]
    GRPO -->|uses| SET["settings<br/>dsp_utils_settings"]
```

### Related Modules

- [teleprompt_finetune_bootstrap](teleprompt_finetune_bootstrap.md) — Shared fine-tuning infrastructure (`FinetuneTeleprompter`, `bootstrap_trace_data`, `FailedPrediction`).
- [teleprompt_finetune_bettertogether](teleprompt_finetune_bettertogether.md) — Combines optimization strategies including fine-tuning.
- [clients_providers_arbor](clients_providers_arbor.md) — The `ArborProvider` and `ArborReinforceJob` that execute GRPO steps.
- [clients_core_lm](clients_core_lm.md) — The `LM` class and its `reinforce()` method.
- [clients_finetune_utils](clients_finetune_utils.md) — Data format types (`GRPOChatData`, `TrainDataFormat`).
- [evaluate_evaluation_engine](evaluate_evaluation_engine.md) — The `Evaluate` engine used for scoring.
- [adapters_implementations](adapters_implementations.md) — `ChatAdapter` used for message formatting.
- [teleprompt_core_base](teleprompt_core_base.md) — The base `Teleprompter` class.

---

## Usage Example

```python
import dspy
from dspy.teleprompt import GRPO

# Configure the student LM (must be a single, reinforceable LM)
lm = dspy.LM("openai/arbor:Qwen/Qwen2.5-0.5B-Instruct", api_base="http://localhost:8000/v1/")
dspy.configure(lm=lm)

# Define a metric that scores predictions
def metric(example, prediction, trace=None):
    return float(prediction.answer == example.answer)

# Create the GRPO optimizer
optimizer = GRPO(
    metric=metric,
    num_train_steps=100,
    num_dspy_examples_per_grpo_step=4,
    num_rollouts_per_grpo_step=8,
    exclude_demos=True,
    multitask=True,
    train_kwargs={"temperature": 0.9, "learning_rate": 1e-6},
)

# Compile the student program (LM is updated in place)
compiled_student = optimizer.compile(
    student=my_program,
    trainset=trainset,
    valset=valset,
)
```

---

## Limitations & Notes

- **Single LM per student** — The student program must use exactly one LM across all predictors.
- **`multitask=True` only** — Independent per-predictor training jobs are not yet supported.
- **`exclude_demos=True` only** — Demos are not yet included in training data.
- **In-place LM updates** — Unlike `BootstrapFinetune`, GRPO mutates the student's LM object directly. This is flagged as a design inconsistency to be standardized.
- **Format failures** — Rollouts that fail to parse are handled via `FailedPrediction` and assigned interpolated format rewards rather than aborting training.
- **Group diversity** — Groups with no diversity (all identical completions) trigger warnings, often caused by low temperature or inadvertently enabled caching.
- **No checkpointing/resumption** — Continuing a GRPO run after a process failure is not yet supported.
