# datasets_alfworld

## Introduction

The `datasets_alfworld` module provides integration between DSPy and the [ALFWorld](https://alfworld.github.io/) benchmark — a text-based interactive environment suite for embodied agents. It exposes the `AlfWorld` dataset class, which wraps a pool of isolated ALFWorld environment processes and produces DSPy-compatible train/dev splits of task indices.

Unlike static datasets (e.g., [GSM8K](datasets_builtin.md), [HotPotQA](datasets_builtin.md)), ALFWorld is an **interactive** dataset: each example is a task index that must be *initialized* and *stepped* through inside a live environment. This module therefore combines two responsibilities:

1. **Environment management** — spawning, pooling, and safely reusing ALFWorld environment processes (`EnvPool`, `_EnvSession`, `env_worker`).
2. **Dataset construction** — building shuffled train/dev splits of task indices as `dspy.Example` objects (`AlfWorld`).

> **Prerequisites:** ALFWorld must be installed (`pip install alfworld==0.3.5` followed by `alfworld-download`), and the `multiprocess` package must be available.

---

## Architecture Overview

The module is organized around a **process-pool pattern**. Because ALFWorld environments are heavyweight, stateful, and not thread-safe, each environment runs in its own spawned process. A queue-based pool manages a fixed number of these workers, and a context-manager session provides safe acquire/release semantics.

```mermaid
graph TD
    subgraph "datasets_alfworld module"
        AlfWorld["AlfWorld<br/>(dataset facade)"]
        EnvPool["EnvPool<br/>(process pool)"]
        EnvSession["_EnvSession<br/>(context manager)"]
        Worker["env_worker<br/>(per-process loop)"]
    end

    subgraph "External"
        ALF["alfworld.agents.environment<br/>AlfredTWEnv"]
        MP["multiprocess<br/>(spawn context)"]
        DSPy["dspy.Example"]
    end

    AlfWorld -->|creates| EnvPool
    AlfWorld -->|builds splits of| DSPy
    EnvPool -->|spawns N| Worker
    EnvPool -->|returns| EnvSession
    EnvSession -->|init / step via queues| Worker
    Worker -->|instantiates| ALF
    EnvPool -->|uses| MP
```

### Component Responsibilities

| Component | Role |
|-----------|------|
| `AlfWorld` | Public dataset facade. Creates the pool, builds shuffled train/dev splits of task indices, and cleans up on destruction. |
| `EnvPool` | Manages a fixed-size pool of spawned worker processes, each owning one ALFWorld environment. Provides `session()` for safe access. |
| `_EnvSession` | Context manager that acquires a worker from the pool, exposes `.init(idx)` and `.step(action)`, and releases the worker on exit. |
| `env_worker` | The per-process entry point. Loads ALFWorld config, creates an `AlfredTWEnv`, and serves `init` / `step` / `close` commands over queues. |

---

## Component Interaction & Data Flow

The following sequence diagram shows the lifecycle of a single task interaction, from dataset creation through environment stepping.

```mermaid
sequenceDiagram
    participant User
    participant AlfWorld
    participant EnvPool
    participant Session as _EnvSession
    participant Worker as env_worker (process)
    participant Env as AlfredTWEnv

    User->>AlfWorld: AlfWorld(max_threads=20)
    AlfWorld->>EnvPool: EnvPool(size=20)
    EnvPool->>Worker: spawn N processes (spawn ctx)
    Worker->>Env: AlfredTWEnv(config, train_eval="train")
    AlfWorld->>AlfWorld: build trainset / devset (dspy.Example)

    User->>EnvPool: pool.session()
    EnvPool-->>Session: _EnvSession
    User->>Session: __enter__() → _acquire()
    User->>Session: init(idx)
    Session->>Worker: inq.put(("init", idx))
    Worker->>Env: init_env(batch_size=1); skip(idx); reset()
    Env-->>Worker: task_def, info
    Worker-->>Session: outq.get() → (task_def, info)
    Session-->>User: (task_def, info)

    User->>Session: step(action)
    Session->>Worker: inq.put(("step", action))
    Worker->>Env: env.step([action])
    Env-->>Worker: obs, rew, done, info
    Worker-->>Session: outq.get()
    Session-->>User: (obs, rew, done, info)

    User->>Session: __exit__() → _release()
```

### Data Flow Summary

```mermaid
flowchart LR
    A["Task index (int)"] -->|init| B["env_worker"]
    B -->|reset| C["(task_def, info)"]
    D["Action (str)"] -->|step| B
    B -->|step| E["(obs, rew, done, info)"]
    F["range(3500)"] -->|shuffle seed 0| G["trainset[:3000]<br/>devset[-500:]"]
    G -->|dspy.Example(idx=...)| H["DSPy Examples"]
```

---

## Core Components

### `AlfWorld`

The public dataset class. On construction it:

1. Creates an `EnvPool` sized by `max_threads` (default `20`).
2. Builds a list of `3500` `dspy.Example` objects, each carrying only an `idx` field, marked as an input via `.with_inputs("idx")`.
3. Shuffles the list deterministically with `random.Random(0)`.
4. Splits into `trainset` (first `3000`) and `devset` (last `500`).

```python
class AlfWorld:
    def __init__(self, max_threads=20):
        self.POOL = EnvPool(size=max_threads)
        import dspy
        dataset = [dspy.Example(idx=idx).with_inputs("idx") for idx in range(3500)]
        random.Random(0).shuffle(dataset)
        trainset, devset = dataset[:3000], dataset[-500:]
        self.trainset = trainset
        self.devset = devset

    def __del__(self):
        self.POOL.close_all()
```

**Key attributes:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `POOL` | `EnvPool` | The underlying pool of ALFWorld environment processes. |
| `trainset` | `list[dspy.Example]` | 3000 shuffled task indices for training. |
| `devset` | `list[dspy.Example]` | 500 shuffled task indices for evaluation. |

**Notes:**
- The deterministic shuffle (`Random(0)`) ensures reproducible splits across runs.
- `__del__` calls `POOL.close_all()` to gracefully terminate all worker processes.
- Each `dspy.Example` uses `idx` as its sole input key, so downstream programs (e.g., a [ReAct](predict_advanced.md) agent) receive the task index and interact with the environment via the pool.

### `EnvPool`

A fixed-size pool of spawned worker processes. Each worker owns exactly one ALFWorld environment instance.

```python
class EnvPool:
    def __init__(self, size=2): ...
    def _acquire(self): ...
    def _release(self, wid): ...
    def close_all(self): ...
    def session(self): ...
```

**Construction details:**
- Requires the `multiprocess` package; raises `ImportError` with install guidance if missing.
- Forces the `spawn` start method (`mp.set_start_method("spawn", force=True)`) — essential because ALFWorld environments cannot be safely forked.
- For each of `size` workers, creates an input queue (`inq`), an output queue (`outq`), and a daemon `Process` running `env_worker`.
- Tracks available worker IDs in a `queue.Queue` (`self.available`).

**Methods:**

| Method | Description |
|--------|-------------|
| `_acquire()` | Blocks until a worker is available; returns `(wid, inq, outq)`. |
| `_release(wid)` | Returns a worker ID to the available queue. |
| `close_all()` | Sends `("close", None)` to every worker, waits for `"CLOSED"`, closes queues, and joins processes. |
| `session()` | Returns a new `_EnvSession` context manager bound to this pool. |

### `_EnvSession`

A context manager providing safe, scoped access to a single pooled worker.

```python
class _EnvSession:
    def __enter__(self): ...        # acquires a worker
    def __exit__(self, *args): ...  # releases the worker
    def init(self, idx): ...        # returns (task_def, info)
    def step(self, action): ...     # returns (obs, rew, done, info)
```

**Usage pattern:**

```python
with pool.session() as sess:
    task_def, info = sess.init(5)          # initialize task index 5
    obs, rew, done, info = sess.step("go north")
    while not done:
        obs, rew, done, info = sess.step(next_action)
```

The context manager guarantees the worker is released back to the pool even if an exception occurs during interaction.

### `env_worker`

The per-process entry point. It runs an infinite command loop, reading `(cmd, data)` tuples from `inq` and writing results to `outq`.

```python
def env_worker(inq, outq):
    ...
```

**Behavior:**
- Lazily imports `alfworld.agents.environment` and `yaml`; raises a descriptive `ImportError` if ALFWorld is not installed.
- Loads `base_config.yml` (located alongside the module) and constructs `AlfredTWEnv(config, train_eval="train")`.
- Suppresses ALFWorld's stdout/stderr during setup via `redirect_stdout`/`redirect_stderr` into a buffer.

**Supported commands:**

| Command | Data | Response |
|---------|------|----------|
| `"init"` | task index | `(task_def[0], info)` after `init_env(batch_size=1)`, `skip(idx)`, `reset()` |
| `"step"` | action string | `(obs, rew, done, info)` from `env.step([action])` |
| `"close"` | `None` | `"CLOSED"` then loop breaks |
| *(unknown)* | — | `"UNKNOWN_CMD"` |

---

## Process Lifecycle

```mermaid
stateDiagram-v2
    [*] --> Spawned: EnvPool.__init__
    Spawned --> Idle: env_worker loads AlfredTWEnv
    Idle --> Initialized: "init" command
    Initialized --> Stepping: "step" command
    Stepping --> Stepping: "step" command
    Stepping --> Idle: session released
    Initialized --> Idle: session released
    Idle --> Closed: "close" command
    Closed --> [*]: proc.join()
```

---

## Relationship to Other Modules

- **[datasets_core](datasets_core.md)** — `AlfWorld` produces `dspy.Example` objects, the same primitive used by `Dataset` and `DataLoader`. Unlike those classes, `AlfWorld` does not subclass `Dataset`; it manages its own splits directly.
- **[primitives](primitives.md)** — `dspy.Example` (from `dspy/primitives/example.py`) is the container for each task index, with `idx` registered as an input key.
- **[predict_advanced](predict_advanced.md)** — Interactive agents such as `ReAct` are the natural consumers of `AlfWorld` examples, using the pool to step through environments.
- **[evaluate](evaluate.md)** — Evaluation metrics can score agent trajectories produced against ALFWorld tasks.

---

## Configuration

The worker loads `base_config.yml` from the module directory (`dspy/datasets/alfworld/base_config.yml`). This file configures the underlying `AlfredTWEnv` (task types, data paths, etc.). It is required for the worker to start; if missing or malformed, environment initialization will fail.

---

## Summary

The `datasets_alfworld` module bridges DSPy and the ALFWorld interactive benchmark by:

1. **Isolating environments** in spawned processes to avoid state leakage and thread-safety issues.
2. **Pooling** those processes for efficient reuse across many tasks.
3. **Exposing** a simple `AlfWorld` dataset facade with deterministic train/dev splits of task indices.

Developers integrating ALFWorld should create an `AlfWorld` instance, iterate over `trainset`/`devset`, and use `POOL.session()` to initialize and step through each task index within their agent programs.
