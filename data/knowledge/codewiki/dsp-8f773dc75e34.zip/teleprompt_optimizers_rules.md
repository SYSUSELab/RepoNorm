# Teleprompt Optimizers: Rules Induction (`teleprompt_optimizers_rules`)

## Introduction

The `teleprompt_optimizers_rules` module implements **`InferRules`**, a DSPy teleprompter (optimizer) that improves a program by *inducing natural-language rules* from training examples and injecting those rules into each predictor's signature instructions.

Unlike optimizers that select demonstrations (e.g., [`BootstrapFewShot`](teleprompt_core_bootstrap.md)) or search over instruction candidates (e.g., [`COPRO`](teleprompt_optimizers_instruction.md)), `InferRules` focuses on **rule-based instruction augmentation**: it asks a teacher language model to extract concise, actionable rules from example inputs/outputs, then appends those rules to the existing instructions of every predictor in the program.

The module contains two core components:

| Component | Role |
|-----------|------|
| `InferRules` | The teleprompter. Orchestrates candidate generation, rule induction, instruction updating, and evaluation. |
| `RulesInductionProgram` | A small `dspy.Module` wrapping a `ChainOfThought` that performs the actual rule extraction from formatted examples. |

---

## Architecture Overview

`InferRules` subclasses [`BootstrapFewShot`](teleprompt_core_bootstrap.md), which in turn subclasses the abstract [`Teleprompter`](teleprompt_core_base.md). It reuses the bootstrap machinery to seed the student program with demonstrations, then layers rule induction on top.

```mermaid
graph TD
    Teleprompter["Teleprompter (abstract)"]
    BootstrapFewShot["BootstrapFewShot"]
    InferRules["InferRules"]
    RulesInductionProgram["RulesInductionProgram (dspy.Module)"]
    ChainOfThought["ChainOfThought"]
    Evaluate["Evaluate"]
    Signature["CustomRulesInduction (dspy.Signature)"]

    Teleprompter --> BootstrapFewShot
    BootstrapFewShot --> InferRules
    InferRules --> RulesInductionProgram
    RulesInductionProgram --> ChainOfThought
    ChainOfThought --> Signature
    InferRules --> Evaluate
```

### Component Responsibilities

- **`InferRules`** — Owns the optimization loop. It bootstraps demos, then for each of `num_candidates` candidates it induces rules per predictor, updates instructions, and evaluates the candidate against a validation set, keeping the best-scoring program.
- **`RulesInductionProgram`** — Encapsulates the LLM call that turns formatted examples into a list of natural-language rules. It defines a dynamic `CustomRulesInduction` signature whose docstring encodes the requested number of rules.

---

## Component Details

### `InferRules`

```python
class InferRules(BootstrapFewShot):
    def __init__(self, num_candidates=10, num_rules=10, num_threads=None,
                 teacher_settings=None, **kwargs):
        ...
```

**Constructor parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `num_candidates` | `10` | Number of candidate programs to generate and evaluate. |
| `num_rules` | `10` | Number of natural-language rules to induce per predictor. |
| `num_threads` | `None` | Thread count passed to `Evaluate` for parallel evaluation. |
| `teacher_settings` | `None` | Settings for the teacher LM (forwarded to `BootstrapFewShot` and `RulesInductionProgram`). |
| `**kwargs` | — | Forwarded to `BootstrapFewShot`; `metric` and `max_errors` are also captured explicitly. |

**Key methods:**

- **`compile(student, *, teacher=None, trainset, valset=None)`** — The main entry point.
  1. If `valset` is `None`, splits `trainset` 50/50 into train/validation.
  2. Calls `super().compile(...)` to bootstrap the student with demonstrations.
  3. Deep-copies the bootstrapped program and snapshots the original instructions of every predictor.
  4. For each candidate: resets instructions, induces rules per predictor, appends rules to instructions, and evaluates on `valset`.
  5. Returns the best-scoring candidate program.

- **`induce_natural_language_rules(predictor, trainset)`** — Formats demos and calls `RulesInductionProgram`. On context-window errors, it progressively drops the last demo until the call succeeds; if a single example still fails, it raises `RuntimeError`.

- **`update_program_instructions(predictor, natural_language_rules)`** — Appends the induced rules to the predictor's signature instructions under a "Please adhere to the following rules..." header.

- **`format_examples(demos, signature)`** — Renders demos into a text block separating input fields from output fields.

- **`get_predictor_demos(trainset, predictor)`** — Filters each example to only the keys present in the predictor's signature input/output fields.

- **`evaluate_program(program, dataset)`** — Wraps [`Evaluate`](evaluate_evaluation_engine.md) to score a program on a dataset, resolving `max_errors` from the instance or `dspy.settings`.

### `RulesInductionProgram`

```python
class RulesInductionProgram(dspy.Module):
    def __init__(self, num_rules, teacher_settings=None):
        ...
```

- Defines a dynamic `CustomRulesInduction` signature whose docstring requests `num_rules` concise, non-redundant, actionable rules.
- Uses [`ChainOfThought`](predict_core_chain_of_thought.md) to reason before producing the `natural_language_rules` output field.
- `forward(examples_text)` runs the induction under the teacher settings context, copying the LM with a randomized temperature in `[0.9, 1.0)` (seeded RNG for reproducibility) to encourage diverse rule sets, and returns the stripped rules string.

---

## Data Flow

The following diagram shows how data moves through a single candidate iteration.

```mermaid
flowchart TD
    Trainset["trainset (Examples)"] --> Bootstrap["BootstrapFewShot.compile"]
    Bootstrap --> Bootstrapped["Bootstrapped student program"]
    Bootstrapped --> Snapshot["Snapshot original instructions"]
    Snapshot --> Loop{"For each candidate"}

    Loop --> Reset["Reset predictor instructions"]
    Reset --> Demos["get_predictor_demos + format_examples"]
    Demos --> Induce["RulesInductionProgram.forward"]
    Induce --> Rules["natural_language_rules"]
    Rules --> Update["update_program_instructions"]
    Update --> Eval["evaluate_program on valset"]
    Eval --> Compare{"score > best_score?"}
    Compare -->|Yes| Keep["Store as best_program"]
    Compare -->|No| Loop
    Keep --> Loop
    Loop -->|Done| Return["Return best_program"]
```

---

## Process Flow: `compile`

```mermaid
sequenceDiagram
    participant User
    participant InferRules
    participant BootstrapFewShot
    participant RulesInductionProgram
    participant Evaluate

    User->>InferRules: compile(student, trainset, valset)
    alt valset is None
        InferRules->>InferRules: split trainset 50/50
    end
    InferRules->>BootstrapFewShot: super().compile(student, trainset)
    BootstrapFewShot-->>InferRules: bootstrapped student
    InferRules->>InferRules: deepcopy + snapshot instructions
    loop num_candidates
        loop each predictor
            InferRules->>RulesInductionProgram: forward(examples_text)
            RulesInductionProgram-->>InferRules: natural_language_rules
            InferRules->>InferRules: update_program_instructions
        end
        InferRules->>Evaluate: evaluate_program(candidate, valset)
        Evaluate-->>InferRules: score
        InferRules->>InferRules: track best_program
    end
    InferRules-->>User: best_program
```

---

## Dependencies

```mermaid
graph LR
    InferRules --> BootstrapFewShot["BootstrapFewShot (teleprompt_core_bootstrap)"]
    InferRules --> Evaluate["Evaluate (evaluate_evaluation_engine)"]
    InferRules --> RulesInductionProgram
    RulesInductionProgram --> ChainOfThought["ChainOfThought (predict_core_chain_of_thought)"]
    RulesInductionProgram --> Signature["dspy.Signature (signatures_signature)"]
    RulesInductionProgram --> Settings["dspy.settings (dsp_utils_settings)"]
    InferRules --> Module["dspy.Module (primitives_module)"]
```

### Internal Dependencies

| Dependency | Purpose |
|------------|---------|
| [`BootstrapFewShot`](teleprompt_core_bootstrap.md) | Base class; provides demo bootstrapping and student/teacher preparation. |
| [`Teleprompter`](teleprompt_core_base.md) | Abstract base defining the `compile` contract. |
| [`Evaluate`](evaluate_evaluation_engine.md) | Scores candidate programs on the validation set. |
| [`ChainOfThought`](predict_core_chain_of_thought.md) | Reasoning module used inside `RulesInductionProgram`. |
| [`Signature`](signatures_signature.md) | Defines the dynamic `CustomRulesInduction` signature. |
| [`Settings`](dsp_utils_settings.md) | Context management for teacher LM settings and temperature overrides. |
| [`Module`](primitives_module.md) | Base class for `RulesInductionProgram`. |

### External Dependencies

- `numpy` — used for `-np.inf` initialization of `best_score`.
- `random` — seeded RNG for reproducible temperature sampling.
- `logging` — structured logging of candidate scores.

---

## Relationship to Other Optimizers

`InferRules` belongs to the `teleprompt_optimizers` family. It is complementary to:

- **[Instruction optimizers](teleprompt_optimizers_instruction.md)** (`COPRO`, `SignatureOptimizer`) — search over instruction *candidates* rather than inducing rules.
- **[Bayesian optimizers](teleprompt_optimizers_bayesian.md)** (`MIPROv2`, `BootstrapFewShotWithOptuna`) — use Bayesian search over instructions and demos.
- **[SIMBA](teleprompt_optimizers_simba.md)** — self-improving optimizer using feedback.
- **[Core teleprompters](teleprompt_core.md)** — `BootstrapFewShot`, `LabeledFewShot`, `Ensemble`, etc.

Where `BootstrapFewShot` augments prompts with *demonstrations*, `InferRules` augments prompts with *explicit natural-language rules* distilled from those demonstrations.

---

## Usage Example

```python
import dspy
from dspy.teleprompt.infer_rules import InferRules

# Define a metric
def metric(example, prediction, trace=None):
    return example.answer.lower() == prediction.answer.lower()

# Configure the optimizer
optimizer = InferRules(
    num_candidates=10,
    num_rules=10,
    num_threads=8,
    metric=metric,
)

# Compile the student program
optimized_program = optimizer.compile(
    student=my_program,
    trainset=trainset,
    valset=valset,
)
```

---

## Notes and Caveats

- **Context window handling**: `induce_natural_language_rules` retries with fewer demos when the model's context window is exceeded. If even a single example cannot fit, a `RuntimeError` is raised.
- **Instruction reset per candidate**: Each candidate starts from the *original* instructions (snapshotted before the loop), so rules from one candidate do not leak into another.
- **Reproducibility**: `RulesInductionProgram` uses `random.Random(0)` for temperature sampling, making rule induction deterministic given identical inputs.
- **Error tolerance**: `max_errors` is resolved from the instance or `dspy.settings.max_errors` and passed to `Evaluate`.
