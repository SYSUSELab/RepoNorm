# Teleprompt Core Ensemble

## Introduction

The `teleprompt_core_ensemble` module provides the **`Ensemble`** teleprompter, a DSPy optimizer that combines the outputs of multiple programs into a single aggregated prediction. Rather than tuning a single program, `Ensemble` runs several candidate programs on the same input and merges their outputs using a user-supplied reduction function (commonly `dspy.majority`).

This module is one of the core teleprompters in the `teleprompt_core` family. For the base class contract and the other core optimizers, see [teleprompt_core_base](teleprompt_core_base.md), [teleprompt_core_bootstrap](teleprompt_core_bootstrap.md), [teleprompt_core_random_search](teleprompt_core_random_search.md), [teleprompt_core_labeled_fewshot](teleprompt_core_labeled_fewshot.md), and [teleprompt_core_knn_fewshot](teleprompt_core_knn_fewshot.md).

---

## Purpose and Core Functionality

The `Ensemble` teleprompter addresses a simple but powerful idea: **combining multiple programs often yields more robust predictions than any single program**. It is typically used to:

- Aggregate the outputs of several independently compiled programs (e.g., multiple `BootstrapFewShot` runs).
- Apply a voting/consensus strategy (e.g., majority vote) across program outputs.
- Optionally sample a random subset of programs per invocation to introduce diversity or reduce cost.

### Key Characteristics

| Feature | Description |
| --- | --- |
| **Aggregation** | Merges outputs from multiple programs via a `reduce_fn`. |
| **Sampling** | Optionally samples `size` programs per call using `random.sample`. |
| **Determinism** | A `deterministic` flag exists but is currently unimplemented (asserts `False`). |
| **Composition** | Returns a `dspy.Module` (`EnsembledProgram`) that can be used like any other program. |

---

## Architecture

The module is intentionally small. It consists of a single class, `Ensemble`, which subclasses `Teleprompter` and produces a dynamically-defined `EnsembledProgram` module at compile time.

```mermaid
classDiagram
    class Teleprompter {
        +compile(student, trainset, teacher, valset, **kwargs) Module
        +get_params() dict
    }
    class Ensemble {
        +reduce_fn
        +size
        +deterministic
        +__init__(reduce_fn, size, deterministic)
        +compile(programs) Module
    }
    class Module {
        +forward(*args, **kwargs)
        +__call__(*args, **kwargs)
    }
    class EnsembledProgram {
        +programs
        +forward(*args, **kwargs)
    }

    Teleprompter <|-- Ensemble
    Module <|-- EnsembledProgram
    Ensemble ..> EnsembledProgram : creates
```

### Component Relationships

- **`Ensemble`** inherits from **`Teleprompter`** ([teleprompt_core_base](teleprompt_core_base.md)), which defines the optimizer interface.
- **`Ensemble.compile`** returns an instance of **`EnsembledProgram`**, a subclass of **`Module`** ([primitives_module](primitives_module.md)).
- The `reduce_fn` typically operates on a list of **`Prediction`** objects ([primitives_prediction](primitives_prediction.md)).

---

## Component Reference

### `Ensemble`

```python
class Ensemble(Teleprompter):
    def __init__(self, *, reduce_fn=None, size=None, deterministic=False):
        ...
```

#### Constructor Parameters

| Parameter | Type | Default | Description |
| --- | --- | --- | --- |
| `reduce_fn` | `Callable[[list], Any]` | `None` | Function that reduces a list of program outputs into a single output. A common choice is `dspy.majority`. If `None`, the raw list of outputs is returned. |
| `size` | `int` | `None` | Number of programs to randomly sample per invocation. If `None`, all programs are used. |
| `deterministic` | `bool` | `False` | Reserved for future deterministic ensembling. Currently asserts `False`; passing `True` raises an `AssertionError`. |

> **Note:** The `deterministic` flag is a placeholder. The assertion `assert deterministic is False` enforces that only non-deterministic ensembling is supported today.

#### `compile(programs)`

```python
def compile(self, programs):
    ...
```

Unlike the standard `Teleprompter.compile` signature (which takes a `student`, `trainset`, etc.), `Ensemble.compile` takes a **list of already-compiled programs** and returns a new `EnsembledProgram` module.

| Parameter | Type | Description |
| --- | --- | --- |
| `programs` | `list[Module]` | The list of programs to ensemble. |

**Returns:** An `EnsembledProgram` instance (a `dspy.Module`).

---

### `EnsembledProgram` (dynamically defined)

`EnsembledProgram` is defined inside `compile` and captures `programs`, `size`, and `reduce_fn` from the enclosing scope.

```python
class EnsembledProgram(dspy.Module):
    def __init__(self):
        super().__init__()
        self.programs = programs

    def forward(self, *args, **kwargs):
        programs = random.sample(self.programs, size) if size else self.programs
        outputs = [prog(*args, **kwargs) for prog in programs]

        if reduce_fn:
            return reduce_fn(outputs)

        return outputs
```

#### `forward(*args, **kwargs)`

1. **Select programs** — If `size` is set, randomly sample `size` programs via `random.sample`; otherwise use all programs.
2. **Execute** — Call each selected program with the same arguments, collecting outputs into a list.
3. **Reduce** — If `reduce_fn` is provided, apply it to the list of outputs and return the reduced result; otherwise return the raw list.

---

## Data Flow

The following diagram illustrates the runtime flow when an `EnsembledProgram` is invoked.

```mermaid
flowchart TD
    A[Input args/kwargs] --> B{size set?}
    B -- Yes --> C[random.sample programs, size]
    B -- No --> D[Use all programs]
    C --> E[Run each program]
    D --> E
    E --> F[Collect outputs list]
    F --> G{reduce_fn set?}
    G -- Yes --> H[reduce_fn outputs]
    G -- No --> I[Return raw outputs list]
    H --> J[Return reduced result]
```

---

## Process Flow: Compilation and Usage

```mermaid
sequenceDiagram
    participant User
    participant Ensemble
    participant EnsembledProgram
    participant Program

    User->>Ensemble: Ensemble(reduce_fn=dspy.majority)
    User->>Ensemble: compile([prog1, prog2, prog3])
    Ensemble->>EnsembledProgram: instantiate with programs
    Ensemble-->>User: EnsembledProgram()
    User->>EnsembledProgram: __call__(input)
    EnsembledProgram->>Program: prog1(input)
    EnsembledProgram->>Program: prog2(input)
    EnsembledProgram->>Program: prog3(input)
    Program-->>EnsembledProgram: outputs
    EnsembledProgram->>EnsembledProgram: reduce_fn(outputs)
    EnsembledProgram-->>User: reduced prediction
```

---

## Dependencies

```mermaid
graph LR
    Ensemble --> Teleprompter
    Ensemble --> Module
    Ensemble --> Prediction
    Ensemble --> random[random.sample]
    Ensemble --> dspy[dspy.majority]

    Teleprompter -.->|base class| Ensemble
    Module -.->|base class of EnsembledProgram| Ensemble
```

| Dependency | Purpose |
| --- | --- |
| `dspy.teleprompt.teleprompt.Teleprompter` | Base class defining the optimizer interface. See [teleprompt_core_base](teleprompt_core_base.md). |
| `dspy.Module` | Base class for the generated `EnsembledProgram`. See [primitives_module](primitives_module.md). |
| `random.sample` | Random subset selection when `size` is set. |
| `dspy.majority` | Common `reduce_fn` for majority voting. |

---

## Usage Example

```python
import dspy
from dspy.teleprompt import Ensemble

# Assume `programs` is a list of already-compiled dspy.Module instances
ensemble = Ensemble(reduce_fn=dspy.majority)
ensembled_program = ensemble.compile(programs)

# Use it like any other module
result = ensembled_program(question="What is the capital of France?")
```

To sample a random subset of programs on each call:

```python
ensemble = Ensemble(reduce_fn=dspy.majority, size=3)
ensembled_program = ensemble.compile(programs)
```

---

## Design Notes and Limitations

- **`EnsembledProgram` structure** — As noted in the module's TODO, the ensembled program does not currently mirror the structure of the individual programs. If all programs are compatible, the top majority-compatible trace could be used as a singular teacher for further compilation. This is a future enhancement.
- **Determinism** — The `deterministic` parameter is not yet implemented. Deterministic ensembling would require example hashing to ensure reproducible program selection.
- **No training set required** — Unlike other teleprompters, `Ensemble.compile` does not accept a `trainset`; it operates purely on pre-compiled programs.

---

## Related Modules

- [teleprompt_core_base](teleprompt_core_base.md) — The `Teleprompter` base class.
- [teleprompt_core_bootstrap](teleprompt_core_bootstrap.md) — `BootstrapFewShot`, a common source of programs to ensemble.
- [teleprompt_core_random_search](teleprompt_core_random_search.md) — `BootstrapFewShotWithRandomSearch`.
- [primitives_module](primitives_module.md) — The `Module` base class.
- [primitives_prediction](primitives_prediction.md) — The `Prediction` object returned by programs.
