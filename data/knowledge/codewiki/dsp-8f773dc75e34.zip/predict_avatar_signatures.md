# predict_avatar_signatures

## Introduction

The `predict_avatar_signatures` module defines the **`Actor`** signature used by the [Avatar](predict_avatar_core.md) agent. The `Actor` is a DSPy [`Signature`](signatures.md) that instructs a language model to act as a decision-making agent: given a `Goal` and a list of available `Tools`, it must decide which tool to invoke and what input to pass to it.

This signature is the "brain" of the Avatar loop. On each iteration of the agent, the `Actor` is invoked to produce the next `Action`, which the Avatar then executes against the corresponding tool. The signature is dynamically extended at runtime by the Avatar to include the history of prior actions and their results, enabling multi-step reasoning.

> **Note:** This module contains a single, focused component. For the broader agent orchestration logic, see [predict_avatar_core](predict_avatar_core.md). For the data models used by the signature (`Action`, `Tool`, `ActionOutput`), see [predict_avatar_models](predict_avatar_models.md).

---

## Core Component: `Actor`

The `Actor` class is a subclass of `dspy.Signature` that declares the input/output contract for the tool-selection step of the Avatar agent.

```python
import dspy
from dspy.predict.avatar.models import Action


class Actor(dspy.Signature):
    """You will be given `Tools` which will be a list of tools to use to accomplish the `Goal`. ..."""

    goal: str = dspy.InputField(
        prefix="Goal:",
        desc="Task to be accomplished.",
    )
    tools: list[str] = dspy.InputField(
        prefix="Tools:",
        desc="list of tools to use",
    )
    action_1: Action = dspy.OutputField(
        prefix="Action 1:",
        desc="1st action to take.",
    )
```

### Fields

| Field | Direction | Type | Prefix | Description |
|-------|-----------|------|--------|-------------|
| `goal` | Input | `str` | `Goal:` | The task to be accomplished. Populated from the parent Avatar signature's docstring. |
| `tools` | Input | `list[str]` | `Tools:` | The list of tool names available to the agent. |
| `action_1` | Output | [`Action`](predict_avatar_models.md) | `Action 1:` | The first action to take, containing a `tool_name` and `tool_input_query`. |

### Instructions (Docstring)

The signature's docstring serves as the natural-language instruction to the LM. It establishes the agent's role and the rules of the decision process:

- The model is given `Tools` to accomplish the `Goal`.
- It must decide **which tool to use** and **what input values to provide**.
- The output is an `Action` consisting of a tool and an input query.
- The model may **opt to use no tools** and provide the final answer directly.
- The model may **use one tool multiple times** with different input queries if applicable.

---

## Architecture & Relationships

The `Actor` signature sits at the center of the Avatar agent's iterative loop. It is consumed by the `Avatar` module, which dynamically mutates the signature between iterations.

```mermaid
graph TD
    subgraph "predict_avatar_signatures"
        Actor["Actor (Signature)"]
    end

    subgraph "predict_avatar_models"
        Action["Action"]
        Tool["Tool"]
        ActionOutput["ActionOutput"]
    end

    subgraph "predict_avatar_core"
        Avatar["Avatar (Module)"]
    end

    subgraph "signatures"
        Signature["Signature"]
    end

    subgraph "predict_core"
        TypedPredictor["TypedPredictor"]
    end

    Actor -->|subclass of| Signature
    Actor -->|output field type| Action
    Avatar -->|instantiates & mutates| Actor
    Avatar -->|wraps in| TypedPredictor
    Avatar -->|executes| Tool
    Avatar -->|records| ActionOutput
```

### Key Relationships

- **Inheritance:** `Actor` extends [`dspy.Signature`](signatures.md), inheriting the field-manipulation API (`append`, `insert`, `with_updated_fields`, etc.).
- **Output typing:** The `action_1` output field is typed as [`Action`](predict_avatar_models.md), a Pydantic model with `tool_name` and `tool_input_query`. This enables structured, typed prediction via `TypedPredictor`.
- **Consumption:** The [`Avatar`](predict_avatar_core.md) module instantiates `Actor` and wraps it in a `dspy.TypedPredictor` (`self.actor`).

---

## Dynamic Signature Mutation

A defining characteristic of the `Actor` signature is that it is **not static**. The Avatar module mutates it on every iteration to accumulate the conversation history of actions and results. This is achieved through the `Signature` class methods `append` and `with_updated_fields`.

### Mutation Flow

```mermaid
sequenceDiagram
    participant Avatar
    participant Actor as Actor Signature
    participant TypedPredictor

    Note over Avatar: __init__: append input fields from parent signature
    Avatar->>Actor: append(field, InputField) for each input field

    loop Each iteration idx
        Avatar->>TypedPredictor: actor(**args)
        TypedPredictor->>Actor: predict action_{idx}
        Actor-->>Avatar: Action(tool_name, tool_input_query)

        alt tool_name != "Finish"
            Avatar->>Avatar: _call_tool(...)
            Avatar->>Actor: with_updated_fields(action_{idx}, Action, input)
            Avatar->>Actor: append(result_{idx}, InputField)
            Avatar->>Actor: append(action_{idx+1}, OutputField)
            Avatar->>Actor: with_updated_fields(action_{idx+1}, Action)
        else tool_name == "Finish"
            Avatar->>Actor: with_updated_fields(action_{idx}, Action, input)
            Avatar->>Actor: append(result_{idx}, InputField)
            Avatar->>Actor: append(output fields)
        end
    end
```

### Mutation Details

1. **Initialization:** During `Avatar.__init__`, the parent signature's input fields are appended to `Actor` in reverse order, so the agent receives the original task inputs.

2. **Per-iteration update (`_update_signature`):**
   - The current `action_{idx}` field is converted from an **output** field to an **input** field via `with_updated_fields(..., __dspy_field_type="input")`, so the model can see what it previously decided.
   - A `result_{idx}` input field is appended to carry the tool's output back into the prompt.
   - If the task is **not** finished, a new `action_{idx+1}` output field is appended and typed as `Action`.
   - If the task **is** finished (`omit_action=True`), the parent signature's output fields are appended instead, allowing the model to produce the final answer.

3. **Reset:** After the loop completes, the Avatar restores the actor from a deep-copied clone (`self.actor_clone`) so the signature returns to its initial state for the next call.

---

## Data Flow

The following diagram illustrates how data flows through the `Actor` signature during a single Avatar invocation.

```mermaid
flowchart LR
    A["Goal (str)"] --> Actor
    B["Tools (list[str])"] --> Actor
    C["Prior actions & results<br/>(action_i, result_i)"] --> Actor
    Actor --> D["Action<br/>(tool_name, tool_input_query)"]
    D --> E{"tool_name == Finish?"}
    E -->|No| F["Execute Tool"]
    F --> G["ActionOutput<br/>(recorded)"]
    G --> C
    E -->|Yes| H["Final Prediction<br/>(output fields + actions)"]
```

---

## Integration with the Avatar Agent

The `Actor` signature is tightly coupled to the [`Avatar`](predict_avatar_core.md) module. The table below summarizes the integration points.

| Integration Point | Description |
|-------------------|-------------|
| `self.actor_signature = Actor` | The Avatar uses `Actor` as the base signature for its internal predictor. |
| `self.actor = dspy.TypedPredictor(self.actor_signature)` | The signature is wrapped in a `TypedPredictor` to enforce the `Action` output type. |
| `self.actor_clone = deepcopy(self.actor)` | A pristine clone is kept to reset the mutated signature after each `forward` call. |
| `_update_signature(idx, omit_action)` | Mutates the `Actor` signature between iterations. |
| `forward(**kwargs)` | Drives the loop, invoking the actor and executing tools until `Finish`. |

---

## Related Modules

- [predict_avatar_core](predict_avatar_core.md) — The `Avatar` module that orchestrates the agent loop and consumes this signature.
- [predict_avatar_models](predict_avatar_models.md) — The `Action`, `ActionOutput`, and `Tool` Pydantic models referenced by this signature.
- [signatures](signatures.md) — The base `Signature` class and its field-manipulation API (`append`, `insert`, `with_updated_fields`).
- [predict_core](predict_core.md) — The `Predict` / `TypedPredictor` machinery used to execute the signature.
