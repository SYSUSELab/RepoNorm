# Datasets Builtin Module

## Introduction

The `datasets_builtin` module provides a collection of **ready-to-use, built-in datasets** for DSPy. These datasets are curated for common reasoning, question-answering, and classification tasks, and are designed to be immediately usable for training, evaluating, and optimizing DSPy programs without requiring users to source or preprocess data themselves.

Each built-in dataset wraps an external data source (typically from the Hugging Face `datasets` library) and normalizes it into DSPy's standard `Example` format, exposing consistent `train`, `dev`, and `test` splits. This module sits alongside the core dataset infrastructure (see [datasets_core](datasets_core.md)) and the AlfWorld environment dataset (see [datasets_alfworld](datasets_alfworld.md)).

### Datasets Provided

| Dataset | Class | Task Type | Source |
|---------|-------|-----------|--------|
| Colors | `Colors` | Classification / reasoning | Built-in color list (from matplotlib) |
| GSM8K | `GSM8K` | Grade-school math word problems | `gsm8k` (Hugging Face) |
| HotPotQA | `HotPotQA` | Multi-hop question answering | `hotpot_qa` (Hugging Face) |
| MATH | `MATH` | Competition mathematics | `DigitalLearningGmbH/MATH-lighteval` (Hugging Face) |

---

## Architecture Overview

The built-in datasets fall into two architectural categories:

1. **`Dataset` subclasses** (`Colors`, `HotPotQA`) — inherit from the core `Dataset` base class, gaining automatic shuffling, sampling, seed management, and lazy split materialization.
2. **Standalone classes** (`GSM8K`, `MATH`) — implement their own `__init__` logic and expose `train`/`dev`/`test` attributes directly, without inheriting from `Dataset`.

```mermaid
graph TD
    subgraph "datasets_builtin"
        Colors["Colors<br/>(Dataset subclass)"]
        HotPotQA["HotPotQA<br/>(Dataset subclass)"]
        GSM8K["GSM8K<br/>(standalone)"]
        MATH["MATH<br/>(standalone)"]
    end

    subgraph "datasets_core"
        Dataset["Dataset<br/>(base class)"]
        DataLoader["DataLoader"]
    end

    subgraph "primitives"
        Example["Example"]
    end

    subgraph "External"
        HF["Hugging Face<br/>datasets library"]
    end

    Colors -->|inherits| Dataset
    HotPotQA -->|inherits| Dataset
    Dataset -->|produces| Example
    GSM8K -->|produces| Example
    MATH -->|produces| Example
    GSM8K -->|loads| HF
    HotPotQA -->|loads| HF
    MATH -->|loads| HF
```

---

## Component Details

### Colors

`Colors` is a synthetic classification dataset built from a curated list of ~150 named colors (originally sourced from matplotlib). It is useful for testing reasoning and classification programs where the label space is a set of natural-language color names.

**Key behaviors:**

- **Suffix sorting** (`sort_by_suffix=True` by default): Colors are sorted by their reversed string (i.e., by suffix). This groups visually/lexically similar colors together, which is important because the train/dev split is a simple contiguous slice — sorting by suffix ensures that similar colors are *not* repeated across train and dev splits.
- **Split ratio**: 60% train / 40% dev, computed as `int(len(colors) * 0.6)`.
- **Deterministic shuffling**: Both splits are shuffled with `random.Random(0)` for reproducibility.
- **Example format**: Each example is a dict `{"color": <color_name>}`.

```python
from dspy.datasets import Colors

colors = Colors()
print(colors.train[0])   # Example(color='...')
print(len(colors.train), len(colors.dev))
```

Because `Colors` inherits from `Dataset`, the `train`/`dev` properties apply additional shuffling and sampling based on the configured seeds and sizes (see [datasets_core](datasets_core.md)).

---

### GSM8K

`GSM8K` loads the official **Grade School Math 8K** dataset from Hugging Face and parses each example into a structured form.

**Key behaviors:**

- **Answer parsing**: The raw `answer` field contains a reasoning chain followed by `#### <final_answer>`. The class splits on the `####` marker to separate `gold_reasoning` from the final numeric `answer` (commas stripped, cast to `int` then `str`).
- **Deterministic shuffling**: Both official train and test splits are shuffled with `random.Random(0)`.
- **Split sizes**:
  - `train`: first 200 examples of the shuffled official train set
  - `dev`: examples 200–500 of the shuffled official train set
  - `test`: the entire official test set
- **Example format**: `dspy.Example(question=..., gold_reasoning=..., answer=...).with_inputs("question")`.

**Helper functions:**

- `parse_integer_answer(answer, only_first_line=True)` — Extracts the last numeric token from a model's answer string, strips decimals, and returns an `int` (defaults to `0` on failure).
- `gsm8k_metric(gold, pred, trace=None)` — The default evaluation metric; returns `True` when the parsed integer answers of the gold and prediction match.

```python
from dspy.datasets import GSM8K

gsm8k = GSM8K()
print(gsm8k.train[0].question)
print(len(gsm8k.train), len(gsm8k.dev), len(gsm8k.test))
```

---

### HotPotQA

`HotPotQA` loads the **HotpotQA fullwiki** dataset for multi-hop question answering, filtering to only "hard" examples.

**Key behaviors:**

- **Hard-only filtering**: Only examples with `level == "hard"` are retained. An assertion enforces `only_hard_examples=True` because the official dev set is entirely hard, and mixing easy examples would break comparability.
- **Detail retention** (`keep_details`):
  - `True` — keeps `id`, `question`, `answer`, `type`, `supporting_facts`, `context`
  - `"dev_titles"` (default) — keeps `question`, `answer`, `supporting_facts` (converted to a `gold_titles` set)
  - otherwise — keeps only `question`, `answer`
- **Split logic**:
  - `train`: first 75% of the shuffled official train set
  - `dev`: remaining 25% of the official train set (when `unofficial_dev=True`), otherwise `None`
  - `test`: the official validation split (all hard)
- **`gold_titles`**: When `supporting_facts` is present, it is transformed into a `set` of titles stored under `gold_titles`, and the raw `supporting_facts` key is removed. For the train split under `keep_details="dev_titles"`, `gold_titles` is deleted to avoid leaking supporting information.

```python
from dspy.datasets import HotPotQA

hotpot = HotPotQA()
print(hotpot.train[0].question)
print(len(hotpot.train), len(hotpot.dev), len(hotpot.test))
```

---

### MATH

`MATH` loads the **MATH-lighteval** dataset for a specified `subset` (e.g., `"algebra"`, `"geometry"`).

**Key behaviors:**

- **Sub-splitting the test set**: The class deliberately uses the dataset's `test` split and divides it into train/dev/test, on the assumption that current language models have already been trained on MATH's official train split. This avoids train/test contamination.
- **Split sizes**: `size = min(350, len(dataset) // 3)`, then `train = dataset[:size]`, `dev = dataset[size:2*size]`, `test = dataset[2*size:]`.
- **Deterministic shuffling**: `random.Random(0).shuffle(dataset)`.
- **Example format**: `dspy.Example(question=..., reasoning=..., answer=...).with_inputs("question")`, where `answer` is extracted from the solution's `\boxed{...}`.

**Helper functions:**

- `extract_answer(s)` — Parses the content of the last `\boxed{...}` expression, correctly handling nested braces, and strips LaTeX formatting commands (`\text{...}`, `\!`).
- `MATH.metric(example, pred, trace=None)` — Uses the external `math_equivalence` package (`is_equiv`) to compare answers. Raises an `ImportError` with installation instructions if the package is missing.

```python
from dspy.datasets import MATH

math_ds = MATH("algebra")
print(math_ds.train[0].question)
print(len(math_ds.train), len(math_ds.dev), len(math_ds.test))
```

> **Note:** The official `math_equivalence.is_equiv` does not have perfect recall (e.g., for reference values like `\left[\frac{1}{2}, \frac{4}{3}\right]`), so metric results should be interpreted with care.

---

## Data Flow

The following diagram illustrates how raw external data flows through each built-in dataset into DSPy `Example` objects.

```mermaid
flowchart LR
    subgraph External["External Sources"]
        HF_GSM["gsm8k (HF)"]
        HF_HOT["hotpot_qa (HF)"]
        HF_MATH["MATH-lighteval (HF)"]
        COLORS["all_colors list"]
    end

    subgraph Processing["Built-in Dataset Processing"]
        GSM8K["GSM8K<br/>parse #### answers"]
        HotPotQA["HotPotQA<br/>filter hard, extract gold_titles"]
        MATH["MATH<br/>extract \\boxed{} answers"]
        Colors["Colors<br/>sort by suffix, split 60/40"]
    end

    subgraph Output["DSPy Output"]
        EX["dspy.Example<br/>.with_inputs(...)"]
        SPLITS["train / dev / test"]
    end

    HF_GSM --> GSM8K
    HF_HOT --> HotPotQA
    HF_MATH --> MATH
    COLORS --> Colors

    GSM8K --> EX
    HotPotQA --> EX
    MATH --> EX
    Colors --> EX
    EX --> SPLITS
```

---

## Class Hierarchy and Inheritance

```mermaid
classDiagram
    class Dataset {
        +train_seed
        +train_size
        +dev_size
        +test_size
        +train
        +dev
        +test
        +reset_seeds()
        +prepare_by_seed()
    }
    class Colors {
        +sort_by_suffix
        +sorted_by_suffix()
    }
    class HotPotQA {
        +only_hard_examples
        +keep_details
        +unofficial_dev
    }
    class GSM8K {
        +do_shuffle
        +train
        +dev
        +test
    }
    class MATH {
        +subset
        +metric()
    }

    Dataset <|-- Colors
    Dataset <|-- HotPotQA
    GSM8K ..> Example : produces
    MATH ..> Example : produces
```

---

## Integration with the Broader System

Built-in datasets are consumed throughout DSPy for evaluation and optimization:

- **Evaluation** — Datasets feed `dev`/`test` splits into the `Evaluate` class (see [evaluate](evaluate.md)) to measure program quality.
- **Optimization** — Teleprompters such as `BootstrapFewShot`, `MIPROv2`, and `GEPA` (see [teleprompt_core](teleprompt_core.md), [teleprompt_optimizers](teleprompt_optimizers.md), [teleprompt_gepa](teleprompt_gepa.md)) use `train`/`dev` splits to compile and optimize programs.
- **Examples** — All datasets produce `dspy.Example` objects (see [primitives](primitives.md)), the universal data container in DSPy.
- **Custom data loading** — For arbitrary datasets, use the `DataLoader` class from [datasets_core](datasets_core.md) instead of these built-ins.

```mermaid
sequenceDiagram
    participant User
    participant Builtin as Built-in Dataset
    participant Example as dspy.Example
    participant Program as DSPy Program
    participant Eval as Evaluate / Teleprompter

    User->>Builtin: instantiate (e.g., GSM8K())
    Builtin->>Example: build train/dev/test Examples
    User->>Program: run on dev examples
    Program-->>Eval: predictions
    Eval->>Eval: apply metric (e.g., gsm8k_metric)
    Eval-->>User: score / optimized program
```

---

## Common Usage Pattern

All built-in datasets follow a consistent interface, making them interchangeable:

```python
from dspy.datasets import GSM8K, HotPotQA, MATH, Colors

# Instantiate
dataset = GSM8K()          # or HotPotQA(), MATH("algebra"), Colors()

# Access splits
trainset = dataset.train
devset = dataset.dev
testset = dataset.test

# Each element is a dspy.Example with inputs configured
example = trainset[0]
print(example.inputs())    # input fields
print(example.labels())    # label fields
```

---

## Related Modules

- [datasets_core](datasets_core.md) — The `Dataset` base class and `DataLoader` for custom data.
- [datasets_alfworld](datasets_alfworld.md) — The AlfWorld interactive environment dataset.
- [primitives](primitives.md) — The `Example` and `Prediction` data containers.
- [evaluate](evaluate.md) — Evaluation utilities that consume dataset splits.
- [teleprompt_core](teleprompt_core.md) — Core optimizers that use datasets for compilation.
