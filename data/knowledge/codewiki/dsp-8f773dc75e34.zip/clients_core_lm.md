# clients_core_lm

## Overview

The `clients_core_lm` module provides the primary language model client for DSPy: the `LM` class. It is the concrete, production-ready implementation of the abstract [`BaseLM`](clients_core_base_lm.md) interface and serves as the bridge between DSPy programs and the underlying LLM providers (OpenAI, Anthropic, Databricks, local models, etc.) via [LiteLLM](https://github.com/BerriAI/litellm).

`LM` is responsible for:

- **Request construction** — normalizing prompts/messages and merging per-call and instance-level kwargs.
- **Provider dispatch** — routing chat vs. text completion requests through LiteLLM.
- **Caching** — integrating with the DSPy [`Cache`](clients_core_cache.md) layer and LiteLLM's own cache.
- **Streaming** — supporting token-by-token streaming into DSPy's streaming pipeline.
- **Usage tracking** — reporting token usage to the [`UsageTracker`](utils.md).
- **Lifecycle management** — launching/killing provider-hosted models and orchestrating fine-tuning and reinforcement-learning jobs through a [`Provider`](clients_core_provider.md).

> Most users interact with this module through the convenience alias `dspy.LM(...)`. Advanced users can subclass [`BaseLM`](clients_core_base_lm.md) directly for custom providers.

---

## Architecture

The `LM` class sits at the center of DSPy's client layer. It inherits from `BaseLM` (which handles history, callbacks, and response post-processing) and delegates provider-specific behavior to a `Provider` instance.

```mermaid
graph TD
    subgraph "DSPy Programs"
        Predict["Predict / ChainOfThought / ReAct"]
    end

    subgraph "clients_core_lm"
        LM["LM"]
    end

    subgraph "clients_core (siblings)"
        BaseLM["BaseLM"]
        Cache["Cache"]
        Provider["Provider"]
        Embedder["Embedder"]
    end

    subgraph "clients_providers"
        OpenAI["OpenAIProvider"]
        Databricks["DatabricksProvider"]
        Local["LocalProvider"]
        Arbor["ArborProvider"]
    end

    subgraph "External"
        LiteLLM["LiteLLM"]
        UsageTracker["UsageTracker"]
        Callbacks["BaseCallback"]
    end

    Predict -->|"__call__ / acall"| LM
    LM -->|inherits| BaseLM
    LM -->|"request_cache"| Cache
    LM -->|"launch/kill/finetune/reinforce"| Provider
    LM -->|"completion / acompletion"| LiteLLM
    LM -->|"add_usage"| UsageTracker
    BaseLM -->|"with_callbacks"| Callbacks

    Provider -.->|"subclass"| OpenAI
    Provider -.->|"subclass"| Databricks
    Provider -.->|"subclass"| Local
    Provider -.->|"subclass"| Arbor
```

### Key Relationships

| Component | Role | Documentation |
|-----------|------|---------------|
| `BaseLM` | Abstract base; handles history, callbacks, response parsing | [clients_core_base_lm.md](clients_core_base_lm.md) |
| `Cache` | Two-level (memory + disk) response cache | [clients_core_cache.md](clients_core_cache.md) |
| `Provider` | Provider abstraction for launch/kill/finetune/reinforce | [clients_core_provider.md](clients_core_provider.md) |
| `OpenAIProvider` | Concrete provider for OpenAI models | [clients_providers.md](clients_providers.md) |
| `UsageTracker` | Aggregates token usage across calls | [utils.md](utils.md) |
| `BaseCallback` | Hook system for LM lifecycle events | [utils.md](utils.md) |

---

## The `LM` Class

### Constructor

```python
LM(
    model: str,
    model_type: Literal["chat", "text"] = "chat",
    temperature: float = 0.0,
    max_tokens: int = 4000,
    cache: bool = True,
    cache_in_memory: bool = True,
    callbacks: list[BaseCallback] | None = None,
    num_retries: int = 3,
    provider: Provider | None = None,
    finetuning_model: str | None = None,
    launch_kwargs: dict[str, Any] | None = None,
    train_kwargs: dict[str, Any] | None = None,
    **kwargs,
)
```

| Parameter | Description |
|-----------|-------------|
| `model` | LiteLLM-style model string, e.g. `"openai/gpt-4o"`. |
| `model_type` | `"chat"` (default) or `"text"` completion. |
| `temperature` | Sampling temperature. |
| `max_tokens` | Max tokens per response. |
| `cache` | Enable DSPy response caching. |
| `cache_in_memory` | *(deprecated)* Enable additional in-memory LRU caching. |
| `callbacks` | List of `BaseCallback` handlers for this LM instance. |
| `num_retries` | Retry count with exponential backoff. |
| `provider` | Explicit `Provider`; inferred from `model` if omitted. |
| `finetuning_model` | Model to fine-tune (may differ from inference model). |
| `launch_kwargs` | Arguments for provider `launch`/`kill`. |
| `train_kwargs` | Default arguments for fine-tuning jobs. |
| `**kwargs` | Forwarded to LiteLLM (e.g. `api_key`, `api_base`). |

#### Model-Family Special Handling

The constructor inspects the model name and applies family-specific configuration:

```mermaid
flowchart TD
    A["Parse model name"] --> B{"Matches o1/o3/o4/o5 or gpt-5?"}
    B -->|Yes| C["Assert temperature == 1.0<br/>and max_tokens >= 20_000"]
    C --> D["kwargs = {temperature,<br/>max_completion_tokens, ...}"]
    B -->|No| E["kwargs = {temperature,<br/>max_tokens, ...}"]
```

OpenAI reasoning models (o-series, gpt-5) require `temperature=1.0` and `max_tokens >= 20_000`, and use the `max_completion_tokens` parameter instead of `max_tokens`.

> **Note:** If you modify the constructor, remember to update `LM.copy()` accordingly.

### Core Methods

#### `forward(prompt=None, messages=None, **kwargs)`

Synchronous completion entry point. It:

1. Pops `cache` / `cache_in_memory` overrides from `kwargs`.
2. Builds `messages` from `prompt` if needed.
3. Merges instance `self.kwargs` with call-level `kwargs`.
4. Selects `litellm_completion` (chat) or `litellm_text_completion` (text).
5. Wraps the completion function with caching via `_get_cached_completion_fn`.
6. Executes the request and warns on truncation (`finish_reason == "length"`).
7. Reports usage to the `UsageTracker` on cache misses.

#### `aforward(prompt=None, messages=None, **kwargs)`

Async counterpart of `forward`, using `alitellm_completion` / `alitellm_text_completion`.

#### `_get_cached_completion_fn(completion_fn, cache, enable_memory_cache)`

Wraps a completion function with the DSPy [`request_cache`](clients_core_cache.md) decorator and computes the LiteLLM cache arguments. API credentials (`api_key`, `api_base`, `base_url`) are excluded from the cache key so that identical requests with different credentials share cache entries.

#### `launch(launch_kwargs=None)` / `kill(launch_kwargs=None)`

Delegate to `self.provider.launch(...)` / `self.provider.kill(...)` for provider-hosted model lifecycle management.

#### `finetune(train_data, train_data_format, train_kwargs=None) -> TrainingJob`

Starts a fine-tuning job in a background thread. Asserts `self.provider.finetunable`, constructs a `TrainingJob`, and returns it immediately while training runs asynchronously.

#### `reinforce(train_kwargs) -> ReinforceJob`

Creates and initializes a reinforcement-learning job. Asserts `self.provider.reinforceable`.

#### `_run_finetune_job(job)`

Internal worker executed in the fine-tuning thread. Calls `provider.finetune(...)`, then produces a new `LM` via `self.copy(model=model)` and stores it on the job via `job.set_result(lm)`. Exceptions are logged and stored as the job result.

#### `infer_provider() -> Provider`

Infers the provider from the model string. Currently returns `OpenAIProvider()` if `OpenAIProvider.is_provider_model(self.model)` is true, otherwise a generic `Provider()`.

#### `dump_state()`

Serializes the LM's configuration (model, model_type, cache flags, retries, finetuning model, launch/train kwargs) merged with `self.kwargs`. Used for state persistence.

---

## Module-Level Completion Functions

These functions are the actual LiteLLM adapters used by `LM.forward`/`aforward`.

```mermaid
graph LR
    subgraph "Chat path"
        LC["litellm_completion"]
        ALC["alitellm_completion"]
    end
    subgraph "Text path"
        LTC["litellm_text_completion"]
        ALTC["alitellm_text_completion"]
    end
    subgraph "Streaming"
        GSC["_get_stream_completion_fn"]
    end

    LC --> GSC
    ALC --> GSC
    LC -->|"no stream"| LiteLLM1["litellm.completion"]
    ALC -->|"no stream"| LiteLLM2["litellm.acompletion"]
    LTC --> LiteLLM3["litellm.text_completion"]
    ALTC --> LiteLLM4["litellm.atext_completion"]
```

| Function | Purpose |
|----------|---------|
| `litellm_completion` | Sync chat completion; uses streaming if a stream is configured. |
| `alitellm_completion` | Async chat completion. |
| `litellm_text_completion` | Sync text completion; extracts provider/model, resolves API key/base from env, joins messages into a prompt. |
| `alitellm_text_completion` | Async text completion. |
| `_get_stream_completion_fn` | Builds a streaming completion closure that forwards chunks to `dspy.settings.send_stream`. |

All completion functions use `retry_strategy="exponential_backoff_retry"` and default to `{"no-cache": True, "no-store": True}` when no cache is provided.

---

## Data Flow

The following sequence diagram shows a typical synchronous chat request from a DSPy program through `LM` to the provider.

```mermaid
sequenceDiagram
    participant P as DSPy Program
    participant LM as LM
    participant BLM as BaseLM
    participant Cache as Cache (request_cache)
    participant LL as LiteLLM
    participant UT as UsageTracker

    P->>LM: __call__(prompt/messages, **kwargs)
    LM->>BLM: __call__ (with_callbacks)
    BLM->>LM: forward(...)
    LM->>LM: merge kwargs, build messages
    LM->>Cache: check cache (request_cache)
    alt Cache hit
        Cache-->>LM: cached response
    else Cache miss
        LM->>LL: completion(request, num_retries, cache)
        LL-->>LM: response
        LM->>Cache: store response
        LM->>UT: add_usage(model, usage)
    end
    LM-->>BLM: raw response
    BLM->>BLM: _process_lm_response (history, outputs)
    BLM-->>P: outputs
```

### Streaming Flow

When `dspy.settings.send_stream` is set, `_get_stream_completion_fn` returns a streaming closure instead of a one-shot completion:

```mermaid
sequenceDiagram
    participant LM as LM
    participant SCF as stream_completion
    participant LL as litellm.acompletion
    participant Stream as send_stream
    participant SL as StreamListener

    LM->>SCF: invoke
    SCF->>LL: acompletion(stream=True)
    loop each chunk
        LL-->>SCF: chunk
        SCF->>SCF: tag chunk.predict_id
        SCF->>Stream: send(chunk)
        Stream->>SL: deliver chunk
    end
    SCF->>SCF: stream_chunk_builder(chunks)
    SCF-->>LM: assembled response
```

Each chunk is tagged with the `caller_predict` id so the [`StreamListener`](streaming.md) can attribute tokens to the correct predictor. When `dspy.settings.track_usage` is enabled, `stream_options={"include_usage": True}` is added to the request.

---

## Fine-Tuning and Reinforcement Learning

`LM` exposes two training workflows, both delegated to the configured `Provider`.

```mermaid
flowchart TD
    A["LM.finetune(train_data, format, kwargs)"] --> B{"provider.finetunable?"}
    B -->|No| C["AssertionError"]
    B -->|Yes| D["Create TrainingJob"]
    D --> E["Start background thread"]
    E --> F["_run_finetune_job"]
    F --> G["provider.finetune(...)"]
    G --> H["LM.copy(model=trained_model)"]
    H --> I["job.set_result(new_lm)"]

    J["LM.reinforce(train_kwargs)"] --> K{"provider.reinforceable?"}
    K -->|No| L["AssertionError"]
    K -->|Yes| M["Create ReinforceJob"]
    M --> N["job.initialize()"]
```

- **Fine-tuning** returns a `TrainingJob` (a `Future` subclass) immediately; the trained model is delivered asynchronously as a new `LM` instance.
- **Reinforcement learning** returns an initialized `ReinforceJob` for stepwise training.

See [clients_core_provider.md](clients_core_provider.md) for the `Provider`, `TrainingJob`, and `ReinforceJob` contracts, and [clients_providers.md](clients_providers.md) for concrete implementations (OpenAI, Databricks, local, Arbor).

---

## Caching Strategy

`LM` participates in a two-tier caching scheme:

1. **DSPy cache** — via the `request_cache` decorator from [`clients_core_cache`](clients_core_cache.md). Controlled by the `cache` and `cache_in_memory` flags.
2. **LiteLLM cache** — controlled by `litellm.cache`; when disabled, requests are sent with `{"no-cache": True, "no-store": True}`.

```mermaid
flowchart LR
    Req["Request"] --> DSPyCache{"DSPy cache enabled?"}
    DSPyCache -->|Yes| RC["request_cache wrapper"]
    DSPyCache -->|No| Raw["raw completion fn"]
    RC --> LLite{"litellm.cache set?"}
    Raw --> LLite
    LLite -->|Yes| LCache["no-cache=False"]
    LLite -->|No| NoCache["no-cache=True"]
```

Cache keys ignore `api_key`, `api_base`, and `base_url` so that credential changes do not invalidate cached responses.

---

## Usage Tracking

On every cache miss, if `dspy.settings.usage_tracker` is set and the response carries a `usage` attribute, `LM` calls:

```python
settings.usage_tracker.add_usage(self.model, dict(results.usage))
```

This feeds the [`UsageTracker`](utils.md), which aggregates token counts per model. Cache hits are explicitly excluded (`cache_hit` flag) to avoid double-counting.

---

## Callbacks

`LM` accepts a `callbacks` list in its constructor. Because `BaseLM.__call__` and `BaseLM.acall` are decorated with `@with_callbacks`, the following handlers fire automatically:

- `on_lm_start(call_id, instance, inputs)`
- `on_lm_end(call_id, outputs, exception)`

Callbacks can also be registered globally via `dspy.settings.configure(callbacks=[...])`. See [`BaseCallback`](utils.md) for the full handler set.

---

## Extension Points

| Goal | Approach |
|------|----------|
| Custom provider | Subclass [`Provider`](clients_core_provider.md) and pass via `provider=`. |
| Custom LM behavior | Subclass [`BaseLM`](clients_core_base_lm.md) and override `forward`/`aforward`. |
| Custom caching | Configure the [`Cache`](clients_core_cache.md) via `dspy.settings`. |
| Custom callbacks | Subclass [`BaseCallback`](utils.md) and pass via `callbacks=`. |

---

## Related Modules

- [clients_core_base_lm.md](clients_core_base_lm.md) — Abstract `BaseLM` interface.
- [clients_core_cache.md](clients_core_cache.md) — Two-level response cache.
- [clients_core_provider.md](clients_core_provider.md) — Provider, `TrainingJob`, `ReinforceJob`.
- [clients_core_embedder.md](clients_core_embedder.md) — Embedding client.
- [clients_providers.md](clients_providers.md) — Concrete provider implementations.
- [clients_finetune_utils.md](clients_finetune_utils.md) — Fine-tuning data formats and status enums.
- [streaming.md](streaming.md) — Streaming listener and message types.
- [utils.md](utils.md) — Callbacks, usage tracking, and other utilities.
