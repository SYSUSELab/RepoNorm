# Primitives: Example

## Introduction

The `Example` class is a foundational data primitive in DSPy. It represents a single data point — a flexible, dictionary-like container that holds input fields, labels, and arbitrary metadata. `Example` is the universal currency for data flowing through DSPy programs: it is produced by datasets, consumed by modules, and returned (as a subclass) by predictions.

Its key design goals are:

- **Attribute-style access** — fields can be read/written as `example.question` in addition to `example["question"]`.
- **Input/label separation** — a designated subset of fields can be marked as *inputs* via `with_inputs()`, enabling clean separation between what a program receives and what it should predict.
- **Metadata isolation** — internal bookkeeping keys (prefixed with `dspy_`) are hidden from the public interface.
- **Composability** — supports copying, filtering, and conversion to/from plain dictionaries.

This document covers the `Example` primitive. For the objects that build on it, see [primitives_prediction.md](primitives_prediction.md), [primitives_module.md](primitives_module.md), and [datasets_core.md](datasets_core.md).

---

## Architecture Overview

`Example` sits at the bottom of the DSPy data hierarchy. It is the base class for `Prediction`, and it is the element type produced by `Dataset`/`DataLoader` and consumed by `Module`, `Evaluate`, and `Predict`.

```mermaid
graph TD
    subgraph "Data Producers"
        Dataset["Dataset<br/>(datasets_core)"]
        DataLoader["DataLoader<br/>(datasets_core)"]
    end

    subgraph "Primitives"
        Example["Example<br/>(this module)"]
        Prediction["Prediction<br/>(primitives_prediction)"]
    end

    subgraph "Consumers"
        Module["Module<br/>(primitives_module)"]
        Predict["Predict<br/>(predict_core)"]
        Evaluate["Evaluate<br/>(evaluate)"]
    end

    Dataset -->|creates| Example
    DataLoader -->|creates| Example
    Example -->|subclassed by| Prediction
    Example -->|inputs passed to| Module
    Module -->|forward returns| Prediction
    Predict -->|returns| Prediction
    Evaluate -->|iterates over| Example
    Evaluate -->|scores| Prediction
```

---

## Core Component: `Example`

### Internal Storage Model

`Example` does not store fields as real Python attributes. Instead, it maintains a single internal dictionary `self._store`, and intercepts attribute access through `__getattr__` / `__setattr__`.

| Attribute | Type | Purpose |
|-----------|------|---------|
| `_store` | `dict` | The backing store for all user fields and `dspy_*` metadata. |
| `_demos` | `list` | Reserved for demonstration bookkeeping (used by subclasses). |
| `_input_keys` | `set` or `None` | The set of keys designated as inputs; `None` until `with_inputs()` is called. |

The `__setattr__` override routes any key that does **not** start with `_` and is **not** a class attribute into `_store`. This is what makes `example.foo = 1` behave like `example["foo"] = 1`.

```mermaid
flowchart LR
    A["example.field = value"] --> B{"key starts with '_'<br/>or in dir(class)?"}
    B -->|Yes| C["super().__setattr__<br/>(real attribute)"]
    B -->|No| D["self._store[key] = value"]
```

### Construction

```python
Example(base=None, **kwargs)
```

The constructor accepts three mutually compatible sources, merged in order:

1. **`base` as another `Example`** — copies its `_store` (shallow copy).
2. **`base` as a `dict`** — copies the dictionary.
3. **`**kwargs`** — applied last, overriding any prior values.

```python
ex = Example(question="What is 2+2?", answer="4")
ex2 = Example(base=ex, answer="four")   # overrides answer
```

### Dictionary-Like Interface

`Example` implements the standard mapping protocol, so it can be used anywhere a dict is expected:

| Method | Behavior |
|--------|----------|
| `__getitem__` / `__setitem__` / `__delitem__` | Direct access to `_store`. |
| `__contains__` | `key in example`. |
| `__iter__` | Iterates over keys. |
| `__len__` | Counts **non-`dspy_`** keys only. |
| `keys()` / `values()` / `items()` | Return public fields; pass `include_dspy=True` to include metadata. |
| `get(key, default)` | Safe lookup. |
| `toDict()` | Returns a shallow copy of the full `_store`. |

> **Note:** `len()`, `keys()`, `values()`, and `items()` deliberately hide keys prefixed with `dspy_` (e.g., `dspy_uuid`, `dspy_split`) so that internal metadata does not pollute user-facing iteration.

### Input / Label Separation

The most important semantic feature of `Example` is the distinction between **inputs** and **labels**.

```mermaid
flowchart TD
    A["Example with fields:<br/>question, context, answer"] --> B["with_inputs('question', 'context')"]
    B --> C["New Example with<br/>_input_keys = {question, context}"]
    C --> D["inputs()"]
    C --> E["labels()"]
    D --> F["Example(question, context)"]
    E --> G["Example(answer)"]
```

- **`with_inputs(*keys)`** — returns a *copy* with `_input_keys` set to the given keys. The original is unchanged.
- **`inputs()`** — returns a new `Example` containing only the input fields. Raises `ValueError` if `with_inputs()` was never called.
- **`labels()`** — returns a new `Example` containing everything *not* in the inputs.

This separation is what allows `Module.batch()` and `Evaluate` to call `example.inputs()` and feed only the relevant fields into a program, while keeping the labels available for scoring.

### Copying and Filtering

| Method | Description |
|--------|-------------|
| `copy(**kwargs)` | Returns a new `Example` based on `self`, with optional overrides. |
| `without(*keys)` | Returns a copy with the specified keys removed. |

Both return new instances; `Example` is treated as effectively immutable in practice.

### Equality, Hashing, and Representation

- **`__eq__`** — two `Example`s are equal iff both are `Example` instances and their `_store` dicts are equal.
- **`__hash__`** — hashes the tuple of `_store` items, making examples usable as dict keys / set members.
- **`__repr__` / `__str__`** — render only public fields plus the `input_keys` set, e.g. `Example({'question': '...'}) (input_keys={'question'})`.

---

## Data Flow

The following sequence shows a typical lifecycle: a dataset produces `Example`s, a module consumes their inputs, and a `Prediction` (an `Example` subclass) is returned and scored.

```mermaid
sequenceDiagram
    participant DS as Dataset / DataLoader
    participant EX as Example
    participant MOD as Module
    participant PRED as Prediction
    participant EV as Evaluate

    DS->>EX: Example(**row).with_inputs(*input_keys)
    EV->>EX: example.inputs()
    EX-->>EV: Example(input fields only)
    EV->>MOD: program(**inputs)
    MOD->>PRED: Prediction.from_completions(...)
    PRED-->>EV: Prediction (subclass of Example)
    EV->>EV: metric(example, prediction)
```

---

## Relationship to `Prediction`

`Prediction` **inherits directly from `Example`**, reusing its storage and mapping semantics while adding:

- A `completions` property (multiple candidate outputs).
- LM usage tracking (`get_lm_usage` / `set_lm_usage`).
- Score-based comparison and arithmetic operators.

Because `Prediction` is an `Example`, any code that accepts an `Example` (metrics, evaluation tables, dataset utilities) transparently accepts a `Prediction`. See [primitives_prediction.md](primitives_prediction.md) for details.

```mermaid
classDiagram
    class Example {
        +_store: dict
        +_input_keys: set
        +with_inputs(*keys)
        +inputs()
        +labels()
        +copy(**kwargs)
        +without(*keys)
        +toDict()
    }
    class Prediction {
        +completions
        +get_lm_usage()
        +set_lm_usage(value)
        +from_completions(...)
    }
    Example <|-- Prediction
```

---

## Integration Points

| Consumer / Producer | Module | How it uses `Example` |
|---------------------|--------|-----------------------|
| `Dataset` | [datasets_core.md](datasets_core.md) | Wraps raw rows into `Example` objects, attaching `dspy_uuid` and `dspy_split` metadata, and applies `with_inputs()`. |
| `DataLoader` | [datasets_core.md](datasets_core.md) | Builds `Example`s from HuggingFace, CSV, pandas, JSON, parquet, and retrieval modules. |
| `Module` | [primitives_module.md](primitives_module.md) | `Module.batch()` calls `example.inputs()` to feed programs in parallel. |
| `Predict` | [predict_core.md](predict_core.md) | Returns a `Prediction` (an `Example`) from `_forward_postprocess`. |
| `Evaluate` | [evaluate.md](evaluate.md) | Iterates over a `devset` of `Example`s, calls `example.inputs()`, and passes `(example, prediction)` to the metric. |

---

## Summary

`Example` is the lightweight, dict-like data primitive that underpins all data handling in DSPy. Its design centers on three ideas:

1. **Flexible field storage** via `_store` with attribute-style access.
2. **Explicit input/label separation** via `with_inputs()`, `inputs()`, and `labels()`.
3. **Metadata isolation** through the `dspy_` key prefix convention.

It is subclassed by `Prediction` and serves as the common data contract between datasets, modules, predictors, and evaluators.
