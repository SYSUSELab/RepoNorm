# Adapter Types

## Overview

The **`adapter_types`** module (`dspy/adapters/types/`) defines the custom type system used by DSPy's [adapters](adapters_implementations.md) to represent rich, non-primitive values inside DSPy signatures. While standard Python types (`str`, `int`, `list`, etc.) cover most signature fields, real-world LM interactions frequently require structured, multimodal, or tool-oriented values — images, audio clips, source code, conversation history, and function-call requests.

This module provides:

- A common base class (`Type`) that all custom types inherit from, defining a uniform serialization contract.
- Concrete custom types for multimodal content (`Image`, `Audio`), code (`Code`), conversation state (`History`), and tool calling (`Tool`, `ToolCalls`).
- The machinery that lets adapters detect custom types nested arbitrarily deep inside field annotations and split them into OpenAI-compatible content blocks.

The types defined here are consumed by the adapter layer when formatting messages for the LM and when parsing LM responses back into structured outputs. For details on how adapters use these types, see [adapters_implementations.md](adapters_implementations.md).

## Architecture

The module is organized around a single inheritance root (`Type`) with specialized subclasses. The base class also hosts the annotation-introspection and message-splitting utilities that adapters rely on.

```mermaid
graph TD
    subgraph "adapter_types module"
        Type["Type<br/>(base_type.py)<br/>abstract base"]
        Image["Image<br/>(image.py)"]
        Audio["Audio<br/>(audio.py)"]
        Code["Code<br/>(code.py)"]
        Tool["Tool<br/>(tool.py)"]
        ToolCalls["ToolCalls<br/>(tool.py)"]
        History["History<br/>(history.py)<br/>standalone pydantic model"]
    end

    Type --> Image
    Type --> Audio
    Type --> Code
    Type --> Tool
    Type --> ToolCalls

    subgraph "Consumers"
        Adapter["Adapter / ChatAdapter / JSONAdapter<br/>(adapters_implementations)"]
        Signature["Signature fields<br/>(signatures)"]
    end

    Type -. "format() / serialize_model()" .-> Adapter
    Type -. "extract_custom_type_from_annotation()" .-> Adapter
    Adapter -. "split_message_content_for_custom_types()" .-> Type
    Signature -. "annotations" .-> Type
    History -. "detected via annotation" .-> Adapter
```

### Type Hierarchy and Serialization Contract

Every custom type inherits from `Type` and must implement `format()`, which returns either a string or a list of OpenAI-style content-part dictionaries. The base class wraps list results in reserved sentinel markers (`<<CUSTOM-TYPE-START-IDENTIFIER>>` / `<<CUSTOM-TYPE-END-IDENTIFIER>>`) so that adapters can later locate and split them into proper multimodal content blocks.

```mermaid
sequenceDiagram
    participant Sig as Signature Field
    participant Adapter as Adapter.format()
    participant Type as Custom Type
    participant Split as split_message_content_for_custom_types()
    participant LM as LM

    Sig->>Adapter: field value (e.g. dspy.Image)
    Adapter->>Type: serialize_model() -> format()
    Type-->>Adapter: "<<START>>[{...content parts...}]<<END>>"
    Adapter->>Split: messages with sentinel markers
    Split->>Split: regex-split around markers
    Split-->>Adapter: list of content blocks
    Adapter->>LM: OpenAI-compatible messages
```

## Sub-modules

The module is split into the following documented sub-modules:

| Sub-module | Core Components | Responsibility |
| --- | --- | --- |
| [adapter_types_base](adapter_types_base.md) | `Type` | Base class, serialization contract, annotation introspection, and custom-type message splitting. |
| [adapter_types_media](adapter_types_media.md) | `Image`, `Audio` | Multimodal content types with encoding helpers for files, URLs, PIL images, and numpy arrays. |
| [adapter_types_code](adapter_types_code.md) | `Code` | Code generation/analysis type with markdown code-block extraction and language parameterization. |
| [adapter_types_history](adapter_types_history.md) | `History` | Conversation history container used to feed multi-turn context into signatures. |
| [adapter_types_tool](adapter_types_tool.md) | `Tool`, `ToolCalls`, `ToolCalls.ToolCall` | Function-calling support: wrapping Python callables as tools and representing LM tool-call requests. |

## How the Module Fits into the System

The custom types are the bridge between DSPy's typed signatures and the raw message formats expected by language models:

- **Signatures** ([signatures.md](signatures.md)) declare fields annotated with these types (e.g. `image: dspy.Image`, `tools: list[dspy.Tool]`, `history: dspy.History`).
- **Adapters** ([adapters_implementations.md](adapters_implementations.md)) inspect those annotations via `Type.extract_custom_type_from_annotation`, format values through `format()`, and split multimodal content via `split_message_content_for_custom_types`. The `Adapter` base class specifically detects `History`, `Tool`, and `ToolCalls` annotations to drive conversation-history formatting and native function calling.
- **Clients** ([clients_core.md](clients_core.md)) receive the resulting OpenAI-compatible message payloads and forward them to providers.
- **Predict modules** ([predict_core.md](predict_core.md)) and higher-level programs (e.g. `ReAct`, `CodeAct` in [predict_advanced.md](predict_advanced.md)) use `Tool`/`ToolCalls` to implement agentic tool-calling loops.

```mermaid
graph LR
    Signature["Signature<br/>(annotations)"] --> Adapter["Adapter<br/>(format/parse)"]
    Adapter --> Types["adapter_types<br/>(Image, Audio, Code,<br/>History, Tool, ToolCalls)"]
    Types --> Adapter
    Adapter --> LM["LM / Clients"]
    LM --> Adapter
    Adapter --> Predict["Predict / Programs"]
    Tool["Tool / ToolCalls"] --> Programs["ReAct, CodeAct,<br/>Avatar"]
```

## Key Design Principles

1. **Uniform contract** — All custom types implement `format()` and inherit `serialize_model()`, so adapters can treat them polymorphically.
2. **Sentinel-based splitting** — List-returning types are wrapped in reserved markers, enabling adapters to reconstruct multimodal content blocks without knowing the concrete type.
3. **Annotation-driven detection** — `extract_custom_type_from_annotation` recursively walks nested generics (e.g. `list[dict[str, Tool]]`), so custom types work at any nesting depth.
4. **Graceful degradation** — Types like `Image` and `Audio` degrade to raw URLs or base64 when optional dependencies (Pillow, soundfile) are unavailable.
