# predict_avatar_core

## Introduction

The `predict_avatar_core` module provides the **`Avatar`** class, a DSPy module that implements an iterative, tool-using agent loop. Given a user-defined signature (a goal plus input/output fields) and a set of tools, `Avatar` repeatedly asks a language model to decide which tool to invoke next, executes that tool, feeds the result back into the conversation, and continues until the model selects the special `Finish` tool or the iteration budget is exhausted.

This module is the orchestration engine of the broader [predict_avatar](predict_avatar.md) family. It depends on the data models defined in [predict_avatar_models](predict_avatar_models.md) (`Tool`, `Action`, `ActionOutput`) and the `Actor` signature defined in [predict_avatar_signatures](predict_avatar_signatures.md).

---

## Purpose and Core Functionality

`Avatar` solves the problem of **dynamic, multi-step tool orchestration**:

- It accepts an arbitrary DSPy signature describing the task (goal + inputs/outputs).
- It augments a base `Actor` signature with the user's input fields and a growing sequence of `action_N` / `result_N` fields.
- At each iteration, the LLM produces an `Action` (a tool name + input query).
- The module executes the chosen tool, records the result, and extends the signature so the next iteration can see prior actions and results.
- The loop terminates when the model chooses the `Finish` tool, after which a final prediction is produced containing the user's declared output fields plus the full list of executed actions.

---

## Architecture

The `Avatar` class is a `dspy.Module` subclass. It composes a `TypedPredictor` over a dynamically-built `Actor` signature and a list of `Tool` objects.

```mermaid
graph TD
    User["User / Caller"] -->|"__call__ / forward(**kwargs)"| Avatar

    subgraph Avatar["Avatar (dspy.Module)"]
        Sig["signature (user-provided)"]
        ActorSig["actor_signature (Actor + user fields)"]
        Actor["actor: TypedPredictor"]
        ActorClone["actor_clone (deepcopy)"]
        Tools["tools: list[Tool]"]
        Finish["finish_tool: Tool(name='Finish')"]
    end

    Avatar --> Actor
    Actor -->|"produces Action"| Action["Action (tool_name, tool_input_query)"]
    Action -->|"tool_name != Finish"| CallTool["_call_tool()"]
    CallTool --> Tools
    CallTool -->|"tool_output"| ActionOutput["ActionOutput"]
    ActionOutput -->|"appended to args"| UpdateSig["_update_signature()"]
    UpdateSig --> ActorSig
    Action -->|"tool_name == Finish"| Final["Final Prediction"]
    Final --> Output["output_fields + actions"]

    Avatar -.->|"reset after run"| ActorClone
```

### Key Components

| Component | Role |
|-----------|------|
| `Avatar` | The module itself; owns the loop, signature mutation, and tool dispatch. |
| `Actor` (signature) | Base signature instructing the LLM to choose a tool and input query. See [predict_avatar_signatures](predict_avatar_signatures.md). |
| `Tool` | Wraps a callable tool with a name, description, and optional input type. See [predict_avatar_models](predict_avatar_models.md). |
| `Action` | Structured LLM output: `tool_name` + `tool_input_query`. See [predict_avatar_models](predict_avatar_models.md). |
| `ActionOutput` | Record of an executed action: tool name, input query, and output. See [predict_avatar_models](predict_avatar_models.md). |
| `TypedPredictor` | DSPy predictor that enforces typed output parsing for the `Actor` signature. |

---

## Component Relationships

```mermaid
classDiagram
    class Module {
        +forward()
        +__call__()
    }
    class Avatar {
        +signature
        +input_fields
        +output_fields
        +tools
        +finish_tool
        +actor_signature
        +actor
        +actor_clone
        +max_iters
        +verbose
        +_get_field(field_info)
        +_update_signature(idx, omit_action)
        +_call_tool(tool_name, tool_input_query)
        +forward(**kwargs)
    }
    class Tool {
        +tool
        +name
        +desc
        +input_type
    }
    class Action {
        +tool_name
        +tool_input_query
    }
    class ActionOutput {
        +tool_name
        +tool_input_query
        +tool_output
    }
    class Actor {
        +goal
        +tools
        +action_1
    }

    Module <|-- Avatar
    Avatar --> Tool : uses
    Avatar --> Action : parses
    Avatar --> ActionOutput : records
    Avatar --> Actor : builds signature from
```

---

## Initialization Flow

When an `Avatar` is constructed, it performs the following setup:

```mermaid
flowchart TD
    Start["Avatar(signature, tools, max_iters, verbose)"] --> Ensure["ensure_signature(signature)"]
    Ensure --> Extract["Extract input_fields & output_fields"]
    Extract --> FinishTool["Create finish_tool (name='Finish')"]
    FinishTool --> AppendTools["tools = tools + [finish_tool]"]
    AppendTools --> BaseActor["actor_signature = Actor"]
    BaseActor --> Loop{"For each input field (reversed)"}
    Loop -->|"append field"| BaseActor
    Loop -->|"done"| Predictor["actor = TypedPredictor(actor_signature)"]
    Predictor --> Clone["actor_clone = deepcopy(actor)"]
    Clone --> Done["Ready"]
```

The user's input fields are appended to the `Actor` signature in **reverse order** so that the resulting field ordering matches the original signature's declaration order.

---

## Execution / Data Flow

The `forward` method implements the core agent loop:

```mermaid
flowchart TD
    Start["forward(**kwargs)"] --> InitArgs["args = {goal, tools} + user inputs"]
    InitArgs --> Loop{"tool_name != 'Finish' AND iters remain?"}
    Loop -->|"yes"| ActorCall["actor_output = actor(**args)"]
    ActorCall --> GetAction["action = actor_output.action_{idx}"]
    GetAction --> Check{"tool_name == 'Finish'?"}
    Check -->|"no"| CallTool["tool_output = _call_tool(...)"]
    CallTool --> Record["action_results.append(ActionOutput)"]
    Record --> UpdateSig["_update_signature(idx)"]
    UpdateSig --> AddArgs["args[action_idx] = action; args[result_idx] = tool_output"]
    AddArgs --> Incr["idx += 1; max_iters -= 1"]
    Incr --> Loop
    Check -->|"yes"| Omit["_update_signature(idx, omit_action=True)"]
    Omit --> Break["args[result_idx] = 'Gathered all information...'"]
    Break --> FinalCall
    Loop -->|"no"| FinalCall["final_answer = actor(**args)"]
    FinalCall --> Reset["actor = deepcopy(actor_clone)"]
    Reset --> Return["Prediction(output_fields..., actions=action_results)"]
```

### Step-by-step

1. **Argument seeding** — `args` is initialized with `goal` (the signature docstring) and the list of tool names, then populated with any user-supplied input fields.
2. **Iteration** — The loop runs while the last chosen tool is not `Finish` and the iteration budget (`max_iters`, optionally overridden per-call via `kwargs["max_iters"]`) has not been exhausted.
3. **Action selection** — The `actor` predictor is invoked with the accumulated `args`, producing an `Action` at index `idx`.
4. **Tool dispatch** — If the tool is not `Finish`, `_call_tool` finds the matching `Tool` and calls `tool.tool.run(tool_input_query)`. The result is recorded as an `ActionOutput`.
5. **Signature growth** — `_update_signature` converts the current `action_{idx}` field into an input, appends a `result_{idx}` input field, and adds the next `action_{idx+1}` output field.
6. **Termination** — When `Finish` is selected, `_update_signature(idx, omit_action=True)` appends the user's declared output fields instead of a new action, and the loop breaks.
7. **Final prediction** — A final `actor(**args)` call produces the output fields, which are wrapped in a `dspy.Prediction` along with the `actions` history.
8. **State reset** — `self.actor` is restored from `actor_clone` so the module is reusable across calls.

---

## Signature Mutation

The `_update_signature` method is the mechanism that lets the agent "remember" prior steps. Each iteration transforms the signature:

```mermaid
graph LR
    subgraph "Iteration idx"
        A["action_idx (input)"] --> B["result_idx (input)"]
        B --> C["action_idx+1 (output)"]
    end
    subgraph "On Finish"
        D["action_idx (input)"] --> E["result_idx (input)"]
        E --> F["output_fields (output)"]
    end
```

- `action_{idx}` is converted from an output field to an input field of type `Action`.
- `result_{idx}` is appended as an input field holding the tool's output.
- Either `action_{idx+1}` (normal case) or the user's output fields (finish case) are appended as outputs.

The `_get_field` helper reconstructs `InputField`/`OutputField` objects from stored `FieldInfo` metadata (`prefix`, `desc`, `format`, `__dspy_field_type`).

---

## Dependencies

```mermaid
graph TD
    Avatar["predict_avatar_core::Avatar"]
    Avatar --> Models["predict_avatar_models<br/>Tool, Action, ActionOutput"]
    Avatar --> Signatures["predict_avatar_signatures<br/>Actor"]
    Avatar --> Module["primitives::Module"]
    Avatar --> EnsureSig["signatures::ensure_signature"]
    Avatar --> TypedPredictor["dspy.TypedPredictor"]
    Avatar --> Prediction["primitives::Prediction"]
```

| Dependency | Module Documentation | Usage |
|------------|----------------------|-------|
| `Tool`, `Action`, `ActionOutput` | [predict_avatar_models](predict_avatar_models.md) | Data models for tools and actions. |
| `Actor` | [predict_avatar_signatures](predict_avatar_signatures.md) | Base signature for the actor predictor. |
| `dspy.Module` | [primitives](primitives.md) | Base class providing `__call__`, callbacks, and history. |
| `ensure_signature` | [signatures](signatures.md) | Normalizes string/class signatures into a `Signature` type. |
| `TypedPredictor` | [predict_core](predict_core.md) | Enforces typed parsing of the `Action` output. |
| `dspy.Prediction` | [primitives](primitives.md) | Container for the final output. |

---

## Usage Example

```python
import dspy
from dspy.predict.avatar.avatar import Avatar
from dspy.predict.avatar.models import Tool

def search(query: str) -> str:
    return f"Results for: {query}"

tools = [Tool(tool=search, name="Search", desc="Search the web")]

class MySignature(dspy.Signature):
    """Answer the user's question using available tools."""
    question: str = dspy.InputField()
    answer: str = dspy.OutputField()

avatar = Avatar(MySignature, tools=tools, max_iters=3, verbose=True)
result = avatar(question="What is DSPy?")
print(result.answer)
print(result.actions)  # list of ActionOutput
```

---

## Related Modules

- [predict_avatar](predict_avatar.md) — Parent module overview.
- [predict_avatar_models](predict_avatar_models.md) — `Tool`, `Action`, `ActionOutput` definitions.
- [predict_avatar_signatures](predict_avatar_signatures.md) — The `Actor` signature.
- [teleprompt_avatar](teleprompt_avatar.md) — `AvatarOptimizer` for optimizing `Avatar` programs.
- [predict_core](predict_core.md) — `Predict`, `ChainOfThought`, and `TypedPredictor` foundations.
- [primitives](primitives.md) — `Module`, `Prediction`, and other base primitives.
