# Retrievers Core

## Introduction

The `retrievers_core` module provides the foundational retrieval abstraction for DSPy. At its heart is the `Retrieve` class, a lightweight, configurable module that acts as a **thin wrapper around a globally configured retrieval model (RM)**. Rather than implementing retrieval logic itself, `Retrieve` delegates the actual search to whatever retrieval backend is registered in `dspy.settings.rm`, normalizes the results into a `Prediction`, and exposes a consistent interface for use inside DSPy programs.

This design decouples *what* a program retrieves from *how* retrieval is performed, allowing users to swap retrieval backends (e.g., ColBERTv2, Databricks Vector Search, Weaviate, or embeddings-based retrieval) without changing their program code.

---

## Module Purpose

The core module answers a single question: **"Given a query, return the top-k relevant passages from the currently configured retrieval model."**

Key responsibilities:

1. **Backend delegation** — Route queries to the RM registered in `dspy.settings.rm`.
2. **Result normalization** — Convert heterogeneous backend outputs into a uniform `Prediction(passages=[...])` object.
3. **Configurability** — Support a default `k` (number of passages) that can be overridden per call.
4. **State management** — Provide `dump_state`/`load_state` for serialization within DSPy programs.
5. **Observability** — Integrate with DSPy's callback system for tracing and instrumentation.

---

## Architecture

The `Retrieve` class sits between DSPy programs and pluggable retrieval backends. It inherits from `Parameter` (a marker base class) and produces `Prediction` objects.

```mermaid
graph TD
    subgraph "DSPy Program"
        P[Module / Predict]
    end

    subgraph "retrievers_core"
        R[Retrieve]
    end

    subgraph "Configuration"
        S[dspy.settings]
        RM[settings.rm<br/>Retrieval Model]
    end

    subgraph "Output"
        PR[Prediction<br/>passages=list]
    end

    P -->|query, k| R
    R -->|reads| S
    S -->|provides| RM
    R -->|delegates query| RM
    RM -->|passages| R
    R -->|normalizes| PR
    PR --> P
```

### Component Relationships

`Retrieve` is the base class for several concrete retriever implementations across the `retrievers` module family. These subclasses override `forward` to implement backend-specific logic while reusing the `Retrieve` interface.

```mermaid
classDiagram
    class Parameter {
        <<marker>>
    }
    class Retrieve {
        +str name = "Search"
        +str input_variable = "query"
        +str desc
        +int k
        +list callbacks
        +str stage
        +__call__(*args, **kwargs)
        +forward(query, k, **kwargs)
        +dump_state()
        +load_state(state)
        +reset()
    }
    class DatabricksRM {
        +forward(query, query_type, filters_json)
    }
    class WeaviateRM {
        +forward(query_or_queries, k, **kwargs)
    }
    class Embeddings {
        +forward(query)
    }
    class ColBERTv2 {
        +__call__(query, k, simplify)
    }

    Parameter <|-- Retrieve
    Retrieve <|-- DatabricksRM
    Retrieve <|-- WeaviateRM
    Embeddings ..> Retrieve : produces compatible Prediction
    ColBERTv2 ..> Retrieve : usable as settings.rm
```

> **Note:** `Embeddings` and `ColBERTv2` are not strict subclasses of `Retrieve`, but they produce compatible outputs and/or serve as the `settings.rm` backend that `Retrieve` delegates to. See [retrievers_embeddings.md](retrievers_embeddings.md), [retrievers_databricks.md](retrievers_databricks.md), [retrievers_weaviate.md](retrievers_weaviate.md), and [dsp_retrieval.md](dsp_retrieval.md) for details.

---

## Core Component: `Retrieve`

### Class Attributes

| Attribute | Value | Purpose |
|-----------|-------|---------|
| `name` | `"Search"` | Human-readable name used in prompts/signatures. |
| `input_variable` | `"query"` | The name of the input field expected by the module. |
| `desc` | `"takes a search query and returns one or more potentially relevant passages from a corpus"` | Description used when embedding the retriever in a program. |

### Constructor

```python
Retrieve(k=3, callbacks=None)
```

- **`k`** (`int`, default `3`): The default number of passages to retrieve.
- **`callbacks`** (`list`, optional): Instance-level callbacks invoked around each call.
- **`stage`**: A random 8-byte hex string generated at construction, used to uniquely identify this retriever instance (e.g., for caching/tracing).

### Methods

| Method | Description |
|--------|-------------|
| `__call__(*args, **kwargs)` | Public entry point, decorated with `@with_callbacks`. Delegates to `forward`. |
| `forward(query, k=None, **kwargs)` | Core retrieval logic. Resolves `k`, validates the RM, delegates the query, and normalizes results. |
| `dump_state()` | Returns serializable state (`{"k": ...}`). |
| `load_state(state)` | Restores state from a dict. |
| `reset()` | No-op; provided for interface compatibility. |

---

## Data Flow

The following sequence diagram illustrates a single retrieval call, including callback instrumentation and result normalization.

```mermaid
sequenceDiagram
    participant Caller as DSPy Program
    participant R as Retrieve
    participant CB as Callbacks
    participant S as dspy.settings
    participant RM as settings.rm

    Caller->>R: __call__(query, k=5)
    R->>CB: on_start (via @with_callbacks)
    R->>R: forward(query, k=5)
    R->>R: k = k or self.k
    R->>S: check dspy.settings.rm
    alt No RM configured
        R-->>Caller: AssertionError("No RM is loaded.")
    else RM configured
        R->>RM: rm(query, k=k, **kwargs)
        RM-->>R: passages (iterable or single)
        R->>R: normalize to iterable
        R->>R: extract psg.long_text
        R->>R: Prediction(passages=[...])
    end
    R->>CB: on_end (via @with_callbacks)
    R-->>Caller: Prediction(passages=[...])
```

### Result Normalization Logic

The `forward` method performs several normalization steps to handle the variety of shapes a retrieval backend may return:

```mermaid
flowchart TD
    A[rm returns passages] --> B{Is it Iterable?}
    B -->|No| C[Wrap in list: passages = passages]
    B -->|Yes| D[Keep as-is]
    C --> E[Extract psg.long_text for each]
    D --> E
    E --> F[Prediction passages=list]
```

1. **Iterability check** — If the backend returns a single passage object (not iterable), it is wrapped in a list. This accommodates backends with inconsistent type signatures.
2. **Field extraction** — Each passage's `long_text` attribute is extracted, producing a flat list of strings.
3. **Prediction construction** — The list is wrapped in a `Prediction(passages=...)` object.

> **Note:** The module contains a helper `single_query_passage(passages)` that aggregates a list of passage dicts into a single `Prediction`, renaming `long_text` to `passages`. This is a utility for multi-document aggregation.

---

## Dependencies

`Retrieve` depends on several other DSPy modules. The diagram below shows the dependency graph.

```mermaid
graph LR
    subgraph "retrievers_core"
        R[Retrieve]
    end

    R -->|inherits| PARAM[predict_core<br/>Parameter]
    R -->|produces| PRED[primitives_prediction<br/>Prediction]
    R -->|decorated by| CB[utils<br/>with_callbacks]
    R -->|reads config| SET[dsp_utils_settings<br/>Settings]
    R -->|delegates to| RM[settings.rm<br/>Retrieval Model]

    PARAM -.->|documented in| P1[predict_core.md]
    PRED -.->|documented in| P2[primitives_prediction.md]
    CB -.->|documented in| P3[utils.md]
    SET -.->|documented in| P4[dsp_utils_settings.md]
```

| Dependency | Role | Reference |
|------------|------|-----------|
| `Parameter` | Marker base class for retrievable parameters. | [predict_core.md](predict_core.md) |
| `Prediction` | Output container for retrieved passages. | [primitives_prediction.md](primitives_prediction.md) |
| `with_callbacks` | Decorator adding start/end callback instrumentation. | [utils.md](utils.md) |
| `Settings` | Global/thread-local configuration holding `rm`. | [dsp_utils_settings.md](dsp_utils_settings.md) |
| `settings.rm` | The pluggable retrieval backend. | See backend docs below |

### Retrieval Backends (`settings.rm`)

The `Retrieve` module is backend-agnostic. Any callable registered as `dspy.settings.rm` that accepts `(query, k=..., **kwargs)` and returns passages with a `long_text` attribute can serve as the backend. Common backends include:

- **ColBERTv2** — HTTP-based retrieval server wrapper. See [dsp_retrieval.md](dsp_retrieval.md).
- **DatabricksRM** — Databricks Mosaic AI Vector Search. See [retrievers_databricks.md](retrievers_databricks.md).
- **WeaviateRM** — Weaviate hybrid search. See [retrievers_weaviate.md](retrievers_weaviate.md).
- **Embeddings** — Local embeddings + FAISS/brute-force search. See [retrievers_embeddings.md](retrievers_embeddings.md).

---

## Usage Patterns

### Basic Usage

```python
import dspy

# Configure a retrieval model globally
dspy.settings.configure(rm=my_retriever)

# Create a Retrieve module
retrieve = dspy.Retrieve(k=3)

# Query
result = retrieve("What is the capital of France?")
print(result.passages)  # list of passage strings
```

### Per-Call Override of `k`

```python
result = retrieve("query text", k=10)  # overrides the default k=3
```

### Inside a DSPy Program

```python
class RAG(dspy.Module):
    def __init__(self):
        super().__init__()
        self.retrieve = dspy.Retrieve(k=3)
        self.generate = dspy.ChainOfThought("context, question -> answer")

    def forward(self, question):
        context = self.retrieve(question).passages
        return self.generate(context=context, question=question)
```

---

## State Management

`Retrieve` supports serialization through `dump_state` and `load_state`, enabling it to be saved and restored as part of a larger DSPy program.

```mermaid
flowchart LR
    A[Retrieve instance] -->|dump_state| B["{'k': 3}"]
    B -->|load_state| C[Restored Retrieve]
```

Only the `k` attribute is persisted; the `stage` identifier and `callbacks` are not serialized.

---

## Callback Integration

The `__call__` method is decorated with `@with_callbacks`, which automatically:

1. Collects active callbacks from both `dspy.settings.callbacks` (global) and `self.callbacks` (instance-level).
2. Fires `on_start` handlers before `forward` executes, passing the resolved inputs.
3. Fires `on_end` handlers after execution, passing outputs and any exception.
4. Manages a call ID hierarchy via `ACTIVE_CALL_ID` for nested call tracing.

This makes every retrieval call observable without modifying the retrieval logic itself. See [utils.md](utils.md) for details on the callback system.

---

## Error Handling

| Condition | Behavior |
|-----------|----------|
| No RM configured (`dspy.settings.rm` is falsy) | Raises `AssertionError("No RM is loaded.")` |
| Backend returns non-iterable | Automatically wrapped in a list |
| Backend returns passages without `long_text` | Raises `AttributeError` during extraction |

---

## Summary

The `retrievers_core` module provides the `Retrieve` abstraction — a minimal, backend-agnostic retrieval interface. Its design philosophy is **delegation over implementation**: it relies on a globally configured retrieval model to perform the actual search, then normalizes the results into a consistent `Prediction` object. This separation of concerns allows DSPy programs to remain portable across retrieval backends while benefiting from built-in state management and callback-based observability.

For backend-specific implementations, refer to the sibling modules:
- [retrievers_embeddings.md](retrievers_embeddings.md)
- [retrievers_databricks.md](retrievers_databricks.md)
- [retrievers_weaviate.md](retrievers_weaviate.md)
- [dsp_retrieval.md](dsp_retrieval.md)
