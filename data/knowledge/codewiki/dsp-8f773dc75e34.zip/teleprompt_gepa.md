# teleprompt_gepa

## Overview

The `teleprompt_gepa` module implements **GEPA** (Genetic-Pareto), an evolutionary optimizer for DSPy programs. GEPA uses *reflection* to evolve the text components (instructions) of complex systems, rather than relying purely on reinforcement learning or gradient-based methods. It is described in the paper [GEPA: Reflective Prompt Evolution Can Outperform Reinforcement Learning](https://arxiv.org/abs/2507.19457).

The core idea is that GEPA:

1. Captures **full execution traces** of a DSPy module.
2. Identifies the sub-trace corresponding to a specific predictor.
3. **Reflects** on the predictor's behaviour (optionally guided by rich textual feedback from the user's metric) to propose a new instruction.
4. Evolves a population of candidate programs, tracking a **Pareto frontier** of validation scores.

The actual optimization engine is provided by the external [`gepa`](https://github.com/gepa-ai/gepa) package. This module provides the DSPy-side integration: a `Teleprompter` subclass (`GEPA`), a `GEPAAdapter` implementation (`DspyAdapter`), and supporting types.

GEPA can also be used as a **batch inference-time search strategy** by passing `valset=trainset, track_stats=True, track_best_outputs=True`, then reading the Pareto frontier from `optimized_program.detailed_results`.

## Architecture

The module is split into two files:

| File | Responsibility |
| --- | --- |
| `dspy/teleprompt/gepa/gepa.py` | The user-facing `GEPA` teleprompter, the `DspyGEPAResult` container, and the `GEPAFeedbackMetric` protocol. |
| `dspy/teleprompt/gepa/gepa_utils.py` | The `DspyAdapter` (bridges DSPy evaluation/tracing to the `gepa` engine), plus supporting types (`LoggerAdapter`, `PredictorFeedbackFn`, `ScoreWithFeedback`, `DSPyTrace`). |

```mermaid
graph TD
    User["User code"] -->|"GEPA(metric=...).compile(student, trainset, valset)"| GEPA

    subgraph teleprompt_gepa
        GEPA["GEPA<br/>(Teleprompter)"]
        Result["DspyGEPAResult"]
        Metric["GEPAFeedbackMetric<br/>(Protocol)"]
        Adapter["DspyAdapter<br/>(GEPAAdapter)"]
        Logger["LoggerAdapter"]
        FB["PredictorFeedbackFn<br/>(Protocol)"]
        SWF["ScoreWithFeedback"]
    end

    GEPA -->|"builds"| Adapter
    GEPA -->|"reads"| Metric
    GEPA -->|"produces"| Result
    GEPA -->|"passes"| Logger
    Adapter -->|"uses"| FB
    Adapter -->|"returns"| SWF

    GEPA -->|"optimize(...)"| GepaEngine["gepa.optimize<br/>(external package)"]
    Adapter -->|"implements"| GepaEngine

    Adapter -->|"evaluates via"| Evaluate["Evaluate"]
    Adapter -->|"traces via"| Bootstrap["bootstrap_trace_data"]
```

## Data Flow

The following diagram shows how a single GEPA optimization step flows through the module.

```mermaid
sequenceDiagram
    participant U as User
    participant G as GEPA
    participant A as DspyAdapter
    participant E as Evaluate / bootstrap_trace_data
    participant GE as gepa.optimize
    participant M as metric_fn

    U->>G: compile(student, trainset, valset)
    G->>G: resolve budget (auto / max_full_evals / max_metric_calls)
    G->>A: construct DspyAdapter(student, metric_fn, feedback_map, ...)
    G->>GE: optimize(seed_candidate, trainset, valset, adapter, ...)
    loop each candidate evaluation
        GE->>A: evaluate(batch, candidate, capture_traces)
        A->>E: run program, capture trace
        E->>M: metric(gold, pred, trace, pred_name, pred_trace)
        M-->>E: float | ScoreWithFeedback
        E-->>A: EvaluationBatch(outputs, scores, trajectories)
        A-->>GE: EvaluationBatch
    end
    loop reflection
        GE->>A: make_reflective_dataset(candidate, eval_batch, components)
        A->>M: feedback_fn(...) per predictor
        M-->>A: ScoreWithFeedback
        A-->>GE: reflective dataset
    end
    GE-->>G: GEPAResult
    G->>A: build_program(best_candidate)
    A-->>G: optimized Module
    G-->>U: optimized Module (+ detailed_results if track_stats)
```

## Sub-modules

The module is documented in two sub-modules:

- **[teleprompt_gepa_optimizer](teleprompt_gepa_optimizer.md)** — the user-facing `GEPA` teleprompter, budget configuration, the `compile` entry point, and the `DspyGEPAResult` / `GEPAFeedbackMetric` types.
- **[teleprompt_gepa_adapter](teleprompt_gepa_adapter.md)** — the `DspyAdapter` that bridges DSPy evaluation, trace capture, feedback extraction, and instruction proposal to the external `gepa` engine, along with its supporting types.

## Key Concepts

### Feedback Metric

Unlike standard DSPy metrics that return a scalar, GEPA metrics may return a `ScoreWithFeedback` (a `Prediction` with `score` and `feedback` fields). The metric is called with:

- `gold`: the gold `Example`
- `pred`: the program `Prediction`
- `trace`: the full execution trace (optional)
- `pred_name`: the name of the predictor currently being optimized (optional)
- `pred_trace`: the sub-trace for that predictor (optional)

If no feedback is returned, GEPA falls back to `f"This trajectory got a score of {score}."`.

### Budget Configuration

Exactly one of the following must be provided to `GEPA.__init__`:

- `auto`: one of `"light"`, `"medium"`, `"heavy"` (mapped to candidate counts 6/12/18 via `AUTO_RUN_SETTINGS`).
- `max_full_evals`: number of full evaluations.
- `max_metric_calls`: raw metric-call budget.

The `auto_budget` method converts `auto` into a concrete `max_metric_calls` estimate based on the number of predictors, candidates, and validation-set size.

### Pareto Tracking

GEPA maintains a Pareto frontier over validation scores. `DspyGEPAResult` exposes `val_aggregate_scores`, `val_subscores`, `per_val_instance_best_candidates`, and `best_outputs_valset` for downstream analysis.

## Related Modules

- **[teleprompt_core](teleprompt_core.md)** — the `Teleprompter` base class that `GEPA` extends.
- **[teleprompt_finetune](teleprompt_finetune.md)** — provides `bootstrap_trace_data`, `TraceData`, and `FailedPrediction`, which `DspyAdapter` reuses for trace capture.
- **[evaluate](evaluate.md)** — the `Evaluate` engine used for non-trace evaluation.
- **[primitives](primitives.md)** — `Module`, `Example`, and `Prediction` primitives used throughout.
- **[propose](propose.md)** — instruction proposal strategies (GEPA currently uses the default `gepa` proposal, with a TODO to integrate MIPROv2-style proposals).
