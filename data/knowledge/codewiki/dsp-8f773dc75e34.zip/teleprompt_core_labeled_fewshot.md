# Teleprompt Core: LabeledFewShot

## Introduction

The `teleprompt_core_labeled_fewshot` module provides the **`LabeledFewShot`** teleprompter — the simplest and most lightweight optimizer in DSPy. Unlike more sophisticated optimizers that generate or refine instructions and demonstrations through LM-driven search, `LabeledFewShot` performs a purely mechanical optimization: it selects a fixed number of labeled examples from a training set and assigns them as demonstrations (`demos`) to every predictor in a program.

This module is part of the broader [teleprompt_core](teleprompt_core.md) family of optimizers and builds directly on the abstract [`Teleprompter`](teleprompt_core_base.md) base class. It is the canonical "zero-cost" baseline against which other optimizers (e.g., `BootstrapFewShot`, `MIPROv2`) are compared.

**Key characteristics:**

- **No LM calls during compilation** — compilation is deterministic and instantaneous.
- **Demonstration-only optimization** — instructions and signatures are left untouched.
- **Deterministic sampling** — uses a fixed random seed (`0`) for reproducibility.
- **Applies uniformly** — the same set of demos is assigned to every predictor in the student program.

---

## Core Component

### `LabeledFewShot`

Located in `dspy/teleprompt/vanilla.py`, this class extends `Teleprompter` and implements the `compile` method.

```python
class LabeledFewShot(Teleprompter):
    def __init__(self, k=16):
        self.k = k

    def compile(self, student, *, trainset, sample=True):
        self.student = student.reset_copy()
        self.trainset = trainset

        if len(self.trainset) == 0:
            return self.student

        rng = random.Random(0)

        for predictor in self.student.predictors():
            if sample:
                predictor.demos = rng.sample(self.trainset, min(self.k, len(self.trainset)))
            else:
                predictor.demos = self.trainset[: min(self.k, len(self.trainset))]

        return self.student
```

#### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `k` | `int` | `16` | The maximum number of labeled examples to assign as demonstrations to each predictor. |

#### `compile` Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `student` | `Module` | — | The program to optimize. A fresh copy is created via `reset_copy()`. |
| `trainset` | `list[Example]` | — | The pool of labeled examples from which demonstrations are drawn. |
| `sample` | `bool` | `True` | If `True`, randomly sample `k` examples (seeded). If `False`, take the first `k` examples in order. |

#### Return Value

Returns a **new** `Module` instance (a reset copy of `student`) whose predictors have their `demos` attribute populated. The original `student` is not mutated.

---

## Architecture and Component Relationships

`LabeledFewShot` sits at the top of the teleprompt hierarchy as a concrete implementation of the abstract `Teleprompter` contract. It depends on the `Module` primitive to enumerate predictors and on `Example` objects as the unit of demonstration data.

```mermaid
graph TD
    Teleprompter["Teleprompter<br/>(abstract base)"] --> LabeledFewShot
    LabeledFewShot --> Module["Module<br/>(student program)"]
    Module --> Predict["Predict<br/>(predictors)"]
    Predict --> Example["Example<br/>(demos)"]
    LabeledFewShot -.->|"reads"| Trainset["trainset: list[Example]"]

    subgraph "teleprompt_core family"
        Teleprompter
        LabeledFewShot
        BootstrapFewShot["BootstrapFewShot"]
        RandomSearch["BootstrapFewShotWithRandomSearch"]
        Ensemble["Ensemble"]
        KNNFewShot["KNNFewShot"]
    end
```

### Class Hierarchy

```mermaid
classDiagram
    class Teleprompter {
        +compile(student, trainset, teacher, valset, **kwargs) Module
        +get_params() dict
    }
    class LabeledFewShot {
        +int k
        +compile(student, trainset, sample) Module
    }
    Teleprompter <|-- LabeledFewShot
```

---

## Compilation Process Flow

The `compile` method follows a simple, deterministic pipeline. Note that no language model is invoked at any point.

```mermaid
flowchart TD
    Start([compile called]) --> Reset["student.reset_copy()<br/>create fresh copy"]
    Reset --> StoreTrainset["store trainset"]
    StoreTrainset --> CheckEmpty{"len(trainset) == 0?"}
    CheckEmpty -->|Yes| ReturnEmpty["return student<br/>(no demos assigned)"]
    CheckEmpty -->|No| InitRNG["rng = random.Random(0)<br/>(fixed seed)"]
    InitRNG --> Loop["for each predictor in student.predictors()"]
    Loop --> SampleCheck{"sample == True?"}
    SampleCheck -->|Yes| RandomSample["predictor.demos =<br/>rng.sample(trainset, min(k, len))"]
    SampleCheck -->|No| Slice["predictor.demos =<br/>trainset[:min(k, len)]"]
    RandomSample --> NextPredictor{"more predictors?"}
    Slice --> NextPredictor
    NextPredictor -->|Yes| Loop
    NextPredictor -->|No| ReturnStudent["return student"]
    ReturnEmpty --> End([done])
    ReturnStudent --> End
```

### Step-by-step Description

1. **Reset copy** — `student.reset_copy()` produces a fresh, uncompiled copy of the program so the original is never mutated.
2. **Empty guard** — If the training set is empty, the reset copy is returned immediately with no demonstrations assigned.
3. **Seeded RNG** — A `random.Random(0)` instance guarantees that sampling is reproducible across runs.
4. **Predictor iteration** — `student.predictors()` yields every `Predict` instance in the program (including nested ones).
5. **Demo assignment** — For each predictor, either a random sample (`sample=True`) or the first `k` examples (`sample=False`) are assigned to `predictor.demos`. The `min(k, len(trainset))` guard prevents requesting more examples than exist.
6. **Return** — The populated student copy is returned.

---

## Data Flow

The following diagram shows how data moves through the module, from the training set to the compiled program's predictors.

```mermaid
sequenceDiagram
    participant User
    participant LFS as LabeledFewShot
    participant Student as Module (copy)
    participant Predictor as Predict

    User->>LFS: compile(student, trainset, sample=True)
    LFS->>Student: reset_copy()
    Student-->>LFS: fresh Module
    LFS->>LFS: rng = Random(0)
    loop for each predictor
        LFS->>Predictor: demos = rng.sample(trainset, k)
    end
    LFS-->>User: compiled Module
    Note over Predictor: demos used at inference time<br/>by the adapter (e.g. ChatAdapter)
```

At inference time, the assigned `demos` are consumed by the [`Predict`](predict_core_predict.md) module's `forward` method, which passes them to the configured adapter (e.g., [`ChatAdapter`](adapters_implementations.md)) to construct the prompt.

---

## Usage Example

```python
import dspy
from dspy.teleprompt import LabeledFewShot

# Configure the LM
dspy.configure(lm=dspy.LM("openai/gpt-4o-mini"))

# Define a program
program = dspy.ChainOfThought("question -> answer")

# Prepare a training set of dspy.Example objects
trainset = [
    dspy.Example(question="What is 2+2?", answer="4").with_inputs("question"),
    dspy.Example(question="What is the capital of France?", answer="Paris").with_inputs("question"),
    # ... more examples
]

# Compile with 4 demonstrations per predictor
optimizer = LabeledFewShot(k=4)
compiled_program = optimizer.compile(program, trainset=trainset, sample=True)

# Use the compiled program
result = compiled_program(question="What is 3+3?")
print(result.answer)
```

### Deterministic vs. Ordered Selection

```python
# Random sample of k examples (reproducible due to seed 0)
compiled = LabeledFewShot(k=8).compile(program, trainset=trainset, sample=True)

# Take the first k examples in order
compiled = LabeledFewShot(k=8).compile(program, trainset=trainset, sample=False)
```

---

## Design Notes and Caveats

- **Determinism**: The fixed seed `random.Random(0)` ensures that repeated compilations with the same `trainset` produce identical demo assignments. This is intentional for reproducibility but means there is no stochastic diversity across runs.
- **Uniform demos**: Every predictor receives the *same* set of demonstrations. This is appropriate for single-predictor programs but may be suboptimal for multi-predictor pipelines where different stages benefit from different examples.
- **Downstream sub-sampling**: As noted in the source, downstream code (adapters) may further sub-sample or truncate demos based on token limits or field requirements. The `k` value is therefore an upper bound, not a guarantee of how many demos appear in the final prompt.
- **No instruction optimization**: Unlike [`GroundedProposer`](propose_grounded.md)-based optimizers, `LabeledFewShot` never modifies signatures or instructions — it only populates `demos`.

---

## Relationship to Other Optimizers

`LabeledFewShot` is the foundation of the `teleprompt_core` family. Other optimizers build on the same `Teleprompter` interface but add LM-driven search:

| Optimizer | Module | Optimization Strategy |
|-----------|--------|-----------------------|
| `LabeledFewShot` | **this module** | Static demo selection (no LM calls) |
| `BootstrapFewShot` | [teleprompt_core_bootstrap](teleprompt_core_bootstrap.md) | Bootstraps demos from teacher traces |
| `BootstrapFewShotWithRandomSearch` | [teleprompt_core_random_search](teleprompt_core_random_search.md) | Random search over bootstrapped candidates |
| `Ensemble` | [teleprompt_core_ensemble](teleprompt_core_ensemble.md) | Combines multiple compiled programs |
| `KNNFewShot` | [teleprompt_core_knn_fewshot](teleprompt_core_knn_fewshot.md) | Retrieval-based demo selection per input |

```mermaid
graph LR
    Teleprompter["Teleprompter<br/>(base)"] --> LFS["LabeledFewShot<br/>(static demos)"]
    Teleprompter --> BFS["BootstrapFewShot<br/>(bootstrapped demos)"]
    BFS --> RS["BootstrapFewShotWithRandomSearch"]
    Teleprompter --> Ens["Ensemble"]
    Teleprompter --> KNN["KNNFewShot<br/>(retrieval-based)"]
    LFS -.->|"baseline for"| BFS
    LFS -.->|"baseline for"| RS
```

---

## Dependencies

| Dependency | Module | Purpose |
|------------|--------|---------|
| `Teleprompter` | [teleprompt_core_base](teleprompt_core_base.md) | Abstract base class defining the `compile` contract |
| `Module` | [primitives_module](primitives_module.md) | Student program; provides `reset_copy()` and `predictors()` |
| `Predict` | [predict_core_predict](predict_core_predict.md) | Predictors whose `demos` attribute is populated |
| `Example` | [primitives_example](primitives_example.md) | Unit of demonstration data in the training set |
| `random` | Python stdlib | Seeded sampling for reproducibility |

---

## Summary

`LabeledFewShot` is a minimal, deterministic teleprompter that assigns a fixed number of labeled examples as demonstrations to every predictor in a program. It requires no language model calls during compilation, making it fast, cheap, and fully reproducible. It serves as the baseline optimizer in the `teleprompt_core` family and is the natural starting point for understanding how DSPy optimizers manipulate program state.
