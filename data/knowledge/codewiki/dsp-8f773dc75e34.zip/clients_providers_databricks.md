# Databricks Provider

## Introduction

The `clients_providers_databricks` module implements DSPy's integration with **Databricks** for fine-tuning and deploying language models. It provides two core components:

- **`DatabricksProvider`** — a concrete [`Provider`](clients_core_provider.md) implementation that handles uploading training data to Databricks Unity Catalog, launching fine-tuning runs via the Databricks Foundation Model training API, and deploying the resulting model to a Databricks Model Serving endpoint.
- **`TrainingJobDatabricks`** — a [`TrainingJob`](clients_core_provider.md) subclass that tracks the lifecycle of a Databricks fine-tuning run.

Unlike proprietary model providers (e.g., OpenAI), Databricks is a *platform* rather than a model vendor, so this provider is **not auto-discovered** via `is_provider_model`. It must be selected explicitly when configuring fine-tuning.

> **Related documentation:** For the provider abstraction and job lifecycle, see [clients_core_provider.md](clients_core_provider.md). For the fine-tuning data formats and utilities, see [clients_finetune_utils.md](clients_finetune_utils.md). For the fine-tuning teleprompter that drives these providers, see [teleprompt_finetune.md](teleprompt_finetune.md).

---

## Architecture Overview

The Databricks provider plugs into DSPy's provider abstraction layer. It is one of several concrete providers, each targeting a different backend.

```mermaid
graph TD
    subgraph "Provider Abstraction (clients_core)"
        Provider["Provider<br/>(abstract base)"]
        TrainingJob["TrainingJob<br/>(Future subclass)"]
    end

    subgraph "Concrete Providers (clients_providers)"
        DatabricksProvider["DatabricksProvider"]
        TrainingJobDatabricks["TrainingJobDatabricks"]
        OpenAIProvider["OpenAIProvider"]
        ArborProvider["ArborProvider"]
        LocalProvider["LocalProvider"]
    end

    subgraph "Fine-tuning Utilities"
        TrainDataFormat["TrainDataFormat"]
        get_finetune_directory["get_finetune_directory()"]
    end

    subgraph "External SDKs"
        WorkspaceClient["databricks.sdk.WorkspaceClient"]
        FoundationModel["databricks.model_training.foundation_model"]
        OpenAI["openai.OpenAI client"]
    end

    Provider --> DatabricksProvider
    Provider --> OpenAIProvider
    Provider --> ArborProvider
    Provider --> LocalProvider
    TrainingJob --> TrainingJobDatabricks

    DatabricksProvider --> TrainingJobDatabricks
    DatabricksProvider --> TrainDataFormat
    DatabricksProvider --> get_finetune_directory
    DatabricksProvider --> WorkspaceClient
    DatabricksProvider --> FoundationModel
    DatabricksProvider --> OpenAI
```

---

## Component Relationships

`DatabricksProvider` is a stateless collection of static methods (with class-level configuration attributes), while `TrainingJobDatabricks` carries per-job state.

```mermaid
classDiagram
    class Provider {
        +bool finetunable
        +bool reinforceable
        +TrainingJob TrainingJob
        +is_provider_model(model) bool
        +launch(lm, launch_kwargs)
        +kill(lm, launch_kwargs)
        +finetune(job, model, train_data, train_data_format, train_kwargs) str
    }

    class TrainingJob {
        +Thread thread
        +str model
        +list train_data
        +TrainDataFormat train_data_format
        +dict train_kwargs
        +cancel()
        +status()
    }

    class DatabricksProvider {
        +bool finetunable = True
        +TrainingJobDatabricks TrainingJob
        +is_provider_model(model) bool
        +deploy_finetuned_model(model, data_format, host, token, timeout)
        +finetune(job, model, train_data, train_data_format, train_kwargs) str
        +upload_data(train_data, path, data_format) str
    }

    class TrainingJobDatabricks {
        +finetuning_run
        +bool launch_started
        +bool launch_completed
        +str endpoint_name
        +status() str
    }

    Provider <|-- DatabricksProvider
    TrainingJob <|-- TrainingJobDatabricks
    DatabricksProvider ..> TrainingJobDatabricks : creates/uses
```

---

## DatabricksProvider

`DatabricksProvider` extends [`Provider`](clients_core_provider.md) and sets `finetunable = True` with `TrainingJob = TrainingJobDatabricks`. It exposes the following key methods.

### `is_provider_model(model) -> bool`

Always returns `False`. Databricks is not a proprietary model provider, so DSPy does not auto-infer Databricks models. Users must explicitly opt into the Databricks provider.

### `finetune(job, model, train_data, train_data_format, train_kwargs) -> str`

The primary entry point invoked by the fine-tuning teleprompter. It orchestrates the full fine-tuning lifecycle:

1. **Normalize the data format** — accepts either a `TrainDataFormat` enum or the strings `"chat"` / `"completion"`.
2. **Upload training data** — requires `train_data_path` in `train_kwargs`; delegates to `upload_data`.
3. **Launch the training run** — requires `register_to` in `train_kwargs`; calls `fm.create(...)` from the Databricks Foundation Model training API.
4. **Poll until completion** — loops on `fm.get(job.run)` every 60 seconds until the status is `Completed` (or raises on `Failed`).
5. **Deploy the model** — unless `skip_deploy=True`, calls `deploy_finetuned_model` and returns the model identifier `databricks/<endpoint_name>`.

**Recognized `train_kwargs` keys:**

| Key | Required | Description |
| --- | --- | --- |
| `train_data_path` | Yes | Unity Catalog directory path where training data is uploaded. |
| `register_to` | Yes | Unity Catalog model name to register the fine-tuned model under. |
| `databricks_host` | No | Override the Databricks host (useful on Databricks-hosted runtime). |
| `databricks_token` | No | Override the Databricks token. |
| `skip_deploy` | No | If `True`, skip serving-endpoint deployment (default `False`). |
| `deploy_timeout` | No | Seconds to wait for the serving endpoint (default `900`). |

### `deploy_finetuned_model(model, data_format, databricks_host, databricks_token, deploy_timeout)`

Creates or updates a Databricks Model Serving endpoint for the fine-tuned model:

1. Resolves the latest model version via `WorkspaceClient.model_versions.list`.
2. Queries the model-optimization-info API to confirm the model is eligible for provisioned throughput and to obtain the `throughput_chunk_size`.
3. Creates a new serving endpoint (or updates the existing one) with provisioned throughput bounds.
4. Polls the endpoint using an OpenAI-compatible client until it responds, up to `deploy_timeout` seconds.

> **Note:** Databricks serving endpoint names cannot contain `.`, so the model name is sanitized by replacing `.` with `_`.

### `upload_data(train_data, databricks_unity_catalog_path, data_format) -> str`

Serializes the training data to a local JSONL file, ensures the target Unity Catalog directory exists, and uploads the file via `WorkspaceClient.files.upload`. Returns the full target path.

---

## TrainingJobDatabricks

`TrainingJobDatabricks` extends [`TrainingJob`](clients_core_provider.md) (itself a `Future`) and tracks Databricks-specific job state.

| Attribute | Description |
| --- | --- |
| `finetuning_run` | The Databricks Foundation Model run object. |
| `launch_started` | Set to `True` once deployment begins. |
| `launch_completed` | Set to `True` once deployment finishes. |
| `endpoint_name` | The sanitized serving endpoint name. |

### `status() -> str`

Retrieves the current status of the fine-tuning run via `fm.get(self.finetuning_run)`. Returns `None` if no run is associated. Requires the `databricks_genai` package.

---

## Fine-Tuning Data Flow

The following sequence diagram illustrates the end-to-end flow from training data to a deployed model.

```mermaid
sequenceDiagram
    participant TP as FinetuneTeleprompter
    participant DP as DatabricksProvider
    participant FS as Local Filesystem
    participant UC as Databricks Unity Catalog
    participant FM as Foundation Model API
    participant MS as Model Serving

    TP->>DP: finetune(job, model, train_data, format, kwargs)
    DP->>DP: Normalize train_data_format
    DP->>DP: upload_data(train_data, path, format)
    DP->>FS: _save_data_to_local_file (JSONL)
    DP->>DP: _validate_chat_data / _validate_completion_data
    DP->>UC: _create_directory_in_databricks_unity_catalog
    DP->>UC: files.upload(target_path)
    UC-->>DP: target_path
    DP->>FM: fm.create(model, train_data_path, register_to, ...)
    FM-->>DP: finetuning_run
    loop Until Completed/Failed
        DP->>FM: fm.get(job.run)
        FM-->>DP: status
    end
    alt skip_deploy = False
        DP->>MS: deploy_finetuned_model(register_to, ...)
        MS-->>DP: endpoint ready
    end
    DP-->>TP: "databricks/<endpoint_name>"
```

---

## Data Validation

Before uploading, training data is validated according to the selected `TrainDataFormat`:

```mermaid
flowchart TD
    Start[Train data item] --> Format{data_format?}
    Format -->|CHAT| ChatCheck["_validate_chat_data"]
    Format -->|COMPLETION| CompCheck["_validate_completion_data"]

    ChatCheck --> HasMessages{"has 'messages' key?"}
    HasMessages -->|No| ChatErr[ValueError]
    HasMessages -->|Yes| IsList{"messages is a list?"}
    IsList -->|No| ChatErr
    IsList -->|Yes| EachMsg{"each message has<br/>'role' and 'content'?"}
    EachMsg -->|No| ChatErr
    EachMsg -->|Yes| Valid[Write to JSONL]

    CompCheck --> HasPrompt{"has 'prompt' key?"}
    HasPrompt -->|No| CompErr[ValueError]
    HasPrompt -->|Yes| HasResp{"has 'response' or 'completion'?"}
    HasResp -->|No| CompErr
    HasResp -->|Yes| Valid
```

- **CHAT format** — each item must be a dict with a `messages` key containing a list of dicts, each with `role` and `content` keys.
- **COMPLETION format** — each item must be a dict with a `prompt` key and either a `response` or `completion` key.

---

## Helper Functions

The module includes several private helpers that support the provider:

| Function | Purpose |
| --- | --- |
| `_get_workspace_client()` | Lazily imports and instantiates `databricks.sdk.WorkspaceClient`, raising a helpful error if `databricks-sdk` is missing. |
| `_create_directory_in_databricks_unity_catalog(w, path)` | Validates the `/Volumes/<catalog>/<schema>/<volume>/...` path format, verifies the volume exists, and creates the directory if needed. |
| `_save_data_to_local_file(train_data, data_format)` | Writes validated training data to a uniquely named JSONL file in the DSPy finetune directory. |
| `_validate_chat_data(data)` | Validates chat-format training items. |
| `_validate_completion_data(data)` | Validates completion-format training items. |

---

## Dependencies

```mermaid
graph LR
    subgraph "Internal"
        provider["dspy.clients.provider"]
        utils_finetune["dspy.clients.utils_finetune"]
    end

    subgraph "External (optional)"
        databricks_sdk["databricks-sdk"]
        databricks_genai["databricks_genai"]
        openai["openai"]
    end

    subgraph "Standard/Third-party"
        requests["requests"]
        ujson["ujson"]
    end

    databricks["dspy.clients.databricks"] --> provider
    databricks --> utils_finetune
    databricks --> requests
    databricks --> ujson
    databricks -.-> databricks_sdk
    databricks -.-> databricks_genai
    databricks -.-> openai
```

### Required Packages

- `requests` — HTTP calls to the Databricks REST API.
- `ujson` — fast JSON serialization for training data.

### Optional Packages

- **`databricks-sdk`** — required for Unity Catalog uploads and model version lookups. Install via `pip install databricks-sdk`.
- **`databricks_genai`** — required for launching and monitoring fine-tuning runs. Install via `pip install databricks_genai`.
- **`openai`** — used as an OpenAI-compatible client to poll the serving endpoint during deployment.

---

## Usage Notes

- **Explicit selection required:** Because `is_provider_model` returns `False`, the Databricks provider is never auto-discovered. It must be configured explicitly in the fine-tuning workflow.
- **Unity Catalog path format:** The `train_data_path` must follow `/Volumes/<catalog>/<schema>/<volume>/...`. The volume must already exist.
- **Hosted runtime overrides:** On Databricks-hosted runtimes, `databricks_host` and `databricks_token` can be passed to override the defaults resolved from the `WorkspaceClient` config.
- **Deployment is optional:** Set `skip_deploy=True` to run fine-tuning without creating a serving endpoint (useful when the model will be deployed separately).

---

## See Also

- [clients_core_provider.md](clients_core_provider.md) — The `Provider`, `TrainingJob`, and `ReinforceJob` abstractions.
- [clients_finetune_utils.md](clients_finetune_utils.md) — `TrainDataFormat`, `get_finetune_directory`, and related utilities.
- [clients_providers_openai.md](clients_providers_openai.md) — The OpenAI provider for comparison.
- [clients_providers_arbor.md](clients_providers_arbor.md) — The Arbor provider (supports reinforcement learning).
- [clients_providers_local.md](clients_providers_local.md) — The local provider.
- [teleprompt_finetune.md](teleprompt_finetune.md) — The `BootstrapFinetune` teleprompter that drives providers.
