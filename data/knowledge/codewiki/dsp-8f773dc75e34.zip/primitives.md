# Primitives

## Overview

The **primitives** module provides the foundational data structures and base classes that underpin the entire DSPy framework. These primitives define the core abstractions for:

- **Modules** — composable, callable units of computation (the building blocks of DSPy programs).
- **Examples** — flexible, dict-like containers for inputs, labels, and metadata.
- **Predictions** — the outputs produced by modules, supporting multiple completions and score-based arithmetic.
- **Sandboxed code execution** — a secure Python interpreter for running untrusted code.

Almost every other DSPy module (predictors, optimizers, retrievers, adapters) builds on top of these primitives. Understanding them is essential to understanding how DSPy programs are structured, composed, saved, and executed.

## Architecture

The primitives module is organized around a small set of tightly related abstractions. `Module` extends `BaseModule`, `Prediction` extends `Example`, and `PythonInterpreter` stands alone as a utility for sandboxed execution.

```mermaid
graph TD
    subgraph Primitives
        BaseModule["BaseModule<br/>(base_module.py)"]
        Module["Module<br/>(module.py)"]
        ProgramMeta["ProgramMeta<br/>(metaclass)"]
        Example["Example<br/>(example.py)"]
        Prediction["Prediction<br/>(prediction.py)"]
        Completions["Completions<br/>(prediction.py)"]
        PythonInterpreter["PythonInterpreter<br/>(python_interpreter.py)"]
        InterpreterError["InterpreterError"]
    end

    ProgramMeta -.->|metaclass of| Module
    Module -->|inherits| BaseModule
    Prediction -->|inherits| Example
    Prediction -->|holds| Completions
    PythonInterpreter -->|raises| InterpreterError

    subgraph External["External Dependencies"]
        Parameter["Parameter<br/>(predict/parameter.py)"]
        Settings["Settings<br/>(dsp/utils/settings.py)"]
        Parallel["Parallel<br/>(predict/parallel.py)"]
        Callbacks["with_callbacks<br/>(utils/callback.py)"]
    end

    BaseModule -.->|discovers| Parameter
    Module -.->|uses| Settings
    Module -.->|uses| Parallel
    Module -.->|decorated by| Callbacks
```

## Core Sub-Modules

The primitives module is split into four logical sub-modules, each documented in detail:

### 1. Module System — [primitives_module.md](primitives_module.md)

The module system defines the composable building blocks of DSPy programs. It consists of:

- **`BaseModule`** — the low-level base class providing parameter discovery (`named_parameters`, `named_sub_modules`), deep-copying (`deepcopy`, `reset_copy`), and serialization (`save`, `load`, `dump_state`, `load_state`).
- **`Module`** — the user-facing base class that adds callable semantics (`__call__`, `acall`), callback integration, usage tracking, batch processing, and predictor management.
- **`ProgramMeta`** — a metaclass that guarantees every `Module` instance is properly initialized even if a subclass forgets to call `super().__init__()`.

See [primitives_module.md](primitives_module.md) for full details.

### 2. Example — [primitives_example.md](primitives_example.md)

**`Example`** is a flexible, dict-like container used throughout DSPy to represent training data, evaluation data, and intermediate values. It supports attribute and item access, input/label separation via `with_inputs()`, and metadata keys prefixed with `dspy_`.

See [primitives_example.md](primitives_example.md) for full details.

### 3. Prediction — [primitives_prediction.md](primitives_prediction.md)

**`Prediction`** extends `Example` to represent the output of a DSPy module. It adds support for multiple completions (`Completions`), LM usage tracking, and score-based arithmetic and comparison operators (useful for feedback-augmented optimization).

See [primitives_prediction.md](primitives_prediction.md) for full details.

### 4. Python Interpreter — [primitives_python_interpreter.md](primitives_python_interpreter.md)

**`PythonInterpreter`** provides a sandboxed Python execution environment powered by Deno and Pyodide. It allows DSPy programs (e.g., `ProgramOfThought`, `CodeAct`) to safely execute generated code with fine-grained control over file, environment, and network access.

See [primitives_python_interpreter.md](primitives_python_interpreter.md) for full details.

## Component Relationships

The following diagram shows how the primitives interact at runtime when a DSPy program is invoked:

```mermaid
sequenceDiagram
    participant User
    participant Module
    participant BaseModule
    participant Parallel
    participant Predict
    participant Prediction

    User->>Module: module(**inputs)
    Module->>Module: __call__ (with_callbacks)
    Module->>Module: settings.context(caller_modules)
    Module->>Module: forward(**inputs)
    Module->>Predict: predictor(**inputs)
    Predict->>Prediction: Prediction.from_completions(...)
    Predict-->>Module: Prediction
    Module-->>User: Prediction

    Note over Module,Parallel: Batch execution
    User->>Module: module.batch(examples)
    Module->>Parallel: Parallel.forward(exec_pairs)
    Parallel-->>Module: list[Prediction]
```

## How Primitives Fit Into the Broader System

The primitives module is a **foundational dependency** for nearly every other DSPy module:

| Consumer Module | Uses Primitive | Purpose |
|-----------------|----------------|---------|
| [predict_core](predict_core.md) | `Module`, `Example`, `Prediction` | `Predict` inherits from `Module` and `Parameter`; returns `Prediction` objects. |
| [predict_advanced](predict_advanced.md) | `Module`, `Prediction` | Advanced predictors (ReAct, CodeAct, etc.) compose modules and consume predictions. |
| [evaluate](evaluate.md) | `Example`, `Prediction` | Evaluation operates on `Example` datasets and `Prediction` outputs. |
| [teleprompt_core](teleprompt_core.md) | `Module`, `Example` | Optimizers compile and mutate `Module` instances using `Example` data. |
| [datasets](datasets.md) | `Example` | Datasets yield `Example` objects. |
| [signatures](signatures.md) | `Example`, `Prediction` | Signatures define the schema for `Example`/`Prediction` fields. |
| [adapters](adapters.md) | `Prediction` | Adapters produce `Completions` that become `Prediction` objects. |
| [predict_advanced_program_synthesis](predict_advanced_program_synthesis.md) | `PythonInterpreter` | `ProgramOfThought` executes generated code in the sandbox. |

## Key Design Principles

1. **Composability** — `Module` instances can be nested arbitrarily; `named_parameters` and `named_sub_modules` traverse the full tree, handling lists, tuples, and dicts.
2. **Serialization** — Modules support both state-only saving (`.json`/`.pkl`) and full-program saving (`save_program=True` via cloudpickle), with dependency-version tracking to warn on environment mismatches.
3. **Flexibility** — `Example` behaves like both a dict and an object, allowing ergonomic access patterns while preserving input/label semantics.
4. **Safety** — `PythonInterpreter` runs untrusted code in a Deno/Pyodide sandbox with explicit, opt-in permissions.
5. **Observability** — `Module.__call__` integrates callbacks and usage tracking, enabling tracing and cost accounting across the program tree.
