# Retrievers Weaviate Module

## Introduction

The `retrievers_weaviate` module provides a DSPy retrieval module (`WeaviateRM`) that integrates the [Weaviate](https://weaviate.io/) vector database as a retrieval backend. It allows DSPy programs to fetch the top-k most relevant passages for a given query (or batch of queries) using Weaviate's **hybrid search** capabilities, which combine dense vector similarity with keyword-based (BM25) matching.

This module is one of several retrieval backends available in DSPy. For an overview of the retrieval subsystem and how it fits into DSPy programs, see the [retrievers_core](retrievers_core.md) documentation. For alternative backends, see [retrievers_embeddings](retrievers_embeddings.md) and [retrievers_databricks](retrievers_databricks.md).

---

## Core Component

### `WeaviateRM`

`WeaviateRM` is a subclass of `dspy.Retrieve` (see [retrievers_core](retrievers_core.md)) that wraps a Weaviate collection and exposes it as a DSPy retrieval module.

**Key responsibilities:**

- Connect to a Weaviate collection via a Weaviate client instance.
- Support both the **v4** (`WeaviateClient`) and **v3** (`Client`) Python client APIs.
- Perform hybrid search over the collection for one or many queries.
- Optionally scope queries to a specific **tenant** (multi-tenancy support).
- Provide helper methods to read (`get_objects`) and write (`insert`) objects (v4 only).

#### Constructor

```python
WeaviateRM(
    weaviate_collection_name: str,
    weaviate_client: weaviate.WeaviateClient | weaviate.Client,
    weaviate_collection_text_key: str | None = "content",
    k: int = 3,
    tenant_id: str | None = None,
)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `weaviate_collection_name` | `str` | Name of the Weaviate collection to query. |
| `weaviate_client` | `WeaviateClient \| Client` | An initialized Weaviate client (v4 or v3). |
| `weaviate_collection_text_key` | `str \| None` | Property name holding the passage text. Defaults to `"content"`. |
| `k` | `int` | Default number of top passages to retrieve. Defaults to `3`. |
| `tenant_id` | `str \| None` | Optional tenant to scope retrieval to. |

During initialization, the module inspects the client to determine its API version:

- If the client has a `collections` attribute → treated as a **v4** `WeaviateClient`.
- If the client has a `query` attribute → treated as a **v3** `Client`.
- Otherwise, a `ValueError` is raised.

#### Methods

##### `forward(query_or_queries, k=None, **kwargs) -> Prediction`

Performs hybrid search for one or more queries and returns the retrieved passages.

- Accepts a single query string or a list of query strings.
- Empty queries are filtered out.
- `k` overrides the default `self.k` when provided.
- A `tenant_id` may be passed via `kwargs` to override the constructor value.
- Returns a list of `dotdict` objects, each with a `long_text` field containing the passage text.

The behavior differs by client version:

| Client | Search call |
|--------|-------------|
| v4 (`WeaviateClient`) | `collection.query.hybrid(query=..., limit=k, ...)` (optionally `.with_tenant(tenant)`) |
| v3 (`Client`) | `client.query.get(...).with_hybrid(...).with_limit(k).do()` (optionally `.with_tenant(tenant)`) |

##### `get_objects(num_samples, fields) -> list[dict]`

Retrieves up to `num_samples` objects from the collection using the cursor/iterator API, returning only the requested `fields`.

> **Note:** Only supported for the v4 client. Raises `ValueError` for v3.

##### `insert(new_object_properties)`

Inserts a new object into the collection with a generated UUID.

> **Note:** Only supported for the v4 client. Raises `AttributeError` for v3.

---

## Architecture

The `WeaviateRM` module sits between DSPy's retrieval abstraction layer and the external Weaviate database.

```mermaid
graph TD
    subgraph DSPy
        Retrieve["dspy.Retrieve<br/>(retrievers_core)"]
        WeaviateRM["WeaviateRM"]
        Prediction["dspy.Prediction<br/>(primitives_prediction)"]
        dotdict["dotdict<br/>(dsp_utils_helpers)"]
    end

    subgraph External
        WeaviateClient["Weaviate Client<br/>(v3 / v4)"]
        WeaviateDB[("Weaviate<br/>Collection")]
    end

    Retrieve -->|inherits| WeaviateRM
    WeaviateRM -->|returns| Prediction
    WeaviateRM -->|wraps passages in| dotdict
    WeaviateRM -->|uses| WeaviateClient
    WeaviateClient -->|queries| WeaviateDB
```

### Component Relationships

```mermaid
classDiagram
    class Retrieve {
        +int k
        +forward(query, k)
        +__call__(*args, **kwargs)
    }
    class WeaviateRM {
        -str _weaviate_collection_name
        -WeaviateClient _weaviate_client
        -Collection _weaviate_collection
        -str _weaviate_collection_text_key
        -str _tenant_id
        -str _client_type
        +forward(query_or_queries, k, **kwargs)
        +get_objects(num_samples, fields)
        +insert(new_object_properties)
    }
    class Prediction {
        +passages
    }
    class dotdict {
        +long_text
    }

    Retrieve <|-- WeaviateRM
    WeaviateRM ..> Prediction : returns
    WeaviateRM ..> dotdict : creates
```

---

## Dependencies

The module depends on the following DSPy components and external libraries:

```mermaid
graph LR
    WeaviateRM["WeaviateRM"]

    WeaviateRM --> Retrieve["dspy.Retrieve<br/>(retrievers_core)"]
    WeaviateRM --> dotdict["dspy.dsp.utils.dotdict<br/>(dsp_utils_helpers)"]
    WeaviateRM --> Prediction["dspy.primitives.prediction.Prediction<br/>(primitives_prediction)"]

    WeaviateRM -.->|optional extra| weaviate["weaviate<br/>(pip install dspy-ai[weaviate])"]
```

| Dependency | Purpose | Reference |
|------------|---------|-----------|
| `dspy.Retrieve` | Base retrieval abstraction that `WeaviateRM` extends. | [retrievers_core](retrievers_core.md) |
| `dspy.dsp.utils.dotdict` | Attribute-accessible dict used to wrap each passage. | [dsp_utils_helpers](dsp_utils_helpers.md) |
| `dspy.primitives.prediction.Prediction` | Return type of `forward`. | [primitives_prediction](primitives_prediction.md) |
| `weaviate` (external) | Weaviate Python client (v3/v4). | — |

> **Installation:** The `weaviate` package is an optional dependency. If it is not installed, importing the module raises an `ImportError` instructing the user to run `pip install dspy-ai[weaviate]`.

---

## Data Flow

The following sequence diagram illustrates a typical retrieval call from a DSPy program through `WeaviateRM` to the Weaviate database.

```mermaid
sequenceDiagram
    participant Program as DSPy Program
    participant Retrieve as dspy.Retrieve
    participant RM as WeaviateRM
    participant Client as Weaviate Client
    participant DB as Weaviate Collection

    Program->>Retrieve: __call__(query, k)
    Retrieve->>RM: forward(query, k)
    RM->>RM: normalize query to list
    loop for each query
        alt v4 client
            RM->>Client: collection.query.hybrid(query, limit=k)
        else v3 client
            RM->>Client: query.get(...).with_hybrid(...).do()
        end
        Client->>DB: hybrid search
        DB-->>Client: matching objects
        Client-->>RM: results
        RM->>RM: extract text via text_key
        RM->>RM: wrap in dotdict(long_text=...)
    end
    RM-->>Retrieve: list[dotdict]
    Retrieve->>Retrieve: extract .long_text
    Retrieve-->>Program: Prediction(passages=[...])
```

### Process Flow: `forward`

```mermaid
flowchart TD
    Start([forward called]) --> ResolveK["Resolve k = k or self.k"]
    ResolveK --> Normalize["Normalize query_or_queries to list"]
    Normalize --> Filter["Filter out empty queries"]
    Filter --> Tenant["Resolve tenant_id from kwargs or self"]
    Tenant --> Loop{"For each query"}
    Loop --> ClientType{"Client type?"}
    ClientType -->|WeaviateClient v4| V4["collection.query.hybrid(...)"]
    ClientType -->|Client v3| V3["query.get(...).with_hybrid(...).do()"]
    V4 --> Extract["Extract text via text_key"]
    V3 --> Extract
    Extract --> Wrap["Wrap in dotdict(long_text=...)"]
    Wrap --> Loop
    Loop -->|done| Return([Return passages list])
```

---

## Usage Examples

### As the default retriever

```python
import weaviate
import dspy
from dspy.retrievers.weaviate_rm import WeaviateRM

llm = dspy.Cohere(model="command-r-plus", api_key=api_key)
weaviate_client = weaviate.connect_to_local()  # or connect_to_wcs / custom / embedded
retriever_model = WeaviateRM("my_collection_name", weaviate_client=weaviate_client)
dspy.settings.configure(lm=llm, rm=retriever_model)

retrieve = dspy.Retrieve(k=1)
topK_passages = retrieve("what are the stages in planning, sanctioning and execution of public works").passages
```

### Inside a module's `forward`

```python
self.retrieve = WeaviateRM("my_collection_name", weaviate_client=weaviate_client, k=num_passages)
```

### Multi-tenancy

```python
retriever = WeaviateRM(
    "my_collection_name",
    weaviate_client=weaviate_client,
    tenant_id="tenant_a",
)
```

---

## Client Version Compatibility

| Feature | v4 (`WeaviateClient`) | v3 (`Client`) |
|---------|:---------------------:|:-------------:|
| `forward` (hybrid search) | ✅ | ✅ |
| Tenant scoping | ✅ | ✅ |
| `get_objects` | ✅ | ❌ (`ValueError`) |
| `insert` | ✅ | ❌ (`AttributeError`) |

> **Recommendation:** Use the v4 Weaviate Python client to access the full feature set, including object iteration and insertion.

---

## Related Modules

- [retrievers_core](retrievers_core.md) — Base `Retrieve` abstraction and the `dspy.Retrieve` program.
- [retrievers_embeddings](retrievers_embeddings.md) — In-memory embeddings-based retriever.
- [retrievers_databricks](retrievers_databricks.md) — Databricks Mosaic AI Vector Search retriever.
- [primitives_prediction](primitives_prediction.md) — The `Prediction` object returned by retrieval.
- [dsp_utils_helpers](dsp_utils_helpers.md) — `dotdict` and other utility helpers.
