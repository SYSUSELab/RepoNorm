# clients_finetune_utils

## Introduction

The `clients_finetune_utils` module (`dspy/clients/utils_finetune.py`) provides the shared data structures, enums, and helper utilities that underpin DSPy's fine-tuning and reinforcement-learning (GRPO) workflows. It defines the canonical data formats exchanged between DSPy teleprompters and model providers, validates that training data conforms to those formats, and manages the on-disk storage of serialized training datasets.

This module is a low-level utility layer. It does not itself perform training; instead, it is consumed by the provider implementations (see [clients_providers](clients_providers.md)) and the fine-tuning teleprompters (see [teleprompt_finetune](teleprompt_finetune.md)).

## Core Concepts

The module centers on three concerns:

1. **Data format definitions** — Enums and `TypedDict`s that describe the shape of training data (`TrainDataFormat`, `Message`, `MessageAssistant`, `GRPOChatData`).
2. **Job status tracking** — A shared `TrainingStatus` enum used by all provider-specific training jobs.
3. **Data preparation utilities** — Functions that infer the correct format from an adapter, validate data, and persist it to disk.

## Component Overview

| Component | Kind | Purpose |
|-----------|------|---------|
| `TrainingStatus` | `str, Enum` | Canonical lifecycle states for a training job. |
| `TrainDataFormat` | `str, Enum` | Supported training data layouts (`chat`, `completion`, `grpo_chat`). |
| `Message` | `TypedDict` | A single chat message with `role` and `content`. |
| `MessageAssistant` | `TypedDict` | An assistant-role message (used for GRPO completions). |
| `GRPOChatData` | `TypedDict` | One GRPO sample: messages, completion, and reward. |
| `infer_data_format` | function | Maps an `Adapter` to a `TrainDataFormat`. |
| `get_finetune_directory` | function | Resolves/creates the finetune cache directory. |
| `save_data` | function | Hashes and writes training data to a `.jsonl` file. |
| `validate_data_format` | function | Validates a dataset against a target format. |
| `find_data_error_chat` / `find_data_error_chat_message` | function | Chat-format validators. |
| `find_data_errors_completion` | function | Completion-format validator. |
| `write_lines` | function | JSONL writer helper. |

## Data Structures

### TrainingStatus

A `str`-based enum describing the lifecycle of a training job. It is shared across all provider-specific `TrainingJob` subclasses (e.g., `TrainingJobOpenAI`, `TrainingJobDatabricks`, `ArborTrainingJob`) so that callers can poll a uniform status regardless of backend.

```mermaid
stateDiagram-v2
    [*] --> not_started
    not_started --> pending
    pending --> running
    running --> succeeded
    running --> failed
    running --> cancelled
    pending --> cancelled
```

### TrainDataFormat

Enumerates the supported layouts for training data:

- `CHAT` — OpenAI-style chat data (`{"messages": [...]}`).
- `COMPLETION` — prompt/completion pairs (`{"prompt": ..., "completion": ...}`).
- `GRPO_CHAT` — grouped GRPO chat samples (a list of `GRPOChatData`).

### Message / MessageAssistant / GRPOChatData

These `TypedDict`s define the wire format for chat and GRPO data:

```python
class Message(TypedDict):
    role: Literal["user"] | Literal["assistant"] | Literal["system"]
    content: str

class MessageAssistant(TypedDict):
    role: Literal["assistant"]
    content: str

class GRPOChatData(TypedDict):
    messages: list[Message]
    completion: MessageAssistant
    reward: float
```

A `GRPOGroup` (defined as `list[GRPOChatData]`) represents a single GRPO training group — a set of candidate completions for the same prompt, each with an associated reward. This grouping is what the GRPO optimizer consumes (see [teleprompt_finetune](teleprompt_finetune.md)).

## Data Flow

The following diagram shows how data moves from a DSPy program through format inference, validation, and persistence, and finally to a provider's training job.

```mermaid
flowchart TD
    A[Adapter e.g. ChatAdapter] -->|infer_data_format| B[TrainDataFormat]
    C[Training data list] -->|validate_data_format| D{Valid?}
    D -->|No| E[Write data_format_errors.log]
    D -->|Yes| F[save_data]
    F -->|Hasher.hash| G[<hash>.jsonl in finetune dir]
    G --> H[Provider.finetune / TrainingJob]
    B --> H
    H --> I[TrainingStatus polling]
```

## Utility Functions

### infer_data_format

Maps a DSPy `Adapter` instance to the corresponding `TrainDataFormat`. Currently only `ChatAdapter` is recognized (returning `TrainDataFormat.CHAT`); any other adapter raises `ValueError`. This keeps the format decision coupled to the adapter that produced the data.

### get_finetune_directory

Resolves the directory used to store finetuned artifacts and serialized data. It honors the `DSPY_FINETUNEDIR` environment variable, falling back to `<DSPY_CACHEDIR>/finetune`, and creates the directory if it does not exist.

### save_data

Serializes a list of dictionaries to a JSONL file. The filename is derived from a content hash computed via `Hasher.hash` (see [utils](utils.md)), which provides deterministic, deduplicated storage — identical datasets map to the same file. Returns the absolute path to the written file.

### validate_data_format

Validates a dataset against a target `TrainDataFormat`. It dispatches to a format-specific error-finding function:

- `TrainDataFormat.CHAT` → `find_data_error_chat`
- `TrainDataFormat.COMPLETION` → `find_data_errors_completion`

If any records fail validation, the errors are written to `data_format_errors.log` in the finetune directory and a `ValueError` is raised pointing to that log.

### Format Validators

- **`find_data_errors_completion`** — Ensures each record is a dict with exactly the keys `prompt` and `completion`, both of type `str`.
- **`find_data_error_chat`** — Ensures each record is a dict with a single `messages` key whose value is a list; delegates per-message checks to `find_data_error_chat_message`.
- **`find_data_error_chat_message`** — Ensures each message has exactly `role` and `content` keys, that `role` is one of `assistant`/`system`/`user`, and that `content` is a `str`. (Adapted from the OpenAI chat fine-tuning data prep cookbook.)

## Relationship to Other Modules

```mermaid
flowchart LR
    subgraph clients_finetune_utils
        TS[TrainingStatus]
        TDF[TrainDataFormat]
        GCD[GRPOChatData]
    end
    TDF --> Provider[clients_core Provider / TrainingJob]
    TS --> Provider
    GCD --> Arbor[clients_providers ArborReinforceJob]
    TDF --> Tele[teleprompt_finetune GRPO / BootstrapFinetune]
    GCD --> Tele
    Adapter[adapters Adapter] --> infer[infer_data_format]
    infer --> TDF
    Hasher[utils Hasher] --> save[save_data]
```

- **[clients_core](clients_core.md)** — `Provider.finetune` and `TrainingJob` accept `TrainDataFormat` and report `TrainingStatus`. `ReinforceJob` (used by GRPO) consumes `GRPOChatData` groups.
- **[clients_providers](clients_providers.md)** — Concrete jobs such as `TrainingJobOpenAI`, `TrainingJobDatabricks`, and `ArborReinforceJob` return `TrainingStatus` values and operate on the data formats defined here.
- **[teleprompt_finetune](teleprompt_finetune.md)** — `BootstrapFinetune` and `GRPO` produce data in these formats and drive the provider jobs.
- **[adapters](adapters.md)** — `infer_data_format` inspects an `Adapter` (e.g., `ChatAdapter`) to select the format.
- **[utils](utils.md)** — `Hasher` provides the content hashing used by `save_data`.

## Usage Example

```python
from dspy.clients.utils_finetune import (
    TrainDataFormat,
    validate_data_format,
    save_data,
)

data = [
    {"messages": [
        {"role": "user", "content": "What is 2+2?"},
        {"role": "assistant", "content": "4"},
    ]},
]

validate_data_format(data, TrainDataFormat.CHAT)
path = save_data(data)  # -> /.../finetune/<hash>.jsonl
```

## Summary

`clients_finetune_utils` is the shared vocabulary for DSPy fine-tuning: it standardizes training data shapes, job statuses, and the validation/persistence pipeline that bridges adapters, teleprompters, and model providers. By centralizing these definitions, provider implementations and optimizers can interoperate without duplicating format logic.
