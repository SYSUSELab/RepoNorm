# GEPA Optimizer

## Introduction

The **GEPA Optimizer** module (`dspy/teleprompt/gepa/gepa.py`) provides DSPy's integration with **GEPA** (Genetic-Pareto), an evolutionary optimizer that uses *reflection* to evolve the text components (instructions) of complex DSPy programs. GEPA is described in the paper [GEPA: Reflective Prompt Evolution Can Outperform Reinforcement Learning](https://arxiv.org/abs/2507.19457), and the underlying optimization engine is provided by the external [`gepa`](https://github.com/gepa-ai/gepa) package.

Unlike gradient-based or purely score-based optimizers, GEPA captures **full execution traces** of a DSPy module, identifies the sub-trace corresponding to a specific predictor, and *reflects* on that predictor's behavior to propose improved instructions. Crucially, GEPA allows users to supply **natural-language feedback** (not just scalar scores) at either the predictor level or the program level, which guides the evolutionary search.

The module exposes three core components:

| Component | Role |
|-----------|------|
| `GEPA` | The teleprompter class that orchestrates optimization via `compile()`. |
| `DspyGEPAResult` | A dataclass wrapping the raw GEPA result with DSPy-native programs and Pareto statistics. |
| `GEPAFeedbackMetric` | A `Protocol` defining the signature of the user-supplied feedback metric. |

> **Related documentation:** The adapter layer that bridges DSPy programs to the GEPA engine is documented in [teleprompt_gepa_adapter.md](teleprompt_gepa_adapter.md). The base class contract is described in [teleprompt_core_base.md](teleprompt_core_base.md).

---

## Architecture Overview

GEPA sits within the broader DSPy teleprompter ecosystem. It inherits from the abstract `Teleprompter` base class and delegates the actual evolutionary search to the external `gepa.optimize` function through a DSPy-specific adapter.

```mermaid
graph TD
    subgraph "DSPy Teleprompters"
        TP[Teleprompter<br/>abstract base]
        GEPA[GEPA]
        MIPRO[MIPROv2]
        COPRO[COPRO]
        SIMBA[SIMBA]
    end

    TP --> GEPA
    TP --> MIPRO
    TP --> COPRO
    TP --> SIMBA

    subgraph "GEPA Module"
        GEPA
        RESULT[DspyGEPAResult]
        METRIC[GEPAFeedbackMetric<br/>Protocol]
    end

    subgraph "Adapter Layer"
        ADAPTER[DspyAdapter]
        LOGGER[LoggerAdapter]
        SWF[ScoreWithFeedback]
        PFF[PredictorFeedbackFn]
    end

    subgraph "External Engine"
        GEPA_PKG["gepa.optimize()"]
        GEPA_RESULT[GEPAResult]
    end

    GEPA -->|creates| ADAPTER
    GEPA -->|calls| GEPA_PKG
    GEPA -->|wraps| LOGGER
    GEPA_PKG -->|returns| GEPA_RESULT
    GEPA_RESULT -->|converted via| RESULT
    ADAPTER -->|uses| SWF
    ADAPTER -->|uses| PFF
    METRIC -->|implemented by user| GEPA
```

---

## Core Components

### `GEPA` (Teleprompter)

`GEPA` is the primary entry point. It is constructed with a user-supplied `metric` and a rich set of configuration options, then invoked via `compile()`.

#### Configuration Groups

The constructor parameters are organized into logical groups:

```mermaid
mindmap
  root((GEPA Config))
    Budget
      auto: light/medium/heavy
      max_full_evals
      max_metric_calls
    Reflection
      reflection_minibatch_size
      candidate_selection_strategy
      reflection_lm
      skip_perfect_score
      add_format_failure_as_feedback
    Merge
      use_merge
      max_merge_invocations
    Evaluation
      num_threads
      failure_score
      perfect_score
    Logging
      log_dir
      track_stats
      use_wandb
      wandb_api_key
      wandb_init_kwargs
      track_best_outputs
    Reproducibility
      seed
```

**Budget configuration** — Exactly one of `auto`, `max_full_evals`, or `max_metric_calls` must be provided (enforced by an assertion in `__init__`). The `auto` presets map to candidate counts:

| `auto` value | `n` (candidates) |
|--------------|------------------|
| `"light"` | 6 |
| `"medium"` | 12 |
| `"heavy"` | 18 |

**Reflection configuration** — Controls how GEPA reflects on predictor behavior:
- `reflection_minibatch_size` (default `3`): number of examples used per reflection step.
- `candidate_selection_strategy` (default `"pareto"`): stochastically selects candidates from the Pareto frontier; `"current_best"` is the alternative.
- `reflection_lm`: the LM used for reflection. Falls back to the student's LM, then `dspy.settings.lm`.
- `skip_perfect_score` (default `True`): skip reflection when a minibatch is already perfect.
- `add_format_failure_as_feedback` (default `False`): whether format-parse failures are surfaced as feedback.

**Merge configuration** — `use_merge` (default `True`) enables merging of successful candidates; `max_merge_invocations` (default `5`) caps merge attempts.

**Evaluation configuration** — `num_threads` for parallel evaluation, `failure_score` (default `0.0`) for failed examples, and `perfect_score` (default `1.0`) used to detect perfect minibatches.

**Logging configuration** — `log_dir` enables checkpointing and resumption (running with the same `log_dir` resumes from the last checkpoint). `track_stats` populates `detailed_results` on the optimized program. `track_best_outputs` (requires `track_stats=True`) records the best outputs per validation task.

**Reproducibility** — `seed` (default `0`) controls the RNG.

#### The `compile()` Method

`compile()` is the main optimization entry point. Its flow is:

```mermaid
flowchart TD
    A[compile student, trainset, valset] --> B{auto set?}
    B -->|yes| C[compute auto_budget]
    B -->|no| D{max_full_evals set?}
    D -->|yes| E[max_metric_calls = max_full_evals * dataset size]
    D -->|no| F[use max_metric_calls directly]
    C --> G[valset = valset or trainset]
    E --> G
    F --> G
    G --> H[create RNG from seed]
    H --> I[build feedback_map per predictor]
    I --> J[create DspyAdapter]
    J --> K[resolve reflection_lm]
    K --> L[build base_program from signatures]
    L --> M[call gepa.optimize]
    M --> N[adapter.build_program best_candidate]
    N --> O{track_stats?}
    O -->|yes| P[attach DspyGEPAResult as detailed_results]
    O -->|no| Q[return new_prog]
    P --> Q
```

Key behaviors:
- **Trainset vs. valset**: GEPA uses `trainset` for reflective updates and `valset` for tracking Pareto scores. If `valset` is omitted, `trainset` is used for both.
- **Teacher unsupported**: `teacher` must be `None`; an assertion enforces this.
- **Feedback map**: For each named predictor, a `feedback_fn` closure is created that invokes the user's `metric_fn` with the predictor name and a single-element sub-trace. If the metric returns a plain score, a default feedback string (`"This trajectory got a score of {score}."`) is synthesized.
- **Reflection LM resolution**: `reflection_lm` is resolved as `self.reflection_lm or settings.lm or student.get_lm()`.

#### `auto_budget()`

Computes a metric-call budget from the number of predictors, candidates, validation set size, and minibatch parameters. It accounts for:
- An initial full evaluation on the default program (`V` calls).
- Up to 5 bootstrapping trials per candidate.
- `N` minibatch evaluations (`N * M`).
- Periodic and final full evaluations.

### `DspyGEPAResult`

A frozen dataclass that wraps the raw `GEPAResult` from the `gepa` package, converting candidate text mappings into fully-built DSPy `Module` objects via the adapter.

| Field | Description |
|-------|-------------|
| `candidates` | List of proposed candidate programs (`Module` objects). |
| `parents` | Lineage info; `parents[i]` is a list of parent indices or `None`. |
| `val_aggregate_scores` | Per-candidate aggregate validation score (higher is better). |
| `val_subscores` | Per-candidate, per-instance validation scores. |
| `per_val_instance_best_candidates` | For each val instance, the set of candidate indices achieving the best score. |
| `discovery_eval_counts` | Budget consumed up to the discovery of each candidate. |
| `best_outputs_valset` | Optional; best outputs per validation task. |
| `total_metric_calls` | Total metric calls across the run. |
| `num_full_val_evals` | Number of full validation evaluations. |
| `log_dir` | Where artifacts were written. |
| `seed` | RNG seed for reproducibility. |

**Properties:**
- `best_idx`: index of the candidate with the highest `val_aggregate_scores`.
- `best_candidate`: the program text mapping for `best_idx`.

**Methods:**
- `to_dict()`: serializes the result (converting sets to lists) for logging/persistence.
- `from_gepa_result(gepa_result, adapter)`: classmethod that constructs a `DspyGEPAResult` from a raw `GEPAResult`, using `adapter.build_program` to materialize each candidate.

### `GEPAFeedbackMetric` (Protocol)

Defines the callable contract for the user-supplied metric. It is invoked with:

| Argument | Description |
|----------|-------------|
| `gold` | The gold `Example`. |
| `pred` | The predicted `Prediction`. |
| `trace` | Optional full execution trace of the program. |
| `pred_name` | Optional name of the predictor currently being optimized. |
| `pred_trace` | Optional sub-trace for that predictor. |

It returns either a `float` score or a `ScoreWithFeedback` object (`{'score': float, 'feedback': str}`). When feedback is omitted, GEPA synthesizes a default feedback string from the score.

---

## Data Flow

The following sequence diagram illustrates a single optimization run, from user invocation to the returned optimized program.

```mermaid
sequenceDiagram
    participant User
    participant GEPA as GEPA.compile()
    participant Adapter as DspyAdapter
    participant Engine as gepa.optimize()
    participant Metric as GEPAFeedbackMetric
    participant Result as DspyGEPAResult

    User->>GEPA: compile(student, trainset, valset)
    GEPA->>GEPA: resolve budget (auto/full_evals/metric_calls)
    GEPA->>GEPA: build feedback_map per predictor
    GEPA->>Adapter: DspyAdapter(student, metric_fn, feedback_map, ...)
    GEPA->>Engine: optimize(seed_candidate, trainset, valset, adapter, ...)
    loop Evolutionary search
        Engine->>Adapter: evaluate(batch, candidate, capture_traces)
        Adapter->>Metric: metric_fn(gold, pred, trace, pred_name, pred_trace)
        Metric-->>Adapter: score / ScoreWithFeedback
        Engine->>Adapter: make_reflective_dataset(candidate, eval_batch, components)
        Adapter-->>Engine: reflective dataset (Inputs/Outputs/Feedback)
        Engine->>Engine: reflect & propose new instructions
    end
    Engine-->>GEPA: GEPAResult
    GEPA->>Adapter: build_program(best_candidate)
    Adapter-->>GEPA: optimized Module
    alt track_stats
        GEPA->>Result: from_gepa_result(gepa_result, adapter)
        Result-->>GEPA: DspyGEPAResult
        GEPA->>GEPA: attach as new_prog.detailed_results
    end
    GEPA-->>User: optimized program
```

---

## Component Interaction

The `GEPA` class orchestrates several collaborating components. The adapter (`DspyAdapter`) is the critical bridge — it encapsulates evaluation, trace capture, feedback extraction, and instruction proposal, exposing a clean interface to the external engine.

```mermaid
classDiagram
    class Teleprompter {
        <<abstract>>
        +compile(student, trainset, teacher, valset)
        +get_params()
    }
    class GEPA {
        +metric_fn
        +auto
        +max_full_evals
        +max_metric_calls
        +reflection_minibatch_size
        +candidate_selection_strategy
        +reflection_lm
        +use_merge
        +max_merge_invocations
        +num_threads
        +failure_score
        +perfect_score
        +log_dir
        +track_stats
        +seed
        +auto_budget(...)
        +compile(student, trainset, teacher, valset)
    }
    class DspyGEPAResult {
        +candidates
        +parents
        +val_aggregate_scores
        +best_idx
        +best_candidate
        +to_dict()
        +from_gepa_result(...)
    }
    class GEPAFeedbackMetric {
        <<protocol>>
        +__call__(gold, pred, trace, pred_name, pred_trace)
    }
    class DspyAdapter {
        +build_program(candidate)
        +evaluate(batch, candidate, capture_traces)
        +make_reflective_dataset(...)
    }
    class LoggerAdapter {
        +log(x)
    }

    Teleprompter <|-- GEPA
    GEPA ..> GEPAFeedbackMetric : uses
    GEPA ..> DspyAdapter : creates
    GEPA ..> LoggerAdapter : wraps
    GEPA ..> DspyGEPAResult : produces
    DspyGEPAResult ..> DspyAdapter : uses build_program
```

---

## Dependencies

```mermaid
graph LR
    GEPA[GEPA] --> Teleprompter[Teleprompter base]
    GEPA --> DspyAdapter[DspyAdapter]
    GEPA --> LoggerAdapter[LoggerAdapter]
    GEPA --> ScoreWithFeedback[ScoreWithFeedback]
    GEPA --> PredictorFeedbackFn[PredictorFeedbackFn]
    GEPA --> DspyGEPAResult[DspyGEPAResult]
    GEPA --> gepa_pkg["gepa.optimize / GEPAResult"]
    GEPA --> LM[LM]
    GEPA --> settings[settings]
    GEPA --> Module[Module]
    GEPA --> Example[Example]
    GEPA --> Prediction[Prediction]
    DspyAdapter --> Evaluate[Evaluate]
    DspyAdapter --> bootstrap_trace_data[bootstrap_trace_data]
    DspyAdapter --> ChatAdapter[ChatAdapter]
    DspyAdapter --> History[History]
```

| Dependency | Purpose |
|------------|---------|
| `gepa.optimize`, `gepa.GEPAResult` | External evolutionary optimization engine. |
| `Teleprompter` | Abstract base class ([teleprompt_core_base.md](teleprompt_core_base.md)). |
| `DspyAdapter`, `LoggerAdapter`, `ScoreWithFeedback`, `PredictorFeedbackFn` | Adapter layer ([teleprompt_gepa_adapter.md](teleprompt_gepa_adapter.md)). |
| `LM`, `settings` | Language model resolution for reflection ([clients_core_lm.md](clients_core_lm.md), [dsp_utils_settings.md](dsp_utils_settings.md)). |
| `Module`, `Example`, `Prediction` | Core DSPy primitives ([primitives_module.md](primitives_module.md), [primitives_example.md](primitives_example.md), [primitives_prediction.md](primitives_prediction.md)). |
| `Evaluate` | Used by the adapter for non-trace evaluation ([evaluate_evaluation_engine.md](evaluate_evaluation_engine.md)). |
| `bootstrap_trace_data` | Used by the adapter for trace-capturing evaluation ([teleprompt_finetune.md](teleprompt_finetune.md)). |

---

## Usage Patterns

### Standard Optimization

```python
import dspy

def metric(gold, pred, trace=None, pred_name=None, pred_trace=None):
    correct = pred.answer == gold.answer
    score = 1.0 if correct else 0.0
    feedback = "Correct!" if correct else "The answer was wrong; reconsider the reasoning."
    return dspy.Prediction(score=score, feedback=feedback)

gepa = dspy.GEPA(metric=metric, auto="light", track_stats=True)
optimized = gepa.compile(student=program, trainset=trainset, valset=valset)
```

### Batch Inference-Time Search

GEPA can also be used as an inference-time search strategy by passing the batch as the `valset` and enabling `track_best_outputs`:

```python
gepa = dspy.GEPA(metric=metric, track_stats=True, track_best_outputs=True)
batch_of_tasks = [dspy.Example(...) for task in tasks]
new_prog = gepa.compile(student, trainset=trainset, valset=batch_of_tasks)
pareto_frontier = new_prog.detailed_results.val_aggregate_scores
best_outputs = new_prog.detailed_results.best_outputs_valset
```

---

## Design Notes & Constraints

- **Exactly one budget mode**: The constructor asserts that exactly one of `auto`, `max_full_evals`, or `max_metric_calls` is set.
- **`track_best_outputs` requires `track_stats`**: Enforced by an assertion.
- **No teacher support**: `compile()` asserts `teacher is None`.
- **Score consistency**: The adapter asserts that feedback functions return the same score as the module-level score (see [teleprompt_gepa_adapter.md](teleprompt_gepa_adapter.md)).
- **Checkpointing**: Reusing the same `log_dir` resumes a run from its last checkpoint.
- **Reproducibility**: A `seed` (default `0`) drives a `random.Random` instance passed to the adapter and the engine.
