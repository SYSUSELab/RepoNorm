# Teleprompt Finetune Bootstrap

## Introduction

The `teleprompt_finetune_bootstrap` module implements **`BootstrapFinetune`**, a DSPy teleprompter (optimizer) that improves a student program by **fine-tuning the underlying language models (LMs)** rather than (or in addition to) optimizing prompts. It works by:

1. **Bootstrapping trace data** — running a teacher program (or the student itself) over a training set to collect input/output traces for each predictor.
2. **Preparing fine-tuning datasets** — converting the collected traces into adapter-specific training data (e.g., chat-format messages).
3. **Launching fine-tuning jobs** — invoking `LM.finetune()` for each unique LM (or LM × predictor combination) and waiting for the resulting fine-tuned models.
4. **Updating the student program** — replacing each predictor's LM with its fine-tuned counterpart.

The module also provides the shared base class **`FinetuneTeleprompter`** and the reusable **`bootstrap_trace_data`** utility, both of which are consumed by sibling optimizers such as [GRPO](teleprompt_finetune_grpo.md) and [BetterTogether](teleprompt_finetune_bettertogether.md).

---

## Module Architecture

The module is centered on a small class hierarchy rooted in the abstract `Teleprompter` base class (see [teleprompt_core](teleprompt_core.md)).

```mermaid
classDiagram
    class Teleprompter {
        <<abstract>>
        +compile(student, trainset, teacher, valset)
        +get_params()
    }
    class FinetuneTeleprompter {
        +train_kwargs: dict[LM, Any]
        +convert_to_lm_dict(arg)$
    }
    class BootstrapFinetune {
        +metric: Callable
        +multitask: bool
        +adapter: dict[LM, Adapter]
        +exclude_demos: bool
        +num_threads: int
        +compile(student, trainset, teacher)
        +finetune_lms(finetune_dict)$
        +_prepare_finetune_data(trace_data, lm, pred_ind)
    }
    class FailedPrediction {
        +completion_text: str
        +format_reward: float
    }
    class TraceData {
        <<TypedDict>>
        +example_ind: int
        +example: Example
        +prediction: Prediction
        +trace: list
        +score: float
    }

    Teleprompter <|-- FinetuneTeleprompter
    FinetuneTeleprompter <|-- BootstrapFinetune
    BootstrapFinetune ..> FailedPrediction : produces
    BootstrapFinetune ..> TraceData : consumes
```

### Core Components

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `FinetuneTeleprompter` | Class | Base class for fine-tuning-based optimizers. Normalizes `train_kwargs` into a per-LM dictionary. |
| `BootstrapFinetune` | Class | The main optimizer. Bootstraps traces, prepares data, launches fine-tuning jobs, and updates the student. |
| `FailedPrediction` | Dataclass | Represents an LM response that failed adapter parsing, carrying a `format_reward` used for scoring. |
| `TraceData` | TypedDict | Schema for a single bootstrapped example: the example, prediction, per-predictor trace, and optional score. |

---

## Component Relationships and Dependencies

`BootstrapFinetune` orchestrates several subsystems of DSPy. The diagram below shows the primary dependencies.

```mermaid
graph TD
    BF[BootstrapFinetune] --> FT[FinetuneTeleprompter]
    BF --> BTD[bootstrap_trace_data]
    BF --> EV[Evaluate]
    BF --> LM[LM.finetune]
    BF --> AD[Adapter.format_finetune_data]
    BF --> IDF[infer_data_format]

    BTD --> EV
    BTD --> FP[FailedPrediction]
    BTD --> APE[AdapterParseError]

    LM --> PR[Provider / TrainingJob]
    AD --> CA[ChatAdapter]
    IDF --> TDF[TrainDataFormat]

    subgraph "Sibling Optimizers"
        GRPO[GRPO]
        BT[BetterTogether]
    end
    GRPO --> FT
    GRPO --> BTD
    BT --> BF
```

### External Dependencies

- **[clients_core](clients_core.md)** — `LM` (the `finetune`, `kill`, `launch` methods), `Provider`, and `TrainingJob` provide the fine-tuning backend.
- **[clients_finetune_utils](clients_finetune_utils.md)** — `infer_data_format` and `TrainDataFormat` determine the training data format.
- **[adapters](adapters.md)** — `Adapter.format_finetune_data` converts traces into training records; `ChatAdapter` is the default.
- **[evaluate](evaluate.md)** — `Evaluate` runs the teacher program over the dataset and applies the metric.
- **[primitives](primitives.md)** — `Module`, `Example`, and `Prediction` are the data structures flowing through the pipeline.
- **[utils](utils.md)** — `AdapterParseError` is caught to handle malformed LM responses.

---

## The `BootstrapFinetune.compile` Workflow

The `compile` method is the heart of the module. It proceeds through five distinct phases.

```mermaid
flowchart TD
    A[Start compile] --> B[Validate: all predictors have LMs]
    B --> C[Prepare teachers]
    C --> D[Bootstrap trace data for each teacher]
    D --> E[Prepare train data per LM/predictor]
    E --> F{num jobs > num_threads?}
    F -->|Yes| G[Raise ValueError]
    F -->|No| H[finetune_lms: launch jobs]
    H --> I[Wait for job results]
    I --> J[Update student predictors with fine-tuned LMs]
    J --> K[Optionally clear demos]
    K --> L[Mark student._compiled = True]
    L --> M[Return student]
```

### Phase 1 — Preparation

- `all_predictors_have_lms(student)` verifies every predictor has an LM assigned.
- Teachers are normalized to a list and passed through `prepare_teacher`, which:
  - Asserts **structural equivalency** between student and teacher (`assert_structural_equivalency`).
  - Asserts the two programs **do not share predictors** (`assert_no_shared_predictor`).
  - If no teacher is provided, the student itself is used as the teacher.

### Phase 2 — Bootstrapping Trace Data

For each teacher, `bootstrap_trace_data` runs the program over the training set and collects traces. See [Bootstrapping Trace Data](#bootstrapping-trace-data) below.

### Phase 3 — Preparing Train Data

For each predictor in the student, a **training key** `(pred.lm, data_pred_ind)` is computed:

- When `multitask=True`, `data_pred_ind` is `None`, so all predictors sharing an LM share one dataset.
- When `multitask=False`, `data_pred_ind` is the predictor index, producing one dataset per predictor.

`_prepare_finetune_data` filters traces by metric score, builds call data via `build_call_data_from_trace`, and shuffles deterministically with `random.Random(0)`.

### Phase 4 — Fine-Tuning Jobs

`finetune_lms` launches one job per training key:

1. Calls `lm.kill()` to free resources before fine-tuning.
2. Calls `lm.finetune(**finetune_kwargs)`, returning a `TrainingJob`.
3. Blocks on `job.result()` for each job and joins its thread.

A guard raises `ValueError` if the number of jobs exceeds `num_threads`.

### Phase 5 — Updating the Student

Each predictor's `lm` is replaced with the fine-tuned LM. If `exclude_demos=True`, the predictor's demos are cleared. Finally, `student._compiled` is set to `True`.

---

## Bootstrapping Trace Data

`bootstrap_trace_data` is a module-level utility (also reused by [GRPO](teleprompt_finetune_grpo.md)) that evaluates a program and captures per-predictor traces.

```mermaid
sequenceDiagram
    participant Caller
    participant BTD as bootstrap_trace_data
    participant Eval as Evaluate
    participant Prog as wrapped_program
    participant Ctx as dspy.context(trace=[])

    Caller->>BTD: program, dataset, metric
    BTD->>Eval: create evaluator
    BTD->>Eval: run wrapped_program with wrapped_metric
    loop each example
        Eval->>Prog: program(**kwargs)
        Prog->>Ctx: enter trace context
        Ctx-->>Prog: prediction + trace
        alt AdapterParseError
            Prog->>Prog: build FailedPrediction
            Prog-->>Eval: failed_pred + trace
        else success
            Prog-->>Eval: prediction + trace
        end
        Eval->>Eval: wrapped_metric scores result
    end
    Eval-->>BTD: results
    BTD-->>Caller: list[TraceData]
```

### Key Behaviors

- **Trace capture**: Uses `dspy.context(trace=[])` so each program invocation records a list of `(predictor, inputs, prediction)` tuples.
- **Format failure handling**: When an `AdapterParseError` is raised, the function locates the failing predictor by signature, constructs a `FailedPrediction` with a `format_reward` interpolated between `format_failure_score` and `failure_score` based on how many output fields were present, and appends it to the trace.
- **Metric wrapping**: `wrapped_metric` returns the `format_reward` for failed predictions, otherwise delegates to the user metric (or `True` if no metric).
- **Error tolerance**: `raise_on_error` controls whether unpacking failures abort the run or are skipped.

### `TraceData` Schema

| Field | Type | Description |
|-------|------|-------------|
| `example_ind` | `int` | Index of the example in the dataset. |
| `example` | `Example` | The original input example. |
| `prediction` | `Prediction` | The program's output. |
| `trace` | `list[tuple]` | Per-invocation `(predictor, inputs, prediction)` tuples. |
| `score` | `float \| None` | Metric score (present only when a metric is supplied). |

---

## Helper Functions

The module exposes several module-level helpers used for program preparation and LM lifecycle management.

| Function | Purpose |
|----------|---------|
| `build_call_data_from_trace(trace, pred_ind, adapter, exclude_demos)` | Extracts a single predictor's call data and formats it via `adapter.format_finetune_data`. |
| `all_predictors_have_lms(program)` | Returns `True` if every predictor has an LM. |
| `copy_program_with_lms(program)` | Deep-copies a program while preserving predictor LMs. |
| `prepare_student(student)` | Validates the student is not already compiled. |
| `prepare_teacher(student, teacher)` | Validates structural equivalency and predictor independence. |
| `assert_structural_equivalency(p1, p2)` | Asserts matching predictor counts and names. |
| `assert_no_shared_predictor(p1, p2)` | Asserts the two programs share no predictor instances. |
| `get_unique_lms(program)` | Returns the set of distinct LMs used by a program. |
| `launch_lms(program)` / `kill_lms(program)` | Launch/kill all unique LMs (used by [BetterTogether](teleprompt_finetune_bettertogether.md)). |

---

## Data Flow Overview

```mermaid
flowchart LR
    TS[Trainset: list of Example] --> BTD[bootstrap_trace_data]
    Teacher[Teacher Program] --> BTD
    BTD --> TD[TraceData list]
    TD --> PFD[_prepare_finetune_data]
    Metric[Metric] --> PFD
    PFD --> CD[Call data + data format]
    CD --> FL[finetune_lms]
    LM[LM.finetune] --> FL
    FL --> FTLM[Fine-tuned LMs]
    FTLM --> Student[Updated Student Program]
```

---

## Configuration Parameters

### `BootstrapFinetune.__init__`

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `metric` | `Callable \| None` | `None` | Scores traces; used to filter training data. |
| `multitask` | `bool` | `True` | If `True`, predictors sharing an LM share one dataset; if `False`, one dataset per predictor. |
| `train_kwargs` | `dict` | `None` | Fine-tuning hyperparameters, either global or keyed by `LM`. |
| `adapter` | `Adapter \| dict[LM, Adapter]` | `None` | Adapter used to format training data; defaults to `ChatAdapter`. |
| `exclude_demos` | `bool` | `False` | Whether to clear predictor demos after fine-tuning. |
| `num_threads` | `int \| None` | `None` | Max concurrent fine-tuning jobs; defaults to `dspy.settings.num_threads`. |

### `FinetuneTeleprompter.convert_to_lm_dict`

Normalizes the `train_kwargs`/`adapter` argument into a `dict[LM, Any]`. If the argument is already keyed by `LM`, it is returned as-is; otherwise a `defaultdict` returns the same value for every LM.

---

## Relationship to Sibling Optimizers

The `teleprompt_finetune` package contains three optimizers that build on this module:

- **[GRPO](teleprompt_finetune_grpo.md)** — Subclasses `FinetuneTeleprompter` and reuses `bootstrap_trace_data` and `FailedPrediction` for reinforcement-learning-based optimization.
- **[BetterTogether](teleprompt_finetune_bettertogether.md)** — Composes `BootstrapFinetune` (as the weight optimizer) with a prompt optimizer, alternating between prompt and weight optimization strategies.

```mermaid
graph LR
    FT[FinetuneTeleprompter] --> BF[BootstrapFinetune]
    FT --> GRPO[GRPO]
    BF --> BT[BetterTogether]
    BTD[bootstrap_trace_data] --> BF
    BTD --> GRPO
```

---

## Notes and Limitations

- **Thread budget**: The number of fine-tuning jobs must not exceed `num_threads`, otherwise `compile` raises a `ValueError`.
- **LM resource management**: `finetune_lms` calls `lm.kill()` before fine-tuning to free resources — a documented "hack" that may be replaced by a dedicated provider method.
- **Adapter support**: `infer_data_format` currently only supports `ChatAdapter`; other adapters raise a `ValueError`.
- **Determinism**: Training data is shuffled with a fixed seed (`random.Random(0)`) for reproducibility.
- **In-place vs. new LMs**: `BootstrapFinetune` creates new LM instances post-training, whereas [GRPO](teleprompt_finetune_grpo.md) updates LMs in place — an inconsistency noted in the code.
