# Utils Logging Module

## Introduction

The `utils_logging` module provides DSPy's centralized event-logging infrastructure. It defines a single, globally-shared logging stream (`DSPyLoggingStream`) that wraps `sys.stderr` and can be toggled on or off at runtime. This stream is used by event-logging APIs throughout DSPy (such as `eprint()` and `logger.info()`) to emit diagnostic and progress information without interfering with normal program output.

The module's primary responsibilities are:

- **Stream redirection**: Forward `write()` and `flush()` calls to whatever `sys.stderr` currently refers to, so logging respects runtime redirection (e.g., notebooks, test harnesses).
- **Global silencing**: Allow users to disable or re-enable all DSPy event logs via `disable_logging()` / `enable_logging()`.
- **Logger configuration**: Attach a consistently-formatted handler to the root DSPy logger via `configure_dspy_loggers()`.

> **Note:** This module handles *event logging* (human-readable diagnostics). For structured usage/token accounting, see [utils_usage_tracking](utils_usage_tracking.md). For programmatic lifecycle hooks, see [utils_callbacks](utils_callbacks.md).

---

## Architecture

The module is intentionally small and self-contained. It exposes one class and three module-level functions, plus a shared singleton stream instance.

```mermaid
graph TD
    subgraph "utils_logging module"
        DLS["DSPyLoggingStream<br/>(class)"]
        INST["DSPY_LOGGING_STREAM<br/>(singleton instance)"]
        DIS["disable_logging()"]
        ENA["enable_logging()"]
        CFG["configure_dspy_loggers()"]
    end

    DLS -->|instantiated as| INST
    DIS -->|sets enabled=False| INST
    ENA -->|sets enabled=True| INST
    CFG -->|StreamHandler(stream=)| INST

    INST -->|write/flush| STDERR["sys.stderr"]
    CFG -->|attaches handler to| LOGGER["logging.getLogger(root_module_name)"]

    style INST fill:#f9f,stroke:#333
    style STDERR fill:#bbf,stroke:#333
    style LOGGER fill:#bbf,stroke:#333
```

### Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| Wraps `sys.stderr` dynamically (looked up at call time) | Respects runtime redirection of `sys.stderr` (e.g., `contextlib.redirect_stderr`, notebook capture). |
| Single global singleton (`DSPY_LOGGING_STREAM`) | Provides one consistent toggle point for all DSPy event logs. |
| `enabled` property with setter | Clean, Pythonic API for toggling; used by `disable_logging()` / `enable_logging()`. |
| Handler identified by name (`dspy_handler`) | Enables idempotent re-configuration without duplicating handlers. |

---

## Core Components

### `DSPyLoggingStream`

A stream-like object that forwards `write()` and `flush()` to `sys.stderr` **at the time of the call**, gated by an internal `_enabled` flag.

```python
class DSPyLoggingStream:
    def __init__(self):
        self._enabled = True

    def write(self, text):
        if self._enabled:
            sys.stderr.write(text)

    def flush(self):
        if self._enabled:
            sys.stderr.flush()

    @property
    def enabled(self):
        return self._enabled

    @enabled.setter
    def enabled(self, value):
        self._enabled = value
```

**Behavior:**

- When `enabled` is `True` (default), `write()` and `flush()` delegate to the *current* `sys.stderr`.
- When `enabled` is `False`, both methods become no-ops, silently discarding output.

**Why dynamic `sys.stderr` lookup matters:** Because the stream resolves `sys.stderr` on every call rather than caching it at construction, it remains compatible with tools that swap out `sys.stderr` mid-execution.

### Module-Level Functions

#### `disable_logging()`

Sets `DSPY_LOGGING_STREAM.enabled = False`, silencing all subsequent DSPy event logs.

#### `enable_logging()`

Sets `DSPY_LOGGING_STREAM.enabled = True`, reversing the effect of `disable_logging()`.

#### `configure_dspy_loggers(root_module_name)`

Configures the Python `logging` subsystem for a given root module (typically `"dspy"`):

1. Creates a `logging.Formatter` using the module constants `LOGGING_LINE_FORMAT` and `LOGGING_DATETIME_FORMAT`.
2. Creates a `logging.StreamHandler` bound to `DSPY_LOGGING_STREAM` (so it respects the enable/disable toggle).
3. Names the handler `"dspy_handler"` and removes any pre-existing handler with the same name (idempotency).
4. Sets the logger level to `INFO` and disables propagation to avoid duplicate output.
5. Attaches the handler.

**Format constants:**

```python
LOGGING_LINE_FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"
LOGGING_DATETIME_FORMAT = "%Y/%m/%d %H:%M:%S"
```

Example output line:

```
2024/01/15 13:45:02 INFO dspy.predict.predict: Calling LM...
```

---

## Data Flow

The following diagram shows how a log message travels from a DSPy component through the logging stack to the terminal.

```mermaid
sequenceDiagram
    participant Comp as DSPy Component<br/>(e.g., Predict)
    participant Logger as logging.getLogger("dspy")
    participant Handler as StreamHandler<br/>(dspy_handler)
    participant Stream as DSPY_LOGGING_STREAM
    participant Stderr as sys.stderr

    Comp->>Logger: logger.info("message")
    Logger->>Handler: emit(record)
    Handler->>Handler: format(record)
    Handler->>Stream: write(formatted_text)
    alt enabled == True
        Stream->>Stderr: sys.stderr.write(text)
    else enabled == False
        Stream-->>Stream: no-op (discarded)
    end
    Handler->>Stream: flush()
    Stream->>Stderr: sys.stderr.flush()
```

---

## Component Interaction

The logging stream integrates with the broader DSPy utility ecosystem. The diagram below shows how it relates to sibling utility modules.

```mermaid
graph LR
    subgraph "utils_logging"
        DLS[DSPyLoggingStream]
        CFG[configure_dspy_loggers]
    end

    subgraph "Sibling utilities"
        CB[utils_callbacks<br/>BaseCallback]
        UT[utils_usage_tracking<br/>UsageTracker]
        PAR[utils_concurrency<br/>ParallelExecutor]
    end

    CFG -.->|configures logger used by| CB
    CFG -.->|configures logger used by| UT
    CFG -.->|configures logger used by| PAR
    PAR -->|logger.error on failures| DLS

    style DLS fill:#f9f,stroke:#333
```

- **utils_callbacks**: Callback handlers frequently emit diagnostic messages via the configured logger.
- **utils_usage_tracking**: Usage accounting may log summaries through the same stream.
- **utils_concurrency**: `ParallelExecutor` logs errors (e.g., `logger.error(...)`) that flow through this stream, and its progress bar writes to `sys.stdout` separately.

---

## Process Flow: Enabling and Disabling Logging

```mermaid
flowchart TD
    START([Application start]) --> INIT["DSPY_LOGGING_STREAM created<br/>enabled = True"]
    INIT --> CONF["configure_dspy_loggers('dspy')<br/>attaches dspy_handler"]
    CONF --> RUN{User action}
    RUN -->|disable_logging| OFF["enabled = False<br/>logs silenced"]
    RUN -->|enable_logging| ON["enabled = True<br/>logs emitted"]
    OFF --> RUN
    ON --> RUN
    RUN -->|log emitted| CHECK{enabled?}
    CHECK -->|True| WRITE["sys.stderr.write(text)"]
    CHECK -->|False| DROP["discard"]
```

---

## Usage Examples

### Silencing DSPy logs

```python
from dspy.utils.logging_utils import disable_logging, enable_logging

disable_logging()   # All subsequent DSPy event logs are silenced
# ... run noisy operations ...
enable_logging()    # Logs resume
```

### Configuring loggers for a root module

```python
from dspy.utils.logging_utils import configure_dspy_loggers

configure_dspy_loggers("dspy")
```

### Toggling the stream directly

```python
from dspy.utils.logging_utils import DSPY_LOGGING_STREAM

DSPY_LOGGING_STREAM.enabled = False  # equivalent to disable_logging()
DSPY_LOGGING_STREAM.enabled = True   # equivalent to enable_logging()
```

---

## API Reference Summary

| Symbol | Type | Description |
|--------|------|-------------|
| `DSPyLoggingStream` | class | Stream wrapper around `sys.stderr` with an `enabled` toggle. |
| `DSPY_LOGGING_STREAM` | instance | The global singleton `DSPyLoggingStream` used throughout DSPy. |
| `disable_logging()` | function | Silences all DSPy event logs. |
| `enable_logging()` | function | Re-enables DSPy event logs. |
| `configure_dspy_loggers(root_module_name)` | function | Attaches a formatted handler to the named root logger. |
| `LOGGING_LINE_FORMAT` | constant | Log line format string. |
| `LOGGING_DATETIME_FORMAT` | constant | Timestamp format string. |

---

## Related Modules

- [utils_callbacks](utils_callbacks.md) — Lifecycle callback handlers that emit diagnostics through this logging stream.
- [utils_usage_tracking](utils_usage_tracking.md) — Token/usage accounting, complementary to event logging.
- [utils_concurrency](utils_concurrency.md) — Parallel execution utilities that log errors via this stream.
- [utils_exceptions](utils_exceptions.md) — Exception types raised by DSPy components.
