# Retrievers: Databricks

## Introduction

The `retrievers_databricks` module provides the `DatabricksRM` retriever, a DSPy retrieval module that queries a **Databricks Mosaic AI Vector Search Index** to return the top-k most relevant documents for a given query. It supports both text and vector queries, optional metadata filtering, and can operate either through the official `databricks-sdk` Python library or via direct HTTP requests using the `requests` library.

This module is one of several retriever implementations in DSPy. For the base retrieval abstraction and other backends, see [retrievers_core](retrievers_core.md), [retrievers_embeddings](retrievers_embeddings.md), and [retrievers_weaviate](retrievers_weaviate.md).

---

## Core Components

| Component | Type | Description |
|-----------|------|-------------|
| `DatabricksRM` | Class | A DSPy retriever module that queries a Databricks Vector Search Index. |
| `Document` | Dataclass | A lightweight document container used when integrating with the Databricks Mosaic Agent Framework. |

### `Document`

A simple dataclass representing a retrieved document with three fields:

- `page_content` (`str`): The textual content of the document.
- `metadata` (`dict[str, Any]`): Associated metadata (e.g., `doc_id`, `doc_uri`, and any extra columns).
- `type` (`str`): The document type identifier (typically `"Document"`).

It exposes a `to_dict()` method that serializes the instance into a plain dictionary, which is the format expected by the Databricks Mosaic Agent Framework.

### `DatabricksRM`

`DatabricksRM` extends `dspy.Retrieve` (see [retrievers_core](retrievers_core.md)) and implements the `forward` method to query a Databricks Vector Search Index. It handles authentication, query construction, result parsing, and output formatting.

---

## Architecture

The following diagram shows how `DatabricksRM` fits into the DSPy retrieval ecosystem and its internal structure.

```mermaid
graph TD
    subgraph "DSPy Core"
        Retrieve["dspy.Retrieve<br/>(base class)"]
        Prediction["dspy.Prediction"]
        Settings["dspy.settings"]
    end

    subgraph "retrievers_databricks"
        DatabricksRM["DatabricksRM"]
        Document["Document (dataclass)"]
    end

    subgraph "External Dependencies"
        SDK["databricks.sdk<br/>WorkspaceClient"]
        Requests["requests library"]
        MLflow["mlflow<br/>(optional)"]
        EnvVars["Environment Variables<br/>DATABRICKS_*"]
    end

    Retrieve --> DatabricksRM
    DatabricksRM --> Document
    DatabricksRM --> Prediction
    DatabricksRM --> SDK
    DatabricksRM --> Requests
    DatabricksRM --> MLflow
    DatabricksRM --> EnvVars
    Settings -.-> Retrieve
```

---

## Dependencies

```mermaid
graph LR
    DatabricksRM["DatabricksRM"]

    DatabricksRM -->|inherits| Retrieve["dspy.Retrieve"]
    DatabricksRM -->|returns| Prediction["dspy.Prediction"]
    DatabricksRM -->|uses| Document["Document"]
    DatabricksRM -->|optional| SDK["databricks-sdk"]
    DatabricksRM -->|fallback| Requests["requests"]
    DatabricksRM -->|optional| MLflow["mlflow"]
    DatabricksRM -->|reads| Env["DATABRICKS_HOST / TOKEN /<br/>CLIENT_ID / CLIENT_SECRET"]
```

**Key dependency notes:**

- **`databricks-sdk`** is detected at import time via `find_spec("databricks.sdk")`. If installed, queries are routed through `WorkspaceClient.vector_search_indexes.query_index`. Otherwise, the module falls back to raw HTTP requests.
- **`requests`** is used as the fallback transport when the SDK is unavailable.
- **`mlflow`** is only required when `use_with_databricks_agent_framework=True`, to register the retriever schema.
- **Environment variables** (`DATABRICKS_HOST`, `DATABRICKS_TOKEN`, `DATABRICKS_CLIENT_ID`, `DATABRICKS_CLIENT_SECRET`) provide default credentials when explicit parameters are not supplied.

---

## Configuration

The `DatabricksRM` constructor accepts the following parameters:

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `databricks_index_name` | `str` | *required* | Name of the Vector Search Index to query. |
| `databricks_endpoint` | `str \| None` | `DATABRICKS_HOST` env | Workspace URL hosting the index. |
| `databricks_token` | `str \| None` | `DATABRICKS_TOKEN` env | Authentication token. |
| `databricks_client_id` | `str \| None` | `DATABRICKS_CLIENT_ID` env | Service principal ID. |
| `databricks_client_secret` | `str \| None` | `DATABRICKS_CLIENT_SECRET` env | Service principal secret. |
| `columns` | `list[str] \| None` | `None` | Extra columns to include in the response. |
| `filters_json` | `str \| None` | `None` | Default JSON query filters. |
| `k` | `int` | `3` | Number of documents to retrieve. |
| `docs_id_column_name` | `str` | `"id"` | Column containing document IDs. |
| `docs_uri_column_name` | `str \| None` | `None` | Column containing document URIs. |
| `text_column_name` | `str` | `"text"` | Column containing document text. |
| `use_with_databricks_agent_framework` | `bool` | `False` | Enable Databricks Mosaic Agent Framework compatibility. |

### Authentication Resolution

The constructor resolves credentials in the following priority order:

1. Explicit constructor arguments.
2. Environment variables (`DATABRICKS_*`).
3. Databricks SDK's ambient environment resolution (when the SDK is installed).

If the SDK is **not** installed and neither a token/endpoint pair nor a client ID/secret pair is available, a `ValueError` is raised.

---

## Data Flow

The following sequence diagram illustrates the end-to-end flow of a retrieval request.

```mermaid
sequenceDiagram
    participant User
    participant DatabricksRM
    participant Transport as SDK / requests
    participant Index as Databricks Vector Search Index

    User->>DatabricksRM: forward(query, query_type, filters_json)
    DatabricksRM->>DatabricksRM: Normalize query_type (legacy mapping)
    DatabricksRM->>DatabricksRM: Determine query_text vs query_vector

    alt databricks-sdk installed
        DatabricksRM->>Transport: _query_via_databricks_sdk(...)
        Transport->>Index: WorkspaceClient.query_index(...)
    else SDK not installed
        DatabricksRM->>Transport: _query_via_requests(...)
        Transport->>Index: POST /api/2.0/vector-search/indexes/{name}/query
    end

    Index-->>Transport: JSON results
    Transport-->>DatabricksRM: results dict

    DatabricksRM->>DatabricksRM: Validate id/text columns exist
    DatabricksRM->>DatabricksRM: Parse data_array into items
    DatabricksRM->>DatabricksRM: Sort by score (desc), take top-k

    alt use_with_databricks_agent_framework
        DatabricksRM-->>User: list[dict] (Document.to_dict())
    else default
        DatabricksRM-->>User: dspy.Prediction(docs, doc_ids, doc_uris, extra_columns)
    end
```

---

## Query Processing Pipeline

The `forward` method implements a multi-stage pipeline:

```mermaid
flowchart TD
    A["forward(query, query_type, filters_json)"] --> B{"query_type in<br/>['vector','text']?"}
    B -->|Yes| C["Map to 'ANN'<br/>(backwards compat)"]
    B -->|No| D["Keep query_type"]
    C --> E{"query is str?"}
    D --> E
    E -->|Yes| F["query_text = query<br/>query_vector = None"]
    E -->|No, list| G["query_vector = query<br/>query_text = None"]
    E -->|Other| H["Raise ValueError"]
    F --> I{"SDK installed?"}
    G --> I
    I -->|Yes| J["_query_via_databricks_sdk"]
    I -->|No| K["_query_via_requests"]
    J --> L["Validate columns"]
    K --> L
    L --> M["Parse data_array rows"]
    M --> N["Sort by score desc, take top-k"]
    N --> O{"Agent Framework mode?"}
    O -->|Yes| P["Return list[Document.to_dict()]"]
    O -->|No| Q["Return dspy.Prediction"]
```

### Key Processing Steps

1. **Query type normalization** — Legacy `query_type` values `"vector"` and `"text"` are mapped to `"ANN"` for backwards compatibility with older DSPy versions. Valid Databricks query types are `"ANN"` (approximate nearest neighbor) and `"HYBRID"`.

2. **Query disambiguation** — The `query` argument may be a `str` (text query) or a `list[float]` (vector query). Exactly one of `query_text` or `query_vector` must be set.

3. **Transport selection** — If the Databricks SDK is installed, `_query_via_databricks_sdk` is used; otherwise `_query_via_requests` performs a direct HTTP POST.

4. **Column validation** — The response manifest's column names are checked to ensure `docs_id_column_name` and `text_column_name` exist in the index.

5. **Result parsing** — Rows from `results["result"]["data_array"]` are zipped with column names into dictionaries.

6. **Sorting** — Results are sorted by the `score` field in descending order and truncated to `k`.

7. **Output formatting** — Depending on `use_with_databricks_agent_framework`, either a list of serialized `Document` dicts or a `dspy.Prediction` is returned.

---

## Transport Backends

### SDK-based Query (`_query_via_databricks_sdk`)

A static method that uses `databricks.sdk.WorkspaceClient`:

- If both `databricks_client_id` and `databricks_client_secret` are provided, it authenticates via **service principal**.
- Otherwise, it falls back to **token-based** authentication using `host` and `token`.
- Calls `vector_search_indexes.query_index(...)` and returns the result as a dictionary via `.as_dict()`.

### HTTP-based Query (`_query_via_requests`)

A static method that performs a direct HTTP request:

- Builds an `Authorization: Bearer <token>` header.
- POSTs to `{databricks_endpoint}/api/2.0/vector-search/indexes/{index_name}/query`.
- Raises an exception if the response contains an `error_code`.

---

## Output Formats

### Default Mode (`use_with_databricks_agent_framework=False`)

Returns a `dspy.Prediction` (see [primitives_prediction](primitives_prediction.md)) with the following fields:

| Field | Description |
|-------|-------------|
| `docs` | List of document text strings. |
| `doc_ids` | List of document IDs. |
| `doc_uris` | List of document URIs (or `None` if `docs_uri_column_name` is unset). |
| `extra_columns` | List of dicts containing additional column values per document. |

### Agent Framework Mode (`use_with_databricks_agent_framework=True`)

Returns a `list[dict[str, Any]]` where each dict is produced by `Document.to_dict()`, containing `page_content`, `metadata` (with `doc_id`, `doc_uri`, and extra columns), and `type`. This mode also registers the retriever schema with MLflow via `mlflow.models.set_retriever_schema`.

---

## Metadata Handling

The module provides two helper methods for extracting metadata from search results:

- **`_extract_doc_ids(item)`** — Extracts the document ID. If `docs_id_column_name == "metadata"`, it parses the JSON `metadata` field and returns `document_id`; otherwise it reads the configured ID column directly.

- **`_get_extra_columns(item)`** — Collects all columns except the ID, text, and URI columns. When the ID column is `"metadata"`, it merges the parsed metadata (excluding `document_id`) into the result.

---

## Usage Example

```python
from databricks.vector_search.client import VectorSearchClient

# Create a Databricks Vector Search Endpoint
client = VectorSearchClient()
client.create_endpoint(
    name="your_vector_search_endpoint_name",
    endpoint_type="STANDARD",
)

# Create a Direct Access Vector Search Index
index = client.create_direct_access_index(
    endpoint_name="your_vector_search_endpoint_name",
    index_name="your_index_name",
    primary_key="id",
    embedding_dimension=1024,
    embedding_vector_column="text_vector",
    schema={
        "id": "int",
        "field2": "str",
        "field3": "float",
        "text_vector": "array<float>",
    },
)

# Configure the DatabricksRM retriever
import dspy
from dspy.retrievers.databricks_rm import DatabricksRM

retriever = DatabricksRM(
    databricks_index_name="your_index_name",
    docs_id_column_name="id",
    text_column_name="field2",
    k=3,
)

# Query the index
retrieved_results = retriever(query="Example query text")
```

---

## Integration with DSPy

`DatabricksRM` can be used as a standalone retriever or registered as the global retrieval model via `dspy.settings.rm`. When used through the base `Retrieve` module (see [retrievers_core](retrievers_core.md)), the `forward` method is invoked with a `query` and optional `k`, and the results are wrapped into a `Prediction` with a `passages` field.

```mermaid
graph LR
    Module["DSPy Module<br/>(e.g., RAG pipeline)"] --> Retrieve["dspy.Retrieve"]
    Retrieve --> Settings["dspy.settings.rm"]
    Settings --> DatabricksRM
    DatabricksRM --> Index["Databricks Vector<br/>Search Index"]
    DatabricksRM --> Prediction["dspy.Prediction"]
    Prediction --> Module
```

---

## Error Handling

| Condition | Behavior |
|-----------|----------|
| SDK not installed and no credentials provided | `ValueError` at construction. |
| `use_with_databricks_agent_framework=True` but `mlflow` not installed | `ValueError` at construction. |
| `query` is neither `str` nor `list` | `ValueError` in `forward`. |
| Neither/both `query_text` and `query_vector` set | `ValueError` in transport methods. |
| `docs_id_column_name` missing from index columns | `Exception` in `forward`. |
| `text_column_name` missing from index columns | `Exception` in `forward`. |
| HTTP response contains `error_code` | `Exception` in `_query_via_requests`. |

---

## Related Modules

- [retrievers_core](retrievers_core.md) — Base `Retrieve` abstraction.
- [retrievers_embeddings](retrievers_embeddings.md) — Embedding-based retriever.
- [retrievers_weaviate](retrievers_weaviate.md) — Weaviate retriever backend.
- [primitives_prediction](primitives_prediction.md) — The `Prediction` output type.
- [clients_providers_databricks](clients_providers_databricks.md) — Databricks LM provider (for generation, complementary to retrieval).
