# GEPA Adapter Module

## Introduction

The `teleprompt_gepa_adapter` module (implemented in `dspy/teleprompt/gepa/gepa_utils.py`) provides the **bridge layer** between DSPy programs and the external [GEPA](https://github.com/gepa-ai/gepa) evolutionary optimization engine. GEPA (Reflective Prompt Evolution) evolves the textual instructions of individual predictors within a DSPy program by reflecting on execution traces and textual feedback.

This module is responsible for:

- **Adapting** a DSPy `Module` into the `GEPAAdapter` interface expected by the `gepa` package.
- **Evaluating** candidate programs (with or without trace capture) using DSPy's `Evaluate` engine.
- **Extracting reflective datasets** — structured `Inputs` / `Generated Outputs` / `Feedback` records — that GEPA uses to propose improved instructions.
- **Bridging logging** between DSPy's `logging.Logger` and GEPA's logger interface.

> For the high-level optimizer that consumes this adapter, see [teleprompt_gepa_optimizer.md](teleprompt_gepa_optimizer.md). For the underlying trace-capture machinery, see [teleprompt_finetune.md](teleprompt_finetune.md).

---

## Core Components

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `DspyAdapter` | Class | Implements `GEPAAdapter`; builds programs, evaluates candidates, and produces reflective datasets. |
| `LoggerAdapter` | Class | Wraps a `logging.Logger` to satisfy GEPA's `.log(x)` interface. |
| `PredictorFeedbackFn` | Protocol | Type contract for per-predictor feedback functions. |
| `ScoreWithFeedback` | Class (`Prediction`) | Container for a `score` and textual `feedback`. |
| `DSPyTrace` | Type alias | `list[tuple[Any, dict[str, Any], Prediction]]` — the execution trace shape. |

---

## Architecture

The adapter sits between the DSPy runtime and the GEPA engine. The `GEPA` optimizer constructs a `DspyAdapter`, hands it to `gepa.optimize`, and GEPA calls back into the adapter during the evolutionary loop.

```mermaid
graph TD
    subgraph DSPy
        GEPA["GEPA (gepa.py)"]
        Adapter["DspyAdapter"]
        Logger["LoggerAdapter"]
        Student["student Module"]
        Eval["Evaluate"]
        BTD["bootstrap_trace_data"]
        Chat["ChatAdapter"]
    end

    subgraph GEPA Engine
        Optimize["gepa.optimize"]
        GEPAAdapter["GEPAAdapter (base)"]
        EvalBatch["EvaluationBatch"]
    end

    GEPA -->|constructs| Adapter
    GEPA -->|constructs| Logger
    GEPA -->|calls| Optimize
    Optimize -->|uses| Adapter
    Adapter -.implements.-> GEPAAdapter
    Adapter -->|build_program| Student
    Adapter -->|evaluate no-trace| Eval
    Adapter -->|evaluate with-trace| BTD
    Adapter -->|format failures| Chat
    Adapter -->|returns| EvalBatch
    Logger -->|passed to| Optimize
```

---

## Component Details

### `DspyAdapter`

The central class. It subclasses `GEPAAdapter[Example, TraceData, Prediction]`, parameterizing the generic adapter over DSPy's `Example` (inputs), `TraceData` (trajectories), and `Prediction` (outputs).

#### Constructor

```python
DspyAdapter(
    student_module,
    metric_fn: Callable,
    feedback_map: dict[str, Callable],
    failure_score=0.0,
    num_threads: int | None = None,
    add_format_failure_as_feedback: bool = False,
    rng: random.Random | None = None,
)
```

| Parameter | Description |
|-----------|-------------|
| `student_module` | The DSPy `Module` being optimized. |
| `metric_fn` | The GEPA feedback metric (see `GEPAFeedbackMetric` in [teleprompt_gepa_optimizer.md](teleprompt_gepa_optimizer.md)). |
| `feedback_map` | Maps predictor name → `PredictorFeedbackFn`. Built by `GEPA.compile`. |
| `failure_score` | Score assigned to failed examples. |
| `num_threads` | Parallelism for evaluation. |
| `add_format_failure_as_feedback` | If `True`, format-parse failures are surfaced as feedback items rather than filtered out. |
| `rng` | Random source for selecting trace instances (defaults to `random.Random(0)`). |

The constructor caches `self.named_predictors = list(self.student.named_predictors())` to avoid repeated traversal.

#### Methods

**`build_program(candidate: dict[str, str]) -> Module`**

Deep-copies the student module and applies candidate instructions to matching predictors. Each candidate is a mapping of `predictor_name → instruction_text`. Instructions are applied via `pred.signature.with_instructions(...)`.

**`evaluate(batch, candidate, capture_traces=False) -> EvaluationBatch`**

Evaluates a candidate program on a batch. Two distinct code paths:

- **With trace capture** (`capture_traces=True`): delegates to `bootstrap_trace_data` (from [teleprompt_finetune.md](teleprompt_finetune.md)) with `raise_on_error=False` and `capture_failed_parses=True`. Returns an `EvaluationBatch` with `outputs`, `scores`, and `trajectories`.
- **Without trace capture**: uses the `Evaluate` engine (see [evaluate.md](evaluate.md)) with `return_all_scores=True`, `return_outputs=True`, and a high `max_errors` ceiling. Returns an `EvaluationBatch` with `trajectories=None`.

**`make_reflective_dataset(candidate, eval_batch, components_to_update) -> dict[str, list[dict]]`**

The heart of GEPA's reflection mechanism. For each predictor in `components_to_update`, it:

1. Filters the captured trace to instances matching the predictor's signature.
2. Optionally filters out `FailedPrediction` instances (unless `add_format_failure_as_feedback`).
3. Selects a trace instance — preferring a `FailedPrediction` if present, otherwise a random choice via `self.rng`.
4. Normalizes inputs/outputs into string form, with special handling for `History` fields (rendered as a JSON code block under a `Context` key).
5. Attaches `Feedback`:
   - For `FailedPrediction`: a structure reminder generated from `ChatAdapter.format(...)`.
   - Otherwise: the result of the predictor's `feedback_map` function, asserting the feedback score equals the module score.
6. Returns `{predictor_name: [ {Inputs, Generated Outputs, Feedback}, ... ]}`.

Raises an exception if no valid predictions are found for any module.

> **Note:** The commented-out `propose_new_texts` method documents a potential future override to use MIPROv2-style instruction proposal instead of GEPA's default.

---

### `LoggerAdapter`

A thin wrapper that adapts a standard `logging.Logger` to GEPA's expected logger interface:

```python
class LoggerAdapter:
    def __init__(self, logger: logging.Logger):
        self.logger = logger

    def log(self, x: str):
        self.logger.info(x)
```

GEPA calls `.log(...)`; this forwards to `logger.info(...)`.

---

### `PredictorFeedbackFn` (Protocol)

Defines the signature of per-predictor feedback functions stored in `feedback_map`:

```python
def __call__(
    predictor_output: dict[str, Any],
    predictor_inputs: dict[str, Any],
    module_inputs: Example,
    module_outputs: Prediction,
    captured_trace: DSPyTrace,
) -> ScoreWithFeedback: ...
```

These functions are created by `GEPA.compile`'s `feedback_fn_creator`, which wraps the user's `metric_fn` and normalizes its return value into a `ScoreWithFeedback` (defaulting feedback to `f"This trajectory got a score of {score}."`).

---

### `ScoreWithFeedback`

A `Prediction` subclass carrying two fields:

```python
class ScoreWithFeedback(Prediction):
    score: float
    feedback: str
```

Because it extends `Prediction` (see [primitives_prediction.md](primitives_prediction.md)), it supports score-based comparison and arithmetic operations.

---

### `DSPyTrace` (Type Alias)

```python
DSPyTrace = list[tuple[Any, dict[str, Any], Prediction]]
```

Each element is `(Predictor, PredictorInputs, Prediction)`. This is the canonical trace shape produced by `bootstrap_trace_data` and consumed by `make_reflective_dataset`.

---

## Data Flow

The following sequence diagram shows how a single GEPA optimization step flows through the adapter.

```mermaid
sequenceDiagram
    participant G as GEPA Engine
    participant A as DspyAdapter
    participant B as bootstrap_trace_data
    participant E as Evaluate
    participant F as feedback_map fn

    G->>A: evaluate(batch, candidate, capture_traces=True)
    A->>A: build_program(candidate)
    A->>B: bootstrap_trace_data(program, batch, metric)
    B-->>A: trajs (TraceData list)
    A-->>G: EvaluationBatch(outputs, scores, trajectories)

    G->>A: make_reflective_dataset(candidate, eval_batch, components)
    A->>A: build_program(candidate)
    loop for each predictor
        A->>A: filter trace by signature
        A->>A: select trace instance (rng / FailedPrediction)
        A->>F: feedback_fn(predictor_output, ...)
        F-->>A: ScoreWithFeedback
        A->>A: assert score == module_score
    end
    A-->>G: {pred_name: [{Inputs, Generated Outputs, Feedback}]}
```

---

## Evaluation Paths

The adapter chooses between two evaluation strategies depending on whether traces are needed.

```mermaid
flowchart TD
    Start["evaluate(batch, candidate, capture_traces)"] --> Build["build_program(candidate)"]
    Build --> Check{capture_traces?}
    Check -->|Yes| BTD["bootstrap_trace_data(...)"]
    BTD --> Collect["Collect outputs + scores from trajs"]
    Collect --> EB1["EvaluationBatch(trajectories=trajs)"]
    Check -->|No| Eval["Evaluate(devset, metric, ...)"]
    Eval --> Extract["Extract outputs + scores from results"]
    Extract --> EB2["EvaluationBatch(trajectories=None)"]
```

---

## Reflective Dataset Construction

The reflective dataset is the structured artifact GEPA uses to propose new instructions. Its construction involves several normalization steps.

```mermaid
flowchart TD
    In["eval_batch.trajectories"] --> Filter["Filter by predictor signature"]
    Filter --> FmtFail{add_format_failure_as_feedback?}
    FmtFail -->|No| DropFail["Drop FailedPrediction instances"]
    FmtFail -->|Yes| Keep["Keep all instances"]
    DropFail --> Select
    Keep --> Select["Select instance (prefer FailedPrediction, else rng.choice)"]
    Select --> Norm["Normalize inputs/outputs to strings"]
    Norm --> Hist{Contains History field?}
    Hist -->|Yes| Render["Render messages as JSON 'Context' block"]
    Hist -->|No| Skip["Use inputs as-is"]
    Render --> Feedback
    Skip --> Feedback
    Feedback --> IsFail{outputs is FailedPrediction?}
    IsFail -->|Yes| Struct["Feedback = ChatAdapter structure reminder"]
    IsFail -->|No| Fn["Feedback = feedback_map[pred_name](...)"]
    Struct --> Append
    Fn --> Append["Append {Inputs, Generated Outputs, Feedback}"]
```

---

## Dependencies

```mermaid
graph LR
    Adapter["DspyAdapter"]

    Adapter -->|imports| GEPA["gepa: EvaluationBatch, GEPAAdapter"]
    Adapter -->|imports| Chat["dspy.adapters.chat_adapter.ChatAdapter"]
    Adapter -->|imports| History["dspy.adapters.types.History"]
    Adapter -->|imports| Eval["dspy.evaluate.Evaluate"]
    Adapter -->|imports| Prims["dspy.primitives: Example, Prediction"]
    Adapter -->|imports| BTD["dspy.teleprompt.bootstrap_finetune: TraceData, bootstrap_trace_data, FailedPrediction"]
```

| Dependency | Purpose | Documentation |
|------------|---------|---------------|
| `gepa.GEPAAdapter`, `gepa.EvaluationBatch` | Base interface and result container from the external GEPA package. | — |
| `ChatAdapter` | Generates structure reminders for format failures. | [adapters.md](adapters.md) |
| `History` | Detected in inputs to render conversation context. | [adapter_types.md](adapter_types.md) |
| `Evaluate` | Parallel evaluation engine. | [evaluate.md](evaluate.md) |
| `Example`, `Prediction` | Core data primitives. | [primitives_example.md](primitives_example.md), [primitives_prediction.md](primitives_prediction.md) |
| `bootstrap_trace_data`, `TraceData`, `FailedPrediction` | Trace capture and failure representation. | [teleprompt_finetune.md](teleprompt_finetune.md) |

---

## Integration with the GEPA Optimizer

The `GEPA` optimizer (see [teleprompt_gepa_optimizer.md](teleprompt_gepa_optimizer.md)) orchestrates the adapter:

1. Builds a `feedback_map` by wrapping the user's `metric_fn` for each named predictor.
2. Instantiates `DspyAdapter` with the student, metric, feedback map, and configuration.
3. Calls `gepa.optimize(...)` passing the adapter and a `LoggerAdapter`.
4. After optimization, calls `adapter.build_program(gepa_result.best_candidate)` to materialize the optimized module.
5. Optionally wraps results via `DspyGEPAResult.from_gepa_result(gepa_result, adapter)`, which uses `adapter.build_program` to convert each candidate into a `Module`.

```mermaid
graph TD
    Compile["GEPA.compile"] --> FMap["Build feedback_map"]
    FMap --> Inst["Instantiate DspyAdapter"]
    Inst --> Opt["gepa.optimize(adapter=...)"]
    Opt --> Best["adapter.build_program(best_candidate)"]
    Best --> Result["Optimized Module"]
    Opt --> DGR["DspyGEPAResult.from_gepa_result(..., adapter)"]
```

---

## Key Design Notes

- **Score consistency invariant:** `make_reflective_dataset` asserts that the feedback function's score equals the module-level score. GEPA currently only supports feedback functions that return the same score as the module's score.
- **History handling:** When a predictor input contains a `History` field, the adapter renders the message list as a JSON code block under a `Context` key and excludes the raw history field from the normalized inputs.
- **Failure feedback:** Format-parse failures can either be filtered out or surfaced as feedback with a structure reminder generated from `ChatAdapter`.
- **Trace selection randomness:** A seeded `random.Random` ensures reproducible trace selection across runs.
