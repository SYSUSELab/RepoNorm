# Local Provider (`clients_providers_local`)

## Introduction

The `clients_providers_local` module implements `LocalProvider`, a concrete [`Provider`](clients_core_provider.md) that enables DSPy to **launch, serve, and fine-tune language models entirely on local hardware**. It is the local-execution counterpart to remote providers such as [`OpenAIProvider`](clients_providers_openai.md) and [`ArborProvider`](clients_providers_arbor.md).

The provider is responsible for three distinct capabilities:

1. **Launching** an inference server for a local model using [SGLang](https://docs.sglang.ai/), exposing it over an OpenAI-compatible HTTP endpoint.
2. **Killing** a previously launched server and cleaning up its resources.
3. **Fine-tuning** a local model on chat-formatted training data using Hugging Face `transformers` and `trl` (SFT), optionally with LoRA/PEFT adapters.

This module is consumed by [`LM`](clients_core_lm.md), which delegates `launch()`, `kill()`, and `finetune()` calls to the active provider.

---

## Architecture Overview

`LocalProvider` subclasses the abstract [`Provider`](clients_core_provider.md) interface and overrides its static lifecycle methods. It is one of several interchangeable provider implementations selected by `LM.infer_provider()`.

```mermaid
classDiagram
    class Provider {
        +bool finetunable
        +bool reinforceable
        +TrainingJob TrainingJob
        +ReinforceJob ReinforceJob
        +is_provider_model(model) bool
        +launch(lm, launch_kwargs)
        +kill(lm, launch_kwargs)
        +finetune(job, model, train_data, train_data_format, train_kwargs) str
    }

    class LocalProvider {
        +bool finetunable = True
        +TrainingJob TrainingJob
        +launch(lm, launch_kwargs)
        +kill(lm, launch_kwargs)
        +finetune(job, model, train_data, train_data_format, train_kwargs) str
    }

    class OpenAIProvider
    class ArborProvider

    Provider <|-- LocalProvider
    Provider <|-- OpenAIProvider
    Provider <|-- ArborProvider
```

### Position in the Client Stack

```mermaid
flowchart TD
    LM["LM (clients_core_lm)"]
    Provider["Provider (clients_core_provider)"]
    Local["LocalProvider (this module)"]
    SGLang["SGLang Server\n(OpenAI-compatible /v1)"]
    TRL["transformers + trl\n(SFTTrainer)"]
    Utils["utils_finetune\n(save_data, TrainDataFormat)"]

    LM -->|"launch / kill / finetune"| Provider
    Provider --> Local
    Local -->|"subprocess"| SGLang
    Local -->|"in-process training"| TRL
    Local -->|"save_data"| Utils
```

---

## Core Component: `LocalProvider`

`LocalProvider` is a stateless (all-static-method) provider. Its constructor only configures capability flags:

```python
class LocalProvider(Provider):
    def __init__(self):
        super().__init__()
        self.finetunable = True
        self.TrainingJob = TrainingJob
```

| Attribute | Value | Meaning |
|-----------|-------|---------|
| `finetunable` | `True` | Enables `LM.finetune()` for local models. |
| `reinforceable` | `False` (inherited) | Local RL/GRPO is **not** supported (see [`ArborProvider`](clients_providers_arbor.md) for that). |
| `TrainingJob` | `TrainingJob` | The generic future-based job wrapper from [`clients_core_provider`](clients_core_provider.md). |

> **Note:** `LocalProvider` does **not** override `is_provider_model()`, so it is never auto-discovered by `LM.infer_provider()`. It must be passed explicitly via `dspy.LM(..., provider=LocalProvider())`.

---

## Capability 1 — Launching a Local Inference Server

`LocalProvider.launch(lm, launch_kwargs)` starts an SGLang server as a subprocess and wires the resulting endpoint back into the `LM` object.

### Launch Flow

```mermaid
sequenceDiagram
    participant User
    participant LM
    participant LP as LocalProvider
    participant Proc as SGLang subprocess
    participant Thread as Log tail thread

    User->>LM: lm.launch()
    LM->>LP: launch(lm, launch_kwargs)
    LP->>LP: import sglang (raise if missing)
    LP->>LP: normalize model name (strip openai/, local:, huggingface/)
    LP->>LP: get_free_port()
    LP->>Proc: Popen("python -m sglang.launch_server ...")
    LP->>Thread: start _tail_process (daemon)
    LP->>LP: wait_for_server(base_url, timeout)
    alt server ready
        LP->>LM: set kwargs[api_base], kwargs[api_key]
        LP->>LM: attach get_logs, process, thread
    else timeout
        LP->>Proc: process.kill()
        LP-->>User: raise TimeoutError
    end
```

### Key Behaviors

- **Dependency check:** Requires `sglang`; raises an `ImportError` with installation instructions if absent.
- **Idempotency:** If `lm` already has a `process` attribute, launch is skipped (`"Server is already launched."`).
- **Model name normalization:** Strips the `openai/`, `local:`, and `huggingface/` prefixes before passing the path to SGLang.
- **Port selection:** `get_free_port()` binds to port `0` on localhost to obtain an OS-assigned free port.
- **Log streaming:** A daemon thread (`_tail_process`) continuously reads merged stdout/stderr into a buffer. Lines are printed live until the server is ready, after which printing stops but buffering continues.
- **Readiness polling:** `wait_for_server()` polls `GET /v1/models` until HTTP 200, then sleeps 5 seconds to ensure full startup. Honors a `timeout` (default `1800`s) from `launch_kwargs`.
- **LM mutation:** On success, sets `lm.kwargs["api_base"] = http://localhost:{port}/v1`, `lm.kwargs["api_key"] = "local"`, and attaches `lm.get_logs`, `lm.process`, and `lm.thread`.

### Helper Functions

| Function | Purpose |
|----------|---------|
| `get_free_port()` | Returns an OS-assigned free TCP port on localhost. |
| `wait_for_server(base_url, timeout)` | Polls `/v1/models` until ready or raises `TimeoutError`. |

---

## Capability 2 — Killing a Local Server

`LocalProvider.kill(lm, launch_kwargs)` terminates the SGLang subprocess and cleans up attached attributes.

```mermaid
flowchart LR
    A["kill(lm)"] --> B{"has lm.process?"}
    B -- No --> C["log: No running server to kill"]
    B -- Yes --> D["terminate_process(lm.process)"]
    D --> E["lm.thread.join()"]
    E --> F["del lm.process / thread / get_logs"]
    F --> G["log: Server killed"]
```

- Uses `sglang.utils.terminate_process` for graceful termination.
- Joins the log-tailing thread to ensure clean shutdown.
- Removes `process`, `thread`, and `get_logs` from the `LM` instance.
- Resilient to being called when no server is running.

---

## Capability 3 — Local Fine-Tuning (SFT)

`LocalProvider.finetune(...)` performs supervised fine-tuning (SFT) of a chat model on local hardware. It is invoked asynchronously by [`LM.finetune()`](clients_core_lm.md), which runs it inside a background thread wrapped in a `TrainingJob` future.

### Fine-Tuning Flow

```mermaid
sequenceDiagram
    participant LM
    participant LP as LocalProvider
    participant Utils as utils_finetune
    participant TRL as train_sft_locally

    LM->>LP: finetune(job, model, train_data, format, kwargs)
    LP->>LP: normalize model name
    LP->>LP: assert format == CHAT
    LP->>Utils: save_data(train_data)
    Utils-->>LP: data_path (.jsonl)
    LP->>LP: create_output_dir(model, data_path)
    LP->>LP: merge default_train_kwargs
    LP->>TRL: train_sft_locally(model, data, kwargs)
    TRL-->>LP: output_dir
    LP-->>LM: "openai/local:{output_dir}"
```

### Data Format Constraint

Only `TrainDataFormat.CHAT` is supported. Any other format raises:

```
ValueError: Only chat models are supported for local finetuning.
```

See [`clients_finetune_utils`](clients_finetune_utils.md) for the `TrainDataFormat` enum and `save_data` helper.

### Default Training Hyperparameters

`finetune()` merges user-supplied `train_kwargs` over these defaults:

| Parameter | Default | Notes |
|-----------|---------|-------|
| `device` | `None` | Auto-detected: `cuda` → `mps` → `cpu`. |
| `use_peft` | `False` | Enables LoRA adapters when `True`. |
| `num_train_epochs` | `5` | |
| `per_device_train_batch_size` | `1` | |
| `gradient_accumulation_steps` | `8` | |
| `learning_rate` | `1e-5` | |
| `max_seq_length` | `None` | Defaults to `4096` inside `train_sft_locally`. |
| `packing` | `True` | |
| `bf16` | `True` | |
| `output_dir` | generated | See `create_output_dir`. |

### Output Directory Naming

`create_output_dir(model_name, data_path)` builds a unique directory by appending a random 6-char string, the sanitized model name, and a timestamp to the data path:

```
{data_path_without_.jsonl}_{rnd}_{model-with-dashes}_{YYYY-MM-DD_HH-MM-SS}
```

### Return Value

On success, returns a model identifier string of the form:

```
openai/local:{output_dir}
```

This is consumed by `LM._run_finetune_job`, which calls `self.copy(model=model)` to produce a new `LM` pointing at the fine-tuned model.

---

## The `train_sft_locally` Pipeline

`train_sft_locally(model_name, train_data, train_kwargs)` is the heavy-lifting routine that performs the actual training.

```mermaid
flowchart TD
    A["Import torch, transformers, trl"] --> B["Resolve device (cuda/mps/cpu)"]
    B --> C["Load AutoModelForCausalLM + AutoTokenizer"]
    C --> D["setup_chat_format (best-effort)"]
    D --> E{"pad_token_id set?"}
    E -- No --> F["Add [!#PAD#!] pad token"]
    E -- Yes --> G["Build HF Dataset"]
    F --> G
    G --> H["tokenize_function → encode_sft_example"]
    H --> I["Filter examples with no assistant labels"]
    I --> J{"use_peft?"}
    J -- Yes --> K["Build LoraConfig (r=32, alpha=64, dropout=0.05)"]
    J -- No --> L["peft_config = None"]
    K --> M["Build SFTConfig"]
    L --> M
    M --> N["SFTTrainer.train()"]
    N --> O["trainer.save_model()"]
    O --> P{"use_peft and merge?"}
    P -- Yes --> Q["merge_and_unload → save_pretrained"]
    P -- No --> R["Cleanup: del model/tokenizer/trainer, gc, empty_cache"]
    Q --> R
```

### Dependencies

Requires `torch`, `transformers`, and `trl` (plus `peft` for LoRA). A missing dependency raises an `ImportError` with the install command:

```
pip install -U torch transformers accelerate trl peft
```

### `SFTConfig` Highlights

- `max_grad_norm=2.0` (overriding the `SFTConfig` default of `1.0`).
- `logging_steps=20`, `warmup_ratio=0.03`, `lr_scheduler_type="constant"`, `save_steps=10_000`.
- `dataset_kwargs={"add_special_tokens": False, "append_concat_token": False}` because tokenization is handled manually.

### PEFT / LoRA

When `use_peft=True`, a `LoraConfig` is created with `r=32`, `lora_alpha=64`, `lora_dropout=0.05`, `target_modules="all-linear"`, and `task_type="CAUSAL_LM"`. After training, the adapter is merged into the base model via `AutoPeftModelForCausalLM.merge_and_unload()` and saved with `safe_serialization=True, max_shard_size="5GB"`.

---

## The `encode_sft_example` Tokenizer

`encode_sft_example(example, tokenizer, max_seq_length)` converts a single chat example into `input_ids`, `labels`, and `attention_mask` tensors suitable for SFT.

- Uses `tokenizer.apply_chat_template` to tokenize the full conversation.
- **Loss masking:** Sets `labels` to `-100` for all non-assistant messages so the model is only trained on assistant turns.
- Correctly handles the assistant generation prefix (`add_generation_prompt=True`) for intermediate messages to avoid leaking the `<|assistant|>` prefix into the loss.
- Truncates at `max_seq_length`.

> Adapted from the [allenai/open-instruct](https://github.com/allenai/open-instruct) repository.

---

## Component Interaction Summary

```mermaid
flowchart TB
    subgraph "clients_core"
        LM["LM"]
        Provider["Provider (abstract)"]
        TrainingJob["TrainingJob (Future)"]
    end

    subgraph "clients_providers_local"
        LP["LocalProvider"]
        Launch["launch()"]
        Kill["kill()"]
        Finetune["finetune()"]
        Train["train_sft_locally()"]
        Encode["encode_sft_example()"]
        Port["get_free_port()"]
        Wait["wait_for_server()"]
        OutDir["create_output_dir()"]
    end

    subgraph "clients_finetune_utils"
        SaveData["save_data()"]
        TDF["TrainDataFormat"]
    end

    LM -->|delegates| LP
    Provider -.->|inherited by| LP
    LP --> Launch
    LP --> Kill
    LP --> Finetune
    Launch --> Port
    Launch --> Wait
    Finetune --> SaveData
    Finetune --> TDF
    Finetune --> OutDir
    Finetune --> Train
    Train --> Encode
    LM -->|wraps in| TrainingJob
```

---

## Usage Example

```python
import dspy
from dspy.clients.lm_local import LocalProvider

# Launch a local SGLang server and use it as an LM
lm = dspy.LM(
    model="openai/local:Qwen/Qwen2.5-7B-Instruct",
    provider=LocalProvider(),
    launch_kwargs={"timeout": 1800},
)
lm.launch()
dspy.configure(lm=lm)

# ... run your DSPy program ...

# Inspect server logs
print(lm.get_logs())

# Fine-tune on chat data (runs asynchronously)
job = lm.finetune(
    train_data=[{"messages": [{"role": "user", "content": "Hi"},
                             {"role": "assistant", "content": "Hello!"}]}],
    train_data_format=TrainDataFormat.CHAT,
    train_kwargs={"num_train_epochs": 3, "use_peft": True},
)
finetuned_lm = job.result()  # blocks until training completes

# Clean up the server
lm.kill()
```

---

## Related Modules

| Module | Relationship |
|--------|--------------|
| [`clients_core_provider`](clients_core_provider.md) | Defines the abstract `Provider`, `TrainingJob`, and `ReinforceJob` interfaces that `LocalProvider` implements. |
| [`clients_core_lm`](clients_core_lm.md) | The `LM` class that delegates `launch`, `kill`, and `finetune` to the provider. |
| [`clients_finetune_utils`](clients_finetune_utils.md) | Provides `TrainDataFormat`, `save_data`, and `TrainingStatus` used during fine-tuning. |
| [`clients_providers_openai`](clients_providers_openai.md) | Remote fine-tuning provider; shares the `finetune` contract and `save_data` helper. |
| [`clients_providers_arbor`](clients_providers_arbor.md) | Remote provider that additionally supports reinforcement learning (GRPO). |
| [`clients_providers_databricks`](clients_providers_databricks.md) | Another remote provider implementation. |
| [`teleprompt_finetune`](teleprompt_finetune.md) | Higher-level optimizers (e.g., `BootstrapFinetune`, `GRPO`) that drive provider fine-tuning. |
