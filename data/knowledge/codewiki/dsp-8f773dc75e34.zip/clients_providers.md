# Clients Providers

## Overview

The **clients_providers** module implements the concrete *provider* backends used by DSPy to
interact with external (and local) model-serving and fine-tuning infrastructure. It sits on top of
the abstract provider contract defined in the [clients_core](clients_core.md) module and supplies
the actual implementations for:

- **Fine-tuning** models on remote or local infrastructure (OpenAI, Databricks, local SGLang/TRL).
- **Reinforcement learning** (GRPO) training loops (Arbor).
- **Launching / killing** local inference servers (SGLang, Arbor).

Each provider is a subclass of `Provider` (from `dspy/clients/provider.py`) and is responsible for
the full lifecycle of a training job: validating data, uploading it, starting remote training,
polling for status, and retrieving the resulting model identifier.

## Architecture

The module follows a **strategy pattern**: the abstract `Provider` base class defines the interface,
and each concrete provider implements the provider-specific mechanics. A `Provider` is paired with a
`TrainingJob` (a `Future` subclass) that tracks the state of an asynchronous training run, and
optionally a `ReinforceJob` for reinforcement-learning workflows.

```mermaid
graph TD
    subgraph clients_core["clients_core (abstract contract)"]
        Provider["Provider"]
        TrainingJob["TrainingJob (Future)"]
        ReinforceJob["ReinforceJob"]
    end

    subgraph clients_providers["clients_providers (this module)"]
        OpenAIProvider["OpenAIProvider"]
        TrainingJobOpenAI["TrainingJobOpenAI"]
        DatabricksProvider["DatabricksProvider"]
        TrainingJobDatabricks["TrainingJobDatabricks"]
        LocalProvider["LocalProvider"]
        ArborProvider["ArborProvider"]
        ArborTrainingJob["ArborTrainingJob"]
        ArborReinforceJob["ArborReinforceJob"]
    end

    subgraph utils["clients_finetune_utils"]
        TrainDataFormat["TrainDataFormat"]
        TrainingStatus["TrainingStatus"]
        save_data["save_data"]
    end

    Provider --> OpenAIProvider
    Provider --> DatabricksProvider
    Provider --> LocalProvider
    Provider --> ArborProvider

    TrainingJob --> TrainingJobOpenAI
    TrainingJob --> TrainingJobDatabricks
    TrainingJob --> ArborTrainingJob
    ReinforceJob --> ArborReinforceJob

    OpenAIProvider -.uses.-> TrainingJobOpenAI
    DatabricksProvider -.uses.-> TrainingJobDatabricks
    ArborProvider -.uses.-> ArborTrainingJob
    ArborProvider -.uses.-> ArborReinforceJob

    OpenAIProvider --> utils
    DatabricksProvider --> utils
    LocalProvider --> utils
    ArborProvider --> utils
```

## Provider Lifecycle

All providers share a common lifecycle, expressed through the `Provider` interface. The diagram below
shows the typical fine-tuning flow, which is implemented (with provider-specific variations) by
`OpenAIProvider`, `DatabricksProvider`, `LocalProvider`, and `ArborProvider`.

```mermaid
sequenceDiagram
    participant User
    participant Provider
    participant Job as TrainingJob
    participant Remote as Remote/Local Infra

    User->>Provider: finetune(job, model, train_data, format, kwargs)
    Provider->>Provider: validate_data_format(format)
    Provider->>Provider: save_data(train_data)
    Provider->>Remote: upload_data(data_path)
    Remote-->>Provider: provider_file_id
    Provider->>Job: job.provider_file_id = ...
    Provider->>Remote: _start_remote_training(...)
    Remote-->>Provider: provider_job_id
    Provider->>Job: job.provider_job_id = ...
    loop poll until terminal
        Provider->>Remote: get_training_status(job_id)
        Remote-->>Provider: TrainingStatus
    end
    Provider->>Remote: get_trained_model(job)
    Remote-->>Provider: finetuned_model_id
    Provider-->>User: model identifier
```

## Sub-modules

The module is organized into four provider implementations. Each is documented in detail in its own
file:

| Sub-module | Documentation | Description |
| --- | --- | --- |
| OpenAI Provider | [clients_providers_openai.md](clients_providers_openai.md) | Fine-tuning against the OpenAI API (`OpenAIProvider`, `TrainingJobOpenAI`). |
| Databricks Provider | [clients_providers_databricks.md](clients_providers_databricks.md) | Fine-tuning and serving-endpoint deployment on Databricks (`DatabricksProvider`, `TrainingJobDatabricks`). |
| Local Provider | [clients_providers_local.md](clients_providers_local.md) | Launching local SGLang inference servers and local SFT fine-tuning (`LocalProvider`). |
| Arbor Provider | [clients_providers_arbor.md](clients_providers_arbor.md) | Remote fine-tuning and GRPO reinforcement learning via Arbor (`ArborProvider`, `ArborTrainingJob`, `ArborReinforceJob`). |

## Shared Concepts

All providers rely on shared types and helpers from the [clients_finetune_utils](clients_finetune_utils.md)
module:

- **`TrainDataFormat`** — enum describing the training data layout (`CHAT`, `COMPLETION`, `GRPO_CHAT`).
- **`TrainingStatus`** — enum describing job state (`not_started`, `pending`, `running`, `succeeded`, `failed`, `cancelled`).
- **`save_data`** — serializes training data to a hashed `.jsonl` file in the finetune directory.

The abstract base classes (`Provider`, `TrainingJob`, `ReinforceJob`) are defined in
[clients_core](clients_core.md). Providers are typically wired into the system through the `LM`
client (see [clients_core](clients_core.md)) and driven by teleprompters such as
`BootstrapFinetune` and `GRPO` (see [teleprompt_finetune](teleprompt_finetune.md)).

## Provider Capability Matrix

| Provider | Fine-tunable | Reinforceable | Launch/Kill | Notes |
| --- | :---: | :---: | :---: | --- |
| `OpenAIProvider` | ✅ | ❌ | ❌ | Remote fine-tuning via OpenAI API. |
| `DatabricksProvider` | ✅ | ❌ | ❌ | Fine-tuning + serving endpoint deployment. |
| `LocalProvider` | ✅ | ❌ | ✅ | Local SGLang server + local SFT via TRL. |
| `ArborProvider` | ✅ | ✅ | ✅ | Remote fine-tuning and GRPO RL. |

## Related Modules

- [clients_core](clients_core.md) — abstract `Provider`, `TrainingJob`, `ReinforceJob`, `LM`, `BaseLM`.
- [clients_finetune_utils](clients_finetune_utils.md) — shared training data formats, statuses, and helpers.
- [teleprompt_finetune](teleprompt_finetune.md) — teleprompters (`BootstrapFinetune`, `GRPO`) that drive providers.
