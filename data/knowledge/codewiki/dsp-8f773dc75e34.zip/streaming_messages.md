# Streaming Messages

## Introduction

The `streaming_messages` module (`dspy/streaming/messages.py`) provides the data structures and callback machinery that power **status message streaming** in DSPy. While the sibling [`streaming_listener`](streaming_listener.md) module is responsible for capturing and yielding the *content* of a predictor's output fields token-by-token, this module focuses on a complementary concern: emitting human-readable **status messages** that describe *what the program is currently doing* (e.g., "Calling tool X...", "Querying the LLM...").

The module defines:

- **`StreamResponse`** — the dataclass representing a single streamed content chunk.
- **`StatusMessage`** — a lightweight wrapper around a status string.
- **`StatusMessageProvider`** — a customizable base class for generating status strings at different execution stages.
- **`StatusStreamingCallback`** — a [`BaseCallback`](utils.md) implementation that hooks into DSPy's callback system and pushes status messages onto the active stream.

Together these components let users build rich, real-time UIs that show both the *output* being generated and the *progress* of the underlying program execution.

---

## Architecture Overview

The module sits at the intersection of three subsystems: the **callback system**, the **settings/streaming context**, and the **streaming listener** that consumes the emitted messages.

```mermaid
graph TD
    subgraph "streaming_messages module"
        SR[StreamResponse]
        SM[StatusMessage]
        SMP[StatusMessageProvider]
        SSC[StatusStreamingCallback]
    end

    subgraph "DSPy Core"
        BC[BaseCallback<br/>dspy/utils/callback.py]
        SET[Settings<br/>dspy/dsp/utils/settings.py]
        SL[StreamListener<br/>streaming_listener.py]
    end

    subgraph "Execution Components"
        MOD[Module / Predict]
        LM[LM]
        TOOL[Tool]
    end

    SSC -->|inherits| BC
    SSC -->|uses| SMP
    SSC -->|reads settings.send_stream| SET
    SSC -->|emits| SM
    SM -->|sent to| SET
    SL -->|produces| SR

    MOD -.->|on_module_start/end| SSC
    LM -.->|on_lm_start/end| SSC
    TOOL -.->|on_tool_start/end| SSC
```

### Key Relationships

| Component | Role | Depends On |
|-----------|------|------------|
| `StreamResponse` | Data container for a streamed content chunk | — |
| `StatusMessage` | Data container for a status string | — |
| `StatusMessageProvider` | Generates status strings per lifecycle event | — |
| `StatusStreamingCallback` | Bridges callbacks → stream | `BaseCallback`, `StatusMessageProvider`, `Settings`, `StatusMessage` |

---

## Core Components

### `StreamResponse`

A `@dataclass` that represents a single chunk of streamed *content* (as opposed to status). It is the canonical payload produced by the [`StreamListener`](streaming_listener.md) and consumed by user-facing streaming APIs.

```python
@dataclass
class StreamResponse:
    predict_name: str
    signature_field_name: str
    chunk: str
    is_last_chunk: bool
```

| Field | Type | Description |
|-------|------|-------------|
| `predict_name` | `str` | Name of the predictor that produced the chunk. |
| `signature_field_name` | `str` | The output field being streamed. |
| `chunk` | `str` | The text fragment for this chunk. |
| `is_last_chunk` | `bool` | `True` when this is the final chunk of the field. |

> **Note:** Although `StreamResponse` is defined in this module, it is *produced* by the [`StreamListener`](streaming_listener.md). See that module for the token-buffering and adapter-identifier logic that determines chunk boundaries.

---

### `StatusMessage`

A minimal `@dataclass` wrapper around a status string. Wrapping the string in a dedicated type allows downstream consumers to distinguish status messages from content chunks (`StreamResponse`) when both flow through the same stream.

```python
@dataclass
class StatusMessage:
    """Dataclass that wraps a status message for status streaming."""
    message: str
```

---

### `StatusMessageProvider`

The extensibility point of the module. `StatusMessageProvider` is a base class whose methods are invoked by `StatusStreamingCallback` at each lifecycle event. Each method must return a `str` (or a falsy value to suppress the message).

```python
class StatusMessageProvider:
    def tool_start_status_message(self, instance, inputs): ...
    def tool_end_status_message(self, outputs): ...
    def module_start_status_message(self, instance, inputs): ...
    def module_end_status_message(self, outputs): ...
    def lm_start_status_message(self, instance, inputs): ...
    def lm_end_status_message(self, outputs): ...
```

#### Default Behavior

| Method | Default Return |
|--------|----------------|
| `tool_start_status_message` | `f"Calling tool {instance.name}..."` |
| `tool_end_status_message` | `"Tool calling finished! Querying the LLM with tool calling results..."` |
| `module_start_status_message` | `None` (no message) |
| `module_end_status_message` | `None` (no message) |
| `lm_start_status_message` | `None` (no message) |
| `lm_end_status_message` | `None` (no message) |

Only the tool-related methods emit messages by default; all others are no-ops that subclasses can override.

#### Customization Example

```python
class MyStatusMessageProvider(StatusMessageProvider):
    def lm_start_status_message(self, instance, inputs):
        return f"Calling LM with inputs {inputs}..."

    def module_end_status_message(self, outputs):
        return f"Module finished with output: {outputs}!"

program = dspy.streamify(
    dspy.Predict("q->a"),
    status_message_provider=MyStatusMessageProvider(),
)
```

---

### `StatusStreamingCallback`

A concrete [`BaseCallback`](utils.md) subclass that translates DSPy lifecycle events into `StatusMessage` objects pushed onto the active stream. It is the operational heart of the module.

```python
class StatusStreamingCallback(BaseCallback):
    def __init__(self, status_message_provider: StatusMessageProvider | None = None):
        self.status_message_provider = status_message_provider or StatusMessageProvider()
```

#### Implemented Handlers

The callback overrides six of the handlers defined by `BaseCallback`:

| Handler | Provider Method Called | Special Guard |
|---------|------------------------|---------------|
| `on_tool_start` | `tool_start_status_message` | Skips if `instance.name == "finish"` |
| `on_tool_end` | `tool_end_status_message` | Skips if `outputs == "Completed."` |
| `on_lm_start` | `lm_start_status_message` | — |
| `on_lm_end` | `lm_end_status_message` | — |
| `on_module_start` | `module_start_status_message` | — |
| `on_module_end` | `module_end_status_message` | — |

Every handler follows the same pattern:

1. Read the active stream from `settings.send_stream`.
2. If no stream is configured, return early (no-op).
3. Ask the provider for a status string.
4. If the string is truthy, send a `StatusMessage` to the stream.

```python
def on_lm_start(self, call_id, instance, inputs):
    stream = settings.send_stream
    if stream is None:
        return
    status_message = self.status_message_provider.lm_start_status_message(instance, inputs)
    if status_message:
        sync_send_to_stream(stream, StatusMessage(status_message))
```

---

## The Sync-to-Async Bridge: `sync_send_to_stream`

DSPy callbacks are invoked synchronously, but streams are asynchronous (`await stream.send(...)`). The module provides a helper that safely bridges this gap regardless of whether an event loop is already running in the current thread.

```python
def sync_send_to_stream(stream, message):
    async def _send():
        await stream.send(message)

    try:
        asyncio.get_running_loop()
        # Event loop is running → offload to a new thread with its own loop
        def run_in_new_loop():
            new_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(new_loop)
            try:
                return new_loop.run_until_complete(_send())
            finally:
                new_loop.close()

        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
            future = executor.submit(run_in_new_loop)
            return future.result()
    except RuntimeError:
        # No running loop → safe to use syncify in this thread
        return syncify(_send)()
```

### Decision Flow

```mermaid
flowchart TD
    A[sync_send_to_stream called] --> B{asyncio.get_running_loop<br/>raises RuntimeError?}
    B -->|No - loop running| C[Spawn ThreadPoolExecutor]
    C --> D[Create new event loop in worker thread]
    D --> E[run_until_complete _send]
    E --> F[Close loop, return result]
    B -->|Yes - no loop| G[Use asyncer.syncify]
    G --> H[Run _send synchronously]
```

This design ensures status messages can be emitted from both synchronous and asynchronous execution contexts without raising `RuntimeError: This event loop is already running`.

---

## Data Flow

The following sequence diagram shows how a status message travels from a lifecycle event to the consumer.

```mermaid
sequenceDiagram
    participant Exec as Execution (Module/LM/Tool)
    participant CB as StatusStreamingCallback
    participant Prov as StatusMessageProvider
    participant Sync as sync_send_to_stream
    participant Stream as settings.send_stream
    participant Consumer as Consumer (UI/CLI)

    Exec->>CB: on_lm_start(call_id, instance, inputs)
    CB->>CB: stream = settings.send_stream
    alt stream is None
        CB-->>Exec: return (no-op)
    else stream configured
        CB->>Prov: lm_start_status_message(instance, inputs)
        Prov-->>CB: "Calling LM..."
        alt message is truthy
            CB->>Sync: sync_send_to_stream(stream, StatusMessage(msg))
            Sync->>Stream: await stream.send(StatusMessage)
            Stream-->>Consumer: StatusMessage
        end
    end
```

### Message Type Discrimination

Both content and status flow through the same stream, so consumers must discriminate by type:

```mermaid
graph LR
    Stream[Stream] --> SR[StreamResponse<br/>content chunk]
    Stream --> SM[StatusMessage<br/>status string]
    SR --> UI1[Render output text]
    SM --> UI2[Render progress indicator]
```

---

## Integration with the Broader System

### Callback System

`StatusStreamingCallback` extends [`BaseCallback`](utils.md), which defines the full set of lifecycle hooks (`on_module_*`, `on_lm_*`, `on_adapter_*`, `on_tool_*`, `on_evaluate_*`). This module only overrides the subset relevant to status streaming. For details on registering callbacks globally or per-component, see the [callback documentation](utils.md).

### Settings and Streaming Context

The callback reads `settings.send_stream` from the global [`Settings`](dsp_utils.md) singleton. This attribute is populated by `dspy.streamify(...)` when a program is wrapped for streaming. If `send_stream` is `None`, all handlers become no-ops — meaning the callback is safe to register even when streaming is not active.

### Streaming Listener

The [`StreamListener`](streaming_listener.md) is the counterpart that captures *content* streaming. It produces `StreamResponse` objects (defined here) by parsing adapter-specific identifiers (`[[ ## field ## ]]` for `ChatAdapter`, `"field":` for `JSONAdapter`, `<field>` for `XMLAdapter`). The two modules are typically used together via `dspy.streamify`.

```mermaid
graph TD
    subgraph "dspy.streamify"
        SL[StreamListener] -->|StreamResponse| OUT[Stream Output]
        SSC[StatusStreamingCallback] -->|StatusMessage| OUT
    end
    OUT --> USER[User Application]
```

---

## Summary

| Aspect | Detail |
|--------|--------|
| **Primary purpose** | Emit human-readable status messages during DSPy program execution |
| **Key abstraction** | `StatusMessageProvider` (customizable) + `StatusStreamingCallback` (wiring) |
| **Data types** | `StatusMessage` (status), `StreamResponse` (content) |
| **Concurrency handling** | `sync_send_to_stream` bridges sync callbacks to async streams |
| **Configuration source** | `settings.send_stream` (set by `dspy.streamify`) |
| **Related modules** | [`streaming_listener`](streaming_listener.md), [`utils` (callbacks)](utils.md), [`dsp_utils` (settings)](dsp_utils.md) |

### Extension Points

1. **Subclass `StatusMessageProvider`** to customize status text for any lifecycle event.
2. **Register `StatusStreamingCallback`** via `dspy.streamify(..., status_message_provider=...)` or through the global callback configuration.
3. **Consume the stream** by discriminating between `StatusMessage` and `StreamResponse` instances.
