# Teleprompt Core Base

## Introduction

The `teleprompt_core_base` module provides the foundational abstraction for **teleprompters** (also known as optimizers) in DSPy. A teleprompter is a component that takes a DSPy program (a `Module`) and a training set, and produces an *optimized* version of that program — typically by selecting, generating, or refining the demonstrations (few-shot examples) and/or instructions that populate the program's predictors.

This module defines the single base class `Teleprompter`, which establishes the common interface that all concrete teleprompters must implement. It is the root of the entire teleprompt hierarchy, including the core teleprompters (`LabeledFewShot`, `BootstrapFewShot`, `BootstrapFewShotWithRandomSearch`, `Ensemble`, `KNNFewShot`), the advanced optimizers (`COPRO`, `MIPROv2`, `SIMBA`, `GEPA`), and the fine-tuning teleprompters (`BootstrapFinetune`, `GRPO`).

> **Note:** This module is intentionally minimal. It defines the *contract* for optimization; the actual optimization logic lives in the concrete subclasses. See the related module documentation for each concrete implementation.

---

## Module Purpose and Core Functionality

The `teleprompt_core_base` module serves three primary purposes:

1. **Interface Definition** — It declares the `compile` method that every teleprompter must implement, providing a uniform API for program optimization.
2. **Parameter Introspection** — It provides `get_params`, a generic mechanism for retrieving the configuration of a teleprompter instance.
3. **Polymorphic Dispatch** — By acting as a common base class, it allows the rest of DSPy to treat any teleprompter uniformly (e.g., calling `.compile(...)` without knowing the concrete optimizer type).

### The `Teleprompter` Class

The `Teleprompter` class is the only component in this module. It is a lightweight abstract base class with no state of its own.

| Member | Signature | Description |
| --- | --- | --- |
| `__init__` | `()` | No-op constructor. Subclasses typically define their own `__init__` to store hyperparameters (e.g., `k`, `metric`, `max_bootstrapped_demos`). |
| `compile` | `(student, *, trainset, teacher=None, valset=None, **kwargs) -> Module` | The core optimization entry point. Raises `NotImplementedError` in the base class; must be overridden. |
| `get_params` | `() -> dict[str, Any]` | Returns the instance's `__dict__`, exposing all stored hyperparameters. |

#### `compile`

```python
def compile(
    self,
    student: Module,
    *,
    trainset: list[Example],
    teacher: Module | None = None,
    valset: list[Example] | None = None,
    **kwargs,
) -> Module:
    raise NotImplementedError
```

The `compile` method is the heart of the teleprompter contract:

- **`student`** — The program to be optimized. Concrete implementations typically operate on a *copy* of the student (via `reset_copy()` or `deepcopy()`) so the original is left untouched.
- **`trainset`** — The labeled examples used to drive optimization. These are `Example` objects (see [primitives_example](primitives_example.md)).
- **`teacher`** — An optional, typically stronger program used to generate demonstrations or guidance for the student. When omitted, the student itself is often used as the teacher.
- **`valset`** — An optional validation set, used by optimizers that need held-out data (e.g., for early stopping or candidate selection).
- **`**kwargs`** — Allows concrete teleprompters to accept additional, optimizer-specific arguments (e.g., `sample=True` for `LabeledFewShot`).

The method returns the optimized `Module`.

#### `get_params`

```python
def get_params(self) -> dict[str, Any]:
    return self.__dict__
```

A simple introspection helper that returns the teleprompter's instance dictionary. This is useful for logging, serialization, and reproducibility, since concrete teleprompters store their hyperparameters as instance attributes.

---

## Architecture and Component Relationships

The `Teleprompter` base class sits at the top of the teleprompt inheritance hierarchy. Every concrete teleprompter subclasses it and overrides `compile`.

```mermaid
classDiagram
    class Teleprompter {
        +__init__()
        +compile(student, *, trainset, teacher, valset, **kwargs) Module
        +get_params() dict
    }

    class LabeledFewShot {
        +k: int
        +compile(student, *, trainset, sample)
    }
    class BootstrapFewShot {
        +metric
        +max_bootstrapped_demos
        +max_labeled_demos
        +compile(student, *, teacher, trainset)
    }
    class BootstrapFewShotWithRandomSearch
    class Ensemble
    class KNNFewShot
    class COPRO
    class MIPROv2
    class SIMBA
    class GEPA
    class BootstrapFinetune
    class GRPO

    Teleprompter <|-- LabeledFewShot
    Teleprompter <|-- BootstrapFewShot
    Teleprompter <|-- BootstrapFewShotWithRandomSearch
    Teleprompter <|-- Ensemble
    Teleprompter <|-- KNNFewShot
    Teleprompter <|-- COPRO
    Teleprompter <|-- MIPROv2
    Teleprompter <|-- SIMBA
    Teleprompter <|-- GEPA
    Teleprompter <|-- BootstrapFinetune
    Teleprompter <|-- GRPO
```

### Position Within the Teleprompt Module Tree

The `teleprompt_core_base` module is the base of the `teleprompt_core` group, which also contains the primary, ready-to-use optimizers.

```mermaid
graph TD
    subgraph teleprompt_core
        BASE[teleprompt_core_base<br/>Teleprompter]
        LFS[teleprompt_core_labeled_fewshot<br/>LabeledFewShot]
        BS[teleprompt_core_bootstrap<br/>BootstrapFewShot]
        RS[teleprompt_core_random_search<br/>BootstrapFewShotWithRandomSearch]
        ENS[teleprompt_core_ensemble<br/>Ensemble]
        KNN[teleprompt_core_knn_fewshot<br/>KNNFewShot]
    end

    subgraph teleprompt_optimizers
        COPRO
        MIPRO
        SIMBA
        SIGOPT[SignatureOptimizer]
        OPTUNA[BootstrapFewShotWithOptuna]
    end

    subgraph teleprompt_finetune
        BFT[BootstrapFinetune]
        GRPO
    end

    subgraph teleprompt_gepa
        GEPA
    end

    BASE --> LFS
    BASE --> BS
    BASE --> RS
    BASE --> ENS
    BASE --> KNN
    BASE --> COPRO
    BASE --> MIPRO
    BASE --> SIMBA
    BASE --> SIGOPT
    BASE --> OPTUNA
    BASE --> BFT
    BASE --> GRPO
    BASE --> GEPA

    BS --> RS
    BS --> OPTUNA
    BS --> BFT
```

---

## Dependencies

The `Teleprompter` base class depends on two core primitives from the `primitives` module, used purely for type annotations:

```mermaid
graph LR
    TP[Teleprompter] -->|type hint| MOD[Module<br/>primitives_module]
    TP -->|type hint| EX[Example<br/>primitives_example]
```

| Dependency | Purpose | Documentation |
| --- | --- | --- |
| `Module` | The type of the `student` and `teacher` programs being optimized. | [primitives_module](primitives_module.md) |
| `Example` | The type of elements in `trainset` and `valset`. | [primitives_example](primitives_example.md) |

Because these are only used as type annotations, the base class has no runtime coupling to the primitives beyond import.

---

## Data Flow

The following diagram illustrates the generic optimization flow that all teleprompters follow, from the caller's perspective through the `compile` contract.

```mermaid
sequenceDiagram
    participant User
    participant Teleprompter as Teleprompter (concrete)
    participant Student as Module (student)
    participant Teacher as Module (teacher, optional)
    participant Trainset as list[Example]

    User->>Teleprompter: compile(student, trainset=..., teacher=...)
    Teleprompter->>Student: reset_copy() / deepcopy()
    Note over Teleprompter: Optimize demos / instructions<br/>(optimizer-specific logic)
    opt Teacher provided
        Teleprompter->>Teacher: run on trainset to generate demos
        Teacher-->>Teleprompter: traces / predictions
    end
    Teleprompter->>Student: assign optimized demos/instructions
    Teleprompter-->>User: optimized Module
```

### Key Data Flow Characteristics

1. **Non-destructive optimization** — Concrete teleprompters operate on a copy of the student, preserving the original program.
2. **Teacher-driven bootstrapping** — Optimizers such as `BootstrapFewShot` use the teacher to generate traces, which are then filtered by a metric and attached to the student's predictors as demonstrations.
3. **Metric-gated acceptance** — When a `metric` is supplied, candidate demonstrations are only accepted if they pass the metric (optionally against a `metric_threshold`).

---

## Component Interaction: How Concrete Teleprompters Use the Base

The base class defines the contract; concrete subclasses fill in the behavior. The table below summarizes how the two simplest core teleprompters implement the contract.

| Teleprompter | `compile` signature | Strategy |
| --- | --- | --- |
| `LabeledFewShot` | `compile(student, *, trainset, sample=True)` | Randomly samples `k` labeled examples from `trainset` and assigns them as demos to every predictor. No teacher or metric required. |
| `BootstrapFewShot` | `compile(student, *, teacher=None, trainset)` | Uses a teacher to generate traces on the trainset, filters them with a metric, and combines bootstrapped demos with labeled demos. |

### Example: `LabeledFewShot` (simplest subclass)

```python
class LabeledFewShot(Teleprompter):
    def __init__(self, k=16):
        self.k = k

    def compile(self, student, *, trainset, sample=True):
        self.student = student.reset_copy()
        self.trainset = trainset
        # ... sample k demos and assign to each predictor ...
        return self.student
```

### Example: `BootstrapFewShot` (teacher-driven subclass)

```python
class BootstrapFewShot(Teleprompter):
    def __init__(self, metric=None, metric_threshold=None, ...):
        self.metric = metric
        self.metric_threshold = metric_threshold
        # ...

    def compile(self, student, *, teacher=None, trainset):
        self.trainset = trainset
        self._prepare_student_and_teacher(student, teacher)
        self._prepare_predictor_mappings()
        self._bootstrap()
        self.student = self._train()
        self.student._compiled = True
        return self.student
```

Both subclasses store their hyperparameters as instance attributes, which is exactly what `get_params` exposes via `self.__dict__`.

---

## Process Flow: The `compile` Contract

The following flowchart captures the general decision process that a concrete teleprompter follows when implementing `compile`.

```mermaid
flowchart TD
    START([compile called]) --> COPY[Copy the student program]
    COPY --> HAS_TEACHER{Teacher provided?}
    HAS_TEACHER -- Yes --> USE_TEACHER[Use teacher to generate demos/traces]
    HAS_TEACHER -- No --> USE_STUDENT[Use student as its own teacher]
    USE_TEACHER --> METRIC{Metric provided?}
    USE_STUDENT --> METRIC
    METRIC -- Yes --> FILTER[Filter candidates by metric / threshold]
    METRIC -- No --> ACCEPT[Accept all candidates]
    FILTER --> ASSIGN[Assign demos/instructions to predictors]
    ACCEPT --> ASSIGN
    ASSIGN --> MARK[Mark student as compiled]
    MARK --> RETURN([Return optimized Module])
```

---

## Related Modules

The `teleprompt_core_base` module is the foundation for a large family of optimizers. Refer to the following documentation for concrete implementations:

### Core Teleprompters
- [teleprompt_core_labeled_fewshot](teleprompt_core_labeled_fewshot.md) — `LabeledFewShot`
- [teleprompt_core_bootstrap](teleprompt_core_bootstrap.md) — `BootstrapFewShot`
- [teleprompt_core_random_search](teleprompt_core_random_search.md) — `BootstrapFewShotWithRandomSearch`
- [teleprompt_core_ensemble](teleprompt_core_ensemble.md) — `Ensemble`
- [teleprompt_core_knn_fewshot](teleprompt_core_knn_fewshot.md) — `KNNFewShot`

### Advanced Optimizers
- [teleprompt_optimizers](teleprompt_optimizers.md) — `COPRO`, `MIPROv2`, `SIMBA`, `SignatureOptimizer`, `BootstrapFewShotWithOptuna`
- [teleprompt_gepa](teleprompt_gepa.md) — `GEPA`
- [teleprompt_finetune](teleprompt_finetune.md) — `BootstrapFinetune`, `GRPO`, `BetterTogether`
- [teleprompt_avatar](teleprompt_avatar.md) — `AvatarOptimizer`

### Supporting Primitives
- [primitives_module](primitives_module.md) — `Module`, `BaseModule`, `ProgramMeta`
- [primitives_example](primitives_example.md) — `Example`
- [predict_core](predict_core.md) — `Predict`, `Parameter` (the predictors whose demos are optimized)
- [evaluate](evaluate.md) — `Evaluate` (used by optimizers to score candidates)
