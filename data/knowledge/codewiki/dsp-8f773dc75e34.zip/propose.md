# Propose Module

## Overview

The **propose** module is responsible for **automatically generating new instructions (prompts) for the predictors of a DSPy program**. It is the "instruction proposal" engine that sits at the heart of prompt-optimization teleprompters such as [`MIPROv2`](teleprompt_optimizers.md), [`COPRO`](teleprompt_optimizers.md), and [`SIMBA`](teleprompt_optimizers.md).

Rather than hand-writing prompts, DSPy programs can delegate the task of writing better prompts to a *proposer*. A proposer inspects the program, the training data, and (optionally) the history of previously attempted instructions, then asks a language model to synthesize a fresh, task-aware instruction for each predictor.

The module is intentionally small and focused. It exposes:

- An abstract **`Proposer`** interface that defines the contract for any instruction-proposal strategy.
- A concrete, feature-rich implementation, **`GroundedProposer`**, which "grounds" its proposals in the dataset, the program source code, few-shot demonstrations, and prompting tips.
- A **dataset summary generator** that distills a training set into a compact natural-language description used to inform instruction generation.

## Purpose and Core Functionality

The propose module answers a single question:

> *"Given a program and some data, what instruction should each predictor use to perform its sub-task better?"*

To answer this, it combines several sources of "grounding" context:

| Grounding signal | Description | Controlled by |
| --- | --- | --- |
| **Dataset summary** | A natural-language description of the training data (topics, format, task nature). | `use_dataset_summary` |
| **Program awareness** | The source code of the program plus a generated description of the program and each module. | `program_aware` |
| **Task demos** | Few-shot input/output examples drawn from bootstrapped demo candidates. | `use_task_demos` |
| **Instruction history** | Previously proposed instructions and their associated scores. | `use_instruct_history` |
| **Prompting tips** | Short stylistic hints (e.g. "be creative", "use a persona"). | `use_tip` |

Each of these signals can be toggled on or off, allowing callers to trade off cost, latency, and proposal quality.

## Architecture

The module is organized into three cooperating layers: an abstract interface, a concrete proposer, and a supporting dataset-summary generator.

```mermaid
graph TD
    subgraph "propose module"
        PB["Proposer<br/>(abstract base)"]
        GP["GroundedProposer<br/>(concrete implementation)"]
        GMI["GenerateModuleInstruction<br/>(dspy.Module)"]
        DSG["Dataset Summary Generator<br/>(create_dataset_summary)"]
        UTILS["utils<br/>(source code, examples, history, prefix stripping)"]
    end

    subgraph "External dependencies"
        SIG["dspy.Signature / dspy.Predict"]
        MOD["dspy.Module / Predict"]
        TPUTILS["teleprompt.utils<br/>(get_prompt_model, get_signature)"]
        SETTINGS["dspy.settings"]
    end

    PB -->|inherited by| GP
    GP -->|uses| GMI
    GP -->|uses| DSG
    GP -->|uses| UTILS
    GMI -->|uses| UTILS
    DSG -->|uses| UTILS
    GMI -->|built on| SIG
    GP -->|built on| MOD
    GP -->|uses| TPUTILS
    DSG -->|uses| SETTINGS
```

### Component Relationships

```mermaid
classDiagram
    class Proposer {
        <<abstract>>
        +propose_instructions_for_program()
        +propose_instruction_for_predictor()
    }
    class GroundedProposer {
        +prompt_model
        +program
        +trainset
        +program_aware
        +use_dataset_summary
        +use_task_demos
        +use_instruct_history
        +use_tip
        +propose_instructions_for_program(trainset, program, demo_candidates, trial_logs, N, T)
        +propose_instruction_for_predictor(...)
    }
    class GenerateModuleInstruction {
        +forward(demo_candidates, pred_i, demo_set_i, program, previous_instructions, data_summary, ...)
    }
    class DescribeProgram {
        <<Signature>>
    }
    class DescribeModule {
        <<Signature>>
    }
    class DatasetDescriptor {
        <<Signature>>
    }
    class DatasetDescriptorWithPriorObservations {
        <<Signature>>
    }
    class ObservationSummarizer {
        <<Signature>>
    }

    Proposer <|-- GroundedProposer
    GroundedProposer --> GenerateModuleInstruction : creates
    GenerateModuleInstruction --> DescribeProgram : uses
    GenerateModuleInstruction --> DescribeModule : uses
    GroundedProposer --> DatasetDescriptor : indirectly via summary
    DatasetDescriptorWithPriorObservations --> ObservationSummarizer : feeds
```

## Sub-modules

The propose module is split into the following documented sub-modules:

### 1. Grounded Proposer — [`propose_grounded.md`](propose_grounded.md)

The core of the module. It contains:

- **`GroundedProposer`** — the concrete `Proposer` implementation. It orchestrates the whole proposal process: it optionally builds a dataset summary and extracts the program source code at construction time, then iterates over every predictor and every demo set to produce a list of candidate instructions. It supports randomized selection of tips and instruction-history usage to encourage diversity across proposals.
- **`GenerateModuleInstruction`** — a `dspy.Module` that performs the actual instruction synthesis for a single predictor. It gathers task demos, optionally describes the program and the target module, and calls a dynamically-constructed generation signature.
- **`DescribeProgram`** / **`DescribeModule`** — `dspy.Signature` definitions used to produce natural-language descriptions of the whole program and of individual modules, enabling "program-aware" proposals.

See [`propose_grounded.md`](propose_grounded.md) for full details.

### 2. Dataset Summary Generator — [`propose_dataset_summary.md`](propose_dataset_summary.md)

Provides the `create_dataset_summary` function and the signatures it relies on:

- **`DatasetDescriptor`** — produces initial observations about a batch of examples.
- **`DatasetDescriptorWithPriorObservations`** — incrementally augments observations across batches, stopping early when the model reports `COMPLETE`.
- **`ObservationSummarizer`** — condenses all accumulated observations into a concise 2–3 sentence summary.

See [`propose_dataset_summary.md`](propose_dataset_summary.md) for full details.

### 3. Proposer Base Interface

Defined in `dspy/propose/propose_base.py`, the `Proposer` abstract base class establishes the contract that all proposers must satisfy:

```python
class Proposer(ABC):
    @abstractmethod
    def propose_instructions_for_program(self):
        pass

    def propose_instruction_for_predictor(self):
        pass
```

- **`propose_instructions_for_program`** (abstract) — returns the full set of new instructions for an entire program.
- **`propose_instruction_for_predictor`** (optional override) — returns a single instruction for one predictor.

This minimal interface allows alternative proposal strategies to be plugged into optimizers without changing the optimizer code.

## How the Module Fits into the System

The propose module is a **dependency of the prompt-optimization teleprompters**. It does not run on its own; it is invoked during the "propose instruction candidates" phase of optimization.

```mermaid
sequenceDiagram
    participant Opt as MIPROv2 / COPRO / SIMBA
    participant GP as GroundedProposer
    participant DSG as Dataset Summary Generator
    participant GMI as GenerateModuleInstruction
    participant LM as Prompt LM

    Opt->>GP: __init__(program, trainset, prompt_model, flags...)
    GP->>DSG: create_dataset_summary(trainset, ...)
    DSG->>LM: DatasetDescriptor / ...WithPriorObservations / ObservationSummarizer
    LM-->>DSG: summary text
    DSG-->>GP: data_summary
    GP->>GP: get_dspy_source_code(program)

    Opt->>GP: propose_instructions_for_program(trainset, program, demo_candidates, N, T)
    loop for each predictor, each demo set
        GP->>GMI: propose_instruction_for_predictor(...)
        GMI->>LM: DescribeProgram / DescribeModule
        GMI->>LM: GenerateSingleModuleInstruction
        LM-->>GMI: proposed_instruction
        GMI-->>GP: proposed_instruction
    end
    GP-->>Opt: {pred_i: [instruction, ...]}
```

### Upstream consumers

- **[`MIPROv2`](teleprompt_optimizers.md)** — instantiates a `GroundedProposer` in its `_propose_instructions` step, passing flags such as `program_aware_proposer`, `data_aware_proposer`, `tip_aware_proposer`, and `fewshot_aware_proposer`. The returned `instruction_candidates` dictionary is then fed into Bayesian optimization (Optuna) to select the best combination of instructions and demos.
- **[`COPRO`](teleprompt_optimizers.md)** and **[`SIMBA`](teleprompt_optimizers.md)** — implement their own instruction-generation loops but share the same conceptual role (proposing candidate instructions) and reuse related signatures/utilities.

### Downstream dependencies

- **[`signatures`](signatures.md)** — the `DescribeProgram`, `DescribeModule`, and dataset-summary signatures are all `dspy.Signature` subclasses, and instruction generation is performed via `dspy.Predict`.
- **[`primitives`](primitives.md)** — `GenerateModuleInstruction` is a `dspy.Module`, and proposals are returned as `dspy.Prediction` objects.
- **[`clients_core`](clients_core.md)** — the `prompt_model` (an `LM`) is used to run all generation calls, with temperature adjusted per proposal round.
- **[`teleprompt_core`](teleprompt_core.md)** / teleprompt utilities — `get_prompt_model` and `get_signature` helpers are used to resolve the prompt LM and read predictor signatures.

## Key Design Notes

- **Grounding is optional and composable.** Every grounding signal (dataset summary, program awareness, task demos, instruction history, tips) is independently toggleable, and the module degrades gracefully: if source-code extraction or dataset summarization fails, the corresponding flag is disabled and proposal continues without it.
- **Diversity through randomization.** `GroundedProposer` can randomly decide whether to use instruction history and randomly select a prompting tip per proposal, which helps produce a diverse candidate pool for downstream search.
- **Temperature control.** Each proposal round uses a caller-specified temperature `T` plus a small random epsilon, allowing the optimizer to explore at different creativity levels.
- **Prefix stripping.** Generated instructions are post-processed with `strip_prefix` to remove any leading field labels the LM may have echoed back.

## Related Documentation

- [Grounded Proposer](propose_grounded.md)
- [Dataset Summary Generator](propose_dataset_summary.md)
- [Teleprompt Optimizers](teleprompt_optimizers.md)
- [Signatures](signatures.md)
- [Primitives](primitives.md)
- [Clients Core](clients_core.md)
