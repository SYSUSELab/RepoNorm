# Teleprompt Core

## Overview

The **Teleprompt Core** module provides the foundational optimization (a.k.a. "compilation") framework for DSPy programs. In DSPy terminology, a *teleprompter* is an optimizer that takes an uncompiled `Module` (the "student") together with a training set and produces an optimized version of that module — typically by attaching demonstrations (few-shot examples) to its predictors, or by wrapping it in a more capable execution strategy.

This module contains the base abstraction (`Teleprompter`) and a set of lightweight, self-contained optimizers that do **not** require an external LM-driven instruction search. These optimizers focus on **demonstration selection and composition**:

- **`LabeledFewShot`** — attaches a fixed number of labeled examples as demos.
- **`BootstrapFewShot`** — generates ("bootstraps") demonstrations by running a teacher program and keeping traces that pass a metric.
- **`BootstrapFewShotWithRandomSearch`** — runs `BootstrapFewShot` across many random seeds and selects the best-scoring candidate program.
- **`Ensemble`** — combines multiple programs and reduces their outputs (e.g., via majority vote).
- **`KNNFewShot`** — dynamically selects the k nearest training examples at inference time using an embedding-based retriever.

> For heavier, LM-driven optimizers (e.g., `MIPROv2`, `COPRO`, `SIMBA`, `GEPA`, finetuning), see the sibling modules [teleprompt_optimizers](teleprompt_optimizers.md), [teleprompt_gepa](teleprompt_gepa.md), and [teleprompt_finetune](teleprompt_finetune.md).

## Architecture

All optimizers in this module inherit from the abstract `Teleprompter` base class, which defines the common `compile(...)` contract. The optimizers build on top of each other: `BootstrapFewShotWithRandomSearch` composes `BootstrapFewShot` and `LabeledFewShot`, while `KNNFewShot` composes `BootstrapFewShot` with a `KNN` retriever.

```mermaid
graph TD
    Teleprompter["Teleprompter (abstract base)"]

    Teleprompter --> LabeledFewShot
    Teleprompter --> BootstrapFewShot
    Teleprompter --> BootstrapFewShotWithRandomSearch
    Teleprompter --> Ensemble
    Teleprompter --> KNNFewShot

    BootstrapFewShotWithRandomSearch -->|uses| BootstrapFewShot
    BootstrapFewShotWithRandomSearch -->|uses| LabeledFewShot
    BootstrapFewShot -->|uses| LabeledFewShot
    KNNFewShot -->|uses| BootstrapFewShot
    KNNFewShot -->|uses| KNN

    BootstrapFewShotWithRandomSearch -->|evaluates with| Evaluate
    BootstrapFewShot -->|operates on| Module
    LabeledFewShot -->|operates on| Module
    Ensemble -->|wraps| Module
    KNNFewShot -->|operates on| Module

    BootstrapFewShot -->|consumes| Example
    LabeledFewShot -->|consumes| Example
    KNNFewShot -->|consumes| Example
    KNN -->|uses| Embedder
```

## Core Components

### `Teleprompter` (base class)

Defined in `dspy/teleprompt/teleprompt.py`, `Teleprompter` is the abstract base for all optimizers. It declares the `compile(student, *, trainset, teacher=None, valset=None, **kwargs)` interface that every optimizer must implement, and provides a `get_params()` helper that returns the optimizer's configuration via `self.__dict__`.

See [teleprompt_core_base](teleprompt_core_base.md) for details.

### `LabeledFewShot`

Defined in `dspy/teleprompt/vanilla.py`, this is the simplest optimizer. It resets a copy of the student and assigns a fixed number (`k`) of labeled examples from the trainset as demonstrations to every predictor. Sampling can be random (seeded for reproducibility) or deterministic (first `k` examples).

See [teleprompt_core_labeled_fewshot](teleprompt_core_labeled_fewshot.md) for details.

### `BootstrapFewShot`

Defined in `dspy/teleprompt/bootstrap.py`, this optimizer generates demonstrations by executing a *teacher* program on the training set and capturing the intermediate traces. Traces that pass the supplied metric are converted into augmented `Example` demos and attached to the corresponding student predictors. It also mixes in labeled demos up to `max_labeled_demos`.

See [teleprompt_core_bootstrap](teleprompt_core_bootstrap.md) for details.

### `BootstrapFewShotWithRandomSearch`

Defined in `dspy/teleprompt/random_search.py`, this optimizer runs `BootstrapFewShot` (and baseline variants) across a range of random seeds, evaluates each candidate program on a validation set, and returns the best-scoring program. All candidates are attached to the returned program via `candidate_programs`.

See [teleprompt_core_random_search](teleprompt_core_random_search.md) for details.

### `Ensemble`

Defined in `dspy/teleprompt/ensemble.py`, this optimizer wraps a list of programs into a single `EnsembledProgram` module. On each forward call it runs all (or a random sample of `size`) programs and combines their outputs using a `reduce_fn` (commonly `dspy.majority`).

See [teleprompt_core_ensemble](teleprompt_core_ensemble.md) for details.

### `KNNFewShot`

Defined in `dspy/teleprompt/knn_fewshot.py`, this optimizer performs *test-time* few-shot selection. It builds a `KNN` retriever over the trainset using an `Embedder`, and at each forward call retrieves the `k` most similar examples and bootstraps them into the student via `BootstrapFewShot`.

See [teleprompt_core_knn_fewshot](teleprompt_core_knn_fewshot.md) for details.

## Data Flow

The typical compilation flow for the demonstration-based optimizers is:

```mermaid
sequenceDiagram
    participant User
    participant Optimizer as Teleprompter
    participant Teacher as Teacher Module
    participant Student as Student Module
    participant Metric

    User->>Optimizer: compile(student, trainset, teacher, ...)
    Optimizer->>Student: reset_copy() / deepcopy()
    Optimizer->>Teacher: prepare (LabeledFewShot if uncompiled)
    loop For each training example
        Optimizer->>Teacher: run example.inputs()
        Teacher-->>Optimizer: prediction + trace
        Optimizer->>Metric: metric(example, prediction, trace)
        Metric-->>Optimizer: score / bool
        Optimizer->>Optimizer: keep passing traces as demos
    end
    Optimizer->>Student: attach demos to predictors
    Optimizer-->>User: compiled student (student._compiled = True)
```

## Relationship to Other Modules

| Dependency | Purpose |
| --- | --- |
| [primitives](primitives.md) (`Module`, `Example`) | The programs being optimized and the data units consumed/produced. |
| [predict_core](predict_core.md) (`Predict`) | The predictors whose `demos` are populated by these optimizers. |
| [evaluate](evaluate.md) (`Evaluate`) | Used by `BootstrapFewShotWithRandomSearch` to score candidate programs. |
| [predict_advanced](predict_advanced.md) (`KNN`) | The retriever used by `KNNFewShot`. |
| [clients_core](clients_core.md) (`Embedder`) | Provides embeddings for the KNN retriever. |
| [dsp_utils](dsp_utils.md) (`Settings`) | Global settings (LM, trace, max_errors) used during bootstrapping. |

## Sub-module Documentation

- [teleprompt_core_base](teleprompt_core_base.md) — The `Teleprompter` abstract base class.
- [teleprompt_core_labeled_fewshot](teleprompt_core_labeled_fewshot.md) — `LabeledFewShot` optimizer.
- [teleprompt_core_bootstrap](teleprompt_core_bootstrap.md) — `BootstrapFewShot` optimizer.
- [teleprompt_core_random_search](teleprompt_core_random_search.md) — `BootstrapFewShotWithRandomSearch` optimizer.
- [teleprompt_core_ensemble](teleprompt_core_ensemble.md) — `Ensemble` optimizer.
- [teleprompt_core_knn_fewshot](teleprompt_core_knn_fewshot.md) — `KNNFewShot` optimizer.
