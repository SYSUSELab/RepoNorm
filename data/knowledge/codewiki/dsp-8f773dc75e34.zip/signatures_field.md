# Signatures Field Module

## Introduction

The `signatures_field` module (`dspy/signatures/field.py`) provides the field-definition primitives used to declare the inputs and outputs of a DSPy [`Signature`](signatures_signature.md). It bridges DSPy's ergonomic field API (`InputField` / `OutputField`) with Pydantic's `Field` machinery, and it retains a legacy set of "old" field classes (`OldField`, `OldInputField`, `OldOutputField`) used for backward compatibility and internal conversions.

The module is responsible for:

- Translating DSPy-specific field arguments (`desc`, `prefix`, `format`, `parser`) into Pydantic's `json_schema_extra` dictionary.
- Translating Pydantic validation constraints (e.g. `gt`, `max_length`) into human-readable descriptions that can be embedded in prompts.
- Providing the `InputField` and `OutputField` factory functions that users call when declaring signatures.
- Providing the legacy `OldField` hierarchy and a `new_to_old_field` conversion helper.

> For the class that consumes these fields, see the [Signatures Signature module](signatures_signature.md).

---

## Architecture Overview

The module sits at the boundary between DSPy's declarative signature API and Pydantic's data-validation layer. Fields created here are stored as Pydantic `FieldInfo` objects whose `json_schema_extra` dictionary carries DSPy metadata.

```mermaid
graph TD
    User["User code<br/>class MySig(Signature):<br/>  q = InputField(desc=...)"]
    subgraph field_module["dspy/signatures/field.py"]
        IF["InputField()"]
        OF["OutputField()"]
        MK["move_kwargs()"]
        TR["_translate_pydantic_field_constraints()"]
        N2O["new_to_old_field()"]
        OldF["OldField"]
        OldIF["OldInputField"]
        OldOF["OldOutputField"]
    end
    Pyd["pydantic.Field"]
    SigMeta["SignatureMeta<br/>(signatures_signature.md)"]
    Sig["Signature"]

    User --> IF
    User --> OF
    IF --> MK
    OF --> MK
    MK --> TR
    MK --> Pyd
    Pyd --> SigMeta
    SigMeta --> Sig
    N2O --> OldIF
    N2O --> OldOF
    OldIF --> OldF
    OldOF --> OldF
```

---

## Core Components

### Field Factory Functions

#### `InputField(**kwargs)`

Creates a Pydantic field marked as a DSPy **input**. It calls `pydantic.Field` with the result of `move_kwargs`, injecting `__dspy_field_type="input"`.

```python
def InputField(**kwargs):  # noqa: N802
    return pydantic.Field(**move_kwargs(**kwargs, __dspy_field_type="input"))
```

#### `OutputField(**kwargs)`

Creates a Pydantic field marked as a DSPy **output**. Identical to `InputField` but injects `__dspy_field_type="output"`.

```python
def OutputField(**kwargs):  # noqa: N802
    return pydantic.Field(**move_kwargs(**kwargs, __dspy_field_type="output"))
```

Both functions accept any standard Pydantic `Field` argument plus the DSPy-specific arguments listed in `DSPY_FIELD_ARG_NAMES`.

---

### Argument Translation

#### `move_kwargs(**kwargs)`

The central translation function. Pydantic does not allow arbitrary keyword arguments on fields, so DSPy-specific arguments must be relocated into the `json_schema_extra` dictionary.

Behavior:

1. Iterates over all keyword arguments.
2. Arguments whose names appear in `DSPY_FIELD_ARG_NAMES` are moved into `json_schema_extra`.
3. All other arguments are passed through to Pydantic unchanged.
4. If a Pydantic `description` is provided but no DSPy `desc`, the description is copied into `json_schema_extra["desc"]`.
5. Pydantic constraints are translated via `_translate_pydantic_field_constraints` and stored under `json_schema_extra["constraints"]`.
6. The assembled `json_schema_extra` is attached to the returned Pydantic kwargs.

```python
def move_kwargs(**kwargs):
    pydantic_kwargs = {}
    json_schema_extra = {}
    for k, v in kwargs.items():
        if k in DSPY_FIELD_ARG_NAMES:
            json_schema_extra[k] = v
        else:
            pydantic_kwargs[k] = v
    if "description" in kwargs and "desc" not in json_schema_extra:
        json_schema_extra["desc"] = kwargs["description"]
    constraints = _translate_pydantic_field_constraints(**kwargs)
    if constraints:
        json_schema_extra["constraints"] = constraints
    pydantic_kwargs["json_schema_extra"] = json_schema_extra
    return pydantic_kwargs
```

#### `_translate_pydantic_field_constraints(**kwargs)`

Extracts Pydantic validation constraints and renders them as a comma-separated, human-readable string. This string is later embedded into prompts so the language model is aware of the constraints.

```python
def _translate_pydantic_field_constraints(**kwargs):
    constraints = []
    for key, value in kwargs.items():
        if key in PYDANTIC_CONSTRAINT_MAP:
            constraints.append(f"{PYDANTIC_CONSTRAINT_MAP[key]}{value}")
    return ", ".join(constraints)
```

---

### Constants

#### `DSPY_FIELD_ARG_NAMES`

The list of argument names that are DSPy-specific and must be relocated into `json_schema_extra`:

```python
DSPY_FIELD_ARG_NAMES = ["desc", "prefix", "format", "parser", "__dspy_field_type"]
```

#### `PYDANTIC_CONSTRAINT_MAP`

Maps Pydantic constraint keywords to human-readable prefixes used when generating constraint descriptions:

| Pydantic keyword | Human-readable prefix |
| --- | --- |
| `gt` | `greater than: ` |
| `ge` | `greater than or equal to: ` |
| `lt` | `less than: ` |
| `le` | `less than or equal to: ` |
| `min_length` | `minimum length: ` |
| `max_length` | `maximum length: ` |
| `multiple_of` | `a multiple of the given number: ` |
| `allow_inf_nan` | `allow 'inf', '-inf', 'nan' values: ` |

---

### Legacy Field Classes

The `OldField` hierarchy is a more ergonomic, pre-Pydantic representation of a field. It infers `prefix` and `desc` lazily via `finalize`, and is used for backward compatibility and conversions from the new Pydantic-based fields.

#### `OldField`

```python
class OldField:
    """A more ergonomic datatype that infers prefix and desc if omitted."""

    def __init__(self, *, prefix=None, desc=None, input, format=None):
        self.prefix = prefix  # This can be None initially and set later
        self.desc = desc
        self.format = format

    def finalize(self, key, inferred_prefix):
        """Set the prefix if it's not provided explicitly."""
        if self.prefix is None:
            self.prefix = inferred_prefix + ":"
        if self.desc is None:
            self.desc = f"${{{key}}}"

    def __repr__(self):
        return f"{self.__class__.__name__}(prefix={self.prefix}, desc={self.desc})"

    def __eq__(self, __value: object) -> bool:
        return self.__dict__ == __value.__dict__
```

Key methods:

- **`finalize(key, inferred_prefix)`** — Fills in a default `prefix` (from the inferred prefix) and a default `desc` (as a template placeholder `${key}`) when they were omitted.
- **`__eq__`** — Compares two fields by their `__dict__`, enabling value-based equality.

#### `OldInputField` / `OldOutputField`

Thin subclasses that fix the `input` flag to `True` / `False` respectively:

```python
class OldInputField(OldField):
    def __init__(self, *, prefix=None, desc=None, format=None):
        super().__init__(prefix=prefix, desc=desc, input=True, format=format)

class OldOutputField(OldField):
    def __init__(self, *, prefix=None, desc=None, format=None):
        super().__init__(prefix=prefix, desc=desc, input=False, format=format)
```

#### `new_to_old_field(field)`

Converts a new Pydantic-based field (a `FieldInfo` with DSPy metadata in `json_schema_extra`) into the corresponding legacy field class. The `__dspy_field_type` metadata determines whether an `OldInputField` or `OldOutputField` is produced.

```python
def new_to_old_field(field):
    return (OldInputField if field.json_schema_extra["__dspy_field_type"] == "input" else OldOutputField)(
        prefix=field.json_schema_extra["prefix"],
        desc=field.json_schema_extra["desc"],
        format=field.json_schema_extra.get("format"),
    )
```

---

## Data Flow

The following diagram shows how a user-declared field flows from the factory function through translation into a Pydantic `FieldInfo`, and how it can be converted back to a legacy field.

```mermaid
flowchart TD
    A["InputField(desc='...', gt=0, max_length=10)"] --> B["move_kwargs()"]
    B --> C{"Is arg in<br/>DSPY_FIELD_ARG_NAMES?"}
    C -->|Yes| D["json_schema_extra[arg] = value"]
    C -->|No| E["pydantic_kwargs[arg] = value"]
    B --> F["_translate_pydantic_field_constraints()"]
    F --> G["json_schema_extra['constraints'] = '...'"]
    D --> H["pydantic.Field(**pydantic_kwargs)"]
    E --> H
    G --> H
    H --> I["FieldInfo<br/>(json_schema_extra populated)"]
    I --> J["SignatureMeta consumes field<br/>(signatures_signature.md)"]
    I --> K["new_to_old_field()"]
    K --> L["OldInputField / OldOutputField"]
```

---

## Component Interaction

```mermaid
sequenceDiagram
    participant User
    participant InputField
    participant move_kwargs
    participant pydantic.Field
    participant SignatureMeta

    User->>InputField: InputField(desc="question", gt=0)
    InputField->>move_kwargs: move_kwargs(desc="question", gt=0, __dspy_field_type="input")
    move_kwargs->>move_kwargs: split DSPy args vs Pydantic args
    move_kwargs->>move_kwargs: translate constraints (gt -> "greater than: 0")
    move_kwargs-->>InputField: pydantic_kwargs with json_schema_extra
    InputField->>pydantic.Field: Field(**pydantic_kwargs)
    pydantic.Field-->>InputField: FieldInfo
    InputField-->>User: FieldInfo
    User->>SignatureMeta: class MySig(Signature): ...
    SignatureMeta->>SignatureMeta: validate __dspy_field_type in {input, output}
```

---

## Relationship to Other Modules

| Module | Relationship |
| --- | --- |
| [signatures_signature.md](signatures_signature.md) | The `Signature` / `SignatureMeta` classes consume the `FieldInfo` objects produced here. `SignatureMeta._validate_fields` enforces that every field carries a valid `__dspy_field_type`. |
| [adapters.md](adapters.md) | Adapters read `json_schema_extra` (prefix, desc, format, constraints) to render prompts and parse model outputs. |
| [predict_core.md](predict_core.md) | `Predict` and related modules rely on signatures whose fields are declared via `InputField` / `OutputField`. |

---

## Summary

The `signatures_field` module is a small but foundational layer of DSPy. It:

1. Exposes the user-facing `InputField` and `OutputField` factories.
2. Translates DSPy-specific field metadata and Pydantic constraints into a `json_schema_extra` dictionary that downstream components (signatures, adapters) can read.
3. Maintains a legacy `OldField` hierarchy and a `new_to_old_field` bridge for backward compatibility.

Because it defines the metadata contract (`__dspy_field_type`, `prefix`, `desc`, `format`, `constraints`) that the rest of the signature system depends on, changes to this module should be made carefully and coordinated with the [Signatures Signature module](signatures_signature.md).
