# DSP Utils Helpers

## Introduction

The `dsp_utils_helpers` module (`dspy/dsp/utils/utils.py`) provides a collection of low-level, dependency-light utility functions and helper classes used throughout the DSPy codebase. These helpers fall into three broad categories:

1. **Attribute-accessible dictionaries** — `dotdict` and `dotdict_lax`, which allow dictionary keys to be accessed as object attributes.
2. **Context management** — `NullContextManager`, a no-op context manager used as a placeholder when a context manager is expected but no behavior is needed.
3. **General-purpose data and I/O helpers** — batching, grouping, zipping, flattening, deduplication, directory creation, timestamping, and progress-tracked file reading.

These utilities are intentionally generic and are reused by higher-level modules such as retrieval ([dsp_retrieval](dsp_retrieval.md)), settings ([dsp_utils_settings](dsp_utils_settings.md)), and the broader DSPy runtime. This module is a sibling of `dsp_utils_settings` under the `dsp_utils` parent module.

---

## Module Architecture

The module is a flat collection of independent helpers with no internal class hierarchy. The diagram below shows the three logical groupings and their primary consumers.

```mermaid
graph TD
    subgraph "dsp_utils_helpers (dspy/dsp/utils/utils.py)"
        DD[dotdict]
        DDL[dotdict_lax]
        NCM[NullContextManager]
        subgraph "Data Helpers"
            BATCH[batch]
            FLAT[flatten]
            ZIPSTAR[zipstar]
            ZIPFIRST[zip_first]
            GROUP[groupby_first_item]
            PROCGROUP[process_grouped_by_first_item]
            GROUPER[grouper]
            LEN2OFF[lengths2offsets]
            DEDUP[deduplicate]
            IOF[int_or_float]
        end
        subgraph "I/O & Misc Helpers"
            PRINTMSG[print_message]
            TS[timestamp]
            FTQDM[file_tqdm]
            MKDIR[create_directory]
            LOADBG[load_batch_backgrounds]
        end
    end

    DD --> SETTINGS[dsp_utils_settings: Settings]
    DD --> COLBERT[dsp_retrieval: ColBERTv2]
    DDL --> SETTINGS
    NCM --> RUNTIME[DSPy Runtime / Predictors]
    BATCH --> RUNTIME
    GROUP --> RUNTIME
```

---

## Core Components

### `dotdict`

A `dict` subclass that exposes keys as attributes, enabling both `d["key"]` and `d.key` access styles.

**Key behaviors:**

- `__getattr__` — resolves attribute access to dictionary lookup. Dunder attributes (`__x__`) are delegated to the parent class to preserve Python internals. Missing keys raise `AttributeError` (not `KeyError`), matching normal attribute semantics.
- `__setattr__` — assigns non-dunder attributes as dictionary items.
- `__delattr__` — deletes non-dunder attributes from the dictionary.
- `__deepcopy__` — performs a deep copy by copying the underlying `dict` first, avoiding infinite recursion that would otherwise occur when deep-copying a dict subclass.

**Usage example:**

```python
from dspy.dsp.utils.utils import dotdict

d = dotdict({"query": "hello", "k": 5})
assert d.query == "hello"
d.k = 10
assert d["k"] == 10
```

This class is used by [dsp_retrieval](dsp_retrieval.md) (e.g., `ColBERTv2` wraps retrieved passages in `dotdict`) and by [dsp_utils_settings](dsp_utils_settings.md) (`Settings.copy()` returns a `dotdict`).

### `dotdict_lax`

A more permissive variant of `dotdict` implemented by directly aliasing dict methods:

```python
class dotdict_lax(dict):
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__
```

**Difference from `dotdict`:** Accessing a missing key returns `None` (via `dict.get`) instead of raising `AttributeError`. This "lax" behavior is useful when optional configuration values are expected to be absent.

| Feature | `dotdict` | `dotdict_lax` |
|---|---|---|
| Missing key access | Raises `AttributeError` | Returns `None` |
| Dunder handling | Explicitly delegated | Not special-cased |
| Deep copy support | Custom `__deepcopy__` | Inherited from `dict` |
| Strictness | Strict | Lax |

### `NullContextManager`

A no-op context manager that optionally returns a "dummy resource" on `__enter__` and does nothing on `__exit__`.

```python
class NullContextManager:
    def __init__(self, dummy_resource=None):
        self.dummy_resource = dummy_resource

    def __enter__(self):
        return self.dummy_resource

    def __exit__(self, *args):
        pass
```

**Purpose:** Allows code to uniformly use a `with` statement regardless of whether a real context manager is available. When no resource is needed, `NullContextManager()` can be substituted without branching logic. It is functionally similar to `contextlib.nullcontext` but predates or complements it within the DSPy codebase.

---

## Data Manipulation Helpers

These functions operate on sequences and iterables and are used across the runtime for batching, grouping, and reshaping data.

```mermaid
flowchart LR
    subgraph Input
        SEQ[Sequence / Iterable]
    end
    subgraph Transformations
        BATCH[batch: chunk into fixed-size blocks]
        GROUPER[grouper: fixed-length chunks w/ fill]
        FLAT[flatten: concatenate nested lists]
        ZIPSTAR[zipstar: transpose list of tuples]
        ZIPFIRST[zip_first: zip two lists w/ length check]
        GROUP[groupby_first_item: group by first element]
        PROCGROUP[process_grouped_by_first_item: stream grouped]
        LEN2OFF[lengths2offsets: cumulative offsets]
        DEDUP[deduplicate: order-preserving unique]
        IOF[int_or_float: parse numeric string]
    end
    SEQ --> BATCH & GROUPER & FLAT & ZIPSTAR & ZIPFIRST & GROUP & PROCGROUP & LEN2OFF & DEDUP & IOF
```

| Function | Signature | Description |
|---|---|---|
| `batch` | `(group, bsize, provide_offset=False)` | Yields successive fixed-size slices of `group`. Optionally yields `(offset, batch)` tuples. |
| `flatten` | `(data_list)` | Concatenates a list of lists into a single list. |
| `zipstar` | `(data_list, lazy=False)` | Faster alternative to `zip(*data_list)`. Returns lists for narrow data (`width < 100`), otherwise a lazy iterator or list. |
| `zip_first` | `(list1, list2)` | Zips two sequences and asserts the resulting length matches `list1`'s length. |
| `groupby_first_item` | `(lst)` | Groups tuples by their first element into a `defaultdict(list)`. |
| `process_grouped_by_first_item` | `(lst)` | Generator that yields `(group_key, items)` for input already grouped by first item; asserts the precondition. |
| `grouper` | `(iterable, n, fillvalue=None)` | Collects data into fixed-length chunks, padding the last chunk with `fillvalue`. |
| `lengths2offsets` | `(lengths)` | Yields `(start, end)` offset tuples from a sequence of lengths. |
| `deduplicate` | `(seq)` | Order-preserving deduplication using `dict.fromkeys`. |
| `int_or_float` | `(val)` | Parses a string as `float` if it contains a `.`, otherwise as `int`. |

---

## I/O and Miscellaneous Helpers

| Function | Signature | Description |
|---|---|---|
| `print_message` | `(*s, condition=True, pad=False, sep=None)` | Prints a timestamped message. Returns the formatted message string. `pad` adds surrounding newlines; `condition` gates printing. |
| `timestamp` | `(daydir=False)` | Returns a formatted timestamp string. Uses `/` separators when `daydir=True`, otherwise `-` and `_`. |
| `file_tqdm` | `(file)` | Generator that yields lines from a file while displaying a `tqdm` progress bar based on file size in MiB. |
| `create_directory` | `(path)` | Creates a directory if it does not exist, printing an informational message either way. |
| `load_batch_backgrounds` | `(args, qids)` | Loads background passages for a batch of query IDs from `args.qid2backgrounds`, joining them with `" [SEP] "`. Returns `None` if no backgrounds are configured. |

---

## Data Flow: `load_batch_backgrounds`

The `load_batch_backgrounds` helper illustrates how several module utilities combine in a retrieval-oriented workflow.

```mermaid
sequenceDiagram
    participant Caller
    participant LB as load_batch_backgrounds
    participant Args as args (qid2backgrounds, collection)
    Caller->>LB: load_batch_backgrounds(args, qids)
    alt qid2backgrounds is None
        LB-->>Caller: None
    else backgrounds configured
        loop for each qid
            LB->>Args: lookup qid2backgrounds[qid]
            alt background entries are ints
                LB->>Args: collection[pid] for each pid
            else entries are string ids
                LB->>Args: collectionX.get(pid, "")
            end
            LB->>LB: join with " [SEP] "
        end
        LB-->>Caller: list of joined background strings
    end
```

---

## Component Interaction Overview

The following diagram shows how the core components of this module relate to each other and to external consumers.

```mermaid
graph LR
    subgraph "dsp_utils_helpers"
        DD[dotdict]
        DDL[dotdict_lax]
        NCM[NullContextManager]
    end

    subgraph "Consumers"
        SETTINGS["dsp_utils_settings<br/>Settings.copy() → dotdict"]
        COLBERT["dsp_retrieval<br/>ColBERTv2 → dotdict(psg)"]
        PREDICT["predict_core<br/>Predict / Predictors"]
        PARALLEL["utils<br/>ParallelExecutor"]
    end

    DD --> SETTINGS
    DD --> COLBERT
    DDL --> SETTINGS
    NCM --> PREDICT
    NCM --> PARALLEL
```

---

## Design Notes and Caveats

- **`dotdict` vs. `dotdict_lax`:** Choose `dotdict` when missing keys should be treated as errors (strict configuration), and `dotdict_lax` when optional keys are expected and `None` is an acceptable default.
- **Dunder safety in `dotdict`:** The explicit handling of `__dunder__` names prevents attribute access from interfering with Python's internal protocols (e.g., pickling, copying).
- **`zipstar` performance:** The function short-circuits to list comprehensions for narrow data (`width < 100`) to avoid the overhead of `zip`, and uses `zip(..., strict=False)` for wider data.
- **`process_grouped_by_first_item` precondition:** This generator assumes the input is already grouped by the first item and will assert if the precondition is violated. Use `groupby_first_item` first if the input is not pre-grouped.
- **`NullContextManager` vs. `contextlib.nullcontext`:** Both serve the same purpose; `NullContextManager` additionally supports returning a dummy resource.

---

## Related Modules

- [dsp_utils_settings](dsp_utils_settings.md) — The `Settings` singleton, which uses `dotdict` for configuration snapshots.
- [dsp_retrieval](dsp_retrieval.md) — Retrieval components (e.g., `ColBERTv2`) that wrap results in `dotdict`.
- [dsp_retrieval_dpr](dsp_retrieval_dpr.md) — Tokenization utilities that operate on the data structures produced by these helpers.
- [utils](utils.md) — Higher-level utilities such as `ParallelExecutor` that may use `NullContextManager`.
