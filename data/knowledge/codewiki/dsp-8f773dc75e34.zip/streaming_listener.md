# Streaming Listener Module

## Introduction

The `streaming_listener` module provides the core mechanism for **incremental, field-level streaming** of language model outputs in DSPy. While a predictor normally returns a complete response only after the LM finishes generating, the `StreamListener` class allows consumers to observe the partial, token-by-token generation of a *specific output field* of a *specific predictor* as it is produced.

This is the foundation that powers user-facing streaming APIs (such as `dspy.streamify`), enabling real-time UIs, progress indicators, and low-latency applications. The module is responsible for:

- Detecting the **start** of a target output field within a raw token stream.
- Buffering and emitting **partial field content** as it arrives.
- Detecting the **end** of the field (i.e., the start of the next field or the completion marker).
- Correctly handling **adapter-specific** field delimiters (Chat, JSON, and XML adapters).
- Automatically **resolving which predictor** a listener should attach to.

> For the message types emitted by streaming (e.g., `StreamResponse`, `StatusMessage`), see the [streaming_messages](streaming_messages.md) documentation.

---

## Architecture Overview

The module centers on a single primary class, `StreamListener`, plus a helper function `find_predictor_for_stream_listeners`. The listener is adapter-aware: it inspects the currently active adapter (via `dspy.dsp.utils.settings.settings.adapter`) to determine the correct start/end delimiters for the field being streamed.

```mermaid
graph TD
    subgraph "streaming_listener module"
        SL[StreamListener]
        FPS[find_predictor_for_stream_listeners]
    end

    subgraph "streaming package"
        SR[StreamResponse]
        SM[StatusMessage / StatusStreamingCallback]
    end

    subgraph "adapters"
        CA[ChatAdapter]
        JA[JSONAdapter]
        XA[XMLAdapter]
    end

    subgraph "core"
        SET[settings]
        MOD[Module / named_predictors]
    end

    SL -->|emits| SR
    SL -->|reads active adapter| SET
    SL -->|delimiter rules| CA
    SL -->|delimiter rules| JA
    SL -->|delimiter rules| XA
    FPS -->|resolves predictor| MOD
    FPS -->|configures| SL
    SM -.->|status events| SET
```

---

## Core Components

### `StreamListener`

The `StreamListener` is a stateful object that consumes raw model stream chunks and produces `StreamResponse` objects for a single target output field.

#### Constructor

```python
StreamListener(
    signature_field_name: str,
    predict: Any = None,
    predict_name: str | None = None,
    allow_reuse: bool = False,
)
```

| Parameter | Description |
|-----------|-------------|
| `signature_field_name` | The name of the output field to listen to (e.g., `"answer"`). |
| `predict` | The predictor instance to listen to. If `None`, `streamify()` will auto-resolve it via `find_predictor_for_stream_listeners`. |
| `predict_name` | The name of the predictor (used for labeling emitted `StreamResponse` objects). Auto-resolved if `None`. |
| `allow_reuse` | If `True`, the listener resets its state after a stream ends so it can be reused for subsequent streams. Note: reuse can hurt performance because the same chunk is dispatched to multiple listeners. |

#### Internal State

The listener maintains several pieces of state that drive its finite-state behavior:

| Attribute | Purpose |
|-----------|---------|
| `field_start_queue` | Buffer of chunks accumulated while searching for the field's start identifier. |
| `field_end_queue` | Rolling buffer (max ~10 tokens) of chunks used to detect the field's end identifier. |
| `stream_start` | `True` once the target field's start identifier has been matched. |
| `stream_end` | `True` once the field's end identifier has been matched. |
| `cache_hit` | `True` when the entire response arrives in a single chunk (cache hit or multi-token chunk). |
| `allow_reuse` | Controls whether state is reset after `stream_end`. |

#### Adapter Delimiter Configuration

The listener defines delimiter rules per adapter in `adapter_identifiers`. Only adapters listed in `ADAPTER_SUPPORT_STREAMING` (`ChatAdapter`, `XMLAdapter`, `JSONAdapter`) are supported.

| Adapter | Start Identifier | End Identifier (regex) | Start Indicator |
|---------|------------------|------------------------|-----------------|
| `ChatAdapter` | `[[ ## {field} ## ]]` | `\[\[ ## (\w+) ## \]\]` | `[` |
| `JSONAdapter` | `"{field}":` | `\w*\"(,\|\s*})` | `"` |
| `XMLAdapter` | `<{field}>` | `</{field}>` | `<` |

#### Key Methods

##### `receive(chunk: ModelResponseStream)`

The main entry point. It processes a single stream chunk and returns a `StreamResponse` when a token of the target field is ready to be emitted, otherwise `None`.

The processing logic follows this state machine:

```mermaid
flowchart TD
    A[receive chunk] --> B{stream_end?}
    B -->|yes, allow_reuse| R[Reset state]
    B -->|yes, no reuse| Z[return None]
    R --> C
    B -->|no| C[Extract delta content]
    C --> D{content is None?}
    D -->|yes| Z
    D -->|no| E{start_identifier in chunk?}
    E -->|yes & end also present| HIT[Set cache_hit, stream_start, stream_end]
    E -->|no| F{start_indicator found & not started?}
    F -->|yes| Q1[Append to field_start_queue, return]
    F -->|no| G{field_start_queue non-empty & not started?}
    G -->|yes| Q2[Accumulate & match start_identifier]
    Q2 -->|matched| START[stream_start = True, trim prefix]
    Q2 -->|partial match| Z
    Q2 -->|no match| RESET[Reset queue, return]
    G -->|no| I{stream_start?}
    START --> I
    I -->|yes| J[Buffer chunk in field_end_queue]
    J --> K{end_identifier matched?}
    K -->|yes| END[stream_end = True, flush buffer]
    K -->|no| EMIT[Emit buffered token]
    END --> EMIT
    EMIT --> OUT[Return StreamResponse]
```

**Cache-hit / single-chunk handling:** If a chunk contains both the start identifier and the end identifier (common with cache hits or models like Gemini that emit multiple tokens per chunk), the listener immediately marks `cache_hit`, `stream_start`, and `stream_end` as `True`.

**Start detection:** The listener waits for the `start_indicator` (e.g., `[` for ChatAdapter), then accumulates chunks in `field_start_queue` until the full `start_identifier` is matched. The `_buffered_message_end_with_start_identifier` helper checks whether the buffered text is a *prefix* of the start identifier, allowing the listener to keep waiting across chunk boundaries.

**End detection:** Once streaming has started, chunks are pushed into `field_end_queue`. The queue is capped at 10 tokens; older tokens are flushed out as `StreamResponse` chunks. When the concatenated buffer matches the `end_identifier`, the stream ends and the remaining buffer is flushed.

##### `flush() -> str`

Flushes the remaining tokens in `field_end_queue` when the stream ends. This is necessary because the listener deliberately withholds the last few tokens to avoid emitting the end identifier itself. The flush logic is adapter-specific:

- **JSONAdapter:** Truncates at the closing `",` or `"}` boundary.
- **XMLAdapter:** Truncates at the closing `</{field}>` tag.
- **ChatAdapter / None:** Truncates at the next `[[` marker.
- **Otherwise:** Raises `ValueError` for unsupported adapters.

### `find_predictor_for_stream_listeners(program, stream_listeners)`

A utility function that automatically resolves the predictor for each `StreamListener` that did not specify one explicitly. It is invoked by `streamify()`.

**Behavior:**

1. Collects all listeners that lack an explicit `predict`.
2. Iterates over `program.named_predictors()` and maps each target `signature_field_name` to its owning predictor.
3. Raises `ValueError` if:
   - A field name is **not unique** across predictors (ambiguous).
   - A field is **not a string** output field (streaming only supports `str`).
   - A field name does not exist in any predictor.
4. Returns a `defaultdict(list)` mapping `id(predictor) -> [listeners]`.

```mermaid
sequenceDiagram
    participant S as streamify()
    participant F as find_predictor_for_stream_listeners
    participant P as program.named_predictors()
    participant L as StreamListener

    S->>F: program, stream_listeners
    F->>P: enumerate predictors
    P-->>F: (name, predictor) pairs
    F->>F: map field_name -> predictor
    F->>F: validate uniqueness & str type
    F->>L: set listener.predict / predict_name
    F-->>S: {predictor_id: [listeners]}
```

---

## Data Flow

The following diagram illustrates how a raw LM stream flows through the listener to produce field-level stream responses.

```mermaid
flowchart LR
    LM[LM / litellm stream] -->|ModelResponseStream chunks| SL[StreamListener.receive]
    SL -->|start detection| SQ[field_start_queue]
    SL -->|end detection| EQ[field_end_queue]
    SL -->|emit| SR[StreamResponse]
    SR -->|predict_name, field, chunk, is_last_chunk| Consumer[User callback / UI]
    SL -.->|reads| SET[settings.adapter]
```

Each emitted `StreamResponse` carries:

| Field | Meaning |
|-------|---------|
| `predict_name` | Name of the predictor producing the field. |
| `signature_field_name` | The output field being streamed. |
| `chunk` | The partial text content. |
| `is_last_chunk` | `True` on the final chunk of the field. |

---

## Component Interaction

```mermaid
graph LR
    subgraph Adapters
        CA[ChatAdapter]
        JA[JSONAdapter]
        XA[XMLAdapter]
    end

    subgraph Streaming
        SL[StreamListener]
        SR[StreamResponse]
    end

    subgraph Settings
        SET[settings.adapter]
    end

    SET -->|active adapter| SL
    CA -->|delimiter format| SL
    JA -->|delimiter format| SL
    XA -->|delimiter format| SL
    SL -->|produces| SR
```

The listener is tightly coupled to the adapter system. The active adapter is read at runtime from `settings.adapter`, and the listener selects the matching delimiter rules. This means the same `StreamListener` instance behaves differently depending on which adapter is configured. See the [adapters](adapters.md) documentation for details on how each adapter formats fields.

---

## Integration with the Broader System

The `streaming_listener` module is a building block used by higher-level streaming utilities:

- **`dspy.streamify`** — Wraps a program and attaches `StreamListener` instances to predictors, using `find_predictor_for_stream_listeners` to resolve targets automatically.
- **`StatusStreamingCallback`** — Emits `StatusMessage` events (tool start/end, LM start/end, module start/end) alongside field-level `StreamResponse` chunks. See [streaming_messages](streaming_messages.md).

```mermaid
graph TD
    STREAMIFY[dspy.streamify] --> FPS[find_predictor_for_stream_listeners]
    STREAMIFY --> SL[StreamListener]
    STREAMIFY --> SSC[StatusStreamingCallback]
    SL --> SR[StreamResponse]
    SSC --> SM[StatusMessage]
    SR --> OUT[Streaming output]
    SM --> OUT
```

---

## Error Handling

| Condition | Exception |
|-----------|-----------|
| Unsupported adapter in `receive` | `ValueError` |
| Unsupported adapter in `flush` | `ValueError` |
| Ambiguous field name in `find_predictor_for_stream_listeners` | `ValueError` |
| Non-string output field | `ValueError` |
| Field not found in any predictor | `ValueError` |

---

## Related Documentation

- [streaming_messages](streaming_messages.md) — `StreamResponse`, `StatusMessage`, `StatusMessageProvider`, and `StatusStreamingCallback`.
- [adapters](adapters.md) — `ChatAdapter`, `JSONAdapter`, `XMLAdapter`, and the base `Adapter` interface.
- [dsp_utils_settings](dsp_utils_settings.md) — The `settings` object that holds the active adapter.
- [primitives_module](primitives_module.md) — `Module` and `named_predictors()`, used for predictor resolution.
