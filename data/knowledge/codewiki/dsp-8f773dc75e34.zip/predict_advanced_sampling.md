# Advanced Sampling Module (`predict_advanced_sampling`)

## Introduction

The `predict_advanced_sampling` module provides **reward-guided sampling strategies** for DSPy modules. Instead of accepting the first output a module produces, these strategies run a module multiple times with varying temperatures and select the best result according to a user-supplied reward function.

The module contains two core components:

| Component | File | Purpose |
|-----------|------|---------|
| `BestOfN` | `dspy/predict/best_of_n.py` | Runs a module up to `N` times and returns the highest-reward prediction (or the first one passing a threshold). |
| `Refine` | `dspy/predict/refine.py` | Extends `BestOfN` by generating **natural-language feedback** between attempts and injecting it as a hint into subsequent runs. |
| `OfferFeedback` | `dspy/predict/refine.py` | A `Signature` used internally by `Refine` to assign blame and produce per-module advice. |

Both `BestOfN` and `Refine` are subclasses of [`Module`](predict_core.md) and follow the standard DSPy module contract (`forward`, `__call__`, `deepcopy`, `set_lm`, etc.).

---

## Architecture Overview

The module sits on top of the core prediction stack. It wraps an arbitrary user module, orchestrates repeated executions, and uses the reward function as a selection signal.

```mermaid
graph TD
    User["User Code"] -->|"BestOfN / Refine"| Wrapper["Sampling Wrapper"]
    Wrapper -->|"deepcopy + set_lm"| Inner["Wrapped Module (e.g. ChainOfThought)"]
    Inner -->|"forward"| Predict["Predict"]
    Predict -->|"adapter call"| Adapter["ChatAdapter / JSONAdapter"]
    Adapter -->|"LM call"| LM["LM / BaseLM"]
    Wrapper -->|"reward_fn(args, pred)"| Reward["Reward Function"]
    Reward -->|"scalar reward"| Wrapper
    Wrapper -->|"best prediction"| User

    subgraph "Refine only"
        Wrapper -->|"on failure"| OfferFeedback["OfferFeedback Signature"]
        OfferFeedback -->|"advice dict"| Wrapper
        Wrapper -->|"WrapperAdapter injects hint_"| Inner
    end
```

### Component Relationships

```mermaid
classDiagram
    class Module {
        +forward(**kwargs)
        +__call__(**kwargs)
        +deepcopy()
        +set_lm(lm)
        +get_lm()
        +named_predictors()
    }
    class BestOfN {
        +module: Module
        +N: int
        +reward_fn: Callable
        +threshold: float
        +fail_count: int
        +forward(**kwargs)
    }
    class Refine {
        +module: Module
        +N: int
        +reward_fn: Callable
        +threshold: float
        +fail_count: int
        +module_code: str
        +reward_fn_code: str
        +forward(**kwargs)
    }
    class OfferFeedback {
        <<Signature>>
        +program_code
        +modules_defn
        +program_inputs
        +program_trajectory
        +program_outputs
        +reward_code
        +target_threshold
        +reward_value
        +module_names
        +discussion
        +advice
    }

    Module <|-- BestOfN
    BestOfN <|-- Refine
    Refine ..> OfferFeedback : uses via dspy.Predict
```

---

## `BestOfN`

`BestOfN` is the simpler of the two strategies. It performs a temperature sweep, evaluates each attempt with the reward function, and returns the best-scoring prediction.

### Constructor

```python
BestOfN(
    module: Module,
    N: int,
    reward_fn: Callable[[dict, Prediction], float],
    threshold: float,
    fail_count: int | None = None,
)
```

| Parameter | Description |
|-----------|-------------|
| `module` | The DSPy module to run repeatedly. |
| `N` | Maximum number of attempts. |
| `reward_fn` | `(args, prediction) -> float`. Receives the kwargs passed to the module and the resulting [`Prediction`](predict_core.md). |
| `threshold` | If a reward meets or exceeds this value, sampling stops early. |
| `fail_count` | Number of tolerated exceptions before re-raising. Defaults to `N`. |

> **Note:** `reward_fn` is wrapped in a lambda (`lambda *args: reward_fn(*args)`) so that it is **not** registered as a DSPy parameter and therefore is excluded from serialization and optimization.

### Temperature Schedule

The temperature list is constructed as:

```python
temps = [lm.kwargs["temperature"]] + [0.5 + i * (0.5 / N) for i in range(N)]
temps = list(dict.fromkeys(temps))[:N]
```

- The first attempt reuses the LM's configured temperature.
- Subsequent attempts use an increasing schedule starting at `0.5`.
- Duplicates are removed via `dict.fromkeys`, and the list is truncated to `N` entries.

### Execution Flow

```mermaid
flowchart TD
    Start["forward(**kwargs)"] --> GetLM["lm = module.get_lm() or settings.lm"]
    GetLM --> BuildTemps["Build temperature schedule"]
    BuildTemps --> Loop{"For each temperature t"}
    Loop --> Copy["lm_ = lm.copy(temperature=t)"]
    Copy --> DeepCopy["mod = module.deepcopy(); mod.set_lm(lm_)"]
    DeepCopy --> Run["with dspy.context(trace=[]): pred = mod(**kwargs)"]
    Run --> Reward["reward = reward_fn(kwargs, pred)"]
    Reward --> Better{"reward > best_reward?"}
    Better -->|Yes| Update["Update best_pred / best_trace / best_reward"]
    Better -->|No| Threshold
    Update --> Threshold{"reward >= threshold?"}
    Threshold -->|Yes| Break["break"]
    Threshold -->|No| Loop
    Run -->|Exception| Handle["print error; if idx > fail_count: raise"]
    Handle --> Loop
    Break --> Extend["settings.trace.extend(best_trace)"]
    Loop -->|Exhausted| Extend
    Extend --> Return["return best_pred"]
```

### Key Behaviors

- **Isolation per attempt:** Each attempt uses a `deepcopy` of the module and a fresh `dspy.context(trace=[])`, so traces do not leak between attempts.
- **Trace propagation:** Only the trace of the *best* attempt is appended to the global `dspy.settings.trace`. The reward function's own trace is intentionally excluded.
- **Error tolerance:** Exceptions are caught and printed. The module raises only once the number of failures exceeds `fail_count`.

### Example

```python
import dspy

dspy.settings.configure(lm=dspy.LM("openai/gpt-4o-mini"))

qa = dspy.ChainOfThought("question -> answer")

def one_word_answer(args, pred):
    return 1.0 if len(pred.answer.split()) == 1 else 0.0

best_of_3 = dspy.BestOfN(module=qa, N=3, reward_fn=one_word_answer, threshold=1.0)
result = best_of_3(question="What is the capital of Belgium?").answer
# Returns: Brussels
```

---

## `Refine`

`Refine` builds on `BestOfN` by adding a **feedback loop**. When an attempt fails to reach the threshold, `Refine` analyzes the program's execution trace and asks an LLM (via the `OfferFeedback` signature) to produce concrete, per-module advice. That advice is then injected into subsequent attempts as an extra input field (`hint_`).

### Constructor

```python
Refine(
    module: Module,
    N: int,
    reward_fn: Callable[[dict, Prediction], float],
    threshold: float,
    fail_count: int | None = None,
)
```

In addition to the `BestOfN` parameters, `Refine` captures source code at construction time:

- `self.module_code = inspect.getsource(module.__class__)`
- `self.reward_fn_code = inspect.getsource(reward_fn)` (falls back to the class source for callables without source).

This source is later fed to `OfferFeedback` so the feedback LLM understands the program and reward logic.

### Feedback Injection Mechanism

The core innovation is the `WrapperAdapter`, a dynamically-created subclass of the active adapter that appends a `hint_` input field to the signature before delegating to the original adapter:

```python
class WrapperAdapter(adapter.__class__):
    def __call__(self, lm, lm_kwargs, signature, demos, inputs):
        inputs["hint_"] = advice.get(signature2name[signature], "N/A")
        signature = signature.append(
            "hint_", InputField(desc="A hint to the module from an earlier run")
        )
        return adapter(lm, lm_kwargs, signature, demos, inputs)
```

The advice is keyed by **signature**, so each predictor inside the wrapped module receives its own tailored hint. See [`Signature.append`](signatures.md) for the field-manipulation API.

### Execution Flow

```mermaid
flowchart TD
    Start["forward(**kwargs)"] --> Setup["Build temps, adapter, best_* trackers"]
    Setup --> Loop{"For each temperature t"}
    Loop --> Copy["lm_ = lm.copy(temperature=t); mod = module.deepcopy()"]
    Copy --> Names["Build predictor2name / signature2name / module_names"]
    Names --> AdviceCheck{"advice is None?"}
    AdviceCheck -->|Yes| RunPlain["outputs = mod(**kwargs)"]
    AdviceCheck -->|No| RunHinted["with WrapperAdapter: outputs = mod(**kwargs)"]
    RunPlain --> Reward["reward = reward_fn(kwargs, outputs)"]
    RunHinted --> Reward
    Reward --> Better{"reward > best_reward?"}
    Better -->|Yes| Update["Update best_pred / best_trace / best_reward"]
    Better -->|No| Threshold
    Update --> Threshold{"reward >= threshold?"}
    Threshold -->|Yes| Break["break"]
    Threshold -->|No| LastCheck{"idx == N-1?"}
    LastCheck -->|Yes| Break
    LastCheck -->|No| BuildAdvice["Build advise_kwargs from trace + code"]
    BuildAdvice --> CallFeedback["advice = dspy.Predict(OfferFeedback)(**advise_kwargs).advice"]
    CallFeedback --> Loop
    RunPlain -->|Exception| Handle["print error; if idx > fail_count: raise"]
    Handle --> Loop
    Break --> Extend["settings.trace.extend(best_trace)"]
    Loop -->|Exhausted| Extend
    Extend --> Return["return best_pred"]
```

### Advice Construction

Before each retry (except the last), `Refine` assembles the inputs for `OfferFeedback`:

| Field | Source |
|-------|--------|
| `program_code` | `self.module_code` |
| `modules_defn` | `inspect_modules(mod)` — formatted I/O of every predictor |
| `program_inputs` | The original `kwargs` |
| `program_trajectory` | List of `{module_name, inputs, outputs}` from the trace |
| `program_outputs` | The failed attempt's outputs |
| `reward_code` | `self.reward_fn_code` |
| `target_threshold` | `self.threshold` |
| `reward_value` | The reward of the failed attempt |
| `module_names` | Names of all predictors |

Non-string values are serialized with `ujson.dumps(recursive_mask(v), indent=2)`. The `recursive_mask` helper replaces non-serializable objects with a placeholder string (`<non-serializable: TypeName>`) so the payload can always be serialized.

### Helper Functions

- **`inspect_modules(program)`** — Produces a human-readable description of each predictor in the program, including input fields, output fields, and original instructions. Uses `get_field_description_string` from `dspy/adapters/utils.py`.
- **`recursive_mask(o)`** — Recursively walks dicts, lists, and tuples, replacing any object that cannot be JSON-serialized with a placeholder string.

### Example

```python
import dspy

dspy.settings.configure(lm=dspy.LM("openai/gpt-4o-mini"))

qa = dspy.ChainOfThought("question -> answer")

def one_word_answer(args, pred):
    return 1.0 if len(pred.answer.split()) == 1 else 0.0

refined = dspy.Refine(module=qa, N=3, reward_fn=one_word_answer, threshold=1.0)
result = refined(question="What is the capital of Belgium?").answer
# Returns: Brussels
```

---

## `OfferFeedback` Signature

`OfferFeedback` is a DSPy [`Signature`](signatures.md) that instructs an LLM to:

1. Assign blame to each module that contributed to a sub-threshold reward.
2. Prescribe concrete, actionable advice for each module's future behavior.

### Fields

**Inputs**

| Field | Description |
|-------|-------------|
| `program_code` | Source code of the program being analyzed. |
| `modules_defn` | Definition of each module, including I/O. |
| `program_inputs` | Inputs to the program. |
| `program_trajectory` | Execution trajectory showing each module's I/O. |
| `program_outputs` | Outputs of the program. |
| `reward_code` | Source of the reward function. |
| `target_threshold` | Target reward threshold. |
| `reward_value` | Reward assigned to the outputs. |
| `module_names` | Names of modules for which advice is sought. |

**Outputs**

| Field | Description |
|-------|-------------|
| `discussion` | Discussion of where each module went wrong. |
| `advice` | `dict[str, str]` mapping module name → concrete advice (or `N/A`). |

The signature's docstring emphasizes that modules **cannot see their own history**, so advice must be entirely concrete and self-contained.

---

## Data Flow Summary

```mermaid
sequenceDiagram
    participant U as User
    participant R as Refine
    participant M as Wrapped Module
    participant RF as reward_fn
    participant OF as OfferFeedback (LLM)

    U->>R: forward(question=...)
    R->>M: attempt 1 (temp t0)
    M-->>R: prediction + trace
    R->>RF: reward_fn(kwargs, pred)
    RF-->>R: reward < threshold
    R->>OF: advise_kwargs (code, trace, reward)
    OF-->>R: advice dict
    R->>M: attempt 2 (temp t1, hint_ injected)
    M-->>R: prediction + trace
    R->>RF: reward_fn(kwargs, pred)
    RF-->>R: reward >= threshold
    R-->>U: best prediction
```

---

## Integration with the Broader System

| Dependency | Role |
|------------|------|
| [`Module`](predict_core.md) | Base class providing `deepcopy`, `set_lm`, `get_lm`, `named_predictors`. |
| [`Predict`](predict_core.md) | Underlying predictor invoked by wrapped modules; also used to run `OfferFeedback`. |
| [`Prediction`](predict_core.md) | Output object passed to `reward_fn`. |
| [`Signature`](signatures.md) | Defines `OfferFeedback`; `Signature.append` injects the `hint_` field. |
| [`ChatAdapter`](adapters.md) | Default adapter; subclassed by `WrapperAdapter` in `Refine`. |
| [`LM` / `BaseLM`](clients_core.md) | Provides `copy(temperature=...)` for the temperature sweep. |
| `dspy.settings` | Global context for `lm`, `adapter`, and `trace`. |

### Comparison: `BestOfN` vs `Refine`

| Aspect | `BestOfN` | `Refine` |
|--------|-----------|----------|
| Temperature sweep | ✅ | ✅ |
| Reward-based selection | ✅ | ✅ |
| Early stop on threshold | ✅ | ✅ |
| Feedback generation | ❌ | ✅ (`OfferFeedback`) |
| Hint injection | ❌ | ✅ (`WrapperAdapter` + `hint_`) |
| Source-code capture | ❌ | ✅ (`module_code`, `reward_fn_code`) |
| Extra LLM calls | None | One per failed attempt |

---

## Design Notes & Caveats

- **Reward function isolation:** Both classes wrap `reward_fn` in a lambda to prevent it from being treated as a DSPy parameter.
- **Trace hygiene:** Each attempt runs inside `dspy.context(trace=[])`; only the winning trace is merged back into the global trace. The `hint_` field is *not* stripped from the trace (a `TODO` in the source notes this).
- **Failure semantics:** `fail_count` decrements on each caught exception; the module re-raises once `idx > fail_count`. Note that `fail_count` is mutated on the instance, so a single `Refine`/`BestOfN` instance is not safe for concurrent reuse across many failing calls.
- **Serialization:** `recursive_mask` guarantees the advice payload is always JSON-serializable, replacing exotic objects with placeholders.
- **Feedback quality:** Because modules cannot see their own history, the quality of `Refine` depends heavily on the concreteness of the advice produced by `OfferFeedback`.
