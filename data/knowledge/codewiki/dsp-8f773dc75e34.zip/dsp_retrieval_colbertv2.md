# dsp_retrieval_colbertv2

## Introduction

The `dsp_retrieval_colbertv2` module provides retrieval and reranking capabilities based on **ColBERTv2**, a late-interaction neural retrieval model. It exposes three core components that cover the two primary ways of using ColBERTv2 within DSPy:

1. **`ColBERTv2`** — a lightweight HTTP client that talks to a *hosted* ColBERTv2 server (either via GET or POST requests).
2. **`ColBERTv2RetrieverLocal`** — a fully local retriever that builds/searches a ColBERT index over an in-memory passage collection.
3. **`ColBERTv2RerankerLocal`** — a local reranker that scores a set of candidate passages against a query using ColBERT's late-interaction scoring.

These components are typically wired into DSPy programs through the retrieval abstraction (see [`retrievers`](retrievers.md) and the `Retrieve` module), where they act as the underlying retrieval model (`rm`) configured in `dspy.settings`.

---

## Architecture Overview

The module sits at the boundary between DSPy's retrieval abstraction layer and the external ColBERTv2 ecosystem (a hosted server or the local `colbert-ai` package).

```mermaid
graph TD
    subgraph DSPy
        Retrieve["Retrieve (retrievers)"]
        Settings["Settings (dsp_utils)"]
        Cache["request_cache (clients_core)"]
        DotDict["dotdict (dsp_utils)"]
    end

    subgraph "dsp_retrieval_colbertv2"
        ColBERTv2["ColBERTv2 (HTTP client)"]
        RetrieverLocal["ColBERTv2RetrieverLocal"]
        RerankerLocal["ColBERTv2RerankerLocal"]
    end

    subgraph External
        HostedServer["Hosted ColBERTv2 Server"]
        ColbertPkg["colbert-ai package (Indexer/Searcher/ColBERT)"]
    end

    Retrieve -->|"calls rm(query, k)"| ColBERTv2
    Retrieve -->|"calls rm(query, k)"| RetrieverLocal
    Settings -->|"dspy.settings.rm"| Retrieve

    ColBERTv2 -->|"GET/POST"| HostedServer
    ColBERTv2 -.->|"cached by"| Cache
    ColBERTv2 -->|"returns"| DotDict

    RetrieverLocal -->|"build_index / get_index"| ColbertPkg
    RetrieverLocal -->|"returns"| DotDict

    RerankerLocal -->|"tokenize + score"| ColbertPkg
```

---

## Core Components

### `ColBERTv2` — Hosted Server Client

A thin wrapper around a remote ColBERTv2 HTTP endpoint. It is the simplest way to use ColBERTv2 when a server is already running (e.g., the hosted ColBERTv2 service).

**Constructor**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `url` | `str` | `"http://0.0.0.0"` | Base URL of the ColBERTv2 server. |
| `port` | `str \| int \| None` | `None` | Optional port appended to `url` as `"{url}:{port}"`. |
| `post_requests` | `bool` | `False` | If `True`, use POST requests; otherwise GET. |

**Call signature**

```python
ColBERTv2(query: str, k: int = 10, simplify: bool = False) -> list[str] | list[dotdict]
```

- `query` — the search query string.
- `k` — number of top passages to return.
- `simplify` — when `True`, returns a plain list of passage strings (`long_text`); otherwise returns a list of `dotdict` objects containing the full passage metadata.

**Behavior**

- Dispatches to `colbertv2_post_request` or `colbertv2_get_request` depending on `post_requests`.
- Both request helpers are decorated with `request_cache` (from [`clients_core`](clients_core.md)), so identical queries are served from DSPy's cache.
- The GET variant asserts `k <= 100`, a limitation of the hosted server.

```mermaid
sequenceDiagram
    participant Caller
    participant ColBERTv2
    participant Cache as request_cache
    participant Server as Hosted Server

    Caller->>ColBERTv2: __call__(query, k, simplify)
    alt post_requests
        ColBERTv2->>Cache: colbertv2_post_request(url, query, k)
    else
        ColBERTv2->>Cache: colbertv2_get_request(url, query, k)
    end
    Cache->>Cache: cache lookup
    alt cache miss
        Cache->>Server: HTTP GET/POST
        Server-->>Cache: {"topk": [...]}
        Cache->>Cache: store result
    end
    Cache-->>ColBERTv2: topk list
    ColBERTv2-->>Caller: list[str] or list[dotdict]
```

---

### `ColBERTv2RetrieverLocal` — Local Index Retriever

Builds and searches a ColBERT index locally over a provided list of passages. This is the fully self-contained retrieval path, requiring the `colbert-ai` package.

**Constructor**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `passages` | `list[str]` | — | The corpus of passages to index and search. |
| `colbert_config` | `ColBERTConfig` | `None` | Required. A `colbert.infra.config.ColBERTConfig` instance. Must define `checkpoint`, `index_name`, and `experiment`. |
| `load_only` | `bool` | `False` | If `False`, builds the index before loading; if `True`, only loads an existing index. |

**Validation** — The constructor asserts that:
- `colbert_config` is provided.
- `colbert_config.checkpoint` is set (e.g., `colbert-ir/colbertv2.0`).
- `colbert_config.index_name` is set.

**Key methods**

- `build_index()` — Uses `colbert.Indexer` within a `Run().context(RunConfig(...))` to index the passage collection under `index_name`.
- `get_index()` — Uses `colbert.Searcher` to load the index and returns a searcher object.
- `forward(query, k=7, **kwargs)` — Searches the index. Supports an optional `filtered_pids` kwarg (a list of integer passage IDs) to restrict results via a `filter_fn`. Returns a list of `dotdict` objects with `long_text`, `score`, and `pid`.

```mermaid
flowchart TD
    A[Init ColBERTv2RetrieverLocal] --> B{load_only?}
    B -- No --> C[build_index: Indexer.index]
    B -- Yes --> D[Skip build]
    C --> E[get_index: Searcher]
    D --> E
    E --> F[forward query]
    F --> G{filtered_pids?}
    G -- Yes --> H[search with filter_fn]
    G -- No --> I[search plain]
    H --> J[Build dotdict results]
    I --> J
    J --> K[Return list of dotdict]
```

---

### `ColBERTv2RerankerLocal` — Local Reranker

Reranks a list of candidate passages against a query using ColBERT's late-interaction scoring. Unlike the retriever, it does not require an index — it directly tokenizes and scores passages.

**Constructor**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `colbert_config` | `ColBERTConfig` | `None` | ColBERT configuration. |
| `checkpoint` | `str` | `"bert-base-uncased"` | Model checkpoint used for embeddings. Assigned to `colbert_config.checkpoint`. |

**Call signature**

```python
ColBERTv2RerankerLocal(query: str, passages: list[str] | None = None) -> np.ndarray
```

**Behavior**

1. Asserts `passages` is non-empty.
2. Sets `colbert_config.nway` to the number of passages.
3. Tokenizes the query (`QueryTokenizer`) and passages (`DocTokenizer`).
4. Instantiates `ColBERT` and computes query/document embeddings.
5. Duplicates the query embedding across passages and computes late-interaction scores via `col.score(...)`.
6. Returns a NumPy array of per-passage scores.

```mermaid
flowchart LR
    Q[query] --> QT[QueryTokenizer]
    P[passages] --> DT[DocTokenizer]
    QT --> QE[col.query]
    DT --> DE[col.doc]
    QE --> DUP[repeat_interleave]
    DUP --> SCORE[col.score]
    DE --> SCORE
    SCORE --> ARR[np.array of scores]
```

---

## Component Interaction & Data Flow

The three components share a common output convention: retrieval results are returned as `dotdict` objects (from [`dsp_utils`](dsp_utils.md)) exposing a `long_text` attribute, which is the field consumed by the `Retrieve` module in [`retrievers`](retrievers.md).

```mermaid
graph LR
    subgraph "Retrieval Pipeline"
        Query[Query] --> Retriever
        Retriever -->|"top-k passages"| Reranker
        Reranker -->|"reranked scores"| Output[Ranked Passages]
    end

    Retriever -.->|"ColBERTv2 or ColBERTv2RetrieverLocal"| Retriever
    Reranker -.->|"ColBERTv2RerankerLocal"| Reranker
```

A typical two-stage pipeline uses `ColBERTv2RetrieverLocal` (or the hosted `ColBERTv2`) to fetch candidates, then `ColBERTv2RerankerLocal` to reorder them by precise late-interaction scores.

---

## Dependencies

| Dependency | Module | Purpose |
|------------|--------|---------|
| `request_cache` | [`clients_core`](clients_core.md) | Caches HTTP retrieval requests to avoid redundant network calls. |
| `dotdict` | [`dsp_utils`](dsp_utils.md) | Attribute-accessible dict used for passage results. |
| `requests` | external | HTTP client for the hosted server path. |
| `colbert-ai` | external | Provides `Indexer`, `Searcher`, `ColBERT`, and tokenizers for local paths. |
| `torch`, `numpy` | external | Tensor operations and score arrays for local components. |

---

## Integration with DSPy

The components in this module are designed to be assigned to `dspy.settings.rm` and invoked through the `Retrieve` module (see [`retrievers`](retrievers.md)). The `Retrieve.forward` method calls `dspy.settings.rm(query, k=k, **kwargs)` and then extracts `psg.long_text` from each returned passage — which is exactly the attribute produced by all three components here.

```mermaid
sequenceDiagram
    participant Program as DSPy Program
    participant Retrieve as Retrieve (retrievers)
    participant RM as ColBERTv2 / RetrieverLocal
    participant Reranker as ColBERTv2RerankerLocal

    Program->>Retrieve: forward(query, k)
    Retrieve->>RM: rm(query, k=k)
    RM-->>Retrieve: list[dotdict(long_text, score, pid)]
    Retrieve-->>Program: Prediction(passages=[...])
    opt Reranking
        Program->>Reranker: forward(query, passages)
        Reranker-->>Program: np.ndarray scores
    end
```

---

## Related Modules

- [`retrievers`](retrievers.md) — The `Retrieve` module and other retrieval models that consume these components.
- [`clients_core`](clients_core.md) — Provides `request_cache` used for caching hosted requests.
- [`dsp_utils`](dsp_utils.md) — Provides `dotdict` and `Settings` used throughout.
- [`dsp_retrieval_dpr`](dsp_retrieval_dpr.md) — Sibling retrieval utilities (DPR tokenizers) in the same `dsp_retrieval` group.
