# Adapter Types: Media

## Introduction

The `adapter_types_media` module provides DSPy's built-in custom types for handling **multimodal media content** — specifically images and audio — within DSPy signatures. These types allow developers to pass rich media as inputs to language models that support multimodal understanding (e.g., GPT-4o, Claude, Gemini).

The module contains two core types:

- **`Image`** — represents an image referenced by URL, local file path, PIL object, raw bytes, or data URI.
- **`Audio`** — represents audio referenced by URL, local file path, numpy-like array, raw bytes, or data URI.

Both types extend the base [`Type`](adapter_types_base.md) class and implement the `format()` contract, which converts the media into the content-part structure expected by the OpenAI-style chat completion API. This is the same structure consumed by DSPy's [adapters](adapters_implementations.md) when building messages for the LM.

---

## Architecture Overview

The media types sit at the boundary between user-provided data and the LM message format. They are consumed by adapters, which serialize them into content parts.

```mermaid
graph TD
    subgraph "adapter_types_media"
        Image["Image<br/>(url: str)"]
        Audio["Audio<br/>(data: str, audio_format: str)"]
    end

    subgraph "adapter_types_base"
        Type["Type<br/>(pydantic.BaseModel)"]
    end

    subgraph "adapters_implementations"
        Adapter["Adapter"]
        ChatAdapter["ChatAdapter"]
        JSONAdapter["JSONAdapter"]
    end

    subgraph "External Libraries"
        Pydantic["pydantic"]
        PIL["Pillow (PIL)"]
        SoundFile["soundfile"]
        Requests["requests"]
    end

    Image -->|extends| Type
    Audio -->|extends| Type
    Adapter -->|formats via format()| Image
    Adapter -->|formats via format()| Audio
    ChatAdapter -->|inherits| Adapter
    JSONAdapter -->|inherits| Adapter

    Image -.->|optional| PIL
    Image -.->|uses| Requests
    Audio -.->|optional| SoundFile
    Audio -.->|uses| Requests
    Type -->|built on| Pydantic
```

---

## Core Components

### `Image`

The `Image` type wraps a single `url` field that may hold a remote URL, a local file path, or a base64 data URI. It is a frozen Pydantic model with strict validation.

**Key characteristics:**

| Aspect | Detail |
| --- | --- |
| Field | `url: str` |
| Model config | `frozen=True`, `str_strip_whitespace=True`, `validate_assignment=True`, `extra="forbid"` |
| `format()` output | `[{"type": "image_url", "image_url": {"url": <encoded>}}]` |
| Optional dependency | Pillow (`PIL`) for PIL Image / bytes handling |

**Construction helpers:**

- `Image.from_url(url, download=False)` — wraps a URL; optionally downloads and base64-encodes it.
- `Image.from_file(file_path)` — reads a local file and encodes it as a data URI.
- `Image.from_PIL(pil_image)` — encodes a PIL Image object.

**Input validation** (`validate_input`, `mode="before"`) accepts:
- A plain string (treated as the URL).
- A dict with exactly one key `url`.
- An existing `Image` instance.

**Representation:** `__repr__` masks base64 payloads, showing only the image type and encoded length (e.g., `Image(url=data:image/png;base64,<IMAGE_BASE_64_ENCODED(12345)>)`), which keeps logs readable.

### `Audio`

The `Audio` type wraps base64-encoded audio data together with its format.

**Key characteristics:**

| Aspect | Detail |
| --- | --- |
| Fields | `data: str` (base64), `audio_format: str` |
| Model config | `frozen=True`, `extra="forbid"` |
| `format()` output | `[{"type": "input_audio", "input_audio": {"data": <data>, "format": <audio_format>}}]` |
| Optional dependency | `soundfile` for numpy-like array encoding |

**Construction helpers:**

- `Audio.from_url(url)` — downloads audio and base64-encodes it; validates the MIME type starts with `audio/`.
- `Audio.from_file(file_path)` — reads a local audio file and encodes it.
- `Audio.from_array(array, sampling_rate, format="wav")` — encodes a numpy-like array using `soundfile` (PCM_16 subtype).

**Input validation** (`validate_input`, `mode="before"`) delegates to the module-level `encode_audio` function, which normalizes many input shapes into the `{data, audio_format}` dict.

**Representation:** `__repr__` masks the base64 payload (e.g., `Audio(data=<AUDIO_BASE_64_ENCODED(54321)>, audio_format='wav')`).

---

## Module-Level Helper Functions

The module exposes several standalone functions that power the type classes and can be used directly.

### Image helpers

| Function | Purpose |
| --- | --- |
| `encode_image(image, download_images=False)` | Central dispatcher that normalizes dicts, strings, PIL images, bytes, and `Image` instances into a data URI or URL. |
| `is_url(string)` | Validates whether a string is an `http`, `https`, or `gs` URL. |
| `is_image(obj)` | Detects whether an object is a PIL image, data URI, file path, or URL. |
| `_encode_image_from_file(file_path)` | Reads a file and produces a base64 data URI using `mimetypes`. |
| `_encode_image_from_url(image_url)` | Downloads a URL and produces a base64 data URI. |
| `_encode_pil_image(image)` | Serializes a PIL Image to a base64 data URI. |
| `_get_file_extension(path_or_url)` | Extracts a file extension, defaulting to `png`. |

### Audio helpers

| Function | Purpose |
| --- | --- |
| `encode_audio(audio, sampling_rate=16000, format="wav")` | Central dispatcher that normalizes dicts, `Audio` instances, data URIs, file paths, URLs, numpy arrays, and bytes into `{data, audio_format}`. |

---

## Data Flow

The following diagram illustrates how a user-provided media value flows through validation, encoding, and formatting into an LM message.

```mermaid
flowchart TD
    A["User provides media value<br/>(str / dict / PIL / bytes / array)"] --> B{"Type constructor<br/>validate_input"}
    B -->|Image| C1["encode_image()"]
    B -->|Audio| C2["encode_audio()"]

    C1 --> D1{"Input kind?"}
    D1 -->|data URI| E1["Return as-is"]
    D1 -->|file path| E2["_encode_image_from_file()"]
    D1 -->|URL| E3{"download_images?"}
    E3 -->|yes| E4["_encode_image_from_url()"]
    E3 -->|no| E5["Return URL"]
    D1 -->|PIL / bytes| E6["_encode_pil_image()"]

    C2 --> D2{"Input kind?"}
    D2 -->|data URI| F1["Parse header + b64"]
    D2 -->|file path| F2["Audio.from_file()"]
    D2 -->|URL| F3["Audio.from_url()"]
    D2 -->|array| F4["Audio.from_array()"]
    D2 -->|bytes| F5["base64 encode"]

    E1 & E2 & E4 & E5 & E6 --> G["Image instance<br/>(url)"]
    F1 & F2 & F3 & F4 & F5 --> H["Audio instance<br/>(data, audio_format)"]

    G --> I["format()"]
    H --> I
    I --> J["Content parts list<br/>consumed by Adapter"]
```

---

## Component Interaction

Media types interact with the adapter layer through the `format()` method defined on the base [`Type`](adapter_types_base.md) class. When an adapter builds messages, it calls `format_field_value` (from `dspy/adapters/utils.py`), which serializes custom types via their Pydantic model serializer. The serializer invokes `format()` and wraps list results in custom-type markers.

```mermaid
sequenceDiagram
    participant User
    participant Signature
    participant Adapter as Adapter (ChatAdapter/JSONAdapter)
    participant Utils as format_field_value
    participant MediaType as Image / Audio
    participant LM as Language Model

    User->>Signature: Provide media value (e.g., Image)
    Adapter->>Utils: format_field_value(field_info, value)
    Utils->>MediaType: serialize_model() -> format()
    MediaType-->>Utils: list[dict] content parts
    Utils-->>Adapter: formatted content
    Adapter->>LM: messages with multimodal content parts
    LM-->>Adapter: response
```

> **Note:** The `Image.format()` output uses the `image_url` content-part shape, while `Audio.format()` uses the `input_audio` shape. These match the OpenAI chat completion content-part schema, which is the common denominator supported by DSPy's adapters.

---

## Dependencies

```mermaid
graph LR
    subgraph "adapter_types_media"
        Image
        Audio
    end

    subgraph "Internal"
        BaseType["adapter_types_base::Type"]
    end

    subgraph "Required"
        Pydantic["pydantic"]
        Requests["requests"]
    end

    subgraph "Optional"
        PIL["Pillow"]
        SoundFile["soundfile"]
    end

    Image --> BaseType
    Audio --> BaseType
    Image --> Pydantic
    Audio --> Pydantic
    Image --> Requests
    Audio --> Requests
    Image -.-> PIL
    Audio -.-> SoundFile
```

- **Required:** `pydantic` (model definition and validation), `requests` (downloading remote media).
- **Optional:** `Pillow` (required only for PIL Image / raw-bytes image handling), `soundfile` (required only for numpy-array audio encoding). Both are guarded by `try/except ImportError` flags (`PIL_AVAILABLE`, `SF_AVAILABLE`).

---

## Usage Examples

### Image as an input field

```python
import dspy

dspy.configure(lm=dspy.LM("openai/gpt-4o-mini"))

class ImageDescription(dspy.Signature):
    image: dspy.Image = dspy.InputField(description="The image to describe")
    description: str = dspy.OutputField(description="A description of the image")

predict = dspy.Predict(ImageDescription)
result = predict(image=dspy.Image.from_file("photo.png"))
print(result.description)
```

### Audio as an input field

```python
import dspy

dspy.configure(lm=dspy.LM("openai/gpt-4o-audio-preview"))

class Transcription(dspy.Signature):
    audio: dspy.Audio = dspy.InputField(description="The audio to transcribe")
    text: str = dspy.OutputField(description="The transcription")

predict = dspy.Predict(Transcription)
result = predict(audio=dspy.Audio.from_file("speech.wav"))
print(result.text)
```

---

## Design Notes & Constraints

- **Frozen models:** Both `Image` and `Audio` are immutable (`frozen=True`), ensuring media payloads are not mutated after construction.
- **Strict validation:** `extra="forbid"` prevents accidental extra fields, catching malformed inputs early.
- **Lazy optional dependencies:** Pillow and soundfile are imported defensively, so the module works without them as long as the corresponding input kinds are not used.
- **Base64 masking in `__repr__`:** Prevents huge base64 strings from flooding logs and terminals.
- **URL passthrough:** By default, `Image` does not download remote URLs — it passes them through as-is unless `download=True` is specified. `Audio.from_url` always downloads and encodes.

---

## Related Modules

- [adapter_types_base.md](adapter_types_base.md) — the `Type` base class that defines the `format()` contract.
- [adapter_types_code.md](adapter_types_code.md) — the `Code` custom type.
- [adapter_types_history.md](adapter_types_history.md) — the `History` type for conversation history.
- [adapter_types_tool.md](adapter_types_tool.md) — the `Tool` and `ToolCalls` types.
- [adapters_implementations.md](adapters_implementations.md) — the adapters (`ChatAdapter`, `JSONAdapter`, etc.) that consume these types.
