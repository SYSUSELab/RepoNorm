# BetterTogether Optimizer

## Introduction

The `BetterTogether` optimizer is an **experimental** DSPy teleprompter that jointly optimizes both the **prompts** (instructions and demonstrations) and the **weights** (model parameters) of a DSPy program. It does so by alternating between a prompt optimizer and a weight optimizer in a configurable sequence, producing a chain of progressively improved candidate programs.

The core insight behind BetterTogether is that prompt optimization and weight (fine-tuning) optimization are complementary: prompt optimization can bootstrap high-quality demonstrations that improve fine-tuning data, while fine-tuning can produce a stronger model that benefits from further prompt optimization. By interleaving the two, BetterTogether aims to reach a better final program than either approach alone.

> **Note:** This optimizer is experimental and requires `dspy.settings.experimental = True` to be set before use.

---

## Architecture Overview

`BetterTogether` is a subclass of [`Teleprompter`](teleprompt_core.md) and orchestrates two other teleprompters:

- A **prompt optimizer** — defaults to [`BootstrapFewShotWithRandomSearch`](teleprompt_core.md).
- A **weight optimizer** — defaults to [`BootstrapFinetune`](teleprompt_finetune_bootstrap.md).

```mermaid
graph TD
    BT["BetterTogether<br/>(Teleprompter)"]
    PO["prompt_optimizer<br/>BootstrapFewShotWithRandomSearch"]
    WO["weight_optimizer<br/>BootstrapFinetune"]
    Student["Student Module"]
    Trainset["Trainset (list[Example])"]

    BT -->|uses| PO
    BT -->|uses| WO
    BT -->|compiles| Student
    BT -->|consumes| Trainset

    PO -.->|prompt optimization| Student
    WO -.->|weight optimization| Student
```

### Component Relationships

```mermaid
graph LR
    subgraph "teleprompt_finetune"
        BT[BetterTogether]
        BF[BootstrapFinetune]
        GRPO[GRPO]
    end
    subgraph "teleprompt_core"
        TP[Teleprompter]
        BFRS[BootstrapFewShotWithRandomSearch]
    end
    subgraph "primitives"
        Module[Module]
        Example[Example]
    end

    BT -->|inherits| TP
    BT -->|default weight optimizer| BF
    BT -->|default prompt optimizer| BFRS
    BT -->|operates on| Module
    BT -->|operates on| Example
```

---

## Class Reference

### `BetterTogether`

```python
class BetterTogether(Teleprompter):
    STRAT_SEP = " -> "
```

A teleprompter that alternates between prompt and weight optimization according to a user-specified strategy string.

#### Constructor

```python
def __init__(
    self,
    metric: Callable,
    prompt_optimizer: Teleprompter | None = None,
    weight_optimizer: Teleprompter | None = None,
    seed: int | None = None,
)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `metric` | `Callable` | The metric used to evaluate and filter training data. Required. |
| `prompt_optimizer` | `Teleprompter \| None` | The optimizer used for prompt optimization. Defaults to `BootstrapFewShotWithRandomSearch(metric=metric)`. |
| `weight_optimizer` | `Teleprompter \| None` | The optimizer used for weight optimization. Defaults to `BootstrapFinetune(metric=metric)`. |
| `seed` | `int \| None` | Seed for the internal random number generator used to shuffle the trainset between steps. |

**Validation performed in the constructor:**

1. Raises `ValueError` if `dspy.settings.experimental` is not `True`.
2. Raises `ValueError` if `prompt_optimizer` is not a `BootstrapFewShotWithRandomSearch` instance or `weight_optimizer` is not a `BootstrapFinetune` instance. Only these two optimizers are currently supported.

#### `compile`

```python
def compile(
    self,
    student: Module,
    trainset: list[Example],
    strategy: str = "p -> w -> p",
    valset_ratio: float = 0.1,
) -> Module
```

Compiles (optimizes) the student program by running the sequence of optimization steps described by `strategy`.

| Parameter | Type | Description |
|-----------|------|-------------|
| `student` | `Module` | The student program to optimize. Must not already be compiled. |
| `trainset` | `list[Example]` | The training set. A shallow copy is made so the original ordering is preserved. |
| `strategy` | `str` | A sequence of `p` (prompt) and `w` (weight) steps separated by `" -> "`. Defaults to `"p -> w -> p"`. |
| `valset_ratio` | `float` | Fraction of the trainset reserved as a validation set for the prompt optimizer. Defaults to `0.1`. |

**Returns:** The optimized `Module`, with a `candidate_programs` attribute attached (see below).

**Raises:** `ValueError` if the strategy contains tokens other than `p` or `w`.

---

## Strategy Execution Flow

The `compile` method delegates to `_run_strategies`, which iterates over the parsed strategy tokens. Each token triggers either prompt or weight optimization, and the resulting program is recorded as a candidate.

```mermaid
flowchart TD
    Start([compile]) --> Validate["Validate strategy string"]
    Validate --> Prep["prepare_student(student)"]
    Prep --> CheckLMs["all_predictors_have_lms(student)"]
    CheckLMs --> Copy["Shallow-copy trainset"]
    Copy --> Run["_run_strategies(...)"]
    Run --> Done([Return optimized student])

    subgraph "_run_strategies loop"
        Init["candidate_programs = [('', student)]"] --> Loop{"For each step_code<br/>in parsed_strategy"}
        Loop --> Shuffle["rng.shuffle(trainset)"]
        Shuffle --> Launch{"LMs launched?"}
        Launch -->|No| LaunchLMs["launch_lms(student)"]
        Launch -->|Yes| DeepCopy
        LaunchLMs --> DeepCopy["student = student.deepcopy()<br/>student._compiled = False"]
        DeepCopy --> Branch{"step_code?"}
        Branch -->|"p"| PromptOpt["_compile_prompt_optimizer"]
        Branch -->|"w"| WeightOpt["_compile_weight_optimizer<br/>launched_flag = False"]
        PromptOpt --> Record["Append (current_strategy, student)"]
        WeightOpt --> Record
        Record --> Loop
        Loop -->|Done| Kill{"launched_flag?"}
        Kill -->|Yes| KillLMs["kill_lms(student)"]
        Kill -->|No| Attach
        KillLMs --> Attach["student.candidate_programs = candidate_programs"]
    end
```

### Step Semantics

| Token | Meaning | Method invoked |
|-------|---------|----------------|
| `p` | Prompt optimization | `_compile_prompt_optimizer` |
| `w` | Weight optimization (fine-tuning) | `_compile_weight_optimizer` |

The `STRAT_SEP` (`" -> "`) separates tokens. For example, `"p -> w -> p"` means: optimize prompts, then fine-tune weights, then optimize prompts again.

---

## Internal Methods

### `_run_strategies`

```python
def _run_strategies(self, parsed_strategy, student, trainset, valset_ratio) -> Module
```

Drives the optimization loop. Key behaviors:

- Maintains a `candidate_programs` list, seeded with `("", student)` representing the initial program.
- Shuffles the trainset before each step using the seeded RNG for reproducibility.
- Launches LMs lazily on the first step and kills them when a weight-optimization step completes (or at the end if still launched).
- Deep-copies the student before each step and resets its `_compiled` flag.
- Attaches the full list of `(strategy, program)` tuples to `student.candidate_programs`.

### `_compile_prompt_optimizer`

```python
def _compile_prompt_optimizer(self, student, trainset, valset_ratio) -> Module
```

Prepares and runs the prompt optimizer:

1. Strips the `hint` input field from each example (hints are dropped for prompt optimization).
2. Splits the trainset into a validation set (`valset_ratio` fraction) and a training set.
3. Saves the current predictor LMs, runs `prompt_optimizer.compile(...)`, then **restores** the original LMs on each predictor.

> The LM restoration works around a known issue where `BootstrapFewShotWithRandomSearch` resets predictor LMs.

### `_compile_weight_optimizer`

```python
def _compile_weight_optimizer(self, student, trainset) -> Module
```

Prepares and runs the weight optimizer:

1. Saves the original LMs of all predictors.
2. Runs `weight_optimizer.compile(student, trainset=trainset)`.
3. For each new (fine-tuned) LM, copies the `train_kwargs` configured for the original LM so that subsequent fine-tuning steps use the correct hyperparameters.

---

## Data Flow

```mermaid
sequenceDiagram
    participant User
    participant BT as BetterTogether
    participant PO as Prompt Optimizer
    participant WO as Weight Optimizer
    participant Student as Student Module

    User->>BT: compile(student, trainset, strategy="p -> w -> p")
    BT->>BT: prepare_student + validate LMs
    loop For each step in strategy
        BT->>BT: shuffle trainset, deepcopy student
        alt step == "p"
            BT->>PO: compile(student, trainset, valset)
            PO-->>BT: prompt-optimized student
            BT->>Student: restore original LMs
        else step == "w"
            BT->>WO: compile(student, trainset)
            WO-->>BT: fine-tuned student
            BT->>WO: copy train_kwargs to new LMs
        end
        BT->>BT: record candidate program
    end
    BT-->>User: optimized student + candidate_programs
```

---

## Candidate Programs

After compilation, the returned student has a `candidate_programs` attribute:

```python
student.candidate_programs = [
    ("", student_initial),
    ("p", student_after_prompt_opt),
    ("p -> w", student_after_weight_opt),
    ("p -> w -> p", student_after_second_prompt_opt),
]
```

Each entry is a tuple of `(strategy_string, program)`. The empty string `""` corresponds to the initial, unoptimized student. This allows downstream selection of the best intermediate program.

---

## Dependencies

### Internal DSPy Modules

| Dependency | Purpose | Documentation |
|------------|---------|---------------|
| `Teleprompter` | Base class defining the `compile` interface. | [teleprompt_core.md](teleprompt_core.md) |
| `BootstrapFewShotWithRandomSearch` | Default prompt optimizer. | [teleprompt_core.md](teleprompt_core.md) |
| `BootstrapFinetune` | Default weight optimizer; performs fine-tuning. | [teleprompt_finetune_bootstrap.md](teleprompt_finetune_bootstrap.md) |
| `prepare_student`, `launch_lms`, `kill_lms`, `all_predictors_have_lms` | Helper functions imported from `bootstrap_finetune`. | [teleprompt_finetune_bootstrap.md](teleprompt_finetune_bootstrap.md) |
| `Module` | The program being optimized. | [primitives.md](primitives.md) |
| `Example` | Training/validation data items. | [primitives.md](primitives.md) |

### Imported Helpers from `bootstrap_finetune`

```python
from dspy.teleprompt.bootstrap_finetune import (
    BootstrapFinetune,
    all_predictors_have_lms,
    kill_lms,
    launch_lms,
    prepare_student,
)
```

- `prepare_student(student)` — validates that the student is not already compiled and returns it.
- `all_predictors_have_lms(student)` — asserts every predictor has an LM assigned.
- `launch_lms(student)` / `kill_lms(student)` — start/stop the unique LMs attached to the program's predictors.

---

## Usage Example

```python
import dspy

# Enable experimental features
dspy.settings.experimental = True

# Define a metric
def my_metric(example, pred, trace=None):
    return example.answer == pred.answer

# Create the optimizer
optimizer = dspy.BetterTogether(
    metric=my_metric,
    seed=42,
)

# Compile the student program
optimized_program = optimizer.compile(
    student=my_program,
    trainset=my_trainset,
    strategy="p -> w -> p",
    valset_ratio=0.1,
)

# Inspect candidate programs
for strategy, program in optimized_program.candidate_programs:
    print(strategy, program)
```

---

## Design Notes and Limitations

- **Experimental status:** Requires `dspy.settings.experimental = True`.
- **Restricted optimizers:** Only `BootstrapFewShotWithRandomSearch` (prompt) and `BootstrapFinetune` (weight) are supported. Passing other optimizers raises a `ValueError`.
- **LM management:** LMs are launched lazily and killed after weight optimization to free resources. The `launched_flag` tracks this state across steps.
- **LM restoration:** After prompt optimization, the original LMs are restored on predictors to work around `BootstrapFewShotWithRandomSearch` resetting them.
- **`train_kwargs` propagation:** When fine-tuning produces new LMs, the original `train_kwargs` are copied to the new LMs so subsequent weight-optimization steps use consistent hyperparameters.
- **Metric requirement:** The metric is currently required, though the code contains TODOs suggesting this may be relaxed in the future (e.g., for unlabeled training data).

---

## Related Documentation

- [teleprompt_finetune_bootstrap.md](teleprompt_finetune_bootstrap.md) — `BootstrapFinetune` and fine-tuning helpers.
- [teleprompt_finetune_grpo.md](teleprompt_finetune_grpo.md) — `GRPO` reinforcement-learning optimizer.
- [teleprompt_core.md](teleprompt_core.md) — `Teleprompter` base class and core optimizers.
- [primitives.md](primitives.md) — `Module`, `Example`, and other primitives.
