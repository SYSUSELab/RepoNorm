# Utils Dummies Module

## Introduction

The `utils_dummies` module provides lightweight, deterministic stand-ins for real language models and retrieval components, enabling fast, offline, and reproducible testing of DSPy programs. It contains two core components:

- **`DummyLM`** — a fake language model that returns pre-configured answers instead of calling a real LLM API.
- **`DummyVectorizer`** — a simple n-gram based vectorizer used for embedding-free retrieval testing (paired with the `dummy_rm` helper).

These utilities are primarily used in unit tests and examples where invoking a real model would be slow, costly, or non-deterministic. By substituting a `DummyLM` into `dspy.settings`, developers can exercise the full DSPy pipeline (adapters, signatures, predictors, optimizers) without any network calls.

---

## Architecture Overview

`DummyLM` subclasses the real [`LM`](clients_core.md) class, so it inherits the full LM interface (`__call__`, `acall`, `history`, `update_history`, `kwargs`, etc.) while overriding the request logic to return canned responses. It reuses the [`ChatAdapter`](adapters.md) formatting machinery to produce responses that look exactly like real model outputs, ensuring downstream parsing works identically.

```mermaid
graph TD
    subgraph utils_dummies
        DLM[DummyLM]
        DV[DummyVectorizer]
        DRM[dummy_rm]
    end

    subgraph clients_core
        LM[LM]
        BLM[BaseLM]
    end

    subgraph adapters
        CA[ChatAdapter]
        FIWN[FieldInfoWithName]
    end

    subgraph signatures
        OF[OutputField]
    end

    subgraph utils_callbacks
        WC[with_callbacks]
    end

    subgraph dsp_utils_helpers
        DD[dotdict]
    end

    DLM -->|inherits| LM
    LM -->|inherits| BLM
    DLM -->|uses| CA
    DLM -->|uses| FIWN
    DLM -->|uses| OF
    DLM -->|decorated by| WC
    DRM -->|uses| DV
    DRM -->|returns| DD
```

---

## Component Details

### `DummyLM`

A dummy language model for unit testing. It extends [`LM`](clients_core.md) and is initialized with a fixed set of answers. It supports three distinct modes of operation.

#### Constructor

```python
DummyLM(
    answers: list[dict[str, str]] | dict[str, dict[str, str]],
    follow_examples: bool = False,
)
```

Internally it calls `super().__init__("dummy", "chat", 0.0, 1000, True)`, configuring a chat-type model with zero temperature, a 1000-token limit, and caching enabled. If `answers` is a list, it is converted into an iterator so successive calls consume answers in order.

#### Operating Modes

| Mode | Input Type | Behavior |
|------|-----------|----------|
| **1. List of dictionaries** | `list[dict]` | Returns the next dictionary in the list for each request, formatted via `format_field_with_value`. |
| **2. Dictionary of dictionaries** | `dict[str, dict]` | Matches a key against the final message content and returns the corresponding value. |
| **3. Follow examples** | `follow_examples=True` | If the prompt contains an example input equal to the prompt, returns that example's output. |

**Mode 1 example:**

```python
lm = DummyLM([{"answer": "red"}, {"answer": "blue"}])
dspy.settings.configure(lm=lm)
predictor("What color is the sky?")  # -> [[## answer ##]]\nred
predictor("What color is the sky?")  # -> [[## answer ##]]\nblue
```

**Mode 2 example:**

```python
lm = DummyLM({"What color is the sky?": {"answer": "blue"}})
dspy.settings.configure(lm=lm)
predictor("What color is the sky?")  # -> [[## answer ##]]\nblue
```

**Mode 3 example:**

```python
lm = DummyLM([{"answer": "red"}], follow_examples=True)
dspy.settings.configure(lm=lm)
predictor("What color is the sky?",
          demos=dspy.Example(input="What color is the sky?", output="blue"))
# -> [[## answer ##]]\nblue
```

#### Key Methods

- **`__call__(prompt=None, messages=None, **kwargs)`** — Decorated with [`with_callbacks`](utils_callbacks.md). Builds `n` outputs (default 1), formats each answer using `ChatAdapter().format_field_with_value`, records an entry in `history` (with `usage=0` and `cost=0`), and returns the list of outputs. When answers are exhausted, it returns `"No more responses"`.
- **`acall(...)`** — Async wrapper that simply delegates to `__call__`.
- **`_use_example(messages)`** — Implements Mode 3. It scans message headers to identify output fields (those appearing fewer times than the max), then finds the last turn whose content contains those output fields and whose preceding input matches the final input.
- **`get_convo(index)`** — Returns the `(messages, outputs)` tuple for the `index`-th recorded interaction.

#### Data Flow

```mermaid
sequenceDiagram
    participant P as Predictor
    participant D as DummyLM
    participant CA as ChatAdapter
    participant H as history

    P->>D: __call__(prompt/messages, n)
    D->>D: select answer (mode 1/2/3)
    D->>CA: format_field_with_value(fields)
    CA-->>D: formatted string
    D->>H: update_history(entry)
    D-->>P: [outputs]
```

---

### `DummyVectorizer`

A simple vectorizer based on character n-grams, used to produce deterministic embeddings without any external model.

#### Constructor

```python
DummyVectorizer(max_length=100, n_gram=2)
```

- `max_length` — dimensionality of the output vectors (also the modulus for hashing).
- `n_gram` — size of the character n-grams.
- Uses a fixed random seed (`123`) to generate polynomial hash coefficients, ensuring reproducibility.

#### Key Methods

- **`_hash(gram)`** — Polynomial rolling hash of an n-gram, reduced modulo a large prime (`10**9 + 7`) and then modulo `max_length`.
- **`__call__(texts: list[str]) -> np.ndarray`** — For each text, computes n-grams, increments the corresponding vector buckets (a bag-of-n-grams / hashing trick), then mean-centers and L2-normalizes each vector. Returns a `float32` NumPy array of shape `(len(texts), max_length)`.

---

### `dummy_rm` (helper)

A factory function that builds a simple retrieval function over a fixed set of passages using `DummyVectorizer`.

```python
def dummy_rm(passages=()) -> callable
```

- If no passages are provided, the returned function raises `ValueError("No passages defined")`.
- Otherwise, it vectorizes all passages once, then returns an `inner(query, *, k, **kwargs)` function that:
  1. Vectorizes the query.
  2. Computes dot-product scores against all passage vectors.
  3. Returns the top-`k` passages as [`dotdict`](dsp_utils_helpers.md) objects with a `long_text` attribute.

This is useful for testing retrieval-based programs (e.g., [`Retrieve`](retrievers_core.md)) without a real vector database.

---

## Component Interaction

```mermaid
graph LR
    subgraph Testing Harness
        T[Unit Test]
    end

    T -->|configures| S[dspy.settings]
    S -->|lm=| DLM[DummyLM]
    S -->|rm=| DRM[dummy_rm]

    DLM -->|formats via| CA[ChatAdapter]
    DRM -->|embeds via| DV[DummyVectorizer]

    T -->|runs| PRED[Predictor / Program]
    PRED -->|calls| DLM
    PRED -->|calls| DRM
```

---

## Integration with the Broader System

`DummyLM` is a drop-in replacement for [`LM`](clients_core.md) and can be configured globally:

```python
import dspy
from dspy.utils.dummies import DummyLM

dspy.settings.configure(lm=DummyLM([{"answer": "blue"}]))
```

Because it inherits from `LM`, it participates in the same callback system ([`with_callbacks`](utils_callbacks.md)), history tracking, and adapter pipeline as a real model. This makes it ideal for:

- **Unit testing** predictors, modules, and optimizers.
- **Documentation examples** that must run without API keys.
- **Deterministic regression tests** where output must be reproducible.

The `DummyVectorizer` and `dummy_rm` pair with retrieval modules such as [`Retrieve`](retrievers_core.md) and [`Embeddings`](retrievers_embeddings.md) to test retrieval flows offline.

---

## Related Modules

- [clients_core](clients_core.md) — `LM` and `BaseLM`, the base classes `DummyLM` extends.
- [adapters](adapters.md) — `ChatAdapter` and `FieldInfoWithName`, used for response formatting.
- [signatures](signatures.md) — `OutputField`, used to construct field metadata.
- [utils_callbacks](utils_callbacks.md) — `with_callbacks`, the decorator applied to `DummyLM.__call__`.
- [dsp_utils_helpers](dsp_utils_helpers.md) — `dotdict`, returned by `dummy_rm`.
- [retrievers_core](retrievers_core.md) — retrieval modules testable with `dummy_rm`.
