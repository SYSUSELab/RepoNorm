# Retrievers

The **retrievers** module provides DSPy's retrieval-augmented generation (RAG) building blocks. It defines a uniform interface for fetching relevant passages from a corpus and ships several concrete retriever implementations backed by different storage/search engines (local embeddings, Databricks Vector Search, and Weaviate).

Retrievers are the "R" in RAG: they take a query and return the top-`k` passages that a downstream DSPy program (e.g. [`Predict`](predict_core.md), [`ChainOfThought`](predict_core_chain_of_thought.md), or [`ReAct`](predict_advanced_agents.md)) can use as context.

## Purpose

- **Standardize retrieval**: expose a single `Retrieve` abstraction that any DSPy module can call.
- **Integrate with `dspy.settings.rm`**: the configured retriever is globally accessible via `dspy.settings.rm`, so programs can retrieve without hard-coding a backend.
- **Provide pluggable backends**: local embeddings (FAISS), Databricks Mosaic AI Vector Search, and Weaviate, each implementing the same call contract.

## Architecture Overview

```mermaid
graph TD
    subgraph "DSPy Program"
        P[Predict / ChainOfThought / ReAct]
    end

    subgraph "retrievers module"
        R["Retrieve<br/>(retrieve.py)"]
        E["Embeddings<br/>(embeddings.py)"]
        D["DatabricksRM<br/>(databricks_rm.py)"]
        W["WeaviateRM<br/>(weaviate_rm.py)"]
    end

    subgraph "External backends"
        FAISS[(FAISS index)]
        DBX[(Databricks Vector Search)]
        WV[(Weaviate)]
    end

    P -->|"dspy.settings.rm(query, k)"| R
    R -->|delegates| E
    R -->|delegates| D
    R -->|delegates| W
    E --> FAISS
    D --> DBX
    W --> WV

    R -->|returns| PRED["Prediction(passages=...)"]
    E -->|returns| PRED
    D -->|returns| PRED
    W -->|returns| PRED
```

### Component Relationships

```mermaid
classDiagram
    class Parameter
    class Retrieve {
        +str name = "Search"
        +str input_variable = "query"
        +int k
        +forward(query, k) Prediction
        +dump_state()
        +load_state(state)
    }
    class Embeddings {
        +list corpus
        +embedder
        +int k
        +forward(query) Prediction
        +_build_faiss()
        +_faiss_search()
        +_rerank_and_predict()
    }
    class DatabricksRM {
        +str databricks_index_name
        +int k
        +forward(query, query_type, filters_json)
    }
    class WeaviateRM {
        +str weaviate_collection_name
        +int k
        +forward(query_or_queries, k)
        +get_objects()
        +insert()
    }

    Parameter <|-- Retrieve
    Retrieve <|-- DatabricksRM
    Retrieve <|-- WeaviateRM
    Embeddings ..> Retrieve : same call contract
```

## Core Functionality

### 1. Retrieve — the retrieval interface
[`Retrieve`](retrievers_core.md) is the base abstraction. It is a `Parameter` subclass that:
- Reads the globally configured retriever from `dspy.settings.rm`.
- Calls it with a `query` and `k`, normalizes the result into a `Prediction(passages=[...])`.
- Supports state serialization (`dump_state` / `load_state`) and callback instrumentation via `with_callbacks`.

See [retrievers_core.md](retrievers_core.md) for details.

### 2. Embeddings — local embeddings retriever
[`Embeddings`](retrievers_embeddings.md) performs in-memory semantic search over a corpus using a user-supplied embedder. It:
- Pre-computes and normalizes corpus embeddings.
- Optionally builds a FAISS IVF-PQ index when the corpus exceeds a brute-force threshold.
- Uses [`Unbatchify`](utils.md) to transparently batch concurrent queries.
- Returns passages plus their corpus indices.

See [retrievers_embeddings.md](retrievers_embeddings.md) for details.

### 3. DatabricksRM — Databricks Vector Search retriever
[`DatabricksRM`](retrievers_databricks.md) queries a Databricks Mosaic AI Vector Search Index. It:
- Supports both the `databricks-sdk` and a raw `requests`-based query path.
- Handles token or service-principal authentication.
- Supports ANN/HYBRID query types, filters, extra columns, and optional Databricks Agent Framework compatibility.

See [retrievers_databricks.md](retrievers_databricks.md) for details.

### 4. WeaviateRM — Weaviate retriever
[`WeaviateRM`](retrievers_weaviate.md) performs hybrid search against a Weaviate collection. It:
- Supports both Weaviate v3 (`Client`) and v4 (`WeaviateClient`) Python clients.
- Supports multi-tenant collections.
- Provides `get_objects` and `insert` helpers (v4 only).

See [retrievers_weaviate.md](retrievers_weaviate.md) for details.

## Data Flow

```mermaid
sequenceDiagram
    participant Prog as DSPy Program
    participant R as Retrieve
    participant RM as dspy.settings.rm
    participant Backend as Backend (Embeddings/Databricks/Weaviate)

    Prog->>R: Retrieve(k=3)(query="...")
    R->>R: forward(query, k)
    R->>RM: rm(query, k=k)
    RM->>Backend: search(query, k)
    Backend-->>RM: passages / docs
    RM-->>R: passages
    R->>R: normalize to Prediction(passages=[...])
    R-->>Prog: Prediction
```

## Integration with the Broader System

- **Configuration**: retrievers are registered through [`dspy.settings`](dsp_utils_settings.md) (`dspy.settings.configure(rm=...)`). `Retrieve.forward` asserts that an RM is loaded.
- **Predictions**: all retrievers return [`Prediction`](primitives_prediction.md) objects (or lists of them), the standard DSPy output container.
- **Parameters**: `Retrieve` extends [`Parameter`](predict_core_predict.md), making it composable inside DSPy modules and optimizable.
- **Callbacks**: `Retrieve.__call__` is wrapped with `with_callbacks` from [`dspy.utils.callback`](utils.md) for observability.
- **Batching**: `Embeddings` relies on [`Unbatchify`](utils.md) for efficient batched embedding/search.

## Sub-module Reference

| Sub-module | File | Description |
|------------|------|-------------|
| [retrievers_core.md](retrievers_core.md) | `dspy/retrievers/retrieve.py` | The `Retrieve` base interface and passage normalization. |
| [retrievers_embeddings.md](retrievers_embeddings.md) | `dspy/retrievers/embeddings.py` | Local embeddings-based retriever with optional FAISS indexing. |
| [retrievers_databricks.md](retrievers_databricks.md) | `dspy/retrievers/databricks_rm.py` | Databricks Mosaic AI Vector Search retriever. |
| [retrievers_weaviate.md](retrievers_weaviate.md) | `dspy/retrievers/weaviate_rm.py` | Weaviate hybrid-search retriever. |
