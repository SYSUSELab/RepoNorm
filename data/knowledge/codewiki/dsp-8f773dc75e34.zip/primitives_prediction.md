# Primitives: Prediction

## Introduction

The `primitives_prediction` module provides the core data structures that represent the **output** of a DSPy module execution. It contains two primary classes:

- **`Prediction`** — the object returned by a DSPy module when it is called. It holds the output fields produced by the underlying language model (or any other predictor) and supports score-based comparison and arithmetic operations.
- **`Completions`** — a container that holds multiple candidate completions for the same set of output fields, enabling multi-sample workflows (e.g., `BestOfN`, `Refine`, or any predictor that returns several candidates).

Together, these classes form the "output side" of the DSPy data model, complementing [`Example`](primitives_example.md) (the "input side") and [`Module`](primitives_module.md) (the executable unit).

---

## Module Overview

`Prediction` is a subclass of [`Example`](primitives_example.md). This inheritance is deliberate: a prediction is fundamentally a key/value store of fields, exactly like an example, but with additional semantics for scoring, comparison, and multi-completion handling.

```mermaid
classDiagram
    class Example {
        +_store: dict
        +_demos: list
        +_input_keys: set
        +with_inputs(*keys)
        +inputs()
        +labels()
        +toDict()
    }

    class Prediction {
        +_completions: Completions
        +_lm_usage: dict
        +from_completions(list_or_dict, signature)
        +get_lm_usage()
        +set_lm_usage(value)
        +completions: Completions
        +__float__()
        +__add__() / __radd__()
        +__truediv__() / __rtruediv__()
        +__lt__() / __le__() / __gt__() / __ge__()
    }

    class Completions {
        +signature
        +_completions: dict
        +items()
        +__getitem__(key)
        +__getattr__(name)
        +__len__()
        +__contains__(key)
    }

    Example <|-- Prediction
    Prediction *-- Completions
    Completions ..> Prediction : creates on indexing
```

---

## `Prediction`

### Purpose

`Prediction` is the canonical return type of a DSPy module call. When a module's `forward` method returns, the framework wraps the output fields into a `Prediction` so that downstream code (evaluators, optimizers, teleprompters) can uniformly access fields, scores, and token usage.

### Construction

`Prediction` inherits `Example`'s flexible constructor (`base` object/dict plus arbitrary `**kwargs`), but it **removes** the `_demos` and `_input_keys` attributes that are only meaningful for inputs:

```python
def __init__(self, *args, **kwargs):
    super().__init__(*args, **kwargs)
    del self._demos
    del self._input_keys
    self._completions = None
    self._lm_usage = None
```

This means a `Prediction` is a pure output container — it does not carry few-shot demonstrations or input-key metadata.

### Factory: `from_completions`

The classmethod `from_completions` builds a `Prediction` from a list of dicts or a dict of lists, storing the full set of candidates in a `Completions` object while exposing the **first** candidate as the primary field values:

```python
@classmethod
def from_completions(cls, list_or_dict, signature=None):
    obj = cls()
    obj._completions = Completions(list_or_dict, signature=signature)
    obj._store = {k: v[0] for k, v in obj._completions.items()}
    return obj
```

This is the bridge between multi-sample predictors and the single-value `Prediction` interface.

### Score-Based Operations

A `Prediction` becomes "numeric" when it contains a `score` field. The `__float__` method extracts it, and all comparison and arithmetic operators delegate to it:

| Operation | Behavior |
|-----------|----------|
| `float(pred)` | Returns `float(pred.score)`; raises `ValueError` if no `score` field |
| `pred + other` / `other + pred` | Adds scores (supports `int`, `float`, or another `Prediction`) |
| `pred / other` / `other / pred` | Divides scores |
| `pred < other`, `<=`, `>`, `>=` | Compares scores |

> **Note:** Equality (`==`) is **not** overridden — it is inherited from `Example`, which compares the underlying `_store` dictionaries. This is intentional: two predictions are "equal" when their data matches, while ordering is defined by score.

This design enables feedback-augmented scoring workflows where predictions can be sorted, averaged, or thresholded directly.

### Token Usage Tracking

`Prediction` carries an optional `_lm_usage` payload, set via `set_lm_usage` and read via `get_lm_usage`. This is populated by [`Module.__call__`](primitives_module.md) when `settings.track_usage` is enabled, allowing callers to inspect token consumption per prediction.

### Representation

`__repr__` renders the primary fields and, when multiple completions exist, notes how many were omitted:

```
Prediction(
    answer='Paris',
    completions=Completions(...)
) (2 completions omitted)
```

---

## `Completions`

### Purpose

`Completions` is a columnar container for multiple candidate outputs. It normalizes two input shapes into a single internal representation — a dict mapping field names to **lists** of values:

- **List of dicts** (one dict per candidate) → transposed into columns.
- **Dict of lists** (already columnar) → used directly.

```python
if isinstance(list_or_dict, list):
    kwargs = {}
    for arg in list_or_dict:
        for k, v in arg.items():
            kwargs.setdefault(k, []).append(v)
else:
    kwargs = list_or_dict
```

It validates that all values are lists and that all lists share the same length, guaranteeing a rectangular structure.

### Access Patterns

`Completions` supports two distinct indexing modes:

| Access | Result |
|--------|--------|
| `completions[i]` (int) | A new `Prediction` built from the `i`-th value of every field |
| `completions["field"]` (str) | The full list of values for that field |
| `completions.field` | Same as string indexing (via `__getattr__`) |
| `len(completions)` | Number of candidates |
| `"field" in completions` | Field membership test |

The integer-indexing behavior is the key feature: it lets callers iterate over candidates as individual `Prediction` objects while retaining access to the aggregate columns.

```mermaid
flowchart LR
    A["Completions\n{answer: [a1, a2, a3],\n reasoning: [r1, r2, r3]}"]
    A -->|"[0]"| P0["Prediction(answer=a1, reasoning=r1)"]
    A -->|"[1]"| P1["Prediction(answer=a2, reasoning=r2)"]
    A -->|"[2]"| P2["Prediction(answer=a3, reasoning=r3)"]
    A -->|"['answer']"| C["[a1, a2, a3]"]
```

### Guarded Attribute Access

`__getattr__` explicitly guards against recursion on `_completions` (raising `AttributeError` for that name) before checking field membership, preventing infinite recursion during unpickling or partial initialization.

---

## Position in the DSPy Data Model

`Prediction` and `Completions` sit at the boundary between execution and evaluation. The diagram below shows how they flow through the system.

```mermaid
flowchart TD
    subgraph Inputs
        EX["Example\n(inputs + labels)"]
    end

    subgraph Execution
        MOD["Module.__call__\n(primitives_module)"]
        PRED["Predict / ChainOfThought\n(predict_core)"]
        ADV["BestOfN / Refine\n(predict_advanced)"]
    end

    subgraph Outputs
        P["Prediction"]
        C["Completions"]
    end

    subgraph Consumers
        EVAL["Evaluate\n(evaluate)"]
        OPT["Teleprompters\n(teleprompt_*)"]
    end

    EX --> MOD
    MOD --> PRED
    MOD --> ADV
    PRED --> P
    ADV --> C
    C -->|"from_completions"| P
    P --> EVAL
    P --> OPT
    C --> OPT
```

### Key Relationships

- **Inherits from [`Example`](primitives_example.md):** Reuses the dict-like field store, `keys()`, `values()`, `items()`, `get()`, and equality semantics.
- **Returned by [`Module`](primitives_module.md):** `Module.__call__` and `Module.acall` return a `Prediction` and attach token usage via `set_lm_usage`.
- **Produced by predictors:** [`Predict`](predict_core.md) and [`ChainOfThought`](predict_core.md) return single `Prediction`s; advanced predictors like `BestOfN` and `Refine` (see [predict_advanced](predict_advanced.md)) populate `Completions`.
- **Consumed by evaluation:** [`Evaluate`](evaluate.md) reads the `score` field and uses the comparison operators to aggregate metrics.
- **Consumed by optimizers:** Teleprompters (see [teleprompt_core](teleprompt_core.md)) inspect predictions and their completions to select and refine programs.

---

## Data Flow: From LM Output to Prediction

```mermaid
sequenceDiagram
    participant Caller
    participant Module as Module.__call__
    participant Predictor as Predict
    participant LM as LM (clients_core)
    participant Pred as Prediction

    Caller->>Module: module(inputs)
    Module->>Predictor: forward(**inputs)
    Predictor->>LM: request(prompt)
    LM-->>Predictor: raw completion
    Predictor->>Pred: Prediction(**parsed_fields)
    Predictor-->>Module: Prediction
    Module->>Pred: set_lm_usage(tokens)
    Module-->>Caller: Prediction
```

For multi-sample predictors, the flow diverges at the predictor step: instead of a single `Prediction`, the predictor builds a `Completions` object and calls `Prediction.from_completions(...)`, which exposes the first candidate as the primary fields while preserving all candidates for downstream selection.

---

## Summary

| Class | Role | Key Capabilities |
|-------|------|------------------|
| `Prediction` | Single output of a module call | Field access (via `Example`), score-based comparison/arithmetic, token usage, multi-completion awareness |
| `Completions` | Container of candidate outputs | Columnar storage, integer indexing → `Prediction`, attribute/field access, length & membership |

The module is intentionally small but central: nearly every DSPy workflow — prediction, evaluation, and optimization — passes through these two classes. Understanding their dual nature (dict-like field store + numeric score carrier) is essential for working with the rest of the framework.

---

## Related Documentation

- [primitives_example.md](primitives_example.md) — the base `Example` class and input handling
- [primitives_module.md](primitives_module.md) — `Module` and `BaseModule`, which return `Prediction`s
- [predict_core.md](predict_core.md) — `Predict`, `ChainOfThought`, and `Parallel`
- [predict_advanced.md](predict_advanced.md) — `BestOfN`, `Refine`, and other multi-completion predictors
- [evaluate.md](evaluate.md) — how predictions are scored and aggregated
- [clients_core.md](clients_core.md) — the LM layer that produces raw completions
