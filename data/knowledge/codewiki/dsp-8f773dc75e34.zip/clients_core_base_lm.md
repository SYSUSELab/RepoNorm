# clients_core_base_lm

## Introduction

The `clients_core_base_lm` module provides the foundational abstraction for all Language Model (LM) interactions in DSPy. At its core is the `BaseLM` class, an extensible base class that defines the contract every language model client must fulfill. It handles the cross-cutting concerns of LM invocation—response normalization, history tracking, callback dispatch, and synchronous/asynchronous execution—while delegating the actual provider-specific request logic to subclasses.

Most users interact with the concrete [`LM`](clients_core_lm.md) subclass, which implements `BaseLM` on top of LiteLLM. However, `BaseLM` is designed to be subclassed directly when integrating custom LLM providers or injecting bespoke logic, requiring only an override of the `forward` (and optionally `aforward`) method.

---

## Purpose and Core Functionality

`BaseLM` serves as the central contract and shared machinery for LM calls within DSPy. Its responsibilities include:

1. **Defining the LM interface** — Establishes the `__call__` / `acall` entry points and the `forward` / `aforward` extension points that subclasses implement.
2. **Response normalization** — Converts provider responses into a consistent output format (a list of strings, or a list of dicts when logprobs/tool calls are present).
3. **History management** — Records every interaction at three levels: global, per-LM-instance, and per-caller-module.
4. **Callback integration** — Wraps calls with the `@with_callbacks` decorator so that user-defined [`BaseCallback`](utils.md) handlers fire around LM execution.
5. **Configuration awareness** — Respects global [`Settings`](dsp_utils.md) such as `disable_history`, `max_history_size`, and `caller_modules`.
6. **Instance cloning** — Provides `copy()` to produce modified LM instances (used heavily by fine-tuning workflows).

---

## Architecture

The module is intentionally minimal, acting as a base layer that concrete providers build upon. The diagram below shows how `BaseLM` sits within the broader clients subsystem.

```mermaid
graph TD
    subgraph "clients_core"
        BaseLM["BaseLM<br/>(base_lm.py)"]
        LM["LM<br/>(lm.py)"]
        Cache["Cache<br/>(cache.py)"]
        Embedder["Embedder<br/>(embedding.py)"]
        Provider["Provider<br/>(provider.py)"]
    end

    subgraph "clients_providers"
        OpenAI["OpenAIProvider"]
        Databricks["DatabricksProvider"]
        Local["LocalProvider"]
        Arbor["ArborProvider"]
    end

    subgraph "dsp_utils"
        Settings["Settings"]
    end

    subgraph "utils"
        Callback["BaseCallback"]
        InspectHistory["pretty_print_history"]
    end

    LM -->|extends| BaseLM
    LM -->|uses| Cache
    LM -->|uses| Provider
    Provider --> OpenAI
    Provider --> Databricks
    Provider --> Local
    Provider --> Arbor

    BaseLM -->|reads config| Settings
    BaseLM -->|dispatches| Callback
    BaseLM -->|renders| InspectHistory
```

### Key Relationships

- **`LM` (subclass)** — The primary concrete implementation. It overrides `forward`/`aforward` to call LiteLLM, adds caching, retries, provider inference, and fine-tuning/reinforcement hooks. See [clients_core_lm.md](clients_core_lm.md).
- **`Settings`** — A thread-safe singleton providing global configuration. `BaseLM` reads `disable_history`, `max_history_size`, and `caller_modules` from it. See [dsp_utils.md](dsp_utils.md).
- **`BaseCallback`** — The callback base class whose `on_lm_start` / `on_lm_end` handlers are triggered via the `@with_callbacks` decorator. See [utils.md](utils.md).
- **`pretty_print_history`** — Utility used by `inspect_history` to render recorded interactions. See [utils.md](utils.md).

---

## Component: `BaseLM`

### Constructor

```python
BaseLM(model, model_type="chat", temperature=0.0, max_tokens=1000, cache=True, **kwargs)
```

| Parameter | Description |
|-----------|-------------|
| `model` | Identifier of the model (e.g., `"openai/gpt-4o"`). |
| `model_type` | Either `"chat"` or `"text"`. |
| `temperature` | Sampling temperature, stored in `self.kwargs`. |
| `max_tokens` | Maximum tokens to generate, stored in `self.kwargs`. |
| `cache` | Whether responses may be cached. |
| `**kwargs` | Additional parameters merged into `self.kwargs`. |

The constructor initializes `self.history = []` and stores all generation parameters in `self.kwargs`, which subclasses merge with per-call overrides.

### Public API

| Method | Description |
|--------|-------------|
| `__call__(prompt, messages, **kwargs)` | Synchronous entry point. Calls `forward`, then normalizes the response. Decorated with `@with_callbacks`. |
| `acall(prompt, messages, **kwargs)` | Asynchronous entry point. Calls `aforward`, then normalizes the response. Decorated with `@with_callbacks`. |
| `forward(prompt, messages, **kwargs)` | **Abstract.** Subclasses must implement; must return an OpenAI-compatible response object. |
| `aforward(prompt, messages, **kwargs)` | **Abstract.** Async variant for subclasses supporting async. |
| `copy(**kwargs)` | Returns a deep copy with updated attributes; resets history. |
| `inspect_history(n=1)` | Pretty-prints the last `n` interactions from this instance's history. |
| `update_history(entry)` | Appends an entry to global, instance, and per-module histories. |

### Response Processing (`_process_lm_response`)

This internal method is the heart of response normalization. It:

1. Merges instance `self.kwargs` with per-call `kwargs`.
2. Iterates over `response.choices`, extracting `text`, optional `logprobs`, and optional `tool_calls`.
3. **Simplifies output**: if every choice contains only a `text` key, returns a flat list of strings; otherwise returns a list of dicts.
4. If `settings.disable_history` is set, returns early without logging.
5. Otherwise builds a history `entry` containing prompt, messages, sanitized kwargs (API keys stripped), response, outputs, usage, cost, timestamp, UUID, and model metadata, then calls `update_history`.

### History Management

`BaseLM` maintains history at three tiers, all bounded by `settings.max_history_size`:

```mermaid
flowchart TD
    A["update_history(entry)"] --> B{"settings.disable_history?"}
    B -->|Yes| Z["Return (no logging)"]
    B -->|No| C["Append to GLOBAL_HISTORY<br/>(capped at MAX_HISTORY_SIZE = 10,000)"]
    C --> D{"settings.max_history_size == 0?"}
    D -->|Yes| Z
    D -->|No| E["Append to self.history<br/>(capped at max_history_size)"]
    E --> F["For each module in settings.caller_modules"]
    F --> G["Append to module.history<br/>(capped at max_history_size)"]
```

- **Global history** (`GLOBAL_HISTORY`) — Shared across all LM instances; capped at the module-level constant `MAX_HISTORY_SIZE = 10_000`. Accessible via the module-level `inspect_history()` function.
- **Instance history** (`self.history`) — Per-LM-instance log, capped at `settings.max_history_size`.
- **Per-module history** — Each module listed in `settings.caller_modules` receives a copy of the entry, enabling module-scoped inspection.

---

## Execution Flow

The following sequence diagram illustrates a typical synchronous LM call, from the caller through to history recording.

```mermaid
sequenceDiagram
    participant Caller as Caller (Module/Predict)
    participant BaseLM as BaseLM.__call__
    participant CB as Callback Handlers
    participant Forward as forward() [subclass]
    participant Process as _process_lm_response
    participant History as update_history

    Caller->>BaseLM: __call__(prompt, messages, **kwargs)
    BaseLM->>CB: on_lm_start(call_id, instance, inputs)
    BaseLM->>Forward: forward(prompt, messages, **kwargs)
    Forward-->>BaseLM: response (OpenAI-compatible)
    BaseLM->>Process: _process_lm_response(response, ...)
    Process->>Process: normalize choices → outputs
    Process->>History: update_history(entry)
    History-->>Process: (global + instance + module)
    Process-->>BaseLM: outputs
    BaseLM->>CB: on_lm_end(call_id, outputs, exception)
    BaseLM-->>Caller: outputs
```

The asynchronous path (`acall` → `aforward`) follows the identical structure, awaiting the provider call.

---

## Extending `BaseLM`

To support a custom provider, subclass `BaseLM` and implement `forward` (and `aforward` for async support). The returned object must match the [OpenAI response format](https://platform.openai.com/docs/api-reference/responses/object).

```python
from openai import OpenAI
import dspy


class MyLM(dspy.BaseLM):
    def forward(self, prompt, messages=None, **kwargs):
        client = OpenAI()
        return client.chat.completions.create(
            model=self.model,
            messages=messages or [{"role": "user", "content": prompt}],
            **self.kwargs,
        )


lm = MyLM(model="gpt-4o-mini")
dspy.configure(lm=lm)
print(dspy.Predict("q->a")(q="Why did the chicken cross the kitchen?"))
```

By implementing only `forward`, the subclass automatically inherits response normalization, history tracking, and callback dispatch.

---

## Dependencies

```mermaid
graph LR
    BaseLM["BaseLM"]
    BaseLM --> settings["dspy.dsp.utils.settings"]
    BaseLM --> callbacks["dspy.utils.callback.with_callbacks"]
    BaseLM --> inspect["dspy.utils.inspect_history.pretty_print_history"]
    BaseLM --> stdlib["datetime, uuid"]
```

| Dependency | Role |
|------------|------|
| `dspy.dsp.utils.settings` | Provides global configuration (`disable_history`, `max_history_size`, `caller_modules`). See [dsp_utils.md](dsp_utils.md). |
| `dspy.utils.callback.with_callbacks` | Decorator that dispatches `on_lm_start` / `on_lm_end` handlers. See [utils.md](utils.md). |
| `dspy.utils.inspect_history.pretty_print_history` | Renders recorded history for `inspect_history`. See [utils.md](utils.md). |
| `datetime`, `uuid` | Timestamping and unique identification of history entries. |

---

## Related Modules

- [clients_core_lm.md](clients_core_lm.md) — The concrete `LM` subclass built on LiteLLM.
- [clients_core_cache.md](clients_core_cache.md) — Caching layer used by `LM`.
- [clients_core_provider.md](clients_core_provider.md) — Provider abstraction for fine-tuning and reinforcement learning.
- [clients_core_embedder.md](clients_core_embedder.md) — Embedding client abstraction.
- [dsp_utils.md](dsp_utils.md) — Global `Settings` configuration.
- [utils.md](utils.md) — Callbacks, history inspection, and other utilities.
