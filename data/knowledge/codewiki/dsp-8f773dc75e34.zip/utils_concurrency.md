# Utils Concurrency Module

## Introduction

The `utils_concurrency` module provides the concurrency primitives that power DSPy's parallel and batched execution. It contains two complementary components:

- **`ParallelExecutor`** — a thread-pool based executor that runs a user function over a collection of items in parallel, with per-task isolation of DSPy settings, error tolerance, straggler timeouts, and progress reporting.
- **`Unbatchify`** — a batching adapter that converts a single-item callable interface into a batched one, transparently accumulating concurrent single-item calls into batches and dispatching them through a batch-processing function.

Together these utilities enable DSPy programs (e.g., [`Parallel`](predict_core.md), [`Evaluate`](evaluate.md), and teleprompters) to scale workloads across threads while preserving correct, isolated configuration state.

---

## Module Architecture

The module sits within the broader `utils` package and depends on DSPy's thread-local settings infrastructure.

```mermaid
graph TD
    subgraph utils_concurrency["utils_concurrency (current module)"]
        PE["ParallelExecutor<br/>(parallelizer.py)"]
        UB["Unbatchify<br/>(unbatchify.py)"]
    end

    subgraph dsp_utils["dsp_utils"]
        Settings["Settings<br/>(settings.py)"]
        ThreadLocal["thread_local_overrides<br/>(settings.py)"]
    end

    subgraph utils_usage["utils_usage_tracking"]
        UT["UsageTracker<br/>(usage_tracker.py)"]
    end

    subgraph consumers["Consumers"]
        Parallel["Parallel<br/>(predict_core)"]
        Evaluate["Evaluate<br/>(evaluate)"]
        Teleprompters["Teleprompters<br/>(teleprompt_*)"]
    end

    PE -->|reads config| Settings
    PE -->|propagates overrides| ThreadLocal
    PE -->|deep-copies per thread| UT
    UB -->|wraps batch_fn| UB

    Parallel --> PE
    Evaluate --> PE
    Teleprompters --> PE
    Parallel --> UB
```

### Component Responsibilities

| Component | File | Primary Responsibility |
|-----------|------|------------------------|
| `ParallelExecutor` | `dspy/utils/parallelizer.py` | Parallel execution of a function over data with isolation, error handling, and timeouts |
| `Unbatchify` | `dspy/utils/unbatchify.py` | Convert single-item calls into batched calls via a background worker thread |

---

## ParallelExecutor

`ParallelExecutor` is the workhorse for concurrent execution in DSPy. It offers isolation between tasks with respect to `dspy.settings`, regardless of whether `num_threads == 1` or `> 1`, and additionally handles straggler timeouts.

### Constructor Parameters

```python
ParallelExecutor(
    num_threads=None,
    max_errors=None,
    disable_progress_bar=False,
    provide_traceback=None,
    compare_results=False,
    timeout=120,
    straggler_limit=3,
)
```

| Parameter | Default | Description |
|-----------|---------|-------------|
| `num_threads` | `settings.num_threads` | Number of worker threads in the pool. Falls back to the global setting when `None`. |
| `max_errors` | `settings.max_errors` | Maximum number of errors tolerated before cancelling all remaining jobs. |
| `disable_progress_bar` | `False` | Whether to suppress the `tqdm` progress bar. |
| `provide_traceback` | `settings.provide_traceback` | Whether to log full tracebacks on task failure. |
| `compare_results` | `False` | When `True`, the progress bar reports an average metric instead of a processed count. |
| `timeout` | `120` | Per-task timeout (seconds) used for straggler detection. `0` disables it. |
| `straggler_limit` | `3` | Only check for stragglers when this few tasks remain outstanding. |

### Public API

#### `execute(function, data)`

The primary entry point. Clears any stale `tqdm` instances, wraps the user function with error handling, and dispatches to the parallel engine.

```python
executor = ParallelExecutor(num_threads=8)
results = executor.execute(my_function, my_data)
```

Returns a list of results in the **same order** as the input `data`. Failed or cancelled items are represented as `None`.

### Execution Flow

```mermaid
flowchart TD
    Start([execute called]) --> Clear[tqdm._instances.clear]
    Clear --> Wrap[_wrap_function<br/>adds error handling + cancellation check]
    Wrap --> Parallel[_execute_parallel]

    Parallel --> Submit[Submit all items to ThreadPoolExecutor]
    Submit --> Loop{futures remaining<br/>and not cancelled?}

    Loop -->|yes| Wait[wait FIRST_COMPLETED, timeout=1s]
    Wait --> Collect[Collect done futures<br/>store results by index]
    Collect --> Progress[Update progress bar]
    Progress --> AllDone{all results filled?}
    AllDone -->|yes| Break[break]
    AllDone -->|no| Straggler{not_done <= straggler_limit<br/>and timeout > 0?}
    Straggler -->|yes| Check[Resubmit tasks exceeding timeout<br/>at most once per item]
    Straggler -->|no| Loop
    Check --> Loop
    Break --> Close[Close progress bar]
    Close --> Shutdown[executor.shutdown wait=False]
    Shutdown --> Cancelled{cancel_jobs set?}
    Cancelled -->|yes| Raise[Raise Exception]
    Cancelled -->|no| Return([Return results])
```

### Key Behaviors

#### 1. Settings Isolation via Thread-Local Overrides

Each worker thread applies the parent thread's overrides before running the user function, then resets them afterward. This ensures that `dspy.context(...)` blocks propagate correctly into spawned threads.

```python
original = thread_local_overrides.get()
token = thread_local_overrides.set({**original, **parent_overrides.copy()})
try:
    return index, function(item)
finally:
    thread_local_overrides.reset(token)
```

See [`Settings`](dsp_utils.md) for details on how thread-local overrides and global configuration interact.

#### 2. Usage Tracker Deep-Copy

When a `usage_tracker` override is present, it is **deep-copied** per thread so that each thread accumulates its own usage independently, avoiding cross-thread mutation races. See [`UsageTracker`](utils_usage_tracking.md) for the tracking data model.

#### 3. Error Tolerance and Cancellation

The wrapped function increments a shared `error_count` under a lock. Once `error_count >= max_errors`, the `cancel_jobs` event is set, causing all pending and future tasks to short-circuit and return `None`. If cancellation occurs, `execute` raises an exception after cleanup.

#### 4. Straggler Timeouts

When only a few tasks remain (`<= straggler_limit`), the executor checks each outstanding task's start time. Any task exceeding `timeout` seconds is **resubmitted once** (tracked via the `resubmitted` set) to mitigate a single slow worker blocking completion.

#### 5. Ctrl-C Handling

An `interrupt_manager` context manager installs a `SIGINT` handler (only in the main thread) that sets `cancel_jobs` and logs a warning, allowing graceful cancellation on keyboard interrupt.

### Progress Reporting

`_update_progress` adapts the progress bar description based on `compare_results`:

- **`compare_results=True`**: `Average Metric: {sum:.2f} / {count} ({pct}%)`
- **`compare_results=False`**: `Processed {nresults} / {ntotal} examples`

---

## Unbatchify

`Unbatchify` bridges the gap between single-item and batched interfaces. It accepts a batch-processing function and exposes a thread-safe single-item callable that transparently accumulates concurrent calls into batches.

### Constructor Parameters

```python
Unbatchify(
    batch_fn: Callable[[list[Any]], list[Any]],
    max_batch_size: int = 32,
    max_wait_time: float = 0.1,
)
```

| Parameter | Default | Description |
|-----------|---------|-------------|
| `batch_fn` | — | Function accepting a list of inputs and returning a list of outputs. |
| `max_batch_size` | `32` | Maximum number of items per batch. |
| `max_wait_time` | `0.1` | Maximum seconds to wait for a batch to fill before processing. |

### Public API

| Method | Description |
|--------|-------------|
| `__call__(input_item)` | Thread-safe; enqueues a single item and blocks until its result is available. |
| `close()` | Stops the worker thread and drains remaining queued items with an error. |
| `__enter__` / `__exit__` | Enables use as a context manager for automatic cleanup. |
| `__del__` | Ensures the worker thread terminates on garbage collection. |

### Batching Flow

```mermaid
sequenceDiagram
    participant Caller as Caller Thread(s)
    participant Queue as input_queue
    participant Worker as Worker Thread
    participant BatchFn as batch_fn

    Caller->>Queue: put((input_item, future))
    Worker->>Queue: get(timeout=max_wait_time)
    Note over Worker: Accumulate until<br/>max_batch_size OR max_wait_time
    Worker->>BatchFn: batch_fn(batch)
    BatchFn-->>Worker: outputs
    Worker->>Caller: future.set_result(output)
    Caller-->>Caller: future.result() returns
```

### Key Behaviors

#### 1. Background Worker Thread

A daemon thread (`self.worker_thread`) is started in the constructor. It continuously drains the `input_queue`, forming batches bounded by both `max_batch_size` and `max_wait_time`.

#### 2. Future-Based Synchronization

Each call creates a `concurrent.futures.Future`, enqueues it alongside the input, and blocks on `future.result()`. This provides a synchronous single-item interface backed by asynchronous batching.

#### 3. Error Propagation

If `batch_fn` raises, the exception is set on **all** futures in the current batch, so every waiting caller receives the error.

#### 4. Graceful Shutdown

`close()` sets the `stop_event` and joins the worker thread. Any items still in the queue are drained and their futures are completed with a `RuntimeError("Unbatchify is closed")`. The context manager and `__del__` both invoke `close()`.

---

## Component Interaction

The two components serve distinct but complementary roles in DSPy's concurrency model:

```mermaid
graph LR
    subgraph "Fan-out (ParallelExecutor)"
        Data[Data Items] --> PE[ParallelExecutor]
        PE --> T1[Thread 1]
        PE --> T2[Thread 2]
        PE --> T3[Thread N]
    end

    subgraph "Fan-in (Unbatchify)"
        T1 --> UB[Unbatchify]
        T2 --> UB
        T3 --> UB
        UB --> Batch[batch_fn]
    end
```

- **`ParallelExecutor`** fans work *out* across threads.
- **`Unbatchify`** fans concurrent single-item calls *in* to a shared batch processor.

A common pattern is to run many parallel tasks (via `ParallelExecutor`) where each task internally calls an `Unbatchify`-wrapped function, allowing the underlying model or service to process requests in efficient batches.

---

## Integration Points

| Consumer | Usage |
|----------|-------|
| [`Parallel`](predict_core.md) | Uses `ParallelExecutor` to run multiple predictions concurrently. |
| [`Evaluate`](evaluate.md) | Uses `ParallelExecutor` to evaluate examples in parallel, leveraging `compare_results` for metric averaging. |
| Teleprompters (`teleprompt_*`) | Use `ParallelExecutor` for parallel bootstrapping and candidate evaluation. |
| [`Settings`](dsp_utils.md) | Provides `num_threads`, `max_errors`, `provide_traceback`, and thread-local override propagation. |
| [`UsageTracker`](utils_usage_tracking.md) | Deep-copied per thread to isolate usage accounting. |

---

## Summary

The `utils_concurrency` module delivers the foundational concurrency building blocks for DSPy:

- **`ParallelExecutor`** provides robust, isolated, error-tolerant parallel execution with straggler handling and progress reporting.
- **`Unbatchify`** provides transparent batching for single-item interfaces via a background worker thread.

Both components are designed to interoperate with DSPy's thread-local [`Settings`](dsp_utils.md) system, ensuring that configuration context is correctly propagated and isolated across concurrent execution paths.
