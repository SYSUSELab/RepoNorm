# Predict Core: ChainOfThought

## Introduction

The `ChainOfThought` module is a foundational reasoning primitive in DSPy. It wraps a user-provided [`Signature`](../signatures/signature.py) and automatically augments it with a `reasoning` output field, instructing the underlying language model to "think step by step" before producing the final answer. This simple yet powerful technique—popularized as *chain-of-thought prompting*—significantly improves performance on tasks requiring multi-step reasoning (e.g., math, logic, and multi-hop question answering).

`ChainOfThought` is a thin, composable wrapper around [`Predict`](predict_core_predict.md). It does not implement its own inference logic; instead, it delegates all execution to an internal `Predict` instance whose signature has been extended with the reasoning field.

---

## Purpose and Core Functionality

The module's responsibilities are deliberately minimal:

1. **Signature augmentation** — Prepend a `reasoning` output field to the supplied signature.
2. **Delegation** — Forward all calls (sync and async) to an internal `Predict` instance.
3. **Configuration passthrough** — Accept and forward arbitrary configuration (e.g., `temperature`, `n`) to the underlying predictor.

By keeping the module thin, `ChainOfThought` inherits all the capabilities of `Predict`—adapters, streaming, caching, usage tracking, tracing—without reimplementing them.

---

## Architecture

`ChainOfThought` sits in the `predict_core` module alongside `Predict` and `Parallel`. It is a subclass of [`Module`](../primitives/module.py), the base class for all DSPy programs.

```mermaid
graph TD
    subgraph predict_core["predict_core module"]
        CoT["ChainOfThought"]
        Pred["Predict"]
        Param["Parameter"]
        Par["Parallel"]
    end

    subgraph primitives["primitives"]
        Module["Module"]
        Prediction["Prediction"]
    end

    subgraph signatures["signatures"]
        Signature["Signature"]
        ensure["ensure_signature()"]
        OutputField["OutputField"]
    end

    CoT -->|inherits| Module
    CoT -->|creates & delegates to| Pred
    Pred -->|inherits| Module
    Pred -->|inherits| Param
    CoT -->|uses| ensure
    CoT -->|uses| OutputField
    CoT -->|uses| Signature
    Pred -->|produces| Prediction
    Module -->|batch uses| Par
```

### Key Relationships

| Component | Relationship | Description |
|-----------|--------------|-------------|
| [`Module`](../primitives/module.py) | Base class | Provides `__call__`, `acall`, `batch`, predictor discovery, and LM management. |
| [`Predict`](predict_core_predict.md) | Composition | The internal predictor that performs the actual LM call. |
| [`Signature`](../signatures/signature.py) | Input/Output | The task specification that is extended with a `reasoning` field. |
| [`OutputField`](../signatures/field.py) | Construction | Used to build the default `reasoning` field. |
| [`Prediction`](../primitives/prediction.py) | Output | The result object returned by the delegated `Predict`. |

---

## Component Deep Dive

### `ChainOfThought`

```python
class ChainOfThought(Module):
    def __init__(
        self,
        signature: str | type[Signature],
        rationale_field: FieldInfo | None = None,
        rationale_field_type: type = str,
        **config: dict[str, Any],
    ):
        ...
        self.predict = dspy.Predict(extended_signature, **config)
```

#### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `signature` | `str \| type[Signature]` | *required* | The task signature. A string is converted to a `Signature` via `ensure_signature`. |
| `rationale_field` | `FieldInfo \| None` | `None` | A custom field definition for the reasoning output. If omitted, a default is created. |
| `rationale_field_type` | `type` | `str` | The Python type of the reasoning field (used when `rationale_field` is not provided). |
| `**config` | `dict[str, Any]` | `{}` | Arbitrary configuration forwarded to the internal `Predict` (e.g., `temperature`, `n`). |

#### Initialization Flow

The constructor performs the following steps:

1. **Normalize the signature** — `ensure_signature(signature)` converts a string into a `Signature` class.
2. **Define the reasoning field** — If no `rationale_field` is supplied, a default `OutputField` is created with:
   - `prefix = "Reasoning: Let's think step by step in order to"`
   - `desc = "${reasoning}"`
3. **Resolve the field type** — The type is taken from `rationale_field.annotation` if a custom field is given, otherwise from `rationale_field_type`.
4. **Extend the signature** — `signature.prepend(name="reasoning", field=rationale_field, type_=rationale_field_type)` inserts the reasoning field as the **first output field**.
5. **Instantiate the predictor** — `dspy.Predict(extended_signature, **config)` is stored as `self.predict`.

```mermaid
flowchart TD
    A["ChainOfThought(signature, ...)"] --> B["ensure_signature(signature)"]
    B --> C{rationale_field provided?}
    C -->|No| D["Create default OutputField<br/>prefix='Reasoning: Let's think step by step in order to'<br/>desc='${reasoning}'"]
    C -->|Yes| E["Use provided rationale_field"]
    D --> F["Resolve field type"]
    E --> F
    F --> G["signature.prepend('reasoning', field, type_)"]
    G --> H["self.predict = dspy.Predict(extended_signature, **config)"]
```

#### Methods

| Method | Signature | Description |
|--------|-----------|-------------|
| `forward` | `forward(**kwargs)` | Synchronous entry point. Delegates to `self.predict(**kwargs)`. |
| `aforward` | `async aforward(**kwargs)` | Asynchronous entry point. Delegates to `await self.predict.acall(**kwargs)`. |

Both methods are invoked indirectly through the inherited `Module.__call__` / `Module.acall`, which handle callbacks, usage tracking, and caller-module context.

---

## Data Flow

The following sequence diagram illustrates a complete synchronous invocation, from the user call through to the returned `Prediction`.

```mermaid
sequenceDiagram
    participant User
    participant CoT as ChainOfThought
    participant Module as Module.__call__
    participant Pred as Predict
    participant Adapter as Adapter (ChatAdapter)
    participant LM as BaseLM

    User->>CoT: cot(question="...")
    CoT->>Module: __call__(question="...")
    Module->>Module: set caller_modules context
    Module->>CoT: forward(question="...")
    CoT->>Pred: predict(question="...")
    Pred->>Pred: _forward_preprocess()
    Pred->>Adapter: adapter(lm, signature, demos, inputs)
    Adapter->>LM: LM request (with reasoning field)
    LM-->>Adapter: raw completions
    Adapter-->>Pred: completions
    Pred->>Pred: _forward_postprocess() -> Prediction
    Pred-->>CoT: Prediction(reasoning=..., answer=...)
    CoT-->>Module: Prediction
    Module-->>User: Prediction
```

### Signature Transformation

The most important data transformation is the signature extension. Given an input signature:

```
Input:  question
Output: answer
```

`ChainOfThought` produces:

```
Input:  question
Output: reasoning   <-- prepended
        answer
```

The `reasoning` field is inserted at index `0` of the output fields, ensuring the model generates its reasoning *before* the final answer.

---

## Integration with the Broader System

Because `ChainOfThought` delegates to `Predict`, it transparently benefits from the entire DSPy runtime:

```mermaid
graph LR
    CoT["ChainOfThought"] --> Pred["Predict"]
    Pred --> Adapters["adapters<br/>(ChatAdapter, JSONAdapter, ...)"]
    Pred --> Clients["clients_core<br/>(LM, BaseLM, Cache)"]
    Pred --> Settings["dsp_utils<br/>(Settings)"]
    Pred --> Streaming["streaming<br/>(StreamListener)"]
    Pred --> Utils["utils<br/>(callbacks, usage_tracker)"]
```

| System Area | Reference | How ChainOfThought benefits |
|-------------|-----------|-----------------------------|
| Adapters | [adapters](adapters.md) | Formats the extended signature for the LM. |
| Clients | [clients_core](clients_core.md) | Executes the LM call and caches results. |
| Settings | [dsp_utils](dsp_utils.md) | Provides global LM, adapter, and tracing configuration. |
| Streaming | [streaming](streaming.md) | Streams tokens when configured. |
| Primitives | [primitives](primitives.md) | `Module` base class and `Prediction` output. |
| Signatures | [signatures](signatures.md) | Signature definition and field manipulation. |

---

## Usage Examples

### Basic Usage

```python
import dspy

# Define a task signature
class QA(dspy.Signature):
    """Answer the question."""
    question = dspy.InputField()
    answer = dspy.OutputField()

# Wrap it with ChainOfThought
cot = dspy.ChainOfThought(QA)

# The model now reasons before answering
result = cot(question="What is 17 * 24?")
print(result.reasoning)  # step-by-step reasoning
print(result.answer)     # final answer
```

### Custom Rationale Field

```python
cot = dspy.ChainOfThought(
    QA,
    rationale_field=dspy.OutputField(
        prefix="Let me work through this carefully:",
        desc="Detailed step-by-step derivation",
    ),
)
```

### With Configuration

```python
cot = dspy.ChainOfThought(QA, temperature=0.7, n=3)
```

### Async Usage

```python
result = await cot.acall(question="What is 17 * 24?")
```

### Batch Processing

Since `ChainOfThought` inherits from `Module`, it supports batched execution via `Module.batch`:

```python
examples = [dspy.Example(question=q).with_inputs("question") for q in questions]
results = cot.batch(examples)
```

---

## Design Rationale

**Why a separate module instead of a flag on `Predict`?**
Separating `ChainOfThought` into its own module keeps `Predict` focused on the mechanics of LM invocation, while `ChainOfThought` expresses a *reasoning strategy*. This composition-based design makes it trivial to build further strategies (e.g., [`ProgramOfThought`](predict_advanced.md), [`ReAct`](predict_advanced.md)) on top of the same primitives.

**Why prepend rather than append the reasoning field?**
Language models generate output tokens autoregressively. Placing `reasoning` first ensures the model produces its intermediate reasoning *before* committing to a final answer, which is the essence of chain-of-thought prompting.

**Why delegate to `Predict`?**
Delegation means `ChainOfThought` automatically inherits every feature added to `Predict`—new adapters, streaming, caching, usage tracking—without any code changes. This minimizes maintenance surface and keeps behavior consistent across the `predict_core` family.

---

## Related Modules

- [predict_core_predict](predict_core_predict.md) — The underlying `Predict` module that performs LM calls.
- [predict_core_parallel](predict_core_parallel.md) — Parallel execution used by `Module.batch`.
- [predict_advanced](predict_advanced.md) — Higher-level reasoning strategies built on similar primitives.
- [primitives](primitives.md) — `Module`, `Prediction`, and other core abstractions.
- [signatures](signatures.md) — Signature definition, field manipulation, and `ensure_signature`.
