# Teleprompt Core: Random Search

## Introduction

The `teleprompt_core_random_search` module provides `BootstrapFewShotWithRandomSearch`, a DSPy teleprompter (optimizer) that automatically discovers high-quality few-shot demonstrations for a program by generating and evaluating many candidate programs.

Rather than relying on a single bootstrapping run, this optimizer explores a *search space* of candidate programs. Each candidate is produced by a different random configuration of the training data (different shuffles and different numbers of bootstrapped demonstrations), and each candidate is scored against a validation set. The best-scoring candidate is returned, with all candidates attached for later inspection.

This module builds directly on top of the bootstrapping machinery in [teleprompt_core_bootstrap](teleprompt_core_bootstrap.md) and the labeled-demo baseline in [teleprompt_core_labeled_fewshot](teleprompt_core_labeled_fewshot.md), and it uses the evaluation engine from [evaluate_evaluation_engine](evaluate_evaluation_engine.md) to score candidates.

---

## Core Component

### `BootstrapFewShotWithRandomSearch`

A subclass of `Teleprompter` (see [teleprompt_core_base](teleprompt_core_base.md)) that implements a random-search strategy over bootstrapped few-shot programs.

**Constructor parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `metric` | `Callable` | required | Metric function used both to accept bootstrapped demos and to score candidate programs. |
| `teacher_settings` | `dict` | `{}` | Settings passed to the teacher model during bootstrapping. |
| `max_bootstrapped_demos` | `int` | `4` | Upper bound on the number of bootstrapped demos sampled per predictor. |
| `max_labeled_demos` | `int` | `16` | Maximum number of labeled demos included in each candidate. |
| `max_rounds` | `int` | `1` | Number of bootstrapping rounds attempted per example. |
| `num_candidate_programs` | `int` | `16` | Number of candidate programs to generate and evaluate. |
| `num_threads` | `int` | `None` | Threads used by the evaluation engine. |
| `max_errors` | `int` | `None` | Error budget; falls back to `dspy.settings.max_errors`. |
| `stop_at_score` | `float` | `None` | Early-stopping threshold; stop once a candidate reaches this score. |
| `metric_threshold` | `float` | `None` | Threshold used by the underlying `BootstrapFewShot` to accept demos. |

**Key attributes set during construction:**

- `min_num_samples = 1` and `max_num_samples = max_bootstrapped_demos` — the range from which the number of traces per predictor is sampled.
- `num_candidate_sets = num_candidate_programs` — the number of candidate programs to attempt.

---

## How It Works

The `compile` method iterates over a range of integer *seeds* from `-3` up to `num_candidate_programs - 1`. Each seed maps to a distinct candidate-generation strategy:

| Seed | Strategy |
|------|----------|
| `-3` | **Zero-shot** — a fresh copy of the student with no demos (`student.reset_copy()`). |
| `-2` | **Labels only** — `LabeledFewShot` with `k = max_labeled_demos`. |
| `-1` | **Unshuffled few-shot** — `BootstrapFewShot` on the original training set order. |
| `>= 0` | **Randomized few-shot** — the training set is shuffled with `random.Random(seed)`, and a random demo count is drawn between `min_num_samples` and `max_num_samples`; then `BootstrapFewShot` runs on the shuffled set. |

For every candidate, the optimizer:

1. Builds the candidate program using the appropriate strategy.
2. Evaluates it on the validation set (`valset`, defaulting to `trainset`) using `Evaluate`.
3. Records the overall `score` and per-example `subscores`.
4. Tracks the best-scoring program seen so far.
5. Optionally stops early if `stop_at_score` is reached.

After the loop, all candidate records (`score`, `subscores`, `seed`, `program`) are attached to the best program as `candidate_programs`, sorted in descending order of score.

### Process Flow

```mermaid
flowchart TD
    A[compile student, trainset, valset] --> B{For each seed in -3..num_candidate_programs-1}
    B --> C{restrict filter?}
    C -->|seed not allowed| B
    C -->|allowed| D{Which seed?}
    D -->|seed == -3| E[Zero-shot: student.reset_copy]
    D -->|seed == -2| F[LabeledFewShot k=max_labeled_demos]
    D -->|seed == -1| G[BootstrapFewShot unshuffled]
    D -->|seed >= 0| H[Shuffle trainset + random demo count]
    H --> I[BootstrapFewShot on shuffled set]
    E --> J[Evaluate on valset]
    F --> J
    G --> J
    I --> J
    J --> K[Record score + subscores]
    K --> L{score > best?}
    L -->|yes| M[Update best_program]
    L -->|no| N[Keep current best]
    M --> O{stop_at_score reached?}
    N --> O
    O -->|yes| P[Break loop]
    O -->|no| B
    P --> Q[Attach sorted candidate_programs to best]
    Q --> R[Return best_program]
```

---

## Architecture and Dependencies

`BootstrapFewShotWithRandomSearch` orchestrates several other modules. It does not implement bootstrapping or evaluation itself; it delegates to specialized components.

```mermaid
graph TD
    RSW[BootstrapFewShotWithRandomSearch] -->|inherits| TP[Teleprompter]
    RSW -->|uses| BFS[BootstrapFewShot]
    RSW -->|uses| LFS[LabeledFewShot]
    RSW -->|uses| EV[Evaluate]
    RSW -->|uses| DSPY[dspy.settings]

    BFS -->|inherits| TP
    LFS -->|inherits| TP
    BFS -->|uses| LFS
    EV -->|returns| ER[EvaluationResult]

    subgraph "teleprompt_core"
        TP
        BFS
        LFS
        RSW
    end
    subgraph "evaluate"
        EV
        ER
    end
```

### Dependency Summary

| Dependency | Role | Documentation |
|------------|------|---------------|
| `Teleprompter` | Base class defining the `compile` interface. | [teleprompt_core_base](teleprompt_core_base.md) |
| `BootstrapFewShot` | Generates bootstrapped demos for each candidate. | [teleprompt_core_bootstrap](teleprompt_core_bootstrap.md) |
| `LabeledFewShot` | Provides the labels-only baseline candidate. | [teleprompt_core_labeled_fewshot](teleprompt_core_labeled_fewshot.md) |
| `Evaluate` / `EvaluationResult` | Scores each candidate on the validation set. | [evaluate_evaluation_engine](evaluate_evaluation_engine.md) |
| `dspy.settings` | Supplies default `max_errors`. | [dsp_utils_settings](dsp_utils_settings.md) |

---

## Data Flow

The following diagram shows how data moves through a single candidate iteration and how results accumulate.

```mermaid
sequenceDiagram
    participant User
    participant RSW as BootstrapFewShotWithRandomSearch
    participant BFS as BootstrapFewShot
    participant Eval as Evaluate
    participant Best as best_program

    User->>RSW: compile(student, trainset, valset)
    loop For each seed
        RSW->>RSW: prepare trainset_copy (shuffle if seed >= 0)
        RSW->>BFS: compile(student, teacher, trainset_copy)
        BFS-->>RSW: candidate program
        RSW->>Eval: evaluate(candidate)
        Eval-->>RSW: EvaluationResult(score, results)
        RSW->>RSW: append score, subscores, score_data
        alt score > max(scores)
            RSW->>Best: update best_program
        end
    end
    RSW->>Best: attach sorted candidate_programs
    RSW-->>User: best_program
```

---

## Component Interaction Details

### Interaction with `BootstrapFewShot`

For each randomized candidate, the optimizer constructs a fresh `BootstrapFewShot` instance, forwarding:

- `metric` and `metric_threshold` (for demo acceptance),
- `max_bootstrapped_demos` (set to the randomly sampled `size`),
- `max_labeled_demos`, `teacher_settings`, `max_rounds`, and `max_errors`.

This means the random search varies the *number of bootstrapped demos* and the *training-set ordering* across candidates, while keeping all other bootstrapping behavior identical. See [teleprompt_core_bootstrap](teleprompt_core_bootstrap.md) for details on how demos are actually bootstrapped.

### Interaction with `Evaluate`

Each candidate is scored via:

```python
evaluate = Evaluate(
    devset=self.valset,
    metric=self.metric,
    num_threads=self.num_threads,
    max_errors=effective_max_errors,
    display_table=False,
    display_progress=True,
)
result = evaluate(program)
score, subscores = result.score, [output[2] for output in result.results]
```

- `result.score` is the aggregate percentage score.
- `result.results` is a list of `(example, prediction, score)` tuples; the third element of each tuple is extracted as the per-example subscore.

See [evaluate_evaluation_engine](evaluate_evaluation_engine.md) for the full evaluation semantics.

### Error Budget Resolution

The effective error budget is resolved once at the start of `compile`:

```python
effective_max_errors = self.max_errors if self.max_errors is not None else dspy.settings.max_errors
```

This value is propagated to both the `BootstrapFewShot` instances and the `Evaluate` calls, ensuring consistent error handling across the whole search.

---

## Output: `candidate_programs`

The returned best program carries a `candidate_programs` attribute — a list of dictionaries, each containing:

| Key | Description |
|-----|-------------|
| `score` | Aggregate validation score for the candidate. |
| `subscores` | Per-example scores from the validation set. |
| `seed` | The seed that produced the candidate (identifies its strategy). |
| `program` | The candidate program object itself. |

The list is sorted in descending order of `score`, so `candidate_programs[0]` is the best candidate. This enables downstream analysis, ensembling, or manual selection.

---

## Usage Example

```python
import dspy
from dspy.teleprompt import BootstrapFewShotWithRandomSearch

# Define a metric
def metric(example, prediction, trace=None):
    return example.answer == prediction.answer

# Create the optimizer
optimizer = BootstrapFewShotWithRandomSearch(
    metric=metric,
    max_bootstrapped_demos=4,
    max_labeled_demos=16,
    num_candidate_programs=16,
    num_threads=8,
    stop_at_score=90.0,
)

# Compile the student program
compiled = optimizer.compile(
    student=my_program,
    trainset=trainset,
    valset=valset,
)

# Inspect all candidates
for candidate in compiled.candidate_programs:
    print(candidate["seed"], candidate["score"])
```

---

## Design Notes and Limitations

The source file contains several `TODO`/`FIXME` comments that document intended future improvements:

- **Budget-based control**: The optimizer currently controls the search via `num_candidate_programs` rather than an explicit `max_budget` / `max_teacher_budget` / `max_student_budget` scheme. A future design would cap the number of candidate programs based on a call budget.
- **Progressive elimination**: A planned enhancement is to drop the bottom third of candidates after 50 examples, another third after 100, and so on, leaving only a few finalists — potentially with error-bound-based early stopping.
- **Demo count vs. token limits**: The maximum number of demos should ideally be informed by the LM's tokenizer and `max_length`, rather than a fixed `max_bootstrapped_demos`.
- **Separate filtering vs. evaluation metrics**: The current implementation uses a single metric for both demo filtering and final evaluation; a future version may support distinct metrics.
- **`valset` default**: When `valset` is not provided, it defaults to `trainset`, which can lead to optimistic scores. Callers should generally supply a held-out validation set.

---

## Related Modules

- [teleprompt_core_base](teleprompt_core_base.md) — the `Teleprompter` base class.
- [teleprompt_core_bootstrap](teleprompt_core_bootstrap.md) — the underlying bootstrapping optimizer.
- [teleprompt_core_labeled_fewshot](teleprompt_core_labeled_fewshot.md) — the labels-only baseline.
- [teleprompt_core_ensemble](teleprompt_core_ensemble.md) — ensembling, often combined with candidate programs.
- [evaluate_evaluation_engine](evaluate_evaluation_engine.md) — the evaluation engine used to score candidates.
- [dsp_utils_settings](dsp_utils_settings.md) — global settings including `max_errors`.
