# predict_core_parallel

## Introduction

The `predict_core_parallel` module provides the **`Parallel`** primitive in DSPy — a lightweight wrapper that executes a module (or a list of modules) over a collection of inputs concurrently using a thread pool. It is the canonical way to fan out independent DSPy calls (e.g., running the same predictor over a dataset, or running several different modules over the same input) while preserving DSPy's thread-local configuration semantics.

The module is intentionally thin: it normalizes the many accepted input shapes into a uniform call signature, then delegates the actual concurrency, error handling, straggler timeouts, and progress reporting to the shared [`ParallelExecutor`](utils.md) utility.

---

## Purpose and Core Functionality

`Parallel` answers a single question: *"Given a list of `(module, example)` pairs, how do I run them all at once, safely, and collect the results?"*

Key responsibilities:

1. **Input normalization** — Accepts `Example`, `dict`, `list`, and `tuple` inputs and dispatches them to the module with the correct calling convention.
2. **Concurrency orchestration** — Uses a configurable thread pool (`num_threads`) to run pairs in parallel.
3. **Error tolerance** — Tracks failures up to a `max_errors` threshold; optionally returns the failed examples and their exceptions.
4. **Configuration propagation** — Relies on `ParallelExecutor` to copy thread-local DSPy settings (via `dspy.context`) into worker threads.
5. **Progress reporting** — Delegates a `tqdm` progress bar to the executor.

---

## Architecture

`Parallel` is a thin façade over `ParallelExecutor`. It owns the *policy* (how to interpret inputs, what to do with failures) while the executor owns the *mechanism* (threads, timeouts, cancellation).

```mermaid
graph TD
    User["User code"] -->|"Parallel(...)(exec_pairs)"| P["Parallel"]
    P -->|"forward()"| PE["ParallelExecutor"]
    PE -->|"ThreadPoolExecutor"| W1["Worker thread 1"]
    PE -->|"ThreadPoolExecutor"| W2["Worker thread 2"]
    PE -->|"ThreadPoolExecutor"| WN["Worker thread N"]
    W1 -->|"module(**inputs)"| M["DSPy Module / Predict"]
    W2 -->|"module(**inputs)"| M
    WN -->|"module(**inputs)"| M
    P -.->|"reads defaults"| S["Settings"]
    PE -.->|"copies thread-local overrides"| S
    P -.->|"reads inputs()"| E["Example"]
```

### Component Relationships

| Component | Role | Reference |
|-----------|------|-----------|
| `Parallel` | Public primitive; input normalization + result aggregation | this module |
| `ParallelExecutor` | Thread pool, error counting, straggler resubmission, progress bar | [utils.md](utils.md) |
| `Settings` | Global + thread-local configuration (`num_threads`, `max_errors`, `provide_traceback`) | [dsp_utils.md](dsp_utils.md) |
| `Example` | Input container; `inputs()` extracts the input fields | [primitives.md](primitives.md) |
| `Predict` / `Module` | The callable being parallelized | [predict_core_predict.md](predict_core_predict.md) |

---

## Class: `Parallel`

### Constructor

```python
Parallel(
    num_threads: int | None = None,
    max_errors: int | None = None,
    access_examples: bool = True,
    return_failed_examples: bool = False,
    provide_traceback: bool | None = None,
    disable_progress_bar: bool = False,
)
```

| Parameter | Default | Description |
|-----------|---------|-------------|
| `num_threads` | `settings.num_threads` | Number of worker threads. Falls back to the global setting when `None`. |
| `max_errors` | `settings.max_errors` | Maximum number of errors tolerated before the whole run is cancelled. |
| `access_examples` | `True` | If `True`, `Example` inputs are unpacked via `example.inputs()` and passed as keyword arguments. If `False`, the whole `Example` is passed positionally. |
| `return_failed_examples` | `False` | When `True`, `forward` returns a 3-tuple `(results, failed_examples, exceptions)` instead of just `results`. |
| `provide_traceback` | `settings.provide_traceback` | Whether to log full tracebacks on errors. |
| `disable_progress_bar` | `False` | Suppress the `tqdm` progress bar. |

The constructor also initializes internal state used for error tracking and cancellation:

- `error_count` — running count of failures.
- `error_lock` — a `threading.Lock` guarding `error_count`.
- `cancel_jobs` — a `threading.Event` used to signal cancellation.
- `failed_examples` / `exceptions` — accumulators populated when `return_failed_examples=True`.

> **Note:** `Parallel` does not subclass `Module`; it is a standalone callable. It is typically used *inside* a `Module`'s `forward` method.

### Method: `forward`

```python
def forward(self, exec_pairs: list[tuple[Any, Example]], num_threads: int | None = None) -> list[Any]
```

Executes each `(module, example)` pair concurrently and returns the list of results in the **same order** as the input pairs.

- `num_threads` may be overridden per-call; otherwise the instance value is used.
- Internally constructs a fresh `ParallelExecutor` for each call, forwarding `num_threads`, `max_errors`, `provide_traceback`, and `disable_progress_bar`.
- Defines a local `process_pair` closure that normalizes the input and invokes the module.
- Returns `results` or, when `return_failed_examples=True`, `(results, self.failed_examples, self.exceptions)`.

### Method: `__call__`

```python
def __call__(self, *args, **kwargs) -> Any
```

Convenience alias that forwards all arguments to `forward`, allowing `parallel(exec_pairs)` syntax.

---

## Input Normalization

The heart of `Parallel` is the `process_pair` closure, which maps each supported input type to a calling convention:

```mermaid
flowchart TD
    Start["process_pair((module, example))"] --> Check{"type(example)?"}
    Check -->|"Example"| Acc{"access_examples?"}
    Acc -->|"True"| Kw["module(**example.inputs())"]
    Acc -->|"False"| Pos["module(example)"]
    Check -->|"dict"| Dict["module(**example)"]
    Check -->|"list AND module is Parallel"| Nest["module(example)"]
    Check -->|"tuple"| Tup["module(*example)"]
    Check -->|"other"| Err["raise ValueError"]
```

| Input type | Condition | Invocation |
|------------|-----------|------------|
| `Example` | `access_examples=True` | `module(**example.inputs())` |
| `Example` | `access_examples=False` | `module(example)` |
| `dict` | — | `module(**example)` |
| `list` | `module` is itself a `Parallel` | `module(example)` (enables nested parallelism) |
| `tuple` | — | `module(*example)` |
| anything else | — | `ValueError` |

The special `list` case allows **nested `Parallel`** instances: when the module being run is another `Parallel`, a list input is passed through as a single argument so the inner `Parallel` can process it as its own `exec_pairs`.

---

## Execution Flow

```mermaid
sequenceDiagram
    participant U as User
    participant P as Parallel
    participant PE as ParallelExecutor
    participant T as ThreadPool
    participant M as Module

    U->>P: __call__(exec_pairs)
    P->>P: forward(exec_pairs)
    P->>PE: ParallelExecutor(...)
    P->>PE: execute(process_pair, exec_pairs)
    loop for each pair
        PE->>T: submit(worker, pair)
        T->>M: process_pair(pair)
        M-->>T: result
        T-->>PE: (index, result)
    end
    PE-->>P: results (ordered)
    alt return_failed_examples
        P-->>U: (results, failed_examples, exceptions)
    else
        P-->>U: results
    end
```

---

## Error Handling and Cancellation

Error handling is split between `Parallel` and `ParallelExecutor`:

- **`Parallel`** holds the `error_count`, `error_lock`, `cancel_jobs`, `failed_examples`, and `exceptions` attributes, but the actual incrementing and cancellation logic lives in `ParallelExecutor._wrap_function`.
- **`ParallelExecutor`** wraps the user function so that any exception increments `error_count` under a lock; once `error_count >= max_errors`, it sets `cancel_jobs`, causing remaining workers to short-circuit and the run to raise `"Execution cancelled due to errors or interruption."`.
- When `provide_traceback=True`, full tracebacks are logged; otherwise a concise error message is emitted.

> **Important:** Because `Parallel` creates a *new* `ParallelExecutor` on every `forward` call, the executor's internal `error_count` is reset per call. The `Parallel`-level counters are the ones intended for cross-call accumulation when `return_failed_examples=True`.

---

## Configuration Propagation

`Parallel` relies on DSPy's thread-local settings model (see [dsp_utils.md](dsp_utils.md)). When a `Parallel` is invoked inside a `dspy.context(...)` block, the `ParallelExecutor` copies the parent thread's overrides into each worker thread, so predictors running in parallel observe the same configuration (e.g., a specific `lm`). The `usage_tracker` override is deep-copied per thread so each thread tracks its own token usage independently.

```mermaid
graph LR
    Ctx["dspy.context(lm=...)"]
    Ctx -->|"thread_local_overrides"| Parent["Parent thread"]
    Parent -->|"copy overrides"| W1["Worker 1"]
    Parent -->|"copy overrides"| W2["Worker 2"]
    W1 -->|"deepcopy usage_tracker"| UT1["UsageTracker 1"]
    W2 -->|"deepcopy usage_tracker"| UT2["UsageTracker 2"]
```

---

## Usage Examples

### Running one predictor over many examples

```python
import dspy

predict = dspy.Predict("question -> answer")
parallel = dspy.Parallel(num_threads=8)

exec_pairs = [(predict, ex) for ex in examples]
results = parallel(exec_pairs)
```

### Collecting failures

```python
parallel = dspy.Parallel(return_failed_examples=True, provide_traceback=True)
results, failed, exceptions = parallel(exec_pairs)
```

### Running different modules over the same input

```python
exec_pairs = [
    (dspy.Predict("question -> answer"), example),
    (dspy.ChainOfThought("question -> answer"), example),
]
results = dspy.Parallel()(exec_pairs)
```

### Nested parallelism

```python
inner = dspy.Parallel(num_threads=4)
outer = dspy.Parallel(num_threads=2)
# A list input is passed through to the inner Parallel
results = outer([(inner, list_of_examples)])
```

---

## Related Modules

- [predict_core_predict.md](predict_core_predict.md) — `Predict` and `Parameter`, the most common modules run inside `Parallel`.
- [predict_core_chain_of_thought.md](predict_core_chain_of_thought.md) — `ChainOfThought`, frequently parallelized.
- [utils.md](utils.md) — `ParallelExecutor`, the underlying concurrency engine.
- [dsp_utils.md](dsp_utils.md) — `Settings`, thread-local configuration and `dspy.context`.
- [primitives.md](primitives.md) — `Example`, `Module`, and `Prediction` primitives.
