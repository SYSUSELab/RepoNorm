# Adapters Implementations

## Introduction

The **Adapters Implementations** module provides the concrete adapter classes that bridge DSPy's structured
signatures and the raw message-based interface of Language Models (LMs). An adapter is responsible for two
fundamental transformations:

1. **Formatting** — converting a DSPy `Signature`, few-shot demonstrations, and input values into a list of
   multiturn chat messages that an LM can consume.
2. **Parsing** — converting the LM's raw text (or tool-call) response back into a dictionary of typed output
   fields.

This module contains the abstract base class `Adapter` and five concrete implementations: `ChatAdapter`,
`JSONAdapter`, `XMLAdapter`, `TwoStepAdapter`, and `BAMLAdapter`. Together they allow DSPy programs to target
different LM providers and output-format preferences while keeping the rest of the framework agnostic to the
wire format.

> For the custom DSPy types used inside signatures (e.g. `Image`, `History`, `Tool`, `ToolCalls`), see
> [adapters_types.md](adapters_types.md). For the LM client that adapters ultimately call, see
> [clients_core.md](clients_core.md).

---

## Architecture Overview

The adapter hierarchy is rooted in the abstract `Adapter` base class. `ChatAdapter` is the primary concrete
implementation, and the other adapters either extend it (`JSONAdapter`, `XMLAdapter`, `BAMLAdapter`) or
implement the base contract independently (`TwoStepAdapter`).

```mermaid
classDiagram
    class Adapter {
        +callbacks: list[BaseCallback]
        +use_native_function_calling: bool
        +__call__(lm, lm_kwargs, signature, demos, inputs)
        +acall(lm, lm_kwargs, signature, demos, inputs)
        +format(signature, demos, inputs)
        +parse(signature, completion)
        +format_field_description(signature)
        +format_field_structure(signature)
        +format_task_description(signature)
        +format_user_message_content(...)
        +format_assistant_message_content(...)
        +format_demos(signature, demos)
        +format_conversation_history(...)
    }

    class ChatAdapter {
        +format_field_with_value(fields_with_values)
        +user_message_output_requirements(signature)
        +format_finetune_data(...)
    }

    class JSONAdapter {
        +use_native_function_calling = True
        +format_field_with_value(fields_with_values, role)
    }

    class XMLAdapter {
        +field_pattern: re.Pattern
    }

    class BAMLAdapter {
        +format_field_structure(signature)
    }

    class TwoStepAdapter {
        +extraction_model: LM
        +format(signature, demos, inputs)
        +parse(signature, completion)
    }

    Adapter <|-- ChatAdapter
    Adapter <|-- TwoStepAdapter
    ChatAdapter <|-- JSONAdapter
    ChatAdapter <|-- XMLAdapter
    JSONAdapter <|-- BAMLAdapter
```

### Key Design Principles

- **Template Method pattern**: `Adapter.__call__` / `acall` define the fixed algorithm
  (`preprocess → format → LM call → postprocess`), while subclasses override the `format_*` and `parse`
  hooks to customize behavior.
- **Callback decoration**: `Adapter.__init_subclass__` automatically wraps every subclass's `format` and
  `parse` methods with the `with_callbacks` decorator, so all adapters emit start/end callback events
  without any per-class boilerplate.
- **Graceful fallback**: `ChatAdapter` falls back to `JSONAdapter` on parse failures, and `JSONAdapter`
  falls back from structured-output mode to plain JSON mode when the provider or schema is incompatible.

---

## The Base `Adapter` Class

`Adapter` (in `dspy/adapters/base.py`) defines the contract and the shared call pipeline.

### Call Pipeline

```mermaid
flowchart TD
    A["__call__ / acall"] --> B["_call_preprocess"]
    B --> C["format (subclass hook)"]
    C --> D["lm(messages=..., **lm_kwargs)"]
    D --> E["_call_postprocess"]
    E --> F["parse (subclass hook)"]
    F --> G["list[dict] of output fields"]

    B -.->|native function calling| B1["Inject tools into lm_kwargs,<br/>strip Tool/ToolCalls fields"]
    E -.->|tool calls present| E1["Build ToolCalls from<br/>LM tool_calls"]
```

### Responsibilities

| Method | Purpose |
| --- | --- |
| `__call__` / `acall` | Orchestrates the full sync/async pipeline. |
| `_call_preprocess` | Handles native function calling: injects `tools` into `lm_kwargs` and removes the `Tool`/`ToolCalls` fields from the signature sent to the LM. |
| `_call_postprocess` | Parses each LM output, fills missing fields with `None`, attaches `logprobs`, and reconstructs `ToolCalls` from native tool-call responses. |
| `format` | Builds the system message, few-shot demos, conversation history, and current user message. |
| `format_field_description` | *(abstract)* Describes input/output fields for the system message. |
| `format_field_structure` | *(abstract)* Describes the required output structure. |
| `format_task_description` | *(abstract)* Wraps `signature.instructions`. |
| `format_user_message_content` | *(abstract)* Renders input values into a user message. |
| `format_assistant_message_content` | *(abstract)* Renders output values into an assistant message. |
| `format_demos` | Splits demos into complete/incomplete and renders them as multiturn messages. |
| `format_conversation_history` | Renders a `History` field into multiturn messages. |
| `parse` | *(abstract)* Parses the LM completion into output fields. |

### Signature Introspection Helpers

The base class provides helpers to detect special fields in a signature:

- `_get_history_field_name` — finds an input field annotated as `History`.
- `_get_tool_call_input_field_name` — finds an input field annotated as `Tool` or `list[Tool]`.
- `_get_tool_call_output_field_name` — finds an output field annotated as `ToolCalls`.

These drive both native function calling and conversation-history formatting.

### Message Structure

`format` produces messages following the recommended structure:

```
[
    {"role": "system", "content": <field description + structure + task>},
    # few-shot demos (user/assistant pairs)
    # conversation history (user/assistant pairs)
    {"role": "user", "content": <current input>},
]
```

After assembly, `split_message_content_for_custom_types` (from
[adapter_types.md](adapter_types.md)) splits user content into content blocks so custom types like
`dspy.Image` are rendered as proper multimodal blocks.

---

## Concrete Adapters

### `ChatAdapter`

The default adapter. It uses explicit section markers to delimit fields.

- **Field markers**: `[[ ## field_name ## ]]` for both input and output fields.
- **Completion marker**: an arbitrary `[[ ## completed ## ]]` section terminates the output.
- **Parsing**: scans lines for the header pattern (`field_header_pattern`), collects section content, and
  casts each value via `parse_value`.
- **Fallback**: on any exception (except `ContextWindowExceededError`), it retries with `JSONAdapter`.
- **Finetune support**: `format_finetune_data` produces OpenAI-style `{"messages": [...]}` training data.

`FieldInfoWithName` is a small `NamedTuple` pairing a field name with its `FieldInfo`, used throughout the
formatting helpers.

### `JSONAdapter`

Extends `ChatAdapter` and enables **native function calling by default**.

- **Structured Outputs**: attempts to build a Pydantic model (`_get_structured_outputs_response_format`)
  from the signature's output fields and passes it as `response_format`. The generated JSON schema is
  post-processed to enforce `required` and `additionalProperties: false` recursively.
- **Fallbacks**:
  - If the provider does not support `response_format`, it delegates to the plain chat path.
  - If any output field is an open-ended mapping (`dict[...]`), structured outputs are skipped.
  - If `ToolCalls` is an output field and native function calling is disabled, it uses `json_object` mode.
  - On any structured-output failure, it logs a warning and falls back to `{"type": "json_object"}`.
- **Parsing**: extracts the first balanced JSON object using a recursive regex, repairs it with
  `json_repair`, filters to known output fields, and casts each value.
- **`format_field_with_value`**: renders user-role fields with `[[ ## name ## ]]` markers and
  assistant-role fields as indented JSON.

### `XMLAdapter`

Extends `ChatAdapter` and renders fields as XML tags.

- **Formatting**: each field becomes `<field_name>\n{value}\n</field_name>`.
- **Parsing**: uses a regex (`<name>...</name>`) to extract field values, then casts them via
  `parse_value`.
- **Output requirements**: instructs the LM to wrap outputs in XML tags and end with `<completed>`.

### `TwoStepAdapter`

A specialized adapter for **reasoning models** that struggle with structured output.

- **Two-stage design**:
  1. The **main LM** receives a natural, unstructured prompt (no field markers) and produces free-form text.
  2. A smaller **extraction model** (`extraction_model`, an `LM` instance) uses a `ChatAdapter` to extract
     structured fields from that text.
- **Extractor signature**: `_create_extractor_signature` builds a `text -> {original output fields}`
  signature on the fly.
- **Limitation**: the extractor signature is created dynamically and invoked without demos, so it cannot be
  optimized/learned (noted in the source as a TODO).
- Implements both `parse` (sync) and `acall` (async) with the same two-stage logic.

### `BAMLAdapter`

Extends `JSONAdapter` and improves rendering of **complex/nested Pydantic models**, inspired by the
[BAML](https://github.com/BoundaryML/baml) project.

- **Simplified schema rendering**: `_build_simplified_schema` and `_render_type_str` recursively render
  Pydantic models into a compact, human-readable schema with `#` comments for field descriptions and
  aliases. This is more token-efficient and easier for smaller LMs than raw JSON schema.
- **Circular reference protection**: uses a `_seen` set and a max recursion depth.
- **Input rendering**: Pydantic input instances are rendered as clean indented JSON via
  `model_dump_json`.
- **Overrides**: `format_field_description`, `format_field_structure`, `format_task_description`, and
  `format_user_message_content`.

---

## Data Flow

The following diagram shows how data flows through an adapter during a single LM call.

```mermaid
sequenceDiagram
    participant P as Predict / Module
    participant A as Adapter
    participant U as adapters.utils
    participant LM as LM Client

    P->>A: __call__(lm, lm_kwargs, signature, demos, inputs)
    A->>A: _call_preprocess (native function calling)
    A->>A: format(signature, demos, inputs)
    A->>U: format_field_value / translate_field_type
    U-->>A: formatted strings
    A->>A: split_message_content_for_custom_types
    A->>LM: lm(messages=..., **lm_kwargs)
    LM-->>A: raw completions (text / tool_calls / logprobs)
    A->>A: _call_postprocess
    A->>U: parse_value
    U-->>A: typed field values
    A-->>P: list[dict] of output fields
```

---

## Dependencies

```mermaid
flowchart LR
    subgraph adapters_implementations
        Base[Adapter]
        Chat[ChatAdapter]
        JSON[JSONAdapter]
        XML[XMLAdapter]
        TwoStep[TwoStepAdapter]
        BAML[BAMLAdapter]
    end

    subgraph adapter_types
        Types[Type / Image / History / Tool / ToolCalls]
    end

    subgraph clients_core
        LM[LM / BaseLM]
    end

    subgraph signatures
        Sig[Signature / SignatureMeta]
    end

    subgraph utils
        Callback[with_callbacks / BaseCallback]
        Exc[AdapterParseError]
    end

    Chat --> Base
    JSON --> Chat
    XML --> Chat
    BAML --> JSON
    TwoStep --> Base
    TwoStep --> Chat

    Base --> Types
    Base --> Sig
    Base --> Callback
    Chat --> Exc
    JSON --> Exc
    XML --> Exc
    TwoStep --> LM
    Base --> LM
```

### External Libraries

| Library | Usage |
| --- | --- |
| `litellm` | Provider capability detection (`supports_function_calling`, `get_supported_openai_params`), `ContextWindowExceededError`. |
| `json_repair` | Lenient JSON parsing of LM responses. |
| `pydantic` | Building structured-output models and validating parsed values. |
| `regex` | Recursive regex for extracting balanced JSON objects. |

---

## Adapter Selection & Fallback Behavior

```mermaid
flowchart TD
    Start[Adapter call] --> Chat{Which adapter?}
    Chat -->|ChatAdapter| TryChat[Try chat format]
    TryChat -->|success| Done[Return fields]
    TryChat -->|ContextWindowExceeded| Raise[Re-raise]
    TryChat -->|other error| FallbackJSON[Fall back to JSONAdapter]

    Chat -->|JSONAdapter| TryStruct[Try structured outputs]
    TryStruct -->|success| Done
    TryStruct -->|unsupported / error| JSONMode[Use json_object mode]
    JSONMode --> Done

    Chat -->|XMLAdapter| TryXML[Parse XML tags]
    TryXML --> Done

    Chat -->|TwoStepAdapter| Step1[Main LM free-form] --> Step2[Extraction LM + ChatAdapter] --> Done

    Chat -->|BAMLAdapter| TryBAML[Simplified Pydantic schema] --> Done
```

---

## Error Handling

All adapters raise `AdapterParseError` (from [utils.md](utils.md)) when the LM response cannot be parsed
into the expected output fields. The exception carries:

- `adapter_name` — which adapter failed.
- `signature` — the expected signature.
- `lm_response` — the raw LM output.
- `parsed_result` — the fields that were successfully parsed (if any).

`ChatAdapter` additionally catches generic exceptions and retries with `JSONAdapter`, except for
`ContextWindowExceededError` (which would not benefit from a retry).

---

## Related Modules

- [adapter_types.md](adapter_types.md) — Custom DSPy types (`Image`, `History`, `Tool`, `ToolCalls`) and
  `split_message_content_for_custom_types`.
- [clients_core.md](clients_core.md) — The `LM` / `BaseLM` clients that adapters invoke.
- [signatures.md](signatures.md) — `Signature` and `SignatureMeta`, the structured I/O contracts.
- [utils.md](utils.md) — `AdapterParseError`, `with_callbacks`, and other shared utilities.
- [predict_core.md](predict_core.md) — `Predict` and modules that drive adapter calls.
