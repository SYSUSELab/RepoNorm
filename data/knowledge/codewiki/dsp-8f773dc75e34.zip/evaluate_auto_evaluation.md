# Evaluate Auto Evaluation

## Introduction

The `evaluate_auto_evaluation` module (`dspy/evaluate/auto_evaluation.py`) provides a collection of **LLM-as-a-judge metrics** for automatically evaluating the quality of a DSPy program's responses. Unlike traditional exact-match metrics, these metrics use a language model (via `ChainOfThought`) to reason about the semantic relationship between a system's response and reference material (ground truth or retrieved context).

The module exposes two ready-to-use metric modules:

- **`SemanticF1`** — computes an F1 score over semantic recall and precision against a ground truth response.
- **`CompleteAndGrounded`** — computes an F1 score combining answer completeness (vs. ground truth) and groundedness (vs. retrieved context).

These metrics are designed to be passed directly as the `metric` argument to the [`Evaluate`](evaluate_evaluation_engine.md) engine, or used as reward/feedback functions in optimizers.

---

## Architecture Overview

The module is built on top of three core DSPy abstractions:

1. **`Signature`** — declaratively defines the inputs/outputs of each judging task.
2. **`ChainOfThought`** — wraps a signature to elicit step-by-step reasoning before producing the final score.
3. **`Module`** — the base class for the two composite metric modules (`SemanticF1`, `CompleteAndGrounded`).

```mermaid
graph TD
    subgraph "evaluate_auto_evaluation"
        SF1[SemanticF1]
        CAG[CompleteAndGrounded]
        SRP[SemanticRecallPrecision]
        DSRP[DecompositionalSemanticRecallPrecision]
        AC[AnswerCompleteness]
        AG[AnswerGroundedness]
        F1[f1_score]
    end

    subgraph "predict_core"
        CoT[ChainOfThought]
    end

    subgraph "signatures"
        Sig[Signature]
        IF[InputField]
        OF[OutputField]
    end

    subgraph "primitives"
        Mod[Module]
    end

    SF1 -->|extends| Mod
    CAG -->|extends| Mod
    SF1 -->|uses| CoT
    CAG -->|uses| CoT
    SF1 -->|uses| F1
    CAG -->|uses| F1

    CoT -->|wraps| SRP
    CoT -->|wraps| DSRP
    CoT -->|wraps| AC
    CoT -->|wraps| AG

    SRP -->|extends| Sig
    DSRP -->|extends| Sig
    AC -->|extends| Sig
    AG -->|extends| Sig

    Sig -->|uses| IF
    Sig -->|uses| OF
```

---

## Component Reference

### Signatures

Signatures define the structured judging tasks. Each is a subclass of [`Signature`](signatures.md) with typed `InputField`s and `OutputField`s.

#### `SemanticRecallPrecision`

Compares a system's response to the ground truth to compute recall and precision.

| Field | Type | Direction | Description |
|-------|------|-----------|-------------|
| `question` | `str` | Input | The original question |
| `ground_truth` | `str` | Input | The reference answer |
| `system_response` | `str` | Input | The system's answer |
| `recall` | `float` | Output | Fraction (out of 1.0) of ground truth covered by the system response |
| `precision` | `float` | Output | Fraction (out of 1.0) of system response covered by the ground truth |

#### `DecompositionalSemanticRecallPrecision`

An extended variant that first enumerates key ideas in each response and discusses their overlap before reporting recall and precision. This "decompositional" approach improves reliability by forcing explicit reasoning.

| Field | Type | Direction | Description |
|-------|------|-----------|-------------|
| `question` | `str` | Input | The original question |
| `ground_truth` | `str` | Input | The reference answer |
| `system_response` | `str` | Input | The system's answer |
| `ground_truth_key_ideas` | `str` | Output | Enumeration of key ideas in the ground truth |
| `system_response_key_ideas` | `str` | Output | Enumeration of key ideas in the system response |
| `discussion` | `str` | Output | Discussion of the overlap between ground truth and system response |
| `recall` | `float` | Output | Fraction (out of 1.0) of ground truth covered |
| `precision` | `float` | Output | Fraction (out of 1.0) of system response covered |

#### `AnswerCompleteness`

Estimates how completely a system response covers the ground truth.

| Field | Type | Direction | Description |
|-------|------|-----------|-------------|
| `question` | `str` | Input | The original question |
| `ground_truth` | `str` | Input | The reference answer |
| `system_response` | `str` | Input | The system's answer |
| `ground_truth_key_ideas` | `str` | Output | Enumeration of key ideas in the ground truth |
| `system_response_key_ideas` | `str` | Output | Enumeration of key ideas in the system response |
| `discussion` | `str` | Output | Discussion of the overlap |
| `completeness` | `float` | Output | Fraction (out of 1.0) of ground truth covered |

#### `AnswerGroundedness`

Estimates how well a system response is supported by retrieved context (i.e., whether claims are grounded in real documents rather than hallucinated).

| Field | Type | Direction | Description |
|-------|------|-----------|-------------|
| `question` | `str` | Input | The original question |
| `retrieved_context` | `str` | Input | The retrieved documents/context |
| `system_response` | `str` | Input | The system's answer |
| `system_response_claims` | `str` | Output | Enumeration of non-trivial or check-worthy claims |
| `discussion` | `str` | Output | Discussion of how supported the claims are |
| `groundedness` | `float` | Output | Fraction (out of 1.0) of system response supported by context |

### Helper Function

#### `f1_score(precision, recall)`

Computes the harmonic mean of precision and recall, with both inputs clamped to the `[0.0, 1.0]` range.

```python
def f1_score(precision, recall):
    precision, recall = max(0.0, min(1.0, precision)), max(0.0, min(1.0, recall))
    return 0.0 if precision + recall == 0 else 2 * (precision * recall) / (precision + recall)
```

- **Clamping**: Both values are clamped to `[0.0, 1.0]` to guard against out-of-range LLM outputs.
- **Zero guard**: Returns `0.0` when `precision + recall == 0` to avoid division by zero.

### Metric Modules

#### `SemanticF1`

A [`Module`](primitives.md) that computes a semantic F1 score between a system response and the ground truth.

```python
class SemanticF1(Module):
    def __init__(self, threshold=0.66, decompositional=False):
        self.threshold = threshold
        if decompositional:
            self.module = ChainOfThought(DecompositionalSemanticRecallPrecision)
        else:
            self.module = ChainOfThought(SemanticRecallPrecision)

    def forward(self, example, pred, trace=None):
        scores = self.module(question=example.question, ground_truth=example.response, system_response=pred.response)
        score = f1_score(scores.precision, scores.recall)
        return score if trace is None else score >= self.threshold
```

**Constructor parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `threshold` | `0.66` | Score threshold used when the metric is invoked in "trace" mode (e.g., during bootstrapping) |
| `decompositional` | `False` | If `True`, uses `DecompositionalSemanticRecallPrecision` for more explicit reasoning |

**`forward(example, pred, trace=None)` behavior:**

- Calls the underlying `ChainOfThought` module with `question`, `ground_truth` (from `example.response`), and `system_response` (from `pred.response`).
- Computes `f1_score(precision, recall)`.
- Returns the raw float score when `trace is None` (normal evaluation).
- Returns a boolean (`score >= threshold`) when `trace` is provided (used by optimizers that need a pass/fail signal).

#### `CompleteAndGrounded`

A [`Module`](primitives.md) that combines completeness and groundedness into a single F1 score.

```python
class CompleteAndGrounded(Module):
    def __init__(self, threshold=0.66):
        self.threshold = threshold
        self.completeness_module = ChainOfThought(AnswerCompleteness)
        self.groundedness_module = ChainOfThought(AnswerGroundedness)

    def forward(self, example, pred, trace=None):
        completeness = self.completeness_module(question=example.question, ground_truth=example.response, system_response=pred.response)
        groundedness = self.groundedness_module(question=example.question, retrieved_context=pred.context, system_response=pred.response)
        score = f1_score(groundedness.groundedness, completeness.completeness)
        return score if trace is None else score >= self.threshold
```

**Constructor parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `threshold` | `0.66` | Score threshold used in "trace" mode |

**`forward(example, pred, trace=None)` behavior:**

- Runs the completeness judge against `example.response` (ground truth).
- Runs the groundedness judge against `pred.context` (retrieved context).
- Combines the two scores via `f1_score`.
- Returns the raw float score when `trace is None`, otherwise a boolean pass/fail.

> **Note:** `CompleteAndGrounded` requires the prediction to expose a `context` attribute (retrieved context). This makes it suitable for retrieval-augmented (RAG) programs.

---

## Data Flow

The following diagram illustrates how a metric module is invoked during evaluation.

```mermaid
sequenceDiagram
    participant Eval as Evaluate
    participant Prog as Program
    participant Metric as SemanticF1 / CompleteAndGrounded
    participant CoT as ChainOfThought
    participant LM as Language Model

    Eval->>Prog: program(**example.inputs())
    Prog-->>Eval: prediction
    Eval->>Metric: metric(example, prediction)
    Metric->>CoT: module(question, ground_truth, system_response, ...)
    CoT->>LM: prompt (with reasoning step)
    LM-->>CoT: reasoning + structured outputs
    CoT-->>Metric: scores (recall/precision or completeness/groundedness)
    Metric->>Metric: f1_score(...)
    Metric-->>Eval: float score (or bool if trace)
```

### Internal Process Flow

```mermaid
flowchart TD
    Start([forward called]) --> Check{decompositional?}
    Check -->|Yes| DSRP[DecompositionalSemanticRecallPrecision]
    Check -->|No| SRP[SemanticRecallPrecision]
    DSRP --> CoT1[ChainOfThought reasoning]
    SRP --> CoT1
    CoT1 --> Extract[Extract precision & recall]
    Extract --> F1[f1_score]
    F1 --> Trace{trace is None?}
    Trace -->|Yes| ReturnScore[Return float score]
    Trace -->|No| ReturnBool[Return score >= threshold]
```

---

## Integration with the Evaluation Engine

These metrics are consumed by the [`Evaluate`](evaluate_evaluation_engine.md) class, which orchestrates parallel evaluation over a devset and aggregates scores.

```mermaid
graph LR
    Devset[devset: list of Examples] --> Eval[Evaluate]
    Eval -->|for each example| Prog[Program]
    Prog --> Pred[Prediction]
    Pred --> Metric[SemanticF1 / CompleteAndGrounded]
    Metric --> Score[float score]
    Score --> Result[EvaluationResult]
```

**Example usage:**

```python
import dspy
from dspy.evaluate import Evaluate
from dspy.evaluate.auto_evaluation import SemanticF1

metric = SemanticF1(threshold=0.66)
evaluator = Evaluate(devset=devset, metric=metric, num_threads=8, display_progress=True)
result = evaluator(program)
print(result.score)  # e.g., 67.30
```

---

## Dependencies

| Dependency | Module | Purpose |
|------------|--------|---------|
| `ChainOfThought` | [`predict_core`](predict_core.md) | Wraps signatures to elicit step-by-step reasoning before scoring |
| `Module` | [`primitives`](primitives.md) | Base class for `SemanticF1` and `CompleteAndGrounded` |
| `Signature`, `InputField`, `OutputField` | [`signatures`](signatures.md) | Declarative definition of judging tasks |
| `Evaluate`, `EvaluationResult` | [`evaluate_evaluation_engine`](evaluate_evaluation_engine.md) | Consumer of these metrics |

---

## Design Notes

- **LLM-as-a-judge pattern**: All metrics delegate the actual scoring to a language model through `ChainOfThought`, which prepends a reasoning step. This makes the scores more robust than direct numeric prompting.
- **Trace mode dual return type**: The `trace` parameter toggles between returning a continuous score (for evaluation) and a boolean (for optimizers such as bootstrapping that need a binary signal). This mirrors the metric contract expected by DSPy optimizers.
- **Decompositional reasoning**: The `decompositional=True` option in `SemanticF1` forces the model to enumerate key ideas and discuss overlap before scoring, trading extra tokens for higher reliability.
- **Clamped F1**: `f1_score` defensively clamps inputs to `[0.0, 1.0]`, protecting against LLM outputs that fall outside the expected range.
- **Groundedness requires context**: `CompleteAndGrounded` assumes `pred.context` exists, so it is intended for RAG-style programs.

---

## Related Documentation

- [Evaluate Evaluation Engine](evaluate_evaluation_engine.md) — the `Evaluate` class and `EvaluationResult`
- [Predict Core](predict_core.md) — `ChainOfThought`, `Predict`, and related modules
- [Signatures](signatures.md) — `Signature`, `InputField`, `OutputField`
- [Primitives](primitives.md) — `Module`, `Prediction`, `Example`
