# clients_core_cache

## Introduction

The `clients_core_cache` module provides DSPy's two-level caching infrastructure for language model (LM) requests. It is centered around the `Cache` class and the `request_cache` decorator, both defined in `dspy/clients/cache.py`.

The module's primary purpose is to **avoid redundant and expensive LM calls** by storing and reusing responses. It achieves this through:

1. **A two-tier storage strategy** — a fast in-memory LRU cache backed by a persistent on-disk cache.
2. **Deterministic cache keys** — derived by hashing a normalized, JSON-serializable representation of the request.
3. **A transparent decorator** — `request_cache`, which wraps completion functions (sync and async) so caching is applied automatically without changing call sites.

This module is a foundational dependency of the [`clients_core_lm`](clients_core_lm.md) module, where `LM.forward` and `LM.aforward` wrap LiteLLM completion functions with `request_cache`.

---

## Architecture Overview

The cache subsystem sits between the LM client layer and the underlying provider calls. When an LM request is issued, the cache is consulted first; only on a miss is the real provider invoked.

```mermaid
graph TD
    subgraph "LM Layer"
        LM["LM (clients_core_lm)"]
        BaseLM["BaseLM (clients_core_base_lm)"]
    end

    subgraph "clients_core_cache"
        RC["request_cache decorator"]
        Cache["Cache"]
        MemCache["memory_cache<br/>(cachetools.LRUCache)"]
        DiskCache["disk_cache<br/>(diskcache.FanoutCache)"]
    end

    subgraph "External"
        LiteLLM["LiteLLM completion fn"]
        Disk["Disk storage"]
    end

    LM -->|wraps completion fn| RC
    RC -->|get / put| Cache
    Cache --> MemCache
    Cache --> DiskCache
    DiskCache --> Disk
    RC -->|on miss| LiteLLM
    BaseLM -.->|inherited by| LM
```

### Two-Level Cache Strategy

The `Cache` class implements a layered lookup that prioritizes speed while retaining persistence:

```mermaid
flowchart TD
    Start([Request]) --> KeyGen["Generate cache key<br/>(sha256 of normalized JSON)"]
    KeyGen --> MemCheck{"In memory_cache?"}
    MemCheck -->|Yes| MemHit["Return deep-copied value<br/>(clear usage)"]
    MemCheck -->|No| DiskCheck{"In disk_cache?"}
    DiskCheck -->|Yes| Promote["Read from disk,<br/>promote into memory_cache"]
    Promote --> MemHit
    DiskCheck -->|No| Miss["Return None (cache miss)"]
```

| Level | Backend | Purpose | Configurable via |
|-------|---------|---------|------------------|
| 1 (fastest) | `cachetools.LRUCache` | In-process, low-latency lookups | `enable_memory_cache`, `memory_max_entries` |
| 2 (persistent) | `diskcache.FanoutCache` | Cross-process, survives restarts | `enable_disk_cache`, `disk_cache_dir`, `disk_size_limit_bytes` |

---

## Core Components

### `Cache`

The `Cache` class is the central storage abstraction. It is instantiated once and exposed globally as `dspy.cache`.

#### Constructor

```python
Cache(
    enable_disk_cache: bool,
    enable_memory_cache: bool,
    disk_cache_dir: str,
    disk_size_limit_bytes: int | None = 1024 * 1024 * 10,  # 10 MB
    memory_max_entries: int | None = 1000000,
)
```

- When `enable_memory_cache` is `True`, an `LRUCache` is created; otherwise a plain `dict` is used (effectively disabled).
- When `enable_disk_cache` is `True`, a `FanoutCache` with 16 shards and a 10-second timeout is created; otherwise a plain `dict` is used.
- A `threading.RLock` (`self._lock`) guards all memory-cache mutations, making the cache safe for concurrent access.

#### Key Methods

| Method | Description |
|--------|-------------|
| `__contains__(key)` | Checks membership across both memory and disk caches. |
| `cache_key(request, ignored_args_for_cache_key)` | Produces a deterministic SHA-256 hash of the normalized request. |
| `get(request, ignored_args_for_cache_key)` | Retrieves a cached value, promoting disk hits into memory. Returns `None` on miss. |
| `put(request, value, ignored_args_for_cache_key, enable_memory_cache)` | Stores a value in memory and/or disk. |
| `reset_memory_cache()` | Clears the in-memory cache. |
| `save_memory_cache(filepath)` | Serializes the memory cache to disk via `cloudpickle`. |
| `load_memory_cache(filepath)` | Restores the memory cache from a `cloudpickle` file. |

#### Cache Key Generation

`cache_key` normalizes the request dictionary before hashing so that semantically equivalent requests map to the same key. The `transform_value` helper handles JSON-incompatible types:

```mermaid
flowchart LR
    Req["request dict"] --> Filter["Drop ignored args<br/>(api_key, api_base, base_url)"]
    Filter --> Transform["transform_value()"]
    Transform --> PydanticType["pydantic class → model_json_schema()"]
    Transform --> PydanticInst["pydantic instance → model_dump(mode='json')"]
    Transform --> Callable["callable → source code or name"]
    Transform --> Nested["dict → recurse"]
    PydanticType --> Serialize["ujson.dumps(sort_keys=True)"]
    PydanticInst --> Serialize
    Callable --> Serialize
    Nested --> Serialize
    Serialize --> Hash["sha256(...).hexdigest()"]
```

Key behaviors:
- **Pydantic models** (classes and instances) are converted to JSON-serializable forms.
- **Callables** are represented by their source code (via `inspect.getsource`) when available, falling back to their name.
- **Ignored arguments** (defaulting to `api_key`, `api_base`, `base_url`) are excluded so that credential changes do not invalidate the cache.
- `ujson.dumps(..., sort_keys=True)` ensures key ordering does not affect the hash.

#### Cache Hit Semantics

On a `get` hit, the value is **deep-copied** before being returned to prevent callers from mutating the stored object. Additionally, if the response has a `usage` attribute, it is reset to `{}` because no actual LM call was made (so token accounting should not be attributed to a cache hit).

### `request_cache` Decorator

The `request_cache` decorator applies caching transparently to a function based on a designated request argument.

```python
request_cache(
    cache_arg_name: str | None = None,
    ignored_args_for_cache_key: list[str] | None = None,
    enable_memory_cache: bool = True,
    *,
    maxsize: int | None = None,  # deprecated / no-op
)
```

| Parameter | Description |
|-----------|-------------|
| `cache_arg_name` | Name of the argument holding the request. If `None`, the entire `kwargs` (plus positional args) form the request. |
| `ignored_args_for_cache_key` | Arguments excluded from the cache key. Defaults to `["api_key", "api_base", "base_url"]`. |
| `enable_memory_cache` | Whether new results are written to the in-memory cache at call time. |
| `maxsize` | **Deprecated** — retained for backward compatibility; emits a warning and has no effect. |

#### Decorator Flow

The decorator inspects whether the wrapped function is a coroutine and returns either a sync or async wrapper. Both wrappers follow the same logic:

```mermaid
sequenceDiagram
    participant Caller
    participant Wrapper as sync/async_wrapper
    participant Cache as dspy.cache
    participant Fn as wrapped function

    Caller->>Wrapper: call(*args, **kwargs)
    Wrapper->>Wrapper: process_request() → modified_request
    Wrapper->>Cache: get(modified_request, ignored_args)
    alt Cache hit
        Cache-->>Wrapper: cached_result
        Wrapper-->>Caller: cached_result
    else Cache miss
        Wrapper->>Wrapper: deep-copy original_request
        Wrapper->>Fn: fn(*args, **kwargs)
        Fn-->>Wrapper: result
        Wrapper->>Cache: put(original_request, result, ...)
        Wrapper-->>Caller: result
    end
```

Key implementation details:
- **Function identity in the key**: `process_request` injects `_fn_identifier` (`{module}.{qualname}`) into the request so that different functions never collide in the cache.
- **Deep copies**: The request is deep-copied because LiteLLM sometimes mutates `kwargs` in place. A separate copy (`original_request`) is preserved before the call so the stored key matches the lookup key.
- **Global cache access**: The wrapper resolves `dspy.cache` at call time (via `import dspy`), allowing the cache to be reconfigured without re-decorating functions.

---

## Integration with the LM Layer

The [`clients_core_lm`](clients_core_lm.md) module is the primary consumer of this cache. In `LM._get_cached_completion_fn`, the LiteLLM completion function is wrapped conditionally:

```mermaid
flowchart TD
    Start["LM.forward / aforward"] --> Pop["Pop cache & cache_in_memory kwargs"]
    Pop --> Choose{"cache enabled?"}
    Choose -->|Yes + memory| WrapMem["request_cache(cache_arg_name='request',<br/>enable_memory_cache=True)"]
    Choose -->|Yes, no memory| WrapDisk["request_cache(cache_arg_name='request',<br/>enable_memory_cache=False)"]
    Choose -->|No| NoWrap["No wrapping"]
    WrapMem --> Call["completion(request=..., num_retries=...)"]
    WrapDisk --> Call
    NoWrap --> Call
    Call --> Result["LM response"]
```

- `cache_arg_name="request"` means only the `request` dict (model, messages, kwargs) participates in the cache key.
- `ignored_args_for_cache_key` is set to `["api_key", "api_base", "base_url"]`.
- When caching is disabled, LiteLLM is instructed with `{"no-cache": True, "no-store": True}`.

The `LM` class also exposes `cache` and `cache_in_memory` flags (see [`clients_core_lm`](clients_core_lm.md)), which flow into this wrapping logic. Note that `cache_in_memory` is documented as deprecated in favor of the global `dspy.cache` configuration.

---

## Dependencies

```mermaid
graph LR
    subgraph "clients_core_cache"
        Cache
        request_cache
    end

    Cache --> cachetools["cachetools.LRUCache"]
    Cache --> diskcache["diskcache.FanoutCache"]
    Cache --> cloudpickle["cloudpickle"]
    Cache --> ujson["ujson"]
    Cache --> pydantic["pydantic"]
    Cache --> hashlib["hashlib.sha256"]
    request_cache --> inspect["inspect"]
    request_cache --> functools["functools.wraps"]
    request_cache --> dspy["dspy.cache (global)"]
```

| Dependency | Role |
|------------|------|
| `cachetools.LRUCache` | In-memory LRU eviction policy. |
| `diskcache.FanoutCache` | Sharded, persistent on-disk storage. |
| `cloudpickle` | Serialization for `save_memory_cache` / `load_memory_cache`. |
| `ujson` | Fast, deterministic JSON serialization for key hashing. |
| `pydantic` | Detection and normalization of Pydantic models in requests. |
| `hashlib.sha256` | Cryptographic hashing for cache keys. |

---

## Configuration and Usage

The cache is configured globally through DSPy's settings system (see [`dsp_utils`](dsp_utils.md) for the `Settings` singleton). The global `dspy.cache` instance is created based on settings such as `enable_disk_cache`, `enable_memory_cache`, `disk_cache_dir`, and `disk_size_limit_bytes`.

Typical usage patterns:

- **Automatic (recommended)**: Configure `dspy.LM(..., cache=True)` and let `request_cache` handle caching transparently.
- **Manual control**: Access `dspy.cache` directly to `get`, `put`, `reset_memory_cache`, or persist the memory cache with `save_memory_cache` / `load_memory_cache`.
- **Per-call override**: Pass `cache=False` or `cache_in_memory=False` to an LM call to bypass caching for that request.

---

## Related Modules

- [`clients_core_lm`](clients_core_lm.md) — The `LM` class that consumes `request_cache` for completion calls.
- [`clients_core_base_lm`](clients_core_base_lm.md) — The `BaseLM` base class providing the LM call interface.
- [`dsp_utils`](dsp_utils.md) — The `Settings` singleton that holds global cache configuration.
- [`utils`](utils.md) — Utility helpers such as `Hasher` used elsewhere in DSPy.
