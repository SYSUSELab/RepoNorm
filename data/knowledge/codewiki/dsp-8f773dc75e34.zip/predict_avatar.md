# predict_avatar

## Overview

The `predict_avatar` module implements **Avatar**, a DSPy module that solves tasks by iteratively selecting and invoking external tools. Unlike a single-shot predictor, Avatar runs an *agentic loop*: at each step an LLM-driven "Actor" decides which tool to call (and with what input), the tool is executed, and its result is fed back into the Actor's context for the next decision. The loop terminates when the Actor selects the special `Finish` tool, at which point the module produces the final output fields defined by the user's signature.

This makes Avatar well suited for tasks that require multi-step reasoning with retrieval, computation, or any other callable capability exposed as a tool.

## Purpose and Core Functionality

- **Tool-augmented task solving**: Given a user-defined `Signature` (the goal and its input/output fields) and a list of `Tool` objects, Avatar orchestrates a sequence of tool calls to gather the information needed to produce the final answer.
- **Dynamic signature growth**: On every iteration, Avatar mutates the Actor's signature to append the previous action and its result, so the LLM sees the full interaction history when deciding the next action.
- **Explicit termination**: A built-in `Finish` tool signals completion; when selected, the Actor is asked to emit the user's declared output fields directly.
- **Optimization support**: The module is designed to be optimized by the [`AvatarOptimizer`](teleprompt_avatar.md) teleprompter, which rewrites the Actor's instructions based on positive/negative example feedback.

## Architecture

The module is composed of three tightly coupled files:

| File | Responsibility |
| --- | --- |
| `dspy/predict/avatar/avatar.py` | The `Avatar` module: orchestration loop, signature mutation, tool dispatch. |
| `dspy/predict/avatar/models.py` | Pydantic data models: `Tool`, `Action`, `ActionOutput`. |
| `dspy/predict/avatar/signatures.py` | The `Actor` signature that drives tool selection. |

```mermaid
graph TD
    User["User Signature<br/>(goal + input/output fields)"] --> Avatar
    Tools["List of Tool objects"] --> Avatar

    subgraph Avatar["Avatar (dspy.Module)"]
        Actor["Actor (TypedPredictor)"]
        Sig["Actor Signature<br/>(dynamically grown)"]
        Actor --> Sig
    end

    Avatar -->|"action_i"| Dispatch["_call_tool()"]
    Dispatch -->|"tool_output"| Avatar
    Avatar -->|"Finish selected"| Final["dspy.Prediction<br/>(output fields + actions)"]

    Avatar -.optimized by.-> Opt["AvatarOptimizer"]
```

### Execution Flow

```mermaid
sequenceDiagram
    participant U as Caller
    participant A as Avatar
    participant Act as Actor (TypedPredictor)
    participant T as Tool

    U->>A: forward(**inputs)
    A->>A: build args {goal, tools, inputs}
    loop until Finish or max_iters
        A->>Act: actor(**args)
        Act-->>A: action_i (tool_name, tool_input_query)
        alt tool_name != "Finish"
            A->>T: run(tool_input_query)
            T-->>A: tool_output
            A->>A: _update_signature(i) + append result_i
        else tool_name == "Finish"
            A->>A: _update_signature(i, omit_action=True)
            A->>A: break
        end
    end
    A->>Act: actor(**args)  # final answer
    Act-->>A: output fields
    A-->>U: Prediction(outputs..., actions=action_results)
```

## Sub-modules

The module is documented in the following sub-module pages:

- **[predict_avatar_core](predict_avatar_core.md)** — The `Avatar` module itself: the agentic loop, dynamic signature construction, and tool dispatch.
- **[predict_avatar_models](predict_avatar_models.md)** — The Pydantic data models (`Tool`, `Action`, `ActionOutput`) that describe tools and their invocations.
- **[predict_avatar_signatures](predict_avatar_signatures.md)** — The `Actor` signature that instructs the LLM how to choose tools.

## Relationship to Other Modules

- **Base module & prediction**: `Avatar` subclasses [`dspy.Module`](primitives.md) and returns a [`dspy.Prediction`](primitives.md) carrying the output fields plus an `actions` list.
- **Signatures**: The user-provided signature is normalized via `ensure_signature` and the Actor signature is built by mutating [`dspy.Signature`](signatures.md) classes (`append`, `with_updated_fields`, `with_instructions`).
- **Predictors**: The Actor is a `dspy.TypedPredictor` (a typed variant of [`Predict`](predict_core.md)), which enforces the structured `Action` output type.
- **Optimization**: [`AvatarOptimizer`](teleprompt_avatar.md) consumes an `Avatar` instance as its `student`, evaluates it against a trainset, and rewrites the Actor's instructions using a comparator and feedback-based instruction generator.

## Key Design Notes

- **Signature cloning**: `Avatar` keeps a pristine `actor_clone` (a `deepcopy` of the Actor) and restores it after each `forward` call, so the dynamically grown signature does not leak between invocations.
- **`max_iters` override**: The iteration cap can be overridden per call by passing `max_iters` in the forward kwargs; otherwise the constructor value is used.
- **`Finish` tool**: Always appended to the user's tool list, it has `tool=None` and is never executed — it only signals termination.
