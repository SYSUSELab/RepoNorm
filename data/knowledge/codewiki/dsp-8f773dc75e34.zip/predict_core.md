# predict_core

## Overview

The `predict_core` module provides the foundational building blocks for making predictions with Large Language Models (LLMs) in DSPy. It contains the core `Predict` primitive — the atomic unit that binds a `Signature` to an LM call — along with higher-level reasoning and execution helpers built on top of it.

This module is the heart of DSPy's execution model: every other predictor (e.g., `ReAct`, `ProgramOfThought`, `BestOfN` in [predict_advanced](predict_advanced.md)) ultimately delegates to a `Predict` instance to perform the actual LM interaction.

### Core Components

| Component | File | Responsibility |
|-----------|------|----------------|
| `Predict` | `dspy/predict/predict.py` | The atomic predictor: binds a `Signature` to an LM call via an `Adapter`. |
| `Parameter` | `dspy/predict/parameter.py` | Marker base class identifying trainable/optimizable parameters. |
| `ChainOfThought` | `dspy/predict/chain_of_thought.py` | Wraps a `Predict` with an injected `reasoning` field for step-by-step reasoning. |
| `Parallel` | `dspy/predict/parallel.py` | Executes a module over many examples concurrently using a thread pool. |

## Architecture

The module is organized around a layered design where `Predict` is the fundamental primitive and the other components compose or orchestrate it.

```mermaid
graph TD
    subgraph predict_core
        CoT[ChainOfThought]
        Pred[Predict]
        Param[Parameter]
        Par[Parallel]
    end

    CoT -->|wraps| Pred
    Pred -->|inherits| Param
    Pred -->|uses| Adapter[Adapter]
    Pred -->|uses| LM[BaseLM / LM]
    Pred -->|uses| Sig[Signature]
    Pred -->|produces| Pred2[Prediction]
    Par -->|executes| Module[Module]
    Par -->|uses| PE[ParallelExecutor]

    Adapter -.->|from| adapters[adapters module]
    LM -.->|from| clients_core[clients_core module]
    Sig -.->|from| signatures[signatures module]
    Pred2 -.->|from| primitives[primitives module]
    PE -.->|from| utils[utils module]
```

### Component Relationships

`Predict` inherits from both `Module` (from [primitives](primitives.md)) and `Parameter`. This dual inheritance is significant:

- **`Module`** provides the callable interface (`__call__`/`acall`), callback support, history tracking, and the `forward`/`aforward` contract.
- **`Parameter`** marks the object as an optimizable parameter, allowing teleprompters (see [teleprompt_core](teleprompt_core.md)) to discover and tune it via `named_predictors()`.

`ChainOfThought` is a thin `Module` wrapper that constructs an extended signature (prepending a `reasoning` output field) and delegates to an internal `Predict`. `Parallel` is a standalone orchestrator that runs any module across a batch of examples.

## Sub-modules

### Predict

The `Predict` class is the atomic predictor. It binds a `Signature` to an LM call, handling:
- Signature resolution and demo (few-shot example) management
- LM selection and configuration merging (temperature, `n`, etc.)
- Adapter invocation (formatting inputs and parsing outputs)
- Streaming support and trace recording
- State serialization (`dump_state`/`load_state`) for saving/loading compiled programs

See [predict_core_predict.md](predict_core_predict.md) for full details.

### ChainOfThought

`ChainOfThought` augments a signature with a `reasoning` field and delegates to an internal `Predict`, enabling step-by-step reasoning before producing the final answer. It is the most commonly used reasoning wrapper in DSPy.

See [predict_core_chain_of_thought.md](predict_core_chain_of_thought.md) for full details.

### Parallel

`Parallel` executes a module over a list of examples concurrently using a thread pool (`ParallelExecutor`), with error tolerance, cancellation, and optional failed-example reporting. It powers `Module.batch()`.

See [predict_core_parallel.md](predict_core_parallel.md) for full details.

## Execution Flow

The following diagram illustrates the end-to-end flow when a `Predict` (or `ChainOfThought`) is invoked.

```mermaid
sequenceDiagram
    participant User
    participant Module as Module.__call__
    participant Predict as Predict.forward
    participant Adapter
    participant LM as BaseLM
    participant Pred as Prediction

    User->>Module: module(**inputs)
    Module->>Module: set caller_modules context
    Module->>Predict: forward(**kwargs)
    Predict->>Predict: _forward_preprocess (resolve lm, config, signature, demos)
    Predict->>Adapter: adapter(lm, lm_kwargs, signature, demos, inputs)
    Adapter->>Adapter: format() -> messages
    Adapter->>LM: lm(messages=..., **lm_kwargs)
    LM-->>Adapter: raw completions
    Adapter->>Adapter: parse() -> output dicts
    Adapter-->>Predict: completions
    Predict->>Pred: Prediction.from_completions(...)
    Predict->>Predict: _forward_postprocess (record trace)
    Predict-->>Module: Prediction
    Module-->>User: Prediction
```

## Key Design Patterns

### Configuration Layering

`Predict` merges configuration from multiple sources with a clear precedence. In `_forward_preprocess`, the effective config is built as `{**self.config, **kwargs.pop("config", {})}`, and the LM is resolved as `kwargs.pop("lm", self.lm) or settings.lm`. This allows per-call overrides to take precedence over instance-level config, which in turn overrides global settings.

### Adapter Abstraction

`Predict` never talks to the LM directly. Instead it delegates to an `Adapter` (defaulting to `ChatAdapter`), which is responsible for:
- Formatting the signature, demos, and inputs into LM messages
- Parsing the LM's raw output back into structured fields

This separation (documented in [adapters](adapters.md)) allows different output formats (JSON, XML, BAML, two-step) to be swapped without changing `Predict`.

### Streaming Context

`Predict._should_stream()` inspects `settings.stream_listeners` and `settings.send_stream` to decide whether to enable streaming for a given call. When streaming, the call is wrapped in `settings.context(caller_predict=self)` so that stream listeners can be matched to the correct predictor.

### State Serialization

`Predict.dump_state()` / `load_state()` enable saving and restoring compiled programs. Demos are serialized (with Pydantic models converted to JSON-compatible dicts via `serialize_object`), and the signature and LM states are dumped separately. Note that loading legacy `extended_signature` state (DSPy ≤ 2.5) raises `NotImplementedError`.

## Related Modules

- [adapters](adapters.md) — Output formatting and parsing strategies used by `Predict`.
- [clients_core](clients_core.md) — `BaseLM`/`LM` classes that `Predict` invokes.
- [signatures](signatures.md) — `Signature` definitions that describe input/output fields.
- [primitives](primitives.md) — `Module`, `Prediction`, and `Example` base classes.
- [utils](utils.md) — `ParallelExecutor` and callback infrastructure.
- [predict_advanced](predict_advanced.md) — Higher-level predictors built on `Predict`.
- [teleprompt_core](teleprompt_core.md) — Optimizers that tune `Predict` parameters.
