# predict_advanced_agents

## Introduction

The `predict_advanced_agents` module provides DSPy's **agentic reasoning paradigms** — modules that let a language model iteratively reason, act, and observe in a loop until a task is complete. Unlike single-shot predictors, these modules maintain a *trajectory* of thoughts, tool calls, and observations, enabling multi-step problem solving with external tools.

This module contains two core components:

| Component | File | Paradigm |
|-----------|------|----------|
| `ReAct` | `dspy/predict/react.py` | Reasoning + Acting via interleaved thought/tool-call steps |
| `CodeAct` | `dspy/predict/code_act.py` | Reasoning + Acting by generating and executing Python code |

Both are subclasses of [`Module`](primitives.md) and integrate with the broader DSPy prediction stack ([`Predict`](predict_core.md), [`ChainOfThought`](predict_core.md)) and the tool abstraction ([`Tool`](adapter_types.md)).

---

## Architecture Overview

The module sits within the `predict_advanced` family, which groups specialized prediction strategies. `predict_advanced_agents` is the *agentic* branch, focused on tool-using, multi-iteration loops.

```mermaid
graph TD
    subgraph predict_advanced["predict_advanced"]
        subgraph agents["predict_advanced_agents (this module)"]
            ReAct["ReAct"]
            CodeAct["CodeAct"]
        end
        subgraph sampling["predict_advanced_sampling"]
            BestOfN["BestOfN"]
            Refine["Refine"]
        end
        subgraph synthesis["predict_advanced_program_synthesis"]
            PoT["ProgramOfThought"]
        end
        subgraph retrieval["predict_advanced_retrieval"]
            KNN["KNN"]
            MCC["MultiChainComparison"]
        end
    end

    CodeAct -->|inherits| ReAct
    CodeAct -->|inherits| PoT
    ReAct -->|uses| Predict
    ReAct -->|uses| CoT
    CodeAct -->|uses| Predict
    CodeAct -->|uses| CoT
    ReAct -->|uses| Tool
    CodeAct -->|uses| Tool
    CodeAct -->|uses| Interp
    PoT -->|uses| Interp
```

### Key Relationships

- **`CodeAct` inherits from both `ReAct` and `ProgramOfThought`** — it reuses `ReAct`'s trajectory-truncation and extraction machinery while adopting `ProgramOfThought`'s code-generation-and-execution loop.
- Both modules delegate LLM calls to [`Predict`](predict_core.md) and [`ChainOfThought`](predict_core.md).
- Both wrap user functions in [`Tool`](adapter_types.md) objects for schema-aware invocation.
- `CodeAct` (and `ProgramOfThought`) rely on [`PythonInterpreter`](primitives.md) for sandboxed code execution.

---

## Component Details

### ReAct

`ReAct` ("Reasoning and Acting") is a generalized tool-using agent. In each iteration, the language model produces:

1. `next_thought` — reasoning about the current situation
2. `next_tool_name` — the tool to invoke (constrained to a `Literal` of available tool names)
3. `next_tool_args` — JSON-formatted arguments for the tool

After each tool call, the resulting observation is appended to the trajectory, and the loop repeats until the model selects the special `finish` tool or `max_iters` is reached.

#### Construction

```python
def get_weather(city: str) -> str:
    return f"The weather in {city} is sunny."

react = dspy.ReAct(signature="question->answer", tools=[get_weather])
pred = react(question="What is the weather in Tokyo?")
```

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `signature` | `str \| type[Signature]` | — | Defines module inputs/outputs; generalized via signature polymorphism |
| `tools` | `list[Callable]` | — | Functions, callable objects, or `dspy.Tool` instances |
| `max_iters` | `int` | `10` | Maximum reasoning iterations |

#### Internal Structure

`ReAct.__init__` builds two sub-modules:

- **`self.react`** — a `Predict` over a dynamically constructed signature with fields `trajectory`, `next_thought`, `next_tool_name` (typed as `Literal[tuple(tools.keys())]`), and `next_tool_args` (`dict[str, Any]`).
- **`self.extract`** — a `ChainOfThought` over a fallback signature that maps the original inputs + trajectory to the original outputs, used to extract the final answer once the loop terminates.

A synthetic `finish` tool is injected into the tool registry to signal task completion.

#### Execution Flow

```mermaid
flowchart TD
    Start([forward / aforward]) --> Init["trajectory = {}<br/>max_iters = input or default"]
    Init --> Loop{"idx < max_iters?"}
    Loop -->|yes| Call["Call self.react with formatted trajectory"]
    Call --> Valid{"Valid tool selected?"}
    Valid -->|no| Break["Log warning, break loop"]
    Valid -->|yes| Record["Record thought/tool_name/tool_args"]
    Record --> Exec["Execute tool (call/acall)"]
    Exec --> Obs["Append observation (or error string)"]
    Obs --> Finish{"tool_name == 'finish'?"}
    Finish -->|yes| Break
    Finish -->|no| Loop
    Loop -->|no| Extract
    Break --> Extract["Call self.extract with trajectory"]
    Extract --> Return["Return Prediction(trajectory=..., **extract)"]
```

#### Context-Window Handling

Both `forward` and `aforward` route LLM calls through `_call_with_potential_trajectory_truncation` (and its async twin). If a `ContextWindowExceededError` is raised, the trajectory is truncated via `truncate_trajectory`, which removes the oldest tool call (4 keys: thought, tool_name, tool_args, observation). This retries up to 3 times. Users may override `truncate_trajectory` to customize behavior.

#### Trajectory Formatting

`_format_trajectory` uses the active adapter (`dspy.settings.adapter` or `ChatAdapter`) to format the trajectory dictionary into a user message. See [adapters](adapters.md) for adapter details.

---

### CodeAct

`CodeAct` extends the agentic paradigm by having the model **generate executable Python code** instead of selecting discrete tools. It combines `ReAct`'s trajectory management with `ProgramOfThought`'s code execution loop.

#### Construction

```python
from dspy.predict import CodeAct

def factorial(n):
    if n == 1:
        return 1
    return n * factorial(n - 1)

act = CodeAct("n->factorial", tools=[factorial])
act(n=5)  # 120
```

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `signature` | `str \| type[Signature]` | — | Module input/output signature |
| `tools` | `list[Callable]` | — | **Functions only** (not callable objects) |
| `max_iters` | `int` | `5` | Maximum code-generation iterations |
| `interpreter` | `PythonInterpreter \| None` | `None` | Sandbox interpreter; a new one is created if omitted |

> **Note:** `CodeAct` raises `ValueError` if any tool is a callable object rather than a plain function, because it injects tool source code into the interpreter.

#### Internal Structure

`CodeAct.__init__` builds:

- **`self.codeact`** — a `Predict` over a signature with `trajectory`, `generated_code` (str), and `finished` (bool) outputs.
- **`self.extractor`** — a `ChainOfThought` for final answer extraction (mirrors `ReAct.extract`).
- **`self.interpreter`** — a `PythonInterpreter` used to execute generated code.

#### Execution Flow

```mermaid
flowchart TD
    Start([forward]) --> Inject["Inject tool source into interpreter"]
    Inject --> Loop{"idx < max_iters?"}
    Loop -->|yes| Gen["self.codeact(trajectory, **kwargs)"]
    Gen --> Parse["_parse_code(code_data)"]
    Parse --> ParseErr{"Parse error?"}
    ParseErr -->|yes| ObsErr["Append parse-error observation"]
    ObsErr --> Loop
    ParseErr -->|no| Exec["_execute_code(code)"]
    Exec --> ExecErr{"Execution error?"}
    ExecErr -->|yes| ObsExec["Append execution-error observation"]
    ExecErr -->|no| Record["Record code_output"]
    Record --> Finished{"code_data.finished?"}
    ObsExec --> Finished
    Finished -->|yes| Break
    Finished -->|no| Loop
    Loop -->|no| Extract
    Break --> Extract["self.extractor(trajectory)"]
    Extract --> Shutdown["interpreter.shutdown()"]
    Shutdown --> Return["Return Prediction(trajectory=..., **extract)"]
```

#### Instruction Building

`_build_instructions` composes the agent prompt, instructing the model to:
- Generate executable Python that collects information for the outputs
- Print any output to be extracted to the console
- Enclose code in fenced code blocks
- Set `finished=True` when all outputs are available

The available tools are listed with their string representations.

---

## Data Flow

The following diagram shows how data flows through a `ReAct`/`CodeAct` invocation, from inputs to final prediction.

```mermaid
sequenceDiagram
    participant User
    participant Agent as ReAct / CodeAct
    participant Predict as Predict / ChainOfThought
    participant Adapter as Adapter
    participant LM as Language Model
    participant Tool as Tool / Interpreter

    User->>Agent: forward(**inputs)
    loop Until finish or max_iters
        Agent->>Predict: call with formatted trajectory
        Predict->>Adapter: format signature + demos + inputs
        Adapter->>LM: send prompt
        LM-->>Adapter: completion
        Adapter-->>Predict: completions
        Predict-->>Agent: Prediction (thought/tool or code)
        Agent->>Tool: execute tool / run code
        Tool-->>Agent: observation / output
        Agent->>Agent: append to trajectory
    end
    Agent->>Predict: extract final answer from trajectory
    Predict-->>Agent: extracted outputs
    Agent-->>User: Prediction(trajectory=..., **outputs)
```

---

## Component Interaction

```mermaid
classDiagram
    class Module {
        +forward(**kwargs)
        +aforward(**kwargs)
        +__call__()
        +acall()
    }
    class ReAct {
        +signature
        +tools: dict[str, Tool]
        +max_iters: int
        +react: Predict
        +extract: ChainOfThought
        +forward(**input_args)
        +aforward(**input_args)
        +truncate_trajectory(trajectory)
    }
    class CodeAct {
        +signature
        +tools: dict[str, Tool]
        +max_iters: int
        +codeact: Predict
        +extractor: ChainOfThought
        +interpreter: PythonInterpreter
        +forward(**kwargs)
    }
    class ProgramOfThought {
        +code_generate
        +code_regenerate
        +generate_answer
        +interpreter
    }
    class Predict
    class ChainOfThought
    class Tool
    class PythonInterpreter

    Module <|-- ReAct
    ReAct <|-- CodeAct
    ProgramOfThought <|-- CodeAct
    ReAct --> Predict
    ReAct --> ChainOfThought
    ReAct --> Tool
    CodeAct --> Predict
    CodeAct --> ChainOfThought
    CodeAct --> Tool
    CodeAct --> PythonInterpreter
    ProgramOfThought --> PythonInterpreter
```

---

## Dependencies

### Internal DSPy Dependencies

| Dependency | Purpose | Documentation |
|------------|---------|---------------|
| `Module` | Base class providing `__call__`/`acall`, callbacks, usage tracking | [primitives.md](primitives.md) |
| `Predict` | Core LLM invocation with signature/demos/config | [predict_core.md](predict_core.md) |
| `ChainOfThought` | Adds step-by-step reasoning before output | [predict_core.md](predict_core.md) |
| `Tool` | Wraps functions with schema-aware validation and invocation | [adapter_types.md](adapter_types.md) |
| `PythonInterpreter` | Sandboxed Deno/Pyodide code execution | [primitives.md](primitives.md) |
| `ProgramOfThought` | Code-generation loop reused by `CodeAct` | [predict_advanced.md](predict_advanced.md) |
| `Signature` / `ensure_signature` | Signature definition and normalization | [signatures.md](signatures.md) |
| `ChatAdapter` | Default adapter for trajectory formatting | [adapters.md](adapters.md) |
| `Prediction` | Output container | [primitives.md](primitives.md) |

### External Dependencies

- **`litellm`** — `ContextWindowExceededError` for context-window handling in `ReAct`.
- **`deno`** — Required runtime for `PythonInterpreter` (used by `CodeAct`). Install via `curl -fsSL https://deno.land/install.sh | sh`.

---

## Usage Patterns

### ReAct with Multiple Tools

```python
import dspy

def search(query: str) -> str:
    """Search the web for information."""
    return f"Results for: {query}"

def calculate(expression: str) -> str:
    """Evaluate a math expression."""
    return str(eval(expression))

react = dspy.ReAct(
    signature="question -> answer",
    tools=[search, calculate],
    max_iters=15,
)
result = react(question="What is 2 + 2, and who invented it?")
print(result.answer)
print(result.trajectory)  # Full reasoning trace
```

### CodeAct with Function Tools

```python
from dspy.predict import CodeAct

def factorial(n: int) -> int:
    if n == 1:
        return 1
    return n * factorial(n - 1)

act = CodeAct("n -> factorial", tools=[factorial], max_iters=5)
result = act(n=5)
print(result.factorial)  # 120
```

### Async Execution

Both modules support async via `aforward`:

```python
result = await react.acall(question="...")
result = await act.acall(n=5)
```

---

## Design Notes & Extension Points

The `ReAct` source includes a set of documented "Thoughts and Planned Improvements" that highlight extension points:

1. **Trajectory formatting timing** — Trajectories are formatted at `forward` runtime, so demonstrations do not automatically update when the adapter changes. A future fix may support `format=fn` on `InputField` or native variadic input fields.
2. **`__init__` simplification** — Modular logic (exception handling, the `finish` tool) could move into the `Tool` class.
3. **Context-window behavior** — Default truncation removes the oldest tool call; users can override `truncate_trajectory`.
4. **Instruction structure** — Instructions are currently plain strings (freely rewritable by optimizers); a structured template is a possible future direction.
5. **Stateful tools** — Idiomatic support for tools that maintain state across iterations but not across `forward` calls is a planned improvement.

### Customizing Trajectory Truncation

```python
class MyReAct(dspy.ReAct):
    def truncate_trajectory(self, trajectory):
        # Custom logic to fit the context window
        ...
```

---

## Related Modules

- [predict_core.md](predict_core.md) — `Predict`, `ChainOfThought`, `Parameter`, `Parallel`
- [predict_advanced.md](predict_advanced.md) — Parent module grouping all advanced predictors
- [primitives.md](primitives.md) — `Module`, `Prediction`, `PythonInterpreter`
- [adapter_types.md](adapter_types.md) — `Tool`, `ToolCalls`, and other adapter types
- [adapters.md](adapters.md) — Adapter implementations used for formatting
- [signatures.md](signatures.md) — Signature definition and polymorphism
