# Program of Thought (Program Synthesis)

## Introduction

The `predict_advanced_program_synthesis` module provides the **`ProgramOfThought`** component, a DSPy module that solves problems by **generating and executing Python programs** rather than producing answers directly through natural language reasoning.

Instead of asking a language model to "think" its way to an answer, `ProgramOfThought` instructs the LM to write executable Python code that programmatically computes the answer. The code is then run inside a sandboxed interpreter, and the resulting output is used to produce the final structured answer. This approach is particularly effective for tasks involving arithmetic, symbolic manipulation, data transformation, and any problem where deterministic computation is more reliable than free-form reasoning.

> **Prerequisite:** This module requires [Deno](https://docs.deno.com/runtime/getting_started/installation/) to be installed, as code execution is sandboxed via Deno + Pyodide.

### Quick Example

```python
import dspy

lm = dspy.LM('openai/gpt-4o-mini')
dspy.configure(lm=lm)

pot = dspy.ProgramOfThought("question -> answer")
pot(question="what is 1+1?")
```

---

## Architecture Overview

`ProgramOfThought` is a `Module` composed of three internal `ChainOfThought` predictors and a sandboxed `PythonInterpreter`. It orchestrates a generate → execute → (retry) → answer loop.

```mermaid
graph TD
    subgraph ProgramOfThought
        CG["code_generate<br/>(ChainOfThought)"]
        CR["code_regenerate<br/>(ChainOfThought)"]
        GA["generate_answer<br/>(ChainOfThought)"]
        PI["PythonInterpreter<br/>(Deno + Pyodide sandbox)"]
    end

    Input["Input kwargs<br/>(signature input fields)"] --> CG
    CG -->|generated_code| Parse["_parse_code"]
    Parse -->|code| Exec["_execute_code"]
    Exec --> PI
    PI -->|output / error| Check{Error?}
    Check -->|No| GA
    Check -->|Yes, hop < max_iters| CR
    CR -->|regenerated code| Parse
    Check -->|Yes, hop == max_iters| Fail["RuntimeError"]
    GA --> Output["Prediction<br/>(signature output fields)"]
```

### Component Responsibilities

| Component | Role |
|-----------|------|
| `code_generate` | `ChainOfThought` predictor that generates the initial Python program from the input fields. |
| `code_regenerate` | `ChainOfThought` predictor that repairs code given the previous code and its error message. |
| `generate_answer` | `ChainOfThought` predictor that converts the final code + its output into the structured answer. |
| `PythonInterpreter` | Sandboxed execution engine (Deno + Pyodide) that runs the generated code. |

---

## Component Relationships

`ProgramOfThought` builds on several core DSPy primitives. The diagram below shows how it fits into the broader framework.

```mermaid
graph LR
    PoT["ProgramOfThought<br/>(this module)"]
    CoT["ChainOfThought<br/>[predict_core]"]
    Mod["Module<br/>[primitives]"]
    Sig["Signature / ensure_signature<br/>[signatures]"]
    PI["PythonInterpreter<br/>[primitives]"]
    Pred["Predict<br/>[predict_core]"]

    PoT -->|inherits| Mod
    PoT -->|uses 3x| CoT
    PoT -->|uses| Sig
    PoT -->|uses| PI
    CoT -->|wraps| Pred
    CoT -->|uses| Sig
```

- **`Module`** — `ProgramOfThought` subclasses `Module`, inheriting the `__call__`/`forward` dispatch, callback handling, usage tracking, and history. See [primitives.md](primitives.md).
- **`ChainOfThought`** — Each of the three internal predictors is a `ChainOfThought`, which prepends a `reasoning` field to a signature and delegates to `Predict`. See [predict_core.md](predict_core.md).
- **`Signature` / `ensure_signature`** — Used to normalize the user-provided signature and to dynamically construct the three mode-specific signatures. See [signatures.md](signatures.md).
- **`PythonInterpreter`** — Provides the sandboxed execution environment. See [primitives.md](primitives.md).

---

## Internal Data Flow

The `forward` method implements the core control loop. The following sequence diagram traces a single invocation, including the retry path.

```mermaid
sequenceDiagram
    participant Caller
    participant PoT as ProgramOfThought
    participant CG as code_generate
    participant Parser as _parse_code
    participant Exec as _execute_code
    participant PI as PythonInterpreter
    participant CR as code_regenerate
    participant GA as generate_answer

    Caller->>PoT: forward(**kwargs)
    PoT->>CG: generate code from input fields
    CG-->>PoT: code_data
    PoT->>Parser: parse generated_code
    Parser-->>PoT: code, error
    alt no parse error
        PoT->>Exec: execute code
        Exec->>PI: interpreter.execute(code)
        PI-->>Exec: output or exception
        Exec-->>PoT: output, error
    end
    loop while error and hop < max_iters
        PoT->>CR: regenerate(previous_code, error)
        CR-->>PoT: code_data
        PoT->>Parser: parse
        Parser-->>PoT: code, error
        alt no parse error
            PoT->>Exec: execute code
            Exec->>PI: interpreter.execute(code)
            PI-->>Exec: output or exception
            Exec-->>PoT: output, error
        end
    end
    alt error and hop == max_iters
        PoT->>PI: shutdown()
        PoT-->>Caller: RuntimeError
    end
    PoT->>GA: generate_answer(final_generated_code, code_output)
    GA-->>PoT: answer_gen_result
    PoT->>PI: shutdown()
    PoT-->>Caller: Prediction
```

---

## Detailed Component Documentation

### `ProgramOfThought`

```python
class ProgramOfThought(Module):
    def __init__(
        self,
        signature: str | type[Signature],
        max_iters: int = 3,
        interpreter: PythonInterpreter | None = None,
    )
```

**Constructor arguments:**

| Argument | Type | Default | Description |
|----------|------|---------|-------------|
| `signature` | `str \| type[Signature]` | — | The task signature (e.g. `"question -> answer"`). Normalized via `ensure_signature`. |
| `max_iters` | `int` | `3` | Maximum number of code generation/execution retries before raising. |
| `interpreter` | `PythonInterpreter \| None` | `None` | A custom interpreter instance. If `None`, a new `PythonInterpreter` is created (which requires Deno). |

**Instance attributes:**

- `self.signature` — the normalized signature.
- `self.input_fields` / `self.output_fields` — the input and output fields of the signature.
- `self.code_generate`, `self.code_regenerate`, `self.generate_answer` — the three internal `ChainOfThought` predictors.
- `self.interpreter` — the sandboxed `PythonInterpreter`.

#### Dynamic Signature Generation

The module constructs three distinct signatures at initialization time via `_generate_signature(mode)` and `_generate_instruction(mode)`:

| Mode | Inputs | Outputs | Purpose |
|------|--------|---------|---------|
| `generate` | signature input fields | `generated_code` | Produce the initial Python program. |
| `regenerate` | signature input fields + `previous_code` + `error` | `generated_code` | Repair failing code. |
| `answer` | `final_generated_code` + `code_output` + signature input fields | signature output fields | Convert code output into the final structured answer. |

The `generate` instruction explicitly tells the LM to:
- Generate executable Python code that computes the answer.
- Call the preloaded `final_answer()` function once the answer is computed.
- Structure the answer as a dict mapping output field names to values.

#### `_parse_code(code_data)`

Extracts a clean Python code block from the LM's raw output. It:
1. Truncates at `---` or triple-newline separators.
2. Extracts the content of a ```` ```python ... ``` ```` fenced block if present.
3. Unescapes `\n` sequences.
4. Validates the code is non-empty and well-formed (heuristics for single-line multi-assignment).
5. Appends a trailing variable name if the last line is an assignment (so the value is returned).

Returns a tuple `(code_block, error)` where `error` is `None` on success.

#### `_execute_code(code)`

Executes the code via `self.interpreter.execute(code)` and JSON-serializes the result. Returns `(output, error)`; on exception, `output` is `None` and `error` is the stringified exception.

#### `forward(**kwargs)`

The main entry point (invoked via `Module.__call__`). It:
1. Extracts the signature's input fields from `kwargs`.
2. Generates code via `code_generate`.
3. Parses and executes the code.
4. On error, loops up to `max_iters` times, calling `code_regenerate` with `previous_code` and `error`.
5. If `max_iters` is reached, shuts down the interpreter and raises `RuntimeError`.
6. Otherwise, calls `generate_answer` with the final code and output.
7. Shuts down the interpreter and returns the resulting `Prediction`.

---

## Execution Flow (Process)

```mermaid
flowchart TD
    Start([forward called]) --> Extract[Extract input fields]
    Extract --> Gen[code_generate]
    Gen --> Parse[_parse_code]
    Parse --> HasErr1{Parse error?}
    HasErr1 -->|No| Exec[_execute_code]
    HasErr1 -->|Yes| Retry
    Exec --> HasErr2{Exec error?}
    HasErr2 -->|No| Answer
    HasErr2 -->|Yes| Retry
    Retry{hop == max_iters?}
    Retry -->|Yes| Shutdown1[interpreter.shutdown]
    Shutdown1 --> Raise[raise RuntimeError]
    Retry -->|No| Regen[code_regenerate]
    Regen --> Parse
    Answer[generate_answer] --> Shutdown2[interpreter.shutdown]
    Shutdown2 --> Return([Return Prediction])
```

---

## Sandboxed Execution

Code execution is delegated to `PythonInterpreter`, which runs Python inside a **Deno + Pyodide** sandbox. Key characteristics:

- **Isolation:** Code runs in a WebAssembly-based Python runtime, not the host interpreter.
- **Permissions:** Read paths, write paths, environment variables, and network access are explicitly allow-listed at construction time.
- **File syncing:** Changes to allow-listed write paths can be synced back to the host (`sync_files=True`).
- **`final_answer()` trick:** The sandbox exposes a `final_answer()` function; when called, the interpreter surfaces its arguments as the execution output (via the `FinalAnswer` error type).
- **Lifecycle:** `ProgramOfThought` calls `interpreter.shutdown()` after each invocation to release the Deno subprocess.

For full details on the interpreter's sandboxing model, see [primitives.md](primitives.md).

---

## Error Handling

| Failure Point | Behavior |
|---------------|----------|
| Deno not installed | `PythonInterpreter` raises `InterpreterError` with installation instructions at construction time. |
| Empty/invalid parsed code | `_parse_code` returns an error string; triggers regeneration. |
| Code execution exception | `_execute_code` returns the exception string; triggers regeneration. |
| `max_iters` exceeded | Interpreter is shut down and a `RuntimeError` is raised. |
| Syntax errors in sandbox | Surfaced as `SyntaxError` from the interpreter. |

---

## Related Modules

- [predict_core.md](predict_core.md) — `Predict`, `ChainOfThought`, `Parameter`, `Parallel`.
- [primitives.md](primitives.md) — `Module`, `Prediction`, `PythonInterpreter`.
- [signatures.md](signatures.md) — `Signature`, `ensure_signature`, field definitions.
- [predict_advanced.md](predict_advanced.md) — Overview of advanced predictors (`BestOfN`, `ReAct`, `CodeAct`, `Refine`, etc.).
- [predict_advanced_agents.md](predict_advanced_agents.md) — `ReAct` and `CodeAct`, which also leverage code/tool execution.
