# Evaluation Engine

## Introduction

The **Evaluation Engine** (`dspy/evaluate/evaluate.py`) is the core component of DSPy's evaluation subsystem. It provides the `Evaluate` class, which measures the performance of a DSPy program against a labeled dataset using a user-supplied metric function. It supports parallel execution, error tolerance, progress reporting, and rich tabular result display.

The engine produces an `EvaluationResult` object — a specialized `Prediction` — that bundles the aggregate score together with per-example `(example, prediction, score)` tuples, making it easy to inspect individual outcomes.

> **Related modules:**
> - [Auto-Evaluation Metrics](evaluate_auto_evaluation.md) — LLM-based metrics such as `SemanticF1` that can be plugged into `Evaluate` as the `metric` argument.
> - [Parallel Executor](utils.md) — the underlying `ParallelExecutor` used for concurrent evaluation.
> - [Predictions & Examples](primitives.md) — the `Prediction` and `Example` primitives that flow through evaluation.
> - [Modules](primitives.md) — the `dspy.Module` programs being evaluated.

---

## Purpose and Core Functionality

The Evaluation Engine answers a single question: **"How well does my program perform on this dataset?"**

It does so by:

1. Iterating over a `devset` of `dspy.Example` objects.
2. Invoking the target `program` on each example's inputs.
3. Scoring each `(example, prediction)` pair with a `metric` callable.
4. Aggregating scores into an overall percentage.
5. Optionally rendering a per-example results table.

### Key Capabilities

| Capability | Description |
|------------|-------------|
| **Parallel evaluation** | Uses `ParallelExecutor` to run examples concurrently across threads. |
| **Error tolerance** | `max_errors` bounds how many failures are tolerated before aborting. |
| **Failure scoring** | `failure_score` assigns a default score when an example raises an exception. |
| **Progress display** | `display_progress` toggles a live `tqdm` progress bar. |
| **Tabular results** | `display_table` renders a styled pandas DataFrame (with optional truncation). |
| **Callback integration** | `@with_callbacks` emits start/end events for observability tooling. |
| **Configurable defaults** | Constructor arguments can be overridden per-call. |

---

## Architecture

The engine sits between the user's program and the dataset, orchestrating execution and scoring.

```mermaid
graph TD
    User["User Code"] -->|"Evaluate(devset, metric)"| Eval["Evaluate"]
    Eval -->|"__call__(program)"| Executor["ParallelExecutor"]
    Executor -->|"process_item(example)"| Program["dspy.Module (program)"]
    Program -->|"prediction"| Metric["metric(example, prediction)"]
    Metric -->|"score"| Executor
    Executor -->|"results list"| Eval
    Eval -->|"aggregate + per-example"| Result["EvaluationResult"]
    Result -->|"display_table"| Table["pandas DataFrame / HTML"]

    subgraph "DSPy Primitives"
        Program
        Example["dspy.Example"]
        Prediction["dspy.Prediction"]
    end

    subgraph "Infrastructure"
        Executor
        Callbacks["with_callbacks"]
        Settings["dspy.settings"]
    end

    Eval -.->|"@with_callbacks"| Callbacks
    Executor -.->|"max_errors default"| Settings
```

### Component Responsibilities

- **`Evaluate`** — Orchestrator. Holds configuration, resolves per-call overrides, drives the executor, aggregates scores, and renders output.
- **`EvaluationResult`** — Data container. A `Prediction` subclass carrying `score` and `results`.
- **`ParallelExecutor`** — Concurrency layer. Handles thread isolation, straggler timeouts, and error counting. See [Parallel Executor](utils.md).
- **`with_callbacks`** — Observability decorator wrapping `Evaluate.__call__`. See [Callbacks](utils.md).

---

## Component Interaction Flow

The following sequence diagram shows the lifecycle of a single `Evaluate.__call__` invocation.

```mermaid
sequenceDiagram
    participant U as User
    participant E as Evaluate
    participant CB as Callbacks
    participant PE as ParallelExecutor
    participant P as Program
    participant M as Metric

    U->>E: __call__(program, metric, devset, ...)
    E->>CB: on_start (via @with_callbacks)
    E->>E: Resolve overrides (metric, devset, num_threads, ...)
    E->>PE: ParallelExecutor(num_threads, max_errors, ...)
    E->>PE: execute(process_item, devset)
    loop For each example (parallel)
        PE->>P: program(**example.inputs())
        P-->>PE: prediction
        PE->>M: metric(example, prediction)
        M-->>PE: score
    end
    PE-->>E: results list
    E->>E: Replace None with (Prediction(), failure_score)
    E->>E: Aggregate ncorrect / ntotal
    opt display_table
        E->>E: _construct_result_table(...)
        E->>E: _display_result_table(...)
    end
    E->>CB: on_end (via @with_callbacks)
    E-->>U: EvaluationResult(score, results)
```

---

## Data Flow

The engine transforms a dataset and a program into a scored result set.

```mermaid
flowchart LR
    A["devset: list[Example]"] --> B["process_item(example)"]
    B --> C["program(**example.inputs())"]
    C --> D["prediction: Prediction"]
    D --> E["metric(example, prediction)"]
    E --> F["score: float"]
    F --> G["(prediction, score) tuple"]
    G --> H["zip with devset"]
    H --> I["(example, prediction, score) tuples"]
    I --> J["Aggregate: sum(scores) / len(devset)"]
    I --> K["_construct_result_table (optional)"]
    J --> L["EvaluationResult.score"]
    K --> M["pandas DataFrame"]
```

### Score Aggregation

The overall score is computed as a percentage:

```
score = round(100 * ncorrect / ntotal, 2)
```

where `ncorrect = sum(score for *_, score in results)` and `ntotal = len(devset)`.

---

## Core Components

### `Evaluate`

The main entry point. It is configured at construction time and invoked via `__call__`.

#### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `devset` | `list[dspy.Example]` | *required* | The evaluation dataset. |
| `metric` | `Callable \| None` | `None` | Scoring function `metric(example, prediction) -> float`. |
| `num_threads` | `int \| None` | `None` | Threads for parallel evaluation (falls back to `dspy.settings.num_threads`). |
| `display_progress` | `bool` | `False` | Show a live progress bar. |
| `display_table` | `bool \| int` | `False` | Render results table; an `int` truncates to that many rows. |
| `max_errors` | `int \| None` | `None` | Max errors before aborting (falls back to `dspy.settings.max_errors`). |
| `provide_traceback` | `bool \| None` | `None` | Include tracebacks in error logs. |
| `failure_score` | `float` | `0.0` | Score assigned when an example raises an exception. |

#### `__call__` Parameters

All constructor parameters can be overridden per-call. Any argument left as `None` falls back to the constructor value.

| Parameter | Description |
|-----------|-------------|
| `program` | The `dspy.Module` to evaluate. |
| `metric` | Override the metric. |
| `devset` | Override the dataset. |
| `num_threads` | Override thread count. |
| `display_progress` | Override progress display. |
| `display_table` | Override table display. |
| `callback_metadata` | Metadata forwarded to callback handlers. |

**Returns:** an `EvaluationResult`.

#### Internal Methods

- **`_construct_result_table(results, metric_name)`** — Builds a pandas `DataFrame` from results. Merges example and prediction fields (prefixing collisions with `example_` / `pred_`), truncates each cell to 25 words, and renames the `correct` column to the metric name. *Note: this method name is intentionally stable as it may be patched by external tracing tools.*
- **`_display_result_table(result_df, display_table, metric_name)`** — Renders the DataFrame, applying metric-name styling and appending a "more rows not displayed" notice when truncated.

### `EvaluationResult`

A subclass of `dspy.Prediction` (which itself extends `Example`). See [Predictions & Examples](primitives.md).

| Field | Type | Description |
|-------|------|-------------|
| `score` | `float` | Overall percentage score (e.g., `67.30`). |
| `results` | `list[tuple[Example, Example, Any]]` | Per-example `(example, prediction, score)` tuples. |

Its `__repr__` summarizes the score and result count:

```
EvaluationResult(score=67.3, results=<list of 100 results>)
```

---

## Helper Functions

The module includes several module-level helpers supporting table construction and display:

| Function | Purpose |
|----------|---------|
| `prediction_is_dictlike(prediction)` | Checks whether a prediction supports `.items()` for dict-like merging. |
| `merge_dicts(d1, d2)` | Merges example and prediction dicts, disambiguating key collisions with `example_` / `pred_` prefixes. |
| `truncate_cell(content)` | Truncates a cell's content to 25 words. |
| `stylize_metric_name(df, metric_name)` | Formats metric cells with checkmarks and bracketed values. |
| `display_dataframe(df)` | Displays a DataFrame in IPython notebooks or pretty-prints to console. |
| `configure_dataframe_for_ipython_notebook_display(df)` | Sets pandas display options for notebook rendering. |
| `is_in_ipython_notebook_environment()` | Detects whether execution is inside an IPython notebook. |

### IPython Compatibility

The module gracefully degrades when IPython is unavailable by defining fallback `display()` and `HTML()` functions that print to the console. Table rendering additionally requires `pandas`; if absent, a warning is logged and display is skipped.

---

## Error Handling and Resilience

```mermaid
flowchart TD
    Start["process_item(example)"] --> Run["program(**example.inputs())"]
    Run -->|success| Score["metric(example, prediction)"]
    Run -->|exception| Catch["ParallelExecutor catches error"]
    Catch --> Count["Increment error_count"]
    Count --> Check{"error_count >= max_errors?"}
    Check -->|yes| Cancel["Set cancel_jobs event"]
    Check -->|no| ReturnNone["Return None"]
    Score --> Done["Return (prediction, score)"]
    ReturnNone --> Replace["Replace None with (Prediction(), failure_score)"]
    Cancel --> Abort["Raise 'Execution cancelled' exception"]
```

Key resilience behaviors:

- **Per-example isolation** — Exceptions in one example do not crash the whole run; the executor records the error and returns `None`.
- **Failure substitution** — `None` results are replaced with `(dspy.Prediction(), self.failure_score)` so aggregation remains well-defined.
- **Error budget** — Once `max_errors` is exceeded, the executor cancels remaining jobs and raises.
- **Traceback control** — `provide_traceback` controls verbosity of error logs.

---

## Integration with Auto-Evaluation Metrics

The `metric` argument accepts any callable `(example, prediction) -> float`. DSPy's [Auto-Evaluation Metrics](evaluate_auto_evaluation.md) — such as `SemanticF1`, `AnswerCompleteness`, and `CompleteAndGrounded` — are `dspy.Module` instances whose `forward(example, pred, trace=None)` signature matches this contract, allowing them to be passed directly:

```python
from dspy.evaluate import Evaluate
from dspy.evaluate.auto_evaluation import SemanticF1

evaluator = Evaluate(devset=devset, metric=SemanticF1(), num_threads=8, display_progress=True)
result = evaluator(program)
print(result.score)
```

---

## Usage Example

```python
import dspy
from dspy.evaluate import Evaluate

# Define a metric
def exact_match(example, prediction, trace=None):
    return example.answer.lower() == prediction.answer.lower()

# Configure the evaluator
evaluator = Evaluate(
    devset=my_devset,
    metric=exact_match,
    num_threads=8,
    display_progress=True,
    display_table=10,        # show first 10 rows
    max_errors=5,
    failure_score=0.0,
)

# Run evaluation
result = evaluator(my_program)

print(f"Score: {result.score}%")
for example, prediction, score in result.results:
    print(example, prediction, score)
```

---

## Dependencies

```mermaid
graph LR
    Eval["evaluate.py"] --> Pred["dspy.primitives.prediction.Prediction"]
    Eval --> CB["dspy.utils.callback.with_callbacks"]
    Eval --> PE["dspy.utils.parallelizer.ParallelExecutor"]
    Eval --> Settings["dspy.settings"]
    Eval --> TQDM["tqdm"]
    Eval --> Pandas["pandas (optional)"]
    Eval --> IPython["IPython (optional)"]
    Eval --> DSPy["dspy (top-level)"]
```

| Dependency | Role | Required? |
|------------|------|-----------|
| `dspy.primitives.prediction.Prediction` | Base class for `EvaluationResult`. | Yes |
| `dspy.utils.callback.with_callbacks` | Observability decorator. | Yes |
| `dspy.utils.parallelizer.ParallelExecutor` | Parallel execution engine. | Yes |
| `dspy.settings` | Defaults for `max_errors`, `num_threads`. | Yes |
| `tqdm` | Progress bar. | Yes |
| `pandas` | Result table construction/display. | Optional |
| `IPython` | Notebook display. | Optional |

---

## Notes and Known Limitations

- **`display_table` edge cases** — The current implementation handles `False` and integer truncation, but `True` behavior is noted as potentially unreliable (see inline `FIXME`/`TODO` comments).
- **`merge_dicts`** — Flagged as "quick and dirty"; key collisions are handled by prefixing rather than deep merging.
- **No built-in failure summary** — A planned feature (counting failures, printing first N failed examples/exceptions) is not yet implemented.
- **`_construct_result_table` stability** — The method name is deliberately preserved because external tracing tools may patch it.
