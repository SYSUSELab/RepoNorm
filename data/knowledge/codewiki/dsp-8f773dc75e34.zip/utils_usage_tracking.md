# Usage Tracking (`utils_usage_tracking`)

## Introduction

The `utils_usage_tracking` module provides lightweight, context-scoped tracking of Language Model (LM) token usage within DSPy. Its central component, `UsageTracker`, aggregates per-model usage entries (prompt tokens, completion tokens, and their detailed breakdowns) and exposes a `track_usage()` context manager that activates tracking for the duration of a `with` block.

This module is intentionally decoupled from the LM call path: it does not perform any LM calls itself. Instead, it relies on the LM client layer (see [clients_core](clients_core.md)) to report usage entries into the active tracker via the global `settings` object (see [dsp_utils](dsp_utils.md)).

---

## Module Structure

The module consists of a single file, `dspy/utils/usage_tracker.py`, containing:

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `UsageTracker` | Class | Stores and aggregates usage entries keyed by LM name. |
| `track_usage` | Context manager | Instantiates a `UsageTracker` and installs it into `settings.context(usage_tracker=...)`. |

---

## Architecture

The tracker sits between the LM client layer (which produces usage data) and the DSPy settings system (which propagates the active tracker). The following diagram shows how these pieces connect.

```mermaid
graph TD
    subgraph "User Code"
        U["with track_usage() as tracker:"]
    end

    subgraph "utils_usage_tracking"
        TU["track_usage() context manager"]
        UT["UsageTracker"]
    end

    subgraph "dsp_utils"
        S["Settings (thread-local context)"]
    end

    subgraph "clients_core"
        LM["LM / BaseLM.forward()"]
    end

    U --> TU
    TU -->|creates| UT
    TU -->|settings.context(usage_tracker=tracker)| S
    LM -->|reads settings.usage_tracker| S
    LM -->|add_usage(model, usage)| UT
    UT -->|get_total_tokens()| U
```

### Key Relationships

- **`track_usage` → `Settings`**: Uses `settings.context(...)` to install the tracker as a thread-local override. This means tracking is scoped to the current thread and any child threads spawned via DSPy primitives (e.g., `ParallelExecutor`). See [dsp_utils](dsp_utils.md) for details on the settings context mechanism.
- **`LM` → `UsageTracker`**: The LM client checks `settings.usage_tracker` after each non-cached response and calls `add_usage(self.model, dict(results.usage))`. See [clients_core](clients_core.md) for the LM call path.

---

## Component Details

### `UsageTracker`

The `UsageTracker` class maintains an internal mapping from LM name to a list of usage entries:

```python
{
    "openai/gpt-4o-mini": [
        {"prompt_tokens": 100, "completion_tokens": 200},
        {"prompt_tokens": 300, "completion_tokens": 400},
    ],
}
```

#### Internal State

| Attribute | Type | Description |
|-----------|------|-------------|
| `usage_data` | `defaultdict(list)` | Maps LM name → list of flattened usage entries. |

#### Methods

| Method | Signature | Description |
|--------|-----------|-------------|
| `add_usage` | `(lm: str, usage_entry: dict)` | Appends a flattened usage entry for the given LM. Empty entries are ignored. |
| `get_total_tokens` | `() -> dict[str, dict[str, Any]]` | Aggregates all entries per LM into a single merged usage dictionary. |
| `_flatten_usage_entry` | `(usage_entry) -> dict` | Converts nested detail objects (e.g., `completion_tokens_details`, `prompt_tokens_details`) into plain dicts. |
| `_merge_usage_entries` | `(usage_entry1, usage_entry2) -> dict` | Recursively merges two usage entries, summing numeric fields and recursing into nested dicts. |

#### Aggregation Logic

The `_merge_usage_entries` method handles the recursive summation of usage data. This is important because usage entries may contain nested detail dictionaries (such as token breakdowns by category) that must be summed field-by-field rather than replaced.

```mermaid
flowchart TD
    A["_merge_usage_entries(e1, e2)"] --> B{"e1 empty?"}
    B -->|Yes| C["return dict(e2)"]
    B -->|No| D{"e2 empty?"}
    D -->|Yes| E["return dict(e1)"]
    D -->|No| F["result = dict(e2)"]
    F --> G["for k, v in e1.items()"]
    G --> H{"v or result[k] is dict?"}
    H -->|Yes| I["recurse _merge_usage_entries"]
    H -->|No| J["result[k] = (current or 0) + (v or 0)"]
    I --> K["return result"]
    J --> K
```

### `track_usage` Context Manager

```python
@contextmanager
def track_usage():
    tracker = UsageTracker()
    with settings.context(usage_tracker=tracker):
        yield tracker
```

The context manager:

1. Creates a fresh `UsageTracker` instance.
2. Installs it into the thread-local settings context under the key `usage_tracker`.
3. Yields the tracker so callers can inspect aggregated usage after the block completes.
4. Automatically restores the previous settings context on exit.

---

## Data Flow

The following sequence diagram illustrates the full lifecycle of usage tracking, from entering the context to reading aggregated totals.

```mermaid
sequenceDiagram
    participant User
    participant track_usage
    participant Settings
    participant LM
    participant UsageTracker

    User->>track_usage: enter `with track_usage() as tracker`
    track_usage->>UsageTracker: UsageTracker()
    track_usage->>Settings: settings.context(usage_tracker=tracker)
    Note over Settings: thread-local override active

    User->>LM: lm(prompt)
    LM->>Settings: read settings.usage_tracker
    Settings-->>LM: tracker
    LM->>UsageTracker: add_usage(model, usage)
    Note over UsageTracker: append flattened entry

    User->>UsageTracker: get_total_tokens()
    UsageTracker-->>User: {model: merged_usage}

    User->>track_usage: exit context
    track_usage->>Settings: reset context
```

---

## Usage Example

```python
import dspy
from dspy.utils.usage_tracker import track_usage

lm = dspy.LM("openai/gpt-4o-mini")
dspy.configure(lm=lm)

with track_usage() as tracker:
    dspy.Predict("question -> answer")(question="What is 2+2?")
    dspy.Predict("question -> answer")(question="What is the capital of France?")

print(tracker.get_total_tokens())
# {
#     "openai/gpt-4o-mini": {
#         "prompt_tokens": 42,
#         "completion_tokens": 18,
#         "total_tokens": 60,
#         ...
#     }
# }
```

---

## Design Considerations

### Cache Awareness

The LM client only reports usage for **non-cached** responses. In `LM.forward` and `LM.aforward`, the tracker is updated only when `results.cache_hit` is falsy:

```python
if not getattr(results, "cache_hit", False) and dspy.settings.usage_tracker and hasattr(results, "usage"):
    settings.usage_tracker.add_usage(self.model, dict(results.usage))
```

This prevents double-counting tokens for responses served from cache. See [clients_core](clients_core.md) for the caching layer.

### Thread-Local Scoping

Because the tracker is installed via `settings.context(...)`, it is scoped to the current thread and propagates to child threads created through DSPy concurrency primitives. This makes it safe to use with parallel execution. See [utils_concurrency](utils_concurrency.md) and [dsp_utils](dsp_utils.md) for the propagation mechanics.

### Nested Detail Handling

Usage entries from providers may include nested detail dictionaries (e.g., `completion_tokens_details`). The `_flatten_usage_entry` method converts these to plain dicts at insertion time, and `_merge_usage_entries` recursively sums them at aggregation time, ensuring no detail fields are lost or overwritten.

---

## Related Modules

- [clients_core](clients_core.md) — `LM` / `BaseLM` produce usage data and report it to the active tracker.
- [dsp_utils](dsp_utils.md) — `Settings` provides the thread-local context mechanism used to install the tracker.
- [utils_concurrency](utils_concurrency.md) — Parallel execution primitives that propagate the settings context (and thus the tracker) to child threads.
