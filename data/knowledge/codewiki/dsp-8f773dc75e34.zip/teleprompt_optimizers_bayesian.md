# Teleprompt Optimizers: Bayesian

## Introduction

The `teleprompt_optimizers_bayesian` module provides DSPy optimizers that use **Bayesian optimization** (via the [Optuna](https://optuna.org/) library) to search over the space of prompt configurations. Rather than exhaustively enumerating candidate programs, these optimizers build a probabilistic surrogate model of the objective (the metric score) and use it to intelligently select the next configuration to evaluate.

This module contains two optimizers:

| Optimizer | Search Space | Strategy |
|-----------|--------------|----------|
| **`MIPROv2`** | Instructions **and** few-shot demonstration sets for every predictor | TPE (Tree-structured Parzen Estimator) over categorical instruction/demo choices, with optional minibatching |
| **`BootstrapFewShotWithOptuna`** | A single demonstration index per predictor | TPE over integer demo indices, built on top of a pre-compiled `BootstrapFewShot` program |

Both optimizers inherit from the base [`Teleprompter`](teleprompt_core.md) class and return an optimized `dspy.Module`.

> **Related documentation:** For the base class and non-Bayesian optimizers, see [teleprompt_core.md](teleprompt_core.md). For instruction proposal internals, see [propose.md](propose.md). For evaluation, see [evaluate.md](evaluate.md).

---

## Architecture Overview

The module sits at the intersection of several DSPy subsystems: it consumes candidate instructions from the proposer, candidate demonstrations from bootstrapping, and evaluates them using the evaluation engine, all orchestrated through Optuna's Bayesian search.

```mermaid
graph TD
    subgraph "teleprompt_optimizers_bayesian"
        MIPRO["MIPROv2"]
        BFO["BootstrapFewShotWithOptuna"]
    end

    subgraph "teleprompt_core"
        TP["Teleprompter (base)"]
        BFS["BootstrapFewShot"]
        LFS["LabeledFewShot"]
    end

    subgraph "propose"
        GP["GroundedProposer"]
    end

    subgraph "evaluate"
        EV["Evaluate"]
    end

    subgraph "External"
        OPT["Optuna (TPE Sampler)"]
    end

    MIPRO -->|inherits| TP
    BFO -->|inherits| TP
    BFO -->|wraps| BFS

    MIPRO -->|proposes instructions| GP
    MIPRO -->|bootstraps demos| BFS
    MIPRO -->|evaluates candidates| EV
    BFO -->|evaluates candidates| EV

    MIPRO -->|Bayesian search| OPT
    BFO -->|Bayesian search| OPT

    BFS -->|uses| LFS
```

---

## MIPROv2

`MIPROv2` (Multiprompt Instruction PRoposal Optimizer v2) is the flagship Bayesian optimizer in DSPy. It jointly optimizes **instructions** and **few-shot demonstrations** for every predictor in a program using Bayesian optimization.

### Purpose

Given a student program, a training set, and a metric, `MIPROv2`:

1. **Bootstraps** several candidate sets of few-shot demonstrations.
2. **Proposes** several candidate instructions per predictor using a grounded proposer.
3. **Searches** over the Cartesian product of (instruction, demo-set) choices per predictor using Optuna's TPE sampler, optionally using minibatching to reduce evaluation cost.

### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `metric` | `Callable` | — | The metric function used to score candidate programs. |
| `prompt_model` | `Any \| None` | `dspy.settings.lm` | LM used for instruction proposal and data summarization. |
| `task_model` | `Any \| None` | `dspy.settings.lm` | LM used to execute the program being optimized. |
| `teacher_settings` | `dict \| None` | `{}` | Settings for the teacher model during bootstrapping. |
| `max_bootstrapped_demos` | `int` | `4` | Max bootstrapped demos per predictor. |
| `max_labeled_demos` | `int` | `4` | Max labeled demos per predictor. |
| `auto` | `"light" \| "medium" \| "heavy" \| None` | `"light"` | Preset run mode that sets `num_trials`, `valset` size, and candidate counts. |
| `num_candidates` | `int \| None` | `None` | Number of instruction/demo candidates (only when `auto=None`). |
| `num_threads` | `int \| None` | `None` | Threads for parallel evaluation. |
| `max_errors` | `int \| None` | `None` | Max errors before aborting evaluation. |
| `seed` | `int` | `9` | Random seed for reproducibility. |
| `init_temperature` | `float` | `0.5` | Temperature for instruction proposal. |
| `verbose` | `bool` | `False` | Verbose logging. |
| `track_stats` | `bool` | `True` | Attach trial logs and candidate programs to the returned program. |
| `log_dir` | `str \| None` | `None` | Directory to save candidate programs. |
| `metric_threshold` | `float \| None` | `None` | Threshold for accepting bootstrapped demos. |

### Auto Run Settings

When `auto` is set, the optimizer selects hyperparameters automatically:

```python
AUTO_RUN_SETTINGS = {
    "light":  {"n": 6,  "val_size": 100},
    "medium": {"n": 12, "val_size": 300},
    "heavy":  {"n": 18, "val_size": 1000},
}
```

- `n` controls the number of candidate instruction/demo sets.
- `val_size` caps the validation set size (via `create_minibatch`).
- When few-shot optimization is enabled, `num_instruct_candidates` is set to `n / 2` and `num_fewshot_candidates` to `n`, biasing budget toward demonstrations.

### Compile Workflow

The `compile` method orchestrates a three-step pipeline:

```mermaid
flowchart TD
    A["compile(student, trainset, ...)"] --> B["Validate params & set seeds"]
    B --> C["Set & validate datasets (trainset/valset split)"]
    C --> D["Set hyperparams from run mode (auto)"]
    D --> E["Initialize program & Evaluate"]

    E --> F["STEP 1: Bootstrap few-shot examples"]
    F --> G["STEP 2: Propose instruction candidates"]
    G --> H{"Zero-shot?"}
    H -->|Yes| I["Discard demos"]
    H -->|No| J["Keep demos"]
    I --> K["STEP 3: Optimize prompt parameters"]
    J --> K
    K --> L["Return best_program"]
```

#### Step 1 — Bootstrap Few-Shot Examples

`_bootstrap_fewshot_examples` calls `create_n_fewshot_demo_sets` (from `teleprompt/utils.py`) to generate `num_fewshot_candidates` distinct demonstration sets. Each set is produced by a `BootstrapFewShot` run with a different random shuffle of the training set. The first three sets are special: zero-shot, labels-only, and unshuffled few-shot.

#### Step 2 — Propose Instruction Candidates

`_propose_instructions` instantiates a [`GroundedProposer`](propose.md) configured with the requested awareness flags:

- `program_aware_proposer` — include program source code.
- `data_aware_proposer` — include a generated dataset summary.
- `tip_aware_proposer` — include a randomly selected prompting tip.
- `fewshot_aware_proposer` — include task demos in the proposal context.

It then calls `propose_instructions_for_program` to generate `num_instruct_candidates` instructions per predictor. The original instruction is always inserted at index `0` as a baseline.

#### Step 3 — Optimize Prompt Parameters

`_optimize_prompt_parameters` is the core Bayesian search loop. It:

1. Evaluates the **default program** as a baseline trial.
2. Creates an Optuna `study` with a `TPESampler(seed=seed, multivariate=True)`.
3. Defines an `objective` that, for each trial:
   - Deep-copies the program.
   - Selects an instruction index and (optionally) a demo-set index per predictor via `trial.suggest_categorical`.
   - Evaluates the candidate on a minibatch or the full valset.
   - Logs results and updates the best program.
4. Periodically performs **full evaluations** on the best-averaging minibatch program (`_perform_full_evaluation`), feeding those results back into the study as new trials.

### Minibatching Strategy

When `minibatch=True`, each trial evaluates on a small random subset (`minibatch_size`, default 35) of the validation set. Every `minibatch_full_eval_steps` trials, the program with the highest **average** minibatch score (computed by `get_program_with_highest_avg_score`) is fully evaluated on the entire validation set. This dramatically reduces the number of LM calls while still surfacing strong candidates.

```mermaid
sequenceDiagram
    participant Study as Optuna Study
    participant Obj as objective()
    participant Eval as Evaluate
    participant Full as Full Evaluation

    Study->>Obj: trial N
    Obj->>Obj: select instruction + demo indices
    Obj->>Eval: evaluate on minibatch
    Eval-->>Obj: minibatch score
    Obj->>Study: return score
    alt N % full_eval_steps == 0
        Study->>Full: pick best-avg program
        Full->>Eval: evaluate on full valset
        Eval-->>Full: full score
        Full->>Study: add_trial(full score)
    end
```

### LM Call Estimation

`_estimate_lm_calls` provides a breakdown of expected prompt-model and task-model calls, useful for budgeting:

- **Prompt model calls** = `10` (data summarizer) + `num_instruct_candidates × num_predictors` + `(num_predictors + 1)` (program-aware proposer).
- **Task model calls** (minibatch) = `minibatch_size × num_trials + len(valset) × full_eval_steps`.
- **Task model calls** (full) = `len(valset) × num_trials`.

### Trial Logging & Statistics

When `track_stats=True`, the returned `best_program` is annotated with:

- `trial_logs` — per-trial metadata (scores, chosen params, saved program paths).
- `score` — the best full-eval score.
- `prompt_model_total_calls` / `total_calls` — call counters.
- `mb_candidate_programs` — all minibatch-evaluated programs, sorted by score.
- `candidate_programs` — all fully-evaluated programs, sorted by score.

---

## BootstrapFewShotWithOptuna

`BootstrapFewShotWithOptuna` is a lighter-weight Bayesian optimizer. It first compiles a program with [`BootstrapFewShot`](teleprompt_core.md), then uses Optuna to select, for each predictor, a single demonstration from the bootstrapped demo pool.

### Purpose

This optimizer is useful when you want to prune a large pool of bootstrapped demonstrations down to the single best demo per predictor, using Bayesian search rather than random selection.

### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `metric` | `Callable` | — | The metric function. |
| `teacher_settings` | `dict \| None` | `{}` | Teacher model settings. |
| `max_bootstrapped_demos` | `int` | `4` | Max bootstrapped demos. |
| `max_labeled_demos` | `int` | `16` | Max labeled demos. |
| `max_rounds` | `int` | `1` | Bootstrap rounds. |
| `num_candidate_programs` | `int` | `16` | Number of Optuna trials. |
| `num_threads` | `int \| None` | `None` | Threads for evaluation. |

### Compile Workflow

```mermaid
flowchart TD
    A["compile(student, teacher, max_demos, trainset, valset)"] --> B["Reset student & teacher copies"]
    B --> C["Compile with BootstrapFewShot"]
    C --> D["Create Optuna study (maximize)"]
    D --> E["study.optimize(objective, n_trials=num_candidate_programs)"]
    E --> F["Return best program from best trial"]
```

The `objective` function:

1. Resets a copy of the student program.
2. For each predictor, suggests an integer `demo_index` into the compiled predictor's demo list.
3. Assigns the selected demo to the corresponding predictor.
4. Evaluates the program on the validation set and returns the score.
5. Stores the candidate program in `trial.set_user_attr("program", program2)`.

After optimization, the program attached to the best trial is returned.

---

## Component Interaction

The following diagram shows how the two optimizers interact with shared DSPy infrastructure.

```mermaid
graph LR
    subgraph Optimizers
        MIPRO["MIPROv2"]
        BFO["BootstrapFewShotWithOptuna"]
    end

    subgraph "teleprompt/utils.py"
        CNF["create_n_fewshot_demo_sets"]
        ECP["eval_candidate_program"]
        GPA["get_program_with_highest_avg_score"]
        CM["create_minibatch"]
    end

    subgraph "propose"
        GP["GroundedProposer"]
    end

    subgraph "evaluate"
        EV["Evaluate"]
    end

    subgraph "teleprompt_core"
        BFS["BootstrapFewShot"]
        LFS["LabeledFewShot"]
    end

    MIPRO --> CNF
    MIPRO --> ECP
    MIPRO --> GPA
    MIPRO --> CM
    MIPRO --> GP
    MIPRO --> EV

    BFO --> BFS
    BFO --> EV

    CNF --> BFS
    CNF --> LFS
```

---

## Data Flow

The end-to-end data flow for `MIPROv2` illustrates how raw data is transformed into an optimized program.

```mermaid
flowchart LR
    TS["Trainset"] --> BS["BootstrapFewShot"]
    BS --> DC["Demo Candidates<br/>(N sets per predictor)"]

    TS --> GP["GroundedProposer"]
    DC --> GP
    GP --> IC["Instruction Candidates<br/>(N per predictor)"]

    DC --> OPT["Optuna TPE Search"]
    IC --> OPT
    VS["Valset"] --> OPT
    OPT --> EV["Evaluate"]
    EV --> BP["Best Program"]

    BP --> OUT["Optimized dspy.Module"]
```

---

## Key Design Considerations

### Why Bayesian Optimization?

The search space of (instruction × demo-set) combinations grows exponentially with the number of predictors. Exhaustive search is infeasible. Bayesian optimization with TPE builds a surrogate model that focuses evaluations on promising regions, achieving good results with far fewer trials than random search.

### Minibatching Trade-off

Minibatching reduces the cost per trial but introduces noisy scores. `MIPROv2` mitigates this by periodically performing full evaluations on the best-averaging candidates and feeding those results back into the study, so the surrogate model learns from both cheap noisy signals and expensive accurate signals.

### Reproducibility

Both optimizers accept a `seed` and use it to seed Python's `random`, NumPy, and Optuna's sampler. `MIPROv2` also uses the seed when creating minibatches and shuffling demo sets, ensuring deterministic behavior given the same inputs.

### Zero-Shot Mode

When `max_bootstrapped_demos == 0` and `max_labeled_demos == 0`, `MIPROv2` runs in zero-shot mode: demos are discarded after being used to inform instruction proposal, and only instructions are optimized.

---

## Usage Examples

### MIPROv2 with Auto Mode

```python
import dspy
from dspy.teleprompt import MIPROv2

optimizer = MIPROv2(
    metric=my_metric,
    auto="light",
    num_threads=8,
)

optimized_program = optimizer.compile(
    student=my_program,
    trainset=trainset,
    valset=valset,
)
```

### MIPROv2 with Manual Hyperparameters

```python
optimizer = MIPROv2(
    metric=my_metric,
    auto=None,
    num_candidates=10,
)

optimized_program = optimizer.compile(
    student=my_program,
    trainset=trainset,
    num_trials=50,
    minibatch=True,
    minibatch_size=35,
)
```

### BootstrapFewShotWithOptuna

```python
from dspy.teleprompt import BootstrapFewShotWithOptuna

optimizer = BootstrapFewShotWithOptuna(
    metric=my_metric,
    num_candidate_programs=16,
)

optimized_program = optimizer.compile(
    student=my_program,
    trainset=trainset,
    max_demos=4,
)
```

---

## Related Modules

- [teleprompt_core.md](teleprompt_core.md) — Base `Teleprompter`, `BootstrapFewShot`, `LabeledFewShot`, and other core optimizers.
- [teleprompt_optimizers_instruction.md](teleprompt_optimizers_instruction.md) — Instruction-focused optimizers (`COPRO`, `SignatureOptimizer`).
- [teleprompt_optimizers_simba.md](teleprompt_optimizers_simba.md) — `SIMBA` optimizer.
- [propose.md](propose.md) — `GroundedProposer` and dataset summarization used for instruction proposal.
- [evaluate.md](evaluate.md) — The `Evaluate` engine used to score candidate programs.
- [predict_core.md](predict_core.md) — `Predict` and `Parameter` primitives that make up optimized programs.
- [primitives.md](primitives.md) — `Module`, `Example`, and `Prediction` primitives.
