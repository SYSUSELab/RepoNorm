# Evaluate Module

## Overview

The `evaluate` module provides the core evaluation infrastructure for DSPy programs. It allows developers to measure the performance of a DSPy program against a labeled development set (`devset`) using a user-supplied metric function. Evaluation can run in parallel across threads, display progress bars, render result tables, and gracefully handle failures.

The module also ships a set of **automatic evaluation metrics** — LLM-based judges that compute semantic quality scores (recall, precision, F1, completeness, groundedness) without requiring hand-written metric functions.

### Purpose

- **Measure program quality**: Run a `dspy.Module` over a dataset and aggregate per-example scores into an overall score.
- **Parallelize evaluation**: Use `ParallelExecutor` to evaluate examples concurrently with error isolation and straggler handling.
- **Visualize results**: Optionally render a pandas DataFrame table of per-example results in the console or an IPython notebook.
- **Provide ready-made metrics**: Offer LLM-judge metrics for semantic comparison of system responses against ground truth or retrieved context.

## Architecture

The module is composed of two sub-modules:

| Sub-module | Responsibility | Documentation |
| --- | --- | --- |
| **Evaluation Engine** | The `Evaluate` class and `EvaluationResult` container that drive dataset evaluation, parallelism, and result display. | [evaluate_evaluation_engine.md](evaluate_evaluation_engine.md) |
| **Auto Evaluation Metrics** | LLM-judge metrics (`SemanticF1`, `CompleteAndGrounded`, and their underlying signatures) for automatic quality scoring. | [evaluate_auto_evaluation.md](evaluate_auto_evaluation.md) |

```mermaid
graph TD
    subgraph evaluate["evaluate module"]
        E["Evaluate<br/>(evaluate.py)"]
        ER["EvaluationResult<br/>(evaluate.py)"]
        SF1["SemanticF1<br/>(auto_evaluation.py)"]
        CG["CompleteAndGrounded<br/>(auto_evaluation.py)"]
        SIG["Signatures:<br/>SemanticRecallPrecision,<br/>AnswerCompleteness,<br/>AnswerGroundedness, ..."]
    end

    E -->|returns| ER
    E -->|uses metric| SF1
    E -->|uses metric| CG
    SF1 --> SIG
    CG --> SIG
```

## How the Module Fits into the System

The `evaluate` module sits at the top of the DSPy workflow, consuming programs and datasets produced elsewhere and producing scores used by optimizers.

```mermaid
graph LR
    subgraph Inputs
        P["dspy.Module<br/>(predict_core, predict_advanced)"]
        D["dspy.Example devset<br/>(datasets)"]
        M["Metric function<br/>(user or auto_evaluation)"]
    end

    E["Evaluate"]

    subgraph Dependencies
        PE["ParallelExecutor<br/>(utils)"]
        PRED["Prediction<br/>(primitives)"]
        CB["with_callbacks<br/>(utils)"]
        COT["ChainOfThought<br/>(predict_core)"]
    end

    subgraph Outputs
        RES["EvaluationResult<br/>(score + results)"]
    end

    P --> E
    D --> E
    M --> E
    E --> PE
    E --> PRED
    E --> CB
    E --> RES
    RES -->|score used by| OPT["Teleprompters / Optimizers<br/>(teleprompt_*)"]
    SF1["SemanticF1 / CompleteAndGrounded"] --> COT
    SF1 -->|metric| E
```

### Key Relationships

- **`dspy.Module`** ([predict_core.md](predict_core.md)): The program being evaluated. `Evaluate.__call__` invokes `program(**example.inputs())` for each example.
- **`dspy.Example`** ([datasets.md](datasets.md)): The dataset element type. Each example provides `.inputs()` and ground-truth fields.
- **`ParallelExecutor`** ([utils.md](utils.md)): Handles thread-pool execution, error counting against `max_errors`, straggler timeouts, and progress reporting.
- **`Prediction`** ([primitives.md](primitives.md)): `EvaluationResult` subclasses `Prediction`, inheriting score-based arithmetic and comparison behavior.
- **`with_callbacks`** ([utils.md](utils.md)): Decorates `Evaluate.__call__` so evaluation participates in the global callback system.
- **`ChainOfThought`** ([predict_core.md](predict_core.md)): Used by the auto-evaluation metrics to run LLM-judge signatures.

## High-Level Functionality

### Evaluation Engine

The `Evaluate` class is the primary entry point. It is configured with a `devset`, a `metric`, and options such as `num_threads`, `display_progress`, `display_table`, `max_errors`, `provide_traceback`, and `failure_score`. Calling an `Evaluate` instance with a program runs the program over the dataset in parallel, applies the metric to each `(example, prediction)` pair, and returns an `EvaluationResult` containing the aggregate percentage score and the per-example results.

See [evaluate_evaluation_engine.md](evaluate_evaluation_engine.md) for details.

### Auto Evaluation Metrics

The `auto_evaluation` sub-module provides LLM-based metrics that require no hand-written scoring logic:

- **`SemanticF1`** — computes F1 between a system response and ground truth using recall/precision judged by an LLM.
- **`CompleteAndGrounded`** — computes F1 between answer completeness (vs. ground truth) and groundedness (vs. retrieved context).

Both are `dspy.Module` subclasses that can be passed directly as the `metric` argument to `Evaluate`.

See [evaluate_auto_evaluation.md](evaluate_auto_evaluation.md) for details.

## Typical Usage

```python
import dspy
from dspy.evaluate import Evaluate

# Hand-written metric
def exact_match(example, pred, trace=None):
    return example.answer.lower() == pred.answer.lower()

evaluator = Evaluate(
    devset=my_devset,
    metric=exact_match,
    num_threads=8,
    display_progress=True,
    display_table=5,
)

result = evaluator(my_program)
print(result.score)   # e.g. 67.3
print(result.results) # list of (example, prediction, score)
```

```python
from dspy.evaluate import Evaluate
from dspy.evaluate.auto_evaluation import SemanticF1

# LLM-judge metric
evaluator = Evaluate(devset=my_devset, metric=SemanticF1(), display_progress=True)
result = evaluator(my_program)
```
