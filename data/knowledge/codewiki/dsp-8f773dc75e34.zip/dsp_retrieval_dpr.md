# dsp_retrieval_dpr

## Introduction

The `dsp_retrieval_dpr` module provides the **text tokenization and normalization primitives** used by DSPy's retrieval stack. It is a faithful port of the tokenizer implementation from Facebook Research's [Dense Passage Retrieval (DPR)](https://github.com/facebookresearch/DPR) project, adapted for use inside DSPy.

The module's core responsibility is to convert raw text into a structured, annotated token representation (`Tokens`) and to provide utilities for answer matching and localization (`has_answer`, `locate_answers`). These primitives are the foundation for retrieval-oriented tasks such as passage ranking, answer span detection, and n-gram overlap scoring.

> **Note:** This module is a *utility* layer. It does not perform retrieval itself. For the retrieval components that consume these primitives, see [dsp_retrieval_colbertv2](dsp_retrieval_colbertv2.md) and the broader [retrievers](retrievers.md) module.

---

## Module Structure

The module lives at `dspy/dsp/utils/dpr.py` and exposes three core classes plus a set of module-level helper functions.

| Component | Kind | Purpose |
|-----------|------|---------|
| `Tokens` | Class | Structured representation of a tokenized text with optional annotations (POS, lemma, NER). |
| `Tokenizer` | Abstract base class | Defines the tokenizer interface (`tokenize`, `shutdown`). |
| `SimpleTokenizer` | Concrete class | Regex-based tokenizer that splits text into alphanumeric and non-whitespace tokens. |
| `has_answer` | Function | Checks whether any tokenized answer appears in a text. |
| `locate_answers` | Function | Returns character offsets of each answer occurrence in a text. |
| `DPR_tokenize` / `DPR_normalize` | Functions | Convenience wrappers around a module-level `SimpleTokenizer` instance. |
| `strip_accents` | Function | Removes diacritic marks from text. |

---

## Architecture

The module is intentionally self-contained, with a single external dependency (`regex`) and the Python standard library. It sits at the bottom of the retrieval dependency stack.

```mermaid
graph TD
    subgraph "dsp_retrieval_dpr (dspy/dsp/utils/dpr.py)"
        Tokens["Tokens"]
        Tokenizer["Tokenizer (ABC)"]
        SimpleTokenizer["SimpleTokenizer"]
        Helpers["has_answer / locate_answers / DPR_tokenize / DPR_normalize / strip_accents"]
    end

    Tokenizer -->|inherits| SimpleTokenizer
    SimpleTokenizer -->|produces| Tokens
    Helpers -->|uses| SimpleTokenizer
    Helpers -->|uses| Tokens

    subgraph "External"
        Regex["regex (PyPI)"]
        Unicodedata["unicodedata (stdlib)"]
    end

    SimpleTokenizer -->|compiles patterns with| Regex
    Helpers -->|normalizes with| Unicodedata

    subgraph "Consumers"
        ColBERT["dsp_retrieval_colbertv2"]
        Retrievers["retrievers"]
    end

    Helpers -.->|tokenization primitives| ColBERT
    Helpers -.->|tokenization primitives| Retrievers
```

### Class Hierarchy

```mermaid
classDiagram
    class Tokenizer {
        <<abstract>>
        +tokenize(text) Tokens
        +shutdown()
        +__del__()
    }
    class SimpleTokenizer {
        +ALPHA_NUM : str
        +NON_WS : str
        +__init__(**kwargs)
        +tokenize(text) Tokens
    }
    class Tokens {
        +TEXT = 0
        +TEXT_WS = 1
        +SPAN = 2
        +POS = 3
        +LEMMA = 4
        +NER = 5
        +data : list
        +annotators : set
        +opts : dict
        +__len__()
        +slice(i, j) Tokens
        +untokenize() str
        +words(uncased) list
        +offsets() list
        +pos() list
        +lemmas() list
        +entities() list
        +ngrams(n, uncased, filter_fn, as_strings) list
        +entity_groups() list
    }

    Tokenizer <|-- SimpleTokenizer
    SimpleTokenizer ..> Tokens : creates
```

---

## Core Components

### `Tokens`

`Tokens` is the central data structure. Each token is stored as a tuple indexed by the class-level constants:

| Index | Constant | Meaning |
|-------|----------|---------|
| 0 | `TEXT` | The token text |
| 1 | `TEXT_WS` | The token text *including* trailing whitespace |
| 2 | `SPAN` | `(start, end)` character offsets |
| 3 | `POS` | Part-of-speech tag (optional) |
| 4 | `LEMMA` | Lemma (optional) |
| 5 | `NER` | Named-entity tag (optional) |

Key methods:

- **`slice(i, j)`** — Returns a shallow copy of the `Tokens` restricted to `[i, j)`. Used internally by `entity_groups`.
- **`untokenize()`** — Reconstructs the original text by joining `TEXT_WS` fields and stripping.
- **`words(uncased=False)`** — Returns the list of token texts, optionally lowercased.
- **`offsets()`** — Returns the list of `[start, end)` character spans.
- **`pos()` / `lemmas()` / `entities()`** — Return annotation lists, or `None` if the corresponding annotator was not enabled.
- **`ngrams(n, uncased, filter_fn, as_strings)`** — Generates all n-grams up to length `n`, with optional filtering and string/list output.
- **`entity_groups()`** — Groups consecutive tokens sharing the same NER tag into `(text, tag)` tuples.

### `Tokenizer` (Abstract Base)

A minimal interface defining `tokenize(text) -> Tokens`. It also provides a no-op `shutdown()` and a `__del__` that calls `shutdown()`, allowing subclasses to release resources (e.g., subprocesses) on garbage collection.

### `SimpleTokenizer`

The only concrete tokenizer. It compiles a single regex combining two patterns:

- `ALPHA_NUM = r"[\p{L}\p{N}\p{M}]+"` — runs of letters, numbers, and combining marks.
- `NON_WS = r"[^\p{Z}\p{C}]"` — any single non-whitespace, non-control character.

The regex is compiled with `IGNORECASE | UNICODE | MULTILINE`. During `tokenize`, it iterates over matches, capturing each token's text, its span, and the whitespace that follows it (up to the next match). Annotators are **not** supported — passing them logs a warning and they are ignored.

### Module-Level Helpers

- **`has_answer(tokenized_answers, text)`** — Normalizes `text` via `DPR_normalize` and checks whether any tokenized answer appears as a contiguous subsequence.
- **`locate_answers(tokenized_answers, text)`** — Tokenizes the text and returns `(offset, endpos)` character ranges for each answer occurrence.
- **`DPR_tokenize(text)`** — Tokenizes `text` after NFD Unicode normalization, using the module-level `STokenizer` singleton.
- **`DPR_normalize(text)`** — Returns the uncased word list of `DPR_tokenize(text)`.
- **`strip_accents(text)`** — Removes combining marks (`Mn` category) after NFD normalization.

---

## Data Flow

The following diagram shows how raw text flows through tokenization, normalization, and answer matching.

```mermaid
flowchart LR
    Raw["Raw text"] --> NFD["unicodedata.normalize('NFD', text)"]
    NFD --> ST["STokenizer.tokenize()"]
    ST --> TokensObj["Tokens object"]

    TokensObj --> Words["words(uncased=True)"]
    TokensObj --> Offsets["offsets()"]
    TokensObj --> Ngrams["ngrams()"]

    Words --> Normalize["DPR_normalize()"]
    Words --> HasAnswer["has_answer()"]
    Offsets --> Locate["locate_answers()"]

    Raw --> StripAccents["strip_accents()"]
```

### Answer Localization Flow

```mermaid
sequenceDiagram
    participant Caller
    participant locate as locate_answers
    participant DPR as DPR_tokenize
    participant Tok as Tokens

    Caller->>locate: locate_answers(tokenized_answers, text)
    locate->>DPR: DPR_tokenize(text)
    DPR->>Tok: SimpleTokenizer.tokenize()
    Tok-->>DPR: Tokens
    DPR-->>locate: Tokens
    locate->>Tok: words(uncased=True)
    locate->>Tok: offsets()
    Note over locate: Slide window over text words,<br/>match against each answer's words
    locate-->>Caller: [(offset, endpos), ...]
```

---

## Integration with the Retrieval Stack

`dsp_retrieval_dpr` provides the low-level tokenization used by retrieval components. The retrieval components themselves live in sibling modules:

- **[dsp_retrieval_colbertv2](dsp_retrieval_colbertv2.md)** — `ColBERTv2`, `ColBERTv2RetrieverLocal`, and `ColBERTv2RerankerLocal` perform actual passage retrieval and reranking. They rely on tokenization primitives for query/document processing.
- **[retrievers](retrievers.md)** — `Retrieve` and `Embeddings` are the high-level DSPy retriever modules that orchestrate retrieval via `dspy.settings.rm` or an embedder.

```mermaid
graph TD
    subgraph "High-level retrieval"
        Retrieve["Retrieve (retrievers)"]
        Embeddings["Embeddings (retrievers)"]
    end
    subgraph "Retrieval backends"
        ColBERT["ColBERTv2 / Local (dsp_retrieval_colbertv2)"]
    end
    subgraph "Tokenization primitives"
        DPR["dsp_retrieval_dpr"]
    end

    Retrieve --> ColBERT
    Embeddings --> ColBERT
    ColBERT -.->|tokenization| DPR
```

---

## Design Notes & Constraints

- **Single annotator support:** `SimpleTokenizer` only tokenizes; it does not produce POS, lemma, or NER annotations. The `Tokens` API still exposes accessors for these, returning `None` when unavailable, preserving compatibility with the original DPR interface.
- **Unicode-aware:** All patterns use Unicode property classes (`\p{L}`, `\p{N}`, `\p{M}`, `\p{Z}`, `\p{C}`), making the tokenizer language-agnostic.
- **Singleton tokenizer:** `STokenizer = SimpleTokenizer()` is instantiated at import time and reused by `DPR_tokenize`/`DPR_normalize` to avoid repeated regex compilation.
- **NFD normalization:** Both `DPR_tokenize` and `strip_accents` apply NFD normalization, ensuring consistent handling of accented characters.
- **License:** Ported from Facebook Research's DPR under its original license (see the module docstring).

---

## Related Modules

| Module | Relationship |
|--------|--------------|
| [dsp_retrieval_colbertv2](dsp_retrieval_colbertv2.md) | Retrieval backends that consume tokenization primitives. |
| [retrievers](retrievers.md) | High-level retriever modules (`Retrieve`, `Embeddings`). |
| [dsp_utils](dsp_utils.md) | Shared DSPy utilities (`Settings`, `dotdict`). |
| [datasets](datasets.md) | Dataset loaders (e.g., HotPotQA) that may use answer matching. |
