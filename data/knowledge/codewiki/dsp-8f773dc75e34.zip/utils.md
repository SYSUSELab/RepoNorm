# Utils Module

## Overview

The `utils` module provides a collection of cross-cutting, reusable utilities that support the rest of the DSPy framework. Unlike the higher-level modules (e.g., `predict_core`, `teleprompt_core`), these utilities are not tied to a single feature area. Instead, they supply foundational infrastructure used throughout DSPy for:

- **Observability** — callback hooks and logging streams that let users observe and instrument module, LM, adapter, tool, and evaluation execution.
- **Concurrency** — a thread-pool based parallel executor and a dynamic batching helper.
- **Testing** — dummy language models and vectorizers for deterministic unit tests.
- **Resource accounting** — a usage tracker that aggregates token usage across LM calls.
- **Determinism & identity** — a stable object hasher used for caching and fingerprinting.
- **Error reporting** — a structured exception type for adapter parsing failures.

These utilities are deliberately low-level and dependency-light so that they can be imported by nearly every other module without introducing circular dependencies.

## Architecture

The module is organized into a set of independent, single-responsibility files. The diagram below shows the components and their primary relationships.

```mermaid
graph TD
    subgraph utils["dspy/utils"]
        CB[callback.py<br/>BaseCallback, with_callbacks]
        DU[dummies.py<br/>DummyLM, DummyVectorizer]
        EX[exceptions.py<br/>AdapterParseError]
        HA[hasher.py<br/>Hasher]
        LO[logging_utils.py<br/>DSPyLoggingStream]
        PA[parallelizer.py<br/>ParallelExecutor]
        UN[unbatchify.py<br/>Unbatchify]
        UT[usage_tracker.py<br/>UsageTracker]
    end

    CB -->|decorates methods of| LM[dspy.LM]
    CB -->|decorates methods of| AD[dspy.Adapter]
    CB -->|decorates methods of| EV[dspy.Evaluate]
    CB -->|decorates methods of| MD[dspy.Module]
    CB -->|decorates methods of| TL[dspy.Tool]

    DU -->|subclass of| LM
    DU -->|uses| CA[ChatAdapter]

    PA -->|reads/writes| ST[dsp_utils_settings<br/>Settings / thread_local_overrides]
    UT -->|reads/writes| ST
    LO -->|configures| LOG[Python logging]

    EX -->|references| SG[signatures_signature<br/>Signature]
```

### Component Interaction Overview

```mermaid
flowchart LR
    User[User Code] -->|configures callbacks| Settings[Settings]
    Settings -->|global callbacks| CB[with_callbacks]
    User -->|passes callbacks| LM[LM / Adapter / Module]
    LM -->|instance callbacks| CB
    CB -->|on_lm_start / on_lm_end| User

    User -->|track_usage context| UT[UsageTracker]
    LM -->|add_usage| UT

    User -->|ParallelExecutor.execute| PA[ParallelExecutor]
    PA -->|thread-local overrides| Settings
```

## Sub-modules

The `utils` module is split into the following documented sub-modules. Each sub-module groups closely related components.

| Sub-module | Components | Purpose |
|------------|------------|---------|
| [utils_callbacks](utils_callbacks.md) | `BaseCallback`, `with_callbacks` | Callback hook system for observing DSPy execution. |
| [utils_dummies](utils_dummies.md) | `DummyLM`, `DummyVectorizer` | Deterministic test doubles for LMs and retrieval. |
| [utils_concurrency](utils_concurrency.md) | `ParallelExecutor`, `Unbatchify` | Parallel execution and dynamic batching helpers. |
| [utils_usage_tracking](utils_usage_tracking.md) | `UsageTracker`, `track_usage` | Aggregation of LM token usage within a context. |
| [utils_logging](utils_logging.md) | `DSPyLoggingStream`, `disable_logging`, `enable_logging`, `configure_dspy_loggers` | Event logging stream and logger configuration. |
| [utils_hasher](utils_hasher.md) | `Hasher` | Stable hashing of arbitrary Python objects. |
| [utils_exceptions](utils_exceptions.md) | `AdapterParseError` | Structured exception for adapter parse failures. |

## How the Utilities Fit into DSPy

The utilities are consumed by many other modules. The table below summarizes the most important integration points.

| Utility | Consumed by | Reference |
|---------|-------------|-----------|
| `BaseCallback` / `with_callbacks` | `clients_core` (`LM`), `adapters` (`Adapter`), `evaluate` (`Evaluate`), `primitives` (`Module`), `adapter_types` (`Tool`) | [clients_core.md](clients_core.md), [adapters.md](adapters.md), [evaluate.md](evaluate.md), [primitives.md](primitives.md) |
| `DummyLM` / `DummyVectorizer` | Test suites across all modules | [clients_core.md](clients_core.md) |
| `ParallelExecutor` | `evaluate` (`Evaluate`), `teleprompt_*` optimizers | [evaluate.md](evaluate.md), [teleprompt_core.md](teleprompt_core.md) |
| `UsageTracker` | `clients_core` (`LM.forward`), `dsp_utils` (`Settings`) | [clients_core.md](clients_core.md), [dsp_utils.md](dsp_utils.md) |
| `AdapterParseError` | `adapters` implementations | [adapters.md](adapters.md) |
| `Hasher` | Caching and fingerprinting layers | [clients_core.md](clients_core.md) |
| `DSPyLoggingStream` | Global DSPy logging configuration | — |

## Design Principles

1. **Isolation from feature modules.** Utilities avoid importing high-level DSPy modules at import time where possible, deferring imports into function bodies to prevent circular dependencies (e.g., `ParallelExecutor` imports `settings` lazily).
2. **Thread-safety.** Concurrency primitives (`ParallelExecutor`, `Unbatchify`) and the `UsageTracker` are designed to be safe under multi-threaded execution, coordinating with the thread-local override mechanism in [dsp_utils](dsp_utils.md).
3. **Determinism for testing.** `DummyLM` and `DummyVectorizer` produce reproducible outputs so that tests do not depend on network calls or randomness.
4. **Composability.** Callbacks, usage tracking, and logging are all opt-in and can be layered independently.
