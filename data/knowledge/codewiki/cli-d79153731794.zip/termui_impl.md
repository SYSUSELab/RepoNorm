# termui_impl Module

## Introduction

The `termui_impl` module (`src/click/_termui_impl.py`) contains the concrete implementations of Click's terminal user interface (TUI) features. To keep Click's import time low, infrequently used functionality is isolated in this module and imported lazily only when needed.

The module provides two primary public components:

- **`ProgressBar`** — a generic, iterable-aware progress bar that renders live progress to a terminal.
- **`Editor`** — a helper that opens the user's preferred text editor to edit a block of text.

In addition, the module implements a set of supporting terminal utilities used by the broader Click framework:

- **Pager functions** (`pager`, `_pipepager`, `_tempfilepager`, `_nullpager`) — page long text output through an external pager program.
- **`open_url`** — open a URL or file location in the platform's default handler.
- **`getchar` / `raw_terminal`** — cross-platform raw terminal character reading.
- **`_translate_ch_to_exc`** — translate control characters into Python exceptions.

This module belongs to the **user_interface_and_presentation** group of the Click architecture, alongside [formatting](formatting.md) and [shell_completion](shell_completion.md).

---

## Architecture Overview

The module sits between Click's high-level public API and the low-level platform/IO foundation. It depends heavily on the [platform_and_io_foundation](platform_and_io_foundation.md) module for cross-platform stream handling and on [exceptions](exceptions.md) for error reporting.

```mermaid
graph TD
    subgraph "user_interface_and_presentation"
        TI["termui_impl<br/>(ProgressBar, Editor)"]
        FMT["formatting<br/>(HelpFormatter)"]
        SC["shell_completion<br/>(ShellComplete)"]
    end

    subgraph "platform_and_io_foundation"
        COMPAT["_compat<br/>(isatty, open_stream,<br/>strip_ansi, term_len,<br/>get_best_encoding)"]
        UTILS["utils<br/>(echo)"]
        WINCON["_winconsole"]
    end

    subgraph "exceptions"
        EXC["ClickException"]
    end

    TI --> COMPAT
    TI --> UTILS
    TI --> EXC
    COMPAT --> WINCON
```

### Key Dependencies

| Dependency | Source | Purpose |
| --- | --- | --- |
| `_default_text_stdout` | [platform_and_io_foundation](platform_and_io_foundation.md) | Resolve the default text stdout stream |
| `isatty` | [platform_and_io_foundation](platform_and_io_foundation.md) | Detect whether a stream is an interactive terminal |
| `open_stream` | [platform_and_io_foundation](platform_and_io_foundation.md) | Open files/streams with encoding handling |
| `strip_ansi` | [platform_and_io_foundation](platform_and_io_foundation.md) | Remove ANSI escape codes from text |
| `term_len` | [platform_and_io_foundation](platform_and_io_foundation.md) | Measure visible terminal width of a string |
| `get_best_encoding` | [platform_and_io_foundation](platform_and_io_foundation.md) | Determine the best encoding for a stream |
| `echo` | [platform_and_io_foundation](platform_and_io_foundation.md) | Cross-platform, color-aware output |
| `ClickException` | [exceptions](exceptions.md) | Report editor failures to the user |

---

## Component Relationships

```mermaid
classDiagram
    class ProgressBar {
        +fill_char: str
        +empty_char: str
        +bar_template: str
        +info_sep: str
        +hidden: bool
        +show_eta: bool
        +show_percent: bool
        +show_pos: bool
        +item_show_func: Callable
        +label: str
        +file: TextIO
        +color: bool
        +update_min_steps: int
        +width: int
        +autowidth: bool
        +length: int
        +pos: int
        +finished: bool
        +__enter__()
        +__exit__()
        +__iter__()
        +__next__()
        +update(n_steps, current_item)
        +finish()
        +render_progress()
        +render_finish()
        +generator()
        +format_bar()
        +format_eta()
        +format_pos()
        +format_pct()
        +format_progress_line()
    }

    class Editor {
        +editor: str
        +env: Mapping
        +require_save: bool
        +extension: str
        +get_editor() str
        +edit_file(filename)
        +edit(text) AnyStr
    }

    class PagerFunctions {
        <<module functions>>
        +pager(generator, color)
        +_pipepager(generator, cmd, color)
        +_tempfilepager(generator, cmd, color)
        +_nullpager(stream, generator, color)
    }

    class TerminalHelpers {
        <<module functions>>
        +open_url(url, wait, locate)
        +getchar(echo)
        +raw_terminal()
        +_translate_ch_to_exc(ch)
    }
```

---

## ProgressBar

`ProgressBar` is a generic class (`ProgressBar[V]`) that renders a live, updating progress bar to a terminal. It is designed to be used as a context manager and as an iterable.

### Construction

The constructor accepts a rich set of options controlling appearance and behavior:

| Parameter | Default | Description |
| --- | --- | --- |
| `iterable` | `None` | The iterable to wrap. If `None`, `length` is required. |
| `length` | `None` | Total number of steps. Inferred via `operator.length_hint` if omitted. |
| `fill_char` | `"#"` | Character used for the filled portion of the bar. |
| `empty_char` | `" "` | Character used for the empty portion of the bar. |
| `bar_template` | `"%(bar)s"` | Template for the rendered line (`label`, `bar`, `info` keys). |
| `info_sep` | `"  "` | Separator between info bits (position, percent, ETA). |
| `hidden` | `False` | Suppress all rendering. |
| `show_eta` | `True` | Show estimated time remaining. |
| `show_percent` | `None` | Show percentage (auto-enabled when length is known and `show_pos` is off). |
| `show_pos` | `False` | Show current position (`pos/length`). |
| `item_show_func` | `None` | Callable mapping the current item to a display string. |
| `label` | `None` | Static label shown in the bar template. |
| `file` | `None` | Output stream; defaults to text stdout, falling back to `StringIO`. |
| `color` | `None` | Force color on/off. |
| `update_min_steps` | `1` | Minimum steps before a re-render occurs. |
| `width` | `30` | Bar width; `0` enables auto-width. |

### Lifecycle and Usage

`ProgressBar` must be used within a `with` block. Entering the block sets `entered = True` and performs an initial render; exiting calls `render_finish()`.

```mermaid
sequenceDiagram
    participant User
    participant PB as ProgressBar
    participant Stream as Output Stream

    User->>PB: with ProgressBar(iterable) as bar
    PB->>PB: __enter__() -> entered=True
    PB->>Stream: render_progress()
    loop For each item
        User->>PB: iterate (__iter__/__next__)
        PB->>PB: generator() yields item
        PB->>PB: update(1)
        PB->>Stream: render_progress()
    end
    PB->>PB: finish()
    PB->>Stream: render_progress()
    User->>PB: exit with block
    PB->>PB: __exit__() -> render_finish()
    PB->>Stream: AFTER_BAR
```

### Iteration Model

The class supports three iteration styles, all backed by the `generator()` method:

- **`for item in bar`** — calls `__iter__`, which requires the `with` block and returns `generator()`.
- **`next(bar)`** — calls `__next__`, which delegates to `next(iter(self))`.
- **`bar.update(n)`** — manual advancement for non-iterable use cases.

> **Note:** The iterator interface relies on `generator()` being a simple, re-entry-safe generator that creates no additional state. Any change to `generator()` must be evaluated against both `iter(bar)` and `next(bar)`.

### Rendering Pipeline

Rendering is driven by `render_progress()`, which builds the output line and only writes when the line changes (tracked via `_last_line`).

```mermaid
flowchart TD
    A[render_progress] --> B{hidden?}
    B -->|yes| Z[return]
    B -->|no| C{isatty?}
    C -->|no| D[Echo label once if changed]
    C -->|yes| E{autowidth?}
    E -->|yes| F[Recompute width from terminal size]
    E -->|no| G[Use fixed width]
    F --> H[Build buffer: BEFORE_BAR + line + padding]
    G --> H
    H --> I{line changed?}
    I -->|yes| J[echo line, flush]
    I -->|no| Z
```

The line itself is produced by `format_progress_line()`, which composes:

- `format_bar()` — the visual bar (filled/empty chars, or an animated "bouncing" indicator when length is unknown).
- `format_pos()` — `pos` or `pos/length`.
- `format_pct()` — percentage.
- `format_eta()` — estimated time remaining (`HH:MM:SS` or `Nd HH:MM:SS`).
- `item_show_func(current_item)` — optional per-item info.

### ETA Calculation

ETA is computed from a rolling average (`self.avg`, capped at 7 samples) of time-per-step. `make_step()` updates this average at most once per second and sets `eta_known` only when `length` is known.

### Terminal Control Sequences

The module defines platform-specific control sequences:

| Constant | Windows | POSIX |
| --- | --- | --- |
| `BEFORE_BAR` | `"\r"` | `"\r\033[?25l"` (carriage return + hide cursor) |
| `AFTER_BAR` | `"\n"` | `"\033[?25h\n"` (show cursor + newline) |

---

## Editor

`Editor` opens the user's preferred text editor to edit a block of text, returning the edited content.

### Editor Resolution

`get_editor()` resolves the editor in the following priority order:

```mermaid
flowchart TD
    A[get_editor] --> B{self.editor set?}
    B -->|yes| C[Return self.editor]
    B -->|no| D{VISUAL env?}
    D -->|yes| E[Return VISUAL]
    D -->|no| F{EDITOR env?}
    F -->|yes| G[Return EDITOR]
    F -->|no| H{Windows?}
    H -->|yes| I[Return notepad]
    H -->|no| J{sensible-editor/vim/nano available?}
    J -->|yes| K[Return first found]
    J -->|no| L[Return vi]
```

### Editing Flow

`edit(text)` writes the text to a temporary file, invokes the editor via `edit_file()`, and reads back the result.

```mermaid
sequenceDiagram
    participant Caller
    participant Editor
    participant TempFile as Temp File
    participant Process as Editor Process

    Caller->>Editor: edit(text)
    Editor->>Editor: Normalize text (newlines, encoding)
    Editor->>TempFile: Write data (mkstemp)
    Editor->>TempFile: Backdate mtime by 2s
    Editor->>Editor: edit_file(name)
    Editor->>Process: Popen(editor "filename")
    Process-->>Editor: exit code
    alt exit code != 0
        Editor->>Caller: raise ClickException
    end
    Editor->>TempFile: Read back content
    Editor->>Editor: Check mtime (require_save)
    Editor->>TempFile: unlink
    Editor-->>Caller: edited text or None
```

Key behaviors:

- **Encoding normalization:** On Windows, `\n` is converted to `\r\n` and encoded as `utf-8-sig`; elsewhere, `utf-8` is used. On read-back, `utf-8-sig` is decoded and `\r\n` normalized to `\n`.
- **`require_save`:** If `True` and the file's mtime is unchanged after editing, `edit()` returns `None` (indicating no save occurred).
- **mtime backdating:** The file's mtime is set 2 seconds in the past to work around low-resolution filesystems (e.g., FAT32, older macOS).
- **Error handling:** A non-zero editor exit code or an `OSError` raises a `ClickException` (see [exceptions](exceptions.md)).

---

## Pager Functions

The pager subsystem selects an appropriate strategy for paging long text output.

```mermaid
flowchart TD
    A[pager] --> B{stdin & stdout are TTYs?}
    B -->|no| N[_nullpager]
    B -->|yes| C{PAGER env set?}
    C -->|yes| D{Windows?}
    D -->|yes| T[_tempfilepager]
    D -->|no| P[_pipepager]
    C -->|no| E{TERM is dumb/emacs?}
    E -->|yes| N
    E -->|no| F{Windows or OS2?}
    F -->|yes| T2[_tempfilepager 'more <']
    F -->|no| G{less available?}
    G -->|yes| P2[_pipepager 'less']
    G -->|no| H{more available?}
    H -->|yes| P3[_pipepager 'more']
    H -->|no| N
```

| Function | Strategy |
| --- | --- |
| `_pipepager` | Pipes text to an external program via `subprocess.Popen`. Supports color when piping to `less` with `-R`/`-r`. |
| `_tempfilepager` | Writes text to a temp file and invokes a program on it. Used on Windows and as a fallback. |
| `_nullpager` | Ultimate fallback: writes text directly to the stream. |

> **Color handling:** When `color` is `None` and the pager is `less`, the module inspects `LESS` flags and enables color if `-R`/`-r` is present, otherwise sets `LESS=-R`. When color is disabled, ANSI codes are stripped via `strip_ansi`.

---

## Terminal Helpers

### `open_url`

Opens a URL or file location using the platform's default handler. Behavior varies by platform:

| Platform | Command | Notes |
| --- | --- | --- |
| macOS (`darwin`) | `open` | Supports `-W` (wait) and `-R` (locate). |
| Windows | `start` / `explorer /select` | Uses `os.system`. |
| Cygwin | `cygstart` | Supports `-w` (wait). |
| Other (Linux) | `xdg-open` | Falls back to `webbrowser.open` for HTTP(S) URLs. |

### `getchar` and `raw_terminal`

These provide cross-platform raw terminal input:

- **Windows:** Uses `msvcrt.getwch`/`getwche`. Handles special-key sequences (`\x00`, `\xe0`) by reading a second character. `raw_terminal` is a no-op context manager yielding `-1`.
- **POSIX:** Uses `termios`/`tty` to set the terminal to raw mode. `raw_terminal` yields the file descriptor and restores settings on exit. Falls back to `/dev/tty` when stdin is not a TTY.

### `_translate_ch_to_exc`

Translates control characters into Python exceptions:

| Character | Platform | Exception |
| --- | --- | --- |
| `\x03` (Ctrl+C) | All | `KeyboardInterrupt` |
| `\x04` (Ctrl+D) | POSIX | `EOFError` |
| `\x1a` (Ctrl+Z) | Windows | `EOFError` |

---

## Data Flow Summary

```mermaid
flowchart LR
    subgraph Input
        ITER[Iterable / Text]
    end

    subgraph termui_impl
        PB[ProgressBar]
        ED[Editor]
        PG[Pager]
    end

    subgraph Foundation
        ECHO[echo]
        COMPAT[_compat helpers]
    end

    subgraph Output
        TERM[Terminal / Stream]
        EXT[External Process]
    end

    ITER --> PB
    ITER --> ED
    ITER --> PG
    PB --> ECHO
    ED --> EXT
    PG --> EXT
    PG --> ECHO
    ECHO --> COMPAT
    ECHO --> TERM
    EXT --> TERM
```

---

## Design Considerations

1. **Lazy loading:** The module is imported only when TUI features are used, keeping Click's base import time low.
2. **TTY awareness:** All rendering paths check `isatty` and degrade gracefully to plain output when not attached to a terminal.
3. **Cross-platform:** Platform-specific behavior (Windows console, Cygwin, macOS) is encapsulated in dedicated branches and helper functions.
4. **Re-entry safety:** `ProgressBar.generator()` is deliberately simple to support both `iter()` and `next()` interfaces.
5. **Color management:** Color output is coordinated with `echo` and `strip_ansi` from the [platform_and_io_foundation](platform_and_io_foundation.md) module.

---

## Related Modules

- [platform_and_io_foundation](platform_and_io_foundation.md) — stream handling, encoding, ANSI utilities, and `echo`.
- [exceptions](exceptions.md) — `ClickException` used for editor error reporting.
- [formatting](formatting.md) — help text formatting (sibling presentation module).
- [shell_completion](shell_completion.md) — shell completion (sibling presentation module).
- [command_model_and_definition](command_model_and_definition.md) — commands and parameters that consume these TUI features.
