# Formatting Module

## Introduction

The `formatting` module is responsible for rendering text-based help pages and usage messages for command-line interfaces. It provides the `HelpFormatter` class along with a set of helper functions that intelligently wrap, indent, and lay out text so that help output remains readable across different terminal widths.

This module is part of the broader [user interface and presentation](user_interface_and_presentation.md) layer. It is primarily consumed by the command model (see [command model and definition](command_model_and_definition.md)) when generating `--help` output, and it relies on low-level text utilities from the [platform and IO foundation](platform_and_io_foundation.md).

The module always writes into an in-memory buffer, which is later flushed to the terminal by the caller. This design makes the output easy to test and capture.

---

## Core Components

### `HelpFormatter`

The central class of the module. It accumulates formatted text in an internal buffer and exposes methods for writing the various building blocks of a help page.

| Method | Purpose |
| --- | --- |
| `write(string)` | Appends a raw string to the buffer. |
| `indent()` / `dedent()` | Increase/decrease the current indentation by `indent_increment`. |
| `write_usage(prog, args, prefix)` | Writes a `Usage:` line, wrapping arguments intelligently. |
| `write_heading(heading)` | Writes a section heading (e.g. `Options:`). |
| `write_paragraph()` | Inserts a blank line separator if the buffer is non-empty. |
| `write_text(text)` | Writes re-indented, paragraph-preserving text. |
| `write_dl(rows, col_max, col_spacing)` | Writes a two-column definition list (used for options/commands). |
| `section(name)` | Context manager: paragraph + heading + indentation. |
| `indentation()` | Context manager: temporarily increases indentation. |
| `getvalue()` | Returns the accumulated buffer as a string. |

#### Construction and width resolution

The formatter resolves its output width in the following priority order:

1. An explicit `width` argument.
2. The module-level `FORCED_WIDTH` (used by the test system).
3. The terminal width, clamped between a minimum of `50` and `max_width` (default `80`), minus `2` columns.

```python
if width is None:
    width = FORCED_WIDTH
    if width is None:
        width = max(min(shutil.get_terminal_size().columns, max_width) - 2, 50)
```

### Helper functions

- **`measure_table(rows)`** — Computes the maximum width of each column across all rows, returning a tuple of column widths.
- **`iter_rows(rows, col_count)`** — Normalizes rows to a fixed column count by padding with empty strings.
- **`wrap_text(...)`** — The core text-wrapping routine. Supports single-paragraph wrapping as well as paragraph-preserving mode (paragraphs separated by blank lines, with `\b` blocks left unwrapped).
- **`join_options(options)`** — Joins a list of option strings (e.g. `-f`, `--foo`) into a single display string, sorted by prefix length, and reports whether any prefix was a slash (`/`).

---

## Architecture

The module sits between the command model (which requests help output) and the low-level text/IO utilities (which provide wrapping and width measurement primitives).

```mermaid
graph TD
    subgraph "Command Model"
        CMD[Command / Group / Option]
    end

    subgraph "Formatting Module"
        HF[HelpFormatter]
        WT[wrap_text]
        MT[measure_table]
        IR[iter_rows]
        JO[join_options]
    end

    subgraph "Platform & IO Foundation"
        TW[TextWrapper]
        TL[term_len]
    end

    subgraph "Argument Parsing"
        SO[_split_opt]
    end

    CMD -->|uses| HF
    HF --> WT
    HF --> MT
    HF --> IR
    WT --> TW
    MT --> TL
    IR --> TL
    JO --> SO
    JO --> TL
```

---

## Component Interaction

The following diagram shows how the pieces of the module collaborate when producing a definition list (the most common help-page construct).

```mermaid
sequenceDiagram
    participant Caller as Command Model
    participant HF as HelpFormatter
    participant MT as measure_table
    participant IR as iter_rows
    participant WT as wrap_text
    participant TW as TextWrapper

    Caller->>HF: write_dl(rows, col_max, col_spacing)
    HF->>MT: measure_table(rows)
    MT-->>HF: column widths
    HF->>IR: iter_rows(rows, col_count)
    IR-->>HF: normalized rows
    loop each row
        HF->>HF: write first column
        HF->>WT: wrap_text(second, text_width)
        WT->>TW: fill / indent_only
        TW-->>WT: wrapped text
        WT-->>HF: wrapped text
        HF->>HF: write wrapped lines
    end
    HF-->>Caller: (buffer updated)
```

---

## Data Flow

Text flows from raw input strings through wrapping and indentation stages into the internal buffer, which is finally returned as a single string.

```mermaid
flowchart LR
    A[Raw text / rows] --> B{Operation}
    B -->|write_text| C[wrap_text preserve_paragraphs=True]
    B -->|write_usage| D[wrap_text with prefix]
    B -->|write_dl| E[measure_table + iter_rows]
    E --> F[wrap_text per cell]
    C --> G[Internal buffer]
    D --> G
    F --> G
    G --> H[getvalue]
    H --> I[Flushed to terminal]
```

---

## Process Flow: Writing a Help Section

The `section` context manager encapsulates the typical pattern of writing a paragraph break, a heading, and an indented body.

```mermaid
flowchart TD
    Start([section name]) --> P[write_paragraph]
    P --> H[write_heading name]
    H --> I[indent]
    I --> Body[caller writes body content]
    Body --> D[dedent]
    D --> End([exit])
```

---

## Text Wrapping Details

`wrap_text` delegates the actual wrapping to `TextWrapper` from the [platform and IO foundation](platform_and_io_foundation.md). Two modes are supported:

1. **Single-paragraph mode** (`preserve_paragraphs=False`): the entire text is treated as one paragraph and filled to the target width.
2. **Paragraph-preserving mode** (`preserve_paragraphs=True`): blank lines split paragraphs. A paragraph whose first line is exactly `\b` (`\x08`) is treated as *raw* and is only indented, never rewrapped.

```mermaid
flowchart TD
    A[text] --> B[expandtabs]
    B --> C{preserve_paragraphs?}
    C -->|No| D[wrapper.fill]
    C -->|Yes| E[split into paragraphs]
    E --> F{paragraph starts with \\b?}
    F -->|Yes| G[wrapper.indent_only]
    F -->|No| H[wrapper.fill]
    G --> I[join with blank lines]
    H --> I
    D --> J[return]
    I --> J
```

---

## Width Measurement and ANSI Handling

Column widths are measured using `term_len`, which strips ANSI escape sequences before counting characters. This ensures that colored output does not distort column alignment. See [platform and IO foundation](platform_and_io_foundation.md) for the underlying `strip_ansi` implementation.

---

## Option String Joining

`join_options` normalizes a collection of option strings for display. It uses `_split_opt` (from the [argument parsing and type system](argument_parsing_and_type_system.md) module) to determine each option's prefix, sorts options by prefix length, and joins them with commas.

```mermaid
flowchart LR
    A[options list] --> B[for each opt: _split_opt]
    B --> C[record prefix length]
    C --> D[sort by prefix length]
    D --> E[join with ', ']
    E --> F[formatted string + slash flag]
```

---

## Dependencies

| Dependency | Source Module | Usage |
| --- | --- | --- |
| `term_len` | [platform and IO foundation](platform_and_io_foundation.md) (`_compat`) | Measure display width ignoring ANSI codes. |
| `TextWrapper` | [platform and IO foundation](platform_and_io_foundation.md) (`_textwrap`) | Perform the actual line wrapping. |
| `_split_opt` | [argument parsing and type system](argument_parsing_and_type_system.md) (`parser`) | Determine option prefixes for `join_options`. |
| `shutil.get_terminal_size` | Python stdlib | Determine default output width. |

---

## Related Modules

- [command model and definition](command_model_and_definition.md) — Consumes `HelpFormatter` to render `--help` output.
- [argument parsing and type system](argument_parsing_and_type_system.md) — Provides `_split_opt` used by `join_options`.
- [platform and IO foundation](platform_and_io_foundation.md) — Provides `TextWrapper` and `term_len`.
- [user interface and presentation](user_interface_and_presentation.md) — Parent layer containing this module.
- [testing](testing.md) — Uses `FORCED_WIDTH` to produce deterministic help output.
