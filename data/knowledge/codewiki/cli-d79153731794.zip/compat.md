# Compat Module

## Introduction

The `compat` module (`src/click/_compat.py`) is Click's **platform and I/O compatibility layer**. It abstracts away the differences between operating systems (notably Windows vs. POSIX), Python versions, and the various ways that standard streams (`stdin`, `stdout`, `stderr`) may be configured by the host environment (terminals, IDEs, Jupyter notebooks, test runners, etc.).

Its primary responsibilities are:

1. **Stream normalization** — Ensuring that text and binary streams behave consistently regardless of how they were originally created.
2. **Encoding resolution** — Determining the best encoding for a stream and recovering gracefully from misconfigured (ASCII) streams.
3. **Atomic file writes** — Providing crash-safe file writing via a temporary file + atomic rename.
4. **ANSI handling** — Detecting whether ANSI color codes should be stripped and, on Windows, wrapping streams with `colorama`.
5. **Windows console support** — Delegating to the [`winconsole`](winconsole.md) module for native Windows console streams.

This module is foundational: nearly every other part of Click that reads from or writes to a stream depends on it. It is part of the broader [platform_and_io_foundation](platform_and_io_foundation.md) group.

---

## Architecture Overview

The module is organized around a small set of public helper functions that wrap a collection of internal stream-fixing utilities and the `_AtomicFile` proxy.

```mermaid
graph TD
    subgraph "Public API"
        open_stream["open_stream()"]
        get_text_stdin["get_text_stdin()"]
        get_text_stdout["get_text_stdout()"]
        get_text_stderr["get_text_stderr()"]
        get_binary_stdin["get_binary_stdin()"]
        get_binary_stdout["get_binary_stdout()"]
        get_binary_stderr["get_binary_stderr()"]
        strip_ansi["strip_ansi()"]
        should_strip_ansi["should_strip_ansi()"]
        auto_wrap_for_ansi["auto_wrap_for_ansi()"]
        isatty["isatty()"]
        term_len["term_len()"]
    end

    subgraph "Stream Fixup Internals"
        _force_correct_text_reader["_force_correct_text_reader()"]
        _force_correct_text_writer["_force_correct_text_writer()"]
        _force_correct_text_stream["_force_correct_text_stream()"]
        _make_text_stream["_make_text_stream()"]
        _find_binary_reader["_find_binary_reader()"]
        _find_binary_writer["_find_binary_writer()"]
        _is_binary_reader["_is_binary_reader()"]
        _is_binary_writer["_is_binary_writer()"]
    end

    subgraph "Core Classes"
        _NonClosingTextIOWrapper["_NonClosingTextIOWrapper"]
        _FixupStream["_FixupStream"]
        _AtomicFile["_AtomicFile"]
    end

    subgraph "Encoding Helpers"
        get_best_encoding["get_best_encoding()"]
        is_ascii_encoding["is_ascii_encoding()"]
        _stream_is_misconfigured["_stream_is_misconfigured()"]
        _is_compatible_text_stream["_is_compatible_text_stream()"]
    end

    get_text_stdin --> _force_correct_text_reader
    get_text_stdout --> _force_correct_text_writer
    get_text_stderr --> _force_correct_text_writer
    _force_correct_text_reader --> _force_correct_text_stream
    _force_correct_text_writer --> _force_correct_text_stream
    _force_correct_text_stream --> _make_text_stream
    _force_correct_text_stream --> _is_compatible_text_stream
    _force_correct_text_stream --> _stream_is_misconfigured
    _force_correct_text_stream --> _find_binary_reader
    _force_correct_text_stream --> _find_binary_writer
    _find_binary_reader --> _is_binary_reader
    _find_binary_writer --> _is_binary_writer
    _make_text_stream --> _NonClosingTextIOWrapper
    _make_text_stream --> get_best_encoding
    _NonClosingTextIOWrapper --> _FixupStream
    get_best_encoding --> is_ascii_encoding
    open_stream --> _AtomicFile
    open_stream --> get_text_stdout
    open_stream --> get_binary_stdout
```

---

## Core Components

### `_NonClosingTextIOWrapper`

A subclass of `io.TextIOWrapper` that **does not close its underlying binary stream when garbage-collected**. This is critical because Click frequently wraps `sys.stdout`/`sys.stderr` in new text wrappers; if those wrappers closed the underlying stream on `__del__`, the interpreter's own streams would be destroyed.

Key behaviors:

- Wraps the incoming binary stream in a [`_FixupStream`](#_fixupstream) before passing it to `TextIOWrapper`.
- Overrides `__del__` to call `self.detach()` (guarded by a bare `except`) instead of closing the stream.
- Overrides `isatty()` to delegate to the *original* stream, working around a [PyPy bug](https://bitbucket.org/pypy/pypy/issue/1803).

```python
class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __init__(self, stream, encoding, errors,
                 force_readable=False, force_writable=False, **extra):
        self._stream = stream = _FixupStream(stream, force_readable, force_writable)
        super().__init__(stream, encoding, errors, **extra)

    def __del__(self):
        try:
            self.detach()
        except Exception:
            pass

    def isatty(self):
        return self._stream.isatty()
```

### `_FixupStream`

A transparent proxy that **adds missing methods** to streams that do not fully implement the modern `io` interface. Some environments (e.g., certain Jupyter notebook versions) place badly-patched objects on `sys`, so this class fills the gaps.

| Method | Behavior |
| --- | --- |
| `__getattr__` | Proxies all unknown attributes to the wrapped stream. |
| `read1(size)` | Uses the stream's `read1` if present, otherwise falls back to `read(size)`. |
| `readable()` | Honors `force_readable`; otherwise probes via `readable()` or a `read(0)` call. |
| `writable()` | Honors `force_writable`; otherwise probes via `writable()` or a `write("")`/`write(b"")` call. |
| `seekable()` | Probes via `seekable()` or a `seek(tell())` round-trip. |

The `force_readable` / `force_writable` flags exist specifically to work around tools that put non-conforming objects on `sys`.

### `_AtomicFile`

A file-like proxy that implements **atomic writes**. It writes to a temporary file in the same directory and, on `close()`, atomically replaces the real file using `os.replace`.

```python
class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self.close(delete=exc_type is not None)
```

Notable design points:

- `name` reports the **real** filename, not the temporary one, so callers see the intended path.
- `__exit__` passes `delete=exc_type is not None`, but note that `close()` currently ignores the `delete` argument and always performs the replace — the parameter is reserved for future behavior.
- All other attributes are proxied to the underlying file object.

---

## Stream Resolution Flow

The heart of the module is the logic that turns an arbitrary stream into a correctly-configured text or binary stream. The following diagram shows how `get_text_stdout()` (and its siblings) resolve a stream.

```mermaid
flowchart TD
    Start["get_text_stdout(encoding, errors)"] --> WinCheck{"Windows console stream available?"}
    WinCheck -->|yes| WinStream["Return _get_windows_console_stream()"]
    WinCheck -->|no| ForceWriter["_force_correct_text_writer()"]
    ForceWriter --> ForceStream["_force_correct_text_stream()"]
    ForceStream --> IsBinary{"is_binary(stream)?"}
    IsBinary -->|yes| UseBinary["Use stream as binary_reader"]
    IsBinary -->|no| Compatible{"Compatible encoding/errors<br/>and not misconfigured?"}
    Compatible -->|yes| ReturnAsIs["Return stream as-is"]
    Compatible -->|no| FindBinary["find_binary(stream)"]
    FindBinary --> Found{"Binary stream found?"}
    Found -->|no| ReturnOriginal["Return original (mojibake)"]
    Found -->|yes| UseBinary
    UseBinary --> MakeText["_make_text_stream()"]
    MakeText --> Wrap["_NonClosingTextIOWrapper + _FixupStream"]
    Wrap --> Done["Return text stream"]
```

### Encoding Resolution

- `get_best_encoding(stream)` returns the stream's declared encoding, falling back to `sys.getdefaultencoding()`. If the result is ASCII, it is upgraded to `utf-8`.
- `is_ascii_encoding(encoding)` uses `codecs.lookup` to determine whether an encoding is ASCII.
- `_stream_is_misconfigured(stream)` treats a stream with no encoding (or an ASCII encoding) as misconfigured — a common situation in unittest environments.
- `_is_compatible_text_stream(stream, encoding, errors)` checks whether a stream's `encoding`/`errors` attributes already match the desired values.

### Binary Stream Discovery

- `_is_binary_reader` / `_is_binary_writer` probe a stream by attempting a zero-length read/write and checking the type of the result.
- `_find_binary_reader` / `_find_binary_writer` first check whether the stream is already binary, then look for a `.buffer` attribute (the documented way to obtain a binary stream from a text stream).

---

## Public API Reference

### Stream Accessors

| Function | Returns | Notes |
| --- | --- | --- |
| `get_binary_stdin()` | `BinaryIO` | Raises `RuntimeError` if no binary stream can be found. |
| `get_binary_stdout()` | `BinaryIO` | Raises `RuntimeError` if no binary stream can be found. |
| `get_binary_stderr()` | `BinaryIO` | Raises `RuntimeError` if no binary stream can be found. |
| `get_text_stdin(encoding, errors)` | `TextIO` | Prefers Windows console stream; forces readable. |
| `get_text_stdout(encoding, errors)` | `TextIO` | Prefers Windows console stream; forces writable. |
| `get_text_stderr(encoding, errors)` | `TextIO` | Prefers Windows console stream; forces writable. |

The module also exposes two mapping dictionaries for dynamic lookup:

```python
binary_streams = {"stdin": get_binary_stdin, "stdout": get_binary_stdout, "stderr": get_binary_stderr}
text_streams   = {"stdin": get_text_stdin,   "stdout": get_text_stdout,   "stderr": get_text_stderr}
```

### Cached Default Streams

`_make_cached_stream_func` builds a `WeakKeyDictionary`-backed cache so that repeated calls for the same underlying stream return the same wrapper. This produces:

- `_default_text_stdin`
- `_default_text_stdout`
- `_default_text_stderr`

### `open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False)`

Opens a file (or a standard stream when `filename == "-"`) and returns a `(stream, should_close)` tuple.

- **Standard streams**: `"-"` maps to stdin/stdout depending on the mode; the `atomic` flag is ignored.
- **Non-atomic**: delegates to `_wrap_io_open`, which omits `encoding`/`errors` in binary mode.
- **Atomic**: only valid with `w` mode. It:
  1. Rejects `a` (append) and `x` (exclusive) modes with `ValueError`.
  2. Preserves the original file's permission bits.
  3. Creates a uniquely-named temporary file (`.__atomic-write<hex>`) in the same directory using `O_RDWR | O_CREAT | O_EXCL`.
  4. Wraps it in an [`_AtomicFile`](#_atomicfile).

### ANSI Handling

| Function | Purpose |
| --- | --- |
| `strip_ansi(value)` | Removes ANSI escape sequences using the `_ansi_re` regex. |
| `should_strip_ansi(stream, color)` | Decides whether to strip color; returns `not isatty(stream)` unless overridden by `color`. |
| `auto_wrap_for_ansi(stream, color)` | **Windows only** — wraps a stream with `colorama.AnsiToWin32`, caching the result. |
| `term_len(x)` | Returns the visible length of a string after stripping ANSI codes. |
| `isatty(stream)` | Safe `isatty()` that returns `False` on any exception. |

On Windows, `auto_wrap_for_ansi` also installs a `_safe_write` wrapper that resets colorama state if a write raises, preventing color leakage after errors.

### Platform Detection

```python
CYGWIN = sys.platform.startswith("cygwin")
WIN = sys.platform.startswith("win")
```

These flags gate the Windows-specific code paths. On non-Windows platforms, `_get_windows_console_stream` is a no-op returning `None`, and `_get_argv_encoding` falls back to `sys.stdin.encoding` or the filesystem encoding.

---

## Component Interaction

The following sequence diagram shows how a typical text write to `stdout` flows through the module.

```mermaid
sequenceDiagram
    participant Caller
    participant compat as _compat
    participant Fixup as _FixupStream
    participant Wrapper as _NonClosingTextIOWrapper
    participant Sys as sys.stdout

    Caller->>compat: get_text_stdout()
    compat->>compat: _get_windows_console_stream() -> None (POSIX)
    compat->>compat: _force_correct_text_writer(sys.stdout)
    compat->>compat: _is_compatible_text_stream()?
    alt incompatible
        compat->>compat: _find_binary_writer(sys.stdout)
        compat->>compat: _make_text_stream(binary, encoding, errors)
        compat->>Fixup: _FixupStream(binary, force_writable=True)
        compat->>Wrapper: _NonClosingTextIOWrapper(fixup, ...)
        Wrapper-->>compat: text stream
    else compatible
        compat-->>Caller: sys.stdout as-is
    end
    compat-->>Caller: text stream
    Caller->>Wrapper: write("hello")
    Wrapper->>Fixup: (proxied) write
    Fixup->>Sys: write
```

---

## Relationship to Other Modules

The `compat` module is a low-level dependency used throughout Click. It sits alongside other members of the [platform_and_io_foundation](platform_and_io_foundation.md) group.

```mermaid
graph LR
    compat["compat (_compat.py)"]
    winconsole["winconsole (_winconsole.py)"]
    utils["utils (utils.py)"]
    textwrap["textwrap (_textwrap.py)"]
    formatting["formatting (formatting.py)"]
    termui["termui_impl (_termui_impl.py)"]
    testing["testing (testing.py)"]

    compat -->|"_get_windows_console_stream"| winconsole
    winconsole -->|"ConsoleStream"| compat
    utils -->|"open_stream, get_text_*"| compat
    formatting -->|"strip_ansi, term_len"| compat
    termui -->|"get_text_*, isatty"| compat
    testing -->|"stream helpers"| compat
```

### Key Consumers

- **[utils](utils.md)** — `LazyFile` calls `open_stream()` to lazily open files (including atomic writes), and `KeepOpenFile` / `PacifyFlushWrapper` complement the stream-wrapping strategy. `PacifyFlushWrapper` specifically suppresses `BrokenPipeError` (EPIPE) during interpreter shutdown, mirroring the robustness goals of this module.
- **[winconsole](winconsole.md)** — Provides `_get_windows_console_stream` and `ConsoleStream`, which `compat` imports on Windows to handle native console I/O.
- **[formatting](formatting.md)** — Uses `strip_ansi` and `term_len` to compute visible widths for help text layout.
- **[termui_impl](termui_impl.md)** — Uses the text stream accessors and `isatty` for progress bars and editors.
- **[testing](testing.md)** — Relies on the stream helpers when constructing test I/O streams.

---

## Design Notes & Edge Cases

1. **Never close the real stream.** `_NonClosingTextIOWrapper.__del__` detaches rather than closes, preventing accidental destruction of `sys.stdout`/`sys.stderr`.
2. **Graceful degradation.** When a binary stream cannot be found, `_force_correct_text_stream` returns the original text stream, accepting mojibake rather than raising.
3. **ASCII recovery.** Streams reporting ASCII encoding are treated as misconfigured and re-wrapped as UTF-8.
4. **Atomic write constraints.** Atomic mode is intentionally restricted to `w` mode; append and exclusive modes raise `ValueError` because they cannot be implemented safely with a temp-file strategy.
5. **Windows-only colorama.** `auto_wrap_for_ansi` is only defined on Windows; on other platforms the name is `None`, so callers must guard against it.
6. **Weak caches.** Stream caches use `WeakKeyDictionary` and swallow exceptions on cache access, ensuring that unhashable or unusual stream objects never break the caching logic.
