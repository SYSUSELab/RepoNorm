# Core Module

## Introduction

The **Core** module (`src/click/core.py`) is the heart of the Click framework. It defines the fundamental building blocks that every Click application is composed of: **commands**, **groups**, **parameters** (options and arguments), and the **context** object that carries state throughout an invocation.

This module is responsible for:

- Defining the command hierarchy (`Command`, `Group`, `CommandCollection`).
- Defining the parameter hierarchy (`Parameter`, `Option`, `Argument`).
- Managing invocation state and lifecycle through `Context`.
- Orchestrating the full command-line parsing and dispatch pipeline.
- Tracking the *source* of each parameter value via `ParameterSource`.

It sits at the top of the dependency graph and ties together the lower-level modules (parsing, types, formatting, exceptions, and I/O) into a coherent CLI framework.

> **Related modules:** For details on the parsing engine see [argument_parsing_and_type_system](argument_parsing_and_type_system.md); for help rendering see [user_interface_and_presentation](user_interface_and_presentation.md); for error types see [exceptions](exceptions.md); for the decorator API see [decorators](decorators.md).

---

## Architecture Overview

The core module is organized around two parallel class hierarchies — **commands** and **parameters** — that are bound together at runtime by the **`Context`**.

```mermaid
graph TD
    subgraph Commands
        Command --> Group
        Group --> CommandCollection
        Command -.deprecated alias.-> _BaseCommand
        Group -.deprecated alias.-> _MultiCommand
    end

    subgraph Parameters
        Parameter --> Option
        Parameter --> Argument
    end

    Context -->|holds| Command
    Context -->|holds| Parameter
    Command -->|owns| Parameter
    Group -->|owns| Command
    CommandCollection -->|delegates to| Group
```

### Key Relationships

| Component | Role | Owns / References |
|-----------|------|-------------------|
| `Command` | Base executable unit | `Parameter` list, `Context` class |
| `Group` | Nests subcommands | `Command` map, result callback |
| `CommandCollection` | Flattens commands from multiple groups | `Group` sources |
| `Parameter` | Base for options/arguments | `ParamType`, callback |
| `Option` | Named, optional parameters | flag/prompt/count behavior |
| `Argument` | Positional parameters | nargs handling |
| `Context` | Invocation state container | parent/child contexts, params, resources |
| `ParameterSource` | Enum of value origins | used by `Context` |

---

## Command Hierarchy

### `Command`

`Command` is the base class for all commands. It encapsulates:

- **Metadata**: `name`, `help`, `epilog`, `short_help`, `hidden`, `deprecated`.
- **Parameters**: a list of `Parameter` objects (`params`).
- **Configuration defaults**: `allow_extra_args`, `allow_interspersed_args`, `ignore_unknown_options`.
- **Class hooks**: `context_class` (defaults to `Context`).

Its lifecycle methods form the core execution pipeline:

```mermaid
flowchart LR
    A[main] --> B[make_context]
    B --> C[parse_args]
    C --> D[invoke]
    D --> E[callback]
    B -.uses.-> F[make_parser]
    C -.uses.-> G[handle_parse_result]
```

| Method | Purpose |
|--------|---------|
| `make_context()` | Builds a `Context` and runs parsing (without invoking the callback). |
| `parse_args()` | Creates a parser, parses tokens, and processes each parameter. |
| `invoke()` | Calls the command callback with parsed params. |
| `main()` | Full entry point: handles completion, errors, and standalone mode. |
| `get_help()` / `get_usage()` | Render help/usage via a `HelpFormatter`. |
| `shell_complete()` | Provides shell completion candidates. |

The `main()` method is the canonical way to run a CLI. It handles:

1. Argument expansion on Windows (`_expand_args`).
2. Shell completion short-circuit (`_main_shell_completion`).
3. Exception translation (`ClickException`, `Abort`, `Exit`, `OSError`/`EPIPE`).
4. Standalone vs. non-standalone mode.

### `Group`

`Group` extends `Command` to **nest other commands**. Key additions:

- `commands`: a mapping of names to `Command` objects.
- `chain`: enables invoking multiple subcommands in sequence.
- `invoke_without_command`: run the group callback even without a subcommand.
- `result_callback`: post-processes the subcommand's return value.
- `command_class` / `group_class`: hooks for custom subcommand classes.

The `invoke()` method of `Group` implements two distinct flows:

```mermaid
flowchart TD
    Start[Group.invoke] --> HasArgs{protected_args?}
    HasArgs -- No --> NoCmd{invoke_without_command?}
    NoCmd -- Yes --> RunGroup[Run group callback + result_callback]
    NoCmd -- No --> Fail[ctx.fail 'Missing command']
    HasArgs -- Yes --> Chain{chain mode?}
    Chain -- No --> Single[Resolve one command, invoke it]
    Chain -- Yes --> Multi[Resolve & invoke all commands, collect results]
    Single --> Result[_process_result]
    Multi --> Result
```

> **Chain mode constraint:** A group in chain mode cannot have optional arguments — this is enforced in `__init__` and by `_check_nested_chain()`.

### `CommandCollection`

`CommandCollection` is a `Group` that **flattens** commands from multiple source groups. Lookup order:

1. Its own registered commands.
2. Each source group in order.

Parameters and callbacks of the sources are *not* inherited — only their commands are exposed.

### Deprecated Aliases

`_BaseCommand` and `_MultiCommand` are deprecated shims (removed in Click 9.0) that use `_FakeSubclassCheck` to preserve `isinstance`/`issubclass` compatibility with the old `BaseCommand`/`MultiCommand` names. Accessing `BaseCommand` or `MultiCommand` via module `__getattr__` emits a `DeprecationWarning`.

---

## Parameter Hierarchy

### `Parameter`

`Parameter` is the abstract base for `Option` and `Argument`. It handles:

- **Declaration parsing** (`_parse_decls`, implemented by subclasses).
- **Type conversion** (`type_cast_value`) honoring `nargs`, `multiple`, and composite types.
- **Value resolution** (`consume_value`) with a strict precedence order.
- **Validation & callbacks** (`process_value`).
- **Environment variable resolution** (`resolve_envvar_value`, `value_from_envvar`).

#### Value Resolution Precedence

`consume_value()` resolves a value from the following sources, in order:

```mermaid
flowchart LR
    A[Command line] --> B[Environment variable]
    B --> C[default_map]
    C --> D[Parameter default]
    D --> E[Prompt - Option only]
```

Each resolved value is tagged with a `ParameterSource` and stored on the context via `set_parameter_source()`.

#### Type Casting

`type_cast_value()` normalizes values based on `nargs` and `multiple`:

| Configuration | Result |
|---------------|--------|
| `nargs == 1` | Single converted value |
| `nargs == -1` | Tuple of all remaining values |
| `nargs > 1` | Tuple of exactly `nargs` values (else `BadParameter`) |
| `multiple=True` | Tuple of converted values |

### `Option`

`Option` adds named-parameter features:

- **Flags**: `is_flag`, `flag_value`, boolean flag pairs (`--foo/--no-foo`).
- **Prompting**: `prompt`, `confirmation_prompt`, `hide_input`, `prompt_required`.
- **Counting**: `count=True` increments an integer.
- **Multiple**: `multiple=True` collects repeated values.
- **Help extras**: `show_default`, `show_envvar`, `show_choices`.

The `_flag_needs_value` sentinel (from the parser) distinguishes "flag given without value" from "flag not given", enabling prompt-on-flag behavior.

### `Argument`

`Argument` represents positional parameters:

- Required by default (unless a default is provided or `nargs <= 0`).
- Supports infinite `nargs=-1`.
- Does **not** support `multiple` (raises `TypeError`).

---

## Context

`Context` is the runtime state container. It is created per command invocation and forms a **parent/child chain** mirroring the command hierarchy.

### Responsibilities

- **State**: `params`, `args`, `obj`, `meta`, `default_map`.
- **Configuration inheritance**: terminal width, color, help option names, envvar prefix, etc. are inherited from the parent context.
- **Resource management**: `with_resource()` and `call_on_close()` register cleanup via an `ExitStack`.
- **Invocation helpers**: `invoke()`, `forward()`, `exit()`, `fail()`, `abort()`.
- **Parameter source tracking**: `set_parameter_source()` / `get_parameter_source()`.

### Context Lifecycle

```mermaid
sequenceDiagram
    participant Cmd as Command
    participant Ctx as Context
    participant Stack as globals stack
    Cmd->>Ctx: make_context()
    Cmd->>Ctx: __enter__ (push_context)
    Cmd->>Ctx: parse_args()
    Cmd->>Ctx: invoke()
    Ctx->>Ctx: callback()
    Cmd->>Ctx: __exit__ (pop_context)
    Ctx->>Ctx: close() -> ExitStack.close()
```

The `scope()` context manager promotes a context to the thread-local current context (see `globals.push_context`). Nested pushes defer cleanup until the outermost scope exits.

### Command Path

`command_path` computes the full invocation path (e.g. `mycli subcmd`) by walking the parent chain and including each parent's usage pieces. This is used in usage/error messages.

---

## ParameterSource

`ParameterSource` is an `enum.Enum` describing where a parameter's value came from:

| Value | Meaning |
|-------|---------|
| `COMMANDLINE` | Provided on the command line |
| `ENVIRONMENT` | Provided via an environment variable |
| `DEFAULT` | Taken from the parameter's default |
| `DEFAULT_MAP` | Taken from `Context.default_map` |
| `PROMPT` | Provided interactively via a prompt |

This is useful for detecting when a user explicitly passed a value equal to the default.

---

## End-to-End Execution Flow

The following diagram shows how the core components collaborate during a typical invocation:

```mermaid
flowchart TD
    Main[Command.main] --> Complete{Completion request?}
    Complete -- Yes --> ShellComplete[shell_complete -> exit]
    Complete -- No --> MakeCtx[make_context]
    MakeCtx --> Parse[parse_args]
    Parse --> Parser[_OptionParser.parse_args]
    Parser --> Handle[param.handle_parse_result]
    Handle --> Consume[consume_value]
    Consume --> Cast[type_cast_value]
    Cast --> Process[process_value + callback]
    Process --> Invoke[Command.invoke]
    Invoke --> CB[user callback]
    Invoke --> ResultCb[Group result_callback]
```

### Error Handling

Errors raised during parsing/invocation are augmented with context via `augment_usage_errors()`:

- `BadParameter` → attaches `ctx` and `param`.
- `UsageError` → attaches `ctx`.

In `main()`, these are caught and rendered (see [exceptions](exceptions.md)) unless `standalone_mode=False`.

---

## Helper Functions

| Function | Purpose |
|----------|---------|
| `augment_usage_errors()` | Context manager attaching `ctx`/`param` to usage errors. |
| `iter_params_for_processing()` | Orders parameters so eager params run first. |
| `_complete_visible_commands()` | Yields non-hidden subcommands matching a prefix. |
| `_check_nested_chain()` | Prevents nesting groups inside chain-mode groups. |
| `batch()` | Groups an iterable into fixed-size tuples (for `multiple` + `nargs`). |
| `_check_iter()` | Validates iterability (rejecting strings). |

---

## Dependencies

```mermaid
graph LR
    core[core.py] --> types[types.py]
    core --> exceptions[exceptions.py]
    core --> formatting[formatting.py]
    core --> globals[globals.py]
    core --> parser[parser.py]
    core --> termui[termui.py]
    core --> utils[utils.py]
    core -.lazy.-> shell_completion[shell_completion.py]
    core -.lazy.-> decorators[decorators.py]
```

- **`types`** — parameter type conversion and validation.
- **`exceptions`** — `UsageError`, `BadParameter`, `Abort`, `Exit`, etc.
- **`formatting`** — `HelpFormatter` for help/usage rendering.
- **`globals`** — thread-local context stack (`push_context`/`pop_context`).
- **`parser`** — the low-level `_OptionParser` engine.
- **`termui`** — `prompt`, `confirm`, `style` for interactive options.
- **`utils`** — `echo`, `make_str`, `_detect_program_name`, `PacifyFlushWrapper`.
- **`shell_completion`** / **`decorators`** — imported lazily to avoid circular imports.

---

## Summary

The core module provides the declarative and imperative backbone of Click:

- **Declarative**: `Command`, `Group`, `Option`, `Argument` describe *what* a CLI looks like.
- **Imperative**: `Context` and the `main()`/`parse_args()`/`invoke()` pipeline describe *how* it runs.

Understanding the interplay between `Context`, `Command`, and `Parameter` is essential for extending Click — whether by subclassing commands, writing custom parameters, or hooking into the invocation lifecycle.
