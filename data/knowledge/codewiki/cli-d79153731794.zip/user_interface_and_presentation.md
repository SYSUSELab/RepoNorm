# User Interface and Presentation

## Purpose

The `user_interface_and_presentation` module is responsible for everything the user *sees* and *interacts with* when using Click-based command-line applications. It sits on top of the command model and argument parsing layers and translates parsed commands into human-friendly output and interactive behavior. Its responsibilities include:

- **Help and usage formatting** — rendering help pages, usage strings, option/argument descriptions, and wrapping text to fit the terminal width.
- **Terminal UI primitives** — prompting for input, echoing, paging, progress bars, and other interactive terminal operations.
- **Shell completion** — generating completion scripts and completion candidates for Bash, Zsh, and Fish.

In short, this module handles the *presentation layer* of Click: how commands are described to users and how users are prompted for and shown information in a terminal.

## Architecture

The module is composed of three cooperating submodules, each with a distinct concern:

```mermaid
graph TD
    subgraph UI["user_interface_and_presentation"]
        F["formatting.py<br/>(help & usage rendering)"]
        T["_termui_impl.py<br/>(terminal UI primitives)"]
        S["shell_completion.py<br/>(shell completion)"]
    end

    CORE["command_model_and_definition<br/>(core.py, decorators.py)"]
    PARSE["argument_parsing_and_type_system<br/>(parser.py, types.py)"]
    PLAT["platform_and_io_foundation<br/>(_compat.py, utils.py, _textwrap.py, _winconsole.py)"]

    CORE -->|"requests help/usage text"| F
    CORE -->|"prompts, echoes, pages"| T
    CORE -->|"registers completion"| S
    PARSE -->|"provides params & types"| F
    PARSE -->|"provides choices"| S

    F -->|"wraps text via"| PLAT
    T -->|"uses platform I/O"| PLAT
    S -->|"uses platform I/O"| PLAT
```

### Submodule roles

| Submodule | File | Role |
|-----------|------|------|
| Formatting | `src/click/formatting.py` | Builds help pages and usage strings; wraps and indents text to terminal width. |
| Terminal UI | `src/click/_termui_impl.py` | Implements interactive primitives: prompts, echo, pager, progress bar, editor launch. |
| Shell completion | `src/click/shell_completion.py` | Generates completion scripts and resolves completion candidates for supported shells. |

The three submodules are largely independent of one another but share the platform and I/O foundation (`_compat.py`, `utils.py`, `_textwrap.py`, `_winconsole.py`) for cross-platform terminal handling.

## Core Components

Detailed documentation for each submodule:

- [Formatting](./formatting.md) — help page and usage string rendering, text wrapping and indentation.
- [Terminal UI Implementation](./termui_impl.md) — interactive terminal primitives (prompts, echo, pager, progress bar).
- [Shell Completion](./shell_completion.md) — completion script generation and candidate resolution for Bash, Zsh, and Fish.