# Argument Parsing and Type System

## Purpose

The `argument_parsing_and_type_system` module is the core of Click's command-line argument processing. It is responsible for two tightly coupled concerns:

1. **Argument parsing** — tokenizing the raw command-line input, splitting it into options and arguments, handling short/long option forms, option-value association, and producing a structured parse result that the command layer can consume.
2. **Type system** — defining how individual parameter values are converted, validated, and normalized from their raw string form into Python objects (and back again for display/help purposes).

Together these components form the bridge between the user's raw `sys.argv` input and the typed, validated parameter values that Click commands receive.

## Architecture

The module consists of two cooperating submodules:

- **`parser.py`** — the low-level tokenizer and option/argument parser. It knows nothing about Click's `Command`/`Parameter` objects; it works with a lightweight `Option`/`Argument` abstraction and produces a `ParsingState`/`OptionParser` result.
- **`types.py`** — the `ParamType` hierarchy (e.g. `STRING`, `INT`, `FLOAT`, `BOOL`, `Choice`, `Path`, `File`, `DateTime`, `Tuple`, etc.) that converts and validates values.

The parser delegates value conversion to the type system once it has associated a raw string with a parameter.

```mermaid
graph TD
    subgraph "argument_parsing_and_type_system"
        P["parser.py<br/>(OptionParser, ParsingState,<br/>Option, Argument, split_opt)"]
        T["types.py<br/>(ParamType, STRING, INT,<br/>Choice, Path, File, ...)"]
    end

    CLI["Raw CLI tokens<br/>(sys.argv)"] --> P
    P -->|"raw string value"| T
    T -->|"converted / validated value"| CMD["Command layer<br/>(core.py)"]
    P -->|"parsed opts & args"| CMD
    CMD -->|"ParamType instance"| T
```

### Data flow

```mermaid
sequenceDiagram
    participant User
    participant Parser as parser.py
    participant Types as types.py
    participant Command as core.py

    User->>Parser: argv tokens
    Parser->>Parser: tokenize / split_opt
    Parser->>Parser: match options & arguments
    Parser->>Types: convert(raw_value, param, ctx)
    Types-->>Parser: typed value or UsageError
    Parser-->>Command: ParsingState (opts, args, order)
    Command->>Command: invoke callback with typed values
```

## Core Components

- **Parser** — see [parser.md](./parser.md) for the `OptionParser`, `ParsingState`, `Option`, `Argument`, and `split_opt` documentation.
- **Types** — see [types.md](./types.md) for the `ParamType` base class and all built-in type implementations.

## References

- `src/click/parser.py` — argument tokenization and option/argument matching.
- `src/click/types.py` — parameter type conversion and validation.
- Consumed by `src/click/core.py` (command model and definition), which wires `Parameter` objects to the parser and type system.