# Utils Module

## Introduction

The `utils` module (`src/click/utils.py`) provides the low-level utility layer that underpins Click's I/O, file handling, and text-processing behavior. It is part of the broader **platform_and_io_foundation** group, sitting alongside the compatibility layer (`_compat`), text wrapping (`_textwrap`), and Windows console support (`_winconsole`).

Its responsibilities include:

- **Safe file opening** with support for standard streams (`-`), lazy opening, and atomic writes.
- **Robust output** via the `echo` function, which handles encoding, binary/text streams, ANSI color codes, and Windows console quirks.
- **Stream wrappers** (`KeepOpenFile`, `LazyFile`, `PacifyFlushWrapper`) that adapt file objects for Click's needs.
- **Filename and path formatting** for display and cross-platform config directory resolution.
- **Argument expansion** and program-name detection helpers used during command invocation.

This module is a foundational dependency for higher-level modules such as [command_model_and_definition](command_model_and_definition.md), [argument_parsing_and_type_system](argument_parsing_and_type_system.md), and [user_interface_and_presentation](user_interface_and_presentation.md).

---

## Architecture Overview

The `utils` module acts as a bridge between Click's public API and the platform-specific compatibility layer. It exposes a set of public helpers and a set of internal stream wrappers.

```mermaid
graph TD
    subgraph "utils module (src/click/utils.py)"
        ECHO[echo]
        OPEN[open_file]
        GBS[get_binary_stream]
        GTS[get_text_stream]
        FF[format_filename]
        GAD[get_app_dir]
        MSH[make_default_short_help]
        MS[make_str]
        SC[safecall]
        POS[_posixify]
        DPN[_detect_program_name]
        EA[_expand_args]

        subgraph "Stream Wrappers"
            LZF[LazyFile]
            KOF[KeepOpenFile]
            PFW[PacifyFlushWrapper]
        end
    end

    subgraph "compat module (_compat)"
        OS[open_stream]
        AF[_AtomicFile]
        FS[_FixupStream]
        NCTW[_NonClosingTextIOWrapper]
        DTS[_default_text_stdout/stderr]
        FBW[_find_binary_writer]
        AWFA[auto_wrap_for_ansi]
        SSA[should_strip_ansi]
        SA[strip_ansi]
        BS[binary_streams]
        TS[text_streams]
        WIN[WIN]
    end

    subgraph "Other modules"
        RCD[globals.resolve_color_default]
        FE[exceptions.FileError]
    end

    OPEN --> OS
    OPEN --> LZF
    OPEN --> KOF
    LZF --> OS
    LZF --> FE
    ECHO --> DTS
    ECHO --> FBW
    ECHO --> AWFA
    ECHO --> SSA
    ECHO --> SA
    ECHO --> RCD
    GBS --> BS
    GTS --> TS
    GAD --> WIN
    GAD --> POS
```

---

## Core Components

### Stream Wrappers

These classes adapt file objects to Click's requirements. They are the primary "core components" of this module.

#### `LazyFile`

A file-like wrapper that defers the actual opening of a file until it is first accessed, while still performing early validation checks.

| Aspect | Behavior |
| --- | --- |
| **Purpose** | Safely open files for writing without opening them prematurely. |
| **Standard streams** | If `filename == "-"`, delegates immediately to `open_stream` and tracks whether it should be closed. |
| **Read mode** | Opens and immediately closes the file to surface access errors early. |
| **Delegation** | `__getattr__` proxies all attribute access to the opened file. |
| **Error handling** | Raises `FileError` (from [exceptions](exceptions.md)) if opening fails. |
| **Context manager** | `__exit__` calls `close_intelligently()`, which only closes files that the wrapper itself opened (never `stdin`). |

Key methods:

- `open()` — Opens the file if not already open; raises `FileError` on failure.
- `close()` — Unconditionally closes the underlying file.
- `close_intelligently()` — Closes only if `should_close` is `True`.
- `__iter__()` — Opens the file and iterates over its lines.

#### `KeepOpenFile`

A thin proxy wrapper that prevents a file from being closed when used as a context manager.

| Aspect | Behavior |
| --- | --- |
| **Purpose** | Wrap standard streams so `with open_file(...)` does not close them. |
| **Delegation** | `__getattr__` proxies all attribute access to the wrapped file. |
| **Context manager** | `__exit__` is a no-op, so the underlying file stays open. |
| **Iteration** | `__iter__` delegates to the wrapped file. |

#### `PacifyFlushWrapper`

A wrapper that suppresses `BrokenPipeError` (EPIPE) raised during interpreter shutdown when flushing `sys.stdout`/`sys.stderr`.

| Aspect | Behavior |
| --- | --- |
| **Purpose** | Prevent noisy `BrokenPipeError` tracebacks during final GC. |
| **`flush()`** | Calls the wrapped stream's `flush()`, swallowing only `OSError` with `errno.EPIPE`. |
| **Delegation** | All other attributes are proxied via `__getattr__`. |

---

### Public Helper Functions

#### `echo`

The primary output function, intended as a replacement for `print`. It provides:

- Correct output encoding on Linux.
- Unicode support on the Windows console.
- Support for writing to binary outputs and writing bytes to text outputs.
- Color/style support on Windows (via colorama when available).
- Automatic stripping of ANSI codes when output is not an interactive terminal.
- Guaranteed flushing.

```mermaid
flowchart TD
    A[echo called] --> B{file provided?}
    B -- No --> C{err flag?}
    C -- Yes --> D[file = _default_text_stderr]
    C -- No --> E[file = _default_text_stdout]
    D --> F{file is None?}
    E --> F
    F -- Yes --> G[return - no stream]
    F -- No --> H[continue]
    B -- Yes --> H
    H --> I{message is bytes?}
    I -- Yes --> J[find binary writer]
    J --> K{binary writer found?}
    K -- Yes --> L[write bytes + flush]
    K -- No --> M[fall through]
    I -- No --> N[resolve color default]
    N --> O{should strip ansi?}
    O -- Yes --> P[strip ansi codes]
    O -- No --> Q{on Windows?}
    Q -- Yes --> R[auto-wrap for ansi or strip]
    Q -- No --> S[write text + flush]
    P --> S
    R --> S
    M --> S
```

#### `open_file`

Opens a file with extra behavior:

- `'-'` maps to `stdin`/`stdout` and is wrapped in `KeepOpenFile` so context managers do not close it.
- `lazy=True` returns a `LazyFile`.
- `atomic=True` writes to a temporary file and replaces the target on close (via `_AtomicFile`).

#### `get_binary_stream` / `get_text_stream`

Return system streams for byte or text processing. Valid names are `'stdin'`, `'stdout'`, and `'stderr'`. These delegate to the `binary_streams` and `text_streams` registries in the [compat](platform_and_io_foundation.md) module.

#### `format_filename`

Formats a filename for display, replacing invalid bytes or surrogate escapes with the replacement character `�`. Optionally shortens to the basename.

#### `get_app_dir`

Returns the platform-appropriate config folder for an application, honoring `roaming` (Windows) and `force_posix` flags.

| Platform | Result (for app `"Foo Bar"`) |
| --- | --- |
| macOS | `~/Library/Application Support/Foo Bar` |
| macOS (POSIX) | `~/.foo-bar` |
| Unix | `~/.config/foo-bar` |
| Unix (POSIX) | `~/.foo-bar` |
| Windows (roaming) | `C:\Users\<user>\AppData\Roaming\Foo Bar` |
| Windows (local) | `C:\Users\<user>\AppData\Local\Foo Bar` |

#### `make_default_short_help`

Condenses a help string into a short summary (default max 45 chars), considering only the first paragraph and truncating at sentence boundaries where possible.

#### `make_str`

Converts a value into a valid string, decoding bytes using the filesystem encoding with a UTF-8 fallback.

#### `safecall`

A decorator that wraps a function so it swallows all exceptions and returns `None` on failure.

---

### Internal Helpers

These functions are marked `:meta private:` and are used internally by Click.

#### `_posixify`

Converts a name into a lowercase, hyphen-separated POSIX-style identifier.

#### `_detect_program_name`

Determines the command used to run the program for help text. Returns the file name for executed files, or `python -m name` for modules/packages.

#### `_expand_args`

Simulates Unix shell expansion (user home, environment variables, globbing) using Python functions. Intended for Windows where the shell does not expand arguments.

---

## Data Flow

The following diagram illustrates how a typical file-open request flows through the module and its dependencies.

```mermaid
sequenceDiagram
    participant Caller
    participant Utils as utils.open_file
    participant Lazy as LazyFile
    participant Compat as _compat.open_stream
    participant Atomic as _AtomicFile
    participant Keep as KeepOpenFile

    Caller->>Utils: open_file(filename, mode, lazy, atomic)
    alt lazy=True
        Utils->>Lazy: LazyFile(...)
        Lazy-->>Utils: lazy wrapper
        Utils-->>Caller: LazyFile
        Note over Lazy: File opened on first access
        Lazy->>Compat: open_stream(...)
        Compat-->>Lazy: (file, should_close)
    else lazy=False
        Utils->>Compat: open_stream(...)
        alt atomic=True
            Compat->>Atomic: _AtomicFile(...)
            Atomic-->>Compat: atomic wrapper
        end
        Compat-->>Utils: (file, should_close)
        alt should_close=False
            Utils->>Keep: KeepOpenFile(file)
            Keep-->>Utils: keep-open wrapper
        end
        Utils-->>Caller: file
    end
```

---

## Component Interaction

The module interacts with several other modules. The table below summarizes the key dependencies.

| Dependency | Used By | Purpose |
| --- | --- | --- |
| `_compat.open_stream` | `LazyFile`, `open_file` | Core file/stream opening logic. |
| `_compat._AtomicFile` | `open_stream` (indirectly) | Atomic write support. |
| `_compat._default_text_stdout/stderr` | `echo` | Default output streams. |
| `_compat._find_binary_writer` | `echo` | Locate binary stream for byte output. |
| `_compat.auto_wrap_for_ansi` | `echo` | Windows ANSI color support. |
| `_compat.should_strip_ansi` / `strip_ansi` | `echo` | ANSI code handling. |
| `_compat.binary_streams` / `text_streams` | `get_binary_stream`, `get_text_stream` | Stream registries. |
| `_compat.WIN` | `get_app_dir` | Platform detection. |
| `globals.resolve_color_default` | `echo` | Resolve color default from context. |
| `exceptions.FileError` | `LazyFile.open` | Raise on file-open failure. |

See [platform_and_io_foundation](platform_and_io_foundation.md) for details on the compatibility layer, and [exceptions](exceptions.md) for the exception hierarchy.

---

## Process Flow: Atomic Write

Atomic writes are handled by `open_stream` in the compat layer, but are exposed through `open_file(atomic=True)`. The flow is:

```mermaid
flowchart TD
    A[open_file atomic=True] --> B[open_stream]
    B --> C{filename == '-'?}
    C -- Yes --> D[return standard stream]
    C -- No --> E{atomic?}
    E -- No --> F[regular open]
    E -- Yes --> G{append or exclusive mode?}
    G -- Yes --> H[raise ValueError]
    G -- No --> I[create temp file in same dir]
    I --> J[wrap in _AtomicFile]
    J --> K[on close: os.replace temp -> real]
```

---

## Summary

The `utils` module is the workhorse of Click's I/O foundation. Its stream wrappers (`LazyFile`, `KeepOpenFile`, `PacifyFlushWrapper`) and helper functions (`echo`, `open_file`, `get_app_dir`, etc.) abstract away platform differences and provide safe, predictable behavior for file and stream operations. It depends heavily on the [compat](platform_and_io_foundation.md) module for platform-specific logic and integrates with [globals](command_model_and_definition.md) and [exceptions](exceptions.md) for context resolution and error reporting.
