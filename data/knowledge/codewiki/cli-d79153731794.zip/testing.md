# Testing Module

## Introduction

The `testing` module (`src/click/testing.py`) provides the infrastructure needed to invoke Click command-line applications in an isolated, deterministic environment for unit testing purposes. It is the backbone of Click's own test suite and is the recommended way for downstream applications to test their CLI commands.

The module's central abstraction is the **`CliRunner`**, which captures standard input/output/error streams, overrides environment variables, and mocks interactive prompt functions so that a command can be executed programmatically and its behavior asserted. The captured output is wrapped in a **`Result`** object that exposes convenient string and byte representations of the output.

> **Note:** This module only works in single-threaded systems without concurrency, because it mutates global interpreter state (`sys.stdin`, `sys.stdout`, `sys.stderr`, `os.environ`, and Click internals).

---

## Architecture Overview

The testing module sits at the top of the Click dependency stack. It orchestrates behavior from the [command model and definition](command_model_and_definition.md), the [user interface and presentation](user_interface_and_presentation.md) layer, and the [platform and IO foundation](platform_and_io_foundation.md).

```mermaid
graph TD
    subgraph testing["testing module (src/click/testing.py)"]
        CliRunner
        Result
        StreamMixer
        BytesIOCopy
        EchoingStdin
        NamedTextIOWrapper["_NamedTextIOWrapper"]
        make_input_stream
        pause_echo["_pause_echo"]
    end

    subgraph core["command_model_and_definition"]
        Command
    end

    subgraph ui["user_interface_and_presentation"]
        HelpFormatter
        termui["termui (prompt funcs)"]
    end

    subgraph foundation["platform_and_io_foundation"]
        compat["_compat"]
        utils["utils"]
    end

    CliRunner -->|invokes| Command
    CliRunner -->|uses| StreamMixer
    CliRunner -->|uses| EchoingStdin
    CliRunner -->|uses| NamedTextIOWrapper
    CliRunner -->|uses| make_input_stream
    CliRunner -->|patches| HelpFormatter
    CliRunner -->|patches| termui
    CliRunner -->|patches| utils
    CliRunner -->|uses| compat
    Result -->|created by| CliRunner
    StreamMixer -->|contains| BytesIOCopy
    EchoingStdin -->|wrapped by| pause_echo
```

---

## Core Components

### `CliRunner`

The `CliRunner` is the primary entry point for testing. It provides functionality to invoke a Click command line script in an isolated environment.

**Constructor parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `charset` | `str` | `"utf-8"` | Character set for input and output data. |
| `env` | `Mapping[str, str \| None]` | `{}` | Environment variables to override. |
| `echo_stdin` | `bool` | `False` | If `True`, reading from `<stdin>` writes to `<stdout>`. |

**Key methods:**

- **`invoke(cli, args, input, env, catch_exceptions, color, **extra)`** — Invokes a command in an isolated environment and returns a `Result`. Arguments may be a string (parsed via `shlex.split`) or a sequence. The `extra` keyword arguments are forwarded to `Command.main`.
- **`isolation(input, env, color)`** — A context manager that sets up the isolated environment. It rebinds `sys.stdin/stdout/stderr`, patches prompt functions, and applies environment overrides. Returns a tuple of `(stdout, stderr, output)` byte streams.
- **`isolated_filesystem(temp_dir)`** — A context manager that creates a temporary directory and changes the CWD into it, isolating tests that touch the filesystem.
- **`get_default_prog_name(cli)`** — Returns the program name (`cli.name` or `"root"`).
- **`make_env(overrides)`** — Merges the runner's base env with per-invocation overrides.

### `Result`

Holds the captured result of an invoked CLI script. It is created by `CliRunner.invoke` and exposes both raw bytes and decoded strings.

| Attribute / Property | Description |
|----------------------|-------------|
| `stdout_bytes` / `stdout` | Standard output as bytes / decoded string. |
| `stderr_bytes` / `stderr` | Standard error as bytes / decoded string. |
| `output_bytes` / `output` | A mix of stdout and stderr in write order, as the user would see it in a terminal. |
| `return_value` | The value returned from the invoked command. |
| `exit_code` | The integer exit code. |
| `exception` | The exception raised, if any. |
| `exc_info` | Exception info tuple `(type, value, traceback)`. |

> **Version note (8.2):** `stderr_bytes` is no longer optional, `output_bytes` was introduced, and the `mix_stderr` parameter was removed. The `output` property is now an independent stream mixing stdout and stderr rather than a proxy for `stdout`.

### `StreamMixer`

Mixes `<stdout>` and `<stderr>` streams into a single ordered `output` stream. It exposes three `io.BytesIO` attributes:

- `output` — the combined stream.
- `stdout` — a `BytesIOCopy` that copies writes into `output`.
- `stderr` — a `BytesIOCopy` that copies writes into `output`.

### `BytesIOCopy`

A subclass of `io.BytesIO` that copies everything written to it into a second `BytesIO` (`copy_to`). This is the mechanism that allows `StreamMixer` to produce both individual and combined streams simultaneously.

### `EchoingStdin`

A binary input stream wrapper that echoes everything read from the underlying input to an output stream. Used when `echo_stdin=True` to simulate a terminal echoing typed input. Echoing can be temporarily suspended via the `_pause_echo` context manager (used by prompt functions to avoid double-echoing).

### `_NamedTextIOWrapper`

A thin subclass of `io.TextIOWrapper` that allows overriding the `name` and `mode` properties. This is used to give the mocked streams realistic names such as `<stdin>`, `<stdout>`, and `<stderr>`.

### `make_input_stream(input, charset)`

A helper that normalizes various input types into a binary stream:

- If `input` already has a `read` method, it is converted via `_find_binary_reader` (from the [platform and IO foundation](platform_and_io_foundation.md)).
- `None` becomes an empty `BytesIO`.
- `str` is encoded using the given charset.

---

## Data Flow

The following diagram illustrates the flow of data during a `CliRunner.invoke` call.

```mermaid
sequenceDiagram
    participant Test as Test Code
    participant Runner as CliRunner
    participant Iso as isolation()
    participant Mixer as StreamMixer
    participant Cmd as Command.main
    participant Result as Result

    Test->>Runner: invoke(cli, args, input, env)
    Runner->>Iso: enter isolation context
    Iso->>Mixer: create StreamMixer
    Iso->>Iso: rebind sys.stdin/stdout/stderr
    Iso->>Iso: patch prompt funcs & env
    Iso-->>Runner: (stdout, stderr, output) streams
    Runner->>Cmd: cli.main(args, prog_name, **extra)
    Cmd-->>Runner: return_value / SystemExit
    Runner->>Mixer: flush & getvalue()
    Runner->>Result: construct Result(...)
    Runner->>Iso: exit isolation (restore globals)
    Runner-->>Test: Result
```

---

## Isolation Process Flow

The `isolation` context manager performs a careful save-and-restore of global state. The process is:

```mermaid
flowchart TD
    A[Enter isolation] --> B[Build binary input stream]
    B --> C[Save old stdin/stdout/stderr & FORCED_WIDTH]
    C --> D[Set FORCED_WIDTH = 80]
    D --> E[Create StreamMixer]
    E --> F{echo_stdin?}
    F -->|Yes| G[Wrap input in EchoingStdin]
    F -->|No| H[Skip echo wrapping]
    G --> I[Rebind sys.stdin/stdout/stderr to _NamedTextIOWrapper]
    H --> I
    I --> J[Patch termui prompt funcs & should_strip_ansi]
    J --> K[Apply env overrides, saving old values]
    K --> L[Yield streams to caller]
    L --> M[Restore env, streams, prompt funcs, FORCED_WIDTH]
    M --> N[Exit isolation]
```

---

## Component Interaction

```mermaid
classDiagram
    class CliRunner {
        +charset: str
        +env: Mapping
        +echo_stdin: bool
        +invoke(cli, args, input, env, catch_exceptions, color, **extra) Result
        +isolation(input, env, color) Iterator
        +isolated_filesystem(temp_dir) Iterator
        +get_default_prog_name(cli) str
        +make_env(overrides) Mapping
    }

    class Result {
        +stdout_bytes: bytes
        +stderr_bytes: bytes
        +output_bytes: bytes
        +return_value: Any
        +exit_code: int
        +exception: BaseException
        +exc_info: tuple
        +output: str
        +stdout: str
        +stderr: str
    }

    class StreamMixer {
        +output: BytesIO
        +stdout: BytesIOCopy
        +stderr: BytesIOCopy
    }

    class BytesIOCopy {
        +copy_to: BytesIO
        +write(b) int
        +flush() None
    }

    class EchoingStdin {
        +read(n) bytes
        +readline(n) bytes
        +readlines() list
    }

    class _NamedTextIOWrapper {
        +name: str
        +mode: str
    }

    CliRunner --> Result : creates
    CliRunner --> StreamMixer : uses
    CliRunner --> EchoingStdin : uses
    CliRunner --> _NamedTextIOWrapper : uses
    StreamMixer --> BytesIOCopy : contains
```

---

## Dependencies

The testing module depends on several other Click modules. Rather than duplicating their documentation, refer to the linked modules:

| Dependency | Purpose in testing |
|------------|--------------------|
| [command_model_and_definition](command_model_and_definition.md) (`Command`) | The command object passed to `invoke` and executed via `Command.main`. |
| [user_interface_and_presentation](user_interface_and_presentation.md) (`HelpFormatter`, `termui`) | `formatting.FORCED_WIDTH` is pinned to 80 for deterministic help output; `termui` prompt functions are patched to read from the mocked stdin. |
| [platform_and_io_foundation](platform_and_io_foundation.md) (`_compat`, `utils`) | `_find_binary_reader` normalizes input streams; `utils.should_strip_ansi` and `_compat.should_strip_ansi` are patched to control ANSI color stripping. |

---

## Usage Example

```python
from click.testing import CliRunner
from myapp import cli

def test_hello():
    runner = CliRunner()
    result = runner.invoke(cli, ["hello", "--name", "World"])
    assert result.exit_code == 0
    assert "Hello World" in result.output

def test_filesystem_isolation():
    runner = CliRunner()
    with runner.isolated_filesystem():
        with open("data.txt", "w") as f:
            f.write("content")
        result = runner.invoke(cli, ["process", "data.txt"])
        assert result.exit_code == 0
```

---

## Version History Highlights

- **8.2** — Introduced `BytesIOCopy`, `StreamMixer`, and `output_bytes`/`output`; removed `mix_stderr`; `stderr_bytes` is now always present.
- **8.0** — Added `return_value` to `Result`; added `temp_dir` to `isolated_filesystem`; `<stderr>` opened with `errors="backslashreplace"`.
- **4.0** — Added the `color` parameter to `invoke` and `isolation`.
- **3.0** — Added `catch_exceptions` and `exc_info`.

---

## Related Modules

- [command_model_and_definition](command_model_and_definition.md) — The `Command` objects being tested.
- [user_interface_and_presentation](user_interface_and_presentation.md) — Help formatting and terminal UI patched during isolation.
- [platform_and_io_foundation](platform_and_io_foundation.md) — Low-level IO and compatibility helpers used for stream normalization.
- [exceptions](exceptions.md) — Exceptions (`SystemExit`, `ClickException`) captured and surfaced through `Result`.
