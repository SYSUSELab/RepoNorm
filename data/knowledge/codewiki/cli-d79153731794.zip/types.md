# Types Module

## Introduction

The `types` module (`src/click/types.py`) implements Click's **parameter type system**. It defines the `ParamType` base class and a rich hierarchy of concrete types that are responsible for **validating and converting** raw values (typically strings from the command line, environment variables, or prompts) into the correct Python types.

Every `Parameter` (an `Option` or `Argument`) is associated with a `ParamType` instance. When a value is consumed from any source, the parameter delegates conversion and validation to its type. This module is therefore the bridge between the raw textual input handled by the [parser](parser.md) and the strongly-typed values delivered to command callbacks.

Key responsibilities:

- **Conversion**: Turn strings into `int`, `float`, `bool`, `datetime`, `uuid.UUID`, file handles, paths, tuples, etc.
- **Validation**: Enforce ranges, choices, existence/permission checks, and arity.
- **Help integration**: Provide metavars and missing-value messages for help output.
- **Shell completion**: Supply completion candidates or special markers for the [shell completion](shell_completion.md) system.
- **Introspection**: Expose structured metadata via `to_info_dict()` for documentation tooling.

## Architecture Overview

The type system is organized around a single abstract base class, `ParamType`, with two intermediate base classes (`CompositeParamType` and `_NumberParamTypeBase`) and a set of concrete leaf types.

```mermaid
classDiagram
    class ParamType {
        <<abstract>>
        +bool is_composite
        +int arity
        +str name
        +str envvar_list_splitter
        +to_info_dict()
        +__call__(value, param, ctx)
        +get_metavar(param)
        +get_missing_message(param)
        +convert(value, param, ctx)
        +split_envvar_value(rv)
        +fail(message, param, ctx)
        +shell_complete(ctx, param, incomplete)
    }

    class CompositeParamType {
        +bool is_composite = True
        +arity()*
    }

    class _NumberParamTypeBase {
        +type _number_class
        +convert(value, param, ctx)
    }

    class _NumberRangeBase {
        +min, max
        +min_open, max_open
        +clamp
        +convert(value, param, ctx)
        +_clamp(bound, dir, open)*
        +_describe_range()
    }

    class FuncParamType
    class UnprocessedParamType
    class StringParamType
    class Choice
    class DateTime
    class BoolParamType
    class UUIDParameterType
    class File
    class Path
    class Tuple

    class IntParamType
    class FloatParamType
    class IntRange
    class FloatRange

    ParamType <|-- CompositeParamType
    ParamType <|-- FuncParamType
    ParamType <|-- UnprocessedParamType
    ParamType <|-- StringParamType
    ParamType <|-- Choice
    ParamType <|-- DateTime
    ParamType <|-- BoolParamType
    ParamType <|-- UUIDParameterType
    ParamType <|-- File
    ParamType <|-- Path
    ParamType <|-- _NumberParamTypeBase

    CompositeParamType <|-- Tuple
    _NumberParamTypeBase <|-- IntParamType
    _NumberParamTypeBase <|-- FloatParamType
    _NumberParamTypeBase <|-- _NumberRangeBase
    _NumberRangeBase <|-- IntRange
    _NumberRangeBase <|-- FloatRange
    IntParamType <|-- IntRange
    FloatParamType <|-- FloatRange
```

### Singleton Instances

The module exposes pre-built singleton instances that are used throughout Click and are also part of the public API:

| Instance | Class | Description |
| --- | --- | --- |
| `UNPROCESSED` | `UnprocessedParamType` | No-op type; leaves bytes untouched. |
| `STRING` | `StringParamType` | Default type; decodes bytes to `str`. |
| `INT` | `IntParamType` | Integer values. |
| `FLOAT` | `FloatParamType` | Floating-point values. |
| `BOOL` | `BoolParamType` | Boolean flags. |
| `UUID` | `UUIDParameterType` | `uuid.UUID` values. |

## Core Component: `ParamType`

`ParamType` is the abstract base class that all types inherit from. It defines the contract that custom types must fulfill.

### Contract for Custom Types

To implement a custom type, a subclass must:

1. Set the `name` class attribute (a descriptive name).
2. Ensure calling an instance with `None` returns `None` (handled by the default `__call__`).
3. Implement `convert()` to convert string values to the target type.
4. Ensure `convert()` accepts values that are already the correct type.
5. Handle the case where `ctx` and `param` are `None` (occurs during prompt input conversion).

### Key Attributes

| Attribute | Type | Purpose |
| --- | --- | --- |
| `is_composite` | `ClassVar[bool]` | Whether the type consumes multiple values (e.g. `Tuple`). |
| `arity` | `ClassVar[int]` | Number of values the type consumes. |
| `name` | `str` | Descriptive name used in help and error messages. |
| `envvar_list_splitter` | `ClassVar[str \| None]` | Splitter for list values from env vars. `None` means whitespace; `File`/`Path` use `os.path.pathsep`. |

### Key Methods

- **`__call__(value, param, ctx)`** — Entry point. Returns `None` for `None` input, otherwise delegates to `convert()`.
- **`convert(value, param, ctx)`** — The core conversion/validation hook. The default implementation returns the value unchanged.
- **`get_metavar(param)`** — Returns the metavar shown in help (e.g. `[a|b|c]` for `Choice`).
- **`get_missing_message(param)`** — Optional extra info shown when a value is missing.
- **`split_envvar_value(rv)`** — Splits an environment variable value using `envvar_list_splitter`.
- **`fail(message, param, ctx)`** — Raises a `BadParameter` exception with the given message.
- **`shell_complete(ctx, param, incomplete)`** — Returns completion candidates (default: empty list).
- **`to_info_dict()`** — Returns structured metadata for documentation tooling.

## Concrete Type Reference

### Scalar Types

#### `StringParamType` (`STRING`)
The implicit default type. Decodes `bytes` to `str` using the argv encoding, falling back to the filesystem encoding and finally UTF-8 with replacement. Non-bytes values are coerced with `str()`.

#### `UnprocessedParamType` (`UNPROCESSED`)
A no-op type that returns the value unchanged. Useful for path-like values that may appear as either bytes or unicode, where no string conversion should occur.

#### `IntParamType` (`INT`) and `FloatParamType` (`FLOAT`)
Both derive from `_NumberParamTypeBase`, which converts using the `_number_class` (`int` or `float`). On failure, they raise a `BadParameter` with a descriptive message.

#### `BoolParamType` (`BOOL`)
Converts values to booleans. Accepts `True`/`False` directly, and recognizes the following string forms (case-insensitive, stripped):

- **True**: `1`, `true`, `t`, `yes`, `y`, `on`
- **False**: `0`, `false`, `f`, `no`, `n`, `off`

#### `UUIDParameterType` (`UUID`)
Converts strings to `uuid.UUID` objects, passing through existing `UUID` instances.

#### `DateTime`
Converts date strings into `datetime` objects using a configurable list of `strptime` format strings. Defaults to `%Y-%m-%d`, `%Y-%m-%dT%H:%M:%S`, and `%Y-%m-%d %H:%M:%S`. Formats are tried in order; the first successful parse wins.

#### `FuncParamType`
Wraps an arbitrary callable as a type. The callable's `__name__` becomes the type name. On `ValueError`, the value is stringified and passed to `fail()`.

### Range Types

`_NumberRangeBase` extends `_NumberParamTypeBase` to add bounds checking. It is configured with:

| Parameter | Description |
| --- | --- |
| `min` / `max` | Inclusive or exclusive bounds. |
| `min_open` / `max_open` | If `True`, the corresponding bound is exclusive. |
| `clamp` | If `True`, out-of-range values are clamped to the boundary instead of failing. |

- **`IntRange`** — Restricts an `INT` to a range. Clamping to an open bound adjusts by ±1.
- **`FloatRange`** — Restricts a `FLOAT` to a range. Clamping is **not supported** for open bounds (raises `TypeError` at construction and `RuntimeError` at clamp time).

The `_describe_range()` method produces human-readable range descriptions (e.g. `0<=x<=10`) used in error messages and `repr()`.

### Choice

`Choice` validates a value against a fixed sequence of string choices.

- **`case_sensitive`** — When `False`, comparison is case-insensitive (via `casefold`).
- **Token normalization** — If `ctx.token_normalize_func` is set, both the value and choices are normalized before comparison.
- **Result preservation** — The returned value is always one of the *originally passed* choices, regardless of normalization.
- **`get_metavar()`** — Produces `{a|b|c}` for required arguments and `[a|b|c]` for options/optional arguments. For options with `show_choices=False`, it derives metavars from the choice types.
- **`shell_complete()`** — Completes choices matching the incomplete prefix.

### File and Path Types

#### `File`
Declares a parameter as a file for reading or writing. Files are automatically closed when the context tears down.

| Parameter | Description |
| --- | --- |
| `mode` | File mode (default `"r"`). |
| `encoding` / `errors` | Encoding and error handling. |
| `lazy` | Open on first IO instead of immediately. Defaults to lazy for write modes; non-lazy for stdin/stdout and read modes. |
| `atomic` | Write to a temp file and move into place on completion. |

The special value `-` maps to stdin/stdout. File-like objects are passed through unchanged. Lazy files are registered with `ctx.call_on_close()` for cleanup. Uses `envvar_list_splitter = os.path.pathsep`.

#### `Path`
Similar to `File` but returns the filename rather than an open handle, with optional validation:

| Parameter | Description |
| --- | --- |
| `exists` | Require the path to exist. |
| `file_okay` / `dir_okay` | Allow files / directories. |
| `readable` / `writable` / `executable` | Permission checks. |
| `resolve_path` | Make absolute and resolve symlinks. |
| `allow_dash` | Allow `-` as a standard-stream marker. |
| `path_type` | Coerce the result to a type (e.g. `pathlib.Path`). |

The `name` attribute is dynamically set to `"file"`, `"directory"`, or `"path"` based on `file_okay`/`dir_okay`.

### Composite Types

#### `CompositeParamType`
Base class for types that consume multiple values. Sets `is_composite = True` and requires subclasses to implement `arity`.

#### `Tuple`
Applies a distinct type to each item of a fixed-length tuple. Requires `nargs` to equal the tuple's arity. Validates that the number of values matches, then converts each item with its corresponding type.

## Type Inference: `convert_type()`

The `convert_type(ty, default)` function maps Python types (or defaults) to `ParamType` instances. This is how `Parameter` resolves its `type` argument.

```mermaid
flowchart TD
    A[convert_type ty, default] --> B{ty is None and default set?}
    B -- yes --> C[Infer ty from default]
    C --> D{default is tuple/list?}
    D -- yes --> E[Build tuple of item types]
    D -- no --> F[ty = type of default]
    B -- no --> G{ty is tuple?}
    E --> G
    F --> G
    G -- yes --> H[return Tuple ty]
    G -- no --> I{ty is ParamType?}
    I -- yes --> J[return ty]
    I -- no --> K{ty is str/None?}
    K -- yes --> L[return STRING]
    K -- no --> M{ty is int?}
    M -- yes --> N[return INT]
    M -- no --> O{ty is float?}
    O -- yes --> P[return FLOAT]
    O -- no --> Q{ty is bool?}
    Q -- yes --> R[return BOOL]
    Q -- no --> S{guessed_type?}
    S -- yes --> T[return STRING]
    S -- no --> U[return FuncParamType ty]
```

Notable behaviors:

- If `ty` is `None` and a `default` is provided, the type is **guessed** from the default value.
- A tuple/list default produces a `Tuple` type; nested tuples/lists detect inner item types.
- An uninstantiated `ParamType` subclass raises an `AssertionError` (in debug mode).
- Any other callable type is wrapped in `FuncParamType`.

## Data Flow: Value Conversion

The following diagram shows how a raw value flows from a source through the type system into a command callback.

```mermaid
sequenceDiagram
    participant Parser as Parser / Env / Prompt
    participant Param as Parameter
    participant Type as ParamType
    participant Ctx as Context
    participant CB as Command Callback

    Parser->>Param: raw value (str)
    Param->>Param: consume_value() determines source
    Param->>Param: type_cast_value()
    Param->>Type: __call__(value, param, ctx)
    Type->>Type: convert(value, param, ctx)
    alt conversion fails
        Type->>Param: fail() -> BadParameter
        Param->>Ctx: propagate error
    else conversion succeeds
        Type-->>Param: converted value
    end
    Param->>Param: process_value() (required check, callback)
    Param->>Ctx: store in ctx.params
    Ctx->>CB: invoke with typed value
```

## Integration with Other Modules

```mermaid
graph LR
    Types[types.py]
    Core[core.py<br/>Parameter, Context]
    Parser[parser.py]
    Exceptions[exceptions.py<br/>BadParameter]
    Utils[utils.py<br/>LazyFile, format_filename]
    Compat[_compat.py<br/>open_stream, _get_argv_encoding]
    Shell[shell_completion.py<br/>CompletionItem]

    Core -->|uses convert_type, ParamType| Types
    Types -->|raises| Exceptions
    Types -->|uses| Utils
    Types -->|uses| Compat
    Types -->|returns| Shell
    Parser -->|produces raw values for| Core
```

### Dependencies

- **[core](core.md)** — `Parameter` holds a `ParamType` and calls it during `type_cast_value()`; `Context` provides `token_normalize_func`, `call_on_close()`, and `resilient_parsing`.
- **[exceptions](exceptions.md)** — `ParamType.fail()` raises `BadParameter`; `File`/`Path` errors surface as `FileError`.
- **[utils](utils.md)** — `LazyFile` for lazy file opening; `format_filename` and `safecall` for safe error formatting and cleanup.
- **[_compat](compat.md)** — `open_stream` for opening files/streams; `_get_argv_encoding` for byte decoding.
- **[shell_completion](shell_completion.md)** — `shell_complete()` returns `CompletionItem` objects; `File`/`Path` return special `type="file"`/`type="dir"` markers.
- **[parser](parser.md)** — Produces the raw string values that types later convert.

## `OptionHelpExtra` TypedDict

`OptionHelpExtra` is a `TypedDict` (with `total=False`) describing optional extra fields that can be attached to option help records:

| Key | Type | Description |
| --- | --- | --- |
| `envvars` | `tuple[str, ...]` | Environment variables associated with the option. |
| `default` | `str` | Rendered default value. |
| `range` | `str` | Range description (from range types). |
| `required` | `str` | Required marker text. |

This is consumed by the help formatting machinery in [formatting](formatting.md).

## Summary

The `types` module is the heart of Click's value handling. Its layered class hierarchy — `ParamType` → intermediate bases → concrete types — provides a consistent, extensible contract for converting and validating input from every source. Custom types integrate seamlessly by subclassing `ParamType` and implementing `convert()`, while the built-in types cover the vast majority of CLI needs: scalars, ranges, choices, dates, files, paths, and composite tuples.
