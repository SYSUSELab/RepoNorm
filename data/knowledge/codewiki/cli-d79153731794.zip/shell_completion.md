# Shell Completion Module

## Introduction

The `shell_completion` module (`src/click/shell_completion.py`) provides tab-completion support for Click-based command line applications across multiple shells: **Bash**, **Zsh**, and **Fish**. It enables users to press `<TAB>` while typing a command to receive context-aware suggestions for subcommands, option names, option values, and file/directory paths.

The module is part of the broader [user interface and presentation](user_interface_and_presentation.md) layer of Click. It bridges the command model defined in [command_model_and_definition](command_model_and_definition.md) with the type system in [argument_parsing_and_type_system](argument_parsing_and_type_system.md), translating parsed command-line state into shell-specific completion output.

### Key Responsibilities

- **Shell script generation** — Produce the shell-specific "source" script that registers a completion function with the shell.
- **Completion resolution** — Parse the current command-line state to determine which command or parameter should provide completions.
- **Completion formatting** — Format completion results into the protocol each shell expects.
- **Extensibility** — Allow custom shells and custom completion sources to be registered.

---

## Architecture Overview

The module is organized around a base class (`ShellComplete`) with one concrete subclass per supported shell. A module-level dispatcher (`shell_complete`) routes completion requests to the appropriate subclass.

```mermaid
graph TD
    subgraph "Entry Points"
        MAIN["Command.main()<br/>(core.py)"]
        MSC["Command._main_shell_completion()"]
    end

    subgraph "shell_completion.py"
        SC["shell_complete()<br/>dispatcher"]
        REG["_available_shells<br/>registry"]
        GAC["get_completion_class()"]
        ACC["add_completion_class()"]

        BASE["ShellComplete<br/>(base class)"]
        BASH["BashComplete"]
        ZSH["ZshComplete"]
        FISH["FishComplete"]

        CI["CompletionItem"]
        SAS["split_arg_string()"]
    end

    subgraph "Resolution Helpers"
        RC["_resolve_context()"]
        RI["_resolve_incomplete()"]
        IIA["_is_incomplete_argument()"]
        IIO["_is_incomplete_option()"]
        SOO["_start_of_option()"]
    end

    MAIN --> MSC
    MSC --> SC
    SC --> GAC
    GAC --> REG
    ACC --> REG
    REG --> BASH
    REG --> ZSH
    REG --> FISH

    BASE --> BASH
    BASE --> ZSH
    BASE --> FISH

    BASE --> RC
    BASE --> RI
    RI --> IIA
    RI --> IIO
    IIO --> SOO
    BASE --> SAS
    BASE --> CI
```

### Component Summary

| Component | Type | Purpose |
|-----------|------|---------|
| `shell_complete` | Function | Top-level dispatcher invoked by `Command.main()`. |
| `ShellComplete` | Base class | Common completion logic; defines the `source`/`complete` protocol. |
| `BashComplete` | Subclass | Bash-specific argument parsing and output formatting. |
| `ZshComplete` | Subclass | Zsh-specific argument parsing and output formatting. |
| `FishComplete` | Subclass | Fish-specific argument parsing and output formatting. |
| `CompletionItem` | Data class | Represents a single completion suggestion with metadata. |
| `add_completion_class` | Function | Registers a custom `ShellComplete` subclass. |
| `get_completion_class` | Function | Looks up a registered shell class by name. |
| `split_arg_string` | Function | Shell-like argument splitting tolerant of incomplete input. |

---

## Component Details

### `CompletionItem`

`CompletionItem` is a lightweight value object (using `__slots__`) that represents a single completion suggestion along with metadata.

```python
CompletionItem(value, type="plain", help=None, **kwargs)
```

| Attribute | Description |
|-----------|-------------|
| `value` | The completion suggestion text. |
| `type` | Special handling hint: `"plain"`, `"dir"`, or `"file"`. |
| `help` | Optional help string shown next to the value (Zsh/Fish). |
| `_info` | Arbitrary extra metadata, accessible via attribute access. |

The `type` field is the key mechanism for delegating path completion back to the shell. When a parameter's type (e.g., [`Path`](argument_parsing_and_type_system.md) or [`File`](argument_parsing_and_type_system.md)) returns a `CompletionItem` with `type="dir"` or `type="file"`, the shell script invokes its native path-completion machinery rather than using Click-provided values.

Arbitrary metadata can be attached and accessed dynamically:

```python
item = CompletionItem("value", custom_attr="data")
item.custom_attr  # "data"
item.missing_attr  # None
```

### `ShellComplete` (Base Class)

`ShellComplete` defines the completion protocol. Subclasses override class attributes and two methods to specialize behavior.

**Class attributes:**

- `name` — The shell's registration name (used in completion instructions like `bash_source`).
- `source_template` — A `%`-style format string for the shell script.

**Instance attributes** (set in `__init__`): `cli`, `ctx_args`, `prog_name`, `complete_var`.

**Key methods:**

| Method | Responsibility |
|--------|----------------|
| `func_name` (property) | Derives a safe shell function name from `prog_name`. |
| `source_vars()` | Provides variables for formatting `source_template`. |
| `source()` | Produces the shell script that registers the completion function. |
| `get_completion_args()` | *(abstract)* Extracts `(args, incomplete)` from shell env vars. |
| `get_completions()` | Resolves the target object and calls its `shell_complete`. |
| `format_completion()` | *(abstract)* Formats a `CompletionItem` for the shell. |
| `complete()` | Orchestrates the full completion flow. |

The `func_name` property sanitizes the program name to produce a valid shell identifier:

```python
safe_name = re.sub(r"\W*", "", self.prog_name.replace("-", "_"), flags=re.ASCII)
return f"_{safe_name}_completion"
```

### Shell-Specific Subclasses

Each subclass implements `get_completion_args()` and `format_completion()` to match its shell's conventions.

```mermaid
classDiagram
    class ShellComplete {
        +name: ClassVar[str]
        +source_template: ClassVar[str]
        +cli
        +ctx_args
        +prog_name
        +complete_var
        +func_name() str
        +source_vars() dict
        +source() str
        +get_completion_args()* tuple
        +get_completions(args, incomplete) list
        +format_completion(item)* str
        +complete() str
    }
    class BashComplete {
        +name = "bash"
        +_check_version()
        +get_completion_args() tuple
        +format_completion(item) str
    }
    class ZshComplete {
        +name = "zsh"
        +get_completion_args() tuple
        +format_completion(item) str
    }
    class FishComplete {
        +name = "fish"
        +get_completion_args() tuple
        +format_completion(item) str
    }
    ShellComplete <|-- BashComplete
    ShellComplete <|-- ZshComplete
    ShellComplete <|-- FishComplete
```

#### `BashComplete`

- **Version check**: `_check_version()` runs `bash -c 'echo "${BASH_VERSION}"'` and warns if the version is older than 4.4 (the minimum for the `nosort` option).
- **Argument parsing**: Reads `COMP_WORDS` and `COMP_CWORD` environment variables.
- **Output format**: `"{type},{value}"` — a comma-separated pair.

#### `ZshComplete`

- **Argument parsing**: Reads `COMP_WORDS` and `COMP_CWORD` (same as Bash).
- **Output format**: Three newline-separated fields — `"{type}\n{value}\n{help or '_'}"`. This allows Zsh to display descriptions alongside completions.

#### `FishComplete`

- **Argument parsing**: Reads `COMP_WORDS` and `COMP_CWORD`. Fish stores the partial word in both, so the trailing partial is removed from the complete args.
- **Output format**: `"{type},{value}\t{help}"` when help is present, otherwise `"{type},{value}"`.

### Shell Script Templates

The module embeds three template strings that define the shell-side completion functions:

- `_SOURCE_BASH` — Defines a function that calls the program with `COMP_WORDS`/`COMP_CWORD` set, then parses the comma-separated response and populates `COMPREPLY`. Uses `compopt -o dirnames` / `compopt -o default` for path completion.
- `_SOURCE_ZSH` — Defines a `#compdef` function that parses the three-field response and uses `_describe`, `compadd`, and `_path_files` for rich completion.
- `_SOURCE_FISH` — Defines a Fish function that parses the response and delegates to `__fish_complete_directories` / `__fish_complete_path`.

---

## Completion Flow

The end-to-end completion process spans the command model, the shell, and this module.

```mermaid
sequenceDiagram
    participant User
    participant Shell
    participant Script as Shell Script
    participant Main as Command.main()
    participant SC as shell_complete()
    participant Comp as ShellComplete subclass
    participant Ctx as Context / Command / Parameter

    User->>Shell: types command + <TAB>
    Shell->>Script: invokes registered completion function
    Script->>Main: runs program with COMP_* env vars + complete_var
    Main->>Main: _main_shell_completion() detects complete_var
    Main->>SC: shell_complete(cli, ctx_args, prog_name, complete_var, instruction)
    SC->>SC: parse instruction into (shell, instruction)
    SC->>Comp: instantiate subclass
    alt instruction == "source"
        Comp->>Script: source() returns shell script
    else instruction == "complete"
        Comp->>Comp: get_completion_args()
        Comp->>Ctx: _resolve_context() + _resolve_incomplete()
        Ctx->>Comp: obj.shell_complete(ctx, incomplete)
        Comp->>Comp: format_completion() per item
        Comp->>Script: complete() returns formatted output
    end
    Script->>Shell: populate completion candidates
    Shell->>User: display suggestions
```

### Step-by-Step

1. **Detection** — [`Command.main()`](command_model_and_definition.md) calls `_main_shell_completion()`, which checks for the `complete_var` environment variable (default `_{PROG_NAME}_COMPLETE`). If present, it invokes `shell_complete()` and exits.

2. **Dispatch** — `shell_complete()` splits the instruction (e.g., `bash_complete`) into shell name and instruction, looks up the class via `get_completion_class()`, and instantiates it.

3. **Source vs. Complete** — If the instruction is `source`, the shell script is emitted. If `complete`, the completion data is produced.

4. **Argument extraction** — `get_completion_args()` reads shell-specific environment variables to produce `(args, incomplete)`.

5. **Context resolution** — `_resolve_context()` builds the context hierarchy by traversing complete arguments through groups and subcommands, using `resilient_parsing=True` to avoid side effects.

6. **Incomplete resolution** — `_resolve_incomplete()` determines which object (command or parameter) should handle the incomplete value.

7. **Completion generation** — The resolved object's `shell_complete()` method returns a list of `CompletionItem`s.

8. **Formatting** — `format_completion()` converts each item into the shell's expected format.

---

## Completion Resolution Logic

The resolution helpers are the heart of the module. They determine *what* should be completed based on the current parsing state.

```mermaid
flowchart TD
    START["_resolve_incomplete(ctx, args, incomplete)"]
    EQ{"incomplete == '='?"}
    HAS_EQ{"'=' in incomplete<br/>and starts with option?"}
    DASH{"'--' not in args<br/>and incomplete starts with option?"}
    OPT{"Any option needs a value?<br/>_is_incomplete_option"}
    ARG{"Any argument can accept values?<br/>_is_incomplete_argument"}
    CMD["Return ctx.command<br/>(option/command names)"]
    PARAM["Return param<br/>(value completion)"]

    START --> EQ
    EQ -->|yes| CLEAR["incomplete = ''"]
    EQ -->|no| HAS_EQ
    CLEAR --> HAS_EQ
    HAS_EQ -->|yes| SPLIT["split name=value,<br/>append name to args"]
    HAS_EQ -->|no| DASH
    SPLIT --> DASH
    DASH -->|yes| CMD
    DASH -->|no| OPT
    OPT -->|yes| PARAM
    OPT -->|no| ARG
    ARG -->|yes| PARAM
    ARG -->|no| CMD
```

### `_resolve_context`

Builds the context hierarchy by walking through complete arguments. It handles both regular groups and **chained** groups (where multiple subcommands can be invoked in sequence). It uses `resilient_parsing=True` so that no prompts, callbacks, or errors are triggered during completion.

### `_resolve_incomplete`

Determines the completion target:

- **`=` handling** — Different shells treat `--opt=value` differently. The function normalizes by splitting on `=` and discarding it.
- **Option name completion** — If the incomplete value starts with an option prefix and `--` hasn't been seen, the command provides option-name completions.
- **Option value completion** — If the last complete arg is an option name awaiting a value (`_is_incomplete_option`), that option provides value completions.
- **Argument value completion** — The first argument that can still accept values (`_is_incomplete_argument`) provides value completions.
- **Command name completion** — Otherwise, the command provides subcommand-name completions.

### `_is_incomplete_argument`

Returns `True` when an `Argument` can still accept values, considering:
- `nargs == -1` (variadic arguments always accept more).
- The value did not come from the command line.
- A multi-value argument (`nargs > 1`) has fewer values than required.

### `_is_incomplete_option`

Returns `True` when an `Option` needs a value. Flags and counting options are excluded. It scans backwards through args (up to `nargs` positions) to find the most recent option and checks whether it matches the parameter.

### `_start_of_option`

Checks whether a value begins with one of the context's option prefixes (`ctx._opt_prefixes`).

---

## Integration with the Type System

Completion for parameter *values* is delegated to the parameter's type via [`ParamType.shell_complete()`](argument_parsing_and_type_system.md). The `Parameter.shell_complete()` method (in [command_model_and_definition](command_model_and_definition.md)) first checks for a custom `shell_complete` callback, then falls back to the type.

```mermaid
graph LR
    P["Parameter.shell_complete()"]
    CUSTOM{"Custom shell_complete<br/>callback set?"}
    TYPE["ParamType.shell_complete()"]
    CHOICE["Choice → matching choices"]
    PATH["Path → type='dir'/'file'"]
    FILE["File → type='file'"]
    DEFAULT["Default → []"]

    P --> CUSTOM
    CUSTOM -->|yes| CB["Invoke callback,<br/>wrap strings in CompletionItem"]
    CUSTOM -->|no| TYPE
    TYPE --> CHOICE
    TYPE --> PATH
    TYPE --> FILE
    TYPE --> DEFAULT
```

| Type | Completion Behavior |
|------|---------------------|
| [`Choice`](argument_parsing_and_type_system.md) | Returns choices matching the incomplete prefix (respecting case sensitivity). |
| [`Path`](argument_parsing_and_type_system.md) | Returns a single `CompletionItem` with `type="dir"` or `type="file"` to delegate to the shell. |
| [`File`](argument_parsing_and_type_system.md) | Returns a single `CompletionItem` with `type="file"`. |
| Other types | Return an empty list (no value completion). |

Commands and groups also implement `shell_complete()`:

- [`Command.shell_complete()`](command_model_and_definition.md) — Completes option names and chained sibling commands.
- [`Group.shell_complete()`](command_model_and_definition.md) — Completes visible subcommand names, then delegates to `Command.shell_complete()`.

---

## Extensibility

### Registering a Custom Shell

Subclass `ShellComplete`, implement `get_completion_args()` and `format_completion()`, then register with `add_completion_class()`:

```python
from click.shell_completion import ShellComplete, add_completion_class

@add_completion_class
class MyShellComplete(ShellComplete):
    name = "myshell"
    source_template = "..."

    def get_completion_args(self):
        ...

    def format_completion(self, item):
        ...
```

The class becomes available under the name `myshell` for completion instructions (`myshell_source`, `myshell_complete`).

### Custom Parameter Completion

Pass a `shell_complete` callback to a parameter (see [command_model_and_definition](command_model_and_definition.md)). The callback receives `(ctx, param, incomplete)` and may return either `CompletionItem` objects or plain strings (which are automatically wrapped).

---

## Utility: `split_arg_string`

`split_arg_string()` splits an argument string like `shlex.split()` but tolerates incomplete input — a missing closing quote or trailing escape does not raise. This is essential because completion frequently operates on partially-typed input.

```python
split_arg_string("example 'my file")   # ["example", "my file"]
split_arg_string("example my\\")        # ["example", "my"]
```

> **Note:** As of version 8.2, this function moved from `parser` to `shell_completion`.

---

## Dependencies

```mermaid
graph TD
    SC["shell_completion.py"]
    CORE["core.py<br/>Command, Group, Context,<br/>Parameter, Argument, Option,<br/>ParameterSource"]
    TYPES["types.py<br/>ParamType, Choice, Path, File"]
    UTILS["utils.py<br/>echo"]

    SC -->|imports| CORE
    SC -->|uses via Parameter| TYPES
    SC -->|imports| UTILS
    CORE -->|delegates to| SC
```

| Dependency | Usage |
|------------|-------|
| [`core.py`](command_model_and_definition.md) | `Command`, `Group`, `Context`, `Parameter`, `Argument`, `Option`, `ParameterSource` for context resolution and completion targets. |
| [`types.py`](argument_parsing_and_type_system.md) | `ParamType.shell_complete()` implementations provide value completions. |
| [`utils.py`](platform_and_io_foundation.md) | `echo()` for emitting source scripts and completion output. |

---

## Related Documentation

- [command_model_and_definition](command_model_and_definition.md) — `Command`, `Group`, `Parameter`, and their `shell_complete()` methods.
- [argument_parsing_and_type_system](argument_parsing_and_type_system.md) — `ParamType`, `Choice`, `Path`, `File` and their completion behavior.
- [user_interface_and_presentation](user_interface_and_presentation.md) — Parent module grouping formatting, terminal UI, and shell completion.
- [platform_and_io_foundation](platform_and_io_foundation.md) — `echo()` and other I/O utilities.
- [testing](testing.md) — `CliRunner` for testing completion behavior.
