# Exceptions Module

## Introduction

The `exceptions` module (`src/click/exceptions.py`) defines the exception hierarchy that Click uses to signal, format, and present errors to users. It provides a structured set of exception classes that:

- Distinguish between **user-facing errors** (which Click formats and displays) and **internal control-flow signals** (which Click catches to alter execution flow).
- Carry **contextual information** (the offending parameter, option, or command context) so that error messages can be rendered consistently and helpfully.
- Map errors to **exit codes** so that standalone CLI applications terminate with meaningful status codes.

This module is a foundational dependency for nearly every other part of Click. The [command model and definition](command_model_and_definition.md) module raises these exceptions during parsing and invocation, the [argument parsing and type system](argument_parsing_and_type_system.md) module raises them during type conversion and validation, and the [testing](testing.md) module relies on them to assert error behavior.

---

## Exception Hierarchy

The module defines two distinct families of exceptions: a **user-facing hierarchy** rooted at `ClickException`, and **internal control-flow signals** rooted at `RuntimeError`.

```mermaid
classDiagram
    class Exception
    class RuntimeError
    class ClickException {
        +int exit_code = 1
        +str message
        +bool|None show_color
        +format_message() str
        +show(file) None
    }
    class UsageError {
        +int exit_code = 2
        +Context ctx
        +Command cmd
        +show(file) None
    }
    class BadParameter {
        +Parameter param
        +str param_hint
        +format_message() str
    }
    class MissingParameter {
        +str param_type
        +format_message() str
    }
    class NoSuchOption {
        +str option_name
        +Sequence possibilities
        +format_message() str
    }
    class BadOptionUsage {
        +str option_name
    }
    class BadArgumentUsage
    class NoArgsIsHelpError {
        +Context ctx
        +show(file) None
    }
    class FileError {
        +str ui_filename
        +str filename
        +format_message() str
    }
    class Abort
    class Exit {
        +int exit_code
    }

    Exception <|-- ClickException
    ClickException <|-- UsageError
    ClickException <|-- FileError
    UsageError <|-- BadParameter
    UsageError <|-- NoSuchOption
    UsageError <|-- BadOptionUsage
    UsageError <|-- BadArgumentUsage
    UsageError <|-- NoArgsIsHelpError
    BadParameter <|-- MissingParameter
    RuntimeError <|-- Abort
    RuntimeError <|-- Exit
```

### Two Families of Exceptions

| Family | Base Class | Purpose | Handled By |
|--------|-----------|---------|------------|
| **User-facing** | `ClickException` | Represent errors that should be shown to the user with a formatted message and an exit code. | `Command.main` catches these, calls `.show()`, and exits with `.exit_code`. |
| **Control-flow** | `RuntimeError` (`Abort`, `Exit`) | Signal Click to abort or exit without being treated as an error message. | `Command.main` catches these to terminate the process cleanly. |

---

## Core Components

### `ClickException`

The root of the user-facing exception hierarchy. Any exception Click should handle and display to the user derives from this class.

- **`exit_code`** (class attribute, default `1`): The status code the process should exit with.
- **`message`**: The raw error message.
- **`show_color`**: The color setting is resolved and cached at construction time via `resolve_color_default()` (from the [platform and I/O foundation](platform_and_io_foundation.md) module). This is necessary because the [context](command_model_and_definition.md) may be gone by the time the message is printed.
- **`format_message()`**: Returns the message to display. Subclasses override this to add context (e.g., parameter hints).
- **`show(file)`**: Writes `Error: {message}` to the given file (defaulting to stderr via `get_text_stderr()`), using `echo()` for color-aware output.

### `UsageError`

Signals that the user invoked the command incorrectly. This is the most commonly raised user-facing error and the base class for most specific usage errors.

- **`exit_code = 2`** (distinct from the generic `ClickException` code of `1`).
- **`ctx`**: The context that caused the error. Click fills this in automatically in many situations.
- **`cmd`**: The command derived from `ctx.command`.
- **`show()`**: Overridden to print the command's **usage line** and a **help hint** (e.g., `Try 'prog --help' for help.`) before the error message. The hint is only shown if the command actually has a help option.

### `BadParameter`

Formats a standardized error message for a bad parameter value. It is typically raised from a parameter callback or a `ParamType` conversion, and Click attaches the offending parameter automatically.

- **`param`**: The parameter object that caused the error.
- **`param_hint`**: An alternative string (or list of strings) used to identify the parameter when no `param` object is available. Lists are joined with ` / ` and each item is quoted via `_join_param_hints()`.
- **`format_message()`**: Produces `Invalid value for {param_hint}: {message}`, or `Invalid value: {message}` when no hint is available. The hint is obtained from `param.get_error_hint(ctx)`.

### `MissingParameter`

A specialization of `BadParameter` raised when a required option or argument is not provided.

- **`param_type`**: A string indicating the kind of parameter (`'parameter'`, `'option'`, or `'argument'`). Defaults to inheriting from `param.param_type_name`.
- **`format_message()`**: Builds a message such as `Missing option '--foo'.` It also appends any extra message from `param.type.get_missing_message(param)`.
- **`__str__()`**: Returns a simplified `Missing parameter: {name}` when no message was supplied.

### `NoSuchOption`

Raised when Click encounters an option that does not exist.

- **`option_name`**: The unrecognized option.
- **`possibilities`**: An optional sequence of candidate option names.
- **`format_message()`**: When possibilities are provided, appends a suggestion using `ngettext` — either `Did you mean {possibility}?` (single candidate) or `(Possible options: {possibilities})` (multiple candidates).

### `BadOptionUsage`

Raised when an option is supplied but used incorrectly (e.g., the wrong number of arguments). Carries the `option_name`.

### `BadArgumentUsage`

Raised when an argument is supplied but used incorrectly (e.g., the wrong number of values). Adds no extra state beyond `UsageError`.

### `NoArgsIsHelpError`

A specialized `UsageError` raised when a command is invoked with no arguments and `no_args_is_help` is enabled. Its message is the command's full help text.

- **`show()`**: Overridden to print the help text directly to stderr (rather than the standard `Error:` prefix), using the context's color setting.

### `FileError`

Raised when a file cannot be opened.

- **`filename`**: The original filename.
- **`ui_filename`**: A display-safe version produced by `format_filename()` (from the [platform and I/O foundation](platform_and_io_foundation.md) module), which replaces invalid bytes/surrogates with the replacement character.
- **`format_message()`**: Produces `Could not open file {filename!r}: {message}`.

### `Abort`

An internal signalling exception (subclass of `RuntimeError`) that tells Click to abort. It carries no message; `Command.main` catches it and prints `Aborted!` before exiting with code `1`.

### `Exit`

An internal signalling exception (subclass of `RuntimeError`) indicating the application should exit with a given status code.

- **`exit_code`**: The status code (default `0`).
- Uses `__slots__` for a lightweight footprint.

---

## Error Handling Flow

The following diagram shows how exceptions propagate from parsing/invocation through `Command.main`, which is the central handler for all exceptions in this module.

```mermaid
flowchart TD
    A[Command.main] --> B[make_context / parse_args]
    B --> C{Error during parsing?}
    C -->|No args + no_args_is_help| D[NoArgsIsHelpError]
    C -->|Unknown option| E[NoSuchOption]
    C -->|Bad option usage| F[BadOptionUsage]
    C -->|Bad argument usage| G[BadArgumentUsage]
    C -->|Bad/missing value| H[BadParameter / MissingParameter]
    C -->|No error| I[invoke callback]
    I --> J{Error during invocation?}
    J -->|ctx.fail| K[UsageError]
    J -->|ctx.abort| L[Abort]
    J -->|ctx.exit| M[Exit]
    J -->|File open failure| N[FileError]
    J -->|No error| O[ctx.exit 0]

    D --> P{standalone_mode?}
    E --> P
    F --> P
    G --> P
    H --> P
    K --> P
    N --> P
    P -->|ClickException| Q[e.show then sys.exit e.exit_code]
    P -->|not standalone| R[re-raise to caller]

    L --> S[echo 'Aborted!' then sys.exit 1]
    M --> T[sys.exit e.exit_code]
```

### Key Handling Rules in `Command.main`

1. **`ClickException`** (and subclasses): If `standalone_mode` is enabled, Click calls `e.show()` and exits with `e.exit_code`. Otherwise the exception is re-raised to the caller.
2. **`Abort`**: If `standalone_mode` is enabled, Click prints `Aborted!` to stderr and exits with code `1`. Otherwise it is re-raised.
3. **`Exit`**: If `standalone_mode` is enabled, Click exits with `e.exit_code`. Otherwise the exit code is returned to the caller.
4. **`EOFError` / `KeyboardInterrupt`**: Converted into an `Abort`.

---

## Component Interaction

The exceptions module depends on several other modules to format and display errors. The diagram below shows these dependencies.

```mermaid
flowchart LR
    subgraph exceptions[exceptions.py]
        CE[ClickException]
        UE[UsageError]
        BP[BadParameter]
        MP[MissingParameter]
        NSO[NoSuchOption]
        FE[FileError]
        AB[Abort]
        EX[Exit]
    end

    subgraph globals[globals.py]
        RCD[resolve_color_default]
    end
    subgraph utils[utils.py]
        ECHO[echo]
        FF[format_filename]
    end
    subgraph compat[_compat.py]
        GTS[get_text_stderr]
    end
    subgraph core[core.py]
        CTX[Context]
        CMD[Command]
        PARAM[Parameter]
    end

    CE --> RCD
    CE --> ECHO
    CE --> GTS
    UE --> CTX
    UE --> CMD
    BP --> PARAM
    MP --> PARAM
    FE --> FF
```

### Dependency Summary

| Dependency | Used By | Purpose |
|-----------|---------|---------|
| `resolve_color_default` ([globals](command_model_and_definition.md)) | `ClickException.__init__` | Cache the color setting before the context is torn down. |
| `echo` ([utils](platform_and_io_foundation.md)) | `ClickException.show`, `UsageError.show`, `NoArgsIsHelpError.show` | Color-aware, cross-platform output. |
| `get_text_stderr` ([_compat](platform_and_io_foundation.md)) | `ClickException.show`, `UsageError.show` | Obtain a correctly-encoded stderr stream. |
| `format_filename` ([utils](platform_and_io_foundation.md)) | `FileError.__init__` | Produce a display-safe filename. |
| `Context` / `Command` ([core](command_model_and_definition.md)) | `UsageError`, `NoArgsIsHelpError` | Access usage text, help text, and color settings. |
| `Parameter` ([core](command_model_and_definition.md)) | `BadParameter`, `MissingParameter` | Obtain error hints and missing-value messages. |

---

## Where Exceptions Are Raised

The exceptions in this module are raised throughout Click. The table below maps each exception to its primary raise sites.

| Exception | Raised In | Trigger |
|-----------|-----------|---------|
| `UsageError` | `Context.fail` ([core](command_model_and_definition.md)) | Explicit `ctx.fail(message)` calls. |
| `BadParameter` | `Parameter.type_cast_value` ([core](command_model_and_definition.md)), `ParamType` conversions ([types](argument_parsing_and_type_system.md)) | Value fails type conversion or validation. |
| `MissingParameter` | `Parameter.process_value` ([core](command_model_and_definition.md)) | A required parameter has no value. |
| `NoSuchOption` | Parser ([parser](argument_parsing_and_type_system.md)) | An unknown option is encountered. |
| `BadOptionUsage` | Parser / option handling ([parser](argument_parsing_and_type_system.md)) | An option is used incorrectly. |
| `BadArgumentUsage` | Parser / argument handling ([parser](argument_parsing_and_type_system.md)) | An argument is used incorrectly. |
| `NoArgsIsHelpError` | `Command.parse_args` ([core](command_model_and_definition.md)) | No args given and `no_args_is_help` is set. |
| `FileError` | File type handling ([types](argument_parsing_and_type_system.md)) | A file cannot be opened. |
| `Abort` | `Context.abort` ([core](command_model_and_definition.md)) | Explicit `ctx.abort()` or `EOFError`/`KeyboardInterrupt`. |
| `Exit` | `Context.exit` ([core](command_model_and_definition.md)) | Explicit `ctx.exit(code)`. |

---

## Message Formatting Pipeline

The following sequence diagram illustrates how a `BadParameter` error is formatted and displayed, showing the interaction between the exception, the parameter, and the output utilities.

```mermaid
sequenceDiagram
    participant P as Parameter
    participant BP as BadParameter
    participant Ctx as Context
    participant U as utils.echo
    participant S as stderr

    P->>BP: raise BadParameter(msg, ctx, param)
    Note over BP: __init__ caches show_color<br/>via resolve_color_default()
    BP->>Ctx: get_usage()
    Ctx-->>BP: usage string
    BP->>P: get_error_hint(ctx)
    P-->>BP: "'--foo'"
    BP->>BP: format_message()
    Note over BP: "Invalid value for '--foo': msg"
    BP->>U: echo(usage + hint + error, color)
    U->>S: write formatted output
```

---

## Design Notes

- **Color caching**: Because the `Context` is destroyed before `show()` is called in `Command.main`, `ClickException.__init__` resolves and stores the color setting immediately. This avoids losing color information during teardown.
- **Exit code separation**: `ClickException` uses exit code `1`, while `UsageError` (and its subclasses) use `2`. This mirrors common Unix conventions where usage errors are distinct from general failures.
- **`param_hint` flexibility**: `BadParameter` and `MissingParameter` accept either a `param` object or a raw `param_hint` string/list, allowing custom validation code to raise errors without a parameter object.
- **`__slots__` on `Exit`**: `Exit` uses `__slots__` to keep the control-flow exception lightweight, since it may be raised frequently.
- **Internal vs. user-facing**: `Abort` and `Exit` deliberately derive from `RuntimeError` rather than `ClickException` so that they are never formatted as error messages — they are pure control-flow signals.

---

## Related Modules

- [Command Model and Definition](command_model_and_definition.md) — `Context`, `Command`, and `Parameter`, which raise and handle these exceptions.
- [Argument Parsing and Type System](argument_parsing_and_type_system.md) — The parser and `ParamType` classes that raise `BadParameter`, `NoSuchOption`, and related errors.
- [Platform and I/O Foundation](platform_and_io_foundation.md) — `echo`, `format_filename`, and `get_text_stderr`, used for output.
- [Testing](testing.md) — `CliRunner` and `Result`, which capture and assert on exception output.
