# Parser Module

## Introduction

The `parser` module (`src/click/parser.py`) is Click's low-level command-line tokenizer and argument dispatcher. It is responsible for taking a raw list of command-line tokens (e.g. `["--verbose", "-n", "3", "input.txt"]`) and turning them into a structured result: a mapping of parameter names to raw values, a list of leftover positional arguments, and an ordered list of the parameters that were encountered.

The module is intentionally **minimal**. It does *not* perform type conversion, default resolution, prompting, environment-variable lookup, or help formatting. Those responsibilities live at a higher level in the [command model and definition](command_model_and_definition.md) module (specifically in `Parameter`, `Option`, and `Argument`). The parser only knows how to recognize option prefixes, split short-option clusters, consume the correct number of values for each option/argument, and report usage errors.

> **Deprecation note:** As of Click 8.2, the public-facing names in this module (`OptionParser`, `Argument`, `Option`, `split_opt`, `normalize_opt`, `ParsingState`) are deprecated and will be removed in Click 9.0. The old parser remains available via the standard library `optparse`. The internal underscore-prefixed classes documented here are the ones actually used by Click's core.

The module began as a trimmed-down copy of the standard library's `optparse` module. It is kept separate from `optparse` because of differences in error-message generation between Python 2.x and 3.x, and because `optparse` uses `gettext` in ways that could cause issues for Click.

---

## Architecture Overview

The parser module is composed of four cooperating classes plus a set of module-level helper functions. The classes form a small pipeline: the `_OptionParser` orchestrates parsing, delegating token recognition to `_Option`/`_Argument` descriptors and accumulating results in a `_ParsingState`.

```mermaid
graph TD
    subgraph "parser.py"
        OP["_OptionParser<br/>(orchestrator)"]
        OPT["_Option<br/>(option descriptor)"]
        ARG["_Argument<br/>(argument descriptor)"]
        PS["_ParsingState<br/>(accumulator)"]
        HELP["_unpack_args / _split_opt / _normalize_opt<br/>(helpers)"]
    end

    subgraph "core.py (higher level)"
        CORE_OPT["Option"]
        CORE_ARG["Argument"]
        CTX["Context"]
    end

    subgraph "exceptions.py"
        NSO["NoSuchOption"]
        BOU["BadOptionUsage"]
        BAU["BadArgumentUsage"]
        UE["UsageError"]
    end

    CORE_OPT -->|"add_to_parser()"| OP
    CORE_ARG -->|"add_to_parser()"| OP
    CTX -->|"configures"| OP

    OP -->|"creates & drives"| PS
    OP -->|"holds"| OPT
    OP -->|"holds"| ARG
    OP -->|"uses"| HELP

    OPT -->|"process()"| PS
    ARG -->|"process()"| PS

    OP -->|"raises"| NSO
    OP -->|"raises"| BOU
    ARG -->|"raises"| BAU
    NSO --> UE
    BOU --> UE
    BAU --> UE
```

### Component Responsibilities

| Component | Role |
|-----------|------|
| `_OptionParser` | The orchestrator. Registers options/arguments, walks the token list, and produces the final `(opts, args, order)` tuple. |
| `_Option` | Describes a single option: its short/long forms, prefixes, action, and `nargs`. Knows how to write its parsed value into the state. |
| `_Argument` | Describes a single positional argument: its destination name and `nargs`. Knows how to write its parsed value into the state. |
| `_ParsingState` | A mutable accumulator holding parsed option values, leftover positional args, remaining tokens, and the encounter order. |
| Helper functions | `_unpack_args`, `_split_opt`, `_normalize_opt` provide token-splitting and argument-distribution utilities. |

---

## Component Details

### `_OptionParser`

The central class. It is modelled after `optparse`'s parser but with a vastly simplified API. It should generally not be used directly — the high-level Click classes (`Option`, `Argument`, `Command`) wrap it.

**Key configuration attributes:**

- `ctx` — the optional [`Context`](command_model_and_definition.md) this parser belongs to. May be `None` for advanced use cases.
- `allow_interspersed_args` — when `False`, parsing stops at the first non-option token. Click uses this to implement nested subcommands safely.
- `ignore_unknown_options` — when `True`, unknown options are shifted into the leftover args instead of raising an error. Useful for forwarding arguments to external programs.
- `_short_opt` / `_long_opt` — dictionaries mapping option strings to their `_Option` descriptors.
- `_opt_prefixes` — the set of valid option prefixes (defaults to `{"-", "--"}`).
- `_args` — the ordered list of registered `_Argument` descriptors.

**Public methods:**

- `add_option(obj, opts, dest, action, nargs, const)` — registers an option. The `obj` is the originating `Option` instance, used to identify the option in the returned order list.
- `add_argument(obj, dest, nargs)` — registers a positional argument.
- `parse_args(args)` — the main entry point. Returns `(values, args, order)`.

### `_Option`

Represents a single option declaration. During construction it splits each declaration into a prefix and value using `_split_opt`, classifying single-character forms as short options and everything else as long options. It records all valid prefixes.

**Actions** (mirroring `optparse`):

| Action | Behavior |
|--------|----------|
| `store` | Store the value under `dest`. |
| `store_const` | Store the fixed `const` value. |
| `append` | Append the value to a list under `dest`. |
| `append_const` | Append the fixed `const` value to a list. |
| `count` | Increment an integer counter under `dest`. |

The `takes_value` property returns `True` for `store` and `append` actions. The `process(value, state)` method writes the result into the `_ParsingState` and appends the originating object to `state.order`.

### `_Argument`

Represents a positional argument. It is much simpler than `_Option` — it has only a `dest` and `nargs`. Its `process` method handles the special case of `nargs > 1` (detecting "holes" — `None` placeholders — and raising `BadArgumentUsage` when only some values are present) and the `nargs == -1` case where an empty tuple is replaced with `None` so an environment variable may be consulted.

### `_ParsingState`

A plain data holder created fresh for each `parse_args` call:

- `opts` — `dict[str, Any]` of parsed option/argument values keyed by destination name.
- `largs` — leftover positional arguments collected so far.
- `rargs` — the remaining tokens still to be processed.
- `order` — the ordered list of `Parameter` objects as they appeared on the command line.

---

## Parsing Flow

The `parse_args` method drives the entire process. It creates a `_ParsingState`, then runs two phases: option processing followed by argument processing. If a `UsageError` is raised and the context is in *resilient parsing* mode (used for shell completion), the error is swallowed.

```mermaid
flowchart TD
    A["parse_args(args)"] --> B["Create _ParsingState(args)"]
    B --> C["_process_args_for_options(state)"]
    C --> D{"Token == '--'?"}
    D -->|Yes| E["Stop option processing"]
    D -->|No| F{"Token starts with<br/>a known prefix?"}
    F -->|Yes| G["_process_opts(token, state)"]
    F -->|No| H{"allow_interspersed_args?"}
    H -->|Yes| I["Append to state.largs"]
    H -->|No| J["Push back & stop"]
    G --> C
    I --> C
    E --> K["_process_args_for_args(state)"]
    J --> K
    K --> L["_unpack_args(largs + rargs, nargs_specs)"]
    L --> M["arg.process() for each _Argument"]
    M --> N["Return (opts, largs, order)"]
    N --> O{"UsageError raised?"}
    O -->|"resilient_parsing"| P["Swallow error"]
    O -->|No| Q["Re-raise"]
```

### Option Matching

When a token is identified as an option, `_process_opts` first attempts a **long-option match**. If the token contains `=`, the portion after `=` is treated as an explicit value. If long matching fails with `NoSuchOption`, the parser falls back to **short-option matching** — unless the token uses a two-character prefix (e.g. `--foo`), in which case the error is re-raised (or the token is ignored if `ignore_unknown_options` is set).

```mermaid
flowchart TD
    A["_process_opts(arg, state)"] --> B{"'=' in arg?"}
    B -->|Yes| C["Split into long_opt + explicit_value"]
    B -->|No| D["long_opt = arg"]
    C --> E["_match_long_opt()"]
    D --> E
    E --> F{"Option found?"}
    F -->|Yes| G["Consume value via _get_value_from_state()"]
    F -->|No| H{"Two-char prefix?"}
    H -->|No| I["_match_short_opt()"]
    H -->|Yes| J{"ignore_unknown_options?"}
    J -->|Yes| K["Append to state.largs"]
    J -->|No| L["Raise NoSuchOption"]
    G --> M["option.process(value, state)"]
    I --> M
```

### Short-Option Clustering

`_match_short_opt` iterates over each character in a clustered token (e.g. `-abc`). For each character it looks up the corresponding short option. If an option takes a value, any remaining characters in the cluster are pushed back onto `rargs` as the value. Unknown characters are either collected (when `ignore_unknown_options` is set) and recombined into a leftover arg, or raise `NoSuchOption`.

### Value Consumption and the Flag Sentinel

`_get_value_from_state` is responsible for pulling the correct number of values from `rargs`. It handles three cases:

1. **Not enough remaining tokens** — if the option allows omitting its value (`_flag_needs_value`), the sentinel `_flag_needs_value` is returned; otherwise `BadOptionUsage` is raised.
2. **`nargs == 1`** — the next token is consumed, *unless* it looks like the start of another option and the option allows omitting its value, in which case the sentinel is returned.
3. **`nargs > 1`** — a tuple of the next `nargs` tokens is consumed.

The module-level sentinel `_flag_needs_value` is a unique object used to distinguish "the option was given as a flag without a value" from "the option was not given at all" (`None`). This sentinel is later interpreted by `Option.consume_value` in the [command model](command_model_and_definition.md) module, which may trigger a prompt or fall back to the option's `flag_value`.

---

## Helper Functions

### `_unpack_args(args, nargs_spec)`

Distributes a flat sequence of tokens across a sequence of `nargs` specifications. It returns a tuple of unpacked values plus the remaining arguments. A `nargs` of `-1` acts as a wildcard that consumes all remaining tokens (only one such wildcard is permitted). Missing items are filled with `None`. This is what allows Click to support variadic positional arguments.

### `_split_opt(opt)`

Splits an option string into its `(prefix, value)` pair. For example, `--foo` → `("--", "foo")`, `-f` → `("-", "f")`, and `-foo` → `("-", "foo")`.

### `_normalize_opt(opt, ctx)`

Applies the context's `token_normalize_func` (if any) to the value portion of an option, enabling features such as case-insensitive option matching. Returns the option unchanged when no context or normalization function is present.

---

## Integration with the Command Model

The parser is deliberately decoupled from Click's higher-level abstractions. The bridge is the `add_to_parser` method implemented by `Option` and `Argument` in the [command model and definition](command_model_and_definition.md) module.

```mermaid
sequenceDiagram
    participant Cmd as Command
    participant Opt as Option / Argument
    participant Parser as _OptionParser
    participant State as _ParsingState

    Cmd->>Parser: __init__(ctx)
    loop for each parameter
        Cmd->>Opt: add_to_parser(parser, ctx)
        Opt->>Parser: add_option(...) / add_argument(...)
    end
    Cmd->>Parser: parse_args(args)
    Parser->>State: create state
    Parser->>Parser: _process_args_for_options()
    Parser->>Parser: _process_args_for_args()
    Parser-->>Cmd: (opts, args, order)
    Cmd->>Opt: consume_value(ctx, opts)
    Note over Opt: type casting, defaults,<br/>envvars, prompting
```

Key points of the contract:

- **`Option.add_to_parser`** translates the option's `multiple`, `count`, and `is_flag` settings into the appropriate parser *action* (`append`, `count`, `store`, `store_const`, `append_const`). Boolean flags with secondary options register two parser options (one for `True`, one for `False`).
- **`Argument.add_to_parser`** simply registers the argument with its `nargs`.
- The parser returns **raw, unconverted values**. Type conversion, default resolution, environment-variable lookup, and prompting all happen later in `Parameter.consume_value` / `Parameter.process_value`.

---

## Error Handling

The parser raises subclasses of `UsageError` (defined in the [exceptions](exceptions.md) module) to signal malformed command lines:

| Exception | Raised when |
|-----------|-------------|
| `NoSuchOption` | An unknown option is encountered (includes "did you mean" suggestions via `difflib.get_close_matches`). |
| `BadOptionUsage` | An option is used incorrectly — e.g. a value is supplied to a flag, or an option is missing required arguments. |
| `BadArgumentUsage` | A positional argument receives the wrong number of values. |

When the associated `Context` has `resilient_parsing` enabled, `parse_args` catches `UsageError` and returns whatever partial state was accumulated. This is essential for shell completion, where the parser must not fail on incomplete input.

---

## Deprecation and Backward Compatibility

The module's `__getattr__` hook provides backward-compatible access to the old public names while emitting `DeprecationWarning`s:

- `OptionParser`, `Argument`, `Option`, `split_opt`, `normalize_opt`, `ParsingState` → mapped to their underscore-prefixed counterparts.
- `split_arg_string` → re-exported from the [shell completion](user_interface_and_presentation.md) module.

All of these will be removed in Click 9.0.

---

## Related Modules

- [command_model_and_definition.md](command_model_and_definition.md) — `Option`, `Argument`, `Parameter`, and `Context`, which drive the parser and consume its output.
- [argument_parsing_and_type_system.md](argument_parsing_and_type_system.md) — the type system that converts the parser's raw values.
- [exceptions.md](exceptions.md) — `UsageError` and its subclasses raised by the parser.
- [user_interface_and_presentation.md](user_interface_and_presentation.md) — shell completion, which relies on resilient parsing.
