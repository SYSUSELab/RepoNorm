# Windows Console (`_winconsole`)

## Introduction

The `_winconsole` module provides a low-level, Windows-specific implementation for
reading from and writing to the Windows console using the native Win32 console
APIs (`ReadConsoleW` / `WriteConsoleW`). It exists to work around the fact that
the standard Python I/O layer on Windows does not always handle Unicode text
correctly when interacting with the console — particularly for interactive
`echo` and `prompt` operations.

Rather than patching the entire interpreter (as the original upstream patches
did), this module operates within a small, self-contained "world" of Click's
echo and prompt functionality. It exposes a set of raw I/O base classes and a
`ConsoleStream` wrapper that transparently routes text writes to the console
while delegating binary writes to the underlying buffer.

> **Platform note:** This module is only importable on Windows. It begins with
> `assert sys.platform == "win32"` and imports `msvcrt` and `ctypes.windll`
> unconditionally. On non-Windows platforms it is never loaded.

This module is part of the broader
[platform and I/O foundation](platform_and_io_foundation.md) layer of Click.

---

## Architecture Overview

The module is built around a layered design that bridges Python's standard
`io` stack with the Win32 console API:

```mermaid
graph TD
    subgraph "Python io layer"
        TextIO["io.TextIOWrapper<br/>(_NonClosingTextIOWrapper)"]
        Buffered["io.BufferedReader /<br/>io.BufferedWriter"]
    end

    subgraph "_winconsole module"
        ConsoleStream["ConsoleStream<br/>(text + byte facade)"]
        Reader["_WindowsConsoleReader"]
        Writer["_WindowsConsoleWriter"]
        RawBase["_WindowsConsoleRawIOBase"]
        PyBuffer["Py_buffer / get_buffer"]
    end

    subgraph "Win32 API (ctypes)"
        ReadConsoleW["ReadConsoleW"]
        WriteConsoleW["WriteConsoleW"]
        GetConsoleMode["GetConsoleMode"]
        GetStdHandle["GetStdHandle"]
    end

    ConsoleStream --> TextIO
    ConsoleStream --> Buffered
    TextIO --> Buffered
    Buffered --> Reader
    Buffered --> Writer
    Reader --> RawBase
    Writer --> RawBase
    Reader --> PyBuffer
    Writer --> PyBuffer
    Reader --> ReadConsoleW
    Writer --> WriteConsoleW
    RawBase --> GetConsoleMode
    Reader --> GetStdHandle
    Writer --> GetStdHandle
```

### Component Responsibilities

| Component | Responsibility |
|-----------|----------------|
| `ConsoleStream` | A text/binary facade that presents a single stream object to Click, routing `str` writes to the text layer and `bytes` writes to the binary buffer. |
| `_WindowsConsoleRawIOBase` | Base class for raw console I/O objects; holds the Win32 `handle` and reports `isatty() == True`. |
| `_WindowsConsoleReader` | Implements `readinto()` using `ReadConsoleW`, decoding UTF-16-LE code units. |
| `_WindowsConsoleWriter` | Implements `write()` using `WriteConsoleW`, encoding UTF-16-LE code units. |
| `Py_buffer` / `get_buffer` | A `ctypes.Structure` mirroring CPython's `Py_buffer` and a helper that obtains a writable/readable buffer view of a Python object via `PyObject_GetBuffer`. |

---

## Component Details

### `ConsoleStream`

`ConsoleStream` is the primary public-facing object produced by this module. It
wraps two streams:

- `_text_stream` — a `_NonClosingTextIOWrapper` (from
  [`_compat`](platform_and_io_foundation.md)) that performs UTF-16-LE encoding
  and delegates to the raw console reader/writer.
- `buffer` — the original binary stream (e.g. `sys.stdout.buffer`).

Its `write()` method dispatches based on the argument type:

```mermaid
flowchart TD
    Start["ConsoleStream.write(x)"] --> IsStr{"isinstance(x, str)?"}
    IsStr -- Yes --> TextWrite["_text_stream.write(x)"]
    IsStr -- No --> Flush["flush() (errors suppressed)"]
    Flush --> BufWrite["buffer.write(x)"]
    TextWrite --> Done["return count"]
    BufWrite --> Done
```

Key behaviors:

- **`name`** — proxied from `self.buffer.name`.
- **`writelines()`** — iterates and calls `write()` for each line.
- **`__getattr__()`** — delegates any unknown attribute access to
  `_text_stream`, making `ConsoleStream` behave like a normal text stream
  (e.g. `.encoding`, `.fileno()`).
- **`isatty()`** — delegates to `self.buffer.isatty()`.
- **`__repr__()`** — includes the stream name and encoding.

### `_WindowsConsoleRawIOBase`

A minimal subclass of `io.RawIOBase` that stores the Win32 `handle` and
overrides `isatty()` to always return `True`. It serves as the common base for
the reader and writer.

### `_WindowsConsoleReader`

Implements `readinto(b)`:

1. Rejects zero-length reads (returns `0`).
2. Rejects odd byte counts, since the console is UTF-16-LE encoded (each code
   unit is 2 bytes).
3. Obtains a writable buffer view of `b` via `get_buffer(b, writable=True)`.
4. Calls `ReadConsoleW` with the number of code units to read.
5. If `GetLastError()` reports `ERROR_OPERATION_ABORTED`, sleeps briefly to
   allow a pending `KeyboardInterrupt` to be raised.
6. Raises `OSError` on failure.
7. Returns `0` if the first code unit is the EOF marker (`\x1a`), otherwise
   returns `2 * code_units_read`.

### `_WindowsConsoleWriter`

Implements `write(b)`:

1. Obtains a readable buffer view of `b` via `get_buffer(b)`.
2. Computes the number of code units to write, capped at
   `MAX_BYTES_WRITTEN` (32767) to avoid overflowing the Win32 API.
3. Calls `WriteConsoleW`.
4. Raises `OSError` with a human-readable message if nothing was written but
   input was non-empty.
5. Returns the number of bytes written (`2 * code_units_written`).

It also provides a static `_get_error_message(errno)` helper that maps known
Win32 error codes (`ERROR_SUCCESS`, `ERROR_NOT_ENOUGH_MEMORY`) to readable
strings.

### `Py_buffer` and `get_buffer`

`Py_buffer` is a `ctypes.Structure` that mirrors CPython's internal
`Py_buffer` layout. The `get_buffer()` helper uses `PyObject_GetBuffer` and
`PyBuffer_Release` from `ctypes.pythonapi` to obtain a raw memory view of a
Python object, returning a `c_char` array via `from_address`.

> **PyPy limitation:** On PyPy, `ctypes.pythonapi` is unavailable, so the
> import is wrapped in a `try/except ImportError` and `get_buffer` is set to
> `None`. When `get_buffer is None`, `_get_windows_console_stream()` refuses to
> activate the console stream (see below).

---

## Stream Construction and Activation

The module provides three factory functions that build the text streams for
stdin, stdout, and stderr:

```mermaid
graph LR
    subgraph "Factories"
        F0["_get_text_stdin"]
        F1["_get_text_stdout"]
        F2["_get_text_stderr"]
    end
    F0 --> R["_WindowsConsoleReader(STDIN_HANDLE)"]
    F1 --> W1["_WindowsConsoleWriter(STDOUT_HANDLE)"]
    F2 --> W2["_WindowsConsoleWriter(STDERR_HANDLE)"]
    R --> Wrap["_NonClosingTextIOWrapper<br/>utf-16-le, strict, line_buffering"]
    W1 --> Wrap
    W2 --> Wrap
    Wrap --> CS["ConsoleStream(text_stream, buffer_stream)"]
```

Each factory:

1. Wraps the appropriate raw reader/writer in an `io.BufferedReader` or
   `io.BufferedWriter`.
2. Wraps that in a `_NonClosingTextIOWrapper` configured with
   `encoding="utf-16-le"`, `errors="strict"`, and `line_buffering=True`.
3. Wraps the result in a `ConsoleStream` together with the original binary
   stream.

The `_stream_factories` mapping associates file descriptors `0`, `1`, and `2`
with these factories.

### Activation Flow

`_get_windows_console_stream(f, encoding, errors)` is the entry point used by
the rest of Click to decide whether to replace a standard stream with a console
stream:

```mermaid
flowchart TD
    Start["_get_windows_console_stream(f, encoding, errors)"] --> CheckBuf{"get_buffer is not None?"}
    CheckBuf -- No --> ReturnNone1["return None"]
    CheckBuf -- Yes --> CheckEnc{"encoding in {utf-16-le, None}?"}
    CheckEnc -- No --> ReturnNone2["return None"]
    CheckEnc -- Yes --> CheckErr{"errors in {strict, None}?"}
    CheckErr -- No --> ReturnNone3["return None"]
    CheckErr -- Yes --> CheckConsole{"_is_console(f)?"}
    CheckConsole -- No --> ReturnNone4["return None"]
    CheckConsole -- Yes --> GetFactory{"factory for f.fileno()?"}
    GetFactory -- No --> ReturnNone5["return None"]
    GetFactory -- Yes --> GetBuf{"f.buffer exists?"}
    GetBuf -- No --> ReturnNone6["return None"]
    GetBuf -- Yes --> Build["factory(f.buffer) -> ConsoleStream"]
```

The `_is_console(f)` helper determines whether a stream is attached to a real
console by:

1. Checking for a `fileno` attribute.
2. Calling `f.fileno()` (catching `OSError` / `io.UnsupportedOperation`).
3. Calling `msvcrt.get_osfhandle(fileno)` to get the OS handle.
4. Calling `GetConsoleMode(handle, ...)` — a non-zero result indicates a
   console.

---

## Constants and Win32 Bindings

The module binds a number of Win32 functions and constants at import time:

| Name | Purpose |
|------|---------|
| `STDIN_HANDLE`, `STDOUT_HANDLE`, `STDERR_HANDLE` | Standard handles obtained via `GetStdHandle(-10/-11/-12)`. |
| `PyBUF_SIMPLE`, `PyBUF_WRITABLE` | Buffer request flags for `PyObject_GetBuffer`. |
| `ERROR_SUCCESS`, `ERROR_NOT_ENOUGH_MEMORY`, `ERROR_OPERATION_ABORTED` | Win32 error codes used for diagnostics. |
| `STDIN_FILENO`, `STDOUT_FILENO`, `STDERR_FILENO` | File descriptor constants (`0`, `1`, `2`). |
| `EOF` | The console EOF marker (`b"\x1a"`). |
| `MAX_BYTES_WRITTEN` | Maximum bytes per `WriteConsoleW` call (`32767`). |
| `ReadConsoleW`, `WriteConsoleW`, `GetConsoleMode`, `GetLastError` | Bound kernel32 functions. |
| `GetCommandLineW`, `CommandLineToArgvW`, `LocalFree` | Bound functions for command-line parsing. |

---

## Dependencies

```mermaid
graph TD
    WinConsole["_winconsole"]
    Compat["_compat<br/>(_NonClosingTextIOWrapper, _FixupStream)"]
    Utils["utils<br/>(KeepOpenFile, LazyFile, PacifyFlushWrapper)"]
    StdLib["Standard library<br/>(io, ctypes, msvcrt, sys, time)"]

    WinConsole --> Compat
    WinConsole --> StdLib
    Compat --> Utils
```

- **`_compat._NonClosingTextIOWrapper`** — the text wrapper used to build the
  console text streams. It internally uses `_FixupStream` to normalize the
  binary stream's `readable`/`writable`/`seekable` behavior. See
  [platform and I/O foundation](platform_and_io_foundation.md).
- **`utils`** — provides related stream wrappers (`KeepOpenFile`, `LazyFile`,
  `PacifyFlushWrapper`) that complement the console stream handling. See
  [platform and I/O foundation](platform_and_io_foundation.md).
- **Standard library** — `io`, `ctypes` (including `ctypes.wintypes`),
  `msvcrt`, `sys`, and `time`.

---

## Interaction with the Wider System

The console stream produced here is consumed by Click's echo and prompt
machinery. When Click needs to write text to a terminal on Windows, it uses
these streams to ensure correct Unicode handling. The relationship to other
modules:

```mermaid
graph LR
    WinConsole["_winconsole"]
    Compat["_compat"]
    Utils["utils"]
    TermUI["_termui_impl<br/>(Editor, ProgressBar)"]
    Formatting["formatting<br/>(HelpFormatter)"]

    WinConsole --> Compat
    Compat --> Utils
    TermUI --> WinConsole
    Formatting --> WinConsole
```

- The [user interface and presentation](user_interface_and_presentation.md)
  layer (e.g. `ProgressBar`, `Editor`, `HelpFormatter`) ultimately writes to
  these console streams when running on Windows.
- The [platform and I/O foundation](platform_and_io_foundation.md) layer
  provides the compatibility wrappers this module depends on.

---

## Summary

The `_winconsole` module is a focused, Windows-only shim that enables correct
Unicode console I/O for Click's interactive features. Its design separates
concerns cleanly:

- **Raw I/O** (`_WindowsConsoleReader` / `_WindowsConsoleWriter`) talks directly
  to the Win32 console API.
- **Buffering** (`io.BufferedReader` / `io.BufferedWriter`) sits on top.
- **Text encoding** (`_NonClosingTextIOWrapper` with UTF-16-LE) handles the
  conversion.
- **Facade** (`ConsoleStream`) presents a unified text/binary interface to the
  rest of Click.

Activation is guarded by `_get_windows_console_stream()`, which only replaces a
stream when it is a genuine console, the encoding/error settings are
compatible, and buffer access is available (i.e. not on PyPy).
