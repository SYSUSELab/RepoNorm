# Text Wrapping Module (`click._textwrap`)

## Introduction

The `click._textwrap` module provides a specialized text-wrapping utility used
throughout Click to render help pages, usage strings, and other terminal output
in a consistent, readable manner. It is a thin but important extension of the
Python standard library's [`textwrap.TextWrapper`](https://docs.python.org/3/library/textwrap.html),
adding behavior that Click specifically needs: correct handling of long words
that exceed the available width, temporary indentation scopes, and a
"re-indent only" mode that preserves existing line breaks.

The module exposes a single public class, `TextWrapper`, which is consumed
primarily by the [user interface and presentation](user_interface_and_presentation.md)
layer (notably `HelpFormatter`) to produce wrapped help text.

---

## Purpose and Core Functionality

The standard library `TextWrapper` is designed for general-purpose text
wrapping, but Click's help rendering has a few requirements that the stock
implementation does not satisfy cleanly:

1. **Predictable long-word handling** — When a single word is longer than the
   available width, Click needs to break it at exactly the right point so that
   the remaining characters continue to flow correctly on subsequent lines.
2. **Scoped indentation** — Help sections are nested (sections, sub-sections,
   definition lists). Click needs to temporarily add an indent prefix and
   restore the previous state reliably, even if an exception occurs.
3. **Indent-only formatting** — Some text already contains meaningful line
   breaks (e.g. pre-formatted blocks) and should only be indented, not
   re-wrapped.

`TextWrapper` addresses all three by overriding `_handle_long_word` and adding
two helper methods: `extra_indent` and `indent_only`.

---

## Architecture

The module is intentionally small and self-contained. It depends only on the
Python standard library (`textwrap`, `contextlib`, `collections.abc`) and is
consumed by higher-level presentation code.

```mermaid
graph TD
    subgraph "click._textwrap"
        TW["TextWrapper<br/>(extends textwrap.TextWrapper)"]
    end

    subgraph "Python Standard Library"
        STW["textwrap.TextWrapper"]
        CTX["contextlib.contextmanager"]
        ABC["collections.abc.Iterator"]
    end

    subgraph "Click Presentation Layer"
        HF["HelpFormatter<br/>(click.formatting)"]
    end

    STW -->|inherits| TW
    CTX -->|decorates extra_indent| TW
    ABC -->|type hint| TW
    TW -->|used by| HF
```

### Component Relationships

| Component | Role | Depends On |
|-----------|------|------------|
| `TextWrapper` | Extended text wrapper with Click-specific behavior | `textwrap.TextWrapper`, `contextlib`, `collections.abc` |
| `HelpFormatter` | Renders help pages using wrapped text | `TextWrapper` (via `wrap_text`) |

---

## The `TextWrapper` Class

`TextWrapper` subclasses `textwrap.TextWrapper` and inherits all of its
configuration attributes (`width`, `initial_indent`, `subsequent_indent`,
`break_long_words`, `break_on_hyphens`, etc.). It overrides one method and adds
two new ones.

### Method Overview

```mermaid
classDiagram
    class TextWrapper {
        +_handle_long_word(reversed_chunks, cur_line, cur_len, width) None
        +extra_indent(indent) Iterator~None~
        +indent_only(text) str
    }
    class TextWrapper_stdlib["textwrap.TextWrapper"] {
        +width
        +initial_indent
        +subsequent_indent
        +break_long_words
        +wrap(text)
        +fill(text)
    }
    TextWrapper_stdlib <|-- TextWrapper
```

### `_handle_long_word(reversed_chunks, cur_line, cur_len, width)`

Overrides the standard library's internal hook that is called when the current
word does not fit on the current line.

**Behavior:**

- Computes `space_left = max(width - cur_len, 1)` — the number of characters
  that can still fit on the current line (always at least 1).
- If `break_long_words` is enabled, it splits the last chunk in
  `reversed_chunks` at `space_left`, appends the fitting portion to
  `cur_line`, and leaves the remainder in `reversed_chunks` for the next line.
- If `break_long_words` is disabled and the current line is empty, it moves the
  entire chunk onto the line (preventing an infinite loop / empty output).

This override ensures that long words are broken at the precise boundary so
that the leftover text flows naturally onto the following line.

### `extra_indent(indent)` — Context Manager

A `@contextmanager` that temporarily prepends `indent` to both
`initial_indent` and `subsequent_indent`.

```mermaid
sequenceDiagram
    participant Caller
    participant TW as TextWrapper
    Caller->>TW: with extra_indent("  "):
    TW->>TW: save old initial/subsequent indent
    TW->>TW: prepend indent to both
    Note over Caller,TW: wrapped text now uses extra indent
    Caller->>TW: (exit context)
    TW->>TW: restore old initial/subsequent indent
```

**Key properties:**

- Uses a `try/finally` block so the original indentation is **always restored**,
  even if an exception is raised inside the `with` block.
- Nestable — each invocation saves and restores its own state, so multiple
  nested `extra_indent` scopes compose correctly.

### `indent_only(text)`

Indents each line of `text` without re-wrapping it.

**Behavior:**

- Splits `text` into lines using `splitlines()`.
- The first line receives `initial_indent`; all subsequent lines receive
  `subsequent_indent`.
- Joins the result with `"\n"`.

This is useful for content whose line breaks are semantically meaningful and
must be preserved (for example, pre-formatted help blocks).

---

## Data Flow

The following diagram shows how text flows from a caller through `TextWrapper`
into rendered output, and how `TextWrapper` fits into the broader help-rendering
pipeline.

```mermaid
flowchart LR
    A["Raw help text"] --> B{"Formatting mode?"}
    B -->|"Re-wrap"| C["TextWrapper.wrap()<br/>(inherited)"]
    B -->|"Preserve line breaks"| D["TextWrapper.indent_only()"]
    C --> E["_handle_long_word()<br/>on overflow"]
    E --> C
    C --> F["Wrapped lines"]
    D --> F
    F --> G["HelpFormatter buffer"]
    G --> H["Terminal output"]
```

---

## Integration with the Presentation Layer

`TextWrapper` is not used directly by end users. Instead, it is wrapped by the
`wrap_text` helper and consumed by `HelpFormatter` in the
[user interface and presentation](user_interface_and_presentation.md) module.

`HelpFormatter` relies on wrapped text for:

- **Usage lines** (`write_usage`) — wrapping argument lists to fit the terminal.
- **Free text** (`write_text`) — re-wrapping and preserving paragraphs.
- **Definition lists** (`write_dl`) — wrapping option/command descriptions in
  the second column.

Because `HelpFormatter` computes widths dynamically from the terminal size, the
precise long-word handling provided by `TextWrapper._handle_long_word` is
essential for producing clean output at narrow widths.

```mermaid
graph TD
    HF["HelpFormatter"] -->|"write_usage / write_text / write_dl"| WT["wrap_text()"]
    WT -->|"instantiates & configures"| TW["TextWrapper"]
    TW -->|"wrap()"| OUT["Formatted string"]
    OUT --> HF
```

---

## Design Notes and Edge Cases

- **Minimum space of 1** — `space_left` is clamped to a minimum of `1` so that
  progress is always made, avoiding infinite loops when `width` is very small.
- **Empty-line guard** — When `break_long_words` is `False`, the override only
  moves a chunk onto the line if `cur_line` is empty, preventing the wrapper
  from stalling.
- **State restoration** — `extra_indent` guarantees restoration via `finally`,
  making it safe to use in exception-prone rendering code.
- **No external dependencies** — The module depends only on the standard
  library, keeping it lightweight and portable across platforms (including the
  Windows console handling described in
  [platform and IO foundation](platform_and_io_foundation.md)).

---

## Related Modules

- [User Interface and Presentation](user_interface_and_presentation.md) — the
  primary consumer of `TextWrapper` via `HelpFormatter`.
- [Platform and IO Foundation](platform_and_io_foundation.md) — sibling
  low-level utilities (`_compat`, `utils`, `_winconsole`) that support terminal
  output.
- [Command Model and Definition](command_model_and_definition.md) — defines the
  commands and parameters whose help text is rendered using this module.
