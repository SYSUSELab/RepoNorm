# Decorators Module

## Introduction

The `decorators` module (`src/click/decorators.py`) provides the high-level, declarative API that most Click applications use to build command-line interfaces. Instead of manually instantiating `Command`, `Group`, `Option`, and `Argument` objects and wiring them together, developers decorate plain Python functions with `@click.command()`, `@click.option()`, `@click.argument()`, and related decorators.

This module is the primary **user-facing entry point** of Click. It sits on top of the core object model (see [command_model_and_definition.md](command_model_and_definition.md)) and translates declarative decorators into concrete command/parameter instances. It also provides a family of "pass-through" decorators (`pass_context`, `pass_obj`, `make_pass_decorator`, `pass_meta_key`) that inject contextual state into callbacks.

### Responsibilities

- **Command creation**: `command()` and `group()` turn functions into `Command`/`Group` instances.
- **Parameter attachment**: `option()` and `argument()` attach `Option`/`Argument` instances to a command.
- **Pre-configured options**: `confirmation_option()`, `password_option()`, `version_option()`, and `help_option()` provide ready-made common options.
- **Context injection**: `pass_context()`, `pass_obj()`, `make_pass_decorator()`, and `pass_meta_key()` inject runtime state into callbacks.
- **Help option class**: `HelpOption` is a pre-configured `Option` subclass for `--help`.

---

## Architecture Overview

The decorators module is a thin, declarative layer that produces and configures objects from the core module. It depends on the core object model, the global context stack, and the output utility.

```mermaid
graph TD
    subgraph "decorators.py"
        CMD["command()"]
        GRP["group()"]
        OPT["option()"]
        ARG["argument()"]
        HELP["help_option() / HelpOption"]
        CONF["confirmation_option()"]
        PASS["password_option()"]
        VER["version_option()"]
        PC["pass_context()"]
        PO["pass_obj()"]
        MPD["make_pass_decorator()"]
        PMK["pass_meta_key()"]
        MEMO["_param_memo()"]
    end

    subgraph "core.py"
        Command
        Group
        Option
        Argument
        Parameter
        Context
    end

    subgraph "globals.py"
        GCC["get_current_context()"]
    end

    subgraph "utils.py"
        ECHO["echo()"]
    end

    CMD --> Command
    GRP --> Group
    GRP --> CMD
    OPT --> Option
    ARG --> Argument
    HELP --> OPT
    HELP --> HelpOption
    HelpOption --> Option
    CONF --> OPT
    PASS --> OPT
    VER --> OPT
    VER --> ECHO
    OPT --> MEMO
    ARG --> MEMO
    MEMO --> Command
    PC --> GCC
    PO --> GCC
    MPD --> GCC
    PMK --> GCC
    MPD --> Context
    PMK --> Context
```

---

## Component Relationships

The decorators fall into three functional groups. The diagram below shows how each group interacts with the core object model.

```mermaid
graph LR
    subgraph "Command Builders"
        command
        group
    end

    subgraph "Parameter Decorators"
        option
        argument
        _param_memo
    end

    subgraph "Context Injectors"
        pass_context
        pass_obj
        make_pass_decorator
        pass_meta_key
    end

    subgraph "Pre-configured Options"
        confirmation_option
        password_option
        version_option
        help_option
    end

    command -->|creates| Command
    group -->|creates| Group
    option -->|creates| Option
    argument -->|creates| Argument
    option --> _param_memo
    argument --> _param_memo
    _param_memo -->|appends to| Command
    confirmation_option --> option
    password_option --> option
    version_option --> option
    help_option --> option
    pass_context -->|reads| Context
    pass_obj -->|reads| Context
    make_pass_decorator -->|reads| Context
    pass_meta_key -->|reads| Context
```

---

## Command Builders

### `command()`

`command()` is the central decorator. It creates a `Command` instance whose callback is the decorated function and automatically attaches any parameters registered by `option()`/`argument()` decorators.

Key behaviors:

- **Name derivation**: If no name is given, the function name is lowercased, underscores are replaced with dashes, and the suffixes `_command`, `_cmd`, `_group`, and `_grp` are stripped (e.g. `init_data_command` → `init-data`).
- **Parameter collection**: Decorated parameters are stored on the function under `__click_params__` and are appended (in reverse order) to the command's `params` list. Any `params` passed explicitly are placed first.
- **Help fallback**: If no `help` attribute is provided, the function's docstring is used.
- **Flexible invocation**: Supports both `@command` (no parentheses) and `@command(...)` forms, and accepts a custom `cls` for subclassing.

```mermaid
flowchart TD
    A["@command decorator applied"] --> B{"callable(name)?"}
    B -->|yes| C["func = name; name = None"]
    B -->|no| D["func = None"]
    C --> E["decorator(f)"]
    D --> E
    E --> F{"f is already a Command?"}
    F -->|yes| G["raise TypeError"]
    F -->|no| H["collect __click_params__"]
    H --> I["set help from docstring if missing"]
    I --> J["derive name if not given"]
    J --> K["cls(name, callback=f, params=params, **attrs)"]
    K --> L["return Command instance"]
```

### `group()`

`group()` is a thin wrapper around `command()` that defaults `cls` to `Group`. It produces a `Group` (a command that nests subcommands). It supports the same no-parentheses and custom-class forms as `command()`.

> For details on how `Group` resolves and invokes subcommands, see [command_model_and_definition.md](command_model_and_definition.md).

---

## Parameter Decorators

### `option()` and `argument()`

Both decorators instantiate a parameter object and attach it to the target function or command via `_param_memo()`.

- `option(*param_decls, cls=Option, **attrs)` creates an `Option`.
- `argument(*param_decls, cls=Argument, **attrs)` creates an `Argument`.

All positional arguments become parameter declarations; all keyword arguments (except `cls`) are forwarded to the parameter constructor.

### `_param_memo()`

`_param_memo()` is the internal helper that records a parameter on its target:

- If the target is already a `Command` (e.g. decorators applied after `@command`), the parameter is appended directly to `Command.params`.
- Otherwise, the parameter is appended to a `__click_params__` list on the function, which `command()` later consumes.

```mermaid
flowchart LR
    subgraph "Decorator order (bottom-up)"
        F["def cli(...)"] --> A1["@argument('name')"]
        A1 --> O1["@option('--count')"]
        O1 --> C1["@command()"]
    end
    O1 -.->|"__click_params__"| F
    A1 -.->|"__click_params__"| F
    C1 -->|"reads __click_params__"| CMD["Command.params"]
```

> For the full parameter model (types, nargs, defaults, envvars, prompting), see [command_model_and_definition.md](command_model_and_definition.md) and [argument_parsing_and_type_system.md](argument_parsing_and_type_system.md).

---

## Pre-configured Options

These decorators wrap `option()` with sensible defaults for common CLI patterns.

| Decorator | Default flag | Purpose |
|-----------|--------------|---------|
| `confirmation_option()` | `--yes` | Prompts for confirmation; aborts if declined. |
| `password_option()` | `--password` | Prompts for a hidden password with confirmation. |
| `version_option()` | `--version` | Prints the version and exits; auto-detects version/package. |
| `help_option()` | `--help` | Prints the help page and exits (uses `HelpOption`). |

### `confirmation_option()`

Adds a `--yes` flag. When not passed, it prompts `"Do you want to continue?"`; if declined, `ctx.abort()` is called. It sets `is_flag=True`, `expose_value=False`, and a callback that aborts on a falsy value.

### `password_option()`

Adds a `--password` option with `prompt=True`, `confirmation_prompt=True`, and `hide_input=True`.

### `version_option()`

Adds a `--version` flag that prints the version and exits. It performs **automatic detection**:

- If `version` is not given, it uses `importlib.metadata.version(package_name)`.
- If `package_name` is not given, it inspects the caller's stack frame globals to infer the package name (handling `__main__` via `__package__`).
- The message template supports `%(prog)s`, `%(package)s`, and `%(version)s`.

The callback is eager (`is_eager=True`) and does not expose a value.

```mermaid
flowchart TD
    A["--version passed"] --> B{"resilient_parsing?"}
    B -->|yes| Z["return"]
    B -->|no| C{"prog_name set?"}
    C -->|no| D["prog_name = ctx.find_root().info_name"]
    C -->|yes| E
    D --> E{"version set?"}
    E -->|no| F["importlib.metadata.version(package_name)"]
    F -->|PackageNotFoundError| G["raise RuntimeError"]
    F -->|ok| H
    E -->|yes| H["echo(message % {...})"]
    H --> I["ctx.exit()"]
```

### `HelpOption` and `help_option()`

`HelpOption` is a pre-configured `Option` subclass that represents the `--help` flag. Its constructor sets `is_flag=True`, `expose_value=False`, `is_eager=True`, a default help string, and the `show_help` callback.

`show_help()` is a static callback that, when the flag is truthy and parsing is not resilient, prints `ctx.get_help()` via `echo()` and calls `ctx.exit()`.

`help_option()` is the decorator form; it simply sets `cls=HelpOption` and delegates to `option()`.

> Note: `Command` also registers a default help option internally via `Command.get_help_option()`. `HelpOption` provides an explicit, decorator-based alternative. See [command_model_and_definition.md](command_model_and_definition.md).

---

## Context Injection Decorators

These decorators wrap a callback so that runtime state is passed as the first argument. They all rely on `get_current_context()` from [globals.py](command_model_and_definition.md) to locate the active `Context`.

### `pass_context()`

Injects the current `Context` as the first argument.

### `pass_obj()`

Injects `Context.obj` (the user-defined object) as the first argument.

### `make_pass_decorator(object_type, ensure=False)`

A factory that produces a decorator injecting the **innermost** object of a given type found by walking the context chain:

- `ensure=False`: uses `ctx.find_object(object_type)`; raises `RuntimeError` if none exists.
- `ensure=True`: uses `ctx.ensure_object(object_type)`, creating and storing a new instance if needed.

The injected object is passed via `ctx.invoke(f, obj, ...)`.

### `pass_meta_key(key, *, doc_description=None)`

A factory that produces a decorator injecting `Context.meta[key]` as the first argument. The generated decorator's docstring is customized using `doc_description`.

```mermaid
sequenceDiagram
    participant User as CLI invocation
    participant Ctx as Context
    participant Wrapper as Decorated callback
    participant Fn as Original function

    User->>Ctx: push context (scope)
    User->>Wrapper: invoke callback
    Wrapper->>Ctx: get_current_context()
    Ctx-->>Wrapper: active Context
    Wrapper->>Ctx: find_object / ensure_object / meta[key]
    Ctx-->>Wrapper: injected object
    Wrapper->>Fn: f(obj, *args, **kwargs)
    Fn-->>Wrapper: return value
    Wrapper-->>User: return value
```

All four decorators use `functools.update_wrapper` to preserve the wrapped function's metadata.

---

## Data Flow: From Decorators to Execution

The following diagram traces how decorators contribute to a running command.

```mermaid
flowchart TD
    subgraph "Definition time"
        F["Plain function"] -->|"@option / @argument"| P["__click_params__ list"]
        P -->|"@command / @group"| CMD["Command / Group instance"]
        CMD -->|"params"| PARAMS["Command.params"]
    end

    subgraph "Invocation time"
        MAIN["Command.main()"] --> MK["make_context()"]
        MK --> PARSE["parse_args()"]
        PARSE --> PARAMS
        PARSE --> INV["invoke()"]
        INV -->|"pass_context / pass_obj / ..."| CB["callback with injected state"]
        CB -->|"echo()"| OUT["stdout / stderr"]
    end
```

---

## Dependencies

| Dependency | Source | Usage |
|------------|--------|-------|
| `Command`, `Group`, `Option`, `Argument`, `Parameter`, `Context` | [command_model_and_definition.md](command_model_and_definition.md) | Core objects created/configured by decorators. |
| `get_current_context()` | [command_model_and_definition.md](command_model_and_definition.md) (globals) | Locates the active context for injection decorators. |
| `echo()` | [platform_and_io_foundation.md](platform_and_io_foundation.md) | Output for `version_option` and `HelpOption.show_help`. |
| `importlib.metadata` | Python stdlib | Version detection in `version_option`. |
| `inspect` | Python stdlib | Stack-frame inspection for package detection. |
| `functools.update_wrapper` | Python stdlib | Preserves metadata on wrapper functions. |

---

## Summary

The `decorators` module is the declarative front-end of Click. It:

1. **Builds commands** (`command`, `group`) from plain functions.
2. **Attaches parameters** (`option`, `argument`, `_param_memo`) to those commands.
3. **Provides common options** (`confirmation_option`, `password_option`, `version_option`, `help_option`, `HelpOption`).
4. **Injects runtime state** (`pass_context`, `pass_obj`, `make_pass_decorator`, `pass_meta_key`).

It delegates all object construction and runtime behavior to the core module, keeping the decorator layer thin and focused on ergonomics. For the underlying object model, parsing, and type system, refer to [command_model_and_definition.md](command_model_and_definition.md) and [argument_parsing_and_type_system.md](argument_parsing_and_type_system.md).
