# Compiler Module

## Introduction

The **compiler module** (`src/jinja2/compiler.py`) is the heart of Jinja2's template
translation pipeline. It takes the abstract syntax tree (AST) produced by the
[parser](lexing_and_parsing.md) and converts it into executable Python source code. The
generated Python code, when executed, produces a *root render function* and a set of
*block functions* that together render the template.

The compiler is responsible for:

- **Code generation** — emitting Python source that mirrors the template's semantics.
- **Scope and identifier tracking** — deciding how names are resolved, aliased, or
  treated as undefined via the [idtracking](compilation_and_analysis.md) subsystem.
- **Constant folding / optimization** — delegating to the
  [optimizer](compilation_and_analysis.md) to simplify constant expressions.
- **Dependency collection** — discovering which filters and tests a template uses so
  they can be resolved at runtime.
- **Introspection support** — providing a subclass used by the
  [meta](compilation_and_analysis.md) module to find undeclared variables.

This module sits in the **compilation and analysis** group of the Jinja2 architecture,
consuming the output of the lexing/parsing stage and producing code that depends on the
[runtime support](runtime_support_and_foundation.md) module.

---

## Architecture Overview

The compiler is a tree-walking code generator. It subclasses `NodeVisitor` and emits
Python source into a text stream as it visits each AST node.

```mermaid
graph TD
    subgraph "Input"
        AST["AST (nodes.Template)"]
        ENV["Environment"]
    end

    subgraph "compiler.py"
        GEN["generate()"]
        CG["CodeGenerator"]
        FRAME["Frame"]
        SYM["Symbols (idtracking)"]
        OPT["Optimizer"]
        DFV["DependencyFinderVisitor"]
        UNV["UndeclaredNameVisitor"]
    end

    subgraph "Output"
        SRC["Python source code"]
        STREAM["TextIO stream"]
    end

    AST --> GEN
    ENV --> GEN
    GEN --> CG
    CG --> FRAME
    FRAME --> SYM
    CG --> OPT
    CG --> DFV
    CG --> UNV
    CG --> SRC
    CG --> STREAM
```

### Key Responsibilities by Component

| Component | Responsibility |
|-----------|----------------|
| `generate` | Entry point; instantiates a `CodeGenerator` and visits the root node. |
| `CodeGenerator` | The main visitor that emits Python source for every node type. |
| `Frame` | Holds compile-time scope information (symbols, buffers, block context). |
| `MacroRef` | Tracks whether a macro/call-block accesses `caller`, `kwargs`, `varargs`. |
| `DependencyFinderVisitor` | Collects filter and test names used in a template. |
| `UndeclaredNameVisitor` | Detects names accessed without being declared. |
| `CompilerExit` | Signals that a block should not be processed further. |
| `VisitorExit` | Signals the `UndeclaredNameVisitor` to stop early. |
| `CodeGenerator._FinalizeInfo` | Caches the finalize function used for output nodes. |

---

## Compilation Pipeline

The overall flow from a parsed template to executable Python is shown below.

```mermaid
flowchart TD
    A["nodes.Template"] --> B["generate()"]
    B --> C["CodeGenerator.__init__"]
    C --> D{"optimized?"}
    D -->|yes| E["Create Optimizer"]
    D -->|no| F["optimizer = None"]
    E --> G["visit(Template)"]
    F --> G
    G --> H["Emit imports & root function"]
    H --> I["Collect blocks"]
    I --> J["Emit block functions"]
    J --> K["Emit blocks dict & debug_info"]
    K --> L["Return source string / write to stream"]
```

### The `generate` Function

`generate()` is the public entry point. It validates that the node is a
`nodes.Template`, instantiates the environment's configured
`code_generator_class`, visits the node, and returns the generated source (or `None`
if a stream was provided).

```python
def generate(node, environment, name, filename, stream=None,
             defer_init=False, optimized=True):
    if not isinstance(node, nodes.Template):
        raise TypeError("Can't compile non template nodes")
    generator = environment.code_generator_class(
        environment, name, filename, stream, defer_init, optimized)
    generator.visit(node)
    if stream is None:
        return generator.stream.getvalue()
    return None
```

---

## The `CodeGenerator` Class

`CodeGenerator` extends `NodeVisitor` and is the workhorse of the module. It maintains
a large amount of state while walking the tree:

- **Output stream** (`self.stream`) — a `StringIO` by default.
- **Block registry** (`self.blocks`) — all `{% block %}` nodes, keyed by name.
- **Import aliases** (`self.import_aliases`) — maps imported names to generated aliases.
- **Filter/test registries** (`self.filters`, `self.tests`) — maps names to generated
  identifiers.
- **Debug info** (`self.debug_info`) — line-number mappings for tracebacks.
- **Indentation & newline tracking** — `_indentation`, `_new_lines`, `_last_line`.
- **Assignment tracking** (`self._assign_stack`) — tracks top-level assignments.
- **Parameter definition blocks** (`self._param_def_block`) — tracks macro parameters.
- **Context reference stack** (`self._context_reference_stack`) — tracks the active
  context object (e.g. `context` or a derived context).

### Code Emission Helpers

The generator uses a set of low-level helpers to manage formatting:

| Method | Purpose |
|--------|---------|
| `write(x)` | Write a raw string, handling pending newlines and indentation. |
| `writeline(x, node, extra)` | `newline()` followed by `write()`. |
| `newline(node, extra)` | Queue one or more newlines before the next write. |
| `indent()` / `outdent(step)` | Adjust the indentation level. |
| `start_write` / `end_write` | Begin/end a `yield` or buffer `.append(`. |
| `simple_write` | Shortcut combining `start_write` + `write` + `end_write`. |
| `blockvisit(nodes, frame)` | Visit a list of nodes, catching `CompilerExit`. |
| `temporary_identifier()` | Generate a unique identifier like `t_1`. |

### Buffering vs. Yielding

A crucial concept is whether a frame writes via `yield` (streaming) or into a buffer
list. Buffering is enabled by `buffer(frame)` and used by macros, filter blocks, and
assign blocks. `return_buffer_contents()` emits the code to return the joined buffer,
respecting autoescape and volatility.

```mermaid
flowchart LR
    A["start_write(frame)"] --> B{"frame.buffer?"}
    B -->|None| C["yield "]
    B -->|set| D["buffer.append("]
    C --> E["write(content)"]
    D --> E
    E --> F["end_write(frame)"]
    F --> G{"frame.buffer?"}
    G -->|set| H["write(')')"]
```

---

## Frame and Scope Management

The `Frame` class encapsulates compile-time scope information. Frames form a tree that
mirrors the nesting of template constructs.

```mermaid
graph TD
    ROOT["Root Frame (rootlevel=True)"]
    IF["Soft Frame (if/cond expr)"]
    LOOP["Loop Frame (loop_frame=True)"]
    BLOCK["Block Frame (block_frame=True)"]
    INNER["Inner Frame (macro/with/scope)"]

    ROOT --> IF
    ROOT --> LOOP
    ROOT --> BLOCK
    ROOT --> INNER
    IF --> INNER
    LOOP --> INNER
```

### Frame Types and Flags

| Flag | Meaning |
|------|---------|
| `toplevel` | Root frame plus soft frames (e.g. `if` conditions). |
| `rootlevel` | The outermost frame; used to optimize inheritance. |
| `loop_frame` | Inside a `for` loop; assignments don't leak outward. |
| `block_frame` | Inside a `{% block %}`; assignments tracked separately. |
| `soft_frame` | Inside an `if`/conditional expression; affects error timing. |
| `require_output_check` | Whether output must be guarded by `if parent_template is None`. |
| `buffer` | Name of the buffer list, or `None` for streaming. |
| `block` | Name of the enclosing block, or `None`. |

### Frame Creation Methods

- `Frame.inner(isolated=False)` — creates a child frame. If `isolated`, the child gets
  a fresh `Symbols` with no parent.
- `Frame.soft()` — creates a copy that is no longer `rootlevel` and is marked
  `soft_frame`.
- `Frame.copy()` — shallow copy with a copied `Symbols` instance.

### Symbol Tracking Integration

Each `Frame` owns a `Symbols` instance from the
[idtracking](compilation_and_analysis.md) module. `Symbols` records:

- `refs` — mapping of names to generated Python identifiers (`l_<level>_<name>`).
- `loads` — mapping of identifiers to load instructions
  (`VAR_LOAD_PARAMETER`, `VAR_LOAD_RESOLVE`, `VAR_LOAD_ALIAS`, `VAR_LOAD_UNDEFINED`).
- `stores` — set of names assigned in the scope.

`enter_frame()` and `leave_frame()` translate these load instructions into actual
Python code (e.g. resolving undefined names, aliasing outer variables).

```mermaid
sequenceDiagram
    participant CG as CodeGenerator
    participant F as Frame
    participant S as Symbols

    CG->>F: inner()
    CG->>S: analyze_node(node)
    CG->>CG: enter_frame(frame)
    Note over CG: emit resolve/alias/undefined code
    CG->>CG: blockvisit(body, frame)
    CG->>CG: leave_frame(frame)
    Note over CG: emit missing assignments
```

---

## Statement Visitors

The `CodeGenerator` implements a `visit_<NodeType>` method for each statement node.
The most significant ones are described below.

### `visit_Template`

The root visitor. It:

1. Emits imports from `jinja2.runtime` (the exported names).
2. Collects all `{% block %}` nodes into `self.blocks`.
3. Emits imports for `ImportedName` nodes.
4. Generates the `root()` render function.
5. Generates a `block_<name>()` function for each block.
6. Emits the `blocks` dictionary and `debug_info`.

```mermaid
flowchart TD
    A["visit_Template"] --> B["Emit runtime imports"]
    B --> C["Collect blocks"]
    C --> D["Emit import aliases"]
    D --> E["Emit root() function"]
    E --> F{"have_extends?"}
    F -->|yes| G["Emit parent_template call"]
    F -->|no| H["Skip"]
    G --> I["Emit block_<name>() functions"]
    H --> I
    I --> J["Emit blocks dict + debug_info"]
```

### Inheritance: `visit_Extends` and `visit_Block`

- `visit_Extends` emits code to load the parent template and merge its blocks into
  `context.blocks`. It tracks `extends_so_far` and `has_known_extends` to optimize
  child templates.
- `visit_Block` emits a call to the block function stored in `context.blocks`. It
  handles `scoped` blocks (deriving a new context) and `required` blocks (raising a
  runtime error if not overridden).

### `visit_Include`, `visit_Import`, `visit_FromImport`

These handle template inclusion and importing. They select the appropriate environment
method (`get_template`, `select_template`, `get_or_select_template`) and emit code to
render or expose the included template's module.

### `visit_For`

Handles `{% for %}` loops, including:

- **Extended loops** — when `loop` is accessed, the loop is recursive, or a scoped
  block is present, a `LoopContext` is created.
- **Loop filtering** — `{% for x in y if cond %}` generates a filter generator
  function.
- **Recursive loops** — generate a `loop()` function that buffers output.
- **`else` clauses** — tracked via an iteration indicator variable.

### `visit_If`, `visit_Macro`, `visit_CallBlock`, `visit_FilterBlock`, `visit_With`

These emit the corresponding Python control flow, using soft frames for `if`, buffered
inner frames for macros/filter blocks, and inner frames for `with`/`scope`.

### `visit_Output`

The most performance-sensitive visitor. It attempts to evaluate constant children at
compile time (constant folding) and groups consecutive constants into a single
`repr()`-ed string. Non-constant children are wrapped with the appropriate
escape/finalize calls.

```mermaid
flowchart TD
    A["visit_Output"] --> B{"require_output_check?"}
    B -->|yes| C["Emit 'if parent_template is None:'"]
    B -->|no| D["Continue"]
    C --> D
    D --> E["For each child node"]
    E --> F{"Constant?"}
    F -->|yes| G["Fold into const group"]
    F -->|no| H["Append as runtime node"]
    G --> I["Emit yield/buffer code"]
    H --> I
```

### `visit_Assign` and `visit_AssignBlock`

- `visit_Assign` pushes assignment tracking, emits the target and value, then pops
  tracking (which may update `context.vars` and `context.exported_vars`).
- `visit_AssignBlock` handles `{% set x %}...{% endset %}` by buffering the body and
  assigning the joined result.

---

## Expression Visitors

Expression visitors emit Python expressions. Many are decorated with `@optimizeconst`,
which attempts constant folding via the `Optimizer` before emitting code.

### Binary and Unary Operators

`_make_binop` and `_make_unop` are factory functions that generate visitor methods for
arithmetic, comparison, and logical operators. When the environment is sandboxed and
the operator is intercepted, they emit calls to `environment.call_binop` /
`environment.call_unop` instead of raw Python operators.

```python
visit_Add = _make_binop("+")
visit_Sub = _make_binop("-")
visit_Mul = _make_binop("*")
# ... etc
visit_Pos = _make_unop("+")
visit_Neg = _make_unop("-")
visit_Not = _make_unop("not ")
```

### `visit_Name`

Resolves a name to its generated reference. For loads, it emits an undefined-check
unless the symbol is a known parameter:

```python
(undefined(name='x') if l_0_x is missing else l_0_x)
```

### `visit_Filter` and `visit_Test`

Both use the `_filter_test_common` context manager, which:

1. Wraps the call in `auto_await` for async environments.
2. Emits the filter/test identifier (resolved via `pull_dependencies`).
3. Injects the `context`/`eval_ctx`/`environment` argument if the filter requires it.
4. Emits the signature (arguments and keyword arguments).

### `visit_Call`

Emits a function call, routing through `environment.call` (sandboxed) or
`context.call`. It forwards `caller`, `_loop_vars`, and `_block_vars` as extra keyword
arguments when appropriate.

### `visit_Getattr` and `visit_Getitem`

Route attribute and item access through `environment.getattr` / `environment.getitem`
to respect sandboxing and custom behavior. Slices bypass `getitem`.

### Other Expression Visitors

| Visitor | Emits |
|---------|-------|
| `visit_Const` | A literal (`repr` or `str` for floats). |
| `visit_TemplateData` | Literal template text, wrapped in `Markup` if autoescaping. |
| `visit_Tuple` / `visit_List` / `visit_Dict` | Python literals. |
| `visit_Concat` | `markup_join` / `str_join` call. |
| `visit_Compare` | Chained comparison. |
| `visit_CondExpr` | Python conditional expression with undefined fallback. |
| `visit_MarkSafe` / `visit_MarkSafeIfAutoescape` | `Markup(...)` wrapping. |
| `visit_EnvironmentAttribute` | `environment.<name>`. |
| `visit_ExtensionAttribute` | `environment.extensions[...].<name>`. |
| `visit_ImportedName` | The generated import alias. |
| `visit_ContextReference` | `context`. |
| `visit_DerivedContextReference` | A derived context expression. |
| `visit_Continue` / `visit_Break` | `continue` / `break`. |
| `visit_Scope` / `visit_OverlayScope` | Scoped blocks with isolated frames. |
| `visit_EvalContextModifier` | Modifies `context.eval_ctx` attributes. |
| `visit_ScopedEvalContextModifier` | Saves/reverts `eval_ctx` around a body. |

---

## Dependency Collection

Before emitting the root and block functions, the compiler calls `pull_dependencies()`,
which uses `DependencyFinderVisitor` to collect all filter and test names. For each
name, it emits a `try/except` block that resolves the filter/test from the environment
at runtime, falling back to a function that raises `TemplateRuntimeError`.

```mermaid
flowchart TD
    A["pull_dependencies(nodes)"] --> B["DependencyFinderVisitor"]
    B --> C["Collect filters & tests"]
    C --> D["For each name"]
    D --> E["Emit try: resolve from environment"]
    E --> F["Emit except KeyError: define error-raising stub"]
```

This design allows filters/tests used inside `if` or conditional expressions to be
resolved lazily, so undefined filters only raise errors when actually invoked.

---

## Undeclared Name Detection

`find_undeclared()` uses `UndeclaredNameVisitor` to determine which of a set of names
(e.g. `self`, `super`, `caller`, `kwargs`, `varargs`) are accessed without being
declared. This is used to:

- Decide whether to inject a `TemplateReference` for `self`.
- Decide whether to inject `context.super(...)` for `super`.
- Decide whether a macro needs `caller`, `kwargs`, or `varargs` parameters.

The visitor raises `VisitorExit` once all target names have been found, short-circuiting
the traversal.

---

## Constant Folding and the Optimizer

The `@optimizeconst` decorator wraps expression visitors. When the frame is not
volatile and an optimizer is present, it runs the
[Optimizer](compilation_and_analysis.md) on the node. If the optimizer produces a
different node (typically a `Const`), the compiler visits that instead.

```mermaid
flowchart TD
    A["visit_<Expr>(node, frame)"] --> B{"optimizer and not volatile?"}
    B -->|no| C["Emit original expression"]
    B -->|yes| D["new_node = optimizer.visit(node)"]
    D --> E{"new_node != node?"}
    E -->|yes| F["visit(new_node, frame)"]
    E -->|no| C
```

The `Optimizer` (a `NodeTransformer`) performs constant folding by calling
`node.as_const()` on `Expr` nodes and replacing them with `Const` nodes when possible.

---

## Output Finalization

The `_make_finalize()` method builds a `_FinalizeInfo` named tuple containing:

- `const` — a function to finalize constant data at compile time.
- `src` — source code to wrap around runtime-evaluated nodes.

This respects the environment's `finalize` function and its `_PassArg` signature
(`context`, `eval_context`, or `environment`). The result is cached in `self._finalize`
so it is only computed once.

---

## Introspection: `TrackingCodeGenerator`

The [meta](compilation_and_analysis.md) module subclasses `CodeGenerator` as
`TrackingCodeGenerator`. It overrides `write()` to do nothing (no code is emitted) and
`enter_frame()` to record all identifiers that would be resolved at runtime but are not
present in `environment.globals`. This powers `meta.find_undeclared_variables()`.

```mermaid
graph LR
    META["meta.find_undeclared_variables"] --> TCG["TrackingCodeGenerator"]
    TCG -->|subclass of| CG["CodeGenerator"]
    TCG -->|records| UND["undeclared_identifiers"]
```

---

## Component Interaction Summary

```mermaid
graph TD
    subgraph "compiler.py"
        CG["CodeGenerator"]
        FR["Frame"]
        MR["MacroRef"]
        DFV["DependencyFinderVisitor"]
        UNV["UndeclaredNameVisitor"]
        FI["_FinalizeInfo"]
    end

    subgraph "idtracking.py"
        SYM["Symbols"]
        RV["RootVisitor"]
        FSV["FrameSymbolVisitor"]
    end

    subgraph "optimizer.py"
        OPT["Optimizer"]
    end

    subgraph "visitor.py"
        NV["NodeVisitor"]
        NT["NodeTransformer"]
    end

    subgraph "meta.py"
        TCG["TrackingCodeGenerator"]
    end

    CG -->|extends| NV
    CG -->|owns| FR
    CG -->|uses| DFV
    CG -->|uses| UNV
    CG -->|uses| OPT
    CG -->|uses| FI
    FR -->|owns| SYM
    SYM -->|uses| RV
    SYM -->|uses| FSV
    OPT -->|extends| NT
    TCG -->|extends| CG
    MR -->|used by| CG
```

---

## Related Modules

- **[lexing_and_parsing](lexing_and_parsing.md)** — produces the AST consumed by the
  compiler (`nodes.py`, `parser.py`, `lexer.py`, `visitor.py`).
- **[compilation_and_analysis](compilation_and_analysis.md)** — the sibling modules
  `optimizer.py`, `idtracking.py`, and `meta.py` that the compiler depends on.
- **[runtime_support_and_foundation](runtime_support_and_foundation.md)** — the runtime
  objects (`Context`, `Macro`, `LoopContext`, `Undefined`, etc.) referenced by the
  generated code.
- **[template_environment_and_loading](template_environment_and_loading.md)** — the
  `Environment` that configures the code generator and provides filters/tests.
- **[extensions_and_filters](extensions_and_filters.md)** — extensions and filters that
  may inject custom nodes handled by the compiler.
