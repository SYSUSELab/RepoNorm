# Lexing and Parsing Module

## Purpose

The `lexing_and_parsing` module is the front-end of the Jinja2 template engine. It is responsible for transforming raw template source text into a structured, traversable Abstract Syntax Tree (AST) that downstream stages (compilation and analysis) can consume. This module bridges the gap between human-authored template syntax and the machine-processable representation used by the compiler.

The module handles three fundamental concerns:

1. **Tokenization** — Converting raw template text into a stream of typed tokens, distinguishing between literal template data and Jinja-specific constructs (statements, expressions, comments, and block delimiters).
2. **Parsing** — Consuming the token stream and building a hierarchical AST composed of typed node objects that represent the template's logical structure.
3. **Tree traversal** — Providing a generic visitor mechanism for walking and transforming the AST, which is used by later stages such as the compiler and optimizer.

## Architecture

The module is organized as a linear pipeline: source text flows through the lexer, into the parser, producing an AST of nodes, which can then be traversed via the visitor infrastructure.

```mermaid
flowchart LR
    A[Template Source Text] --> B[lexer.py]
    B -->|Token Stream| C[parser.py]
    C -->|AST| D[nodes.py]
    D --> E[visitor.py]
    E -->|Traversal / Transformation| F[Compilation & Analysis]

    subgraph lexing_and_parsing
        B
        C
        D
        E
    end
```

### Component Interaction Detail

```mermaid
flowchart TD
    subgraph Lexer
        L1[Environment lexing config] --> L2[Tokenize source]
        L2 --> L3[TokenStream]
    end

    subgraph Parser
        P1[Parser consumes TokenStream] --> P2[Recursive descent]
        P2 --> P3[Build Node tree]
    end

    subgraph Nodes
        N1[Node base class]
        N2[Stmt nodes]
        N3[Expr nodes]
        N4[Helper nodes]
        N1 --> N2
        N1 --> N3
        N1 --> N4
    end

    subgraph Visitor
        V1[NodeVisitor]
        V2[NodeTransformer]
    end

    L3 --> P1
    P3 --> N1
    N1 --> V1
    N1 --> V2
```

## Core Components

The module consists of four tightly coupled components, each documented separately:

- **[Lexer](./lexer.md)** — Defines the token types and the `Lexer` class that scans template source into a `TokenStream`. It handles Jinja's configurable delimiters (block, variable, comment) and produces tokens consumed by the parser.

- **[Parser](./parser.md)** — Implements a recursive-descent parser that consumes the token stream and constructs the AST. It enforces Jinja's grammar for statements, expressions, and template inheritance constructs.

- **[Nodes](./nodes.md)** — Defines the AST node hierarchy, including the `Node` base class and its subclasses for statements (`Stmt`), expressions (`Expr`), and helper nodes. Nodes carry source location metadata and support serialization.

- **[Visitor](./visitor.md)** — Provides the `NodeVisitor` and `NodeTransformer` classes for generic traversal and transformation of the AST, enabling downstream stages to walk the tree without coupling to specific node types.

## Data Flow Summary

| Stage | Input | Output | Key Abstraction |
|-------|-------|--------|-----------------|
| Lexing | Raw template string | `TokenStream` | `Token`, `Lexer` |
| Parsing | `TokenStream` | AST root `Node` | `Parser` |
| Representation | — | Typed node tree | `Node`, `Stmt`, `Expr` |
| Traversal | AST | Visited/transformed AST | `NodeVisitor`, `NodeTransformer` |

The output of this module — a fully constructed AST — is the primary input to the `compilation_and_analysis` module, where it is optimized and compiled into executable Python code.