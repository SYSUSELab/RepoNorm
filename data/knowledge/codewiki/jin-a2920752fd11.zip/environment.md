# Environment Module

## Introduction

The **Environment module** (`src/jinja2/environment.py`) is the central orchestration layer of Jinja2. It is the primary entry point that most users interact with, and it ties together every other subsystem in the library: lexing, parsing, compilation, runtime execution, template loading, and bytecode caching.

The `Environment` class holds all shared configuration (delimiters, filters, tests, globals, policies) and provides the high-level API for loading, compiling, and rendering templates. The `Template` class represents a compiled, renderable template, while `TemplateModule`, `TemplateExpression`, and `TemplateStream` provide specialized access patterns for imported templates, expression evaluation, and streaming output respectively.

This module is the "hub" of the module tree — it depends on nearly every other module and is depended upon by the specialized environment variants (`nativetypes`, `sandbox`).

---

## Architecture Overview

The environment module sits at the top of the dependency hierarchy. It consumes the lexing/parsing, compilation, runtime, and loading subsystems, and is extended by specialized environment subclasses.

```mermaid
graph TD
    subgraph "Environment Module (this module)"
        ENV[Environment]
        TPL[Template]
        TMOD[TemplateModule]
        TEXPR[TemplateExpression]
        TSTREAM[TemplateStream]
    end

    subgraph "Specialized Environments"
        NATIVE[NativeEnvironment]
        SANDBOX[SandboxedEnvironment]
        IMMUT[ImmutableSandboxedEnvironment]
    end

    subgraph "Lexing & Parsing"
        LEXER[Lexer]
        PARSER[Parser]
        NODES[nodes.Template]
    end

    subgraph "Compilation & Analysis"
        CODEGEN[CodeGenerator]
        OPT[Optimizer]
    end

    subgraph "Runtime Support"
        CTX[Context]
        UNDEF[Undefined]
        EXC[exceptions]
    end

    subgraph "Loading & Caching"
        LOADER[BaseLoader]
        BCC[BytecodeCache]
    end

    subgraph "Extensions & Filters"
        EXT[Extension]
        FILTERS[filters / tests]
    end

    ENV --> LEXER
    ENV --> PARSER
    ENV --> CODEGEN
    ENV --> CTX
    ENV --> LOADER
    ENV --> BCC
    ENV --> EXT
    ENV --> FILTERS
    ENV --> UNDEF
    ENV --> EXC

    TPL --> ENV
    TPL --> CTX
    TMOD --> TPL
    TEXPR --> TPL
    TSTREAM --> TPL

    NATIVE -.->|extends| ENV
    SANDBOX -.->|extends| ENV
    IMMUT -.->|extends| SANDBOX
```

---

## Core Components

### `Environment`

The `Environment` is the core component of Jinja. It contains important shared variables such as configuration, filters, tests, globals, and policies. Instances may be modified only if they are not shared and no template has been loaded yet — modifications after the first template load lead to undefined behavior.

**Key responsibilities:**

- **Configuration storage** — delimiters (`block_start_string`, `variable_start_string`, etc.), whitespace handling (`trim_blocks`, `lstrip_blocks`), newline handling, and async mode.
- **Registry management** — `filters`, `tests`, `globals`, and `policies` dictionaries, seeded from `defaults`.
- **Extension management** — loading, binding, and iterating extensions by priority.
- **Compilation pipeline** — `parse()`, `lex()`, `preprocess()`, `compile()`, and `compile_expression()`.
- **Template loading** — `get_template()`, `select_template()`, `get_or_select_template()`, `from_string()`, and the internal `_load_template()` with caching.
- **Filter/test invocation** — `call_filter()` and `call_test()` mirror how the compiler invokes them, including `@pass_context`, `@pass_eval_context`, and `@pass_environment` handling.
- **Overlay support** — `overlay()` creates a linked environment sharing data but with overridden attributes.

**Class-level hooks** (overridable by subclasses):

| Attribute | Purpose |
|-----------|---------|
| `code_generator_class` | Code generator used for compilation (default `CodeGenerator`) |
| `context_class` | Context class used for templates (default `Context`) |
| `template_class` | Template class produced by the environment |
| `concat` | String concatenation function (`"".join` by default) |
| `sandboxed` | Flag controlling sandboxed code generation |
| `overlayed` / `linked_to` / `shared` | Overlay and sharing state |

**Initialization parameters** include delimiters, whitespace options, `extensions`, `optimized`, `undefined`, `finalize`, `autoescape`, `loader`, `cache_size`, `auto_reload`, `bytecode_cache`, and `enable_async`. The constructor argument order is intentionally stable because it is used internally for spontaneous environments and unit tests.

> **Note:** The `undefined` class must be a subclass of `jinja2.Undefined`, and the block/variable/comment start strings must all differ. These invariants are enforced by `_environment_config_check()`.

### `Template`

A `Template` is a compiled, renderable template. Templates are normally created through `Environment` methods, but can also be constructed directly (which creates a shared "spontaneous" environment behind the scenes via `get_spontaneous_environment()`).

**Construction paths:**

- `Template.from_code()` — builds a template from compiled code and globals (used by loaders and the environment).
- `Template.from_module_dict()` — builds a template from a module dict (used by the module loader).
- `Template._from_namespace()` — the shared internal constructor that wires up `blocks`, `root_render_func`, `_debug_info`, and `_uptodate`.

**Rendering API:**

| Method | Description |
|--------|-------------|
| `render(*args, **kwargs)` | Renders the whole template to a string (sync or async-aware) |
| `render_async(*args, **kwargs)` | Async coroutine version of `render` |
| `generate(*args, **kwargs)` | Yields rendered pieces lazily |
| `generate_async(*args, **kwargs)` | Async iterator version of `generate` |
| `stream(*args, **kwargs)` | Returns a `TemplateStream` wrapping `generate` |
| `new_context(...)` | Creates a new `Context` for this template |
| `make_module(...)` / `make_module_async(...)` | Evaluates the template as a module |
| `module` (property) | Cached `TemplateModule` (not available in async mode) |

**Introspection helpers:** `get_corresponding_lineno()`, `is_up_to_date` (property), and `debug_info` (property).

### `TemplateModule`

Represents an imported template. All exported names of the template are available as attributes, and converting it to a string renders its contents. It is constructed from a `Template`, a `Context`, and an optional `body_stream`. In async mode a `body_stream` must be supplied.

### `TemplateExpression`

Returned by `Environment.compile_expression()`. It encapsulates expression-like access to a template, accepting keyword arguments that appear as variables in the expression. When called, it renders the wrapped template, consumes the output, and returns the `result` variable — optionally converting `Undefined` to `None` based on `undefined_to_none`.

### `TemplateStream`

A generator-like wrapper that can buffer multiple items to reduce iteration overhead. Buffering is disabled by default; `enable_buffering(size)` combines `size` items into a single string. `dump(fp, encoding, errors)` writes the complete stream to a file or file-like object.

---

## Compilation and Rendering Pipeline

The environment orchestrates a multi-stage pipeline from source string to rendered output. The following diagram shows the flow through the environment's methods and the subsystems they delegate to.

```mermaid
flowchart TD
    SRC[Template Source String] --> PRE[Environment.preprocess]
    PRE --> LEX[Environment.lex / Lexer.tokenize]
    LEX --> PARSE[Environment.parse / Parser.parse]
    PARSE --> AST[nodes.Template AST]
    AST --> GEN[Environment._generate / CodeGenerator]
    GEN --> CODE[Python Source Code]
    CODE --> COMPILE[Environment._compile / compile]
    COMPILE --> CO[Code Object]
    CO --> FROMCODE[Template.from_code]
    FROMCODE --> TPLOBJ[Template Object]
    TPLOBJ --> RENDER[Template.render / generate]
    RENDER --> CTX[Context]
    CTX --> OUT[Rendered Output]
```

**Stage details:**

1. **Preprocess** — `preprocess()` runs each extension's `preprocess()` in priority order over the source.
2. **Lex** — `lex()` / `_tokenize()` produce a `TokenStream`; extensions may filter the stream via `filter_stream()`.
3. **Parse** — `parse()` delegates to `Parser(self, source, name, filename).parse()` to produce a `nodes.Template` AST.
4. **Generate** — `_generate()` calls `generate()` from the compiler module, using `code_generator_class` and the `optimized` flag.
5. **Compile** — `_compile()` calls Python's built-in `compile()` to produce a code object.
6. **Instantiate** — `Template.from_code()` executes the code and builds the `Template`.
7. **Render** — `render()` / `generate()` create a `Context` and drive `root_render_func`.

> For details on the lexing and parsing stages, see [lexing_and_parsing.md](lexing_and_parsing.md). For the code generation stage, see [compilation_and_analysis.md](compilation_and_analysis.md). For the runtime context and undefined handling, see [runtime_support_and_foundation.md](runtime_support_and_foundation.md).

---

## Template Loading and Caching

The environment delegates actual template retrieval to a configured `BaseLoader` and caches results in an LRU cache keyed by `(weakref.ref(loader), name)`.

```mermaid
sequenceDiagram
    participant User
    participant Env as Environment
    participant Cache as LRU Cache
    participant Loader as BaseLoader
    participant BCC as BytecodeCache
    participant Tpl as Template

    User->>Env: get_template(name)
    Env->>Env: join_path(name, parent)
    Env->>Cache: lookup (loader_ref, name)
    alt cache hit and up-to-date
        Cache-->>Env: cached Template
        Env->>Tpl: update globals if provided
        Env-->>User: Template
    else cache miss
        Env->>Loader: load(env, name, globals)
        Loader->>Loader: get_source(env, name)
        Loader->>BCC: get_bucket(...)
        alt bytecode cached
            BCC-->>Loader: cached code
        else no bytecode
            Loader->>Env: compile(source, name, filename)
            Env-->>Loader: code object
            Loader->>BCC: set_bucket(bucket)
        end
        Loader->>Tpl: from_code(env, code, globals, uptodate)
        Tpl-->>Loader: Template
        Loader-->>Env: Template
        Env->>Cache: store (loader_ref, name)
        Env-->>User: Template
    end
```

**Cache behavior** is controlled by `cache_size`:

- `0` — caching disabled; templates recompiled every time.
- `-1` — unbounded cache (plain dict).
- positive `n` — LRU cache of capacity `n` (default `400`).

**Auto-reload** — when `auto_reload` is `True`, the loader's `uptodate` callback is consulted on each cache hit; if it returns `False`, the template is reloaded.

**Globals handling** — `make_globals()` returns a `ChainMap` overlaying template-specific globals on top of environment globals, ensuring template globals never mutate the environment's globals.

> For loader implementations and bytecode cache backends, see [loaders.md](loaders.md) and [bytecode_cache.md](bytecode_cache.md).

---

## Specialized Environment Variants

The environment module is designed for extension. Two specialized subclasses live in sibling modules and override key hooks:

```mermaid
classDiagram
    class Environment {
        +code_generator_class
        +context_class
        +template_class
        +concat
        +sandboxed
        +getitem()
        +getattr()
        +call_filter()
        +call_test()
    }
    class NativeEnvironment {
        +code_generator_class = NativeCodeGenerator
        +concat = native_concat
    }
    class SandboxedEnvironment {
        +sandboxed = True
        +is_safe_attribute()
        +is_safe_callable()
        +call_binop()
        +call_unop()
        +getitem()
        +getattr()
        +format_string()
        +call()
    }
    class ImmutableSandboxedEnvironment

    Environment <|-- NativeEnvironment
    Environment <|-- SandboxedEnvironment
    SandboxedEnvironment <|-- ImmutableSandboxedEnvironment
```

- **`NativeEnvironment`** — renders templates to native Python types rather than strings by swapping `code_generator_class` and `concat`. See [nativetypes.md](nativetypes.md).
- **`SandboxedEnvironment`** — sets `sandboxed = True` to generate sandboxed code and overrides attribute/item access, callable checks, operator interception, and string formatting to enforce security. See [sandbox.md](sandbox.md).

---

## Extension Integration

Extensions hook into the environment at multiple points. The environment loads them via `load_extensions()`, binds them to the environment, and iterates them by priority.

```mermaid
flowchart LR
    subgraph Environment
        LOADEX[load_extensions]
        ITER[iter_extensions]
        PRE[preprocess]
        TOK[_tokenize]
    end
    subgraph Extension
        E_PRE[preprocess]
        E_FILTER[filter_stream]
        E_BIND[bind]
        E_PRIORITY[priority]
    end
    LOADEX --> E_BIND
    ITER --> E_PRIORITY
    PRE --> E_PRE
    TOK --> E_FILTER
```

- `add_extension()` adds an extension after environment creation.
- `extend(**attributes)` registers callbacks/config values without breaking inheritance.
- `overlay()` re-binds all extensions to the new overlay environment and merges any extra extensions.

> For extension implementations, see [extensions_and_filters.md](extensions_and_filters.md).

---

## Filter and Test Invocation

The environment provides `call_filter()` and `call_test()` which replicate the compiler's invocation semantics. Both delegate to `_filter_test_common()`, which:

1. Looks up the function in `filters` or `tests`.
2. Raises `TemplateRuntimeError` if not found (with a helpful hint if the name is `Undefined`).
3. Prepends the value as the first argument.
4. Injects `context`, `eval_ctx`, or the environment itself based on the `_PassArg` decorator detected on the function.

This ensures that filters/tests behave identically whether invoked from compiled template code or directly from Python.

---

## Async Support

When `enable_async=True`, the environment sets `is_async = True`, which propagates through the entire pipeline:

- The compiler generates `async def` functions and `async for` loops.
- `Template.render()` runs the coroutine via an event loop; `render_async()` is the native coroutine.
- `generate_async()` yields an async iterator; `generate()` bridges to sync by running the loop.
- `make_module_async()` must be used instead of `make_module()`; the `module` property is unavailable.

---

## Component Interaction Summary

```mermaid
graph LR
    ENV[Environment] -->|compile| CODEGEN[CodeGenerator]
    ENV -->|parse| PARSER[Parser]
    ENV -->|lex| LEXER[Lexer]
    ENV -->|load| LOADER[BaseLoader]
    ENV -->|cache| BCC[BytecodeCache]
    ENV -->|extensions| EXT[Extension]
    ENV -->|filters/tests| FT[filters / tests]
    ENV -->|undefined| UNDEF[Undefined]
    ENV -->|errors| EXC[exceptions]

    TPL[Template] -->|uses| ENV
    TPL -->|creates| CTX[Context]
    TPL -->|produces| TMOD[TemplateModule]
    TPL -->|wraps| TEXPR[TemplateExpression]
    TPL -->|streams| TSTREAM[TemplateStream]
```

---

## Related Documentation

- [lexing_and_parsing.md](lexing_and_parsing.md) — Lexer, Parser, AST nodes, and visitors.
- [compilation_and_analysis.md](compilation_and_analysis.md) — CodeGenerator, Optimizer, id tracking, and meta analysis.
- [runtime_support_and_foundation.md](runtime_support_and_foundation.md) — Context, Undefined, exceptions, and utilities.
- [loaders.md](loaders.md) — Template loader implementations.
- [bytecode_cache.md](bytecode_cache.md) — Bytecode cache backends.
- [nativetypes.md](nativetypes.md) — Native Python type rendering.
- [sandbox.md](sandbox.md) — Sandboxed execution environments.
- [extensions_and_filters.md](extensions_and_filters.md) — Extensions and built-in filters/tests.
