# Bytecode Cache Module

## Introduction

The `bytecode_cache` module (`src/jinja2/bccache.py`) provides Jinja's **optional bytecode caching system**. Its purpose is to persist the compiled Python bytecode of templates so that expensive parsing and compilation steps can be skipped on subsequent loads. This is especially valuable for:

- **Forking web applications** that are initialized on the first request (e.g. Gunicorn/uWSGI workers), where each worker would otherwise recompile every template.
- **Complex template situations** where compilation of many templates noticeably slows down application startup.

The module defines a small, pluggable abstraction (`BytecodeCache`) with two concrete implementations — a filesystem-backed cache and a memcached-backed cache — plus a `Bucket` container that carries the bytecode and handles cache invalidation transparently.

> **Note:** This module is consumed by the template loading pipeline. For how templates are loaded and how the cache is wired into the environment, see [template_environment_and_loading.md](template_environment_and_loading.md).

---

## Core Components

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `Bucket` | class | Holds the bytecode for a single template; performs magic-header and checksum validation. |
| `BytecodeCache` | abstract base class | Defines the cache interface (`load_bytecode`, `dump_bytecode`) and provides key/checksum helpers. |
| `FileSystemBytecodeCache` | concrete cache | Stores bytecode as files in a directory. |
| `MemcachedBytecodeCache` | concrete cache | Stores bytecode in a memcached-compatible client. |
| `_MemcachedClient` | protocol (typing) | Structural type describing the minimal memcached client interface. |

### Module-level constants

- `bc_version = 5` — the bytecode cache format version.
- `bc_magic` — a magic byte prefix written at the start of every cache entry. It encodes both the cache format version and the running Python major/minor version, so that bytecode produced by an incompatible Python interpreter is automatically rejected.

---

## Architecture

The module is organized around a clear separation of concerns: the **cache backend** decides *where* bytecode lives, while the **`Bucket`** decides *whether* cached bytecode is still valid.

```mermaid
classDiagram
    class BytecodeCache {
        <<abstract>>
        +load_bytecode(bucket)*
        +dump_bytecode(bucket)*
        +clear()
        +get_cache_key(name, filename) str
        +get_source_checksum(source) str
        +get_bucket(env, name, filename, source) Bucket
        +set_bucket(bucket)
    }
    class FileSystemBytecodeCache {
        +directory: str
        +pattern: str
        +_get_default_cache_dir() str
        +_get_cache_filename(bucket) str
        +load_bytecode(bucket)
        +dump_bytecode(bucket)
        +clear()
    }
    class MemcachedBytecodeCache {
        +client: _MemcachedClient
        +prefix: str
        +timeout: int
        +ignore_memcache_errors: bool
        +load_bytecode(bucket)
        +dump_bytecode(bucket)
    }
    class Bucket {
        +environment: Environment
        +key: str
        +checksum: str
        +code: CodeType
        +reset()
        +load_bytecode(f)
        +write_bytecode(f)
        +bytecode_from_string(s)
        +bytecode_to_string() bytes
    }
    class _MemcachedClient {
        <<protocol>>
        +get(key) bytes
        +set(key, value, timeout)
    }

    BytecodeCache <|-- FileSystemBytecodeCache
    BytecodeCache <|-- MemcachedBytecodeCache
    BytecodeCache ..> Bucket : creates & manages
    MemcachedBytecodeCache ..> _MemcachedClient : uses
```

---

## Component Details

### `Bucket`

A `Bucket` is the unit of transfer between the cache and the loader. It is created and initialized by the cache (via `BytecodeCache.get_bucket`) and passed to the loading functions. Crucially, **individual cache subclasses do not need to handle cache invalidation** — the bucket does it automatically.

**State:**
- `environment` — the owning `Environment`.
- `key` — the unique cache key (a SHA-1 hex digest).
- `checksum` — the source checksum used to detect source changes.
- `code` — the cached `CodeType`, or `None` if no valid bytecode is loaded.

**Key methods:**

| Method | Description |
|--------|-------------|
| `reset()` | Unloads the bytecode by setting `code = None`. |
| `load_bytecode(f)` | Reads from a binary file-like object, validating the magic header, checksum, and marshal payload. Resets on any mismatch. |
| `write_bytecode(f)` | Writes the magic header, checksum, and marshalled code. Raises `TypeError` if the bucket is empty. |
| `bytecode_from_string(s)` | Convenience wrapper around `load_bytecode` using a `BytesIO`. |
| `bytecode_to_string()` | Convenience wrapper around `write_bytecode` returning `bytes`. |

**Validation logic in `load_bytecode`:**

```mermaid
flowchart TD
    A[Read magic header] --> B{magic == bc_magic?}
    B -- No --> R[reset: code = None]
    B -- Yes --> C[Read checksum]
    C --> D{checksum matches?}
    D -- No --> R
    D -- Yes --> E[marshal.load]
    E --> F{EOFError / ValueError / TypeError?}
    F -- Yes --> R
    F -- No --> G[code = loaded code]
```

The `bytecode_from_string` / `bytecode_to_string` pair is what makes the bucket backend-agnostic: filesystem caches use the file-based methods, while memcached uses the string-based methods.

### `BytecodeCache` (abstract base)

The base class defines the contract every cache must fulfill. To implement a custom cache, subclass it and override `load_bytecode` and `dump_bytecode`.

**Abstract methods:**
- `load_bytecode(bucket)` — must load bytecode into the bucket, or do nothing if not found.
- `dump_bytecode(bucket)` — must write the bucket's bytecode back to the cache; must raise on failure rather than fail silently.

**Provided helpers:**
- `clear()` — no-op by default; subclasses may implement cache clearing.
- `get_cache_key(name, filename)` — returns a SHA-1 hex digest of the template name (and optionally the filename).
- `get_source_checksum(source)` — returns a SHA-1 hex digest of the source.
- `get_bucket(environment, name, filename, source)` — builds a `Bucket`, computes key/checksum, and calls `load_bytecode` to populate it.
- `set_bucket(bucket)` — delegates to `dump_bytecode`.

### `FileSystemBytecodeCache`

Stores bytecode as individual files on disk.

**Constructor parameters:**
- `directory` — where cache files are stored. If `None`, a safe default directory is chosen.
- `pattern` — filename template, default `"__jinja2_%s.cache"`, where `%s` is replaced by the bucket key. Multiple caches can share a directory by using distinct patterns.

**Default directory selection (`_get_default_cache_dir`):**
- On Windows (`os.name == "nt"`), the system temp directory is used directly.
- On UNIX, a per-user directory `_jinja2-cache-{uid}` is created inside the temp directory with `S_IRWXU` permissions. The directory's ownership, type, and permissions are verified; if they cannot be confirmed safe, a `RuntimeError` is raised.

**Methods:**
- `load_bytecode(bucket)` — opens the cache file if it exists and delegates to `bucket.load_bytecode`.
- `dump_bytecode(bucket)` — writes the bucket to the cache file.
- `clear()` — removes all files matching the pattern (imports `os.remove` lazily for App Engine compatibility).

### `MemcachedBytecodeCache`

Stores bytecode in any memcached-compatible client. It does **not** enforce a specific library; it accepts any object providing the minimal interface described by `_MemcachedClient`.

**Constructor parameters:**
- `client` — the memcached client.
- `prefix` — key prefix, default `"jinja2/bytecode/"`.
- `timeout` — optional expiry in seconds; a high or no timeout is recommended.
- `ignore_memcache_errors` — if `True` (default), memcache errors are swallowed; if `False`, they propagate.

**Methods:**
- `load_bytecode(bucket)` — fetches the value and calls `bucket.bytecode_from_string`.
- `dump_bytecode(bucket)` — serializes the bucket and stores it via `client.set`.
- `clear()` — inherited no-op; memcached caches cannot be cleared through this interface.

**Compatible libraries:** `cachelib`, `python-memcached`. The Django cache interface is *not* directly compatible (it stores text, not binary), but the underlying client (`django.core.cache.cache._client`) can be passed instead.

### `_MemcachedClient` (protocol)

A `typing.Protocol` (only defined under `TYPE_CHECKING`) describing the minimal client interface:

```python
class _MemcachedClient(te.Protocol):
    def get(self, key: str) -> bytes: ...
    def set(self, key: str, value: bytes, timeout: t.Optional[int] = None) -> None: ...
```

---

## Integration with the Loading Pipeline

The bytecode cache is wired into the environment via the `bytecode_cache` parameter of `Environment`. The actual cache lookup and population happens inside `BaseLoader.load` (see [template_environment_and_loading.md](template_environment_and_loading.md)).

```mermaid
sequenceDiagram
    participant Env as Environment
    participant Loader as BaseLoader
    participant BCC as BytecodeCache
    participant Bucket as Bucket
    participant Compiler as Environment.compile

    Env->>Loader: load(environment, name, globals)
    Loader->>Loader: get_source(environment, name)
    Note over Loader: returns (source, filename, uptodate)
    Loader->>BCC: get_bucket(env, name, filename, source)
    BCC->>BCC: get_cache_key + get_source_checksum
    BCC->>Bucket: new Bucket(env, key, checksum)
    BCC->>BCC: load_bytecode(bucket)
    BCC-->>Loader: bucket
    alt bucket.code is None
        Loader->>Compiler: compile(source, name, filename)
        Compiler-->>Loader: code
        Loader->>Bucket: bucket.code = code
        Loader->>BCC: set_bucket(bucket)
        BCC->>BCC: dump_bytecode(bucket)
    end
    Loader->>Env: template_class.from_code(env, code, globals, uptodate)
```

**Key points:**
1. The loader always fetches the source first (needed to compute the checksum).
2. If a valid bucket is returned with `code` set, compilation is skipped entirely.
3. If the bucket is empty (cache miss or stale), the template is compiled and the fresh bytecode is written back to the cache.

---

## Data Flow and Cache Invalidation

Cache invalidation is handled entirely by the `Bucket` and the magic header, so backends stay simple.

```mermaid
flowchart LR
    subgraph Write Path
        C1[Compiled CodeType] --> B1[Bucket.code]
        B1 --> W[write_bytecode]
        W --> M[bc_magic + checksum + marshal]
        M --> S[(Cache Storage)]
    end
    subgraph Read Path
        S --> R[load_bytecode]
        R --> V{magic & checksum valid?}
        V -- Yes --> B2[Bucket.code]
        V -- No --> N[code = None -> recompile]
    end
```

**Invalidation triggers:**
- **Python version change** — `bc_magic` embeds the interpreter's major/minor version, so bytecode from a different Python is rejected.
- **Cache format change** — `bc_version` is embedded in `bc_magic`.
- **Source change** — the source checksum stored in the bucket is compared against the freshly computed checksum.
- **Corrupt payload** — marshal load failures (`EOFError`, `ValueError`, `TypeError`) reset the bucket.

---

## Dependencies

```mermaid
graph TD
    BCC[bccache.py]
    BCC -->|uses Environment type| ENV[environment.py]
    BCC -->|used by BaseLoader.load| LOAD[loaders.py]
    BCC -->|stdlib| STD[errno, fnmatch, marshal, os, pickle, stat, sys, tempfile, hashlib, io, types]
    LOAD -->|calls get_bucket/set_bucket| BCC
    ENV -->|bytecode_cache attribute| BCC
```

- **`environment.py`** — `Environment` holds the `bytecode_cache` attribute and provides `compile()`, which produces the `CodeType` stored in buckets. See [template_environment_and_loading.md](template_environment_and_loading.md).
- **`loaders.py`** — `BaseLoader.load` is the primary consumer, orchestrating bucket retrieval and population. See [template_environment_and_loading.md](template_environment_and_loading.md).
- **Standard library** — `marshal` (bytecode serialization), `pickle` (checksum/version serialization), `hashlib.sha1` (keys and checksums), `tempfile`/`os`/`stat`/`errno` (filesystem cache), `fnmatch` (cache clearing).

---

## Usage Examples

### Filesystem cache

```python
from jinja2 import Environment, FileSystemLoader
from jinja2.bccache import FileSystemBytecodeCache

bcc = FileSystemBytecodeCache("/tmp/jinja_cache", "%s.cache")
env = Environment(
    loader=FileSystemLoader("templates"),
    bytecode_cache=bcc,
)
```

### Memcached cache

```python
from jinja2 import Environment, FileSystemLoader
from jinja2.bccache import MemcachedBytecodeCache
import memcache

client = memcache.Client(["127.0.0.1:11211"])
bcc = MemcachedBytecodeCache(client, prefix="jinja2/bytecode/", timeout=None)
env = Environment(
    loader=FileSystemLoader("templates"),
    bytecode_cache=bcc,
)
```

### Custom cache

```python
from jinja2.bccache import BytecodeCache

class MyCache(BytecodeCache):
    def __init__(self, directory):
        self.directory = directory

    def load_bytecode(self, bucket):
        filename = os.path.join(self.directory, bucket.key)
        if os.path.exists(filename):
            with open(filename, "rb") as f:
                bucket.load_bytecode(f)

    def dump_bytecode(self, bucket):
        filename = os.path.join(self.directory, bucket.key)
        with open(filename, "wb") as f:
            bucket.write_bytecode(f)
```

---

## Summary

The `bytecode_cache` module is a self-contained, pluggable caching layer for compiled template bytecode. Its design cleanly separates:

- **Storage backends** (`FileSystemBytecodeCache`, `MemcachedBytecodeCache`, or user-defined subclasses of `BytecodeCache`).
- **Validity logic** (`Bucket`, which transparently rejects stale or incompatible bytecode via magic headers and checksums).

This separation means new backends can be added without reimplementing invalidation, and the loading pipeline (see [template_environment_and_loading.md](template_environment_and_loading.md)) can treat the cache as a simple get/set store keyed by template name and source checksum.
