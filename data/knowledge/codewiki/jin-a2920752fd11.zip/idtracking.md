# ID Tracking Module

## Introduction

The `idtracking` module (`src/jinja2/idtracking.py`) is a compile-time analysis component of Jinja2's template compilation pipeline. Its primary responsibility is **symbol tracking** — determining how template variables (names) are referenced, stored, and resolved across different lexical scopes (frames) during compilation.

Jinja2 compiles templates into Python source code. To do this correctly, the compiler must know, for every variable name used in a template:

- Whether the name is **loaded** (read) or **stored** (assigned).
- Whether the name refers to a **parameter** (e.g., a macro argument), an **alias** to an outer-scope variable, a **resolved** runtime lookup, or an **undefined** value.
- How names map to generated Python identifiers (references) at each scope level.

The `idtracking` module answers these questions by walking the template's abstract syntax tree (AST) and building a `Symbols` object per scope. The compiler then consumes these `Symbols` to emit correct Python code.

> **Related modules:** This module operates on the AST defined in [nodes](nodes.md) and uses the traversal infrastructure from [visitor](visitor.md). Its primary consumer is the [compiler](compiler.md), and it is also used indirectly by [meta](meta.md) for introspection.

---

## Core Concepts

### Symbols

A `Symbols` instance represents the symbol table for a single lexical scope (frame). It tracks three categories of information:

| Attribute | Type | Purpose |
|-----------|------|---------|
| `refs` | `Dict[str, str]` | Maps a template name to its generated Python identifier (e.g., `"foo"` → `"l_0_foo"`). |
| `loads` | `Dict[str, Any]` | Maps a generated identifier to a *load instruction* tuple `(action, param)` describing how the variable should be initialized. |
| `stores` | `Set[str]` | The set of names that are assigned within this scope. |
| `level` | `int` | The nesting depth of this scope (0 for the root). |
| `parent` | `Optional[Symbols]` | The enclosing scope, enabling lexical lookup. |

### Load Instructions

The module defines four load instruction constants that describe how a variable reference should be initialized when entering a frame:

| Constant | Value | Meaning |
|----------|-------|---------|
| `VAR_LOAD_PARAMETER` | `"param"` | The name is a function parameter (macro argument, loop target, etc.). Always defined. |
| `VAR_LOAD_RESOLVE` | `"resolve"` | The name must be resolved at runtime from the context (e.g., `resolve("foo")`). |
| `VAR_LOAD_ALIAS` | `"alias"` | The name is an alias to a variable in an outer scope. |
| `VAR_LOAD_UNDEFINED` | `"undefined"` | The name is not yet defined and should be set to `missing`. |

These instructions are consumed by the compiler's `enter_frame` / `leave_frame` methods to emit the appropriate initialization code.

---

## Architecture

The module is built around a two-visitor design that separates **scope-boundary handling** from **symbol recording**.

```mermaid
graph TD
    subgraph "idtracking.py"
        FS[find_symbols]
        SFN[symbols_for_node]
        SYM[Symbols]
        RV[RootVisitor]
        FSV[FrameSymbolVisitor]
    end

    subgraph "visitor.py"
        NV[NodeVisitor]
    end

    subgraph "nodes.py"
        N[Node AST types]
    end

    FS -->|creates| SYM
    FS -->|creates| FSV
    FS -->|visits| N
    SFN -->|creates| SYM
    SFN -->|calls analyze_node| SYM
    SYM -->|creates| RV
    RV -->|delegates to| FSV
    RV -->|subclass of| NV
    FSV -->|subclass of| NV
    FSV -->|mutates| SYM
    RV -->|visits| N
    FSV -->|visits| N
```

### Component Responsibilities

- **`Symbols`** — The central data structure. Holds the symbol table for one scope and provides operations to define references, record loads/stores, resolve names across parent scopes, and merge branch results.

- **`RootVisitor`** — A `NodeVisitor` that handles **scope boundaries**. It knows which node types introduce new scopes (blocks, macros, for-loops, scopes, overlay scopes) and how to traverse into them, delegating the actual symbol recording to a `FrameSymbolVisitor`.

- **`FrameSymbolVisitor`** — A `NodeVisitor` that records symbol usage. It handles `Name` nodes (the fundamental load/store/param operations) and special constructs like `If` branches, imports, and assignments.

- **`find_symbols` / `symbols_for_node`** — Convenience entry points that construct a `Symbols` object and run the appropriate visitor over a set of nodes or a single node.

---

## Data Flow

The following diagram shows how a template AST flows through the idtracking module and into the compiler.

```mermaid
sequenceDiagram
    participant CG as CodeGenerator (compiler)
    participant Frame as Frame
    participant Sym as Symbols
    participant RV as RootVisitor
    participant FSV as FrameSymbolVisitor

    CG->>Frame: create Frame (new scope)
    Frame->>Sym: Symbols(parent.symbols)
    CG->>Sym: analyze_node(node)
    Sym->>RV: RootVisitor(self)
    RV->>RV: visit(node) — handle scope boundaries
    RV->>FSV: visit(child) for in-scope nodes
    FSV->>Sym: store() / load() / declare_parameter()
    Sym-->>CG: refs, loads, stores populated
    CG->>CG: enter_frame() emits init code from loads
    CG->>Sym: ref(name) to emit Python identifier
```

### Step-by-step

1. The compiler creates a `Frame` for a new scope, which internally creates a `Symbols` object linked to the parent frame's symbols.
2. `Symbols.analyze_node(node)` instantiates a `RootVisitor` and visits the node.
3. `RootVisitor` decides whether to descend into child nodes directly (via `FrameSymbolVisitor`) or to treat the node as a scope boundary.
4. `FrameSymbolVisitor` records each `Name` usage as a load, store, or parameter declaration on the `Symbols` object.
5. The compiler reads `frame.symbols.loads` in `enter_frame` to emit variable initialization, and calls `frame.symbols.ref(name)` to obtain the generated Python identifier for each name.

---

## Component Interaction

### RootVisitor: Scope Boundary Handling

`RootVisitor` distinguishes between nodes that **propagate** symbol tracking into children and nodes that **introduce new scopes**.

```mermaid
graph LR
    RV[RootVisitor]
    RV -->|_simple_visit| Simple["Template, Block, Macro,<br/>FilterBlock, Scope, If,<br/>ScopedEvalContextModifier"]
    RV -->|custom| Custom["AssignBlock, CallBlock,<br/>OverlayScope, For, With"]
    RV -->|generic_visit| Error["NotImplementedError"]

    Simple -->|iter_child_nodes| FSV[FrameSymbolVisitor]
    Custom -->|selective traversal| FSV
```

- **`_simple_visit`** (aliased to `visit_Template`, `visit_Block`, `visit_Macro`, `visit_FilterBlock`, `visit_Scope`, `visit_If`, `visit_ScopedEvalContextModifier`): Iterates over all child nodes and forwards each to the `FrameSymbolVisitor`.

- **`visit_AssignBlock`**: Only visits the `body` children (the target is handled separately).

- **`visit_CallBlock`**: Visits all children *except* the `call` node.

- **`visit_OverlayScope`**: Only visits the `body` children.

- **`visit_For`**: Handles the three branches of a for-loop (`body`, `else`, `test`) separately. For `body` and `test`, the loop target is visited with `store_as_param=True`.

- **`visit_With`**: Visits the `targets` and then the `body`.

- **`generic_visit`**: Raises `NotImplementedError` — every node type that can appear at a scope root must be explicitly handled.

### FrameSymbolVisitor: Symbol Recording

`FrameSymbolVisitor` is where the actual symbol semantics live.

```mermaid
graph TD
    FSV[FrameSymbolVisitor]
    FSV --> Name["visit_Name<br/>load / store / param"]
    FSV --> NSRef["visit_NSRef<br/>load"]
    FSV --> If["visit_If<br/>branch merging"]
    FSV --> Macro["visit_Macro<br/>store"]
    FSV --> Import["visit_Import / visit_FromImport<br/>store"]
    FSV --> Assign["visit_Assign<br/>visit node then target"]
    FSV --> For["visit_For<br/>visit iter only"]
    FSV --> Stop["visit_Scope / visit_Block /<br/>visit_OverlayScope<br/>stop traversal"]
```

Key behaviors:

- **`visit_Name`** — The heart of the module. Based on `node.ctx`:
  - `"param"` or `store_as_param=True` → `declare_parameter(name)`
  - `"store"` → `store(name)`
  - `"load"` → `load(name)`

- **`visit_If`** — Creates a *copy* of the current symbols for each branch (`body`, `elif_`, `else_`), visits each branch independently, then calls `branch_update` to merge the results. This correctly handles variables that are only conditionally defined.

- **`visit_Assign`** — Visits the value (`node.node`) *before* the target, ensuring the correct load/store ordering.

- **`visit_For`** — Stops traversal at the loop body (the body is visited as part of the outer scope by `RootVisitor`); only the `iter` expression is visited here.

- **`visit_Scope`, `visit_Block`, `visit_OverlayScope`** — Deliberately stop traversal, as these introduce their own scopes handled elsewhere.

---

## Symbol Resolution Semantics

### Defining References

When a name is first encountered, `Symbols._define_ref` generates a unique identifier using the pattern:

```
l_{level}_{name}
```

For example, a variable `foo` at scope level 0 becomes `l_0_foo`. This namespacing prevents collisions between variables of the same name in different scopes.

### Store Semantics

When `store(name)` is called:

```mermaid
flowchart TD
    Start[store name] --> AddStore[Add to stores set]
    AddStore --> CheckRef{name in refs?}
    CheckRef -->|Yes| Done[Done]
    CheckRef -->|No| CheckParent{parent has ref?}
    CheckParent -->|Yes| Alias["_define_ref with<br/>VAR_LOAD_ALIAS"]
    CheckParent -->|No| Undef["_define_ref with<br/>VAR_LOAD_UNDEFINED"]
    Alias --> Done
    Undef --> Done
```

If the name already has a reference in an outer scope, it is aliased to that outer reference. Otherwise, it is marked as undefined (to be set to `missing`).

### Load Semantics

When `load(name)` is called and no reference exists, the name is defined with `VAR_LOAD_RESOLVE`, meaning it will be resolved at runtime from the template context.

### Branch Merging

`branch_update` merges the symbol tables of conditional branches. A variable is only considered "definitely stored" if it is stored in **all** branches. For variables stored in only some branches:

- If the variable exists in an outer scope, it becomes an **alias** to the outer reference.
- Otherwise, it becomes a **resolve** instruction (runtime lookup).

This ensures that conditionally-assigned variables behave correctly at runtime.

---

## Public API

### Functions

| Function | Signature | Description |
|----------|-----------|-------------|
| `find_symbols` | `(nodes, parent_symbols=None) -> Symbols` | Builds a `Symbols` object by running a `FrameSymbolVisitor` over an iterable of nodes. |
| `symbols_for_node` | `(node, parent_symbols=None) -> Symbols` | Builds a `Symbols` object for a single node via `analyze_node`. |

### `Symbols` Methods

| Method | Description |
|--------|-------------|
| `analyze_node(node, **kwargs)` | Runs a `RootVisitor` over the node to populate this symbol table. |
| `find_load(target)` | Looks up a load instruction by identifier, searching parent scopes. |
| `find_ref(name)` | Looks up a generated identifier by name, searching parent scopes. |
| `ref(name)` | Like `find_ref` but raises `AssertionError` if not found. |
| `copy()` | Returns a shallow copy with copied `refs`, `loads`, and `stores`. |
| `store(name)` | Records a store and defines a reference if needed. |
| `declare_parameter(name)` | Records a parameter store and defines a `VAR_LOAD_PARAMETER` reference. |
| `load(name)` | Records a load, defining a `VAR_LOAD_RESOLVE` reference if needed. |
| `branch_update(branch_symbols)` | Merges symbol tables from conditional branches. |
| `dump_stores()` | Returns a dict of all stored names (across scopes) mapped to their references. |
| `dump_param_targets()` | Returns the set of identifiers that are parameters. |

---

## Integration with the Compiler

The `idtracking` module is consumed primarily by the [compiler](compiler.md). The `Frame` class in the compiler holds a `Symbols` instance and uses it throughout code generation:

- **`Frame.__init__`** creates a `Symbols` object, either as a root (`Symbols(level=level)`) or as a child (`Symbols(parent.symbols, level=level)`).
- **`CodeGenerator.enter_frame`** iterates over `frame.symbols.loads` and emits initialization code based on the load instruction:
  - `VAR_LOAD_RESOLVE` → `target = resolve("name")`
  - `VAR_LOAD_ALIAS` → `target = outer_ref`
  - `VAR_LOAD_UNDEFINED` → collected and set to `missing`
- **`CodeGenerator.leave_frame`** resets all loaded variables to `missing`.
- **`CodeGenerator.visit_Name`** calls `frame.symbols.ref(node.name)` to obtain the Python identifier and `frame.symbols.find_load(ref)` to determine whether undefined-checking is needed.
- **`CodeGenerator.dump_local_context`** uses `frame.symbols.dump_stores()` to build the local context dict for derived contexts.
- **`CodeGenerator.push_parameter_definitions`** uses `frame.symbols.dump_param_targets()` to track macro parameters.

### Introspection via meta

The [meta](meta.md) module's `TrackingCodeGenerator` subclasses `CodeGenerator` and overrides `enter_frame` to collect undeclared identifiers. It inspects `frame.symbols.loads` for `VAR_LOAD_RESOLVE` instructions whose parameter is not in `environment.globals`, building the set of names that must be provided at render time.

```mermaid
graph LR
    IDT[idtracking.Symbols] -->|frame.symbols| CG[compiler.CodeGenerator]
    IDT -->|frame.symbols| TCG[meta.TrackingCodeGenerator]
    CG -->|enter_frame/leave_frame| Code[Generated Python]
    TCG -->|undeclared_identifiers| Meta[Template introspection]
```

---

## Process Flow: Analyzing a Template

The following diagram summarizes the complete flow of symbol analysis for a template containing a conditional assignment.

```mermaid
flowchart TD
    A[Template AST] --> B[Frame created with Symbols]
    B --> C[analyze_node → RootVisitor]
    C --> D{Node type?}
    D -->|Scope boundary| E[Handle branch/scope]
    D -->|In-scope node| F[FrameSymbolVisitor]
    E --> F
    F --> G{Name node?}
    G -->|ctx=load| H[symbols.load]
    G -->|ctx=store| I[symbols.store]
    G -->|ctx=param| J[symbols.declare_parameter]
    H --> K[Define ref if missing]
    I --> K
    J --> K
    K --> L{If node?}
    L -->|Yes| M[Copy symbols per branch]
    M --> N[Visit each branch]
    N --> O[branch_update merges]
    L -->|No| P[Continue traversal]
    O --> Q[Symbols complete]
    P --> Q
    Q --> R[Compiler emits code from loads/refs]
```

---

## Summary

The `idtracking` module is a focused, compile-time symbol resolution engine. Its two-visitor architecture cleanly separates the concerns of scope traversal (`RootVisitor`) and symbol recording (`FrameSymbolVisitor`), while the `Symbols` data structure encapsulates all the state and resolution logic. By producing precise load instructions and identifier mappings, it enables the [compiler](compiler.md) to generate correct Python code for variable access across Jinja2's complex scoping rules — including macros, loops, blocks, conditional branches, and overlay scopes.
