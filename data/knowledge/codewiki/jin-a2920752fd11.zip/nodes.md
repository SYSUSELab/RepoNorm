# Nodes Module

## Introduction

The `nodes` module (`src/jinja2/nodes.py`) defines the **Abstract Syntax Tree (AST)** used throughout Jinja2. It provides the complete set of node classes that the [parser](parser.md) produces, the [compiler](compiler.md) consumes, and the [optimizer](optimizer.md) and [idtracking](idtracking.md) transform. In addition, it exposes a rich set of tree-manipulation helpers (`iter_fields`, `find`, `find_all`, `set_ctx`, `set_lineno`, `set_environment`, `dump`) that normalize and traverse node trees.

Every template that Jinja2 processes is first tokenized by the [lexer](lexer.md), assembled into a tree of these nodes by the [parser](parser.md), optionally folded by the [optimizer](optimizer.md), analyzed by [idtracking](idtracking.md), and finally emitted as Python source by the [compiler](compiler.md). The `nodes` module is therefore the **central data model** that ties the entire compilation pipeline together.

---

## Architecture Overview

The module is organized around a single metaclass-driven base class (`Node`) and four major node categories, plus a set of helper nodes and extension-oriented nodes.

```mermaid
graph TD
    Node["Node (metaclass=NodeType)"]
    Node --> Stmt["Stmt (abstract)"]
    Node --> Expr["Expr (abstract)"]
    Node --> Helper["Helper (abstract)"]
    Node --> Template["Template"]

    Stmt --> Output
    Stmt --> Extends
    Stmt --> For
    Stmt --> If
    Stmt --> Macro
    Stmt --> CallBlock
    Stmt --> FilterBlock
    Stmt --> With
    Stmt --> Block
    Stmt --> Include
    Stmt --> Import
    Stmt --> FromImport
    Stmt --> ExprStmt
    Stmt --> Assign
    Stmt --> AssignBlock
    Stmt --> Continue
    Stmt --> Break
    Stmt --> Scope
    Stmt --> OverlayScope
    Stmt --> EvalContextModifier
    Stmt --> ScopedEvalContextModifier

    Expr --> BinExpr
    Expr --> UnaryExpr
    Expr --> Name
    Expr --> NSRef
    Expr --> Literal
    Expr --> CondExpr
    Expr --> _FilterTestCommon
    Expr --> Call
    Expr --> Getitem
    Expr --> Getattr
    Expr --> Slice
    Expr --> Concat
    Expr --> Compare
    Expr --> EnvironmentAttribute
    Expr --> ExtensionAttribute
    Expr --> ImportedName
    Expr --> InternalName
    Expr --> MarkSafe
    Expr --> MarkSafeIfAutoescape
    Expr --> ContextReference
    Expr --> DerivedContextReference

    BinExpr --> Mul
    BinExpr --> Div
    BinExpr --> FloorDiv
    BinExpr --> Add
    BinExpr --> Sub
    BinExpr --> Mod
    BinExpr --> Pow
    BinExpr --> And
    BinExpr --> Or

    UnaryExpr --> Not
    UnaryExpr --> Neg
    UnaryExpr --> Pos

    Literal --> Const
    Literal --> TemplateData
    Literal --> Tuple
    Literal --> List
    Literal --> Dict

    _FilterTestCommon --> Filter
    _FilterTestCommon --> Test

    Helper --> Pair
    Helper --> Keyword
    Helper --> Operand
```

### The Four Major Node Types

| Category | Base Class | Purpose |
|----------|-----------|---------|
| **Statements** | `Stmt` | Control flow and side-effecting constructs (`For`, `If`, `Block`, `Assign`, ...) |
| **Expressions** | `Expr` | Values that can be evaluated, folded to constants, or assigned to (`Name`, `Const`, `Call`, ...) |
| **Helpers** | `Helper` | Nodes that only exist in a specific context (`Pair`, `Keyword`, `Operand`) |
| **Template** | `Template` | The outermost wrapper node passed to the compiler |

---

## Core Concepts

### `NodeType` Metaclass

`NodeType` is a metaclass that handles **field and attribute inheritance**. When a subclass is defined, the metaclass automatically merges the `fields` and `attributes` tuples from the parent class with those declared on the child. This means subclasses only declare *new* fields, and the full layout is computed automatically.

Key guarantees enforced by the metaclass:
- **Single inheritance only** — multiple inheritance is disallowed (`assert len(bases) <= 1`).
- **No layout conflicts** — duplicate field/attribute names raise an assertion.
- **`abstract` defaults to `False`** for concrete subclasses.

At the bottom of the module, `NodeType.__new__` is replaced with a failing function so that **no custom node types can be created** outside the module. This keeps the AST closed and predictable for the compiler.

### `Node` Base Class

`Node` is the base class for every AST node. Its design separates **fields** (positional, structural children) from **attributes** (keyword, metadata):

- **Fields** are passed as positional constructor arguments and may be other nodes, lists of nodes, or arbitrary values.
- **Attributes** are passed as keyword arguments. Every node has at least `lineno` and `environment`. The `environment` attribute is set automatically at the end of parsing via `set_environment`.

```python
class Node(metaclass=NodeType):
    fields: t.Tuple[str, ...] = ()
    attributes: t.Tuple[str, ...] = ("lineno", "environment")
    abstract = True
```

The constructor validates that the correct number of positional fields is supplied and that no unknown attributes are passed, raising `TypeError` otherwise. Abstract nodes cannot be instantiated.

### `EvalContext`

`EvalContext` holds **evaluation-time information** used during constant folding (`as_const`). It carries:

- `environment` — the active `Environment`.
- `autoescape` — resolved from the environment (supporting callable autoescape).
- `volatile` — a flag set when a construct (e.g. an `EvalContextModifier`) makes the context unpredictable, disabling compile-time folding.

It supports `save()` / `revert()` for scoped modifications, which is how `ScopedEvalContextModifier` and the `{% autoescape %}` tag work.

The helper `get_eval_context(node, ctx)` returns the supplied context or constructs a default one from `node.environment`, raising `RuntimeError` if neither is available.

---

## Tree Traversal and Manipulation Helpers

`Node` provides a comprehensive set of helpers used by the parser, compiler, optimizer, and idtracking modules.

```mermaid
flowchart LR
    subgraph Traversal
        iter_fields["iter_fields()"]
        iter_child_nodes["iter_child_nodes()"]
        find["find()"]
        find_all["find_all()"]
    end
    subgraph Mutation
        set_ctx["set_ctx()"]
        set_lineno["set_lineno()"]
        set_environment["set_environment()"]
    end
    subgraph Output
        dump["dump()"]
        repr["__repr__()"]
        eq["__eq__()"]
    end
```

| Method | Description |
|--------|-------------|
| `iter_fields(exclude, only)` | Yields `(name, value)` tuples for the node's fields, optionally filtered. |
| `iter_child_nodes(exclude, only)` | Yields direct child `Node` instances (flattening lists). |
| `find(node_type)` | Returns the first descendant of the given type, or `None`. |
| `find_all(node_type)` | Yields all descendants matching a type or tuple of types. |
| `set_ctx(ctx)` | Recursively sets the `ctx` field (`load`/`store`/`param`) on all nodes that have one. Used by the parser to mark assignment targets. |
| `set_lineno(lineno, override)` | Recursively assigns line numbers where missing (or always if `override`). |
| `set_environment(environment)` | Recursively attaches the environment to every node. |
| `dump()` | Produces a reconstructable Python source representation of the tree (e.g. `nodes.Template(...)`). |
| `__eq__` | Structural equality based on `iter_fields()`. |

These helpers are the foundation for the visitor pattern implemented in the [visitor module](visitor.md).

---

## Expression Evaluation: `as_const`

The `Expr` base class defines the constant-folding contract:

```python
class Expr(Node):
    abstract = True

    def as_const(self, eval_ctx=None):
        raise Impossible()

    def can_assign(self) -> bool:
        return False
```

- `as_const()` attempts to evaluate the expression to a Python constant at compile time. If evaluation is not possible (e.g. it depends on runtime state, uses an intercepted sandbox operator, or references an undefined name), it raises `Impossible`.
- `can_assign()` reports whether the node is a valid assignment target.

The [optimizer](optimizer.md) relies on `as_const` for **constant folding**, and the [compiler](compiler.md) uses it to pre-render constant output. `Const.from_untrusted()` is the safe entry point that only produces a `Const` when the value has a safe `repr` (checked via `compiler.has_safe_repr`).

### `Impossible` Exception

`Impossible` is raised whenever a node cannot perform a requested action (typically constant folding). It is caught by the optimizer and compiler to fall back to runtime evaluation.

---

## Node Categories in Detail

### Statements (`Stmt`)

Statements represent control flow and side effects. Notable examples:

- **`Template`** — the root node; `body` is a list of nodes.
- **`Output`** — holds expressions to be printed (used for both `{{ ... }}` and template data).
- **`For`** — loop with `target`, `iter`, `body`, `else_`, optional `test` (filtered loops), and `recursive` flag.
- **`If`** — conditional with `test`, `body`, `elif_` (list of nested `If`), and `else_`.
- **`Macro`** / **`CallBlock`** — macro definitions and unnamed call blocks.
- **`Block`** — template inheritance blocks with `name`, `body`, `scoped`, and `required`.
- **`Extends`**, **`Include`**, **`Import`**, **`FromImport`** — template composition.
- **`Assign`** / **`AssignBlock`** — variable assignment (the block form captures rendered content).
- **`With`** — scoped variable bindings.
- **`Scope`** / **`OverlayScope`** — artificial scopes for extensions.
- **`EvalContextModifier`** / **`ScopedEvalContextModifier`** — modify the `EvalContext` (e.g. `{% autoescape %}`).
- **`Continue`** / **`Break`** — loop control.

### Expressions (`Expr`)

Expressions are values. Key groups:

- **Binary operators** (`BinExpr` subclasses): `Add`, `Sub`, `Mul`, `Div`, `FloorDiv`, `Mod`, `Pow`, `And`, `Or`. Each declares an `operator` string mapped to a Python function via `_binop_to_func`.
- **Unary operators** (`UnaryExpr` subclasses): `Not`, `Neg`, `Pos`, mapped via `_uaop_to_func`.
- **Literals** (`Literal` subclasses): `Const`, `TemplateData`, `Tuple`, `List`, `Dict`.
- **`Name`** — variable lookup/store with a `ctx` of `load`, `store`, or `param`.
- **`NSRef`** — namespace attribute assignment (`{% set ns.attr = ... %}`).
- **`Call`** — function/macro invocation with positional args, keyword args, and dynamic `*args`/`**kwargs`.
- **`Getattr`** / **`Getitem`** — attribute and subscript access.
- **`Slice`** — slice objects for subscripts.
- **`Concat`** — string concatenation (`~` operator).
- **`Compare`** / **`Operand`** — chained comparisons mapped via `_cmpop_to_func`.
- **`CondExpr`** — inline conditional (`a if b else c`).
- **`Filter`** / **`Test`** — filter and test application (share `_FilterTestCommon`).
- **`MarkSafe`** / **`MarkSafeIfAutoescape`** — wrap expressions as `Markup`.
- **`ContextReference`** / **`DerivedContextReference`** — access the current template context.

### Helpers (`Helper`)

Helpers exist only in specific contexts and are never rendered directly:

- **`Pair`** — key/value pair for `Dict` literals.
- **`Keyword`** — key/value pair for keyword arguments.
- **`Operand`** — operator/expression pair for `Compare`.

### Extension-Oriented Nodes

These nodes support the [extensions module](extensions.md):

- **`EnvironmentAttribute`** — loads an attribute from the environment.
- **`ExtensionAttribute`** — loads an attribute from a bound extension.
- **`ImportedName`** — represents an optimized import (e.g. `cgi.escape`).
- **`InternalName`** — compiler-internal identifiers created via `Parser.free_identifier()`. Its constructor deliberately raises `TypeError` to prevent manual creation.

---

## Data Flow Through the Compilation Pipeline

The `nodes` module sits at the heart of the pipeline. The following diagram shows how node trees flow between modules.

```mermaid
flowchart TD
    Source["Template Source"] --> Lexer["lexer.Lexer"]
    Lexer -->|TokenStream| Parser["parser.Parser"]
    Parser -->|"builds nodes.*"| AST["AST (nodes module)"]
    AST --> Optimizer["optimizer.Optimizer"]
    Optimizer -->|"constant folding via as_const"| AST2["Optimized AST"]
    AST2 --> IdTracking["idtracking.Symbols"]
    IdTracking -->|"analyze_node"| AST2
    AST2 --> Compiler["compiler.CodeGenerator"]
    Compiler -->|"visit_* methods"| Python["Generated Python Source"]
    AST2 --> Meta["meta.TrackingCodeGenerator"]
    Meta -->|"undeclared_identifiers"| Introspection["Template Introspection"]
```

### Interaction with the Visitor Pattern

The [visitor module](visitor.md) provides `NodeVisitor` and `NodeTransformer`, which dispatch to `visit_<ClassName>` methods based on the node's type name. This is the mechanism by which:

- The **compiler** (`CodeGenerator`) emits Python code for each node type.
- The **optimizer** (`Optimizer`) rewrites the tree, folding constants.
- The **idtracking** module (`RootVisitor`, `FrameSymbolVisitor`) analyzes variable loads/stores.
- The **meta** module (`TrackingCodeGenerator`) collects undeclared identifiers.

```mermaid
sequenceDiagram
    participant Parser
    participant Node as nodes.Node
    participant Visitor as NodeVisitor
    participant Compiler as CodeGenerator

    Parser->>Node: construct node tree
    Node->>Node: set_environment()
    Compiler->>Visitor: visit(node)
    Visitor->>Compiler: dispatch visit_<Type>()
    Compiler->>Node: iter_child_nodes()
    Compiler->>Node: as_const() (for folding)
```

---

## Component Relationships

```mermaid
graph LR
    subgraph "nodes module"
        Node
        NodeType
        EvalContext
        Impossible
    end

    Lexer["lexer module"] -->|"tokens"| Parser["parser module"]
    Parser -->|"creates"| Node
    Node -->|"consumed by"| Compiler["compiler module"]
    Node -->|"transformed by"| Optimizer["optimizer module"]
    Node -->|"analyzed by"| IdTracking["idtracking module"]
    Node -->|"introspected by"| Meta["meta module"]
    Node -->|"traversed by"| Visitor["visitor module"]
    Node -->|"extended by"| Extensions["extensions module"]
    Node -->|"uses"| Utils["utils module (_PassArg)"]
    Node -->|"uses"| MarkupSafe["markupsafe.Markup"]
```

### Key Dependencies

| Dependency | Usage |
|-----------|-------|
| `utils._PassArg` | Determines how filters/tests/finalize functions receive context (`context`, `eval_context`, `environment`). |
| `markupsafe.Markup` | Used by `TemplateData`, `MarkSafe`, and `MarkSafeIfAutoescape` for safe-string handling. |
| `compiler.has_safe_repr` | Imported lazily inside `Const.from_untrusted` to validate constant values. |
| `environment.Environment` | Type-only import; the environment is attached to nodes at parse time. |

---

## The `_FilterTestCommon` Base

`Filter` and `Test` share a common base, `_FilterTestCommon`, which implements the `as_const` logic for both. This logic:

1. Rejects folding when the eval context is `volatile`.
2. Looks up the filter/test function in `environment.filters` or `environment.tests`.
3. Refuses to fold if the function is missing or requires `@pass_context`.
4. Refuses to fold async filters/tests when the environment is async.
5. Evaluates arguments via `args_as_const` and invokes the function, wrapping any error in `Impossible`.

The `_is_filter` class attribute distinguishes the two subclasses.

---

## Summary

The `nodes` module is the **AST backbone of Jinja2**. Its design emphasizes:

- **Closed, validated node types** via the `NodeType` metaclass and the disabled `__new__`.
- **Clean separation** of fields (structure) and attributes (metadata).
- **Compile-time evaluation** through the `as_const` / `Impossible` contract, enabling optimization.
- **Rich traversal helpers** that power the visitor pattern used across the compiler, optimizer, and analysis modules.

For details on how nodes are produced, see the [parser](parser.md) and [lexer](lexer.md) documentation. For how they are consumed, see the [compiler](compiler.md), [optimizer](optimizer.md), [idtracking](idtracking.md), and [meta](meta.md) documentation. For the traversal mechanism, see the [visitor](visitor.md) documentation.
