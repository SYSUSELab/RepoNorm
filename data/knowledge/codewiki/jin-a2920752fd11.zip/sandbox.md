# Sandbox Module

## Introduction

The `sandbox` module (`src/jinja2/sandbox.py`) provides a security layer for Jinja2 that ensures unsafe operations cannot be performed during template rendering. It is designed for scenarios where **the template itself comes from an untrusted source** — for example, user-supplied templates in a multi-tenant application, a CMS, or any system where template authors are not fully trusted.

The sandbox works by subclassing the standard [`Environment`](environment.md) and instructing the compiler to generate *sandboxed* code. At runtime, the sandboxed environment intercepts attribute access, item access, function calls, and string formatting, rejecting anything that could be used to escape the template's intended scope (e.g. reaching `__class__`, `__globals__`, or mutating shared mutable objects).

> **Note:** The sandbox is a *defense-in-depth* mechanism, not a complete security boundary. It raises [`SecurityError`](exceptions.md) for known-unsafe operations, but callers must still catch all exceptions during rendering and should not rely on the sandbox alone to isolate arbitrary Python execution.

---

## Core Components

| Component | Kind | Purpose |
|-----------|------|---------|
| `SandboxedEnvironment` | Class | Base sandboxed environment; overrides attribute/item access, callables, and operators. |
| `ImmutableSandboxedEnvironment` | Class | Extends `SandboxedEnvironment` to also block mutation of builtin mutable objects. |
| `SandboxedFormatter` | Class | `string.Formatter` subclass that routes field access through the sandbox. |
| `SandboxedEscapeFormatter` | Class | Combines `SandboxedFormatter` with `markupsafe.EscapeFormatter` for autoescaped strings. |

### Supporting Functions and Constants

| Name | Purpose |
|------|---------|
| `safe_range(*args)` | A `range` replacement that refuses to build ranges longer than `MAX_RANGE`. |
| `unsafe(f)` | Decorator marking a function/method as unsafe to call. |
| `is_internal_attribute(obj, attr)` | Detects internal Python attributes (e.g. `mro`, `gi_frame`, `cr_code`). |
| `modifies_known_mutable(obj, attr)` | Detects attributes that mutate builtin mutable objects. |
| `inspect_format_method(callable)` | Detects `str.format` / `str.format_map` bound methods. |
| `MAX_RANGE` | Maximum number of items a sandboxed `range` may produce (`100000`). |
| `UNSAFE_FUNCTION_ATTRIBUTES`, `UNSAFE_METHOD_ATTRIBUTES`, `UNSAFE_GENERATOR_ATTRIBUTES`, `UNSAFE_COROUTINE_ATTRIBUTES`, `UNSAFE_ASYNC_GENERATOR_ATTRIBUTES` | Sets of attribute names considered unsafe per object type. |
| `_mutable_spec` | Mapping of mutable ABCs / `deque` to their mutating method names. |

---

## Architecture

The sandbox is a thin, security-focused subclass layer on top of the standard environment. It does not reimplement parsing, compilation, or rendering — it only overrides the *runtime hooks* that the compiler calls when generating sandboxed code.

```mermaid
graph TD
    Environment["Environment<br/>(environment.md)"]
    SandboxedEnvironment["SandboxedEnvironment"]
    ImmutableSandboxedEnvironment["ImmutableSandboxedEnvironment"]
    Formatter["string.Formatter"]
    EscapeFormatter["markupsafe.EscapeFormatter"]
    SandboxedFormatter["SandboxedFormatter"]
    SandboxedEscapeFormatter["SandboxedEscapeFormatter"]

    Environment --> SandboxedEnvironment
    SandboxedEnvironment --> ImmutableSandboxedEnvironment
    Formatter --> SandboxedFormatter
    EscapeFormatter --> SandboxedEscapeFormatter
    SandboxedFormatter --> SandboxedEscapeFormatter

    SandboxedEnvironment -.uses.-> SandboxedFormatter
    SandboxedEnvironment -.uses.-> SandboxedEscapeFormatter
```

### Class Hierarchy

```mermaid
classDiagram
    class Environment {
        +sandboxed: bool
        +getattr(obj, attribute)
        +getitem(obj, argument)
        +call(...)
    }
    class SandboxedEnvironment {
        +sandboxed = True
        +default_binop_table
        +default_unop_table
        +intercepted_binops
        +intercepted_unops
        +is_safe_attribute(obj, attr, value)
        +is_safe_callable(obj)
        +call_binop(context, operator, left, right)
        +call_unop(context, operator, arg)
        +getitem(obj, argument)
        +getattr(obj, attribute)
        +unsafe_undefined(obj, attribute)
        +format_string(s, args, kwargs, format_func)
        +call(context, obj, *args, **kwargs)
    }
    class ImmutableSandboxedEnvironment {
        +is_safe_attribute(obj, attr, value)
    }
    Environment <|-- SandboxedEnvironment
    SandboxedEnvironment <|-- ImmutableSandboxedEnvironment
```

---

## How the Sandbox Works

The sandbox relies on the `Environment.sandboxed` flag. When set to `True`, the [compiler](compiler.md) generates code that routes attribute access, item access, and calls through the environment's methods instead of using native Python operators. This is why simply setting `sandboxed = True` on a plain `Environment` is *not* sufficient — the actual safety checks live in the overridden methods of `SandboxedEnvironment`.

```mermaid
sequenceDiagram
    participant T as Template Code
    participant C as Compiled Code
    participant SE as SandboxedEnvironment
    participant O as Target Object

    T->>C: {{ obj.attr }}
    C->>SE: getattr(obj, "attr")
    SE->>O: getattr(obj, "attr")
    O-->>SE: value
    SE->>SE: is_safe_attribute(obj, "attr", value)
    alt safe
        SE-->>C: value
    else unsafe
        SE-->>C: unsafe_undefined(...) -> SecurityError on use
    end
```

### Attribute and Item Access

- **`getattr(obj, attribute)`** — Prefers the attribute. If the attribute is unsafe (per `is_safe_attribute`), returns an `unsafe_undefined` object that raises [`SecurityError`](exceptions.md) when used.
- **`getitem(obj, argument)`** — Prefers the item (`obj[argument]`). Falls back to attribute access for string keys, applying the same safety check.

### Safety Checks

- **`is_safe_attribute(obj, attr, value)`** — Returns `False` for any attribute starting with `_` or any attribute flagged by `is_internal_attribute`. This blocks access to dunder attributes such as `__class__`, `__globals__`, `__subclasses__`, etc.
- **`is_safe_callable(obj)`** — Returns `False` for callables decorated with `@unsafe` (via the `unsafe_callable` attribute) or following the Django convention of `alters_data = True`.

### Callable Interception

The `call` method intercepts every call made from template code:

1. If the target is a bound `str.format` / `str.format_map` method, the call is routed through `format_string` so the sandboxed formatter is used.
2. Otherwise, `is_safe_callable` is checked; unsafe callables raise `SecurityError`.
3. Safe callables are delegated to [`Context.call`](runtime.md), which handles `pass_context` / `pass_environment` injection.

### String Formatting

`format_string` selects a formatter based on the input type:

- `Markup` input → `SandboxedEscapeFormatter` (preserves autoescaping).
- Plain `str` input → `SandboxedFormatter`.

Both formatters override `get_field` to route attribute and item lookups through `SandboxedEnvironment.getattr` / `getitem`, so `"{0.__class__}".format(obj)` is blocked just like `{{ obj.__class__ }}`.

### Operator Interception

`SandboxedEnvironment` supports optional interception of binary and unary operators:

- `intercepted_binops` / `intercepted_unops` — frozensets of operators to intercept (empty by default).
- `binop_table` / `unop_table` — per-instance copies of the default operator callback tables.
- `call_binop` / `call_unop` — invoked instead of the native operator when an operator is intercepted.

Interception is opt-in because intercepted calls are slower than native operators.

---

## ImmutableSandboxedEnvironment

`ImmutableSandboxedEnvironment` extends `SandboxedEnvironment` to additionally prevent mutation of builtin mutable objects. It overrides `is_safe_attribute` to reject any attribute that `modifies_known_mutable` reports as mutating.

```mermaid
graph LR
    A["is_safe_attribute(obj, attr, value)"] --> B{"super().is_safe_attribute?"}
    B -- No --> R["False (unsafe)"]
    B -- Yes --> C{"modifies_known_mutable(obj, attr)?"}
    C -- Yes --> R
    C -- No --> S["True (safe)"]
```

The following mutating methods are blocked (see `_mutable_spec`):

| Type | Blocked Methods |
|------|-----------------|
| `MutableSet` | `add`, `clear`, `difference_update`, `discard`, `pop`, `remove`, `symmetric_difference_update`, `update` |
| `MutableMapping` | `clear`, `pop`, `popitem`, `setdefault`, `update` |
| `MutableSequence` | `append`, `reverse`, `insert`, `sort`, `extend`, `remove` |
| `deque` | `append`, `appendleft`, `clear`, `extend`, `extendleft`, `pop`, `popleft`, `remove`, `rotate` |

---

## Data Flow

The following diagram shows how a template expression flows through the sandbox at runtime.

```mermaid
flowchart TD
    Start["Template expression"] --> Kind{"Expression kind?"}
    Kind -- "attribute/item" --> GA["getattr / getitem"]
    Kind -- "call" --> Call["call"]
    Kind -- "format" --> Fmt["format_string"]

    GA --> SafeAttr{"is_safe_attribute?"}
    SafeAttr -- Yes --> Value["Return value"]
    SafeAttr -- No --> UU["unsafe_undefined -> SecurityError"]

    Call --> FmtCheck{"str.format method?"}
    FmtCheck -- Yes --> Fmt
    FmtCheck -- No --> SafeCall{"is_safe_callable?"}
    SafeCall -- No --> SecErr["raise SecurityError"]
    SafeCall -- Yes --> CtxCall["Context.call"]

    Fmt --> Formatter["SandboxedFormatter / SandboxedEscapeFormatter"]
    Formatter --> GA
```

---

## Dependencies

The sandbox module depends on several other Jinja2 modules and external libraries.

```mermaid
graph TD
    Sandbox["sandbox.py"]
    Environment["environment.py<br/>(environment.md)"]
    Exceptions["exceptions.py<br/>(exceptions.md)"]
    Runtime["runtime.py<br/>(runtime.md)"]
    MarkupSafe["markupsafe<br/>(EscapeFormatter, Markup)"]
    StdLib["stdlib<br/>(operator, types, string, collections)"]

    Sandbox --> Environment
    Sandbox --> Exceptions
    Sandbox --> Runtime
    Sandbox --> MarkupSafe
    Sandbox --> StdLib
```

| Dependency | Used For |
|------------|----------|
| [`Environment`](environment.md) | Base class; provides `globals`, `undefined`, and the `sandboxed` flag. |
| [`SecurityError`](exceptions.md) | Raised for unsafe attribute access and unsafe callables. |
| [`Context`](runtime.md) | Passed to `call_binop` / `call_unop`; used by `call` to invoke callables. |
| [`Undefined`](runtime.md) | Returned by `unsafe_undefined` and `getattr` / `getitem` fallbacks. |
| `markupsafe.EscapeFormatter`, `markupsafe.Markup` | Autoescape-aware string formatting. |
| `operator`, `types`, `string.Formatter`, `collections.abc`, `collections.deque` | Operator tables, type inspection, and mutable-object specs. |

---

## Usage

### Basic Sandboxed Environment

```python
from jinja2.sandbox import SandboxedEnvironment

env = SandboxedEnvironment()
template = env.from_string("{{ obj.attr }}")
```

### Immutable Sandboxed Environment

```python
from jinja2.sandbox import ImmutableSandboxedEnvironment

env = ImmutableSandboxedEnvironment()
# Attempting to call list.append, dict.update, etc. from a template
# will result in a SecurityError.
```

### Marking a Callable as Unsafe

```python
from jinja2.sandbox import unsafe

@unsafe
def delete_everything():
    ...
```

### Customizing Safety Policies

Subclass `SandboxedEnvironment` and override `is_safe_attribute` or `is_safe_callable` to implement application-specific policies:

```python
from jinja2.sandbox import SandboxedEnvironment

class MySandbox(SandboxedEnvironment):
    def is_safe_attribute(self, obj, attr, value):
        if attr == "dangerous_method":
            return False
        return super().is_safe_attribute(obj, attr, value)
```

---

## Related Modules

- [environment.md](environment.md) — The base `Environment` class and template loading/compilation.
- [runtime.md](runtime.md) — `Context`, `Undefined`, and runtime helpers used by the sandbox.
- [exceptions.md](exceptions.md) — `SecurityError` and the broader exception hierarchy.
- [compiler.md](compiler.md) — Generates the sandboxed code that calls into these hooks.
- [nativetypes.md](nativetypes.md) — Native Python type rendering, which can be combined with sandboxing.
