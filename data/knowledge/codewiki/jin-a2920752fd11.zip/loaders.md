# Loaders Module

## Introduction

The `loaders` module (`src/jinja2/loaders.py`) provides the API and concrete implementations for **loading templates from different data sources**. A loader is the bridge between an [`Environment`](environment.md) and the raw template source: given a template name, a loader locates the source, returns it (along with an optional filename and an "up-to-date" callback), and lets the environment compile and cache it.

The module defines an abstract base class (`BaseLoader`) and a family of ready-to-use loaders covering the most common storage backends: the file system, Python packages, in-memory dictionaries, arbitrary callables, precompiled modules, and composition strategies (`PrefixLoader`, `ChoiceLoader`).

---

## Architecture Overview

The loaders module sits between the [`Environment`](environment.md) (which orchestrates template retrieval) and the underlying data sources. The environment never reads template source directly; it delegates to a loader.

```mermaid
graph TD
    Env["Environment<br/>(environment.md)"]
    Env -->|"get_template / _load_template"| Loader["BaseLoader.load()"]
    Loader -->|"get_source()"| Source["(source, filename, uptodate)"]
    Loader -->|"compile + cache"| BCC["BytecodeCache<br/>(bytecode_cache.md)"]
    Loader -->|"from_code"| Template["Template"]

    subgraph "Concrete Loaders"
        FSL["FileSystemLoader"]
        PKL["PackageLoader"]
        DL["DictLoader"]
        FL["FunctionLoader"]
        ML["ModuleLoader"]
        PL["PrefixLoader"]
        CL["ChoiceLoader"]
    end

    FSL -.->|extends| Loader
    PKL -.->|extends| Loader
    DL -.->|extends| Loader
    FL -.->|extends| Loader
    ML -.->|extends| Loader
    PL -.->|extends| Loader
    CL -.->|extends| Loader
```

### Class Hierarchy

```mermaid
classDiagram
    class BaseLoader {
        +bool has_source_access
        +get_source(environment, template)
        +list_templates()
        +load(environment, name, globals)
    }
    class FileSystemLoader
    class PackageLoader
    class DictLoader
    class FunctionLoader
    class ModuleLoader {
        +has_source_access = False
        +get_template_key(name)
        +get_module_filename(name)
    }
    class PrefixLoader
    class ChoiceLoader
    class _TemplateModule

    BaseLoader <|-- FileSystemLoader
    BaseLoader <|-- PackageLoader
    BaseLoader <|-- DictLoader
    BaseLoader <|-- FunctionLoader
    BaseLoader <|-- ModuleLoader
    BaseLoader <|-- PrefixLoader
    BaseLoader <|-- ChoiceLoader
    ModuleType <|-- _TemplateModule
```

---

## Core Components

### `BaseLoader`

The abstract base class for all loaders. Subclasses override `get_source` to implement a custom loading mechanism. The environment calls `load` (which subclasses should **not** override) to obtain a `Template`.

| Member | Description |
| --- | --- |
| `has_source_access` | Class attribute (default `True`). When `False`, the loader cannot expose template source. |
| `get_source(environment, template)` | Returns `(source, filename, uptodate)` or raises `TemplateNotFound`. The `uptodate` callable is used for auto-reload checks. |
| `list_templates()` | Returns all template names; raises `TypeError` by default if unsupported. |
| `load(environment, name, globals)` | Orchestrates source retrieval, bytecode-cache lookup, compilation, and template construction. Decorated with `@internalcode`. |

The `load` method implements the central loading pipeline:

```mermaid
flowchart TD
    Start["load(environment, name, globals)"] --> GetSource["get_source()"]
    GetSource --> HasBCC{"bytecode_cache<br/>configured?"}
    HasBCC -->|Yes| GetBucket["bcc.get_bucket()"]
    GetBucket --> HasCode{"bucket.code<br/>present?"}
    HasBCC -->|No| Compile
    HasCode -->|Yes| UseCode["use cached code"]
    HasCode -->|No| Compile["environment.compile()"]
    Compile --> StoreBucket{"bcc set and<br/>bucket empty?"}
    StoreBucket -->|Yes| SetBucket["bucket.code = code<br/>bcc.set_bucket()"]
    StoreBucket -->|No| Build
    UseCode --> Build["template_class.from_code()"]
    SetBucket --> Build
    Build --> End["Template"]
```

> **Note:** Loaders that compose other loaders (`PrefixLoader`, `ChoiceLoader`) override `load` to delegate to the wrapped loaders rather than calling `get_source` directly.

### `FileSystemLoader`

Loads templates from one or more directories on the file system. Directories are searched in order, stopping at the first match.

- **Parameters:** `searchpath` (a path or sequence of paths), `encoding` (default `"utf-8"`), `followlinks` (default `False`).
- **`get_source`:** Splits the template path via `split_template_path`, joins it with each search path, and reads the file. Returns an `uptodate` closure comparing the file's `mtime`.
- **`list_templates`:** Walks each search path and returns a sorted, de-duplicated list of relative template names.

### `PackageLoader`

Loads templates from a directory inside an importable Python package.

- **Parameters:** `package_name`, `package_path` (default `"templates"`), `encoding` (default `"utf-8"`).
- **Behavior:** Uses `importlib.util.find_spec` to locate the package. Supports regular packages, single-module packages, limited [PEP 420](https://peps.python.org/pep-0420/) namespace packages, and zip/egg imports (`zipimport.zipimporter`).
- **`get_source`:** Reads from the filesystem for directory packages (with an `mtime`-based `uptodate`), or via `loader.get_data` for zip packages (always reported as current, `uptodate = None`).
- **`list_templates`:** Walks the template root for directory packages; for zip packages, requires the loader to expose `_files` metadata.

### `DictLoader`

Loads templates from an in-memory mapping of template name to source string. Primarily useful for unit testing.

- **`get_source`:** Returns the mapped source with `filename = None` and an `uptodate` closure comparing against the current mapping value.
- **`list_templates`:** Returns the sorted mapping keys.

### `FunctionLoader`

Wraps a user-supplied callable that performs the loading.

- **`load_func`:** Receives the template name and returns either a source string, a `(source, filename, uptodatefunc)` tuple, or `None` (which raises `TemplateNotFound`).

### `ModuleLoader`

Loads templates from **precompiled** template modules (produced by `Environment.compile_templates`).

- **`has_source_access = False`** — precompiled templates cannot expose their source.
- **Construction:** Creates a synthetic `_TemplateModule` package whose `__path__` points at the given directory, and registers it in `sys.modules` via a `weakref.proxy` so it is garbage-collected when the loader is released.
- **`get_template_key(name)` / `get_module_filename(name)`:** Static helpers deriving a `tmpl_<sha1>` key and the corresponding `.py` filename.
- **`load`:** Imports the compiled module and builds a template via `template_class.from_module_dict`.

### `PrefixLoader`

Dispatches to a mapping of loaders, each bound to a prefix. The prefix is separated from the template name by a `delimiter` (default `"/"`).

- **`get_loader(template)`:** Splits the name into `(prefix, name)` and looks up the loader; raises `TemplateNotFound` on failure.
- **`get_source` / `load`:** Delegate to the resolved loader, re-raising `TemplateNotFound` with the **prefixed** name for accurate error reporting.
- **`list_templates`:** Prefixes each child loader's templates with `prefix + delimiter`.

### `ChoiceLoader`

Tries a sequence of loaders in order, returning the first successful result. Useful for letting user templates override built-in ones.

- **`get_source` / `load`:** Iterate over `self.loaders`, catching `TemplateNotFound` and continuing.
- **`list_templates`:** Returns the sorted union of all child loaders' templates.

### `_TemplateModule`

A private `ModuleType` subclass that adds support for weak references, used internally by `ModuleLoader`.

---

## Composition and Delegation

`PrefixLoader` and `ChoiceLoader` are *composite* loaders. They do not read source themselves; instead they route requests to child loaders. This enables layered template resolution strategies.

```mermaid
graph LR
    subgraph ChoiceLoader
        CL["ChoiceLoader"] --> L1["FileSystemLoader<br/>(user templates)"]
        CL --> L2["FileSystemLoader<br/>(system templates)"]
    end

    subgraph PrefixLoader
        PL["PrefixLoader"] -->|"app1/"| P1["PackageLoader<br/>(mypackage.app1)"]
        PL -->|"app2/"| P2["PackageLoader<br/>(mypackage.app2)"]
    end
```

### Template Resolution Flow

```mermaid
sequenceDiagram
    participant Env as Environment
    participant CL as ChoiceLoader
    participant FSL as FileSystemLoader
    participant DL as DictLoader

    Env->>CL: load(env, "index.html")
    CL->>FSL: load(env, "index.html")
    FSL-->>CL: TemplateNotFound
    CL->>DL: load(env, "index.html")
    DL-->>CL: Template
    CL-->>Env: Template
```

---

## Dependencies

The loaders module depends on several other Jinja modules:

| Dependency | Purpose |
| --- | --- |
| [`environment`](environment.md) | Provides `Environment` (compile, bytecode cache, template class) and `Template`. |
| [`bytecode_cache`](bytecode_cache.md) | `BytecodeCache` / `Bucket` used by `BaseLoader.load` to cache compiled code. |
| [`exceptions`](exceptions.md) | `TemplateNotFound` raised when a template cannot be located. |
| [`utils`](utils.md) | `internalcode` decorator and `open_if_exists` helper. |

```mermaid
graph TD
    Loaders["loaders.py"]
    Loaders --> Environment["environment.py"]
    Loaders --> BCCache["bccache.py"]
    Loaders --> Exceptions["exceptions.py"]
    Loaders --> Utils["utils.py"]
    Environment -.->|"uses loader"| Loaders
```

---

## Path Sanitization

The module-level helper `split_template_path(template)` splits a template name into path segments and performs a **security sanity check**: any segment containing an OS path separator, an alternate separator, or `..` raises `TemplateNotFound`. This prevents directory-traversal attacks when loaders resolve names against a root directory.

```mermaid
flowchart LR
    Name["template name"] --> Split["split('/')"]
    Split --> Check{"segment contains<br/>sep / altsep / '..'?"}
    Check -->|Yes| Raise["raise TemplateNotFound"]
    Check -->|No| Append["append non-empty, non-'.' segments"]
```

---

## Summary

The loaders module provides a clean, extensible abstraction for template retrieval:

- **`BaseLoader`** defines the contract (`get_source`, `list_templates`, `load`) and the loading pipeline.
- **Concrete loaders** cover filesystem, package, dict, callable, and precompiled-module sources.
- **Composite loaders** (`PrefixLoader`, `ChoiceLoader`) enable layered resolution without duplicating loading logic.
- The module integrates tightly with the [`Environment`](environment.md) for compilation and caching, with the [`BytecodeCache`](bytecode_cache.md) for performance, and with [`exceptions`](exceptions.md) for consistent error reporting.
