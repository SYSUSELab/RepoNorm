# Template Environment and Loading

## Purpose

The `template_environment_and_loading` module is the entry point and orchestration layer of Jinja2. It is responsible for:

- **Environment configuration**: Defining the central `Environment` object that holds all shared configuration (delimiters, filters, tests, globals, policies) and serves as the factory for compiled templates.
- **Template loading**: Providing a pluggable loader abstraction (`BaseLoader` and its subclasses) that resolves template names to source strings from filesystems, packages, dictionaries, or custom sources.
- **Template compilation & caching**: Turning loaded source into executable templates, with optional bytecode caching to avoid recompilation.
- **Native Python rendering**: Offering `NativeEnvironment`/`NativeTemplate`, which render templates directly to Python objects instead of strings.
- **Sandboxed execution**: Providing `SandboxedEnvironment`, which restricts attribute/item access and callable invocation to prevent untrusted templates from escaping their sandbox.

Together these components form the public API surface that users interact with most directly (`Environment`, `FileSystemLoader`, `DictLoader`, `SandboxedEnvironment`, `NativeEnvironment`, etc.).

## Architecture

The module is composed of five cooperating submodules. The `Environment` sits at the center, consuming loaders for source retrieval, delegating to the compiler for code generation, and using the bytecode cache for persistence. `SandboxedEnvironment` and `NativeEnvironment` are specialized subclasses that override code-generation and execution behavior.

```mermaid
graph TD
    subgraph "template_environment_and_loading"
        ENV["environment.py<br/>Environment, Template"]
        LOAD["loaders.py<br/>BaseLoader, FileSystemLoader,<br/>DictLoader, PackageLoader, ..."]
        BCC["bccache.py<br/>BytecodeCache, FileSystemBytecodeCache"]
        SBX["sandbox.py<br/>SandboxedEnvironment,<br/>SandboxedFormatter"]
        NAT["nativetypes.py<br/>NativeEnvironment,<br/>NativeTemplate, NativeCodeGenerator"]
    end

    ENV -->|"uses loader to<br/>get_source()"| LOAD
    ENV -->|"reads/writes<br/>compiled bytecode"| BCC
    ENV -->|"compiles via<br/>CodeGenerator"| COMPILER["compilation_and_analysis<br/>(compiler.py)"]
    ENV -->|"parses via"| PARSER["lexing_and_parsing<br/>(lexer.py, parser.py)"]
    ENV -->|"executes with"| RUNTIME["runtime_support_and_foundation<br/>(runtime.py)"]

    SBX -->|"extends"| ENV
    SBX -->|"overrides code generation<br/>for safe access"| COMPILER
    NAT -->|"extends"| ENV
    NAT -->|"overrides code generation<br/>for native output"| COMPILER

    LOAD -->|"raises"| EXC["runtime_support_and_foundation<br/>(exceptions.py)"]
    BCC -->|"uses"| UTILS["runtime_support_and_foundation<br/>(utils.py)"]
```

### Data flow during template rendering

```mermaid
sequenceDiagram
    participant User
    participant Env as Environment
    participant Loader as BaseLoader
    participant Cache as BytecodeCache
    participant Compiler as CodeGenerator
    participant Template as Template

    User->>Env: get_template(name)
    Env->>Loader: get_source(environment, name)
    Loader-->>Env: source, filename, uptodate
    Env->>Cache: get_bucket(environment, name, filename, source)
    alt cache hit
        Cache-->>Env: cached bytecode
    else cache miss
        Env->>Compiler: compile(source, ...)
        Compiler-->>Env: code object
        Env->>Cache: set_bucket(...)
    end
    Env->>Template: from_code(environment, code, globals, ...)
    Template-->>User: Template instance
    User->>Template: render(context)
    Template-->>User: rendered output
```

## Core Components

The following submodules make up this module. Each is documented in detail in its own file:

- **[environment.py](./environment.md)** — Defines `Environment` (the central configuration and template factory) and `Template` (the compiled, renderable template object). Covers configuration options, `get_template`/`from_string`, globals, filters, tests, policies, and the `Template` rendering lifecycle.
- **[loaders.py](./loaders.md)** — Defines the loader abstraction (`BaseLoader`) and concrete loaders: `FileSystemLoader`, `PackageLoader`, `DictLoader`, `FunctionLoader`, `PrefixLoader`, `ChoiceLoader`, `ModuleLoader`. Covers `get_source`, `list_templates`, and `load` semantics.
- **[bccache.py](./bytecode_cache.md)** — Defines `BytecodeCache` and `FileSystemBytecodeCache` for persisting compiled template bytecode to disk, including bucket management and cache invalidation.
- **[sandbox.py](./sandbox.md)** — Defines `SandboxedEnvironment` and `SandboxedFormatter`, which intercept attribute/item access and callable invocation to enforce a security policy for untrusted templates.
- **[nativetypes.py](./nativetypes.md)** — Defines `NativeEnvironment`, `NativeTemplate`, and `NativeCodeGenerator`, which render templates to native Python objects (lists, dicts, ints, etc.) rather than concatenated strings.

## Related Modules

This module depends on and is complemented by the following sibling modules:

- **lexing_and_parsing** (`lexer.py`, `parser.py`, `nodes.py`, `visitor.py`) — Produces the AST consumed by the compiler.
- **compilation_and_analysis** (`compiler.py`, `optimizer.py`, `idtracking.py`, `meta.py`) — Generates executable Python code from the AST; `sandbox.py` and `nativetypes.py` subclass its `CodeGenerator`.
- **runtime_support_and_foundation** (`runtime.py`, `exceptions.py`, `utils.py`) — Provides the runtime context, exception hierarchy, and shared utilities used throughout.
- **extensions_and_filters** (`ext.py`, `filters.py`) — Extensions and built-in filters/tests registered on the `Environment`.