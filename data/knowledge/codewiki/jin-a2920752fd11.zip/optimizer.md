# Optimizer Module

## Introduction

The `optimizer` module (`src/jinja2/optimizer.py`) is a compile-time AST
transformation pass in Jinja's template compilation pipeline. Its primary
purpose is **constant folding**: it walks the abstract syntax tree (AST)
produced by the parser and replaces any expression that can be evaluated to a
constant value at compile time with a single `Const` node. This reduces the
amount of work the generated Python code must perform at render time.

The module is intentionally small and focused. It exposes a single public
function, `optimize`, and a single class, `Optimizer`, which is a specialized
`NodeTransformer`. Because the AST does not carry complete scoping information
(that is resolved later by the compiler), the optimizer deliberately limits
itself to optimizations that are safe without scope knowledge — for example,
loop unrolling is *not* performed because unrolled loops would change scoping
semantics.

> **Note:** The optimizer is part of the broader
> [compilation and analysis](compiler.md) stage. It runs *before* the
> [CodeGenerator](compiler.md) emits Python source, and it relies on the
> [AST node definitions](nodes.md) and the
> [visitor infrastructure](visitor.md).

---

## Architecture Overview

The optimizer sits between parsing and code generation. The environment's
`compile` method parses source into an AST, then the code generator (when
`optimized=True`) invokes the optimizer on the tree before emitting code.

```mermaid
flowchart LR
    subgraph Parsing
        L[Lexer] --> P[Parser]
        P --> AST[AST: nodes.Template]
    end

    subgraph "Compilation & Analysis"
        AST --> OPT[Optimizer]
        OPT -->|folded AST| CG[CodeGenerator]
        IDT[idtracking] -.-> CG
        META[meta] -.-> CG
    end

    subgraph Runtime
        CG --> PY[Generated Python source]
        PY --> RT[runtime]
    end

    ENV[Environment] -.->|environment ref| OPT
    ENV -.->|optimized flag| CG
```

The `Environment` controls whether optimization happens at all via its
`optimized` constructor flag (default `True`). When enabled, the
`CodeGenerator` instantiates an `Optimizer` and applies it to the parsed tree.

---

## Core Components

### `optimize(node, environment)`

```python
def optimize(node: nodes.Node, environment: "Environment") -> nodes.Node:
    optimizer = Optimizer(environment)
    return t.cast(nodes.Node, optimizer.visit(node))
```

A convenience entry point. It constructs an `Optimizer` bound to the given
`Environment` and runs the visitor over the supplied AST node, returning the
(possibly modified) tree. The `environment` is used to validate that folded
constants have a safe representation (see below).

### `Optimizer`

```python
class Optimizer(NodeTransformer):
    def __init__(self, environment: "t.Optional[Environment]") -> None:
        self.environment = environment

    def generic_visit(self, node, *args, **kwargs):
        node = super().generic_visit(node, *args, **kwargs)
        if isinstance(node, nodes.Expr):
            try:
                return nodes.Const.from_untrusted(
                    node.as_const(args[0] if args else None),
                    lineno=node.lineno,
                    environment=self.environment,
                )
            except nodes.Impossible:
                pass
        return node
```

`Optimizer` extends `NodeTransformer`, which recursively walks the AST and
allows nodes to be replaced by the return value of visitor methods. The
optimizer overrides only `generic_visit`, so it applies the same folding logic
to *every* node type without needing a dedicated `visit_*` method for each.

The folding algorithm is:

1. **Recurse first.** `super().generic_visit(...)` visits and transforms all
   child nodes, so children are folded before their parent. This enables
   bottom-up constant folding (e.g. `1 + 2` folds to `3`, then `3 * 4` folds
   to `12`).
2. **Attempt folding only for expressions.** Only nodes that are instances of
   `nodes.Expr` are candidates. Other node types (statements, helpers) may
   also implement `as_const`, but folding them causes errors later in
   compilation, so they are skipped.
3. **Evaluate to a constant.** `node.as_const(...)` is called. The optional
   `EvalContext` is taken from the first positional argument if present
   (`args[0]`), otherwise `None`.
4. **Validate and wrap.** The resulting value is passed to
   `nodes.Const.from_untrusted(...)`, which checks that the value has a *safe
   representation* (i.e. `eval(repr(x)) == x`). If not, it raises
   `Impossible`.
5. **Fall back gracefully.** If `as_const` raises `nodes.Impossible` (either
   because the expression is not constant or because the value is not safely
   representable), the original node is returned unchanged.

---

## Constant Folding Process

The following sequence diagram illustrates how a single expression such as
`{{ 1 + 2 * 3 }}` is folded during compilation.

```mermaid
sequenceDiagram
    participant CG as CodeGenerator
    participant OPT as Optimizer
    participant NT as NodeTransformer
    participant EXPR as Expr node
    participant CONST as Const.from_untrusted

    CG->>OPT: visit(template_ast)
    OPT->>NT: generic_visit(node)
    NT->>NT: recurse into child nodes
    Note over NT: children folded bottom-up
    NT-->>OPT: transformed node
    OPT->>OPT: isinstance(node, Expr)?
    alt node is an Expr
        OPT->>EXPR: node.as_const(eval_ctx)
        alt value is constant
            EXPR-->>OPT: value
            OPT->>CONST: from_untrusted(value, lineno, env)
            alt safe repr
                CONST-->>OPT: Const node
                OPT-->>CG: Const node (replaces Expr)
            else unsafe repr
                CONST-->>OPT: raise Impossible
                OPT-->>CG: original node
            end
        else not constant
            EXPR-->>OPT: raise Impossible
            OPT-->>CG: original node
        end
    else node is not an Expr
        OPT-->>CG: original node
    end
```

### Why `from_untrusted`?

`Const.from_untrusted` (defined in [nodes](nodes.md)) delegates to
`compiler.has_safe_repr` to ensure the folded value can be safely embedded in
the generated Python source via `repr()`. This guards against folding values
whose `repr` cannot be round-tripped (for example, objects with custom
`__repr__` implementations), which would otherwise produce broken or unsafe
generated code.

---

## Component Relationships

```mermaid
classDiagram
    class NodeVisitor {
        +get_visitor(node)
        +visit(node, *args, **kwargs)
        +generic_visit(node, *args, **kwargs)
    }
    class NodeTransformer {
        +generic_visit(node, *args, **kwargs)
        +visit_list(node, *args, **kwargs)
    }
    class Optimizer {
        +environment
        +__init__(environment)
        +generic_visit(node, *args, **kwargs)
    }
    class Node {
        +fields
        +attributes
        +iter_fields()
        +iter_child_nodes()
    }
    class Expr {
        +as_const(eval_ctx)
        +can_assign()
    }
    class Const {
        +value
        +as_const(eval_ctx)
        +from_untrusted(value, lineno, environment)
    }
    class Impossible {
        <<exception>>
    }

    NodeVisitor <|-- NodeTransformer
    NodeTransformer <|-- Optimizer
    Node <|-- Expr
    Expr <|-- Const
    Optimizer ..> Expr : folds
    Optimizer ..> Const : produces
    Optimizer ..> Impossible : catches
```

### Dependency Summary

| Dependency | Role |
| --- | --- |
| [`visitor.NodeTransformer`](visitor.md) | Base class providing recursive AST traversal and node replacement. |
| [`nodes.Expr`](nodes.md) | Marker/base class for expressions; only these are folded. |
| [`nodes.Const`](nodes.md) | Target node type for folded constants; provides `from_untrusted`. |
| [`nodes.Impossible`](nodes.md) | Exception signaling that a node cannot be folded. |
| [`environment.Environment`](environment.md) | Supplies the environment reference used for safe-repr validation. |
| [`compiler.CodeGenerator`](compiler.md) | Consumer of the optimizer; instantiates and applies it. |

---

## Integration with the Compilation Pipeline

The optimizer is not invoked directly by end users. Instead, it is wired into
the pipeline through the `CodeGenerator`:

```python
class CodeGenerator(NodeVisitor):
    def __init__(self, environment, name, filename, stream=None,
                 defer_init=False, optimized=True):
        ...
        self.optimizer: t.Optional[Optimizer] = None
        if optimized:
            self.optimizer = Optimizer(environment)
```

The `optimized` flag originates from the `Environment.optimized` attribute,
which is passed through `Environment._generate` into the `generate` function
and ultimately into the `CodeGenerator`. When `optimized=False`, no optimizer
is created and the AST is compiled as-is.

```mermaid
flowchart TD
    A[Environment.compile] --> B[Environment._parse]
    B --> C[Parser.parse -> AST]
    C --> D[Environment._generate]
    D --> E[generate(optimized=env.optimized)]
    E --> F{optimized?}
    F -->|True| G[CodeGenerator with Optimizer]
    F -->|False| H[CodeGenerator without Optimizer]
    G --> I[Optimizer.visit folds AST]
    I --> J[Emit Python source]
    H --> J
```

---

## Design Constraints and Limitations

The module docstring explicitly documents the key limitation:

> Because the AST does not contain all the scoping information and the
> compiler has to find that out, we cannot do all the optimizations we want.
> For example, loop unrolling doesn't work because unrolled loops would have a
> different scope. The solution would be a second syntax tree that stored the
> scoping rules.

Consequences of this design:

- **Only constant folding is performed.** More aggressive optimizations
  (loop unrolling, dead-code elimination across scopes, etc.) are out of
  scope.
- **Only `Expr` nodes are folded.** Statements and helpers are left untouched
  even if they expose `as_const`, because folding them breaks later
  compilation stages.
- **Folding is bottom-up.** Because `generic_visit` recurses before folding,
  nested constant expressions collapse fully in a single pass.
- **Safety over aggressiveness.** Any value that cannot be safely represented
  in generated source is left as a runtime expression rather than folded.

---

## Related Modules

- [compiler](compiler.md) — The `CodeGenerator` that consumes the optimized
  AST and emits Python source; also defines `has_safe_repr`.
- [nodes](nodes.md) — AST node definitions including `Expr`, `Const`, and
  `Impossible`.
- [visitor](visitor.md) — `NodeVisitor` / `NodeTransformer` traversal
  infrastructure.
- [environment](environment.md) — The `Environment` that owns the `optimized`
  flag and provides the environment reference.
- [idtracking](idtracking.md) — Symbol tracking used by the compiler after
  optimization.
- [meta](meta.md) — `TrackingCodeGenerator` used for template introspection.
