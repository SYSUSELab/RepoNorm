# Compilation and Analysis Module

## Purpose

The `compilation_and_analysis` module is the backend of the Jinja2 template engine. It takes the abstract syntax tree (AST) produced by the lexing and parsing stage and transforms it into executable Python code. Beyond code generation, this module also performs static analysis of templates to extract metadata (such as referenced variables, undeclared variables, and referenced templates) without actually rendering them.

The module is responsible for:

- **Code generation** — translating Jinja AST nodes into Python source code that, when executed, renders the template.
- **Optimization** — applying AST-level transformations (e.g., constant folding) to simplify the tree before compilation.
- **Symbol tracking** — analyzing variable scopes, assignments, and references to correctly resolve names during compilation.
- **Static analysis** — exposing template metadata (undeclared variables, referenced templates, etc.) for tooling and introspection.

## Architecture

The module is composed of four cooperating components. The compiler is the central piece; the optimizer and id-tracking modules feed into it, while the meta module builds on top of the compiler's analysis capabilities.

```mermaid
flowchart TD
    subgraph Input
        AST[Template AST<br/>from lexing_and_parsing]
    end

    subgraph compilation_and_analysis
        OPT[optimizer.py<br/>AST optimization]
        IDT[idtracking.py<br/>symbol / scope tracking]
        COMP[compiler.py<br/>code generation]
        META[meta.py<br/>static analysis]
    end

    subgraph Output
        CODE[Generated Python code]
        INFO[Template metadata<br/>undeclared vars, refs]
    end

    AST --> OPT
    OPT --> COMP
    IDT --> COMP
    COMP --> CODE
    COMP --> META
    META --> INFO
```

### Component Roles

- **`compiler.py`** — The core code generator. It walks the AST using the visitor pattern and emits Python source. It relies on `idtracking` to resolve variable scopes and on `optimizer` to simplify the tree beforehand.
- **`optimizer.py`** — Performs AST-level optimizations (notably constant folding) before compilation, reducing the amount of work the compiler must do and producing more efficient generated code.
- **`idtracking.py`** — Tracks symbol definitions, assignments, and references across nested scopes (blocks, loops, macros, etc.). This information is essential for the compiler to emit correct variable lookups and assignments.
- **`meta.py`** — Provides static analysis utilities that operate on the AST (via the compiler's analysis pass) to report undeclared variables, referenced templates, and other metadata without rendering the template.

## Core Components

Detailed documentation for each component is available in the following files:

- [Compiler](./compiler.md) — AST-to-Python code generation.
- [Optimizer](./optimizer.md) — AST optimization passes.
- [ID Tracking](./idtracking.md) — Symbol and scope tracking.
- [Meta](./meta.md) — Static template analysis and metadata extraction.