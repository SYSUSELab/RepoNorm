# Filters Module

## Introduction

The `filters` module (`src/jinja2/filters.py`) implements Jinja's built-in **template filters** — the functions invoked with the `|` operator inside templates (e.g. `{{ name|upper }}`). Filters transform a value on the left-hand side of the pipe into a new value, optionally accepting arguments.

This module is the canonical registry of the default filter set. It exposes a single `FILTERS` dictionary that maps filter names to their implementations, which the [`Environment`](template_environment_and_loading.md) copies into `Environment.filters` at construction time. The compiler then resolves `|filter` expressions against this mapping at runtime.

The module covers a broad range of concerns:

- **String manipulation** — `upper`, `lower`, `title`, `capitalize`, `trim`, `truncate`, `wordwrap`, `indent`, `replace`, `center`, `striptags`, `wordcount`.
- **Sequence/collection operations** — `sort`, `unique`, `min`, `max`, `sum`, `list`, `first`, `last`, `random`, `reverse`, `slice`, `batch`, `groupby`, `join`, `map`, `select`, `reject`, `selectattr`, `rejectattr`.
- **Type conversion** — `int`, `float`, `string`, `list`, `format`.
- **HTML/escaping safety** — `escape`, `forceescape`, `safe`, `mark_unsafe`, `xmlattr`, `tojson`, `urlize`, `urlencode`.
- **Attribute access** — `attr`, `map(attribute=...)`, `groupby`, `sort(attribute=...)`.
- **Miscellaneous** — `default`, `dictsort`, `filesizeformat`, `pprint`, `round`, `items`.

## Architecture Overview

The filters module sits at the boundary between the template author's syntax and the runtime evaluation machinery. Filters are plain Python callables that may optionally receive the active `Context`, `Environment`, or `EvalContext` as their first argument via decorators.

```mermaid
graph TD
    subgraph "Template Author"
        T["{{ value|filter(args) }}"]
    end

    subgraph "Compilation & Analysis"
        C["compiler.CodeGenerator"]
        N["nodes.Filter"]
    end

    subgraph "Runtime Support"
        ENV["Environment"]
        CTX["Context"]
        EC["EvalContext"]
        UND["Undefined"]
    end

    subgraph "filters.py"
        REG["FILTERS registry"]
        IMPL["do_* implementations"]
        HELP["make_attrgetter / make_multi_attrgetter"]
        PREP["prepare_map / prepare_select_or_reject"]
    end

    subgraph "Utilities"
        U["utils: pass_context, pass_environment,<br/>pass_eval_context, urlize, url_quote,<br/>htmlsafe_json_dumps, pformat"]
        AU["async_utils: async_variant,<br/>auto_aiter, auto_await, auto_to_list"]
    end

    T --> N --> C
    C -->|"env.call_filter(name, value, ...)"| ENV
    ENV --> REG
    REG --> IMPL
    IMPL --> HELP
    IMPL --> PREP
    IMPL --> U
    IMPL --> AU
    IMPL --> UND
    ENV --> CTX
    CTX --> EC
```

## Core Components

### `HasHTML` (Protocol)

A `typing.Protocol` (only defined under `TYPE_CHECKING`) describing objects that expose an `__html__()` method returning a pre-escaped HTML string. It is used as a type hint for filters such as `do_forceescape` and `do_striptags`, which check `hasattr(value, "__html__")` to decide whether to coerce the value through its HTML representation before processing. This mirrors the `markupsafe.Markup` protocol.

### `_GroupTuple` (NamedTuple)

A `NamedTuple` subclass with fields `grouper` and `list`, produced by the `groupby` filter. It behaves like a regular tuple (so `{% for city, items in users|groupby("city") %}` unpacking works) but overrides `__repr__` and `__str__` to delegate to the plain `tuple` implementations, hiding the subclass from users who print the value during debugging.

```python
class _GroupTuple(t.NamedTuple):
    grouper: t.Any
    list: t.List

    def __repr__(self) -> str:
        return tuple.__repr__(self)

    def __str__(self) -> str:
        return tuple.__str__(self)
```

## Filter Registration and Dispatch

All filters are collected into the module-level `FILTERS` dictionary. The [`Environment`](template_environment_and_loading.md) copies this dict into `Environment.filters` during initialization (`self.filters = DEFAULT_FILTERS.copy()`), where `DEFAULT_FILTERS` is imported from this module.

```mermaid
flowchart LR
    A["filters.FILTERS dict"] -->|"DEFAULT_FILTERS.copy()"| B["Environment.filters"]
    B -->|"env.call_filter(name, value, args, kwargs)"| C["_filter_test_common"]
    C -->|"lookup func = env_map[name]"| D["do_* implementation"]
    C -->|"inspect _PassArg.from_obj(func)"| E{"pass_arg?"}
    E -->|"context"| F["insert Context as arg[0]"]
    E -->|"eval_context"| G["insert EvalContext as arg[0]"]
    E -->|"environment"| H["insert Environment as arg[0]"]
    E -->|"None"| I["call func(value, *args)"]
    F --> J["func(*args, **kwargs)"]
    G --> J
    H --> J
    I --> J
```

The dispatch mechanism relies on the `_PassArg` marker set by the decorators in [`utils`](runtime_support_and_foundation.md). When `Environment.call_filter` (or `Context.call`) invokes a filter, it inspects the callable's `jinja_pass_arg` attribute and injects the appropriate object as the first positional argument.

## Argument Injection Decorators

Filters that need access to runtime state are decorated with one of three decorators from [`utils`](runtime_support_and_foundation.md):

| Decorator | Injected first argument | Example filters |
|-----------|------------------------|-----------------|
| `@pass_context` | `Context` | `do_random`, `do_map`, `do_select`, `do_reject`, `do_selectattr`, `do_rejectattr` |
| `@pass_environment` | `Environment` | `do_sort`, `do_unique`, `do_min`, `do_max`, `do_first`, `do_last`, `do_truncate`, `do_wordwrap`, `do_groupby`, `do_sum`, `do_attr` |
| `@pass_eval_context` | `EvalContext` | `do_replace`, `do_xmlattr`, `do_join`, `do_urlize`, `do_tojson` |

These decorators set a `jinja_pass_arg` attribute on the function, which the runtime uses to decide what to inject. See [runtime_support_and_foundation.md](runtime_support_and_foundation.md) for the full decorator semantics.

## Async Support

Many filters have both a synchronous and an asynchronous implementation. The `@async_variant(sync_func)` decorator from [`async_utils`](runtime_support_and_foundation.md) wraps the pair and dispatches at call time based on whether the active environment is in async mode (`environment.is_async`).

```mermaid
flowchart TD
    A["do_join (async_variant wrapper)"] --> B{"is_async(args)?"}
    B -->|"True"| C["async do_join<br/>await auto_to_list(value)"]
    B -->|"False"| D["sync_do_join"]
    C --> E["sync_do_join on materialized list"]
```

Filters with async variants include: `join`, `first`, `slice`, `groupby`, `sum`, `list`, `map`, `select`, `reject`, `selectattr`, `rejectattr`.

The helper functions `auto_aiter`, `auto_await`, and `auto_to_list` normalize both sync and async iterables/awaitables so the async implementations can reuse the sync logic after materializing the input.

> **Note:** `do_last` intentionally has **no** async variant, because reversing an async iterable is not safe in async mode.

## Attribute Lookup Helpers

Several filters (`sort`, `unique`, `min`, `max`, `groupby`, `map`, `join`, `sum`) support an `attribute` parameter that extracts a value from each item using Jinja's lookup rules. This is implemented by two factory functions:

- **`make_attrgetter(environment, attribute, postprocess, default)`** — returns a callable that resolves a single (possibly dotted) attribute path against an object using `environment.getitem`. Integer path segments are looked up as integers. If a lookup yields an `Undefined` and a `default` is provided, the default is substituted.
- **`make_multi_attrgetter(environment, attribute, postprocess)`** — handles comma-separated attribute lists (e.g. `"age,name"`), returning a list of extracted values. Used by `do_sort` to support multi-key sorting.

Both rely on `_prepare_attribute_parts`, which splits a dotted string into parts and converts digit-only segments to integers.

```mermaid
flowchart LR
    A["attribute='address.city'"] --> B["_prepare_attribute_parts"]
    B --> C["['address', 'city']"]
    C --> D["make_attrgetter"]
    D --> E["attrgetter(item)"]
    E --> F["environment.getitem(item, 'address')"]
    F --> G["environment.getitem(..., 'city')"]
    G --> H["postprocess (e.g. ignore_case)"]
```

The `ignore_case` postprocessor lowercases string values and passes other types through unchanged, enabling case-insensitive sorting/grouping by default.

## Filter Categories

### String Filters

| Filter | Function | Notes |
|--------|----------|-------|
| `upper` / `lower` | `do_upper` / `do_lower` | Uses `soft_str` for safe coercion |
| `title` | `do_title` | Splits on `[-\s({\[<]+` word boundaries |
| `capitalize` | `do_capitalize` | First char upper, rest lower |
| `trim` | `do_trim` | `str.strip` with optional chars |
| `truncate` | `do_truncate` | Honors `truncate.leeway` policy |
| `wordwrap` | `do_wordwrap` | Wraps each paragraph separately |
| `indent` | `do_indent` | Preserves `Markup` safety |
| `replace` | `do_replace` | Autoescape-aware |
| `center` | `do_center` | Pads to width |
| `striptags` | `do_striptags` | Uses `Markup.striptags` |
| `wordcount` | `do_wordcount` | Regex `\w+` count |

### Sequence & Collection Filters

| Filter | Function | Notes |
|--------|----------|-------|
| `sort` | `do_sort` | Stable; supports multi-attribute |
| `unique` | `do_unique` | Preserves first-occurrence order |
| `min` / `max` | `do_min` / `do_max` | Shared `_min_or_max` helper |
| `sum` | `do_sum` | Supports `attribute` and `start` |
| `list` | `do_list` | Async variant available |
| `first` / `last` | `do_first` / `do_last` | `last` has no async variant |
| `random` | `do_random` | Uses `@pass_context` |
| `reverse` | `do_reverse` | Strings reversed directly |
| `slice` | `do_slice` | Column-style slicing |
| `batch` | `do_batch` | Row-style batching |
| `groupby` | `do_groupby` | Returns `_GroupTuple` list |
| `join` | `do_join` | Autoescape-aware separator handling |
| `map` | `do_map` | Attribute lookup or filter invocation |
| `select` / `reject` | `do_select` / `do_reject` | Test-based filtering |
| `selectattr` / `rejectattr` | `do_selectattr` / `do_rejectattr` | Attribute + test filtering |

### Type Conversion Filters

| Filter | Function | Notes |
|--------|----------|-------|
| `int` | `do_int` | Falls back to `int(float(value))` |
| `float` | `do_float` | Returns default on failure |
| `string` | `soft_str` | Direct alias |
| `format` | `do_format` | printf-style; rejects mixed args |
| `round` | `do_round` | `common`/`ceil`/`floor` methods |

### HTML & Escaping Filters

| Filter | Function | Notes |
|--------|----------|-------|
| `escape` / `e` | `escape` | Direct `markupsafe.escape` alias |
| `forceescape` | `do_forceescape` | Coerces via `__html__` then escapes |
| `safe` | `do_mark_safe` | Wraps in `Markup` |
| `mark_unsafe` | `do_mark_unsafe` | Reverse of `safe` |
| `xmlattr` | `do_xmlattr` | Skips `None`/`Undefined` values |
| `tojson` | `do_tojson` | Uses `json.dumps_function` policy |
| `urlize` | `do_urlize` | Honors `urlize.*` policies |
| `urlencode` | `do_urlencode` | String or mapping/iterable |

### Miscellaneous Filters

| Filter | Function | Notes |
|--------|----------|-------|
| `default` / `d` | `do_default` | `boolean` flag for falsy values |
| `dictsort` | `do_dictsort` | Sort by key or value |
| `filesizeformat` | `do_filesizeformat` | Decimal or binary prefixes |
| `pprint` | `do_pprint` | Uses `utils.pformat` |
| `attr` | `do_attr` | Sandbox-aware attribute access |
| `items` | `do_items` | Mapping items; empty for `Undefined` |

## Data Flow: A Filter Invocation

The following sequence diagram traces a filter call from template source to result, using `{{ users|sort(attribute="age") }}` as an example.

```mermaid
sequenceDiagram
    participant T as Template
    participant C as CodeGenerator
    participant E as Environment
    participant F as filters.do_sort
    participant H as make_multi_attrgetter
    participant U as Undefined

    T->>C: compile "users|sort(attribute='age')"
    C->>E: env.call_filter("sort", users, kwargs={attribute:"age"})
    E->>E: _filter_test_common: lookup FILTERS["sort"]
    E->>E: _PassArg.from_obj(do_sort) == environment
    E->>F: do_sort(env, users, attribute="age")
    F->>H: make_multi_attrgetter(env, "age", postprocess=ignore_case)
    H-->>F: key_func
    F->>F: sorted(users, key=key_func)
    F-->>E: sorted list
    E-->>C: result
    C-->>T: rendered output
```

## Interaction with Other Modules

```mermaid
graph LR
    F["filters.py"]

    F -->|"pass_context, pass_environment,<br/>pass_eval_context, urlize, url_quote,<br/>htmlsafe_json_dumps, pformat"| U["utils.py"]
    F -->|"async_variant, auto_aiter,<br/>auto_await, auto_to_list"| AU["async_utils.py"]
    F -->|"Undefined"| RT["runtime.py"]
    F -->|"FilterArgumentError"| EX["exceptions.py"]
    F -->|"escape, Markup, soft_str"| MS["markupsafe"]
    F -->|"Environment (type hint)"| ENV["environment.py"]
    F -->|"EvalContext (type hint)"| ND["nodes.py"]
    F -->|"SandboxedEnvironment (type hint)"| SB["sandbox.py"]

    ENV -->|"DEFAULT_FILTERS.copy()"| F
```

### Key Dependencies

- **[utils](runtime_support_and_foundation.md)** — provides the argument-injection decorators (`pass_context`, `pass_environment`, `pass_eval_context`), the `urlize`/`url_quote` helpers, `htmlsafe_json_dumps`, and `pformat`.
- **[async_utils](runtime_support_and_foundation.md)** — provides `async_variant` and the async normalization helpers.
- **[runtime](runtime_support_and_foundation.md)** — `Undefined` is used throughout for empty-sequence handling and default substitution; `Context` is injected into context-aware filters.
- **[exceptions](runtime_support_and_foundation.md)** — `FilterArgumentError` is raised for invalid filter arguments (e.g. bad `dictsort` `by`, mixed `format` args, invalid `round` method).
- **[environment](template_environment_and_loading.md)** — `Environment` copies `FILTERS` into `Environment.filters` and dispatches calls via `call_filter`.
- **[nodes](lexing_and_parsing.md)** — `EvalContext` is the type injected by `@pass_eval_context`; `Filter` nodes represent filter expressions in the AST.
- **[sandbox](template_environment_and_loading.md)** — `do_attr` checks `environment.sandboxed` and calls `is_safe_attribute`/`unsafe_undefined` when running under a `SandboxedEnvironment`.

## Error Handling

Filters raise `FilterArgumentError` (a subclass of `TemplateRuntimeError`) for invalid arguments:

- `do_dictsort` — invalid `by` value (must be `"key"` or `"value"`).
- `do_format` — both positional and keyword arguments supplied.
- `do_round` — invalid `method` (must be `common`, `ceil`, or `floor`).
- `do_reverse` — non-iterable argument.
- `do_urlize` — invalid URI scheme prefix.
- `prepare_map` — missing filter argument or unexpected keyword argument.
- `prepare_select_or_reject` — missing attribute name parameter.

Empty sequences are handled gracefully by returning `environment.undefined(...)` rather than raising, for filters like `first`, `last`, `random`, `min`, and `max`.

## Summary

The `filters` module is the heart of Jinja's value-transformation capabilities. Its design separates concerns cleanly:

1. **Registration** — a flat `FILTERS` dict consumed by the `Environment`.
2. **Dispatch** — decorator-driven argument injection handled by the runtime.
3. **Reuse** — shared helpers (`make_attrgetter`, `_min_or_max`, `select_or_reject`, `prepare_map`) keep implementations DRY.
4. **Async parity** — `@async_variant` provides async equivalents without duplicating logic.
5. **Safety** — autoescape awareness and sandbox integration are woven into the relevant filters.

For details on how filters are invoked during rendering, see [runtime_support_and_foundation.md](runtime_support_and_foundation.md). For how filter expressions are parsed and compiled, see [lexing_and_parsing.md](lexing_and_parsing.md) and [compilation_and_analysis.md](compilation_and_analysis.md).
