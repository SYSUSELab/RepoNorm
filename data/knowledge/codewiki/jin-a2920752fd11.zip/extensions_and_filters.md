# Extensions and Filters Module

## Introduction

The **Extensions and Filters** module provides Jinja's extension API for adding custom tags and behavior to the template engine at the parser level, along with the built-in extensions that ship with Jinja. The core of this module lives in `src/jinja2/ext.py`, which defines the `Extension` base class and several concrete extensions:

- **`Extension`** — the base class that all custom extensions inherit from.
- **`InternationalizationExtension`** (`i18n`) — adds `gettext`/`ngettext`/`pgettext`/`npgettext` support and the `{% trans %}` tag.
- **`ExprStmtExtension`** (`do`) — adds the `{% do %}` tag for evaluating expressions without output.
- **`LoopControlExtension`** (`loopcontrols`) — adds `{% break %}` and `{% continue %}`.
- **`DebugExtension`** (`debug`) — adds the `{% debug %}` tag that dumps context, filters, and tests.

The module also provides translation extraction utilities (`extract_from_ast`, `babel_extract`, `_CommentFinder`) used by Babel-style tooling.

Extensions are the primary mechanism by which Jinja is extended without modifying its core. They hook into the lexing, parsing, and code-generation pipeline through well-defined lifecycle methods.

---

## Architecture Overview

Extensions integrate with the Jinja pipeline at multiple stages. The `Environment` loads extensions, and each extension can participate in preprocessing, token filtering, and parsing.

```mermaid
graph TD
    Env[Environment] -->|load_extensions| Ext[Extension instances]
    Env -->|iter_extensions by priority| Pipeline
    Ext -->|preprocess| Pre[Source preprocessing]
    Ext -->|filter_stream| Lex[Token filtering]
    Ext -->|parse| Parse[Parser hook per tag]
    Parse --> Nodes[nodes.Node AST]
    Nodes --> Compiler[CodeGenerator]
    Compiler -->|ExtensionAttribute| Runtime[Runtime attribute lookup]
```

### Extension Lifecycle

Each extension can hook into the following stages, executed in priority order (lower value = higher priority):

```mermaid
flowchart LR
    A[Source string] --> B[preprocess]
    B --> C[Lexer.tokenize]
    C --> D[filter_stream]
    D --> E[Parser]
    E -->|tag matched| F[Extension.parse]
    F --> G[AST nodes]
    G --> H[Compiler]
```

| Stage | Method | Purpose |
|-------|--------|---------|
| Preprocessing | `preprocess(source, name, filename)` | Rewrite source before lexing |
| Token filtering | `filter_stream(stream)` | Filter/transform the token stream |
| Parsing | `parse(parser)` | Handle a matched tag, return AST nodes |
| Code generation | `attr(name)` / `call_method(...)` | Emit `ExtensionAttribute`/`Call` nodes |

---

## Core Components

### `Extension` (base class)

The `Extension` class is the foundation of the extension API. Key characteristics:

- **Identifier**: Each subclass automatically gets an `identifier` of the form `"{module}.{ClassName}"` via `__init_subclass__`. This identifier is used by `ExtensionAttribute` to look up the extension at runtime.
- **`tags`**: A set of tag names the extension listens for. When the parser encounters a matching tag, it dispatches to `parse`.
- **`priority`**: Defaults to `100`. Lower values run first — useful for extensions that preprocess values.
- **`bind(environment)`**: Creates a copy of the extension bound to another environment. This is essential for environment overlays, since extensions must not store environment-specific data on `self`.
- **`attr(name, lineno)`**: Returns an `ExtensionAttribute` node referencing a constant on the extension.
- **`call_method(...)`**: Shortcut combining `attr` + `nodes.Call` to invoke an extension method from generated template code.

> **Design note:** Extensions are created by the environment and cannot accept configuration arguments directly. Configuration must be stored on the environment (using `environment.extend(...)`), with carefully namespaced attribute names to avoid clashes.

### `InternationalizationExtension` (`i18n`)

Adds gettext support. It registers the `{% trans %}` tag and installs several environment methods:

- `install_gettext_translations(translations, newstyle=None)`
- `install_null_translations(newstyle=None)`
- `install_gettext_callables(gettext, ngettext, ...)`
- `uninstall_gettext_translations(translations)`
- `extract_translations(source, gettext_functions)`

It also sets `environment.globals["_"]` to `_gettext_alias` and adds the `newstyle_gettext` policy.

The `parse` method handles the `{% trans %}` / `{% pluralize %}` / `{% endtrans %}` block, building `gettext`/`ngettext`/`pgettext`/`npgettext` call nodes. It supports:

- Named variables (`{% trans count=items|length %}`)
- Context strings (`{% trans "context" %}`)
- `trimmed`/`notrimmed` modifiers
- Pluralization via `{% pluralize %}`

The helper factories `_make_new_gettext`, `_make_new_ngettext`, `_make_new_pgettext`, and `_make_new_npgettext` wrap translation callables for "newstyle" gettext, which handles variable expansion and autoescaping internally.

### `ExprStmtExtension` (`do`)

Adds the `{% do %}` tag. Its `parse` method returns an `ExprStmt` node wrapping the parsed tuple expression, evaluating it without producing output.

### `LoopControlExtension` (`loopcontrols`)

Adds `{% break %}` and `{% continue %}`. Its `parse` method inspects the matched token and returns a `Break` or `Continue` node.

### `DebugExtension` (`debug`)

Adds the `{% debug %}` tag. Its `parse` method emits a call to `_render`, which returns a pretty-printed dump of the context, available filters, and tests.

### Translation Extraction Utilities

- **`extract_from_ast(ast, gettext_functions, babel_style)`** — Walks the AST for `Call` nodes whose callee is a gettext function, yielding `(lineno, function, message)` tuples. In Babel style, non-string parameters are returned as `None`.
- **`_CommentFinder`** — Finds translator comments preceding gettext calls in a token stream.
- **`babel_extract(fileobj, keywords, comment_tags, options)`** — The Babel extraction entry point. Builds a temporary `Environment`, parses the source, and yields `(lineno, funcname, message, comments)` tuples.

---

## Component Interaction

The following diagram shows how the built-in extensions interact with the environment, parser, and runtime.

```mermaid
sequenceDiagram
    participant Env as Environment
    participant Parser
    participant Ext as Extension
    participant Nodes as AST Nodes
    participant Ctx as Context (runtime)

    Env->>Ext: __init__(environment)
    Ext->>Env: environment.extend(...) / globals update
    Env->>Parser: _tokenize (preprocess + filter_stream)
    Parser->>Ext: parse(parser) on tag match
    Ext->>Nodes: build nodes (Call, Output, ExprStmt, ...)
    Nodes->>Ctx: ExtensionAttribute lookup at runtime
    Ctx->>Ext: call_method invocation
```

### Runtime Attribute Resolution

When an extension emits an `ExtensionAttribute` node (via `attr` or `call_method`), the compiler generates code that resolves the attribute on the extension instance bound to the environment at runtime. This is how extension methods like `DebugExtension._render` are invoked from generated template code.

---

## Data Flow: `{% trans %}` Parsing

The i18n extension's parsing flow is the most complex in this module:

```mermaid
flowchart TD
    Start[{% trans ... %}] --> ParseVars[Parse variables & context]
    ParseVars --> ParseSingular[_parse_block singular]
    ParseSingular --> HasPlural{pluralize?}
    HasPlural -->|yes| ParsePlural[_parse_block plural]
    HasPlural -->|no| Trim
    ParsePlural --> Trim[Apply trimmed policy]
    Trim --> MakeNode[_make_node]
    MakeNode --> Newstyle{newstyle_gettext?}
    Newstyle -->|yes| Kwargs[Emit Call with kwargs]
    Newstyle -->|no| Mod[MarkSafeIfAutoescape + Mod with Dict]
    Kwargs --> Output[Output node]
    Mod --> Output
```

---

## Dependencies

The extensions module depends on several other Jinja modules:

```mermaid
graph LR
    ext[ext.py] --> environment[environment.py]
    ext --> nodes[nodes.py]
    ext --> exceptions[exceptions.py]
    ext --> runtime[runtime.py]
    ext --> utils[utils.py]
    ext --> defaults[defaults.py]
    ext --> lexer[lexer.py]
    ext --> parser[parser.py]
```

| Dependency | Used For |
|------------|----------|
| [`environment`](template_environment_and_loading.md) | `Environment` type, `extend`, `globals`, `policies` |
| [`nodes`](lexing_and_parsing.md) | AST node construction (`Call`, `Output`, `ExprStmt`, `ExtensionAttribute`, etc.) |
| [`exceptions`](runtime_support_and_foundation.md) | `TemplateAssertionError`, `TemplateSyntaxError` |
| [`runtime`](runtime_support_and_foundation.md) | `Context`, `Undefined`, `concat` |
| [`utils`](runtime_support_and_foundation.md) | `import_string`, `pass_context` |
| [`lexer`](lexing_and_parsing.md) | `Token`, `TokenStream` (type hints) |
| [`parser`](lexing_and_parsing.md) | `Parser` (type hints, parse hooks) |

---

## Filters Submodule

The `filters` submodule (`src/jinja2/filters.py`) provides the built-in filter implementations. The core components listed for this module are:

- **`HasHTML`** — A protocol/type used to identify objects that expose an `__html__` method (used for autoescaping decisions).
- **`_GroupTuple`** — A named tuple used by the `groupby` filter to represent grouped items.

Filters are registered on the environment's `filters` mapping and invoked via `Environment.call_filter`. For details on the filter execution model and the `@pass_context`/`@pass_environment` decorators, see the [runtime support module](runtime_support_and_foundation.md).

---

## Writing a Custom Extension

A minimal custom extension follows this pattern:

```python
from jinja2.ext import Extension
from jinja2 import nodes

class MyExtension(Extension):
    tags = {"mytag"}

    def parse(self, parser):
        lineno = next(parser.stream).lineno
        # parse arguments, build nodes
        return nodes.Output([...], lineno=lineno)
```

Key guidelines:

1. **Never store environment-specific data on `self`** — use `environment.extend(...)` instead, since extensions are copied via `bind` for overlays.
2. **Namespace configuration attributes** to avoid clashes (e.g., `fragment_cache_prefix` rather than `prefix`).
3. **Use `attr`/`call_method`** to reference extension constants and methods from generated code.
4. **Set `priority`** if the extension preprocesses values (lower = earlier).

---

## Related Documentation

- [Template Environment and Loading](template_environment_and_loading.md) — how extensions are loaded and bound to environments.
- [Lexing and Parsing](lexing_and_parsing.md) — the `Parser`, `TokenStream`, and AST `nodes` used by extensions.
- [Compilation and Analysis](compilation_and_analysis.md) — how extension-generated nodes are compiled.
- [Runtime Support and Foundation](runtime_support_and_foundation.md) — `Context`, `Undefined`, exceptions, and utilities.
