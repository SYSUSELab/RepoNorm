# Visitor Module

## Introduction

The `visitor` module (`src/jinja2/visitor.py`) provides the foundational API for **traversing the Jinja abstract syntax tree (AST)**. It implements the classic [Visitor pattern](https://en.wikipedia.org/wiki/Visitor_pattern) over the node hierarchy defined in the [`nodes`](nodes.md) module.

Two complementary traversal strategies are offered:

- **`NodeVisitor`** — a read-only walker that dispatches to per-node-type handler methods and forwards return values.
- **`NodeTransformer`** — a subclass of `NodeVisitor` that additionally allows nodes to be **replaced, removed, or expanded** in place.

This module is intentionally small and generic. It contains no Jinja-specific logic; instead it is the shared traversal engine reused by the compiler, the optimizer, the identifier tracker, and the meta-introspection layer. The module docstring states its purpose succinctly:

> *API for traversing the AST nodes. Implemented by the compiler and meta introspection.*

---

## Core Components

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `NodeVisitor` | class | Read-only AST walker with dynamic dispatch to `visit_<NodeType>` methods. |
| `NodeTransformer` | class | Subclass of `NodeVisitor` that mutates the tree based on visitor return values. |
| `VisitCallable` | protocol | Type-only protocol describing the signature of a visitor function. |

### `VisitCallable`

A `typing.Protocol` (imported under `TYPE_CHECKING` from `typing_extensions`) that documents the expected signature of any visitor function:

```python
class VisitCallable(te.Protocol):
    def __call__(self, node: Node, *args: t.Any, **kwargs: t.Any) -> t.Any:
        ...
```

It exists purely for static type checking and has no runtime footprint.

### `NodeVisitor`

The base traversal class. Its behavior is driven by three methods:

| Method | Purpose |
|--------|---------|
| `get_visitor(node)` | Resolves the handler for a node via `getattr(self, f"visit_{type(node).__name__}", None)`. Returns `None` when no specific handler exists. |
| `visit(node, *args, **kwargs)` | Entry point. Calls the resolved handler, or falls back to `generic_visit`. Forwards all extra arguments and returns the handler's return value. |
| `generic_visit(node, *args, **kwargs)` | Default behavior: recursively visits every direct child node via `node.iter_child_nodes()`. |

**Dispatch convention:** a node of class `TryFinally` is handled by a method named `visit_TryFinally`. This convention can be overridden by reimplementing `get_visitor`.

### `NodeTransformer`

Extends `NodeVisitor` to support **in-place tree modification**. It overrides `generic_visit` to iterate over each field of a node and apply the following rules to the visitor's return value:

| Return value | Effect |
|--------------|--------|
| `None` | The node is **removed** (deleted from its parent field, or dropped from a list). |
| A `Node` | The node is **replaced** by the returned node. |
| A `list` of nodes | The node is **expanded** into multiple nodes (only valid inside list fields). |
| The original node | No change. |

It also provides `visit_list(node, *args, **kwargs)`, a convenience helper that guarantees a list return value — useful because transformers may legitimately return either a single node or a list.

---

## Architecture

The visitor module sits at the heart of the **lexing and parsing** layer and is consumed by the **compilation and analysis** layer. It depends only on the `Node` base class from [`nodes`](nodes.md).

```mermaid
graph TD
    subgraph "lexing_and_parsing"
        LEXER["lexer.py<br/>Lexer, Token"]
        PARSER["parser.py<br/>Parser"]
        NODES["nodes.py<br/>Node, Stmt, Expr, ..."]
        VISITOR["visitor.py<br/>NodeVisitor, NodeTransformer"]
    end

    subgraph "compilation_and_analysis"
        COMPILER["compiler.py<br/>DependencyFinderVisitor<br/>UndeclaredNameVisitor"]
        OPTIMIZER["optimizer.py<br/>Optimizer"]
        IDTRACKING["idtracking.py<br/>FrameSymbolVisitor<br/>RootVisitor"]
        META["meta.py<br/>TrackingCodeGenerator"]
    end

    PARSER -->|produces| NODES
    LEXER -->|feeds| PARSER
    VISITOR -->|depends on| NODES

    COMPILER -->|extends NodeVisitor| VISITOR
    OPTIMIZER -->|extends NodeTransformer| VISITOR
    IDTRACKING -->|extends NodeVisitor| VISITOR
    META -->|uses CodeGenerator| COMPILER
```

### Dependency Direction

```mermaid
graph LR
    VISITOR["visitor.py"] --> NODES["nodes.py::Node"]
    VISITOR -.->|TYPE_CHECKING| TE["typing_extensions::Protocol"]

    COMPILER["compiler.py"] --> VISITOR
    OPTIMIZER["optimizer.py"] --> VISITOR
    IDTRACKING["idtracking.py"] --> VISITOR
```

The module has **no runtime dependencies** beyond `nodes.Node` and the standard library (`typing`). This minimal footprint is what makes it reusable across every analysis pass.

---

## Class Hierarchy

```mermaid
classDiagram
    class NodeVisitor {
        +get_visitor(node) VisitCallable
        +visit(node, *args, **kwargs) Any
        +generic_visit(node, *args, **kwargs) Any
    }

    class NodeTransformer {
        +generic_visit(node, *args, **kwargs) Node
        +visit_list(node, *args, **kwargs) List~Node~
    }

    class DependencyFinderVisitor
    class UndeclaredNameVisitor
    class FrameSymbolVisitor
    class RootVisitor
    class Optimizer

    NodeVisitor <|-- NodeTransformer
    NodeVisitor <|-- DependencyFinderVisitor
    NodeVisitor <|-- UndeclaredNameVisitor
    NodeVisitor <|-- FrameSymbolVisitor
    NodeVisitor <|-- RootVisitor
    NodeTransformer <|-- Optimizer
```

---

## Traversal Flow

The following sequence diagram illustrates how `visit` dispatches to a handler and how `NodeTransformer` differs from `NodeVisitor` when processing children.

```mermaid
sequenceDiagram
    participant Caller
    participant Visitor as NodeVisitor
    participant Handler as visit_<NodeType>
    participant Generic as generic_visit

    Caller->>Visitor: visit(node, *args)
    Visitor->>Visitor: get_visitor(node)
    alt handler exists
        Visitor->>Handler: handler(node, *args)
        Handler-->>Visitor: return value
    else no handler
        Visitor->>Generic: generic_visit(node, *args)
        loop for each child in node.iter_child_nodes()
            Generic->>Visitor: visit(child, *args)
        end
        Generic-->>Visitor: (None or node)
    end
    Visitor-->>Caller: return value
```

### `NodeTransformer` Mutation Flow

```mermaid
flowchart TD
    START["generic_visit(node)"] --> LOOP["for field, old_value in node.iter_fields()"]
    LOOP --> ISLIST{"old_value is a list?"}
    ISLIST -->|yes| LISTLOOP["for value in old_value"]
    LISTLOOP --> VISIT1["value = self.visit(value)"]
    VISIT1 --> CHECK1{"value is None?"}
    CHECK1 -->|yes| DROP["skip (remove from list)"]
    CHECK1 -->|no| CHECK2{"value is a Node?"}
    CHECK2 -->|no| EXTEND["new_values.extend(value)"]
    CHECK2 -->|yes| APPEND["new_values.append(value)"]
    DROP --> LISTLOOP
    EXTEND --> LISTLOOP
    APPEND --> LISTLOOP
    LISTLOOP --> ASSIGN["old_value[:] = new_values"]

    ISLIST -->|no| ISNODE{"old_value is a Node?"}
    ISNODE -->|yes| VISIT2["new_node = self.visit(old_value)"]
    VISIT2 --> CHECK3{"new_node is None?"}
    CHECK3 -->|yes| DEL["delattr(node, field)"]
    CHECK3 -->|no| SET["setattr(node, field, new_node)"]
    ISNODE -->|no| LOOP
    ASSIGN --> LOOP
    DEL --> LOOP
    SET --> LOOP
    LOOP --> RETURN["return node"]
```

---

## Consumers and Usage Patterns

The visitor module is the backbone of Jinja's static analysis passes. Each consumer subclasses `NodeVisitor` (or `NodeTransformer`) and implements a small set of `visit_<NodeType>` methods tailored to its goal.

### Read-only visitors (`NodeVisitor`)

| Consumer | Location | Goal | Notable overrides |
|----------|----------|------|-------------------|
| `DependencyFinderVisitor` | [`compiler`](compiler.md) | Collect the set of filters and tests referenced by a template. | `visit_Filter`, `visit_Test`, `visit_Block` (stops at blocks). |
| `UndeclaredNameVisitor` | [`compiler`](compiler.md) | Detect names accessed without being declared. | `visit_Name`, `visit_Block`; raises `VisitorExit` early when all names are resolved. |
| `FrameSymbolVisitor` | [`idtracking`](idtracking.md) | Track symbol load/store/param actions within a frame. | `visit_Name`, `visit_If`, `visit_For`, `visit_Macro`, `visit_Import`, etc. |
| `RootVisitor` | [`idtracking`](idtracking.md) | Drive `FrameSymbolVisitor` from the root of the tree. | Delegates to `sym_visitor`; raises `NotImplementedError` on unknown nodes. |

### Transforming visitors (`NodeTransformer`)

| Consumer | Location | Goal | Notable overrides |
|----------|----------|------|-------------------|
| `Optimizer` | [`optimizer`](optimizer.md) | Perform constant folding on expression nodes. | `generic_visit` — folds `Expr` nodes via `as_const` into `Const`. |

### Indirect consumers

`TrackingCodeGenerator` in [`meta`](meta.md) subclasses `CodeGenerator` (from [`compiler`](compiler.md)), which itself relies on the visitor infrastructure for its analysis passes. It "abuses the code generator for introspection" to collect undeclared identifiers.

---

## Extension Points

To build a new analysis or transformation pass:

1. **Subclass `NodeVisitor`** for read-only analysis. Implement `visit_<NodeType>` methods for the node types you care about; everything else falls through to `generic_visit`, which recurses into children automatically.
2. **Subclass `NodeTransformer`** when you need to rewrite the tree. Return `None` to delete, a `Node` to replace, or a `list` to expand. Use `visit_list` when a list result is required.
3. **Override `get_visitor`** if you need a dispatch scheme other than the `visit_<ClassName>` convention.
4. **Pass extra arguments** through `visit(node, *args, **kwargs)` — they are forwarded to every handler, enabling context to flow down the traversal (as `FrameSymbolVisitor` does with `store_as_param`).

### Example: a minimal read-only visitor

```python
from jinja2.visitor import NodeVisitor
from jinja2 import nodes


class NameCollector(NodeVisitor):
    def __init__(self):
        self.names = set()

    def visit_Name(self, node: nodes.Name) -> None:
        self.names.add(node.name)
        # no need to call generic_visit: Name has no child nodes
```

### Example: a minimal transformer

```python
from jinja2.visitor import NodeTransformer
from jinja2 import nodes


class ConstFolder(NodeTransformer):
    def generic_visit(self, node, *args, **kwargs):
        node = super().generic_visit(node, *args, **kwargs)
        if isinstance(node, nodes.Expr):
            try:
                return nodes.Const(node.as_const())
            except nodes.Impossible:
                pass
        return node
```

---

## Design Notes

- **Dynamic dispatch over explicit tables.** Rather than a registry, the visitor resolves handlers by attribute name (`visit_<ClassName>`). This keeps subclasses declarative and avoids boilerplate, at the cost of a `getattr` per node.
- **Argument forwarding.** Both `visit` and `generic_visit` accept and forward `*args, **kwargs`, allowing stateful context to be threaded through the traversal without instance attributes.
- **In-place mutation.** `NodeTransformer.generic_visit` mutates the node's fields directly (`old_value[:] = new_values`, `setattr`, `delattr`) and returns the (possibly unchanged) node, so the root of the tree is always returned.
- **Early termination.** Consumers such as `UndeclaredNameVisitor` raise a dedicated exception (`VisitorExit`) from within a handler to abort traversal early — a pattern enabled by the simple call stack of `visit`.

---

## Related Modules

- [`nodes`](nodes.md) — the AST node hierarchy that the visitor traverses (`Node`, `Stmt`, `Expr`, `iter_child_nodes`, `iter_fields`).
- [`parser`](parser.md) — produces the AST consumed by visitors.
- [`lexer`](lexer.md) — tokenizes source before parsing.
- [`compiler`](compiler.md) — hosts `DependencyFinderVisitor` and `UndeclaredNameVisitor`.
- [`optimizer`](optimizer.md) — a `NodeTransformer` performing constant folding.
- [`idtracking`](idtracking.md) — hosts `FrameSymbolVisitor` and `RootVisitor`.
- [`meta`](meta.md) — introspection built on the code generator.
