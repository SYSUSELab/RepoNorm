# Exceptions Module

## Introduction

The `exceptions` module (`src/jinja2/exceptions.py`) defines the complete exception hierarchy used throughout the Jinja2 template engine. It provides a single, well-structured base class (`TemplateError`) from which all template-related errors derive, allowing applications to catch broad categories of errors (e.g., all template errors) or specific ones (e.g., a missing template).

The module is a foundational, low-level component: it has **no runtime dependencies** on other Jinja2 modules (only a `TYPE_CHECKING`-guarded import of `Undefined`), which makes it safe to import from anywhere in the codebase. Every other subsystem — the [lexer and parser](lexing_and_parsing.md), the [compiler](compilation_and_analysis.md), the [runtime](runtime_support_and_foundation.md), the [loaders](template_environment_and_loading.md), and the [sandbox](template_environment_and_loading.md) — raises these exceptions to signal failures.

## Exception Hierarchy

All exceptions in Jinja2 descend from `TemplateError`, which itself derives from Python's built-in `Exception`. The hierarchy is split into two major branches: **syntax/compile-time errors** and **runtime errors**.

```mermaid
classDiagram
    Exception <|-- TemplateError
    TemplateError <|-- TemplateSyntaxError
    TemplateError <|-- TemplateRuntimeError
    TemplateSyntaxError <|-- TemplateAssertionError
    TemplateRuntimeError <|-- UndefinedError
    TemplateRuntimeError <|-- SecurityError
    TemplateRuntimeError <|-- FilterArgumentError

    IOError <|-- TemplateNotFound
    LookupError <|-- TemplateNotFound
    TemplateError <|-- TemplateNotFound
    TemplateNotFound <|-- TemplatesNotFound

    class TemplateError {
        +message: Optional[str]
    }
    class TemplateSyntaxError {
        +lineno: int
        +name: Optional[str]
        +filename: Optional[str]
        +source: Optional[str]
        +translated: bool
    }
    class TemplateNotFound {
        +name
        +templates: list
        +message: Optional[str]
    }
    class TemplatesNotFound {
        +templates: list
    }
```

### Hierarchy Overview

| Exception | Base(s) | Category | Raised When |
|-----------|---------|----------|-------------|
| `TemplateError` | `Exception` | Base | Base class for all template errors |
| `TemplateSyntaxError` | `TemplateError` | Compile-time | Template has a syntax problem |
| `TemplateAssertionError` | `TemplateSyntaxError` | Compile-time | Compile-time error not caused by syntax |
| `TemplateRuntimeError` | `TemplateError` | Runtime | Generic runtime error in the engine |
| `UndefinedError` | `TemplateRuntimeError` | Runtime | Operation on an `Undefined` value |
| `SecurityError` | `TemplateRuntimeError` | Runtime | Insecure operation with sandbox enabled |
| `FilterArgumentError` | `TemplateRuntimeError` | Runtime | Filter called with inappropriate arguments |
| `TemplateNotFound` | `IOError`, `LookupError`, `TemplateError` | Loading | A template does not exist |
| `TemplatesNotFound` | `TemplateNotFound` | Loading | None of multiple selected templates exist |

## Core Components

### `TemplateError`

The root of the entire hierarchy. It provides a uniform `message` property so that all subclasses expose their human-readable description consistently.

```python
class TemplateError(Exception):
    """Baseclass for all template errors."""

    def __init__(self, message: t.Optional[str] = None) -> None:
        super().__init__(message)

    @property
    def message(self) -> t.Optional[str]:
        return self.args[0] if self.args else None
```

- **`message`** — a read-only property returning the first positional argument passed to the constructor (or `None`). This is the canonical way to retrieve an error's description across all subclasses.

### `TemplateNotFound`

Raised when a template cannot be located by a loader. It is a **multiple-inheritance** exception, deriving from `IOError`, `LookupError`, and `TemplateError`, so it can be caught by code expecting any of those standard Python exception types.

```python
class TemplateNotFound(IOError, LookupError, TemplateError):
    message: t.Optional[str] = None

    def __init__(self, name, message=None):
        IOError.__init__(self, name)
        if message is None:
            from .runtime import Undefined
            if isinstance(name, Undefined):
                name._fail_with_undefined_error()
            message = name
        self.message = message
        self.name = name
        self.templates = [name]

    def __str__(self) -> str:
        return str(self.message)
```

Key behaviors:
- **`name`** — the name of the template that was not found.
- **`templates`** — a list containing the single missing name (kept for API symmetry with `TemplatesNotFound`).
- **Undefined handling** — if `name` is an `Undefined` instance and no explicit message is given, it delegates to `Undefined._fail_with_undefined_error()`, raising an `UndefinedError` instead. This is the mechanism referenced by the `.. versionchanged:: 2.11` note.

This exception is raised by loaders such as `BaseLoader.get_source` (see [template_environment_and_loading.md](template_environment_and_loading.md)) and propagated by `Environment.get_template`.

### `TemplatesNotFound`

A specialization of `TemplateNotFound` raised when **multiple** candidate templates are tried and none can be loaded. Because it subclasses `TemplateNotFound`, catching the base class catches both cases.

```python
class TemplatesNotFound(TemplateNotFound):
    def __init__(self, names=(), message=None):
        if message is None:
            from .runtime import Undefined
            parts = []
            for name in names:
                if isinstance(name, Undefined):
                    parts.append(name._undefined_message)
                else:
                    parts.append(name)
            parts_str = ", ".join(map(str, parts))
            message = f"none of the templates given were found: {parts_str}"
        super().__init__(names[-1] if names else None, message)
        self.templates = list(names)
```

Key behaviors:
- **`templates`** — the full list of names that were attempted.
- **Undefined-aware messages** — if any name is `Undefined`, its `_undefined_message` is used to build a helpful error message rather than an empty string.
- Raised by `Environment.select_template` when all candidates fail.

### `TemplateSyntaxError`

Raised to signal a problem with the template source. It carries rich location metadata used to produce readable error messages and tracebacks.

```python
class TemplateSyntaxError(TemplateError):
    def __init__(self, message, lineno, name=None, filename=None):
        super().__init__(message)
        self.lineno = lineno
        self.name = name
        self.filename = filename
        self.source = None
        self.translated = False
```

Attributes:
- **`lineno`** — the line number where the error occurred.
- **`name`** — the template's load name.
- **`filename`** — the filesystem filename (if loaded from disk).
- **`source`** — the full template source, set later so the offending line can be displayed.
- **`translated`** — set to `True` when the debug extension rewrites the syntax error into a new traceback.

`__str__` builds a multi-line message including the location (`File "name", line N`) and, when `source` is available, the offending source line. `__reduce__` is implemented to support pickling despite the required `lineno` argument (see [Python issue 1692335](https://bugs.python.org/issue1692335)).

This exception is raised by the [lexer](lexing_and_parsing.md) (via the `Failure` helper class) and the [parser](lexing_and_parsing.md), and is intercepted by `Environment.handle_exception` for traceback rewriting.

### `TemplateAssertionError`

A direct subclass of `TemplateSyntaxError` with identical attributes. It covers compile-time errors that are not strictly syntax errors (e.g., a block defined twice, an unknown tag). Because it subclasses `TemplateSyntaxError`, existing handlers continue to work.

### `TemplateRuntimeError`

A generic runtime error raised by the engine during template execution. It serves as the parent for the more specific runtime errors below.

### `UndefinedError`

Raised when a template attempts an operation on an `Undefined` value. The `Undefined` class in the [runtime module](runtime_support_and_foundation.md) raises this (or a configured subclass) via `_fail_with_undefined_error`. The default `Undefined` type uses `UndefinedError` as its `exc` parameter.

### `SecurityError`

Raised when a template attempts an insecure operation while the [sandbox](template_environment_and_loading.md) is enabled. The `SandboxedEnvironment` and its subclasses raise this to block attribute access, operator use, or other operations deemed unsafe.

### `FilterArgumentError`

Raised when a filter is invoked with inappropriate arguments. This is a runtime error surfaced during filter execution.

## Exception Flow Through the Engine

The following diagram shows how exceptions propagate through the major subsystems of Jinja2, from template loading through compilation to rendering.

```mermaid
flowchart TD
    subgraph Loading["Template Loading"]
        L1[Environment.get_template] -->|not found| TNotFound[TemplateNotFound]
        L2[Environment.select_template] -->|all fail| TNotFound2[TemplatesNotFound]
        L3[BaseLoader.get_source] -->|missing| TNotFound
    end

    subgraph Compile["Lexing / Parsing / Compiling"]
        C1[Lexer] -->|bad token| TSyntax[TemplateSyntaxError]
        C2[Parser] -->|bad grammar| TSyntax
        C3[Compiler] -->|semantic error| TAssert[TemplateAssertionError]
    end

    subgraph Runtime["Rendering"]
        R1[Undefined access] -->|operation| TUndef[UndefinedError]
        R2[Sandboxed op] -->|insecure| TSec[SecurityError]
        R3[Filter call] -->|bad args| TFilter[FilterArgumentError]
        R4[Engine error] -->|generic| TRuntime[TemplateRuntimeError]
    end

    TNotFound --> Base[TemplateError]
    TNotFound2 --> TNotFound
    TSyntax --> Base
    TAssert --> TSyntax
    TUndef --> TRuntime
    TSec --> TRuntime
    TFilter --> TRuntime
    TRuntime --> Base
```

### Compile-Time Error Handling

When the [lexer](lexing_and_parsing.md) or [parser](lexing_and_parsing.md) encounters a problem, it raises a `TemplateSyntaxError`. The `Environment.parse` and `Environment.compile` methods catch this and route it through `Environment.handle_exception`, which invokes the debug extension's `rewrite_traceback_stack` to produce a friendlier traceback.

```mermaid
sequenceDiagram
    participant Env as Environment
    participant Parser as Parser / Lexer
    participant Debug as debug.rewrite_traceback_stack
    participant User as Caller

    Env->>Parser: parse(source)
    Parser-->>Env: raise TemplateSyntaxError
    Env->>Debug: handle_exception(source)
    Debug-->>User: rewritten traceback (TemplateSyntaxError)
```

### Loading Error Handling

`Environment.get_template` raises `TemplateNotFound` when the loader cannot find a template. `Environment.select_template` tries each candidate and raises `TemplatesNotFound` if all fail. Both are documented in [template_environment_and_loading.md](template_environment_and_loading.md).

## Interaction with `Undefined`

The exceptions module has a special, bidirectional relationship with the `Undefined` class in the [runtime module](runtime_support_and_foundation.md):

```mermaid
flowchart LR
    subgraph exceptions.py
        UE[UndefinedError]
        TNF[TemplateNotFound]
        TSNF[TemplatesNotFound]
    end
    subgraph runtime.py
        U[Undefined]
    end
    U -->|_fail_with_undefined_error raises| UE
    U -->|_undefined_message used by| TSNF
    TNF -->|isinstance check triggers| U
    TSNF -->|isinstance check triggers| U
```

- `Undefined._fail_with_undefined_error` raises `self._undefined_exception`, which defaults to `UndefinedError`.
- `TemplateNotFound.__init__` and `TemplatesNotFound.__init__` import `Undefined` lazily (inside the method) to avoid a circular import, then check `isinstance(name, Undefined)` to produce better error messages or raise `UndefinedError`.
- `TemplatesNotFound` uses `Undefined._undefined_message` to build its message.

This lazy-import pattern is essential: `exceptions.py` must not import `runtime.py` at module load time, because `runtime.py` imports from `exceptions.py`.

## Dependency Relationships

The exceptions module is a **leaf dependency** — it is imported by nearly every other module but imports almost nothing itself.

```mermaid
flowchart TD
    Exceptions[exceptions.py]
    Runtime[runtime.py]
    Lexer[lexer.py]
    Parser[parser.py]
    Compiler[compiler.py]
    Loaders[loaders.py]
    Environment[environment.py]
    Sandbox[sandbox.py]
    Ext[ext.py]

    Runtime -->|imports| Exceptions
    Lexer -->|imports| Exceptions
    Parser -->|imports| Exceptions
    Compiler -->|imports| Exceptions
    Loaders -->|imports| Exceptions
    Environment -->|imports| Exceptions
    Sandbox -->|imports| Exceptions
    Ext -->|imports| Exceptions

    Exceptions -.->|TYPE_CHECKING only| Runtime
```

The only outgoing reference is the `TYPE_CHECKING`-guarded import of `Undefined`, used purely for type annotations and never executed at runtime.

## Usage Patterns

### Catching All Template Errors

```python
from jinja2 import TemplateError

try:
    template.render()
except TemplateError as e:
    print(f"Template failed: {e.message}")
```

### Catching Loading Errors

```python
from jinja2 import TemplateNotFound, TemplatesNotFound

try:
    env.get_template("missing.html")
except TemplateNotFound as e:
    print(f"Could not find: {e.name}")
```

Because `TemplatesNotFound` subclasses `TemplateNotFound`, a single `except TemplateNotFound` clause handles both single and multi-template lookups.

### Catching Syntax Errors with Location

```python
from jinja2 import TemplateSyntaxError

try:
    env.from_string("{% for x in %}")
except TemplateSyntaxError as e:
    print(f"Syntax error on line {e.lineno}: {e.message}")
```

### Catching Runtime Errors

```python
from jinja2 import UndefinedError, SecurityError, FilterArgumentError

try:
    template.render()
except UndefinedError:
    ...
except SecurityError:
    ...
except FilterArgumentError:
    ...
```

## Summary

The `exceptions` module provides a clean, layered exception hierarchy that:

1. **Centralizes error types** under a single `TemplateError` base, enabling broad or narrow catching.
2. **Distinguishes compile-time from runtime failures** via the `TemplateSyntaxError` and `TemplateRuntimeError` branches.
3. **Integrates with Python's standard exceptions** (`IOError`, `LookupError`) for `TemplateNotFound`, easing interoperability.
4. **Cooperates with `Undefined`** through lazy imports to produce helpful messages without creating circular dependencies.
5. **Carries rich metadata** (`lineno`, `name`, `filename`, `source`, `templates`) to support precise diagnostics and traceback rewriting.

For details on where these exceptions are raised, see the related module documentation:

- [lexing_and_parsing.md](lexing_and_parsing.md) — `TemplateSyntaxError` from the lexer and parser
- [compilation_and_analysis.md](compilation_and_analysis.md) — `TemplateAssertionError` and compile-time errors
- [runtime_support_and_foundation.md](runtime_support_and_foundation.md) — `UndefinedError` and `Undefined`
- [template_environment_and_loading.md](template_environment_and_loading.md) — `TemplateNotFound`, `TemplatesNotFound`, and `SecurityError`
