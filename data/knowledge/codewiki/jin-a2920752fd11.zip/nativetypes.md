# Native Types Module

## Introduction

The `nativetypes` module extends Jinja's standard templating engine to render templates directly into **native Python types** instead of strings. While a regular Jinja template always produces a `str`, a native template can produce an `int`, `float`, `list`, `dict`, `tuple`, `bool`, `None`, or any other Python object that can be represented by a literal expression.

This is particularly useful when templates are used to generate configuration data, structured values, or any output that should be consumed programmatically rather than displayed as text.

The module is built on top of the core templating pipeline and only overrides the parts responsible for **output finalization** and **concatenation**:

- [`NativeCodeGenerator`](#nativecodegenerator) — a `CodeGenerator` subclass that avoids wrapping output nodes in `str()`.
- [`NativeEnvironment`](#nativeenvironment) — an `Environment` subclass that uses the native code generator and a native concatenation function.
- [`NativeTemplate`](#nativetemplate) — a `Template` subclass whose `render`/`render_async` methods return native Python values.
- [`native_concat`](#native_concat) — the helper that converts a stream of rendered nodes into a single native value.

> For the general templating pipeline (lexing, parsing, compilation, runtime), see the related module documentation: [environment](environment.md), [compiler](compiler.md), [runtime](runtime.md), and [nodes](nodes.md).

---

## Architecture Overview

The `nativetypes` module is a thin specialization layer over the standard Jinja environment. It reuses the entire lexing → parsing → compilation → runtime pipeline and only customizes the final output stage.

```mermaid
graph TD
    subgraph "Standard Jinja Pipeline"
        L[Lexer] --> P[Parser]
        P --> N[nodes.Template AST]
        N --> C[CodeGenerator]
        C --> CODE[Compiled Python code]
        CODE --> T[Template]
    end

    subgraph "nativetypes specialization"
        NCG[NativeCodeGenerator] -.extends.-> C
        NE[NativeEnvironment] -.extends.-> ENV[Environment]
        NT[NativeTemplate] -.extends.-> T
        NCONCAT[native_concat] -.replaces.-> CONCAT["''.join"]
    end

    NE -->|code_generator_class| NCG
    NE -->|concat| NCONCAT
    NE -->|template_class| NT
    NT -->|render| NCONCAT
```

### Key Design Principle

The standard `Environment` sets `concat = "".join` and the standard `CodeGenerator` wraps every output expression in `str(...)` (or `escape(...)`). The native variants invert both behaviors:

| Aspect | Standard Jinja | Native Types |
| --- | --- | --- |
| Output wrapping | `str(value)` / `escape(value)` | value passed through unchanged |
| Concatenation | `"".join(values)` | `native_concat(values)` |
| Render result | always `str` | native Python type when possible |
| Constant output repr | `repr(concat(group))` | `repr("".join(str(v) for v in group))` |

---

## Component Relationships

```mermaid
classDiagram
    class Environment {
        +code_generator_class
        +concat
        +template_class
        +is_async
    }
    class NativeEnvironment {
        +code_generator_class = NativeCodeGenerator
        +concat = native_concat
    }
    class Template {
        +environment_class
        +render()
        +render_async()
    }
    class NativeTemplate {
        +environment_class = NativeEnvironment
        +render()
        +render_async()
    }
    class CodeGenerator {
        +_default_finalize()
        +_output_const_repr()
        +_output_child_to_const()
        +_output_child_pre()
        +_output_child_post()
    }
    class NativeCodeGenerator {
        +_default_finalize()
        +_output_const_repr()
        +_output_child_to_const()
        +_output_child_pre()
        +_output_child_post()
    }

    Environment <|-- NativeEnvironment
    Template <|-- NativeTemplate
    CodeGenerator <|-- NativeCodeGenerator
    NativeEnvironment --> NativeCodeGenerator : uses
    NativeEnvironment --> NativeTemplate : creates
    NativeTemplate --> NativeEnvironment : environment_class
```

---

## Core Components

### `native_concat`

```python
def native_concat(values: t.Iterable[t.Any]) -> t.Optional[t.Any]
```

The central helper that converts an iterable of rendered output nodes into a single native Python value. It is assigned as the `concat` attribute of `NativeEnvironment`, replacing the default `"".join`.

**Algorithm:**

1. Pull the first two items from the iterable (`head`).
2. If the iterable is empty → return `None`.
3. If there is exactly **one** item:
   - If it is **not** a `str`, return it directly (preserving its native type, e.g. an `int` or `list`).
   - If it is a `str`, fall through to parsing.
4. If there are **multiple** items, re-chain the head with the remaining generator (if it is a `GeneratorType`) and join all items as strings.
5. Attempt to parse the resulting string with `ast.literal_eval` (via `ast.parse(..., mode="eval")`).
   - On success → return the parsed native value.
   - On `ValueError`, `SyntaxError`, or `MemoryError` → return the raw string.

> **Note on Python 3.10+:** `ast.literal_eval` strips leading spaces/tabs from the input string. To preserve backwards compatibility, `native_concat` calls `ast.parse(raw, mode="eval")` directly and passes the resulting AST to `literal_eval`, avoiding the stripping behavior.

```mermaid
flowchart TD
    A[values iterable] --> B[head = first 2 items]
    B --> C{head empty?}
    C -->|yes| D[return None]
    C -->|no| E{len head == 1?}
    E -->|yes| F{raw is str?}
    F -->|no| G[return raw as-is]
    F -->|yes| H[raw = head 0]
    E -->|no| I{values is GeneratorType?}
    I -->|yes| J[chain head + values]
    I -->|no| K[use values]
    J --> L[raw = join str of all]
    K --> L
    H --> M[literal_eval parse raw]
    L --> M
    M --> N{parse succeeds?}
    N -->|yes| O[return parsed value]
    N -->|no| P[return raw string]
```

---

### `NativeCodeGenerator`

```python
class NativeCodeGenerator(CodeGenerator)
```

A subclass of [`CodeGenerator`](compiler.md) that renders Python types by **not** adding `str()` around output nodes. It overrides the output-finalization hooks used by `visit_Output`.

| Method | Standard behavior | Native override |
| --- | --- | --- |
| `_default_finalize(value)` | `return str(value)` | `return value` (identity) |
| `_output_const_repr(group)` | `repr(concat(group))` | `repr("".join(str(v) for v in group))` |
| `_output_child_to_const(node, frame, finalize)` | escapes + finalizes constants | returns `const` for `TemplateData`, otherwise `finalize.const(const)`; raises `Impossible` if `has_safe_repr` fails |
| `_output_child_pre(node, frame, finalize)` | writes `str(` / `escape(` wrappers | writes only `finalize.src` if present |
| `_output_child_post(node, frame, finalize)` | writes closing `)` | writes only `)` if `finalize.src` is present |

**Why `has_safe_repr` matters:** When converting a constant child node at compile time, the generator checks [`has_safe_repr`](compiler.md) to ensure the value can be safely represented as a Python literal. If not, it raises `nodes.Impossible`, causing the node to be evaluated at runtime instead.

```mermaid
flowchart LR
    subgraph "Standard CodeGenerator"
        S1["str(value)"] --> S2["''.join(...)"]
    end
    subgraph "NativeCodeGenerator"
        N1["value (no str)"] --> N2["native_concat(...)"]
    end
```

---

### `NativeEnvironment`

```python
class NativeEnvironment(Environment):
    code_generator_class = NativeCodeGenerator
    concat = staticmethod(native_concat)
```

An [`Environment`](environment.md) subclass that renders templates to native Python types. It wires together the native code generator and the native concatenation function. All other environment configuration (loaders, filters, tests, autoescape, async mode, etc.) is inherited unchanged.

Because `concat` is set as a `staticmethod`, it can be called as `environment.concat(values)` without binding `self`, matching the call sites generated by the compiler (`concat = environment.concat`).

---

### `NativeTemplate`

```python
class NativeTemplate(Template):
    environment_class = NativeEnvironment
```

A [`Template`](environment.md) subclass whose render methods return native Python values.

#### `render(*args, **kwargs) -> t.Any`

Renders the template and returns a native Python type. It:

1. Builds a new context via `new_context(dict(*args, **kwargs))`.
2. Calls `self.environment_class.concat(self.root_render_func(ctx))`.
3. On exception, delegates to `self.environment.handle_exception()`.

Unlike the standard `Template.render`, which returns `str`, this returns whatever `native_concat` produces.

#### `render_async(*args, **kwargs) -> t.Any`

The async counterpart. It:

1. Raises `RuntimeError` if the environment was not created with async mode enabled.
2. Builds a new context.
3. Collects all async events into a list and passes them to `native_concat`.

#### Class registration

At the bottom of the module:

```python
NativeEnvironment.template_class = NativeTemplate
```

This ensures that `NativeEnvironment` creates `NativeTemplate` instances (e.g. via `from_string` or `get_template`), completing the wiring between the environment and template classes.

---

## Data Flow

The following diagram shows how a native template flows from source to a native Python value.

```mermaid
sequenceDiagram
    participant User
    participant NE as NativeEnvironment
    participant NCG as NativeCodeGenerator
    participant NT as NativeTemplate
    participant NC as native_concat

    User->>NE: from_string(source)
    NE->>NCG: generate code (no str wrapping)
    NCG-->>NE: compiled code
    NE->>NT: from_code(...)
    User->>NT: render(**context)
    NT->>NT: new_context(...)
    NT->>NT: root_render_func(ctx)
    NT->>NC: concat(rendered nodes)
    NC->>NC: literal_eval / join
    NC-->>NT: native Python value
    NT-->>User: int / list / dict / str / None
```

---

## Usage Example

```python
from jinja2.nativetypes import NativeEnvironment

env = NativeEnvironment()

# Single expression -> native type preserved
t = env.from_string("{{ 1 + 2 }}")
assert t.render() == 3          # int, not "3"

# Literal-looking string -> parsed to native type
t = env.from_string("{{ '[1, 2, 3]' }}")
assert t.render() == [1, 2, 3]  # list

# Multiple nodes -> joined then parsed
t = env.from_string("{{ '1' }}{{ '2' }}")
assert t.render() == 12         # int

# Non-parseable output -> returned as string
t = env.from_string("{{ 'hello' }}")
assert t.render() == "hello"    # str
```

---

## Integration with the Broader System

```mermaid
graph TD
    NT[nativetypes] --> ENV[environment]
    NT --> COMP[compiler]
    NT --> NODES[nodes]
    NT --> RT[runtime]

    ENV --> LEX[lexer]
    ENV --> PARSE[parser]
    COMP --> OPT[optimizer]
    COMP --> IDT[idtracking]
    RT --> EXC[exceptions]
    RT --> UTILS[utils]
```

- **environment** — `NativeEnvironment` and `NativeTemplate` extend `Environment` and `Template`. See [environment](environment.md).
- **compiler** — `NativeCodeGenerator` extends `CodeGenerator` and reuses `Frame`, `has_safe_repr`, and the `_FinalizeInfo` mechanism. See [compiler](compiler.md).
- **nodes** — uses `nodes.Expr`, `nodes.TemplateData`, and `nodes.Impossible` during constant folding. See [nodes](nodes.md).
- **runtime** — the generated code relies on the runtime `Context`, `Undefined`, and `concat` helpers. See [runtime](runtime.md).

---

## Summary

The `nativetypes` module provides a minimal, focused extension of Jinja that changes only the output stage of the pipeline:

1. **`NativeCodeGenerator`** stops wrapping output in `str()`.
2. **`native_concat`** converts the rendered node stream into a native Python value using `ast.literal_eval`.
3. **`NativeEnvironment`** and **`NativeTemplate`** wire these together while inheriting all other behavior from the standard environment and template.

This design keeps the module small and maintainable, relying on the existing lexing, parsing, compilation, and runtime infrastructure documented in the related modules.
