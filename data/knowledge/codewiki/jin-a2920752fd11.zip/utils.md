# Utils Module

## Introduction

The `utils` module (`src/jinja2/utils.py`) provides a collection of foundational helper utilities that are shared across the entire Jinja2 templating engine. It sits within the **runtime support and foundation** layer of the architecture and supplies:

- **Template-facing helper objects** exposed directly to templates (`Cycler`, `Joiner`, `Namespace`).
- **Internal caching primitives** used by the environment and loaders (`LRUCache`).
- **Decorator metadata** that drives how the runtime injects context into filters, tests, and functions (`_PassArg` and the `pass_context` / `pass_eval_context` / `pass_environment` decorators).
- **General-purpose helpers** such as `import_string`, `urlize`, `select_autoescape`, `htmlsafe_json_dumps`, `generate_lorem_ipsum`, and `url_quote`.

Because these utilities are consumed by nearly every other module, this module is a low-level dependency with very few dependencies of its own (only `markupsafe` and the standard library at import time, plus lazy imports of `runtime`, `environment`, and `lexer`).

---

## Architecture and Position in the System

The `utils` module is part of the **runtime support and foundation** group. It is depended upon by the environment, runtime, filters, and extensions layers, but it depends on almost nothing itself.

```mermaid
graph TD
    subgraph "Runtime Support & Foundation"
        UTILS["utils.py<br/>(Cycler, Joiner, LRUCache,<br/>Namespace, _PassArg)"]
        RUNTIME["runtime.py<br/>(Context, Undefined, Macro)"]
        EXC["exceptions.py"]
    end

    subgraph "Template Environment & Loading"
        ENV["environment.py<br/>(Environment, Template)"]
        LOADERS["loaders.py"]
        BCCACHE["bccache.py"]
    end

    subgraph "Lexing & Parsing"
        LEXER["lexer.py"]
    end

    subgraph "Extensions & Filters"
        EXT["ext.py"]
        FILTERS["filters.py"]
    end

    ENV -->|uses LRUCache, select_autoescape,<br/>htmlsafe_json_dumps, _PassArg| UTILS
    RUNTIME -->|uses _PassArg, missing,<br/>object_type_repr, internalcode| UTILS
    FILTERS -->|uses urlize, htmlsafe_json_dumps,<br/>pass_* decorators| UTILS
    EXT -->|uses pass_* decorators,<br/>import_string| UTILS
    LOADERS -->|uses LRUCache| UTILS
    BCCACHE -->|uses LRUCache| UTILS
    LEXER -->|uses internalcode| UTILS

    UTILS -.->|lazy import| RUNTIME
    UTILS -.->|lazy import| ENV
    UTILS -.->|lazy import| LEXER
```

### Key Design Notes

- **Lazy imports**: To avoid circular imports, `utils` imports `runtime`, `environment`, and `lexer` *inside* function bodies (e.g., `is_undefined`, `clear_caches`). This keeps the module importable at the very bottom of the dependency graph.
- **`markupsafe` dependency**: The module relies on `markupsafe` for HTML escaping and the `Markup` safe-string type, which is central to autoescaping behavior.

---

## Core Components

### `_PassArg` (enum)

`_PassArg` is an `enum.Enum` that encodes *which* runtime object should be injected as the first argument when a callable is invoked during template rendering.

| Member | Injected first argument |
| --- | --- |
| `context` | The active `Context` (see [runtime.md](runtime.md)) |
| `eval_context` | The active `EvalContext` |
| `environment` | The active `Environment` (see [environment.md](environment.md)) |

The class method `from_obj(obj)` inspects an object for a `jinja_pass_arg` attribute and returns the corresponding `_PassArg` member (or `None`). This is the mechanism that the runtime's `Context.call` and the environment's `_filter_test_common` use to decide how to invoke filters, tests, and functions.

```mermaid
classDiagram
    class _PassArg {
        <<enum>>
        context
        eval_context
        environment
        +from_obj(obj) Optional~_PassArg~
    }
    class Cycler {
        +items
        +pos
        +reset()
        +current
        +next()
    }
    class Joiner {
        +sep
        +used
        +__call__()
    }
    class Namespace {
        +__getattribute__(name)
        +__setitem__(name, value)
    }
    class LRUCache {
        +capacity
        +get(key, default)
        +setdefault(key, default)
        +clear()
        +copy()
    }
```

### `Cycler`

`Cycler` cycles through a fixed set of values, yielding one at a time and restarting once the end is reached. It is exposed to templates as the `cycler` global and is useful for alternating values across multiple loops (unlike `loop.cycle`, which is scoped to a single loop).

- **Constructor**: `Cycler(*items)` — raises `RuntimeError` if no items are provided.
- **`reset()`**: Resets the position to the first item.
- **`current`** (property): Returns the item that will be returned by the next `next()` call.
- **`next()`** (aliased as `__next__`): Returns the current item and advances the position modulo the number of items.

**Example (template usage):**

```jinja
{% set row_class = cycler("odd", "even") %}
<ul class="browser">
{% for folder in folders %}
  <li class="folder {{ row_class.next() }}">{{ folder }}
{% endfor %}
{% for file in files %}
  <li class="file {{ row_class.next() }}">{{ file }}
{% endfor %}
</ul>
```

### `Joiner`

`Joiner` is a small helper that returns an empty string on its first call and a separator string on every subsequent call. It is exposed to templates as the `joiner` global and is commonly used to insert separators between items without trailing separators.

- **Constructor**: `Joiner(sep=", ")`.
- **`__call__()`**: Returns `""` the first time, then `sep` thereafter.

### `Namespace`

`Namespace` is a mutable object that holds arbitrary attributes. It can be initialized from a dictionary or with keyword arguments and is exposed to templates as the `namespace` global. It is typically used to carry state across `{% set %}` assignments inside loops or macros.

- **Constructor**: `Namespace(*args, **kwargs)` — accepts a dict positionally and/or keyword arguments.
- **`__getattribute__(name)`**: Resolves attribute access against the internal `__attrs` dict, raising `AttributeError` for missing names. `__class__` and the internal attribute name are special-cased (the former is needed for the async awaitable check).
- **`__setitem__(name, value)`**: Sets an attribute in the internal dict.
- **`__repr__`**: Returns `<Namespace {...}>`.

### `LRUCache`

`LRUCache` is a simple Least-Recently-Used cache implementation registered as a `collections.abc.MutableMapping`. It is used by the environment to cache compiled templates and by the bytecode cache layer. It is optimized for small capacities (below ~1000 entries).

Internally it maintains:
- `_mapping`: a dict of key → value.
- `_queue`: a `deque` tracking usage order (most recently used at the right).
- `_wlock`: a `threading.Lock` guarding mutations.

| Method | Behavior |
| --- | --- |
| `get(key, default=None)` | Returns the value or `default`. |
| `setdefault(key, default=None)` | Returns existing value or inserts and returns `default`. |
| `clear()` | Empties the cache (thread-safe). |
| `copy()` / `__copy__` | Returns a shallow copy. |
| `__getitem__(key)` | Returns value and promotes the key to most-recently-used. |
| `__setitem__(key, value)` | Inserts/updates and promotes; evicts the LRU entry when at capacity. |
| `__delitem__(key)` | Removes a key. |
| `__contains__`, `__len__`, `__iter__`, `__reversed__` | Mapping protocol support. |
| `items()`, `values()`, `keys()` | Ordered by most recent usage. |

It also implements `__getstate__`, `__setstate__`, and `__getnewargs__` to support pickling (re-establishing the lock and queue aliases via `_postinit`).

```mermaid
flowchart TD
    A["__setitem__(key, value)"] --> B{"key in _mapping?"}
    B -- Yes --> C["_remove(key) from queue"]
    B -- No --> D{"len == capacity?"}
    D -- Yes --> E["evict _popleft() from mapping"]
    D -- No --> F["continue"]
    C --> G["_append(key) to queue"]
    E --> G
    F --> G
    G --> H["_mapping[key] = value"]
```

---

## Supporting Utilities

Beyond the core components, the module provides a number of helper functions used throughout Jinja2:

| Function | Purpose |
| --- | --- |
| `pass_context` / `pass_eval_context` / `pass_environment` | Decorators that tag a callable with a `jinja_pass_arg` attribute so the runtime injects the appropriate object. |
| `internalcode` | Marks a function's code object as internal (tracked in `internal_code`). |
| `is_undefined(obj)` | Convenience wrapper around an `isinstance` check against `Undefined` (see [runtime.md](runtime.md)). |
| `consume(iterable)` | Exhausts an iterable without using its values. |
| `clear_caches()` | Clears the spontaneous-environment and lexer caches. |
| `import_string(name, silent=False)` | Imports an object from a dotted or colon-delimited path. |
| `open_if_exists(filename, mode)` | Opens a file if it exists, else returns `None`. |
| `object_type_repr(obj)` | Returns a readable type name (used by `Undefined` error messages). |
| `pformat(obj)` | Wraps `pprint.pformat`. |
| `urlize(...)` | Converts URLs and emails in text into clickable links. |
| `generate_lorem_ipsum(...)` | Generates lorem ipsum text for templates. |
| `url_quote(obj, charset, for_qs)` | Quotes a string for use in a URL. |
| `select_autoescape(...)` | Builds an autoescape callable based on template filename extensions. |
| `htmlsafe_json_dumps(obj, dumps, **kwargs)` | Serializes to JSON and escapes HTML-unsafe characters, returning `Markup`. |

### `select_autoescape` and `htmlsafe_json_dumps`

These two functions are tightly coupled to the [environment](environment.md) and [filters](filters.md) modules:

- `select_autoescape` is the recommended way to configure the `Environment.autoescape` parameter. It returns a callable that decides autoescaping based on the template name's extension (case-insensitive).
- `htmlsafe_json_dumps` backs the `|tojson` filter. It escapes `<`, `>`, `&`, and `'` into Unicode escapes and wraps the result in `markupsafe.Markup`.

---

## Data Flow: Context Injection via `_PassArg`

The following sequence shows how `_PassArg` metadata (set by the `pass_*` decorators) flows through the runtime to inject the correct object into a filter/test/function call.

```mermaid
sequenceDiagram
    participant Dev as Developer
    participant Dec as pass_context decorator
    participant Fn as Filter/Test/Function
    participant Env as Environment._filter_test_common
    participant Ctx as Context.call

    Dev->>Dec: @pass_context
    Dec->>Fn: sets fn.jinja_pass_arg = _PassArg.context
    Note over Env: During rendering
    Env->>Fn: _PassArg.from_obj(fn)
    Fn-->>Env: _PassArg.context
    Env->>Fn: fn(context, value, ...)
    Note over Ctx: For callables invoked in templates
    Ctx->>Fn: _PassArg.from_obj(fn)
    Fn-->>Ctx: _PassArg.context
    Ctx->>Fn: fn(derived_context, ...)
```

---

## Dependencies

```mermaid
graph LR
    UTILS["utils.py"]
    UTILS --> MS["markupsafe"]
    UTILS --> STD["stdlib:<br/>enum, json, os, re,<br/>collections, random,<br/>threading, urllib"]
    UTILS -.->|lazy| RUNTIME["runtime.py"]
    UTILS -.->|lazy| ENV["environment.py"]
    UTILS -.->|lazy| LEXER["lexer.py"]
    UTILS -.->|lazy| CONST["constants.py"]
```

- **`markupsafe`**: Used for `escape`, `Markup`, and safe-string handling.
- **Standard library**: `enum`, `json`, `os`, `re`, `collections.abc`, `collections.deque`, `random`, `threading`, `types`, `urllib.parse`.
- **Lazy internal imports**: `runtime.Undefined`, `environment.get_spontaneous_environment`, `lexer._lexer_cache`, and `constants.LOREM_IPSUM_WORDS` are imported inside functions to break circular dependencies.

---

## Related Modules

- [runtime.md](runtime.md) — `Context`, `Undefined`, and the runtime that consumes `_PassArg`, `missing`, and `object_type_repr`.
- [environment.md](environment.md) — `Environment` uses `LRUCache`, `select_autoescape`, `htmlsafe_json_dumps`, and `_PassArg`.
- [lexer.md](lexer.md) — Uses `internalcode` and participates in `clear_caches`.
- [filters.md](filters.md) — Uses `urlize`, `htmlsafe_json_dumps`, and the `pass_*` decorators.
- [extensions.md](extensions.md) — Uses `import_string` and the `pass_*` decorators.
- [bytecode_cache.md](bytecode_cache.md) — Uses `LRUCache` for caching compiled bytecode.
