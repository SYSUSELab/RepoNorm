# Runtime Support and Foundation

## Introduction

The **runtime** module (`src/jinja2/runtime.py`) provides the runtime functions and state that compiled Jinja templates depend on during execution. While the [compilation and analysis](compilation_and_analysis.md) module transforms the parsed template AST into Python code, that generated code does not stand alone — it imports and calls into a set of runtime primitives defined here.

This module is the bridge between *generated template code* and the *template engine's data model*. It supplies:

- **`Context`** — the immutable variable scope passed through template evaluation.
- **`Undefined`** and its variants — the sentinel objects used for missing variables.
- **`LoopContext` / `AsyncLoopContext`** — the `loop` object available inside `{% for %}` blocks.
- **`Macro`** — the wrapper around compiled macro functions.
- **`TemplateReference` / `BlockReference`** — the `self` object and block-super machinery used by template inheritance.
- **Join helpers** (`markup_join`, `str_join`, `identity`) and the `new_context` factory.

Together with the [exceptions](exceptions.md) and [utils](utils.md) modules (its sibling components under *runtime_support_and_foundation*), it forms the foundation that every rendered template relies on.

---

## Architecture Overview

The runtime module sits at the bottom of the template evaluation stack. Compiled templates are essentially Python functions that receive a `Context` and call into these runtime objects.

```mermaid
graph TD
    subgraph "Compilation & Analysis"
        CG[CodeGenerator]
    end

    subgraph "Runtime Support and Foundation"
        RT[runtime.py]
        EX[exceptions.py]
        UT[utils.py]
    end

    subgraph "Lexing & Parsing"
        ND[nodes.py: EvalContext]
    end

    subgraph "Environment & Loading"
        ENV[environment.py: Environment]
    end

    CG -->|generates code that imports| RT
    RT -->|raises| EX
    RT -->|uses helpers| UT
    RT -->|holds| ND
    ENV -->|creates Context via context_class| RT
    RT -->|references| ENV
```

### Key Relationships

| Runtime Component | Depends On | Used By |
|-------------------|-----------|---------|
| `Context` | `Environment`, `EvalContext`, `_PassArg` | Generated template code, filters/tests via `pass_context` |
| `Undefined` family | `UndefinedError`, `object_type_repr` | `Context.resolve`, generated code |
| `LoopContext` | `Undefined`, `LoopRenderFunc` | Generated `{% for %}` code |
| `Macro` | `Environment`, `EvalContext`, `pass_eval_context` | Generated `{% macro %}` code |
| `TemplateReference` / `BlockReference` | `Context` | Generated inheritance code |
| `new_context` | `Environment.context_class` | `Environment` internals |

---

## Core Components

### Context

`Context` is the central runtime object. It is registered as an `abc.Mapping` and holds all variables visible to a template at a given point in evaluation.

**Design constraints:**

- The context is **immutable** from the perspective of filters and global functions. Modifications to `parent` must not happen; only generated template code may write to `vars`.
- It supports read-only dict operations (`get`, `keys`, `values`, `items`, `__getitem__`, `__contains__`).
- `resolve()` never raises `KeyError`; it returns an `Undefined` object for missing variables.

**Key methods:**

| Method | Purpose |
|--------|---------|
| `resolve(key)` | Look up a variable, returning `Undefined` if missing. |
| `resolve_or_missing(key)` | The overridable lookup hook; returns the `missing` sentinel. |
| `get(key, default)` | Dict-style lookup with a default. |
| `get_all()` | Return the full context as a dict (may not be a copy). |
| `get_exported()` | Return only exported variables. |
| `call(obj, *args, **kwargs)` | Invoke a callable, injecting context/eval-context/environment based on `_PassArg`. |
| `derived(locals)` | Create an independent derived context (used for loops/blocks). |
| `super(name, current)` | Return a `BlockReference` to the parent block. |

The `call` method is the mechanism behind `pass_context`, `pass_eval_context`, and `pass_environment`. It inspects the callable's `jinja_pass_arg` attribute (via `_PassArg.from_obj`) and prepends the appropriate object to the argument list. It also handles `_loop_vars` and `_block_vars` by deriving a new context, and converts a `StopIteration` raised by the callable into an `Undefined`.

```mermaid
flowchart TD
    A[Context.call obj, args] --> B{obj has jinja_pass_arg?}
    B -->|context| C[Derive context if loop/block vars]
    C --> D[Prepend context to args]
    B -->|eval_context| E[Prepend eval_ctx]
    B -->|environment| F[Prepend environment]
    B -->|none| G[No injection]
    D --> H[Invoke obj]
    E --> H
    F --> H
    G --> H
    H --> I{StopIteration?}
    I -->|yes| J[Return Undefined]
    I -->|no| K[Return result]
```

### new_context

`new_context` is the internal factory used to build `Context` instances. It resolves the `parent` mapping (either the shared `vars` dict or a merged globals+vars dict), applies `locals`, and delegates to `environment.context_class`. This indirection allows environments to substitute custom context classes.

### TemplateReference and BlockReference

`TemplateReference` is the object bound to `self` inside templates. Indexing it (`self["blockname"]`) returns a `BlockReference`.

`BlockReference` represents one block on a template reference and implements the inheritance chain. Its `super` property walks up the block stack, and calling it renders the block body. It supports both sync (`__call__`) and async (`_async_call`) rendering, applying autoescaping based on the active `EvalContext`.

```mermaid
sequenceDiagram
    participant T as Template (self)
    participant TR as TemplateReference
    participant BR as BlockReference
    participant C as Context

    T->>TR: self["content"]
    TR->>C: context.blocks["content"]
    TR-->>BR: BlockReference(name, ctx, stack, 0)
    T->>BR: call()
    BR->>C: render stack[depth](ctx)
    C-->>BR: iterator of strings
    BR-->>T: concatenated (Markup if autoescape)
    T->>BR: super
    BR-->>T: BlockReference(depth+1)
```

### LoopContext and AsyncLoopContext

`LoopContext` wraps an iterable to provide the `loop` variable inside `{% for %}` blocks. It exposes the standard Jinja loop attributes:

| Attribute | Description |
|-----------|-------------|
| `index0` / `index` | Current iteration (0-based / 1-based). |
| `revindex0` / `revindex` | Iterations from the end. |
| `first` / `last` | Whether this is the first/last iteration. |
| `length` | Total length (eagerly evaluated for generators). |
| `depth` / `depth0` | Recursion depth. |
| `previtem` / `nextitem` | Adjacent items (Undefined at boundaries). |
| `cycle(*args)` | Cycle through values by `index0`. |
| `changed(*value)` | Detect value changes between iterations. |

The `last` and `nextitem` properties use `_peek_next`, which advances the iterator one item ahead and caches the result in `_after`. This early advancement is why the `groupby` filter has special handling (see [extensions and filters](extensions_and_filters.md)).

`AsyncLoopContext` subclasses `LoopContext` and overrides the iterator machinery to work with async iterables via `auto_aiter`. Its `length`, `revindex0`, `revindex`, `last`, and `nextitem` become coroutines/async properties.

```mermaid
classDiagram
    class LoopContext {
        +index0
        +length
        +depth
        +index
        +revindex0
        +revindex
        +first
        +last
        +previtem
        +nextitem
        +cycle()
        +changed()
        +__next__()
        +__call__()
    }
    class AsyncLoopContext {
        +length (async)
        +revindex0 (async)
        +revindex (async)
        +last (async)
        +nextitem (async)
        +__anext__()
    }
    LoopContext <|-- AsyncLoopContext
```

### Macro

`Macro` wraps a compiled macro function. It handles:

- **Argument binding** — positional args are consumed first, then keyword args and defaults fill the remainder.
- **The special `caller` argument** — appended in a fixed order (caller, keyword args, positional args) that must match the compiler's `function_scoping` method.
- **`catch_kwargs` / `catch_varargs`** — whether the macro accepts `**kwargs` / `*args`.
- **Autoescape resolution** — determined at *call time* from the passed `EvalContext`, falling back to the compile-time `default_autoescape`. This is important because a macro's safety depends on where it is *used*, not where it was *defined*.

`Macro.__call__` is decorated with `@pass_eval_context`, so the active `EvalContext` is injected as the first argument when called during rendering. It supports both sync (`_invoke`) and async (`_async_invoke`) execution.

### Undefined and Variants

The `Undefined` class is the default sentinel for missing variables. It can be printed (as an empty string) and iterated (yielding nothing), but any other operation raises an `UndefinedError`.

```mermaid
classDiagram
    class Undefined {
        +_undefined_hint
        +_undefined_obj
        +_undefined_name
        +_undefined_exception
        +_undefined_message
        +_fail_with_undefined_error()
        +__str__() ""
        +__bool__() False
        +__iter__() empty
    }
    class ChainableUndefined {
        +__getattr__() self
        +__getitem__() self
    }
    class DebugUndefined {
        +__str__() debug info
    }
    class StrictUndefined {
        +__str__() raises
        +__iter__() raises
        +__bool__() raises
    }
    Undefined <|-- ChainableUndefined
    Undefined <|-- DebugUndefined
    Undefined <|-- StrictUndefined
```

| Variant | Behavior |
|---------|----------|
| `Undefined` | Default. Printable/iterable; other ops raise. |
| `ChainableUndefined` | `__getattr__` and `__getitem__` return `self`, allowing `foo.bar['baz']` chains. |
| `DebugUndefined` | Prints debug info like `{{ foo }}` instead of an empty string. |
| `StrictUndefined` | Raises on print, iteration, boolean tests, and comparisons. |

The `_undefined_message` property builds a context-aware error message based on how the value was accessed (missing name, missing attribute, or missing element).

#### make_logging_undefined

`make_logging_undefined(logger, base)` is a factory that returns a new `Undefined` subclass which logs warnings on print/iteration/boolean tests and logs errors before raising. This is used by the `DebugExtension` (see [extensions and filters](extensions_and_filters.md)).

### Join Helpers

| Function | Purpose |
|----------|---------|
| `identity(x)` | Returns its argument unchanged. |
| `markup_join(seq)` | Concatenates, escaping if any element has `__html__`. |
| `str_join(seq)` | Converts all elements to strings and concatenates. |

These are exported into the template runtime namespace and used by generated code for output concatenation.

### Exported Names

The module defines two export lists that are injected into the template runtime namespace:

- `exported` — `LoopContext`, `TemplateReference`, `Macro`, `Markup`, `TemplateRuntimeError`, `missing`, `escape`, `markup_join`, `str_join`, `identity`, `TemplateNotFound`, `Namespace`, `Undefined`, `internalcode`.
- `async_exported` — `AsyncLoopContext`, `auto_aiter`, `auto_await`.

---

## Data Flow During Template Rendering

The following diagram shows how the runtime components participate in a typical render cycle.

```mermaid
flowchart LR
    ENV[Environment.get_template] --> NC[new_context]
    NC --> CTX[Context]
    CTX --> GEN[Generated template code]
    GEN -->|resolve vars| CTX
    GEN -->|for loops| LC[LoopContext]
    GEN -->|macros| MC[Macro]
    GEN -->|inheritance| TR[TemplateReference]
    TR --> BR[BlockReference]
    GEN -->|missing vars| UD[Undefined]
    UD -->|invalid op| ERR[UndefinedError]
    LC -->|recursive| LRF[LoopRenderFunc]
    MC -->|autoescape| EC[EvalContext]
    BR -->|autoescape| EC
```

---

## Async Support

The runtime module provides parallel async implementations throughout:

- `AsyncLoopContext` mirrors `LoopContext` for async iterables.
- `BlockReference._async_call` renders blocks asynchronously.
- `Macro._async_invoke` awaits async macro functions.
- `Context.call` works with both sync and async callables (the async path is handled by the generated code and `auto_await`).

The `auto_aiter` and `auto_await` helpers from `async_utils` normalize sync/async inputs, allowing the same runtime objects to serve both execution modes.

---

## Related Modules

- **[exceptions](exceptions.md)** — Defines `UndefinedError`, `TemplateRuntimeError`, and the exception hierarchy raised by runtime operations.
- **[utils](utils.md)** — Provides `_PassArg`, `internalcode`, `missing`, `object_type_repr`, `pass_eval_context`, and other helpers used throughout the runtime.
- **[compilation and analysis](compilation_and_analysis.md)** — The `CodeGenerator` produces the code that imports and calls these runtime primitives.
- **[lexing and parsing](lexing_and_parsing.md)** — Defines `EvalContext` (in `nodes.py`), which the runtime holds and passes to macros and blocks.
- **[environment and loading](template_environment_and_loading.md)** — The `Environment` creates `Context` instances and selects the `undefined` class used by `Context.resolve`.
- **[extensions and filters](extensions_and_filters.md)** — Extensions such as `DebugExtension` build on `make_logging_undefined`; filters interact with `LoopContext` and `Context`.
