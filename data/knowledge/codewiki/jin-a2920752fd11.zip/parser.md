# Parser Module

## Introduction

The `parser` module (`src/jinja2/parser.py`) is the central component of Jinja's
**lexing and parsing** stage. It consumes the flat stream of tokens produced by
the [lexer](lexer.md) and transforms them into a structured **Abstract Syntax
Tree (AST)** composed of [node](nodes.md) objects. This AST is the canonical
intermediate representation that the
[compilation and analysis](compiler.md) stage later turns into executable Python
code.

The module exposes a single public class, `Parser`, which is instantiated by the
[`Environment`](environment.md) whenever a template source needs to be parsed
(e.g. via `Environment.parse`, `Environment.compile`, or
`Environment.compile_expression`).

---

## Purpose and Core Functionality

The `Parser` class is responsible for:

1. **Token consumption** — It wraps the environment's `TokenStream` and walks
   through tokens one at a time, using lookahead and backtracking helpers.
2. **Statement parsing** — It recognizes Jinja statement keywords (`for`, `if`,
   `block`, `extends`, `macro`, `set`, `with`, `autoescape`, `include`,
   `import`, `from`, `print`, `call`, `filter`) and dispatches to dedicated
   `parse_*` methods.
3. **Expression parsing** — It implements a full recursive-descent expression
   grammar (conditional expressions, boolean logic, comparisons, arithmetic,
   concatenation, power, unary, primary, postfix, filters, and tests).
4. **Node construction** — It builds `nodes.*` instances (e.g. `nodes.For`,
   `nodes.If`, `nodes.Filter`) carrying line numbers and context information.
5. **Extension integration** — It exposes registered extension tags so custom
   tags can be parsed by extensions.
6. **Error reporting** — It produces human-readable `TemplateSyntaxError` and
   `TemplateAssertionError` messages with line numbers, names, and filenames.

---

## Architecture

The parser sits between the lexer and the compiler in the template processing
pipeline. It is the bridge that converts a linear token stream into a tree.

```mermaid
flowchart LR
    subgraph Environment
        E[Environment]
    end
    E -->|_tokenize| L[Lexer]
    L -->|TokenStream| P[Parser]
    P -->|nodes.Template AST| C[Compiler / CodeGenerator]
    P -.uses.-> N[nodes module]
    P -.uses.-> X[exceptions]
    P -.uses.-> EX[Extensions]
```

### Component Relationships

```mermaid
classDiagram
    class Parser {
        +Environment environment
        +TokenStream stream
        +str name
        +str filename
        +bool closed
        +dict extensions
        +parse() Template
        +parse_statement() Node
        +parse_statements(end_tokens, drop_needle) list
        +subparse(end_tokens) list
        +parse_expression(with_condexpr) Expr
        +parse_tuple(...) Tuple|Expr
        +parse_assign_target(...) NSRef|Name|Tuple
        +fail(msg, lineno, exc)
        +fail_unknown_tag(name, lineno)
        +fail_eof(end_tokens, lineno)
    }
    class TokenStream {
        +Token current
        +next()
        +look() Token
        +skip(n)
        +skip_if(expr) bool
        +expect(expr) Token
        +push(token)
    }
    class Node {
        +int lineno
        +Environment environment
        +set_ctx(ctx)
        +set_environment(env)
    }
    class Environment {
        +_tokenize(source, name, filename, state) TokenStream
        +iter_extensions() Iterator
    }
    Parser --> TokenStream : consumes
    Parser --> Node : constructs
    Parser --> Environment : configured by
```

---

## Initialization and Dependencies

The `Parser` constructor wires together the environment, the token stream, and
the set of extension tags:

```python
def __init__(self, environment, source, name=None, filename=None, state=None):
    self.environment = environment
    self.stream = environment._tokenize(source, name, filename, state)
    ...
    for extension in environment.iter_extensions():
        for tag in extension.tags:
            self.extensions[tag] = extension.parse
```

Key points:

- **`environment._tokenize`** performs preprocessing (via extensions) and
  lexing, returning a `TokenStream`. See [lexer](lexer.md) and
  [environment](environment.md) for details.
- **`state`** allows parsing a fragment in `"variable"` or `"block"` mode,
  which is used by `Environment.compile_expression`.
- **Extension tags** are collected into `self.extensions`, mapping a tag name
  to the extension's `parse` callable. See [extensions](extensions.md).

### Internal State

| Attribute | Purpose |
|-----------|---------|
| `_last_identifier` | Counter for generating unique `InternalName` nodes (`fi1`, `fi2`, ...). |
| `_tag_stack` | Stack of currently open statement tags, used for error messages. |
| `_end_token_stack` | Stack of expected end-token tuples for nested constructs. |
| `closed` | Flag indicating the parser has finished. |

---

## Parsing Flow

The top-level entry point is `parse()`, which delegates to `subparse()` and
wraps the result in a `nodes.Template`.

```mermaid
flowchart TD
    A[parse] --> B[subparse]
    B --> C{token type?}
    C -->|data| D[TemplateData node]
    C -->|variable_begin| E[parse_tuple -> Output]
    C -->|block_begin| F{end token?}
    F -->|yes| G[return body]
    F -->|no| H[parse_statement]
    H --> I{keyword?}
    I -->|statement keyword| J[parse_&lt;keyword&gt;]
    I -->|call/filter| K[parse_call_block / parse_filter_block]
    I -->|extension tag| L[extension.parse]
    I -->|unknown| M[fail_unknown_tag]
    J --> N[append node to body]
    K --> N
    L --> N
    N --> C
    D --> C
    E --> C
    B --> O[nodes.Template]
```

### Statement Dispatch

`parse_statement()` inspects the current token and routes to the appropriate
handler:

```mermaid
flowchart LR
    S[parse_statement] --> K{token.value}
    K -->|in _statement_keywords| A[getattr self parse_&lt;value&gt;]
    K -->|call| B[parse_call_block]
    K -->|filter| C[parse_filter_block]
    K -->|in extensions| D[extension.parse]
    K -->|otherwise| E[fail_unknown_tag]
```

The `_statement_keywords` set contains: `for`, `if`, `block`, `extends`,
`print`, `macro`, `include`, `from`, `import`, `set`, `with`, `autoescape`.

---

## Expression Grammar

Expression parsing is implemented as a classic recursive-descent precedence
chain. Each level calls the next-higher-precedence level, building nodes as it
goes.

```mermaid
flowchart TD
    E[parse_expression] --> CE[parse_condexpr]
    CE --> OR[parse_or]
    OR --> AND[parse_and]
    AND --> NOT[parse_not]
    NOT --> CMP[parse_compare]
    CMP --> M1[parse_math1]
    M1 --> CONCAT[parse_concat]
    CONCAT --> M2[parse_math2]
    M2 --> POW[parse_pow]
    POW --> UN[parse_unary]
    UN --> PRI[parse_primary]
    PRI --> POST[parse_postfix]
    POST --> FILT[parse_filter_expr]
```

| Method | Handles | Produces |
|--------|---------|----------|
| `parse_condexpr` | `a if b else c` | `nodes.CondExpr` |
| `parse_or` | `or` | `nodes.Or` |
| `parse_and` | `and` | `nodes.And` |
| `parse_not` | `not` | `nodes.Not` |
| `parse_compare` | `==`, `!=`, `<`, `in`, `not in`, ... | `nodes.Compare` / `nodes.Operand` |
| `parse_math1` | `+`, `-` | `nodes.Add` / `nodes.Sub` |
| `parse_concat` | `~` | `nodes.Concat` |
| `parse_math2` | `*`, `/`, `//`, `%` | `nodes.Mul` / `nodes.Div` / `nodes.FloorDiv` / `nodes.Mod` |
| `parse_pow` | `**` | `nodes.Pow` |
| `parse_unary` | unary `-`, `+` | `nodes.Neg` / `nodes.Pos` |
| `parse_primary` | literals, names, `(...)`, `[...]`, `{...}` | `nodes.Const`, `nodes.Name`, `nodes.Tuple`, `nodes.List`, `nodes.Dict` |
| `parse_postfix` | `.attr`, `[index]`, `(...)` | `nodes.Getattr`, `nodes.Getitem`, `nodes.Call` |
| `parse_filter_expr` | `\| filter`, `is test`, `(...)` | `nodes.Filter`, `nodes.Test`, `nodes.Call` |

The `_math_nodes` mapping translates token types to node classes:

```python
_math_nodes = {
    "add": nodes.Add, "sub": nodes.Sub, "mul": nodes.Mul,
    "div": nodes.Div, "floordiv": nodes.FloorDiv, "mod": nodes.Mod,
}
```

---

## Key Parsing Methods

### Statement Parsers

| Method | Construct | Result Node |
|--------|-----------|-------------|
| `parse_set` | `{% set x = ... %}` / `{% set x %}...{% endset %}` | `nodes.Assign` / `nodes.AssignBlock` |
| `parse_for` | `{% for x in y %}...{% endfor %}` | `nodes.For` |
| `parse_if` | `{% if %}...{% elif %}...{% else %}...{% endif %}` | `nodes.If` |
| `parse_with` | `{% with a=1 %}...{% endwith %}` | `nodes.With` |
| `parse_autoescape` | `{% autoescape true %}...{% endautoescape %}` | `nodes.Scope` wrapping `nodes.ScopedEvalContextModifier` |
| `parse_block` | `{% block name %}...{% endblock %}` | `nodes.Block` |
| `parse_extends` | `{% extends "base.html" %}` | `nodes.Extends` |
| `parse_include` | `{% include "x" ignore missing %}` | `nodes.Include` |
| `parse_import` | `{% import "x" as y %}` | `nodes.Import` |
| `parse_from` | `{% from "x" import a, b %}` | `nodes.FromImport` |
| `parse_macro` | `{% macro name(args) %}...{% endmacro %}` | `nodes.Macro` |
| `parse_call_block` | `{% call macro() %}...{% endcall %}` | `nodes.CallBlock` |
| `parse_filter_block` | `{% filter name %}...{% endfilter %}` | `nodes.FilterBlock` |
| `parse_print` | `{% print expr %}` | `nodes.Output` |

### Helper Methods

- **`parse_statements(end_tokens, drop_needle)`** — Parses a body until one of
  the `end_tokens` is reached. Optionally consumes the end token.
- **`parse_signature(node)`** — Parses a macro/call-block argument list,
  enforcing that non-default arguments do not follow default arguments.
- **`parse_assign_target(...)`** — Parses assignment targets, supporting
  tuples, names, and namespace references (`NSRef`). Calls `set_ctx("store")`.
- **`parse_tuple(...)`** — Parses comma-separated expressions into a
  `nodes.Tuple`, or a single expression if no comma is found.
- **`parse_call_args()`** — Parses call arguments, keyword arguments, and
  dynamic `*args` / `**kwargs`.
- **`parse_filter(node, start_inline)`** — Parses a filter chain, supporting
  dotted filter names.
- **`parse_test(node)`** — Parses `is` tests, including `is not` negation.
- **`free_identifier(lineno)`** — Generates a unique `nodes.InternalName`.

---

## Error Handling

The parser provides rich, context-aware error messages through several helpers:

```mermaid
flowchart TD
    F[fail] -->|raises| TSE[TemplateSyntaxError]
    FU[fail_unknown_tag] --> U[_fail_ut_eof]
    FE[fail_eof] --> U
    U --> F
    U -->|builds message| MSG["expected tags, nesting hints, innermost block"]
```

- **`fail(msg, lineno, exc)`** — Raises `exc` (default `TemplateSyntaxError`)
  with the message, line number, template name, and filename.
- **`fail_unknown_tag(name, lineno)`** — Called for unrecognized tags; produces
  a message listing expected tags and hints about nesting mistakes.
- **`fail_eof(end_tokens, lineno)`** — Like `fail_unknown_tag` but for
  unexpected end-of-template situations.
- **`_fail_ut_eof(...)`** — Shared logic that assembles the diagnostic message
  from the `_end_token_stack` and `_tag_stack`.

The parser also raises `TemplateAssertionError` for semantic issues such as
importing names that start with an underscore.

---

## Integration with the Environment

The `Environment` is the primary consumer of the parser:

```mermaid
sequenceDiagram
    participant Env as Environment
    participant P as Parser
    participant L as Lexer
    participant C as Compiler

    Env->>P: Parser(env, source, name, filename)
    P->>L: env._tokenize(...)
    L-->>P: TokenStream
    Env->>P: parse()
    P-->>Env: nodes.Template
    Env->>C: _generate(nodes.Template)
```

- `Environment._parse` creates a `Parser` and calls `parse()`.
- `Environment.compile_expression` creates a `Parser` with `state="variable"`
  and calls `parse_expression()` directly, then checks `stream.eos`.
- `Environment.parse` wraps `_parse` with exception handling via
  `handle_exception`.

See [environment](environment.md) for the full lifecycle.

---

## Data Flow Summary

```mermaid
flowchart LR
    SRC[Template source string] --> PRE[Extension preprocessing]
    PRE --> LEX[Lexer.tokenize]
    LEX --> TS[TokenStream]
    TS --> PARSE[Parser]
    PARSE --> AST[nodes.Template AST]
    AST --> OPT[Optimizer]
    OPT --> COMP[CodeGenerator]
    COMP --> CODE[Python code / bytecode]
```

The parser is the transformation step from **tokens** to **AST**. Everything
downstream (optimization, compilation, runtime) operates on the node tree it
produces.

---

## Related Modules

- [lexer](lexer.md) — Produces the `TokenStream` consumed by the parser.
- [nodes](nodes.md) — Defines all AST node types the parser constructs.
- [environment](environment.md) — Instantiates and drives the parser.
- [compiler](compiler.md) — Consumes the AST produced by the parser.
- [extensions](extensions.md) — Register custom tags parsed via `Parser.extensions`.
- [exceptions](exceptions.md) — `TemplateSyntaxError` and `TemplateAssertionError` raised by the parser.
- [visitor](visitor.md) — Provides `NodeVisitor` / `NodeTransformer` for traversing the AST.
