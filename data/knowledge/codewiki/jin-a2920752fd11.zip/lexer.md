# Lexer Module

## Introduction

The `lexer` module (`src/jinja2/lexer.py`) implements a combined **Jinja / Python lexer**. It is the first stage of the template processing pipeline: it takes raw template source text and converts it into a stream of typed [`Token`](#token) objects that the [parser](parser.md) can consume.

The lexer performs several important preprocessing tasks:

- **Separates template data from template code** — it distinguishes literal text (`data`) from Jinja expressions (`{{ ... }}`), statement blocks (`{% ... %}`), comments (`{# ... #}`), and line-based statements/comments.
- **Filters out invalid operators** — operators that Jinja does not allow in templates (such as bit-shift operators) are never emitted as valid tokens.
- **Handles whitespace control** — supports `-` (strip), `+` (preserve), `lstrip_blocks`, and `trim_blocks` semantics.
- **Normalizes newlines** — converts all line endings to the environment's configured `newline_sequence`.
- **Validates literals** — parses integers, floats, and strings into their Python values, raising [`TemplateSyntaxError`](exceptions.md) on malformed input.

The lexer is created and cached by the [`Environment`](environment.md) and is not normally instantiated directly by users.

---

## Architecture Overview

The lexer sits between the raw template source and the parser. The [`Environment`](environment.md) owns a cached `Lexer` instance, which produces a [`TokenStream`](#tokenstream) that the [`Parser`](parser.md) consumes to build the AST defined in [nodes](nodes.md).

```mermaid
graph TD
    Source["Template Source (str)"]
    Env["Environment<br/>(environment.py)"]
    Lexer["Lexer<br/>(lexer.py)"]
    TokenStream["TokenStream<br/>(lexer.py)"]
    Parser["Parser<br/>(parser.py)"]
    Nodes["AST Nodes<br/>(nodes.py)"]

    Source --> Env
    Env -->|get_lexer / _tokenize| Lexer
    Lexer -->|tokenize| TokenStream
    TokenStream -->|current / next / expect| Parser
    Parser -->|builds| Nodes

    Lexer -.->|raises| TSE["TemplateSyntaxError<br/>(exceptions.py)"]
    Lexer -.->|caches via| LRU["LRUCache<br/>(utils.py)"]
```

### Key Design Points

- **Environment-independent instances**: A `Lexer` is *not* bound to a single environment at runtime. Multiple environments that share identical lexing configuration can reuse the same cached lexer instance (see [`get_lexer`](#get_lexer)).
- **Rule-based state machine**: Lexing is driven by a dictionary of named states (`root`, `block_begin`, `variable_begin`, `comment_begin`, `raw_begin`, etc.), each holding an ordered list of [`_Rule`](#_rule) objects. The lexer transitions between states as it encounters start/end delimiters.
- **Two-phase tokenization**: `tokeniter` produces raw `(lineno, token_type, value)` tuples; `wrap` converts these into fully-typed [`Token`](#token) objects with Python-native values.

---

## Component Relationships

```mermaid
classDiagram
    class Lexer {
        +rules: Dict[str, List[_Rule]]
        +lstrip_blocks: bool
        +newline_sequence: str
        +keep_trailing_newline: bool
        +tokenize(source, name, filename, state) TokenStream
        +tokeniter(source, name, filename, state) Iterator
        +wrap(stream, name, filename) Iterator~Token~
        +_normalize_newlines(value) str
    }

    class Token {
        <<NamedTuple>>
        +lineno: int
        +type: str
        +value: str
        +test(expr) bool
        +test_any(*iterable) bool
    }

    class TokenStream {
        +current: Token
        +name: str
        +filename: str
        +closed: bool
        +eos: bool
        +push(token)
        +look() Token
        +skip(n)
        +next_if(expr) Token
        +skip_if(expr) bool
        +expect(expr) Token
        +close()
    }

    class TokenStreamIterator {
        +stream: TokenStream
        +__next__() Token
    }

    class Failure {
        +message: str
        +error_class: Type
        +__call__(lineno, filename)
    }

    class OptionalLStrip {
        <<tuple>>
    }

    class _Rule {
        <<NamedTuple>>
        +pattern: Pattern
        +tokens: str | Tuple
        +command: str
    }

    Lexer --> _Rule : uses
    Lexer --> TokenStream : creates
    Lexer --> Token : yields
    Lexer --> Failure : raises via
    Lexer --> OptionalLStrip : uses
    TokenStream --> Token : holds
    TokenStream --> TokenStreamIterator : creates
    _Rule --> Failure : may contain
```

---

## Core Components

### `Lexer`

The central class implementing the lexer for a given environment. It is automatically created by the [`Environment`](environment.md) and cached, so users rarely instantiate it directly.

**Responsibilities:**

1. **Rule compilation** — In `__init__`, it builds the `self.rules` dictionary from the environment's delimiter configuration (`block_start_string`, `variable_start_string`, `comment_start_string`, line prefixes, etc.) via [`compile_rules`](#compile_rules).
2. **State machine execution** — `tokeniter` walks the source using the rules for the current state, handling state pushes/pops (`#pop`, `#bygroup`, or explicit state names).
3. **Token wrapping** — `wrap` converts raw tuples into [`Token`](#token) objects, converting literal values and normalizing newlines.

**Key attributes:**

| Attribute | Description |
|-----------|-------------|
| `rules` | `Dict[str, List[_Rule]]` — the state machine's rule table. |
| `lstrip_blocks` | Whether to strip leading whitespace before block tags. |
| `newline_sequence` | The sequence used to normalize newlines in data/strings. |
| `keep_trailing_newline` | Whether to preserve a trailing newline in the source. |

**Key methods:**

- `tokenize(source, name, filename, state)` — Public entry point. Returns a [`TokenStream`](#tokenstream).
- `tokeniter(source, name, filename, state)` — Generator yielding raw `(lineno, token_type, value)` tuples. Use this if you only need raw tokenization.
- `wrap(stream, name, filename)` — Wraps raw tuples into `Token` objects and converts values.
- `_normalize_newlines(value)` — Replaces all newlines with `newline_sequence`.

#### Lexing States

The lexer operates as a stack-based state machine. The initial state is `root`; entering a delimiter pushes a new state, and end delimiters pop back.

```mermaid
stateDiagram-v2
    [*] --> root
    root --> comment_begin : comment_start_string
    root --> block_begin : block_start_string
    root --> variable_begin : variable_start_string
    root --> linestatement_begin : line_statement_prefix
    root --> linecomment_begin : line_comment_prefix
    root --> raw_begin : block_start raw

    comment_begin --> root : comment_end_string
    block_begin --> root : block_end_string
    variable_begin --> root : variable_end_string
    linestatement_begin --> root : newline / EOF
    linecomment_begin --> root : newline / EOF
    raw_begin --> root : endraw
```

#### Whitespace Control

The lexer implements Jinja's whitespace control semantics:

- **`-` modifier** (e.g. `{%- ... %}`): strips all whitespace between the preceding text and the tag. Implemented via [`OptionalLStrip`](#optionallstrip) and the `strip_sign == "-"` branch in `tokeniter`.
- **`+` modifier** (e.g. `{%+ ... %}`): explicitly preserves whitespace, overriding `lstrip_blocks`.
- **`lstrip_blocks`**: when enabled, strips whitespace from the start of a line to a block tag (but not variable tags).
- **`trim_blocks`**: strips the first newline after a block tag, controlled by `block_suffix_re`.

#### Brace Balancing

The lexer tracks a `balancing_stack` of open `{`, `(`, `[` characters. End tags (`variable_end`, `block_end`, `linestatement_end`) are only matched when the stack is balanced, allowing operators like `}}` inside expressions to be handled correctly. Unbalanced or mismatched brackets raise [`TemplateSyntaxError`](exceptions.md).

---

### `Token`

A `NamedTuple` representing a single lexical token.

```python
class Token(t.NamedTuple):
    lineno: int
    type: str
    value: str
```

| Field | Description |
|-------|-------------|
| `lineno` | The 1-based line number where the token starts. |
| `type` | The token type (one of the `TOKEN_*` interned strings). |
| `value` | The token's value (converted to a Python object for literals). |

**Methods:**

- `test(expr)` — Tests the token against a token expression. `expr` may be a bare token type (e.g. `"name"`) or a `"type:value"` pair (e.g. `"name:for"`).
- `test_any(*iterable)` — Returns `True` if the token matches any of the given expressions.
- `__str__` — Returns a human-readable description via [`describe_token`](#describe_token).

#### Token Types

Token types are interned strings (via `sys.intern`) for fast identity comparison. They fall into several categories:

| Category | Examples |
|----------|----------|
| **Operators** | `add`, `sub`, `mul`, `div`, `floordiv`, `mod`, `pow`, `tilde`, `eq`, `ne`, `gt`, `gteq`, `lt`, `lteq`, `assign`, `dot`, `colon`, `pipe`, `comma`, `semicolon` |
| **Brackets** | `lbrace`, `rbrace`, `lbracket`, `rbracket`, `lparen`, `rparen` |
| **Literals** | `integer`, `float`, `string`, `name` |
| **Delimiters** | `block_begin`, `block_end`, `variable_begin`, `variable_end`, `comment_begin`, `comment_end`, `raw_begin`, `raw_end`, `linestatement_begin`, `linestatement_end`, `linecomment_begin`, `linecomment_end` |
| **Content** | `data`, `comment`, `linecomment`, `whitespace` |
| **Special** | `initial`, `eof` |

The `operators` dictionary maps operator strings to token types, and `reverse_operators` provides the inverse mapping.

---

### `TokenStream`

An iterable wrapper around a token generator. Unlike a plain iterator, the parser does **not** iterate over it directly — instead it calls `next()` to advance and inspects the `current` token.

```mermaid
graph LR
    Gen["Token Generator"] --> TS["TokenStream"]
    TS -->|current| Cur["Current Token"]
    TS -->|push| Pushed["Pushed Stack (deque)"]
    TS -->|look| Look["Peek Next"]
    TS -->|expect| Expect["Assert & Advance"]
```

**Key attributes:**

| Attribute | Description |
|-----------|-------------|
| `current` | The currently active [`Token`](#token). |
| `name` | The template name (for error messages). |
| `filename` | The template filename (for error messages). |
| `closed` | Whether the stream has been closed. |
| `eos` | Property: `True` when at the end of the stream. |

**Key methods:**

- `push(token)` — Pushes a token back onto the stream (used by `look`).
- `look()` — Returns the next token without consuming it.
- `skip(n=1)` — Advances `n` tokens.
- `next_if(expr)` — Advances and returns the token if it matches `expr`, else `None`.
- `skip_if(expr)` — Like `next_if` but returns a boolean.
- `expect(expr)` — Asserts the current token matches `expr` and advances; raises [`TemplateSyntaxError`](exceptions.md) otherwise.
- `close()` — Closes the stream, setting `current` to an `eof` token.

The stream supports `__bool__` (truthy while tokens remain) and `__iter__` (returns a [`TokenStreamIterator`](#tokenstreamiterator)).

---

### `TokenStreamIterator`

The iterator for `TokenStream`. It yields tokens until the `eof` token is reached, at which point it closes the stream and raises `StopIteration`.

```python
class TokenStreamIterator:
    def __init__(self, stream: TokenStream) -> None: ...
    def __iter__(self) -> TokenStreamIterator: ...
    def __next__(self) -> Token: ...
```

---

### `Failure`

A callable helper used by the lexer to declare *known* error conditions within rules. When a rule's token tuple contains a `Failure` instance, the lexer invokes it, which raises the configured exception.

```python
class Failure:
    def __init__(self, message, cls=TemplateSyntaxError) -> None: ...
    def __call__(self, lineno, filename) -> NoReturn: ...
```

**Example usages in rules:**

- `Failure("Missing end of comment tag")`
- `Failure("Missing end of raw directive")`

---

### `OptionalLStrip`

A special `tuple` subclass used to mark a rule whose matched text may have `lstrip` applied. It behaves like a normal tuple but signals to `tokeniter` that whitespace-stripping logic should be evaluated for the match.

```python
class OptionalLStrip(tuple):
    __slots__ = ()
    def __new__(cls, *members, **kwargs): ...
```

It is used in the `root` and `raw_begin` rules, e.g. `OptionalLStrip(TOKEN_DATA, "#bygroup")`.

---

### `_Rule`

A `NamedTuple` describing a single lexing rule within a state.

```python
class _Rule(t.NamedTuple):
    pattern: t.Pattern[str]
    tokens: t.Union[str, t.Tuple[str, ...], t.Tuple[Failure]]
    command: t.Optional[str]
```

| Field | Description |
|-------|-------------|
| `pattern` | The compiled regex to match at the current position. |
| `tokens` | The token type(s) to emit. May be a single string, a tuple of types, a tuple containing a [`Failure`](#failure), or the special `"#bygroup"` marker. |
| `command` | A state transition command: `"#pop"`, `"#bygroup"`, an explicit state name, or `None`. |

---

## Module-Level Functions and Constants

### `get_lexer(environment)`

Returns a cached `Lexer` for the given environment. The cache key is a tuple of all lexing-relevant environment settings (delimiters, prefixes, whitespace flags, newline sequence). The cache is an [`LRUCache`](utils.md) with capacity 50.

```python
def get_lexer(environment: Environment) -> Lexer: ...
```

### `compile_rules(environment)`

Compiles the environment's delimiter configuration into a sorted list of `(token_type, regex)` rules. Rules are sorted by descending delimiter length so that longer delimiters (e.g. `<%=`) match before shorter ones (e.g. `<%`).

### `describe_token(token)` / `describe_token_expr(expr)` / `_describe_token_type(token_type)`

Produce human-readable descriptions of tokens for error messages. For example, `TOKEN_BLOCK_BEGIN` becomes `"begin of statement block"`, and operators are mapped back to their symbols via `reverse_operators`.

### `count_newlines(value)`

Counts newline characters in a string. Useful for extensions that filter token streams.

### Static Regexes

| Regex | Purpose |
|-------|---------|
| `whitespace_re` | Matches runs of whitespace. |
| `newline_re` | Matches `\r\n`, `\r`, or `\n`. |
| `string_re` | Matches single- and double-quoted strings with escapes. |
| `integer_re` | Matches binary, octal, hex, and decimal integers (with `_` separators). |
| `float_re` | Matches floating-point literals with optional exponent. |
| `operator_re` | Matches operators, sorted longest-first. |

### Token Sets

- `ignored_tokens` — Tokens dropped entirely during `wrap` (comments, whitespace, line comments).
- `ignore_if_empty` — Tokens not emitted when their value is empty (`whitespace`, `data`, `comment`, `linecomment`).

---

## Data Flow

The following diagram shows the end-to-end flow from source text to a `TokenStream`.

```mermaid
sequenceDiagram
    participant Env as Environment
    participant Lex as Lexer
    participant TI as tokeniter
    participant W as wrap
    participant TS as TokenStream

    Env->>Lex: get_lexer(environment)
    Env->>Lex: tokenize(source, name, filename, state)
    Lex->>TI: tokeniter(source, ...)
    TI-->>TI: state machine loop
    TI-->>W: yield (lineno, type, value)
    W-->>W: convert values, normalize newlines
    W-->>TS: yield Token
    Lex->>TS: TokenStream(wrapped, name, filename)
    TS-->>Env: return TokenStream
```

### Value Conversion in `wrap`

The `wrap` method performs type-specific conversions:

| Raw token | Conversion |
|-----------|------------|
| `data` | Newlines normalized via `_normalize_newlines`. |
| `name` | Validated as a Python identifier; raises on invalid characters. |
| `string` | Unescaped via `unicode-escape` decoding. |
| `integer` | Parsed with `int(value.replace("_", ""), 0)`. |
| `float` | Parsed with `ast.literal_eval`. |
| `operator` | Mapped to its token type via the `operators` dict. |
| `linestatement_begin/end` | Remapped to `block_begin`/`block_end`. |
| `raw_begin/raw_end` | Dropped (not relevant to the parser). |

---

## Error Handling

The lexer raises [`TemplateSyntaxError`](exceptions.md) (from `exceptions.py`) in several situations:

- **Invalid identifier characters** — when a `name` token is not a valid Python identifier.
- **Malformed string literals** — when unescaping fails.
- **Unbalanced brackets** — unexpected or mismatched `}`, `)`, `]`.
- **Unexpected characters** — when no rule matches at the current position.
- **Missing end tags** — via [`Failure`](#failure) instances in rules (e.g. missing `#}` or `{% endraw %}`).
- **Internal errors** — `RuntimeError` is raised for rule bugs (empty-string matches without state change, or `#bygroup`/`#bygroup` resolution failures).

All syntax errors carry `lineno`, `name`, and `filename` for precise diagnostics.

---

## Integration with Other Modules

| Module | Relationship |
|--------|--------------|
| [environment](environment.md) | Owns and caches the `Lexer`; provides delimiter configuration and calls `_tokenize`. |
| [parser](parser.md) | Consumes the [`TokenStream`](#tokenstream) via `current`, `next`, `expect`, `skip_if`, etc. |
| [nodes](nodes.md) | The parser builds AST nodes from the tokens the lexer produces. |
| [exceptions](exceptions.md) | Provides `TemplateSyntaxError`, raised throughout lexing. |
| [utils](utils.md) | Provides `LRUCache` for the lexer cache. |

---

## Summary

The `lexer` module is the entry point of Jinja's template processing pipeline. Through a cached, rule-driven state machine, it transforms raw template text into a validated, typed token stream. Its careful handling of whitespace control, brace balancing, literal conversion, and error reporting ensures that the [parser](parser.md) receives clean, well-formed input for building the template AST.
