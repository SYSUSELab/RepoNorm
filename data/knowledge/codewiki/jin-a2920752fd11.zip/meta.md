# Meta Module

## Introduction

The `meta` module (`src/jinja2/meta.py`) provides **introspection utilities** for Jinja templates. It exposes information about a parsed template's abstract syntax tree (AST) that is useful for static analysis, dependency tracking, and tooling — without ever rendering the template.

The module answers two key questions about a template:

1. **Which variables will be looked up from the render context at runtime?** — via `find_undeclared_variables`.
2. **Which other templates does this template reference (via `extends`, `include`, `import`, `from ... import`)?** — via `find_referenced_templates`.

These capabilities are built on top of the compilation pipeline. Rather than writing a dedicated AST walker, the module **reuses the code generator** in a "tracking" mode that records information instead of emitting Python source code.

> **Note:** The module docstring describes it as *"Functions that expose information about templates that might be interesting for introspection."*

---

## Architecture Overview

The `meta` module is a thin, specialized layer that sits on top of the [compilation and analysis](compiler.md) subsystem. It subclasses the standard `CodeGenerator` and disables its output side effects while retaining its symbol-tracking behavior.

```mermaid
graph TD
    subgraph "meta module"
        TCG["TrackingCodeGenerator<br/>(CodeGenerator subclass)"]
        FUV["find_undeclared_variables()"]
        FRT["find_referenced_templates()"]
    end

    subgraph "compilation_and_analysis"
        CG["CodeGenerator"]
        FR["Frame"]
        OPT["Optimizer"]
        IDT["Symbols / idtracking"]
    end

    subgraph "lexing_and_parsing"
        NODES["nodes (AST)"]
        PARSER["Parser"]
    end

    subgraph "template_environment_and_loading"
        ENV["Environment"]
    end

    FUV -->|instantiates| TCG
    FRT -->|walks AST| NODES
    TCG -->|extends| CG
    CG -->|uses| FR
    CG -->|uses| IDT
    CG -->|uses| OPT
    FR -->|holds| IDT
    ENV -->|parse| PARSER
    PARSER -->|produces| NODES
    ENV -->|provides globals| TCG
```

### Key Design Principle: "Abusing" the Code Generator

The central design decision is documented directly in the source:

```python
class TrackingCodeGenerator(CodeGenerator):
    """We abuse the code generator for introspection."""
```

Instead of building a separate AST analysis engine, the module leverages the fact that the `CodeGenerator` already performs **symbol resolution** (deciding whether each name is a parameter, a local alias, a resolved context lookup, or undefined). By overriding just two methods, the tracking generator captures this resolution data without producing any output.

---

## Core Components

### `TrackingCodeGenerator`

A subclass of [`CodeGenerator`](compiler.md) that records undeclared identifiers instead of generating Python code.

| Member | Purpose |
| --- | --- |
| `undeclared_identifiers: Set[str]` | Accumulates the names that must be resolved from the context at runtime. |
| `__init__(environment)` | Initializes the base generator with placeholder name/filename `"<introspection>"` and an empty identifier set. |
| `write(x)` | **Overridden to do nothing** — suppresses all code output. |
| `enter_frame(frame)` | **Overridden** to inspect each frame's symbol loads and record those that resolve from the context. |

#### How `enter_frame` detects undeclared variables

```python
def enter_frame(self, frame: Frame) -> None:
    """Remember all undeclared identifiers."""
    super().enter_frame(frame)

    for _, (action, param) in frame.symbols.loads.items():
        if action == "resolve" and param not in self.environment.globals:
            self.undeclared_identifiers.add(param)
```

The logic relies on the symbol-tracking machinery from [idtracking](idtracking.md):

- Each entry in `frame.symbols.loads` is a `(action, param)` pair.
- An action of `"resolve"` (`VAR_LOAD_RESOLVE`) means the name is **not** a local parameter or alias — it must be looked up from the render context.
- Names that are already present in `environment.globals` are excluded, since they are always available and not "undeclared" from the user's perspective.

```mermaid
flowchart TD
    A["enter_frame(frame)"] --> B["super().enter_frame(frame)"]
    B --> C["Iterate frame.symbols.loads"]
    C --> D{"action == 'resolve'?"}
    D -->|No| C
    D -->|Yes| E{"param in environment.globals?"}
    E -->|Yes| C
    E -->|No| F["undeclared_identifiers.add(param)"]
    F --> C
```

### `find_undeclared_variables(ast)`

The public entry point for variable introspection.

```python
def find_undeclared_variables(ast: nodes.Template) -> t.Set[str]:
    codegen = TrackingCodeGenerator(ast.environment)
    codegen.visit(ast)
    return codegen.undeclared_identifiers
```

**Behavior:**

- Accepts a parsed [`nodes.Template`](nodes.md) AST (obtained via `Environment.parse`).
- Runs the tracking generator over the whole tree.
- Returns the set of all variables that will be looked up from the context at runtime.

**Important caveat:** Because the code generator is used internally, this function can raise a `TemplateAssertionError` during compilation (e.g., for duplicate blocks or invalid constructs). This is explicitly documented in the source's `admonition` block.

**Example:**

```python
from jinja2 import Environment, meta

env = Environment()
ast = env.parse('{% set foo = 42 %}{{ bar + foo }}')
meta.find_undeclared_variables(ast) == {'bar'}
# True
```

Note that `foo` is *not* reported because it is assigned locally via `{% set %}`; only `bar` is resolved from the context.

### `find_referenced_templates(ast)`

The public entry point for template dependency introspection.

```python
_ref_types = (nodes.Extends, nodes.FromImport, nodes.Import, nodes.Include)

def find_referenced_templates(ast: nodes.Template) -> t.Iterator[t.Optional[str]]:
    ...
```

**Behavior:**

- Walks the AST for all nodes of the reference types: `Extends`, `FromImport`, `Import`, and `Include`.
- Yields the **hardcoded** template names as strings.
- Yields `None` whenever a reference is **dynamic** (i.e., not a compile-time constant), signaling that the dependency cannot be statically determined.

**Resolution rules for the `template` field of each reference node:**

| AST shape | Result |
| --- | --- |
| `Const` with a `str` value | Yields the string. |
| `Const` with a `tuple`/`list` value (in an `Include`) | Yields each string element. |
| `Tuple`/`List` node | Yields each `Const` string element; yields `None` for any non-const element. |
| Any other (dynamic) expression | Yields `None`. |

**Example:**

```python
from jinja2 import Environment, meta

env = Environment()
ast = env.parse('{% extends "layout.html" %}{% include helper %}')
list(meta.find_referenced_templates(ast))
# ['layout.html', None]
```

Here `"layout.html"` is a static reference, while `helper` is a variable and therefore yields `None`.

```mermaid
flowchart TD
    A["find_referenced_templates(ast)"] --> B["ast.find_all(Extends, FromImport, Import, Include)"]
    B --> C{"template is Const?"}
    C -->|No| D{"Tuple or List node?"}
    D -->|Yes| E["For each item:<br/>yield str if Const str, else None"]
    D -->|No| F["yield None"]
    C -->|Yes| G{"value is str?"}
    G -->|Yes| H["yield value"]
    G -->|No| I{"Include with tuple/list value?"}
    I -->|Yes| J["yield each str element"]
    I -->|No| K["yield None"]
```

---

## Data Flow

The following diagram shows how a template flows from source text to introspection results.

```mermaid
sequenceDiagram
    participant User
    participant Env as Environment
    participant Parser as Parser
    participant Meta as meta module
    participant TCG as TrackingCodeGenerator
    participant CG as CodeGenerator

    User->>Env: parse(source)
    Env->>Parser: Parser(env, source).parse()
    Parser-->>Env: nodes.Template (AST)
    Env-->>User: AST

    User->>Meta: find_undeclared_variables(ast)
    Meta->>TCG: TrackingCodeGenerator(ast.environment)
    Meta->>TCG: visit(ast)
    TCG->>CG: enter_frame(frame) [super]
    CG-->>TCG: symbol loads populated
    TCG->>TCG: record "resolve" names not in globals
    TCG-->>Meta: undeclared_identifiers
    Meta-->>User: Set[str]

    User->>Meta: find_referenced_templates(ast)
    Meta->>Meta: ast.find_all(ref_types)
    Meta-->>User: Iterator[str | None]
```

---

## Component Interaction

The `meta` module interacts with several other subsystems. The table below summarizes the relationships and links to the relevant documentation.

| Dependency | Role in `meta` | Documentation |
| --- | --- | --- |
| `CodeGenerator` | Base class; provides symbol resolution and AST visiting. | [compiler.md](compiler.md) |
| `Frame` | Carries `symbols.loads` used to detect undeclared names. | [compiler.md](compiler.md) |
| `Symbols` (idtracking) | Defines the `"resolve"` load action and `loads` mapping. | [idtracking.md](idtracking.md) |
| `nodes` | AST node types (`Template`, `Extends`, `Include`, `Import`, `FromImport`, `Const`, `Tuple`, `List`). | [nodes.md](nodes.md) |
| `Environment` | Provides `globals` (to filter out known names) and `parse` (to build the AST). | [environment.md](environment.md) |

```mermaid
graph LR
    META["meta.py"]
    META -->|subclasses| CG["compiler.CodeGenerator"]
    META -->|reads| FRAME["compiler.Frame"]
    META -->|reads loads| SYM["idtracking.Symbols"]
    META -->|walks| NODES["nodes.*"]
    META -->|reads globals| ENV["environment.Environment"]
```

---

## Process Flows

### Flow 1: Finding Undeclared Variables

```mermaid
flowchart TD
    S["Start: parsed AST"] --> A["Create TrackingCodeGenerator(ast.environment)"]
    A --> B["codegen.visit(ast)"]
    B --> C["For each frame entered"]
    C --> D["Inspect frame.symbols.loads"]
    D --> E["Collect 'resolve' names not in globals"]
    E --> F["Return undeclared_identifiers set"]
    F --> G["End"]
```

### Flow 2: Finding Referenced Templates

```mermaid
flowchart TD
    S["Start: parsed AST"] --> A["ast.find_all(ref_types)"]
    A --> B["For each reference node"]
    B --> C["Extract node.template"]
    C --> D["Classify: static vs dynamic"]
    D --> E["Yield string names or None"]
    E --> B
    B --> F["End: iterator exhausted"]
```

---

## Use Cases

### Dependency Tracking / Incremental Rebuilds

`find_referenced_templates` is explicitly designed for **dependency tracking**. As the source notes:

> *"This function is useful for dependency tracking. For example if you want to rebuild parts of the website after a layout template has changed."*

A build system can parse each template, collect its referenced templates, and construct a dependency graph. When a template changes, only its dependents need to be re-rendered.

### Static Analysis & Linting

`find_undeclared_variables` enables tools to:

- Detect variables that must be supplied at render time.
- Validate that a caller provides all required context variables.
- Document the "interface" of a template.

### Tooling & IDE Support

Both functions support editor tooling by exposing the template's external contract (inputs and dependencies) without executing it.

---

## Limitations & Caveats

| Limitation | Details |
| --- | --- |
| **Compile-time errors** | `find_undeclared_variables` may raise `TemplateAssertionError` because it runs the code generator. |
| **Dynamic references** | `find_referenced_templates` yields `None` for dynamic references; it cannot resolve runtime-computed template names. |
| **Globals excluded** | Names present in `environment.globals` are not reported as undeclared. |
| **All paths returned** | Since the runtime execution path is unknown at compile time, *all* variables across all branches are returned. |
| **Requires parsed AST** | Both functions operate on a `nodes.Template`; the source must be parsed first via `Environment.parse`. |

---

## Related Modules

- [compiler.md](compiler.md) — The `CodeGenerator` and `Frame` classes that `meta` builds upon.
- [idtracking.md](idtracking.md) — Symbol tracking (`Symbols`, load actions) that powers undeclared-variable detection.
- [nodes.md](nodes.md) — The AST node types traversed by both introspection functions.
- [environment.md](environment.md) — Provides `parse`, `globals`, and the environment context.
- [parser.md](parser.md) — Produces the AST consumed by the `meta` module.
