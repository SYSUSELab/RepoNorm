# Task0 Loading Module

## Introduction

The **task0_loading** module (`tiktoken/load.py`) is responsible for **acquiring, validating, caching, and parsing** the raw data that defines a BPE (Byte Pair Encoding) vocabulary. It is the data-acquisition layer that sits between remote/local storage and the in-memory `Encoding` objects used for tokenization.

Its core responsibilities are:

- **Fetching** vocabulary files from HTTP(S) URLs or local/cloud blob paths.
- **Caching** downloaded data on disk to avoid repeated network requests.
- **Validating** data integrity via SHA-256 hash checks.
- **Parsing** two vocabulary formats into the canonical `dict[bytes, int]` mergeable-ranks structure:
  - the native tiktoken `.tiktoken` format (`load_tiktoken_bpe`), and
  - the legacy OpenAI Data Gym format (`data_gym_to_mergeable_bpe_ranks`).
- **Serializing** mergeable ranks back to the `.tiktoken` format (`dump_tiktoken_bpe`).

This module is consumed primarily by the built-in encoding constructors (see [task0_builtin_encodings](task0_builtin_encodings.md)), which call `load_tiktoken_bpe` to obtain the `mergeable_ranks` dictionary passed into an `Encoding` object (see [task0_core_encoding](task0_core_encoding.md)).

---

## Architecture Overview

The module is a small, self-contained utility layer with no dependency on the rest of tiktoken. It depends only on the Python standard library plus two optional third-party packages (`blobfile`, `requests`).

```mermaid
graph TD
    subgraph "task0_loading (tiktoken/load.py)"
        RF[read_file]
        RFC[read_file_cached]
        CH[check_hash]
        LT[load_tiktoken_bpe]
        DT[dump_tiktoken_bpe]
        DG[data_gym_to_mergeable_bpe_ranks]
    end

    subgraph "External"
        BLOB[blobfile]
        REQ[requests]
        FS[(Local / Cloud Storage)]
        HTTP[(HTTP Endpoint)]
    end

    subgraph "Consumers"
        BE[task0_builtin_encodings<br/>cl100k_base, o200k_base, ...]
        ENC[task0_core_encoding<br/>Encoding]
    end

    RFC --> RF
    RFC --> CH
    LT --> RFC
    DG --> RFC
    DT --> BLOB

    RF --> BLOB
    RF --> REQ
    BLOB --> FS
    REQ --> HTTP

    BE --> LT
    BE --> ENC
    LT -.produces mergeable_ranks.-> ENC
```

---

## Component Reference

### `read_file(blobpath: str) -> bytes`

The lowest-level fetch primitive. It selects a transport based on the path scheme:

| Path scheme | Transport | Rationale |
|---|---|---|
| `http://` / `https://` | `requests.get` | Avoids `blobfile` for public files, sidestepping auth issues such as MFA prompts. |
| anything else | `blobfile.BlobFile` | Supports local paths and cloud blob stores (e.g. Azure Blob Storage). |

- Raises `ImportError` with an actionable message if `blobfile` is required but not installed.
- Calls `resp.raise_for_status()` so HTTP errors surface as exceptions.

### `check_hash(data: bytes, expected_hash: str) -> bool`

Computes the SHA-256 hex digest of `data` and compares it to `expected_hash`. Returns `True` on match. Used to detect corrupted downloads and stale cache entries.

### `read_file_cached(blobpath: str, expected_hash: str | None = None) -> bytes`

The caching wrapper around `read_file`. It implements a **content-addressed disk cache** keyed by the SHA-1 hash of the blob path.

**Cache directory resolution order:**

1. `TIKTOKEN_CACHE_DIR` environment variable (user-specified).
2. `DATA_GYM_CACHE_DIR` environment variable (legacy, user-specified).
3. `<system temp dir>/data-gym-cache` (default, *not* user-specified).

**Special cases:**

- If the resolved `cache_dir` is the empty string `""`, caching is **disabled** and the call delegates directly to `read_file`.
- If a cached file exists but fails the `expected_hash` check, it is removed and re-fetched.
- If a freshly downloaded file fails the hash check, a `ValueError` is raised (corrupted download).
- Writes are performed atomically via a temporary file (`<cache_path>.<uuid>.tmp`) followed by `os.rename`.
- Write failures to the **default** cache are silently ignored (see upstream issue #75); write failures to a **user-specified** cache are re-raised.

### `load_tiktoken_bpe(tiktoken_bpe_file: str, expected_hash: str | None = None) -> dict[bytes, int]`

Parses the native tiktoken `.tiktoken` format. Each non-empty line is `base64(token) <space> rank`. Returns a mapping of decoded token bytes to integer rank.

- Delegates fetching to `read_file_cached`.
- Wraps parse errors in a `ValueError` that includes the offending line and file name.
- **Note:** caching is intentionally *not* added at this level — it is handled by `read_file_cached`.

### `dump_tiktoken_bpe(bpe_ranks: dict[bytes, int], tiktoken_bpe_file: str) -> None`

The inverse of `load_tiktoken_bpe`. Writes each token as `base64(token) <space> rank\n`, sorted by rank ascending, using `blobfile.BlobFile` in write mode. Raises `ImportError` if `blobfile` is unavailable.

### `data_gym_to_mergeable_bpe_ranks(...) -> dict[bytes, int]`

Converts the **legacy OpenAI Data Gym** vocabulary format (a `vocab.bpe` merges file plus an `encoder.json` file) into the canonical mergeable-ranks dictionary.

**Signature:**

```python
data_gym_to_mergeable_bpe_ranks(
    vocab_bpe_file: str,
    encoder_json_file: str,
    vocab_bpe_hash: str | None = None,
    encoder_json_hash: str | None = None,
) -> dict[bytes, int]
```

**Algorithm:**

1. Build a reversible byte remapping (`data_gym_byte_to_byte`) that maps printable characters to their byte values and assigns the remaining bytes to non-printable code points. This mirrors the original GPT-2 byte-level encoding.
2. Read and parse `vocab.bpe` (skipping the header line and trailing blank line) into merge pairs.
3. Seed `bpe_ranks` with the 256 single-byte tokens, then assign increasing ranks to each merge.
4. Load `encoder.json`, decode its keys through the same remapping, drop the `<|endoftext|>` and `<|startoftext|>` special tokens, and **assert** that the result equals `bpe_ranks`.

The final assertion is a critical sanity check: tiktoken assumes ranks are ordered identically to merge priority, so a mismatch between the two files indicates an inconsistent vocabulary.

---

## Data Flow

The following diagram shows how data flows from a remote source into a usable `Encoding`.

```mermaid
sequenceDiagram
    participant BE as Builtin Encoding<br/>(cl100k_base)
    participant LT as load_tiktoken_bpe
    participant RFC as read_file_cached
    participant RF as read_file
    participant SRC as Remote/Local Source

    BE->>LT: load_tiktoken_bpe(url, expected_hash)
    LT->>RFC: read_file_cached(url, expected_hash)
    RFC->>RFC: resolve cache_dir
    alt cache hit & hash valid
        RFC-->>LT: cached bytes
    else cache miss / invalid
        RFC->>RF: read_file(url)
        RF->>SRC: fetch (requests / blobfile)
        SRC-->>RF: raw bytes
        RF-->>RFC: raw bytes
        RFC->>RFC: check_hash(contents, expected_hash)
        RFC->>RFC: write to cache atomically
        RFC-->>LT: raw bytes
    end
    LT->>LT: parse base64 lines -> dict[bytes, int]
    LT-->>BE: mergeable_ranks
    BE->>BE: construct Encoding(mergeable_ranks=...)
```

---

## Process Flows

### Cache Resolution and Validation

```mermaid
flowchart TD
    A[read_file_cached called] --> B{TIKTOKEN_CACHE_DIR set?}
    B -- yes --> C[use it, user_specified=True]
    B -- no --> D{DATA_GYM_CACHE_DIR set?}
    D -- yes --> C
    D -- no --> E[use temp/data-gym-cache, user_specified=False]
    C --> F{cache_dir == ''?}
    E --> F
    F -- yes --> G[read_file directly, no caching]
    F -- no --> H{cache file exists?}
    H -- yes --> I{hash valid or no expected_hash?}
    I -- yes --> J[return cached data]
    I -- no --> K[remove stale cache file]
    H -- no --> K
    K --> L[read_file from source]
    L --> M{expected_hash matches?}
    M -- no --> N[raise ValueError: hash mismatch]
    M -- yes --> O[write atomically via tmp + rename]
    O --> P{write failed?}
    P -- yes & user_specified --> Q[raise OSError]
    P -- yes & default --> R[ignore, issue #75]
    P -- no --> J
    R --> J
```

### Data Gym Conversion

```mermaid
flowchart LR
    A[vocab.bpe] --> B[parse merge pairs]
    C[encoder.json] --> D[decode keys via byte remap]
    B --> E[seed 256 single-byte tokens]
    E --> F[assign ranks to merges]
    D --> G[drop endoftext/startoftext]
    F --> H{bpe_ranks == encoder_json_loaded?}
    G --> H
    H -- yes --> I[return bpe_ranks]
    H -- no --> J[AssertionError]
```

---

## Dependencies

### Internal Dependencies

This module has **no internal dependencies** on other tiktoken modules. It is a leaf utility module.

### External Dependencies

| Dependency | Type | Purpose |
|---|---|---|
| `base64` | stdlib | Encode/decode token bytes in `.tiktoken` format. |
| `hashlib` | stdlib | SHA-256 (integrity) and SHA-1 (cache key). |
| `os` | stdlib | Environment variables, path handling, atomic rename. |
| `tempfile` | stdlib | Default cache directory. |
| `uuid` | stdlib | Unique temporary filenames for atomic writes. |
| `json` | stdlib | Parse `encoder.json` in Data Gym conversion. |
| `blobfile` | optional 3rd-party | Local/cloud blob access. Required for non-HTTP paths and for `dump_tiktoken_bpe`. |
| `requests` | optional 3rd-party | HTTP(S) fetching. |

### Downstream Consumers

- **[task0_builtin_encodings](task0_builtin_encodings.md)** — `cl100k_base`, `o200k_base`, `p50k_base`, etc. call `load_tiktoken_bpe` with a URL and expected hash.
- **[task0_core_encoding](task0_core_encoding.md)** — the resulting `mergeable_ranks` dict is passed to the `Encoding` constructor.
- **[task0_registry](task0_registry.md)** — indirectly, since the registry instantiates the built-in encoding constructors.

---

## Configuration

| Environment Variable | Effect |
|---|---|
| `TIKTOKEN_CACHE_DIR` | Overrides the cache directory. Highest priority. Setting to `""` disables caching. |
| `DATA_GYM_CACHE_DIR` | Legacy cache directory override. Lower priority than `TIKTOKEN_CACHE_DIR`. |

If neither is set, the default cache directory is `<system temp>/data-gym-cache`. Failures to write to the default cache are non-fatal.

---

## Error Handling Summary

| Condition | Behavior |
|---|---|
| `blobfile` missing for a non-HTTP path | `ImportError` with install instructions. |
| HTTP request fails | `requests` raises via `raise_for_status()`. |
| Downloaded data fails hash check | `ValueError` (corrupted download). |
| Cached data fails hash check | Cache entry removed, data re-fetched. |
| `.tiktoken` line fails to parse | `ValueError` with line and file context. |
| Data Gym files inconsistent | `AssertionError` from the final equality check. |
| Default cache write fails | Silently ignored (issue #75). |
| User-specified cache write fails | `OSError` re-raised. |

---

## Related Documentation

- [task0_core_encoding](task0_core_encoding.md) — the `Encoding` class that consumes `mergeable_ranks`.
- [task0_builtin_encodings](task0_builtin_encodings.md) — the built-in encoding constructors that call `load_tiktoken_bpe`.
- [task0_registry](task0_registry.md) — how encodings are discovered and instantiated.
- [task0_model_mapping](task0_model_mapping.md) — mapping model names to encodings.
