# Educational BPE Module (`tiktoken/_educational.py`)

## Introduction

The `task0_educational` module provides a **pure-Python, dependency-light reference implementation** of the Byte Pair Encoding (BPE) algorithm used by `tiktoken`. Unlike the production `Encoding` class (see [task0_core_encoding.md](task0_core_encoding.md)), which delegates the hot path to a Rust `CoreBPE` engine, this module implements the entire encode/train pipeline in readable Python.

Its purpose is **pedagogical**: it lets developers inspect, step through, and visualise exactly how BPE tokenisation works — how text is split by a regex, how byte pairs are merged by rank, and how a vocabulary is learned from raw training data. It is *not* intended for production use, as it is orders of magnitude slower than the Rust-backed implementation.

The module exposes a single class, `SimpleBytePairEncoding`, plus three module-level helper functions (`bpe_encode`, `bpe_train`, `visualise_tokens`) and a demo entry point (`train_simple_encoding`).

---

## Architecture Overview

The module is intentionally self-contained but interoperates with the rest of `tiktoken` through a thin adapter (`SimpleBytePairEncoding.from_tiktoken`).

```mermaid
graph TD
    subgraph "task0_educational"
        SBPE[SimpleBytePairEncoding]
        BE[bpe_encode]
        BT[bpe_train]
        VT[visualise_tokens]
        TSE[train_simple_encoding]
    end

    subgraph "task0_core_encoding"
        ENC[Encoding]
    end

    subgraph "task0_registry"
        GE[get_encoding]
    end

    SBPE -->|encode calls| BE
    SBPE -->|train calls| BT
    BE -->|visualise| VT
    BT -->|visualise| VT
    TSE -->|uses| SBPE
    SBPE -->|from_tiktoken reads _pat_str, _mergeable_ranks| ENC
    SBPE -->|from_tiktoken str path| GE
    GE -->|returns| ENC
```

### Component Responsibilities

| Component | Responsibility |
|-----------|----------------|
| `SimpleBytePairEncoding` | Container for a `pat_str` + `mergeable_ranks`; provides `encode`, `decode`, `decode_bytes`, `decode_tokens_bytes`, `train`, and `from_tiktoken`. |
| `bpe_encode` | Core greedy merge loop: given ranks and raw bytes, repeatedly merges the lowest-rank adjacent pair until no merge is possible. |
| `bpe_train` | Learns a `mergeable_ranks` vocabulary from a training corpus by iteratively merging the most frequent byte pair. |
| `visualise_tokens` | Renders a list of token byte values to the terminal with alternating background colours. |
| `train_simple_encoding` | Demo that trains a 600-token encoding on this file's own source and encodes `"hello world"`. |

---

## Component Interaction & Data Flow

### Encoding Flow

`SimpleBytePairEncoding.encode` splits text with the regex pattern, then delegates each word to `bpe_encode`.

```mermaid
sequenceDiagram
    participant User
    participant SBPE as SimpleBytePairEncoding
    participant Regex as regex._pat
    participant BE as bpe_encode
    participant VT as visualise_tokens

    User->>SBPE: encode("hello world")
    SBPE->>Regex: findall(text)
    Regex-->>SBPE: ["hello", " world"]
    loop for each word
        SBPE->>BE: bpe_encode(mergeable_ranks, word_bytes)
        loop until no mergeable pair
            BE->>BE: find lowest-rank adjacent pair
            BE->>BE: merge pair
            BE->>VT: visualise_tokens(parts) [if visualise]
        end
        BE-->>SBPE: [token ids]
    end
    SBPE-->>User: [388, 372]
```

### Training Flow

`bpe_train` builds a vocabulary bottom-up: it seeds ranks with all 256 single bytes, then repeatedly counts adjacent pairs across the corpus and merges the most frequent one.

```mermaid
flowchart TD
    A[Start: data, vocab_size, pat_str] --> B{vocab_size >= 256?}
    B -- No --> B1[raise ValueError]
    B -- Yes --> C[Seed ranks with 256 single-byte tokens]
    C --> D[Split data into words via regex]
    D --> E{len ranks < vocab_size?}
    E -- No --> Z[Return ranks]
    E -- Yes --> F[Count all adjacent pairs across words]
    F --> G[Select most common pair]
    G --> H[Create new token = pair bytes, rank = len ranks]
    H --> I[Merge that pair in every word]
    I --> J[visualise if enabled]
    J --> E
```

---

## Core Components

### `SimpleBytePairEncoding`

A lightweight analogue of the production `Encoding` class. It stores only two pieces of state:

- `pat_str` — the regex pattern used to pre-split text into "words".
- `mergeable_ranks` — a `dict[bytes, int]` mapping token byte sequences to merge-priority ranks.

It derives a `_decoder` (reverse map) and a compiled `_pat` in the constructor.

**Key methods:**

| Method | Description |
|--------|-------------|
| `encode(text, visualise="colour")` | Regex-splits text, then BPE-encodes each word. Returns `list[int]`. |
| `decode_bytes(tokens)` | Joins the byte values of each token. |
| `decode(tokens)` | Decodes bytes to `str` with `errors="replace"`. |
| `decode_tokens_bytes(tokens)` | Returns the per-token byte values (useful for visualisation). |
| `train(training_data, vocab_size, pat_str)` *(static)* | Trains a new instance via `bpe_train`. |
| `from_tiktoken(encoding)` *(static)* | Adapts a production `Encoding` (or encoding name) into a `SimpleBytePairEncoding`. |

> **Note on `from_tiktoken`:** It reads the private attributes `encoding._pat_str` and `encoding._mergeable_ranks` from the production `Encoding` object. This is a deliberate coupling for educational convenience — see [task0_core_encoding.md](task0_core_encoding.md) for the `Encoding` internals.

### `bpe_encode`

The heart of the algorithm. Given `mergeable_ranks` and an `input` byte string:

1. Initialise `parts` as a list of single-byte tokens.
2. Repeatedly scan all adjacent pairs, find the pair whose concatenation has the **lowest rank** (highest merge priority).
3. Merge that pair in place and repeat.
4. Stop when no adjacent pair exists in `mergeable_ranks`.
5. Map each final part to its token id.

The `visualise` parameter (`"colour"`/`"color"`, `"simple"`, or `None`) controls intermediate rendering.

### `bpe_train`

Learns `mergeable_ranks` from a corpus:

- Requires `vocab_size >= 256` (all single bytes must be representable).
- Seeds ranks `0..255` for each single byte.
- Iteratively counts adjacent pairs (`collections.Counter`), picks the most common, assigns it the next rank, and merges it throughout the corpus.
- Supports the same `visualise` modes as `bpe_encode`.

### `visualise_tokens`

Renders token byte values with cycling ANSI background colours. Tokens that do not align to UTF-8 character boundaries are decoded with `errors="replace"`, so partial characters appear as `�`. This is purely a debugging/teaching aid.

### `train_simple_encoding`

A runnable demo. It reads its own source file as training data, trains a 600-token encoding using the GPT-2 regex pattern, then encodes `"hello world"` and asserts round-trip correctness across `decode`, `decode_bytes`, and `decode_tokens_bytes`.

---

## Relationship to the Production Pipeline

The educational module mirrors the production architecture but replaces the Rust engine with Python:

```mermaid
graph LR
    subgraph Production
        P1[Encoding.encode] --> P2[CoreBPE - Rust]
        P2 --> P3[regex split + merge]
    end
    subgraph Educational
        E1[SimpleBytePairEncoding.encode] --> E2[bpe_encode - Python]
        E2 --> E3[regex split + merge]
    end
    P1 -.mirrors.-> E1
    P2 -.mirrors.-> E2
```

| Concern | Production | Educational |
|---------|-----------|-------------|
| Merge engine | Rust `CoreBPE` | Python `bpe_encode` |
| Special tokens | Full support (`allowed_special`/`disallowed_special`) | Not supported |
| Batching | `encode_batch`, thread pools | Not supported |
| Training | Offline (data-gym / BPE files) | In-memory `bpe_train` |
| Performance | Optimised | Reference only |

For the production encoding API, see [task0_core_encoding.md](task0_core_encoding.md). For how encodings are registered and looked up by name, see [task0_registry.md](task0_registry.md). For mapping model names to encodings, see [task0_model_mapping.md](task0_model_mapping.md). For loading pre-trained BPE files, see [task0_loading.md](task0_loading.md). For the concrete built-in encodings (e.g. `cl100k_base`, `o200k_base`), see [task0_builtin_encodings.md](task0_builtin_encodings.md).

---

## Usage Examples

### Training from scratch

```python
from tiktoken._educational import SimpleBytePairEncoding

gpt2_pattern = r"""'s|'t|'re|'ve|'m|'ll|'d| ?[\p{L}]+| ?[\p{N}]+| ?[^\s\p{L}\p{N}]+|\s+(?!\S)|\s+"""

enc = SimpleBytePairEncoding.train(
    training_data="hello world, hello there",
    vocab_size=300,
    pat_str=gpt2_pattern,
)

tokens = enc.encode("hello world", visualise=None)
assert enc.decode(tokens) == "hello world"
```

### Adapting a production encoding

```python
from tiktoken._educational import SimpleBytePairEncoding

enc = SimpleBytePairEncoding.from_tiktoken("cl100k_base")
enc.encode("hello world", visualise="simple")
```

### Running the built-in demo

```python
from tiktoken._educational import train_simple_encoding

enc = train_simple_encoding()
```

---

## Design Notes & Limitations

- **No special-token handling.** Unlike `Encoding.encode`, there is no `allowed_special`/`disallowed_special` logic; all text is treated as ordinary text.
- **No batching or threading.** Encoding is single-threaded and per-string.
- **Performance.** The greedy O(n²)-per-word merge loop and full-corpus pair counting make this unsuitable for large inputs.
- **Private-attribute coupling.** `from_tiktoken` depends on `Encoding._pat_str` and `Encoding._mergeable_ranks`, which are internal attributes and may change.
- **UTF-8 boundary caveat.** `decode` uses `errors="replace"`, so decoded strings may contain `�` where token boundaries split multi-byte characters — the same caveat documented for the production `Encoding.decode`.
