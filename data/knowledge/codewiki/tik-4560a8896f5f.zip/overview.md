# tiktoken

## Introduction

`tiktoken` is a fast [Byte Pair Encoding (BPE)](https://en.wikipedia.org/wiki/Byte_pair_encoding) tokeniser for use with OpenAI's models. It converts text into sequences of integer tokens (and back) using a reversible, lossless BPE scheme that operates on arbitrary UTF-8 text.

The library is designed around three goals:

1. **Speed** — the hot path (regex splitting + BPE merging) is implemented in Rust (`src/lib.rs`, `src/py.rs`) and exposed to Python through the `_tiktoken` extension module. `tiktoken` is typically 3–6× faster than comparable open-source tokenisers.
2. **Extensibility** — new encodings can be registered through the `tiktoken_ext` namespace-package plugin mechanism, or simply constructed and passed around directly.
3. **Correctness & safety** — special tokens (e.g. `<|endoftext|>`) are guarded so that arbitrary user text cannot accidentally be interpreted as a control token.

The public Python API is intentionally small:

```python
import tiktoken

enc = tiktoken.get_encoding("o200k_base")
assert enc.decode(enc.encode("hello world")) == "hello world"

# Tokeniser for a specific OpenAI model:
enc = tiktoken.encoding_for_model("gpt-4o")
```

## Architecture Overview

`tiktoken` is layered: a thin public API (`tiktoken/__init__.py`) delegates to a registry that discovers encoding constructors, which in turn build `Encoding` objects backed by a Rust core. Model-name resolution and data loading sit alongside this flow.

```mermaid
graph TD
    subgraph Public API
        INIT["tiktoken/__init__.py<br/>(Encoding, get_encoding,<br/>encoding_for_model, ...)"]
    end

    subgraph Resolution
        MODEL["model.py<br/>encoding_for_model /<br/>encoding_name_for_model"]
        REG["registry.py<br/>get_encoding /<br/>list_encoding_names"]
    end

    subgraph Construction
        EXT["tiktoken_ext/openai_public.py<br/>ENCODING_CONSTRUCTORS"]
        LOAD["load.py<br/>load_tiktoken_bpe /<br/>data_gym_to_mergeable_bpe_ranks"]
    end

    subgraph Runtime
        CORE["core.py<br/>Encoding"]
        RUST["_tiktoken (Rust)<br/>CoreBPE"]
    end

    subgraph Auxiliary
        EDU["_educational.py<br/>SimpleBytePairEncoding"]
        SCRIPTS["scripts/<br/>benchmark.py, redact.py"]
    end

    INIT --> MODEL
    INIT --> REG
    INIT --> CORE
    MODEL --> REG
    REG --> EXT
    EXT --> LOAD
    REG --> CORE
    CORE --> RUST
    EDU --> CORE
    SCRIPTS --> CORE
```

### Request flow: `tiktoken.get_encoding("cl100k_base")`

```mermaid
sequenceDiagram
    participant User
    participant Registry as registry.get_encoding
    participant Plugins as _available_plugin_modules
    participant Ext as openai_public.ENCODING_CONSTRUCTORS
    participant Load as load.load_tiktoken_bpe
    participant Core as Encoding.__init__

    User->>Registry: get_encoding("cl100k_base")
    Registry->>Registry: check ENCODINGS cache
    alt not cached
        Registry->>Plugins: discover tiktoken_ext modules
        Plugins-->>Registry: ["tiktoken_ext.openai_public"]
        Registry->>Ext: read ENCODING_CONSTRUCTORS
        Ext->>Load: load_tiktoken_bpe(url, hash)
        Load-->>Ext: mergeable_ranks
        Ext-->>Registry: constructor kwargs
        Registry->>Core: Encoding(**kwargs)
        Core-->>Registry: Encoding instance
        Registry->>Registry: cache in ENCODINGS
    end
    Registry-->>User: Encoding
```

## Sub-modules

The module is organised into the following sub-modules. Each has its own detailed documentation.

| Sub-module | Responsibility | Documentation |
| --- | --- | --- |
| **Core Encoding** | The `Encoding` class: encode/decode, batching, special-token handling, offsets, pickling. Wraps the Rust `CoreBPE`. | [task0_core_encoding.md](task0_core_encoding.md) |
| **Registry** | Plugin discovery via the `tiktoken_ext` namespace package, constructor caching, and the `get_encoding` / `list_encoding_names` entry points. | [task0_registry.md](task0_registry.md) |
| **Model Mapping** | Maps OpenAI model names (and prefixes) to encoding names via `encoding_for_model` / `encoding_name_for_model`. | [task0_model_mapping.md](task0_model_mapping.md) |
| **Loading** | Downloads, caches, and hash-verifies BPE data files; parses them into `mergeable_ranks` dictionaries. | [task0_loading.md](task0_loading.md) |
| **Built-in Encodings** | The `ENCODING_CONSTRUCTORS` registry in `tiktoken_ext/openai_public.py` defining `gpt2`, `r50k_base`, `p50k_base`, `p50k_edit`, `cl100k_base`, and `o200k_base`. | [task0_builtin_encodings.md](task0_builtin_encodings.md) |
| **Educational** | A pure-Python, readable BPE implementation (`SimpleBytePairEncoding`) for learning and visualising the algorithm. | [task0_educational.md](task0_educational.md) |
| **Scripts** | Developer utilities: `benchmark.py` (performance comparison) and `redact.py` (source redaction). | [task0_scripts.md](task0_scripts.md) |

## Component Dependency Graph

```mermaid
graph LR
    subgraph "tiktoken package"
        core["core.py"]
        registry["registry.py"]
        model["model.py"]
        load["load.py"]
        educational["_educational.py"]
    end

    ext["tiktoken_ext/openai_public.py"]
    rust["_tiktoken (Rust ext)"]

    model --> registry
    registry --> core
    registry --> ext
    ext --> load
    core --> rust
    educational --> core
    educational --> registry
```

## Key Concepts

- **Mergeable ranks** — a `dict[bytes, int]` mapping token byte sequences to their merge priority (rank). Lower rank = higher priority.
- **Pattern string (`pat_str`)** — a regex used to split input text into "words" before BPE merging. Each encoding has its own pattern tuned for its training data.
- **Special tokens** — artificial tokens (e.g. `<|endoftext|>`, `<|fim_prefix|>`) that unlock model capabilities. They are guarded by `allowed_special` / `disallowed_special` parameters to prevent accidental injection.
- **`ENCODING_CONSTRUCTORS`** — the plugin contract: a module-level dict mapping encoding names to zero-argument factory functions returning `Encoding` kwargs.

## Extending tiktoken

There are two supported extension paths (see the project README for full examples):

1. **Direct construction** — build an `Encoding` yourself and pass it around. Useful when you only need a custom special-token set.
2. **Plugin registration** — create a namespace package under `tiktoken_ext` exposing an `ENCODING_CONSTRUCTORS` dict so that `tiktoken.get_encoding` can discover it. See [task0_registry.md](task0_registry.md) and [task0_builtin_encodings.md](task0_builtin_encodings.md) for the exact contract.

## Related Modules

- The Rust core (`src/lib.rs`, `src/py.rs`) implements `CoreBPE`, the performance-critical BPE engine consumed by [task0_core_encoding.md](task0_core_encoding.md).
- The test suite under `tests/` exercises encoding round-trips, offsets, pickling, and the public API.
