# Core Encoding Module

## Introduction

The `task0_core_encoding` module is the heart of the tiktoken library. It defines the `Encoding` class, which is the primary user-facing abstraction for converting text to tokens (encoding) and tokens back to text (decoding). This module orchestrates the interaction between a Python-level API and a high-performance Rust BPE (Byte Pair Encoding) core, while enforcing safety rules around special tokens.

The module is responsible for:

- Providing a stable, ergonomic Python API for tokenization.
- Delegating the performance-critical BPE merge operations to the Rust `_tiktoken.CoreBPE` backend.
- Guarding against accidental encoding of special tokens (which could be used to manipulate models).
- Supporting batch, numpy, and "unstable completion" encoding variants.

> **Note:** This module does not define *which* encodings exist. The concrete encoding definitions (vocabularies, regex patterns, special tokens) live in [task0_builtin_encodings](task0_builtin_encodings.md), and the mechanism to look them up lives in [task0_registry](task0_registry.md).

---

## Architecture Overview

The `Encoding` class acts as a thin, safety-aware facade over the Rust `CoreBPE` engine. It holds the encoding's configuration (name, regex pattern, mergeable ranks, special tokens) and exposes methods that either delegate directly to Rust or add Python-level validation.

```mermaid
graph TD
    User["User Code"] -->|encode / decode| Encoding["Encoding (core.py)"]
    Encoding -->|delegates BPE ops| CoreBPE["_tiktoken.CoreBPE (Rust)"]
    Encoding -->|special token guard| Regex["_special_token_regex"]
    Regex -->|on match| Raise["raise_disallowed_special_token"]
    Encoding -.->|constructed by| Registry["task0_registry"]
    Registry -.->|uses constructors from| Builtin["task0_builtin_encodings"]
    Builtin -.->|loads vocab via| Loading["task0_loading"]
    Model["task0_model_mapping"] -.->|resolves name then calls| Registry
```

### Key Design Principles

1. **Rust-backed performance:** All heavy BPE merging is performed by `_tiktoken.CoreBPE`. The Python layer only handles configuration, validation, and convenience wrappers.
2. **Safety by default:** `encode` raises an error when it encounters text matching a disallowed special token, preventing accidental injection.
3. **Lazy construction:** `Encoding` objects are typically created on demand by the registry, not directly by users.
4. **Pickle-friendly:** Registered encodings are pickled by reference (name only) to avoid serializing large vocabularies.

---

## Core Components

### `Encoding`

The central class. It is constructed with a name, a regex pattern string (`pat_str`), a mapping of mergeable token bytes to ranks, and a mapping of special token strings to token values.

#### Construction

```python
Encoding(
    name="cl100k_base",
    pat_str=r"""...""",
    mergeable_ranks={b"hello": 31373, ...},
    special_tokens={"<|endoftext|>": 100257, ...},
    explicit_n_vocab=None,
)
```

During construction, the class:

- Computes `max_token_value` as the maximum rank across mergeable and special tokens.
- Optionally validates `explicit_n_vocab` against the total vocabulary size.
- Instantiates the Rust backend: `self._core_bpe = _tiktoken.CoreBPE(mergeable_ranks, special_tokens, pat_str)`.

> **Important:** The `mergeable_ranks` dictionary's *values* must correspond to merge priority (rank order). This ordering is what the BPE algorithm relies on.

#### Encoding Methods

| Method | Purpose | Special Token Handling |
| --- | --- | --- |
| `encode_ordinary(text)` | Encode ignoring special tokens (fastest) | None — special tokens treated as normal text |
| `encode(text, allowed_special, disallowed_special)` | Full-featured encode with safety checks | Configurable via parameters |
| `encode_to_numpy(text, ...)` | Encode directly into a `numpy.uint32` array | Same as `encode` |
| `encode_ordinary_batch(text, num_threads)` | Parallel `encode_ordinary` over a list | None |
| `encode_batch(text, num_threads, ...)` | Parallel `encode` over a list | Configurable |
| `encode_with_unstable(text, ...)` | Returns stable tokens + possible completions | Configurable |
| `encode_single_token(text_or_bytes)` | Encode a single token's text to its value | Encodes *all* special tokens |

#### Decoding Methods

| Method | Purpose |
| --- | --- |
| `decode_bytes(tokens)` | Decode tokens to raw bytes |
| `decode(tokens, errors)` | Decode tokens to a UTF-8 string (lossy by default) |
| `decode_single_token_bytes(token)` | Decode one token to bytes |
| `decode_tokens_bytes(tokens)` | Decode tokens to a list of per-token bytes (useful for visualization) |
| `decode_with_offsets(tokens)` | Decode to text plus character offsets per token |
| `decode_batch(batch, errors, num_threads)` | Parallel decode over a batch |
| `decode_bytes_batch(batch, num_threads)` | Parallel `decode_bytes` over a batch |

#### Miscellaneous Properties & Methods

| Member | Description |
| --- | --- |
| `name` | The encoding's name (e.g. `"cl100k_base"`) |
| `max_token_value` | Highest token value in the vocabulary |
| `n_vocab` | `max_token_value + 1` (backwards compatibility) |
| `eot_token` | The `<|endoftext|>` token value |
| `special_tokens_set` | Cached set of all special token strings |
| `is_special_token(token)` | Whether a token value is a special token |
| `token_byte_values()` | List of all token byte values |

#### Private / Internal Methods

- `_encode_single_piece(text_or_bytes)` — Encodes bytes without regex splitting; does not encode special tokens.
- `_encode_only_native_bpe(text)` — Performs regex splitting in Python (used for testing/validation).
- `_encode_bytes(text)` — Direct byte-level encoding via the Rust core.
- `__getstate__` / `__setstate__` — Custom pickling that serializes registered encodings by name reference.

### `_special_token_regex`

```python
@functools.lru_cache(maxsize=128)
def _special_token_regex(tokens: frozenset[str]) -> "regex.Pattern[str]":
    inner = "|".join(regex.escape(token) for token in tokens)
    return regex.compile(f"({inner})")
```

A cached helper that builds a compiled regex matching any of the given special tokens. The `lru_cache` avoids recompiling the same pattern repeatedly, which matters because `encode` may be called in tight loops. Tokens are escaped to prevent regex metacharacters in token strings from being interpreted.

### `raise_disallowed_special_token`

```python
def raise_disallowed_special_token(token: str) -> NoReturn:
    raise ValueError(...)
```

Raises a descriptive `ValueError` when text matching a disallowed special token is encountered. The error message guides the user toward the correct fix (`allowed_special` or `disallowed_special` parameters).

---

## Special Token Safety Model

The most subtle aspect of this module is its handling of special tokens. Special tokens (like `<|endoftext|>` or fill-in-the-middle markers) can unlock model capabilities, so accidentally encoding user text that *looks like* a special token is a security concern.

```mermaid
flowchart TD
    Start["encode(text, allowed_special, disallowed_special)"] --> ResolveAllowed{"allowed_special == 'all'?"}
    ResolveAllowed -->|Yes| AllAllowed["allowed_special = all special tokens"]
    ResolveAllowed -->|No| KeepAllowed["use provided set"]
    AllAllowed --> ResolveDisallowed
    KeepAllowed --> ResolveDisallowed
    ResolveDisallowed{"disallowed_special == 'all'?"} -->|Yes| AllDisallowed["disallowed = all - allowed"]
    ResolveDisallowed -->|No| KeepDisallowed["use provided collection"]
    AllDisallowed --> Check
    KeepDisallowed --> Check
    Check{"disallowed_special non-empty?"} -->|No| Encode
    Check -->|Yes| Search["_special_token_regex(disallowed).search(text)"]
    Search --> Match{"Match found?"}
    Match -->|Yes| Raise["raise_disallowed_special_token"]
    Match -->|No| Encode["self._core_bpe.encode(text, allowed_special)"]
    Encode --> UnicodeErr{"UnicodeEncodeError?"}
    UnicodeErr -->|Yes| Fixup["Fix surrogate pairs via utf-16 roundtrip"]
    UnicodeErr -->|No| Done["return tokens"]
    Fixup --> Done
```

### Parameter Semantics

- `allowed_special="all"` — Treat all special-token-looking text as actual special tokens.
- `allowed_special={...}` — Treat only the listed tokens as special.
- `disallowed_special="all"` (default) — Raise if any special token (not in `allowed_special`) appears.
- `disallowed_special=()` — Disable the check entirely; encode everything as normal text.

### Unicode Handling

BPE operates on bytes, but the regex operates on Unicode. If a `str` containing invalid UTF-8 (e.g. lone surrogates) is passed to Rust, it raises `UnicodeEncodeError`. The module catches this and performs a "quick and dirty" fixup:

```python
text = text.encode("utf-16", "surrogatepass").decode("utf-16", "replace")
```

This introduces a case where `encode` + `decode` does not round-trip a Python string, but it allows otherwise-unsupported input to be processed.

---

## Data Flow

The following diagram shows how a typical `encode` call flows through the system, from user input to token output.

```mermaid
sequenceDiagram
    participant U as User
    participant E as Encoding
    participant R as _special_token_regex
    participant C as CoreBPE (Rust)

    U->>E: encode("hello <|endoftext|>")
    E->>E: resolve allowed/disallowed sets
    E->>R: search for disallowed special tokens
    R-->>E: match or None
    alt disallowed token found
        E-->>U: raise ValueError
    else no disallowed token
        E->>C: encode(text, allowed_special)
        C-->>E: list[int]
        E-->>U: [tokens]
    end
```

---

## Component Interaction

```mermaid
graph LR
    subgraph "task0_core_encoding"
        Encoding
        Regex["_special_token_regex"]
        Raise["raise_disallowed_special_token"]
    end
    subgraph "Rust Backend"
        CoreBPE["_tiktoken.CoreBPE"]
    end
    subgraph "task0_registry"
        GetEncoding["get_encoding"]
    end
    subgraph "task0_builtin_encodings"
        Constructors["gpt2, cl100k_base, ..."]
    end

    GetEncoding -->|Encoding(**constructor())| Encoding
    Constructors -->|provides config dict| GetEncoding
    Encoding -->|uses| Regex
    Regex -->|on match| Raise
    Encoding -->|delegates| CoreBPE
```

### Relationship to Other Modules

- **[task0_registry](task0_registry.md):** The registry constructs `Encoding` instances by calling the constructor functions and passing their returned dictionaries as keyword arguments. It also caches instances and handles pickling by reference.
- **[task0_builtin_encodings](task0_builtin_encodings.md):** Provides the concrete configuration dictionaries (`name`, `pat_str`, `mergeable_ranks`, `special_tokens`) that `Encoding.__init__` consumes.
- **[task0_model_mapping](task0_model_mapping.md):** Maps model names to encoding names, then delegates to the registry to obtain an `Encoding`.
- **[task0_loading](task0_loading.md):** Supplies the `mergeable_ranks` dictionaries loaded from `.tiktoken` files, which are passed into `Encoding`.
- **[task0_educational](task0_educational.md):** Provides a pure-Python reference implementation of BPE for learning purposes, contrasting with the Rust-backed `Encoding`.

---

## Pickling Behavior

`Encoding` implements custom pickling to avoid serializing large vocabularies:

```mermaid
flowchart TD
    Pickle["pickle.dumps(enc)"] --> GetState["__getstate__"]
    GetState --> Registered{"enc is registry.ENCODINGS[name]?"}
    Registered -->|Yes| ByName["return name (string)"]
    Registered -->|No| ByDict["return config dict"]
    ByName --> Unpickle["__setstate__"]
    ByDict --> Unpickle
    Unpickle --> IsStr{"value is str?"}
    IsStr -->|Yes| Lookup["registry.get_encoding(value).__dict__"]
    IsStr -->|No| Reinit["self.__init__(**value)"]
```

- **Registered encodings** are pickled by name only, then resolved back through the registry on unpickling. This keeps pickles small and ensures the canonical instance is reused.
- **Ad-hoc encodings** (not in the registry) are pickled with their full configuration dictionary.

---

## Summary

The `task0_core_encoding` module provides the `Encoding` class — the primary interface for tokenization in tiktoken. It balances three concerns:

1. **Performance** — by delegating BPE operations to the Rust `CoreBPE` backend.
2. **Safety** — by enforcing special-token rules through `_special_token_regex` and `raise_disallowed_special_token`.
3. **Ergonomics** — by offering a rich set of encode/decode variants (batch, numpy, offsets, unstable completions).

It sits at the center of the tiktoken architecture, consuming configuration from the registry and built-in encodings, and serving as the object that users interact with directly.
