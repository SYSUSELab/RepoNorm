# task0_scripts

## Introduction

The `task0_scripts` module contains standalone command-line utilities and benchmarking tools that support the `tiktoken` library. Unlike the core encoding modules, these scripts are not part of the public API consumed by downstream applications. Instead, they serve two distinct operational purposes:

1. **Performance benchmarking** (`scripts/benchmark.py`) — measures the throughput of `tiktoken`'s batch encoding against a reference implementation (Hugging Face `transformers`).
2. **Repository maintenance / redaction** (`scripts/redact.py`) — a maintenance tool that strips or deletes sensitive/private content from tracked files before publication.

These scripts depend on the public encoding API exposed by the core modules (see [task0_core_encoding.md](task0_core_encoding.md) and [task0_registry.md](task0_registry.md)) but are otherwise self-contained executables.

---

## Module Architecture

The module consists of two independent scripts that share no code between them. Each script is a thin orchestration layer over either the `tiktoken` public API or the local filesystem/git.

```mermaid
graph TD
    subgraph "task0_scripts"
        B["scripts/benchmark.py<br/>benchmark_batch"]
        R["scripts/redact.py<br/>redact / redact_file / main"]
    end

    subgraph "tiktoken public API"
        REG["tiktoken.registry<br/>get_encoding"]
        ENC["tiktoken.core.Encoding<br/>encode_ordinary_batch"]
    end

    subgraph "External"
        HF["transformers<br/>GPT2TokenizerFast"]
        GIT["git ls-files"]
        FS["Filesystem / Path"]
    end

    B --> REG
    REG --> ENC
    B --> HF
    R --> GIT
    R --> FS
```

---

## Component Overview

| Script | Core Components | Purpose |
| --- | --- | --- |
| `scripts/benchmark.py` | `benchmark_batch` | Compare `tiktoken` batch-encoding throughput vs. Hugging Face |
| `scripts/redact.py` | `redact`, `redact_file`, `main` | Remove or delete redacted content from tracked files |

---

## scripts/benchmark.py

### Purpose

`benchmark_batch` is a performance harness that measures how many bytes per second `tiktoken` can encode when processing a batch of documents, and compares that figure against the equivalent Hugging Face `GPT2TokenizerFast` implementation.

### Component: `benchmark_batch(documents: list[str]) -> None`

The function performs the following steps:

1. **Reads thread configuration** from the `RAYON_NUM_THREADS` environment variable. This controls the parallelism used by the underlying Rust `CoreBPE` implementation.
2. **Computes total input size** by summing the byte length of every document.
3. **Warms up `tiktoken`** by fetching the `gpt2` encoding via `tiktoken.get_encoding("gpt2")` and encoding a small string. Warming up ensures lazy initialization (loading BPE ranks, constructing the `CoreBPE`) is excluded from the timed region.
4. **Times `tiktoken`** using `time.perf_counter_ns()` around a call to `enc.encode_ordinary_batch(documents, num_threads=num_threads)`.
5. **Warms up Hugging Face** by loading `GPT2TokenizerFast.from_pretrained("gpt2")` and encoding a small string. `model_max_length` is set to a very large value to silence length warnings.
6. **Times Hugging Face** around `hf_enc(documents)`.
7. **Prints throughput** for both implementations in bytes/second.

### Data Flow

```mermaid
sequenceDiagram
    participant User
    participant benchmark_batch
    participant tiktoken as tiktoken.get_encoding
    participant CoreBPE as Encoding.encode_ordinary_batch
    participant HF as GPT2TokenizerFast

    User->>benchmark_batch: documents
    benchmark_batch->>benchmark_batch: read RAYON_NUM_THREADS
    benchmark_batch->>benchmark_batch: sum byte lengths
    benchmark_batch->>tiktoken: get_encoding("gpt2")
    tiktoken-->>benchmark_batch: Encoding
    benchmark_batch->>CoreBPE: encode("warmup")
    benchmark_batch->>CoreBPE: encode_ordinary_batch(documents, num_threads)
    CoreBPE-->>benchmark_batch: list[list[int]]
    benchmark_batch->>benchmark_batch: compute bytes/s
    benchmark_batch->>HF: from_pretrained("gpt2")
    HF-->>benchmark_batch: tokenizer
    benchmark_batch->>HF: tokenizer(documents)
    HF-->>benchmark_batch: encodings
    benchmark_batch->>benchmark_batch: compute bytes/s
    benchmark_batch-->>User: print results
```

### Dependencies

- **`tiktoken`** — the library under test. `get_encoding` is documented in [task0_registry.md](task0_registry.md); `encode_ordinary_batch` is documented in [task0_core_encoding.md](task0_core_encoding.md).
- **`transformers`** — imported lazily inside the function to avoid a hard dependency for users who only want the `tiktoken` measurement.
- **`blobfile`** — imported at module level (used by the broader benchmark tooling to stream documents).
- **Standard library** — `base64`, `functools`, `gzip`, `json`, `os`, `random`, `time`, `typing`.

### Notes

- The `RAYON_NUM_THREADS` environment variable is **required**; a missing value raises `KeyError`.
- The comparison is intentionally apples-to-apples: both implementations are warmed up before timing, and both process the same `documents` list.

---

## scripts/redact.py

### Purpose

`redact.py` is a maintenance utility used to strip private or sensitive content from files in the `tiktoken` repository before they are published. It supports two redaction strategies:

1. **Deletion** — if a file's first line contains the word `redact`, the entire file is deleted.
2. **Inline redaction** — content between paired redaction markers is removed, leaving the rest of the file intact.

### Components

#### `redact_file(path: Path, dry_run: bool) -> None`

Processes a single file. The logic is:

1. **Skip** non-existent paths and directories.
2. **Skip** empty files.
3. **Delete** the file if its first line contains `"redact"` (unless `dry_run`).
4. **Redact inline** if any redaction marker pair is found. The markers are:
   - `# ===== redact-beg =====` / `# ===== redact-end =====` (Python-style comments)
   - `<!--- redact-beg -->` / `<!--- redact-end -->` (HTML-style comments)
5. **Skip** files with no markers.

The inline redaction works by building a regex alternation of all markers, splitting the text on that pattern, and keeping only the even-indexed segments (`re.split(...)[::2]`). This effectively removes everything between a `beg` and `end` marker.

#### `redact(dry_run: bool) -> None`

The orchestrator. It:

1. Locates the repository root (`Path(__file__).parent.parent`) and asserts it is named `tiktoken` and contains `pyproject.toml` — a safety check to prevent running against the wrong directory.
2. Enumerates tracked files via `git ls-files`. If git is unavailable (`CalledProcessError`), it falls back to globbing `**/*`.
3. Calls `redact_file` on each path.

#### `main() -> None`

The CLI entry point. It parses a `--dry-run` argument with a custom lambda type that treats any value other than one starting with `f`/`F` as `True`. The default is `True` (dry run). After running, it prints a reminder if still in dry-run mode.

### Process Flow

```mermaid
flowchart TD
    A["main()"] --> B["parse --dry-run"]
    B --> C["redact(dry_run)"]
    C --> D["locate repo root<br/>assert name == tiktoken"]
    D --> E{"git ls-files<br/>succeeds?"}
    E -- yes --> F["paths = tracked files"]
    E -- no --> G["paths = glob('**/*')"]
    F --> H["for each path"]
    G --> H
    H --> I["redact_file(path, dry_run)"]
    I --> J{"exists and<br/>not dir?"}
    J -- no --> K["return (skip)"]
    J -- yes --> L{"empty?"}
    L -- yes --> K
    L -- no --> M{"first line<br/>contains 'redact'?"}
    M -- yes --> N["delete file<br/>(unless dry_run)"]
    M -- no --> O{"marker pair<br/>found?"}
    O -- yes --> P["strip content between markers<br/>(unless dry_run)"]
    O -- no --> Q["print Skipped"]
```

### Redaction Marker Semantics

```mermaid
graph LR
    subgraph "Before"
        A1["line 1"]
        A2["# ===== redact-beg ====="]
        A3["SECRET CONTENT"]
        A4["# ===== redact-end ====="]
        A5["line 5"]
    end
    subgraph "After"
        B1["line 1"]
        B2["line 5"]
    end
    A1 --> B1
    A5 --> B2
```

### Dependencies

- **Standard library** — `argparse`, `re`, `subprocess`, `pathlib`.
- **`git`** — used to enumerate tracked files (with a filesystem glob fallback).

### Notes

- The `--dry-run` flag defaults to `True` for safety. To actually modify files, pass `--dry-run=false`.
- The repository-root assertion (`tiktoken_root.name == "tiktoken"`) is a guard against accidentally redacting an unrelated directory.

---

## Relationship to Other Modules

The scripts module sits at the top of the dependency graph and consumes the public API of the core modules:

```mermaid
graph TD
    SCRIPTS["task0_scripts"]
    REGISTRY["task0_registry<br/>get_encoding"]
    CORE["task0_core_encoding<br/>Encoding.encode_ordinary_batch"]
    MODEL["task0_model_mapping"]
    LOAD["task0_loading"]
    BUILTIN["task0_builtin_encodings"]
    EDU["task0_educational"]

    SCRIPTS --> REGISTRY
    REGISTRY --> CORE
    REGISTRY --> BUILTIN
    BUILTIN --> LOAD
    MODEL --> REGISTRY
    EDU --> CORE
```

- `benchmark_batch` calls `tiktoken.get_encoding("gpt2")` — see [task0_registry.md](task0_registry.md) for how encodings are resolved and constructed.
- The `gpt2` encoding itself is defined in [task0_builtin_encodings.md](task0_builtin_encodings.md).
- The `encode_ordinary_batch` method being benchmarked is part of the `Encoding` class documented in [task0_core_encoding.md](task0_core_encoding.md).
- `redact.py` has no dependency on the `tiktoken` library itself; it operates purely on the repository filesystem.

---

## Summary

| Aspect | benchmark.py | redact.py |
| --- | --- | --- |
| **Type** | Performance harness | Maintenance utility |
| **Entry point** | `benchmark_batch` | `main` |
| **Depends on tiktoken** | Yes (`get_encoding`, `encode_ordinary_batch`) | No |
| **External deps** | `transformers`, `blobfile` | `git` |
| **Side effects** | Prints throughput metrics | Deletes/rewrites files |
| **Safety mechanism** | Warmup before timing | `--dry-run` default + repo-root assertion |
