# Built-in Encodings (`tiktoken_ext/openai_public.py`)

## Introduction

The `task0_builtin_encodings` module defines the **built-in encoding constructors** that ship with `tiktoken`. It is the canonical source of the six public OpenAI encodings — `gpt2`, `r50k_base`, `p50k_base`, `p50k_edit`, `cl100k_base`, and `o200k_base` — and exposes them through a single `ENCODING_CONSTRUCTORS` dictionary.

Each constructor is a zero-argument function that returns a keyword-argument dictionary suitable for instantiating an [`Encoding`](task0_core_encoding.md) object. The module is discovered as a **plugin** by the [registry](task0_registry.md), which imports it and merges its `ENCODING_CONSTRUCTORS` into the global encoding table.

This module is the bridge between the abstract `Encoding` class and the concrete, downloadable BPE vocabulary files hosted on OpenAI's public blob storage.

---

## Purpose and Core Functionality

The module serves three primary responsibilities:

1. **Declare encoding metadata** — vocabulary size, regex split pattern (`pat_str`), and special-token mappings for each encoding.
2. **Load mergeable BPE ranks** — fetch and parse the vocabulary files (via the [loading module](task0_loading.md)) and verify their integrity with SHA-256 hashes.
3. **Register constructors** — expose all encodings through the `ENCODING_CONSTRUCTORS` mapping consumed by the [registry](task0_registry.md).

---

## Architecture

```mermaid
graph TD
    subgraph "task0_builtin_encodings"
        EC[ENCODING_CONSTRUCTORS]
        G[gpt2]
        R[r50k_base]
        P[p50k_base]
        PE[p50k_edit]
        C[cl100k_base]
        O[o200k_base]
    end

    subgraph "task0_loading"
        DG[data_gym_to_mergeable_bpe_ranks]
        LT[load_tiktoken_bpe]
    end

    subgraph "task0_registry"
        FC[_find_constructors]
        GE[get_encoding]
    end

    subgraph "task0_core_encoding"
        ENC[Encoding]
    end

    EC --> G & R & P & PE & C & O
    G --> DG
    R & P & PE & C & O --> LT
    FC -->|imports plugin| EC
    GE -->|looks up| EC
    GE -->|instantiates| ENC
    G & R & P & PE & C & O -->|return kwargs| ENC
```

---

## The Encoding Constructors

All constructors return a dictionary with the following keys (consumed by `Encoding.__init__`):

| Key | Type | Description |
|-----|------|-------------|
| `name` | `str` | Unique encoding name |
| `pat_str` | `str` | Regex pattern used to split input text |
| `mergeable_ranks` | `dict[bytes, int]` | Token bytes → rank (merge priority) |
| `special_tokens` | `dict[str, int]` | Special token string → token value |
| `explicit_n_vocab` | `int` (optional) | Expected total vocabulary size (validated) |

### Encoding Comparison

| Encoding | Vocab Size | Pattern | Special Tokens | Loader |
|----------|-----------|---------|----------------|--------|
| `gpt2` | 50257 | `r50k_pat_str` | `<\|endoftext\|>` | `data_gym_to_mergeable_bpe_ranks` |
| `r50k_base` | 50257 | `r50k_pat_str` | `<\|endoftext\|>` | `load_tiktoken_bpe` |
| `p50k_base` | 50281 | `r50k_pat_str` | `<\|endoftext\|>` | `load_tiktoken_bpe` |
| `p50k_edit` | — | `r50k_pat_str` | EOT + FIM (prefix/middle/suffix) | `load_tiktoken_bpe` |
| `cl100k_base` | — | cl100k pattern | EOT + FIM + `<\|endofprompt\|>` | `load_tiktoken_bpe` |
| `o200k_base` | — | o200k pattern | EOT + `<\|endofprompt\|>` | `load_tiktoken_bpe` |

> **Note:** `p50k_edit`, `cl100k_base`, and `o200k_base` do not set `explicit_n_vocab`, so the vocabulary-size assertion in `Encoding.__init__` is skipped for them.

---

## Special Token Constants

The module defines module-level constants for the special token strings used across encodings:

```python
ENDOFTEXT   = "<|endoftext|>"
FIM_PREFIX  = "<|fim_prefix|>"
FIM_MIDDLE  = "<|fim_middle|>"
FIM_SUFFIX  = "<|fim_suffix|>"
ENDOFPROMPT = "<|endofprompt|>"
```

These are reused as dictionary keys in each constructor's `special_tokens` mapping, ensuring consistency across encodings.

---

## Regex Split Patterns

The `pat_str` controls how input text is segmented before BPE merging. Two distinct patterns are used:

### `r50k_pat_str` (GPT-2 family)

Used by `gpt2`, `r50k_base`, `p50k_base`, and `p50k_edit`. It is a performance-optimized equivalent of the original GPT-2 pattern:

```python
r50k_pat_str = (
    r"""'(?:[sdmt]|ll|ve|re)| ?\p{L}++| ?\p{N}++| ?[^\s\p{L}\p{N}]++|\s++$|\s+(?!\S)|\s"""
)
```

The original GPT-2 release used a slower but semantically equivalent pattern (documented in the source comment).

### `cl100k_base` pattern

A more elaborate pattern handling case-insensitive contractions, multi-byte letters, and newline handling:

```python
r"""'(?i:[sdmt]|ll|ve|re)|[^\r\n\p{L}\p{N}]?+\p{L}++|\p{N}{1,3}+| ?[^\s\p{L}\p{N}]++[\r\n]*+|\s++$|\s*[\r\n]|\s+(?!\S)|\s"""
```

### `o200k_base` pattern

Built by joining seven sub-patterns with `|`, with explicit handling of uppercase/lowercase letter classes and Unicode marks:

```python
pat_str = "|".join([
    r"""[^\r\n\p{L}\p{N}]?[\p{Lu}\p{Lt}\p{Lm}\p{Lo}\p{M}]*[\p{Ll}\p{Lm}\p{Lo}\p{M}]+(?i:'s|'t|'re|'ve|'m|'ll|'d)?""",
    r"""[^\r\n\p{L}\p{N}]?[\p{Lu}\p{Lt}\p{Lm}\p{Lo}\p{M}]+[\p{Ll}\p{Lm}\p{Lo}\p{M}]*(?i:'s|'t|'re|'ve|'m|'ll|'d)?""",
    r"""\p{N}{1,3}""",
    r""" ?[^\s\p{L}\p{N}]+[\r\n/]*""",
    r"""\s*[\r\n]+""",
    r"""\s+(?!\S)""",
    r"""\s+""",
])
```

---

## Data Flow

The following diagram shows how a constructor produces an `Encoding` instance, from remote file download to a usable object.

```mermaid
sequenceDiagram
    participant User
    participant Registry as get_encoding (registry)
    participant Plugin as ENCODING_CONSTRUCTORS
    participant Ctor as e.g. cl100k_base()
    participant Loader as load_tiktoken_bpe (load)
    participant Blob as OpenAI Blob Storage
    participant Enc as Encoding (core)

    User->>Registry: get_encoding("cl100k_base")
    Registry->>Plugin: lookup constructor
    Plugin-->>Registry: cl100k_base
    Registry->>Ctor: cl100k_base()
    Ctor->>Loader: load_tiktoken_bpe(url, expected_hash)
    Loader->>Blob: read_file_cached(url)
    Blob-->>Loader: base64-encoded ranks
    Loader->>Loader: verify SHA-256 hash
    Loader-->>Ctor: dict[bytes, int]
    Ctor-->>Registry: {name, pat_str, mergeable_ranks, special_tokens}
    Registry->>Enc: Encoding(**kwargs)
    Enc-->>Registry: Encoding instance
    Registry-->>User: Encoding instance
```

### Loading Paths

Two distinct loading strategies are used:

```mermaid
graph LR
    subgraph "GPT-2 legacy path"
        G[gpt2] --> DG[data_gym_to_mergeable_bpe_ranks]
        DG --> V[vocab.bpe]
        DG --> E[encoder.json]
        DG -->|cross-validate| DG
    end

    subgraph "tiktoken native path"
        R[r50k_base / p50k_base / p50k_edit / cl100k_base / o200k_base] --> LT[load_tiktoken_bpe]
        LT --> T[*.tiktoken file]
    end
```

- **`gpt2`** uses `data_gym_to_mergeable_bpe_ranks`, which downloads both `vocab.bpe` and `encoder.json`, reconstructs the byte-to-rank mapping, and **cross-validates** that the two files agree (an important sanity check since tiktoken assumes ranks are ordered by merge priority). See [loading module](task0_loading.md) for details.
- **All other encodings** use `load_tiktoken_bpe`, which parses a single base64-encoded `.tiktoken` file where each line is `<base64-token> <rank>`.

---

## Integrity Verification

Every constructor passes an `expected_hash` (SHA-256) to its loader. The loader verifies the downloaded file against this hash before parsing, protecting against corrupted or tampered vocabulary files.

| Encoding | Hash (truncated) |
|----------|------------------|
| `gpt2` (vocab.bpe) | `1ce1664773c50f3e...` |
| `gpt2` (encoder.json) | `196139668be63f3b...` |
| `r50k_base` | `306cd27f03c1a714...` |
| `p50k_base` / `p50k_edit` | `94b5ca7dff4d0076...` |
| `cl100k_base` | `223921b76ee99bde...` |
| `o200k_base` | `446a9538cb6c348e...` |

> `p50k_base` and `p50k_edit` share the same vocabulary file and hash; they differ only in their special-token sets.

---

## Plugin Registration

The module is discovered as a plugin by the [registry](task0_registry.md). The registry's `_find_constructors` function imports available plugin modules and reads their `ENCODING_CONSTRUCTORS` attribute:

```python
ENCODING_CONSTRUCTORS = {
    "gpt2": gpt2,
    "r50k_base": r50k_base,
    "p50k_base": p50k_base,
    "p50k_edit": p50k_edit,
    "cl100k_base": cl100k_base,
    "o200k_base": o200k_base,
}
```

```mermaid
graph TD
    A[_find_constructors] -->|import_module| B[tiktoken_ext.openai_public]
    B -->|read attribute| C[ENCODING_CONSTRUCTORS]
    C -->|merge into global table| D[registry.ENCODING_CONSTRUCTORS]
    D -->|lookup by name| E[get_encoding]
    E -->|Encoding **kwargs| F[Encoding instance]
```

The registry enforces that:
- Each plugin defines `ENCODING_CONSTRUCTORS` (else `ValueError`).
- Encoding names are unique across all plugins (duplicates raise `ValueError`).

---

## Component Interaction Summary

```mermaid
graph TD
    subgraph "Public API"
        GE[get_encoding]
        EFM[encoding_for_model]
    end

    subgraph "task0_builtin_encodings"
        EC[ENCODING_CONSTRUCTORS]
    end

    subgraph "task0_registry"
        FC[_find_constructors]
    end

    subgraph "task0_model_mapping"
        ENFM[encoding_name_for_model]
    end

    subgraph "task0_loading"
        LT[load_tiktoken_bpe]
        DG[data_gym_to_mergeable_bpe_ranks]
    end

    subgraph "task0_core_encoding"
        ENC[Encoding]
    end

    EFM --> ENFM
    ENFM -->|encoding name| GE
    GE --> FC
    FC --> EC
    EC --> LT
    EC --> DG
    GE --> ENC
```

---

## Related Modules

- **[task0_core_encoding.md](task0_core_encoding.md)** — The `Encoding` class that consumes the constructor output.
- **[task0_registry.md](task0_registry.md)** — Discovers this module as a plugin and exposes `get_encoding`.
- **[task0_loading.md](task0_loading.md)** — `load_tiktoken_bpe` and `data_gym_to_mergeable_bpe_ranks` used to fetch and parse vocabulary files.
- **[task0_model_mapping.md](task0_model_mapping.md)** — Maps model names to encoding names resolved by this module.
- **[task0_educational.md](task0_educational.md)** — A from-scratch BPE implementation for learning purposes.

---

## Key Takeaways

1. **Single source of truth** for OpenAI's public encodings, exposed via `ENCODING_CONSTRUCTORS`.
2. **Two loading strategies**: legacy GPT-2 data-gym files (with cross-validation) vs. native `.tiktoken` files.
3. **Hash-verified downloads** ensure vocabulary integrity.
4. **Plugin architecture** allows the registry to discover and merge these constructors dynamically.
5. **Regex patterns** (`pat_str`) are encoding-specific and critical to correct tokenization behavior.
