# task0_registry

## Introduction

The `task0_registry` module (`tiktoken/registry.py`) is the **central discovery and caching layer** of the `tiktoken` library. It is responsible for:

- **Discovering** encoding constructors exposed by installed plugin packages (namespace packages under `tiktoken_ext`).
- **Resolving** an encoding name (e.g. `"cl100k_base"`) into a fully constructed [`Encoding`](task0_core_encoding.md) object.
- **Caching** both the discovered constructors and the constructed `Encoding` instances so that repeated lookups are cheap and thread-safe.
- **Enumerating** all available encoding names.

In short, the registry answers the question *"given a name, give me the tokenizer"* — and it does so lazily, idempotently, and in a thread-safe manner.

---

## Architecture Overview

The registry sits between the public API surface (model mapping, direct name lookups) and the plugin packages that actually define encodings.

```mermaid
graph TD
    subgraph "Public API"
        M["task0_model_mapping<br/>encoding_for_model / encoding_name_for_model"]
        U["User code<br/>tiktoken.get_encoding('cl100k_base')"]
    end

    subgraph "task0_registry (this module)"
        GE["get_encoding()"]
        LEN["list_encoding_names()"]
        FC["_find_constructors()"]
        APM["_available_plugin_modules()"]
        ENC_CACHE["ENCODINGS<br/>(name -> Encoding)"]
        CON_CACHE["ENCODING_CONSTRUCTORS<br/>(name -> callable)"]
    end

    subgraph "Plugin packages"
        EXT["tiktoken_ext namespace package"]
        PUB["task0_builtin_encodings<br/>openai_public.py"]
    end

    subgraph "Core"
        CORE["task0_core_encoding<br/>Encoding"]
    end

    U --> GE
    M --> GE
    GE --> ENC_CACHE
    GE --> FC
    LEN --> FC
    FC --> APM
    FC --> CON_CACHE
    APM --> EXT
    EXT --> PUB
    GE --> CORE
    CON_CACHE -.constructs.-> CORE
```

### Key design decisions

| Decision | Rationale |
|----------|-----------|
| **Namespace package** (`tiktoken_ext`) | `pkgutil.iter_modules` is fast over namespace packages, and it works correctly with editable installs (unlike namespace subpackages of non-namespace packages). |
| **Lazy discovery** | Constructors are only imported when first needed, avoiding import-time cost and side effects. |
| **Two-level caching** | `ENCODING_CONSTRUCTORS` caches the *callables*; `ENCODINGS` caches the *constructed objects* (which are expensive to build because they load BPE ranks). |
| **`threading.RLock`** | All mutation of the caches is guarded by a re-entrant lock, making the registry safe for concurrent use. |
| **Idempotent error handling** | If discovery fails, `ENCODING_CONSTRUCTORS` is reset to `None` so the error is raised consistently on every subsequent call. |

---

## Core Components

### `_available_plugin_modules() -> Sequence[str]`

Discovers the plugin modules that may define encodings.

- Iterates over the `tiktoken_ext` namespace package using `pkgutil.iter_modules`.
- Returns fully-qualified module names (e.g. `tiktoken_ext.openai_public`).
- Decorated with `functools.lru_cache`, so the filesystem scan happens only once per process.

```mermaid
flowchart LR
    A["_available_plugin_modules()"] --> B["pkgutil.iter_modules(<br/>tiktoken_ext.__path__,<br/>tiktoken_ext.__name__ + '.')"]
    B --> C["['tiktoken_ext.openai_public', ...]"]
```

### `_find_constructors() -> None`

Populates the global `ENCODING_CONSTRUCTORS` mapping by importing every available plugin module and reading its `ENCODING_CONSTRUCTORS` attribute.

Behavior:
1. Acquires `_lock`.
2. If `ENCODING_CONSTRUCTORS` is already populated, returns immediately (idempotent).
3. For each plugin module:
   - Imports it via `importlib.import_module`.
   - Reads `mod.ENCODING_CONSTRUCTORS`; raises `ValueError` if the attribute is missing.
   - Merges each `{encoding_name: constructor}` entry into the global dict.
   - Raises `ValueError` on **duplicate encoding names** across plugins.
4. On any exception, resets `ENCODING_CONSTRUCTORS` to `None` before re-raising, ensuring the failure is reproducible.

### `get_encoding(encoding_name: str) -> Encoding`

The primary entry point. Resolves a name to a cached [`Encoding`](task0_core_encoding.md) instance.

```mermaid
flowchart TD
    A["get_encoding(name)"] --> B{"isinstance(name, str)?"}
    B -- No --> E1["raise ValueError"]
    B -- Yes --> C{"name in ENCODINGS?"}
    C -- Yes --> R1["return cached Encoding"]
    C -- No --> D["acquire _lock"]
    D --> C2{"name in ENCODINGS?<br/>(double-check)"}
    C2 -- Yes --> R1
    C2 -- No --> F{"ENCODING_CONSTRUCTORS<br/>is None?"}
    F -- Yes --> G["_find_constructors()"]
    F -- No --> H
    G --> H{"name in<br/>ENCODING_CONSTRUCTORS?"}
    H -- No --> E2["raise ValueError<br/>(unknown encoding)"]
    H -- Yes --> I["constructor = ENCODING_CONSTRUCTORS[name]"]
    I --> J["enc = Encoding(**constructor())"]
    J --> K["ENCODINGS[name] = enc"]
    K --> R2["return enc"]
```

Key characteristics:
- **Fast path**: a lock-free dictionary lookup for already-cached encodings.
- **Double-checked locking**: re-checks the cache after acquiring the lock to avoid redundant construction.
- **Rich error message**: unknown encodings report the discovered plugins and the `tiktoken` version to aid debugging.
- **Construction**: calls the plugin constructor (which returns a kwargs dict) and instantiates `Encoding(**kwargs)`.

### `list_encoding_names() -> list[str]`

Returns the names of all registered encodings.

- Ensures constructors are discovered (calling `_find_constructors()` if needed).
- Returns `list(ENCODING_CONSTRUCTORS)` — the keys of the constructor mapping.

---

## Module-Level State

| Name | Type | Purpose |
|------|------|---------|
| `_lock` | `threading.RLock` | Guards all cache mutation. |
| `ENCODINGS` | `dict[str, Encoding]` | Cache of constructed encoding objects. |
| `ENCODING_CONSTRUCTORS` | `dict[str, Callable[[], dict[str, Any]]] \| None` | Cache of plugin-provided constructor callables; `None` means "not yet discovered". |

---

## Data Flow

The following sequence shows the full lifecycle from a user request to a constructed encoding.

```mermaid
sequenceDiagram
    participant User
    participant Registry as get_encoding()
    participant Find as _find_constructors()
    participant Plugins as _available_plugin_modules()
    participant Ext as tiktoken_ext.openai_public
    participant Core as Encoding

    User->>Registry: get_encoding("cl100k_base")
    Registry->>Registry: check ENCODINGS (miss)
    Registry->>Registry: acquire _lock
    Registry->>Find: _find_constructors()
    Find->>Plugins: _available_plugin_modules()
    Plugins-->>Find: ["tiktoken_ext.openai_public"]
    Find->>Ext: import_module + read ENCODING_CONSTRUCTORS
    Ext-->>Find: {"cl100k_base": cl100k_base, ...}
    Find-->>Registry: ENCODING_CONSTRUCTORS populated
    Registry->>Ext: call cl100k_base()
    Ext-->>Registry: {"name", "pat_str", "mergeable_ranks", "special_tokens"}
    Registry->>Core: Encoding(**kwargs)
    Core-->>Registry: Encoding instance
    Registry->>Registry: ENCODINGS["cl100k_base"] = enc
    Registry-->>User: Encoding instance
```

---

## Dependencies

### Internal dependencies

| Dependency | Relationship |
|------------|--------------|
| [`task0_core_encoding`](task0_core_encoding.md) | The registry constructs and caches `Encoding` objects. `Encoding.__getstate__`/`__setstate__` also reference `tiktoken.registry.ENCODINGS` and `get_encoding` for pickle-by-reference optimization. |
| [`task0_builtin_encodings`](task0_builtin_encodings.md) | `tiktoken_ext.openai_public` is the default plugin that supplies `ENCODING_CONSTRUCTORS` (e.g. `cl100k_base`, `o200k_base`). |
| [`task0_model_mapping`](task0_model_mapping.md) | `encoding_for_model` resolves a model name to an encoding name, then delegates to `get_encoding`. |
| [`task0_loading`](task0_loading.md) | Plugin constructors (invoked by the registry) use `load_tiktoken_bpe` to fetch BPE ranks. |

### External dependencies

- `importlib`, `pkgutil` — plugin discovery and import.
- `functools` — `lru_cache` for plugin module listing.
- `threading` — `RLock` for thread safety.
- `tiktoken_ext` — the namespace package scanned for plugins.

```mermaid
graph LR
    REG["task0_registry"]
    REG --> CORE["task0_core_encoding"]
    REG --> EXT["tiktoken_ext namespace"]
    EXT --> PUB["task0_builtin_encodings"]
    PUB --> LOAD["task0_loading"]
    MODEL["task0_model_mapping"] --> REG
```

---

## Extension Points

The registry is designed to be **extensible without modification**. To add a new encoding:

1. Create a module inside the `tiktoken_ext` namespace package.
2. Define a module-level `ENCODING_CONSTRUCTORS` dictionary mapping encoding names to zero-argument callables.
3. Each callable must return a kwargs dict accepted by [`Encoding`](task0_core_encoding.md) (`name`, `pat_str`, `mergeable_ranks`, `special_tokens`, optional `explicit_n_vocab`).

The registry will automatically discover the new module on the next process start (or first call, since discovery is lazy and `lru_cache`d).

> **Note:** Duplicate encoding names across plugins raise a `ValueError` during discovery, so names must be globally unique.

---

## Related Modules

- [task0_core_encoding](task0_core_encoding.md) — the `Encoding` class constructed and cached by the registry.
- [task0_model_mapping](task0_model_mapping.md) — maps model names to encoding names before calling `get_encoding`.
- [task0_builtin_encodings](task0_builtin_encodings.md) — the default plugin providing `ENCODING_CONSTRUCTORS`.
- [task0_loading](task0_loading.md) — BPE data loading used by plugin constructors.
- [task0_educational](task0_educational.md) — a standalone educational BPE implementation, independent of the registry.
- [task0_scripts](task0_scripts.md) — benchmarking and redaction utilities that consume encodings via the registry.
