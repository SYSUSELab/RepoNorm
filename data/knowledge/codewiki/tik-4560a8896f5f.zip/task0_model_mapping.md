# Model Mapping Module (`tiktoken/model.py`)

## Introduction

The **Model Mapping** module provides the bridge between human-readable OpenAI model names (e.g., `"gpt-4o"`, `"gpt-3.5-turbo"`) and the underlying tokenizer encodings used to process text for those models. It answers two fundamental questions:

1. **Which encoding does a given model use?** — via `encoding_name_for_model`
2. **Give me the actual encoding object for a model** — via `encoding_for_model`

This module is a thin, stateless translation layer. It contains no tokenization logic itself; instead, it maps model identifiers to encoding names and delegates the actual encoding construction to the [Registry module](task0_registry.md).

---

## Core Components

| Component | Signature | Purpose |
|-----------|-----------|---------|
| `encoding_name_for_model` | `(model_name: str) -> str` | Resolves a model name to an encoding name (e.g., `"gpt-4o"` → `"o200k_base"`). Raises `KeyError` if unrecognized. |
| `encoding_for_model` | `(model_name: str) -> Encoding` | Resolves a model name to a fully constructed `Encoding` object. Raises `KeyError` if unrecognized. |

### Module-Level Data Structures

| Constant | Type | Purpose |
|----------|------|---------|
| `MODEL_TO_ENCODING` | `dict[str, str]` | Exact-match lookup table mapping full model names to encoding names. |
| `MODEL_PREFIX_TO_ENCODING` | `dict[str, str]` | Prefix-match lookup table for versioned/fine-tuned model names. |

---

## Architecture

The module sits between the public API surface and the encoding registry. It performs a two-stage lookup and then hands off to the registry for encoding construction.

```mermaid
graph TD
    User["User Code"] -->|"encoding_for_model('gpt-4o')"| EFM["encoding_for_model"]
    User -->|"encoding_name_for_model('gpt-4o')"| ENFM["encoding_name_for_model"]

    EFM -->|"delegates name resolution"| ENFM
    EFM -->|"get_encoding(name)"| Registry["Registry Module<br/>(get_encoding)"]

    ENFM -->|"exact match"| MTE["MODEL_TO_ENCODING"]
    ENFM -->|"prefix match"| MPTE["MODEL_PREFIX_TO_ENCODING"]

    Registry -->|"constructs"| Encoding["Encoding Object<br/>(core module)"]
    Registry -->|"uses constructors from"| Builtin["Builtin Encodings<br/>(openai_public)"]

    style ENFM fill:#e1f5ff
    style EFM fill:#e1f5ff
    style MTE fill:#fff4e1
    style MPTE fill:#fff4e1
```

---

## Lookup Resolution Flow

The `encoding_name_for_model` function implements a **two-tier resolution strategy**: an exact-match lookup followed by a prefix-match fallback. This design allows the library to support new model versions without requiring a code update for every release.

```mermaid
flowchart TD
    Start["encoding_name_for_model(model_name)"] --> Exact{"model_name in<br/>MODEL_TO_ENCODING?"}
    Exact -->|Yes| Found["encoding_name =<br/>MODEL_TO_ENCODING[model_name]"]
    Exact -->|No| PrefixLoop["Iterate MODEL_PREFIX_TO_ENCODING"]

    PrefixLoop --> PrefixCheck{"model_name.startswith<br/>(model_prefix)?"}
    PrefixCheck -->|Yes| ReturnPrefix["return model_encoding_name"]
    PrefixCheck -->|No, more prefixes| PrefixLoop
    PrefixCheck -->|No, exhausted| CheckNone{"encoding_name is None?"}

    Found --> CheckNone
    CheckNone -->|Yes| Raise["raise KeyError<br/>(unrecognized model)"]
    CheckNone -->|No| ReturnName["return encoding_name"]

    style Raise fill:#ffe1e1
    style ReturnName fill:#e1ffe1
    style ReturnPrefix fill:#e1ffe1
```

### Resolution Priority

1. **Exact match** (`MODEL_TO_ENCODING`) — highest priority. Used for stable, canonical model names.
2. **Prefix match** (`MODEL_PREFIX_TO_ENCODING`) — fallback for versioned names (e.g., `gpt-4o-2024-05-13`) and fine-tuned models (e.g., `ft:gpt-4o:...`).
3. **Failure** — raises `KeyError` with a helpful message directing the user to `tiktoken.get_encoding`.

> **Note:** Prefix matching can match non-existent models (e.g., `gpt-3.5-turbo-FAKE`). This is an intentional trade-off to avoid library updates for every model version release.

---

## Model-to-Encoding Mapping Reference

### Exact Matches (`MODEL_TO_ENCODING`)

| Category | Models | Encoding |
|----------|--------|----------|
| **Reasoning** | `o1`, `o3` | `o200k_base` |
| **Chat** | `gpt-4o` | `o200k_base` |
| **Chat** | `gpt-4`, `gpt-3.5-turbo`, `gpt-3.5`, `gpt-35-turbo` | `cl100k_base` |
| **Base** | `davinci-002`, `babbage-002` | `cl100k_base` |
| **Embeddings** | `text-embedding-ada-002`, `text-embedding-3-small`, `text-embedding-3-large` | `cl100k_base` |
| **Text (deprecated)** | `text-davinci-003`, `text-davinci-002` | `p50k_base` |
| **Text (deprecated)** | `text-davinci-001`, `text-curie-001`, `text-babbage-001`, `text-ada-001`, `davinci`, `curie`, `babbage`, `ada` | `r50k_base` |
| **Code (deprecated)** | `code-davinci-002`, `code-davinci-001`, `code-cushman-002`, `code-cushman-001`, `davinci-codex`, `cushman-codex` | `p50k_base` |
| **Edit (deprecated)** | `text-davinci-edit-001`, `code-davinci-edit-001` | `p50k_edit` |
| **Old embeddings (deprecated)** | `text-similarity-*`, `text-search-*`, `code-search-*` | `r50k_base` |
| **Open source** | `gpt2`, `gpt-2` | `gpt2` |

### Prefix Matches (`MODEL_PREFIX_TO_ENCODING`)

| Prefix | Encoding | Example Match |
|--------|----------|---------------|
| `o1-` | `o200k_base` | `o1-preview` |
| `o3-` | `o200k_base` | `o3-mini` |
| `chatgpt-4o-` | `o200k_base` | `chatgpt-4o-latest` |
| `gpt-4o-` | `o200k_base` | `gpt-4o-2024-05-13` |
| `gpt-4-` | `cl100k_base` | `gpt-4-0314`, `gpt-4-32k` |
| `gpt-3.5-turbo-` | `cl100k_base` | `gpt-3.5-turbo-0301` |
| `gpt-35-turbo-` | `cl100k_base` | Azure deployment names |
| `ft:gpt-4o` | `o200k_base` | Fine-tuned GPT-4o |
| `ft:gpt-4` | `cl100k_base` | Fine-tuned GPT-4 |
| `ft:gpt-3.5-turbo` | `cl100k_base` | Fine-tuned GPT-3.5 |
| `ft:davinci-002` | `cl100k_base` | Fine-tuned davinci-002 |
| `ft:babbage-002` | `cl100k_base` | Fine-tuned babbage-002 |

---

## Component Interaction Sequence

The following sequence diagram shows the full lifecycle of a call to `encoding_for_model`, including the registry's caching behavior.

```mermaid
sequenceDiagram
    participant U as User
    participant EFM as encoding_for_model
    participant ENFM as encoding_name_for_model
    participant REG as registry.get_encoding
    participant CACHE as ENCODINGS cache
    participant CON as Encoding constructor

    U->>EFM: encoding_for_model("gpt-4o")
    EFM->>ENFM: encoding_name_for_model("gpt-4o")
    ENFM->>ENFM: exact match in MODEL_TO_ENCODING
    ENFM-->>EFM: "o200k_base"
    EFM->>REG: get_encoding("o200k_base")
    REG->>CACHE: lookup "o200k_base"
    alt cached
        CACHE-->>REG: Encoding instance
    else not cached
        REG->>CON: construct Encoding
        CON-->>REG: Encoding instance
        REG->>CACHE: store instance
    end
    REG-->>EFM: Encoding instance
    EFM-->>U: Encoding instance
```

---

## Dependencies

```mermaid
graph LR
    Model["model.py<br/>(this module)"] -->|"imports Encoding"| Core["core.py<br/>(Encoding class)"]
    Model -->|"imports get_encoding"| Registry["registry.py<br/>(get_encoding)"]

    Registry -->|"uses constructors"| Builtin["openai_public.py<br/>(encoding constructors)"]
    Registry -->|"constructs"| Core
    Builtin -->|"loads BPE ranks"| Load["load.py<br/>(load_tiktoken_bpe)"]

    style Model fill:#e1f5ff
```

### Internal Dependencies

| Dependency | Imported Symbol | Role |
|------------|-----------------|------|
| [Core Encoding module](task0_core_encoding.md) | `Encoding` | Return type of `encoding_for_model`; the tokenizer object. |
| [Registry module](task0_registry.md) | `get_encoding` | Constructs/retrieves the `Encoding` object by name. |

### Downstream Dependencies (via Registry)

| Module | Role |
|--------|------|
| [Builtin Encodings](task0_builtin_encodings.md) | Provides the encoding constructors (`o200k_base`, `cl100k_base`, etc.) referenced by name. |
| [Loading module](task0_loading.md) | Loads BPE rank files referenced by the constructors. |

---

## Usage Examples

### Resolving an encoding name

```python
from tiktoken.model import encoding_name_for_model

encoding_name_for_model("gpt-4o")          # "o200k_base"
encoding_name_for_model("gpt-4-0314")      # "cl100k_base" (prefix match)
encoding_name_for_model("ft:gpt-4o:acme")  # "o200k_base" (prefix match)
encoding_name_for_model("unknown-model")   # raises KeyError
```

### Getting an encoding object

```python
from tiktoken.model import encoding_for_model

enc = encoding_for_model("gpt-4o")
tokens = enc.encode("hello world")
```

### Handling unrecognized models

```python
from tiktoken.model import encoding_for_model

try:
    enc = encoding_for_model("my-custom-model")
except KeyError as e:
    # Fall back to an explicit encoding
    from tiktoken import get_encoding
    enc = get_encoding("cl100k_base")
```

---

## Design Considerations

### Why two lookup tables?

- **`MODEL_TO_ENCODING`** provides deterministic, exact mappings for canonical model names. This is the authoritative source for stable models.
- **`MODEL_PREFIX_TO_ENCODING`** provides forward-compatibility. New model versions (e.g., `gpt-4o-2025-01-01`) automatically resolve to the correct encoding without a library release.

### Why raise `KeyError` instead of defaulting?

Silently defaulting to an encoding could produce incorrect token counts and subtle bugs. Raising `KeyError` forces the caller to make an explicit choice, and the error message guides them toward `tiktoken.get_encoding`.

### Future direction

The source code notes that these tables will *"likely be replaced by an API endpoint"*, suggesting the mapping may eventually be served dynamically rather than hard-coded.

---

## Related Documentation

- [Core Encoding module](task0_core_encoding.md) — the `Encoding` class returned by `encoding_for_model`.
- [Registry module](task0_registry.md) — `get_encoding` and encoding caching.
- [Builtin Encodings module](task0_builtin_encodings.md) — the encoding constructors referenced by name.
- [Loading module](task0_loading.md) — how BPE rank data is loaded for encodings.
