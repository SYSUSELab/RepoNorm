# task1371 — Outlines: Structured Text Generation

## Introduction

`task1371` documents the **Outlines** library, a framework for *structured text
generation* with large language models. Outlines lets you constrain the output of
a language model to a regular expression, a JSON schema, a context-free grammar,
or a Python/Pydantic type, guaranteeing that the generated text is valid by
construction.

The library achieves this by compiling the desired output structure into a
**finite-state machine (FSM)** or a **parser state**, then using that machine to
*bias the logits* of the underlying model at every decoding step. Because the
constraint is applied at the token level, the model can never emit an invalid
token.

The module is organized around a small set of abstractions that are shared across
many model providers:

- A **`Tokenizer`** protocol that normalizes tokenization across providers.
- A **`Guide`** abstraction (regex, CFG, stop-at-EOS) that drives generation.
- A **`Sampler`** abstraction (greedy, multinomial, beam search).
- A **`SequenceGenerator`** / **`SequenceGeneratorAdapter`** that ties a model,
  a guide and a sampler together.
- **Logits processors** that apply the guide's constraints to raw logits.

## Architecture Overview

```mermaid
graph TD
    subgraph "User API"
        F["Function<br/>(outlines/function.py)"]
        P["Prompt<br/>(outlines/prompts.py)"]
        V["vectorize<br/>(outlines/base.py)"]
    end

    subgraph "Generation Layer"
        SG["SequenceGenerator<br/>(generate/api.py)"]
        SGA["SequenceGeneratorAdapter<br/>(generate/api.py)"]
        VSGA["VisionSequenceGeneratorAdapter"]
        GEN["sequence_generator loop<br/>(generate/generator.py)"]
    end

    subgraph "Guides / FSM"
        G["Guide"]
        RG["RegexGuide"]
        CG["CFGGuide"]
        SEOS["StopAtEOSGuide"]
        PARSE["PartialLark / parsing.py"]
        TYPES["python_types_to_regex<br/>(fsm/types.py)"]
    end

    subgraph "Processors"
        OLP["OutlinesLogitsProcessor"]
        GLP["GuideLogitsProcessor"]
        RLP["RegexLogitsProcessor"]
        JLP["JSONLogitsProcessor"]
        CLP["CFGLogitsProcessor"]
    end

    subgraph "Samplers"
        GR["GreedySampler"]
        MS["MultinomialSampler"]
        BS["BeamSearchSampler"]
    end

    subgraph "Models"
        TR["Transformers"]
        LC["LlamaCpp"]
        VL["VLLM"]
        EX["ExLlamaV2Model"]
        MLX["MLXLM"]
        OAI["OpenAI"]
        TRV["TransformersVision"]
        TOK["Tokenizer (protocol)"]
    end

    subgraph "Support"
        CACHE["CloudpickleDisk / cache<br/>(caching.py)"]
        LOC["locale / US<br/>(types/locales.py)"]
    end

    F --> SG
    F --> SGA
    P --> F
    V --> OAI

    SG --> GEN
    SGA --> TR
    SGA --> LC
    SGA --> VL
    SGA --> EX
    SGA --> MLX
    VSGA --> TRV

    GEN --> G
    GEN --> GR
    GEN --> MS
    GEN --> BS

    G --> RG
    G --> CG
    G --> SEOS
    CG --> PARSE
    RG --> TYPES

    GLP --> G
    RLP --> RG
    JLP --> RLP
    CLP --> CG
    OLP --> GLP

    TR --> TOK
    LC --> TOK
    VL --> TOK
    EX --> TOK
    MLX --> TOK

    RG --> CACHE
    LOC --> TYPES
```

## Core Functionality by Sub-module

The module is split into the following sub-modules. Each has its own detailed
documentation page.

### 1. Generation API & Loop — [task1371_generation](task1371_generation.md)

The heart of the library. `SequenceGenerator` runs the token-by-token decoding
loop for local models (via `sequence_generator`), while
`SequenceGeneratorAdapter` unifies the interface to provider libraries that
implement their own generation (transformers, vLLM, llama.cpp, exllamav2, mlx).
Also defines the `GenerationParameters` and `SamplingParameters` dataclasses and
the `VisionSequenceGeneratorAdapter` for multimodal models.

**Core components:** `SequenceGenerator`, `SequenceGeneratorAdapter`,
`VisionSequenceGeneratorAdapter`, `GenerationParameters`, `SamplingParameters`,
`GenerationState`, `ContextLengthExceededError`, `sequence_generator`.

### 2. Guides & FSM — [task1371_guides](task1371_guides.md)

The constraint engine. A `Guide` maps a generation state to the set of allowed
next tokens. `RegexGuide` compiles a regex into an FSM, `CFGGuide` uses a Lark
LALR parser for context-free grammars, and `StopAtEOSGuide` simply stops at the
EOS token. The `parsing.py` module contains the partial/incremental Lark parser
machinery, and `types.py` maps Python types to regexes.

**Core components:** `Guide`, `RegexGuide`, `CFGGuide`, `StopAtEOSGuide`,
`PartialLark`, `PartialParser`, `PartialParserState`, `PartialScanner`,
`PartialBasicLexer`, `PartialContextualLexer`, `PartialIndenter`,
`PartialPythonIndenter`, `FormatFunction`, `python_types_to_regex`.

### 3. Logits Processors — [task1371_processors](task1371_processors.md)

Adapters that apply a guide's constraints to raw logits for provider libraries
that expose a logits-processor hook. `OutlinesLogitsProcessor` normalizes array
types (torch, numpy, mlx, jax) and `GuideLogitsProcessor` masks disallowed
tokens. `RegexLogitsProcessor`, `JSONLogitsProcessor` and `CFGLogitsProcessor`
are the concrete structured-generation processors.

**Core components:** `OutlinesLogitsProcessor`, `GuideLogitsProcessor`,
`RegexLogitsProcessor`, `JSONLogitsProcessor`, `CFGLogitsProcessor`.

### 4. Samplers — [task1371_samplers](task1371_samplers.md)

Token-selection strategies. `GreedySampler` picks the argmax, `MultinomialSampler`
samples from the (optionally top-k/top-p/temperature-adjusted) distribution, and
`BeamSearchSampler` performs beam search. Each exposes a `sampling_params`
property used to build `SamplingParameters`.

**Core components:** `Sampler`, `GreedySampler`, `MultinomialSampler`,
`BeamSearchSampler`, `SamplingParameters`, `keep_top_k_logits`,
`keep_top_p_logits`, `rescale_logits`.

### 5. Models & Tokenizers — [task1371_models](task1371_models.md)

Provider wrappers that give every backend the same `generate`/`stream` interface,
plus the `Tokenizer` protocol that normalizes tokenization. Covers transformers,
transformers-vision, llama.cpp, vLLM, exllamav2, mlx-lm and OpenAI.

**Core components:** `Tokenizer`, `Transformers`, `TransformerTokenizer`,
`TransformersVision`, `LlamaCpp`, `LlamaCppTokenizer`, `LlamaCppParams`, `VLLM`,
`ExLlamaV2Model`, `OutlinesExLlamaV2Tokenizer`, `ExllamaV2Params`, `MLXLM`,
`OpenAI`, `OpenAIConfig`.

### 6. Support Utilities — [task1371_support](task1371_support.md)

Cross-cutting helpers: `vectorize` (array-aware function vectorization with
async support), `Prompt` (Jinja2 prompt templates), `Function` (encapsulated
prompt + model + schema), the disk cache (`CloudpickleDisk`, `cache`,
`cache_disabled`), and locale-specific types (`US`, `locale`).

**Core components:** `vectorize`, `Prompt`, `Function`, `CloudpickleDisk`,
`US`, `locale`.

### 7. Benchmarks — [task1371_benchmarks](task1371_benchmarks.md)

Performance benchmarks for the FSM/guide compilation and logits-processor
application paths, used to track regressions in the structured-generation hot
paths.

**Core components:** `RegexGuideBenchmark`, `MemoryRegexGuideBenchmark`,
`JsonSchemaBenchmark`, `CFGGuideBenchmark`, `LogitsProcessorPassthroughBenchmark`,
`LogitsProcessorStructuredBenchmark`, `HalvingLogitsProcessor`.

## End-to-End Data Flow

The following diagram shows how a structured generation request flows through
the system for a local (transformers) model.

```mermaid
sequenceDiagram
    participant User
    participant Gen as SequenceGenerator
    participant Loop as sequence_generator
    participant Model as Transformers
    participant Guide as RegexGuide/CFGGuide
    participant Sampler

    User->>Gen: __call__(prompt, max_tokens, stop_at)
    Gen->>Gen: tokenizer.encode(prompts)
    Gen->>Loop: sequence_generator(model, sampler, fsms, ...)
    loop until all FSMs final
        Loop->>Model: forward(token_ids, attention_mask, kv_cache)
        Model-->>Loop: logits, kv_cache
        Loop->>Guide: get_next_instruction(state).tokens
        Guide-->>Loop: allowed token ids
        Loop->>Loop: bias_logits(logits, allowed)
        Loop->>Sampler: __call__(biased_logits, weights, rng)
        Sampler-->>Loop: next_token_ids, ancestors, weights
        Loop->>Loop: update token_ids / masks / kv_cache / fsm_states
        Loop-->>Gen: GenerationState
    end
    Gen->>Gen: tokenizer.decode + format_sequence
    Gen-->>User: formatted output
```

For provider libraries that own their generation loop (vLLM, llama.cpp,
exllamav2, mlx, OpenAI), the flow is instead:

```mermaid
sequenceDiagram
    participant User
    participant Adapter as SequenceGeneratorAdapter
    participant Processor as GuideLogitsProcessor
    participant Provider as Provider Model

    User->>Adapter: __call__(prompt, ...)
    Adapter->>Adapter: prepare_generation_parameters(...)
    Adapter->>Provider: generate(prompts, params, logits_processor, sampling_params)
    loop each decoding step
        Provider->>Processor: process_logits(input_ids, logits)
        Processor-->>Provider: masked logits
    end
    Provider-->>Adapter: completions
    Adapter->>Adapter: _format(completions)
    Adapter-->>User: formatted output
```

## Relationship to Other Modules

- The **Generation API** depends on **Guides**, **Samplers** and **Models**.
- **Processors** depend on **Guides** and the **Tokenizer** protocol.
- **Models** depend on the **Generation API** dataclasses
  (`GenerationParameters`, `SamplingParameters`) and the **Tokenizer** protocol.
- **Support utilities** (`vectorize`, `cache`) are used by **Models** (OpenAI)
  and **Guides** (caching of state mappings).
- **Benchmarks** exercise **Guides** and **Processors** directly.

## Key Design Principles

1. **Provider-agnostic interface.** Every model backend implements the same
   `generate`/`stream` signature, so switching providers is a one-line change.
2. **Constraint at the token level.** Guides operate on token ids, not strings,
   guaranteeing validity without post-hoc validation or retries.
3. **Incremental parsing.** The `Partial*` parser classes allow the CFG guide to
   evaluate partial token sequences without re-parsing from scratch.
4. **Caching.** Expensive FSM/state-mapping computations are memoized on disk via
   `CloudpickleDisk`, keyed on the tokenizer and pattern.
5. **Array-library agnosticism.** `OutlinesLogitsProcessor` transparently
   converts between torch, numpy, mlx and jax arrays.
