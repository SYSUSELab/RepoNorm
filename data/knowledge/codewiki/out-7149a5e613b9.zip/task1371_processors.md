# Processors Module

## Introduction

The `task1371_processors` module provides **logits processors** that constrain and bias the token generation of language models. These processors are the runtime enforcement mechanism for Outlines' structured generation: they take the raw logits produced by a model at each generation step and mask out tokens that would violate a user-specified constraint (a regular expression, a JSON schema, or a context-free grammar).

The module is built around two files:

- `outlines/processors/base_logits_processor.py` — defines the `OutlinesLogitsProcessor` protocol, which normalizes the many array types used across model backends into a single `torch.Tensor`-based interface.
- `outlines/processors/structured.py` — implements the concrete processors (`GuideLogitsProcessor`, `RegexLogitsProcessor`, `JSONLogitsProcessor`, `CFGLogitsProcessor`) that use a finite-state-machine `Guide` to decide which tokens are legal.

The processors are consumed by the [generation module](task1371_generation.md) and the [samplers module](task1371_samplers.md), and they depend on the [guides module](task1371_guides.md) for the underlying state machines and on the [models module](task1371_models.md) for tokenizers.

---

## Architecture Overview

The module follows a layered design: a backend-agnostic base protocol handles type normalization, while concrete subclasses implement the actual constraint logic on top of a `Guide`.

```mermaid
graph TD
    subgraph "processors module"
        OLP["OutlinesLogitsProcessor<br/>(Protocol)"]
        GLP["GuideLogitsProcessor"]
        RLP["RegexLogitsProcessor"]
        JLP["JSONLogitsProcessor"]
        CLP["CFGLogitsProcessor"]
    end

    subgraph "guides module"
        Guide["Guide"]
        RegexGuide["RegexGuide"]
        CFGGuide["CFGGuide"]
    end

    subgraph "models module"
        Tokenizer["Tokenizer"]
    end

    subgraph "external"
        Core["outlines_core.fsm.json_schema<br/>build_regex_from_schema"]
        Pydantic["pydantic.BaseModel"]
    end

    OLP --> GLP
    GLP --> RLP
    RLP --> JLP
    GLP --> CLP

    GLP -.uses.-> Guide
    RLP -.uses.-> RegexGuide
    CLP -.uses.-> CFGGuide
    GLP -.uses.-> Tokenizer
    JLP -.uses.-> Core
    JLP -.uses.-> Pydantic
```

### Class Hierarchy

The concrete processors form an inheritance chain that progressively specializes the constraint type:

```mermaid
classDiagram
    class OutlinesLogitsProcessor {
        <<Protocol>>
        +process_logits(input_ids, logits) torch.Tensor
        +__call__(input_ids, logits) Array
        +_to_torch(tensor_like) torch.Tensor
        +_from_torch(tensor, target_type) Array
    }
    class GuideLogitsProcessor {
        +Tokenizer tokenizer
        +Guide guide
        +Dict _guide_states
        +Optional _seq_start_idx
        +process_logits(input_ids, logits) torch.Tensor
        +copy() GuideLogitsProcessor
    }
    class RegexLogitsProcessor {
        +__init__(regex_string, tokenizer)
    }
    class JSONLogitsProcessor {
        +__init__(schema, tokenizer, whitespace_pattern)
    }
    class CFGLogitsProcessor {
        +CFGGuide guide
        +process_logits(input_ids, logits) torch.Tensor
    }

    OutlinesLogitsProcessor <|-- GuideLogitsProcessor
    GuideLogitsProcessor <|-- RegexLogitsProcessor
    RegexLogitsProcessor <|-- JSONLogitsProcessor
    GuideLogitsProcessor <|-- CFGLogitsProcessor
```

---

## Core Components

### `OutlinesLogitsProcessor` (base protocol)

Defined in `outlines/processors/base_logits_processor.py`, this is the abstract base for all logits processors. Its primary responsibility is **type normalization**: different model backends produce logits in different array libraries, and this class unifies them so that subclasses only need to implement a single business-logic method.

| Backend | Array type produced | Normalized to |
| --- | --- | --- |
| llama-cpp-python | `numpy.ndarray` | `torch.Tensor` |
| mlx-lm | `mlx.core.array` | `torch.Tensor` |
| JAX | `jaxlib.xla_extension.ArrayImpl` | `torch.Tensor` |
| transformers / vLLM / others | `torch.Tensor` | `torch.Tensor` |

**Key methods:**

- `process_logits(input_ids, logits)` — abstract method that subclasses implement. Both arguments are always 2D tensors representing a batch of sequences.
- `__call__(input_ids, logits)` — the public entry point. It performs the full normalization pipeline (see [Data Flow](#data-flow) below) and is decorated with `@torch.no_grad()`.
- `_to_torch(tensor_like)` — static helper converting any supported array type into a `torch.Tensor`.
- `_from_torch(tensor, target_type)` — static helper converting a `torch.Tensor` back into the original array library type.

> **Design note:** Normalization does not move memory — it only casts the type. This keeps the overhead of supporting multiple backends minimal.

### `GuideLogitsProcessor`

The workhorse processor. It uses a `Guide` (a finite-state machine) to determine, for each sequence in the batch, the set of tokens that are legal at the current generation step, then masks all other logits to `-inf`.

**Attributes:**

- `tokenizer` — the `Tokenizer` used to convert tokens to ids.
- `guide` — the `Guide` that drives the constraint.
- `_guide_states` — a cache mapping a hash of the generated token sequence to the corresponding guide state, avoiding recomputation.
- `_seq_start_idx` — the index at which generation begins (i.e., the length of the prompt), used to separate prompt tokens from generated tokens.

**Methods:**

- `process_logits(input_ids, logits)` — computes the guide state for each sequence, gathers the allowed tokens, and applies a boolean mask (`masked_fill_` with `-inf`) to disallow illegal tokens.
- `copy()` — returns a fresh processor with a copied guide, useful for reusing a processor configuration across independent generations.

### `RegexLogitsProcessor`

A thin specialization of `GuideLogitsProcessor` that builds a `RegexGuide` from a regular expression string via `RegexGuide.from_regex(regex_string, tokenizer)` and passes it to the base constructor.

### `JSONLogitsProcessor`

Specializes `RegexLogitsProcessor`. It converts a JSON schema (a `dict`, a JSON string, or a Pydantic `BaseModel`) into a regular expression using `convert_json_schema_to_str` and `build_regex_from_schema`, then delegates to the regex processor. An optional `whitespace_pattern` controls the syntactic whitespace allowed in the generated JSON (without affecting string literals).

### `CFGLogitsProcessor`

Specializes `GuideLogitsProcessor` for context-free grammars. It builds a `CFGGuide` from a Lark grammar string. Unlike the other processors, it **overrides `process_logits`** to use a *rejection-sampling* strategy rather than a full mask:

1. It computes the guide state for each sequence (same as the base class).
2. Instead of masking all illegal tokens, it sorts the logits in descending order and selects the **first legal token** via `guide.iter_valid_token_ids`.
3. It builds a mask that is `-inf` everywhere except for that single legal token, whose original logit value is preserved.

This approach is more efficient for CFGs, where enumerating all valid tokens can be expensive.

---

## Data Flow

The following diagram shows how a single call to a processor flows through type normalization, business logic, and back-conversion.

```mermaid
flowchart TD
    A["Model produces logits<br/>(ndarray / mlx / jax / torch)"] --> B["__call__(input_ids, logits)"]
    B --> C["_to_torch(logits)"]
    B --> D["_to_torch(input_ids)"]
    C --> E{"logits.ndim?"}
    D --> E
    E -->|"2D"| F["process_logits(input_ids, logits)"]
    E -->|"1D"| G["unsqueeze(0) → process_logits → squeeze(0)"]
    F --> H["_from_torch(processed, type(logits))"]
    G --> H
    H --> I["Return logits in original array type"]
```

### Inside `GuideLogitsProcessor.process_logits`

```mermaid
flowchart TD
    A["input_ids, logits (2D torch)"] --> B{"_seq_start_idx set?"}
    B -->|No| C["Set _seq_start_idx = len(input_ids[0])"]
    B -->|Yes| D["Continue"]
    C --> D
    D --> E["For each sequence in batch"]
    E --> F["Extract generated ids (after prompt)"]
    F --> G{"State cached?"}
    G -->|No| H["Compute next state via guide.get_next_state"]
    G -->|Yes| I["Reuse cached state"]
    H --> J["Cache state"]
    I --> K["Collect allowed tokens via guide.get_next_instruction"]
    J --> K
    K --> L["Build boolean mask over logits"]
    L --> M["masked_fill_(mask, -inf)"]
    M --> N["Return biased logits"]
```

### Inside `CFGLogitsProcessor.process_logits` (rejection sampling)

```mermaid
flowchart TD
    A["input_ids, logits (2D torch)"] --> B["Compute guide state per sequence"]
    B --> C["mask = full(-inf)"]
    C --> D["For each sequence i"]
    D --> E["Sort logits[i] descending"]
    E --> F["guide.iter_valid_token_ids(state, sorted_ids)"]
    F --> G["Take first legal token"]
    G --> H["mask[i, token] = logits[i, token]"]
    H --> I["Return mask"]
```

---

## Component Interaction

The processors sit between the model (which produces logits) and the sampler (which selects the next token). The `Guide` provides the constraint logic, and the `Tokenizer` provides the vocabulary mapping.

```mermaid
sequenceDiagram
    participant Model as Model (task1371_models)
    participant Proc as LogitsProcessor
    participant Guide as Guide (task1371_guides)
    participant Sampler as Sampler (task1371_samplers)

    Model->>Proc: logits + input_ids
    Proc->>Proc: _to_torch (normalize types)
    Proc->>Guide: get_next_state(prev_state, token_id)
    Guide-->>Proc: new state
    Proc->>Guide: get_next_instruction(state)
    Guide-->>Proc: allowed tokens
    Proc->>Proc: mask illegal logits to -inf
    Proc->>Proc: _from_torch (restore type)
    Proc-->>Sampler: biased logits
    Sampler->>Sampler: select next token
```

---

## Dependencies

```mermaid
graph LR
    subgraph "task1371_processors"
        P["processors"]
    end
    P --> G["task1371_guides<br/>(Guide, RegexGuide, CFGGuide)"]
    P --> M["task1371_models<br/>(Tokenizer)"]
    P --> Core["outlines_core<br/>(build_regex_from_schema)"]
    P --> Torch["torch"]
    P --> Numpy["numpy"]
    P --> Pydantic["pydantic"]
    P -.optional.-> MLX["mlx.core"]
    P -.optional.-> JAX["jax / jaxlib"]
```

| Dependency | Purpose |
| --- | --- |
| [task1371_guides](task1371_guides.md) | Provides `Guide`, `RegexGuide`, `CFGGuide` — the state machines that define legal tokens. |
| [task1371_models](task1371_models.md) | Provides the `Tokenizer` protocol used to map tokens to ids and decode them. |
| `outlines_core.fsm.json_schema` | `build_regex_from_schema` converts JSON schemas to regexes. |
| `torch` | The canonical internal tensor type for all processors. |
| `numpy` | Supported input/output array type. |
| `pydantic` | Accepts `BaseModel` classes as JSON schema inputs. |
| `mlx.core` *(optional)* | Supported input/output array type for mlx-lm. |
| `jax` / `jaxlib` *(optional)* | Supported input/output array type for JAX backends. |

---

## Usage Examples

### Regex-constrained generation

```python
from outlines.processors import RegexLogitsProcessor

processor = RegexLogitsProcessor(r"[0-9]{3}-[0-9]{4}", tokenizer)
# Pass `processor` to your model's generation call.
```

### JSON-schema-constrained generation

```python
from pydantic import BaseModel
from outlines.processors import JSONLogitsProcessor

class User(BaseModel):
    name: str
    age: int

processor = JSONLogitsProcessor(User, tokenizer)
```

### CFG-constrained generation

```python
from outlines.processors import CFGLogitsProcessor

grammar = """
start: "hello" " " "world"
"""
processor = CFGLogitsProcessor(grammar, tokenizer)
```

---

## Design Considerations

- **Single-use processors.** As noted in the base class docstring, logits processors are used once and never re-applied to a new sequence generator. State caches (`_guide_states`) are therefore scoped to a single generation run.
- **Batch handling.** All processors operate on 2D tensors (batch × sequence). The base `__call__` transparently handles 1D inputs by unsqueezing and squeezing.
- **Prompt vs. generation boundary.** `_seq_start_idx` is lazily set on the first call to mark where generation begins, since some backends prefix `input_ids` with the prompt and others do not.
- **Beam search ordering.** The base class warns that some sampling methods (e.g., beam search in vLLM) produce unstable sequence ordering, which processors must tolerate.
- **CFG efficiency.** Because enumerating all valid tokens for a CFG is expensive, `CFGLogitsProcessor` uses rejection sampling to select only the highest-probability legal token.

---

## Related Modules

- [task1371_guides](task1371_guides.md) — the finite-state-machine guides that define legal token sets.
- [task1371_generation](task1371_generation.md) — the sequence generators that consume these processors.
- [task1371_samplers](task1371_samplers.md) — the samplers that select tokens from the biased logits.
- [task1371_models](task1371_models.md) — the model backends and tokenizers.
- [task1371_benchmarks](task1371_benchmarks.md) — benchmarks including `LogitsProcessorStructuredBenchmark` and `HalvingLogitsProcessor`.
