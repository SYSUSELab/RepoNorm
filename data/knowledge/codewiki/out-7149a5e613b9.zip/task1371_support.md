# Support Module (`task1371_support`)

## Introduction

The **Support** module provides the foundational, cross-cutting utilities that the rest of the Outlines library depends on. Unlike the generation, guides, processors, samplers, and models modules — which implement the core structured-generation pipeline — the support module supplies the "glue" that makes those modules ergonomic and reusable:

- **`vectorize`** — a NumPy-compatible vectorization decorator that transparently batches synchronous functions and runs coroutines concurrently.
- **`Prompt`** — a Jinja2-backed prompt templating system that turns function docstrings into reusable, partially-applicable prompt builders.
- **`Function`** — a high-level abstraction that bundles a prompt template, a schema, and a model into a single callable unit, loadable from GitHub.
- **`CloudpickleDisk`** — a disk-cache backend that serializes arbitrary Python objects (including closures and lambdas) using `cloudpickle`.
- **`US` locale** — a registry of locale-specific structured types (zip codes, phone numbers) used to constrain generation.

These components are deliberately decoupled from any specific model provider, allowing them to be reused across the entire library.

---

## Module Architecture

The support module sits at the bottom of the dependency graph. It has no dependency on the generation pipeline, but the generation pipeline and higher-level APIs depend on it.

```mermaid
graph TD
    subgraph Support["task1371_support"]
        V["vectorize<br/>(base.py)"]
        P["Prompt<br/>(prompts.py)"]
        F["Function<br/>(function.py)"]
        C["CloudpickleDisk<br/>(caching.py)"]
        L["US locale<br/>(types/locales.py)"]
    end

    subgraph Generation["task1371_generation"]
        SG["SequenceGenerator"]
        SGA["SequenceGeneratorAdapter"]
    end

    subgraph Models["task1371_models"]
        TR["Transformers"]
        OA["OpenAI"]
    end

    subgraph Guides["task1371_guides"]
        G["Guide / RegexGuide"]
    end

    F --> P
    F --> SG
    F --> TR
    F --> OA
    L --> G
    C -.->|caches| TR
    C -.->|caches| OA
    V -.->|batches| SG
```

### Component Responsibilities

| Component | File | Responsibility |
|-----------|------|----------------|
| `vectorize` | `outlines/base.py` | Batch synchronous/coroutine functions over array inputs |
| `Prompt` | `outlines/prompts.py` | Render Jinja2 templates from docstrings or files |
| `Function` | `outlines/function.py` | Bundle prompt + schema + model into a callable |
| `CloudpickleDisk` | `outlines/caching.py` | Serialize arbitrary objects for disk caching |
| `US` | `outlines/types/locales.py` | Registry of locale-specific structured types |

---

## Component Details

### 1. `vectorize` — Array-Aware Function Batching

`vectorize` is a class-based decorator that mirrors NumPy's `vectorize` but adds two important capabilities:

1. **Coroutine concurrency** — when the wrapped function is a coroutine, all invocations are gathered and executed concurrently in a dedicated event loop, rather than sequentially.
2. **Optional gufunc-style signatures** — a signature string (e.g. `"(m),(s)->(s,m)"`) can be supplied to control how core dimensions are broadcast and reshaped.

```mermaid
flowchart TD
    A["__call__(*args, **kwargs)"] --> B{args or kwargs?}
    B -->|No| T["call_thunk()"]
    B -->|Yes| C{signature set?}
    C -->|Yes| S["call_with_signature()"]
    C -->|No| N["call_no_signature()"]

    N --> N1["Broadcast inputs"]
    N1 --> N2{coroutine?}
    N2 -->|Yes| N3["vectorize_call_coroutine()<br/>asyncio.gather"]
    N2 -->|No| N4["vectorize_call()<br/>for loop"]
    N3 --> N5["Reshape outputs"]
    N4 --> N5

    S --> S1["Parse input dims"]
    S1 --> S2["Broadcast to input shapes"]
    S2 --> S3{coroutine?}
    S3 -->|Yes| S4["vectorize_call_coroutine()"]
    S3 -->|No| S5["vectorize_call()"]
    S4 --> S6["Update output dim sizes"]
    S5 --> S6
    S6 --> S7["Reshape outputs"]
```

**Key behaviors:**

- **No signature** (`call_no_signature`): all inputs/outputs are treated as scalars. Inputs are broadcast to a common shape, the function is applied element-wise, and results are reshaped back.
- **With signature** (`call_with_signature`): core dimensions are parsed from the signature, inputs are broadcast to their computed shapes, and outputs are reshaped according to the declared output core dimensions.
- **Thunks** (`call_thunk`): zero-argument functions are called directly (still handling coroutines).
- **NumPy version compatibility**: the module imports private NumPy helpers from `numpy.lib._function_base_impl` (NumPy ≥ 2) or `numpy.lib.function_base` (NumPy < 2).
- **Notebook support**: if running under IPython, `nest_asyncio` is applied so nested event loops work.

> **Note:** `_update_arrays_type` is a helper that widens string-array dtypes when longer results appear, preventing truncation of fixed-length string arrays.

---

### 2. `Prompt` — Jinja2 Prompt Templating

`Prompt` is a dataclass wrapping a `jinja2.Template` and an optional `inspect.Signature`. It is normally created via the `@outlines.prompt` decorator, which extracts the template from a function's docstring.

```mermaid
flowchart LR
    subgraph Creation
        DS["Function docstring"] -->|"@prompt"| PT["Prompt(template, signature)"]
        STR["String content"] -->|"Prompt.from_str"| PT
        FILE["File path"] -->|"Prompt.from_file"| PT
    end
    PT -->|"__call__(*args, **kwargs)"| R["Rendered string"]
```

**Construction paths:**

| Method | Source | Signature inference |
|--------|--------|---------------------|
| `@prompt` decorator | Function docstring | Yes (`inspect.signature`) |
| `Prompt.from_str` | Raw string | No |
| `Prompt.from_file` | Jinja2 file (supports includes/inheritance) | No |

**Template processing pipeline** (`_template_from_str`):

1. `inspect.cleandoc` removes common leading whitespace.
2. Trailing double-newlines are preserved.
3. Extra whitespace is collapsed (except after newlines, to preserve line continuations).
4. A `jinja2.Environment` is configured with `trim_blocks`, `lstrip_blocks`, `keep_trailing_newline`, and `StrictUndefined`.

**Custom Jinja2 filters** registered on the environment:

| Filter | Function | Purpose |
|--------|----------|---------|
| `name` | `get_fn_name` | Callable's name |
| `description` | `get_fn_description` | First line of docstring |
| `source` | `get_fn_source` | Full source code |
| `signature` | `get_fn_signature` | Parameter list |
| `schema` | `get_schema` | JSON schema (dict or Pydantic) |
| `args` | `get_fn_args` | Annotated argument list |

**Schema rendering** uses `functools.singledispatch`:
- `dict` → pretty-printed JSON.
- Pydantic `BaseModel` → recursively resolved schema via `parse_pydantic_schema`, following `$ref`/`$defs` references for nested models.

---

### 3. `Function` — Bundled Prompt + Schema + Model

`Function` is a dataclass that encapsulates the three ingredients needed to run a structured generation task:

```mermaid
flowchart TD
    F["Function"] --> PT["prompt_template: Prompt"]
    F --> SC["schema: str | Callable | object"]
    F --> MN["model_name: str"]
    F --> GEN["generator: SequenceGenerator (lazy)"]

    F -->|"__call__(*args, **kwargs)"| INIT{"generator is None?"}
    INIT -->|Yes| IG["init_generator()<br/>load model + generate.json"]
    INIT -->|No| RENDER
    IG --> RENDER["Render prompt template"]
    RENDER --> CALL["generator(prompt)"]
```

**Key methods:**

- **`from_github(program_path, function_name="fn")`** — downloads a Python file from GitHub (`{user}/{repo}/{path}`), executes it in an isolated module, and extracts an `outlines.Function` instance. Raises descriptive errors for invalid paths, missing files (404), or wrong types.
- **`init_generator()`** — lazily loads a `transformers` model and builds a JSON generator via `generate.json(model, schema)`.
- **`__call__`** — lazily initializes the generator, renders the prompt, and delegates to the generator. *Batching is not currently supported.*

> **Dependencies:** `Function` depends on the [generation module](task1371_generation.md) (`SequenceGenerator`, `generate.json`) and the [models module](task1371_models.md) (`models.transformers`).

---

### 4. `CloudpickleDisk` — Disk Cache Backend

`CloudpickleDisk` extends `diskcache.Disk` to serialize values with `cloudpickle`, enabling caching of objects that standard `pickle` cannot handle (lambdas, closures, locally-defined classes).

```mermaid
flowchart LR
    subgraph Cache["diskcache.Cache"]
        GET["get(key)"] --> CD1["CloudpickleDisk.get"]
        SET["set(key, value)"] --> CD2["CloudpickleDisk.store"]
    end
    CD1 -->|"cloudpickle.loads"| OBJ["Python object"]
    CD2 -->|"cloudpickle.dumps"| BYTES["Serialized bytes"]
```

**Overridden methods:**

| Method | Behavior |
|--------|----------|
| `put(key)` | Serializes the key with `cloudpickle.dumps` |
| `get(key, raw)` | Deserializes with `cloudpickle.loads` |
| `store(value, read, key)` | Serializes value unless `read=True` |
| `fetch(mode, filename, value, read)` | Deserializes unless `read=True` |

**Cache management functions:**

- **`get_cache()`** — `lru_cache`-memoized factory returning a `diskcache.Cache` at `$OUTLINES_CACHE_DIR` (default `~/.cache/outlines`). Automatically clears the cache when the Outlines version changes.
- **`cache(expire, typed, ignore)`** — decorator that memoizes function calls (sync and async) using `diskcache`'s key generation.
- **`disable_cache()`** — disables caching for the session (useful for sampling workflows).
- **`clear_cache()`** — erases the cache entirely.
- **`cache_disabled()`** — context manager that temporarily disables caching.

> **Note:** The cache is used to avoid expensive model computations and API calls. See the [models module](task1371_models.md) for where caching is applied.

---

### 5. `US` Locale — Structured Type Registry

The `US` dataclass groups locale-specific structured types that can be used to constrain generation via the [guides module](task1371_guides.md).

```mermaid
flowchart TD
    L["locale('us')"] --> US["US"]
    US --> ZC["ZipCode = USZipCode"]
    US --> PN["PhoneNumber = USPhoneNumber"]

    ZC --> ZR["Regex: \\d{5}(?:-\\d{4})?"]
    PN --> PR["Regex: (\\([0-9]{3}\\) |[0-9]{3}-)[0-9]{3}-[0-9]{4}"]
```

**Types:**

| Type | Definition | Pattern |
|------|------------|---------|
| `USZipCode` | `Annotated[str, WithJsonSchema(...)]` | `\d{5}(?:-\d{4})?` (Zip and Zip+4) |
| `USPhoneNumber` | `Annotated[str, WithJsonSchema(...)]` | `(\([0-9]{3}\) \|[0-9]{3}-)[0-9]{3}-[0-9]{4}` |

**`locale(locale_str)`** — factory that returns the locale registry for a given string (currently only `"us"`). Raises `NotImplementedError` for unsupported locales, encouraging community contributions.

> **Note:** These types are `Annotated` strings carrying JSON Schema patterns, making them directly usable as output schemas for structured generation.

---

## Data Flow

The following diagram shows how support components participate in a typical structured-generation call.

```mermaid
sequenceDiagram
    participant User
    participant Prompt as Prompt
    participant Function as Function
    participant Cache as CloudpickleDisk
    participant Gen as SequenceGenerator
    participant Model as Transformers

    User->>Function: __call__(question="...")
    Function->>Function: init_generator() (lazy)
    Function->>Model: load model
    Function->>Gen: generate.json(model, schema)
    Function->>Prompt: render template
    Prompt-->>Function: prompt string
    Function->>Gen: generator(prompt)
    Gen->>Cache: check cache
    Cache-->>Gen: cache miss
    Gen->>Model: generate tokens
    Model-->>Gen: token ids
    Gen->>Cache: store result
    Gen-->>Function: formatted output
    Function-->>User: result
```

---

## Integration Points

| Support Component | Consumed By | Purpose |
|-------------------|-------------|---------|
| `vectorize` | Generation, Models | Batch function calls over arrays |
| `Prompt` | `Function`, user code | Build prompts from templates |
| `Function` | User code, GitHub programs | High-level task abstraction |
| `CloudpickleDisk` | Models, Generation | Cache expensive computations |
| `US` locale | Guides, user schemas | Constrain output to valid formats |

### Related Modules

- [Generation Module](task1371_generation.md) — `SequenceGenerator`, `SequenceGeneratorAdapter`, generation parameters.
- [Guides Module](task1371_guides.md) — FSM guides that consume locale types and schemas.
- [Processors Module](task1371_processors.md) — Logits processors applied during generation.
- [Samplers Module](task1371_samplers.md) — Sampling strategies used by generators.
- [Models Module](task1371_models.md) — Model providers that use caching and vectorization.
- [Benchmarks Module](task1371_benchmarks.md) — Performance benchmarks for the pipeline.

---

## Summary

The `task1371_support` module provides the reusable infrastructure that underpins the entire Outlines library:

- **`vectorize`** enables transparent batching of sync and async functions over array inputs.
- **`Prompt`** turns docstrings and files into reusable Jinja2 templates with rich function-introspection filters.
- **`Function`** bundles prompts, schemas, and models into a single callable, loadable from GitHub.
- **`CloudpickleDisk`** provides robust disk caching for arbitrary Python objects.
- **`US` locale** registers structured types for locale-aware constrained generation.

Because these components are provider-agnostic and sit at the base of the dependency graph, they can be reused and extended independently of the generation pipeline.
