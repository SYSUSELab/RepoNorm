# task1371_models

## Introduction

The `task1371_models` module is the **model provider abstraction layer** of Outlines. It wraps a wide range of inference backends (Hugging Face `transformers`, `llama-cpp-python`, `vLLM`, `exllamav2`, `mlx-lm`, and the OpenAI API) behind a **single, uniform interface**. This uniformity is what allows Outlines' structured generation features — regex/JSON/CFG-guided decoding — to work identically regardless of which inference engine is used.

Every model wrapper in this module exposes the same two core methods:

- `generate(prompts, generation_parameters, logits_processor, sampling_parameters, **model_specific_params)` — produce completions.
- `stream(prompts, generation_parameters, logits_processor, sampling_parameters, **model_specific_params)` — produce completions incrementally (where supported).

These signatures are consumed by the [`SequenceGeneratorAdapter`](task1371_generation.md) in the generation module, which is the public entry point users interact with. The `logits_processor` argument is an [`OutlinesLogitsProcessor`](task1371_processors.md) that enforces the structured output constraints during decoding.

---

## Module Architecture

The module is organized around a shared `Tokenizer` protocol and a set of provider-specific model classes. Each provider file also exposes a factory function (e.g. `transformers()`, `llamacpp()`, `vllm()`) that loads the underlying library and returns a wrapped model instance.

```mermaid
graph TD
    subgraph "task1371_models"
        TOK["Tokenizer<br/>(Protocol)"]
        TT["TransformerTokenizer"]
        LCT["LlamaCppTokenizer"]
        EXLT["OutlinesExLlamaV2Tokenizer"]

        TR["Transformers"]
        TRV["TransformersVision"]
        LC["LlamaCpp"]
        VL["VLLM"]
        EXL["ExLlamaV2Model"]
        MLX["MLXLM"]
        OAI["OpenAI"]

        TR --> TT
        TRV --> TR
        LC --> LCT
        EXL --> EXLT
        MLX --> TT
        TT -.implements.-> TOK
        LCT -.implements.-> TOK
        EXLT -.implements.-> TOK
    end

    subgraph "Consumers"
        SGA["SequenceGeneratorAdapter<br/>(task1371_generation)"]
        OLP["OutlinesLogitsProcessor<br/>(task1371_processors)"]
        SP["SamplingParameters<br/>(task1371_samplers)"]
    end

    SGA -->|calls generate/stream| TR
    SGA -->|calls generate/stream| LC
    SGA -->|calls generate/stream| VL
    SGA -->|calls generate/stream| EXL
    SGA -->|calls generate/stream| MLX
    SGA -->|calls __call__| OAI
    SGA -->|passes| OLP
    SGA -->|passes| SP
```

---

## The `Tokenizer` Protocol

**File:** `outlines/models/tokenizer.py`

`Tokenizer` is a `Protocol` (structural interface) that every provider-specific tokenizer must satisfy. It is `Hashable` so tokenizers can be used as cache keys (see [`CloudpickleDisk`](task1371_support.md)).

| Member | Type | Purpose |
| --- | --- | --- |
| `eos_token` | `str` | End-of-sequence token string. |
| `eos_token_id` | `int` | End-of-sequence token id. |
| `pad_token_id` | `int` | Padding token id. |
| `vocabulary` | `Dict[str, int]` | Mapping from token string to token id. |
| `special_tokens` | `Set[str]` | Set of special tokens. |
| `encode(prompt)` | `(NDArray, NDArray)` | Returns `(token_ids, attention_mask)`. |
| `decode(token_ids)` | `List[str]` | Converts token ids back to strings. |
| `convert_token_to_string(token)` | `str` | Normalizes a raw token to its string form (handles BPE whitespace markers like `Ġ`). |

The `vocabulary` and `convert_token_to_string` members are critical for the FSM/guide machinery in [`task1371_guides`](task1371_guides.md): the regex/CFG index is built by iterating over the vocabulary and matching token strings against the grammar.

### Tokenizer Implementations

```mermaid
classDiagram
    class Tokenizer {
        <<Protocol>>
        +str eos_token
        +int eos_token_id
        +int pad_token_id
        +Dict vocabulary
        +Set special_tokens
        +encode(prompt)
        +decode(token_ids)
        +convert_token_to_string(token)
    }
    class TransformerTokenizer {
        +PreTrainedTokenizer tokenizer
        +bool is_llama
        +encode(prompt, **kwargs)
        +decode(token_ids)
        +convert_token_to_string(token)
    }
    class LlamaCppTokenizer {
        +Llama model
        +_hf_tokenizer
        +encode(prompt, add_bos, special)
        +decode(token_ids)
    }
    class OutlinesExLlamaV2Tokenizer {
        +exl2_tokenizer
        +decode(token_ids)
    }
    Tokenizer <|.. TransformerTokenizer
    Tokenizer <|.. LlamaCppTokenizer
    Tokenizer <|.. OutlinesExLlamaV2Tokenizer
```

- **`TransformerTokenizer`** wraps a Hugging Face `PreTrainedTokenizer`. It includes a workaround (`is_llama`) for Llama-family tokenizers that mishandle leading spaces (`SPIECE_UNDERLINE` / `<0x20>`). It is also reused by `MLXLM`.
- **`LlamaCppTokenizer`** wraps `llama_cpp.Llama`'s tokenizer. It builds the vocabulary either from an attached HF tokenizer or by decoding every token id. It provides a stable `__getstate__` for caching but raises `NotImplementedError` on `__setstate__`.
- **`OutlinesExLlamaV2Tokenizer`** wraps `exllamav2`'s tokenizer, exposing `get_piece_to_id_dict()` as the vocabulary.

---

## Model Wrappers

### `Transformers` — Hugging Face `transformers`

**File:** `outlines/models/transformers.py`

The most feature-complete wrapper. It supports both decoder-only and encoder-decoder architectures, KV-cache reuse, batching, multiple samples, and streaming.

Key methods:

- `forward(input_ids, attention_mask, past_key_values)` — runs a forward pass under `torch.inference_mode()`, returning `(logits, past_key_values)`.
- `__call__(...)` — returns only the next-token logits plus the KV cache.
- `generate(...)` — translates Outlines' `GenerationParameters`/`SamplingParameters` into a Hugging Face `GenerationConfig` and calls `model.generate`.
- `stream(...)` — a stand-in that yields decoded tokens after generation completes (full streaming is pending an upstream `transformers` feature).
- `_get_generation_kwargs(...)` — maps sampler names (`multinomial`, `beam_search`) to `do_sample`/`num_beams`, sets `top_p`/`top_k`/`temperature`, and wraps the logits processor in a `LogitsProcessorList`.
- `_generate_output_seq(...)` / `_decode_generation(...)` — normalize output shapes across 1D/2D/3D cases.

Factory: `transformers(model_name, device, model_kwargs, tokenizer_kwargs, model_class, tokenizer_class)` loads via `AutoModelForCausalLM`/`AutoTokenizer` by default. A `mamba(...)` helper reuses it with `MambaForCausalLM`.

### `TransformersVision` — Multimodal `transformers`

**File:** `outlines/models/transformers_vision.py`

Subclasses `Transformers` to add image inputs. Its `generate` accepts an additional `media` argument (a `List[PIL.Image]` or `List[List[PIL.Image]]`) and uses a `processor` (e.g. `AutoProcessor`) to build inputs. `stream` raises `NotImplementedError`.

Factory: `transformers_vision(...)` loads a model, processor, and tokenizer.

### `LlamaCpp` — `llama-cpp-python`

**File:** `outlines/models/llamacpp.py`

Wraps `llama_cpp.Llama`. Notable characteristics:

- **No batch inference** — `generate`/`stream` raise `NotImplementedError` for list prompts.
- **No beam search / multiple samples** — enforced in `prepare_generation_parameters`.
- `prepare_generation_parameters(...)` reconciles Outlines' parameters with `llama.cpp`'s different defaults (e.g. `max_tokens - 1` because llama.cpp generates one extra token; disabling Mirostat/TFS/penalties).
- `LlamaCppParams` is a `TypedDict` describing the pass-through kwargs accepted by `Llama.__call__`.
- `load_lora(adapter_path)` applies a LoRA adapter.

Factory: `llamacpp(repo_id, filename, **params)` uses `Llama.from_pretrained` and emits a warning about the known unicode pre-tokenizer issue.

### `VLLM` — `vLLM`

**File:** `outlines/models/vllm.py`

Wraps `vllm.LLM` for high-throughput batched inference.

- `_get_tokenizer()` locates the tokenizer on the LLM instance and passes it through `adapt_tokenizer(...)`, which adds the Outlines-specific `vocabulary`, `special_tokens`, and `convert_token_to_string` attributes.
- `generate(...)` accepts an optional `vllm.sampling_params.SamplingParams` that supersedes Outlines parameters, and maps sampler settings (`use_beam_search`, `n`, `best_of`, etc.).
- Output shape is normalized: a single string, a list of samples, a list of batches, or a 2D list.
- `stream` raises `NotImplementedError`.
- `load_lora(adapter_path)` sets a `LoRARequest`.

Factory: `vllm(model_name, **params)`.

### `ExLlamaV2Model` — `exllamav2`

**File:** `outlines/models/exllamav2.py`

Wraps `ExLlamaV2DynamicGenerator`.

- `prepare_generation_parameters(...)` computes per-prompt `max_new_tokens` from the remaining context window, builds `stop_conditions`, and configures `ExLlamaV2Sampler.Settings` (temperature/top_p/top_k + the structure logits processor). Multiple samples are handled by duplicating prompts.
- `reformat_output(...)` converts exllamav2's output conventions into Outlines' conventions.
- `generate(...)` picks the minimum `max_new_tokens` across the batch to avoid exceeding the sequence length.
- `stream(...)` enqueues `ExLlamaV2DynamicJob`s and yields incremental text.
- `ExllamaV2Params` is a `TypedDict` for pass-through kwargs.

Factory: `exl2(model_path, ...)` builds the config, model, cache (optionally Q4), optional draft model, and generator.

### `MLXLM` — `mlx-lm` (Apple Silicon)

**File:** `outlines/models/mlxlm.py`

Wraps `mlx_lm` models. It reuses `TransformerTokenizer` for the HF tokenizer while keeping the mlx tokenizer for encoding.

- `generate(...)` simply joins the output of `stream(...)`.
- `stream(...)` enforces several limitations (no batch, no beam search, no multiple samples, no `top_k`, no `seed`, no `stop_at`) and drives `generate_step(...)`.
- `generate_step(...)` is a generator that runs the model with a prompt cache, applies the logits processor (reshaping to 1D as expected by `OutlinesLogitsProcessor`), and samples via greedy or multinomial (with optional top-p).

Factory: `mlxlm(...)` requires Metal (Apple Silicon) and raises otherwise.

### `OpenAI` — OpenAI / Azure OpenAI API

**File:** `outlines/models/openai.py`

Unlike the local wrappers, `OpenAI` is an **async, API-based** model. It does not accept a `logits_processor` (the API cannot be constrained at the logit level); instead structured output is achieved via `response_format` (JSON mode) and post-hoc formatting.

- `OpenAIConfig` is a frozen dataclass capturing API parameters (`model`, `temperature`, `top_p`, `n`, `stop`, `seed`, `response_format`, penalties, etc.).
- `__call__(...)` invokes `generate_chat(...)`, accumulates token usage counters, and applies `format_sequence`.
- `generate_chat(...)` is decorated with `@vectorize` (from [`task1371_support`](task1371_support.md)) and `@cache()` (from [`CloudpickleDisk`](task1371_support.md)), and wraps the API call in `error_handler`.
- `stream` raises `NotImplementedError`.
- `new_with_replacements(**kwargs)` returns a copy with an updated config.

Factories: `openai(...)` (a `singledispatch` function, with a `str` overload for model names) and `azure_openai(...)`.

---

## Data Flow

The following sequence diagram shows how a structured generation request flows from the public API through a model wrapper.

```mermaid
sequenceDiagram
    participant User
    participant SGA as SequenceGeneratorAdapter
    participant Model as Model Wrapper
    participant LP as OutlinesLogitsProcessor
    participant Backend as Inference Backend

    User->>SGA: __call__(prompt, max_tokens, stop_at, seed)
    SGA->>SGA: prepare_generation_parameters()
    SGA->>Model: generate(prompts, gen_params, logits_processor, sampling_params)
    Model->>Model: prepare_generation_parameters() (provider-specific)
    Model->>Backend: model.generate(...) / model(...)
    loop each decoding step
        Backend->>LP: __call__(input_ids, logits)
        LP->>LP: process_logits() (apply FSM mask)
        LP-->>Backend: masked logits
    end
    Backend-->>Model: generated token ids
    Model->>Model: decode / reformat_output
    Model-->>SGA: text (str / List[str] / List[List[str]])
    SGA->>SGA: _format() / format_sequence()
    SGA-->>User: formatted output
```

### Parameter Reconciliation

Each provider has its own defaults and capabilities, so every wrapper implements a `prepare_generation_parameters`-style step that merges three sources of truth, in priority order:

```mermaid
flowchart LR
    A["Outlines<br/>GenerationParameters<br/>(max_tokens, stop_at, seed)"] --> M
    B["Outlines<br/>SamplingParameters<br/>(sampler, num_samples, top_p, top_k, temperature)"] --> M
    C["Provider-specific<br/>pass-through kwargs<br/>(TypedDict)"] --> M
    M["prepare_generation_parameters()"] --> D["Provider-native<br/>generation config"]
```

Provider-specific pass-through kwargs (e.g. `LlamaCppParams`, `ExllamaV2Params`, `vllm.SamplingParams`) always **supersede** the Outlines-level parameters.

---

## Capability Matrix

| Provider | Class | Batch | Multiple Samples | Beam Search | Streaming | Logits Processor | LoRA |
| --- | --- | :---: | :---: | :---: | :---: | :---: | :---: |
| `transformers` | `Transformers` | ✅ | ✅ | ✅ | ⚠️ (post-hoc) | ✅ | — |
| `transformers` (vision) | `TransformersVision` | ✅ | ✅ | ✅ | ❌ | ✅ | — |
| `llama-cpp-python` | `LlamaCpp` | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ |
| `vLLM` | `VLLM` | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ |
| `exllamav2` | `ExLlamaV2Model` | ✅ | ✅ | — | ✅ | ✅ | — |
| `mlx-lm` | `MLXLM` | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ (load-time) |
| OpenAI API | `OpenAI` | ✅ | ✅ | — | ❌ | ❌ | — |

---

## Dependencies

```mermaid
graph LR
    subgraph "task1371_models"
        M[models]
    end
    M -->|GenerationParameters, SamplingParameters| G["task1371_generation"]
    M -->|OutlinesLogitsProcessor| P["task1371_processors"]
    M -->|SamplingParameters| S["task1371_samplers"]
    M -->|vectorize, cache| SUP["task1371_support"]
    M -.vocabulary used by.-> GD["task1371_guides"]
```

- **[`task1371_generation`](task1371_generation.md)** — defines `GenerationParameters` and `SamplingParameters`, and the `SequenceGeneratorAdapter` that calls into these models.
- **[`task1371_processors`](task1371_processors.md)** — provides `OutlinesLogitsProcessor`, the type of the `logits_processor` argument passed to every `generate`/`stream`.
- **[`task1371_samplers`](task1371_samplers.md)** — defines the `SamplingParameters` dataclass consumed by the wrappers.
- **[`task1371_guides`](task1371_guides.md)** — relies on the `Tokenizer.vocabulary` and `convert_token_to_string` exposed by this module to build FSM indices.
- **[`task1371_support`](task1371_support.md)** — provides `vectorize` and `CloudpickleDisk` caching used by the OpenAI integration.

---

## Extending the Module

To add a new model provider:

1. Implement a tokenizer satisfying the `Tokenizer` protocol (or reuse `TransformerTokenizer`).
2. Implement a model class exposing `generate(...)` and `stream(...)` with the standard signatures, plus a `prepare_generation_parameters`-style reconciliation step.
3. Add a factory function that loads the backend and returns the wrapped model.
4. Optionally define a `TypedDict` for provider-specific pass-through kwargs.

Because the [`SequenceGeneratorAdapter`](task1371_generation.md) only depends on the `generate`/`stream` signatures, no changes to the generation layer are required.
