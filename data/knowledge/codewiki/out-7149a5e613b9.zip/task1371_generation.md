# Generation Module (`task1371_generation`)

## Introduction

The **Generation** module is the core text-generation engine of Outlines. It is responsible for
turning a *prompt* into *structured output* by coordinating three collaborating subsystems:

1. **A model** that produces next-token logits (see [Models](task1371_models.md)).
2. **A finite-state machine (FSM) / guide** that constrains which tokens are legal at each step
   (see [Guides](task1371_guides.md)).
3. **A sampler** that selects the next token from the (biased) logits (see
   [Samplers](task1371_samplers.md)).

The module exposes two distinct generation paths:

- **`SequenceGenerator`** — a *local* generation loop that drives the model token-by-token,
  applying FSM constraints directly inside the loop. Used by local backends such as
  `transformers`, `llamacpp`, `mlxlm`, and `exllamav2`.
- **`SequenceGeneratorAdapter`** (and its vision variant) — a thin *adapter* that delegates
  generation to a model provider's own `generate`/`stream` implementation, passing a
  [logits processor](task1371_processors.md) instead of running the loop itself. Used by
  backends such as `vllm` and `openai`.

This document covers the public API (`outlines/generate/api.py`) and the low-level generation
loop (`outlines/generate/generator.py`).

---

## Module Structure

```
outlines/generate/
├── api.py        # Public API: SequenceGenerator, adapters, parameter dataclasses
└── generator.py  # Low-level token-by-token generation loop + GenerationState
```

### Core Components

| Component | File | Role |
|-----------|------|------|
| `SequenceGenerator` | `api.py` | Local generation loop; applies FSM constraints in-process |
| `SequenceGeneratorAdapter` | `api.py` | Delegates generation to a model provider |
| `VisionSequenceGeneratorAdapter` | `api.py` | Adapter variant for multimodal (image + text) models |
| `GenerationParameters` | `api.py` | Frozen dataclass: `max_tokens`, `stop_at`, `seed` |
| `SamplingParameters` | `api.py` | Frozen dataclass: `sampler`, `num_samples`, `top_p`, `top_k`, `temperature` |
| `GenerationState` | `generator.py` | Frozen dataclass snapshot of one generation step |
| `ContextLengthExceededError` | `generator.py` | Raised when the model's context window is exceeded |
| `sequence_generator` | `generator.py` | Generator function implementing the core loop |

---

## Architecture Overview

The generation module sits between the user-facing API and the model/guide/sampler subsystems.

```mermaid
graph TD
    User["User / High-level API<br/>(outlines.generate.*)"]

    subgraph Generation["task1371_generation"]
        SG["SequenceGenerator<br/>(local loop)"]
        SGA["SequenceGeneratorAdapter<br/>(delegating)"]
        VSGA["VisionSequenceGeneratorAdapter"]
        GEN["sequence_generator()<br/>generator.py"]
        GS["GenerationState"]
        GP["GenerationParameters"]
        SP["SamplingParameters"]
    end

    subgraph Guides["task1371_guides"]
        Guide["Guide / RegexGuide / CFGGuide"]
    end

    subgraph Samplers["task1371_samplers"]
        Sampler["Sampler<br/>(Greedy/Multinomial/BeamSearch)"]
    end

    subgraph Models["task1371_models"]
        Model["Transformers / LlamaCpp / VLLM / ..."]
        Tokenizer["Tokenizer"]
    end

    subgraph Processors["task1371_processors"]
        LP["OutlinesLogitsProcessor<br/>(GuideLogitsProcessor)"]
    end

    User --> SG
    User --> SGA
    User --> VSGA

    SG --> GEN
    GEN --> GS
    SG --> Guide
    SG --> Sampler
    SG --> Model
    SG --> Tokenizer

    SGA --> GP
    SGA --> SP
    SGA --> LP
    SGA --> Model
    VSGA --> SGA
```

---

## The Two Generation Paths

### Path A — Local Loop (`SequenceGenerator`)

`SequenceGenerator` owns the entire generation loop. It is constructed with an FSM, a model, a
sampler, and a device:

```python
SequenceGenerator(fsm, model, sampler, device)
```

It exposes two entry points:

- **`__call__(prompts, max_tokens, stop_at, rng)`** — generates the *full* sequence and returns
  the decoded (and optionally formatted) output. It loops over `sequence_generator` internally so
  the tokenizer is invoked only once at the end.
- **`stream(prompts, max_tokens, stop_at, rng)`** — yields the generated text one token at a time.
  Because `Tokenizer.decode` strips whitespace, the stream re-decodes the full generated prefix at
  each step and diffs it against the previously decoded string.

Both methods share the same setup: encode prompts, repeat them `num_samples` times, copy the FSM
per sequence, initialize FSM states to `0`, and hand everything to `sequence_generator`.

### Path B — Delegating Adapter (`SequenceGeneratorAdapter`)

`SequenceGeneratorAdapter` does **not** run a loop. Instead it:

1. Builds a `GenerationParameters` object from `max_tokens`, `stop_at`, `seed`.
2. Calls `model.generate(prompts, generation_params, logits_processor, sampling_params, ...)`.
3. Applies `format_sequence` to the result via `_format`.

The `logits_processor` (a [GuideLogitsProcessor](task1371_processors.md)) is copied before being
passed to the model, so the same adapter can be reused across calls.

`VisionSequenceGeneratorAdapter` extends this to accept a `media` argument (a URI or a
`PIL.Image`), validating that each prompt is paired with the correct media before delegating.

---

## Component Interaction

The following diagram shows how the pieces interact during a single local generation call.

```mermaid
sequenceDiagram
    participant U as User
    participant SG as SequenceGenerator
    participant T as Tokenizer
    participant G as sequence_generator
    participant M as Model
    participant F as Guide (FSM)
    participant S as Sampler

    U->>SG: __call__(prompts, max_tokens, stop_at)
    SG->>T: encode(prompts)
    T-->>SG: prompt_token_ids, attention_masks
    SG->>SG: repeat prompts × num_samples, copy FSMs
    SG->>G: sequence_generator(model, sampler, fsms, ...)

    loop until finished / max_tokens / stop_at
        G->>M: model(token_ids, attention_masks, kv_cache)
        M-->>G: logits, kv_cache
        G->>F: get_next_instruction(state).tokens
        F-->>G: allowed_tokens
        G->>G: bias_logits(logits, allowed_tokens)
        G->>S: sampler(biased_logits, weights, rng)
        S-->>G: next_token_ids, ancestors, weights
        G->>G: update token_ids / masks / kv_cache / fsm_states
        G-->>SG: yield GenerationState
    end

    SG->>T: decode(generated_token_ids)
    T-->>SG: generated strings
    SG->>SG: strip_stop_sequences + format_sequence
    SG-->>U: formatted output
```

---

## The Core Generation Loop (`sequence_generator`)

`sequence_generator` is a Python generator that yields a `GenerationState` after every step. Each
iteration performs the following pipeline:

```mermaid
flowchart TD
    Start([Start]) --> Forward["model(token_ids, attention_masks, kv_cache)"]
    Forward -->|IndexError| CtxErr["raise ContextLengthExceededError"]
    Forward --> Allowed["get_allowed_tokens(fsms, fsm_states)"]
    Allowed --> Bias["bias_logits(logits, allowed_tokens)"]
    Bias --> Sample["sampler(biased_logits, weights, rng)"]
    Sample --> Update["update_token_ids / attention_masks / kv_cache"]
    Update --> Reorder{"len(ancestors) > 1?"}
    Reorder -->|yes| ReorderFSM["reorder_fsms / reorder_fsm_states"]
    Reorder -->|no| NextState
    ReorderFSM --> NextState["get_next_fsm_states(...)"]
    NextState --> Finished{"is_generation_finished?"}
    Finished -->|yes| YieldFinal["yield GenerationState; return"]
    Finished -->|no| Yield["yield GenerationState"]
    Yield --> Forward
```

### Helper Functions

| Function | Purpose |
|----------|---------|
| `get_allowed_tokens` | Queries each FSM for the set of legal next tokens |
| `bias_logits` | Masks disallowed logits to `-inf` (per-sequence) |
| `update_token_ids` | Selects ancestor rows and appends the new token |
| `update_attention_masks` | Selects ancestor rows and appends a `1` |
| `reorder_kv_cache` | Re-indexes the KV-cache by ancestor (beam search) |
| `reorder_fsms` / `reorder_fsm_states` | Re-orders FSM state for beam search |
| `get_next_fsm_states` | Advances each FSM by the sampled token |
| `is_generation_finished` | True when *all* FSMs are in a final state |

### `GenerationState`

A frozen dataclass capturing a single step's snapshot:

```python
@dataclasses.dataclass(frozen=True)
class GenerationState:
    token_ids: "torch.Tensor"      # full token sequences so far
    kv_cache: "torch.Tensor"       # model KV-cache
    logits: "torch.Tensor"         # raw logits for this step
    weights: "torch.Tensor"        # cumulative sequence weights
    fsm_states: List[int]          # FSM state per sequence
```

### `ContextLengthExceededError`

Raised by `sequence_generator` when the model's forward pass raises an `IndexError`, which
indicates the input length has exceeded the model's context window.

---

## Data Flow: From Prompt to Formatted Output

```mermaid
flowchart LR
    P["prompts<br/>(str | List[str])"] --> Enc["Tokenizer.encode"]
    Enc --> Rep["repeat_interleave<br/>× num_samples"]
    Rep --> Loop["sequence_generator loop"]
    Loop --> Dec["Tokenizer.decode"]
    Dec --> Strip["strip_stop_sequences"]
    Strip --> Fmt["format_sequence"]
    Fmt --> Out["FormattedOutput<br/>(str | int | float | bool | date | ...)"]
```

`FormattedOutput` is a union type covering `str`, `int`, `float`, `bool`, and the `datetime`
types. Subclasses override `format_sequence` to return richer types (e.g. a Pydantic model or a
dict when generating JSON).

### Output Shaping

Both `__call__` and `stream` reshape the flat `(batch_size × num_samples)` output back into a
nested structure and strip leading dimensions:

| `batch_size` | `num_samples` | Returned shape |
|--------------|---------------|----------------|
| 1 | 1 | single value |
| 1 | >1 | `List[value]` |
| >1 | 1 | `List[value]` |
| >1 | >1 | `List[List[value]]` |

---

## Parameter Dataclasses

### `GenerationParameters`

```python
@dataclass(frozen=True)
class GenerationParameters:
    max_tokens: Optional[int]
    stop_at: Optional[Union[str, List[str]]]
    seed: Optional[int]
```

Used by the adapter path to communicate generation controls to a model provider. The adapter's
`prepare_generation_parameters` normalizes a single `stop_at` string into a list.

### `SamplingParameters`

```python
@dataclass(frozen=True)
class SamplingParameters:
    sampler: str
    num_samples: int = 1
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    temperature: Optional[float] = None
```

Describes *how* to sample. Each [Sampler](task1371_samplers.md) exposes a `sampling_params`
property that produces an instance of this dataclass (e.g. `MultinomialSampler` →
`"multinomial"`, `BeamSearchSampler` → `"beam_search"`).

---

## Dependencies

```mermaid
graph LR
    Gen["task1371_generation"]

    Gen -->|uses| Guides["task1371_guides<br/>Guide, RegexGuide, CFGGuide"]
    Gen -->|uses| Samplers["task1371_samplers<br/>Sampler, SamplingParameters"]
    Gen -->|uses| Models["task1371_models<br/>Tokenizer, Transformers, VLLM, ..."]
    Gen -->|uses| Processors["task1371_processors<br/>OutlinesLogitsProcessor"]
    Gen -->|uses| Support["task1371_support<br/>Prompt, Function, caching"]
    Gen -->|benchmarked by| Benchmarks["task1371_benchmarks"]
```

### Key Interfaces Consumed

- **`Guide`** ([Guides](task1371_guides.md)) — provides `get_next_instruction(state).tokens`,
  `get_next_state(state, token_id)`, `is_final_state(state)`, `initial_state`, and `copy()`.
- **`Sampler`** ([Samplers](task1371_samplers.md)) — a protocol with a `samples` attribute and a
  `__call__(next_token_logits, sequence_weights, rng)` returning
  `(next_token_ids, ancestors, weights)`.
- **`Tokenizer`** ([Models](task1371_models.md)) — provides `encode`, `decode`,
  `convert_token_to_string`, plus `eos_token_id` / `pad_token_id`.
- **`OutlinesLogitsProcessor`** ([Processors](task1371_processors.md)) — normalizes logits types
  and applies guide-based masking in the adapter path.

---

## Relationship to Other Modules

- **[Guides](task1371_guides.md)** define the *constraints*. The generation loop queries them for
  allowed tokens and advances their state. `RegexGuide`, `CFGGuide`, and `StopAtEOSGuide` are the
  concrete implementations.
- **[Samplers](task1371_samplers.md)** define the *selection strategy*. `GreedySampler`,
  `MultinomialSampler`, and `BeamSearchSampler` implement the `Sampler` protocol. Beam search is
  the reason the loop must reorder FSMs, FSM states, and the KV-cache by `ancestors`.
- **[Models](task1371_models.md)** provide the *logits*. Local backends (`Transformers`,
  `LlamaCpp`, `MLXLM`, `ExLlamaV2Model`) use `SequenceGenerator`; provider backends (`VLLM`,
  `OpenAI`) use `SequenceGeneratorAdapter`.
- **[Processors](task1371_processors.md)** are the adapter-path equivalent of the in-loop
  `bias_logits` step. `GuideLogitsProcessor` maintains a cache of guide states keyed by the
  generated token prefix.
- **[Benchmarks](task1371_benchmarks.md)** measure the performance of the guides and processors
  that this module drives.

---

## Summary

The `task1371_generation` module is the orchestration layer of Outlines' structured generation.
It offers two complementary strategies — an in-process token loop (`SequenceGenerator`) and a
delegating adapter (`SequenceGeneratorAdapter`) — that both combine a model, a guide, and a
sampler to produce constrained, formatted output. The low-level `sequence_generator` generator
function encapsulates the per-step pipeline (forward pass → mask → sample → update → advance FSM),
while the dataclasses `GenerationParameters`, `SamplingParameters`, and `GenerationState` provide
clean, immutable contracts between the module and its collaborators.
