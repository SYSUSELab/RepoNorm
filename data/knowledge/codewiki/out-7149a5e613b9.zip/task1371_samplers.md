# Samplers Module (`outlines/samplers.py`)

## Introduction

The **Samplers** module provides the token-selection strategies used by Outlines to
turn a probability distribution over the vocabulary (the *next-token logits*) into
concrete token ids. It is the component that decides *which* token is appended to a
sequence at every generation step.

The module exposes three concrete sampling algorithms behind a single, uniform
callable interface:

| Sampler | Strategy | Deterministic | Multi-sample |
|---------|----------|---------------|--------------|
| `GreedySampler` | Always pick the most likely token | ✅ | ❌ (1 sample) |
| `MultinomialSampler` | Sample from the categorical distribution (with `top_k` / `top_p` / `temperature`) | ❌ | ✅ |
| `BeamSearchSampler` | Keep the `k` highest-weight partial sequences | ✅ | ✅ (beams) |

All samplers share the same `__call__` signature and return a 3-tuple
`(next_token_ids, ancestors, weights)`, which makes them interchangeable inside the
generation loop. This design lets the generation engine treat sampling as a
pluggable strategy.

> **Related documentation:** The samplers are consumed by the generation engine
> described in [task1371_generation.md](task1371_generation.md). The logits they
> receive are first biased by the structured-generation machinery documented in
> [task1371_processors.md](task1371_processors.md) and
> [task1371_guides.md](task1371_guides.md).

---

## Architecture Overview

The module is intentionally small and dependency-light. It depends only on `torch`
(imported lazily inside methods) and the standard library. The central abstraction is
the `Sampler` protocol, which all concrete implementations satisfy.

```mermaid
classDiagram
    class Sampler {
        <<Protocol>>
        +int samples
        +__call__(next_token_logits, sequence_weights, rng)
    }
    class GreedySampler {
        +int samples = 1
        +__call__(...)
        +sampling_params
    }
    class MultinomialSampler {
        +int samples
        +top_k
        +top_p
        +temperature
        +logits_processors
        +__call__(...)
        +sampling_params
    }
    class BeamSearchSampler {
        +int samples
        +__call__(...)
        +sampling_params
    }
    class SamplingParameters {
        <<dataclass, frozen>>
        +str sampler
        +int num_samples
        +float top_p
        +int top_k
        +float temperature
    }

    Sampler <|.. GreedySampler
    Sampler <|.. MultinomialSampler
    Sampler <|.. BeamSearchSampler
    GreedySampler ..> SamplingParameters : produces
    MultinomialSampler ..> SamplingParameters : produces
    BeamSearchSampler ..> SamplingParameters : produces
```

### Module-level aliases

For convenience, the module exposes lowercase aliases that point to the classes:

```python
greedy = GreedySampler
multinomial = MultinomialSampler
beam_search = BeamSearchSampler
```

These aliases are what the public API typically references when a user selects a
sampler by name.

---

## The `Sampler` Protocol

`Sampler` is a `typing.Protocol` that defines the contract every sampling strategy
must fulfill. It is not instantiated directly; it exists to type-check and document
the interface.

```python
class Sampler(Protocol):
    samples: int

    def __call__(
        self,
        next_token_logits: "torch.DoubleTensor",
        sequence_weights: "torch.DoubleTensor",
        rng: "torch.Generator",
    ) -> "torch.DoubleTensor":
        ...
```

### The uniform call contract

Every sampler is invoked with three arguments and returns a 3-tuple:

| Argument | Shape | Meaning |
|----------|-------|---------|
| `next_token_logits` | `(n_seqs, vocab_size)` | Unnormalized log-probabilities of the next token over the vocabulary. |
| `sequence_weights` | `(n_seqs,)` | Cumulative log-probability weight of each sequence so far. |
| `rng` | `torch.Generator` | Random number generator (ignored by deterministic samplers). |

| Return value | Shape | Meaning |
|--------------|-------|---------|
| `next_token_ids` | `(n_seqs, 1)` | The chosen token id for each sequence. |
| `ancestors` | `(n_seqs,)` | Index of the parent sequence each new sequence descends from. |
| `weights` | `(n_seqs,)` | Updated cumulative weights. |

The `ancestors` tensor is the key to supporting multi-sample and beam-search
strategies: it tells the generation loop how to reorder the KV-cache, attention
masks, FSMs and FSM states so that each new sequence correctly inherits the history
of its parent. See [task1371_generation.md](task1371_generation.md) for how
`ancestors` is consumed by `sequence_generator`.

---

## `SamplingParameters`

`SamplingParameters` is a frozen dataclass that captures the configuration of a
sampler in a serializable, model-agnostic form. It is the bridge between the
in-process samplers and model providers (e.g. vLLM, OpenAI) that perform sampling
internally.

```python
@dataclass(frozen=True)
class SamplingParameters:
    sampler: str
    num_samples: int = 1
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    temperature: Optional[float] = None
```

| Field | Description |
|-------|-------------|
| `sampler` | Name of the strategy: `"greedy"`, `"multinomial"`, or `"beam_search"`. |
| `num_samples` | Number of samples (or beams) per input sequence. |
| `top_p` | Nucleus-sampling threshold (multinomial only). |
| `top_k` | Top-k truncation (multinomial only). |
| `temperature` | Logit rescaling factor (multinomial only). |

Each sampler exposes a `sampling_params` property that returns the corresponding
`SamplingParameters` instance. This is how `SequenceGeneratorAdapter` forwards the
sampling configuration to remote model providers — see
[task1371_generation.md](task1371_generation.md).

> **Note:** There is a second, structurally identical `SamplingParameters` defined in
> `outlines/generate/api.py`. The one in this module is the canonical definition used
> by the samplers themselves.

---

## Sampling Algorithms

### `GreedySampler`

Greedy sampling always selects the token with the highest likelihood. It is fully
deterministic and produces exactly one sample per input sequence.

**Algorithm:**
1. Compute `log_softmax` over the logits.
2. Take `argmax` along the vocabulary dimension.
3. `ancestors` is the identity mapping (`arange`), since no reordering occurs.
4. Update weights by adding the selected token's log-probability.

```python
logprobs = torch.nn.functional.log_softmax(next_token_logits, dim=-1)
next_token_ids = torch.argmax(logprobs, dim=-1, keepdim=True)
ancestors = torch.arange(next_token_logits.shape[0], device=...)
weights = sequence_weights + torch.gather(logprobs, 1, next_token_ids).squeeze()
```

The `sampling_params` property reports `temperature=0.0` to signal determinism.

> **Design note:** Greedy sampling is deliberately limited to a single sample. The
> docstring notes that allowing `k` samples would be equivalent to beam search
> *without* sequence weights, so the two are kept distinct.

### `MultinomialSampler`

Multinomial sampling draws the next token from a categorical distribution
parameterized by the (optionally transformed) logits. It supports the standard
decoding-time transformations.

**Constructor parameters:**

| Parameter | Effect |
|-----------|--------|
| `samples` | Number of samples per input sequence. |
| `top_k` | Keep only the `k` highest logits; mask the rest with `-inf`. |
| `top_p` | Nucleus sampling: keep the smallest set of tokens whose cumulative probability ≥ `p`. |
| `temperature` | Divide logits by `temperature` before softmax. |

**Logits-processor pipeline:** The constructor builds a list of `logits_processors`
applied in order before sampling:

```mermaid
flowchart LR
    A[next_token_logits] --> B{top_k set?}
    B -- yes --> C[keep_top_k_logits]
    B -- no --> D{top_p set?}
    D -- yes --> E[keep_top_p_logits]
    C --> F{temperature set?}
    E --> F
    D -- no --> F
    F -- yes --> G[rescale_logits]
    F -- no --> H[softmax]
    G --> H
    H --> I[torch.multinomial]
    I --> J[next_token_ids]
```

Note that `top_k` and `top_p` are mutually exclusive in the pipeline: `top_k` takes
precedence if both are provided (`elif` branch).

**Algorithm:**
1. Apply each logits processor sequentially.
2. `softmax` the transformed logits.
3. `torch.multinomial` to draw one token per sequence using `rng`.
4. Compute `log_softmax` of the transformed logits to update weights.
5. `ancestors` is the identity mapping.

#### Helper logits processors

Three module-level factory functions build the transformations:

- **`keep_top_k_logits(k)`** — Masks all logits below the top-`k` values with
  `-math.inf`. Validates that `k` is a strictly positive integer.
- **`keep_top_p_logits(p)`** — Sorts logits ascending, computes the cumulative
  softmax probability, and masks tokens whose cumulative probability is below
  `1 - p`. Validates that `0 < p ≤ 1`.
- **`rescale_logits(temperature)`** — Divides logits by `temperature`. Validates
  that `temperature` is a positive float and explicitly rejects `0.0`, directing
  users to the greedy sampler instead.

### `BeamSearchSampler`

Beam search maintains `beams` candidate sequences per input, expanding each by all
vocabulary tokens and keeping the globally highest-weight candidates.

**Constructor parameter:** `beams` — the number of beams (stored as `samples`).

**Algorithm:**
1. Compute `log_softmax` over the logits.
2. Add the current `sequence_weights` (broadcast) to form candidate weights.
3. Flatten to `(batch_size, samples * vocab_size)`.
4. **Bootstrap special case:** if all `sequence_weights == 0` (start of search),
   restrict to the first `vocab_size` columns so the initial beams are not
   duplicated.
5. `torch.topk` to select the `samples` best candidates per batch.
6. Decode the flat indices back into `ancestors` (parent beam) and
   `next_token_ids` (token within the vocabulary).
7. Offset `ancestors` by the batch's first beam index and reshape to
   `(samples * batch_size,)`.

The `sampling_params` property reports `temperature=1.0`.

---

## Data Flow

The following diagram shows how a sampler fits into a single generation step. The
logits produced by the model are first constrained by the structured-generation
machinery, then handed to the sampler.

```mermaid
sequenceDiagram
    participant Model
    participant Guide as Guide / FSM
    participant Sampler
    participant Loop as sequence_generator

    Loop->>Model: token_ids, attention_masks, kv_cache
    Model-->>Loop: logits, kv_cache
    Loop->>Guide: get_allowed_tokens(fsms, fsm_states)
    Guide-->>Loop: allowed_tokens
    Loop->>Loop: bias_logits(logits, allowed_tokens)
    Loop->>Sampler: __call__(biased_logits, sequence_weights, rng)
    Sampler-->>Loop: next_token_ids, ancestors, weights
    Loop->>Loop: update_token_ids / reorder_kv_cache / reorder_fsms
```

The `ancestors` output drives the reordering of all per-sequence state (KV-cache,
attention masks, FSMs, FSM states) whenever a sampler produces more than one
sequence per input (multinomial with `samples > 1`, or beam search).

---

## Component Interaction

```mermaid
flowchart TD
    subgraph Samplers["outlines/samplers.py"]
        G[GreedySampler]
        M[MultinomialSampler]
        B[BeamSearchSampler]
        SP[SamplingParameters]
    end

    subgraph Generation["task1371_generation"]
        SG[SequenceGenerator]
        SGA[SequenceGeneratorAdapter]
        GEN[sequence_generator]
    end

    subgraph Processors["task1371_processors"]
        GLP[GuideLogitsProcessor]
    end

    subgraph Models["task1371_models"]
        MDL[Model providers]
    end

    SG -->|uses| G
    SG -->|uses| M
    SG -->|uses| B
    GEN -->|calls| G
    GEN -->|calls| M
    GEN -->|calls| B
    GLP -->|biases logits before| GEN
    SGA -->|forwards sampling_params| MDL
    G -.->|sampling_params| SP
    M -.->|sampling_params| SP
    B -.->|sampling_params| SP
```

### Integration points

- **`SequenceGenerator`** (in [task1371_generation.md](task1371_generation.md))
  receives a `sampler` and reads `sampler.samples` to determine `num_samples`. It
  repeats prompts and copies FSMs accordingly.
- **`sequence_generator`** (in [task1371_generation.md](task1371_generation.md))
  calls the sampler once per step and uses the returned `ancestors` to reorder
  state.
- **`SequenceGeneratorAdapter`** (in [task1371_generation.md](task1371_generation.md))
  reads `sampler.sampling_params` and forwards it to model providers that perform
  sampling internally (e.g. vLLM, OpenAI).
- **`GuideLogitsProcessor`** (in [task1371_processors.md](task1371_processors.md))
  biases the logits *before* they reach the sampler, ensuring only
  grammar-valid tokens are sampled.

---

## Process Flow: Choosing a Sampler

```mermaid
flowchart TD
    Start([User selects sampler]) --> Q1{Deterministic?}
    Q1 -- yes --> Greedy[GreedySampler]
    Q1 -- no --> Q2{Multiple candidates?}
    Q2 -- no --> Multi[MultinomialSampler]
    Q2 -- yes --> Q3{Exhaustive search?}
    Q3 -- yes --> Beam[BeamSearchSampler]
    Q3 -- no --> Multi
    Greedy --> Params1[SamplingParameters greedy, 1, temp=0.0]
    Multi --> Params2[SamplingParameters multinomial, n, top_p, top_k, temp]
    Beam --> Params3[SamplingParameters beam_search, beams, temp=1.0]
```

---

## Summary

The `outlines/samplers.py` module is a compact, self-contained strategy layer:

- **`Sampler`** — a protocol defining the uniform `(logits, weights, rng) → (ids, ancestors, weights)` contract.
- **`GreedySampler`** — deterministic argmax decoding.
- **`MultinomialSampler`** — stochastic decoding with `top_k`, `top_p`, and `temperature` transformations.
- **`BeamSearchSampler`** — beam search over the vocabulary.
- **`SamplingParameters`** — a frozen dataclass describing a sampler's configuration for model providers.

Its clean separation from the generation loop, the structured-generation guides, and
the model providers makes sampling a fully pluggable concern. For the surrounding
machinery, see [task1371_generation.md](task1371_generation.md),
[task1371_processors.md](task1371_processors.md),
[task1371_guides.md](task1371_guides.md), and
[task1371_models.md](task1371_models.md).
