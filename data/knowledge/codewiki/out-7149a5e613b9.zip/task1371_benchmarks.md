# Benchmarks Module

## Introduction

The `task1371_benchmarks` module provides a suite of performance benchmarks for the core structured-generation machinery of Outlines. It measures the cost of building finite-state-machine (FSM) guides from regular expressions, JSON schemas, and context-free grammars (CFGs), as well as the runtime cost of applying logits processors during a single decoder pass.

These benchmarks are written against the [pytest-benchmark](https://pytest-benchmark.readthedocs.io/) convention: each benchmark class exposes a `params` attribute, a `setup` method, and one or more `time_*` / `peakmem_*` methods. They are intended to be run in CI or locally to detect performance regressions in the guide-construction and logits-processing hot paths.

The module is organized into four benchmark files:

| File | Focus | Core Components |
|------|-------|-----------------|
| `bench_regex_guide.py` | Regex → FSM guide construction (time & memory) | `RegexGuideBenchmark`, `MemoryRegexGuideBenchmark` |
| `bench_json_schema.py` | JSON schema → regex → FSM guide construction | `JsonSchemaBenchmark` |
| `bench_cfg_guide.py` | CFG guide construction and guided decoding | `CFGGuideBenchmark` |
| `bench_processors.py` | Logits processor passthrough & structured masking | `HalvingLogitsProcessor`, `LogitsProcessorPassthroughBenchmark`, `LogitsProcessorStructuredBenchmark` |

---

## Architecture Overview

The benchmarks sit at the top of the Outlines stack and exercise the guide-construction and logits-processing layers. They deliberately disable the caching layer so that each measurement reflects the true cost of the underlying computation.

```mermaid
graph TD
    subgraph Benchmarks["task1371_benchmarks"]
        RG["RegexGuideBenchmark<br/>MemoryRegexGuideBenchmark"]
        JS["JsonSchemaBenchmark"]
        CFG["CFGGuideBenchmark"]
        LP["LogitsProcessor<br/>Passthrough/Structured Benchmarks"]
    end

    subgraph Guides["task1371_guides"]
        RegexGuide["RegexGuide"]
        CFGGuide["CFGGuide"]
        Guide["Guide (base)"]
    end

    subgraph Processors["task1371_processors"]
        OLP["OutlinesLogitsProcessor"]
        RLP["RegexLogitsProcessor"]
    end

    subgraph Models["task1371_models"]
        Tokenizer["Tokenizer"]
        TransformerTokenizer["TransformerTokenizer"]
        Transformers["Transformers"]
    end

    subgraph Support["task1371_support"]
        Cache["cache_disabled"]
    end

    RG --> RegexGuide
    JS --> RegexGuide
    CFG --> CFGGuide
    LP --> OLP
    LP --> RLP
    RLP --> RegexGuide

    RegexGuide --> Guide
    CFGGuide --> Guide
    RegexGuide --> Tokenizer
    CFGGuide --> Tokenizer
    RLP --> Tokenizer

    RG --> Cache
    JS --> Cache
    CFG --> Cache
    LP --> Transformers
    Transformers --> TransformerTokenizer
    TransformerTokenizer --> Tokenizer
```

---

## Component Relationships

The following diagram shows how the benchmark classes depend on the production components they measure.

```mermaid
graph LR
    subgraph bench_regex_guide.py
        RGB["RegexGuideBenchmark"]
        MRGB["MemoryRegexGuideBenchmark"]
    end
    subgraph bench_json_schema.py
        JSB["JsonSchemaBenchmark"]
    end
    subgraph bench_cfg_guide.py
        CFGB["CFGGuideBenchmark"]
    end
    subgraph bench_processors.py
        HLP["HalvingLogitsProcessor"]
        LPPB["LogitsProcessorPassthroughBenchmark"]
        LPSB["LogitsProcessorStructuredBenchmark"]
    end

    RGB -->|"RegexGuide.from_regex"| RegexGuide
    MRGB -->|"RegexGuide.from_regex"| RegexGuide
    JSB -->|"build_regex_from_schema + from_regex"| RegexGuide
    CFGB -->|"CFGGuide(...)"| CFGGuide

    LPPB -->|"subclass"| OLP
    HLP -->|"subclass"| OLP
    LPSB -->|"RegexLogitsProcessor"| RLP
    RLP -->|"RegexGuide.from_regex"| RegexGuide
```

---

## Benchmark Files

### `bench_regex_guide.py`

Measures the cost of compiling a regular expression into a `RegexGuide` FSM. This is the most fundamental guide-construction path, since JSON-schema and regex-based structured generation both ultimately build a `RegexGuide`.

**Components:**

- **`RegexGuideBenchmark`** — Times `RegexGuide.from_regex(pattern, tokenizer)` for a set of representative regex patterns.
- **`MemoryRegexGuideBenchmark`** — Measures peak memory of the same operation for a subset of patterns (a simple phone number and a complex span-constrained relation-extraction pattern).

**Sample patterns** (`regex_samples`) include `email`, `complex_phone`, `simple_phone`, `date`, `time`, `ip`, `url`, `ssn`, and `complex_span_constrained_relation_extraction`. These span a wide range of FSM complexity, from trivial (`ssn`) to very large (`complex_span_constrained_relation_extraction`).

Both benchmarks decorate their measurement methods with `@cache_disabled()` (from [task1371_support](task1371_support.md)) so that the FSM construction is not served from the on-disk cache, ensuring a genuine measurement of the compilation cost.

```mermaid
sequenceDiagram
    participant B as RegexGuideBenchmark
    participant T as setup_tokenizer()
    participant C as cache_disabled
    participant G as RegexGuide

    B->>T: setup_tokenizer()
    T-->>B: tokenizer
    B->>C: enter cache_disabled context
    B->>G: from_regex(pattern, tokenizer)
    G-->>B: RegexGuide instance
    B->>C: exit context (restore cache state)
```

### `bench_json_schema.py`

Measures the full JSON-schema → regex → FSM pipeline. This is the path used by JSON-structured generation.

**Component:**

- **`JsonSchemaBenchmark`** — Times `build_regex_from_schema(schema)` followed by `RegexGuide.from_regex(regex, tokenizer)`.

**Schemas** (`schemas`) include a `simple_schema` (a "Character" object with an enum `$defs` reference) and a `complex_schema` (a "recording" schema with nested `definitions`, arrays, and `$ref` references). The complex schema exercises recursive reference resolution and array handling in the schema-to-regex conversion.

The schema-to-regex conversion is delegated to `outlines_core.fsm.json_schema.build_regex_from_schema`, while the FSM construction reuses the same `RegexGuide` path as `bench_regex_guide.py`. The measurement is again wrapped in `@cache_disabled()`.

### `bench_cfg_guide.py`

Measures context-free-grammar (CFG) guide construction and guided decoding. Unlike regex guides, CFG guides use a Lark parser and are explicitly marked experimental.

**Component:**

- **`CFGGuideBenchmark`** — Benchmarks three distinct operations:
  1. `time_cfg_guide_setup` — constructing a `CFGGuide` from a grammar string.
  2. `time_cfg_guide_run_rejection_sampling` — running 40 decoding steps using rejection sampling over the vocabulary.
  3. `time_cfg_guide_run` — running 40 decoding steps using the guide's `get_next_instruction` (the "lazy" approach).
  4. `peakmem_cfg_guide_run` — peak memory of the guided run.

**Grammars** (`benched_grammars`) are `json` and `arithmetic`, sourced from `outlines.grammars`.

The benchmark uses a tiny tokenizer (`hf-internal-testing/tiny-random-gpt2`, ~1000 tokens) to keep the per-step vocabulary scan tractable. The `_run_random_cfg` helper simulates a decoding loop: it shuffles the vocabulary to emulate logits ordering, then either picks the first valid token (rejection sampling) or samples from the guide's allowed tokens.

```mermaid
flowchart TD
    Start["_run_random_cfg(guide)"] --> Init["state = guide.initial_state"]
    Init --> Loop{"40 iterations?"}
    Loop -->|yes| Shuffle["shuffle token_ids<br/>(simulate logit ordering)"]
    Shuffle --> Mode{"rejection_sampling?"}
    Mode -->|yes| Rej["next = first valid token<br/>via iter_valid_token_ids"]
    Mode -->|no| Lazy["next = random choice from<br/>get_next_instruction(state).tokens"]
    Rej --> Update["state = get_next_state(state, next)"]
    Lazy --> Update
    Update --> Loop
    Loop -->|no| Done["done"]
```

### `bench_processors.py`

Measures the runtime cost of logits processors during a single decoder pass. This file is the most cross-cutting, exercising multiple array frameworks.

**Components:**

- **`HalvingLogitsProcessor`** — A minimal `OutlinesLogitsProcessor` subclass that simply halves the logits. Used to isolate the framework-conversion overhead from any structured-generation logic.
- **`LogitsProcessorPassthroughBenchmark`** — Times the passthrough of a trivial processor, which should be on the order of microseconds. This measures the cost of the array-framework conversion performed by `OutlinesLogitsProcessor.__call__`.
- **`LogitsProcessorStructuredBenchmark`** — Times the application of a `RegexLogitsProcessor` mask for a single decoder pass, using two extreme patterns: `[^Z]*` (accepts very many tokens) and `Z*` (accepts very few tokens).

**Array frameworks** are detected dynamically:

- `LogitsProcessorPassthroughBenchmark.params` includes `torch`, `numpy`, and conditionally `mlx`, `torch_cuda`, `torch_mps`, and `jax`.
- `LogitsProcessorStructuredBenchmark.array_libraries` includes `torch`, `numpy`, and conditionally `mlx`, `torch_cuda`, `torch_mps`.

The `get_mock_processor_inputs` helper synthesizes a batch of 4 sequences with a 30,000-token vocabulary and 2,048-token context, matching realistic decoder shapes. The structured benchmark uses the real `facebook/opt-125m` tokenizer (via [task1371_models](task1371_models.md)) so that the regex mask is built against an actual vocabulary.

```mermaid
flowchart LR
    subgraph Passthrough
        A1["mock logits + input_ids"] --> A2["HalvingLogitsProcessor.__call__"]
        A2 --> A3["_to_torch → process_logits → _from_torch"]
    end
    subgraph Structured
        B1["mock logits + input_ids"] --> B2["RegexLogitsProcessor.__call__"]
        B2 --> B3["RegexGuide mask applied"]
    end
```

---

## Data Flow

The following diagram traces the data flow through the two main benchmark categories: guide construction and logits processing.

```mermaid
flowchart TD
    subgraph GuideConstruction["Guide Construction Benchmarks"]
        P1["regex pattern / JSON schema / CFG grammar"] --> P2["RegexGuide.from_regex<br/>or CFGGuide(...)"]
        P2 --> P3["Tokenizer vocabulary"]
        P3 --> P4["FSM states mapping"]
        P4 --> P5["Guide instance"]
    end

    subgraph LogitsProcessing["Logits Processing Benchmarks"]
        L1["mock logits (4, 30000)"] --> L2["OutlinesLogitsProcessor.__call__"]
        L3["mock input_ids (4, 2048)"] --> L2
        L2 --> L4["_to_torch normalization"]
        L4 --> L5["process_logits (business logic)"]
        L5 --> L6["_from_torch back to source framework"]
    end
```

---

## Dependencies

The benchmarks depend on the following Outlines modules. Refer to their dedicated documentation for details rather than duplicating information here.

| Dependency | Used By | Purpose |
|------------|---------|---------|
| [task1371_guides](task1371_guides.md) — `RegexGuide`, `CFGGuide`, `Guide` | regex, json, cfg benchmarks | FSM guide construction and guided decoding |
| [task1371_processors](task1371_processors.md) — `OutlinesLogitsProcessor`, `RegexLogitsProcessor` | processors benchmark | Logits masking and framework normalization |
| [task1371_models](task1371_models.md) — `Tokenizer`, `TransformerTokenizer`, `Transformers` | all benchmarks | Tokenizer setup and model loading |
| [task1371_support](task1371_support.md) — `cache_disabled` | regex, json, cfg benchmarks | Disable caching to measure true cost |
| `outlines_core.fsm.json_schema.build_regex_from_schema` | json benchmark | JSON schema → regex conversion |
| `outlines.grammars` | cfg benchmark | Prebuilt JSON and arithmetic grammars |

### External Dependencies

- **`pytest-benchmark`** — Provides the `params`, `setup`, and `time_*` / `peakmem_*` conventions.
- **`torch`** — Core tensor library used by processors and guides.
- **`numpy`** — Array framework exercised by the processors benchmark.
- **`mlx.core`** (optional) — Apple MLX array framework, benchmarked when available.
- **`jax`** (optional) — JAX array framework, benchmarked when available.
- **`transformers`** — Provides `AutoTokenizer` and the `facebook/opt-125m` tokenizer.

---

## Running the Benchmarks

The benchmarks follow the pytest-benchmark convention and can be run with:

```bash
pytest benchmarks/bench_regex_guide.py --benchmark-only
pytest benchmarks/bench_json_schema.py --benchmark-only
pytest benchmarks/bench_cfg_guide.py --benchmark-only
pytest benchmarks/bench_processors.py --benchmark-only
```

Each benchmark class parameterizes over its `params` attribute, so a single invocation runs all patterns, schemas, grammars, or array frameworks. Optional frameworks (MLX, JAX, CUDA, MPS) are only included when the corresponding runtime is detected as available.

---

## Design Notes

- **Cache disabling is essential.** Guide construction is cached on disk by default (see [task1371_support](task1371_support.md)). Every guide-construction benchmark wraps its measurement in `@cache_disabled()` so that repeated runs measure the actual compilation cost rather than a cache hit.
- **Tiny tokenizers for CFG.** CFG guide construction and decoding scan the entire vocabulary per step, so the CFG benchmark uses a ~1000-token tokenizer to keep the benchmark fast while still exercising the parser.
- **Realistic shapes for processors.** The processors benchmark uses a 30,000-token vocabulary and 2,048-token context to reflect production decoder shapes, and uses a real tokenizer for the structured benchmark so the regex mask is built against an actual vocabulary.
- **Framework-agnostic measurement.** The processors benchmark dynamically detects and includes MLX, JAX, CUDA, and MPS backends, ensuring the array-conversion overhead is measured across all supported frameworks.
