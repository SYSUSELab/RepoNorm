# task1371_guides

## Introduction

The `task1371_guides` module implements the **generation guides** that power Outlines' structured text generation. A *guide* is a finite-state machine (FSM) that constrains a language model's token-by-token generation so that the resulting text conforms to a target structure — a regular expression, a context-free grammar (CFG), or simply "stop at the EOS token".

The module is composed of three files:

| File | Responsibility |
| --- | --- |
| `outlines/fsm/guide.py` | Defines the `Guide` abstraction and its concrete implementations (`RegexGuide`, `CFGGuide`, `StopAtEOSGuide`). |
| `outlines/fsm/parsing.py` | Provides the *partial* Lark parser/lexer machinery that lets a CFG be parsed incrementally, one token at a time. |
| `outlines/fsm/types.py` | Maps Python types to regex patterns and formatting functions (`FormatFunction`). |

Guides are consumed by the [task1371_processors](task1371_processors.md) module (which turns a guide into a logits processor) and driven by the [task1371_generation](task1371_generation.md) module (which runs the generation loop). They rely on tokenizers from [task1371_models](task1371_models.md).

---

## Architecture Overview

The module sits between the *generation loop* (above) and the *tokenizer/model* layer (below). A guide answers two questions at every generation step:

1. **What tokens are allowed next?** (`get_next_instruction`)
2. **Given the token that was actually produced, what is the new state?** (`get_next_state`)

```mermaid
graph TD
    subgraph "task1371_generation"
        SG[SequenceGenerator]
    end

    subgraph "task1371_processors"
        GLP[GuideLogitsProcessor]
        RLP[RegexLogitsProcessor]
        CLP[CFGLogitsProcessor]
    end

    subgraph "task1371_guides"
        G[Guide]
        RG[RegexGuide]
        CG[CFGGuide]
        SE[StopAtEOSGuide]
        PL[PartialLark / PartialParser]
        T[FormatFunction]
    end

    subgraph "task1371_models"
        TOK[Tokenizer]
    end

    SG --> GLP
    GLP --> G
    RLP --> RG
    CLP --> CG
    G --> RG
    G --> CG
    G --> SE
    CG --> PL
    RG --> TOK
    CG --> TOK
    SE --> TOK
    T -.-> RG
```

---

## Core Concepts

### The `Guide` abstraction

`Guide` (in `outlines/fsm/guide.py`) extends `outlines_core.fsm.guide.Guide`. It defines the contract that every guide must satisfy:

- `initial_state` — the starting FSM state.
- `get_next_instruction(state) -> Instruction` — returns either a `Generate` (the model must sample from a set of allowed token ids) or a `Write` (a fixed sequence of tokens can be appended without sampling).
- `get_next_state(state, token_id) -> state` — advances the FSM given the token that was generated.
- `is_final_state(state) -> bool` — whether generation may stop.
- `copy()` — returns an independent copy (used to fan out across batch/sample dimensions).

`Instruction` is a union of `Write` and `Generate` (both imported from `outlines_core`).

```mermaid
classDiagram
    class Guide {
        +initial_state
        +get_next_instruction(state)
        +get_next_state(state, token_id)
        +is_final_state(state)
        +copy()
    }
    class StopAtEOSGuide {
        +final_state = 1
        +start_state = 0
        +eos_token_id
        +vocabulary
    }
    class RegexGuide {
        +from_regex(regex_string, tokenizer)
    }
    class CFGGuide {
        +cfg_string
        +parser
        +iter_valid_token_ids(state, ids)
        +can_terminate_state(state)
        +must_terminate_state(state)
    }
    Guide <|-- StopAtEOSGuide
    Guide <|-- RegexGuide
    Guide <|-- CFGGuide
```

### `StopAtEOSGuide`

The simplest guide. It has two states:

- `start_state = 0` / `initial_state = 0` — generation continues, `Generate(None)` allows any token.
- `final_state = 1` — once the EOS token is produced (or the final state is reached), it emits `Write([eos_token_id])`.

It is constructed from a `Tokenizer` and reads `eos_token_id` and `vocabulary`. `copy()` returns `self` because the guide is stateless.

### `RegexGuide`

A thin wrapper around `outlines_core.fsm.guide.RegexGuide`. Its only addition is `from_regex`, which injects a `cached_create_states_mapping` function so that the (expensive) FSM state mapping for a regex/tokenizer pair is cached. This is the guide used by `RegexLogitsProcessor`.

### `CFGGuide`

The most complex guide. It generates text that belongs to the language of a context-free Lark grammar.

- **Construction**: builds a `PartialLark` parser (LALR) with the grammar and an empty initial state `CFGState(parser_state=parser.parse(""), prev_token=None)`.
- **State**: a `CFGState` namedtuple of `(parser_state, prev_token)`. `parser_state` is `None` when generation is complete.
- **`get_next_instruction`**: iterates over the whole vocabulary, tentatively applying each token to a copy of the parser state, and returns a `Generate` with the valid token ids (or a `Write` if exactly one token is valid).
- **`iter_valid_token_ids`**: the core validity check. For each candidate token it tries `_get_parser_state_token_applied` and swallows `ValueError`, `EOFError`, `UnexpectedToken`, `UnexpectedCharacters`, and `DedentError` for invalid tokens. The EOS token is only yielded if `can_terminate_state` holds.
- **`_get_parser_state_token_applied`**: copies the parser state (to avoid side effects), decodes the new token string (handling leading-whitespace normalization via `prev_token`), rejects empty tokens, and feeds the text into the parser.
- **`can_terminate_state` / `must_terminate_state`**: determine whether generation *may* or *must* stop.

> ⚠️ **Disclaimer**: Outlines' public, community-contributed CFG structured generation is **experimental**. See the upstream disclaimer referenced in the source.

---

## The Partial Parsing Machinery (`parsing.py`)

Standard Lark parsers consume a complete input string. Structured generation, however, produces text incrementally and must be able to ask "is this prefix still valid?" and "what terminals could come next?". The `parsing.py` file provides a set of `Partial*` subclasses of Lark internals that support this incremental, prefix-aware parsing.

```mermaid
graph TD
    PL[PartialLark] --> PPF[PartialParsingFrontend]
    PPF --> PLP[PartialLALRParser]
    PPF --> PCL[PartialContextualLexer]
    PPF --> PLT[PartialLexerThread]
    PLP --> PP[PartialParser]
    PP --> PPS[PartialParserState]
    PCL --> PBL[PartialBasicLexer]
    PBL --> PS[PartialScanner]
    PS --> FSMU[fsm_union / walk_fsm]
    PPF --> PL2[PartialPostLexConnector]
    PL2 --> PI[PartialIndenter]
    PI --> PPI[PartialPythonIndenter]
```

### Key components

| Component | Role |
| --- | --- |
| `PartialLark` | Entry point. Builds a `PartialParsingFrontend` and exposes `parse_from_state`. Forces `regex=True` and asserts LALR. |
| `PartialParsingFrontend` | Wires up the partial lexer/parser plugins. Lazily computes `termset_fsm_info`, `symbols_to_states`, and `reverse_shifts` maps. |
| `PartialLALRParser` | LALR parser that can optionally build a *deterministic* parse table (`deterministic=True`) and an `IntParseTable`. |
| `PartialParser` / `PartialParserState` | The parser and its state. `PartialParserState.feed_token` handles `partial` tokens and can skip value-stack tracking (`use_value_stack=False`) for performance. |
| `PartialScanner` | Builds a union FSM over all terminal regexes and reports which terminals could match a given FSM state sequence. |
| `PartialBasicLexer` / `PartialContextualLexer` | Lexers that emit `partial` tokens when a match is not yet complete. |
| `PartialIndenter` / `PartialPythonIndenter` | Indentation handling that does **not** reset state between `process` calls (needed for incremental parsing). |

### FSM utilities

- `fsm_union(fsms)` — builds the union FSM of several terminal FSMs and returns a map from each component FSM to its transitions, finals, and state mapping.
- `get_sub_fsms_from_seq(state_seq, fsms_to_trans_finals)` — yields, for each sub-FSM, whether it can continue and whether it is in a final state.
- `walk_fsm(fsm, token_transition_keys, start_state, full_match)` — walks an FSM over a sequence of transition keys, returning the accepted state sequence.
- `terminals_to_fsms(lp)` — maps terminal names to their FSMs.

### Partial parsing data flow

```mermaid
sequenceDiagram
    participant CG as CFGGuide
    participant PPS as PartialParserState
    participant PBL as PartialBasicLexer
    participant PS as PartialScanner

    CG->>PPS: copy state
    CG->>PPS: feed new token text
    PPS->>PBL: lex(state)
    PBL->>PS: match(text, pos, last_fsm_state_seq)
    PS-->>PBL: fsm_state_seq
    PBL-->>PPS: Token (partial or complete)
    PPS->>PPS: feed_token / feed_token_no_stack
    PPS-->>CG: updated PartialParserState
```

---

## Type-to-Regex Mapping (`types.py`)

`types.py` provides `FormatFunction` (a `Protocol` for callables that convert a generated string into a Python value) and `python_types_to_regex`, which maps a Python type to a `(regex_string, format_function)` pair. This is used when building regex guides from typed schemas (e.g. JSON schema generation).

Supported types and their patterns:

| Python type | Regex constant | Format function |
| --- | --- | --- |
| `float` | `FLOAT` | `float(sequence)` |
| `int` | `INTEGER` | `int(sequence)` |
| `bool` | `BOOLEAN` | `bool(sequence)` |
| `datetime.date` | `DATE` | `strptime(..., "%Y-%m-%d").date()` |
| `datetime.time` | `TIME` | `strptime(..., "%H:%M:%S").time()` |
| `datetime.datetime` | `DATETIME` | `strptime(..., "%Y-%m-%d %H:%M:%S")` |
| `Enum` subclass | alternation of member names | `str(sequence)` |
| `Annotated[T, ...]` | `json_schema["pattern"]` | `T(sequence)` |

```mermaid
flowchart LR
    A[Python type] --> B{Annotated?}
    B -- yes --> C[use json_schema pattern]
    B -- no --> D{Enum?}
    D -- yes --> E[alternation of members]
    D -- no --> F{builtin / datetime?}
    F -- yes --> G[INTEGER/FLOAT/BOOLEAN/DATE/TIME/DATETIME]
    F -- no --> H[NotImplementedError]
    C --> I[(regex, format_fn)]
    E --> I
    G --> I
```

---

## How Guides Integrate with the Rest of the System

### With processors (`task1371_processors`)

`GuideLogitsProcessor` holds a `Guide` and, at each step, calls `guide.get_next_state` to track the FSM state per sequence and `guide.get_next_instruction` to obtain the allowed tokens, then masks the logits with `-inf` for disallowed tokens. `RegexLogitsProcessor` and `CFGLogitsProcessor` are thin subclasses that construct the appropriate guide. `CFGLogitsProcessor` overrides `process_logits` to use **rejection sampling** via `guide.iter_valid_token_ids`.

### With generation (`task1371_generation`)

`SequenceGenerator` copies the FSM (`self.fsm.copy()`) for each batch/sample, initializes `fsm_states`, and drives the generation loop. The guide's `copy()` method is therefore essential for correct multi-sample generation.

### With models (`task1371_models`)

All guides depend on a `Tokenizer` (from `task1371_models`) for `eos_token_id`, `vocabulary`, and `decode`. The `CFGGuide` in particular relies on `tokenizer.decode` to reconstruct token strings for the parser.

---

## Component Interaction Summary

```mermaid
graph LR
    subgraph Guides
        SE[StopAtEOSGuide]
        RG[RegexGuide]
        CG[CFGGuide]
    end
    subgraph Parsing
        PL[PartialLark]
        PPS[PartialParserState]
    end
    subgraph Types
        FF[FormatFunction]
    end
    subgraph External
        CORE[outlines_core.fsm.guide]
        TOK[Tokenizer]
    end

    RG --> CORE
    SE --> TOK
    CG --> PL
    PL --> PPS
    RG --> TOK
    FF -.-> RG
```

---

## References

- [task1371_generation](task1371_generation.md) — the generation loop that drives guides.
- [task1371_processors](task1371_processors.md) — logits processors that consume guides.
- [task1371_samplers](task1371_samplers.md) — sampling strategies used alongside guides.
- [task1371_models](task1371_models.md) — tokenizers and models that guides depend on.
- [task1371_support](task1371_support.md) — shared utilities (`vectorize`, `Prompt`, `Function`, caching).
- [task1371_benchmarks](task1371_benchmarks.md) — benchmarks for regex/CFG guides and processors.
