# Applications Module

## Introduction

The `applications` module provides the `Application` class, a high-level abstraction that encapsulates a **prompt template** and an **output type** into a single, reusable object. It serves as the primary user-facing entry point for building structured generation workflows in Outlines, allowing developers to define a prompt once and reuse it across multiple models and invocations.

The module bridges three core subsystems:

- **Templates** ([templates.md](templates.md)) — for rendering prompts from Jinja templates.
- **Generators** ([generator.md](generator.md)) — for orchestrating constrained generation.
- **Models** ([models.md](models.md)) — for the underlying inference backend.

By combining these, an `Application` lets you write code such as:

```python
application = Application(template, JsonType(OutputModel))
result = application(model, {"num": 3}, max_new_tokens=20)
```

---

## Core Component: `Application`

The `Application` class is the sole public component of this module. It is defined in `outlines/applications.py`.

### Responsibilities

| Responsibility | Description |
|----------------|-------------|
| **Template storage** | Holds a `Template` (or any callable) that produces a prompt string. |
| **Output type storage** | Holds the desired output type (e.g., a JSON schema, regex, or Python type). |
| **Generator caching** | Lazily creates and caches a `Generator` bound to a specific model. |
| **Invocation** | Renders the prompt and delegates generation to the cached generator. |

### Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `template` | `Union[Template, Callable]` | The prompt template used to build the prompt. |
| `output_type` | `Optional[Any]` | The output type passed to the generator. |
| `generator` | `Optional[Union[BlackBoxGenerator, SteerableGenerator]]` | Cached generator instance (created lazily). |
| `model` | `Optional[Model]` | The model the cached generator is bound to. |

### Methods

#### `__init__(template, output_type=None)`

Initializes the application with a template and an optional output type. The generator and model are set to `None` and populated lazily on first invocation.

#### `__call__(model, template_vars, **inference_kwargs)`

The main entry point. It performs the following steps:

1. Validates that a `model` was provided (raises `ValueError` otherwise).
2. Checks whether the model has changed since the last call. If so, it rebuilds and caches a new `Generator`.
3. Renders the prompt by calling `self.template(**template_vars)`.
4. Invokes the generator with the rendered prompt and any inference keyword arguments.

Returns the generated response.

---

## Architecture

The `Application` class sits at the top of the Outlines stack, orchestrating templates, generators, and models.

```mermaid
graph TD
    User["User Code"] -->|"application(model, vars, **kwargs)"| App["Application"]
    App -->|"renders prompt"| Template["Template<br/>(templates.py)"]
    App -->|"lazily creates"| Generator["Generator<br/>(generator.py)"]
    Generator -->|"BlackBoxGenerator"| BB["BlackBoxGenerator"]
    Generator -->|"SteerableGenerator"| SG["SteerableGenerator"]
    BB -->|"generate(prompt, output_type)"| Model["Model<br/>(models/base.py)"]
    SG -->|"generate(prompt, logits_processor)"| Model
    Model -->|"inference"| Backend["Inference Backend<br/>(Transformers, vLLM, OpenAI, ...)"]
```

---

## Component Interaction

The following sequence diagram illustrates the lifecycle of a single `Application` call, including the lazy generator creation and caching behavior.

```mermaid
sequenceDiagram
    participant U as User
    participant A as Application
    participant T as Template
    participant G as Generator
    participant M as Model

    U->>A: __call__(model, template_vars, **kwargs)
    A->>A: validate model is not None
    alt model changed or generator is None
        A->>G: Generator(model, output_type)
        G->>M: inspect tokenizer / tensor_library_name
        G-->>A: generator instance (cached)
    end
    A->>T: template(**template_vars)
    T-->>A: rendered prompt string
    A->>G: generator(prompt, **kwargs)
    G->>M: model.generate(prompt, output_type/processor, **kwargs)
    M-->>G: generated response
    G-->>A: response
    A-->>U: response
```

---

## Data Flow

The data flow through an `Application` transforms template variables into a structured model response.

```mermaid
flowchart LR
    Vars["template_vars<br/>{'num': 3}"] --> Template["Template.render()"]
    Template --> Prompt["Prompt String<br/>'What is 2 times 3?'"]
    OutputType["output_type<br/>JsonType(OutputModel)"] --> Generator["Generator"]
    Prompt --> Generator
    Generator --> Model["Model.generate()"]
    Model --> Response["Structured Response<br/>{'result': 6}"]
```

---

## Generator Selection Logic

The type of generator created depends on the model and output type. This logic is delegated to the `Generator` factory (see [generator.md](generator.md)).

```mermaid
flowchart TD
    Start["Generator(model, output_type)"] --> Check{"Model type?"}
    Check -->|"Black-box / API model"| BB["BlackBoxGenerator<br/>output_type passed directly"]
    Check -->|"Steerable / local model"| SG["SteerableGenerator<br/>output_type compiled to logits processor"]
    BB --> BBGen["model.generate(prompt, output_type)"]
    SG --> SGGen["model.generate(prompt, logits_processor)"]
```

- **`BlackBoxGenerator`** is used for API-based models where constrained generation is not controlled locally. The `output_type` is passed directly to the model. Note that `FSM` output types are not supported for these models.
- **`SteerableGenerator`** is used for local models where Outlines controls constrained generation. The `output_type` is compiled into a logits processor (e.g., `CFGLogitsProcessor`, `GuideLogitsProcessor`, `RegexLogitsProcessor`).

---

## Caching Behavior

A key design decision of `Application` is **generator caching**. Building a generator (and its associated logits processor) can be expensive, so the application caches the generator and only rebuilds it when the model changes.

```mermaid
stateDiagram-v2
    [*] --> NoGenerator: __init__
    NoGenerator --> GeneratorCreated: first call / model changed
    GeneratorCreated --> GeneratorCreated: subsequent calls (same model)
    GeneratorCreated --> GeneratorCreated: model changed (rebuild)
```

This means:

- Repeated calls with the **same model** reuse the cached generator — fast.
- Calls with a **different model** trigger a rebuild — correct.

---

## Usage Example

```python
from pydantic import BaseModel
from transformers import AutoModelForCausalLM, AutoTokenizer
from outlines import models, Application
from outlines.types import JsonType
from outlines.templates import Template

class OutputModel(BaseModel):
    result: int

model = models.from_transformers(
    AutoModelForCausalLM.from_pretrained("microsoft/Phi-3-mini-4k-instruct"),
    AutoTokenizer.from_pretrained("microsoft/Phi-3-mini-4k-instruct")
)

template_string = "What is 2 times {{ num }}?"
template = Template.from_string(template_string)

application = Application(template, JsonType(OutputModel))

result = application(model, {"num": 3}, max_new_tokens=20)
print(result)  # Expected output: { "result" : 6 }
```

---

## Dependencies

The `Application` class depends on the following modules:

| Dependency | Purpose | Documentation |
|------------|---------|---------------|
| `outlines.templates.Template` | Renders the prompt from a Jinja template. | [templates.md](templates.md) |
| `outlines.generator` | Provides `BlackBoxGenerator` and `SteerableGenerator`. | [generator.md](generator.md) |
| `outlines.models.base.Model` | The base model interface used for inference. | [models.md](models.md) |
| `outlines.types` | Defines output types (e.g., `JsonType`, `Regex`, `CFG`). | [types_dsl.md](types_dsl.md) |
| `outlines.processors` | Logits processors used by steerable generators. | [processors.md](processors.md) |

```mermaid
graph LR
    App["Application"] --> Templates["templates.py"]
    App --> Generator["generator.py"]
    App --> Models["models/base.py"]
    Generator --> Types["types/dsl.py"]
    Generator --> Processors["processors/*"]
    Models --> Backends["models/*"]
```

---

## Relationship to Other Modules

- **Templates** ([templates.md](templates.md)): `Application` accepts a `Template` (or any callable) and calls it with the provided variables to produce the prompt.
- **Generators** ([generator.md](generator.md)): `Application` uses the `Generator` factory to create either a `BlackBoxGenerator` or `SteerableGenerator`, depending on the model.
- **Models** ([models.md](models.md)): The `model` argument passed to `Application.__call__` is any `Model` subclass. The application caches the generator per model.
- **Types DSL** ([types_dsl.md](types_dsl.md)): The `output_type` is typically a type from the `outlines.types` module (e.g., `JsonType`, `Regex`, `CFG`).
- **Processors** ([processors.md](processors.md)): For steerable models, the output type is compiled into a logits processor by the generator.

---

## Summary

The `applications` module provides a thin but powerful abstraction — `Application` — that:

1. **Encapsulates** a prompt template and an output type into a reusable object.
2. **Orchestrates** the rendering of prompts and the invocation of generators.
3. **Caches** generators per model to avoid expensive rebuilds.
4. **Delegates** the heavy lifting of constrained generation to the `generator`, `models`, and `processors` modules.

It is the recommended high-level API for developers who want to define structured generation workflows declaratively and reuse them across models.
