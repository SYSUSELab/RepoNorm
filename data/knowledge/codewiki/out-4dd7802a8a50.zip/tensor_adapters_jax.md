# Tensor Adapters - JAX

## Introduction

The `tensor_adapters_jax` module provides the JAX-specific implementation of the tensor adapter abstraction used throughout Outlines' structured generation pipeline. It exposes a single concrete class, `JAXTensorAdapter`, which translates the library-agnostic tensor operations defined by the [`TensorAdapter`](tensor_adapters_base.md) interface into their JAX equivalents.

This adapter allows Outlines' logits processors (such as [`GuideLogitsProcessor`](processors_structured.md) and [`RegexLogitsProcessor`](processors_structured.md)) to operate on JAX arrays without any awareness of the underlying tensor library. By conforming to the common interface, JAX support is added to the framework without modifying any processor logic.

## Purpose and Core Functionality

The module's sole responsibility is to bridge the gap between Outlines' generic tensor manipulation API and the JAX library. It implements every abstract method declared by `TensorAdapter`, mapping each operation to the corresponding `jax.numpy` function or JAX array method.

Key responsibilities:

- **Shape introspection** — reporting the dimensions of a JAX array.
- **Dimension manipulation** — adding/removing a leading axis (`unsqueeze`/`squeeze`).
- **Conversion** — converting arrays to Python lists or scalars.
- **Construction** — creating arrays filled with a value or boolean ones.
- **Combination** — concatenating multiple arrays along axis 0.
- **Masking** — applying boolean masks to fill values.
- **Sorting** — producing descending-order indices for token selection.

## Architecture

The `JAXTensorAdapter` is one of several sibling implementations of the abstract [`TensorAdapter`](tensor_adapters_base.md) base class. Each adapter targets a distinct tensor library while presenting an identical interface.

```mermaid
classDiagram
    class TensorAdapter {
        <<abstract>>
        +str library_name
        +shape(tensor) list[int]
        +unsqueeze(tensor) TensorType
        +squeeze(tensor) TensorType
        +to_list(tensor) list
        +to_scalar(tensor) Any
        +full_like(tensor, fill_value) TensorType
        +concatenate(tensors) TensorType
        +get_device(tensor) str
        +to_device(tensor, device) TensorType
        +boolean_ones_like(tensor) TensorType
        +apply_mask(tensor, mask, value) TensorType
        +argsort_descending(tensor) TensorType
    }

    class JAXTensorAdapter {
        +str library_name = "jax"
        +__init__()
        +shape(tensor)
        +unsqueeze(tensor)
        +squeeze(tensor)
        +to_list(tensor)
        +to_scalar(tensor)
        +full_like(tensor, fill_value)
        +concatenate(tensors)
        +to_device(tensor, device)
        +get_device(tensor)
        +boolean_ones_like(tensor)
        +apply_mask(tensor, mask, value)
        +argsort_descending(tensor)
    }

    class TorchTensorAdapter
    class NumpyTensorAdapter
    class MLXTensorAdapter
    class TensorFlowTensorAdapter

    TensorAdapter <|-- JAXTensorAdapter
    TensorAdapter <|-- TorchTensorAdapter
    TensorAdapter <|-- NumpyTensorAdapter
    TensorAdapter <|-- MLXTensorAdapter
    TensorAdapter <|-- TensorFlowTensorAdapter
```

## Component Reference

### `JAXTensorAdapter`

The concrete adapter for the JAX library. It declares `library_name = "jax"` and lazily imports `jax` inside its constructor, keeping the dependency optional until an instance is actually created.

#### Constructor

```python
def __init__(self):
    import jax
    self.jax = jax
```

The `jax` module is imported lazily and stored on the instance as `self.jax`, so that importing the adapter module does not require JAX to be installed.

#### Method Mapping

The table below summarizes how each interface method is implemented in terms of JAX operations.

| Method | JAX Implementation | Notes |
| --- | --- | --- |
| `shape(tensor)` | `tensor.shape` | Returns the array's shape tuple. |
| `unsqueeze(tensor)` | `jax.numpy.expand_dims(tensor, axis=0)` | Adds a leading dimension. |
| `squeeze(tensor)` | `jax.numpy.squeeze(tensor, axis=0)` | Removes the leading dimension. |
| `to_list(tensor)` | `tensor.tolist()` | Converts to a nested Python list. |
| `to_scalar(tensor)` | `tensor.item()` | Extracts the single element. |
| `full_like(tensor, fill_value)` | `jax.numpy.full_like(tensor, fill_value)` | Creates an array of the same shape filled with `fill_value`. |
| `concatenate(tensors)` | `jax.numpy.concatenate(tensors, axis=0)` | Joins arrays along axis 0. |
| `to_device(tensor, device)` | `tensor` | No-op; JAX manages device placement via its own mechanisms. |
| `get_device(tensor)` | `None` | JAX arrays do not expose a device name in the same way as other libraries. |
| `boolean_ones_like(tensor)` | `jax.numpy.ones_like(tensor, dtype=bool)` | Boolean mask of ones. |
| `apply_mask(tensor, mask, value)` | `tensor.copy()` then `result.at[mask].set(value)` | Uses JAX's functional `.at[].set()` update syntax. |
| `argsort_descending(tensor)` | `jax.numpy.argsort(-tensor)` | Negates the array to obtain descending order. |

#### Notable Implementation Details

- **Functional masking**: Unlike the in-place mutation used by the [NumPy adapter](tensor_adapters_numpy.md), `apply_mask` uses JAX's immutable update pattern (`result.at[mask].set(value)`), which is required because JAX arrays are immutable.
- **Device handling**: `to_device` is a no-op and `get_device` returns `None`. JAX abstracts device placement through its own array/device model, so the adapter does not attempt to move arrays explicitly.
- **Descending sort**: JAX's `argsort` has no `descending` parameter, so the adapter negates the input (`-tensor`) before sorting, mirroring the approach used by the [NumPy adapter](tensor_adapters_numpy.md).

## Data Flow

The adapter sits between the structured-generation processors and the JAX runtime. Processors call generic tensor operations, which the adapter dispatches to JAX.

```mermaid
flowchart LR
    A[Logits Processor] -->|generic tensor ops| B[JAXTensorAdapter]
    B -->|jax.numpy calls| C[JAX Runtime]
    C -->|JAX arrays| B
    B -->|adapted results| A
```

## Integration with the Broader System

The `JAXTensorAdapter` is registered and selected alongside the other adapters so that Outlines can transparently support JAX-backed models. It is consumed by the logits processors defined in the [`processors_structured`](processors_structured.md) module and conforms to the contract established by the [`tensor_adapters_base`](tensor_adapters_base.md) module.

```mermaid
flowchart TD
    Base["TensorAdapter (base)"] --> JAX["JAXTensorAdapter"]
    Base --> Torch["TorchTensorAdapter"]
    Base --> Numpy["NumpyTensorAdapter"]
    Base --> MLX["MLXTensorAdapter"]
    Base --> TF["TensorFlowTensorAdapter"]

    JAX --> Processors["Structured Logits Processors"]
    Processors --> Guides["Guides (Regex / CFG / JSON)"]
```

## Related Modules

- [`tensor_adapters_base`](tensor_adapters_base.md) — Defines the abstract `TensorAdapter` interface implemented here.
- [`tensor_adapters_torch`](tensor_adapters_torch.md) — PyTorch implementation of the same interface.
- [`tensor_adapters_numpy`](tensor_adapters_numpy.md) — NumPy implementation, sharing the negation-based descending sort strategy.
- [`tensor_adapters_mlx`](tensor_adapters_mlx.md) — MLX implementation.
- [`tensor_adapters_tensorflow`](tensor_adapters_tensorflow.md) — TensorFlow implementation.
- [`processors_structured`](processors_structured.md) — Logits processors that consume tensor adapters.
- [`processors_guides`](processors_guides.md) — Guides that drive the masking and sorting operations.
