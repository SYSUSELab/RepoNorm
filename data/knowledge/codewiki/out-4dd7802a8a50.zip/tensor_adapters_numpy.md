# Tensor Adapters - NumPy

## Introduction

The `tensor_adapters_numpy` module provides the NumPy implementation of the tensor adapter abstraction used throughout Outlines' logits processing pipeline. It exposes a single concrete class, `NumpyTensorAdapter`, which adapts NumPy arrays to the common `TensorAdapter` interface so that structured-generation logits processors can operate on NumPy-backed tensors without being coupled to a specific tensor library.

This module is one of several sibling adapters (Torch, JAX, MLX, TensorFlow) that together form the [tensor_adapters](tensor_adapters.md) subsystem. For the shared contract that all adapters must satisfy, see the [tensor_adapters_base](tensor_adapters_base.md) documentation.

---

## Purpose and Core Functionality

`NumpyTensorAdapter` implements the full `TensorAdapter` abstract interface using the `numpy` library. Its responsibilities are:

- **Shape introspection** — report the dimensions of a tensor.
- **Dimension manipulation** — add or remove a leading axis (`unsqueeze` / `squeeze`).
- **Conversion** — convert tensors to Python lists or scalars.
- **Allocation** — create tensors filled with a constant value or boolean ones.
- **Combination** — concatenate multiple tensors along axis 0.
- **Device handling** — provide no-op device semantics (NumPy arrays are CPU-only).
- **Masking and ordering** — apply boolean masks and produce descending sort indices.

Because NumPy arrays are always CPU-resident, the device-related methods (`get_device`, `to_device`) are intentionally trivial: `get_device` returns `None` and `to_device` returns the tensor unchanged.

---

## Architecture

The adapter sits between the generic logits-processing logic and the concrete NumPy library. The `TensorAdapter` base class defines the interface; `NumpyTensorAdapter` is one of its concrete implementations.

```mermaid
classDiagram
    class TensorAdapter {
        <<abstract>>
        +str library_name
        +shape(tensor) list[int]
        +unsqueeze(tensor) TensorType
        +squeeze(tensor) TensorType
        +to_list(tensor) list
        +to_scalar(tensor) Any
        +full_like(tensor, fill_value) TensorType
        +concatenate(tensors) TensorType
        +get_device(tensor) str
        +to_device(tensor, device) TensorType
        +boolean_ones_like(tensor) TensorType
        +apply_mask(tensor, mask, value) TensorType
        +argsort_descending(tensor) TensorType
    }

    class NumpyTensorAdapter {
        +str library_name = "numpy"
        +numpy
        +__init__()
        +shape(tensor)
        +unsqueeze(tensor)
        +squeeze(tensor)
        +to_list(tensor)
        +to_scalar(tensor)
        +full_like(tensor, fill_value)
        +concatenate(tensors)
        +get_device(tensor)
        +to_device(tensor, device)
        +boolean_ones_like(tensor)
        +apply_mask(tensor, mask, value)
        +argsort_descending(tensor)
    }

    TensorAdapter <|-- NumpyTensorAdapter
```

---

## Component Reference

### `NumpyTensorAdapter`

The sole class in this module. It subclasses `TensorAdapter` and declares `library_name = "numpy"`, which is used by the adapter registry to select this implementation for NumPy tensors.

#### Constructor

```python
def __init__(self):
    import numpy
    self.numpy = numpy
```

The `numpy` import is performed lazily inside the constructor and stored on the instance as `self.numpy`. This keeps NumPy an optional dependency — the module can be imported even when NumPy is not installed, and the import only fails if an adapter instance is actually created.

#### Method Mapping

The table below maps each interface method to its NumPy implementation and notes any behavioral specifics.

| Method | NumPy Implementation | Notes |
| --- | --- | --- |
| `shape(tensor)` | `tensor.shape` | Returns the array's shape tuple. |
| `unsqueeze(tensor)` | `numpy.expand_dims(tensor, axis=0)` | Adds a leading axis. |
| `squeeze(tensor)` | `numpy.squeeze(tensor, axis=0)` | Removes the leading axis. |
| `to_list(tensor)` | `tensor.tolist()` | Converts to nested Python lists. |
| `to_scalar(tensor)` | `tensor.item()` | Extracts the single element. |
| `full_like(tensor, fill_value)` | `numpy.full_like(tensor, fill_value)` | Allocates a same-shaped array filled with `fill_value`. |
| `concatenate(tensors)` | `numpy.concatenate(tensors, axis=0)` | Joins along axis 0. |
| `get_device(tensor)` | `None` | NumPy arrays have no device. |
| `to_device(tensor, device)` | `tensor` | No-op; returns the tensor unchanged. |
| `boolean_ones_like(tensor)` | `numpy.ones_like(tensor, dtype=bool)` | Boolean mask of ones. |
| `apply_mask(tensor, mask, value)` | copy + `result[mask] = value` | Copies the tensor, then assigns `value` where `mask` is `True`. |
| `argsort_descending(tensor)` | `numpy.argsort(-tensor)` | Negates the tensor to obtain descending order indices. |

#### Implementation Notes

- **`apply_mask` copies first.** Unlike the Torch adapter (which uses `masked_fill`), the NumPy implementation explicitly copies the input via `tensor.copy()` before mutating it with boolean indexing. This preserves the immutability expectations of the interface.
- **`argsort_descending` uses negation.** Rather than a dedicated descending-sort flag, it negates the tensor and calls `numpy.argsort`, which yields indices that sort the original tensor in descending order along the last axis.
- **Device methods are no-ops.** Since NumPy has no concept of devices, `get_device` returns `None` and `to_device` is an identity function.

---

## Data Flow

The adapter is invoked by logits processors to manipulate logits arrays during constrained decoding. The typical flow is:

```mermaid
flowchart LR
    A[Logits Processor] -->|calls interface methods| B[NumpyTensorAdapter]
    B -->|delegates to| C[numpy library]
    C -->|returns arrays| B
    B -->|returns adapted results| A
```

A representative masking workflow:

```mermaid
sequenceDiagram
    participant LP as Logits Processor
    participant NA as NumpyTensorAdapter
    participant NP as numpy

    LP->>NA: boolean_ones_like(logits)
    NA->>NP: ones_like(logits, dtype=bool)
    NP-->>NA: mask
    NA-->>LP: mask
    LP->>NA: apply_mask(logits, mask, -inf)
    NA->>NP: logits.copy()
    NP-->>NA: result
    NA->>NP: result[mask] = -inf
    NA-->>LP: masked logits
    LP->>NA: argsort_descending(logits)
    NA->>NP: argsort(-logits)
    NP-->>NA: indices
    NA-->>LP: sorted indices
```

---

## Relationship to Other Adapters

`NumpyTensorAdapter` is one of five concrete adapters sharing the `TensorAdapter` contract. The table below highlights how the NumPy implementation compares to its siblings on the methods where behavior diverges.

| Method | NumPy | Torch | JAX |
| --- | --- | --- | --- |
| `unsqueeze` | `expand_dims(axis=0)` | `unsqueeze(0)` | `expand_dims(axis=0)` |
| `concatenate` | `concatenate(axis=0)` | `cat(dim=0)` | `concatenate(axis=0)` |
| `get_device` | `None` | `tensor.device` | `None` |
| `to_device` | identity | `tensor.to(device)` | identity |
| `apply_mask` | copy + boolean index | `masked_fill` | `.at[mask].set(value)` |
| `argsort_descending` | `argsort(-tensor)` | `argsort(descending=True)` | `argsort(-tensor)` |

For details on the shared interface and the `full_like` / `concatenate` torch-tensor compatibility requirement, refer to [tensor_adapters_base](tensor_adapters_base.md). For the other implementations, see [tensor_adapters_torch](tensor_adapters_torch.md), [tensor_adapters_jax](tensor_adapters_jax.md), [tensor_adapters_mlx](tensor_adapters_mlx.md), and [tensor_adapters_tensorflow](tensor_adapters_tensorflow.md).

---

## Integration with the Broader System

The adapter is consumed by the structured logits processors in the [processors_structured](processors_structured.md) module (e.g., `GuideLogitsProcessor`, `RegexLogitsProcessor`, `JSONLogitsProcessor`, `CFGLogitsProcessor`). These processors select the appropriate adapter based on the tensor library in use, allowing the same constrained-decoding logic to run over NumPy, Torch, JAX, MLX, or TensorFlow tensors.

```mermaid
flowchart TD
    subgraph Processors
        GLP[GuideLogitsProcessor]
        RLP[RegexLogitsProcessor]
        JLP[JSONLogitsProcessor]
        CLP[CFGLogitsProcessor]
    end

    subgraph Adapters
        TA[TensorAdapter interface]
        NTA[NumpyTensorAdapter]
        TTA[TorchTensorAdapter]
        JTA[JAXTensorAdapter]
    end

    GLP --> TA
    RLP --> TA
    JLP --> TA
    CLP --> TA
    TA --> NTA
    TA --> TTA
    TA --> JTA
```

---

## Summary

`NumpyTensorAdapter` is a thin, stateless adapter that maps the generic `TensorAdapter` interface onto NumPy operations. Its key characteristics are:

- Lazy NumPy import to keep the dependency optional.
- CPU-only semantics with no-op device methods.
- Copy-before-mutate masking to preserve immutability.
- Negation-based descending sort.

It enables Outlines' structured-generation logits processors to operate transparently on NumPy arrays alongside other tensor backends.
