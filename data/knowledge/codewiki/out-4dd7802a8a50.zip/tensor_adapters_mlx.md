# Tensor Adapters: MLX

## Introduction

The `tensor_adapters_mlx` module provides the `MLXTensorAdapter`, a concrete implementation of the abstract [`TensorAdapter`](tensor_adapters_base.md) interface for the [MLX](https://github.com/ml-explore/mlx) array framework. MLX is Apple's array framework optimized for unified memory on Apple Silicon, and it is the tensor backend used by the `mlx-lm` model integration.

This adapter allows Outlines' logits processors (such as [`GuideLogitsProcessor`](processors_structured.md)) to manipulate logits and token-id tensors using MLX operations, without the processors needing to know which array library the underlying model uses. It is one of several sibling adapters (Torch, NumPy, JAX, TensorFlow) that together form the tensor abstraction layer described in [tensor_adapters_base.md](tensor_adapters_base.md).

## Purpose and Core Functionality

The `MLXTensorAdapter` translates the generic tensor operations required by Outlines' logits processors into their MLX equivalents. Its responsibilities include:

- **Shape inspection** — reporting tensor dimensions.
- **Dimension manipulation** — adding/removing a leading axis (`unsqueeze`/`squeeze`).
- **Conversion** — turning tensors into Python lists or scalars.
- **Construction** — creating filled, boolean, or concatenated tensors.
- **Masking** — applying boolean masks to bias logits (e.g., setting disallowed tokens to `-inf`).
- **Sorting** — producing descending argsort indices (used by samplers).
- **Device handling** — MLX uses unified memory, so device operations are effectively no-ops.

## Architecture

The adapter sits within the tensor adapter layer, which decouples logits processors from the concrete array library used by a model.

```mermaid
graph TD
    subgraph "Logits Processors"
        OLP[OutlinesLogitsProcessor]
        GLP[GuideLogitsProcessor]
    end

    subgraph "Tensor Adapter Layer"
        TA[TensorAdapter<br/>abstract base]
        MLX[MLXTensorAdapter]
        TORCH[TorchTensorAdapter]
        NP[NumpyTensorAdapter]
        JAX[JAXTensorAdapter]
        TF[TensorFlowTensorAdapter]
    end

    subgraph "MLX Ecosystem"
        MLXCORE[mlx.core]
        MLXLM[MLXLM model]
    end

    OLP -->|selects by library_name| TA
    GLP --> OLP
    TA --> MLX
    TA --> TORCH
    TA --> NP
    TA --> JAX
    TA --> TF
    MLX -->|wraps| MLXCORE
    MLXLM -->|uses| MLX
```

The `OutlinesLogitsProcessor` constructor resolves the correct adapter class from a registry keyed by `tensor_library_name`. When a model uses MLX, the string `"mlx"` selects `MLXTensorAdapter`.

## Component Relationships

```mermaid
classDiagram
    class TensorAdapter {
        <<abstract>>
        +str library_name
        +shape(tensor)
        +unsqueeze(tensor)
        +squeeze(tensor)
        +to_list(tensor)
        +to_scalar(tensor)
        +full_like(tensor, fill_value)
        +concatenate(tensors)
        +get_device(tensor)
        +to_device(tensor, device)
        +boolean_ones_like(tensor)
        +apply_mask(tensor, mask, value)
        +argsort_descending(tensor)
    }

    class MLXTensorAdapter {
        +str library_name = "mlx"
        +mlx.core mlx
        +__init__()
    }

    TensorAdapter <|-- MLXTensorAdapter
```

## Method Reference

The following table summarizes how each abstract method is implemented for MLX.

| Method | MLX Implementation | Notes |
|--------|-------------------|-------|
| `shape(tensor)` | `tensor.shape` | Direct attribute access. |
| `unsqueeze(tensor)` | `mlx.expand_dims(tensor, 0)` | Adds a leading axis. |
| `squeeze(tensor)` | `tensor[0]` if `shape[0] == 1` else `tensor` | Conditional squeeze; avoids errors when the axis is not size 1. |
| `to_list(tensor)` | `tensor.tolist()` | Converts to nested Python list. |
| `to_scalar(tensor)` | `tensor.item()` | Extracts a single element. |
| `full_like(tensor, fill_value)` | `mlx.full(tensor.shape, fill_value)` | **Accepts a torch tensor** (see compatibility note). |
| `concatenate(tensors)` | `mlx.concatenate([...], axis=0)` | **Handles both torch and MLX tensors** by converting non-MLX inputs. |
| `get_device(tensor)` | `None` | MLX uses unified memory; no device concept. |
| `to_device(tensor, device)` | `tensor` | No-op; returns tensor unchanged. |
| `boolean_ones_like(tensor)` | `mlx.ones(tensor.shape, dtype=mlx.bool_)` | Boolean mask of ones. |
| `apply_mask(tensor, mask, value)` | `mlx.where(mask, mlx.array(value), tensor)` | Fills masked positions with `value`. |
| `argsort_descending(tensor)` | `mlx.argsort(-tensor)` | Negates to achieve descending order. |

## Data Flow

The adapter is exercised during each generation step by a logits processor. The flow below shows how a `GuideLogitsProcessor` uses the MLX adapter to bias logits.

```mermaid
sequenceDiagram
    participant Model as MLXLM Model
    participant Proc as GuideLogitsProcessor
    participant Adapter as MLXTensorAdapter
    participant MLX as mlx.core

    Model->>Proc: __call__(input_ids, logits)
    Proc->>Adapter: shape(input_ids), shape(logits)
    Proc->>Adapter: unsqueeze(...) (if 1D)
    Proc->>Proc: process_logits(input_ids, logits)
    Proc->>Adapter: to_list(gen_ids)
    Proc->>Adapter: to_scalar(gen_ids[-1])
    Proc->>Adapter: full_like(allowed_tokens, i)
    Proc->>Adapter: concatenate(allowed_tokens_batch)
    Proc->>Adapter: get_device(logits)
    Proc->>Adapter: to_device(concat, device)
    Proc->>Adapter: boolean_ones_like(logits)
    Proc->>Adapter: apply_mask(logits, mask, -inf)
    Adapter->>MLX: mlx.where / mlx.ones / mlx.concatenate
    MLX-->>Adapter: MLX arrays
    Adapter-->>Proc: processed logits
    Proc-->>Model: biased logits
```

## Torch Compatibility

A key design constraint (documented in the base class) is that `full_like` and `concatenate` must be able to accept **torch tensors**, because the underlying `outlines-core` library currently emits torch tensors regardless of the model's array library. The MLX adapter handles this explicitly:

- `full_like` reads `tensor.shape` (works for both torch and MLX tensors) and constructs a fresh MLX array.
- `concatenate` inspects each element and wraps non-MLX inputs with `mlx.array(t)` before concatenating.

This ensures interoperability until `outlines-core` is updated to emit plain arrays.

## Integration with the MLXLM Model

The [`MLXLM`](models_local.md) model and its `MLXLMTypeAdapter` use MLX tensors and pass `"mlx"` as the tensor library name when constructing logits processors. The `MLXLMTypeAdapter.format_output_type` wraps the provided `OutlinesLogitsProcessor` into a list, which the `mlx-lm` generation loop then invokes. Because `mlx-lm` does not support batch inference, the adapter's `squeeze`/`unsqueeze` logic (driven by `OutlinesLogitsProcessor.__call__`) is important for normalizing the 1D `input_ids` produced by `mlx-lm` into the 2D form expected by `process_logits`.

## Related Modules

- [tensor_adapters_base.md](tensor_adapters_base.md) — the abstract `TensorAdapter` interface and the registry that maps library names to adapters.
- [tensor_adapters_torch.md](tensor_adapters_torch.md) — the PyTorch adapter.
- [tensor_adapters_numpy.md](tensor_adapters_numpy.md) — the NumPy adapter.
- [tensor_adapters_jax.md](tensor_adapters_jax.md) — the JAX adapter.
- [tensor_adapters_tensorflow.md](tensor_adapters_tensorflow.md) — the TensorFlow adapter.
- [processors_base.md](processors_base.md) — `OutlinesLogitsProcessor`, the consumer of tensor adapters.
- [processors_structured.md](processors_structured.md) — `GuideLogitsProcessor` and other structured processors.
- [models_local.md](models_local.md) — local model integrations including `MLXLM`.
