# Templates Module

## Introduction

The `templates` module (`outlines/templates.py`) provides utilities for building and rendering **prompt templates** for language models. It is built on top of [Jinja2](https://jinja.palletsprojects.com/) and offers two primary capabilities:

1. **`Template`** — a callable wrapper around a Jinja2 template that can be constructed from a string or a file, with optional signature binding for argument validation.
2. **`Vision`** — a data container that packages a text prompt together with an image, encoding the image as a base64 string suitable for vision-capable models.

The module also exposes a set of helper functions for creating Jinja environments, registering built-in filters (e.g. `name`, `description`, `source`, `signature`, `args`, `schema`), and rendering JSON schemas from Pydantic models or dictionaries.

This module is a foundational utility used across the Outlines ecosystem to keep prompt content separate from application code, making prompts easier to maintain, reuse, and partially apply.

---

## Architecture Overview

The module is intentionally small and self-contained. It depends on Jinja2 for templating, Pydantic for schema rendering, and Pillow for image handling. Its outputs (`Template` renderings and `Vision` instances) are consumed by the model layer.

```mermaid
graph TD
    subgraph "templates module"
        Template["Template"]
        Vision["Vision"]
        prompt["prompt (deprecated)"]
        build_str["build_template_from_string"]
        build_file["build_template_from_file"]
        env["create_jinja_env"]
        filters["Built-in filters<br/>(name, description, source,<br/>signature, args, schema)"]
        schema["get_schema (singledispatch)"]
    end

    subgraph "External libraries"
        Jinja["jinja2"]
        Pydantic["pydantic"]
        PIL["PIL.Image"]
    end

    subgraph "Consumers"
        Models["Model layer<br/>(OpenAI, TransformersMultiModal, ...)"]
        Generator["Generator"]
    end

    Template --> build_str
    Template --> build_file
    build_str --> env
    build_file --> env
    env --> filters
    filters --> schema
    prompt --> build_str
    prompt --> Template

    env --> Jinja
    schema --> Pydantic
    Vision --> PIL

    Template --> Models
    Vision --> Models
    Models --> Generator
```

---

## Core Components

### `Template`

`Template` is a dataclass that wraps a compiled `jinja2.Template` together with an optional `inspect.Signature`. It is the central abstraction of the module.

| Attribute | Type | Description |
|-----------|------|-------------|
| `template` | `jinja2.Template` | The compiled Jinja2 template. |
| `signature` | `Optional[inspect.Signature]` | Optional signature used to bind and validate call arguments. |

**Key behaviors:**

- **`__call__(*args, **kwargs) -> str`** — Renders the template. If a `signature` is present, arguments are bound and defaults applied before rendering; otherwise, keyword arguments are passed directly to `render`.
- **`from_string(content, filters={})`** — Classmethod that builds a `Template` from a raw string. The string is cleaned (dedented, whitespace normalized) before compilation. No signature is inferred.
- **`from_file(path, filters={})`** — Classmethod that builds a `Template` from a file. Uses a `FileSystemLoader` rooted at the file's directory, so Jinja `include`/inheritance works within that folder but not outside it. No signature is inferred.

> **Note:** `from_file` deliberately does not infer a signature because templates split across multiple files (via includes/inheritance) cannot be reliably introspected.

### `Vision`

`Vision` is a dataclass that packages a prompt and an image for vision-capable models. It is passed as the `model_input` argument to models that support vision (e.g. `TransformersMultiModal`, `OpenAI`).

| Attribute | Type | Description |
|-----------|------|-------------|
| `prompt` | `str` | The text prompt. |
| `image` | `PIL.Image.Image` | The image to accompany the prompt. |
| `image_str` | `str` | *(derived)* Base64-encoded image bytes. |
| `image_format` | `str` | *(derived)* MIME type, e.g. `image/png`. |

In `__post_init__`, the image is validated (must have a readable `format`), serialized to a `BytesIO` buffer, base64-encoded, and stored along with its MIME type. This makes the instance directly consumable by API-based vision models.

---

## Data Flow

The following diagram illustrates how a prompt flows from definition to a rendered string, and how a `Vision` input is prepared for a model.

```mermaid
flowchart LR
    subgraph "Template creation"
        A["String / File"] --> B["build_template_from_string /<br/>build_template_from_file"]
        B --> C["create_jinja_env<br/>(+ filters)"]
        C --> D["jinja2.Template"]
        D --> E["Template(template, signature)"]
    end

    subgraph "Rendering"
        E --> F["Template.__call__(*args, **kwargs)"]
        F --> G{"signature?"}
        G -->|Yes| H["bind + apply_defaults"]
        G -->|No| I["render(**kwargs)"]
        H --> J["render(**arguments)"]
        I --> K["Rendered prompt string"]
        J --> K
    end

    subgraph "Vision input"
        L["prompt + PIL.Image"] --> M["Vision.__post_init__"]
        M --> N["base64 encode + MIME type"]
        N --> O["Vision instance"]
    end

    K --> P["Model.generate()"]
    O --> P
```

---

## Component Interaction

The diagram below shows how the internal helpers collaborate when a `Template` is created and rendered.

```mermaid
sequenceDiagram
    participant User
    participant Template
    participant Builder as build_template_from_*
    participant Env as create_jinja_env
    participant Jinja as jinja2.Environment
    participant Filters as Built-in filters

    User->>Template: from_string(content, filters)
    Template->>Builder: build_template_from_string(content, filters)
    Builder->>Builder: cleandoc + whitespace normalization
    Builder->>Env: create_jinja_env(None, filters)
    Env->>Jinja: Environment(loader, trim_blocks, ...)
    Env->>Filters: register name/description/source/signature/args/schema
    Env->>Filters: apply user filters (override)
    Env-->>Builder: env
    Builder->>Jinja: env.from_string(cleaned)
    Jinja-->>Builder: jinja2.Template
    Builder-->>Template: jinja2.Template
    Template-->>User: Template instance

    User->>Template: __call__(*args, **kwargs)
    Template->>Template: bind signature (if present)
    Template->>Jinja: render(**arguments)
    Jinja-->>User: rendered string
```

---

## Built-in Jinja Filters

`create_jinja_env` registers a set of filters that make it easy to introspect Python callables and render schemas directly from templates. Users may override any of these by passing a `filters` dictionary.

| Filter | Function | Description |
|--------|----------|-------------|
| `name` | `get_fn_name` | Returns the name of a callable. |
| `description` | `get_fn_description` | Returns the first line of a callable's docstring. |
| `source` | `get_fn_source` | Returns the dedented source code of a callable. |
| `signature` | `get_fn_signature` | Returns the parameter list of a callable. |
| `args` | `get_fn_args` | Returns arguments with annotations and defaults. |
| `schema` | `get_schema` | Renders a JSON schema for a dict or Pydantic model. |

### Schema Rendering (`get_schema`)

`get_schema` is a `functools.singledispatch` function, allowing type-specific rendering:

- **`dict`** → pretty-printed JSON via `json.dumps(model, indent=2)`.
- **`type[BaseModel]`** → the Pydantic model's JSON schema, recursively resolving `$ref` references (via `parse_pydantic_schema`) so nested models are inlined as human-readable descriptions.

```mermaid
flowchart TD
    A["get_schema(model)"] --> B{"type?"}
    B -->|dict| C["get_schema_dict<br/>json.dumps(indent=2)"]
    B -->|type[BaseModel]| D["get_schema_pydantic"]
    D --> E["model_json_schema() / schema()"]
    E --> F["parse_pydantic_schema<br/>(resolve $ref recursively)"]
    F --> G["json.dumps(indent=2)"]
    B -->|other| H["NotImplementedError"]
```

---

## The `prompt` Decorator (Deprecated)

The `prompt` decorator allows defining a template in a function's docstring and returns a `Template` bound to that function's signature.

> ⚠️ **Deprecated:** The `@prompt` decorator is deprecated and will be removed in Outlines 1.1.0. Use `Template.from_file()` to load prompts from separate template files, or a plain Python function that returns text. This keeps prompt content separate from code and is more maintainable.

```python
import outlines

@outlines.prompt
def build_prompt(question):
    "I have a ${question}"

prompt = build_prompt("How are you?")
```

Because the returned object is a `Template` with a bound signature, it can be partially applied with `functools.partial` — useful in agent contexts where parts of the prompt are fixed at initialization.

---

## Integration with the Model Layer

`Template` and `Vision` are consumed by the model layer. The `Model` base class accepts a `model_input` that may be a plain string, a list of strings, or a `Vision` instance.

```mermaid
graph LR
    Template["Template<br/>(rendered string)"] --> Model["Model.generate()"]
    Vision["Vision<br/>(prompt + image)"] --> Model
    Model --> OpenAI["OpenAI<br/>(API vision)"]
    Model --> TMM["TransformersMultiModal<br/>(local vision)"]
    Model --> Others["Other models"]
```

- **`OpenAI`** accepts `Union[str, Vision]` as `model_input` and formats it via its type adapter.
- **`TransformersMultiModal`** accepts `Union[str, List[str], dict]` and processes inputs through a Hugging Face processor.

For details on how models consume these inputs, see the model documentation:

- [models_base.md](models_base.md) — `Model`, `AsyncModel`, `ModelTypeAdapter`
- [models_api.md](models_api.md) — API-based models including `OpenAI`
- [models_local.md](models_local.md) — local models including `TransformersMultiModal`

---

## Process Flow: End-to-End Prompt Usage

```mermaid
flowchart TD
    Start["Define prompt"] --> Choice{"Definition style"}
    Choice -->|String| S1["Template.from_string(content)"]
    Choice -->|File| S2["Template.from_file(path)"]
    Choice -->|Docstring (deprecated)| S3["@prompt decorator"]

    S1 --> T["Template instance"]
    S2 --> T
    S3 --> T

    T --> Render["Render with args/kwargs"]
    Render --> PromptStr["Prompt string"]

    PromptStr --> ModelCall["model(prompt, output_type)"]
    Img["PIL.Image + prompt"] --> VisionInst["Vision(prompt, image)"]
    VisionInst --> ModelCall

    ModelCall --> Gen["Generator"]
    Gen --> Output["Generated response"]
```

---

## Summary

The `templates` module provides a lightweight, Jinja2-based abstraction for prompt management:

- **`Template`** wraps Jinja2 templates with optional signature binding, supporting both string and file sources.
- **`Vision`** packages prompts with images for vision models.
- **Built-in filters** enable introspection of callables and schema rendering directly within templates.
- The deprecated **`@prompt`** decorator offers a docstring-based template definition (to be removed in 1.1.0).

By separating prompt content from application code, the module improves maintainability and reuse across the Outlines ecosystem, feeding rendered prompts and vision inputs into the [model layer](models_base.md).
