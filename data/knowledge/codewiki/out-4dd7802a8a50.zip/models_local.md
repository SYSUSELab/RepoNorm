# Local Models Module

## Introduction

The `models_local` module provides Outlines integrations for **local inference engines** — libraries that run language models directly on the user's hardware (CPU, GPU, or Apple Silicon) rather than calling a remote API. It wraps four distinct backends behind a unified interface:

| Backend | Library | Tensor Library | Streaming | Batch |
|---------|---------|----------------|-----------|-------|
| `Transformers` / `TransformersMultiModal` | `transformers` | torch / jax / tensorflow | ❌ | ✅ |
| `LlamaCpp` | `llama-cpp-python` | numpy | ✅ | ❌ |
| `MLXLM` | `mlx-lm` | mlx | ✅ | ❌ |
| `VLLMOffline` | `vllm` (offline) | — (server-side) | ❌ | ✅ |

Each wrapper converts the high-level input/output types provided by the user into the arguments expected by the underlying library, and applies Outlines' structured-generation constraints via logits processors (or, for vLLM, native guided-decoding parameters).

> **Related documentation:** For the shared base classes and the type-adapter contract, see [models_base.md](models_base.md). For the tokenizer abstraction, see [models_tokenizer.md](models_tokenizer.md). For the logits processors that enforce structured output, see [processors.md](processors.md). For the DSL types used to describe output constraints, see [types_dsl.md](types_dsl.md).

---

## Architecture

All local models inherit from the abstract `Model` base class and delegate input/output formatting to a `ModelTypeAdapter`. The key architectural distinction between local and API-based models is that **local models receive a logits processor as their `output_type`**, whereas API models receive a type (JSON schema, enum, etc.).

```mermaid
classDiagram
    class Model {
        <<abstract>>
        +type_adapter: ModelTypeAdapter
        +tensor_library_name: str
        +generate(model_input, output_type, **kwargs)
        +generate_stream(model_input, output_type, **kwargs)
        +__call__(model_input, output_type, **kwargs)
        +stream(model_input, output_type, **kwargs)
    }
    class ModelTypeAdapter {
        <<abstract>>
        +format_input(model_input)
        +format_output_type(output_type)
    }
    class Transformers
    class TransformersMultiModal
    class LlamaCpp
    class MLXLM
    class VLLMOffline

    Model <|-- Transformers
    Transformers <|-- TransformersMultiModal
    Model <|-- LlamaCpp
    Model <|-- MLXLM
    Model <|-- VLLMOffline

    Model o-- ModelTypeAdapter
```

### Component Overview

```mermaid
graph TD
    subgraph "models_local"
        T[Transformers<br/>TransformersMultiModal]
        L[LlamaCpp]
        M[MLXLM]
        V[VLLMOffline]
    end

    subgraph "Shared Infrastructure"
        BASE[Model / ModelTypeAdapter<br/>models_base]
        TOK[Tokenizer<br/>models_tokenizer]
        LP[OutlinesLogitsProcessor<br/>processors]
        TA[TensorAdapter<br/>tensor_adapters]
        DSL[DSL Types<br/>types_dsl]
    end

    T --> BASE
    L --> BASE
    M --> BASE
    V --> BASE

    T --> TOK
    L --> TOK
    M --> TOK

    T --> LP
    L --> LP
    M --> LP
    V --> DSL

    LP --> TA
```

---

## The Type Adapter Pattern

Every local model defines a `ModelTypeAdapter` subclass that implements two methods:

- **`format_input(model_input)`** — validates and converts the user's input into the format the backend expects. Implemented with `@singledispatchmethod` so that different input types (e.g. `str`, `list`, `dict`) can be handled separately.
- **`format_output_type(output_type)`** — converts the Outlines logits processor (or DSL term) into the backend-specific argument.

```mermaid
flowchart LR
    U[User input + output_type] --> M[Model.generate]
    M --> FI[type_adapter.format_input]
    M --> FO[type_adapter.format_output_type]
    FI --> BE[Backend call]
    FO --> BE
    BE --> DEC[Decode / post-process]
    DEC --> R[Result]
```

The table below summarizes how each backend formats its output type:

| Model | `format_output_type` returns |
|-------|------------------------------|
| `Transformers` | `transformers.LogitsProcessorList([processor])` or `None` |
| `LlamaCpp` | `llama_cpp.LogitsProcessorList([processor])` |
| `MLXLM` | `[processor]` (plain list) or `None` |
| `VLLMOffline` | `dict` of `GuidedDecodingParams` kwargs (`grammar`, `json`, or `regex`) |

---

## Transformers Integration

**File:** `outlines/models/transformers.py`

The `Transformers` class wraps a `transformers.PreTrainedModel` and a `PreTrainedTokenizer`. It is the most feature-rich local integration, supporting text-to-text and encoder-decoder models across three tensor backends.

### Key Behaviors

- **Tensor library detection:** During `__init__`, the model type is inspected to set `tensor_library_name` to `"jax"` (Flax), `"tensorflow"` (TF), or `"torch"` (default). This value is later used by logits processors to select the correct `TensorAdapter`.
- **Left padding:** The tokenizer's `padding_side` is forced to `"left"` to ensure correct generation with batched inputs.
- **Encoder-decoder handling:** `_generate_output_seq` strips the input prefix for decoder-only models but keeps the full sequence for encoder-decoder models.
- **Multi-sample support:** When `num_return_sequences > 1` and the input is a list, the output is reshaped to a 3D tensor `(batch, num_samples, seq_len)`.

### `TransformerTokenizer`

A `Tokenizer` implementation wrapping a HuggingFace tokenizer. Notable details:

- Handles missing `pad_token_id` by falling back to `eos_token_id`.
- Detects Llama-family tokenizers (`LlamaTokenizer`, `LlamaTokenizerFast`, `CodeLlamaTokenizer`, `CodeLlamaTokenizerFast`) to apply a whitespace work-around in `convert_token_to_string` (the `SPIECE_UNDERLINE` / `<0x20>` hack).
- Implements `__eq__`, `__hash__`, and pickling support for use with the caching layer (see [caching.md](caching.md)).

### `TransformersMultiModal`

Extends `Transformers` to support vision/audio models via a `ProcessorMixin`. Its type adapter requires a `dict` input containing at least a `"text"` key, plus any additional keys the processor needs (e.g. `"images"`, `"audios"`). The processor is invoked with `padding=True, return_tensors="pt"`.

### Factory Function

```python
from outlines.models.transformers import from_transformers

model = from_transformers(pretrained_model, tokenizer_or_processor)
```

`from_transformers` dispatches on the second argument: a `PreTrainedTokenizer`/`PreTrainedTokenizerFast` produces a `Transformers` instance, while a `ProcessorMixin` produces a `TransformersMultiModal` instance.

### Generation Flow

```mermaid
sequenceDiagram
    participant U as User
    participant M as Transformers
    participant TA as TransformersTypeAdapter
    participant TK as TransformerTokenizer
    participant HF as HF Model

    U->>M: generate(prompt, output_type)
    M->>TA: format_input(prompt)
    TA-->>M: prompts
    M->>TK: encode(prompts)
    TK-->>M: input_ids, attention_mask
    M->>TA: format_output_type(output_type)
    TA-->>M: LogitsProcessorList
    M->>HF: model.generate(inputs, logits_processor=...)
    HF-->>M: output_ids
    M->>TK: decode(generated_ids)
    TK-->>M: text
    M-->>U: text
```

> **Note:** `generate_stream` is **not implemented** for Transformers models (pending upstream support).

---

## LlamaCpp Integration

**File:** `outlines/models/llamacpp.py`

The `LlamaCpp` class wraps a `llama_cpp.Llama` model. It uses the `numpy` tensor library.

### Key Behaviors

- **No batch inference:** The type adapter only registers `str` input; lists raise `NotImplementedError`.
- **CFG not supported:** Both `generate` and `generate_stream` raise `NotImplementedError` when given a `CFGLogitsProcessor`, due to a bug in the llama.cpp tokenizer.
- **Model reset:** After generation (and at the end of streaming), `self.model.reset()` is called to clear the model's internal state.
- **Streaming:** `generate_stream` returns a generator that yields `result["choices"][0]["text"]` chunks.

### `LlamaCppTokenizer`

A `Tokenizer` implementation built from the llama.cpp model's tokenizer. Notable details:

- Attempts to use the underlying HuggingFace tokenizer's vocabulary when available; otherwise reconstructs the vocabulary by decoding every token id.
- Vocabulary is sorted by token id to guarantee stable ordering.
- Implements a custom `__hash__` (since `pickle.dumps` is unstable) and a `__getstate__` for the caching layer. `__setstate__` raises `NotImplementedError` — pickled tokenizers cannot be reloaded.

### Deprecated

`load_lora` is deprecated since v1.0.0 and will be removed in v1.1.0.

### Factory Function

```python
from outlines.models.llamacpp import from_llamacpp

model = from_llamacpp(llama_instance)
```

---

## MLXLM Integration

**File:** `outlines/models/mlxlm.py`

The `MLXLM` class wraps an `mlx_lm` model for Apple Silicon inference. It uses the `mlx` tensor library.

### Key Behaviors

- **Dual tokenizer references:** `self.mlx_tokenizer` is passed to `mlx_lm`'s generate functions, while `self.tokenizer` (a `TransformerTokenizer` wrapping `tokenizer._tokenizer`) is used by the logits processor.
- **No batch inference:** Only `str` input is supported.
- **Streaming:** `generate_stream` uses `mlx_lm.stream_generate` and yields `gen_response.text` for each chunk.
- **Output type:** `format_output_type` returns a plain Python list `[processor]` (not a `LogitsProcessorList`), matching the `mlx_lm` API.

### Factory Function

```python
from outlines.models.mlxlm import from_mlxlm

model = from_mlxlm(mlx_model, tokenizer)
```

---

## VLLMOffline Integration

**File:** `outlines/models/vllm_offline.py`

The `VLLMOffline` class wraps a `vllm.LLM` instance for offline (in-process) batch inference. Unlike the other local models, it does **not** use logits processors — instead it leverages vLLM's native **guided decoding** feature.

### Output Type Conversion

`VLLMOfflineTypeAdapter.format_output_type` converts the user's output type into a `dict` of `GuidedDecodingParams` keyword arguments:

```mermaid
flowchart TD
    OT[output_type] --> PTT[python_types_to_terms]
    PTT --> T{Term type?}
    T -->|CFG| G["{'grammar': definition}"]
    T -->|JsonSchema| J["{'json': schema,<br/>'whitespace_pattern': ...}"]
    T -->|other| R["{'regex': to_regex(term)}"]
```

The resulting dict is passed to `GuidedDecodingParams(**output_type_args)` and assigned to `sampling_params.guided_decoding`.

### Result Shaping

`generate` normalizes the nested vLLM output (`List[List[str]]`) based on batch and sample sizes:

| batch_size | sample_size | Returned |
|------------|-------------|----------|
| 1 | 1 | `str` |
| 1 | >1 | `List[str]` |
| >1 | 1 | `List[str]` |
| >1 | >1 | `List[List[str]]` |

### Key Behaviors

- **Streaming not available:** `generate_stream` raises `NotImplementedError`.
- **LoRA:** `load_lora` is deprecated since v1.0.0. The `lora_request` attribute is retained for v0 legacy compatibility and will be removed.

### Factory Function

```python
from outlines.models.vllm_offline import from_vllm_offline

model = from_vllm_offline(vllm_llm_instance)
```

> **Note:** For the server-based vLLM integration (with async support), see [models_server.md](models_server.md).

---

## Cross-Cutting Concerns

### Structured Generation

Local models enforce structured output by passing an `OutlinesLogitsProcessor` to the backend. The processor masks logits at each generation step to keep the output within the grammar/regex/schema. The processor selects a `TensorAdapter` based on the model's `tensor_library_name`:

```mermaid
graph LR
    M[Local Model] -->|tensor_library_name| LP[OutlinesLogitsProcessor]
    LP --> TA{TensorAdapter}
    TA -->|torch| TT[TorchTensorAdapter]
    TA -->|numpy| NT[NumpyTensorAdapter]
    TA -->|mlx| MT[MLXTensorAdapter]
    TA -->|jax| JT[JAXTensorAdapter]
    TA -->|tensorflow| FT[TensorFlowTensorAdapter]
```

See [processors.md](processors.md) and [tensor_adapters.md](tensor_adapters.md) for details.

### Tokenization

`Transformers`, `LlamaCpp`, and `MLXLM` each provide a `Tokenizer` implementation (see [models_tokenizer.md](models_tokenizer.md)). `VLLMOffline` relies on vLLM's internal tokenization and does not expose a `Tokenizer`.

### Caching

`TransformerTokenizer` and `LlamaCppTokenizer` implement `__getstate__`/`__hash__` to support the disk-based caching layer. See [caching.md](caching.md).

---

## Summary

The `models_local` module unifies four local inference backends under the `Model`/`ModelTypeAdapter` abstraction. Each backend contributes:

1. A **model wrapper** implementing `generate` (and optionally `generate_stream`).
2. A **type adapter** translating user input and Outlines output types into backend-specific arguments.
3. Optionally, a **tokenizer** implementation for structured generation.

The primary differences between backends are their tensor library, streaming support, batch support, and the mechanism used to enforce structured output (logits processors vs. native guided decoding).
