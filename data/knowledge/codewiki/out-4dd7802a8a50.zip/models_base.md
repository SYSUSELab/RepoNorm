# Models Base Module

## Introduction

The `models_base` module (`outlines/models/base.py`) defines the foundational abstract base classes that every model integration in Outlines must implement. It establishes a uniform contract for both **synchronous** and **asynchronous** models, and introduces the **type adapter** abstraction that decouples user-facing input/output types from the specific formats expected by each backend.

This module is the backbone of the entire `outlines.models` package. Every concrete model — whether a local model (e.g. `Transformers`, `LlamaCpp`), an API-based model (e.g. `OpenAI`, `Anthropic`), or a server-based model (e.g. `VLLM`, `SGLang`) — inherits from `Model` or `AsyncModel` and supplies a `ModelTypeAdapter` implementation.

The module contains three core components:

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `Model` | Abstract base class | Synchronous model contract (`generate`, `generate_stream`, `__call__`, `stream`) |
| `AsyncModel` | Abstract base class | Asynchronous model contract (`async generate`, `async generate_stream`, `__call__`, `stream`) |
| `ModelTypeAdapter` | Abstract base class | Formatting/validation of user input and output types for a specific backend |

---

## Architecture Overview

The base module sits at the center of a layered architecture. Concrete models inherit from the base classes, and the `Generator` layer consumes them through a shared interface.

```mermaid
graph TD
    subgraph "models_base (this module)"
        Model["Model (ABC)"]
        AsyncModel["AsyncModel (ABC)"]
        MTA["ModelTypeAdapter (ABC)"]
    end

    subgraph "Generator layer"
        Gen["Generator"]
        Steerable["SteerableGenerator"]
        BlackBox["BlackBoxGenerator"]
        AsyncBlackBox["AsyncBlackBoxGenerator"]
    end

    subgraph "Concrete models"
        Local["Local models<br/>(Transformers, LlamaCpp, MLXLM, VLLMOffline)"]
        API["API models<br/>(OpenAI, Anthropic, Gemini, Ollama, Dottxt)"]
        Server["Server models<br/>(VLLM, SGLang, TGI)"]
    end

    subgraph "Type adapters"
        TAT["TransformersTypeAdapter"]
        TAO["OpenAITypeAdapter"]
        TAA["AnthropicTypeAdapter"]
        TAX["... other adapters"]
    end

    Model --> Local
    Model --> API
    Model --> Server
    AsyncModel --> Server
    AsyncModel --> API

    MTA --> TAT
    MTA --> TAO
    MTA --> TAA
    MTA --> TAX

    Local -.uses.-> TAT
    API -.uses.-> TAO
    API -.uses.-> TAA

    Gen --> Steerable
    Gen --> BlackBox
    Gen --> AsyncBlackBox
    Steerable --> Model
    BlackBox --> Model
    AsyncBlackBox --> AsyncModel
```

---

## Core Components

### `ModelTypeAdapter`

`ModelTypeAdapter` is an abstract base class (ABC) that defines how a model translates between the **user-facing** representation of inputs/outputs and the **backend-specific** representation.

A type adapter instance must be assigned to the `type_adapter` attribute of a model. It exposes two abstract methods:

#### `format_input(model_input: Any) -> Any`

Formats and validates the user input into the format expected by the model.

- **API-based models**: typically builds the `messages` argument passed to the client (e.g. `OpenAITypeAdapter.format_input` produces a `{"messages": [...]}` dict, handling both `str` and `Vision` inputs).
- **Local models**: may cast the input (e.g. `str` → `list[str]`), as done by `TransformersTypeAdapter` via `singledispatchmethod`.

This method is also the validation point: unsupported input types raise a `TypeError`/`NotImplementedError`.

#### `format_output_type(output_type: Optional[Any] = None) -> Any`

Formats the user-specified output type into the format expected by the model.

- **API-based models**: typically builds a `response_format` argument (e.g. `OpenAITypeAdapter` converts Pydantic models, dataclasses, `TypedDict`s, Genson schemas, and `JsonSchema` into OpenAI's `json_schema` response format).
- **Local models**: wraps the logits processor into the object type expected by the backend (e.g. `TransformersTypeAdapter` wraps it in a `LogitsProcessorList`).

```mermaid
classDiagram
    class ModelTypeAdapter {
        <<abstract>>
        +format_input(model_input) Any
        +format_output_type(output_type) Any
    }
    class OpenAITypeAdapter {
        +format_input(model_input) dict
        +format_output_type(output_type) dict
        +format_str_model_input(model_input) dict
        +format_vision_model_input(model_input) dict
        +format_json_output_type(schema) dict
        +format_json_mode_type() dict
    }
    class TransformersTypeAdapter {
        +format_input(model_input) str|list
        +format_output_type(output_type) LogitsProcessorList
    }
    ModelTypeAdapter <|-- OpenAITypeAdapter
    ModelTypeAdapter <|-- TransformersTypeAdapter
```

> **Note:** The distinction between *steerable* (local) and *black-box* (API) models is reflected in how `format_output_type` is used. For local models the output type is a logits processor; for API models it is a type such as `Json` or `Enum`. See the [generator module](generator.md) for how these are consumed.

---

### `Model`

`Model` is the abstract base class for all **synchronous** models. It provides a shared, user-friendly calling convention while delegating the actual generation to subclasses.

#### Class attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `type_adapter` | `ModelTypeAdapter` | Required. Used by `generate` to format input/output types. |
| `tensor_library_name` | `str` | Required for **local** models. Identifies the tensor library (e.g. `"torch"`, `"numpy"`) used to build logits processors. |

#### Public methods

- **`__call__(model_input, output_type=None, **inference_kwargs)`** — Convenience entry point. Internally constructs a `Generator(self, output_type)` and calls it. This makes `model("prompt", Foo)` equivalent to `Generator(model, Foo)("prompt")`.
- **`stream(model_input, output_type=None, **inference_kwargs)`** — Convenience streaming entry point. Constructs a `Generator` and delegates to its `stream` method, returning an `Iterator[Any]`.

#### Abstract methods (must be implemented by subclasses)

- **`generate(model_input, output_type=None, **inference_kwargs) -> Any`** — Produces a single response. The `output_type` is a logits processor for local models and a type (e.g. `Json`, `Enum`) for API models. Not intended for direct end-user use.
- **`generate_stream(model_input, output_type=None, **inference_kwargs) -> Iterator[Any]`** — Produces a stream of responses. Same `output_type` semantics as `generate`.

```mermaid
classDiagram
    class Model {
        <<abstract>>
        +ModelTypeAdapter type_adapter
        +str tensor_library_name
        +__call__(model_input, output_type, **kwargs) Any
        +stream(model_input, output_type, **kwargs) Iterator
        +generate(model_input, output_type, **kwargs)* Any
        +generate_stream(model_input, output_type, **kwargs)* Iterator
    }
    class Transformers
    class OpenAI
    class VLLM
    Model <|-- Transformers
    Model <|-- OpenAI
    Model <|-- VLLM
```

---

### `AsyncModel`

`AsyncModel` mirrors `Model` but for **asynchronous** execution. It is used by server-based and API-based backends that expose async clients (e.g. `AsyncVLLM`, `AsyncSGLang`, `AsyncTGI`).

#### Class attributes

Identical to `Model`: `type_adapter` and `tensor_library_name`.

#### Public methods

- **`async __call__(model_input, output_type=None, **inference_kwargs)`** — Awaits a `Generator` call. Equivalent to `await Generator(model, Foo)("prompt")`.
- **`async stream(model_input, output_type=None, **inference_kwargs) -> AsyncIterator[Any]`** — Async generator that yields chunks from the underlying `Generator.stream`.

#### Abstract methods

- **`async generate(...) -> Any`** — Async single response.
- **`async generate_stream(...) -> AsyncIterator[Any]`** — Async stream of responses.

```mermaid
classDiagram
    class AsyncModel {
        <<abstract>>
        +ModelTypeAdapter type_adapter
        +str tensor_library_name
        +__call__(model_input, output_type, **kwargs) Any
        +stream(model_input, output_type, **kwargs) AsyncIterator
        +generate(model_input, output_type, **kwargs)* Any
        +generate_stream(model_input, output_type, **kwargs)* AsyncIterator
    }
    class AsyncVLLM
    class AsyncSGLang
    class AsyncTGI
    AsyncModel <|-- AsyncVLLM
    AsyncModel <|-- AsyncSGLang
    AsyncModel <|-- AsyncTGI
```

---

## Data Flow

The following sequence diagram shows how a user call flows through the base classes, the generator layer, and the type adapter.

```mermaid
sequenceDiagram
    participant User
    participant Model as Model / AsyncModel
    participant Gen as Generator
    participant TA as ModelTypeAdapter
    participant Backend as Backend (local/API)

    User->>Model: model("prompt", OutputType)
    Model->>Gen: Generator(self, OutputType)
    Gen->>Model: generate(prompt, output_type, **kwargs)
    Model->>TA: format_input(prompt)
    TA-->>Model: formatted input
    Model->>TA: format_output_type(output_type)
    TA-->>Model: formatted output type
    Model->>Backend: invoke with formatted args
    Backend-->>Model: raw response
    Model-->>Gen: response
    Gen-->>User: response
```

For **local (steerable)** models, the `output_type` passed to `generate` is a logits processor built by `SteerableGenerator`. For **API (black-box)** models, it is the raw output type passed through by `BlackBoxGenerator`/`AsyncBlackBoxGenerator`. See the [generator module](generator.md) for details.

---

## Component Interaction

```mermaid
graph LR
    subgraph "User API"
        U["model(prompt, type)"]
        S["model.stream(prompt, type)"]
    end

    subgraph "models_base"
        M["Model.__call__ / stream"]
        AM["AsyncModel.__call__ / stream"]
    end

    subgraph "generator"
        G["Generator"]
        SG["SteerableGenerator"]
        BG["BlackBoxGenerator"]
        ABG["AsyncBlackBoxGenerator"]
    end

    subgraph "processors"
        LP["OutlinesLogitsProcessor"]
    end

    U --> M
    S --> M
    U --> AM
    S --> AM
    M --> G
    AM --> G
    G --> SG
    G --> BG
    G --> ABG
    SG --> LP
```

---

## How the Module Fits into the System

The `models_base` module is the **contract layer** of the models subsystem. Its role can be summarized as:

1. **Uniform interface** — All models, regardless of backend, expose the same `generate`/`generate_stream`/`__call__`/`stream` surface, so downstream code (generators, applications) never needs backend-specific logic.
2. **Separation of concerns** — The `ModelTypeAdapter` isolates the messy details of input/output formatting (messages, response formats, logits processor wrapping) from the generation logic.
3. **Sync/async parity** — `Model` and `AsyncModel` provide parallel APIs so that both blocking and non-blocking backends integrate cleanly.

### Related modules

- **[generator](generator.md)** — Consumes `Model`/`AsyncModel` via `SteerableGenerator`, `BlackBoxGenerator`, and `AsyncBlackBoxGenerator`.
- **[models_local](models_local.md)** — Concrete local models (`Transformers`, `LlamaCpp`, `MLXLM`, `VLLMOffline`) that subclass `Model` and define `tensor_library_name`.
- **[models_api](models_api.md)** — Concrete API models (`OpenAI`, `Anthropic`, `Gemini`, `Ollama`, `Dottxt`) that subclass `Model` and provide API-specific type adapters.
- **[models_server](models_server.md)** — Concrete server models (`VLLM`, `SGLang`, `TGI`) that subclass `Model`/`AsyncModel`.
- **[models_tokenizer](models_tokenizer.md)** — Tokenizer abstractions used by local models to build logits processors.
- **[processors](processors.md)** — Logits processors produced for steerable models and passed as `output_type` to `generate`.
- **[types_dsl](types_dsl.md)** — The output type DSL (`JsonSchema`, `Regex`, `CFG`, etc.) that type adapters translate into backend formats.

---

## Extending the Module

To add a new model integration, a developer must:

1. Subclass `Model` (or `AsyncModel` for async backends).
2. Implement `generate` and `generate_stream`.
3. Implement a `ModelTypeAdapter` subclass with `format_input` and `format_output_type`.
4. Assign an instance of the adapter to the model's `type_adapter` attribute.
5. For local models, set `tensor_library_name` to the appropriate tensor library identifier.

```mermaid
flowchart TD
    A["Create ModelTypeAdapter subclass"] --> B["Implement format_input"]
    B --> C["Implement format_output_type"]
    C --> D["Create Model/AsyncModel subclass"]
    D --> E["Implement generate"]
    E --> F["Implement generate_stream"]
    F --> G["Set type_adapter attribute"]
    G --> H{"Local model?"}
    H -- Yes --> I["Set tensor_library_name"]
    H -- No --> J["Done"]
    I --> J
```
