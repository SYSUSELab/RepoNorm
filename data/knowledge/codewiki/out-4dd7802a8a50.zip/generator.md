# Generator Module

## Introduction

The `generator` module (`outlines/generator.py`) is the central abstraction that **encapsulates a model and an output type into a reusable object**. It is the primary entry point through which users invoke constrained generation in Outlines.

A generator binds together:

- **A model** — either a local *steerable* model (where Outlines controls the sampling loop via logits processors) or a remote *black-box* model (an API-based model where Outlines only passes the output type along).
- **An output type** — a Python type, a DSL term (regex, JSON schema, CFG, FSM), or a pre-built logits processor that constrains the generation.

The module exposes three concrete generator classes plus a factory function `Generator` that selects the correct class based on the model type. This design lets the rest of the library (applications, legacy adapters, model `__call__` shortcuts) treat generation uniformly regardless of whether the underlying model is local or remote, synchronous or asynchronous.

---

## Architecture Overview

The generator module sits between the **models** layer and the **processors** layer, acting as the orchestration glue.

```mermaid
graph TD
    User["User / Application / Legacy Adapter"]
    Factory["Generator() factory"]
    SG["SteerableGenerator"]
    BBG["BlackBoxGenerator"]
    ABBG["AsyncBlackBoxGenerator"]

    User --> Factory
    Factory -->|SteerableModel| SG
    Factory -->|BlackBoxModel| BBG
    Factory -->|AsyncBlackBoxModel| ABBG

    SG -->|builds| LP["OutlinesLogitsProcessor"]
    SG -->|calls generate| SM["SteerableModel"]
    BBG -->|calls generate| BBM["BlackBoxModel"]
    ABBG -->|calls generate| ABBM["AsyncBlackBoxModel"]

    LP --> RLP["RegexLogitsProcessor"]
    LP --> CLP["CFGLogitsProcessor"]
    LP --> GLP["GuideLogitsProcessor"]

    SG -.uses.-> DSL["outlines.types.dsl"]
    SG -.uses.-> Guide["RegexGuide"]
```

### Component Responsibilities

| Component | Responsibility |
|-----------|----------------|
| `Generator` (factory) | Validates arguments and dispatches to the correct generator class based on the model type. |
| `SteerableGenerator` | Builds and caches a logits processor from an output type; passes it to a local model. |
| `BlackBoxGenerator` | Passes the output type directly to a synchronous API-based model. |
| `AsyncBlackBoxGenerator` | Passes the output type directly to an asynchronous API-based model. |

---

## The `Generator` Factory

The `Generator` function is the recommended way to create a generator. It performs argument validation and type-based dispatch.

```python
def Generator(
    model: Union[Model, AsyncModel],
    output_type: Optional[Any] = None,
    *,
    processor: Optional[OutlinesLogitsProcessor] = None,
) -> Union[SteerableGenerator, BlackBoxGenerator, AsyncBlackBoxGenerator]:
```

### Dispatch Logic

```mermaid
flowchart TD
    Start["Generator(model, output_type, processor)"]
    Validate{"output_type AND processor both set?"}
    Error1["ValueError: at most one allowed"]
    IsSteerable{"isinstance(model, SteerableModel)?"}
    HasProc{"processor provided?"}
    FromProc["SteerableGenerator.from_processor()"]
    FromType["SteerableGenerator(model, output_type)"]
    IsAsync{"isinstance(model, AsyncBlackBoxModel)?"}
    Async["AsyncBlackBoxGenerator"]
    IsBB{"isinstance(model, BlackBoxModel)?"}
    BB["BlackBoxGenerator"]
    Error2["ValueError: invalid model type"]

    Start --> Validate
    Validate -->|yes| Error1
    Validate -->|no| IsSteerable
    IsSteerable -->|yes| HasProc
    HasProc -->|yes| FromProc
    HasProc -->|no| FromType
    IsSteerable -->|no| IsAsync
    IsAsync -->|yes| Async
    IsAsync -->|no| IsBB
    IsBB -->|yes| BB
    IsBB -->|no| Error2
```

### Key Rules

1. **Mutual exclusivity** — `output_type` and `processor` cannot both be provided. Providing both raises a `ValueError`.
2. **Processor only for steerable models** — Passing `processor` with a black-box model raises `NotImplementedError`, since API-based models do not support logits processors.
3. **Model type determines generator class** — The factory inspects the model instance to choose between the three generator classes.

---

## Generator Classes

### `SteerableGenerator`

Represents a generator for which **Outlines controls constrained generation**. This is used with local models (e.g., Transformers, vLLM, llama.cpp) where the sampling loop can be biased via logits processors.

The generator is responsible for **building and storing the logits processor** (which can be expensive to construct) once, then reusing it across calls.

#### Construction Paths

There are two mutually exclusive ways to construct a `SteerableGenerator`:

**1. From an output type (`__init__`)**

The output type is first normalized into a DSL `Term` via `python_types_to_terms`, then compiled into the appropriate logits processor:

```mermaid
flowchart TD
    OT["output_type"] --> None{"is None?"}
    None -->|yes| NoLP["logits_processor = None"]
    None -->|no| PTT["python_types_to_terms(output_type)"]
    PTT --> IsCFG{"isinstance(term, CFG)?"}
    IsCFG -->|yes| CFG["CFGLogitsProcessor(cfg_string, tokenizer, tensor_lib)"]
    PTT --> IsFSM{"isinstance(term, FSM)?"}
    IsFSM -->|yes| FSM["RegexGuide.from_interegular_fsm() → GuideLogitsProcessor"]
    PTT --> Else["to_regex(term)"]
    Else --> Regex["RegexLogitsProcessor(regex_string, tokenizer, tensor_lib)"]
```

| DSL Term | Processor Built |
|----------|-----------------|
| `CFG` | `CFGLogitsProcessor` |
| `FSM` | `GuideLogitsProcessor` (via `RegexGuide.from_interegular_fsm`) |
| Any other term | `RegexLogitsProcessor` (via `to_regex`) |

**2. From a pre-built processor (`from_processor`)**

Advanced users can supply an already-constructed `OutlinesLogitsProcessor`. The classmethod validates the type and bypasses the compilation step:

```python
@classmethod
def from_processor(cls, model, processor):
    if not isinstance(processor, OutlinesLogitsProcessor):
        raise TypeError(...)
    instance = cls.__new__(cls)
    instance.model = model
    instance.logits_processor = processor
    return instance
```

#### Calling

Both `__call__` and `stream` forward the stored `logits_processor` to the model:

```python
def __call__(self, prompt, **inference_kwargs):
    return self.model.generate(prompt, self.logits_processor, **inference_kwargs)

def stream(self, prompt, **inference_kwargs):
    return self.model.generate_stream(prompt, self.logits_processor, **inference_kwargs)
```

---

### `BlackBoxGenerator`

Synchronous generator for models where **Outlines does not control constrained generation**. The output type is passed directly to the model rather than being compiled into a logits processor.

- **FSM restriction** — Constructing a `BlackBoxGenerator` with an `FSM` output type raises `NotImplementedError`, because FSM generation requires local logits control.
- `__call__` delegates to `model.generate(prompt, output_type, ...)`.
- `stream` delegates to `model.generate_stream(prompt, output_type, ...)`.

---

### `AsyncBlackBoxGenerator`

The asynchronous counterpart to `BlackBoxGenerator`, used with `AsyncBlackBoxModel` instances (e.g., async API clients).

- Same FSM restriction as `BlackBoxGenerator`.
- `__call__` is a coroutine: `await self.model.generate(...)`.
- `stream` is an async generator that yields chunks from `self.model.generate_stream(...)`.

---

## Data Flow

The following sequence diagram shows how a constrained generation request flows through the generator for a steerable model.

```mermaid
sequenceDiagram
    participant U as User
    participant G as Generator (factory)
    participant SG as SteerableGenerator
    participant P as LogitsProcessor
    participant M as SteerableModel

    U->>G: Generator(model, output_type)
    G->>SG: SteerableGenerator(model, output_type)
    SG->>SG: python_types_to_terms(output_type)
    SG->>P: build processor (Regex/CFG/Guide)
    Note over SG: processor cached on instance
    U->>SG: generator(prompt, **kwargs)
    SG->>M: model.generate(prompt, logits_processor, **kwargs)
    M->>P: __call__(input_ids, logits)
    P-->>M: biased logits
    M-->>SG: generated text
    SG-->>U: response
```

For a black-box model, the processor step is skipped and the output type is forwarded directly to the model.

---

## Integration with the Rest of the System

The generator module is consumed by several other parts of Outlines. Rather than duplicating logic, those components delegate to `Generator`.

```mermaid
graph LR
    subgraph Consumers
        App["Application"]
        ModelCall["Model.__call__ / Model.stream"]
        V0["GeneratorV0Adapter"]
    end
    Consumers --> Gen["Generator factory"]
    Gen --> GenClasses["SteerableGenerator / BlackBoxGenerator / AsyncBlackBoxGenerator"]
```

- **`Application`** ([applications.md](applications.md)) — Caches a generator instance per model and invokes it with a rendered prompt template.
- **`Model.__call__` / `Model.stream`** ([models.md](models.md)) — Provide a shortcut so `model("prompt", Foo)` is equivalent to `Generator(model, Foo)("prompt")`.
- **`GeneratorV0Adapter`** ([v0_legacy.md](v0_legacy.md)) — Bridges the legacy `generate` API to the current `Generator` object.

---

## Dependencies

### Internal Dependencies

| Dependency | Purpose |
|------------|---------|
| `outlines.models` (`BlackBoxModel`, `SteerableModel`, `AsyncBlackBoxModel`) | Model type hierarchy used for dispatch. See [models.md](models.md). |
| `outlines.models.base` (`Model`, `AsyncModel`) | Base model classes for type hints. |
| `outlines.processors` (`CFGLogitsProcessor`, `GuideLogitsProcessor`, `RegexLogitsProcessor`, `OutlinesLogitsProcessor`) | Logits processors built by `SteerableGenerator`. See [processors.md](processors.md). |
| `outlines.processors.guide.RegexGuide` | Builds a guide from an interegular FSM. See [processors.md](processors.md). |
| `outlines.types` (`CFG`, `FSM`) | DSL term types used to select the processor. See [types_dsl.md](types_dsl.md). |
| `outlines.types.dsl` (`python_types_to_terms`, `to_regex`) | Normalize Python types into DSL terms and compile terms to regex. See [types_dsl.md](types_dsl.md). |

### Dependency Diagram

```mermaid
graph TD
    Gen["outlines/generator.py"]
    Gen --> Models["outlines.models"]
    Gen --> ModelsBase["outlines.models.base"]
    Gen --> Processors["outlines.processors"]
    Gen --> Guide["outlines.processors.guide"]
    Gen --> Types["outlines.types"]
    Gen --> DSL["outlines.types.dsl"]

    Processors --> BaseLP["OutlinesLogitsProcessor"]
    Processors --> Structured["Regex/CFG/Guide LogitsProcessors"]
    DSL --> Term["Term hierarchy"]
```

---

## Usage Examples

### Basic constrained generation (steerable model)

```python
from outlines import Generator

generator = Generator(model, output_type=Foo)
result = generator("prompt")
```

### Streaming

```python
for chunk in generator.stream("prompt"):
    print(chunk)
```

### Using a pre-built processor (advanced)

```python
from outlines import Generator
from outlines.processors import RegexLogitsProcessor

processor = RegexLogitsProcessor(r"\d+", model.tokenizer, model.tensor_library_name)
generator = Generator(model, processor=processor)
```

### Black-box (API) model

```python
generator = Generator(api_model, output_type=Foo)
result = generator("prompt")  # output_type forwarded to the API
```

---

## Summary

The `generator` module provides a clean, uniform abstraction over constrained generation:

- **`Generator`** is the factory that validates arguments and dispatches based on model type.
- **`SteerableGenerator`** compiles output types into logits processors and drives local models.
- **`BlackBoxGenerator`** / **`AsyncBlackBoxGenerator`** forward output types to remote API models.

By centralizing the model + output-type binding, the module enables consistent behavior across local and remote, synchronous and asynchronous models, and serves as the integration point for applications, model shortcuts, and legacy adapters.
