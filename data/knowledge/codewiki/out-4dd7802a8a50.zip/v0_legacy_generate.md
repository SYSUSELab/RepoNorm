# v0_legacy_generate

## Introduction

The `v0_legacy_generate` module provides the **backward-compatibility bridge** between the legacy Outlines v0 `generate` API and the current v1 `Generator` architecture. It allows code written against the v0 API to keep working after the library's major refactor, by wrapping the modern `Generator` object behind an interface that mimics the old `generate` functions.

> **Note:** This module exists purely for backward compatibility with v0. It is explicitly marked as legacy and should **not** be used as an example for writing new code. New code should use the v1 `Generator` API directly (see [generator.md](generator.md)).

The module is centered on two adapter classes:

- `GeneratorV0Adapter` — bridges legacy text-only generation calls to the v1 `Generator`.
- `GeneratorVisionV0Adapter` — a subclass that additionally handles multi-modal (text + media) inputs for the legacy `TransformersVision` model.

---

## Purpose and Core Functionality

The legacy v0 API exposed `generate` functions that returned a callable object. When invoked, that object produced text (or a stream of text) constrained by an output type and a sampler. In v1, this responsibility was split:

1. A `Generator` object is created from a model and an output type (see [generator.md](generator.md)).
2. The generator is called with prompts and inference parameters.

The `v0_legacy_generate` module reconciles these two worlds by:

- **Validating** that the model is one of the models that existed in v0 (`V0GeneratorModel`).
- **Constructing** a v1 `Generator` internally from the model and output type.
- **Translating** legacy call arguments (`max_tokens`, `stop_at`, `seed`, plus model-specific params) into the keyword arguments expected by the underlying v1 model, using per-model *parameter adapters*.
- **Exposing** a `__call__` and `stream` interface identical to the legacy API.

---

## Architecture

The module sits at the boundary between the legacy v0 layer and the modern v1 core. It depends on the v1 `Generator` factory and on the v0 model wrappers and samplers.

```mermaid
graph TD
    subgraph "Legacy v0 API"
        User["User code (v0 style)"]
        Sampler["Sampler<br/>(Greedy/Multinomial/BeamSearch)"]
    end

    subgraph "v0_legacy_generate"
        GVA["GeneratorV0Adapter"]
        GVVA["GeneratorVisionV0Adapter"]
    end

    subgraph "v1 Core"
        GenFactory["Generator() factory"]
        Gen["SteerableGenerator /<br/>BlackBoxGenerator"]
    end

    subgraph "v0 Models"
        ExLlama["ExLlamaV2Model"]
        LlamaCpp["LlamaCpp"]
        MLX["MLXLM"]
        TF["Transformers"]
        TFV["TransformersVision"]
        VLLM["VLLMOffline"]
    end

    subgraph "Parameter Adapters"
        TFA["transformers_params_adapter"]
        LCA["llamacpp_params_adapter"]
        EXA["exllamav2_params_adapter"]
        VLA["vllm_offline_params_adapter"]
        MLA["mlxlm_params_adapter"]
    end

    User --> GVA
    User --> GVVA
    Sampler --> GVA
    GVVA -->|inherits| GVA
    GVA --> GenFactory
    GenFactory --> Gen
    GVA --> ExLlama
    GVA --> LlamaCpp
    GVA --> MLX
    GVA --> TF
    GVA --> VLLM
    GVVA --> TFV
    GVA --> TFA
    GVA --> LCA
    GVA --> EXA
    GVA --> VLA
    GVA --> MLA
```

---

## Component Relationships

### Class Hierarchy

`GeneratorVisionV0Adapter` extends `GeneratorV0Adapter`, overriding only the input-handling behavior to merge prompts and media into a single dictionary before delegating to the parent implementation.

```mermaid
classDiagram
    class GeneratorV0Adapter {
        +model
        +generator: Generator
        +sampling_params: dict
        +format_sequence(sequence)
        +create_inference_params(max_tokens, stop_at, seed, **params)
        +__call__(prompts, max_tokens, stop_at, seed, **params)
        +stream(prompts, max_tokens, stop_at, seed, **params)
    }

    class GeneratorVisionV0Adapter {
        +merge_prompts_and_media(prompts, media)$
        +__call__(prompts, media, max_tokens, stop_at, seed, **params)
        +stream(prompts, media, max_tokens, stop_at, seed, **params)
    }

    GeneratorVisionV0Adapter --|> GeneratorV0Adapter
```

### `GeneratorV0Adapter`

The primary adapter. Its responsibilities:

| Member | Description |
|--------|-------------|
| `__init__(model, output_type, sampler)` | Validates the model against `V0GeneratorModel`, builds a v1 `Generator(model, output_type)`, and stores the sampler's `SamplingParameters` as a dict via `asdict`. |
| `format_sequence(sequence)` | Hook for post-processing generated sequences. Default is identity; subclasses may override. |
| `create_inference_params(...)` | Selects the correct parameter adapter based on the model type and translates legacy arguments into model keyword arguments. |
| `__call__(...)` | Runs generation and applies `format_sequence` to the result (handling both single and list results). |
| `stream(...)` | Delegates to the underlying generator's `stream` method. |

### `GeneratorVisionV0Adapter`

Adds multi-modal support for the legacy `TransformersVision` model. The key difference is that the legacy model expects **separate** `prompts` and `media` arguments, while the v1 `TransformersMultiModal` model expects a **single** dictionary containing `text` and `images`. The `merge_prompts_and_media` static method performs this conversion.

---

## Data Flow

The following sequence diagram shows how a legacy call flows through the adapter into the v1 generator and back.

```mermaid
sequenceDiagram
    participant U as User (v0 style)
    participant A as GeneratorV0Adapter
    participant P as create_inference_params
    participant Ad as Params Adapter
    participant G as v1 Generator
    participant M as v1 Model

    U->>A: __call__(prompts, max_tokens, stop_at, seed, **params)
    A->>P: create_inference_params(...)
    P->>P: select adapter by model type
    P->>Ad: adapter(sampling_params, generation_params, model_params)
    Ad-->>P: inference_params (kwargs)
    P-->>A: inference_params
    A->>G: generator(prompts, **inference_params)
    G->>M: model.generate(prompt, logits_processor, **kwargs)
    M-->>G: generated text
    G-->>A: result
    A->>A: format_sequence(result)
    A-->>U: formatted result
```

### Parameter Translation

The `create_inference_params` method dispatches to a model-specific adapter function. Each adapter maps the legacy `SamplingParameters` and generation arguments onto the keyword arguments understood by the corresponding v1 model.

```mermaid
flowchart TD
    Start["create_inference_params"] --> Check{"Model type?"}
    Check -->|LlamaCpp| LC["llamacpp_params_adapter"]
    Check -->|VLLMOffline| VL["vllm_offline_params_adapter"]
    Check -->|Transformers| TF["transformers_params_adapter"]
    Check -->|ExLlamaV2Model| EX["exllamav2_params_adapter"]
    Check -->|MLXLM| ML["mlxlm_params_adapter"]
    LC --> Out["inference_params"]
    VL --> Out
    TF --> Out
    EX --> Out
    ML --> Out
```

For example, `transformers_params_adapter` maps:
- `stop_at` → `stop_strings`
- `max_tokens` → `max_new_tokens` (defaulting to `2**30` when unset)
- `seed` → global `set_seed`
- `sampler == "multinomial"` → `do_sample = True`
- `sampler == "beam_search"` → `num_beams`
- `num_samples` → `num_return_sequences`
- `top_p`, `top_k`, `temperature` → same-named kwargs

The `llamacpp_params_adapter` performs an analogous mapping but raises `NotImplementedError` for beam search and multi-sample generation, since `llama_cpp_python` does not support them.

---

## Supported Models

The adapter only accepts models that existed in v0, enforced by the `V0GeneratorModel` union type:

```mermaid
graph LR
    V0["V0GeneratorModel"] --> ExLlama["ExLlamaV2Model"]
    V0 --> LlamaCpp["LlamaCpp"]
    V0 --> MLX["MLXLM"]
    V0 --> TF["Transformers"]
    V0 --> TFV["TransformersVision"]
    V0 --> VLLM["VLLMOffline"]
```

If a model outside this union is passed, `__init__` raises a `ValueError`. See [v0_legacy_models.md](v0_legacy_models.md) for details on the legacy model wrappers, and [models_local.md](models_local.md) / [models_server.md](models_server.md) for the v1 model implementations.

---

## Samplers

The adapter consumes a `Sampler` (see [v0_legacy_samplers.md](v0_legacy_samplers.md)) and extracts its `SamplingParameters` via `asdict`. The available samplers are:

| Sampler | `sampler` value | Notes |
|---------|-----------------|-------|
| `GreedySampler` | `"greedy"` | Always 1 sample, temperature 0.0 |
| `MultinomialSampler` | `"multinomial"` | Supports `top_k`, `top_p`, `temperature`, multiple samples |
| `BeamSearchSampler` | `"beam_search"` | Number of beams = number of samples |

The `SamplingParameters` dataclass carries: `sampler`, `num_samples`, `top_p`, `top_k`, and `temperature`.

---

## Process Flow: End-to-End Generation

```mermaid
flowchart TD
    A["Legacy generate() returns GeneratorV0Adapter"] --> B["User calls adapter(prompts, ...)"]
    B --> C["create_inference_params translates args"]
    C --> D["v1 Generator.__call__ invoked"]
    D --> E{"Model type?"}
    E -->|Steerable| F["SteerableGenerator:<br/>build logits processor,<br/>call model.generate"]
    E -->|BlackBox| G["BlackBoxGenerator:<br/>pass output_type to model"]
    F --> H["Generated text"]
    G --> H
    H --> I["format_sequence applied"]
    I --> J["Return to user"]
```

For streaming, the same flow applies but `stream` is used instead of `__call__`, and the underlying generator returns an iterator of chunks.

---

## Vision Adapter Flow

The vision adapter inserts a merge step before delegating to the parent:

```mermaid
flowchart LR
    P["prompts"] --> M["merge_prompts_and_media"]
    Media["media"] --> M
    M --> D["{'text': prompts, 'images': media}"]
    D --> Super["GeneratorV0Adapter.__call__ / stream"]
```

This is required because the legacy `TransformersVision` model takes separate `prompt` and `assets` arguments, whereas the v1 `TransformersMultiModal` model expects a single dictionary. See [v0_legacy_models.md](v0_legacy_models.md) for the `TransformersVision` wrapper.

---

## Related Modules

- [generator.md](generator.md) — The v1 `Generator` factory and generator classes (`SteerableGenerator`, `BlackBoxGenerator`, `AsyncBlackBoxGenerator`) that this module wraps.
- [v0_legacy_models.md](v0_legacy_models.md) — Legacy model wrappers (`ExLlamaV2Model`, `TransformersVision`) and their parameter adapters.
- [v0_legacy_samplers.md](v0_legacy_samplers.md) — The `Sampler` protocol and concrete samplers.
- [v0_legacy_function.md](v0_legacy_function.md) — The legacy `Function` and `vectorize` helpers.
- [models_local.md](models_local.md) — v1 local model implementations (`Transformers`, `LlamaCpp`, `MLXLM`, `VLLMOffline`).
- [models_server.md](models_server.md) — v1 server-based model implementations.
- [processors_structured.md](processors_structured.md) — Logits processors used by steerable generators.
