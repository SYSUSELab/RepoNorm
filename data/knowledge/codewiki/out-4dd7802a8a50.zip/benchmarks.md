# Benchmarks

## Overview

The `benchmarks` module contains the performance benchmark suite for the Outlines
library. It measures the cost of the two most performance-sensitive parts of
structured generation:

1. **Building guides** — compiling a regular expression, context-free grammar
   (CFG), or JSON schema into a finite-state machine / parser that constrains
   generation.
2. **Applying logits processors** — masking the model's logits at each decoding
   step so that only grammar-valid tokens can be sampled.

The suite is built on top of [ASV (airspeed velocity)](https://asv.readthedocs.io/),
a Python benchmarking tool that tracks performance across commits. Each benchmark
is a class whose methods are named with an ASV prefix (`time_*`, `peakmem_*`) and
whose `params`/`setup` attributes drive parameterized runs.

The benchmarks are intentionally isolated from the rest of the library: they
import the public Outlines API (`outlines.processors`, `outlines.models`,
`outlines.caching`) and exercise it exactly as a user would, so the measured
numbers reflect real-world usage.

## Purpose

- **Regression detection**: catch performance regressions in guide construction
  and logits masking before they reach users.
- **Cross-backend comparison**: measure the same operation across tensor
  libraries (torch, numpy, mlx, jax) and devices (CPU, CUDA, MPS).
- **Memory profiling**: track peak memory of guide construction for large
  vocabularies and complex grammars.

## Architecture

The module is a flat collection of ASV benchmark files plus a shared helper
module. Each benchmark file targets one area of the library.

```mermaid
graph TD
    subgraph benchmarks["benchmarks module"]
        Common["common.py<br/>setup_tokenizer()"]
        Regex["bench_regex_guide.py<br/>RegexGuideBenchmark<br/>MemoryRegexGuideBenchmark"]
        CFG["bench_cfg_guide.py<br/>CFGGuideBenchmark"]
        JSON["bench_json_schema.py<br/>JsonSchemaBenchmark"]
        Proc["bench_processors.py<br/>LogitsProcessorPassthroughBenchmark<br/>LogitsProcessorStructuredBenchmark<br/>HalvingLogitsProcessor"]
    end

    subgraph library["Outlines library (under test)"]
        Guides["outlines.processors.guide<br/>RegexGuide / CFGGuide"]
        Struct["outlines.processors.structured<br/>RegexLogitsProcessor"]
        Base["outlines.processors.base_logits_processor<br/>OutlinesLogitsProcessor"]
        Models["outlines.models<br/>transformers / tokenizer"]
        Cache["outlines.caching<br/>cache_disabled"]
    end

    Regex --> Guides
    CFG --> Guides
    JSON --> Guides
    Proc --> Struct
    Proc --> Base
    Regex --> Common
    CFG --> Common
    JSON --> Common
    Proc --> Models
    Regex --> Cache
    CFG --> Cache
    JSON --> Cache
    Proc --> Cache
```

### Shared infrastructure

| Component | Role |
|-----------|------|
| `benchmarks/common.py::setup_tokenizer` | Loads the GPT-2 tokenizer via `transformers` and wraps it in `TransformerTokenizer`. Used by the regex and JSON-schema benchmarks. |
| `benchmarks/asv.conf.json` | ASV configuration: project metadata, build command (`pip install .[test]`), environment type (`virtualenv`), and results/HTML output directories. |
| `outlines.caching.cache_disabled` | Context manager used by every timed method to disable Outlines' disk cache, ensuring each run measures the real computation rather than a cache hit. |

### Benchmark areas

The suite is organized into three logical areas, each documented in its own file:

| Area | File | Benchmarks | Documentation |
|------|------|-----------|---------------|
| Guide construction & execution | `bench_regex_guide.py`, `bench_cfg_guide.py` | `RegexGuideBenchmark`, `MemoryRegexGuideBenchmark`, `CFGGuideBenchmark` | [benchmarks_guide.md](benchmarks_guide.md) |
| Logits processor performance | `bench_processors.py` | `LogitsProcessorPassthroughBenchmark`, `LogitsProcessorStructuredBenchmark`, `HalvingLogitsProcessor` | [benchmarks_processors.md](benchmarks_processors.md) |
| JSON schema compilation | `bench_json_schema.py` | `JsonSchemaBenchmark` | [benchmarks_json_schema.md](benchmarks_json_schema.md) |

## Data Flow

A typical benchmark run follows the ASV lifecycle: `setup` prepares the inputs
(usually a tokenizer and a prebuilt guide), then each `time_*` / `peakmem_*`
method is executed repeatedly and timed.

```mermaid
sequenceDiagram
    participant ASV as ASV runner
    participant Bench as Benchmark class
    participant Lib as Outlines library

    ASV->>Bench: setup(params)
    Bench->>Lib: build tokenizer / guide
    Lib-->>Bench: prepared objects
    loop for each timed method
        ASV->>Bench: time_* / peakmem_*()
        Bench->>Lib: exercise API (cache disabled)
        Lib-->>Bench: result
        Bench-->>ASV: timing / memory sample
    end
    ASV->>ASV: aggregate & store results
```

## Relationship to Other Modules

- **[processors](processors.md)** — the guides (`RegexGuide`, `CFGGuide`) and
  logits processors (`RegexLogitsProcessor`, `OutlinesLogitsProcessor`) that the
  benchmarks measure are defined here.
- **[models](models.md)** — the benchmarks use `outlines.models.transformers`
  and `TransformerTokenizer` to obtain real tokenizers.
- **[types_dsl](types_dsl.md)** — the regex/CFG/JSON schema inputs benchmarked
  here correspond to the DSL types (`Regex`, `CFG`, `JsonSchema`) that the
  library compiles into guides.
- **[caching](caching.md)** — `cache_disabled` is used to isolate benchmark
  measurements from the disk cache.

## Running the Benchmarks

The suite is driven by ASV from the `benchmarks/` directory:

```bash
# Run all benchmarks once
asv run

# Run a specific benchmark file
asv run --bench bench_regex_guide

# Compare against a previous commit
asv continuous HEAD^ HEAD
```

Because the benchmarks import the library under test, the environment must have
Outlines installed (see the `build_command` in `asv.conf.json`). Optional
backends (mlx, jax, CUDA, MPS) are detected at import time and their benchmarks
are only registered when the corresponding hardware/library is available.
