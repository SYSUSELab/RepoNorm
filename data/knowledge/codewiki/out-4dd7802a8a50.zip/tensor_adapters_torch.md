# Tensor Adapters - Torch

## Introduction

The `tensor_adapters_torch` module provides the PyTorch implementation of the
[`TensorAdapter`](tensor_adapters_base.md) abstract interface. It enables the
Outlines logits processors to manipulate tensors using the `torch` library in a
library-agnostic way.

The `TorchTensorAdapter` is the concrete adapter used whenever a model is backed
by PyTorch tensors (e.g. the `Transformers`, `LlamaCpp`, `MLXLM`, and
`VLLMOffline` local models). By delegating all tensor operations to this adapter,
the structured-generation logic in the
[logits processors](processors_base.md) can remain independent of the underlying
tensor framework.

## Core Component

### `TorchTensorAdapter`

Located in `outlines/processors/tensor_adapters/torch.py`, this class implements
every abstract method defined by [`TensorAdapter`](tensor_adapters_base.md) using
the `torch` API.

| Attribute / Method | Description |
| --- | --- |
| `library_name` | Class attribute set to `"torch"`. Used by the adapter registry to select this implementation. |
| `__init__` | Lazily imports `torch` and stores it as `self.torch`, avoiding a hard import dependency at module load time. |
| `shape(tensor)` | Returns `tensor.shape`. |
| `unsqueeze(tensor)` | Adds a dimension at axis 0 via `tensor.unsqueeze(0)`. |
| `squeeze(tensor)` | Removes the dimension at axis 0 via `tensor.squeeze(0)`. |
| `to_list(tensor)` | Converts the tensor to a Python list via `tensor.tolist()`. |
| `to_scalar(tensor)` | Returns the single element via `tensor.item()`. |
| `full_like(tensor, fill_value)` | Creates a tensor of the same shape filled with `fill_value` via `torch.full_like`. |
| `concatenate(tensors)` | Concatenates a list of tensors along axis 0 via `torch.cat(tensors, dim=0)`. |
| `get_device(tensor)` | Returns `tensor.device`. |
| `to_device(tensor, device)` | Moves the tensor to `device` via `tensor.to(device)`. |
| `boolean_ones_like(tensor)` | Creates a boolean tensor of ones with the same shape via `torch.ones_like(..., dtype=torch.bool)`. |
| `apply_mask(tensor, mask, value)` | Fills elements where `mask` is `True` with `value` via `torch.masked_fill`. |
| `argsort_descending(tensor)` | Returns indices that sort the tensor in descending order via `torch.argsort(..., descending=True)`. |

## Architecture

The adapter sits between the framework-agnostic processor layer and the
PyTorch runtime. The processor never imports `torch` directly; instead it calls
methods on the adapter, which is resolved at runtime from the adapter registry.

```mermaid
graph TD
    subgraph "Processor Layer"
        OLP["OutlinesLogitsProcessor<br/>(base_logits_processor.py)"]
        GLP["GuideLogitsProcessor<br/>(structured.py)"]
    end

    subgraph "Adapter Layer"
        TA["TensorAdapter (ABC)<br/>tensor_adapters/base.py"]
        TTA["TorchTensorAdapter<br/>tensor_adapters/torch.py"]
    end

    subgraph "Runtime"
        TORCH["torch library"]
    end

    OLP -->|"resolves via registry"| TA
    GLP -->|"inherits"| OLP
    TA -->|"implements"| TTA
    TTA -->|"delegates calls"| TORCH
```

## Component Relationships

`TorchTensorAdapter` is one of several sibling implementations of the
[`TensorAdapter`](tensor_adapters_base.md) interface. Each adapter targets a
different tensor library but exposes an identical method surface.

```mermaid
classDiagram
    class TensorAdapter {
        <<abstract>>
        +str library_name
        +shape(tensor)
        +unsqueeze(tensor)
        +squeeze(tensor)
        +to_list(tensor)
        +to_scalar(tensor)
        +full_like(tensor, fill_value)
        +concatenate(tensors)
        +get_device(tensor)
        +to_device(tensor, device)
        +boolean_ones_like(tensor)
        +apply_mask(tensor, mask, value)
        +argsort_descending(tensor)
    }

    class TorchTensorAdapter {
        +str library_name = "torch"
        +__init__()
    }

    class NumpyTensorAdapter {
        +str library_name = "numpy"
    }

    class JAXTensorAdapter {
        +str library_name = "jax"
    }

    class MLXTensorAdapter {
        +str library_name = "mlx"
    }

    class TensorFlowTensorAdapter {
        +str library_name = "tensorflow"
    }

    TensorAdapter <|-- TorchTensorAdapter
    TensorAdapter <|-- NumpyTensorAdapter
    TensorAdapter <|-- JAXTensorAdapter
    TensorAdapter <|-- MLXTensorAdapter
    TensorAdapter <|-- TensorFlowTensorAdapter
```

## Data Flow

The following sequence shows how a logits processor uses the
`TorchTensorAdapter` during a single generation step. The processor standardizes
tensor shapes, computes a mask of disallowed tokens, and applies it to the
logits — all through adapter methods.

```mermaid
sequenceDiagram
    participant Model as PyTorch Model
    participant OLP as OutlinesLogitsProcessor
    participant TTA as TorchTensorAdapter
    participant Torch as torch

    Model->>OLP: __call__(input_ids, logits)
    OLP->>TTA: shape(input_ids) / shape(logits)
    TTA->>Torch: tensor.shape
    Torch-->>TTA: shape
    TTA-->>OLP: shape

    alt logits are 1D
        OLP->>TTA: unsqueeze(input_ids), unsqueeze(logits)
        TTA->>Torch: tensor.unsqueeze(0)
        Torch-->>TTA: 2D tensor
    end

    OLP->>OLP: process_logits(input_ids, logits)
    Note over OLP: Build allowed-token mask
    OLP->>TTA: full_like(allowed_tokens, batch_index)
    TTA->>Torch: torch.full_like
    OLP->>TTA: concatenate(allowed_tokens_batch)
    TTA->>Torch: torch.cat(..., dim=0)
    OLP->>TTA: get_device(logits)
    TTA->>Torch: tensor.device
    OLP->>TTA: to_device(tensor, device)
    TTA->>Torch: tensor.to(device)
    OLP->>TTA: boolean_ones_like(logits)
    TTA->>Torch: torch.ones_like(..., dtype=torch.bool)
    OLP->>TTA: apply_mask(logits, mask, -inf)
    TTA->>Torch: torch.masked_fill
    Torch-->>TTA: masked logits
    TTA-->>OLP: masked logits

    alt logits were originally 1D
        OLP->>TTA: squeeze(processed_logits)
        TTA->>Torch: tensor.squeeze(0)
    end

    OLP-->>Model: processed_logits
```

## Integration with the Processor Layer

The adapter is instantiated by
[`OutlinesLogitsProcessor.__init__`](processors_base.md), which looks up the
adapter class by the `tensor_library_name` argument. Passing `"torch"` selects
`TorchTensorAdapter`:

```python
from outlines.processors.base_logits_processor import OutlinesLogitsProcessor

# The processor resolves TorchTensorAdapter from the registry
processor = SomeLogitsProcessor(tensor_library_name="torch")
processor.tensor_adapter  # -> TorchTensorAdapter instance
```

The [`GuideLogitsProcessor`](processors_structured.md) is the primary consumer of
the adapter's methods. It relies on `full_like`, `concatenate`, `get_device`,
`to_device`, `boolean_ones_like`, and `apply_mask` to construct and apply the
token mask that biases generation toward guide-valid tokens.

## Design Notes

- **Lazy import**: `torch` is imported inside `__init__` rather than at module
  scope. This keeps the adapter importable even when PyTorch is not installed,
  which is important because the adapter registry may load all adapters.
- **Torch-tensor compatibility**: Per the note in
  [`TensorAdapter`](tensor_adapters_base.md), `full_like` and `concatenate` may
  receive plain `torch.Tensor` inputs regardless of the active library. The
  `TorchTensorAdapter` handles these natively since it operates on torch tensors
  directly.
- **Device handling**: Unlike the NumPy, JAX, and MLX adapters (which return
  `None` from `get_device` and are no-ops for `to_device`), the torch adapter
  reports the real device and performs actual device transfers, supporting
  GPU/CPU placement.

## Related Modules

- [Tensor Adapters - Base](tensor_adapters_base.md) — the abstract interface implemented here.
- [Tensor Adapters - NumPy](tensor_adapters_numpy.md) — NumPy implementation.
- [Tensor Adapters - JAX](tensor_adapters_jax.md) — JAX implementation.
- [Tensor Adapters - MLX](tensor_adapters_mlx.md) — MLX implementation.
- [Tensor Adapters - TensorFlow](tensor_adapters_tensorflow.md) — TensorFlow implementation.
- [Processors - Base](processors_base.md) — instantiates and uses the adapter.
- [Processors - Structured](processors_structured.md) — primary consumer of adapter methods.
