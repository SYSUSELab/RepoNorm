# Models Server

## Introduction

The `models_server` module provides Outlines integrations for **self-hosted inference servers** that expose an OpenAI-compatible or HuggingFace-compatible HTTP API. Unlike the local model integrations (see [models_local.md](models_local.md)) which run inference in-process, these integrations delegate generation to a remote server process (vLLM, SGLang, or TGI) and communicate with it over the network.

The module contains three server integrations:

| Server | File | Client Library | Structured Output Mechanism |
|--------|------|----------------|-----------------------------|
| **vLLM** | `outlines/models/vllm.py` | `openai.OpenAI` / `openai.AsyncOpenAI` | `guided_grammar`, `guided_json`, `guided_regex` (via `extra_body`) |
| **SGLang** | `outlines/models/sglang.py` | `openai.OpenAI` / `openai.AsyncOpenAI` | `ebnf`, `regex` (via `extra_body`), JSON via `response_format` |
| **TGI** | `outlines/models/tgi.py` | `huggingface_hub.InferenceClient` / `AsyncInferenceClient` | `grammar` (`json` or `regex`) |

Each integration follows the same three-part pattern:

1. A **`Model`** subclass (synchronous) — e.g. `VLLM`, `SGLang`, `TGI`.
2. An **`AsyncModel`** subclass (asynchronous) — e.g. `AsyncVLLM`, `AsyncSGLang`, `AsyncTGI`.
3. A **`ModelTypeAdapter`** subclass — e.g. `VLLMTypeAdapter`, `SGLangTypeAdapter`, `TGITypeAdapter` — that translates Outlines input/output types into the server-specific request arguments.

A module-level `from_<server>` factory function (`from_vllm`, `from_sglang`, `from_tgi`) constructs the correct sync/async wrapper from a user-supplied client instance.

## Architecture

All server integrations build on the abstract base classes defined in [models_base.md](models_base.md). The base classes define the `generate` / `generate_stream` contract and the `type_adapter` mechanism, while each server integration supplies the concrete client calls and request formatting.

```mermaid
graph TD
    subgraph "models_base"
        Model["Model (ABC)"]
        AsyncModel["AsyncModel (ABC)"]
        ModelTypeAdapter["ModelTypeAdapter (ABC)"]
    end

    subgraph "models_server"
        VLLM["VLLM"]
        AsyncVLLM["AsyncVLLM"]
        VLLMTypeAdapter["VLLMTypeAdapter"]

        SGLang["SGLang"]
        AsyncSGLang["AsyncSGLang"]
        SGLangTypeAdapter["SGLangTypeAdapter"]

        TGI["TGI"]
        AsyncTGI["AsyncTGI"]
        TGITypeAdapter["TGITypeAdapter"]
    end

    subgraph "External Clients"
        OpenAIClient["openai.OpenAI / AsyncOpenAI"]
        HFClient["huggingface_hub.InferenceClient / AsyncInferenceClient"]
    end

    Model --> VLLM
    Model --> SGLang
    Model --> TGI
    AsyncModel --> AsyncVLLM
    AsyncModel --> AsyncSGLang
    AsyncModel --> AsyncTGI

    ModelTypeAdapter --> VLLMTypeAdapter
    ModelTypeAdapter --> SGLangTypeAdapter
    ModelTypeAdapter --> TGITypeAdapter

    VLLM --> VLLMTypeAdapter
    AsyncVLLM --> VLLMTypeAdapter
    SGLang --> SGLangTypeAdapter
    AsyncSGLang --> SGLangTypeAdapter
    TGI --> TGITypeAdapter
    AsyncTGI --> TGITypeAdapter

    VLLM --> OpenAIClient
    AsyncVLLM --> OpenAIClient
    SGLang --> OpenAIClient
    AsyncSGLang --> OpenAIClient
    TGI --> HFClient
    AsyncTGI --> HFClient
```

## Component Relationships

The following diagram shows how the type adapters reuse shared formatting logic. Both `VLLMTypeAdapter` and `SGLangTypeAdapter` delegate input formatting to `OpenAITypeAdapter` (from [models_api.md](models_api.md)) because both servers accept OpenAI-style `messages` payloads. `TGITypeAdapter` uses a `singledispatchmethod` to handle input types directly.

```mermaid
graph LR
    subgraph "Shared Formatting"
        OpenAITypeAdapter["OpenAITypeAdapter<br/>(models_api)"]
        DSL["types.dsl<br/>python_types_to_terms / to_regex"]
        Vision["templates.Vision"]
    end

    VLLMTypeAdapter["VLLMTypeAdapter"] --> OpenAITypeAdapter
    VLLMTypeAdapter --> DSL
    VLLMTypeAdapter --> Vision

    SGLangTypeAdapter["SGLangTypeAdapter"] --> OpenAITypeAdapter
    SGLangTypeAdapter --> DSL
    SGLangTypeAdapter --> Vision

    TGITypeAdapter["TGITypeAdapter"] --> DSL
```

## Data Flow

The end-to-end flow for a generation request is identical across all three servers; only the request-argument construction and the underlying client call differ.

```mermaid
sequenceDiagram
    participant User
    participant Model as Model (VLLM/SGLang/TGI)
    participant Adapter as TypeAdapter
    participant Client as External Client
    participant Server as Inference Server

    User->>Model: generate(model_input, output_type, **kwargs)
    Model->>Model: _build_client_args(...)
    Model->>Adapter: format_input(model_input)
    Adapter-->>Model: messages / prompt
    Model->>Adapter: format_output_type(output_type)
    Adapter-->>Model: structured-output args
    Model->>Client: create(**client_args) / text_generation(**client_args)
    Client->>Server: HTTP request
    Server-->>Client: response
    Client-->>Model: response object
    Model->>Model: extract message content / refusal check
    Model-->>User: str or list[str]
```

## vLLM Integration

**File:** `outlines/models/vllm.py`

The vLLM integration wraps an `openai.OpenAI` (or `openai.AsyncOpenAI`) client pointed at a vLLM server. Because vLLM exposes an OpenAI-compatible chat completions endpoint, input formatting is delegated entirely to `OpenAITypeAdapter`.

### `VLLMTypeAdapter`

| Method | Behavior |
|--------|----------|
| `format_input` | Delegates to `OpenAITypeAdapter().format_input` to produce the `messages` argument. |
| `format_output_type` | Converts the Outlines output type into vLLM's guided-decoding arguments. |

`format_output_type` maps Outlines DSL terms to vLLM request fields:

- `CFG` → `{"guided_grammar": term.definition}`
- `JsonSchema` → `{"guided_json": <schema>}` (plus `whitespace_pattern` if set)
- Any other term → `{"guided_regex": to_regex(term)}`

### `VLLM` / `AsyncVLLM`

Both classes store the client, an optional `model_name`, and a `VLLMTypeAdapter`. They implement:

- `generate` — calls `client.chat.completions.create(**client_args)`, checks each choice's `message.refusal`, and returns a single string (one choice) or a list of strings (multiple choices).
- `generate_stream` — calls the same endpoint with `stream=True` and yields `chunk.choices[0].delta.content`.
- `_build_client_args` — merges formatted messages, output-type args (placed inside `extra_body`), and inference kwargs. The `model_name` is injected as the `model` argument when not already provided.

### `from_vllm`

Factory that inspects the client type and returns `VLLM` for `OpenAI` or `AsyncVLLM` for `AsyncOpenAI`, raising `ValueError` otherwise.

## SGLang Integration

**File:** `outlines/models/sglang.py`

The SGLang integration also wraps an OpenAI-compatible client. Its type adapter differs from vLLM's in how structured outputs are expressed.

### `SGLangTypeAdapter`

| Method | Behavior |
|--------|----------|
| `format_input` | Delegates to `OpenAITypeAdapter().format_input`. |
| `format_output_type` | Maps Outlines terms to SGLang request fields. |

`format_output_type` maps terms as follows:

- `CFG` → `{"extra_body": {"ebnf": term.definition}}`. A warning is emitted because SGLang expects an **EBNF** grammar rather than the Lark grammar generally used in Outlines; such a grammar is only compatible with the sglang and llguidance backends.
- `JsonSchema` → delegates to `OpenAITypeAdapter().format_json_output_type(...)`, producing a `response_format` argument.
- Any other term → `{"extra_body": {"regex": to_regex(term)}}`.

### `SGLang` / `AsyncSGLang`

These mirror the vLLM classes. The key difference is in `_build_client_args`: instead of nesting output-type args inside `extra_body`, SGLang **merges them directly** into `inference_kwargs` (since the adapter already wraps regex/ebnf args in `extra_body` and returns `response_format` for JSON).

### `from_sglang`

Factory returning `SGLang` for `OpenAI` or `AsyncSGLang` for `AsyncOpenAI`.

## TGI Integration

**File:** `outlines/models/tgi.py`

The TGI integration wraps a `huggingface_hub.InferenceClient` (or `AsyncInferenceClient`) and uses the `text_generation` endpoint rather than chat completions.

### `TGITypeAdapter`

| Method | Behavior |
|--------|----------|
| `format_input` | A `singledispatchmethod`. `str` inputs pass through unchanged; `list` inputs raise `NotImplementedError` (TGI does not support batch inference); other types raise `NotImplementedError`. |
| `format_output_type` | Maps Outlines terms to TGI's `grammar` argument. |

`format_output_type` maps terms as follows:

- `CFG` → raises `NotImplementedError` (TGI does not support CFG-based structured outputs).
- `JsonSchema` → `{"grammar": {"type": "json", "value": <schema>}}`.
- Any other term → `{"grammar": {"type": "regex", "value": to_regex(term)}}`.

### `TGI` / `AsyncTGI`

- `generate` — calls `client.text_generation(**client_args)` and returns the generated string.
- `generate_stream` — calls `text_generation(..., stream=True)` and yields each chunk.
- `_build_client_args` — builds `{"prompt": prompt, **inference_kwargs}` where the prompt comes from `format_input` and the grammar args are merged into `inference_kwargs`.

Note that TGI does not perform a refusal check (unlike vLLM/SGLang) and does not support batch inference.

### `from_tgi`

Factory returning `TGI` for `InferenceClient` or `AsyncTGI` for `AsyncInferenceClient`.

## Structured Output Support Matrix

The following table summarizes which Outlines output types each server supports and how they are transmitted.

| Output Type | vLLM | SGLang | TGI |
|-------------|------|--------|-----|
| `JsonSchema` | `extra_body.guided_json` | `response_format` (json_schema) | `grammar.type = "json"` |
| `Regex` / other terms | `extra_body.guided_regex` | `extra_body.regex` | `grammar.type = "regex"` |
| `CFG` | `extra_body.guided_grammar` | `extra_body.ebnf` (EBNF, with warning) | ❌ Not supported |
| Batch inference | ✅ (multiple choices) | ✅ (multiple choices) | ❌ Not supported |

## Process Flow: Building Client Arguments

The `_build_client_args` method is the central point where input, output type, and inference kwargs are combined. The flow differs slightly per server:

```mermaid
flowchart TD
    Start([generate called]) --> FI["type_adapter.format_input(model_input)"]
    FI --> FOT["type_adapter.format_output_type(output_type)"]

    FOT --> Branch{Server}

    Branch -->|vLLM| V1["extra_body = kwargs.pop('extra_body', {})"]
    V1 --> V2["extra_body.update(output_type_args)"]
    V2 --> V3["inject model_name if absent"]
    V3 --> V4["client_args = {**messages, **kwargs, extra_body}"]

    Branch -->|SGLang| S1["kwargs.update(output_type_args)"]
    S1 --> S2["inject model_name if absent"]
    S2 --> S3["client_args = {**messages, **kwargs}"]

    Branch -->|TGI| T1["kwargs.update(output_type_args)"]
    T1 --> T2["client_args = {prompt, **kwargs}"]

    V4 --> Call["client.chat.completions.create(**client_args)"]
    S3 --> Call
    T2 --> TGICall["client.text_generation(**client_args)"]
```

## Relationship to Other Modules

- **[models_base.md](models_base.md)** — Defines `Model`, `AsyncModel`, and `ModelTypeAdapter`, the abstract contracts implemented by every class in this module.
- **[models_api.md](models_api.md)** — Provides `OpenAITypeAdapter`, which `VLLMTypeAdapter` and `SGLangTypeAdapter` reuse for input formatting and (for SGLang) JSON output formatting.
- **[models_local.md](models_local.md)** — The in-process counterpart to this module; local models apply logits processors directly rather than sending structured-output arguments to a server.
- **[models_tokenizer.md](models_tokenizer.md)** — Tokenizer abstractions; server integrations do not require a local tokenizer since tokenization happens server-side.
- **[generator.md](generator.md)** — The `Generator` class used by `Model.__call__` and `Model.stream` to wrap these models.
- **[types_dsl.md](types_dsl.md)** — Provides `python_types_to_terms`, `to_regex`, `CFG`, and `JsonSchema`, used by every type adapter to translate output types.
- **[templates.md](templates.md)** — Provides the `Vision` input type accepted by vLLM and SGLang (via `OpenAITypeAdapter`).

## Usage Example

```python
from openai import OpenAI
from outlines import models

client = OpenAI(base_url="http://localhost:8000/v1", api_key="EMPTY")
model = models.from_vllm(client, model_name="meta-llama/Llama-3-8B-Instruct")

# Unstructured generation
response = model("What is the capital of France?")

# Structured generation with a JSON schema
from pydantic import BaseModel

class Answer(BaseModel):
    capital: str
    population: int

response = model("Describe Paris.", Answer)
```

The same pattern applies to SGLang (`models.from_sglang`) and TGI (`models.from_tgi`), substituting the appropriate client instance.
