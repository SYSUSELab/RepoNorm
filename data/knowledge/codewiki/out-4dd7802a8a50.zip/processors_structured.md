# Structured Logits Processors

## Introduction

The `processors_structured` module provides the concrete **logits processors** that
Outlines uses to enforce *structured generation* — constraining a language model's
output to follow a regular expression, a JSON schema, or a context-free grammar
(CFG). Each processor biases the model's next-token logits so that only tokens
that keep the generation on a valid path are sampled.

The module is built around a small class hierarchy rooted at
[`OutlinesLogitsProcessor`](processors_base.md):

```
OutlinesLogitsProcessor
└── GuideLogitsProcessor          # generic guide-driven masking
    ├── RegexLogitsProcessor      # regex-constrained generation
    │   └── JSONLogitsProcessor   # JSON-schema-constrained generation
    └── CFGLogitsProcessor        # grammar-constrained generation (rejection sampling)
```

All four classes live in `outlines/processors/structured.py` and share the same
public contract: they are callables that accept `(input_ids, logits)` and return
masked logits.

---

## Architecture Overview

The processors sit between the model's raw logits and the sampling step. They
translate a *structural specification* (regex / JSON schema / CFG) into a
[`Guide`](processors_guides.md) — a finite-state machine that knows which tokens
are legal at each generation step — and then use that guide to mask the logits.

```mermaid
graph TD
    subgraph "Structural Specifications"
        RE["Regex string"]
        JS["JSON schema<br/>(dict / Pydantic / str)"]
        CFG["CFG string (Lark)"]
    end

    subgraph "processors_structured"
        RLP["RegexLogitsProcessor"]
        JLP["JSONLogitsProcessor"]
        CLP["CFGLogitsProcessor"]
        GLP["GuideLogitsProcessor"]
    end

    subgraph "processors_guides"
        RG["RegexGuide"]
        CG["CFGGuide"]
    end

    subgraph "processors_base"
        OLP["OutlinesLogitsProcessor"]
    end

    subgraph "processors_tensor_adapters"
        TA["TensorAdapter"]
    end

    RE --> RLP
    JS --> JLP
    CFG --> CLP

    RLP -->|builds| RG
    JLP -->|builds regex then| RLP
    CLP -->|builds| CG

    RLP --> GLP
    CLP --> GLP
    GLP --> OLP
    OLP --> TA
```

### Key design points

- **Guide-driven masking.** `GuideLogitsProcessor` is the workhorse: it maintains
  a cache of guide states keyed by the generated token sequence and computes an
  allowed-token mask for each sequence in the batch.
- **Inheritance for specialization.** `RegexLogitsProcessor` and
  `CFGLogitsProcessor` only differ in *how they build the guide*; they reuse the
  masking logic of the parent. `JSONLogitsProcessor` reuses the regex path after
  converting the schema to a regex.
- **Library-agnostic tensors.** All tensor manipulation is delegated to a
  [`TensorAdapter`](processors_tensor_adapters.md) selected by
  `tensor_library_name` (e.g. `"torch"`, `"numpy"`, `"jax"`, `"mlx"`,
  `"tensorflow"`), so the same processor works across backends.

---

## Component Reference

### `GuideLogitsProcessor`

The base class for all guide-based processors. It owns the tokenizer, the guide,
and a state cache.

| Attribute | Type | Description |
|-----------|------|-------------|
| `tokenizer` | `Tokenizer` | Converts tokens to ids and back. |
| `guide` | `Guide` | The FSM that defines legal continuations. |
| `_guide_states` | `Dict[int, Any]` | Cache mapping a hash of the generated token tuple to a guide state. |
| `_seq_start_idx` | `Optional[int]` | Index where generation starts (set on first call), used to strip prompt tokens. |

**Constructor**

```python
GuideLogitsProcessor(tokenizer, guide, tensor_library_name)
```

Initializes the state cache with the guide's `initial_state` under the hash of an
empty tuple, and sets `_seq_start_idx` to `None`.

**`process_logits(input_ids, logits) -> TensorType`**

The core masking algorithm:

1. On the first call, record `_seq_start_idx = len(input_ids[0])` so that prompt
   tokens are excluded from state tracking.
2. For each sequence in the batch, compute the generated ids
   (`seq_ids[_seq_start_idx:]`) and derive a cache key from their hash.
3. If the key is not cached, look up the previous state and advance it with
   `guide.get_next_state(prev_state, last_token)`.
4. For each sequence state, fetch the allowed tokens via
   `guide.get_next_instruction(state).tokens`.
5. Build a boolean mask (all `True` = disallowed), set allowed positions to
   `False`, and apply it with `float("-inf")` so disallowed tokens get zero
   probability.

**`copy() -> GuideLogitsProcessor`**

Returns a fresh processor with a copied guide, so processors are single-use and
never re-applied to a new sequence generator.

---

### `RegexLogitsProcessor`

```python
RegexLogitsProcessor(regex_string, tokenizer, tensor_library_name)
```

Subclass of `GuideLogitsProcessor` that builds a
[`RegexGuide`](processors_guides.md) from a regex string via
`RegexGuide.from_regex(regex_string, tokenizer)` and delegates all masking to the
parent. It overrides the `guide` attribute type to `RegexGuide`.

---

### `JSONLogitsProcessor`

```python
JSONLogitsProcessor(schema, tokenizer, tensor_library_name, whitespace_pattern=None)
```

Subclass of `RegexLogitsProcessor`. It converts a JSON schema into a regex and
then reuses the regex pipeline:

1. Normalize the schema with
   [`JsonSchema(schema).schema`](types_dsl.md) — accepting a `dict`, a Pydantic
   `BaseModel`, or a JSON string.
2. Convert the schema string to a regex with
   `build_regex_from_schema(schema_str, whitespace_pattern)` (from
   `outlines_core`).
3. Call `RegexLogitsProcessor.__init__` with the resulting regex.

The optional `whitespace_pattern` controls JSON syntactic whitespace (it does not
affect string literals), e.g. `r"[\n ]?"` to allow only a single space or newline.

---

### `CFGLogitsProcessor`

```python
CFGLogitsProcessor(cfg_str, tokenizer, tensor_library_name)
```

Subclass of `GuideLogitsProcessor` that builds a
[`CFGGuide`](processors_guides.md) from a Lark grammar string. It **overrides
`process_logits`** to use a different masking strategy.

**`process_logits(input_ids, logits) -> TensorType`**

Instead of masking *all* allowed tokens, the CFG processor uses **rejection
sampling**:

1. Compute the guide state for each sequence (same state-tracking logic as the
   parent).
2. Initialize a mask filled with `-math.inf`.
3. For each sequence, sort the logits in descending order
   (`argsort_descending`) and pick the **first legal token** via
   `guide.iter_valid_token_ids(state, sorted_indices)`.
4. Keep only that single token's logit; everything else is `-inf`.

This is more efficient for CFGs, where enumerating every valid token per step is
expensive, but it changes the sampling distribution (it always picks the
highest-probability legal token rather than renormalizing over all legal tokens).

> **Note:** CFG structured generation is experimental and emits a warning on
> construction. See the [CFG guide documentation](processors_guides.md) for
> details.

---

## Data Flow

The following sequence diagram shows how a single generation step flows through a
`GuideLogitsProcessor` (the regex/JSON path).

```mermaid
sequenceDiagram
    participant Model
    participant OLP as OutlinesLogitsProcessor.__call__
    participant GLP as GuideLogitsProcessor.process_logits
    participant Guide
    participant TA as TensorAdapter

    Model->>OLP: (input_ids, logits)
    OLP->>OLP: normalize to 2D tensors
    OLP->>GLP: process_logits(input_ids, logits)
    loop for each sequence
        GLP->>TA: to_list(gen_ids)
        GLP->>GLP: compute state cache key
        alt state not cached
            GLP->>Guide: get_next_state(prev_state, last_token)
        end
        GLP->>Guide: get_next_instruction(state).tokens
    end
    GLP->>TA: concatenate allowed tokens + batch indices
    GLP->>TA: boolean_ones_like(logits)
    GLP->>TA: apply_mask(logits, mask, -inf)
    GLP-->>OLP: masked logits
    OLP-->>Model: masked logits
```

### CFG rejection-sampling flow

```mermaid
flowchart TD
    A["process_logits(input_ids, logits)"] --> B["Compute guide state per sequence"]
    B --> C["mask = full_like(logits, -inf)"]
    C --> D{"For each sequence i"}
    D --> E["sorted = argsort_descending(logits[i])"]
    E --> F["first_legal = next(iter_valid_token_ids(state, sorted))"]
    F --> G["mask[i, first_legal] = logits[i, first_legal]"]
    G --> D
    D --> H["return mask"]
```

---

## Class Hierarchy & Dependencies

```mermaid
classDiagram
    class OutlinesLogitsProcessor {
        +TensorAdapter tensor_adapter
        +__call__(input_ids, logits)
        +process_logits(input_ids, logits)*
    }
    class GuideLogitsProcessor {
        +Tokenizer tokenizer
        +Guide guide
        +Dict _guide_states
        +int _seq_start_idx
        +process_logits(input_ids, logits)
        +copy()
    }
    class RegexLogitsProcessor {
        +RegexGuide guide
    }
    class JSONLogitsProcessor
    class CFGLogitsProcessor {
        +CFGGuide guide
        +process_logits(input_ids, logits)
    }

    OutlinesLogitsProcessor <|-- GuideLogitsProcessor
    GuideLogitsProcessor <|-- RegexLogitsProcessor
    RegexLogitsProcessor <|-- JSONLogitsProcessor
    GuideLogitsProcessor <|-- CFGLogitsProcessor
```

### External dependencies

| Dependency | Used by | Purpose |
|------------|---------|---------|
| [`OutlinesLogitsProcessor`](processors_base.md) | all | Base class, tensor normalization, `__call__` entrypoint. |
| [`Guide` / `RegexGuide` / `CFGGuide`](processors_guides.md) | all | FSM that defines legal tokens and state transitions. |
| [`TensorAdapter`](processors_tensor_adapters.md) | all | Backend-agnostic tensor operations. |
| [`Tokenizer`](models_tokenizer.md) | all | Token ↔ id conversion, vocabulary, EOS handling. |
| [`JsonSchema`](types_dsl.md) | `JSONLogitsProcessor` | Normalizes dict/Pydantic/str schemas to a JSON string. |
| `outlines_core.fsm.json_schema.build_regex_from_schema` | `JSONLogitsProcessor` | Converts a JSON schema to a regex. |

---

## Usage Examples

### Regex-constrained generation

```python
from outlines.processors import RegexLogitsProcessor

processor = RegexLogitsProcessor(
    regex_string=r"\d{3}-\d{4}",
    tokenizer=tokenizer,
    tensor_library_name="torch",
)
```

### JSON-schema-constrained generation

```python
from pydantic import BaseModel
from outlines.processors import JSONLogitsProcessor

class User(BaseModel):
    name: str
    age: int

processor = JSONLogitsProcessor(
    schema=User,
    tokenizer=tokenizer,
    tensor_library_name="torch",
    whitespace_pattern=r"[\n ]?",
)
```

### CFG-constrained generation

```python
from outlines.processors import CFGLogitsProcessor

processor = CFGLogitsProcessor(
    cfg_str="?start: expr\n...",
    tokenizer=tokenizer,
    tensor_library_name="torch",
)
```

---

## Design Considerations

- **Single-use processors.** As documented in
  [`OutlinesLogitsProcessor`](processors_base.md), a logits processor is applied
  once and never re-applied to a new sequence generator. Use `copy()` to obtain a
  fresh instance with an independent guide.
- **State caching.** `_guide_states` avoids recomputing guide transitions for
  repeated prefixes, which is important for batched generation where sequences
  share prefixes.
- **Prompt stripping.** `_seq_start_idx` is captured on the first call so that
  only *generated* tokens drive the guide state, regardless of whether the model
  passes only output ids or prefixes with input ids.
- **Backend portability.** Because all tensor ops go through the
  `TensorAdapter`, the same processor logic works for torch, numpy, jax, mlx, and
  tensorflow models.
- **CFG vs. regex masking.** Regex/JSON processors renormalize over *all* legal
  tokens; the CFG processor uses rejection sampling and keeps only the single
  highest-probability legal token, trading distributional fidelity for speed.

---

## Related Modules

- [processors_base.md](processors_base.md) — `OutlinesLogitsProcessor` base class and the `__call__` contract.
- [processors_guides.md](processors_guides.md) — `Guide`, `RegexGuide`, `CFGGuide`, `StopAtEOSGuide`.
- [processors_tensor_adapters.md](processors_tensor_adapters.md) — backend-specific tensor operations.
- [types_dsl.md](types_dsl.md) — `JsonSchema` and other structural type definitions.
- [models_tokenizer.md](models_tokenizer.md) — the `Tokenizer` protocol.
