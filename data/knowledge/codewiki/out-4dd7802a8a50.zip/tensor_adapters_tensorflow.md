# TensorFlow Tensor Adapter

## Introduction

The `tensor_adapters_tensorflow` module provides the `TensorFlowTensorAdapter` class, a concrete implementation of the abstract [`TensorAdapter`](tensor_adapters_base.md) interface for the [TensorFlow](https://www.tensorflow.org/) library. It enables Outlines' logits processors to manipulate tensors using TensorFlow's API, allowing structured generation (regex, JSON schema, CFG, etc.) to work seamlessly with TensorFlow-based models.

This adapter is one of several library-specific implementations (alongside [Torch](tensor_adapters_torch.md), [NumPy](tensor_adapters_numpy.md), [JAX](tensor_adapters_jax.md), and [MLX](tensor_adapters_mlx.md)) that share a common interface. The correct adapter is selected at runtime based on the `tensor_library_name` passed to a logits processor.

## Purpose and Core Functionality

The module's single responsibility is to translate the generic tensor operations required by Outlines' logits processors into TensorFlow equivalents. This abstraction decouples the structured-generation logic from any specific tensor framework.

Key responsibilities:

- **Shape manipulation**: `shape`, `unsqueeze`, `squeeze`
- **Conversion**: `to_list`, `to_scalar`
- **Tensor creation**: `full_like`, `boolean_ones_like`
- **Combining tensors**: `concatenate`
- **Device management**: `get_device`, `to_device`
- **Masking and sorting**: `apply_mask`, `argsort_descending`

## Architecture

The adapter sits between the framework-agnostic logits processors and the TensorFlow runtime.

```mermaid
graph TD
    A[OutlinesLogitsProcessor] -->|uses| B[TensorAdapter ABC]
    B -->|implements| C[TensorFlowTensorAdapter]
    C -->|calls| D[TensorFlow API tf]
    A -->|subclass| E[GuideLogitsProcessor]
    A -->|subclass| F[RegexLogitsProcessor]
    A -->|subclass| G[JSONLogitsProcessor]
    A -->|subclass| H[CFGLogitsProcessor]
```

The `TensorFlowTensorAdapter` is instantiated lazily by the logits processor's constructor, which looks up the adapter class from a registry keyed by `library_name` (`"tensorflow"`).

## Component Relationships

```mermaid
classDiagram
    class TensorAdapter {
        <<abstract>>
        +str library_name
        +shape(tensor)
        +unsqueeze(tensor)
        +squeeze(tensor)
        +to_list(tensor)
        +to_scalar(tensor)
        +full_like(tensor, fill_value)
        +concatenate(tensors)
        +get_device(tensor)
        +to_device(tensor, device)
        +boolean_ones_like(tensor)
        +apply_mask(tensor, mask, value)
        +argsort_descending(tensor)
    }
    class TensorFlowTensorAdapter {
        +str library_name = "tensorflow"
        +tf
        +__init__()
    }
    TensorAdapter <|-- TensorFlowTensorAdapter
```

## Method Reference

| Method | TensorFlow Implementation | Notes |
|--------|---------------------------|-------|
| `shape(tensor)` | `tensor.shape` | Returns the tensor's shape. |
| `unsqueeze(tensor)` | `tf.expand_dims(tensor, axis=0)` | Adds a dimension at axis 0. |
| `squeeze(tensor)` | `tf.squeeze(tensor, axis=0)` | Removes the dimension at axis 0. |
| `to_list(tensor)` | `tensor.numpy().tolist()` | Converts to a Python list via NumPy. |
| `to_scalar(tensor)` | `tensor.numpy().item()` | Extracts the single element. |
| `full_like(tensor, fill_value)` | `tf.fill(tf.shape(tensor), fill_value)` | Creates a tensor of the same shape filled with a value. |
| `concatenate(tensors)` | `tf.concat(tensors, axis=0)` | Concatenates along axis 0. |
| `get_device(tensor)` | `tensor.device` | Returns the device string. |
| `to_device(tensor, device)` | `tf.device(device)` + `tf.identity(tensor)` | Moves tensor using a device scope. |
| `boolean_ones_like(tensor)` | `tf.ones_like(tensor, dtype=tf.bool)` | Boolean ones tensor of the same shape. |
| `apply_mask(tensor, mask, value)` | `tf.where(mask, tf.constant(value, dtype=tensor.dtype), tensor)` | Fills masked positions with `value`. |
| `argsort_descending(tensor)` | `tf.argsort(tensor, direction='DESCENDING')` | Indices that sort descending along the last axis. |

### TensorFlow-Specific Considerations

- **Device placement**: Unlike PyTorch's `.to(device)`, TensorFlow uses a device *scope*. The adapter wraps `tf.identity` inside `with self.tf.device(device):` to force placement on the target device.
- **Eager execution**: `to_list` and `to_scalar` rely on `.numpy()`, which requires eager execution (the default in TF2). In graph mode these calls would fail.
- **Masking**: `apply_mask` uses `tf.where`, which is non-mutating and returns a new tensor, consistent with TensorFlow's functional style.

## Data Flow

The following sequence shows how a logits processor uses the adapter during a generation step (e.g., `GuideLogitsProcessor.process_logits`).

```mermaid
sequenceDiagram
    participant Model
    participant Processor as OutlinesLogitsProcessor
    participant Adapter as TensorFlowTensorAdapter
    participant TF as TensorFlow

    Model->>Processor: __call__(input_ids, logits)
    Processor->>Adapter: shape(input_ids), shape(logits)
    Adapter->>TF: tensor.shape
    Processor->>Processor: normalize to 2D
    Processor->>Processor: process_logits(input_ids, logits)
    Processor->>Adapter: full_like(allowed_tokens, i)
    Adapter->>TF: tf.fill(...)
    Processor->>Adapter: concatenate(batches)
    Adapter->>TF: tf.concat(...)
    Processor->>Adapter: get_device(logits)
    Adapter->>TF: tensor.device
    Processor->>Adapter: to_device(tensor, device)
    Adapter->>TF: tf.device + tf.identity
    Processor->>Adapter: boolean_ones_like(logits)
    Adapter->>TF: tf.ones_like(..., dtype=tf.bool)
    Processor->>Adapter: apply_mask(logits, mask, -inf)
    Adapter->>TF: tf.where(...)
    Processor-->>Model: processed logits
```

## Integration with the Processor System

The adapter is consumed by [`OutlinesLogitsProcessor`](processors_base.md) and its subclasses. The base processor:

1. Accepts a `tensor_library_name` argument (e.g., `"tensorflow"`).
2. Looks up the corresponding adapter class in the `tensor_adapters` registry.
3. Instantiates it and stores it as `self.tensor_adapter`.
4. Uses the adapter throughout `__call__` and `process_logits` to normalize shapes and manipulate tensors.

```mermaid
flowchart LR
    A[tensor_library_name='tensorflow'] --> B[registry lookup]
    B --> C[TensorFlowTensorAdapter]
    C --> D[self.tensor_adapter]
    D --> E[process_logits]
```

For details on the processor lifecycle and the structured-generation subclasses, see:

- [processors_base.md](processors_base.md) — `OutlinesLogitsProcessor`
- [processors_structured.md](processors_structured.md) — `GuideLogitsProcessor`, `RegexLogitsProcessor`, `JSONLogitsProcessor`, `CFGLogitsProcessor`
- [processors_guides.md](processors_guides.md) — `Guide`, `RegexGuide`, `CFGGuide`

## Dependencies

```mermaid
graph TD
    A[TensorFlowTensorAdapter] --> B[TensorAdapter ABC]
    A --> C[tensorflow]
    B --> D[torch - type hints only]
```

- **Internal**: [`TensorAdapter`](tensor_adapters_base.md) (abstract base class).
- **External**: `tensorflow` (imported lazily inside `__init__` to avoid a hard dependency at import time).
- **Type hints**: The base class references `torch.Tensor` in `full_like` and `concatenate` signatures, but the TensorFlow implementation does not require torch at runtime.

## Related Modules

- [tensor_adapters_base.md](tensor_adapters_base.md) — The abstract `TensorAdapter` interface.
- [tensor_adapters_torch.md](tensor_adapters_torch.md) — PyTorch implementation.
- [tensor_adapters_numpy.md](tensor_adapters_numpy.md) — NumPy implementation.
- [tensor_adapters_jax.md](tensor_adapters_jax.md) — JAX implementation.
- [tensor_adapters_mlx.md](tensor_adapters_mlx.md) — MLX implementation.
- [processors_base.md](processors_base.md) — Base logits processor that consumes adapters.
