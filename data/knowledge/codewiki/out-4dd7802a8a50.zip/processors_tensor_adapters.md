# Tensor Adapters

## Introduction

The `processors_tensor_adapters` module provides a unified abstraction layer for manipulating tensors across multiple numerical computing libraries. It enables Outlines' logits processors to operate seamlessly with models built on **PyTorch**, **NumPy**, **JAX**, **MLX**, and **TensorFlow** without duplicating tensor-manipulation logic.

The module is built around a single abstract base class, [`TensorAdapter`](#tensoradapter), and five concrete implementations, one per supported library. Each adapter exposes an identical set of operations (shape inspection, dimension manipulation, masking, device movement, etc.), so that higher-level components such as [`OutlinesLogitsProcessor`](processors_base.md) and [`GuideLogitsProcessor`](processors_structured.md) can remain library-agnostic.

> **Note:** This module is a sub-module of the broader [processors](processors.md) package. For information about how logits processors consume these adapters, see the [processors base](processors_base.md) and [structured processors](processors_structured.md) documentation.

---

## Architecture

The module follows a classic **Strategy pattern**: the abstract `TensorAdapter` defines the interface, and each concrete adapter encapsulates the library-specific implementation details.

```mermaid
classDiagram
    class TensorAdapter {
        <<abstract>>
        +str library_name
        +shape(tensor) list[int]
        +unsqueeze(tensor) TensorType
        +squeeze(tensor) TensorType
        +to_list(tensor) list
        +to_scalar(tensor) Any
        +full_like(tensor, fill_value) TensorType
        +concatenate(tensors) TensorType
        +get_device(tensor) str
        +to_device(tensor, device) TensorType
        +boolean_ones_like(tensor) TensorType
        +apply_mask(tensor, mask, value) TensorType
        +argsort_descending(tensor) TensorType
    }

    class TorchTensorAdapter {
        +library_name = "torch"
    }
    class NumpyTensorAdapter {
        +library_name = "numpy"
    }
    class JAXTensorAdapter {
        +library_name = "jax"
    }
    class MLXTensorAdapter {
        +library_name = "mlx"
    }
    class TensorFlowTensorAdapter {
        +library_name = "tensorflow"
    }

    TensorAdapter <|-- TorchTensorAdapter
    TensorAdapter <|-- NumpyTensorAdapter
    TensorAdapter <|-- JAXTensorAdapter
    TensorAdapter <|-- MLXTensorAdapter
    TensorAdapter <|-- TensorFlowTensorAdapter
```

### Component Overview

| Component | File | Library | `library_name` |
|-----------|------|---------|----------------|
| [`TensorAdapter`](#tensoradapter) | `base.py` | — (abstract) | — |
| [`TorchTensorAdapter`](#torchtensoradapter) | `torch.py` | PyTorch | `"torch"` |
| [`NumpyTensorAdapter`](#numpytensoradapter) | `numpy.py` | NumPy | `"numpy"` |
| [`JAXTensorAdapter`](#jaxtensoradapter) | `jax.py` | JAX | `"jax"` |
| [`MLXTensorAdapter`](#mlxtensoradapter) | `mlx.py` | MLX | `"mlx"` |
| [`TensorFlowTensorAdapter`](#tensorflowtensoradapter) | `tensorflow.py` | TensorFlow | `"tensorflow"` |

---

## How the Module Fits into the System

Tensor adapters are instantiated by logits processors based on the `tensor_library_name` passed at construction time. The processor then delegates all tensor manipulation to the adapter, keeping its own logic library-independent.

```mermaid
flowchart TD
    Model["Model<br/>(torch / numpy / jax / mlx / tf)"] -->|input_ids, logits| LP["OutlinesLogitsProcessor.__call__"]
    LP -->|"tensor_library_name"| Registry["tensor_adapters registry"]
    Registry -->|lookup| Adapter["TensorAdapter instance"]
    LP -->|delegates ops| Adapter
    Adapter -->|library-specific ops| Lib["torch / numpy / jax / mlx / tensorflow"]
    LP -->|process_logits| Sub["GuideLogitsProcessor / RegexLogitsProcessor / ..."]
    Sub -->|uses adapter| Adapter
    LP -->|processed logits| Model
```

The `OutlinesLogitsProcessor` base class resolves the correct adapter class from a registry keyed by `tensor_library_name`:

```python
tensor_adapter_class = tensor_adapters.get(tensor_library_name)
if tensor_adapter_class is None:
    raise NotImplementedError(f"Library {tensor_library_name} is not available")
self.tensor_adapter = tensor_adapter_class()
```

This means adding support for a new tensor library requires only implementing a new `TensorAdapter` subclass and registering it — no changes to the processors themselves.

---

## Data Flow

The following sequence diagram illustrates how a `GuideLogitsProcessor` uses the adapter during a single generation step (see [`GuideLogitsProcessor.process_logits`](processors_structured.md) for the full algorithm).

```mermaid
sequenceDiagram
    participant Model
    participant LP as OutlinesLogitsProcessor
    participant Adapter as TensorAdapter
    participant Sub as GuideLogitsProcessor

    Model->>LP: __call__(input_ids, logits)
    LP->>Adapter: shape(input_ids), shape(logits)
    LP->>Adapter: unsqueeze(...) (if 1D)
    LP->>Sub: process_logits(input_ids, logits)
    Sub->>Adapter: to_list(gen_ids)
    Sub->>Adapter: to_scalar(gen_ids[-1])
    Sub->>Adapter: full_like(allowed_tokens, i)
    Sub->>Adapter: get_device(logits)
    Sub->>Adapter: concatenate(allowed_tokens_batch)
    Sub->>Adapter: to_device(concat, device)
    Sub->>Adapter: boolean_ones_like(logits)
    Sub->>Adapter: apply_mask(logits, mask, -inf)
    Sub-->>LP: processed logits
    LP->>Adapter: squeeze(...) (if originally 1D)
    LP-->>Model: processed logits
```

---

## Core Components

### `TensorAdapter`

**File:** `outlines/processors/tensor_adapters/base.py`

The abstract base class defining the interface all adapters must implement. It is an `ABC` (abstract base class) with a generic type parameter `TensorType` representing the library-specific tensor type.

**Attributes:**

- `library_name: str` — A class-level string identifying the library (e.g., `"torch"`). Used by processors to reconstruct adapters (e.g., in `GuideLogitsProcessor.copy()`).

**Methods:**

| Method | Description |
|--------|-------------|
| `shape(tensor) -> list[int]` | Returns the shape of the tensor as a list of dimension sizes. |
| `unsqueeze(tensor) -> TensorType` | Adds a dimension at axis 0. |
| `squeeze(tensor) -> TensorType` | Removes the dimension at axis 0. |
| `to_list(tensor) -> list` | Converts the tensor to a Python list. |
| `to_scalar(tensor) -> Any` | Returns the single element of a scalar tensor. |
| `full_like(tensor, fill_value) -> TensorType` | Creates a tensor with the same shape as `tensor`, filled with `fill_value`. |
| `concatenate(tensors) -> TensorType` | Concatenates a list of tensors along axis 0. |
| `get_device(tensor) -> str` | Returns the name of the tensor's device. |
| `to_device(tensor, device) -> TensorType` | Moves the tensor to the specified device. |
| `boolean_ones_like(tensor) -> TensorType` | Creates a boolean tensor of ones with the same shape. |
| `apply_mask(tensor, mask, value) -> TensorType` | Fills elements where `mask` is `True` with `value`. |
| `argsort_descending(tensor) -> TensorType` | Returns indices that would sort the tensor in descending order along axis -1. |

> **Important compatibility note:** The docstring warns that `full_like` and `concatenate` must be able to handle **PyTorch tensors** regardless of the adapter's own library. This is a temporary requirement until `outlines-core` is updated to emit plain arrays instead of torch tensors. Implementations such as [`MLXTensorAdapter`](#mlxtensoradapter) explicitly account for this.

---

### `TorchTensorAdapter`

**File:** `outlines/processors/tensor_adapters/torch.py` · **`library_name = "torch"`**

Wraps the `torch` module (imported lazily in `__init__`). Notable mappings:

- `unsqueeze` / `squeeze` → `tensor.unsqueeze(0)` / `tensor.squeeze(0)`
- `concatenate` → `torch.cat(tensors, dim=0)`
- `get_device` → `tensor.device`
- `to_device` → `tensor.to(device)`
- `boolean_ones_like` → `torch.ones_like(tensor, dtype=torch.bool)`
- `apply_mask` → `torch.masked_fill(tensor, mask, value)`
- `argsort_descending` → `torch.argsort(tensor, descending=True)`

---

### `NumpyTensorAdapter`

**File:** `outlines/processors/tensor_adapters/numpy.py` · **`library_name = "numpy"`**

Wraps the `numpy` module. Notable mappings:

- `unsqueeze` / `squeeze` → `numpy.expand_dims(tensor, axis=0)` / `numpy.squeeze(tensor, axis=0)`
- `concatenate` → `numpy.concatenate(tensors, axis=0)`
- `get_device` → `None` (NumPy has no device concept)
- `to_device` → returns the tensor unchanged
- `apply_mask` → copies the tensor and assigns `result[mask] = value`
- `argsort_descending` → `numpy.argsort(-tensor)`

---

### `JAXTensorAdapter`

**File:** `outlines/processors/tensor_adapters/jax.py` · **`library_name = "jax"`**

Wraps the `jax` module, using `jax.numpy` for array operations. Notable mappings:

- `unsqueeze` / `squeeze` → `jax.numpy.expand_dims` / `jax.numpy.squeeze`
- `concatenate` → `jax.numpy.concatenate(tensors, axis=0)`
- `get_device` → `None`; `to_device` → returns the tensor unchanged
- `apply_mask` → uses the functional update idiom `result.at[mask].set(value)`
- `argsort_descending` → `jax.numpy.argsort(-tensor)`

---

### `MLXTensorAdapter`

**File:** `outlines/processors/tensor_adapters/mlx.py` · **`library_name = "mlx"`**

Wraps `mlx.core`. This adapter contains the most explicit handling of the torch-tensor compatibility requirement:

- `full_like` → `mlx.full(tensor.shape, fill_value)` (works with a torch tensor's `.shape`)
- `concatenate` → converts each element to an `mlx.array` if it is not already one, then `mlx.concatenate(..., axis=0)`
- `squeeze` → returns `tensor[0]` only when `tensor.shape[0] == 1`, otherwise returns the tensor unchanged
- `apply_mask` → uses `mlx.where(mask, mlx.array(value), result)`
- `argsort_descending` → `mlx.argsort(-tensor)`
- `get_device` → `None`; `to_device` → returns the tensor unchanged

---

### `TensorFlowTensorAdapter`

**File:** `outlines/processors/tensor_adapters/tensorflow.py` · **`library_name = "tensorflow"`**

Wraps `tensorflow` (imported as `tf`). Notable mappings:

- `unsqueeze` / `squeeze` → `tf.expand_dims(tensor, axis=0)` / `tf.squeeze(tensor, axis=0)`
- `to_list` / `to_scalar` → call `.numpy()` first, then `.tolist()` / `.item()`
- `full_like` → `tf.fill(tf.shape(tensor), fill_value)`
- `concatenate` → `tf.concat(tensors, axis=0)`
- `get_device` → `tensor.device`
- `to_device` → uses the `with tf.device(device):` context manager and returns `tf.identity(tensor)`
- `apply_mask` → `tf.where(mask, tf.constant(value, dtype=tensor.dtype), tensor)`
- `argsort_descending` → `tf.argsort(tensor, direction='DESCENDING')`

---

## Cross-Library Behavior Comparison

The table below highlights how each adapter handles operations that differ meaningfully across libraries.

| Operation | Torch | NumPy | JAX | MLX | TensorFlow |
|-----------|-------|-------|-----|-----|------------|
| `get_device` | `tensor.device` | `None` | `None` | `None` | `tensor.device` |
| `to_device` | `tensor.to(device)` | no-op | no-op | no-op | `tf.device` context |
| `apply_mask` | `masked_fill` | copy + assign | `.at[mask].set` | `mlx.where` | `tf.where` |
| `argsort_descending` | `argsort(descending=True)` | `argsort(-tensor)` | `argsort(-tensor)` | `argsort(-tensor)` | `argsort(direction='DESCENDING')` |
| Torch-tensor input handling | native | native | native | explicit conversion | native |

---

## Design Considerations

1. **Lazy imports.** Every concrete adapter imports its library inside `__init__` rather than at module load time. This keeps the module importable even when only a subset of the supported libraries is installed.

2. **Torch-tensor interoperability.** Because `outlines-core` currently emits torch tensors, `full_like` and `concatenate` are documented to accept torch tensors. The `MLXTensorAdapter` is the clearest example of an adapter that explicitly bridges this gap. This requirement is expected to be removed once `outlines-core` is updated.

3. **Device abstraction.** Libraries without an explicit device concept (NumPy, JAX, MLX) return `None` from `get_device` and treat `to_device` as a no-op, allowing processors to call these methods unconditionally.

4. **Extensibility.** Adding a new backend requires only: (a) subclassing `TensorAdapter`, (b) setting `library_name`, and (c) registering the class in the `tensor_adapters` registry consumed by [`OutlinesLogitsProcessor`](processors_base.md).

---

## Related Documentation

- [processors](processors.md) — Parent package overview.
- [processors_base](processors_base.md) — `OutlinesLogitsProcessor`, the primary consumer of tensor adapters.
- [processors_structured](processors_structured.md) — `GuideLogitsProcessor`, `RegexLogitsProcessor`, `JSONLogitsProcessor`, `CFGLogitsProcessor`.
- [processors_guides](processors_guides.md) — `Guide`, `RegexGuide`, `CFGGuide`, `StopAtEOSGuide`.
- [models_base](models_base.md) — Model abstractions that produce the tensors processed here.
