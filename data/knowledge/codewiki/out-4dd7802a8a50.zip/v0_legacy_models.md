# v0 Legacy Models

## Introduction

The `v0_legacy_models` module provides **backward-compatibility shims** for model
integrations that existed in Outlines v0 but are no longer part of the supported
v1 model surface. It contains two legacy model wrappers:

- **`ExLlamaV2Model`** — a wrapper around the `exllamav2` library's dynamic
  generator, along with its tokenizer adapter (`OutlinesExLlamaV2Tokenizer`) and
  a `TypedDict` describing generation parameters (`ExllamaV2Params`).
- **`TransformersVision`** — a vision-capable subclass of the modern
  `Transformers` model, retained for users who relied on the v0
  `transformers_vision` entry point.

> **Deprecation notice:** Every public entry point in this module emits a
> `DeprecationWarning`. Support is scheduled for removal in **v1.1.0**. New code
> should use the modern equivalents described in
> [models_local.md](models_local.md) and [models_base.md](models_base.md).

This module is part of the broader [v0_legacy](v0_legacy_function.md) compatibility
layer, which also includes the legacy generator adapters
([v0_legacy_generate.md](v0_legacy_generate.md)), samplers
([v0_legacy_samplers.md](v0_legacy_samplers.md)), and the `Function`/`vectorize`
helpers ([v0_legacy_function.md](v0_legacy_function.md)).

---

## Module Structure

```mermaid
graph TD
    subgraph "v0_legacy_models"
        EXL["ExLlamaV2Model<br/>(exllamav2.py)"]
        EXLTOK["OutlinesExLlamaV2Tokenizer<br/>(exllamav2.py)"]
        EXLPARAMS["ExllamaV2Params<br/>(exllamav2.py)"]
        EXL2FN["exl2() factory<br/>(exllamav2.py)"]
        TV["TransformersVision<br/>(transformers_vision.py)"]
        TVFN["transformers_vision() factory<br/>(transformers_vision.py)"]
    end

    subgraph "Modern models"
        TRANS["Transformers<br/>(models/transformers.py)"]
        TRANSMMTA["TransformersMultiModalTypeAdapter<br/>(models/transformers.py)"]
        BASE["Model / ModelTypeAdapter<br/>(models/base.py)"]
    end

    subgraph "Legacy bridge"
        GENADAPTER["GeneratorV0Adapter<br/>(v0_legacy/generate/api.py)"]
    end

    EXL2FN --> EXL
    EXL --> EXLTOK
    EXL --> EXLPARAMS
    TVFN --> TV
    TV -->|inherits| TRANS
    TV -->|uses| TRANSMMTA
    TRANS -->|inherits| BASE
    GENADAPTER -->|dispatches to| EXL
    GENADAPTER -->|dispatches to| TRANS
```

---

## Component Overview

| Component | File | Kind | Purpose |
|-----------|------|------|---------|
| `ExLlamaV2Model` | `exllamav2.py` | Class | Legacy wrapper around `ExLlamaV2DynamicGenerator` |
| `OutlinesExLlamaV2Tokenizer` | `exllamav2.py` | Class | Adapts the exllamav2 tokenizer to the Outlines tokenizer interface |
| `ExllamaV2Params` | `exllamav2.py` | `TypedDict` | Schema for exllamav2 generation parameters |
| `exl2` | `exllamav2.py` | Factory function | Loads an `ExLlamaV2Model` from a model path |
| `TransformersVision` | `transformers_vision.py` | Class | Vision-capable subclass of `Transformers` |
| `transformers_vision` | `transformers_vision.py` | Factory function | Loads a `TransformersVision` model |

---

## ExLlamaV2Model

`ExLlamaV2Model` is a thin wrapper around the `exllamav2` library's
`ExLlamaV2DynamicGenerator`. It is **not** a subclass of the modern
[`Model`](models_base.md) base class, so it does not implement the standard
`__call__`/`stream` interface. Instead, it exposes a v0-style API:

- `generate(prompts, logits_processor, **kwargs)` — synchronous generation.
- `generate_stream(prompts, logits_processor, **kwargs)` — streaming generation
  via `ExLlamaV2DynamicJob`.
- `prepare_generation_parameters(...)` — translates Outlines-style kwargs into
  exllamav2 parameters.
- `reformat_output(...)` — normalizes exllamav2's output shape to Outlines'
  conventions.

### Why it is deprecated

The `exllamav2` library is not compatible with several key features of Outlines
v1, so support was dropped. The constructor emits a `DeprecationWarning`, and
`__call__`/`stream` raise `NotImplementedError` to signal that the modern
interface is unavailable.

### Generation parameter translation

`prepare_generation_parameters` maps Outlines kwargs onto exllamav2 settings:

```mermaid
flowchart LR
    A["Outlines kwargs<br/>max_tokens, stop_at, seed,<br/>temperature, top_p, top_k, num_samples"] --> B["prepare_generation_parameters"]
    B --> C["ExllamaV2Params<br/>max_new_tokens, stop_conditions,<br/>seed, gen_settings"]
    C --> D["ExLlamaV2DynamicGenerator.generate()"]
    D --> E["reformat_output()"]
    E --> F["str | List[str]"]
```

Key behaviors:

- **`max_new_tokens`** is computed per prompt as `max_seq_len - prompt_tokens`
  when `max_tokens` is not supplied; otherwise it is set uniformly.
- **`stop_conditions`** always includes the EOS token id, plus any user-provided
  `stop_at` strings.
- **`num_samples > 1`** duplicates the prompts and the `max_new_tokens` list.
- The final `generate` call uses `min(max_new_tokens)` to avoid exceeding the
  maximum sequence length for any prompt in the batch.

### Output reformatting

`reformat_output` reconciles exllamav2's output conventions with Outlines':

1. A `str` input yields a `str` output.
2. A single-element list yields the element itself.
3. When `num_samples > 1`, the flat output list is regrouped into a list of
   per-sample lists.

---

## OutlinesExLlamaV2Tokenizer

A lightweight adapter that exposes the subset of the Outlines tokenizer
interface required by the legacy generation path:

| Attribute / Method | Description |
|--------------------|-------------|
| `vocabulary` | Piece-to-id dictionary from the exllamav2 tokenizer |
| `special_tokens` | Set of extended piece ids |
| `eos_token_id` | End-of-sequence token id |
| `convert_token_to_string(token)` | Identity passthrough |
| `decode(token_ids)` | Decodes ids to a list of strings (special tokens excluded) |

---

## ExllamaV2Params

A `TypedDict` (`total=False`) describing the parameters consumed by the
exllamav2 generator:

```python
class ExllamaV2Params(TypedDict, total=False):
    stop_conditions: Optional[List[Union[int, str]]]
    seed: Optional[int]
    gen_settings: "ExLlamaV2Sampler.Settings"
    max_new_tokens: List[int]
```

The companion helper `exllamav2_params_adapter` merges sampling and generation
parameter dictionaries into a single kwargs dict. This adapter is invoked by the
[`GeneratorV0Adapter`](v0_legacy_generate.md) when the underlying model is an
`ExLlamaV2Model`.

---

## TransformersVision

`TransformersVision` is a subclass of the modern
[`Transformers`](models_local.md) model that adds multi-modal (vision) input
handling. It is retained purely for backward compatibility with the v0
`transformers_vision` entry point.

### Relationship to the modern model

```mermaid
classDiagram
    class Model {
        <<abstract>>
        +generate()
        +generate_stream()
        +__call__()
        +stream()
    }
    class Transformers {
        +model
        +tokenizer
        +type_adapter
        +_prepare_model_inputs()
    }
    class TransformersVision {
        +processor
        +_prepare_model_inputs()
    }
    class TransformersMultiModalTypeAdapter {
        +format_input()
        +format_output_type()
    }

    Model <|-- Transformers
    Transformers <|-- TransformersVision
    TransformersVision ..> TransformersMultiModalTypeAdapter : uses
```

### Key differences from `Transformers`

- Adds a `processor` attribute (with `padding_side="left"` and
  `pad_token="[PAD]"`).
- Overrides `_prepare_model_inputs` to run the processor over the formatted
  multi-modal input and move tensors to the model device.
- Uses `TransformersMultiModalTypeAdapter` instead of the standard
  `TransformersTypeAdapter`, enabling dictionary inputs that contain a `text`
  key plus additional asset keys (e.g. `images`, `audios`).

### Migration path

The deprecation warning recommends instantiating a `TransformersMultiModal`
model directly via `outlines.from_transformers`:

```python
from transformers import AutoModelForCausalLM, AutoProcessor
from outlines import from_transformers

model = from_transformers(
    AutoModelForCausalLM.from_pretrained("<model_name>"),
    AutoProcessor.from_pretrained("<model_name>"),
)
```

See [models_local.md](models_local.md) for the modern multi-modal model
documentation.

---

## Factory Functions

### `exl2(...)`

Loads an `ExLlamaV2Model` from a model path. It:

1. Imports the `exllamav2` library (raising a helpful `ImportError` if missing).
2. Builds an `ExLlamaV2Config` and `ExLlamaV2` model.
3. Creates a cache (`ExLlamaV2Cache` or `ExLlamaV2Cache_Q4`).
4. Optionally loads a draft model for speculative decoding.
5. Initializes an `ExLlamaV2DynamicGenerator`.
6. Wraps the tokenizer in `OutlinesExLlamaV2Tokenizer` and returns an
   `ExLlamaV2Model`.

### `transformers_vision(...)`

Loads a `TransformersVision` model. It:

1. Emits a `DeprecationWarning`.
2. Resolves default `AutoProcessor`/`AutoTokenizer` classes if not provided.
3. Loads the model, processor, and tokenizer from the given model name.
4. Returns a `TransformersVision` instance.

---

## Integration with the Legacy Generation Bridge

The legacy models are consumed by the
[`GeneratorV0Adapter`](v0_legacy_generate.md), which bridges the v0 `generate`
functions and the modern `Generator` object. The adapter dispatches to a
model-specific parameter adapter based on the model type:

```mermaid
sequenceDiagram
    participant User
    participant Adapter as GeneratorV0Adapter
    participant Model as ExLlamaV2Model / Transformers
    participant Gen as Generator (modern)

    User->>Adapter: __call__(prompts, max_tokens, stop_at, seed, ...)
    Adapter->>Adapter: create_inference_params(...)
    Note over Adapter: selects exllamav2_params_adapter<br/>or transformers_params_adapter
    Adapter->>Gen: generator(prompts, **inference_params)
    Gen->>Model: generate(...)
    Model-->>Gen: raw output
    Gen-->>Adapter: result
    Adapter->>Adapter: format_sequence(result)
    Adapter-->>User: str | List[str]
```

The adapter only accepts models that were available in v0 (it validates against
`V0GeneratorModel`), which is why these legacy wrappers remain necessary for the
v0 API to function.

---

## Related Documentation

- [models_base.md](models_base.md) — the modern `Model` / `ModelTypeAdapter` base classes.
- [models_local.md](models_local.md) — modern local models including `Transformers` and `TransformersMultiModal`.
- [v0_legacy_generate.md](v0_legacy_generate.md) — the `GeneratorV0Adapter` bridge.
- [v0_legacy_samplers.md](v0_legacy_samplers.md) — legacy sampler protocol and implementations.
- [v0_legacy_function.md](v0_legacy_function.md) — legacy `Function` and `vectorize` helpers.
- [processors_guides.md](processors_guides.md) — logits processors passed into legacy generation.
