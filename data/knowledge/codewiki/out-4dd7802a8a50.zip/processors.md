# Processors

## Introduction

The `processors` module is the **structured generation engine** of Outlines. It provides the
logits processors that bias a language model's next-token distribution so that the generated
text conforms to a user-specified structure — a regular expression, a JSON schema, or a
context-free grammar (CFG).

At its core, a *logits processor* is a callable that receives the current `input_ids` and the
raw `logits` produced by a model, and returns a modified set of `logits` where all tokens that
would violate the target structure are masked out (set to `-inf`). The model then samples from
this constrained distribution, guaranteeing that the output is always valid.

The module is deliberately **tensor-library agnostic**: the same processor logic works with
PyTorch, NumPy, JAX, MLX, and TensorFlow models through a pluggable *tensor adapter* layer.

## Architecture Overview

The module is organized into three cooperating layers:

1. **Base layer** — `OutlinesLogitsProcessor` defines the shared `__call__` entrypoint and
   delegates the actual masking to a subclass-provided `process_logits` method.
2. **Guide layer** — `Guide` subclasses (`RegexGuide`, `CFGGuide`, `StopAtEOSGuide`) implement
   the finite-state-machine logic that decides which tokens are legal at each generation step.
3. **Structured processors** — `GuideLogitsProcessor` and its specializations
   (`RegexLogitsProcessor`, `JSONLogitsProcessor`, `CFGLogitsProcessor`) combine a guide with a
   tokenizer to produce the final masked logits.

A cross-cutting **tensor adapter** layer abstracts every tensor operation so that the processors
are independent of the underlying numerical library.

```mermaid
graph TD
    subgraph "Structured Processors"
        GLP[GuideLogitsProcessor]
        RLP[RegexLogitsProcessor]
        JLP[JSONLogitsProcessor]
        CLP[CFGLogitsProcessor]
    end

    subgraph "Base"
        OLP[OutlinesLogitsProcessor]
    end

    subgraph "Guides"
        G[Guide]
        RG[RegexGuide]
        CG[CFGGuide]
        SE[StopAtEOSGuide]
    end

    subgraph "Tensor Adapters"
        TA[TensorAdapter]
        TORCH[TorchTensorAdapter]
        NUMPY[NumpyTensorAdapter]
        JAX[JAXTensorAdapter]
        MLX[MLXTensorAdapter]
        TF[TensorFlowTensorAdapter]
    end

    RLP --> GLP
    JLP --> RLP
    CLP --> GLP
    GLP --> OLP
    GLP --> G
    RLP --> RG
    CLP --> CG
    RG --> G
    CG --> G
    SE --> G
    OLP --> TA
    TA --> TORCH
    TA --> NUMPY
    TA --> JAX
    TA --> MLX
    TA --> TF
```

## Sub-modules

### Base Logits Processor

The [`OutlinesLogitsProcessor`](processors_base.md) base class defines the universal contract
for all logits processors. It standardizes the shape of `input_ids` and `logits` to 2D tensors
before dispatching to the abstract `process_logits` method, and casts the result back to the
original shape. It also instantiates the correct tensor adapter based on the
`tensor_library_name` passed at construction time.

### Guides

The [guides](processors_guides.md) sub-module contains the finite-state-machine definitions that
drive constrained generation:

- `Guide` — abstract base extending the `outlines_core` guide.
- `RegexGuide` — generates text matching a regular expression (with a cached state mapping).
- `CFGGuide` — generates text conforming to a Lark context-free grammar.
- `StopAtEOSGuide` — a minimal guide that simply stops at the EOS token.

### Structured Processors

The [structured processors](processors_structured.md) sub-module contains the concrete logits
processors that users interact with:

- `GuideLogitsProcessor` — biases logits using any `Guide`.
- `RegexLogitsProcessor` — biases logits using a regular expression.
- `JSONLogitsProcessor` — biases logits using a JSON schema.
- `CFGLogitsProcessor` — biases logits using a context-free grammar (rejection sampling).

### Tensor Adapters

The [tensor adapters](processors_tensor_adapters.md) sub-module provides the abstraction layer
that makes the processors library-agnostic. `TensorAdapter` defines the interface, and concrete
implementations exist for PyTorch, NumPy, JAX, MLX, and TensorFlow.

## Data Flow

The following diagram shows how a single generation step flows through the module:

```mermaid
sequenceDiagram
    participant Model
    participant OLP as OutlinesLogitsProcessor
    participant GLP as GuideLogitsProcessor
    participant Guide
    participant TA as TensorAdapter

    Model->>OLP: __call__(input_ids, logits)
    OLP->>TA: shape / unsqueeze (normalize to 2D)
    OLP->>GLP: process_logits(input_ids, logits)
    GLP->>Guide: get_next_state(prev_state, token_id)
    GLP->>Guide: get_next_instruction(state).tokens
    GLP->>TA: concatenate / boolean_ones_like / apply_mask
    TA-->>GLP: masked logits
    GLP-->>OLP: masked logits
    OLP->>TA: squeeze (restore original shape)
    OLP-->>Model: processed logits
```

## Relationship to Other Modules

- **Models** — Every model in the [models module](models.md) exposes a `SteerableGenerator`
  that accepts a logits processor. The processor's `tensor_library_name` must match the model's
  backend (e.g. `"torch"` for Transformers, `"mlx"` for MLX-LM).
- **Types / DSL** — The [types DSL](types_dsl.md) (`JsonSchema`, `Regex`, `CFG`, etc.) is used
  by the structured processors to convert high-level type specifications into the regex strings
  and grammars consumed by the guides.
- **Tokenizer** — The [tokenizer](models_tokenizer.md) abstraction is required by every guide
  and structured processor to map between token ids and strings.
- **Caching** — `RegexGuide` uses the [caching](caching.md) module to memoize the expensive
  state-mapping computation.
- **FSM Parsing** — `CFGGuide` relies on the [fsm parsing](fsm_parsing.md) module
  (`PartialLark`, `PartialParserState`) for incremental grammar parsing.
- **Benchmarks** — The [benchmarks](benchmarks.md) module provides performance benchmarks for
  the logits processors and guides.
