# Types DSL Module

## Introduction

The `types_dsl` module (`outlines/types/dsl.py`) provides the **regular expression DSL and output type system** for structured generation in Outlines. It is the foundational layer that lets users describe *what* an LLM should generate — as regular expressions, context-free grammars, JSON schemas, or native Python types — in a uniform, composable way.

The module is organized around three logical steps:

1. **Definition** — `Term` classes that hold output type definitions. This includes both standalone terms (`JsonSchema`, `CFG`, `Regex`, `FSM`) and composable DSL terms (`Alternatives`, `Sequence`, `KleeneStar`, etc.).
2. **Conversion** — `python_types_to_terms` translates native Python types (e.g. `int`, `List[str]`, Pydantic models) into `Term` instances.
3. **Lowering** — `to_regex` converts a `Term` instance into a regular expression string that downstream guides and processors can consume.

The resulting regular expressions are consumed by the [processors](processors.md) module (specifically `RegexGuide`, `CFGGuide`, and the structured logits processors) to constrain token generation.

---

## Architecture Overview

The DSL is a small, self-contained tree of dataclasses rooted at the abstract `Term` base class. Every concrete term knows how to (a) render itself as an ASCII tree for debugging and (b) be lowered to a regex via `to_regex`.

```mermaid
classDiagram
    class Term {
        <<abstract>>
        +__add__(other) Sequence
        +__or__(other) Alternatives
        +validate(value) str
        +matches(value) bool
        +display_ascii_tree() str
        +optional() Optional
        +exactly(count) QuantifyExact
        +at_least(count) QuantifyMinimum
        +at_most(count) QuantifyMaximum
        +between(min, max) QuantifyBetween
        +one_or_more() KleenePlus
        +zero_or_more() KleeneStar
    }

    class String {
        +value: str
    }
    class Regex {
        +pattern: str
    }
    class CFG {
        +definition: str
        +from_file(path) CFG
    }
    class FSM {
        +fsm: interegular.fsm.FSM
    }
    class JsonSchema {
        +schema: str
        +whitespace_pattern: str
        +from_file(path) JsonSchema
    }
    class KleeneStar {
        +term: Term
    }
    class KleenePlus {
        +term: Term
    }
    class Optional {
        +term: Term
    }
    class Alternatives {
        +terms: List~Term~
    }
    class Sequence {
        +terms: List~Term~
    }
    class QuantifyExact {
        +term: Term
        +count: int
    }
    class QuantifyMinimum {
        +term: Term
        +min_count: int
    }
    class QuantifyMaximum {
        +term: Term
        +max_count: int
    }
    class QuantifyBetween {
        +term: Term
        +min_count: int
        +max_count: int
    }

    Term <|-- String
    Term <|-- Regex
    Term <|-- CFG
    Term <|-- FSM
    Term <|-- JsonSchema
    Term <|-- KleeneStar
    Term <|-- KleenePlus
    Term <|-- Optional
    Term <|-- Alternatives
    Term <|-- Sequence
    Term <|-- QuantifyExact
    Term <|-- QuantifyMinimum
    Term <|-- QuantifyMaximum
    Term <|-- QuantifyBetween

    KleeneStar --> Term : term
    KleenePlus --> Term : term
    Optional --> Term : term
    Alternatives --> Term : terms
    Sequence --> Term : terms
    QuantifyExact --> Term : term
    QuantifyMinimum --> Term : term
    QuantifyMaximum --> Term : term
    QuantifyBetween --> Term : term
```

### Term Categories

| Category | Terms | Purpose |
|----------|-------|---------|
| **Leaf / atomic** | `String`, `Regex`, `CFG`, `FSM`, `JsonSchema` | Self-contained output definitions |
| **Combinators** | `Alternatives`, `Sequence` | Combine multiple sub-terms |
| **Repetition** | `KleeneStar`, `KleenePlus`, `Optional` | Zero-or-more, one-or-more, optional |
| **Quantifiers** | `QuantifyExact`, `QuantifyMinimum`, `QuantifyMaximum`, `QuantifyBetween` | Bounded repetition |

---

## Core Components

### `Term` (base class)

The abstract base for all DSL nodes. It provides:

- **Operator overloading** for ergonomic composition:
  - `term_a + term_b` → `Sequence([term_a, term_b])`
  - `term_a | term_b` → `Alternatives([term_a, term_b])`
  - String operands are automatically wrapped in `String`.
- **Pydantic integration** via `__get_pydantic_core_schema__` and `__get_pydantic_json_schema__`. A `Term` used as a field type in a Pydantic model is serialized to JSON Schema as `{"type": "string", "pattern": <regex>}` and validated against that regex.
- **Validation helpers**: `validate(value)` raises `ValueError` if the value is not in the language; `matches(value)` returns a boolean.
- **Fluent builder methods** (`optional`, `exactly`, `at_least`, `at_most`, `between`, `one_or_more`, `zero_or_more`) that delegate to the module-level factory functions.
- **Debugging**: `display_ascii_tree()` renders the term tree; `__str__` returns it.
- **Deprecated methods**: `times` and `repeat` (see [Deprecations](#deprecations)).

### Atomic Terms

| Term | Description |
|------|-------------|
| `String(value)` | A literal string. Lowered via `re.escape`. |
| `Regex(pattern)` | A raw regular expression pattern. |
| `CFG(definition)` | A context-free grammar (Lark syntax). Supports `CFG.from_file(path)`. |
| `FSM(fsm)` | A finite state machine wrapping an `interegular.fsm.FSM`. |
| `JsonSchema(schema, whitespace_pattern=None)` | A JSON schema. Accepts a `dict`, JSON `str`, Pydantic model, `TypedDict`, dataclass, or genSON `SchemaBuilder`. Supports `JsonSchema.from_file(path)`. |

`JsonSchema` normalizes all accepted inputs into a JSON string and validates it with `jsonschema.Draft7Validator.check_schema` in `__post_init__`.

### Combinators

- **`Alternatives(terms)`** — logical OR (`|`). Lowered to `(a|b|c)`.
- **`Sequence(terms)`** — concatenation. Lowered to `abc`.

### Repetition & Quantifiers

| Term | Regex equivalent | Factory |
|------|------------------|---------|
| `KleeneStar(term)` | `(x)*` | `zero_or_more(term)` |
| `KleenePlus(term)` | `(x)+` | `one_or_more(term)` |
| `Optional(term)` | `(x)?` | `optional(term)` |
| `QuantifyExact(term, count)` | `(x){n}` | `exactly(count, term)` |
| `QuantifyMinimum(term, min_count)` | `(x){n,}` | `at_least(count, term)` |
| `QuantifyMaximum(term, max_count)` | `(x){,m}` | `at_most(count, term)` |
| `QuantifyBetween(term, min, max)` | `(x){n,m}` | `between(min, max, term)` |

`QuantifyBetween.__post_init__` raises `ValueError` if `min_count > max_count`.

---

## Factory Functions

The module exposes factory functions that accept either `Term` instances or plain strings (auto-wrapped in `String`):

```python
regex(pattern)              # -> Regex
cfg(definition)             # -> CFG
fsm(fsm)                    # -> FSM
json_schema(schema)         # -> JsonSchema
either(*terms)              # -> Alternatives
optional(term)              # -> Optional
exactly(count, term)        # -> QuantifyExact
at_least(count, term)       # -> QuantifyMinimum
at_most(count, term)        # -> QuantifyMaximum
between(min_count, max_count, term)  # -> QuantifyBetween
zero_or_more(term)          # -> KleeneStar
one_or_more(term)           # -> KleenePlus
```

---

## Python Type Conversion

`python_types_to_terms(ptype, recursion_depth=0)` is the bridge from native Python typing constructs to the DSL. It is the entry point used by model type adapters (see [models](models.md)) to turn user-declared types into constraints.

```mermaid
flowchart TD
    A[python_types_to_terms] --> B{Is Term?}
    B -->|yes| C[return as-is]
    B -->|no| D{Basic type?}
    D -->|int| E[types.integer]
    D -->|float| F[types.number]
    D -->|bool| G[types.boolean]
    D -->|str| H[types.string]
    D -->|dict| I[CFG json grammar]
    D -->|date/time/datetime| J[types.date/time/datetime]
    D -->|no| K{Instance?}
    K -->|str instance| L[String]
    K -->|int/float instance| M[Regex]
    K -->|no| N{Structured?}
    N -->|dataclass/TypedDict/Pydantic| O[JsonSchema]
    N -->|genSON builder| O
    N -->|no| P{Enum?}
    P -->|yes| Q[Alternatives of members]
    P -->|no| R{Generic args?}
    R -->|Literal| S[_handle_literal]
    R -->|Union| T[_handle_union]
    R -->|List| U[_handle_list]
    R -->|Tuple| V[_handle_tuple]
    R -->|Dict| W[_handle_dict]
    R -->|Callable| X[JsonSchema from signature]
    R -->|unsupported| Y[TypeError]
```

### Conversion Rules

| Python type | Resulting `Term` |
|-------------|------------------|
| `int` | `types.integer` |
| `float` | `types.number` |
| `bool` | `types.boolean` |
| `str` | `types.string` |
| `dict` | `CFG(grammars.json)` |
| `datetime.date` / `time` / `datetime` | `types.date` / `types.time` / `types.datetime` |
| `str` instance | `String(value)` |
| `int`/`float` instance | `Regex(str(value))` |
| dataclass / `TypedDict` / Pydantic model | `JsonSchema` |
| genSON `SchemaBuilder` | `JsonSchema` |
| `Enum` | `Alternatives` of member terms |
| `Literal[...]` | `Alternatives` |
| `Union[...]` / `Optional[T]` | `Alternatives` (with `String("None")` for optionals) |
| `List[T]` | `Sequence` with `KleeneStar` for repeated items |
| `Tuple[...]` | `Sequence` (fixed or variadic) |
| `Dict[K, V]` | `Sequence` with `Optional`/`KleeneStar` pairs |
| `Callable` | `JsonSchema` derived from the signature |

### Helper Functions

- `_get_enum_members(ptype)` — collects enum values plus non-dunder function members.
- `_handle_literal(args)` — builds `Alternatives` from literal values.
- `_handle_union(args, depth)` — handles `Optional[T]` specially, otherwise builds `Alternatives`.
- `_handle_list(args, depth)` — enforces homogeneous lists; builds `[item, item, ...]` structure.
- `_handle_tuple(args, depth)` — handles empty, variadic (`Tuple[T, ...]`), and fixed tuples.
- `_handle_dict(args, depth)` — builds `{key:value, ...}` structure.

A `recursion_depth` guard raises `RecursionError` beyond depth 10 to protect against recursive type definitions.

---

## Regex Lowering

`to_regex(term)` performs a structural match over the term tree and produces a regular expression string. This is the function invoked by `Term.validate`, `Term.matches`, and the Pydantic JSON schema hook.

```mermaid
flowchart LR
    T[Term] --> R[to_regex]
    R --> S1["String -> re.escape(value)"]
    R --> S2["Regex -> (pattern)"]
    R --> S3["JsonSchema -> build_regex_from_schema"]
    R --> S4["KleeneStar -> (x)*"]
    R --> S5["KleenePlus -> (x)+"]
    R --> S6["Optional -> (x)?"]
    R --> S7["Alternatives -> (a|b)"]
    R --> S8["Sequence -> abc"]
    R --> S9["Quantify* -> (x){n,m}"]
```

`JsonSchema` lowering delegates to `outlines_core.fsm.json_schema.build_regex_from_schema`, which converts a JSON schema into a regex that matches valid JSON documents.

---

## Data Flow

The following diagram shows how a user-declared type flows through the DSL and into the generation pipeline.

```mermaid
sequenceDiagram
    participant User
    participant DSL as types_dsl
    participant Adapter as ModelTypeAdapter
    participant Guide as RegexGuide / CFGGuide
    participant Proc as GuideLogitsProcessor

    User->>DSL: declare type (e.g. List[int], Pydantic model)
    DSL->>DSL: python_types_to_terms(ptype)
    DSL-->>Adapter: Term instance
    Adapter->>DSL: to_regex(term)
    DSL-->>Adapter: regex string
    Adapter->>Guide: from_regex(regex, tokenizer)
    Guide-->>Proc: Guide (state machine)
    Proc->>Proc: bias logits per step
```

1. A user declares an output type (native Python type, `Term`, or JSON schema).
2. `python_types_to_terms` normalizes it into a `Term`.
3. `to_regex` lowers the `Term` to a regex string.
4. The regex is handed to a `Guide` (e.g. `RegexGuide.from_regex`) which builds a token-level state machine.
5. A `GuideLogitsProcessor` uses the guide to mask invalid tokens at each generation step.

---

## Dependencies

```mermaid
flowchart TD
    DSL[types_dsl]
    DSL --> UTILS[outlines.types.utils]
    DSL --> TYPES[outlines.types]
    DSL --> GRAMMARS[outlines.grammars]
    DSL --> CORE[outlines_core.fsm.json_schema]
    DSL --> INTEREGULAR[interegular]
    DSL --> JSONSCHEMA[jsonschema]
    DSL --> GENSON[genson]
    DSL --> PYDANTIC[pydantic]

    UTILS --> DSL
    TYPES --> DSL
    GRAMMARS --> DSL
```

| Dependency | Role |
|------------|------|
| `outlines.types.utils` | Type-inspection predicates (`is_int`, `is_pydantic_model`, etc.) and `get_schema_from_signature` |
| `outlines.types` | Predefined terms (`integer`, `string`, `boolean`, `number`, `date`, `time`, `datetime`) |
| `outlines.grammars` | The built-in JSON grammar (`grammars.json`) |
| `outlines_core.fsm.json_schema` | `build_regex_from_schema` for JSON schema → regex lowering |
| `interegular` | `FSM` representation |
| `jsonschema` | Draft7 schema validation |
| `genson` | `SchemaBuilder` support |
| `pydantic` | Core schema / JSON schema integration and `TypeAdapter` |

### Downstream Consumers

- **[processors](processors.md)** — `RegexGuide`, `CFGGuide`, and structured logits processors consume the regex/CFG output.
- **[models](models.md)** — `ModelTypeAdapter` subclasses use `python_types_to_terms` and `to_regex` to translate user types into constraints.
- **[fsm_parsing](fsm_parsing.md)** — `PartialLark` and related partial parsers power `CFGGuide`.

---

## Usage Examples

### Composing terms with operators

```python
from outlines.types import Regex, either, zero_or_more

digit = Regex(r"[0-9]")
letter = Regex(r"[a-zA-Z]")

# Using operators
identifier = letter + zero_or_more(letter | digit)

# Using factory functions
identifier = either(letter, digit)
```

### Using a Term as a Pydantic field type

```python
from outlines.types import Regex
from pydantic import BaseModel

age_type = Regex("[0-9]+")

class User(BaseModel):
    name: str
    age: age_type  # validated against the regex
```

### Converting Python types

```python
from outlines.types.dsl import python_types_to_terms, to_regex
from typing import List

term = python_types_to_terms(List[int])
print(to_regex(term))
```

### Loading from files

```python
from outlines.types import CFG, JsonSchema

grammar = CFG.from_file("grammar.lark")
schema = JsonSchema.from_file("schema.json")
```

---

## Deprecations

The following functions/methods are deprecated since **v0.2.2** and scheduled for removal in **v1.5.0**:

| Deprecated | Replacement |
|------------|-------------|
| `Term.times(count)` / `times(term, count)` | `exactly(count, term)` |
| `Term.repeat(min, max)` / `repeat(term, min, max)` | `between`, `at_least`, or `at_most` |

Both emit `DeprecationWarning` with migration guidance.

---

## Related Modules

- [processors](processors.md) — Guides and logits processors that consume DSL output.
- [models](models.md) — Model type adapters that bridge user types to the DSL.
- [fsm_parsing](fsm_parsing.md) — Partial parsers used by CFG-based generation.
- [tensor_adapters](tensor_adapters.md) — Tensor backend abstraction used by processors.
