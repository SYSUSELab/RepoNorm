# Tensor Adapters Base

## Introduction

The `tensor_adapters_base` module defines the abstract interface that allows Outlines to manipulate tensors in a **library-agnostic** way. Outlines supports multiple deep learning and numerical computing frameworks (PyTorch, NumPy, JAX, MLX, TensorFlow), and the logits processors that bias generation must operate on tensors produced by whichever framework the underlying model uses.

The `TensorAdapter` abstract base class (ABC) is the contract that every concrete adapter must fulfill. It exposes a small, well-defined set of tensor operations (shape inspection, reshaping, concatenation, masking, device movement, etc.) that the higher-level logits processors rely on. By depending only on this interface, the processing pipeline never needs to know which tensor library is in use.

> **Note:** This module contains only the abstract base class. The concrete implementations live in sibling modules:
> - [tensor_adapters_torch.md](tensor_adapters_torch.md) — `TorchTensorAdapter`
> - [tensor_adapters_numpy.md](tensor_adapters_numpy.md) — `NumpyTensorAdapter`
> - [tensor_adapters_jax.md](tensor_adapters_jax.md) — `JAXTensorAdapter`
> - [tensor_adapters_mlx.md](tensor_adapters_mlx.md) — `MLXTensorAdapter`
> - [tensor_adapters_tensorflow.md](tensor_adapters_tensorflow.md) — `TensorFlowTensorAdapter`

---

## Purpose and Core Functionality

The `TensorAdapter` class solves a single, focused problem: **abstracting away the differences between tensor libraries** so that the rest of Outlines can be written once and work everywhere.

Its responsibilities are:

1. **Define a uniform tensor API** — a fixed set of operations that all supported libraries can implement.
2. **Enable polymorphic logits processing** — logits processors (see [processors_base.md](processors_base.md)) hold a `tensor_adapter` instance and call its methods without branching on the library.
3. **Bridge the `outlines-core` boundary** — some methods (`full_like`, `concatenate`) must accept raw `torch.Tensor` objects because the current version of `outlines-core` emits torch tensors, regardless of the model's native library.

---

## Architecture

The `TensorAdapter` ABC sits at the bottom of the processing stack. Concrete adapters implement it, and logits processors consume it.

```mermaid
graph TD
    subgraph "tensor_adapters_base (this module)"
        TA["TensorAdapter (ABC)"]
    end

    subgraph "Concrete Adapters"
        TORCH["TorchTensorAdapter"]
        NUMPY["NumpyTensorAdapter"]
        JAX["JAXTensorAdapter"]
        MLX["MLXTensorAdapter"]
        TF["TensorFlowTensorAdapter"]
    end

    subgraph "Consumers"
        OLP["OutlinesLogitsProcessor"]
        GLP["GuideLogitsProcessor"]
        RLP["RegexLogitsProcessor"]
        JLP["JSONLogitsProcessor"]
        CLP["CFGLogitsProcessor"]
    end

    TORCH -.implements.-> TA
    NUMPY -.implements.-> TA
    JAX -.implements.-> TA
    MLX -.implements.-> TA
    TF -.implements.-> TA

    OLP -->|holds a| TA
    GLP -->|extends| OLP
    RLP -->|extends| OLP
    JLP -->|extends| OLP
    CLP -->|extends| OLP
```

### Class Hierarchy

```mermaid
classDiagram
    class TensorAdapter {
        <<abstract>>
        +str library_name
        +shape(tensor) list[int]
        +unsqueeze(tensor) TensorType
        +squeeze(tensor) TensorType
        +to_list(tensor) list
        +to_scalar(tensor) Any
        +full_like(tensor, fill_value) TensorType
        +concatenate(tensors) TensorType
        +get_device(tensor) str
        +to_device(tensor, device) TensorType
        +boolean_ones_like(tensor) TensorType
        +apply_mask(tensor, mask, value) TensorType
        +argsort_descending(tensor) TensorType
    }

    class TorchTensorAdapter
    class NumpyTensorAdapter
    class JAXTensorAdapter
    class MLXTensorAdapter
    class TensorFlowTensorAdapter

    TensorAdapter <|-- TorchTensorAdapter
    TensorAdapter <|-- NumpyTensorAdapter
    TensorAdapter <|-- JAXTensorAdapter
    TensorAdapter <|-- MLXTensorAdapter
    TensorAdapter <|-- TensorFlowTensorAdapter
```

---

## The `TensorAdapter` Interface

### Class Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `library_name` | `str` | Identifier of the tensor library the adapter targets (e.g. `"torch"`, `"numpy"`). Used by `OutlinesLogitsProcessor` to look up the correct adapter and by `GuideLogitsProcessor.copy()` to reconstruct processors. |

### Abstract Methods

Each method below is declared `@abstractmethod` and must be implemented by every concrete adapter.

| Method | Signature | Description |
|--------|-----------|-------------|
| `shape` | `(tensor) -> list[int]` | Returns the shape of the tensor as a list with one entry per dimension. |
| `unsqueeze` | `(tensor) -> TensorType` | Adds a new dimension at axis `0`. |
| `squeeze` | `(tensor) -> TensorType` | Removes the dimension at axis `0`. |
| `to_list` | `(tensor) -> list` | Converts the tensor to a Python list. |
| `to_scalar` | `(tensor) -> Any` | Returns the single element of a scalar tensor. |
| `full_like` | `(tensor: torch.Tensor, fill_value) -> TensorType` | Creates a tensor with the same shape as the input, filled with `fill_value`. **Receives a torch tensor regardless of library.** |
| `concatenate` | `(tensors: list[torch.Tensor \| TensorType]) -> TensorType` | Concatenates tensors along axis `0`. **May receive torch tensors or native tensors.** |
| `get_device` | `(tensor) -> str` | Returns the name of the tensor's device. |
| `to_device` | `(tensor, device: str) -> TensorType` | Moves the tensor to the specified device. |
| `boolean_ones_like` | `(tensor) -> TensorType` | Creates a boolean tensor of ones with the same shape as the input. |
| `apply_mask` | `(tensor, mask, value) -> TensorType` | Fills elements where `mask` is `True` with `value`. |
| `argsort_descending` | `(tensor) -> TensorType` | Returns indices that would sort the tensor in descending order along axis `-1`. |

### The `outlines-core` Compatibility Caveat

The class docstring explicitly flags a temporary constraint:

> **TODO:** Update the version of `outlines-core` used to receive plain arrays instead of torch tensors. In the meantime, implementations of this class must make sure that their `full_like` and `concatenate` methods can handle torch tensors.

This means concrete adapters must defensively handle `torch.Tensor` inputs in `full_like` and `concatenate`, even when the model itself uses a different library. For example, `MLXTensorAdapter.full_like` reads `tensor.shape` (works on torch tensors) and `MLXTensorAdapter.concatenate` converts each element via `mlx.array(...)` when needed.

---

## Data Flow

The adapter is invoked inside the logits-processing pipeline. The following sequence shows how a `GuideLogitsProcessor` uses the adapter to build a mask and bias logits.

```mermaid
sequenceDiagram
    participant Model
    participant OLP as OutlinesLogitsProcessor.__call__
    participant TA as TensorAdapter
    participant GLP as GuideLogitsProcessor.process_logits

    Model->>OLP: __call__(input_ids, logits)
    OLP->>TA: shape(input_ids), shape(logits)
    Note over OLP: Normalize to 2D (unsqueeze if needed)
    OLP->>GLP: process_logits(input_ids, logits)
    GLP->>TA: to_list(gen_ids)
    GLP->>TA: to_scalar(gen_ids[-1])
    GLP->>TA: full_like(allowed_tokens, i)
    GLP->>TA: get_device(logits)
    GLP->>TA: concatenate(allowed_tokens_batch)
    GLP->>TA: to_device(concat, device)
    GLP->>TA: boolean_ones_like(logits)
    GLP->>TA: apply_mask(logits, mask, -inf)
    GLP-->>OLP: biased logits
    OLP->>TA: squeeze(...) if originally 1D
    OLP-->>Model: processed logits
```

### Key Flow Characteristics

- **Shape normalization:** `OutlinesLogitsProcessor.__call__` uses `shape`, `unsqueeze`, and `squeeze` to guarantee that `process_logits` always receives 2D tensors, then restores the original dimensionality.
- **State tracking:** `GuideLogitsProcessor` uses `to_list` and `to_scalar` to convert tensor slices into hashable Python values for guide-state caching.
- **Mask construction:** `full_like`, `concatenate`, `get_device`, `to_device`, and `boolean_ones_like` cooperate to build a batch-aware boolean mask.
- **Masking:** `apply_mask` writes `float("-inf")` into disallowed positions, biasing the sampler.

---

## Component Interaction

```mermaid
graph LR
    subgraph "Library Selection"
        NAME["tensor_library_name: str"]
        REG["tensor_adapters registry"]
    end

    NAME --> REG
    REG -->|lookup| TA["TensorAdapter instance"]
    TA --> OLP["OutlinesLogitsProcessor.tensor_adapter"]

    subgraph "Operations used by processors"
        TA --> S["shape / unsqueeze / squeeze"]
        TA --> C["to_list / to_scalar"]
        TA --> M["full_like / concatenate"]
        TA --> D["get_device / to_device"]
        TA --> K["boolean_ones_like / apply_mask"]
        TA --> A["argsort_descending"]
    end
```

The `tensor_library_name` string is passed to `OutlinesLogitsProcessor.__init__`, which resolves it against a registry (`tensor_adapters`) to instantiate the correct concrete adapter. If the name is unknown, a `NotImplementedError` is raised. See [processors_base.md](processors_base.md) for details on the registry and the base processor.

---

## Design Rationale

| Design Choice | Rationale |
|---------------|-----------|
| **Abstract base class** | Enforces a complete, consistent API across all libraries; missing methods fail fast at instantiation. |
| **`library_name` attribute** | Enables registry lookup and processor reconstruction (e.g. `GuideLogitsProcessor.copy()`). |
| **Torch-tolerant `full_like`/`concatenate`** | Works around the current `outlines-core` interface that emits torch tensors. |
| **Device abstraction** | `get_device`/`to_device` let processors move tensors to the correct device; libraries without device concepts (NumPy, JAX, MLX) return `None`/identity. |
| **`argsort_descending`** | Supports sampling strategies that need ranked logits (e.g. top-k style selection). |

---

## Related Modules

- [processors_base.md](processors_base.md) — `OutlinesLogitsProcessor`, the primary consumer of `TensorAdapter`.
- [processors_structured.md](processors_structured.md) — `GuideLogitsProcessor`, `RegexLogitsProcessor`, `JSONLogitsProcessor`, `CFGLogitsProcessor`.
- [processors_guides.md](processors_guides.md) — `Guide` implementations used alongside the adapter.
- [tensor_adapters_torch.md](tensor_adapters_torch.md), [tensor_adapters_numpy.md](tensor_adapters_numpy.md), [tensor_adapters_jax.md](tensor_adapters_jax.md), [tensor_adapters_mlx.md](tensor_adapters_mlx.md), [tensor_adapters_tensorflow.md](tensor_adapters_tensorflow.md) — concrete implementations.
- [models_base.md](models_base.md) — models that produce the tensors processed by these adapters.
