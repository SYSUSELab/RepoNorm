# FSM Parsing Module

## Introduction

The `fsm_parsing` module (`outlines/fsm/parsing.py`) provides the machinery to build a **finite state machine (FSM) from a context-free grammar (CFG)**. It is the foundation for *context-free grammar guided generation* in Outlines: given a Lark grammar, it constructs a parser whose internal state can be queried at every generation step to determine which tokens are legal continuations.

The module is a specialized, "partial" re-implementation of the [Lark](https://github.com/lark-parser/lark) parsing toolkit. The key insight is that Outlines does **not** need to build a full concrete syntax tree (CST) during generation — it only needs to track enough parser state to know which terminal symbols are acceptable next. This allows the parser to:

1. **Incrementally consume text** token-by-token (rather than parsing a complete document).
2. **Expose the set of legal next terminals** at any point, so a logits processor can mask out illegal tokens.
3. **Detect partial matches** where a token is a valid prefix of a terminal but not yet a complete terminal.

The module is consumed primarily by the [`CFGGuide`](processors.md) (in `outlines/processors/guide.py`), which wraps a `PartialLark` parser and drives guided generation.

---

## Architecture Overview

The module is organized as a layered stack of "partial" replacements for Lark's parsing components. Each `Partial*` class subclasses its Lark counterpart and overrides behavior to support incremental, state-queryable parsing.

```mermaid
graph TD
    subgraph "Public Entry Point"
        PL[PartialLark]
    end

    subgraph "Parsing Frontend"
        PPF[PartialParsingFrontend]
        PLC[PartialPostLexConnector]
        PLT[PartialLexerThread]
    end

    subgraph "Parser Layer"
        PLALR[PartialLALRParser]
        PP[PartialParser]
        PPS[PartialParserState]
        PPC[PartialParserConf]
    end

    subgraph "Lexer Layer"
        PCL[PartialContextualLexer]
        PBL[PartialBasicLexer]
        PS[PartialScanner]
    end

    subgraph "Post-Lexer"
        PI[PartialIndenter]
        PPI[PartialPythonIndenter]
    end

    subgraph "Data Structures"
        PTI[PartialTerminalInfo]
        PTKI[PartialTokensInfo]
    end

    PL --> PPF
    PL --> PBL
    PL --> PLALR
    PPF --> PLC
    PPF --> PLT
    PPF --> PLALR
    PPF --> PBL
    PPF --> PCL
    PLALR --> PP
    PP --> PPS
    PP --> PPC
    PCL --> PBL
    PBL --> PS
    PS --> PTI
    PS --> PTKI
    PPI --> PI
```

### Component Responsibilities

| Component | Base Class | Responsibility |
|-----------|-----------|----------------|
| `PartialLark` | `lark.Lark` | Public entry point; builds the partial lexer/parser stack from a grammar. |
| `PartialParsingFrontend` | `lark.ParsingFrontend` | Wires lexer + parser together; computes termset/FSM metadata and state-transition maps. |
| `PartialLALRParser` | `lark.LALR_Parser` | Builds the LALR parse table; supports deterministic (tuple-keyed) states. |
| `PartialParser` | `lark._Parser` | Drives parsing from a state; supports `parse_from_state`. |
| `PartialParserState` | `lark.ParserState` | Tracks the parser stack; handles `partial` tokens and stack-free parsing. |
| `PartialParserConf` | `lark.ParserConf` | Parser configuration carrying `deterministic` and `use_value_stack` flags. |
| `PartialContextualLexer` | `lark.ContextualLexer` | Selects a per-parser-state lexer based on the current parser position. |
| `PartialBasicLexer` | `lark.BasicLexer` | Tokenizes text; emits `partial` tokens for incomplete matches. |
| `PartialScanner` | `lark.Scanner` | Builds terminal FSMs and matches text against them. |
| `PartialLexerThread` | `lark.LexerThread` | Copyable lexer/state wrapper. |
| `PartialPostLexConnector` | `lark.PostLexConnector` | Copyable connector between lexer and post-lexer. |
| `PartialIndenter` | `lark.Indenter` | Stateful indentation handling (does not reset between `process` calls). |
| `PartialPythonIndenter` | `PartialIndenter` | Python-specific indenter configuration. |
| `PartialTerminalInfo` | — | Dataclass describing a terminal's priority, name, and transition/final status. |
| `PartialTokensInfo` | — | Dataclass bundling FSM state sequence and terminal info for a `partial` token. |

---

## Data Flow

The following diagram shows how text flows through the parsing stack during guided generation, and how the parser state is queried to determine legal tokens.

```mermaid
sequenceDiagram
    participant Guide as CFGGuide
    participant Parser as PartialLark
    participant State as PartialParserState
    participant CLexer as PartialContextualLexer
    participant BLexer as PartialBasicLexer
    participant Scanner as PartialScanner

    Guide->>Parser: parse_from_state(state, is_end=False)
    Parser->>State: feed_token / lex
    State->>CLexer: lex(lexer_state, parser_state)
    CLexer->>BLexer: next_token (per parser position)
    BLexer->>Scanner: match(text, pos, last_fsm_state_seq)
    Scanner-->>BLexer: fsm_state_seq
    BLexer->>Scanner: get_terminals_info(fsm_state_seq)
    Scanner-->>BLexer: (terminals_and_info, final_terminals_and_info)
    BLexer-->>CLexer: Token (or "partial" token)
    CLexer-->>State: Token
    State->>State: feed_token (shift/reduce)
    State-->>Guide: updated PartialParserState
```

### The "Partial" Token Concept

The central innovation is the **`partial` token**. When the lexer matches text that is a valid *prefix* of one or more terminals but has not yet reached a final state, it emits a token of type `"partial"` whose value is a `PartialTokensInfo` object. This object carries:

- `fsm_state_seq`: the sequence of FSM states traversed so far.
- `is_not_finished`: whether more input is expected.
- `terminals_and_info`: all terminals consistent with the current FSM state.
- `final_terminals_and_info`: the subset of terminals that are in a final (accepting) state.

This allows the parser to defer committing to a terminal until enough text has been consumed, while still being able to answer "what can come next?".

---

## Component Interaction

### Lexer Construction and Terminal FSMs

`PartialScanner` builds a single union FSM from all terminal FSMs. The `fsm_union` function (a modified version of `interegular.fsm.FSM.union`) returns both the aggregate FSM and a map (`fsms_to_trans_finals`) that tracks, for each component FSM, its state transitions, final states, and a mapping from component states to aggregate states.

```mermaid
graph LR
    T1[Terminal 1 regex] --> F1[FSM 1]
    T2[Terminal 2 regex] --> F2[FSM 2]
    T3[Terminal N regex] --> F3[FSM N]
    F1 --> U[fsm_union]
    F2 --> U
    F3 --> U
    U --> AF[Aggregate FSM]
    U --> MAP[fsms_to_trans_finals]
    AF --> SC[PartialScanner]
    MAP --> SC
```

`PartialScanner.get_terminals_info` uses `get_sub_fsms_from_seq` to determine which component FSMs could have produced a given state sequence, returning `PartialTerminalInfo` records for each.

### Parser State and Stack-Free Parsing

`PartialParserState` extends Lark's `ParserState` with two important behaviors:

1. **`partial` token handling** (`feed_token`): When a `partial` token arrives, the parser tests each candidate terminal by attempting to feed a synthetic token. If none can transition, it raises `UnexpectedToken` — this catches invalid REDUCE cases that would otherwise be missed.

2. **Stack-free parsing** (`feed_token_no_stack`): When `use_value_stack=False`, the parser skips all value-stack (CST-building) operations, since Outlines only needs the state stack. This avoids the growing cost of tracking a parse tree.

```mermaid
flowchart TD
    A[feed_token called] --> B{token.type == 'partial'?}
    B -->|Yes| C[Test each candidate terminal]
    C --> D{Any can transition?}
    D -->|No| E[Raise UnexpectedToken]
    D -->|Yes| F[Continue]
    B -->|No| G{use_value_stack?}
    G -->|Yes| H[super().feed_token]
    G -->|No| I[feed_token_no_stack]
    F --> G
```

### Deterministic Parse Tables

`PartialLALRParser` supports a `deterministic` mode in which parse-table states (which are normally `frozenset`s) are converted to sorted tuples. This makes states hashable and comparable in a stable order, and allows the parse table to be converted to an `IntParseTable` for performance. The `states_to_rulesets` mapping preserves the correspondence between integer states and the original rule sets.

### Contextual Lexing

`PartialContextualLexer` maintains a separate `PartialBasicLexer` per parser state (or per unique set of accepted terminals). During lexing, it looks up the lexer for the current `parser_state.position` and delegates tokenization to it. This ensures that only terminals valid in the current parser state are considered.

---

## Process Flow: Guided Generation with a CFG

The following diagram shows the end-to-end flow when a `CFGGuide` uses this module to guide generation.

```mermaid
flowchart TD
    Start[CFG string + tokenizer] --> Build[PartialLark builds parser]
    Build --> Init[CFGGuide.initial_state = parse of empty string]
    Init --> Loop{Generation step}
    Loop --> Query[get_next_instruction]
    Query --> Iter[iter_valid_token_ids over vocabulary]
    Iter --> Apply[Apply token to copied parser state]
    Apply --> Valid{Valid?}
    Valid -->|Yes| Yield[Yield token id]
    Valid -->|No| Skip[Skip token]
    Yield --> Mask[Mask logits to valid tokens]
    Skip --> Iter
    Mask --> Sample[Sample next token]
    Sample --> Update[get_next_state]
    Update --> Loop
    Loop -->|EOS| End[Terminate]
```

Key methods used by the guide:

- `PartialLark.parse_from_state(state, is_end)`: advances the parser by one token.
- `PartialParserState.feed_eof()`: checks whether the current state can legally terminate.
- `PartialParserState.accepts()`: returns the set of terminals that can advance the parser.
- `PartialParserState.choices()`: returns the parse-table transitions for the current position.

---

## Relationship to Other Modules

The `fsm_parsing` module sits at the boundary between grammar definitions and token-level generation control.

```mermaid
graph TD
    DSL[types_dsl: CFG] -->|definition string| FP[fsm_parsing]
    FP -->|PartialLark| Guide[processors/guide: CFGGuide]
    Guide -->|Guide| Struct[processors/structured: CFGLogitsProcessor]
    Struct -->|masked logits| Models[models/*]
    Tokenizer[models/tokenizer: Tokenizer] -->|vocabulary| Guide
    Core[outlines_core.fsm.regex] -->|BetterFSM, make_deterministic_fsm| FP
```

- **[types_dsl](types_dsl.md)**: The `CFG` term class represents a context-free grammar definition. Its `definition` string is passed to `PartialLark`.
- **[processors](processors.md)**: `CFGGuide` wraps a `PartialLark` instance and implements the `Guide` interface (`get_next_instruction`, `get_next_state`, `is_final_state`). `CFGLogitsProcessor` uses the guide to mask logits.
- **[models](models.md)**: The `Tokenizer` interface provides the vocabulary and decode/encode methods used to map between token ids and text.
- **`outlines_core.fsm.regex`**: Provides `BetterFSM`, `make_deterministic_fsm`, and `get_token_transition_keys`, which are used to build and traverse terminal FSMs.

---

## Key Functions

### `fsm_union(fsms)`

Constructs an aggregate FSM representing the union of the input FSMs. Unlike `interegular`'s version, it returns an additional `fsms_to_trans_finals` map that records, for each component FSM:

- the set of state-to-state transitions in the aggregate FSM,
- the set of final states,
- a mapping from component states to aggregate states.

This metadata is essential for `get_sub_fsms_from_seq` to determine which terminals match a given state sequence.

### `get_sub_fsms_from_seq(state_seq, fsms_to_trans_finals)`

Given a state sequence and the union metadata, yields tuples `(fsm_idx, can_continue, is_final)` for each component FSM whose transitions are a superset of the sequence's transitions. This is how the lexer determines which terminals are still viable.

### `walk_fsm(fsm, token_transition_keys, start_state, full_match)`

Traverses an FSM given a sequence of transition keys, returning the list of accepted states. When `full_match=False`, it returns the longest prefix that ends in a final state (useful for partial matching).

### `terminals_to_fsms(lp)`

Builds a dictionary mapping terminal names to their FSMs from a `PartialLark` instance. Terminals whose patterns are unsupported by `interegular` map to `None`.

### `get_contextual_lexer(x)`

Helper that unwraps a `PartialLexerThread` or `PartialParsingFrontend` to retrieve the underlying `ContextualLexer`.

---

## Design Notes and Caveats

- **Experimental status**: CFG-guided generation is community-contributed and experimental. The `CFGGuide` emits a warning to this effect.
- **No value stack by default**: By default `use_value_stack=False`, meaning no CST is built. This is a deliberate performance optimization.
- **Prefix/postfix unsupported**: `PartialScanner` asserts that terminal patterns have no prefix/postfix (`(0, 0)`), as these are not currently supported.
- **Deterministic mode**: When `deterministic=True`, parse-table states are converted to sorted tuples and optionally to an `IntParseTable`, improving performance and enabling stable state comparison.
- **Copy semantics**: Many components implement `__copy__` to support the guide's need to fork parser state without side effects (e.g., `PartialParserState.__copy__`, `PartialLexerThread.__copy__`, `PartialIndenter.__copy__`).
- **Indenter statefulness**: `PartialIndenter` overrides `process` to avoid resetting indentation state on each call, which is necessary for incremental parsing.

---

## Summary

The `fsm_parsing` module is a specialized parsing engine that transforms context-free grammars into queryable finite state machines. By replacing Lark's tree-building parser with a "partial" variant that tracks only the state stack and exposes legal next terminals, it enables token-level constrained generation. It is the core dependency of the [`CFGGuide`](processors.md) and, through it, of CFG-based structured generation across all supported [models](models.md).
