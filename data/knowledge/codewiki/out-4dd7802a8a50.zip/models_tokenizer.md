# Models Tokenizer Module

## Introduction

The `models_tokenizer` module provides a unified abstraction for tokenizers used across the various model integrations in Outlines. It defines a common `Tokenizer` protocol that all model-specific tokenizers implement, enabling the rest of the library (logits processors, guides, generators) to interact with tokenizers in a consistent, backend-agnostic way.

The module is composed of three core components:

- **`Tokenizer`** (`outlines/models/tokenizer.py`) — a `Protocol` defining the interface every tokenizer must satisfy.
- **`TransformerTokenizer`** (`outlines/models/transformers.py`) — the concrete implementation for Hugging Face `transformers` tokenizers.
- **`LlamaCppTokenizer`** (`outlines/models/llamacpp.py`) — the concrete implementation for `llama-cpp-python` tokenizers.

By standardizing tokenization behind a single interface, Outlines can build structured-generation machinery (regex/CFG guides, logits processors) that works identically regardless of the underlying inference backend.

---

## Purpose and Core Functionality

The tokenizer abstraction exists to solve a fundamental problem in structured generation: **the constraint machinery must know exactly how text maps to token IDs and back**. Different backends (Hugging Face, llama.cpp, vLLM, MLX, etc.) expose tokenizers with wildly different APIs. The `Tokenizer` protocol normalizes these differences.

Key responsibilities of a tokenizer in Outlines:

1. **Encoding** — convert prompts (strings or lists of strings) into token ID arrays plus attention masks.
2. **Decoding** — convert token ID arrays back into strings.
3. **Vocabulary access** — expose the mapping from token strings to token IDs, which guides use to build finite-state machines over the vocabulary.
4. **Special token handling** — expose EOS/PAD token IDs and the set of special tokens.
5. **Token-to-string conversion** — handle backend-specific quirks (e.g., BPE whitespace markers like `Ġ` or the SentencePiece underline `▁`).

---

## Architecture

The module follows a **protocol + concrete implementations** pattern. The `Tokenizer` protocol defines the contract, and each model integration supplies its own implementation.

```mermaid
classDiagram
    class Tokenizer {
        <<Protocol>>
        +str eos_token
        +int eos_token_id
        +int pad_token_id
        +Dict~str,int~ vocabulary
        +Set~str~ special_tokens
        +encode(prompt) Tuple
        +decode(token_ids) List~str~
        +convert_token_to_string(token) str
    }

    class TransformerTokenizer {
        +PreTrainedTokenizer tokenizer
        +bool is_llama
        +encode(prompt, **kwargs)
        +decode(token_ids)
        +convert_token_to_string(token)
        +__eq__(other)
        +__hash__()
        +__getstate__()
        +__setstate__(state)
    }

    class LlamaCppTokenizer {
        +Llama model
        +_hf_tokenizer
        +encode(prompt, add_bos, special)
        +decode(token_ids)
        +convert_token_to_string(token)
        +__eq__(other)
        +__hash__()
        +__getstate__()
        +__setstate__(state)
    }

    Tokenizer <|.. TransformerTokenizer : implements
    Tokenizer <|.. LlamaCppTokenizer : implements
```

### Component Relationships

The tokenizer is consumed by model wrappers and by the structured-generation pipeline. The diagram below shows how the tokenizer fits into the broader system.

```mermaid
graph TD
    subgraph "models_tokenizer module"
        T[Tokenizer Protocol]
        TT[TransformerTokenizer]
        LT[LlamaCppTokenizer]
    end

    subgraph "Model Wrappers"
        TR[Transformers]
        TRM[TransformersMultiModal]
        LC[LlamaCpp]
    end

    subgraph "Structured Generation"
        GP[Guide / RegexGuide / CFGGuide]
        LP[OutlinesLogitsProcessor]
        GEN[Generator]
    end

    TT -.implements.-> T
    LT -.implements.-> T

    TR --> TT
    TRM --> TT
    LC --> LT

    TR --> GEN
    LC --> GEN
    GEN --> LP
    LP --> GP
    GP -.uses vocabulary.-> T
```

---

## The `Tokenizer` Protocol

The `Tokenizer` protocol (`outlines/models/tokenizer.py`) is the central contract. It inherits from `Hashable` and `Protocol`, meaning implementations must be hashable (important for caching) and structurally conform to the interface.

### Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `eos_token` | `str` | The end-of-sequence token string. |
| `eos_token_id` | `int` | The token ID corresponding to the EOS token. |
| `pad_token_id` | `int` | The token ID used for padding. |
| `vocabulary` | `Dict[str, int]` | Mapping from token strings to token IDs. Used by guides to build FSMs. |
| `special_tokens` | `Set[str]` | The set of special tokens (e.g., `<s>`, `</s>`, `<pad>`). |

### Methods

| Method | Signature | Description |
|--------|-----------|-------------|
| `encode` | `(prompt: Union[str, List[str]]) -> Tuple[NDArray[np.int64], NDArray[np.int64]]` | Translate prompts into arrays of token IDs and attention masks. |
| `decode` | `(token_ids: NDArray[np.int64]) -> List[str]` | Translate an array of token IDs to a string or list of strings. |
| `convert_token_to_string` | `(token: str) -> str` | Convert a token to its equivalent string, handling BPE/SentencePiece quirks. |

> **Note on `convert_token_to_string`:** This method is essential for BPE tokenizers where whitespace is represented by special characters such as `Ġ` (GPT-style) or `▁` (SentencePiece). Without this conversion, a raw token containing `Ġ` would never match a plain string during guide construction.

---

## Concrete Implementations

### `TransformerTokenizer`

Located in `outlines/models/transformers.py`, this class wraps a Hugging Face `PreTrainedTokenizer`.

**Initialization behavior:**

- Copies `eos_token_id`, `eos_token`, and `pad_token_id` from the wrapped tokenizer.
- If the wrapped tokenizer has no `pad_token_id`, it falls back to the `eos_token_id`.
- Populates `special_tokens` from `tokenizer.all_special_tokens`.
- Populates `vocabulary` from `tokenizer.get_vocab()`.
- Detects whether the tokenizer is a Llama-family tokenizer (via `get_llama_tokenizer_types()`), setting the `is_llama` flag.

**Encoding:** Forces `padding=True` and `return_tensors="pt"`, returning `(input_ids, attention_mask)` as PyTorch tensors.

**Decoding:** Uses `batch_decode` with `skip_special_tokens=True`.

**Llama work-around:** For Llama tokenizers, `convert_token_to_string` prepends a space when the token starts with the SentencePiece underline (`SPIECE_UNDERLINE`) or equals `<0x20>`, compensating for missing spaces in HF's Llama tokenizers.

**Hashing and equality:** Equality compares the underlying tokenizer (or `model_name`/`kwargs` if present). Hashing uses `datasets.fingerprint.Hasher` over the tokenizer, which is important for the caching layer (see [caching.md](caching.md)).

**Pickling:** `__getstate__`/`__setstate__` serialize only the wrapped tokenizer, allowing reconstruction.

### `LlamaCppTokenizer`

Located in `outlines/models/llamacpp.py`, this class wraps a `llama_cpp.Llama` model's tokenizer.

**Initialization behavior:**

- Derives `eos_token_id` from `model.token_eos()` and decodes it to obtain `eos_token`.
- Sets `pad_token_id` equal to `eos_token_id`.
- Attempts to obtain the vocabulary from an underlying Hugging Face tokenizer (`model.tokenizer_.hf_tokenizer`). If unavailable, it iterates over all `n_vocab()` tokens, decoding each to build the vocabulary.
- Sorts the vocabulary by token ID to ensure stable ordering.

**Encoding:** Does **not** support batch tokenization (raises `NotImplementedError` for list inputs). Manually constructs an attention mask since `llama-cpp-python` does not provide one.

**Decoding:** Uses `detokenize` and decodes bytes with `errors="ignore"`.

**Hashing:** Uses a custom hash over the sorted vocabulary, EOS/PAD IDs, and special tokens, because `pickle.dumps(self)` is not stable for this tokenizer.

**Pickling:** `__getstate__` produces a stable representation for the caching layer, but `__setstate__` raises `NotImplementedError` — a pickled LlamaCpp tokenizer cannot be reloaded.

---

## Data Flow

The following sequence diagram illustrates how a tokenizer participates in a typical structured-generation request.

```mermaid
sequenceDiagram
    participant User
    participant Model as Model Wrapper
    participant Tok as Tokenizer
    participant Guide as Guide (FSM)
    participant LP as LogitsProcessor

    User->>Model: generate(prompt, output_type)
    Model->>Tok: encode(prompt)
    Tok-->>Model: (input_ids, attention_mask)
    Model->>Guide: build FSM using vocabulary
    Guide-->>Model: guide state
    loop token generation
        Model->>LP: process_logits(input_ids, logits)
        LP->>Guide: get allowed tokens
        Guide-->>LP: token mask
        LP-->>Model: masked logits
    end
    Model->>Tok: decode(generated_ids)
    Tok-->>Model: generated text
    Model-->>User: text
```

---

## Integration with Other Modules

The tokenizer module is a foundational dependency for several other parts of Outlines:

- **[models_base.md](models_base.md)** — The `Model` and `ModelTypeAdapter` base classes. Model wrappers instantiate a tokenizer and use it during `generate`.
- **[models_local.md](models_local.md)** — Local model integrations (`Transformers`, `LlamaCpp`, `MLXLM`, `VLLMOffline`) each construct a tokenizer from this module.
- **[models_api.md](models_api.md)** — API-based models do not use this tokenizer abstraction directly (they rely on server-side tokenization).
- **[models_server.md](models_server.md)** — Server-based models (vLLM, SGLang, TGI) similarly delegate tokenization to the server.
- **[processors.md](processors.md)** — `OutlinesLogitsProcessor` and its subclasses rely on the tokenizer's vocabulary to build token masks.
- **[caching.md](caching.md)** — The `__hash__` and `__getstate__` implementations are designed to support the caching layer (`CloudpickleDisk`).

---

## Design Considerations

### Why a Protocol?

Using a `Protocol` (rather than an abstract base class) allows tokenizers to be structurally typed. Any object exposing the required attributes and methods satisfies the interface, which keeps the abstraction lightweight and avoids forcing inheritance.

### Hashability and Caching

Both concrete implementations provide custom `__hash__` and `__getstate__` methods. This is critical because guides and logits processors are cached based on the tokenizer's identity. A stable hash ensures that identical tokenizers produce identical cache keys, while a stable `__getstate__` ensures correct serialization.

### Backend-Specific Quirks

The `convert_token_to_string` method encapsulates the messy reality of tokenization:

- **GPT-style BPE** uses `Ġ` to represent leading whitespace.
- **SentencePiece** (Llama, T5) uses `▁` (`SPIECE_UNDERLINE`).
- **llama.cpp** may or may not expose an underlying HF tokenizer, requiring two different code paths.

Centralizing these quirks in the tokenizer keeps the guide-building logic clean and backend-agnostic.

### Batch Support

`TransformerTokenizer` supports batched encoding, while `LlamaCppTokenizer` explicitly does not. This asymmetry reflects the capabilities of the underlying libraries and is surfaced to users through `NotImplementedError` where unsupported.
