# benchmarks_json_schema

## Introduction

The `benchmarks_json_schema` module provides performance benchmarks for the **JSON schema → FSM (Finite State Machine) compilation pipeline** in Outlines. It measures how long it takes to convert a JSON schema into a regular expression and then build a `RegexGuide` (the state machine that constrains token generation) from that regex.

This benchmark isolates the *setup/compilation* cost of structured JSON generation — the work that happens **before** any tokens are sampled. It does not benchmark the per-token masking cost (that is covered by [benchmarks_processors](benchmarks_processors.md)) nor the raw regex-to-guide conversion (covered by [benchmarks_guide](benchmarks_guide.md)).

The module is built on top of the [pytest-benchmark](https://pytest-benchmark.readthedocs.io/) framework, where each benchmark class exposes `params`, a `setup` method, and one or more `time_*` / `peakmem_*` methods.

---

## Core Component

### `JsonSchemaBenchmark`

The single core component of this module. It benchmarks the end-to-end conversion of a JSON schema into a `RegexGuide`.

```python
class JsonSchemaBenchmark:
    params = schemas.keys()

    def setup(self, schema_name):
        self.tokenizer = setup_tokenizer()
        self.schema = schemas[schema_name]

    @cache_disabled()
    def time_json_schema_to_fsm(self, schema_name):
        regex = build_regex_from_schema(self.schema)
        RegexGuide.from_regex(regex, self.tokenizer)
```

| Member | Purpose |
| --- | --- |
| `params` | Iterates over the keys of the `schemas` dict (`simple_schema`, `complex_schema`), parameterizing the benchmark across schema complexity. |
| `setup(schema_name)` | Loads a GPT-2 tokenizer via `setup_tokenizer()` and selects the schema under test. Runs once per parameter combination. |
| `time_json_schema_to_fsm(schema_name)` | The timed operation: builds a regex from the schema, then compiles it into a `RegexGuide`. |

#### Benchmark Inputs

Two representative schemas are defined at module level:

- **`simple_schema`** — a small `Character` object with a `$defs`/`$ref` enum (`Armor`), string and integer properties, and a `maxLength` constraint. Exercises `$defs`, `$ref`, `enum`, and `maxLength`.
- **`complex_schema`** — a draft-04 "recording" schema with nested objects, arrays, `definitions`/`$ref` reuse, and required fields. Exercises deeper nesting and array item references.

These two inputs let the benchmark capture how compilation cost scales with schema complexity.

---

## Architecture

The benchmark sits at the boundary between the JSON-schema tooling and the guide/FSM machinery. It orchestrates two library calls and wraps them in a cache-disabled context.

```mermaid
graph TD
    subgraph "benchmarks_json_schema"
        B["JsonSchemaBenchmark"]
        S1["simple_schema"]
        S2["complex_schema"]
    end

    subgraph "outlines_core"
        BRS["build_regex_from_schema"]
    end

    subgraph "outlines"
        RG["RegexGuide.from_regex"]
        CD["cache_disabled"]
        TOK["setup_tokenizer"]
    end

    subgraph "outlines.processors"
        CRG["CoreRegexGuide"]
    end

    S1 --> B
    S2 --> B
    B -->|"schema"| BRS
    BRS -->|"regex string"| RG
    B -->|"tokenizer"| TOK
    TOK --> RG
    B -->|"context manager"| CD
    RG -->|"subclass of"| CRG
```

### Key Relationships

- **`build_regex_from_schema`** (from `outlines_core.fsm.json_schema`) converts a JSON schema string into a regex string. This is the same function used in production by [`JSONLogitsProcessor`](processors_structured.md).
- **`RegexGuide.from_regex`** (from [outlines.processors.guide](processors_guide.md)) compiles the regex into a state machine. It is a thin wrapper around `CoreRegexGuide` that injects a cached `create_states_mapping` function.
- **`cache_disabled`** (from [outlines.caching](caching.md)) temporarily disables the global caching layer so that each benchmark iteration performs the *full* compilation rather than returning a cached result. This is essential for accurate timing.
- **`setup_tokenizer`** (from `benchmarks.common`) loads a GPT-2 tokenizer wrapped in a `TransformerTokenizer`.

---

## Data Flow

The benchmark measures a two-stage compilation pipeline. The diagram below shows the flow of data through the timed method.

```mermaid
sequenceDiagram
    participant PB as pytest-benchmark
    participant B as JsonSchemaBenchmark
    participant CD as cache_disabled
    participant BRS as build_regex_from_schema
    participant RG as RegexGuide.from_regex
    participant TOK as setup_tokenizer

    PB->>B: setup(schema_name)
    B->>TOK: setup_tokenizer()
    TOK-->>B: TransformerTokenizer (gpt2)
    B->>B: self.schema = schemas[schema_name]

    PB->>B: time_json_schema_to_fsm(schema_name)
    B->>CD: enter (disable cache)
    B->>BRS: build_regex_from_schema(self.schema)
    BRS-->>B: regex string
    B->>RG: from_regex(regex, tokenizer)
    RG-->>B: RegexGuide (FSM)
    B->>CD: exit (restore cache)
```

### Stage Breakdown

| Stage | Operation | Input | Output |
| --- | --- | --- | --- |
| 1 | `build_regex_from_schema` | JSON schema string | Regex string |
| 2 | `RegexGuide.from_regex` | Regex string + tokenizer | `RegexGuide` FSM |

Both stages are timed together as a single unit (`time_json_schema_to_fsm`), reflecting the real-world cost a user pays when constructing a `JSONLogitsProcessor`.

---

## Position in the Benchmark Suite

`benchmarks_json_schema` is one of three sibling benchmark modules, each targeting a different layer of the structured-generation stack:

```mermaid
graph LR
    subgraph "Compilation (setup cost)"
        JS["benchmarks_json_schema<br/>schema → regex → guide"]
        RG["benchmarks_guide<br/>regex → guide"]
        CFG["benchmarks_guide<br/>CFG → guide"]
    end
    subgraph "Runtime (per-token cost)"
        PR["benchmarks_processors<br/>mask application"]
    end

    JS -->|"uses"| RG
    JS -->|"uses"| CFG
    PR -->|"consumes guides from"| JS
```

| Module | What it benchmarks | Relationship |
| --- | --- | --- |
| **benchmarks_json_schema** (this) | JSON schema → regex → `RegexGuide` | Highest-level compilation benchmark |
| [benchmarks_guide](benchmarks_guide.md) | Regex/CFG → guide conversion | Lower-level primitive reused here |
| [benchmarks_processors](benchmarks_processors.md) | Per-token logits masking | Consumes the guides produced by this pipeline |

---

## Process Flow

The full lifecycle of a single benchmark run:

```mermaid
flowchart TD
    A["pytest-benchmark collects JsonSchemaBenchmark"] --> B["For each schema in params"]
    B --> C["setup(schema_name)"]
    C --> C1["setup_tokenizer() → gpt2 tokenizer"]
    C --> C2["select schema (simple/complex)"]
    C1 --> D["time_json_schema_to_fsm(schema_name)"]
    C2 --> D
    D --> E["cache_disabled() context"]
    E --> F["build_regex_from_schema(schema)"]
    F --> G["RegexGuide.from_regex(regex, tokenizer)"]
    G --> H["Record timing"]
    H --> I{"More params?"}
    I -->|Yes| B
    I -->|No| J["Report benchmark results"]
```

---

## Design Notes

- **Cache disabling is critical.** `RegexGuide.from_regex` uses `cached_create_states_mapping` internally. Without `@cache_disabled()`, repeated benchmark iterations would hit the cache and report artificially low (near-zero) times. The decorator ensures every iteration performs genuine work.
- **Tokenizer reuse.** The tokenizer is created once in `setup` and reused across iterations, so tokenizer loading cost is excluded from the timed method.
- **Schema complexity as a parameter.** By parameterizing over `simple_schema` and `complex_schema`, the benchmark reveals how compilation cost grows with schema features such as `$ref`, `enum`, arrays, and nesting depth.

---

## Related Documentation

- [benchmarks_guide](benchmarks_guide.md) — Regex and CFG guide benchmarks (the primitive used here)
- [benchmarks_processors](benchmarks_processors.md) — Runtime logits-masking benchmarks
- [processors_guide](processors_guide.md) — `RegexGuide`, `CFGGuide`, and the `Guide` abstraction
- [processors_structured](processors_structured.md) — `JSONLogitsProcessor` and other structured processors that consume this pipeline
- [caching](caching.md) — The caching layer disabled during benchmarking
- [types_dsl](types_dsl.md) — `JsonSchema` type used to normalize schema inputs
