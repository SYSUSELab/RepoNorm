# v0_legacy_samplers

## Introduction

The `v0_legacy_samplers` module (`outlines/v0_legacy/samplers.py`) defines the sampling
strategies used by the **legacy (v0) Outlines API**. It provides a small, dependency-free
set of classes that describe *how* tokens should be selected during generation:

- **Greedy** decoding (always pick the most likely token)
- **Multinomial** sampling (sample from the next-token distribution, with optional
  `top_k`, `top_p`, and `temperature` controls)
- **Beam search** (explore multiple candidate sequences in parallel)

A key design point of the v0 legacy API is that **the generation loop is delegated to the
models themselves**. As a result, samplers in this module do *not* perform any token
selection directly. Instead, each sampler is a lightweight configuration object whose only
job is to produce a `SamplingParameters` dataclass that is passed down to the model.

> **Note:** This module is part of the deprecated `v0_legacy` package. New code should use
> the current `Generator`-based API. See [generator.md](generator.md) and
> [models_base.md](models_base.md) for the modern equivalents.

---

## Module Purpose

The module answers a single question: *"What sampling configuration should be handed to
the model?"* It does so by exposing:

1. A frozen dataclass, `SamplingParameters`, that carries the sampling configuration.
2. A `Sampler` protocol that all samplers conform to.
3. Three concrete sampler implementations: `GreedySampler`, `MultinomialSampler`, and
   `BeamSearchSampler`.
4. Lowercase aliases (`greedy`, `multinomial`, `beam_search`) for ergonomic use.

---

## Architecture

The module is intentionally flat and has **no internal dependencies** — it only relies on
the Python standard library (`dataclasses`, `typing`). Its outputs are consumed by the
legacy generation bridge and, ultimately, by the models.

```mermaid
graph TD
    subgraph "v0_legacy_samplers"
        SP["SamplingParameters<br/>(frozen dataclass)"]
        S["Sampler<br/>(Protocol)"]
        G["GreedySampler"]
        M["MultinomialSampler"]
        B["BeamSearchSampler"]
    end

    G -- "implements" --> S
    M -- "implements" --> S
    B -- "implements" --> S

    G -- "produces" --> SP
    M -- "produces" --> SP
    B -- "produces" --> SP

    SP -- "consumed by" --> ADAPTER["GeneratorV0Adapter<br/>(v0_legacy_generate)"]
    ADAPTER -- "passes params to" --> MODEL["Model<br/>(models_base)"]
```

### Component Relationships

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `SamplingParameters` | `@dataclass(frozen=True)` | Immutable container for the sampling configuration. |
| `Sampler` | `Protocol` | Structural interface requiring a `samples` attribute and a `sampling_params` property. |
| `GreedySampler` | Class | Always selects the most likely token; exactly one sample. |
| `MultinomialSampler` | Class | Randomly samples tokens from the next-token distribution. |
| `BeamSearchSampler` | Class | Explores `beams` candidate sequences. |

---

## Core Components

### `SamplingParameters`

A frozen (immutable) dataclass that is the canonical representation of a sampling
configuration. Because it is frozen, it is hashable and safe to share across threads.

```python
@dataclass(frozen=True)
class SamplingParameters:
    sampler: str
    num_samples: int = 1
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    temperature: Optional[float] = None
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `sampler` | `str` | — | Identifier of the sampling strategy (`"greedy"`, `"multinomial"`, `"beam_search"`). |
| `num_samples` | `int` | `1` | Number of samples (or beams) to generate per input. |
| `top_p` | `Optional[float]` | `None` | Nucleus sampling threshold. |
| `top_k` | `Optional[int]` | `None` | Top-k sampling cutoff. |
| `temperature` | `Optional[float]` | `None` | Softmax temperature applied to logits. |

### `Sampler` (Protocol)

A `typing.Protocol` that defines the structural contract every sampler must satisfy. Any
object exposing a `samples` attribute and a `sampling_params` property is considered a
valid sampler (no explicit inheritance required).

```python
class Sampler(Protocol):
    samples: int

    def sampling_params(self) -> SamplingParameters:
        ...
```

The docstring makes the design intent explicit: *"the samplers are only used to define the
sampling parameters that are passed to the model."*

### `GreedySampler`

Chooses the token with the largest likelihood at every step. Only a single sample is
allowed (`samples = 1`). The docstring notes that allowing more samples would be
equivalent to beam search without sequence weights.

```python
class GreedySampler:
    def __init__(self):
        self.samples = 1

    @property
    def sampling_params(self):
        return SamplingParameters("greedy", self.samples, None, None, 0.0)
```

- `samples` is fixed at `1`.
- `temperature` is set to `0.0` to signal deterministic decoding.

### `MultinomialSampler`

Samples the next token from a Categorical distribution parameterized by the next-token
logits. Supports the standard decoding controls.

```python
class MultinomialSampler:
    def __init__(
        self,
        samples: int = 1,
        *,
        top_k: Optional[int] = None,
        top_p: Optional[float] = None,
        temperature: Optional[float] = None,
    ):
        self.samples = samples
        self.top_k = top_k
        self.top_p = top_p
        self.temperature = temperature
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `samples` | `int` | `1` | Number of samples per input sequence. |
| `top_k` | `Optional[int]` | `None` | Restrict sampling to the `k` most likely tokens. |
| `top_p` | `Optional[float]` | `None` | Nucleus sampling probability mass. |
| `temperature` | `Optional[float]` | `None` | Logit temperature. |

### `BeamSearchSampler`

Explores multiple candidate sequences simultaneously. The number of beams is stored in the
`samples` attribute.

```python
class BeamSearchSampler:
    def __init__(self, beams: int = 1):
        self.samples = beams

    @property
    def sampling_params(self):
        return SamplingParameters("beam_search", self.samples, None, None, 1.0)
```

- `beams` maps directly to `samples`.
- `temperature` is set to `1.0`.

### Aliases

For convenience, lowercase aliases are provided:

```python
greedy = GreedySampler
multinomial = MultinomialSampler
beam_search = BeamSearchSampler
```

---

## Data Flow

The following diagram shows how a sampler's configuration flows from user code, through
the legacy generation bridge, and into the model.

```mermaid
sequenceDiagram
    participant User
    participant Sampler as GreedySampler / MultinomialSampler / BeamSearchSampler
    participant Adapter as GeneratorV0Adapter
    participant Model as Model

    User->>Sampler: instantiate (e.g. multinomial(samples=2, top_k=5))
    User->>Adapter: generate.json(model, schema, sampler)
    Adapter->>Sampler: read .sampling_params
    Adapter->>Adapter: asdict(sampler.sampling_params)
    Adapter->>Model: create_inference_params(...) -> model call
    Model-->>User: generated text
```

The `GeneratorV0Adapter` (see [v0_legacy_generate.md](v0_legacy_generate.md)) converts the
`SamplingParameters` dataclass into a plain dictionary via `asdict(...)` and merges it with
generation parameters (`max_tokens`, `stop_at`, `seed`) before handing everything to the
model.

---

## Process Flow: Choosing a Sampler

```mermaid
flowchart TD
    Start([Need to generate]) --> Q1{Deterministic<br/>output desired?}
    Q1 -- Yes --> Greedy["Use GreedySampler<br/>samples=1, temperature=0.0"]
    Q1 -- No --> Q2{Explore multiple<br/>candidate sequences?}
    Q2 -- Yes --> Beam["Use BeamSearchSampler<br/>beams=N"]
    Q2 -- No --> Multi["Use MultinomialSampler<br/>samples, top_k, top_p, temperature"]
    Greedy --> Params["SamplingParameters"]
    Beam --> Params
    Multi --> Params
    Params --> Model["Passed to Model"]
```

---

## Integration with the Broader System

The samplers module sits at the boundary between user-facing configuration and the model
execution layer. It is referenced by:

- **[v0_legacy_generate.md](v0_legacy_generate.md)** — `GeneratorV0Adapter` reads
  `sampler.sampling_params` and converts it into model inference parameters.
- **[v0_legacy_function.md](v0_legacy_function.md)** — `Function` objects initialize a
  generator (via `generate.json`) that ultimately consumes a sampler.
- **[models_base.md](models_base.md)** — the `Model` base class receives the resulting
  inference parameters and performs the actual generation loop.

Because the module has no dependencies of its own, it can be imported and used in
isolation, which makes it easy to test and reason about.

---

## Summary

The `v0_legacy_samplers` module is a small, self-contained configuration layer for the
legacy Outlines API. Its three samplers (`GreedySampler`, `MultinomialSampler`,
`BeamSearchSampler`) each produce an immutable `SamplingParameters` dataclass that is
forwarded to the model, which owns the actual generation loop. The `Sampler` protocol
defines the minimal structural contract, and lowercase aliases provide a convenient,
functional-style API.
