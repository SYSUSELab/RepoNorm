# Models API Module

## Introduction

The `models_api` module provides integrations with **remote, API-based language model providers**. Unlike local models (see [models_local.md](models_local.md)) or self-hosted server models (see [models_server.md](models_server.md)), these models are accessed over the network through vendor-specific client libraries.

The module wraps each provider's client into a uniform Outlines `Model` interface, so that the same high-level generation API works regardless of the underlying provider. Each provider is implemented as a pair of classes:

- A **`Model`** subclass (e.g. `OpenAI`, `Anthropic`, `Gemini`, `Ollama`, `Dottxt`) that wraps the vendor client and implements `generate` / `generate_stream`.
- A **`ModelTypeAdapter`** subclass (e.g. `OpenAITypeAdapter`) that translates Outlines inputs (`str`, `Vision`) and output types (`JsonSchema`, `Regex`, `CFG`, Pydantic models, dataclasses, etc.) into the provider-specific request arguments.

The module currently supports the following providers:

| Provider | Model class | Type adapter | Structured output support |
|----------|-------------|--------------|---------------------------|
| OpenAI | `OpenAI` (+ legacy `OpenAILegacy`) | `OpenAITypeAdapter` | JSON Schema / JSON mode |
| Anthropic | `Anthropic` | `AnthropicTypeAdapter` | None (text only) |
| Gemini | `Gemini` | `GeminiTypeAdapter` | JSON Schema, enums, lists |
| Ollama | `Ollama` | `OllamaTypeAdapter` | JSON Schema |
| Dottxt | `Dottxt` | `DottxtTypeAdapter` | JSON Schema (required) |

---

## Architecture

All API models share a common architecture built on the abstract base classes defined in [models_base.md](models_base.md). The `Model` base class provides the user-facing `__call__` and `stream` methods (which delegate to a `Generator`), while each concrete model implements the lower-level `generate` and `generate_stream` methods. The `ModelTypeAdapter` base class defines the `format_input` and `format_output_type` contract that every adapter implements.

```mermaid
classDiagram
    class Model {
        <<abstract>>
        +type_adapter: ModelTypeAdapter
        +__call__(model_input, output_type, **kwargs)
        +stream(model_input, output_type, **kwargs)
        +generate(model_input, output_type, **kwargs)*
        +generate_stream(model_input, output_type, **kwargs)*
    }
    class ModelTypeAdapter {
        <<abstract>>
        +format_input(model_input)*
        +format_output_type(output_type)*
    }

    Model <|-- OpenAI
    Model <|-- Anthropic
    Model <|-- Gemini
    Model <|-- Ollama
    Model <|-- Dottxt

    ModelTypeAdapter <|-- OpenAITypeAdapter
    ModelTypeAdapter <|-- AnthropicTypeAdapter
    ModelTypeAdapter <|-- GeminiTypeAdapter
    ModelTypeAdapter <|-- OllamaTypeAdapter
    ModelTypeAdapter <|-- DottxtTypeAdapter

    OpenAI --> OpenAITypeAdapter : uses
    Anthropic --> AnthropicTypeAdapter : uses
    Gemini --> GeminiTypeAdapter : uses
    Ollama --> OllamaTypeAdapter : uses
    Dottxt --> DottxtTypeAdapter : uses

    OpenAI ..> OpenAILegacy : delegates (legacy mode)
```

### Component Relationships

Each provider file follows the same internal structure:

```mermaid
graph TD
    subgraph "outlines/models/openai.py"
        OA[OpenAI] --> OATA[OpenAITypeAdapter]
        OA -.legacy.-> OAL[OpenAILegacy]
        OAL --> OAC[OpenAIConfig]
        OAL --> GC[generate_chat]
        GC --> EH[error_handler]
    end
    subgraph "outlines/models/anthropic.py"
        AN[Anthropic] --> ANTA[AnthropicTypeAdapter]
    end
    subgraph "outlines/models/gemini.py"
        GE[Gemini] --> GETA[GeminiTypeAdapter]
    end
    subgraph "outlines/models/ollama.py"
        OL[Ollama] --> OLTA[OllamaTypeAdapter]
    end
    subgraph "outlines/models/dottxt.py"
        DO[Dottxt] --> DOTA[DottxtTypeAdapter]
    end
```

---

## Dependencies

The module depends on several other Outlines modules and external client libraries.

```mermaid
graph LR
    subgraph "models_api"
        MA[API Models]
    end
    subgraph "Outlines core"
        BASE[models/base.py<br/>Model, ModelTypeAdapter]
        TEMPL[templates.py<br/>Vision]
        TYPES[types/dsl.py<br/>JsonSchema, Regex, CFG]
        UTILS[types/utils.py<br/>type predicates]
        CACHE[caching.py<br/>cache]
        V0[v0_legacy/base.py<br/>vectorize]
    end
    subgraph "External clients"
        OAI[openai]
        ANTH[anthropic]
        GENAI[google.genai]
        OLL[ollama]
        DOT[dottxt]
        PYD[pydantic]
    end

    MA --> BASE
    MA --> TEMPL
    MA --> TYPES
    MA --> UTILS
    MA --> CACHE
    MA --> V0
    MA --> OAI
    MA --> ANTH
    MA --> GENAI
    MA --> OLL
    MA --> DOT
    MA --> PYD
```

Key dependencies:

- **[models_base.md](models_base.md)** — `Model` and `ModelTypeAdapter` abstract base classes.
- **[templates.md](templates.md)** — the `Vision` dataclass used for multimodal inputs.
- **[types_dsl.md](types_dsl.md)** — `JsonSchema`, `Regex`, and `CFG` output type markers.
- **`outlines.types.utils`** — predicate helpers (`is_dataclass`, `is_pydantic_model`, `is_typed_dict`, `is_genson_schema_builder`, `is_native_dict`, `is_enum`, `is_literal`, `is_typing_list`, `get_enum_from_literal`) used to detect and convert output types.
- **[caching.md](caching.md)** — the `cache` decorator used by the legacy OpenAI path.
- **[v0_legacy.md](v0_legacy.md)** — the `vectorize` decorator used by `generate_chat`.

---

## Data Flow

The following diagram shows how a user request flows through an API model, from input formatting to the provider client call and back.

```mermaid
sequenceDiagram
    participant User
    participant Model as Model (e.g. OpenAI)
    participant Adapter as ModelTypeAdapter
    participant Client as Vendor Client

    User->>Model: generate(model_input, output_type, **kwargs)
    Model->>Adapter: format_input(model_input)
    Adapter-->>Model: provider-specific input (e.g. messages)
    Model->>Adapter: format_output_type(output_type)
    Adapter-->>Model: provider-specific output config (e.g. response_format)
    Model->>Client: client.<method>(**input, **output_config, **kwargs)
    Client-->>Model: provider response
    Model-->>User: extracted text / list of texts
```

### Input Formatting

`format_input` accepts either a `str` or a `Vision` object and produces the provider-specific input structure:

- **OpenAI / Anthropic** — produce a `messages` list. For `Vision`, the image is embedded as a base64 data URL (OpenAI) or a base64 source block (Anthropic).
- **Gemini** — produces a `contents` list, using `types.Part.from_bytes` for images.
- **Ollama** — produces a `prompt` (and `images` list for vision).
- **Dottxt** — passes the string prompt through unchanged (text only).

### Output Type Formatting

`format_output_type` translates the user's requested output type into the provider's structured-output mechanism. The supported types vary by provider:

```mermaid
graph TD
    OT[output_type] --> N{None?}
    N -->|Yes| EMPTY[empty config / JSON mode]
    N -->|No| T{Type?}
    T -->|JsonSchema| JS[convert to JSON schema]
    T -->|Regex| RX[Regex - unsupported by most APIs]
    T -->|CFG| CFG[CFG - unsupported by most APIs]
    T -->|Pydantic/dataclass/TypedDict| PM[model_json_schema / TypeAdapter]
    T -->|genson SchemaBuilder| GS[to_json]
    T -->|Enum/Literal| EN[enum schema - Gemini only]
    T -->|list[...]| LS[list schema - Gemini only]
```

---

## Provider Details

### OpenAI (`outlines/models/openai.py`)

The `OpenAI` model wraps an `openai.OpenAI` or `openai.AzureOpenAI` client. It is the most feature-complete API integration.

- **`OpenAITypeAdapter`** formats inputs into `messages` and output types into a `response_format` argument. It supports JSON Schema (from Pydantic models, dataclasses, typed dicts, genson builders, or `JsonSchema` objects) and "JSON mode" (for native dicts). It explicitly rejects `Regex` and `CFG` output types.
- **`OpenAI`** implements `generate` and `generate_stream`, calling `client.chat.completions.create`. It handles `openai.BadRequestError` for unsupported schemas and raises `ValueError` on model refusals.
- **`from_openai(client, model_name)`** is the recommended factory function.

#### Legacy support

For backwards compatibility with Outlines v0, the class can be instantiated with an `OpenAIConfig` instance (or a `config` kwarg), which triggers a `DeprecationWarning` and delegates to `OpenAILegacy`. This path will be removed in v1.1.0.

- **`OpenAIConfig`** — a frozen dataclass holding OpenAI API parameters (`model`, `temperature`, `top_p`, `n`, `stop`, etc.).
- **`OpenAILegacy`** — wraps the client and config, tracks token usage (`prompt_tokens`, `completion_tokens`), and calls `generate_chat`.
- **`generate_chat`** — a `vectorize`-decorated async function that calls the Chat Completion API, wrapped by `error_handler` and `cache`.
- **`error_handler`** — maps OpenAI exceptions to `OSError` (connection issues) or re-raises them.

```mermaid
graph TD
    OA[OpenAI.__init__] --> C{model_name is OpenAIConfig<br/>or config kwarg?}
    C -->|Yes| LEG[OpenAILegacy]
    C -->|No| REG[Regular mode:<br/>client + model_name + type_adapter]
    LEG --> GC[generate_chat]
    GC --> EH[error_handler]
    GC --> CA[cache]
```

### Anthropic (`outlines/models/anthropic.py`)

The `Anthropic` model wraps an `anthropic.Anthropic` client. Anthropic does **not** support structured generation, so `AnthropicTypeAdapter.format_output_type` raises `NotImplementedError` for any non-`None` output type. The model supports text and vision inputs and streaming via `client.messages.create(stream=True)`.

### Gemini (`outlines/models/gemini.py`)

The `Gemini` model wraps a `google.genai.Client`. Its type adapter is the most expressive for output types:

- Supports JSON Schema (Pydantic models, dataclasses, typed dicts) via `response_mime_type: application/json`.
- Supports enums and literals via `response_mime_type: text/x.enum`.
- Supports homogeneous lists of structured types.
- Rejects `Regex`, `CFG`, genson builders, and raw `JsonSchema` objects.

### Ollama (`outlines/models/ollama.py`)

The `Ollama` model wraps an `ollama.Client`. It supports text and vision inputs and JSON Schema output types (passed via the `format` argument). `Regex` and `CFG` are rejected. Streaming is supported.

### Dottxt (`outlines/models/dottxt.py`)

The `Dottxt` model wraps a `dottxt.Dottxt` client. It is a **constrained-generation-only** provider: an output type is **required** (passing `None` raises `TypeError`). It supports JSON Schema output types and passes them to `client.json`. Streaming is not supported.

---

## Process Flow: Generation

The following diagram illustrates the full generation process shared by all API models, highlighting the provider-specific branches.

```mermaid
flowchart TD
    START([User calls model.generate]) --> FI[type_adapter.format_input]
    FI --> FOT[type_adapter.format_output_type]
    FOT --> CHECK{Provider?}
    CHECK -->|OpenAI| OAI[client.chat.completions.create]
    CHECK -->|Anthropic| AN[client.messages.create]
    CHECK -->|Gemini| GE[client.models.generate_content]
    CHECK -->|Ollama| OL[client.generate]
    CHECK -->|Dottxt| DO[client.json]
    OAI --> EXTRACT[Extract text from response]
    AN --> EXTRACT
    GE --> EXTRACT
    OL --> EXTRACT
    DO --> EXTRACT
    EXTRACT --> END([Return str or list of str])
```

---

## Usage

Each provider exposes a factory function that takes a pre-configured vendor client and an optional model name:

```python
from openai import OpenAI as OpenAIClient
from outlines import from_openai

client = OpenAIClient()
model = from_openai(client, "gpt-4o")
```

```python
from anthropic import Anthropic as AnthropicClient
from outlines import from_anthropic

client = AnthropicClient()
model = from_anthropic(client, "claude-3-5-sonnet-latest")
```

```python
from google.genai import Client
from outlines import from_gemini

client = Client()
model = from_gemini(client, "gemini-2.0-flash")
```

```python
from ollama import Client as OllamaClient
from outlines import from_ollama

client = OllamaClient()
model = from_ollama(client, "llama3.2")
```

```python
from dottxt import Dottxt as DottxtClient
from outlines import from_dottxt

client = DottxtClient()
model = from_dottxt(client, "meta-llama/Meta-Llama-3-8B-Instruct")
```

Once instantiated, models can be called directly or wrapped in a `Generator` (see [generator.md](generator.md)):

```python
from pydantic import BaseModel

class User(BaseModel):
    name: str
    age: int

# Direct call
result = model("Extract the user info: John is 30", User)

# Streaming
for chunk in model.stream("Tell me a story"):
    print(chunk, end="")
```

---

## Related Modules

- **[models_base.md](models_base.md)** — abstract `Model` and `ModelTypeAdapter` base classes.
- **[models_local.md](models_local.md)** — local model integrations (Transformers, LlamaCpp, MLXLM, VLLMOffline).
- **[models_server.md](models_server.md)** — self-hosted server integrations (VLLM, SGLang, TGI).
- **[models_tokenizer.md](models_tokenizer.md)** — tokenizer abstractions.
- **[templates.md](templates.md)** — `Vision` and `Template` input types.
- **[types_dsl.md](types_dsl.md)** — `JsonSchema`, `Regex`, `CFG` and other output type markers.
- **[generator.md](generator.md)** — the `Generator` class that wraps models.
- **[caching.md](caching.md)** — the `cache` decorator.
- **[v0_legacy.md](v0_legacy.md)** — legacy v0 compatibility layer.
