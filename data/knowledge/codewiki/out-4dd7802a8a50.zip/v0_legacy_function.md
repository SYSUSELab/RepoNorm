# v0_legacy_function Module

## Introduction

The `v0_legacy_function` module provides the **legacy `Function` abstraction** from Outlines v0, along with the `vectorize` utility that supports batched execution of functions and coroutines. The `Function` class encapsulates a prompt template, an output schema, and a language model into a single callable object, allowing users to define reusable structured-generation "functions" that render a prompt and produce a schema-constrained response.

> **⚠️ Deprecation Notice**
> The `Function` class is **deprecated starting from v1.0.0** and its support will be **removed in v1.1.0**. Users should migrate to the [`Application`](applications.md) class, which implements similar functionality with a cleaner API. See the [Migration Guide](#migration-guide) section below.

This module is part of the broader [`v0_legacy`](v0_legacy.md) compatibility layer, which preserves the v0 API surface while bridging it to the current v1 internals.

---

## Module Structure

The module consists of two core components:

| Component | File | Purpose |
|-----------|------|---------|
| `Function` | `outlines/v0_legacy/function.py` | Encapsulates a prompt template, output schema, and model into a callable structured-generation unit. |
| `vectorize` | `outlines/v0_legacy/base.py` | A NumPy-style vectorization decorator that broadcasts function calls over array inputs, executing coroutines concurrently. |

### Supporting Functions

The `function.py` file also defines three module-level helper functions used by `Function.from_github`:

- `function_warning()` — Emits the deprecation warning.
- `download_from_github(short_path)` — Downloads a Python file from a GitHub repository.
- `extract_function_from_file(content, function_name)` — Dynamically loads a `Function` instance from downloaded source.

---

## Architecture Overview

The `Function` class acts as a high-level facade that ties together the prompt template, the model, and the structured generator. It relies on the legacy `generate` API and the legacy transformers model loader.

```mermaid
graph TD
    subgraph "v0_legacy_function Module"
        F["Function<br/>(function.py)"]
        V["vectorize<br/>(base.py)"]
    end

    subgraph "Dependencies"
        T["Template<br/>(templates.py)"]
        G["generate.json<br/>(v0_legacy/generate)"]
        GA["GeneratorV0Adapter<br/>(v0_legacy/generate/api.py)"]
        TR["transformers<br/>(v0_legacy/models)"]
        APP["Application<br/>(applications.py)"]
    end

    F -->|"prompt_template"| T
    F -->|"init_generator()"| TR
    F -->|"init_generator()"| G
    G -->|"returns"| GA
    F -->|"generator"| GA
    F -.->|"deprecated in favor of"| APP
    V -.->|"used by legacy OpenAI model"| GA
```

### Component Relationships

```mermaid
classDiagram
    class Function {
        +Template prompt_template
        +Union~str, Callable, object~ schema
        +str model_name
        +Optional~GeneratorV0Adapter~ generator
        +__post_init__()
        +from_github(program_path, function_name) Function
        +init_generator()
        +__call__(*args, **kwargs)
    }

    class vectorize {
        +Callable func
        +Optional~str~ signature
        +bool is_coroutine_fn
        +__call__(*args, **kwargs)
        +call_thunk()
        +call_no_signature(*args, **kwargs)
        +call_with_signature(*args, **kwargs)
        +vectorize_call(broadcast_shape, args, kwargs)
        +vectorize_call_coroutine(broadcast_shape, args, kwargs)
    }

    class GeneratorV0Adapter {
        +Model model
        +Generator generator
        +dict sampling_params
        +__call__(prompts, ...)
        +stream(prompts, ...)
    }

    Function --> GeneratorV0Adapter : uses
    Function --> Template : renders
```

---

## The `Function` Class

### Purpose

`Function` is a `@dataclass` that represents an Outlines function. It bundles together:

1. **`prompt_template`** — A [`Template`](templates.md) instance (or callable) that renders the prompt.
2. **`schema`** — The output structure, expressed as a JSON schema string, a Pydantic model, or a callable.
3. **`model_name`** — The name of the transformers model to load.
4. **`generator`** — An optional cached [`GeneratorV0Adapter`](v0_legacy_generate.md) instance, lazily initialized.

### Lifecycle

```mermaid
flowchart TD
    A["Function(...)"] --> B["__post_init__()<br/>emit deprecation warning"]
    B --> C{"Called?"}
    C -->|"__call__"| D{"generator is None?"}
    D -->|"Yes"| E["init_generator()"]
    D -->|"No"| F["render prompt"]
    E --> E1["transformers(model_name)"]
    E1 --> E2["generate.json(model, schema)"]
    E2 --> F
    F --> G["generator(prompt)"]
    G --> H["return generated response"]
```

### Key Methods

#### `__post_init__()`
Invoked automatically by the dataclass machinery. It calls `function_warning()` to emit the `DeprecationWarning` whenever a `Function` is instantiated.

#### `from_github(program_path, function_name="fn")` *(classmethod)*
Loads a `Function` instance stored in a GitHub repository.

- **`program_path`** must be in the form `{USERNAME}/{REPO_NAME}/{PATH_TO_FILE}` (without the `.py` extension).
- Downloads the file via `download_from_github`, then extracts the named function via `extract_function_from_file`.
- Raises `ValueError` for malformed paths or missing files, `AttributeError` if the function is not found, and `TypeError` if the extracted object is not an `outlines.Function`.

#### `init_generator()`
Lazily loads the model and initializes the structured generator:

```python
model = transformers(self.model_name)
self.generator = generate.json(model, self.schema)
```

This uses the legacy transformers model loader and the legacy `generate.json` entry point, which returns a [`GeneratorV0Adapter`](v0_legacy_generate.md).

#### `__call__(*args, **kwargs)`
Renders the prompt template with the provided arguments and passes it to the generator.

> **Note:** Batching is **not** supported by this method.

The method temporarily suppresses `DeprecationWarning`s (from the underlying `json` and `transformers` calls) while it initializes the generator and produces output.

### Helper Functions

```mermaid
flowchart LR
    A["from_github(path, name)"] --> B["download_from_github(path)"]
    B -->|"HTTP 200"| C["extract_function_from_file(content, name)"]
    B -->|"HTTP 404"| D["raise ValueError"]
    C --> E["exec source in module"]
    E --> F["getattr(module, name)"]
    F --> G["validate isinstance Function"]
```

- **`download_from_github(short_path)`** — Constructs a raw GitHub URL (`https://raw.githubusercontent.com/{user}/{repo}/main/{path}.py`) and fetches the file. Raises `ValueError` on invalid paths or 404 responses.
- **`extract_function_from_file(content, function_name)`** — Uses `importlib.util.spec_from_loader` to create a synthetic module, executes the downloaded source in it, and retrieves the named attribute. Validates that the result is an `outlines.Function` instance.

---

## The `vectorize` Class

### Purpose

`vectorize` returns an object that behaves like a function but accepts **arrays** as input. It mirrors NumPy's `vectorize` behavior for Python functions:

- **Regular functions** are executed in a `for` loop over the broadcasted input elements.
- **Coroutines** are executed **concurrently** using `asyncio.gather`.

This utility is primarily used by the **legacy OpenAI model** to support batched inference.

### NumPy Dependency Handling

NumPy is an **optional dependency** (only required for the legacy OpenAI model). The `setup_numpy` method imports NumPy and the internal helper functions needed for signature parsing inside a `try`/`except` block, gracefully degrading if NumPy is unavailable. It supports both NumPy 1.x and 2.x by selecting the correct import path for the private `_function_base_impl` helpers.

### Execution Modes

```mermaid
flowchart TD
    A["__call__(*args, **kwargs)"] --> B{"NumPy installed?"}
    B -->|"No"| C["raise ImportError"]
    B -->|"Yes"| D{"args and kwargs empty?"}
    D -->|"Yes"| E["call_thunk()"]
    D -->|"No"| F{"signature provided?"}
    F -->|"Yes"| G["call_with_signature()"]
    F -->|"No"| H["call_no_signature()"]
    E --> I{"coroutine?"}
    I -->|"Yes"| J["run in new event loop"]
    I -->|"No"| K["call directly"]
```

#### `call_thunk()`
Handles argument-less ("thunk") calls. Coroutines are run to completion in a fresh event loop; regular functions are called directly.

#### `call_no_signature(*args, **kwargs)`
Used when no signature is specified. Assumes all inputs and outputs are scalars (core dimension of zero):

1. Converts args/kwargs to NumPy arrays.
2. Broadcasts them to a common shape.
3. Applies the function over each element (loop for functions, concurrent for coroutines).
4. Reshapes the flat results back to the broadcast shape.

#### `call_with_signature(*args, **kwargs)`
Used when a NumPy gufunc-style signature (e.g., `"(m),(s)->(s,m)"`) is provided. It:

1. Parses the signature into input/output core dimensions.
2. Validates the number of arguments against the signature.
3. Computes the broadcast shape and per-argument shapes.
4. Executes the function (loop or concurrent).
5. Validates the number of outputs and reshapes them accordingly.

#### `vectorize_call(broadcast_shape, args, kwargs)`
Iterates over `np.ndindex(*broadcast_shape)` and calls the wrapped function for each element. A possible future extension is parallelization.

#### `vectorize_call_coroutine(broadcast_shape, args, kwargs)`
Creates one coroutine task per broadcasted element and gathers them concurrently in a new event loop.

### Notebook Compatibility

At import time, `base.py` checks for `__IPYTHON__` in `builtins` and, if present, applies `nest_asyncio` to allow nested event loops in notebooks. This is done conditionally to avoid interfering with other libraries that use `asyncio`.

---

## Data Flow

The following diagram illustrates the end-to-end flow when a `Function` is called:

```mermaid
sequenceDiagram
    participant User
    participant Function
    participant Template
    participant GeneratorV0Adapter
    participant Model

    User->>Function: __call__(num=3)
    Function->>Function: check generator is None
    Function->>Model: transformers(model_name)
    Function->>Function: generate.json(model, schema)
    Function->>Template: prompt_template(num=3)
    Template-->>Function: rendered prompt string
    Function->>GeneratorV0Adapter: generator(prompt)
    GeneratorV0Adapter->>Model: generate with sampling params
    Model-->>GeneratorV0Adapter: raw output
    GeneratorV0Adapter-->>Function: formatted sequence
    Function-->>User: generated response
```

---

## Migration Guide

The `Function` class is deprecated in favor of the [`Application`](applications.md) class. The table below maps the old API to the new one:

| Legacy (`Function`) | Modern (`Application`) |
|---------------------|------------------------|
| `Function(prompt_template, schema, model_name)` | `Application(template, output_type)` |
| `fn(num=3)` (model loaded internally) | `app(model, {"num": 3})` (model passed explicitly) |
| `Function.from_github(...)` | No direct equivalent; load templates/models separately |
| Schema as JSON string / Pydantic model | `output_type` (e.g., `JsonType(OutputModel)`) |

### Example Migration

**Legacy:**
```python
from outlines import Function
from outlines.templates import Template

template = Template.from_string("What is 2 times {{ num }}?")
fn = Function(template, schema, "microsoft/Phi-3-mini-4k-instruct")
result = fn(num=3)
```

**Modern:**
```python
from pydantic import BaseModel
from transformers import AutoModelForCausalLM, AutoTokenizer
from outlines import models, Application
from outlines.types import JsonType
from outlines.templates import Template

class OutputModel(BaseModel):
    result: int

model = models.from_transformers(
    AutoModelForCausalLM.from_pretrained("microsoft/Phi-3-mini-4k-instruct"),
    AutoTokenizer.from_pretrained("microsoft/Phi-3-mini-4k-instruct")
)

template = Template.from_string("What is 2 times {{ num }}?")
application = Application(template, JsonType(OutputModel))

result = application(model, {"num": 3})
print(result)  # Expected output: { "result" : 6 }
```

---

## Related Modules

- [`v0_legacy`](v0_legacy.md) — The parent legacy compatibility layer.
- [`v0_legacy_generate`](v0_legacy_generate.md) — The `GeneratorV0Adapter` that bridges legacy `generate` functions to the current `Generator`.
- [`v0_legacy_models`](v0_legacy_models.md) — Legacy model implementations (e.g., `TransformersVision`, `ExLlamaV2Model`).
- [`v0_legacy_samplers`](v0_legacy_samplers.md) — Legacy sampling strategies used by the v0 generators.
- [`applications`](applications.md) — The recommended replacement for `Function`.
- [`templates`](templates.md) — The `Template` class used for prompt rendering.
- [`generator`](generator.md) — The current generator abstraction that `GeneratorV0Adapter` wraps.

---

## Summary

The `v0_legacy_function` module preserves the v0 `Function` abstraction and the `vectorize` utility for backward compatibility. While `Function` remains functional, it is **deprecated** and should be replaced by the [`Application`](applications.md) class. The `vectorize` utility continues to provide NumPy-style broadcasting with concurrent coroutine execution, primarily supporting the legacy OpenAI model's batched inference.
