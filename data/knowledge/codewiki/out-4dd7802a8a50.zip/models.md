# Models

## Overview

The `outlines.models` module provides a unified abstraction layer over a wide
range of Large Language Model (LLM) backends. It allows users to interact with
local models (e.g. `transformers`, `llama-cpp-python`, `mlx-lm`, `vllm`) and
remote/API-based models (e.g. OpenAI, Anthropic, Gemini, Ollama, Dottxt, TGI,
SGLang, vLLM server) through a single, consistent interface.

The central design goal is **separation of concerns**:

- **Models** know how to talk to a specific backend (build the request, call
  the client, return the response).
- **Type adapters** know how to translate the generic Outlines input/output
  types into the specific format each backend expects.
- **Generators** (see [generator.md](generator.md)) orchestrate constrained
  generation by building logits processors and passing them to the model.

This design means that adding support for a new backend only requires
implementing a `Model` subclass and a `ModelTypeAdapter` subclass, without
touching the rest of the library.

## Architecture

The module is organized around two abstract base classes and a family of
concrete implementations grouped by backend category.

```mermaid
graph TD
    subgraph "Base Abstractions"
        Model["Model (ABC)"]
        AsyncModel["AsyncModel (ABC)"]
        MTA["ModelTypeAdapter (ABC)"]
    end

    subgraph "Local / Steerable Models"
        Transformers["Transformers"]
        TransformersMM["TransformersMultiModal"]
        LlamaCpp["LlamaCpp"]
        MLXLM["MLXLM"]
        VLLMOffline["VLLMOffline"]
    end

    subgraph "API / Black-box Models"
        OpenAI["OpenAI"]
        Anthropic["Anthropic"]
        Gemini["Gemini"]
        Ollama["Ollama"]
        Dottxt["Dottxt"]
    end

    subgraph "Server-backed Models"
        VLLM["VLLM / AsyncVLLM"]
        SGLang["SGLang / AsyncSGLang"]
        TGI["TGI / AsyncTGI"]
    end

    subgraph "Support"
        Tokenizer["Tokenizer (Protocol)"]
        TransformerTokenizer["TransformerTokenizer"]
        LlamaCppTokenizer["LlamaCppTokenizer"]
    end

    Model --> Transformers
    Model --> TransformersMM
    Model --> LlamaCpp
    Model --> MLXLM
    Model --> VLLMOffline
    Model --> OpenAI
    Model --> Anthropic
    Model --> Gemini
    Model --> Ollama
    Model --> Dottxt
    Model --> VLLM
    Model --> SGLang
    Model --> TGI

    AsyncModel --> VLLM
    AsyncModel --> SGLang
    AsyncModel --> TGI

    Transformers --> TransformerTokenizer
    LlamaCpp --> LlamaCppTokenizer
    MLXLM --> TransformerTokenizer

    Model -.uses.-> MTA
    AsyncModel -.uses.-> MTA
```

### The Model / Type Adapter contract

Every model exposes the same public surface:

| Method | Purpose |
| --- | --- |
| `generate(model_input, output_type, **kwargs)` | Produce a single (or batched) response. |
| `generate_stream(model_input, output_type, **kwargs)` | Produce an iterator/async-iterator of chunks. |
| `__call__(...)` | Convenience wrapper that builds a `Generator` and calls it. |
| `stream(...)` | Convenience wrapper that builds a `Generator` and streams from it. |

The `output_type` argument is interpreted differently depending on the model
category:

- **Steerable (local) models** receive an `OutlinesLogitsProcessor` (built by
  the generator from the user's output type). See
  [processors.md](processors.md).
- **Black-box (API) models** receive the raw output type (a Pydantic model,
  dataclass, `JsonSchema`, `Regex`, `CFG`, etc.) and translate it into the
  backend's native structured-output mechanism.

The `ModelTypeAdapter` is the component that performs this translation. It
exposes two methods:

- `format_input(model_input)` — validates and converts the user input into the
  arguments expected by the backend (e.g. a `messages` list for chat APIs, a
  plain string for local models).
- `format_output_type(output_type)` — converts the output type into the
  backend's structured-output argument (e.g. `response_format` for OpenAI,
  `generation_config` for Gemini, a `LogitsProcessorList` for local models).

```mermaid
sequenceDiagram
    participant User
    participant Generator
    participant Model
    participant TypeAdapter
    participant Backend

    User->>Generator: generator(prompt, output_type)
    Generator->>Generator: build logits processor / keep output type
    Generator->>Model: generate(prompt, output_type)
    Model->>TypeAdapter: format_input(prompt)
    TypeAdapter-->>Model: backend-specific input
    Model->>TypeAdapter: format_output_type(output_type)
    TypeAdapter-->>Model: backend-specific output config
    Model->>Backend: client call
    Backend-->>Model: raw response
    Model-->>Generator: parsed response
    Generator-->>User: response
```

## Sub-modules

The module is split into the following sub-modules, each documented separately:

### Core abstractions
- **[models_base](models_base.md)** — The `Model`, `AsyncModel` and
  `ModelTypeAdapter` abstract base classes that define the contract every
  backend must implement.

### Local / steerable models
- **[models_local](models_local.md)** — Integrations with local inference
  libraries: `Transformers`, `TransformersMultiModal`, `LlamaCpp`, `MLXLM`
  and `VLLMOffline`. These models support full constrained generation via
  logits processors.

### API / black-box models
- **[models_api](models_api.md)** — Integrations with hosted APIs:
  `OpenAI`, `Anthropic`, `Gemini`, `Ollama` and `Dottxt`. These models rely on
  the backend's native structured-output support.

### Server-backed models
- **[models_server](models_server.md)** — Integrations with self-hosted
  inference servers exposing an OpenAI-compatible or HuggingFace-compatible
  API: `VLLM`/`AsyncVLLM`, `SGLang`/`AsyncSGLang` and `TGI`/`AsyncTGI`.

### Tokenizers
- **[models_tokenizer](models_tokenizer.md)** — The `Tokenizer` protocol and
  its concrete implementations (`TransformerTokenizer`,
  `LlamaCppTokenizer`) used by local models and logits processors.

## How the module fits into the system

The `models` module sits at the boundary between the user-facing API and the
underlying inference backends.

```mermaid
graph LR
    User["User code"] --> Generator["Generator<br/>(generator.md)"]
    Generator --> Models["Models<br/>(this module)"]
    Generator --> Processors["Logits processors<br/>(processors.md)"]
    Models --> Types["Output types<br/>(types_dsl.md)"]
    Models --> Templates["Vision template<br/>(templates.md)"]
    Models --> Tokenizers["Tokenizers<br/>(models_tokenizer.md)"]
    Models --> Backends["Inference backends<br/>(transformers, vllm, openai, ...)"]
    Processors --> Tokenizers
```

- **Generators** ([generator.md](generator.md)) decide whether a model is
  *steerable* (local) or *black-box* (API) and build the appropriate
  constrained-generation strategy.
- **Output types** ([types_dsl.md](types_dsl.md)) are converted to logits
  processors for local models, or to backend-native schemas for API models.
- **Templates** ([templates.md](templates.md)) provide the `Vision` input
  wrapper used by multimodal models.
- **Processors** ([processors.md](processors.md)) are the logits processors
  consumed by local models.

## Common usage patterns

### Local model with constrained generation

```python
from transformers import AutoModelForCausalLM, AutoTokenizer
from outlines import from_transformers, Generator
from pydantic import BaseModel

model = from_transformers(
    AutoModelForCausalLM.from_pretrained("model"),
    AutoTokenizer.from_pretrained("model"),
)

class Character(BaseModel):
    name: str
    age: int

generator = Generator(model, Character)
result = generator("Create a character")
```

### API model with structured output

```python
from openai import OpenAI as OpenAIClient
from outlines import from_openai, Generator

client = OpenAIClient()
model = from_openai(client, "gpt-4o")

generator = Generator(model, Character)
result = generator("Create a character")
```

### Streaming

```python
for chunk in model.stream("Tell me a story", output_type=None):
    print(chunk, end="")
```

## Adding a new backend

To add support for a new backend:

1. Create a `ModelTypeAdapter` subclass implementing `format_input` and
   `format_output_type`.
2. Create a `Model` (or `AsyncModel`) subclass implementing `generate` and
   `generate_stream`, and set the `type_adapter` attribute.
3. For local models, also set the `tensor_library_name` attribute and provide
   a `Tokenizer` implementation.
4. Provide a `from_<backend>` factory function that wraps the backend's client
   or model instance.

See [models_base](models_base.md) for the exact contract.
