# Tensor Adapters

## Introduction

The **tensor_adapters** module provides a unified abstraction layer for manipulating tensors across multiple numerical computing libraries. Outlines supports a wide range of model backends (PyTorch, JAX, MLX, NumPy, TensorFlow), and each of these libraries represents tensors with its own type and exposes its own set of operations. The tensor adapters module bridges this gap by defining a single, library-agnostic interface — [`TensorAdapter`](tensor_adapters_base.md) — that logits processors and other components use to operate on tensors without knowing which underlying library produced them.

The primary consumer of this module is the logits processing pipeline (see [processors](processors.md)). When a model generates tokens, Outlines applies masks to the logits to constrain generation. Those masks must be computed using the same tensor library the model uses. Rather than scattering library-specific code throughout the processors, the processors delegate all tensor manipulation to a `TensorAdapter` instance selected at runtime based on the model's library name.

## Purpose and Core Functionality

The module solves three related problems:

1. **Library abstraction** — A single interface (`TensorAdapter`) exposes the tensor operations needed by the generation pipeline (shape inspection, dimension manipulation, masking, concatenation, device movement, sorting).
2. **Runtime dispatch** — A registry maps a library name string (`"torch"`, `"jax"`, `"mlx"`, `"numpy"`, `"tensorflow"`) to the concrete adapter class, so processors can be constructed generically.
3. **Cross-library interoperability** — Because the underlying `outlines-core` library still emits PyTorch tensors in some code paths, adapters are explicitly designed to accept PyTorch tensors in `full_like` and `concatenate` even when the target library is different.

## Architecture Overview

The module follows a classic **abstract base class + concrete strategy** pattern. The abstract base defines the contract; each concrete adapter implements it for one library.

```mermaid
classDiagram
    class TensorAdapter {
        <<abstract>>
        +str library_name
        +shape(tensor) list[int]
        +unsqueeze(tensor) TensorType
        +squeeze(tensor) TensorType
        +to_list(tensor) list
        +to_scalar(tensor) Any
        +full_like(tensor, fill_value) TensorType
        +concatenate(tensors) TensorType
        +get_device(tensor) str
        +to_device(tensor, device) TensorType
        +boolean_ones_like(tensor) TensorType
        +apply_mask(tensor, mask, value) TensorType
        +argsort_descending(tensor) TensorType
    }

    class TorchTensorAdapter {
        +library_name = "torch"
    }
    class JAXTensorAdapter {
        +library_name = "jax"
    }
    class MLXTensorAdapter {
        +library_name = "mlx"
    }
    class NumpyTensorAdapter {
        +library_name = "numpy"
    }
    class TensorFlowTensorAdapter {
        +library_name = "tensorflow"
    }

    TensorAdapter <|-- TorchTensorAdapter
    TensorAdapter <|-- JAXTensorAdapter
    TensorAdapter <|-- MLXTensorAdapter
    TensorAdapter <|-- NumpyTensorAdapter
    TensorAdapter <|-- TensorFlowTensorAdapter
```

### How Adapters Are Selected

The adapter is instantiated by the logits processor base class based on a `tensor_library_name` string. The registry lookup happens in [`OutlinesLogitsProcessor.__init__`](processors_base.md):

```mermaid
sequenceDiagram
    participant Model
    participant Processor as OutlinesLogitsProcessor
    participant Registry as tensor_adapters registry
    participant Adapter as Concrete TensorAdapter

    Model->>Processor: __init__(tensor_library_name="torch")
    Processor->>Registry: get("torch")
    Registry-->>Processor: TorchTensorAdapter class
    Processor->>Adapter: TorchTensorAdapter()
    Note over Processor,Adapter: self.tensor_adapter = adapter
    Model->>Processor: __call__(input_ids, logits)
    Processor->>Adapter: shape / unsqueeze / squeeze
    Processor->>Processor: process_logits(...)
    Processor->>Adapter: apply_mask / concatenate / ...
    Processor-->>Model: processed logits
```

If the requested library name is not registered, the processor raises `NotImplementedError`.

## The TensorAdapter Interface

Every adapter must implement the following operations. These are the primitives required by the logits processing pipeline to build and apply token masks.

| Method | Purpose |
| --- | --- |
| `shape(tensor)` | Return the tensor's shape as a `list[int]`. |
| `unsqueeze(tensor)` | Add a dimension at axis 0 (used to promote 1D tensors to 2D). |
| `squeeze(tensor)` | Remove the dimension at axis 0 (used to demote 2D back to 1D). |
| `to_list(tensor)` | Convert the tensor to a Python list. |
| `to_scalar(tensor)` | Extract the single element of a tensor. |
| `full_like(tensor, fill_value)` | Create a tensor of the same shape filled with a scalar. **Accepts a PyTorch tensor.** |
| `concatenate(tensors)` | Concatenate a list of tensors along axis 0. **Accepts PyTorch tensors.** |
| `get_device(tensor)` | Return the name of the tensor's device. |
| `to_device(tensor, device)` | Move a tensor to a device. |
| `boolean_ones_like(tensor)` | Create a boolean tensor of ones with the same shape. |
| `apply_mask(tensor, mask, value)` | Fill elements where `mask` is `True` with `value`. |
| `argsort_descending(tensor)` | Return indices that sort the tensor descending along axis -1. |

> **Note on PyTorch interoperability:** The `full_like` and `concatenate` methods are explicitly documented to accept PyTorch tensors regardless of the adapter's target library. This is a temporary measure until `outlines-core` is updated to emit plain arrays instead of PyTorch tensors. Concrete adapters (e.g. MLX) handle this conversion internally.

## Sub-modules

The module is organized into a base contract and one concrete adapter per supported library.

### Base Contract

- **[tensor_adapters_base.md](tensor_adapters_base.md)** — The abstract [`TensorAdapter`](tensor_adapters_base.md) class defining the full interface and the `TensorType` type variable.

### Concrete Adapters

- **[tensor_adapters_torch.md](tensor_adapters_torch.md)** — `TorchTensorAdapter` for PyTorch, including device handling and `masked_fill`.
- **[tensor_adapters_jax.md](tensor_adapters_jax.md)** — `JAXTensorAdapter` for JAX, using functional `jax.numpy` operations and `.at[].set()` updates.
- **[tensor_adapters_mlx.md](tensor_adapters_mlx.md)** — `MLXTensorAdapter` for Apple MLX, with explicit PyTorch-to-MLX conversion in `concatenate`.
- **[tensor_adapters_numpy.md](tensor_adapters_numpy.md)** — `NumpyTensorAdapter` for NumPy.
- **[tensor_adapters_tensorflow.md](tensor_adapters_tensorflow.md)** — `TensorFlowTensorAdapter` for TensorFlow, with `tf.device`-based placement.

## Relationship to Other Modules

```mermaid
graph TD
    subgraph processors[processors module]
        OLP[OutlinesLogitsProcessor]
        GLP[GuideLogitsProcessor]
        RLP[RegexLogitsProcessor]
        JLP[JSONLogitsProcessor]
        CLP[CFGLogitsProcessor]
    end

    subgraph ta[tensor_adapters module]
        Base[TensorAdapter]
        Torch[TorchTensorAdapter]
        JAX[JAXTensorAdapter]
        MLX[MLXTensorAdapter]
        Numpy[NumpyTensorAdapter]
        TF[TensorFlowTensorAdapter]
    end

    subgraph models[models module]
        M[Model / AsyncModel]
    end

    OLP -->|instantiates by library_name| Base
    Base --> Torch
    Base --> JAX
    Base --> MLX
    Base --> Numpy
    Base --> TF
    GLP -->|inherits| OLP
    RLP -->|inherits| OLP
    JLP -->|inherits| OLP
    CLP -->|inherits| OLP
    M -->|calls __call__| OLP
```

- **processors** — The [processors](processors.md) module is the primary consumer. `OutlinesLogitsProcessor` owns a `tensor_adapter` attribute and uses it to normalize tensor shapes and apply masks. See [processors_base.md](processors_base.md) and [processors_structured.md](processors_structured.md).
- **models** — Each model backend (see [models](models.md)) determines which `tensor_library_name` is passed to the logits processor, effectively selecting the adapter. For example, the Transformers backend uses `"torch"`, while MLX-LM uses `"mlx"`.

## Design Considerations

- **Lazy imports** — Each concrete adapter imports its library inside `__init__` rather than at module import time. This keeps the module importable even when only one backend library is installed.
- **Device semantics vary** — `get_device`/`to_device` are no-ops for JAX, MLX, and NumPy (which have no explicit device model in this context), while Torch and TensorFlow implement real device movement.
- **Masking strategy differs per library** — Torch uses `masked_fill`, JAX uses immutable `.at[mask].set()`, MLX uses `where`, NumPy uses in-place assignment on a copy, and TensorFlow uses `tf.where`.
