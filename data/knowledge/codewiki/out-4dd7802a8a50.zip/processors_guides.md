# Processors Guides

## Introduction

The **processors_guides** module (`outlines/processors/guide.py`) defines the *guides* that drive structured text generation in Outlines. A guide is a finite-state machine (FSM) abstraction that, given the current generation state, tells the generation loop **which tokens are allowed next** and **how the state advances** after a token is emitted.

Guides are the "brains" behind structured generation. They are consumed by logits processors (see [processors_structured.md](processors_structured.md)) which translate a guide's instructions into a mask applied to the model's logits. This separation of concerns means the same guide can be reused across any tensor backend (torch, numpy, jax, mlx, tensorflow) via the [processors_tensor_adapters.md](processors_tensor_adapters.md) layer.

This module provides four concrete guide types:

| Guide | Purpose | Backing mechanism |
|-------|---------|-------------------|
| `Guide` | Abstract base class defining the guide interface | `outlines_core.fsm.guide.Guide` |
| `StopAtEOSGuide` | Generate freely until the EOS token is produced | Simple 2-state FSM |
| `RegexGuide` | Generate text matching a regular expression | `outlines_core` regex FSM + cache |
| `CFGGuide` | Generate text matching a context-free grammar | Lark LALR parser (`PartialLark`) |

---

## Architecture

The module sits between the high-level structured-generation API and the low-level logits processors. It builds on top of `outlines_core` (the compiled FSM engine) and the partial-parsing infrastructure in `outlines/fsm/parsing.py`.

```mermaid
graph TD
    subgraph "Public API"
        DSL["outlines.types.dsl<br/>(Regex, CFG, JsonSchema)"]
    end

    subgraph "processors_guides (this module)"
        Guide["Guide<br/>(abstract base)"]
        StopAtEOS["StopAtEOSGuide"]
        RegexGuide["RegexGuide"]
        CFGGuide["CFGGuide"]
    end

    subgraph "processors_structured"
        GLP["GuideLogitsProcessor"]
        RLP["RegexLogitsProcessor"]
        CLP["CFGLogitsProcessor"]
        JLP["JSONLogitsProcessor"]
    end

    subgraph "External / Core"
        CoreGuide["outlines_core.fsm.guide<br/>Guide / RegexGuide"]
        PartialLark["PartialLark<br/>(fsm/parsing.py)"]
        Tokenizer["Tokenizer<br/>(models/tokenizer.py)"]
        Cache["caching.cache<br/>(CloudpickleDisk)"]
    end

    DSL --> RegexGuide
    DSL --> CFGGuide

    Guide --> StopAtEOS
    Guide --> CFGGuide
    CoreGuide --> Guide
    CoreGuide --> RegexGuide

    RegexGuide --> Cache
    CFGGuide --> PartialLark
    CFGGuide --> Tokenizer
    StopAtEOS --> Tokenizer

    GLP --> Guide
    RLP --> RegexGuide
    CLP --> CFGGuide
    JLP --> RLP
```

### Class Hierarchy

```mermaid
classDiagram
    class CoreGuide {
        <<outlines_core>>
        +initial_state
        +get_next_instruction(state)
        +get_next_state(state, token_id)
        +is_final_state(state)
        +copy()
    }
    class CoreRegexGuide {
        <<outlines_core>>
        +from_regex(regex, tokenizer)
    }
    class Guide {
        +initial_state: Any
    }
    class StopAtEOSGuide {
        +final_state = 1
        +initial_state = 0
        +eos_token_id
        +vocabulary
    }
    class RegexGuide {
        +from_regex(regex, tokenizer)
    }
    class CFGGuide {
        +cfg_string
        +tokenizer
        +parser: PartialLark
        +initial_state: CFGState
    }

    CoreGuide <|-- Guide
    CoreGuide <|-- CoreRegexGuide
    Guide <|-- StopAtEOSGuide
    Guide <|-- CFGGuide
    CoreRegexGuide <|-- RegexGuide
```

---

## Core Components

### `Guide` (abstract base)

`Guide` extends `outlines_core.fsm.guide.Guide` and defines the common contract for all guides. It declares an `initial_state` attribute and inherits the FSM interface:

- `get_next_instruction(state) -> Instruction` — returns either a `Generate` (sample from allowed tokens) or a `Write` (force-append specific tokens) instruction.
- `get_next_state(state, token_id) -> state` — advances the FSM given the emitted token.
- `is_final_state(state) -> bool` — reports whether generation may stop.
- `copy() -> Guide` — produces an independent copy (important for batched/parallel generation).

The `Instruction` type is a union of `Write` and `Generate` from `outlines_core.fsm.guide`. A `Write` instruction lets the guide emit a token sequence directly (e.g. forcing EOS), while `Generate` restricts sampling to a set of allowed token ids.

### `StopAtEOSGuide`

The simplest guide: a two-state FSM (`initial_state = 0`, `final_state = 1`) that permits any token until the EOS token is generated.

- **Construction**: takes a `Tokenizer` and stores `eos_token_id` and the vocabulary.
- **`get_next_instruction`**: returns `Write([eos_token_id])` in the final state, otherwise `Generate(None)` (unconstrained).
- **`get_next_state`**: transitions to the final state when EOS is emitted or already final; otherwise stays in the initial state.
- **`copy`**: returns `self` because the guide is stateless and immutable.

This guide is used for plain (unconstrained) generation where only termination needs to be controlled.

### `RegexGuide`

`RegexGuide` is a thin wrapper around `outlines_core.fsm.guide.RegexGuide`. Its sole purpose is to add **caching** to the expensive `create_states_mapping` operation, which maps regex states to token ids.

- **`from_regex(regex_string, tokenizer, **kwargs)`**: classmethod that delegates to the core implementation, injecting `_create_states_mapping=cached_create_states_mapping`.
- **`cached_create_states_mapping`**: a module-level function decorated with `@cache()` (from `outlines.caching`) that memoizes the underlying `uncached_create_states_mapping`. The cache is backed by `CloudpickleDisk` (see [caching.md](caching.md)), so state mappings persist across processes.

Because building the token-to-state mapping is the dominant cost of regex-constrained generation, this caching is critical for performance. The benchmarks in `benchmarks/bench_regex_guide.py` (`RegexGuideBenchmark`, `MemoryRegexGuideBenchmark`) measure exactly this cost with the cache disabled.

### `CFGGuide`

`CFGGuide` enables generation constrained by a **context-free grammar** (Lark grammar). Unlike regex guides, it does not precompute a token-to-state mapping; instead it performs *lazy* validation of candidate tokens against a partial Lark parser.

Key design points:

- **State representation**: `CFGState = namedtuple("CFGState", ["parser_state", "prev_token"])`. The `prev_token` is needed to correctly decode token strings with leading whitespace (BPE normalization).
- **Parser**: a `PartialLark` instance (from `outlines/fsm/parsing.py`) configured with `parser="lalr"` and the bundled `grammars.GRAMMAR_PATH` import path. `PartialLark` supports incremental parsing via `parse_from_state`.
- **`get_next_instruction`**: iterates over the vocabulary, testing each token against a copy of the parser state. If exactly one token is valid it returns a `Write`; otherwise a `Generate` with the valid token set. When the parser state is `None` (complete), it returns `Write([eos_token_id])`.
- **`iter_valid_token_ids`**: yields token ids that keep the parser in a valid state, catching `ValueError`, `EOFError`, `UnexpectedToken`, `UnexpectedCharacters`, and `DedentError`. EOS is only yielded when `can_terminate_state` is true.
- **`_get_parser_state_token_applied`**: copies the parser state (to avoid side effects), decodes the new token string (handling the first-token vs. subsequent-token whitespace normalization), rejects empty tokens, and feeds the text into the parser.
- **`can_terminate_state` / `must_terminate_state`**: determine whether generation *may* or *must* stop, based on whether `feed_eof()` succeeds and whether the only accepted symbol is `$END`.

> **Note**: `CFGGuide` emits a `warnings.warn` on construction because community-contributed CFG structured generation is experimental.

---

## Data Flow

The following sequence diagram shows how a guide participates in a single generation step, from the model's logits to the masked logits returned to the sampler.

```mermaid
sequenceDiagram
    participant Model
    participant LP as GuideLogitsProcessor
    participant Guide
    participant Tokenizer

    Model->>LP: __call__(input_ids, logits)
    LP->>LP: standardize to 2D tensors
    LP->>LP: process_logits(input_ids, logits)
    loop for each sequence in batch
        LP->>LP: compute current state key from gen_ids
        alt state not cached
            LP->>Guide: get_next_state(prev_state, last_token)
            Guide-->>LP: new state
        end
        LP->>Guide: get_next_instruction(state)
        Guide-->>LP: Generate(allowed_tokens) / Write(tokens)
    end
    LP->>LP: build boolean mask, set disallowed tokens to -inf
    LP-->>Model: masked logits
```

For `CFGGuide`, the flow differs slightly: `CFGLogitsProcessor` uses **rejection sampling** — it sorts logits descending and picks the first legal token via `iter_valid_token_ids`, rather than masking the full vocabulary. See [processors_structured.md](processors_structured.md) for details.

---

## Guide State Lifecycle

```mermaid
stateDiagram-v2
    [*] --> InitialState
    InitialState --> InitialState: token != EOS (StopAtEOS)
    InitialState --> FinalState: token == EOS (StopAtEOS)

    state "Regex FSM" as RegexFSM {
        [*] --> RegexState
        RegexState --> RegexState: valid token
        RegexState --> RegexFinal: accepting state
    }

    state "CFG Parser" as CFGParser {
        [*] --> ParserState
        ParserState --> ParserState: valid token applied
        ParserState --> ParserComplete: parser_state = None
    }
```

---

## Relationship to Other Modules

| Module | Relationship |
|--------|--------------|
| [processors_structured.md](processors_structured.md) | `GuideLogitsProcessor` and subclasses consume guides to mask logits. `RegexLogitsProcessor` wraps `RegexGuide`; `CFGLogitsProcessor` wraps `CFGGuide`; `JSONLogitsProcessor` builds a `RegexGuide` from a JSON schema. |
| [processors_base.md](processors_base.md) | `OutlinesLogitsProcessor` provides the `__call__`/`process_logits` contract and tensor standardization that guide processors build on. |
| [processors_tensor_adapters.md](processors_tensor_adapters.md) | Guides return token ids as tensors; the tensor adapters convert these into masks for the active backend. |
| [fsm_parsing.md](fsm_parsing.md) | `CFGGuide` depends on `PartialLark` and `PartialParserState` for incremental LALR parsing. |
| [models_tokenizer.md](models_tokenizer.md) | All guides require a `Tokenizer` to map between token ids and strings. |
| [caching.md](caching.md) | `RegexGuide` uses the `@cache()` decorator backed by `CloudpickleDisk` to persist state mappings. |
| [types_dsl.md](types_dsl.md) | `Regex` and `CFG` DSL terms are the user-facing entry points that ultimately produce `RegexGuide`/`CFGGuide` instances. |

---

## Benchmarks

The module is exercised by three benchmark suites:

- **`benchmarks/bench_regex_guide.py`** — `RegexGuideBenchmark` measures time to build a guide from a regex; `MemoryRegexGuideBenchmark` measures peak memory. Both disable the cache to measure raw construction cost.
- **`benchmarks/bench_cfg_guide.py`** — `CFGGuideBenchmark` measures CFG guide setup time, run time (both rejection-sampling and instruction-based paths), and peak memory across a set of grammars.
- **`benchmarks/bench_processors.py`** — `LogitsProcessorStructuredBenchmark` measures end-to-end structured mask application using a `RegexLogitsProcessor` (which internally uses `RegexGuide`), while `LogitsProcessorPassthroughBenchmark` measures the tensor-conversion overhead using a trivial `HalvingLogitsProcessor`.

These benchmarks validate that the caching strategy in `RegexGuide` and the lazy validation in `CFGGuide` perform acceptably across backends (torch, numpy, mlx, jax, and CUDA/MPS variants).

---

## Summary

The **processors_guides** module provides the FSM abstractions that make structured generation possible in Outlines:

1. **`Guide`** defines the interface (`get_next_instruction`, `get_next_state`, `is_final_state`, `copy`).
2. **`StopAtEOSGuide`** handles unconstrained generation with EOS termination.
3. **`RegexGuide`** wraps the core regex FSM with disk-backed caching for performance.
4. **`CFGGuide`** implements lazy, parser-driven validation for context-free grammars.

Guides are deliberately decoupled from tensor manipulation and logits masking, which are handled by the [processors_structured.md](processors_structured.md) and [processors_tensor_adapters.md](processors_tensor_adapters.md) modules respectively. This separation allows the same guide logic to power structured generation across every supported model backend.
