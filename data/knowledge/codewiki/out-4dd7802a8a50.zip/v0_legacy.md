# v0 Legacy Module

## Introduction

The `v0_legacy` module (`outlines/v0_legacy/`) is a **backward-compatibility layer** that preserves the public API of Outlines v0 while the library transitions to its v1 architecture. It exists so that code written against the v0 API continues to work after upgrading to v1, giving users time to migrate.

> **Deprecation notice:** Everything in this module is deprecated starting from v1.0.0 and is scheduled for removal in v1.1.0. New code should use the v1 equivalents:
> - `outlines.Function` → [`outlines.Application`](applications.md)
> - `outlines.generate.*` → [`outlines.Generator`](generator.md)
> - `outlines.models.*` (v0 factories) → [`outlines.models`](models.md) / `outlines.from_*`
> - `outlines.samplers.*` → sampling parameters passed directly to the model

The module does **not** reimplement generation logic. Instead, it is a thin **adapter layer** that translates v0 concepts (samplers, legacy model wrappers, the `Function` abstraction) into the v1 building blocks — chiefly the [`Generator`](generator.md) and the [`models`](models.md) hierarchy.

---

## Architecture Overview

The v0 legacy layer sits *on top of* the v1 core. Each legacy entry point wraps a v1 component and adapts the calling convention.

```mermaid
graph TD
    subgraph "v0 Legacy API (this module)"
        Function["Function<br/>(v0_legacy_function.md)"]
        GenAdapter["GeneratorV0Adapter<br/>GeneratorVisionV0Adapter<br/>(v0_legacy_generate.md)"]
        Samplers["Samplers<br/>Greedy / Multinomial / BeamSearch<br/>(v0_legacy_samplers.md)"]
        LegacyModels["Legacy Models<br/>ExLlamaV2Model / TransformersVision<br/>(v0_legacy_models.md)"]
        Vectorize["vectorize<br/>(v0_legacy_function.md)"]
    end

    subgraph "v1 Core"
        Generator["Generator<br/>(generator.md)"]
        Models["Models<br/>(models.md)"]
        Templates["Template<br/>(templates.md)"]
        Types["Output types<br/>(types_dsl.md)"]
    end

    Function --> Templates
    Function --> GenAdapter
    Function --> LegacyModels
    GenAdapter --> Generator
    GenAdapter --> LegacyModels
    GenAdapter --> Samplers
    Generator --> Models
    LegacyModels --> Models
    Vectorize -.used by.-> LegacyModels
```

### Design principle: adapt, don't duplicate

The legacy layer follows a strict **adapter pattern**:

| v0 concept | v1 target | Adapter |
| --- | --- | --- |
| `generate.json(model, schema)` | `Generator(model, output_type)` | `GeneratorV0Adapter` |
| v0 sampler objects | `SamplingParameters` → model kwargs | `*_params_adapter` functions |
| `Function` (template + schema + model) | `Application` (template + output type) | `Function` wrapper |
| v0 model factories (`exl2`, `transformers_vision`) | `from_transformers`, `from_vllm_offline`, … | legacy model classes |

This means the legacy module is **shallow**: it holds almost no generation logic of its own and delegates to the v1 core, which is why it can be removed cleanly in v1.1.0.

---

## Sub-modules

The module is split into four sub-modules, each documented separately:

### Generation adapters
- **[v0_legacy_generate](v0_legacy_generate.md)** — `GeneratorV0Adapter` and
  `GeneratorVisionV0Adapter`. These bridge the legacy `generate` functions to
  the current [`Generator`](generator.md) object, translating v0 sampler
  parameters into model-specific inference parameters via per-backend adapter
  functions.

### Legacy models
- **[v0_legacy_models](v0_legacy_models.md)** — The v0 model wrappers that are
  no longer part of the v1 model hierarchy: `ExLlamaV2Model` (with
  `OutlinesExLlamaV2Tokenizer` and `ExllamaV2Params`) and `TransformersVision`.
  These wrap v1 models (e.g. [`Transformers`](models_local.md)) and add the
  legacy calling conventions.

### Samplers
- **[v0_legacy_samplers](v0_legacy_samplers.md)** — The v0 sampler objects
  (`GreedySampler`, `MultinomialSampler`, `BeamSearchSampler`) and the
  `SamplingParameters` dataclass. In v1 the generation loop is delegated to the
  models, so samplers now only carry the sampling parameters that are forwarded
  to the model.

### Function and vectorization
- **[v0_legacy_function](v0_legacy_function.md)** — The deprecated `Function`
  class (a v0 precursor to [`Application`](applications.md)) and the `vectorize`
  utility that lets a function accept NumPy arrays as input, executing
  coroutines concurrently.

---

## How the module fits into the system

The legacy module is a **leaf consumer** of the v1 core: it depends on the
generator, models, templates and types modules, but nothing in the v1 core
depends on it (except for the `GeneratorV0Adapter` reference noted in
[generator.md](generator.md)).

```mermaid
graph LR
    User["Legacy user code"] --> V0["v0_legacy<br/>(this module)"]
    V0 --> Generator["Generator<br/>(generator.md)"]
    V0 --> Models["Models<br/>(models.md)"]
    V0 --> Templates["Template<br/>(templates.md)"]
    V0 --> Types["Output types<br/>(types_dsl.md)"]
    Generator --> Processors["Logits processors<br/>(processors.md)"]
    Models --> Processors
```

### Dependency diagram

```mermaid
graph TD
    subgraph "v0_legacy"
        Function["function.py"]
        Base["base.py (vectorize)"]
        GenAPI["generate/api.py"]
        Exl2["models/exllamav2.py"]
        Vision["models/transformers_vision.py"]
        Samplers["samplers.py"]
    end

    Function --> GenAPI
    Function --> Vision
    Function --> Templates["outlines.templates"]
    GenAPI --> Generator["outlines.generator"]
    GenAPI --> Exl2
    GenAPI --> Vision
    GenAPI --> Models["outlines.models"]
    GenAPI --> Samplers
    Vision --> ModelsLocal["outlines.models.transformers"]
    Exl2 --> Base
```

---

## Common usage patterns

### Legacy `Function` (deprecated)

```python
from outlines import Function
from outlines.templates import Template

fn = Function(
    prompt_template=Template.from_string("What is 2 times {{ num }}?"),
    schema=OutputModel,
    model_name="microsoft/Phi-3-mini-4k-instruct",
)
result = fn(num=3)
```

The v1 equivalent is [`Application`](applications.md):

```python
from outlines import Application
from outlines.templates import Template

application = Application(Template.from_string("What is 2 times {{ num }}?"), OutputModel)
result = application(model, num=3)
```

### Legacy `generate` API

```python
from outlines import generate, models

model = models.transformers("microsoft/Phi-3-mini-4k-instruct")
generator = generate.json(model, OutputModel)  # returns a GeneratorV0Adapter
result = generator("What is 2 times 3?")
```

The v1 equivalent is [`Generator`](generator.md):

```python
from outlines import Generator

generator = Generator(model, OutputModel)
result = generator("What is 2 times 3?")
```

### Legacy samplers

```python
from outlines import samplers

generator = generate.json(model, OutputModel, sampler=samplers.multinomial(2, temperature=0.7))
```

In v1, sampling parameters are passed directly to the model/generator.

---

## Migration summary

| Legacy (v0) | Recommended (v1) | Documentation |
| --- | --- | --- |
| `Function` | `Application` | [applications.md](applications.md) |
| `generate.json/regex/cfg/...` | `Generator(model, output_type)` | [generator.md](generator.md) |
| `samplers.greedy/multinomial/beam_search` | model inference kwargs | [models.md](models.md) |
| `models.exl2` | `from_vllm_offline` / other local models | [models_local.md](models_local.md) |
| `models.transformers_vision` | `from_transformers` with a processor | [models_local.md](models_local.md) |
| `vectorize` | not needed in v1 | — |

---

## Summary

The `v0_legacy` module is a **deprecation shim** that keeps the Outlines v0 API
functional on top of the v1 core. It is composed of four sub-modules:

- **[v0_legacy_generate](v0_legacy_generate.md)** — adapters from the legacy
  `generate` functions to the v1 [`Generator`](generator.md).
- **[v0_legacy_models](v0_legacy_models.md)** — legacy model wrappers
  (`ExLlamaV2Model`, `TransformersVision`).
- **[v0_legacy_samplers](v0_legacy_samplers.md)** — v0 sampler objects and
  `SamplingParameters`.
- **[v0_legacy_function](v0_legacy_function.md)** — the deprecated `Function`
  class and the `vectorize` utility.

Because it only adapts and never reimplements, the module can be removed in
v1.1.0 without affecting the v1 core.
