# Caching

## Introduction

The `outlines.caching` module provides a persistent, disk-backed memoization
layer for Outlines. Its primary purpose is to avoid redundant and expensive
computations — most notably the construction of finite-state-machine state
mappings for structured generation guides, and repeated calls to remote model
APIs.

The module is built on top of the [`diskcache`](https://grantjenks.com/docs/diskcache/)
library and extends it with a custom disk backend (`CloudpickleDisk`) that uses
`cloudpickle` for serialization. This allows arbitrary Python objects — including
lambdas, closures, and complex state machines — to be stored and retrieved
across process boundaries.

The module exposes four public entry points:

| Function | Purpose |
| --- | --- |
| `cache` | Decorator that memoizes a function's return values on disk. |
| `get_cache` | Returns the singleton `diskcache.Cache` instance. |
| `disable_cache` | Globally disables caching for the current session. |
| `clear_cache` | Erases the entire on-disk cache. |

A context manager, `cache_disabled`, is also provided for temporarily disabling
caching within a `with` block.

## Architecture

The caching module sits at the bottom of the Outlines dependency stack. It has
no dependencies on other Outlines modules (aside from reading its own version
string), and is consumed by higher-level components such as the structured
generation guides.

```mermaid
graph TD
    subgraph "outlines.caching"
        CC[cache decorator]
        GC[get_cache]
        DC[disable_cache]
        CL[clear_cache]
        CD[cache_disabled context manager]
        CPD[CloudpickleDisk]
    end

    subgraph "External"
        DISKCACHE[diskcache.Cache]
        CLOUDPICKLE[cloudpickle]
    end

    subgraph "Consumers"
        RG[RegexGuide / cached_create_states_mapping]
        MODELS[Models: Transformers, OpenAI, ...]
    end

    CC --> GC
    GC --> DISKCACHE
    GC --> CPD
    CPD --> CLOUDPICKLE
    DC --> CC
    CL --> GC
    CD --> CC
    RG --> CC
    MODELS --> CC
```

### Component Relationships

- **`CloudpickleDisk`** is a subclass of `diskcache.Disk`. It overrides the
  four serialization hooks (`put`, `get`, `store`, `fetch`) so that every value
  written to disk is serialized with `cloudpickle` rather than the default
  `pickle`. This is what enables caching of non-standard objects.
- **`get_cache`** is decorated with `functools.lru_cache(1)`, making it a
  process-wide singleton accessor. It resolves the cache directory, constructs
  the `diskcache.Cache` with `CloudpickleDisk`, and performs version-based
  invalidation.
- **`cache`** is the user-facing decorator. It captures the singleton cache at
  decoration time and produces a wrapper that computes a cache key, checks the
  cache, and stores results on a miss.
- **`disable_cache` / `cache_disabled`** toggle the module-level
  `_caching_enabled` flag, which every wrapper checks before touching the cache.
- **`clear_cache`** simply delegates to `Cache.clear()`.

## Cache Directory Resolution

`get_cache` determines the on-disk location using the following precedence
order:

```mermaid
flowchart TD
    A[Start] --> B{OUTLINES_CACHE_DIR set?}
    B -- yes --> C[Use OUTLINES_CACHE_DIR]
    B -- no --> D{XDG_CACHE_HOME set?}
    D -- yes --> E[XDG_CACHE_HOME/.cache/outlines]
    D -- no --> F{home_dir != '/'?}
    F -- yes --> G[~/.cache/outlines]
    F -- no --> H[tempdir/.cache/outlines]
    C --> I[Create diskcache.Cache]
    E --> I
    G --> I
    H --> I
    I --> J{Stored version == current?}
    J -- no --> K[Clear cache]
    J -- yes --> L[Return cache]
    K --> M[Store current version]
    M --> L
```

The fallback to the system temp directory handles the case where the process
runs inside a container with no real home directory (i.e. `home_dir == "/"`).

### Version-Based Invalidation

After constructing the cache, `get_cache` compares the stored `__version__`
key against the currently installed Outlines version. If they differ, the cache
is cleared and the new version is written. This guarantees that stale entries
produced by an older version of Outlines are never reused after an upgrade.

## The `cache` Decorator

The `cache` decorator is modeled on `diskcache`'s `memoize`. It supports both
synchronous and asynchronous functions.

```python
from outlines.caching import cache

@cache(expire=3600, typed=True, ignore=("verbose",))
def expensive_computation(x, verbose=False):
    ...
```

### Parameters

| Parameter | Type | Description |
| --- | --- | --- |
| `expire` | `Optional[float]` | Seconds until cached arguments expire. `None` means never expire. |
| `typed` | `bool` | If `True`, arguments of different types produce different cache keys. |
| `ignore` | `tuple` | Positional or keyword argument names to exclude from the cache key. |

### Cache Key Generation

The cache key is derived from the fully-qualified function name plus the
function arguments, using `diskcache.core.args_to_key`. The `typed` and
`ignore`
parameters are forwarded to this function. The key function is attached to the
wrapper as `__cache_key__`, and the underlying cache as `__memory__`.

### Execution Flow

```mermaid
flowchart TD
    A[Call decorated function] --> B{_caching_enabled?}
    B -- no --> C[Call function directly]
    B -- yes --> D[Compute cache key]
    D --> E{Key in cache?}
    E -- yes --> F[Return cached result]
    E -- no --> G[Call function]
    G --> H[Store result in cache]
    H --> I[Return result]
    C --> I
    F --> I
```

For coroutine functions, the wrapper is an `async def` and awaits the
underlying function on a cache miss. The cache lookup and store use
`retry=True` to tolerate transient disk contention.

## Enabling and Disabling Caching

Caching is enabled by default (`_caching_enabled = True`). Because generative
models produce different outputs on each call when sampling, caching may be
undesirable for some workflows. Two mechanisms allow disabling it:

### Permanent (session-wide) Disable

```python
import outlines.caching as cache
cache.disable_cache()
```

This sets `_caching_enabled = False` for the remainder of the process. It does
**not** delete existing cache entries, nor does it overwrite them with values
computed while disabled.

### Temporary Disable

```python
from outlines.caching import cache_disabled

with cache_disabled():
    # caching is disabled inside this block
    ...
```

`cache_disabled` is a context manager that saves the current state of
`_caching_enabled`, sets it to `False`, and restores the original value on exit
— even if an exception is raised.

```mermaid
stateDiagram-v2
    [*] --> Enabled: import outlines
    Enabled --> Disabled: disable_cache()
    Disabled --> Enabled: (not reversible in-session)
    Enabled --> TempDisabled: enter cache_disabled()
    TempDisabled --> Enabled: exit cache_disabled()
```

## Clearing the Cache

```python
from outlines.caching import clear_cache
clear_cache()
```

`clear_cache` retrieves the singleton cache and calls `Cache.clear()`, removing
all stored entries. This is the recommended way to reclaim disk space or force
recomputation.

## Integration with Structured Generation

The most important consumer of the caching module is the structured generation
guide system. Building the state mapping for a `RegexGuide` is computationally
expensive, so the result is memoized via `cached_create_states_mapping`.

```mermaid
sequenceDiagram
    participant User
    participant RegexLogitsProcessor
    participant RegexGuide
    participant cache as cached_create_states_mapping
    participant Disk as CloudpickleDisk

    User->>RegexLogitsProcessor: __init__(regex_string, tokenizer)
    RegexLogitsProcessor->>RegexGuide: from_regex(regex_string, tokenizer)
    RegexGuide->>cache: _create_states_mapping(...)
    cache->>Disk: get(cache_key)
    alt cache hit
        Disk-->>cache: states mapping
    else cache miss
        cache->>cache: compute states mapping
        cache->>Disk: set(cache_key, mapping)
    end
    cache-->>RegexGuide: states mapping
    RegexGuide-->>RegexLogitsProcessor: guide instance
```

Because the cache key incorporates the regex string and the tokenizer (which
implements `__hash__` and `__eq__`), identical regex/tokenizer combinations
reuse the same mapping across runs and processes. See
[processors](processors.md) for details on `RegexGuide`, `CFGGuide`, and the
logits processors that consume them.

### Why `cloudpickle`?

The state mappings and other cached artifacts may contain closures, lambdas, or
dynamically generated classes that the standard `pickle` module cannot
serialize. `CloudpickleDisk` transparently swaps in `cloudpickle` for all
serialization, making these objects cacheable without changes to the callers.

## API Reference

### `CloudpickleDisk`

```python
class CloudpickleDisk(Disk):
    def __init__(self, directory, compress_level=1, **kwargs): ...
    def put(self, key): ...
    def get(self, key, raw): ...
    def store(self, value, read, key=UNKNOWN): ...
    def fetch(self, mode, filename, value, read): ...
```

A `diskcache.Disk` subclass that serializes keys and values with
`cloudpickle`. The `compress_level` argument controls the compression applied
by the underlying disk backend.

### `get_cache()`

Returns the singleton `diskcache.Cache` instance, creating it on first call.
The result is memoized with `functools.lru_cache(1)`.

### `cache(expire=None, typed=False, ignore=())`

Returns a decorator that memoizes the decorated function. See
[The `cache` Decorator](#the-cache-decorator).

### `disable_cache()`

Globally disables caching for the current session.

### `clear_cache()`

Erases the entire on-disk cache.

### `cache_disabled()`

A context manager that temporarily disables caching.

## Related Modules

- [processors](processors.md) — structured generation guides and logits
  processors that rely on the cache.
- [models](models.md) — model wrappers whose expensive calls benefit from
  memoization.
- [fsm_parsing](fsm_parsing.md) — the partial parser machinery used by CFG
  guides.
