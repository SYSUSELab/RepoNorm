# Benchmarks Processors

## Introduction

The `benchmarks_processors` module provides performance benchmarks for the
logits processors used by Outlines to constrain text generation. It measures two
distinct aspects of processor performance:

1. **Framework conversion overhead** — the cost of passing logits through the
   `OutlinesLogitsProcessor` machinery (tensor standardization, adapter
   dispatch, and casting back), which should remain on the order of
   microseconds.
2. **Structured generation masking** — the cost of applying a real
   regex-based token mask for a single decoder pass, which is the dominant
   per-step cost during constrained generation.

These benchmarks are built on top of the
[`processors`](processors.md) module (the `OutlinesLogitsProcessor` base class
and `RegexLogitsProcessor`) and the [`models`](models.md) module (used to obtain
a real tokenizer). They help maintainers detect regressions in the hot path of
constrained decoding across the supported array frameworks (PyTorch, NumPy, MLX,
and JAX).

---

## Module Structure

The module is a single file, `benchmarks/bench_processors.py`, containing three
core components:

| Component | Role |
| --- | --- |
| `HalvingLogitsProcessor` | A trivial `OutlinesLogitsProcessor` subclass that halves logits; used as a no-op workload to isolate framework overhead. |
| `LogitsProcessorPassthroughBenchmark` | Benchmarks the round-trip cost of invoking a logits processor across array frameworks. |
| `LogitsProcessorStructuredBenchmark` | Benchmarks the cost of applying a real regex mask via `RegexLogitsProcessor`. |

Supporting module-level helpers:

- `is_mlx_lm_allowed()` / `is_jax_allowed()` — feature-detection guards that
  conditionally enable MLX and JAX benchmark parameters.
- `get_mock_processor_inputs(array_library, num_tokens)` — generates synthetic
  `logits` (`(4, num_tokens)`) and `input_ids` (`(4, 2048)`) tensors in the
  requested array framework.

---

## Architecture

The benchmarks sit at the top of the Outlines stack, exercising the processor
layer through the public `OutlinesLogitsProcessor` interface.

```mermaid
graph TD
    subgraph Benchmarks["benchmarks_processors"]
        HLP["HalvingLogitsProcessor"]
        LPB["LogitsProcessorPassthroughBenchmark"]
        LSB["LogitsProcessorStructuredBenchmark"]
        GM["get_mock_processor_inputs"]
    end

    subgraph Processors["processors module"]
        OLP["OutlinesLogitsProcessor"]
        GLP["GuideLogitsProcessor"]
        RLP["RegexLogitsProcessor"]
        RG["RegexGuide"]
    end

    subgraph TensorAdapters["tensor_adapters module"]
        TA["TensorAdapter (torch/numpy/mlx/jax)"]
    end

    subgraph Models["models module"]
        TR["Transformers"]
        TK["Tokenizer"]
    end

    LPB --> HLP
    LSB --> RLP
    LPB --> GM
    LSB --> GM

    HLP -->|subclass| OLP
    RLP -->|subclass| GLP
    GLP -->|subclass| OLP
    RLP -->|builds| RG

    OLP -->|dispatches| TA
    GLP -->|uses| TK
    LSB -->|tokenizer| TR
    TR -->|provides| TK
```

### Component Relationships

- `HalvingLogitsProcessor` extends `OutlinesLogitsProcessor` and implements only
  `process_logits`, returning `logits / 2`. Because it performs no masking, any
  measured time is attributable to the base-class `__call__` standardization
  logic and the tensor adapter dispatch.
- `LogitsProcessorStructuredBenchmark` instantiates a `RegexLogitsProcessor`,
  which internally builds a `RegexGuide` from the pattern and delegates to
  `GuideLogitsProcessor.process_logits` to compute and apply the token mask.
- Both benchmarks obtain a real tokenizer via
  `models.transformers("facebook/opt-125m")` so that the vocabulary size and
  token-to-id mapping match a production model.

---

## Component Details

### `HalvingLogitsProcessor`

A minimal `OutlinesLogitsProcessor` subclass used as a controlled workload.

```python
class HalvingLogitsProcessor(OutlinesLogitsProcessor):
    """Simply halve the passed logits"""

    def process_logits(self, input_ids, logits):
        return logits / 2
```

Because it inherits the base class `__call__`, invoking it exercises the full
standardization path (1D/2D reshaping, adapter dispatch, casting back to the
original framework). This makes it ideal for isolating framework-conversion
overhead from masking cost. See
[`OutlinesLogitsProcessor`](processors.md) for the base-class contract.

### `LogitsProcessorPassthroughBenchmark`

Measures the time to convert between array frameworks when a logits processor is
invoked. The expected cost is on the order of microseconds.

**Parameters** are assembled dynamically based on the runtime environment:

| Parameter | Condition |
| --- | --- |
| `torch` | always |
| `numpy` | always |
| `mlx` | only if `is_mlx_lm_allowed()` (MLX installed and Metal available) |
| `torch_cuda` | only if `torch.cuda.is_available()` |
| `torch_mps` | only if `torch.mps.is_available()` |
| `jax` | only if `is_jax_allowed()` |

**Methods:**

- `setup(array_library)` — creates a `HalvingLogitsProcessor` and generates mock
  inputs via `get_mock_processor_inputs`.
- `time_passthrough(*params)` — invokes the processor on the mock inputs.

### `LogitsProcessorStructuredBenchmark`

Measures the cost of applying a structured-generation mask for a single decoder
pass. This is the realistic hot-path benchmark.

**Parameters** are a cross-product of `array_libraries` and `patterns`:

- `array_libraries`: `["torch", "numpy"]`, plus `mlx`, `torch_cuda`, and
  `torch_mps` when available.
- `patterns`: `[r"[^Z]*", "Z*"]` — chosen to accept very many or very few tokens
  respectively, exercising both extremes of mask density.

**Methods:**

- `setup(array_library, pattern)` — loads the `facebook/opt-125m` tokenizer,
  constructs a `RegexLogitsProcessor(pattern, tokenizer)`, and generates mock
  inputs sized to the tokenizer vocabulary.
- `time_structured_generation(array_library, pattern)` — invokes the processor
  on the mock inputs.

---

## Data Flow

The following diagram shows the flow of a single benchmark iteration for the
structured benchmark, which is representative of the full processor pipeline.

```mermaid
sequenceDiagram
    participant Bench as LogitsProcessorStructuredBenchmark
    participant GM as get_mock_processor_inputs
    participant RLP as RegexLogitsProcessor
    participant GLP as GuideLogitsProcessor
    participant RG as RegexGuide
    participant TA as TensorAdapter

    Bench->>GM: request logits + input_ids (array_library, vocab_size)
    GM-->>Bench: logits (4, V), input_ids (4, 2048)
    Bench->>RLP: __call__(input_ids, logits)
    RLP->>GLP: process_logits(input_ids, logits)
    GLP->>RG: get_next_state / get_next_instruction
    RG-->>GLP: allowed token ids per sequence
    GLP->>TA: concatenate, to_device, boolean_ones_like, apply_mask
    TA-->>GLP: masked logits
    GLP-->>RLP: masked logits
    RLP-->>Bench: processed logits
```

### Mock Input Generation

`get_mock_processor_inputs` produces framework-native tensors with a fixed shape
so results are comparable across frameworks:

| Framework | `logits` | `input_ids` |
| --- | --- | --- |
| `torch` / `torch_cuda` / `torch_mps` | `torch.rand((4, num_tokens))` | `torch.randint((4, 2048))` |
| `numpy` | `np.random.rand(4, num_tokens)` | `np.random.randint((4, 2048))` |
| `mlx` | `mx.random.uniform((4, num_tokens))` | `mx.random.randint((4, 2048))` |
| `jax` | `jnp.random.uniform((4, num_tokens))` | `jnp.random.randint((4, 2048))` |

The `torch_*` variants parse the device suffix from the library name (e.g.
`torch_cuda` → device `"cuda"`).

---

## Process Flow

```mermaid
flowchart TD
    Start([Benchmark run]) --> Detect{Detect available frameworks}
    Detect -->|MLX + Metal| AddMLX[Add mlx param]
    Detect -->|CUDA| AddCUDA[Add torch_cuda param]
    Detect -->|MPS| AddMPS[Add torch_mps param]
    Detect -->|JAX| AddJAX[Add jax param]
    AddMLX --> Setup[setup: build processor + mock inputs]
    AddCUDA --> Setup
    AddMPS --> Setup
    AddJAX --> Setup
    Setup --> Run[time_*: invoke processor]
    Run --> Measure[Record timing]
    Measure --> End([Report results])
```

---

## Dependencies

### Internal Dependencies

| Dependency | Used for |
| --- | --- |
| [`outlines.processors.OutlinesLogitsProcessor`](processors.md) | Base class for `HalvingLogitsProcessor`; defines the `__call__`/`process_logits` contract. |
| [`outlines.processors.RegexLogitsProcessor`](processors.md) | Structured-generation processor under test. |
| [`outlines.processors.guide.RegexGuide`](processors.md) | Builds the FSM from a regex pattern inside `RegexLogitsProcessor`. |
| [`outlines.processors.tensor_adapters.TensorAdapter`](tensor_adapters.md) | Framework-agnostic tensor operations used by the processors. |
| [`outlines.models.transformers.Transformers`](models.md) | Provides the `facebook/opt-125m` tokenizer. |
| [`outlines.models.tokenizer.Tokenizer`](models.md) | Token-to-id mapping and vocabulary size. |

### External Dependencies

- `numpy` — NumPy array framework.
- `torch` — PyTorch array framework (CPU, CUDA, MPS).
- `mlx.core` — optional; MLX framework (Apple Silicon).
- `jax` / `jax.numpy` — optional; JAX framework.

All optional frameworks are guarded by `try/except ImportError` and the
`is_mlx_lm_allowed()` / `is_jax_allowed()` helpers, so the module imports cleanly
in minimal environments.

---

## Related Documentation

- [processors.md](processors.md) — the logits processor base class, guide
  processors, and structured processors exercised by these benchmarks.
- [tensor_adapters.md](tensor_adapters.md) — the framework-agnostic tensor
  abstraction layer used by the processors.
- [models.md](models.md) — model wrappers and tokenizers used to obtain a real
  vocabulary for the structured benchmark.
- [benchmarks_guide.md](benchmarks_guide.md) — benchmarks for the guide layer
  (`RegexGuide`, `CFGGuide`).
- [benchmarks_json_schema.md](benchmarks_json_schema.md) — benchmarks for JSON
  schema generation.
