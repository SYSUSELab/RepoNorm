# Benchmarks Guide

## Introduction

The `benchmarks_guide` module is a collection of performance benchmarks for the
**guide-based structured generation** machinery in Outlines. A *guide* is the
component that constrains a language model's token-by-token output so that the
generated text conforms to a formal language — a regular expression, a
context-free grammar (CFG), or a JSON schema.

This module measures two things that dominate the cost of structured
generation:

1. **Guide construction cost** — the time and peak memory required to compile a
   formal language (regex / CFG / JSON schema) into a guide that is aware of a
   tokenizer's vocabulary.
2. **Per-step guide cost** — the time required to compute the set of valid next
   tokens and advance the guide's state during decoding.

The benchmarks are written for the [ASV (airspeed velocity)](https://asv.readthedocs.io/)
framework and are configured by [`benchmarks/asv.conf.json`](#asv-configuration).

> **Related modules**
> - [processors.md](processors.md) — the `Guide`, `RegexGuide`, and `CFGGuide`
>   classes that these benchmarks exercise.
> - [caching.md](caching.md) — the `cache_disabled` context manager used to
>   isolate benchmark measurements.
> - [models.md](models.md) — tokenizers (`TransformerTokenizer`) used to build
>   guides.
> - [benchmarks_processors.md](benchmarks_processors.md) — sibling benchmarks
>   for logits processors.
> - [benchmarks_json_schema.md](benchmarks_json_schema.md) — sibling benchmarks
>   for JSON-schema-to-FSM conversion.

---

## Module Structure

The `benchmarks_guide` module is composed of three benchmark files, each
targeting a different guide type:

| File | Benchmark class(es) | Guide under test |
| --- | --- | --- |
| `benchmarks/bench_regex_guide.py` | `RegexGuideBenchmark`, `MemoryRegexGuideBenchmark` | `RegexGuide` |
| `benchmarks/bench_cfg_guide.py` | `CFGGuideBenchmark` | `CFGGuide` |
| `benchmarks/bench_json_schema.py` | `JsonSchemaBenchmark` | `RegexGuide` (via JSON schema → regex) |

All three files share a common helper, `setup_tokenizer`, defined in
`benchmarks/common.py`.

```mermaid
graph TD
    subgraph benchmarks_guide
        RG[bench_regex_guide.py<br/>RegexGuideBenchmark<br/>MemoryRegexGuideBenchmark]
        CG[bench_cfg_guide.py<br/>CFGGuideBenchmark]
        JS[bench_json_schema.py<br/>JsonSchemaBenchmark]
    end

    COMMON[benchmarks/common.py<br/>setup_tokenizer]

    RG --> COMMON
    JS --> COMMON

    RG -->|RegexGuide.from_regex| REGEX[outlines.processors.guide.RegexGuide]
    JS -->|build_regex_from_schema| CORE[outlines_core.fsm.json_schema]
    JS -->|RegexGuide.from_regex| REGEX
    CG -->|CFGGuide| CFG[outlines.processors.guide.CFGGuide]

    RG -->|cache_disabled| CACHE[outlines.caching.cache_disabled]
    JS -->|cache_disabled| CACHE
    CG -->|cache_disabled| CACHE

    CFG -->|PartialLark| FSM[outlines.fsm.parsing]
    CFG -->|grammars| GRAMMARS[outlines.grammars]
```

---

## Architecture and Component Relationships

The benchmarks sit at the top of a dependency stack. They depend on the public
guide API, which in turn depends on the FSM/parsing layer and the tokenizer
abstraction.

```mermaid
graph LR
    subgraph "Benchmark layer"
        B1[RegexGuideBenchmark]
        B2[MemoryRegexGuideBenchmark]
        B3[CFGGuideBenchmark]
        B4[JsonSchemaBenchmark]
    end

    subgraph "Guide layer (processors)"
        G1[RegexGuide]
        G2[CFGGuide]
    end

    subgraph "Support layer"
        T[TransformerTokenizer]
        C[cache_disabled]
        P[PartialLark / PartialParserState]
        GR[outlines.grammars]
    end

    B1 --> G1
    B2 --> G1
    B4 --> G1
    B3 --> G2

    G1 --> T
    G2 --> T
    G2 --> P
    G2 --> GR

    B1 -.-> C
    B2 -.-> C
    B3 -.-> C
    B4 -.-> C
```

### Key design decisions

- **Cache isolation.** Every timed method is decorated with
  `@cache_disabled()`. Outlines caches the expensive
  `create_states_mapping` computation (see [caching.md](caching.md)); without
  disabling it, repeated benchmark runs would measure cache hits rather than
  real compilation cost. `cache_disabled` is a context manager that flips the
  global `_caching_enabled` flag off for the duration of the call and restores
  it afterwards.
- **Shared tokenizer setup.** `setup_tokenizer()` loads the GPT-2 tokenizer
  once per benchmark `setup()` call and wraps it in a `TransformerTokenizer`,
  ensuring all regex/JSON benchmarks operate on an identical vocabulary.
- **Tiny tokenizer for CFG.** The CFG benchmark deliberately uses a
  ~1000-token vocabulary (`hf-internal-testing/tiny-random-gpt2`) because the
  CFG guide's lazy validity check iterates over the *entire* vocabulary for
  every step — a full GPT-2 vocabulary would make the benchmark prohibitively
  slow.

---

## Component Reference

### `RegexGuideBenchmark` (`bench_regex_guide.py`)

Measures the **time** to compile a regular expression into a `RegexGuide`.

- **Parameters:** one entry per key in `regex_samples` — `email`,
  `complex_phone`, `simple_phone`, `date`, `time`, `ip`, `url`, `ssn`, and
  `complex_span_constrained_relation_extraction`.
- **`setup(pattern_name)`** — loads the GPT-2 tokenizer and selects the regex
  pattern.
- **`time_regex_to_guide(pattern_name)`** — calls
  `RegexGuide.from_regex(self.pattern, self.tokenizer)` under
  `@cache_disabled()`.

The sample set spans a wide complexity range: `ssn` is a trivial fixed-format
pattern, while `complex_span_constrained_relation_extraction` is a large
alternation-heavy pattern that stresses the FSM construction algorithm.

### `MemoryRegexGuideBenchmark` (`bench_regex_guide.py`)

Measures the **peak memory** consumed while compiling a regex into a
`RegexGuide`.

- **Parameters:** a reduced set — `simple_phone` and
  `complex_span_constrained_relation_extraction` — chosen to bracket the
  memory cost from small to large.
- **`peakmem_regex_to_guide(pattern_name)`** — identical body to the timing
  benchmark but tracked by ASV's peak-memory tracker.

### `CFGGuideBenchmark` (`bench_cfg_guide.py`)

Measures both construction and per-step cost of a `CFGGuide` built from a Lark
grammar.

- **Parameters:** `json` and `arithmetic` (from `outlines.grammars`).
- **`setup(grammar_name)`** — builds a tiny tokenizer and pre-builds a
  `CFGGuide` so that per-step benchmarks do not include construction cost.
- **`_run_random_cfg(guide, rejection_sampling)`** — a static helper that
  simulates 40 decoding steps. At each step it shuffles the vocabulary (to
  emulate logits ordered from highest to lowest probability) and then either:
  - **rejection sampling** (`rejection_sampling=True`): picks the first valid
    token via `guide.iter_valid_token_ids(...)`, or
  - **direct sampling** (`rejection_sampling=False`): picks a random token from
    `guide.get_next_instruction(state).tokens`.
- **Timed methods:**
  - `time_cfg_guide_setup` — construction cost of `CFGGuide`.
  - `time_cfg_guide_run_rejection_sampling` — 40 steps using rejection
    sampling.
  - `time_cfg_guide_run` — 40 steps using direct instruction sampling.
  - `peakmem_cfg_guide_run` — peak memory of a 40-step run.

### `JsonSchemaBenchmark` (`bench_json_schema.py`)

Measures the **time** to convert a JSON schema into a regex and then into a
`RegexGuide`.

- **Parameters:** `simple_schema` (a small "Character" object) and
  `complex_schema` (a nested "recording" schema with `$ref`/`definitions`).
- **`time_json_schema_to_fsm(schema_name)`** — calls
  `build_regex_from_schema(self.schema)` (from `outlines_core`) followed by
  `RegexGuide.from_regex(regex, self.tokenizer)`, all under
  `@cache_disabled()`.

---

## Data Flow

The following diagram shows the end-to-end data flow for each benchmark family,
from a formal-language specification to a compiled guide.

```mermaid
flowchart TD
    subgraph Regex["RegexGuideBenchmark / MemoryRegexGuideBenchmark"]
        R1[regex string] --> R2[RegexGuide.from_regex]
        R2 --> R3[RegexGuide]
    end

    subgraph JSON["JsonSchemaBenchmark"]
        J1[JSON schema] --> J2[build_regex_from_schema]
        J2 --> J3[regex string]
        J3 --> J4[RegexGuide.from_regex]
        J4 --> J5[RegexGuide]
    end

    subgraph CFG["CFGGuideBenchmark"]
        C1[Lark grammar] --> C2[CFGGuide.__init__]
        C2 --> C3[PartialLark parser]
        C3 --> C4[CFGGuide]
        C4 --> C5[iter_valid_token_ids / get_next_state]
    end

    TOK[TransformerTokenizer<br/>GPT-2 or tiny-gpt2] --> R2
    TOK --> J4
    TOK --> C2
```

### Per-step decoding flow (CFG benchmark)

```mermaid
sequenceDiagram
    participant Bench as CFGGuideBenchmark
    participant Guide as CFGGuide
    participant Parser as PartialLark

    Bench->>Guide: initial_state
    loop 40 steps
        Bench->>Bench: shuffle token_ids (simulate logits order)
        alt rejection sampling
            Bench->>Guide: iter_valid_token_ids(state, token_ids)
            Guide->>Parser: parse_from_state (per candidate)
            Parser-->>Guide: valid / invalid
            Guide-->>Bench: first valid token_id
        else direct sampling
            Bench->>Guide: get_next_instruction(state)
            Guide-->>Bench: Instruction(tokens)
            Bench->>Bench: random.choice(tokens)
        end
        Bench->>Guide: get_next_state(state, token_id)
        Guide->>Parser: parse_from_state (apply token)
        Parser-->>Guide: new parser_state
        Guide-->>Bench: new CFGState
    end
```

---

## Process Flow: Running the Benchmarks

```mermaid
flowchart LR
    A[asv run] --> B[Read asv.conf.json]
    B --> C[Build virtualenv<br/>pip install .test]
    C --> D[Discover benchmark classes]
    D --> E[For each param:<br/>call setup]
    E --> F[Run timed method<br/>with cache_disabled]
    F --> G[Record time / peakmem]
    G --> H[Store results in results_dir]
    H --> I[asv publish → html_dir]
```

### ASV configuration

The benchmarks are driven by `benchmarks/asv.conf.json`:

| Setting | Value | Meaning |
| --- | --- | --- |
| `project` | `Outlines` | Project name shown in reports |
| `repo` | `..` | Repository root is the parent directory |
| `branches` | `["HEAD"]` | Benchmarks run against the current commit |
| `build_command` | `pip install .[test]` + wheel build | Installs Outlines with test extras |
| `environment_type` | `virtualenv` | Each run uses an isolated virtualenv |
| `benchmark_dir` | `.` | Benchmarks live in the `benchmarks/` directory |
| `results_dir` | `results` | Raw results output |
| `html_dir` | `html` | Generated HTML reports |

---

## Dependencies

```mermaid
graph TD
    BG[benchmarks_guide]

    BG -->|imports| GUIDE[outlines.processors.guide<br/>RegexGuide, CFGGuide]
    BG -->|imports| CACHE[outlines.caching<br/>cache_disabled]
    BG -->|imports| TOK[outlines.models.transformers<br/>TransformerTokenizer]
    BG -->|imports| GRAMMARS[outlines.grammars<br/>json, arithmetic]
    BG -->|imports| CORE[outlines_core.fsm.json_schema<br/>build_regex_from_schema]
    BG -->|imports| HF[transformers<br/>AutoTokenizer]
    BG -->|imports| ASV[asv framework]

    GUIDE --> FSM[outlines.fsm.parsing<br/>PartialLark, PartialParserState]
    GUIDE --> CORE
```

| Dependency | Purpose |
| --- | --- |
| `outlines.processors.guide` | The `RegexGuide` and `CFGGuide` classes under test |
| `outlines.caching.cache_disabled` | Disables the state-mapping cache during measurement |
| `outlines.models.transformers.TransformerTokenizer` | Wraps HuggingFace tokenizers for guide construction |
| `outlines.grammars` | Provides the `json` and `arithmetic` Lark grammars |
| `outlines_core.fsm.json_schema` | Converts JSON schemas to regexes |
| `transformers.AutoTokenizer` | Loads GPT-2 / tiny-gpt2 tokenizers |
| `asv` | Benchmark harness (discovery, timing, memory tracking) |

---

## Interpreting Results

- **`time_regex_to_guide` / `time_json_schema_to_fsm` / `time_cfg_guide_setup`**
  measure one-time compilation cost. These are paid once per (pattern,
  tokenizer) pair in production and are the primary target for caching
  optimizations.
- **`time_cfg_guide_run*`** measure per-step cost. Because the CFG guide uses a
  lazy, vocabulary-wide validity check, these numbers scale linearly with
  vocabulary size — hence the tiny tokenizer.
- **`peakmem_*`** measure the memory footprint of guide construction and
  decoding, which matters for large vocabularies and complex grammars.

Comparing the `simple_*` and `complex_*` parameters within each benchmark
isolates how cost scales with pattern/grammar complexity.

---

## See Also

- [processors.md](processors.md) — `Guide`, `RegexGuide`, `CFGGuide` internals.
- [caching.md](caching.md) — how `cache_disabled` and the state-mapping cache work.
- [fsm_parsing.md](fsm_parsing.md) — the `PartialLark` parser used by `CFGGuide`.
- [models.md](models.md) — tokenizer abstractions.
- [benchmarks_processors.md](benchmarks_processors.md) — logits-processor benchmarks.
- [benchmarks_json_schema.md](benchmarks_json_schema.md) — JSON-schema benchmarks.
