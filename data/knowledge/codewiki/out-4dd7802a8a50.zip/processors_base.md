# Processors Base Module

## Introduction

The `processors_base` module provides the foundational abstraction for all logits processors in Outlines. Its central component, `OutlinesLogitsProcessor`, defines a library-agnostic interface for biasing token generation by manipulating the logits produced by a language model at each generation step.

The key design goal of this module is **tensor library independence**: Outlines supports models running on PyTorch, NumPy, JAX, MLX, and TensorFlow. Rather than duplicating logits-processing logic for each backend, `OutlinesLogitsProcessor` delegates all tensor manipulation to a pluggable [`TensorAdapter`](processors_tensor_adapters.md), while subclasses implement only the backend-agnostic masking logic in `process_logits`.

This module is the base class for the concrete processors found in:
- [`processors_structured`](processors_structured.md) — `GuideLogitsProcessor`, `RegexLogitsProcessor`, `JSONLogitsProcessor`, `CFGLogitsProcessor`
- [`processors_guides`](processors_guides.md) — the `Guide` implementations that drive the masking

---

## Core Component: `OutlinesLogitsProcessor`

`OutlinesLogitsProcessor` is an abstract base class that implements a shared `__call__` entrypoint and requires subclasses to implement `process_logits`.

### Responsibilities

| Responsibility | Description |
| --- | --- |
| **Backend selection** | Resolves the correct `TensorAdapter` implementation from the `tensor_library_name` passed to the constructor. |
| **Shape normalization** | Standardizes `input_ids` and `logits` to 2D tensors before processing, then restores the original shape. |
| **Delegation** | Calls the subclass-provided `process_logits` to apply the actual masking/bias. |
| **Validation** | Raises `NotImplementedError` for unsupported libraries and `ValueError` for unsupported tensor shapes. |

### Class Structure

```python
class OutlinesLogitsProcessor:
    tensor_adapter: TensorAdapterImplementation

    def __init__(self, tensor_library_name: str): ...
    @abstractmethod
    def process_logits(self, input_ids, logits): ...
    def __call__(self, input_ids, logits): ...
```

### Constructor

```python
def __init__(self, tensor_library_name: str)
```

The constructor looks up the adapter class in the `tensor_adapters` registry using `tensor_library_name`. Supported values are `"jax"`, `"mlx"`, `"numpy"`, `"tensorflow"`, and `"torch"`. If the library is not registered, a `NotImplementedError` is raised. The instantiated adapter is stored on `self.tensor_adapter`.

> **Note:** The `tensor_library_name` must match the library used by the model that will invoke the processor. See [processors_tensor_adapters](processors_tensor_adapters.md) for the full list of adapters and their capabilities.

### `process_logits` (abstract)

```python
@abstractmethod
def process_logits(self, input_ids: TensorType, logits: TensorType) -> TensorType
```

This is the method subclasses must implement. It receives **2D** `input_ids` and `logits` tensors and returns the processed (biased) logits. The docstring highlights several important design constraints for universal logits processors:

- Logits processors are used **once** and never re-applied for a new sequence generator.
- Some models pass only `output_ids`; others (e.g. `llamacpp`, `transformers`) prefix with `input_ids`.
- Some sampling methods (e.g. beam search) produce **unstable sequence ordering** in models like vLLM.

### `__call__` (entrypoint)

```python
def __call__(self, input_ids: TensorType, logits: TensorType) -> TensorType
```

This is the method invoked by the model. It performs shape normalization and delegates to `process_logits`:

1. **1D/2D reconciliation** — If `input_ids` is 1D while `logits` is 2D with a single sequence, `input_ids` is unsqueezed to 2D (needed for `mlx-lm`).
2. **Shape assertion** — Asserts that the leading dimensions of `logits` and `input_ids` match.
3. **Dispatch**:
   - If `logits` is 2D → call `process_logits` directly.
   - If `logits` is 1D → unsqueeze both inputs, call `process_logits`, then squeeze the result back to 1D.
   - Otherwise → raise `ValueError`.

---

## Architecture

The following diagram shows how `OutlinesLogitsProcessor` sits between the model and the tensor backend, and how concrete processors extend it.

```mermaid
classDiagram
    class OutlinesLogitsProcessor {
        +TensorAdapterImplementation tensor_adapter
        +__init__(tensor_library_name: str)
        +__call__(input_ids, logits) TensorType
        +process_logits(input_ids, logits)* TensorType
    }

    class GuideLogitsProcessor {
        +Tokenizer tokenizer
        +Guide guide
        +process_logits(input_ids, logits)
        +copy()
    }

    class RegexLogitsProcessor
    class JSONLogitsProcessor
    class CFGLogitsProcessor

    class TensorAdapter {
        <<abstract>>
        +library_name: str
        +shape(tensor)
        +unsqueeze(tensor)
        +squeeze(tensor)
        +to_list(tensor)
        +to_scalar(tensor)
        +full_like(tensor, fill_value)
        +concatenate(tensors)
        +get_device(tensor)
        +to_device(tensor, device)
        +boolean_ones_like(tensor)
        +apply_mask(tensor, mask, value)
        +argsort_descending(tensor)
    }

    OutlinesLogitsProcessor --> TensorAdapter : uses
    GuideLogitsProcessor --|> OutlinesLogitsProcessor
    RegexLogitsProcessor --|> GuideLogitsProcessor
    JSONLogitsProcessor --|> RegexLogitsProcessor
    CFGLogitsProcessor --|> GuideLogitsProcessor
```

---

## Component Interaction Flow

The sequence below illustrates a single generation step: a model calls the processor, which normalizes shapes, delegates to the subclass, and uses the tensor adapter to manipulate tensors.

```mermaid
sequenceDiagram
    participant Model
    participant P as OutlinesLogitsProcessor
    participant Sub as process_logits (subclass)
    participant TA as TensorAdapter

    Model->>P: __call__(input_ids, logits)
    P->>TA: shape(input_ids), shape(logits)
    alt input_ids 1D & logits 2D single seq
        P->>TA: unsqueeze(input_ids)
    end
    P->>P: assert leading dims match
    alt logits is 2D
        P->>Sub: process_logits(input_ids, logits)
    else logits is 1D
        P->>TA: unsqueeze(input_ids), unsqueeze(logits)
        P->>Sub: process_logits(...)
        Sub-->>P: processed (2D)
        P->>TA: squeeze(processed)
    else unsupported shape
        P->>P: raise ValueError
    end
    Sub-->>P: processed logits
    P-->>Model: processed logits
```

---

## Dependency Graph

`OutlinesLogitsProcessor` depends on the tensor adapter registry and is itself the base for the structured processors.

```mermaid
graph TD
    OLP[OutlinesLogitsProcessor] -->|resolves adapter from| REG[tensor_adapters registry]
    REG --> TA_BASE[TensorAdapter]
    REG --> TA_TORCH[TorchTensorAdapter]
    REG --> TA_NUMPY[NumpyTensorAdapter]
    REG --> TA_JAX[JAXTensorAdapter]
    REG --> TA_MLX[MLXTensorAdapter]
    REG --> TA_TF[TensorFlowTensorAdapter]

    GLP[GuideLogitsProcessor] -->|extends| OLP
    RLP[RegexLogitsProcessor] -->|extends| GLP
    JLP[JSONLogitsProcessor] -->|extends| RLP
    CLP[CFGLogitsProcessor] -->|extends| GLP

    GLP -->|uses| GUIDE[Guide]
    RLP -->|builds| RG[RegexGuide]
    CLP -->|builds| CG[CFGGuide]
```

---

## How Subclasses Use the Base

The base class is intentionally minimal. Concrete processors implement `process_logits` and rely on `self.tensor_adapter` for all backend-specific operations. For example, `GuideLogitsProcessor` (in [processors_structured](processors_structured.md)) uses the adapter to:

- Convert generated token ids to Python lists (`to_list`) for guide-state hashing.
- Extract scalar token ids (`to_scalar`) for state transitions.
- Build per-batch index tensors (`full_like`).
- Concatenate allowed-token batches (`concatenate`).
- Move tensors to the correct device (`get_device`, `to_device`).
- Construct and apply boolean masks (`boolean_ones_like`, `apply_mask`).

`CFGLogitsProcessor` additionally uses `argsort_descending` to implement rejection sampling over valid token ids.

This separation means a new backend only requires a new `TensorAdapter` implementation — no changes to any processor logic.

---

## Design Considerations

The `process_logits` docstring enumerates constraints that any universal logits processor must respect:

1. **Single-use semantics** — Processors are not reused across sequence generators.
2. **Input variability** — Models differ in whether they pass `output_ids` only or prefix with `input_ids`.
3. **Ordering instability** — Beam search and similar methods can reorder sequences (notably in vLLM), so processors must not assume stable sequence positions.

These constraints are why the base class centralizes shape normalization and delegates all tensor operations to the adapter, keeping subclass logic focused on the masking semantics.

---

## Related Modules

- [processors_tensor_adapters](processors_tensor_adapters.md) — The `TensorAdapter` interface and per-library implementations used by this module.
- [processors_structured](processors_structured.md) — Concrete logits processors (`GuideLogitsProcessor`, `RegexLogitsProcessor`, `JSONLogitsProcessor`, `CFGLogitsProcessor`) built on this base class.
- [processors_guides](processors_guides.md) — The `Guide` finite-state-machine abstractions that drive structured masking.
- [models_base](models_base.md) — The model abstraction that invokes logits processors during generation.
