# Teleprompt Prompt Module

## Introduction

The **Teleprompt Prompt** module is a sub-module of DSPy's `teleprompt` package that focuses on **prompt optimization** — automatically discovering better *instructions* (and, in some cases, few-shot demonstrations) for a DSPy program's predictors without modifying the underlying model weights.

Unlike weight-based optimizers (see [teleprompt_weight.md](teleprompt_weight.md)) or few-shot-only optimizers (see [teleprompt_fewshot.md](teleprompt_fewshot.md)), the optimizers in this module treat the *natural-language instruction* attached to each `Signature` as the primary optimization variable. They iteratively propose, evaluate, and select instructions using a separate "prompt model" (a teacher LM) while scoring candidates against a task metric.

The module contains four optimizers plus one shared utility signature:

| Component | File | Role |
|-----------|------|------|
| `COPRO` | `copro_optimizer.py` | Coordinate-ascent instruction optimizer (breadth/depth search) |
| `SignatureOptimizer` | `signature_opt.py` | **Deprecated** alias of `COPRO` |
| `MIPROv2` | `mipro_optimizer_v2.py` | Bayesian (Optuna/TPE) joint instruction + few-shot optimizer |
| `SIMBA` | `simba.py` | Stochastic Introspective Mini-Batch Ascent optimizer |
| `OfferFeedback` | `simba_utils.py` | Signature used by SIMBA to generate module-level advice |

---

## Architecture Overview

All optimizers in this module inherit from the abstract `Teleprompter` base class and follow the same high-level contract: given a `student` program, a `trainset`, and a `metric`, return an optimized copy of the program.

```mermaid
graph TD
    TP["Teleprompter<br/>(teleprompt_core)"]
    COPRO["COPRO"]
    SO["SignatureOptimizer<br/>(deprecated)"]
    MIPRO["MIPROv2"]
    SIMBA["SIMBA"]

    TP --> COPRO
    COPRO --> SO
    TP --> MIPRO
    TP --> SIMBA

    subgraph "Shared Infrastructure"
        EV["Evaluate<br/>(evaluate_program_evaluation)"]
        GP["GroundedProposer<br/>(propose_grounded_proposer)"]
        UT["teleprompt.utils<br/>(teleprompt_core)"]
        PRED["Predict / Signature<br/>(predict_core, signatures)"]
    end

    COPRO --> EV
    COPRO --> PRED
    MIPRO --> EV
    MIPRO --> GP
    MIPRO --> UT
    SIMBA --> EV
    SIMBA --> PRED
```

### Position in the Teleprompt Ecosystem

```mermaid
graph LR
    subgraph teleprompt
        CORE["teleprompt_core<br/>Teleprompter, utils"]
        FEW["teleprompt_fewshot<br/>BootstrapFewShot, KNN"]
        PROMPT["teleprompt_prompt<br/>(this module)"]
        WEIGHT["teleprompt_weight<br/>BootstrapFinetune, GRPO"]
        META["teleprompt_meta<br/>Ensemble, BetterTogether"]
    end
    CORE --> PROMPT
    FEW -.->|"few-shot candidates"| PROMPT
    PROMPT -.->|"optimized programs"| META
```

The prompt module **depends on** `teleprompt_core` (base class + utilities) and `teleprompt_fewshot` (MIPROv2 reuses bootstrapped few-shot sets). Its outputs are commonly fed into `teleprompt_meta` optimizers such as `Ensemble` and `BetterTogether`.

---

## Component Details

### COPRO — Coordinate Ascent Prompt Optimizer

`COPRO` performs a **coordinate-ascent** search over the instruction space of each predictor. It alternates between:

1. **Proposing** a batch of `breadth` new instructions for a predictor (seeded by the current instruction, then by the history of past attempts and their scores).
2. **Evaluating** each candidate by running the full program on the trainset via `Evaluate`.
3. **Selecting** the best-scoring instruction and fixing it before moving to the next predictor.

This is repeated for `depth` iterations, with each iteration using the *history of attempts and scores* as few-shot context for the next proposal round.

```mermaid
flowchart TD
    Start([compile student, trainset]) --> Seed["Seed each predictor with<br/>BasicGenerateInstruction<br/>(breadth-1 candidates + original)"]
    Seed --> DepthLoop{"For d in depth"}
    DepthLoop --> PredLoop["For each predictor p"]
    PredLoop --> CandLoop["For each candidate c"]
    CandLoop --> SetSig["Set signature instruction +<br/>output prefix on clone"]
    SetSig --> Eval["Evaluate program on trainset"]
    Eval --> Record["Record score in<br/>evaluated_candidates"]
    Record --> CandLoop
    CandLoop --> Best["Set predictor to best candidate"]
    Best --> PredLoop
    PredLoop --> GenNext["GenerateInstructionGivenAttempts<br/>using sorted attempts"]
    GenNext --> DepthLoop
    DepthLoop --> Dedup["Sort + drop duplicates"]
    Dedup --> Return([Return best program])
```

**Key signatures used:**

- `BasicGenerateInstruction` — proposes an improved instruction + output-field prefix from the *initial* instruction.
- `GenerateInstructionGivenAttempts` — proposes new instructions given a ranked list of previously attempted instructions and their scores.

**Constructor parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `prompt_model` | `None` | LM used to generate instructions (defaults to `dspy.settings.lm`) |
| `metric` | `None` | Task metric used for scoring |
| `breadth` | `10` | New prompts generated per iteration (must be > 1) |
| `depth` | `3` | Number of proposal/evaluation rounds |
| `init_temperature` | `1.4` | Sampling temperature for proposal |
| `track_stats` | `False` | Attach `results_best`, `results_latest`, `total_calls` to the best program |

**Statistics tracking** (when `track_stats=True`): the returned program carries `results_best` and `results_latest` dictionaries keyed by predictor id, each containing `depth`, `max`, `average`, `min`, and `std` arrays, plus a `total_calls` counter.

---

### SignatureOptimizer — Deprecated Alias

`SignatureOptimizer` is a thin, **deprecated** subclass of `COPRO`. It emits a red warning on construction and simply forwards `compile(student, devset=...)` to `COPRO.compile(student, trainset=...)`. New code should use `COPRO` directly.

```mermaid
classDiagram
    Teleprompter <|-- COPRO
    COPRO <|-- SignatureOptimizer
    class SignatureOptimizer {
        +compile(student, devset, eval_kwargs)
    }
```

---

### MIPROv2 — Bayesian Joint Optimizer

`MIPROv2` (Multiprompt Instruction PRoposal Optimizer v2) is the most sophisticated optimizer in the module. It jointly optimizes **instructions** and **few-shot demonstration sets** using Bayesian optimization (Optuna's TPE sampler).

The pipeline has three explicit steps:

```mermaid
flowchart TD
    Start([compile]) --> Validate["Validate auto/num_trials/num_candidates<br/>+ set random seeds"]
    Validate --> Datasets["Set & validate trainset/valset"]
    Datasets --> Hyper["Set hyperparams from run mode<br/>(light/medium/heavy)"]
    Hyper --> Confirm{"requires_permission_to_run?"}
    Confirm -->|yes| Estimate["Estimate LM calls<br/>+ await user confirmation"]
    Confirm -->|no| Step1
    Estimate --> Step1
    Step1["STEP 1: Bootstrap few-shot examples<br/>create_n_fewshot_demo_sets"] --> Step2
    Step2["STEP 2: Propose instruction candidates<br/>GroundedProposer"] --> Step3
    Step3["STEP 3: Optimize prompt parameters<br/>Optuna TPE over instructions + demos"] --> Return([Return best program])
```

**Auto run modes** (`AUTO_RUN_SETTINGS`):

| Mode | `n` (candidates) | `val_size` |
|------|------------------|------------|
| `light` | 6 | 100 |
| `medium` | 12 | 300 |
| `heavy` | 18 | 1000 |

When `auto` is set, `num_candidates` and `num_trials` are derived automatically; when `auto=None`, both must be supplied explicitly. The number of trials is computed as `max(2 * num_vars * log2(num_candidates), 1.5 * num_candidates)`.

**Minibatching:** When enabled, each trial evaluates on a small minibatch (`minibatch_size`, default 35), and a full validation-set evaluation is performed every `minibatch_full_eval_steps` trials (default 5) plus at the end. This dramatically reduces LM call cost while still surfacing the best full-eval program.

**Key collaborators:**

- `GroundedProposer` (from [propose_grounded_proposer.md](propose_grounded_proposer.md)) — generates instruction candidates using dataset summaries, program source, task demos, and prompting tips.
- `create_n_fewshot_demo_sets` (from [teleprompt_core.md](teleprompt_core.md)) — produces candidate few-shot demonstration sets.
- `Evaluate` (from [evaluate_program_evaluation.md](evaluate_program_evaluation.md)) — scores candidate programs.

**Constructor parameters (selected):**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `metric` | required | Task metric |
| `prompt_model` | `None` | LM for instruction proposal |
| `task_model` | `None` | LM for program execution |
| `max_bootstrapped_demos` | `4` | Max bootstrapped demos per predictor |
| `max_labeled_demos` | `4` | Max labeled demos per predictor |
| `auto` | `"light"` | Auto run mode (`light`/`medium`/`heavy`/`None`) |
| `num_candidates` | `None` | Instruction/few-shot candidates (required if `auto=None`) |
| `init_temperature` | `0.5` | Proposal temperature |
| `track_stats` | `True` | Attach trial logs and candidate programs |
| `metric_threshold` | `None` | Threshold passed to bootstrapping |

**Statistics attached to the best program** (when `track_stats=True`): `trial_logs`, `score`, `prompt_model_total_calls`, `total_calls`, `mb_candidate_programs` (minibatch-evaluated), and `candidate_programs` (full-eval, sorted by score).

---

### SIMBA — Stochastic Introspective Mini-Batch Ascent

`SIMBA` is a gradient-free, mini-batch ascent optimizer inspired by stochastic optimization. It maintains a **pool of programs**, samples trajectories on mini-batches, and uses two introspection strategies to build improved candidates:

- **`append_a_demo`** — adds a successful trajectory step as a new few-shot demo to a predictor.
- **`append_a_rule`** — uses the `OfferFeedback` signature to generate natural-language *advice* that is appended to a predictor's instructions.

```mermaid
flowchart TD
    Start([compile student, trainset]) --> Init["Initialize pool with baseline program<br/>(simba_idx=0)"]
    Init --> BatchLoop{"For each of max_steps batches"}
    BatchLoop --> Sample["Sample trajectories:<br/>num_candidates models x bsize examples<br/>via softmax over top programs"]
    Sample --> Execute["Execute in parallel"]
    Execute --> Bucket["Bucket results by example,<br/>sort by (max-min gap, max, max-avg gap)"]
    Bucket --> Build["Build new candidates:<br/>drop demos + apply strategy<br/>(append_a_demo / append_a_rule)"]
    Build --> EvalCand["Evaluate candidates on mini-batch"]
    EvalCand --> Register["Register candidates in pool,<br/>track winning programs"]
    Register --> BatchLoop
    BatchLoop --> Final["Evaluate winning programs on full trainset"]
    Final --> Return([Return best program])
```

**Constructor parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `metric` | required | Task metric |
| `bsize` | `32` | Mini-batch size |
| `num_candidates` | `6` | New candidates per iteration |
| `max_steps` | `8` | Optimization steps |
| `max_demos` | `4` | Max demos per predictor before dropping |
| `demo_input_field_maxlen` | `100_000` | Truncation length for demo input fields |
| `temperature_for_sampling` | `0.2` | Softmax temperature for trajectory sampling |
| `temperature_for_candidates` | `0.2` | Softmax temperature for source-program selection |

**Statistics attached to the best program:** `candidate_programs` (sorted `{score, program}` dicts) and `trial_logs`.

---

### OfferFeedback — Introspection Signature

`OfferFeedback` is a `dspy.Signature` used by SIMBA's `append_a_rule` strategy. Given a *better* and a *worse* execution trajectory of the same program, it produces:

- `discussion` — a blame analysis of where each module went wrong.
- `module_advice` — a `dict[str, str]` mapping each module name to concrete, generalizable advice.

The advice is appended to the corresponding predictor's instructions, effectively performing a targeted, trajectory-grounded instruction edit.

**Supporting utilities in `simba_utils.py`:**

| Function | Purpose |
|----------|---------|
| `prepare_models_for_resampling` | Creates `n` LM copies with varied temperatures for trajectory sampling |
| `wrap_program` | Wraps a program to return `{prediction, trace, score, example}` |
| `append_a_demo` | Strategy that appends a successful trace step as a demo |
| `append_a_rule` | Strategy that generates and appends instruction advice via `OfferFeedback` |
| `inspect_modules` | Renders a human-readable definition of all program modules |
| `recursive_mask` | Makes arbitrary objects JSON-serializable for the feedback prompt |

---

## Data Flow

The following diagram shows how data flows through a typical prompt-optimization run (using MIPROv2 as the representative example):

```mermaid
sequenceDiagram
    participant User
    participant Opt as MIPROv2
    participant Boot as create_n_fewshot_demo_sets
    participant Prop as GroundedProposer
    participant Eval as Evaluate
    participant LM as Task/Prompt LM

    User->>Opt: compile(student, trainset, valset)
    Opt->>Boot: bootstrap few-shot demo sets
    Boot->>LM: run program on trainset
    LM-->>Boot: traces -> demos
    Boot-->>Opt: demo_candidates
    Opt->>Prop: propose_instructions_for_program
    Prop->>LM: generate instructions
    LM-->>Prop: instruction candidates
    Prop-->>Opt: instruction_candidates
    loop num_trials
        Opt->>Opt: select instruction + demo combo (Optuna)
        Opt->>Eval: evaluate candidate program
        Eval->>LM: run program on minibatch/valset
        LM-->>Eval: predictions
        Eval-->>Opt: score
    end
    Opt-->>User: best_program (+ stats)
```

---

## Component Interaction Summary

```mermaid
graph TD
    subgraph "teleprompt_prompt"
        COPRO
        SO["SignatureOptimizer"]
        MIPRO
        SIMBA
        OF["OfferFeedback"]
    end

    subgraph "External Dependencies"
        TP["Teleprompter"]
        EV["Evaluate"]
        GP["GroundedProposer"]
        UT["teleprompt.utils"]
        SIG["Signature / Predict"]
        PAR["Parallel"]
        SET["settings"]
    end

    SO --> COPRO
    COPRO --> TP
    COPRO --> EV
    COPRO --> SIG
    MIPRO --> TP
    MIPRO --> EV
    MIPRO --> GP
    MIPRO --> UT
    SIMBA --> TP
    SIMBA --> PAR
    SIMBA --> OF
    SIMBA --> SIG
    OF --> SIG
    COPRO --> SET
    MIPRO --> SET
```

---

## Choosing an Optimizer

| Scenario | Recommended Optimizer |
|----------|----------------------|
| Quick instruction-only optimization, small budget | `COPRO` |
| Joint instruction + few-shot optimization with strong results | `MIPROv2` |
| Noisy/expensive metrics, want trajectory-grounded introspection | `SIMBA` |
| Legacy code referencing `SignatureOptimizer` | Migrate to `COPRO` |

---

## Related Documentation

- [teleprompt_core.md](teleprompt_core.md) — `Teleprompter` base class and shared utilities (`create_n_fewshot_demo_sets`, `eval_candidate_program`, etc.)
- [teleprompt_fewshot.md](teleprompt_fewshot.md) — Few-shot optimizers (`BootstrapFewShot`, `KNNFewShot`, etc.)
- [teleprompt_weight.md](teleprompt_weight.md) — Weight/fine-tuning optimizers (`BootstrapFinetune`, `GRPO`)
- [teleprompt_meta.md](teleprompt_meta.md) — Meta-optimizers (`Ensemble`, `BetterTogether`)
- [propose_grounded_proposer.md](propose_grounded_proposer.md) — `GroundedProposer` used by MIPROv2
- [evaluate_program_evaluation.md](evaluate_program_evaluation.md) — `Evaluate` and `EvaluationResult`
- [predict_core.md](predict_core.md) — `Predict` and `Parameter`
- [signatures_signature.md](signatures_signature.md) — `Signature` and `SignatureMeta`
- [primitives_module_system.md](primitives_module_system.md) — `Module` and `BaseModule`
