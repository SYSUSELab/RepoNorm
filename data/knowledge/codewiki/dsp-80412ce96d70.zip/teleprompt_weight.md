# Teleprompt Weight Module

## Introduction

The `teleprompt_weight` module provides DSPy optimizers that improve a program by **updating the underlying language model weights** rather than (or in addition to) modifying prompts and few-shot demonstrations. This is in contrast to prompt-based optimizers such as `MIPROv2` or `COPRO` (see [teleprompt_prompt.md](teleprompt_prompt.md)) and few-shot optimizers such as `BootstrapFewShot` (see [teleprompt_fewshot.md](teleprompt_fewshot.md)).

The module contains two optimizers:

- **`BootstrapFinetune`** — a supervised fine-tuning (SFT) optimizer that bootstraps traces from a teacher program, converts them into provider-specific training data, and fine-tunes the student's LMs.
- **`GRPO`** — a reinforcement-learning optimizer that uses Group Relative Policy Optimization to train the student's LM in place across multiple training steps, using a metric as the reward signal.

Both optimizers share a common base class, `FinetuneTeleprompter`, and a set of shared bootstrapping utilities defined in `bootstrap_finetune.py`.

---

## Module Structure

```mermaid
graph TD
    subgraph teleprompt_weight["teleprompt_weight (current module)"]
        FT["FinetuneTeleprompter<br/>(base class)"]
        BFT["BootstrapFinetune"]
        GRPO["GRPO"]
        FP["FailedPrediction<br/>(dataclass)"]
        BTD["bootstrap_trace_data()"]
        HELPERS["all_predictors_have_lms()<br/>assert_structural_equivalency()<br/>prepare_teacher()<br/>build_call_data_from_trace()"]
    end

    subgraph teleprompt_core["teleprompt_core"]
        TP["Teleprompter"]
    end

    subgraph clients["clients"]
        LM["LM"]
        PROV["Provider / ReinforceJob / TrainingJob"]
        UFT["utils_finetune<br/>(TrainDataFormat, GRPOGroup)"]
    end

    subgraph adapters["adapters"]
        AD["Adapter / ChatAdapter"]
    end

    subgraph evaluate["evaluate"]
        EV["Evaluate"]
    end

    subgraph primitives["primitives"]
        MOD["Module"]
        EX["Example"]
    end

    TP --> FT
    FT --> BFT
    FT --> GRPO
    BFT --> BTD
    GRPO --> BTD
    BFT --> FP
    GRPO --> FP
    BFT --> HELPERS
    GRPO --> HELPERS

    BFT --> LM
    GRPO --> LM
    LM --> PROV
    BFT --> UFT
    GRPO --> UFT
    BFT --> AD
    GRPO --> AD
    BTD --> EV
    BFT --> MOD
    GRPO --> MOD
    BTD --> EX
```

---

## Core Components

### `FinetuneTeleprompter`

`FinetuneTeleprompter` is the abstract base class for all weight-based optimizers. It extends the generic [`Teleprompter`](teleprompt_core.md) interface and adds the concept of **per-LM training kwargs**.

| Member | Description |
| --- | --- |
| `train_kwargs` | A `dict[LM, Any]` mapping each LM to its training hyperparameters. |
| `convert_to_lm_dict(arg)` | Static helper that normalizes an argument into a `dict[LM, Any]`. If the argument is already keyed by `LM` instances, it is returned as-is; otherwise a `defaultdict` is created that returns the same value for every LM. |

The `convert_to_lm_dict` helper is reused by both subclasses to accept either a single shared configuration (e.g. `train_kwargs={"lr": 1e-5}`) or a per-LM configuration (e.g. `train_kwargs={lm_a: {...}, lm_b: {...}}`).

### `BootstrapFinetune`

`BootstrapFinetune` performs **supervised fine-tuning**. It runs a teacher program over the training set to collect traces, filters them with an optional metric, converts them into provider-specific training data, and launches fine-tuning jobs.

#### Constructor parameters

| Parameter | Type | Default | Description |
| --- | --- | --- | --- |
| `metric` | `Callable \| None` | `None` | Metric used to filter bootstrapped traces. If `None`, all traces are kept. |
| `multitask` | `bool` | `True` | If `True`, a single fine-tuning job is created per unique LM. If `False`, one job is created per predictor. |
| `train_kwargs` | `dict` | `None` | Training hyperparameters, either shared or per-LM. |
| `adapter` | `Adapter \| dict[LM, Adapter]` | `None` | Adapter used to format training data. Defaults to `settings.adapter` or `ChatAdapter`. |
| `exclude_demos` | `bool` | `False` | Whether to strip few-shot demos from the training data. |
| `num_threads` | `int \| None` | `None` | Number of concurrent fine-tuning jobs. Defaults to `dspy.settings.num_threads`. |

#### Compilation flow

```mermaid
flowchart TD
    A["compile(student, trainset, teacher)"] --> B["all_predictors_have_lms(student)"]
    B --> C["prepare_teacher() for each teacher"]
    C --> D["bootstrap_trace_data()<br/>collect traces from teachers"]
    D --> E["Group traces by (LM, predictor index)"]
    E --> F["_prepare_finetune_data()<br/>filter by metric, build call data"]
    F --> G["finetune_lms()<br/>launch jobs in parallel"]
    G --> H["Update student predictors<br/>with fine-tuned LMs"]
    H --> I["student._compiled = True"]
    I --> J["return student"]
```

Key behaviors:

1. **Teacher preparation** — `prepare_teacher` validates structural equivalency between student and teacher and ensures they do not share predictors.
2. **Trace bootstrapping** — `bootstrap_trace_data` runs the teacher(s) over the dataset and captures the internal `dspy.settings.trace`.
3. **Data preparation** — `_prepare_finetune_data` filters traces by metric score, builds call data via `build_call_data_from_trace`, and shuffles deterministically (`random.Random(0)`).
4. **Job launching** — `finetune_lms` calls `lm.kill()` to free resources, then `lm.finetune(...)` for each job, joining threads as they complete.
5. **Student update** — each predictor's `lm` is replaced with the fine-tuned LM. Demos are cleared if `exclude_demos=True`.

> **Note:** `BootstrapFinetune` requires `num_threads >= number of fine-tuning jobs`, otherwise it raises a `ValueError`.

### `GRPO`

`GRPO` (Group Relative Policy Optimization) is a reinforcement-learning optimizer that **updates the student's LM in place** across a configurable number of training steps. Unlike `BootstrapFinetune`, it does not create new LM instances; instead, the provider's `ReinforceJob` mutates the LM's `model` field.

#### Constructor parameters (selected)

| Parameter | Type | Default | Description |
| --- | --- | --- | --- |
| `metric` | `Callable \| None` | `None` | Reward function used to score rollouts. |
| `multitask` | `bool` | `True` | Must be `True` (independent per-predictor jobs are unsupported). |
| `num_threads` | `int` | `6` | Threads for bootstrapping and evaluation. |
| `num_train_steps` | `int` | `100` | Number of GRPO training steps. |
| `seed` | `int` | `0` | Seed for the internal RNG. |
| `num_dspy_examples_per_grpo_step` | `int` | `1` | Examples sampled per training step. |
| `num_rollouts_per_grpo_step` | `int` | `1` | Rollouts (group size) per step. |
| `use_train_as_val` | `bool` | `False` | Use the training set as the validation set. |
| `num_steps_for_val` | `int` | `5` | Frequency (in steps) of validation reporting. |
| `report_train_scores` | `bool` | `False` | Report training scores during validation. |
| `failure_score` | `float` | `0` | Reward for a failed (but parseable) prediction. |
| `format_failure_score` | `float` | `-1` | Reward for a formatting failure. |
| `variably_invoked_predictor_grouping_mode` | `Literal` | `"truncate"` | How to handle predictors invoked a variable number of times (`truncate`, `fill`, `ragged`). |
| `variably_invoked_predictor_fill_strategy` | `Literal` | `None` | Fill strategy (`randint` or `max`) when mode is `fill`. |

#### Constraints

- `failure_score > format_failure_score` is enforced (the range is used to interpolate formatting rewards).
- `exclude_demos` must be `True` and `multitask` must be `True`.
- The student program must use a **single LM** across all predictors.
- The student program must be included in the list of teachers.
- `num_rollouts_per_grpo_step` must be divisible by the number of teachers.

#### Compilation flow

```mermaid
flowchart TD
    A["compile(student, trainset, teacher, valset)"] --> B["Validate inputs &<br/>single-LM constraint"]
    B --> C["Prepare teachers &<br/>assert structural equivalency"]
    C --> D["Disable LM cache for all programs"]
    D --> E["Create ReinforceJob per unique LM"]
    E --> F["report_validation_metrics(step=-1)"]
    F --> G{"For each train step"}
    G --> H["select_training_sample_and_update_shuffled_trainset()"]
    H --> I["bootstrap_trace_data() per teacher"]
    I --> J["validate_trace_data_and_log_issues()"]
    J --> K["Build GRPOGroup batches per predictor"]
    K --> L["job.step(train_data, GRPO_CHAT)"]
    L --> M["report_validation_metrics(step)"]
    M --> G
    G --> N["job.terminate() for all jobs"]
    N --> O["Recover LM cache states"]
    O --> P["student._compiled = True"]
    P --> Q["return student"]
```

Key behaviors:

1. **In-place LM updates** — the `ReinforceJob` mutates `lm.model`, which is shared by the student (and any teacher sharing the same LM).
2. **Cache management** — `disable_lm_cache` / `recover_lm_cache` toggle `lm.cache` around training to avoid stale rollouts.
3. **Shuffled trainset** — `update_shuffled_trainset` and `select_training_sample_and_update_shuffled_trainset` implement epoch-based sampling with padding to fill GRPO steps.
4. **Group construction** — traces are grouped per predictor and per rollout, handling variably-invoked predictors via truncation, filling, or ragged grouping.
5. **Format-failure handling** — `FailedPrediction` instances are converted into training examples with a `format_reward`.

### `FailedPrediction`

A lightweight dataclass representing a prediction whose LM response could not be parsed by the adapter.

```python
@dataclass
class FailedPrediction:
    completion_text: str
    format_reward: float | None = None
```

It is produced by `bootstrap_trace_data` when an `AdapterParseError` is raised, and consumed by both `BootstrapFinetune` (as a training example) and `GRPO` (as a reward signal).

---

## Shared Bootstrapping Utilities

These functions live in `bootstrap_finetune.py` and are shared by both optimizers.

### `bootstrap_trace_data`

Runs a program over a dataset using [`Evaluate`](evaluate_program_evaluation.md) and captures the internal trace for each example.

```mermaid
sequenceDiagram
    participant Caller as Optimizer
    participant BTD as bootstrap_trace_data
    participant Eval as Evaluate
    participant Prog as Program
    participant Trace as dspy.settings.trace

    Caller->>BTD: program, dataset, metric
    BTD->>Eval: evaluate(wrapped_program, wrapped_metric)
    loop For each example
        Eval->>Prog: program(**inputs)
        Prog->>Trace: record (Predictor, inputs, outputs)
        alt AdapterParseError
            Prog-->>BTD: FailedPrediction + trace
        else Success
            Prog-->>BTD: prediction + trace
        end
    end
    BTD-->>Caller: list[{example, prediction, trace, score}]
```

Notable parameters:

- `raise_on_error` — if `False`, examples that fail to unpack are skipped.
- `capture_failed_parses` — whether to capture `AdapterParseError` as `FailedPrediction`.
- `failure_score` / `format_failure_score` — scores assigned to failures.

### Helper functions

| Function | Purpose |
| --- | --- |
| `build_call_data_from_trace(trace, pred_ind, adapter, exclude_demos)` | Extracts a single predictor's call data from a trace and formats it via `adapter.format_finetune_data`. |
| `all_predictors_have_lms(program)` | Returns `True` if every predictor has an LM set. |
| `copy_program_with_lms(program)` | Deep-copies a program while preserving predictor LMs. |
| `prepare_student(student)` | Validates that the student is not already compiled. |
| `prepare_teacher(student, teacher)` | Validates structural equivalency and no shared predictors. |
| `assert_structural_equivalency(p1, p2)` | Asserts matching predictor counts and names. |
| `assert_no_shared_predictor(p1, p2)` | Asserts the two programs share no predictor instances. |
| `get_unique_lms(program)` | Returns the set of unique LMs used by a program. |
| `launch_lms(program)` / `kill_lms(program)` | Launch/kill all LMs in a program. |

---

## Data Flow

The following diagram shows how data flows from a DSPy program through bootstrapping into provider-specific training formats.

```mermaid
flowchart LR
    subgraph Input
        TS["trainset<br/>(list[Example])"]
        TEA["teacher program"]
    end

    subgraph Bootstrap
        BTD["bootstrap_trace_data()"]
        TRACE["trace_data<br/>[{example, prediction, trace, score}]"]
    end

    subgraph Formatting
        BCD["build_call_data_from_trace()"]
        FFD["adapter.format_finetune_data()"]
        IDF["infer_data_format()"]
    end

    subgraph Training
        CHAT["TrainDataFormat.CHAT"]
        GRPOF["TrainDataFormat.GRPO_CHAT"]
        JOB["LM.finetune() / LM.reinforce()"]
    end

    TS --> BTD
    TEA --> BTD
    BTD --> TRACE
    TRACE --> BCD
    BCD --> FFD
    FFD --> IDF
    IDF --> CHAT
    IDF --> GRPOF
    CHAT --> JOB
    GRPOF --> JOB
```

### Training data formats

The `TrainDataFormat` enum (from [clients_finetune.md](clients_finetune.md)) defines the supported formats:

| Format | Used by | Description |
| --- | --- | --- |
| `CHAT` | `BootstrapFinetune` | A list of chat messages (`{"messages": [...]}`). |
| `COMPLETION` | `BootstrapFinetune` | Prompt/completion pairs. |
| `GRPO_CHAT` | `GRPO` | A list of `GRPOChatData` groups with rewards. |

`infer_data_format(adapter)` maps an adapter to a format — currently only `ChatAdapter` is supported, mapping to `TrainDataFormat.CHAT`.

---

## Component Interaction

```mermaid
graph TB
    subgraph Optimizers
        BFT["BootstrapFinetune"]
        GRPO["GRPO"]
    end

    subgraph LM_Layer["LM Layer"]
        LM["LM"]
        LM_FT["LM.finetune()"]
        LM_RF["LM.reinforce()"]
    end

    subgraph Providers
        PROV["Provider"]
        TJ["TrainingJob"]
        RJ["ReinforceJob"]
        OAI["OpenAIProvider"]
        DBX["DatabricksProvider"]
        ARB["ArborProvider"]
    end

    subgraph Adapters
        AD["Adapter"]
        CA["ChatAdapter"]
    end

    BFT --> LM_FT
    GRPO --> LM_RF
    LM_FT --> LM
    LM_RF --> LM
    LM --> PROV
    PROV --> TJ
    PROV --> RJ
    PROV --> OAI
    PROV --> DBX
    PROV --> ARB
    BFT --> AD
    GRPO --> AD
    AD --> CA
```

### Provider support matrix

| Provider | Fine-tuning (`BootstrapFinetune`) | Reinforcement (`GRPO`) |
| --- | --- | --- |
| `OpenAIProvider` | ✅ (`CHAT`, `COMPLETION`) | ❌ |
| `DatabricksProvider` | ✅ (`CHAT`, `COMPLETION`) | ❌ |
| `ArborProvider` | ✅ (`CHAT`, `COMPLETION`, `GRPO_CHAT`) | ✅ |
| `LocalProvider` | ❌ | ❌ |

`GRPO` requires a provider whose `reinforceable` flag is `True` (currently only `ArborProvider`). `BootstrapFinetune` requires a provider whose `finetunable` flag is `True`.

---

## Relationship to Other Modules

- **[teleprompt_core.md](teleprompt_core.md)** — `FinetuneTeleprompter` extends the base `Teleprompter` interface.
- **[teleprompt_prompt.md](teleprompt_prompt.md)** — prompt-based optimizers that modify instructions instead of weights.
- **[teleprompt_fewshot.md](teleprompt_fewshot.md)** — few-shot optimizers that modify demonstrations instead of weights.
- **[clients_lm.md](clients_lm.md)** — the `LM` class provides `finetune()` and `reinforce()` entry points.
- **[clients_providers.md](clients_providers.md)** — provider implementations that execute the actual training jobs.
- **[clients_finetune.md](clients_finetune.md)** — `TrainDataFormat`, `GRPOChatData`, and related data structures.
- **[adapters_core.md](adapters_core.md)** — adapters format traces into training data via `format_finetune_data`.
- **[evaluate_program_evaluation.md](evaluate_program_evaluation.md)** — `Evaluate` powers trace bootstrapping and validation reporting.
- **[primitives_module_system.md](primitives_module_system.md)** — `Module` and `Example` are the core program/data abstractions.

---

## Usage Examples

### Supervised fine-tuning with `BootstrapFinetune`

```python
import dspy
from dspy.teleprompt import BootstrapFinetune

lm = dspy.LM("openai/gpt-4o-mini", temperature=0.7)
dspy.configure(lm=lm)

student = MyProgram()
teacher = MyProgram()

optimizer = BootstrapFinetune(
    metric=my_metric,
    train_kwargs={"learning_rate": 1e-5},
    exclude_demos=True,
)
compiled = optimizer.compile(student, trainset=trainset, teacher=teacher)
```

### Reinforcement learning with `GRPO`

```python
import dspy
from dspy.teleprompt import GRPO

lm = dspy.LM("openai/arbor:my-model", api_base="http://localhost:8000/v1/")
dspy.configure(lm=lm)

student = MyProgram()

optimizer = GRPO(
    metric=my_metric,
    num_train_steps=100,
    num_dspy_examples_per_grpo_step=4,
    num_rollouts_per_grpo_step=8,
    exclude_demos=True,
    multitask=True,
)
compiled = optimizer.compile(student, trainset=trainset, valset=valset)
```

---

## Summary

The `teleprompt_weight` module provides two complementary weight-optimization strategies for DSPy programs:

- **`BootstrapFinetune`** — supervised fine-tuning driven by bootstrapped teacher traces, producing new LM instances.
- **`GRPO`** — reinforcement learning that updates the student's LM in place using metric-based rewards.

Both share the `FinetuneTeleprompter` base class and a common set of bootstrapping utilities (`bootstrap_trace_data`, `FailedPrediction`, and structural-validation helpers), and both rely on the `LM`/`Provider` abstraction to delegate the actual training to backend providers.
