# Adapters

## Introduction

The **adapters** module is the translation layer between DSPy's structured, typed programming model and the raw text-based interface of Large Language Models (LMs). DSPy programs are built around [`Signature`](signatures.md) objects that declare typed input and output fields, but LMs only understand and produce text (or, increasingly, structured JSON and native function calls). Adapters bridge this gap in both directions:

- **Formatting (DSPy → LM):** Convert a signature, its few-shot demonstrations, conversation history, and current inputs into a list of chat messages that the LM can consume.
- **Parsing (LM → DSPy):** Convert the LM's raw text response back into a dictionary of typed output fields that match the signature.

By centralizing this logic, DSPy allows the same program to be run against different LM providers and prompting strategies simply by swapping the adapter, without changing any program code.

## Purpose and Core Functionality

The module provides:

1. **A pluggable adapter abstraction** — the [`Adapter`](adapters_core.md) base class defines the contract (`format`, `parse`, `__call__`, `acall`) that all adapters implement.
2. **A family of concrete adapters** — each optimized for a different prompting/parsing strategy:
   - [`ChatAdapter`](adapters_core.md) — the default, marker-delimited (`[[ ## field ## ]]`) chat format.
   - [`JSONAdapter`](adapters_core.md) — JSON output, with optional OpenAI Structured Outputs support.
   - [`XMLAdapter`](adapters_core.md) — XML-tag-delimited output.
   - [`TwoStepAdapter`](adapters_core.md) — a natural-language first stage plus a separate extraction LM.
3. **A set of custom DSPy types** — rich field types such as [`Image`](adapters_types.md), [`Audio`](adapters_types.md), [`Code`](adapters_types.md), [`History`](adapters_types.md), [`Tool`](adapters_types.md), and [`ToolCalls`](adapters_types.md) that adapters know how to serialize into provider-native content parts.

## Architecture Overview

The adapters module sits between the DSPy program layer (signatures, modules, predictions) and the LM client layer. The diagram below shows the high-level position of the module and its internal structure.

```mermaid
graph TD
    subgraph Program["DSPy Program Layer"]
        SIG["Signature<br/>(typed fields)"]
        MOD["Module / Predict"]
    end

    subgraph Adapters["adapters module"]
        BASE["Adapter (base)"]
        CHAT["ChatAdapter"]
        JSON["JSONAdapter"]
        XML["XMLAdapter"]
        TWO["TwoStepAdapter"]
        TYPES["Custom Types<br/>(Image, Audio, Code,<br/>History, Tool, ToolCalls)"]
        UTILS["utils<br/>(format/parse helpers)"]
    end

    subgraph Clients["clients module"]
        LM["LM / BaseLM"]
    end

    MOD -->|"signature + demos + inputs"| BASE
    BASE --> CHAT
    BASE --> TWO
    CHAT --> JSON
    CHAT --> XML
    BASE -.uses.-> TYPES
    BASE -.uses.-> UTILS
    BASE -->|"messages"| LM
    LM -->|"raw text / tool_calls"| BASE
    BASE -->|"typed outputs"| MOD

    SIG -.defines.-> MOD
```

### The Adapter Call Lifecycle

Every adapter invocation follows the same lifecycle, implemented in [`Adapter.__call__`](adapters_core.md) / [`Adapter.acall`](adapters_core.md):

```mermaid
sequenceDiagram
    participant P as Predict/Module
    participant A as Adapter
    participant LM as LM Client

    P->>A: __call__(lm, lm_kwargs, signature, demos, inputs)
    A->>A: _call_preprocess()<br/>(native function calling setup)
    A->>A: format(signature, demos, inputs)
    Note over A: Build system message,<br/>few-shot demos,<br/>history, current input
    A->>LM: messages + lm_kwargs
    LM-->>A: raw outputs (text / tool_calls / logprobs)
    A->>A: _call_postprocess()
    A->>A: parse(signature, text)
    A-->>P: list[dict] of typed output fields
```

The base class orchestrates this flow and delegates the format-specific work to overridable hooks:

| Hook | Responsibility |
| --- | --- |
| `format_field_description` | Describe input/output fields in the system message |
| `format_field_structure` | Describe the required output structure |
| `format_task_description` | Render `signature.instructions` |
| `format_user_message_content` | Render a user turn (demos, history, current input) |
| `format_assistant_message_content` | Render an assistant turn (demos, history) |
| `parse` | Extract typed output fields from the LM response |

## Sub-modules

The module is organized into two sub-modules, each documented separately:

### 1. Core Adapters — [adapters_core.md](adapters_core.md)

Contains the [`Adapter`](adapters_core.md) base class and all concrete adapter implementations. This is where the format/parse contract lives and where the different prompting strategies are realized. Key components:

- **`Adapter`** — abstract base defining the lifecycle, native function-calling preprocessing, conversation-history handling, and demo formatting.
- **`ChatAdapter`** — the default adapter using `[[ ## field_name ## ]]` section markers, with automatic fallback to `JSONAdapter` on parse failure.
- **`JSONAdapter`** — extends `ChatAdapter` to produce/parse JSON, with support for OpenAI Structured Outputs and native function calling.
- **`XMLAdapter`** — extends `ChatAdapter` to use XML tags for field delimitation.
- **`TwoStepAdapter`** — decouples generation from extraction, useful for reasoning models that struggle with structured output.

### 2. Custom Types — [adapters_types.md](adapters_types.md)

Contains the custom DSPy field types that adapters serialize into provider-native content parts. Key components:

- **`Type`** — base class for all custom types, defining the `format()` contract and serialization markers.
- **`Image`**, **`Audio`** — multimodal content types.
- **`Code`** — code generation/analysis type with language awareness.
- **`History`** — conversation history container.
- **`Tool`**, **`ToolCalls`** — function/tool calling support.

## Relationship to Other Modules

- **[signatures](signatures.md):** Adapters consume `Signature` objects to know which fields to format and parse. The `Signature` API (`delete`, `insert`, `make_signature`) is used by adapters to derive modified signatures (e.g., removing the history field, or building an extractor signature).
- **[clients](clients.md):** Adapters call into the `LM` client to actually invoke the model, passing formatted messages and receiving raw outputs. Native function calling relies on `litellm` capabilities surfaced through the client.
- **[predict](predict.md):** `Predict` and other modules invoke adapters via the configured adapter, passing demos and inputs and receiving typed outputs.
- **[utils](utils.md):** The `AdapterParseError` exception (in `dspy/utils/exceptions.py`) is raised by adapters when parsing fails, and `BaseCallback` (in `dspy/utils/callback.py`) provides the `on_adapter_format_*` / `on_adapter_parse_*` hooks that wrap adapter `format`/`parse` methods.

## Choosing an Adapter

| Adapter | Best for | Output format |
| --- | --- | --- |
| `ChatAdapter` | General-purpose default | `[[ ## field ## ]]` markers |
| `JSONAdapter` | Providers with JSON/structured-output support | JSON object |
| `XMLAdapter` | Models that handle XML tags well | `<field>...</field>` tags |
| `TwoStepAdapter` | Reasoning models (e.g., o-series) | Natural language + extraction LM |

Adapters are configured globally via `dspy.configure(adapter=...)` or per-call, and `ChatAdapter` automatically falls back to `JSONAdapter` when parsing fails (except on context-window errors).
