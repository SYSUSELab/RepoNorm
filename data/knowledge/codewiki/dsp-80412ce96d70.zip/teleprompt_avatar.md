# Teleprompt Avatar Module

## Introduction

The `teleprompt_avatar` module provides **`AvatarOptimizer`**, a teleprompter (optimizer) that automatically improves the instruction text of an [`Avatar`](predict_avatar.md) agent. The `Avatar` agent is a tool-using agent that iteratively selects and invokes tools to accomplish a goal. Rather than optimizing model weights or few-shot demonstrations, `AvatarOptimizer` performs **instruction optimization**: it evaluates the agent on a training set, separates examples into "positive" and "negative" buckets based on a metric, asks an LLM to compare the two groups, and then rewrites the agent's instruction to improve performance on the failing cases.

This module is part of the broader [teleprompt](teleprompt.md) family of optimizers, but it is unique in that it targets the *instruction* of a tool-using agent rather than demonstrations or weights.

---

## Core Components

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `AvatarOptimizer` | `Teleprompter` subclass | Orchestrates the iterative instruction-optimization loop. |
| `Comparator` | `dspy.Signature` | Analyzes positive vs. negative examples and produces feedback. |
| `FeedbackBasedInstruction` | `dspy.Signature` | Rewrites the instruction by incorporating the feedback. |
| `EvalResult` | Pydantic `BaseModel` | Structured container for a single evaluated example (input, score, actions). |

---

## Architecture

The optimizer sits between the training data, the `Avatar` agent being optimized, and the LLM-backed signatures that generate feedback and new instructions.

```mermaid
graph TD
    subgraph "teleprompt_avatar"
        AO[AvatarOptimizer]
        CMP[Comparator<br/>dspy.Signature]
        FBI[FeedbackBasedInstruction<br/>dspy.Signature]
        ER[EvalResult<br/>BaseModel]
    end

    subgraph "predict_avatar"
        AV[Avatar Agent]
        ACT[Actor Signature]
        AOUT[ActionOutput]
    end

    subgraph "teleprompt_core"
        TP[Teleprompter]
    end

    subgraph "primitives"
        MOD[Module]
        EX[Example]
    end

    TP --> AO
    AO -->|evaluates| AV
    AV --> ACT
    AV --> AOUT
    AO -->|builds| ER
    AO -->|calls| CMP
    AO -->|calls| FBI
    CMP --> ER
    AO -->|reads/writes| ACT
    AO -->|consumes| EX
    AV --> MOD
```

### Key Relationships

- **`AvatarOptimizer` extends [`Teleprompter`](teleprompt.md)** — it implements the `compile(student, *, trainset)` contract defined by the base class.
- **`AvatarOptimizer` operates on an [`Avatar`](predict_avatar.md) agent** — it reads `best_actor.actor.signature.instructions` and `best_actor.tools`, and writes back a new instruction via `signature.with_instructions(...)`.
- **`Comparator` and `FeedbackBasedInstruction` are DSPy signatures** — they are wrapped in `dspy.TypedPredictor` and `dspy.Predict` respectively, delegating LLM interaction to the [predict](predict.md) layer.
- **`EvalResult` reuses `ActionOutput`** from the [predict_avatar](predict_avatar.md) module to capture the actions taken on each example.

---

## Component Details

### `AvatarOptimizer`

The central class. It is constructed with a metric function and several tuning parameters, then invoked via `compile`.

**Constructor parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `metric` | `Callable` | *(required)* | Scoring function `metric(example, prediction) -> float`. |
| `max_iters` | `int` | `10` | Number of optimization iterations. |
| `lower_bound` | `int` | `0` | Scores `<= lower_bound` are classified as negative examples. |
| `upper_bound` | `int` | `1` | Scores `>= upper_bound` are classified as positive examples. |
| `max_positive_inputs` | `int \| None` | `10` | Cap on positive examples sampled per iteration. |
| `max_negative_inputs` | `int \| None` | `10` | Cap on negative examples sampled per iteration. |
| `optimize_for` | `str` | `"max"` | Whether to maximize (`"max"`) or minimize (`"min"`) the metric. |

Internally it instantiates:
- `self.comparator = dspy.TypedPredictor(Comparator)`
- `self.feedback_instruction = dspy.Predict(FeedbackBasedInstruction)`

**Methods:**

- `process_example(actor, example, return_outputs)` — Deep-copies the actor, runs it on a single example's inputs, and computes the metric. Exceptions are caught and treated as a score of `0`.
- `thread_safe_evaluator(devset, actor, return_outputs=False, num_threads=None)` — Evaluates the actor over the whole dev set using a `ThreadPoolExecutor` (defaulting to `dspy.settings.num_threads`), returning the average metric and optionally per-example results.
- `_get_pos_neg_results(actor, trainset)` — Runs the evaluator, then partitions results into positive (`score >= upper_bound`) and negative (`score <= lower_bound`) `EvalResult` lists. Raises `ValueError` if either bucket is empty.
- `compile(student, *, trainset)` — The main optimization loop (see below).

### `Comparator` (Signature)

An LLM signature that receives the current instruction, the available actions/tools, and the positive/negative example sets. It produces a `feedback` string that:
1. Contrasts patterns of successful vs. unsuccessful inputs.
2. Reviews computational logic for inconsistencies.
3. Specifies tool-usage modifications to improve negative inputs.

### `FeedbackBasedInstruction` (Signature)

An LLM signature that takes the `previous_instruction` and the `feedback` and produces a `new_instruction`. The prompt constrains the output to no more than 3 paragraphs and requires retaining the general guidelines from the previous instruction.

### `EvalResult` (BaseModel)

A structured record for a single evaluated example:

```python
class EvalResult(BaseModel):
    example: dict
    score: float
    actions: list[ActionOutput] | None = None
```

---

## Optimization Process Flow

The `compile` method runs an iterative loop that evaluates, partitions, generates feedback, and rewrites the instruction.

```mermaid
flowchart TD
    START([compile student, trainset]) --> INIT[best_actor = deepcopy student<br/>best_score = -999 or 999]
    INIT --> LOOP{iteration < max_iters?}
    LOOP -->|yes| EVAL[_get_pos_neg_results<br/>thread_safe_evaluator]
    EVAL --> PART[Partition into pos/neg EvalResults]
    PART --> CHECK{pos and neg non-empty?}
    CHECK -->|no| ERR[Raise ValueError]
    CHECK -->|yes| SAMPLE[Sample up to max_positive/negative inputs]
    SAMPLE --> CMP[Comparator -> feedback]
    CMP --> FBI[FeedbackBasedInstruction -> new_instruction]
    FBI --> IMPROVE{score improves best_score?}
    IMPROVE -->|yes| UPDATE[Update actor signature instructions<br/>deepcopy actor_clone<br/>best_score = score]
    IMPROVE -->|no| NEXT
    UPDATE --> NEXT[iteration += 1]
    NEXT --> LOOP
    LOOP -->|no| RETURN([return best_actor])
```

### Step-by-step

1. **Initialize** — `best_actor` is a deep copy of the student; `best_score` starts at `-999` (for `"max"`) or `999` (for `"min"`).
2. **Evaluate** — `_get_pos_neg_results` runs the actor over the training set in parallel and computes the average score.
3. **Partition** — Examples scoring `>= upper_bound` become positive; those `<= lower_bound` become negative. Empty buckets raise a `ValueError` with guidance to adjust bounds or add data.
4. **Sample** — Positive and negative sets are down-sampled to `max_positive_inputs` / `max_negative_inputs` to bound prompt size.
5. **Generate feedback** — The `Comparator` signature contrasts the two groups and emits feedback.
6. **Rewrite instruction** — The `FeedbackBasedInstruction` signature produces a new instruction from the previous instruction plus feedback.
7. **Accept if improved** — Only when the new score beats `best_score` (respecting `optimize_for`) is the actor's signature updated with the new instruction and `actor_clone` refreshed.
8. **Repeat** until `max_iters` is exhausted, then return `best_actor`.

---

## Data Flow

```mermaid
sequenceDiagram
    participant U as User
    participant AO as AvatarOptimizer
    participant AV as Avatar (best_actor)
    participant M as metric
    participant CMP as Comparator
    participant FBI as FeedbackBasedInstruction

    U->>AO: compile(student, trainset)
    loop max_iters
        AO->>AV: run on each example (threaded)
        AV-->>AO: prediction + actions
        AO->>M: metric(example, prediction)
        M-->>AO: score
        AO->>AO: partition pos/neg EvalResults
        AO->>CMP: instruction, actions, pos/neg inputs
        CMP-->>AO: feedback
        AO->>FBI: previous_instruction, feedback
        FBI-->>AO: new_instruction
        AO->>AV: update signature if improved
    end
    AO-->>U: best_actor
```

---

## Dependencies

```mermaid
graph LR
    AO[AvatarOptimizer] --> TP[Teleprompter<br/>teleprompt_core]
    AO --> AV[Avatar<br/>predict_avatar]
    AO --> AOUT[ActionOutput<br/>predict_avatar]
    AO --> SIG[dspy.Signature<br/>signatures]
    AO --> PRED[dspy.TypedPredictor / dspy.Predict<br/>predict]
    AO --> EX[Example<br/>primitives]
    AO --> SET[dspy.settings<br/>dsp_utils]
    AO --> PYD[pydantic.BaseModel]
    AO --> TQDM[tqdm]
```

| Dependency | Module | Purpose |
|------------|--------|---------|
| `Teleprompter` | [teleprompt](teleprompt.md) | Base class defining the `compile` contract. |
| `Avatar`, `ActionOutput` | [predict_avatar](predict_avatar.md) | The agent being optimized and its action records. |
| `dspy.Signature` | [signatures](signatures.md) | Defines `Comparator` and `FeedbackBasedInstruction`. |
| `dspy.TypedPredictor`, `dspy.Predict` | [predict](predict.md) | Wraps signatures for LLM execution. |
| `dspy.Example` | [primitives](primitives.md) | Training examples consumed by `compile`. |
| `dspy.settings` | [dsp_utils](dsp_utils.md) | Provides `num_threads` for parallel evaluation. |

---

## Usage Example

```python
import dspy
from dspy.teleprompt.avatar_optimizer import AvatarOptimizer
from dspy.predict.avatar import Avatar, Tool

# Define tools and an Avatar agent
tools = [Tool(tool=my_search_fn, name="Search", desc="Search the web")]
agent = Avatar("Answer the user's question using tools.", tools=tools)

# Define a metric
def metric(example, prediction):
    return float(prediction.answer == example.answer)

# Optimize the agent's instruction
optimizer = AvatarOptimizer(
    metric=metric,
    max_iters=5,
    upper_bound=1.0,
    lower_bound=0.0,
    optimize_for="max",
)
optimized_agent = optimizer.compile(agent, trainset=trainset)
```

---

## Design Notes & Constraints

- **Instruction-only optimization** — Unlike weight-based optimizers such as [GRPO](teleprompt.md) or demonstration-based ones like [BootstrapFewShot](teleprompt.md), `AvatarOptimizer` only rewrites the actor's instruction string.
- **Bound sensitivity** — The optimizer requires at least one positive and one negative example per iteration. If the metric is too lenient or too strict, `_get_pos_neg_results` raises a `ValueError`; adjust `upper_bound`/`lower_bound` or supply more data.
- **Thread safety** — Each example is evaluated on a deep copy of the actor, so concurrent execution does not mutate shared state.
- **Best-so-far tracking** — The returned actor is the best-scoring one seen across iterations, not necessarily the last one produced.

---

## Related Modules

- [predict_avatar](predict_avatar.md) — The `Avatar` agent and its `Tool`/`Action`/`ActionOutput` models.
- [teleprompt](teleprompt.md) — The `Teleprompter` base class and the broader optimizer family.
- [predict](predict.md) — `Predict`, `TypedPredictor`, and other prediction modules.
- [signatures](signatures.md) — The `Signature` system used to define `Comparator` and `FeedbackBasedInstruction`.
- [primitives](primitives.md) — `Module`, `Example`, and `Prediction` data containers.
- [dsp_utils](dsp_utils.md) — Global `Settings`, including `num_threads`.
