# Signatures Module

## Overview

The **signatures** module is the declarative backbone of DSPy. A *Signature* defines the input/output contract of a DSPy program: it declares which fields a module consumes, which fields it produces, their types, and the natural-language instructions that guide the underlying language model. Signatures are the primary way developers describe *what* a module should do, decoupled from *how* it is executed.

The module is intentionally small but foundational — nearly every other DSPy module (predictors, adapters, optimizers, retrievers) depends on it. It provides:

- A **class-based DSL** for declaring signatures (`class MySig(dspy.Signature): ...`).
- A **string-based DSL** for quickly constructing signatures (`"question -> answer"`).
- **Field constructors** (`InputField`, `OutputField`) that carry DSPy-specific metadata (prefix, description, format, parser) alongside standard Pydantic constraints.
- **Introspection and manipulation utilities** for reading, mutating, serializing, and comparing signatures.

## Architecture

The module is split into two cohesive sub-modules:

| Sub-module | File | Responsibility |
|------------|------|----------------|
| [signatures_fields](signatures_fields.md) | `dspy/signatures/field.py` | Field constructors and metadata translation to Pydantic |
| [signatures_signature](signatures_signature.md) | `dspy/signatures/signature.py` | The `Signature` base class, `SignatureMeta` metaclass, and string/dict parsing |

```mermaid
graph TD
    subgraph "signatures module"
        F["field.py<br/>InputField / OutputField<br/>OldField / OldInputField / OldOutputField"]
        S["signature.py<br/>Signature / SignatureMeta<br/>make_signature / ensure_signature"]
    end

    F -->|"InputField / OutputField used by"| S
    S -->|"builds on Pydantic"| P["pydantic.BaseModel / FieldInfo"]
    F -->|"wraps"| P

    S -->|"consumed by"| PRED["predict module"]
    S -->|"consumed by"| ADP["adapters module"]
    S -->|"consumed by"| TP["teleprompt module"]
    S -->|"consumed by"| RET["retrievers module"]
```

## Core Concepts

### Signatures as Pydantic Models

Every `Signature` is a subclass of `pydantic.BaseModel`. This gives DSPy free validation, JSON-schema generation, and type coercion. DSPy layers its own semantics on top by storing field metadata inside Pydantic's `json_schema_extra` dictionary under reserved keys such as `__dspy_field_type`, `prefix`, `desc`, `format`, and `parser`.

### Input vs. Output Fields

Fields are tagged as either `input` or `output` via the `__dspy_field_type` metadata key. This distinction drives:

- The string representation (`"input1, input2 -> output1, output2"`).
- Field ordering (inputs always precede outputs).
- How adapters render prompts and parse responses.

### Instructions

The class docstring of a `Signature` subclass becomes its **instructions** — the natural-language prompt describing the task. If omitted, DSPy synthesizes a default instruction from the field names.

## Data Flow

```mermaid
flowchart LR
    A["User declares<br/>class MySig(Signature)"] --> B["SignatureMeta.__new__<br/>collects fields, sets defaults"]
    B --> C["Signature class<br/>(Pydantic model)"]
    D["User calls<br/>Signature('q -> a')"] --> E["SignatureMeta.__call__<br/>-> make_signature"]
    E --> F["_parse_signature<br/>AST parsing"]
    F --> C
    C --> G["input_fields / output_fields / fields"]
    C --> H["instructions / signature"]
    C --> I["dump_state / load_state"]
```

## Sub-module Documentation

- **[signatures_fields](signatures_fields.md)** — Documents the field constructors (`InputField`, `OutputField`), the legacy `OldField` hierarchy, and the translation of DSPy arguments and Pydantic constraints into `json_schema_extra`.
- **[signatures_signature](signatures_signature.md)** — Documents the `Signature` base class, the `SignatureMeta` metaclass (including frame-based custom-type detection), and the string/dict parsing pipeline (`make_signature`, `ensure_signature`, `_parse_signature`, `_parse_type_node`, `infer_prefix`).

## Relationship to Other Modules

- **predict** — Predictors such as `Predict` and `ChainOfThought` accept a `Signature` to define their I/O contract. See [predict.md](predict.md).
- **adapters** — Adapters (`ChatAdapter`, `JSONAdapter`, etc.) consume `Signature` field metadata to build prompts and parse LM outputs. See [adapters.md](adapters.md).
- **teleprompt** — Optimizers mutate signatures (instructions, prefixes, descriptions) during compilation. See [teleprompt.md](teleprompt.md).
- **primitives** — `Example` and `Prediction` mirror signature fields as data containers. See [primitives.md](primitives.md).
