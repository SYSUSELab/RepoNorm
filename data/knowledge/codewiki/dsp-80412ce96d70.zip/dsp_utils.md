# dsp_utils

## Overview

The `dsp_utils` module provides the foundational, low-level utilities that the rest of DSPy relies on. It is intentionally small and dependency-light, and it serves two distinct purposes:

1. **Global configuration management** — a thread-safe, singleton-based settings system (`Settings`) that holds the active language model, adapter, retrieval model, callbacks, and dozens of other runtime knobs used throughout DSPy.
2. **General-purpose helpers** — a collection of small utility functions and data structures (attribute-accessible dictionaries, batching helpers, context managers, etc.) used across the codebase.

Because almost every other DSPy module reads from `dspy.settings` and uses these helpers, `dsp_utils` sits at the very bottom of the dependency graph and has no internal DSPy dependencies of its own (it only depends on the Python standard library and `tqdm`).

## Architecture

The module is composed of two files, each with a clear responsibility:

```mermaid
graph TD
    subgraph dsp_utils
        Settings["settings.py<br/>Settings (singleton)"]
        Utils["utils.py<br/>dotdict, dotdict_lax,<br/>NullContextManager, helpers"]
    end

    Settings -->|uses dotdict| Utils

    subgraph "Consumers (rest of DSPy)"
        Predict["predict"]
        Clients["clients"]
        Adapters["adapters"]
        Teleprompt["teleprompt"]
        Parallel["utils/parallelizer"]
    end

    Predict -->|reads config| Settings
    Clients -->|reads config| Settings
    Adapters -->|reads config| Settings
    Teleprompt -->|reads config| Settings
    Parallel -->|propagates context| Settings
    Predict -->|helpers| Utils
    Clients -->|helpers| Utils
```

### Component Relationships

```mermaid
graph LR
    subgraph settings.py
        Settings
        DEFAULT_CONFIG["DEFAULT_CONFIG (dotdict)"]
        main_thread_config["main_thread_config"]
        thread_local_overrides["thread_local_overrides (ContextVar)"]
        Settings --> DEFAULT_CONFIG
        Settings --> main_thread_config
        Settings --> thread_local_overrides
    end

    subgraph utils.py
        dotdict
        dotdict_lax
        NullContextManager
        helpers["batch, flatten, zipstar,<br/>grouper, deduplicate, ..."]
    end

    DEFAULT_CONFIG -.->|is a| dotdict
    main_thread_config -.->|is a| dotdict
    thread_local_overrides -.->|is a| dotdict
```

## Sub-modules

The module is split into two documented sub-modules:

| Sub-module | Description | Documentation |
| --- | --- | --- |
| **Settings** | The thread-safe singleton configuration system, including global config, thread-local overrides, and the `configure`/`context` APIs. | [dsp_utils_settings.md](dsp_utils_settings.md) |
| **Utilities** | General-purpose helper functions and data structures (`dotdict`, `dotdict_lax`, `NullContextManager`, batching/zipping helpers). | [dsp_utils_utilities.md](dsp_utils_utilities.md) |

## High-Level Functionality

### Settings (`dspy/dsp/utils/settings.py`)

`Settings` is a **singleton** that exposes DSPy's global configuration as attribute access. It implements a three-tier configuration model:

- **`DEFAULT_CONFIG`** — the immutable baseline of all recognized configuration keys (e.g. `lm`, `adapter`, `rm`, `callbacks`, `max_errors`, `num_threads`).
- **`main_thread_config`** — the global configuration, mutable only via `configure()` by a single "owner" thread.
- **`thread_local_overrides`** — a `contextvars.ContextVar` holding per-thread overrides set via the `context()` context manager.

Reads resolve in the order: thread-local override → global config → `AttributeError`. This design allows a single global configuration while still supporting safe, temporary, thread-scoped overrides that propagate to child threads spawned by DSPy primitives (e.g. `ParallelExecutor`).

See [dsp_utils_settings.md](dsp_utils_settings.md) for full details.

### Utilities (`dspy/dsp/utils/utils.py`)

A grab-bag of small helpers. The most important are the attribute-accessible dictionary types:

- **`dotdict`** — a `dict` subclass supporting attribute-style access (`d.foo`), with a custom `__deepcopy__` to avoid recursion.
- **`dotdict_lax`** — a lighter variant where missing keys return `None` instead of raising.
- **`NullContextManager`** — a no-op context manager used as a default when no real context is needed.

The file also contains many standalone helpers (`batch`, `flatten`, `zipstar`, `grouper`, `deduplicate`, `lengths2offsets`, `groupby_first_item`, etc.) used for data manipulation.

See [dsp_utils_utilities.md](dsp_utils_utilities.md) for full details.

## Configuration Data Flow

The following diagram shows how configuration flows from a `configure()` call to a consumer reading a value:

```mermaid
sequenceDiagram
    participant User
    participant Settings
    participant main_thread_config
    participant thread_local_overrides
    participant Consumer

    User->>Settings: configure(lm=my_lm)
    Settings->>Settings: _ensure_configure_allowed()
    Settings->>main_thread_config: main_thread_config["lm"] = my_lm

    User->>Settings: with context(temperature=0.5):
    Settings->>thread_local_overrides: set({...overrides, temperature: 0.5})
    Consumer->>Settings: settings.temperature
    Settings->>thread_local_overrides: get()
    thread_local_overrides-->>Settings: {temperature: 0.5}
    Settings-->>Consumer: 0.5
    Note over Settings: on exit, reset(token)
```

## Relationship to Other Modules

- **[clients](clients.md)** — `LM`, `BaseLM`, and providers read the active model and cache settings from `dspy.settings`.
- **[adapters](adapters.md)** — adapters read the configured adapter and formatting options from `dspy.settings`.
- **[predict](predict.md)** — predictors read `lm`, `adapter`, `callbacks`, and `max_errors` from settings.
- **[utils](utils.md)** — `ParallelExecutor` copies thread-local overrides into spawned threads, which is the mechanism that makes `Settings.context()` propagate.
- **[teleprompt](teleprompt.md)** — optimizers frequently use `dspy.context(...)` to temporarily swap models during evaluation.

## Summary

`dsp_utils` is the configuration and helper backbone of DSPy. Its `Settings` singleton provides a thread-safe, context-aware global configuration, while `utils.py` supplies the small data structures and functions that the rest of the framework builds upon. Despite its small size, it is a dependency of nearly every other module.
