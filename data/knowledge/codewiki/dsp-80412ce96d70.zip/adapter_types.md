# Adapter Types

## Overview

The **adapter_types** module (`dspy/adapters/types/`) defines the custom data types that DSPy uses to represent rich, non-textual content within signatures and LM interactions. These types extend the base `Type` class and provide a uniform mechanism for:

- **Encoding** external content (images, audio, code, conversation history, tool definitions) into a format the LM can consume.
- **Formatting** that content into the content-block structure expected by chat-completion APIs (e.g., OpenAI's multimodal message format).
- **Serializing/deserializing** the content so it can be embedded in prompts and parsed back out of LM responses.

These types are the building blocks that the [adapters_core](adapters_core.md) module (e.g., `ChatAdapter`, `JSONAdapter`) relies on when it formats user messages and parses LM outputs. Whenever a signature field is annotated with one of these types, the adapter detects it and produces the appropriate multimodal content blocks.

## Architecture

The module is organized around a single abstract base class, `Type`, from which all concrete custom types inherit. The base class defines the contract (`format()`, `description()`, serialization markers) and provides shared utilities for detecting and splitting custom-type content inside messages.

```mermaid
classDiagram
    class Type {
        <<abstract>>
        +format() list~dict~ | str
        +description() str
        +extract_custom_type_from_annotation(annotation)
        +serialize_model()
    }
    class Image {
        +url: str
        +format()
        +from_url()
        +from_file()
        +from_PIL()
    }
    class Audio {
        +data: str
        +audio_format: str
        +format()
        +from_url()
        +from_file()
        +from_array()
    }
    class Code {
        +code: str
        +language: ClassVar~str~
        +format()
        +description()
    }
    class Tool {
        +func: Callable
        +name: str
        +desc: str
        +args: dict
        +format_as_litellm_function_call()
        +__call__()
        +acall()
        +from_mcp_tool()
        +from_langchain()
    }
    class ToolCalls {
        +tool_calls: list~ToolCall~
        +from_dict_list()
        +format()
    }
    class History {
        +messages: list~dict~
    }

    Type <|-- Image
    Type <|-- Audio
    Type <|-- Code
    Type <|-- Tool
    Type <|-- ToolCalls
    ToolCalls *-- ToolCall
    History ..> Type : standalone pydantic model
```

### Position in the broader system

The custom types sit between user-facing DSPy signatures and the low-level LM clients. The adapter layer inspects signature field annotations, and when a custom type is found, it invokes the type's `format()` method to produce content blocks.

```mermaid
flowchart LR
    Sig["dspy.Signature<br/>(fields annotated with custom types)"]
    Adapter["adapters_core<br/>(ChatAdapter / JSONAdapter)"]
    Types["adapter_types<br/>(Image, Audio, Code, Tool, ToolCalls, History)"]
    LM["clients<br/>(LM / BaseLM)"]

    Sig --> Adapter
    Adapter -- "format() / serialize_model()" --> Types
    Types -- "content blocks" --> Adapter
    Adapter -- "messages" --> LM
    LM -- "raw response" --> Adapter
    Adapter -- "parse()" --> Sig
```

## Core Concepts

### The `Type` base class

`Type` (in `base_type.py`) is a Pydantic `BaseModel` that all custom types inherit from. Its key responsibilities:

- **`format()`** — returns either a list of content-block dictionaries (matching the OpenAI multimodal content-part schema) or a plain string. Subclasses must implement this.
- **`description()`** — returns a human-readable description used by adapters when describing fields to the LM.
- **`serialize_model()`** — a Pydantic model serializer that wraps the formatted output between the reserved markers `<<CUSTOM-TYPE-START-IDENTIFIER>>` and `<<CUSTOM-TYPE-END-IDENTIFIER>>`. This allows the adapter to later locate and split custom-type content out of a flattened string.
- **`extract_custom_type_from_annotation()`** — recursively walks a (possibly nested) type annotation to find all custom types, e.g. detecting `Tool` inside `list[dict[str, Tool]]`.

The module also exposes `split_message_content_for_custom_types()`, which scans user messages for the reserved markers and splits the string content into a list of content blocks (text + multimodal parts). This is what enables `dspy.Image` and friends to be rendered as proper multimodal messages.

### Serialization markers

```mermaid
sequenceDiagram
    participant User as User code
    participant Type as Custom Type
    participant Adapter as Adapter
    participant LM as LM

    User->>Type: create Image(url=...)
    Type->>Type: serialize_model() wraps format() in markers
    Adapter->>Adapter: build user message string
    Adapter->>Adapter: split_message_content_for_custom_types()
    Note over Adapter: markers replaced by content blocks
    Adapter->>LM: messages with multimodal content
```

## Sub-modules

The module is split into the following documented sub-modules:

| Sub-module | Description | Documentation |
| --- | --- | --- |
| **Base Type** | The abstract `Type` base class and the custom-type splitting utilities. | [adapter_types_base_type.md](adapter_types_base_type.md) |
| **Media Types** | `Image` and `Audio` — multimodal content types with encoding helpers. | [adapter_types_media.md](adapter_types_media.md) |
| **Code Type** | `Code` — code generation/analysis type with markdown extraction and language parameterization. | [adapter_types_code.md](adapter_types_code.md) |
| **Tool Types** | `Tool` and `ToolCalls` — function-calling support, schema inference, and invocation. | [adapter_types_tool.md](adapter_types_tool.md) |
| **History Type** | `History` — conversation history container. | [adapter_types_history.md](adapter_types_history.md) |

## How the Types Integrate with Adapters

The adapter layer (`adapters_core`) uses these types in several ways:

1. **Field description** — `Type.description()` is used to describe custom-typed fields to the LM.
2. **Message formatting** — `Type.format()` output is embedded into user messages and later split into content blocks via `split_message_content_for_custom_types()`.
3. **Tool calling** — `Tool.format_as_litellm_function_call()` produces the tool schema passed to the LM, and `ToolCalls` is used as the output field type to capture tool-call results. See [adapters_core.md](adapters_core.md) for the `_call_preprocess` / `_call_postprocess` logic that wires this up.
4. **Conversation history** — `History` is detected by the adapter's `_get_history_field_name()` and expanded into multiturn messages.

```mermaid
flowchart TD
    subgraph adapter_types
        T[Type]
        IMG[Image]
        AUD[Audio]
        CODE[Code]
        TOOL[Tool]
        TC[ToolCalls]
        HIST[History]
    end
    subgraph adapters_core
        CA[ChatAdapter]
        JA[JSONAdapter]
    end
    CA -->|format_field_value| T
    CA -->|_get_history_field_name| HIST
    CA -->|_get_tool_call_*_field_name| TOOL
    CA -->|_get_tool_call_output_field_name| TC
    JA -->|structured outputs| T
```

## Related Modules

- [adapters_core.md](adapters_core.md) — The adapter implementations that consume these types.
- [clients.md](clients.md) — The LM clients that receive the formatted messages.
- [signatures.md](signatures.md) — Signatures whose fields are annotated with these custom types.
- [utils.md](utils.md) — Shared utilities such as `AdapterParseError` and callbacks.
