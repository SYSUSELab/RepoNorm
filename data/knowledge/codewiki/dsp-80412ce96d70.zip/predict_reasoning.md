# Predict Reasoning Module

## Introduction

The `predict_reasoning` module provides DSPy's **reasoning-oriented prediction strategies** — modules that augment a base task signature with explicit intermediate reasoning steps before producing a final answer. Unlike the plain [`Predict`](predict_core.md) primitive, which maps inputs directly to outputs, these modules deliberately elicit, structure, and (in some cases) verify intermediate reasoning to improve accuracy on complex tasks.

The module contains three core components:

| Component | File | Purpose |
|-----------|------|---------|
| `ChainOfThought` | `dspy/predict/chain_of_thought.py` | Adds a single step-by-step reasoning field before the output. |
| `ProgramOfThought` | `dspy/predict/program_of_thought.py` | Generates, executes, and iteratively repairs Python code to compute the answer. |
| `MultiChainComparison` | `dspy/predict/multi_chain_comparison.py` | Aggregates multiple reasoning attempts into a single corrected rationale and answer. |

All three are built on top of the [`Module`](primitives.md) base class and ultimately delegate to one or more [`Predict`](predict_core.md) instances. They are the building blocks used by higher-level agent modules such as [`ReAct`](predict_agents.md) and [`CodeAct`](predict_agents.md).

---

## Architecture Overview

The reasoning modules form a thin orchestration layer between the user-facing task signature and the underlying `Predict` primitive. Each module transforms the signature (or the inputs) and then invokes `Predict`.

```mermaid
graph TD
    subgraph "predict_reasoning"
        CoT[ChainOfThought]
        PoT[ProgramOfThought]
        MCC[MultiChainComparison]
    end

    subgraph "predict_core"
        Predict[Predict]
        Parameter[Parameter]
    end

    subgraph "primitives"
        Module[Module]
        Signature[Signature]
        PythonInterpreter[PythonInterpreter]
        Prediction[Prediction]
    end

    subgraph "signatures"
        OutputField[OutputField]
        InputField[InputField]
    end

    CoT -->|extends| Module
    PoT -->|extends| Module
    MCC -->|extends| Module

    CoT -->|wraps| Predict
    PoT -->|wraps 3x| Predict
    MCC -->|wraps| Predict

    CoT -->|prepends reasoning field| Signature
    PoT -->|builds generate/regenerate/answer signatures| Signature
    MCC -->|appends reasoning_attempt fields| Signature

    PoT -->|executes code| PythonInterpreter
    Predict -->|produces| Prediction
    Signature -->|uses| OutputField
    Signature -->|uses| InputField
```

### Key Design Principle

Every reasoning module follows the same pattern:

1. **Transform the signature** — inject reasoning-related input/output fields.
2. **Delegate to `Predict`** — the actual LM call is always performed by a `Predict` instance.
3. **Post-process** — combine or interpret the raw predictions into the final result.

This keeps the reasoning logic decoupled from the LM invocation machinery (adapters, caching, streaming), which lives entirely in [`Predict`](predict_core.md) and the [adapters](adapters.md) module.

---

## Component Details

### ChainOfThought

`ChainOfThought` is the simplest reasoning strategy. It implements the classic "Let's think step by step" prompt by prepending a `reasoning` output field to the user's signature.

**Construction flow:**

```mermaid
sequenceDiagram
    participant User
    participant CoT as ChainOfThought
    participant Sig as Signature
    participant Pred as Predict

    User->>CoT: __init__(signature, rationale_field, rationale_field_type)
    CoT->>Sig: ensure_signature(signature)
    CoT->>CoT: build rationale_field (default: OutputField "Reasoning: Let's think step by step in order to ${reasoning}")
    CoT->>Sig: prepend("reasoning", rationale_field, type_)
    CoT->>Pred: Predict(extended_signature, **config)
    Note over CoT: self.predict = Predict(...)
```

**Key behaviors:**

- The `rationale_field` defaults to an `OutputField` with prefix `"Reasoning: Let's think step by step in order to"` and description `"${reasoning}"`.
- The field type defaults to `str` but can be overridden via `rationale_field_type` or by passing a `FieldInfo` whose `annotation` is used.
- `forward(**kwargs)` simply delegates to `self.predict(**kwargs)`.
- `aforward(**kwargs)` delegates to `self.predict.acall(**kwargs)` for async execution.

Because `ChainOfThought` is itself a `Module`, it participates in the standard module lifecycle (callbacks, usage tracking, history) inherited from [`Module`](primitives.md).

---

### ProgramOfThought

`ProgramOfThought` (PoT) solves a task by generating Python code, executing it in a sandboxed interpreter, and iteratively repairing the code on failure. It is the most complex of the three reasoning modules.

**Prerequisites:** Requires [Deno](https://docs.deno.com/runtime/getting_started/installation/) to be installed, since code execution is sandboxed via [`PythonInterpreter`](primitives.md).

**Internal sub-modules:** PoT composes **three** `ChainOfThought` instances, each with a dynamically generated signature:

| Sub-module | Mode | Role |
|------------|------|------|
| `code_generate` | `generate` | Produce initial Python code from the task inputs. |
| `code_regenerate` | `regenerate` | Repair code given the previous code and its error. |
| `generate_answer` | `answer` | Convert the final code + its output into the task's output fields. |

**Signature generation:** The `_generate_signature(mode)` method builds a signature by combining the original task input fields with mode-specific fields:

- **generate**: adds `generated_code` (OutputField, prefix `"Code:"`).
- **regenerate**: adds `previous_code` (InputField), `error` (InputField), and `generated_code` (OutputField).
- **answer**: adds `final_generated_code` (InputField), `code_output` (InputField), plus the original task output fields.

The `_generate_instruction(mode)` method produces natural-language instructions tailored to each mode, including the requirement to call the preloaded `final_answer()` function and return a dict mapping output field names to values.

**Execution flow:**

```mermaid
flowchart TD
    Start([forward kwargs]) --> Extract[Extract input fields]
    Extract --> Gen[code_generate: produce code]
    Gen --> Parse[_parse_code]
    Parse --> ParseErr{Parse error?}
    ParseErr -->|No| Exec[_execute_code via PythonInterpreter]
    ParseErr -->|Yes| Retry
    Exec --> ExecErr{Execution error?}
    ExecErr -->|No| Answer
    ExecErr -->|Yes| Retry

    Retry{hop == max_iters?}
    Retry -->|Yes| Fail[shutdown interpreter + raise RuntimeError]
    Retry -->|No| Regen[code_regenerate with previous_code + error]
    Regen --> Parse

    Answer[generate_answer with final code + output] --> Shutdown[interpreter.shutdown]
    Shutdown --> Return([return answer])
```

**Code parsing (`_parse_code`):** Extracts the Python code block from the LM response, handling markdown fences (```` ```python ````), stripping trailing content after `---` or triple newlines, and repairing common formatting issues (e.g., multiple assignments on one line, missing final expression).

**Code execution (`_execute_code`):** Serializes the interpreter output to JSON. Returns `(output, None)` on success or `(None, error_string)` on failure.

**Retry loop:** The `forward` method retries up to `max_iters` (default `3`) times. On each failure it updates the input kwargs with `previous_code` and `error`, then calls `code_regenerate`. If `max_iters` is reached, the interpreter is shut down and a `RuntimeError` is raised.

**Resource management:** The `PythonInterpreter` is shut down both on success (after `generate_answer`) and on failure (before raising), ensuring the Deno subprocess is cleaned up.

---

### MultiChainComparison

`MultiChainComparison` (MCC) implements the "multi-chain comparison" strategy: it takes `M` independent reasoning attempts (typically produced by sampling the same task multiple times) and asks the LM to holistically compare them and produce a single corrected rationale and answer.

**Construction flow:**

```mermaid
sequenceDiagram
    participant User
    participant MCC as MultiChainComparison
    participant Sig as Signature
    participant Pred as Predict

    User->>MCC: __init__(signature, M=3, temperature=0.7)
    MCC->>Sig: ensure_signature(signature)
    MCC->>MCC: capture last_key = last output field name
    loop idx in range(M)
        MCC->>Sig: append("reasoning_attempt_{idx+1}", InputField)
    end
    MCC->>Sig: prepend("rationale", OutputField)
    MCC->>Pred: Predict(signature, temperature=0.7)
```

**Key behaviors:**

- The last output field name is captured as `self.last_key` — this is the field whose value is treated as the "answer" in each attempt.
- For each of the `M` attempts, an input field `reasoning_attempt_{idx+1}` is appended with prefix `"Student Attempt #{idx+1}:"`.
- A `rationale` output field is prepended with prefix `"Accurate Reasoning: Thank you everyone. Let's now holistically"`.
- The default `temperature=0.7` encourages diverse reasoning during comparison.

**Forward flow:**

```mermaid
flowchart LR
    Completions[completions: list of M predictions] --> Extract[For each completion:]
    Extract --> R[Extract rationale: c.rationale or c.reasoning, first line]
    Extract --> A[Extract answer: c last_key, first line]
    R --> Format[Format: «I'm trying to {rationale} I'm not sure but my prediction is {answer}»]
    A --> Format
    Format --> Assert{len attempts == M?}
    Assert -->|No| Error[AssertionError]
    Assert -->|Yes| Build[Build kwargs with reasoning_attempt_N fields]
    Build --> Predict[Predict forward]
    Predict --> Result([corrected rationale + answer])
```

**Input contract:** `forward(completions, **kwargs)` expects `completions` to be a list of exactly `M` predictions. Each prediction must contain either a `rationale` or `reasoning` field, plus the field named by `last_key`. An `AssertionError` is raised if the number of attempts does not match `M`.

---

## Component Interaction

The following diagram shows how the three reasoning modules relate to each other and to the broader DSPy ecosystem.

```mermaid
graph TB
    subgraph "User-facing reasoning modules"
        CoT[ChainOfThought]
        PoT[ProgramOfThought]
        MCC[MultiChainComparison]
    end

    subgraph "Agent modules (predict_agents)"
        ReAct[ReAct]
        CodeAct[CodeAct]
    end

    subgraph "Core prediction"
        Predict[Predict]
    end

    subgraph "Execution & sandbox"
        Interp[PythonInterpreter]
    end

    subgraph "Optimization (teleprompt)"
        Bootstrap[BootstrapFewShot]
        MIPRO[MIPROv2]
    end

    ReAct -.uses.-> CoT
    CodeAct -.uses.-> CoT
    PoT -->|composes 3x| CoT
    CoT --> Predict
    MCC --> Predict
    PoT --> Predict
    PoT --> Interp
    Bootstrap -.optimizes.-> CoT
    MIPRO -.optimizes.-> CoT
```

**Notable relationships:**

- **PoT → CoT**: `ProgramOfThought` internally composes three `ChainOfThought` instances, making `ChainOfThought` a direct dependency.
- **Agents → CoT**: Higher-level agent modules (`ReAct`, `CodeAct`) build on `ChainOfThought` for their reasoning steps. See [predict_agents.md](predict_agents.md).
- **Optimizers → reasoning modules**: Teleprompters such as `BootstrapFewShot` and `MIPROv2` can optimize the instructions and demonstrations of these modules since they expose `Predict` sub-modules via `named_predictors()`. See [teleprompt.md](teleprompt.md).

---

## Data Flow

The end-to-end data flow for a reasoning module call is shown below. All three modules share the same outer pipeline; only the internal transformation differs.

```mermaid
flowchart TD
    Input[User inputs: kwargs] --> ModuleCall[Module.__call__]
    ModuleCall --> Forward[forward / aforward]
    Forward --> Transform{Module type}

    Transform -->|ChainOfThought| CoT_T[Prepend reasoning field to signature]
    Transform -->|ProgramOfThought| PoT_T[Generate code → execute → repair → answer]
    Transform -->|MultiChainComparison| MCC_T[Format M attempts → compare]

    CoT_T --> PredictCall[Predict.forward]
    PoT_T --> PredictCall
    MCC_T --> PredictCall

    PredictCall --> Adapter[Adapter formats prompt]
    Adapter --> LM[LM generates completions]
    LM --> Parse[Adapter parses completions]
    Parse --> Prediction[Prediction object]
    Prediction --> Output[Return to caller]
```

**Shared infrastructure:** The `Predict` primitive handles LM selection, adapter selection, streaming, caching, and usage tracking. Reasoning modules do not reimplement any of this — they only shape the signature and inputs. For details, see [predict_core.md](predict_core.md) and [adapters.md](adapters.md).

---

## Process Flow: Choosing a Reasoning Strategy

```mermaid
flowchart TD
    Task[Complex task] --> Q1{Requires computation<br/>or algorithmic steps?}
    Q1 -->|Yes| PoT[Use ProgramOfThought]
    Q1 -->|No| Q2{Need higher accuracy<br/>via multiple samples?}
    Q2 -->|Yes| MCC[Use MultiChainComparison]
    Q2 -->|No| CoT[Use ChainOfThought]

    PoT --> Note1[Requires Deno installed]
    MCC --> Note2[Requires M completions as input]
    CoT --> Note3[Simplest, lowest overhead]
```

---

## Dependencies

| Dependency | Used By | Purpose |
|------------|---------|---------|
| [`Module`](primitives.md) | All three | Base class providing callbacks, history, usage tracking. |
| [`Predict`](predict_core.md) | All three | Underlying LM invocation primitive. |
| [`Signature`](signatures.md) | All three | Field manipulation (`prepend`, `append`, `insert`). |
| [`OutputField` / `InputField`](signatures.md) | All three | Defining reasoning-related fields. |
| [`PythonInterpreter`](primitives.md) | `ProgramOfThought` | Sandboxed code execution via Deno/Pyodide. |
| [`Prediction`](primitives.md) | `MultiChainComparison` | Consuming prior predictions as input. |

---

## Usage Examples

### ChainOfThought

```python
import dspy

lm = dspy.LM("openai/gpt-4o-mini")
dspy.configure(lm=lm)

cot = dspy.ChainOfThought("question -> answer")
result = cot(question="What is the capital of France?")
print(result.reasoning)  # step-by-step reasoning
print(result.answer)     # final answer
```

### ProgramOfThought

```python
import dspy

lm = dspy.LM("openai/gpt-4o-mini")
dspy.configure(lm=lm)

pot = dspy.ProgramOfThought("question -> answer")
result = pot(question="What is 1 + 1?")
print(result.answer)
```

### MultiChainComparison

```python
import dspy

lm = dspy.LM("openai/gpt-4o-mini", temperature=0.7, n=3)
dspy.configure(lm=lm)

# Generate M=3 attempts, then compare them
cot = dspy.ChainOfThought("question -> answer")
completions = [cot(question="...") for _ in range(3)]

mcc = dspy.MultiChainComparison("question -> answer", M=3)
result = mcc(completions=completions, question="...")
print(result.rationale)
print(result.answer)
```

---

## Related Modules

- [predict_core.md](predict_core.md) — The `Predict` primitive and `Parameter` base class.
- [predict_agents.md](predict_agents.md) — `ReAct` and `CodeAct`, which build on reasoning modules.
- [predict_execution.md](predict_execution.md) — `Parallel`, `BestOfN`, `Refine`, `KNN` for execution strategies.
- [primitives.md](primitives.md) — `Module`, `Signature`, `Prediction`, `PythonInterpreter`.
- [signatures.md](signatures.md) — `Signature`, `InputField`, `OutputField`.
- [adapters.md](adapters.md) — Prompt formatting and completion parsing.
- [teleprompt.md](teleprompt.md) — Optimizers that tune reasoning module instructions and demos.
