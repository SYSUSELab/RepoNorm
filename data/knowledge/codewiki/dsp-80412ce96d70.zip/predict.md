# Predict Module

## Overview

The `predict` module is the **execution core** of DSPy. It contains the building blocks that turn declarative `Signature` definitions into runnable programs that call language models (LMs), execute tools, run code, and orchestrate multi-step reasoning. Every DSPy program ultimately bottoms out in a `Predict` instance, and the higher-level modules in this package (`ChainOfThought`, `ReAct`, `ProgramOfThought`, `CodeAct`, etc.) are compositions built on top of it.

The module provides three broad categories of functionality:

1. **The base predictor** — `Predict`, the atomic unit that maps a signature to an LM call via an adapter.
2. **Reasoning / agentic strategies** — modules that wrap one or more `Predict` instances to implement well-known prompting and agent patterns.
3. **Execution utilities** — helpers for running modules in parallel, sampling multiple candidates, and refining outputs against a reward function.

## Architecture

```mermaid
graph TD
    subgraph "Predict Module"
        Predict["Predict<br/>(base predictor)"]
        CoT["ChainOfThought"]
        PoT["ProgramOfThought"]
        ReAct["ReAct"]
        CodeAct["CodeAct"]
        MCC["MultiChainComparison"]
        BoN["BestOfN"]
        Refine["Refine"]
        Parallel["Parallel"]
        KNN["KNN"]
        Parameter["Parameter"]
    end

    subgraph "Dependencies"
        Signature["signatures.Signature"]
        Adapter["adapters.Adapter<br/>(ChatAdapter, JSONAdapter, ...)"]
        LM["clients.LM / BaseLM"]
        Module["primitives.Module"]
        Prediction["primitives.Prediction"]
        Tool["adapters.types.Tool"]
        Interpreter["primitives.PythonInterpreter"]
        ParallelExec["utils.ParallelExecutor"]
        Embedder["clients.Embedder"]
    end

    CoT --> Predict
    PoT --> CoT
    PoT --> Interpreter
    ReAct --> Predict
    ReAct --> Tool
    CodeAct --> ReAct
    CodeAct --> PoT
    MCC --> Predict
    BoN --> Module
    Refine --> Predict
    Parallel --> ParallelExec
    KNN --> Embedder

    Predict --> Signature
    Predict --> Adapter
    Predict --> LM
    Predict --> Prediction
    Predict -.inherits.-> Module
    CoT -.inherits.-> Module
    ReAct -.inherits.-> Module
    PoT -.inherits.-> Module
    CodeAct -.inherits.-> Module
    MCC -.inherits.-> Module
    BoN -.inherits.-> Module
    Refine -.inherits.-> Module
```

## Core Concepts

### The `Predict` primitive

`Predict` is the fundamental unit of computation. It binds a `Signature` (the declarative I/O contract) to an LM through an `Adapter` (which formats the prompt and parses the response). All other modules in this package either wrap `Predict` or compose multiple `Predict` instances. See [predict_core](predict_core.md) for details.

### Reasoning strategies

The module implements several canonical prompting/agent patterns as reusable `Module` subclasses:

- **`ChainOfThought`** — injects a `reasoning` field before the outputs to elicit step-by-step thinking.
- **`ProgramOfThought`** — generates and executes Python code to compute the answer.
- **`ReAct`** — interleaves reasoning with tool calls in an iterative loop.
- **`CodeAct`** — a hybrid of `ReAct` and `ProgramOfThought` that acts by writing executable code.
- **`MultiChainComparison`** — aggregates several reasoning attempts into a single corrected answer.

See [predict_reasoning](predict_reasoning.md) for details.

### Agentic / tool-using modules

`ReAct` and `CodeAct` form the tool-using agent layer, relying on `dspy.Tool` and the sandboxed `PythonInterpreter`. See [predict_agents](predict_agents.md).

### Execution utilities

- **`Parallel`** — runs a module over many examples concurrently using `ParallelExecutor`.
- **`BestOfN`** — samples up to `N` candidates at varying temperatures and returns the best by reward.
- **`Refine`** — like `BestOfN`, but generates natural-language feedback to improve subsequent attempts.
- **`KNN`** — a k-nearest-neighbor retriever over a training set using an `Embedder`.

See [predict_execution](predict_execution.md) for details.

## Sub-modules

| Sub-module | Description | Documentation |
| --- | --- | --- |
| Core Predictor | The `Predict` primitive and the `Parameter` marker class | [predict_core](predict_core.md) |
| Reasoning Strategies | `ChainOfThought`, `ProgramOfThought`, `MultiChainComparison` | [predict_reasoning](predict_reasoning.md) |
| Agentic Modules | `ReAct`, `CodeAct` and their tool/interpreter integration | [predict_agents](predict_agents.md) |
| Execution Utilities | `Parallel`, `BestOfN`, `Refine`, `KNN` | [predict_execution](predict_execution.md) |

## How the Module Fits into DSPy

```mermaid
graph LR
    User["User Program"] --> Modules["predict.* Modules"]
    Modules --> Predict["Predict"]
    Predict --> Adapter["adapters.*"]
    Adapter --> LM["clients.LM"]
    LM --> Provider["clients.providers.*"]
    Modules --> Signatures["signatures.Signature"]
    Modules --> Primitives["primitives.*"]
    Teleprompt["teleprompt.*"] -.optimizes.-> Modules
    Evaluate["evaluate.*"] -.scores.-> Modules
```

- **Upstream**: `signatures` define the I/O contract; `adapters` translate signatures into LM prompts; `clients` provide the LM backends.
- **Downstream**: `teleprompt` optimizers (e.g. `BootstrapFewShot`, `MIPROv2`) tune the demos and instructions of `Predict` instances inside these modules; `evaluate` scores their outputs.
- **Shared primitives**: all modules inherit from `primitives.Module` and return `primitives.Prediction` objects.

## Key Design Notes

- **Composition over inheritance**: most strategies are thin wrappers that delegate to one or more `Predict` instances, making them easy to optimize and introspect via `named_predictors()`.
- **Async support**: `Predict`, `ChainOfThought`, and `ReAct` provide `aforward`/`acall` variants for asynchronous execution.
- **State serialization**: `Predict.dump_state()` / `load_state()` enable saving and restoring compiled programs.
- **Reward-driven sampling**: `BestOfN` and `Refine` share the same `(module, N, reward_fn, threshold, fail_count)` interface, differing only in whether they generate feedback between attempts.
