# Teleprompt Meta Module

## Introduction

The **Teleprompt Meta** module provides a collection of *meta-optimizers* for DSPy programs. Unlike the base optimizers that tune a single dimension of a program (prompts, demonstrations, or model weights), the meta-optimizers in this module orchestrate **multiple optimization strategies** or **combine multiple programs** to produce a stronger, more robust compiled program.

The module contains three core components:

| Component | File | Purpose |
|-----------|------|---------|
| `Ensemble` | `dspy/teleprompt/ensemble.py` | Combines the outputs of several programs into a single aggregated prediction. |
| `BetterTogether` | `dspy/teleprompt/bettertogether.py` | Alternates between prompt optimization and weight (fine-tuning) optimization in a configurable strategy. |
| `AvatarOptimizer` | `dspy/teleprompt/avatar_optimizer.py` | Iteratively refines the instruction of an `Avatar` agent using feedback derived from positive/negative examples. |

All three components inherit from the shared [`Teleprompter`](teleprompt_core.md) base class and follow the common `compile(...)` contract.

---

## Architecture Overview

The meta-optimizers sit *above* the standard optimizers and predictors. They consume programs (and, in the case of `BetterTogether`, other teleprompters) and produce a compiled program.

```mermaid
graph TD
    subgraph "Teleprompt Meta Module"
        Ensemble[Ensemble]
        BetterTogether[BetterTogether]
        AvatarOptimizer[AvatarOptimizer]
    end

    subgraph "Base Abstraction"
        Teleprompter[Teleprompter]
    end

    subgraph "Composed Optimizers"
        BFRS[BootstrapFewShotWithRandomSearch]
        BFT[BootstrapFinetune]
    end

    subgraph "Programs & Predictors"
        Module[Module]
        Avatar[Avatar]
        Predict[Predict / TypedPredictor]
    end

    Ensemble --> Teleprompter
    BetterTogether --> Teleprompter
    AvatarOptimizer --> Teleprompter

    BetterTogether --> BFRS
    BetterTogether --> BFT
    AvatarOptimizer --> Avatar
    Avatar --> Predict
    Ensemble --> Module
```

### Component Relationships

```mermaid
graph LR
    subgraph "Ensemble"
        E[Ensemble.compile] --> EP[EnsembledProgram]
        EP -->|random.sample| P1[Program 1]
        EP -->|random.sample| P2[Program 2]
        EP -->|random.sample| PN[Program N]
        EP -->|reduce_fn| R[dspy.majority / custom]
    end
```

---

## Component Details

### 1. `Ensemble`

`Ensemble` is the simplest meta-optimizer. It wraps a list of already-compiled programs into a single `EnsembledProgram` that runs each member program and aggregates their outputs.

**Key behavior:**

- On each `forward` call, it optionally samples a subset of programs (`size`) at random.
- It executes every selected program with the same inputs.
- If a `reduce_fn` is provided (a common choice is `dspy.majority`), the outputs are reduced into a single prediction; otherwise the raw list of outputs is returned.

```python
class Ensemble(Teleprompter):
    def __init__(self, *, reduce_fn=None, size=None, deterministic=False):
        ...
    def compile(self, programs):
        ...
        return EnsembledProgram()
```

**Parameters:**

| Parameter | Description |
|-----------|-------------|
| `reduce_fn` | Function that aggregates a list of outputs into one (e.g. `dspy.majority`). |
| `size` | Number of programs to sample per call. If `None`, all programs are used. |
| `deterministic` | Reserved for future deterministic hashing; currently must be `False`. |

> **Note:** The `EnsembledProgram` does not currently mirror the structure of its member programs. This means it cannot yet be used as a singular teacher for further compilation. See the TODO in the source.

---

### 2. `BetterTogether`

`BetterTogether` is an **experimental** meta-optimizer that interleaves prompt optimization (`p`) and weight optimization (`w`) according to a user-supplied strategy string (e.g. `"p -> w -> p"`).

**Requirements:**

- `dspy.settings.experimental` must be set to `True`.
- The prompt optimizer must be a `BootstrapFewShotWithRandomSearch` instance.
- The weight optimizer must be a `BootstrapFinetune` instance.

**Parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `metric` | required | Metric used to filter training data and evaluate candidates. |
| `prompt_optimizer` | `BootstrapFewShotWithRandomSearch(metric)` | Optimizer used for `p` steps. |
| `weight_optimizer` | `BootstrapFinetune(metric)` | Optimizer used for `w` steps. |
| `seed` | `None` | Seed for the internal RNG used to shuffle the trainset. |

**Compilation flow:**

```mermaid
flowchart TD
    Start([compile student, trainset, strategy]) --> Validate[Validate strategy string]
    Validate --> Prep[prepare_student + all_predictors_have_lms]
    Prep --> Loop{For each step in strategy}
    Loop -->|p| Prompt[Compile prompt optimizer]
    Loop -->|w| Weight[Compile weight optimizer]
    Prompt --> Record[Record candidate program]
    Weight --> Record
    Record --> Loop
    Loop -->|done| Kill[kill_lms if still launched]
    Kill --> Return([Return student with candidate_programs])
```

**Strategy execution details:**

- The strategy string is split on `" -> "` and each token must be `p` or `w`.
- The trainset is shuffled before each step using the seeded RNG.
- LMs are launched lazily (`launch_lms`) before the first step and killed (`kill_lms`) after a weight step or at the end.
- For prompt steps, a validation set is carved out of the trainset (`valset_ratio`), and `hint` inputs are dropped.
- For weight steps, the original LMs are saved and their `train_kwargs` are transferred to the newly fine-tuned LMs.
- All intermediate programs are recorded in `student.candidate_programs` as `(strategy, program)` tuples.

> **Note:** `BetterTogether` depends on helper functions (`prepare_student`, `launch_lms`, `kill_lms`, `all_predictors_have_lms`) from the [weight optimization module](teleprompt_weight.md).

---

### 3. `AvatarOptimizer`

`AvatarOptimizer` optimizes the **instruction** of an [`Avatar`](predict_avatar.md) agent. It evaluates the agent on a training set, separates examples into positive and negative buckets based on a metric, and uses two signatures to generate improved instructions.

**Supporting signatures:**

- `Comparator` — analyzes positive vs. negative inputs and produces feedback about tool usage.
- `FeedbackBasedInstruction` — incorporates feedback into a new instruction while retaining general guidelines from the previous instruction.

**Supporting model:**

- `EvalResult` — a Pydantic model capturing an example, its score, and the actions taken.

**Parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `metric` | required | Evaluation metric `(example, prediction) -> score`. |
| `max_iters` | `10` | Number of optimization iterations. |
| `lower_bound` | `0` | Scores `<= lower_bound` are treated as negative. |
| `upper_bound` | `1` | Scores `>= upper_bound` are treated as positive. |
| `max_positive_inputs` | `10` | Max positive examples sampled per iteration. |
| `max_negative_inputs` | `10` | Max negative examples sampled per iteration. |
| `optimize_for` | `"max"` | Whether to maximize or minimize the metric. |

**Optimization loop:**

```mermaid
flowchart TD
    Start([compile student, trainset]) --> Init[best_actor = deepcopy student]
    Init --> Iter{For i in max_iters}
    Iter --> Eval[thread_safe_evaluator on trainset]
    Eval --> Split[Split into pos/neg via bounds]
    Split --> Sample[Sample max pos/neg inputs]
    Sample --> Compare[Comparator -> feedback]
    Compare --> NewInstr[FeedbackBasedInstruction -> new_instruction]
    NewInstr --> Better{Score improved?}
    Better -->|yes| Update[Update actor signature + clone]
    Better -->|no| Iter
    Update --> Iter
    Iter -->|done| Return([Return best_actor])
```

**Evaluation:**

- `thread_safe_evaluator` runs `process_example` across a `ThreadPoolExecutor` (using `dspy.settings.num_threads` by default).
- `process_example` deep-copies the actor, runs it on the example inputs, and computes the metric. Exceptions are caught and scored as `0`.
- `_get_pos_neg_results` raises a `ValueError` if either bucket is empty, guiding the user to adjust bounds or provide more data.

> **Note:** `AvatarOptimizer` relies on the [`Avatar`](predict_avatar.md) program and its `ActionOutput` model. The `Avatar` exposes `actor`, `tools`, and `actor_clone` attributes that the optimizer mutates.

---

## Data Flow

The following diagram shows how data flows through the meta-optimizers during compilation.

```mermaid
sequenceDiagram
    participant User
    participant Meta as Meta-Optimizer
    participant Sub as Sub-Optimizer / Program
    participant Eval as Evaluator

    User->>Meta: compile(student, trainset, ...)
    loop Optimization iterations / steps
        Meta->>Sub: compile / forward
        Sub-->>Meta: candidate program / predictions
        Meta->>Eval: evaluate candidate
        Eval-->>Meta: score
        Meta->>Meta: update best candidate
    end
    Meta-->>User: compiled program
```

---

## Dependencies

```mermaid
graph TD
    Ensemble --> Teleprompter
    BetterTogether --> Teleprompter
    BetterTogether --> BootstrapFewShotWithRandomSearch
    BetterTogether --> BootstrapFinetune
    BetterTogether --> Module
    BetterTogether --> Example
    AvatarOptimizer --> Teleprompter
    AvatarOptimizer --> Avatar
    AvatarOptimizer --> ActionOutput
    AvatarOptimizer --> TypedPredictor
    AvatarOptimizer --> Predict
```

| Dependency | Module Documentation |
|------------|----------------------|
| `Teleprompter` | [teleprompt_core.md](teleprompt_core.md) |
| `BootstrapFewShotWithRandomSearch` | [teleprompt_fewshot.md](teleprompt_fewshot.md) |
| `BootstrapFinetune` | [teleprompt_weight.md](teleprompt_weight.md) |
| `Avatar`, `ActionOutput` | [predict_avatar.md](predict_avatar.md) |
| `Module`, `Example` | [primitives_module_system.md](primitives_module_system.md) |
| `TypedPredictor`, `Predict` | [predict_core.md](predict_core.md) |

---

## Usage Examples

### Ensemble

```python
import dspy

ensemble = dspy.Ensemble(reduce_fn=dspy.majority)
compiled = ensemble.compile([program_a, program_b, program_c])
result = compiled(question="What is the capital of France?")
```

### BetterTogether

```python
import dspy

dspy.settings.experimental = True

optimizer = dspy.BetterTogether(metric=my_metric)
compiled = optimizer.compile(
    student=my_program,
    trainset=trainset,
    strategy="p -> w -> p",
    valset_ratio=0.1,
)
```

### AvatarOptimizer

```python
import dspy

optimizer = dspy.AvatarOptimizer(
    metric=my_metric,
    max_iters=5,
    upper_bound=0.8,
    lower_bound=0.2,
)
optimized_actor = optimizer.compile(avatar_program, trainset=trainset)
```

---

## Summary

The **Teleprompt Meta** module provides higher-order optimization strategies:

- **`Ensemble`** aggregates multiple programs for robustness.
- **`BetterTogether`** interleaves prompt and weight optimization for combined gains.
- **`AvatarOptimizer`** refines agent instructions through feedback-driven iteration.

Each component builds on the shared [`Teleprompter`](teleprompt_core.md) abstraction and composes lower-level optimizers and programs, making them powerful tools for advanced DSPy workflows.
