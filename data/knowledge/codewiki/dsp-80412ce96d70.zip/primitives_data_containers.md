# Primitives Data Containers

## Introduction

The **Primitives Data Containers** module provides the fundamental data structures used throughout DSPy to represent inputs, outputs, and model predictions. These containers form the backbone of data exchange between DSPy modules, datasets, optimizers, and evaluation routines.

The module consists of two core components:

- **`Example`** — A flexible, dictionary-like container for holding input/output data pairs (e.g., a question and its answer).
- **`Prediction`** — A specialized subclass of `Example` that represents the output of a DSPy module, with support for multiple completions, LM usage tracking, and score-based arithmetic/comparison operations.

Together, these containers enable DSPy to treat data uniformly across training, evaluation, and inference workflows.

---

## Architecture Overview

The module sits at the lowest layer of the DSPy primitives stack. It is consumed by nearly every other subsystem — datasets, evaluation, prediction modules, and optimizers.

```mermaid
graph TD
    subgraph "primitives_data_containers"
        Example["Example<br/>(dict-like container)"]
        Prediction["Prediction<br/>(extends Example)"]
        Completions["Completions<br/>(multi-completion store)"]
    end

    Prediction -->|inherits| Example
    Prediction -->|holds| Completions

    subgraph "Consumers"
        Dataset["datasets.Dataset"]
        DataLoader["datasets.DataLoader"]
        Evaluate["evaluate.Evaluate"]
        Module["primitives.Module"]
        Predict["predict.Predict"]
        Optimizers["teleprompt.*"]
    end

    Dataset -->|creates| Example
    DataLoader -->|creates| Example
    Evaluate -->|consumes| Example
    Evaluate -->|consumes| Prediction
    Module -->|returns| Prediction
    Predict -->|returns| Prediction
    Optimizers -->|consume| Example
```

---

## Component Relationships

The following diagram shows the inheritance and composition relationships between the core classes.

```mermaid
classDiagram
    class Example {
        +dict _store
        +list _demos
        +set _input_keys
        +__getattr__(key)
        +__setattr__(key, value)
        +__getitem__(key)
        +__setitem__(key, value)
        +keys(include_dspy)
        +values(include_dspy)
        +items(include_dspy)
        +get(key, default)
        +with_inputs(*keys)
        +inputs()
        +labels()
        +copy(**kwargs)
        +without(*keys)
        +toDict()
    }

    class Prediction {
        +Completions _completions
        +dict _lm_usage
        +from_completions(list_or_dict, signature)
        +get_lm_usage()
        +set_lm_usage(value)
        +completions
        +__float__()
        +__add__(other)
        +__lt__(other)
        +__gt__(other)
    }

    class Completions {
        +dict _completions
        +Signature signature
        +items()
        +__getitem__(key)
        +__getattr__(name)
        +__len__()
        +__contains__(key)
    }

    Example <|-- Prediction
    Prediction *-- Completions
```

---

## Example

`Example` is a lightweight, dictionary-like container designed to hold arbitrary key-value data while providing convenient access patterns for DSPy workflows.

### Design Rationale

Unlike a plain `dict`, `Example` supports **attribute-style access** (`example.question` instead of `example["question"]`), which makes DSPy programs more readable. It also distinguishes between **inputs** and **labels**, a distinction critical for training and evaluation.

### Internal Storage

| Attribute | Type | Purpose |
|-----------|------|---------|
| `_store` | `dict` | The underlying key-value data store. |
| `_demos` | `list` | Reserved for demonstration examples (used by optimizers). |
| `_input_keys` | `set` or `None` | The set of keys designated as inputs. |

### Construction

`Example` can be constructed from several sources:

```python
# From keyword arguments
ex = Example(question="What is 2+2?", answer="4")

# From a dict
ex = Example({"question": "What is 2+2?", "answer": "4"})

# From another Example (copies the store)
ex2 = Example(base=ex, extra_field="value")
```

### Attribute vs. Item Access

The class overrides `__getattr__` and `__setattr__` so that non-underscore, non-class attributes are transparently routed to `_store`:

```python
ex.question          # → ex._store["question"]
ex.question = "..."  # → ex._store["question"] = "..."
ex["question"]       # → ex._store["question"]
```

> **Note:** Keys beginning with `dspy_` are treated as internal metadata (e.g., `dspy_uuid`, `dspy_split`) and are excluded from `keys()`, `values()`, `items()`, `__len__`, and `__repr__` unless `include_dspy=True` is passed.

### Input/Label Separation

The `with_inputs()` method returns a **copy** of the example with `_input_keys` set. This enables the crucial input/label split used throughout DSPy:

```python
ex = Example(question="What is 2+2?", answer="4").with_inputs("question")

ex.inputs()   # Example(question="What is 2+2?")
ex.labels()   # Example(answer="4")
```

```mermaid
flowchart LR
    A["Example<br/>question, answer"] -->|with_inputs('question')| B["Example<br/>_input_keys={'question'}"]
    B -->|inputs()| C["Example<br/>question only"]
    B -->|labels()| D["Example<br/>answer only"]
```

### Key Methods

| Method | Description |
|--------|-------------|
| `keys(include_dspy=False)` | Returns non-`dspy_` keys. |
| `values(include_dspy=False)` | Returns non-`dspy_` values. |
| `items(include_dspy=False)` | Returns non-`dspy_` key-value pairs. |
| `get(key, default=None)` | Safe lookup with default. |
| `with_inputs(*keys)` | Returns a copy with input keys set. |
| `inputs()` | Returns a new `Example` containing only input keys. Raises `ValueError` if inputs not set. |
| `labels()` | Returns a new `Example` containing only non-input keys. |
| `copy(**kwargs)` | Returns a copy, optionally overriding fields. |
| `without(*keys)` | Returns a copy with specified keys removed. |
| `toDict()` | Returns a shallow copy of the underlying store. |

### Equality and Hashing

- `__eq__` compares the underlying `_store` dictionaries.
- `__hash__` hashes the tuple of store items, allowing `Example` instances to be used as dict keys or set members.

---

## Prediction

`Prediction` extends `Example` to represent the **output of a DSPy module**. It adds support for multiple completions, LM usage tracking, and score-based numeric operations.

### Additional Attributes

| Attribute | Type | Purpose |
|-----------|------|---------|
| `_completions` | `Completions` or `None` | Holds all candidate completions when multiple are generated. |
| `_lm_usage` | `dict` or `None` | Token usage information for the LM call(s). |

> **Note:** `Prediction.__init__` deletes the inherited `_demos` and `_input_keys` attributes, since predictions are outputs rather than training examples.

### Creating Predictions from Completions

The `from_completions()` classmethod builds a `Prediction` from a list of dicts or a dict of lists, storing the first completion in `_store` and retaining all completions in `_completions`:

```python
pred = Prediction.from_completions(
    [{"answer": "4"}, {"answer": "four"}],
    signature=my_signature,
)
pred.answer          # "4" (first completion)
pred.completions     # Completions object with both answers
```

### Score-Based Operations

When a `Prediction` contains a `score` field, it supports arithmetic and comparison operations that operate on the score value. This is essential for feedback-augmented scoring and optimizers that rank predictions.

```mermaid
flowchart TD
    P["Prediction<br/>score=0.8"] --> F["__float__() → 0.8"]
    F --> CMP["Comparisons: <, <=, >, >="]
    F --> ARITH["Arithmetic: +, /"]
    CMP --> R1["pred > 0.5 → True"]
    ARITH --> R2["pred + 0.2 → 1.0"]
```

| Operation | Behavior |
|-----------|----------|
| `float(pred)` | Returns `float(pred.score)`; raises `ValueError` if no `score` field. |
| `pred + other` / `other + pred` | Adds score to a number or another `Prediction`'s score. |
| `pred / other` / `other / pred` | Divides score by a number or another `Prediction`'s score. |
| `pred < other`, `<=`, `>`, `>=` | Compares scores as floats. |

> **Equality** (`==`) is inherited from `Example` and compares the full underlying data store, not just the score.

### LM Usage Tracking

`get_lm_usage()` and `set_lm_usage()` provide access to token usage metadata. The `Module.__call__` method (see [primitives_module_system.md](primitives_module_system.md)) automatically populates this when usage tracking is enabled.

---

## Completions

`Completions` is a container that holds **multiple candidate completions** for a single prediction. It normalizes both list-of-dicts and dict-of-lists inputs into a consistent dict-of-lists representation.

### Construction

```python
# From a list of dicts
c = Completions([{"answer": "4"}, {"answer": "four"}])
# → {"answer": ["4", "four"]}

# From a dict of lists
c = Completions({"answer": ["4", "four"]})
```

All values must be lists of equal length; this is validated at construction time.

### Access Patterns

| Access | Result |
|--------|--------|
| `c["answer"]` | The full list of values for that key. |
| `c[0]` | A `Prediction` built from the first element of each list. |
| `c.answer` | Attribute-style access to the list. |
| `len(c)` | Number of completions (length of any value list). |
| `"answer" in c` | Membership check on keys. |

```mermaid
flowchart LR
    L["list of dicts"] --> C["Completions"]
    D["dict of lists"] --> C
    C --> K["c['answer'] → list"]
    C --> I["c[0] → Prediction"]
    C --> A["c.answer → list"]
```

---

## Data Flow

The following sequence diagram illustrates how these containers flow through a typical DSPy inference and evaluation cycle.

```mermaid
sequenceDiagram
    participant DS as Dataset
    participant EX as Example
    participant MOD as Module
    participant PRED as Prediction
    participant EV as Evaluate

    DS->>EX: creates Example with dspy_uuid, dspy_split
    EX->>EX: with_inputs(*input_keys)
    EX->>MOD: example.inputs()
    MOD->>PRED: returns Prediction (from LM output)
    PRED->>PRED: set_lm_usage(tokens)
    MOD->>EV: (example, prediction)
    EV->>EV: metric(example, prediction)
    EV->>EV: aggregate scores
```

### Integration Points

| Consumer | How it uses the containers |
|----------|---------------------------|
| [`datasets.Dataset`](datasets_core.md) | Wraps raw data into `Example` objects, tagging them with `dspy_uuid` and `dspy_split`. |
| [`datasets.DataLoader`](datasets_core.md) | Converts HuggingFace/CSV/JSON/pandas data into `Example` lists via `with_inputs()`. |
| [`evaluate.Evaluate`](evaluate_program_evaluation.md) | Iterates over `Example` devsets, calls the program, and scores `Prediction` outputs. |
| [`primitives.Module`](primitives_module_system.md) | Returns `Prediction` objects from `__call__`, attaching LM usage. |
| [`predict.Predict`](predict_core.md) | Produces `Prediction` objects from LM responses. |
| [`teleprompt.*`](teleprompt.md) | Optimizers consume `Example` demos and rank `Prediction` scores. |

---

## Process Flow: From Raw Data to Scored Prediction

```mermaid
flowchart TD
    A["Raw data<br/>(dict / HF dataset / CSV)"] --> B["DataLoader / Dataset"]
    B --> C["Example<br/>with_inputs()"]
    C --> D["Module.__call__"]
    D --> E["Predict → LM"]
    E --> F["Prediction<br/>from_completions()"]
    F --> G{"Multiple<br/>completions?"}
    G -->|Yes| H["Completions<br/>store all"]
    G -->|No| I["Single value in _store"]
    H --> J["Evaluate / Optimizer"]
    I --> J
    J --> K["Score-based<br/>comparison & arithmetic"]
```

---

## Design Considerations

### Why `Example` is dict-like but not a `dict`

`Example` deliberately avoids subclassing `dict` to:
- Support attribute-style access without polluting the namespace.
- Reserve internal attributes (`_store`, `_demos`, `_input_keys`) that don't collide with user data.
- Provide the input/label distinction that plain dicts lack.

### Why `Prediction` extends `Example`

By inheriting from `Example`, `Prediction` can be used anywhere an `Example` is expected (e.g., in metrics and evaluation), while adding output-specific features like completions and score arithmetic. This keeps the API uniform across the framework.

### Metadata Convention

Keys prefixed with `dspy_` (e.g., `dspy_uuid`, `dspy_split`) are treated as framework-internal metadata and hidden from standard iteration and representation. This convention allows DSPy to attach bookkeeping data without interfering with user-visible fields.

---

## Related Modules

- [primitives_module_system.md](primitives_module_system.md) — `Module` and `BaseModule`, which produce `Prediction` objects.
- [primitives_python_interpreter.md](primitives_python_interpreter.md) — The Python interpreter primitive.
- [datasets_core.md](datasets_core.md) — `Dataset` and `DataLoader`, which create `Example` objects.
- [evaluate_program_evaluation.md](evaluate_program_evaluation.md) — `Evaluate`, which consumes `Example` and `Prediction`.
- [predict_core.md](predict_core.md) — `Predict` and `Parameter`, which generate `Prediction` outputs.
