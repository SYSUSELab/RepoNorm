# Adapters Core

## Introduction

The **Adapters Core** module is the translation layer between DSPy's structured, typed programming model and the raw text/message interface exposed by Language Models (LMs). DSPy programs are defined using [`Signature`](signatures.md) classes with typed input and output fields, but LMs only understand strings and chat messages. Adapters bridge this gap by:

1. **Formatting** a `Signature`, its few-shot demonstrations, and the current inputs into a list of chat messages that the LM can consume.
2. **Parsing** the LM's raw text response back into a dictionary of typed output fields.

The module provides a base `Adapter` abstraction and four concrete implementations, each with a different serialization strategy (chat markers, JSON, XML, or a two-stage extraction pipeline). It also integrates with DSPy's custom type system (e.g., `Image`, `Tool`, `History`) and the callback system for observability.

## Architecture Overview

The module is organized around a single abstract base class (`Adapter`) that defines the full call lifecycle, and concrete subclasses that override the formatting and parsing hooks.

```mermaid
graph TD
    Adapter["Adapter (base.py)<br/>abstract base"]
    ChatAdapter["ChatAdapter<br/>(chat_adapter.py)"]
    JSONAdapter["JSONAdapter<br/>(json_adapter.py)"]
    XMLAdapter["XMLAdapter<br/>(xml_adapter.py)"]
    TwoStepAdapter["TwoStepAdapter<br/>(two_step_adapter.py)"]

    Adapter --> ChatAdapter
    Adapter --> TwoStepAdapter
    ChatAdapter --> JSONAdapter
    ChatAdapter --> XMLAdapter

    ChatAdapter -. "fallback on error" .-> JSONAdapter
```

| Adapter | Serialization Strategy | Native Function Calling | Notes |
|---------|------------------------|-------------------------|-------|
| `Adapter` | Abstract | Configurable | Defines the lifecycle; not used directly |
| `ChatAdapter` | `[[ ## field ## ]]` section markers | Optional | Default adapter; falls back to `JSONAdapter` on parse failure |
| `JSONAdapter` | JSON object / Structured Outputs | Default `True` | Subclass of `ChatAdapter`; uses OpenAI structured outputs when supported |
| `XMLAdapter` | `<field>...</field>` tags | Optional | Subclass of `ChatAdapter`; XML-tag based parsing |
| `TwoStepAdapter` | Natural prompt + extraction LM | N/A | Uses a second LM to extract structured data from a reasoning model's output |

## The Adapter Lifecycle

Every adapter inherits the `__call__` / `acall` lifecycle defined in `Adapter`. This lifecycle is the heart of the module and is shared across all implementations.

```mermaid
sequenceDiagram
    participant Caller as Predict / Module
    participant Adapter
    participant LM

    Caller->>Adapter: __call__(lm, lm_kwargs, signature, demos, inputs)
    Note over Adapter: _call_preprocess()
    Adapter->>Adapter: Handle native function calling<br/>(inject tools, strip tool fields)
    Adapter->>Adapter: format(signature, demos, inputs)
    Note over Adapter: Build system + few-shot + user messages
    Adapter->>LM: lm(messages=..., **lm_kwargs)
    LM-->>Adapter: raw outputs (text / tool_calls / logprobs)
    Note over Adapter: _call_postprocess()
    Adapter->>Adapter: parse(signature, text)
    Adapter->>Adapter: Attach tool_calls / logprobs
    Adapter-->>Caller: list[dict[str, Any]]
```

### Key Lifecycle Methods

- **`__call__` / `acall`** — The public entry points. They orchestrate preprocessing, formatting, the LM call, and postprocessing. Both are decorated with `with_callbacks` (via `__init_subclass__`) so that `on_adapter_format_*` and `on_adapter_parse_*` callbacks fire automatically.
- **`_call_preprocess`** — Handles native function calling. When `use_native_function_calling` is enabled and the signature declares a `list[dspy.Tool]` input field plus a `ToolCalls` output field, it converts tools to LiteLLM function-call format, injects them into `lm_kwargs["tools"]`, and returns a signature with the tool fields removed.
- **`format`** — Converts the signature, demos, and inputs into chat messages. See [Formatting Pipeline](#formatting-pipeline).
- **`_call_postprocess`** — Parses each raw LM output via `parse`, fills missing output fields with `None`, and attaches `tool_calls` and `logprobs` when present.

## Formatting Pipeline

The base `format` method assembles messages in a well-defined order. Concrete adapters customize the individual pieces by overriding the `format_*` hooks.

```mermaid
flowchart TD
    Start["format(signature, demos, inputs)"]
    History{"History field<br/>present?"}
    StripHistory["Delete history field<br/>from signature"]
    FormatHistory["format_conversation_history()"]
    System["Build system message:<br/>format_field_description()<br/>format_field_structure()<br/>format_task_description()"]
    Demos["format_demos()"]
    User["format_user_message_content()"]
    Split["split_message_content_for_custom_types()"]
    End["messages list"]

    Start --> History
    History -- yes --> StripHistory --> FormatHistory
    History -- no --> System
    FormatHistory --> System
    System --> Demos --> User --> Split --> End
```

### Overridable Hooks

| Hook | Purpose | Required? |
|------|---------|-----------|
| `format_field_description` | Describe input/output fields in the system message | Yes (abstract) |
| `format_field_structure` | Dictate the serialization format for fields | Yes (abstract) |
| `format_task_description` | Describe the task (usually wraps `signature.instructions`) | Yes (abstract) |
| `format_user_message_content` | Render input fields into a user message | Yes (abstract) |
| `format_assistant_message_content` | Render output fields into an assistant message | Yes (abstract) |
| `format_demos` | Render few-shot examples as multiturn messages | No (base impl) |
| `format_conversation_history` | Render `History` field as multiturn messages | No (base impl) |
| `parse` | Parse LM text into output fields | Yes (abstract) |

The base `format_demos` implementation splits demos into **complete** (all fields present) and **incomplete** (at least one input and one output field) groups, prefixing incomplete demos with a clarifying message.

## Adapter Implementations

### ChatAdapter

The default adapter. It serializes fields using section markers of the form `[[ ## field_name ## ]]` and appends a `[[ ## completed ## ]]` marker to signal the end of output.

- **Formatting**: `format_field_structure` emits the marker schema; `format_user_message_content` wraps each input field in its marker; `user_message_output_requirements` adds a lightweight inline reminder of the expected output format.
- **Parsing**: `parse` scans lines for the `field_header_pattern` regex (`\[\[ ## (\w+) ## \]\]`), collects section content, and casts each value via `parse_value`.
- **Fallback**: On any exception (except `ContextWindowExceededError`), `__call__`/`acall` retry with a `JSONAdapter`. This makes `ChatAdapter` resilient to models that struggle with the marker format.
- **Finetuning**: Implements `format_finetune_data` to produce OpenAI-style `{"messages": [...]}` training data.

### JSONAdapter

A subclass of `ChatAdapter` that prefers JSON serialization and **enables native function calling by default**.

- **Structured Outputs**: `_get_structured_outputs_response_format` builds a Pydantic model from the signature's output fields and enforces OpenAI Structured Outputs compatibility (all properties `required`, `additionalProperties: false`). It recursively patches nested objects, arrays, and `$defs`.
- **Fallback chain**: If the provider does not support `response_format`, or if the signature contains an open-ended mapping (`dict[str, Any]`) or a `ToolCalls` field with native function calling disabled, it falls back to `{"type": "json_object"}` mode. If structured output generation fails, it also falls back to JSON mode.
- **Parsing**: `parse` extracts the first balanced JSON object using a recursive regex, repairs it with `json_repair`, filters to known output fields, and casts values.
- **Note**: `format_finetune_data` is not yet implemented.

### XMLAdapter

A subclass of `ChatAdapter` that uses XML tags (`<field>...</field>`) instead of section markers.

- **Formatting**: `format_field_with_value` wraps each field in `<name>...</name>` tags; `user_message_output_requirements` instructs the model to end with a `<completed>` tag.
- **Parsing**: `parse` uses the regex `<(?P<name>\w+)>(?P<content>.*?)</\1>` to extract fields, then casts values via `parse_value`.

### TwoStepAdapter

A specialized adapter for **reasoning models** (e.g., OpenAI o-series) that struggle with structured output. It decouples generation from extraction:

```mermaid
sequenceDiagram
    participant Program
    participant TwoStep as TwoStepAdapter
    participant MainLM as Main LM (reasoning)
    participant ExtractLM as Extraction LM

    Program->>TwoStep: __call__(...)
    TwoStep->>MainLM: Natural-language prompt
    MainLM-->>TwoStep: Free-form reasoning text
    TwoStep->>TwoStep: _create_extractor_signature()
    TwoStep->>ExtractLM: ChatAdapter(text -> output fields)
    ExtractLM-->>TwoStep: Structured output fields
    TwoStep-->>Program: list[dict[str, Any]]
```

- **Constructor**: Requires an `extraction_model` (an `LM` instance) used for the second stage.
- **Formatting**: Overrides `format` entirely to produce a natural-language prompt (no strict structure) for the main LM.
- **Parsing**: Builds an extractor signature (`text -> {original output fields}`) and invokes a `ChatAdapter` with the extraction model to pull structured data from the free-form text.
- **Limitation**: The extractor signature is created on the fly and invoked with no demonstrations, so it cannot be optimized/learned (noted in the source as a TODO).

## Custom Type Integration

Adapters rely on the [adapters_types](adapters_types.md) module to handle non-primitive field types. The base `format` method calls `split_message_content_for_custom_types` to expand custom types (e.g., `Image`, `Audio`) into multimodal content parts.

Key custom types used by adapters:

- **`History`** — Detected by `_get_history_field_name`; its messages are expanded into multiturn user/assistant pairs via `format_conversation_history`.
- **`Tool` / `ToolCalls`** — Detected by `_get_tool_call_input_field_name` and `_get_tool_call_output_field_name`; drive native function calling in `_call_preprocess` and tool-call attachment in `_call_postprocess`.
- **`Image`, `Audio`, `Code`** — Serialized via their `format()` methods and expanded into content parts.

See [adapters_types](adapters_types.md) for full details on the type system.

## Dependencies

```mermaid
graph LR
    subgraph adapters_core
        Adapter
        ChatAdapter
        JSONAdapter
        XMLAdapter
        TwoStepAdapter
    end

    Adapter --> signatures["signatures<br/>(Signature, SignatureMeta)"]
    Adapter --> adapters_types["adapters_types<br/>(History, Tool, ToolCalls)"]
    Adapter --> callbacks["utils<br/>(BaseCallback, with_callbacks)"]
    Adapter --> lm["clients<br/>(LM)"]
    ChatAdapter --> exceptions["utils<br/>(AdapterParseError)"]
    JSONAdapter --> litellm["litellm / pydantic / json_repair"]
    TwoStepAdapter --> lm
```

| Dependency | Used For |
|------------|----------|
| [`signatures`](signatures.md) | `Signature`, `SignatureMeta`, `make_signature`, `InputField` — the structured contract adapters translate |
| [`adapters_types`](adapters_types.md) | `History`, `Tool`, `ToolCalls`, `Type` — custom field types |
| [`clients`](clients.md) | `LM` — the language model interface adapters call |
| [`utils`](utils.md) | `BaseCallback`, `with_callbacks`, `AdapterParseError` — observability and error reporting |
| `litellm` | Provider capability detection (`supports_function_calling`, `get_supported_openai_params`) |
| `pydantic` | Structured output model generation |
| `json_repair` | Lenient JSON parsing of LM responses |

## Error Handling

All adapters raise `AdapterParseError` (from [utils](utils.md)) when the LM response cannot be parsed into the expected output fields. The error captures the adapter name, signature, raw LM response, and any partially parsed result, producing a detailed diagnostic message.

`ChatAdapter` additionally implements a **graceful degradation** strategy: any parse failure (other than context-window overflow) triggers a retry with `JSONAdapter`, which is generally more robust for models that do not follow the marker format.

## Callback Integration

Adapters are instrumented for observability through the callback system. The `Adapter.__init_subclass__` hook automatically wraps each subclass's `format` and `parse` methods with `with_callbacks`, emitting:

- `on_adapter_format_start` / `on_adapter_format_end`
- `on_adapter_parse_start` / `on_adapter_parse_end`

This allows users to trace exactly how inputs are formatted and how LM responses are parsed. See [utils](utils.md) for the `BaseCallback` interface.

## Summary

The Adapters Core module provides a clean, extensible abstraction for translating between DSPy's typed signatures and LM message interfaces. Its layered design — a shared lifecycle in `Adapter`, a marker-based default in `ChatAdapter`, and specialized variants (`JSONAdapter`, `XMLAdapter`, `TwoStepAdapter`) — lets developers choose the serialization strategy best suited to their model while reusing common formatting, parsing, tool-calling, and observability infrastructure.
