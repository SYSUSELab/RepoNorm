# Utils Logging Module

## Introduction

The `utils_logging` module provides DSPy's centralized event-logging infrastructure. It defines a single, globally-shared logging stream (`DSPyLoggingStream`) that wraps `sys.stderr`, along with helper functions to enable/disable logging and to configure the root DSPy logger. This module is the backbone that allows DSPy to emit diagnostic and progress messages throughout the framework (`eprint()`, `logger.info()`, etc.) while giving users a single switch to silence or restore all such output.

The module is intentionally small and dependency-free (only the Python standard library), making it a low-level utility that other DSPy subsystems rely on for consistent, controllable logging behavior.

---

## Core Components

### `DSPyLoggingStream`

A Python stream-like object designed to be used with event-logging APIs throughout DSPy. It wraps `sys.stderr` and forwards `write()` and `flush()` calls to whatever stream `sys.stderr` currently refers to **at the time of the call** (rather than capturing a reference at construction time). This indirection is important because `sys.stderr` may be replaced at runtime (e.g., by test harnesses, notebooks, or output-capturing tools).

Key characteristics:

| Member | Type | Description |
| --- | --- | --- |
| `_enabled` | `bool` | Internal flag controlling whether writes are forwarded. Defaults to `True`. |
| `write(text)` | method | Forwards `text` to `sys.stderr.write()` when enabled; otherwise a no-op. |
| `flush()` | method | Forwards to `sys.stderr.flush()` when enabled; otherwise a no-op. |
| `enabled` | property | Getter/setter exposing the `_enabled` flag for runtime toggling. |

### Module-level singleton: `DSPY_LOGGING_STREAM`

A single shared instance of `DSPyLoggingStream` created at import time. All DSPy logging flows through this instance, which is why toggling its `enabled` property affects the entire framework.

### `disable_logging()` / `enable_logging()`

Convenience functions that flip the `enabled` flag on the shared `DSPY_LOGGING_STREAM`:

- `disable_logging()` — silences all subsequent event logs.
- `enable_logging()` — restores event logs (reverses `disable_logging()`).

### `configure_dspy_loggers(root_module_name)`

Configures a standard `logging` handler for the DSPy root logger:

1. Builds a `logging.Formatter` using the module-level format constants.
2. Creates a `logging.StreamHandler` bound to `DSPY_LOGGING_STREAM` (so it respects the enable/disable switch).
3. Names the handler `"dspy_handler"` for idempotent re-configuration.
4. Sets the logger level to `INFO` and disables propagation to avoid duplicate output.
5. Removes any pre-existing handler with the same name before adding the new one, preventing duplicate handlers on repeated calls.

### Format constants

| Constant | Value |
| --- | --- |
| `LOGGING_LINE_FORMAT` | `"%(asctime)s %(levelname)s %(name)s: %(message)s"` |
| `LOGGING_DATETIME_FORMAT` | `"%Y/%m/%d %H:%M:%S"` |

---

## Architecture

The module sits at the lowest layer of DSPy's utility stack. It has no internal DSPy dependencies and is consumed by higher-level subsystems that need to emit or suppress logs.

```mermaid
graph TD
    subgraph "utils_logging module"
        STREAM["DSPyLoggingStream"]
        SINGLETON["DSPY_LOGGING_STREAM (singleton)"]
        DISABLE["disable_logging()"]
        ENABLE["enable_logging()"]
        CONFIG["configure_dspy_loggers()"]
        FMT["LOGGING_LINE_FORMAT / LOGGING_DATETIME_FORMAT"]
    end

    SINGLETON -->|instance of| STREAM
    DISABLE -->|sets enabled=False| SINGLETON
    ENABLE -->|sets enabled=True| SINGLETON
    CONFIG -->|StreamHandler bound to| SINGLETON
    CONFIG -->|uses| FMT

    STREAM -->|write/flush| STDERR["sys.stderr"]

    subgraph "Consumers"
        CALLBACK["utils_callbacks (BaseCallback)"]
        PARALLEL["utils_parallelization (ParallelExecutor)"]
        USAGE["utils_usage_tracking (UsageTracker)"]
        CORE["DSPy core / modules / clients"]
    end

    CORE -->|eprint / logger.info| SINGLETON
    PARALLEL -->|logger.error / logger.warning| SINGLETON
    CALLBACK -.->|diagnostic output| SINGLETON
    USAGE -.->|diagnostic output| SINGLETON
```

---

## Component Interaction

The following diagram shows how the pieces of the module interact at runtime, from configuration through to output emission and suppression.

```mermaid
sequenceDiagram
    participant User
    participant Config as configure_dspy_loggers()
    participant Logger as logging.Logger (root_module_name)
    participant Handler as StreamHandler
    participant Stream as DSPY_LOGGING_STREAM
    participant Stderr as sys.stderr

    User->>Config: configure_dspy_loggers("dspy")
    Config->>Handler: create StreamHandler(stream=DSPY_LOGGING_STREAM)
    Config->>Handler: setFormatter(LOGGING_LINE_FORMAT)
    Config->>Logger: setLevel(INFO), propagate=False
    Config->>Logger: remove old "dspy_handler" (if any)
    Config->>Logger: addHandler(Handler)

    Note over User,Stderr: Normal logging flow
    Logger->>Handler: emit(record)
    Handler->>Stream: write(formatted_message)
    Stream->>Stderr: sys.stderr.write(text)

    Note over User,Stderr: Suppression flow
    User->>Stream: disable_logging() -> enabled=False
    Logger->>Handler: emit(record)
    Handler->>Stream: write(formatted_message)
    Stream--xStderr: (no-op, suppressed)
```

---

## Data Flow

```mermaid
flowchart LR
    A["DSPy code calls<br/>eprint() / logger.info()"] --> B{"DSPY_LOGGING_STREAM.enabled?"}
    B -->|True| C["DSPyLoggingStream.write(text)"]
    C --> D["sys.stderr.write(text)"]
    B -->|False| E["No-op (silenced)"]
    D --> F["Terminal / captured output"]
```

The single decision point (`enabled`) means that toggling logging is O(1) and affects every logging call site uniformly, without requiring changes to individual callers.

---

## Process Flow: Configuration and Toggling

```mermaid
flowchart TD
    Start([Import utils_logging]) --> Create["Create DSPY_LOGGING_STREAM<br/>(enabled=True)"]
    Create --> Choice{User action}

    Choice -->|Configure loggers| Cfg["configure_dspy_loggers(root_module_name)"]
    Cfg --> Fmt["Build Formatter from constants"]
    Fmt --> H["Create named StreamHandler 'dspy_handler'"]
    H --> Clean["Remove existing 'dspy_handler'"]
    Clean --> Add["Add handler to logger<br/>level=INFO, propagate=False"]

    Choice -->|Silence logs| Dis["disable_logging()"]
    Dis --> Off["DSPY_LOGGING_STREAM.enabled = False"]

    Choice -->|Restore logs| En["enable_logging()"]
    En --> On["DSPY_LOGGING_STREAM.enabled = True"]
```

---

## Relationship to Other Modules

The `utils_logging` module is a foundational utility with no internal DSPy dependencies. It is referenced by other utility and core subsystems:

- **[utils_parallelization](utils_parallelization.md)** — `ParallelExecutor` uses the standard `logging` module (`logger.error`, `logger.warning`) for error reporting and cancellation notices. These messages flow through the same logging infrastructure configured here.
- **[utils_callbacks](utils_callbacks.md)** — `BaseCallback` provides lifecycle hooks (e.g., `on_lm_start`, `on_module_end`) that users commonly combine with logging to trace execution. Callback-driven diagnostics ultimately surface through the same stream.
- **[utils_usage_tracking](utils_usage_tracking.md)** — `UsageTracker` collects token usage data; diagnostic output about usage is emitted via the shared logging stream.
- **DSPy core, modules, and clients** — Throughout the framework, `eprint()` and `logger.info()` calls route through `DSPY_LOGGING_STREAM`, making this module the single control point for framework-wide log verbosity.

> Because all documentation files live in the same folder, the links above point directly to the corresponding module documentation files.

---

## Usage Examples

### Silencing and restoring DSPy logs

```python
from dspy.utils.logging_utils import disable_logging, enable_logging

disable_logging()   # All subsequent DSPy event logs are silenced
# ... run noisy operations ...
enable_logging()    # Logs are emitted again
```

### Configuring the DSPy root logger

```python
from dspy.utils.logging_utils import configure_dspy_loggers

configure_dspy_loggers("dspy")
# The "dspy" logger now emits INFO-level messages through DSPY_LOGGING_STREAM,
# formatted as "YYYY/MM/DD HH:MM:SS LEVEL name: message".
```

### Toggling the stream directly

```python
from dspy.utils.logging_utils import DSPY_LOGGING_STREAM

DSPY_LOGGING_STREAM.enabled = False  # equivalent to disable_logging()
DSPY_LOGGING_STREAM.enabled = True   # equivalent to enable_logging()
```

---

## Design Notes

- **Late binding to `sys.stderr`**: `DSPyLoggingStream` resolves `sys.stderr` on every `write()`/`flush()` call rather than caching it. This ensures compatibility with environments that swap out `sys.stderr` (test runners, notebooks, output capture).
- **Idempotent configuration**: `configure_dspy_loggers()` removes any existing handler named `"dspy_handler"` before adding a new one, so repeated calls do not produce duplicate log lines.
- **No propagation**: Setting `logger.propagate = False` prevents messages from bubbling up to the Python root logger, avoiding duplicate output when the application also configures root logging.
- **Zero internal dependencies**: The module imports only from the standard library (`logging`, `logging.config`, `sys`), keeping it safe to import from anywhere in DSPy without circular-import risk.
