# predict_avatar

## Overview

The `predict_avatar` module implements **Avatar**, a DSPy module that enables an LLM-driven agent to solve a task by iteratively selecting and invoking external **tools**. Unlike a single-shot predictor, Avatar runs a multi-step *reason–act* loop: at each iteration an internal `Actor` signature decides which tool to call (and with what input), the tool is executed, and its result is fed back into the next iteration. The loop terminates when the agent selects the special `Finish` tool, at which point the final output fields of the user-supplied signature are produced.

Avatar is the runtime counterpart of the [`teleprompt_avatar`](teleprompt_avatar.md) optimizer (`AvatarOptimizer`), which tunes the actor's instruction based on positive/negative examples collected from Avatar runs.

### Key Capabilities

- **Tool-augmented reasoning**: Dynamically builds a signature that grows with each tool invocation, accumulating `action_i` / `result_i` pairs.
- **Iterative execution loop**: Bounded by `max_iters` (default `3`) and terminated by the `Finish` tool.
- **Signature-driven**: Wraps any user-provided DSPy `Signature`, preserving its input and output fields.
- **Traceable**: Returns the full list of `ActionOutput` records alongside the final prediction.
- **Optimizable**: Designed to be compiled by `AvatarOptimizer`.

## Architecture

Avatar is composed of three cooperating sub-modules: the **core module** (the execution engine), the **data models** (typed structures for tools and actions), and the **signatures** (the LLM prompt contract).

```mermaid
graph TD
    subgraph predict_avatar
        Avatar["Avatar<br/>(avatar.py)"]
        Models["models.py<br/>Tool, Action, ActionOutput"]
        Sigs["signatures.py<br/>Actor"]
    end

    Avatar -->|uses| Models
    Avatar -->|uses| Sigs
    Avatar -->|wraps| TypedPredictor["dspy.TypedPredictor"]
    Avatar -->|extends| Module["dspy.Module"]
    Avatar -->|returns| Prediction["dspy.Prediction"]

    TypedPredictor -->|uses| Actor
    Actor -->|outputs| Action

    Optimizer["AvatarOptimizer<br/>(teleprompt_avatar)"] -.->|compiles| Avatar
```

### Component Relationships

```mermaid
classDiagram
    class Avatar {
        +signature
        +tools: list[Tool]
        +actor: TypedPredictor
        +actor_clone
        +max_iters
        +verbose
        +forward(**kwargs) Prediction
        -_get_field(field_info)
        -_update_signature(idx, omit_action)
        -_call_tool(tool_name, query)
    }
    class Tool {
        +tool: Any
        +name: str
        +desc: str
        +input_type: str
    }
    class Action {
        +tool_name: Any
        +tool_input_query: Any
    }
    class ActionOutput {
        +tool_name: str
        +tool_input_query: str
        +tool_output: str
    }
    class Actor {
        +goal: str
        +tools: list[str]
        +action_1: Action
    }

    Avatar "1" --> "*" Tool : holds
    Avatar "1" --> "1" Actor : builds
    Actor "1" --> "1" Action : produces
    Avatar "1" --> "*" ActionOutput : records
```

## Sub-modules

### 1. Avatar Core (`avatar.py`)

The execution engine. The `Avatar` class extends [`dspy.Module`](primitives.md) and orchestrates the reason–act loop. It:

- Normalizes the user signature via `ensure_signature` and extracts input/output fields.
- Appends a synthetic `Finish` tool to the provided tool list.
- Dynamically extends the `Actor` signature with the user's input fields.
- Runs the loop in `forward`, calling tools and accumulating results until `Finish` is selected or `max_iters` is exhausted.
- Restores the actor to its pristine state (`actor_clone`) after each call so the module is reusable.

See [predict_avatar_core.md](predict_avatar_core.md) for full details.

### 2. Avatar Models (`models.py`)

Pydantic-based data structures that give the agent's actions a typed shape:

- **`Tool`** — wraps a callable tool with a name, description, and optional input type.
- **`Action`** — the structured output of the actor: a `tool_name` and a `tool_input_query`.
- **`ActionOutput`** — a record of an executed action: tool name, input query, and the resulting output.

See [predict_avatar_models.md](predict_avatar_models.md) for full details.

### 3. Avatar Signatures (`signatures.py`)

Defines the **`Actor`** signature — the prompt contract that instructs the LLM to choose a tool and provide its input. It declares `goal`, `tools`, and the first `action_1` output field, which the core module extends at runtime.

See [predict_avatar_signatures.md](predict_avatar_signatures.md) for full details.

## Execution Flow

The following sequence diagram illustrates a single `Avatar.forward` call that performs two tool invocations before finishing.

```mermaid
sequenceDiagram
    participant Caller
    participant Avatar
    participant Actor as Actor (TypedPredictor)
    participant Tool

    Caller->>Avatar: forward(**inputs)
    Avatar->>Avatar: build args {goal, tools, inputs}
    loop until Finish or max_iters
        Avatar->>Actor: actor(**args)
        Actor-->>Avatar: action_i (tool_name, query)
        alt tool_name != "Finish"
            Avatar->>Tool: _call_tool(tool_name, query)
            Tool-->>Avatar: tool_output
            Avatar->>Avatar: _update_signature(idx)
            Avatar->>Avatar: append action_i, result_i to args
        else tool_name == "Finish"
            Avatar->>Avatar: _update_signature(idx, omit_action=True)
            Avatar->>Avatar: break
        end
    end
    Avatar->>Actor: actor(**args)  (final answer)
    Actor-->>Avatar: final output fields
    Avatar->>Avatar: restore actor from actor_clone
    Avatar-->>Caller: Prediction(outputs..., actions=[ActionOutput])
```

## Integration with the Broader System

| Dependency | Role |
| --- | --- |
| [`dspy.Module`](primitives.md) | Base class providing `__call__`, callbacks, and usage tracking. |
| [`dspy.TypedPredictor`](predict.md) | Wraps the `Actor` signature to produce typed `Action` outputs. |
| [`dspy.Signature`](signatures.md) | Provides `append`, `with_updated_fields`, and `with_instructions` used to grow the actor signature. |
| [`dspy.Prediction`](primitives.md) | Return type carrying output fields plus the `actions` trace. |
| [`AvatarOptimizer`](teleprompt_avatar.md) | Teleprompter that compiles an `Avatar` instance by rewriting the actor's instructions. |

## Usage Example

```python
import dspy
from dspy.predict.avatar import Avatar
from dspy.predict.avatar.models import Tool

def search(query: str) -> str:
    return f"Results for: {query}"

tools = [Tool(tool=search, name="Search", desc="Search the web", input_type="str")]

class Task(dspy.Signature):
    """Answer the user's question using the available tools."""
    question: str = dspy.InputField()
    answer: str = dspy.OutputField()

avatar = Avatar(Task, tools=tools, max_iters=3, verbose=True)
result = avatar(question="What is the capital of France?")
print(result.answer)
print(result.actions)  # list[ActionOutput]
```

## Related Documentation

- [predict_avatar_core.md](predict_avatar_core.md) — Avatar execution engine
- [predict_avatar_models.md](predict_avatar_models.md) — Tool / Action / ActionOutput models
- [predict_avatar_signatures.md](predict_avatar_signatures.md) — Actor signature
- [teleprompt_avatar.md](teleprompt_avatar.md) — AvatarOptimizer
- [predict.md](predict.md) — Predict / TypedPredictor
- [signatures.md](signatures.md) — Signature system
- [primitives.md](primitives.md) — Module / Prediction primitives
