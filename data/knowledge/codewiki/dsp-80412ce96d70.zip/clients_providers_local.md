# Local Provider (`clients_providers_local`)

## Introduction

The `clients_providers_local` module implements `LocalProvider`, a DSPy `Provider` subclass that enables running and fine-tuning language models **entirely on the local machine**. Unlike remote providers (e.g., [OpenAI](clients_providers_openai.md), [Databricks](clients_providers_databricks.md), or [Arbor](clients_providers_arbor.md)), `LocalProvider` manages the full lifecycle of a local inference server and performs supervised fine-tuning (SFT) using the Hugging Face ecosystem.

It is responsible for three core capabilities:

1. **Launching** a local inference server via [SGLang](https://docs.sglang.ai/) on a dynamically allocated free port.
2. **Killing** the launched server and cleaning up associated resources.
3. **Fine-tuning** a local model using `transformers` + `trl` (with optional PEFT/LoRA), producing a new model directory that can be served locally.

The provider is discovered and used through the [`LM`](clients_lm.md) client, which delegates `launch`, `kill`, and `finetune` calls to the active provider.

---

## Architecture Overview

`LocalProvider` extends the abstract [`Provider`](clients_clients_providers.md) base class and is one of several concrete provider implementations. It is selected when an `LM` is configured with a local model (e.g., `local:...` or `huggingface/...`).

```mermaid
graph TD
    LM["LM (dspy/clients/lm.py)"]
    Provider["Provider (abstract base)"]
    LocalProvider["LocalProvider"]
    TrainingJob["TrainingJob (Future)"]
    SGLang["SGLang Server (subprocess)"]
    HF["HuggingFace / TRL / PEFT"]
    Utils["utils_finetune (save_data, TrainDataFormat)"]

    LM -->|delegates launch/kill/finetune| LocalProvider
    Provider -->|inherited by| LocalProvider
    LocalProvider -->|spawns| SGLang
    LocalProvider -->|creates| TrainingJob
    LocalProvider -->|uses| HF
    LocalProvider -->|uses| Utils
```

### Class Definition

```python
class LocalProvider(Provider):
    def __init__(self):
        super().__init__()
        self.finetunable = True
        self.TrainingJob = TrainingJob
```

Key attributes:

| Attribute | Value | Meaning |
|-----------|-------|---------|
| `finetunable` | `True` | Signals to `LM.finetune()` that this provider supports fine-tuning. |
| `reinforceable` | `False` (inherited) | Reinforcement learning (GRPO) is **not** supported locally. |
| `TrainingJob` | `TrainingJob` | The job class used to track asynchronous fine-tuning. |

---

## Component Relationships

The module interacts with several other modules in the DSPy codebase. The diagram below shows the dependency graph.

```mermaid
graph LR
    subgraph "clients_providers_local"
        LP["LocalProvider"]
    end

    subgraph "clients_clients_providers"
        P["Provider"]
        TJ["TrainingJob"]
    end

    subgraph "clients_finetune"
        TDF["TrainDataFormat"]
        SD["save_data"]
    end

    subgraph "clients_lm"
        LM["LM"]
    end

    LP -->|inherits| P
    LP -->|instantiates| TJ
    LP -->|validates| TDF
    LP -->|persists data| SD
    LM -->|invokes| LP
```

- **`Provider` / `TrainingJob`** — Base abstractions defined in [clients_clients_providers.md](clients_clients_providers.md). `LocalProvider` overrides the static `launch`, `kill`, and `finetune` methods.
- **`TrainDataFormat` / `save_data`** — Defined in [clients_finetune.md](clients_finetune.md). Used to validate the training data format and persist training data to disk.
- **`LM`** — Defined in [clients_lm.md](clients_lm.md). The user-facing client that delegates lifecycle operations to the provider.

---

## Core Functionality

### 1. Launching a Local Inference Server

`LocalProvider.launch(lm, launch_kwargs)` starts an SGLang server as a subprocess.

```mermaid
sequenceDiagram
    participant User
    participant LM
    participant LocalProvider
    participant SGLang as SGLang Subprocess
    participant Thread as Log Tail Thread

    User->>LM: lm.launch()
    LM->>LocalProvider: launch(lm, launch_kwargs)
    LocalProvider->>LocalProvider: check sglang installed
    LocalProvider->>LocalProvider: normalize model name
    LocalProvider->>LocalProvider: get_free_port()
    LocalProvider->>SGLang: Popen(launch_server ...)
    LocalProvider->>Thread: start log tailing
    LocalProvider->>SGLang: wait_for_server(base_url, timeout)
    SGLang-->>LocalProvider: /v1/models returns 200
    LocalProvider->>LM: set kwargs[api_base], kwargs[api_key]
    LocalProvider->>LM: attach get_logs, process, thread
    LocalProvider-->>User: server ready
```

**Behavior details:**

- **Dependency check** — Raises `ImportError` with installation guidance if `sglang` is not installed.
- **Idempotency** — If `lm` already has a `process` attribute, the method logs "Server is already launched." and returns.
- **Model name normalization** — Strips prefixes such as `openai/`, `local:`, and `huggingface/` to obtain the raw model path.
- **Port allocation** — `get_free_port()` binds to port `0` on localhost to obtain an OS-assigned free port.
- **Command construction** — Builds `python -m sglang.launch_server --model-path {model} --port {port} --host 0.0.0.0`.
- **Log streaming** — A daemon thread (`_tail_process`) continuously reads merged stdout/stderr into a buffer and prints lines until the server is ready.
- **Readiness wait** — `wait_for_server()` polls `/v1/models` until a `200` response is received or the timeout (default `1800s`) elapses.
- **LM mutation** — On success, sets `lm.kwargs["api_base"]`, `lm.kwargs["api_key"] = "local"`, and attaches `lm.get_logs`, `lm.process`, and `lm.thread`.

### 2. Killing the Server

`LocalProvider.kill(lm, launch_kwargs)` terminates the running server.

```mermaid
flowchart TD
    A["kill(lm)"] --> B{"has lm.process?"}
    B -- No --> C["log: No running server to kill"]
    B -- Yes --> D["terminate_process(lm.process)"]
    D --> E["lm.thread.join()"]
    E --> F["delete lm.process, lm.thread, lm.get_logs"]
    F --> G["log: Server killed"]
```

- Uses `sglang.utils.terminate_process` to stop the subprocess.
- Joins the log-tailing thread and removes the attached attributes from the `LM` instance.

### 3. Fine-Tuning a Local Model

`LocalProvider.finetune(job, model, train_data, train_data_format, train_kwargs)` performs supervised fine-tuning.

```mermaid
flowchart TD
    A["finetune(job, model, ...)"] --> B["normalize model name"]
    B --> C{"train_data_format == CHAT?"}
    C -- No --> D["raise ValueError"]
    C -- Yes --> E["save_data(train_data)"]
    E --> F["create_output_dir(model, data_path)"]
    F --> G["merge default_train_kwargs"]
    G --> H["train_sft_locally(...)"]
    H --> I["return 'openai/local:{output_dir}'"]
```

**Behavior details:**

- **Format validation** — Only `TrainDataFormat.CHAT` is supported; other formats raise `ValueError`.
- **Data persistence** — `save_data()` (from [clients_finetune.md](clients_finetune.md)) writes the training data to a hashed `.jsonl` file.
- **Output directory** — `create_output_dir()` generates a unique directory name combining a random string, the sanitized model name, and a timestamp.
- **Default hyperparameters** — Merged with user-supplied `train_kwargs`:

  | Parameter | Default |
  |-----------|---------|
  | `device` | `None` (auto-detected) |
  | `use_peft` | `False` |
  | `num_train_epochs` | `5` |
  | `per_device_train_batch_size` | `1` |
  | `gradient_accumulation_steps` | `8` |
  | `learning_rate` | `1e-5` |
  | `max_seq_length` | `None` (later defaulted to `4096`) |
  | `packing` | `True` |
  | `bf16` | `True` |
  | `output_dir` | generated |

- **Return value** — A model identifier string `openai/local:{output_dir}` that can be passed back to `LM` for inference.

---

## Training Pipeline (`train_sft_locally`)

The actual training is delegated to `train_sft_locally`, which uses Hugging Face `transformers` and `trl`.

```mermaid
flowchart TD
    A["train_sft_locally"] --> B["import torch, transformers, trl"]
    B --> C["detect device (cuda/mps/cpu)"]
    C --> D["load AutoModelForCausalLM + AutoTokenizer"]
    D --> E["setup_chat_format (best-effort)"]
    E --> F["ensure pad_token"]
    F --> G["build HF Dataset from train_data"]
    G --> H["tokenize via encode_sft_example"]
    H --> I["filter empty-label examples"]
    I --> J{"use_peft?"}
    J -- Yes --> K["build LoraConfig"]
    J -- No --> L["peft_config = None"]
    K --> M["SFTConfig + SFTTrainer"]
    L --> M
    M --> N["trainer.train()"]
    N --> O["trainer.save_model()"]
    O --> P{"use_peft and merge?"}
    P -- Yes --> Q["merge_and_unload + save"]
    P -- No --> R["cleanup (gc, empty_cache)"]
    Q --> R
```

### Key Steps

1. **Dependency import** — Requires `torch`, `transformers`, and `trl`; raises an informative `ImportError` otherwise.
2. **Device selection** — Auto-detects `cuda`, then `mps`, then falls back to `cpu`.
3. **Model & tokenizer loading** — Uses `AutoModelForCausalLM` and `AutoTokenizer`.
4. **Chat format setup** — `setup_chat_format` is applied in a `try/except` (only relevant for non-chat model variants).
5. **Padding token** — Adds a `[!#PAD#!]` pad token if missing.
6. **Dataset construction** — Converts `train_data` into a Hugging Face `Dataset` and tokenizes each example via `encode_sft_example`.
7. **Label masking** — `encode_sft_example` masks non-assistant tokens with `-100` so loss is computed only on assistant responses.
8. **PEFT/LoRA (optional)** — When `use_peft=True`, applies a `LoraConfig` (rank `32`, alpha `64`, dropout `0.05`, `all-linear` target modules).
9. **Training** — Configures `SFTConfig` (with `max_grad_norm=2.0`, `warmup_ratio=0.03`, constant LR schedule) and runs `SFTTrainer.train()`.
10. **Saving & merging** — Saves the model; if PEFT was used, merges the adapter into the base model and saves the merged model.
11. **Cleanup** — Deletes model/tokenizer/trainer and frees GPU memory.

---

## Helper Functions

| Function | Purpose |
|----------|---------|
| `create_output_dir(model_name, data_path)` | Generates a unique output directory name from a random string, sanitized model name, and timestamp. |
| `train_sft_locally(model_name, train_data, train_kwargs)` | Runs the full SFT training pipeline and returns the output directory. |
| `get_free_port()` | Returns a free TCP port on localhost by binding to port `0`. |
| `wait_for_server(base_url, timeout)` | Polls `/v1/models` until the server responds with `200` or times out. |
| `encode_sft_example(example, tokenizer, max_seq_length)` | Tokenizes a chat example and masks non-assistant tokens for SFT loss computation. |

---

## Data Flow

The following diagram illustrates how training data flows from the user through the provider into a fine-tuned model.

```mermaid
flowchart LR
    User["User train_data (list of dicts)"] --> LM["LM.finetune()"]
    LM --> LP["LocalProvider.finetune()"]
    LP --> SD["save_data() -> hashed .jsonl"]
    SD --> TSL["train_sft_locally()"]
    TSL --> DS["HF Dataset"]
    DS --> TOK["encode_sft_example()"]
    TOK --> TR["SFTTrainer"]
    TR --> OUT["output_dir (fine-tuned model)"]
    OUT --> RET["'openai/local:{output_dir}'"]
    RET --> LM2["New LM instance"]
```

---

## Integration with `LM`

`LocalProvider` is invoked indirectly through the [`LM`](clients_lm.md) client. The relevant `LM` methods are:

- `LM.launch(launch_kwargs)` → `self.provider.launch(self, launch_kwargs)`
- `LM.kill(launch_kwargs)` → `self.provider.kill(self, launch_kwargs)`
- `LM.finetune(train_data, train_data_format, train_kwargs)` → asserts `provider.finetunable`, creates a `TrainingJob`, and runs `_run_finetune_job` in a background thread.

```mermaid
sequenceDiagram
    participant User
    participant LM
    participant LocalProvider
    participant Job as TrainingJob

    User->>LM: lm.finetune(train_data, CHAT)
    LM->>LM: assert provider.finetunable
    LM->>Job: create TrainingJob(thread, model, ...)
    LM->>Job: thread.start()
    Job->>LocalProvider: finetune(job, ...)
    LocalProvider-->>Job: model string
    Job-->>LM: set_result(new_lm)
    LM-->>User: TrainingJob (Future)
```

Because `TrainingJob` is a `Future`, callers can await the result to obtain a new `LM` instance pointing at the fine-tuned model.

---

## Comparison with Other Providers

| Provider | Launch | Kill | Fine-tune | Reinforce | Backend |
|----------|--------|------|-----------|-----------|---------|
| **LocalProvider** | ✅ (SGLang subprocess) | ✅ | ✅ (local SFT) | ❌ | SGLang + HF/TRL |
| [OpenAIProvider](clients_providers_openai.md) | ❌ | ❌ | ✅ (remote) | ❌ | OpenAI API |
| [DatabricksProvider](clients_providers_databricks.md) | ❌ | ❌ | ✅ (remote) | ❌ | Databricks |
| [ArborProvider](clients_providers_arbor.md) | ✅ (HTTP) | ✅ | ✅ (remote) | ✅ | Arbor server |

---

## Error Handling & Edge Cases

- **Missing `sglang`** — `launch()` raises `ImportError` with a link to installation instructions.
- **Missing `torch`/`transformers`/`trl`** — `train_sft_locally()` raises `ImportError` with a `pip install` hint.
- **Server timeout** — If `wait_for_server` times out, the subprocess is killed and `TimeoutError` is re-raised.
- **Unsupported data format** — Non-`CHAT` formats raise `ValueError` in `finetune()`.
- **Empty messages** — `encode_sft_example` raises `ValueError` if the `messages` field is empty.
- **Idempotent launch/kill** — Both methods gracefully handle already-launched or non-running servers.

---

## Related Documentation

- [clients_lm.md](clients_lm.md) — The `LM` client that delegates to providers.
- [clients_clients_providers.md](clients_clients_providers.md) — The `Provider` and `TrainingJob` base abstractions.
- [clients_finetune.md](clients_finetune.md) — `TrainDataFormat`, `save_data`, and fine-tuning utilities.
- [clients_providers_openai.md](clients_providers_openai.md) — OpenAI provider implementation.
- [clients_providers_databricks.md](clients_providers_databricks.md) — Databricks provider implementation.
- [clients_providers_arbor.md](clients_providers_arbor.md) — Arbor provider implementation.
