# Retrievers: Embeddings

## Introduction

The `retrievers_embeddings` module provides the `Embeddings` retriever, a lightweight, in-memory semantic search component for DSPy. It embeds an entire corpus of text passages using a configurable embedder, then retrieves the top-`k` most semantically similar passages for a given query.

The retriever supports two search strategies that are automatically selected based on corpus size:

- **Brute-force search** — an exact, exhaustive similarity computation over all corpus embeddings. Used for small corpora.
- **FAISS approximate search** — an IVF-PQ (Inverted File with Product Quantization) index for efficient approximate nearest-neighbor search. Used for large corpora.

This module is one of several retriever implementations in DSPy. For the general retrieval abstraction and how retrievers plug into modules, see [retrievers_core.md](retrievers_core.md). For other backends, see [retrievers_databricks.md](retrievers_databricks.md) and [retrievers_weaviate.md](retrievers_weaviate.md).

---

## Core Component

### `Embeddings`

The `Embeddings` class is the sole public component of this module. It is a callable retriever that maps a query string to a ranked list of passages.

```python
class Embeddings:
    def __init__(
        self,
        corpus: list[str],
        embedder,
        k: int = 5,
        callbacks: list[Any] | None = None,
        cache: bool = False,
        brute_force_threshold: int = 20_000,
        normalize: bool = True,
    ):
        ...
```

#### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `corpus` | `list[str]` | — | The list of text passages to be indexed and searched. |
| `embedder` | callable | — | A callable that maps a list of strings to a 2D array of embeddings. Typically a [`dspy.Embedder`](clients_embedding.md) instance. |
| `k` | `int` | `5` | The number of top passages to return per query. |
| `callbacks` | `list[Any] \| None` | `None` | Optional callbacks (reserved for future use). |
| `cache` | `bool` | `False` | Caching is **not supported**; passing `True` raises an assertion error. |
| `brute_force_threshold` | `int` | `20_000` | Corpus size at or above which a FAISS index is built instead of brute-force search. |
| `normalize` | `bool` | `True` | Whether to L2-normalize embeddings before similarity computation. |

> **Note:** The module contains a `TODO` to add `.save` and `.load` methods for persistence. Currently, the index and embeddings are held only in memory.

#### Key Attributes

- `corpus_embeddings` — the (optionally normalized) embeddings of the entire corpus.
- `index` — a FAISS index if the corpus is large enough, otherwise `None`.
- `search_fn` — an [`Unbatchify`](utils.md) wrapper around `_batch_forward`, enabling thread-safe single-query calls that are internally batched.

---

## Architecture

The `Embeddings` retriever composes three collaborating pieces: an embedder, an optional FAISS index, and an unbatching search wrapper.

```mermaid
graph TD
    subgraph Embeddings["Embeddings Retriever"]
        C[corpus: list of str]
        CE[corpus_embeddings]
        IDX[FAISS index optional]
        SF[search_fn: Unbatchify]
        BF[_batch_forward]
        RR[_rerank_and_predict]
    end

    EMB[Embedder / callable] -->|embed corpus| CE
    CE -->|if len >= threshold| IDX
    SF -->|batches queries| BF
    BF -->|embed queries| EMB
    BF -->|if index| IDX
    BF -->|else| CE
    BF --> RR
    RR -->|top-k passages + indices| OUT[Prediction]
```

### Component Relationships

| Component | Role | Reference |
|-----------|------|-----------|
| `Embedder` | Computes embeddings for corpus and queries. | [clients_embedding.md](clients_embedding.md) |
| `Unbatchify` | Batches concurrent single-query calls into efficient batches. | [utils.md](utils.md) |
| `Prediction` | Return type wrapping `passages` and `indices`. | [primitives_data_containers.md](primitives_data_containers.md) |
| `Retrieve` | The generic retrieval abstraction that can delegate to an RM. | [retrievers_core.md](retrievers_core.md) |

---

## Data Flow

The following diagram illustrates the end-to-end flow from a query to a ranked result.

```mermaid
sequenceDiagram
    participant U as Caller
    participant E as Embeddings
    participant SF as Unbatchify
    participant BF as _batch_forward
    participant EMB as Embedder
    participant IDX as FAISS index / corpus_embeddings

    U->>E: __call__(query)
    E->>E: forward(query)
    E->>SF: search_fn(query)
    SF->>BF: _batch_forward([query, ...])
    BF->>EMB: embed(queries)
    EMB-->>BF: q_embeds
    BF->>BF: normalize(q_embeds)
    alt index exists
        BF->>IDX: _faiss_search(q_embeds, k*10)
        IDX-->>BF: candidate pids
    else brute force
        BF->>BF: pids = all corpus indices
    end
    BF->>BF: _rerank_and_predict(q_embeds, pids)
    BF-->>SF: [(passages, indices), ...]
    SF-->>E: (passages, indices)
    E-->>U: Prediction(passages, indices)
```

---

## Process Flows

### Initialization Flow

During construction, the retriever embeds the entire corpus once and decides on a search strategy.

```mermaid
flowchart TD
    A[Start __init__] --> B{cache is True?}
    B -->|Yes| C[AssertionError]
    B -->|No| D[Embed corpus]
    D --> E{normalize?}
    E -->|Yes| F[L2-normalize corpus embeddings]
    E -->|No| G[Keep raw embeddings]
    F --> H{len corpus >= brute_force_threshold?}
    G --> H
    H -->|Yes| I[_build_faiss]
    H -->|No| J[index = None]
    I --> K[Wrap _batch_forward in Unbatchify]
    J --> K
    K --> L[Ready]
```

### Search Flow (`_batch_forward`)

```mermaid
flowchart TD
    A[Receive batch of queries] --> B[Embed queries]
    B --> C{normalize?}
    C -->|Yes| D[Normalize query embeddings]
    C -->|No| E[Keep raw]
    D --> F{index exists?}
    E --> F
    F -->|Yes| G[FAISS search for k*10 candidates]
    F -->|No| H[Use all corpus indices]
    G --> I[_rerank_and_predict]
    H --> I
    I --> J[Compute dot-product scores]
    J --> K[Select top-k per query]
    K --> L[Return passages + indices]
```

---

## Method Reference

### `__call__(query)` / `forward(query)`

The public entry point. Delegates to `search_fn` (the `Unbatchify`-wrapped batch function) and wraps the result in a `dspy.Prediction`.

```python
def forward(self, query: str):
    import dspy
    passages, indices = self.search_fn(query)
    return dspy.Prediction(passages=passages, indices=indices)
```

**Returns:** `dspy.Prediction` with fields:
- `passages` — list of retrieved passage strings.
- `indices` — list of corresponding corpus indices.

### `_batch_forward(queries)`

The core batched search routine. Embeds the queries, optionally normalizes them, retrieves candidate indices (via FAISS or all indices), and reranks.

### `_build_faiss()`

Builds an IVF-PQ FAISS index over the corpus embeddings.

- Uses `nbytes = 32` and `partitions = int(2 * sqrt(len(corpus)))`.
- Requires `faiss-cpu`; raises `ImportError` with guidance if unavailable.
- Sets `index.nprobe = min(16, partitions)`.

> **Tip:** If FAISS is not installed, increase `brute_force_threshold` above the corpus size to force brute-force search.

### `_faiss_search(query_embeddings, num_candidates)`

Runs the FAISS index search and returns the candidate index IDs (the second element of the FAISS result tuple).

### `_rerank_and_predict(q_embeds, candidate_indices)`

Computes exact dot-product scores between query embeddings and candidate embeddings using `np.einsum("qd,qkd->qk", ...)`, then selects the top-`k` per query via `np.argsort`. Returns a list of `(passages, indices)` tuples.

### `_normalize(embeddings)`

L2-normalizes embeddings along axis 1, guarding against division by zero with `np.maximum(norms, 1e-10)`.

---

## Usage Example

```python
import dspy

# Build an embedder (hosted or local)
embedder = dspy.Embedder("openai/text-embedding-3-small")

# Create the retriever over a corpus
corpus = ["DSPy is a framework for programming LLMs.", "Retrieval augments generation.", ...]
retriever = dspy.retrievers.Embeddings(corpus=corpus, embedder=embedder, k=3)

# Query
result = retriever("What is DSPy?")
print(result.passages)
print(result.indices)
```

---

## Design Notes & Constraints

- **No caching:** The `cache` parameter must be `False`; caching is explicitly unsupported for embeddings-based retrievers.
- **No persistence:** `.save` / `.load` are not yet implemented (see `TODO` in source).
- **Automatic strategy selection:** The `brute_force_threshold` (default 20,000) governs the trade-off between exactness and scalability.
- **Concurrency:** `Unbatchify` transparently batches concurrent single-query calls, improving throughput when many queries arrive simultaneously.
- **Normalization:** With `normalize=True`, dot-product scoring is equivalent to cosine similarity.

---

## Related Modules

- [retrievers_core.md](retrievers_core.md) — The generic `Retrieve` abstraction.
- [retrievers_databricks.md](retrievers_databricks.md) — Databricks-backed retriever.
- [retrievers_weaviate.md](retrievers_weaviate.md) — Weaviate-backed retriever.
- [clients_embedding.md](clients_embedding.md) — The `Embedder` used to compute embeddings.
- [utils.md](utils.md) — The `Unbatchify` utility for batched concurrent execution.
- [primitives_data_containers.md](primitives_data_containers.md) — The `Prediction` return type.
