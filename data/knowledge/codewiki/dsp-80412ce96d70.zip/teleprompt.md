# Teleprompt Module

## Overview

The **Teleprompt** module is DSPy's collection of **optimizers** (also called *teleprompters*). An optimizer takes a DSPy program (a `Module` composed of `Predict` predictors) together with a training set and a metric, and returns an *optimized* version of that program. Optimization can take several forms:

- **Prompt optimization** — rewriting the natural-language instructions and/or output prefixes of each predictor's `Signature`.
- **Few-shot optimization** — selecting, bootstrapping, or synthesizing demonstrations (demos) to inject into each predictor's prompt.
- **Weight optimization** — fine-tuning the underlying language model(s) (SFT, GRPO reinforcement learning, etc.).
- **Ensembling / meta-optimization** — combining multiple programs or chaining prompt and weight optimizers.

Every optimizer derives from the abstract [`Teleprompter`](teleprompt_core.md) base class and exposes a `compile(student, *, trainset, teacher=None, valset=None, **kwargs)` method.

## Purpose

The module answers the question: *"Given a program and some data, how do I automatically make it better?"* It provides a spectrum of strategies ranging from trivial (attach labeled demos) to sophisticated (Bayesian search over instruction + demo combinations, or reinforcement-learning fine-tuning).

## Architecture Overview

```mermaid
graph TD
    TP["Teleprompter (abstract base)"]

    subgraph "Few-Shot / Demo Optimizers"
        LFS["LabeledFewShot"]
        BFS["BootstrapFewShot"]
        BFSRS["BootstrapFewShotWithRandomSearch"]
        BFSO["BootstrapFewShotWithOptuna"]
        KNN["KNNFewShot"]
        IR["InferRules"]
    end

    subgraph "Prompt / Instruction Optimizers"
        COPRO["COPRO"]
        SIGOPT["SignatureOptimizer (deprecated)"]
        MIPRO["MIPROv2"]
        SIMBA["SIMBA"]
    end

    subgraph "Weight / Fine-Tuning Optimizers"
        FT["FinetuneTeleprompter"]
        BFT["BootstrapFinetune"]
        GRPO["GRPO"]
    end

    subgraph "Meta / Composition Optimizers"
        ENS["Ensemble"]
        BT["BetterTogether"]
        AVATAR["AvatarOptimizer"]
    end

    TP --> LFS
    TP --> BFS
    TP --> BFSRS
    TP --> BFSO
    TP --> KNN
    TP --> COPRO
    TP --> MIPRO
    TP --> SIMBA
    TP --> FT
    TP --> ENS
    TP --> BT
    TP --> AVATAR

    BFS --> BFSRS
    BFS --> BFSO
    BFS --> IR
    COPRO --> SIGOPT
    FT --> BFT
    FT --> GRPO
    BFSRS --> BT
    BFT --> BT
    KNN --> BFS
```

## Core Concepts

| Concept | Description |
| --- | --- |
| **Student** | The program being optimized. Must be *uncompiled* (`_compiled == False`) when passed to `compile`. |
| **Teacher** | An optional, typically stronger program used to generate bootstrapped demonstrations. Must be structurally equivalent to the student. |
| **Trainset** | A list of `dspy.Example` objects used to bootstrap demos or fine-tune weights. |
| **Valset** | A held-out list of examples used to score candidate programs. |
| **Metric** | A callable `metric(example, prediction, trace=None) -> bool | float` used to filter bootstrapped demos and rank candidates. |
| **Demos** | Few-shot examples attached to a predictor (`predictor.demos`). |
| **Candidate programs** | Optimizers frequently attach a `candidate_programs` attribute to the returned program, listing all explored variants with their scores. |

## Sub-Modules

The module is organized into the following sub-modules. Each has its own detailed documentation:

### 1. [Teleprompt Core](teleprompt_core.md)
The abstract `Teleprompter` base class and shared utility functions (`create_minibatch`, `create_n_fewshot_demo_sets`, `eval_candidate_program`, `get_signature`, `set_signature`, `save_candidate_program`, etc.) used across optimizers.

### 2. [Few-Shot Optimizers](teleprompt_fewshot.md)
Optimizers that primarily manipulate demonstrations:
- `LabeledFewShot` — attach `k` labeled examples.
- `BootstrapFewShot` — bootstrap demos by tracing a teacher program.
- `BootstrapFewShotWithRandomSearch` — random search over bootstrapped demo sets.
- `BootstrapFewShotWithOptuna` — Optuna-driven demo selection.
- `KNNFewShot` — retrieve nearest-neighbor demos at inference time.
- `InferRules` — induce natural-language rules from examples.

### 3. [Prompt Optimizers](teleprompt_prompt.md)
Optimizers that rewrite instructions and prefixes:
- `COPRO` — coordinate-ascent over instruction candidates.
- `SignatureOptimizer` — deprecated alias of `COPRO`.
- `MIPROv2` — Bayesian (Optuna/TPE) joint optimization of instructions and demos.
- `SIMBA` — stochastic introspective mini-batch ascent.

### 4. [Weight Optimizers](teleprompt_weight.md)
Optimizers that fine-tune model weights:
- `FinetuneTeleprompter` — base class managing `train_kwargs` per LM.
- `BootstrapFinetune` — supervised fine-tuning on bootstrapped traces.
- `GRPO` — Group Relative Policy Optimization reinforcement learning.

### 5. [Meta Optimizers](teleprompt_meta.md)
Optimizers that compose or ensemble other programs:
- `Ensemble` — run multiple programs and reduce their outputs.
- `BetterTogether` — alternate prompt and weight optimization strategies.
- `AvatarOptimizer` — optimize agent (Avatar) instructions via feedback.

## Data Flow

A typical optimization run follows this pipeline:

```mermaid
flowchart LR
    A["Student Module"] --> B["compile()"]
    C["Trainset"] --> B
    D["Metric"] --> B
    E["Teacher (optional)"] --> B
    B --> F["Bootstrap / Propose candidates"]
    F --> G["Evaluate candidates on valset"]
    G --> H["Select best program"]
    H --> I["Optimized Module"]
    I --> J["candidate_programs / trial_logs attached"]
```

## Dependencies on Other Modules

The teleprompt module builds on several other DSPy modules:

- **[primitives](primitives.md)** — `Module`, `Example`, `Prediction` are the data structures being optimized.
- **[predict](predict.md)** — `Predict`, `ChainOfThought`, `KNN`, `Parallel` are the building blocks of student/teacher programs.
- **[evaluate](evaluate.md)** — `Evaluate` and `EvaluationResult` score candidate programs.
- **[propose](propose.md)** — `GroundedProposer` generates instruction candidates for `MIPROv2`.
- **[clients](clients.md)** — `LM`, `Embedder`, and fine-tuning utilities (`infer_data_format`, `GRPOGroup`, `TrainDataFormat`) power weight optimization.
- **[signatures](signatures.md)** — `Signature` objects are mutated by prompt optimizers.
- **[adapters](adapters.md)** — `Adapter`/`ChatAdapter` format fine-tuning data.

## Choosing an Optimizer

```mermaid
flowchart TD
    Start["What do you want to optimize?"] --> Q1{"Prompt only?"}
    Q1 -->|Yes| Q2{"Need instructions?"}
    Q2 -->|No, just demos| FewShot["LabeledFewShot / BootstrapFewShot / KNNFewShot"]
    Q2 -->|Yes| Q3{"Budget?"}
    Q3 -->|Low| COPRO
    Q3 -->|High| MIPRO["MIPROv2 / SIMBA"]
    Q1 -->|No| Q4{"Fine-tune weights?"}
    Q4 -->|SFT| BFT["BootstrapFinetune"]
    Q4 -->|RL| GRPO
    Q4 -->|Both prompt + weights| BT["BetterTogether"]
```
