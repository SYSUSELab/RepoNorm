# OpenAI Provider Module

## Introduction

The `clients_providers_openai` module implements DSPy's integration with OpenAI's fine-tuning API. It provides the concrete `OpenAIProvider` class (a subclass of the abstract [`Provider`](clients_providers.md)) and the `TrainingJobOpenAI` class (a subclass of [`TrainingJob`](clients_providers.md)), enabling DSPy programs to fine-tune OpenAI models directly through the standard DSPy fine-tuning interface.

This module is one of several provider implementations in DSPy. For the abstract provider interface and the fine-tuning data utilities it relies on, see the [clients_providers](clients_providers.md) and [clients_finetune](clients_finetune.md) documentation.

---

## Module Purpose

The module serves three primary responsibilities:

1. **Model Discovery** — Determine whether a given model string corresponds to an OpenAI model (base or fine-tuned), enabling automatic provider inference by [`LM`](clients_lm.md).
2. **Fine-Tuning Orchestration** — Validate, upload, and submit training data to OpenAI's fine-tuning API, then poll for completion and retrieve the resulting fine-tuned model.
3. **Job Lifecycle Management** — Track, query, and cancel OpenAI fine-tuning jobs through the `TrainingJobOpenAI` abstraction.

---

## Architecture

The module sits at the boundary between DSPy's provider abstraction layer and the external `openai` Python SDK.

```mermaid
graph TD
    subgraph "DSPy Core"
        LM["LM<br/>(clients_lm)"]
        Provider["Provider<br/>(clients_providers)"]
        TrainingJob["TrainingJob<br/>(clients_providers)"]
        Utils["utils_finetune<br/>(clients_finetune)"]
    end

    subgraph "clients_providers_openai"
        OP["OpenAIProvider"]
        TJO["TrainingJobOpenAI"]
    end

    subgraph "External"
        SDK["openai SDK<br/>(fine_tuning.jobs, files)"]
    end

    LM -->|"infer_provider()"| OP
    LM -->|"finetune()"| OP
    Provider -->|"inherits"| OP
    TrainingJob -->|"inherits"| TJO
    OP -->|"creates"| TJO
    OP -->|"validate/save"| Utils
    OP -->|"API calls"| SDK
    TJO -->|"status/cancel"| OP
```

### Key Relationships

| Component | Inherits From | Role |
|-----------|--------------|------|
| `OpenAIProvider` | [`Provider`](clients_providers.md) | Implements the fine-tuning interface for OpenAI |
| `TrainingJobOpenAI` | [`TrainingJob`](clients_providers.md) | Tracks an OpenAI fine-tuning job's lifecycle |

---

## Component Details

### `OpenAIProvider`

The `OpenAIProvider` class is the central component. It is instantiated automatically by [`LM.infer_provider()`](clients_lm.md) when a model string matches an OpenAI model, or it can be passed explicitly.

#### Configuration

On construction, the provider sets:
- `finetunable = True` — signals to [`LM.finetune()`](clients_lm.md) that this provider supports fine-tuning.
- `TrainingJob = TrainingJobOpenAI` — the job class used to track fine-tuning jobs.

#### Model Detection

`is_provider_model(model)` determines whether a model belongs to OpenAI. It:

1. Strips the `openai/` prefix via `_remove_provider_prefix`.
2. Checks membership in the static `_OPENAI_MODELS` list (GPT-4 family, GPT-3.5, o1 reasoning models, embeddings, TTS, DALL-E, Whisper, etc.).
3. Matches fine-tuned model names using the RegEx pattern `ft:([^:]+):`, verifying the base model is a known OpenAI model.

```mermaid
flowchart TD
    A["is_provider_model(model)"] --> B["Strip 'openai/' prefix"]
    B --> C{"In _OPENAI_MODELS?"}
    C -->|Yes| D["Return True"]
    C -->|No| E{"Matches 'ft:BASE:' pattern?"}
    E -->|Yes, base known| D
    E -->|No| F["Return False"]
```

#### Fine-Tuning Workflow

The static `finetune()` method orchestrates the full fine-tuning pipeline:

```mermaid
sequenceDiagram
    participant LM as LM.finetune()
    participant OP as OpenAIProvider
    participant FS as Local Filesystem
    participant OAI as OpenAI API

    LM->>OP: finetune(job, model, train_data, format, kwargs)
    OP->>OP: validate_data_format(format)
    OP->>FS: save_data(train_data) → data_path
    OP->>OAI: files.create(purpose="fine-tune")
    OAI-->>OP: provider_file_id
    OP->>OP: job.provider_file_id = provider_file_id
    OP->>OAI: fine_tuning.jobs.create(model, training_file, hyperparameters)
    OAI-->>OP: provider_job_id
    OP->>OP: job.provider_job_id = provider_job_id
    OP->>OP: wait_for_job(job) [poll loop]
    OP->>OAI: fine_tuning.jobs.retrieve(job_id)
    OAI-->>OP: fine_tuned_model
    OP-->>LM: finetuned model name
```

#### Method Reference

| Method | Purpose |
|--------|---------|
| `is_provider_model(model)` | Static; detects OpenAI models (base + fine-tuned) |
| `_remove_provider_prefix(model)` | Static; strips the `openai/` prefix |
| `finetune(job, model, train_data, train_data_format, train_kwargs)` | Static; full fine-tuning pipeline |
| `does_job_exist(job_id)` | Static; checks job existence via API |
| `does_file_exist(file_id)` | Static; checks file existence via API |
| `is_terminal_training_status(status)` | Static; returns `True` for succeeded/failed/cancelled |
| `get_training_status(job_id)` | Static; maps OpenAI status → [`TrainingStatus`](clients_finetune.md) |
| `validate_data_format(data_format)` | Static; only `CHAT` and `COMPLETION` are supported |
| `upload_data(data_path)` | Static; uploads a JSONL file for fine-tuning |
| `_start_remote_training(train_file_id, model, train_kwargs)` | Static; creates the remote job |
| `wait_for_job(job, poll_frequency)` | Static; polls job events until terminal |
| `get_trained_model(job)` | Static; retrieves the fine-tuned model name |

#### Status Mapping

`get_training_status` translates OpenAI's provider-specific statuses into DSPy's canonical [`TrainingStatus`](clients_finetune.md) enum:

| OpenAI Status | DSPy `TrainingStatus` |
|---------------|----------------------|
| `validating_files` | `pending` |
| `queued` | `pending` |
| `running` | `running` |
| `succeeded` | `succeeded` |
| `failed` | `failed` |
| `cancelled` | `cancelled` |
| *(no job)* | `not_started` |

#### Data Format Support

`validate_data_format` restricts supported formats to those OpenAI accepts:

- ✅ [`TrainDataFormat.CHAT`](clients_finetune.md)
- ✅ [`TrainDataFormat.COMPLETION`](clients_finetune.md)
- ❌ `TrainDataFormat.GRPO_CHAT` (raises `ValueError`)

---

### `TrainingJobOpenAI`

`TrainingJobOpenAI` extends [`TrainingJob`](clients_providers.md) (itself a `Future`) to manage the lifecycle of a single OpenAI fine-tuning job. It adds two provider-specific identifiers:

- `provider_file_id` — the ID of the uploaded training file.
- `provider_job_id` — the ID of the remote fine-tuning job.

#### Cancellation

The `cancel()` method performs a two-stage cleanup before delegating to the parent:

```mermaid
flowchart TD
    A["cancel()"] --> B{"Job exists?"}
    B -->|Yes| C{"Terminal status?"}
    C -->|Yes| D["Raise Exception<br/>(cannot cancel completed job)"]
    C -->|No| E["openai.fine_tuning.jobs.cancel()"]
    E --> F["provider_job_id = None"]
    B -->|No| G
    F --> G{"File exists?"}
    G -->|Yes| H["openai.files.delete()"]
    G -->|No| I
    H --> I["provider_file_id = None"]
    I --> J["super().cancel()"]
```

#### Status

`status()` delegates to `OpenAIProvider.get_training_status(self.provider_job_id)`, returning a [`TrainingStatus`](clients_finetune.md) value.

---

## Integration with the Broader System

### Provider Inference

When a user creates an [`LM`](clients_lm.md) with an OpenAI model string (e.g., `"openai/gpt-4o"`), `LM.infer_provider()` calls `OpenAIProvider.is_provider_model()` and instantiates the provider automatically.

### Fine-Tuning via Teleprompters

The [`BootstrapFinetune`](teleprompt.md) teleprompter drives fine-tuning end-to-end. It calls `LM.finetune()`, which:

1. Asserts `provider.finetunable` is `True`.
2. Spawns a background thread running `_run_finetune_job`.
3. Creates a `TrainingJobOpenAI` and returns it as a `Future`.

The thread invokes `OpenAIProvider.finetune(...)`, and on success sets the job result to a new `LM` instance bound to the fine-tuned model.

```mermaid
graph LR
    BF["BootstrapFinetune<br/>(teleprompt)"] -->|"lm.finetune()"| LM["LM"]
    LM -->|"provider.finetune()"| OP["OpenAIProvider"]
    OP -->|"creates"| TJO["TrainingJobOpenAI"]
    TJO -->|"Future result"| LM
    LM -->|"copy(model=...)"| LM2["Fine-tuned LM"]
```

### Data Utilities

The provider relies on [`clients_finetune`](clients_finetune.md) utilities:

- `save_data(train_data)` — serializes training data to a hashed JSONL file in the fine-tune directory (configurable via `DSPY_FINETUNEDIR`).
- `TrainDataFormat` — the enum of supported data formats.
- `TrainingStatus` — the canonical status enum.

---

## Dependencies

```mermaid
graph TD
    OAI["clients_providers_openai"]
    OAI --> P["clients_providers<br/>(Provider, TrainingJob)"]
    OAI --> UF["clients_finetune<br/>(TrainDataFormat, TrainingStatus, save_data)"]
    OAI --> SDK["openai SDK"]
    OAI --> RE["re, time, datetime"]
    LM["clients_lm"] --> OAI
    BF["teleprompt<br/>(BootstrapFinetune)"] --> LM
```

| Dependency | Type | Usage |
|-----------|------|-------|
| [`clients_providers`](clients_providers.md) | Internal | Base `Provider` and `TrainingJob` classes |
| [`clients_finetune`](clients_finetune.md) | Internal | `TrainDataFormat`, `TrainingStatus`, `save_data` |
| [`clients_lm`](clients_lm.md) | Internal (consumer) | Invokes provider for inference and fine-tuning |
| `openai` | External | OpenAI Python SDK for API calls |
| `re`, `time`, `datetime` | Standard library | Model matching, polling, timestamps |

---

## Notes and Limitations

- **Model list maintenance**: `_OPENAI_MODELS` is a hardcoded list. The code comments note that `openai.models.list()` could replace it, but that may require an API key.
- **Fine-tuned model detection**: Uses a RegEx heuristic rather than an API call, so it may not match all fine-tuned model names exactly.
- **Error handling in existence checks**: `does_job_exist` and `does_file_exist` catch all exceptions and return `False`, which could mask unrelated API errors (noted as a TODO in the source).
- **Log streaming**: Job progress is polled via `list_events`; streaming logs are noted as a potential future enhancement.

---

## Related Documentation

- [clients_providers](clients_providers.md) — Abstract `Provider`, `TrainingJob`, and `ReinforceJob` interfaces
- [clients_finetune](clients_finetune.md) — Fine-tuning data formats, statuses, and serialization utilities
- [clients_lm](clients_lm.md) — The `LM` class that consumes providers
- [clients_providers_databricks](clients_providers_databricks.md) — Databricks provider implementation
- [clients_providers_local](clients_providers_local.md) — Local provider implementation
- [clients_providers_arbor](clients_providers_arbor.md) — Arbor provider implementation
- [teleprompt](teleprompt.md) — `BootstrapFinetune` and other optimizers
