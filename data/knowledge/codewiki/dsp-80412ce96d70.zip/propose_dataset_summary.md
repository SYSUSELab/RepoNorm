# Propose Dataset Summary

## Introduction

The **Propose Dataset Summary** module (`dspy/propose/dataset_summary_generator.py`) is responsible for automatically generating a concise, natural-language summary of a training dataset. This summary captures the most salient trends, topics, and characteristics that hold across the dataset's examples, and is used downstream to inform instruction generation for prompt optimization.

The module is a key building block of the [Grounded Proposer](propose_grounded_proposer.md) pipeline. When the `GroundedProposer` is configured with `use_dataset_summary=True`, it invokes `create_dataset_summary(...)` to produce a "data-aware" description of the training set. This description is then injected into the instruction-generation prompts, allowing the optimizer to propose instructions that are grounded in the actual data distribution rather than relying solely on the program's source code.

The module is built entirely on top of DSPy's declarative primitives — it defines three `dspy.Signature` classes and orchestrates them with `dspy.Predict` calls inside a batched, iterative loop.

---

## Core Components

The module exposes three signature classes and one orchestration function.

| Component | Kind | Purpose |
|-----------|------|---------|
| `DatasetDescriptor` | `dspy.Signature` | Generates initial observations about a batch of dataset examples. |
| `DatasetDescriptorWithPriorObservations` | `dspy.Signature` | Extends prior observations with new ones from a subsequent batch, or signals `COMPLETE`. |
| `ObservationSummarizer` | `dspy.Signature` | Condenses the accumulated observations into a 2–3 sentence summary. |
| `create_dataset_summary` | function | Orchestrates the batched observation loop and produces the final summary string. |
| `order_input_keys_in_string` | helper function | Normalizes the ordering of `input_keys` in an `Example` repr for deterministic prompting. |

### `DatasetDescriptor`

A signature that takes a batch of dataset examples and produces free-form observations about trends that hold for most or all samples. The instructions explicitly encourage the model to consider topics, content, syntax, and conciseness, and to make a creative educated guess about the nature of the task the dataset enables.

- **Inputs:** `examples` — sample data points from the dataset.
- **Outputs:** `observations` — statements that hold true for most or all of the observed data.

### `DatasetDescriptorWithPriorObservations`

An incremental variant of `DatasetDescriptor`. In addition to a new batch of examples, it receives the observations accumulated so far. The model is instructed to either add new observations or respond with `COMPLETE` if the existing observations are already comprehensive.

- **Inputs:** `examples`, `prior_observations`.
- **Outputs:** `observations` — new observations, or `COMPLETE` if nothing remains to add.

### `ObservationSummarizer`

A signature that condenses the full set of accumulated observations into a brief 2–3 sentence summary highlighting only the most important details.

- **Inputs:** `observations`.
- **Outputs:** `summary` — a two-to-three sentence summary.

### `create_dataset_summary`

The orchestration function that ties the signatures together. Its signature is:

```python
def create_dataset_summary(trainset, view_data_batch_size, prompt_model, log_file=None, verbose=False):
```

It returns a cleaned summary string (via `strip_prefix`).

---

## Architecture

The module is a thin, self-contained layer that depends on DSPy's core primitives. It does not depend on any other `propose` submodule at import time, but it is consumed by the `GroundedProposer`.

```mermaid
graph TD
    subgraph "propose_dataset_summary"
        CDS["create_dataset_summary()"]
        OIK["order_input_keys_in_string()"]
        DD["DatasetDescriptor<br/>(Signature)"]
        DDP["DatasetDescriptorWithPriorObservations<br/>(Signature)"]
        OS["ObservationSummarizer<br/>(Signature)"]
    end

    subgraph "DSPy Core"
        SIG["Signature"]
        PRED["Predict"]
        SET["Settings"]
    end

    subgraph "propose"
        UTIL["strip_prefix<br/>(propose/utils.py)"]
        GP["GroundedProposer"]
    end

    CDS --> DD
    CDS --> DDP
    CDS --> OS
    CDS --> OIK
    CDS --> UTIL
    CDS --> SET

    DD -.inherits.-> SIG
    DDP -.inherits.-> SIG
    OS -.inherits.-> SIG

    CDS -.uses.-> PRED
    GP -->|"use_dataset_summary=True"| CDS
```

### Dependency Summary

- **`dspy.Signature`** — all three components are declarative signatures. See [signatures](signatures.md) for details on the signature system.
- **`dspy.Predict`** — used to execute each signature. See [predict_core](predict_core.md).
- **`dspy.settings`** — the `Settings` singleton provides the `context(lm=...)` mechanism used to scope the prompt model. See [dsp_utils_settings](dsp_utils_settings.md).
- **`strip_prefix`** — a utility from `dspy/propose/utils.py` that removes leading role prefixes (e.g., `"Summary:"`) and surrounding quotes from generated text.
- **`GroundedProposer`** — the primary consumer. See [propose_grounded_proposer](propose_grounded_proposer.md).

---

## Data Flow

The following diagram illustrates how data flows through `create_dataset_summary`, from the raw training set to the final summary string.

```mermaid
flowchart TD
    A["trainset (list of Examples)"] --> B["Slice first batch:<br/>trainset[0:upper_lim]"]
    B --> C["order_input_keys_in_string(<br/>batch.__repr__())"]
    C --> D["Predict(DatasetDescriptor)<br/>temperature=1.0"]
    D --> E["observations (initial)"]

    E --> F{"More batches?<br/>b < len(trainset)<br/>and calls < max_calls"}
    F -->|Yes| G["Slice next batch:<br/>trainset[b:upper_lim]"]
    G --> H["order_input_keys_in_string(<br/>batch.__repr__())"]
    H --> I["Predict(DatasetDescriptorWithPriorObservations)<br/>prior_observations=observations"]
    I --> J{"Output starts with<br/>'COMPLETE'?"}
    J -->|Yes| K["skips += 1"]
    K --> L{"skips >= 5?"}
    L -->|Yes| M["Break loop"]
    L -->|No| F
    J -->|No| N["observations += new observations"]
    N --> F
    F -->|No| M

    M --> O["Predict(ObservationSummarizer)<br/>observations=observations"]
    O --> P["summary.summary"]
    P --> Q["strip_prefix(...)"]
    Q --> R["Final summary string"]
```

### Key Flow Characteristics

1. **Batched observation.** The dataset is processed in batches of size `view_data_batch_size`. The first batch seeds the initial observations; subsequent batches extend them.
2. **Early termination.** The loop stops when the model returns `COMPLETE` five times in a row (`skips >= 5`), or after `max_calls = 10` iterations, whichever comes first.
3. **Fault tolerance.** The entire incremental loop is wrapped in a `try/except`. If any error occurs, the module falls back to the observations accumulated so far and proceeds to summarization.
4. **Final summarization.** Regardless of how many batches were processed, `ObservationSummarizer` condenses the accumulated observations into the final 2–3 sentence summary.

---

## Process Flow

The sequence of interactions between the orchestration function, the LM, and the signatures is shown below.

```mermaid
sequenceDiagram
    participant Caller as GroundedProposer
    participant CDS as create_dataset_summary
    participant Settings as dspy.settings
    participant LM as prompt_model
    participant Sig as Signatures

    Caller->>CDS: create_dataset_summary(trainset, batch_size, prompt_model)
    CDS->>Settings: context(lm=prompt_model)
    CDS->>Sig: Predict(DatasetDescriptor)(examples=...)
    Sig->>LM: generate observations
    LM-->>CDS: initial observations

    loop For each subsequent batch (max 10 calls)
        CDS->>Settings: context(lm=prompt_model)
        CDS->>Sig: Predict(DatasetDescriptorWithPriorObservations)(...)
        Sig->>LM: generate new observations
        LM-->>CDS: observations or "COMPLETE"
        alt Output is COMPLETE
            CDS->>CDS: skips += 1 (break if skips >= 5)
        else New observations
            CDS->>CDS: observations += output
        end
    end

    CDS->>Settings: context(lm=prompt_model)
    CDS->>Sig: Predict(ObservationSummarizer)(observations=...)
    Sig->>LM: summarize
    LM-->>CDS: summary
    CDS->>CDS: strip_prefix(summary.summary)
    CDS-->>Caller: final summary string
```

---

## Component Interaction Details

### Model Scoping via `dspy.settings.context`

Every `dspy.Predict` call is wrapped in `with dspy.settings.context(lm=prompt_model):`. This ensures the specified `prompt_model` is used for the call without mutating the global LM configuration. If `prompt_model` is `None`, the function falls back to `dspy.settings.lm`. See [dsp_utils_settings](dsp_utils_settings.md) for the thread-local override semantics of `Settings.context`.

### Deterministic Example Representation

`order_input_keys_in_string` uses a regular expression to find `input_keys={...}` substrings within an `Example`'s `repr()` and sorts the keys alphabetically. This produces a stable, deterministic string representation of the examples, which is important for reproducibility when the same dataset is summarized across multiple runs.

### Output Cleaning with `strip_prefix`

The final summary is passed through `strip_prefix` (from `dspy/propose/utils.py`), which strips leading role prefixes such as `"Summary:"` and surrounding quotation marks. This normalizes the LM output into a clean, directly usable string.

---

## Integration with the Grounded Proposer

The `GroundedProposer` is the primary consumer of this module. During its initialization:

```python
self.data_summary = None
if self.use_dataset_summary:
    try:
        self.data_summary = create_dataset_summary(
            trainset=trainset,
            view_data_batch_size=view_data_batch_size,
            prompt_model=prompt_model,
        )
    except Exception as e:
        print(f"Error getting data summary: {e}.\n\nRunning without data aware proposer.")
        self.use_dataset_summary = False
```

The resulting `data_summary` string is later passed into `GenerateModuleInstruction` as the `data_summary` argument, where it grounds the proposed instructions in the actual dataset characteristics. If summary generation fails, the proposer gracefully degrades to a non-data-aware mode.

For full details on how the summary is consumed, see [propose_grounded_proposer](propose_grounded_proposer.md).

---

## Error Handling and Robustness

| Scenario | Behavior |
|----------|----------|
| `prompt_model` is `None` | Falls back to `dspy.settings.lm`. |
| Exception during incremental observation loop | Caught; the module proceeds with observations accumulated so far. |
| Model repeatedly returns `COMPLETE` | Loop breaks after 5 consecutive `COMPLETE` responses. |
| Excessive batches | Loop breaks after `max_calls = 10` iterations. |
| `log_file` provided | Writes progress markers (`PRODUCING DATASET SUMMARY`, per-round observations, and the final summary). |

---

## Related Modules

- [propose_grounded_proposer](propose_grounded_proposer.md) — the primary consumer of the dataset summary.
- [propose_proposer_base](propose_proposer_base.md) — the abstract `Proposer` base class.
- [signatures](signatures.md) — the declarative signature system used by all three components.
- [predict_core](predict_core.md) — the `Predict` module used to execute signatures.
- [dsp_utils_settings](dsp_utils_settings.md) — the `Settings` singleton providing `context(lm=...)`.
