# Evaluate Auto Metrics

## Introduction

The `evaluate_auto_metrics` module provides a collection of **LLM-as-a-judge** metric functions for automatically evaluating the quality of a DSPy program's responses. Unlike traditional exact-match or string-overlap metrics, these metrics use a language model (via `ChainOfThought`) to reason about the semantic relationship between a system's response and reference material (ground truth or retrieved context).

The module exposes two ready-to-use metric `Module` classes:

- **`SemanticF1`** — computes an F1 score over semantic recall and precision against a ground-truth response.
- **`CompleteAndGrounded`** — computes an F1 score combining answer completeness (vs. ground truth) and groundedness (vs. retrieved context).

These metrics are designed to be passed directly as the `metric` argument to the [`Evaluate`](evaluate_program_evaluation.md) class, enabling fully automated, reference-based and reference-free evaluation of generative programs.

---

## Architecture Overview

The module is built on top of three core DSPy abstractions:

1. **`Signature`** — declaratively defines the input/output contract for each judging task.
2. **`ChainOfThought`** — wraps a signature to elicit step-by-step reasoning from the LM before producing the final numeric outputs.
3. **`Module`** — the base class that makes each metric callable as a DSPy program.

```mermaid
graph TD
    subgraph "evaluate_auto_metrics"
        SF1[SemanticF1]
        CG[CompleteAndGrounded]
    end

    subgraph "Signatures"
        SRP[SemanticRecallPrecision]
        DSRP[DecompositionalSemanticRecallPrecision]
        AC[AnswerCompleteness]
        AG[AnswerGroundedness]
    end

    subgraph "Core DSPy"
        CoT[ChainOfThought]
        Mod[Module]
        Sig[Signature]
    end

    SF1 -->|uses| CoT
    CG -->|uses| CoT
    SF1 -->|decompositional=True| DSRP
    SF1 -->|decompositional=False| SRP
    CG -->|completeness_module| AC
    CG -->|groundedness_module| AG

    CoT --> Mod
    SRP --> Sig
    DSRP --> Sig
    AC --> Sig
    AG --> Sig

    SF1 --> Mod
    CG --> Mod
```

---

## Component Reference

### Metric Modules

#### `SemanticF1`

A `Module` that computes the semantic F1 score between a system response and a ground-truth response.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `threshold` | `float` | `0.66` | Score threshold used when the metric is invoked in "trace" mode (e.g., during optimization). |
| `decompositional` | `bool` | `False` | When `True`, uses `DecompositionalSemanticRecallPrecision` to explicitly enumerate key ideas before scoring. |

**`forward(example, pred, trace=None)`**

1. Calls the underlying `ChainOfThought` module with `question`, `ground_truth` (from `example.response`), and `system_response` (from `pred.response`).
2. Computes `f1_score(scores.precision, scores.recall)`.
3. Returns the raw F1 score when `trace is None`, otherwise returns a boolean `score >= threshold`.

#### `CompleteAndGrounded`

A `Module` that combines **completeness** (coverage of ground truth) and **groundedness** (support by retrieved context) into a single F1 score.

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `threshold` | `float` | `0.66` | Score threshold used in "trace" mode. |

Internally it holds two `ChainOfThought` modules: `completeness_module` (over `AnswerCompleteness`) and `groundedness_module` (over `AnswerGroundedness`).

**`forward(example, pred, trace=None)`**

1. Computes `completeness` using `example.question`, `example.response`, and `pred.response`.
2. Computes `groundedness` using `example.question`, `pred.context`, and `pred.response`.
3. Computes `f1_score(groundedness.groundedness, completeness.completeness)`.
4. Returns the raw score when `trace is None`, otherwise a boolean `score >= threshold`.

> **Note:** `CompleteAndGrounded` requires the prediction to expose a `context` attribute (typically populated by a retrieval-augmented program).

### Signatures

Each signature defines the LM judging task. All are subclasses of [`Signature`](signatures.md).

| Signature | Inputs | Outputs | Purpose |
|-----------|--------|---------|---------|
| `SemanticRecallPrecision` | `question`, `ground_truth`, `system_response` | `recall`, `precision` | Directly score recall/precision of the response vs. ground truth. |
| `DecompositionalSemanticRecallPrecision` | `question`, `ground_truth`, `system_response` | `ground_truth_key_ideas`, `system_response_key_ideas`, `discussion`, `recall`, `precision` | Enumerate key ideas first, then score recall/precision. |
| `AnswerCompleteness` | `question`, `ground_truth`, `system_response` | `ground_truth_key_ideas`, `system_response_key_ideas`, `discussion`, `completeness` | Estimate how much of the ground truth is covered. |
| `AnswerGroundedness` | `question`, `retrieved_context`, `system_response` | `system_response_claims`, `discussion`, `groundedness` | Estimate how much of the response is supported by retrieved context. |

### Helper Function

#### `f1_score(precision, recall)`

Computes the harmonic mean of precision and recall, with both inputs clamped to the `[0.0, 1.0]` range. Returns `0.0` when `precision + recall == 0`.

```python
def f1_score(precision, recall):
    precision, recall = max(0.0, min(1.0, precision)), max(0.0, min(1.0, recall))
    return 0.0 if precision + recall == 0 else 2 * (precision * recall) / (precision + recall)
```

---

## Data Flow

The following diagram illustrates how a metric is invoked during evaluation, from the `Evaluate` driver down to the LM judge.

```mermaid
sequenceDiagram
    participant Eval as Evaluate
    participant Metric as SemanticF1 / CompleteAndGrounded
    participant CoT as ChainOfThought
    participant LM as Language Model

    Eval->>Metric: metric(example, prediction)
    Metric->>CoT: forward(question, ground_truth, system_response)
    CoT->>LM: prompt with reasoning step
    LM-->>CoT: reasoning + numeric outputs
    CoT-->>Metric: scores (recall/precision or completeness/groundedness)
    Metric->>Metric: f1_score(...)
    Metric-->>Eval: float score (or bool if trace)
```

### Trace vs. Non-Trace Mode

```mermaid
flowchart TD
    A[forward called] --> B{trace is None?}
    B -->|Yes| C[Return raw float score]
    B -->|No| D{score >= threshold?}
    D -->|Yes| E[Return True]
    D -->|No| F[Return False]
```

- **Non-trace mode** (`trace is None`): returns the continuous F1 score. Used for reporting/aggregation by `Evaluate`.
- **Trace mode** (`trace` provided): returns a boolean pass/fail. Used by optimizers (e.g., bootstrapping) that need a binary signal.

---

## Integration with the Evaluation Pipeline

The metrics in this module are consumed by the [`Evaluate`](evaluate_program_evaluation.md) class. The typical workflow is:

```mermaid
graph LR
    Devset[devset: list of Example] --> Eval[Evaluate]
    Program[DSPy Program] --> Eval
    Metric[SemanticF1 / CompleteAndGrounded] --> Eval
    Eval --> Result[EvaluationResult: score + results]
```

```python
from dspy.evaluate import Evaluate
from dspy.evaluate.auto_evaluation import SemanticF1

metric = SemanticF1(threshold=0.66)
evaluator = Evaluate(devset=devset, metric=metric, display_progress=True)
result = evaluator(program)
print(result.score)  # e.g., 67.30
```

The `Evaluate` class calls `metric(example, prediction)` for each item in the devset and aggregates the returned scores. See [evaluate_program_evaluation.md](evaluate_program_evaluation.md) for details on parallel execution, error handling, and result table display.

---

## Dependencies

```mermaid
graph TD
    A[evaluate_auto_metrics] --> B[predict_chain_of_thought]
    A --> C[primitives_module]
    A --> D[signatures]
    B --> C
    B --> D
    C --> D
```

| Dependency | Module Documentation | Usage |
|------------|----------------------|-------|
| `ChainOfThought` | [predict.md](predict.md) | Wraps signatures to add step-by-step reasoning. |
| `Module` | [primitives.md](primitives.md) | Base class providing callable/async/batch behavior. |
| `Signature`, `InputField`, `OutputField` | [signatures.md](signatures.md) | Declarative I/O contracts for judging tasks. |
| `Evaluate`, `EvaluationResult` | [evaluate_program_evaluation.md](evaluate_program_evaluation.md) | Consumer of these metrics. |

---

## Design Notes

- **LLM-as-a-judge:** All scoring is delegated to a language model, making the metrics robust to paraphrasing and semantic equivalence that exact-match metrics would miss.
- **Reasoning-first:** Every signature is wrapped in `ChainOfThought`, forcing the LM to reason (and, for decompositional variants, enumerate key ideas) before emitting numeric scores. This improves scoring reliability.
- **Threshold semantics:** The `threshold` parameter only affects trace mode. It does not influence the continuous score returned in normal evaluation.
- **Composability:** Because both metrics are `Module` subclasses, they can be nested, batched, or used as sub-components within larger DSPy programs.
