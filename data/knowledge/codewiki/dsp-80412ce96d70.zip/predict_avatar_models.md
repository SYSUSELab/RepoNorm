# predict_avatar_models

## Introduction

The `predict_avatar_models` module defines the core **data models** used by the DSPy Avatar agent framework. It provides lightweight, Pydantic-based structures that describe:

- **Tools** available to an agent (their name, description, and expected input type).
- **Actions** the agent decides to take (which tool to call and with what input).
- **ActionOutputs** — the recorded result of executing an action.

These models form the shared vocabulary between the [`Avatar`](predict_avatar_core.md) agent loop and the [`Actor`](predict_avatar_signatures.md) signature. The `Avatar` module constructs `Tool` instances, the `Actor` signature emits `Action` objects, and the agent loop records `ActionOutput` objects as it executes tools.

> **Source:** `dspy/predict/avatar/models.py`

---

## Module Position in the Avatar Subsystem

The Avatar subsystem is composed of three cooperating modules. `predict_avatar_models` is the foundational data layer that the other two depend on.

```mermaid
graph TD
    subgraph "predict_avatar"
        Core["predict_avatar_core<br/>(Avatar agent loop)"]
        Sig["predict_avatar_signatures<br/>(Actor signature)"]
        Models["predict_avatar_models<br/>(Tool, Action, ActionOutput)"]
    end

    Core -->|constructs Tool, reads Action, builds ActionOutput| Models
    Sig -->|emits Action| Models
    Core -->|invokes| Sig
```

- [`predict_avatar_core`](predict_avatar_core.md) — the `Avatar` module that orchestrates the iterative tool-use loop.
- [`predict_avatar_signatures`](predict_avatar_signatures.md) — the `Actor` signature that decides the next action.
- **`predict_avatar_models`** (this module) — the shared data structures.

---

## Core Components

### `Tool`

A Pydantic `BaseModel` describing a callable tool exposed to the agent.

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `tool` | `Any` | — | The underlying tool object (must expose a `.run(query)` method). `None` for the synthetic `Finish` tool. |
| `name` | `str` | — | Human-readable tool name used for selection and dispatch. |
| `desc` | `str \| None` | — | Description of what the tool does. |
| `input_type` | `str \| None` | `None` | Optional description of the valid input format. |

**String representation:** `Tool.__str__` renders as:

```
<name>(valid_input: <input_type>): <desc>
```

The `(valid_input: ...)` segment is omitted when `input_type` is `None`. `__repr__` delegates to `__str__`, so tools print cleanly in prompts and logs.

**Usage in the Avatar loop:** The `Avatar` module appends a synthetic `Finish` tool (`tool=None`, `name="Finish"`) to the user-supplied tool list. Tool names are passed to the `Actor` signature as the `tools` input field, and `_call_tool` dispatches by matching `tool.name` and invoking `tool.tool.run(tool_input_query)`.

---

### `Action`

A Pydantic `BaseModel` representing a single decision made by the agent: which tool to use and what input to pass.

| Field | Type | Description |
|-------|------|-------------|
| `tool_name` | `Any` | Name of the tool to use. |
| `tool_input_query` | `Any` | Query to pass as input to the tool. |

Both fields are required (`Field(...)`) and carry descriptive metadata used by DSPy's typed prediction machinery.

**Usage in the Avatar loop:** The `Actor` signature declares `action_1: Action` as an output field. On each iteration, the `Avatar` loop reads `action_{idx}` from the actor output, extracts `tool_name` and `tool_input_query`, and either dispatches the tool or terminates when `tool_name == "Finish"`. The `Action` type is also injected into dynamically appended signature fields via `_update_signature`.

---

### `ActionOutput`

A Pydantic `BaseModel` recording the result of executing an action. Unlike `Action`, all fields are plain `str`.

| Field | Type | Description |
|-------|------|-------------|
| `tool_name` | `str` | Name of the tool that was executed. |
| `tool_input_query` | `str` | The input query that was passed. |
| `tool_output` | `str` | The output returned by the tool. |

**Usage in the Avatar loop:** After each successful (non-`Finish`) tool call, the `Avatar` loop appends an `ActionOutput` to an `action_results` list. This list is returned as the `actions` attribute of the final `dspy.Prediction`, providing a full audit trail of the agent's tool-use trajectory.

---

## Data Flow

The following diagram shows how the three models flow through a single Avatar iteration.

```mermaid
sequenceDiagram
    participant User
    participant Avatar as Avatar (predict_avatar_core)
    participant Actor as Actor (predict_avatar_signatures)
    participant Tool as Tool (this module)
    participant Out as ActionOutput (this module)

    User->>Avatar: forward(**kwargs)
    Avatar->>Avatar: build args (goal, tools, inputs)
    loop until Finish or max_iters
        Avatar->>Actor: actor(**args)
        Actor-->>Avatar: action_{idx} (Action)
        alt tool_name != "Finish"
            Avatar->>Tool: _call_tool(name, query)
            Tool-->>Avatar: tool_output
            Avatar->>Out: ActionOutput(name, query, output)
            Avatar->>Avatar: _update_signature(idx)
        else tool_name == "Finish"
            Avatar->>Avatar: _update_signature(idx, omit_action=True)
        end
    end
    Avatar->>Actor: actor(**args)  # final answer
    Actor-->>Avatar: output fields
    Avatar-->>User: Prediction(outputs..., actions=[ActionOutput...])
```

---

## Component Interaction Overview

```mermaid
classDiagram
    class Tool {
        +Any tool
        +str name
        +str|None desc
        +str|None input_type
        +__str__() str
        +__repr__() str
    }

    class Action {
        +Any tool_name
        +Any tool_input_query
    }

    class ActionOutput {
        +str tool_name
        +str tool_input_query
        +str tool_output
    }

    class Avatar {
        +list~Tool~ tools
        +forward(**kwargs) Prediction
        +_call_tool(name, query) str
    }

    class Actor {
        +str goal
        +list~str~ tools
        +Action action_1
    }

    Avatar "1" o-- "*" Tool : holds
    Avatar ..> Action : reads
    Avatar ..> ActionOutput : creates
    Actor ..> Action : emits
```

---

## Design Notes

- **Pydantic-based:** All three models extend `pydantic.BaseModel`, giving automatic validation, serialization, and schema generation. This integrates cleanly with DSPy's typed prediction and adapter layers (see [`adapters`](adapters.md)).
- **`Any` vs `str` typing:** `Action` uses `Any` for its fields to remain flexible during LLM generation, while `ActionOutput` uses strict `str` since it records concrete executed results.
- **Synthetic `Finish` tool:** The `Finish` tool is a `Tool` with `tool=None`; the agent loop special-cases it to terminate rather than dispatch, so `_call_tool` is never invoked for it.
- **Audit trail:** `ActionOutput` instances are collected into the `actions` field of the returned `Prediction`, enabling downstream inspection, evaluation, or optimization (e.g., via [`teleprompt_avatar`](teleprompt_avatar.md)).

---

## Related Modules

| Module | Relationship |
|--------|--------------|
| [`predict_avatar_core`](predict_avatar_core.md) | The `Avatar` agent loop that consumes and produces these models. |
| [`predict_avatar_signatures`](predict_avatar_signatures.md) | The `Actor` signature that emits `Action` objects. |
| [`teleprompt_avatar`](teleprompt_avatar.md) | Optimizer that uses Avatar trajectories (including `ActionOutput` records) for feedback-based instruction tuning. |
| [`primitives`](primitives.md) | Provides `Prediction`, the container that carries `ActionOutput` results. |
| [`signatures`](signatures.md) | Provides the `Signature` base used by `Actor`. |
