# Clients Providers Module

## Introduction

The `clients_clients_providers` module defines the **provider abstraction layer** for DSPy's language model clients. It provides a unified interface for interacting with different LLM backends (OpenAI, Databricks, local SGLang servers, and Arbor) for three key capabilities:

1. **Inference server lifecycle management** — launching and killing model servers.
2. **Fine-tuning** — submitting supervised fine-tuning (SFT) jobs to remote or local providers.
3. **Reinforcement learning** — running GRPO-style reinforcement jobs against a provider.

The module is built around a small set of abstract base classes (`Provider`, `TrainingJob`, `ReinforceJob`) that concrete providers subclass to plug into DSPy's `LM` client. This design lets DSPy auto-discover the correct provider for a given model string and expose a consistent API regardless of the underlying backend.

> **Related documentation:** For the `LM` client that consumes these providers, see [clients_lm.md](clients_lm.md). For the data formats and helper utilities used by providers, see [clients_finetune.md](clients_finetune.md).

---

## Architecture Overview

The module follows a classic **abstract factory + strategy** pattern. The `Provider` base class defines the contract, and each concrete provider implements backend-specific behavior.

```mermaid
graph TD
    subgraph "Base Abstractions (provider.py)"
        Provider["Provider<br/>(abstract base)"]
        TrainingJob["TrainingJob<br/>(Future subclass)"]
        ReinforceJob["ReinforceJob<br/>(abstract base)"]
    end

    subgraph "Concrete Providers"
        OpenAIProvider["OpenAIProvider"]
        DatabricksProvider["DatabricksProvider"]
        LocalProvider["LocalProvider"]
        ArborProvider["ArborProvider"]
    end

    subgraph "Concrete Jobs"
        TrainingJobOpenAI["TrainingJobOpenAI"]
        TrainingJobDatabricks["TrainingJobDatabricks"]
        ArborTrainingJob["ArborTrainingJob"]
        ArborReinforceJob["ArborReinforceJob"]
    end

    Provider --> OpenAIProvider
    Provider --> DatabricksProvider
    Provider --> LocalProvider
    Provider --> ArborProvider

    TrainingJob --> TrainingJobOpenAI
    TrainingJob --> TrainingJobDatabricks
    TrainingJob --> ArborTrainingJob
    ReinforceJob --> ArborReinforceJob

    OpenAIProvider -.uses.-> TrainingJobOpenAI
    DatabricksProvider -.uses.-> TrainingJobDatabricks
    LocalProvider -.uses.-> TrainingJob
    ArborProvider -.uses.-> ArborTrainingJob
    ArborProvider -.uses.-> ArborReinforceJob
```

### Provider Capability Matrix

Each provider advertises its capabilities through the `finetunable` and `reinforceable` flags set in its constructor.

| Provider | `finetunable` | `reinforceable` | Auto-discovered | Backend |
|---|---|---|---|---|
| `Provider` (base) | `False` | `False` | — | Generic / LiteLLM |
| `OpenAIProvider` | `True` | `False` | ✅ | OpenAI API |
| `DatabricksProvider` | `True` | `False` | ❌ | Databricks Model Serving |
| `LocalProvider` | `True` | `False` | ❌ | Local SGLang server |
| `ArborProvider` | `True` | `True` | ❌ | Arbor server |

---

## Core Components

### `Provider` (base class)

The abstract base class that all providers extend. It defines the interface consumed by `dspy.clients.lm.LM`.

**Key attributes:**

- `finetunable` — whether the provider supports fine-tuning.
- `reinforceable` — whether the provider supports reinforcement learning.
- `TrainingJob` — the `TrainingJob` subclass to instantiate for fine-tuning.
- `ReinforceJob` — the `ReinforceJob` subclass to instantiate for RL.

**Key methods:**

| Method | Purpose |
|---|---|
| `is_provider_model(model)` *(static)* | Returns `True` if the provider can handle the given model string. Used for auto-discovery. |
| `launch(lm, launch_kwargs)` *(static)* | Starts an inference server for the model. Must be resilient to being called when a server is already running. |
| `kill(lm, launch_kwargs)` *(static)* | Stops a running inference server. Must be resilient to being called when no server is running. |
| `finetune(job, model, train_data, train_data_format, train_kwargs)` *(static)* | Runs a fine-tuning job and returns the resulting model identifier. |

> **Design note:** `launch` and `kill` are intentionally idempotent/resilient — they may be called even when there is no launched LM to kill, or when an LM is already launched.

### `TrainingJob`

A subclass of `concurrent.futures.Future` that represents an asynchronous fine-tuning job. It carries the training metadata and is returned to the caller immediately while the actual training runs in a background thread.

**Attributes:**

- `thread` — the background thread executing the job.
- `model` — the model being fine-tuned.
- `train_data` — the training examples.
- `train_data_format` — a `TrainDataFormat` value.
- `train_kwargs` — provider-specific training hyperparameters.

**Methods:**

- `cancel()` — cancels the job. Subclasses should override to perform provider-specific cleanup (e.g., deleting uploaded files) and then call `super().cancel()`.
- `status()` *(abstract)* — returns the current `TrainingStatus`.

### `ReinforceJob`

The abstract base class for reinforcement learning jobs (currently only implemented by Arbor). It manages a stateful RL loop with checkpoints.

**Attributes:**

- `lm` — the `LM` instance being reinforced.
- `train_kwargs` — RL hyperparameters.
- `checkpoints` — a mapping of checkpoint names to metadata.
- `last_checkpoint` — the most recent checkpoint name.

**Abstract methods:** `initialize()`, `step()`, `terminate()`, `update_model()`, `save_checkpoint()`, plus `cancel()` and `status()`.

---

## Concrete Providers

### `OpenAIProvider`

Handles OpenAI models and fine-tuned OpenAI models. It is the only provider that participates in **auto-discovery** via `is_provider_model`.

**Model detection** (`is_provider_model`):
1. Strips the `openai/` prefix.
2. Checks membership in the hard-coded `_OPENAI_MODELS` list.
3. Matches fine-tuned models using the regex `ft:([^:]+):` and verifies the base model is known.

**Fine-tuning flow** (`finetune`):

```mermaid
sequenceDiagram
    participant LM as LM.finetune()
    participant P as OpenAIProvider
    participant API as OpenAI API

    LM->>P: finetune(job, model, train_data, ...)
    P->>P: validate_data_format()
    P->>P: save_data() → local .jsonl
    P->>API: files.create(purpose="fine-tune")
    API-->>P: provider_file_id
    P->>API: fine_tuning.jobs.create()
    API-->>P: provider_job_id
    P->>P: wait_for_job() (poll events)
    P->>API: fine_tuning.jobs.retrieve()
    API-->>P: fine_tuned_model
    P-->>LM: fine-tuned model name
```

**Supported data formats:** `CHAT`, `COMPLETION`.

**Key helper methods:** `does_job_exist`, `does_file_exist`, `is_terminal_training_status`, `get_training_status`, `validate_data_format`, `upload_data`, `_start_remote_training`, `wait_for_job`, `get_trained_model`.

### `DatabricksProvider`

Handles fine-tuning and deployment on Databricks. It does **not** participate in auto-discovery (Databricks is not a proprietary model provider).

**Fine-tuning flow** (`finetune`):
1. Normalizes `train_data_format` (accepts string `"chat"`/`"completion"`).
2. Requires `train_data_path` and `register_to` in `train_kwargs`.
3. Uploads data to Databricks Unity Catalog via `upload_data`.
4. Creates a run via `databricks.model_training.foundation_model.create`.
5. Polls until the run status is `Completed` (or raises on `Failed`).
6. Optionally deploys the model via `deploy_finetuned_model` (unless `skip_deploy` is set).
7. Returns `databricks/<endpoint_name>`.

**Deployment** (`deploy_finetuned_model`):
- Checks model optimization eligibility.
- Creates or updates a serving endpoint.
- Polls the endpoint with a test completion until ready (up to `deploy_timeout` seconds).

**Module-level helpers:**
- `_get_workspace_client()` — lazily imports and instantiates `WorkspaceClient`.
- `_create_directory_in_databricks_unity_catalog()` — validates the `/Volumes/<catalog>/<schema>/<volume>/...` path and creates the directory.
- `_save_data_to_local_file()` — writes validated data to a local `.jsonl` file.
- `_validate_chat_data()` / `_validate_completion_data()` — validate the structure of training examples.

> **Dependency note:** Requires the `databricks-sdk` and `databricks_genai` packages.

### `LocalProvider`

Manages a local **SGLang** inference server and local SFT training.

**Server lifecycle:**
- `launch()` — spawns `python -m sglang.launch_server` on a free port, tails logs in a background thread, waits for readiness via `wait_for_server`, and attaches `api_base`, `api_key`, `get_logs`, `process`, and `thread` to the `LM`.
- `kill()` — terminates the process via `sglang.utils.terminate_process` and cleans up attributes.

**Fine-tuning** (`finetune`):
- Only supports `TrainDataFormat.CHAT`.
- Saves data, creates an output directory, and calls `train_sft_locally`.
- Returns `openai/local:<output_dir>`.

**Module-level helpers:**
- `create_output_dir()` — builds a unique output directory name.
- `train_sft_locally()` — loads the model/tokenizer, sets up chat format, tokenizes the dataset, optionally configures LoRA (PEFT), runs `SFTTrainer`, and merges PEFT weights.
- `get_free_port()` — finds an available TCP port.
- `wait_for_server()` — polls `/v1/models` until the server responds.
- `encode_sft_example()` — tokenizes a chat example and masks non-assistant tokens with `-100` for loss computation.

> **Dependency note:** Requires `sglang` for launching, and `torch`, `transformers`, `trl`, and optionally `peft` for local training.

### `ArborProvider`

The most feature-complete provider, supporting both fine-tuning and reinforcement learning. It communicates with an Arbor server over HTTP and via the OpenAI SDK (with a redirected `base_url`).

**Capabilities:** `finetunable = True`, `reinforceable = True`.

**Server lifecycle:**
- `launch()` — POSTs to `{api_base}chat/launch`.
- `kill()` — POSTs to `{api_base}chat/kill`.

**Model prefix handling:**
- `_remove_provider_prefix()` — strips `openai/` and `arbor:` prefixes.
- `_add_provider_prefix()` — ensures the `openai/arbor:` prefix.
- `_get_arbor_base_api()` — reads `dspy.settings.arbor_api_base`.

**Fine-tuning** (`finetune`): Mirrors the OpenAI flow (validate → save → upload → start → wait → retrieve), but redirects `openai.base_url` to the Arbor API for each call. Supports `CHAT`, `COMPLETION`, and `GRPO_CHAT` formats.

**Reinforcement learning** (`ArborReinforceJob`):

```mermaid
stateDiagram-v2
    [*] --> initialize
    initialize --> step: POST /fine_tuning/grpo/initialize
    step --> step: POST /fine_tuning/grpo/step (per group)
    step --> save_checkpoint: POST /fine_tuning/grpo/checkpoint
    save_checkpoint --> step
    step --> terminate: POST /fine_tuning/grpo/terminate
    terminate --> [*]
```

- `initialize()` — sends all GRPO hyperparameters (temperature, beta, num_iterations, etc.) to the server and updates `lm.model`.
- `step()` — runs a GRPO step for each group in `train_data` (requires `GRPO_CHAT` format).
- `save_checkpoint()` — records a checkpoint and its score.
- `terminate()` — finalizes the RL run and updates `lm.model`.

`GRPOTrainKwargs` is a `TypedDict` requiring `num_generations`.

---

## Component Interaction

The following diagram shows how the provider layer integrates with the `LM` client and the fine-tuning utilities.

```mermaid
graph LR
    subgraph "dspy.clients.lm"
        LM["LM"]
    end

    subgraph "clients_clients_providers"
        Provider["Provider"]
        OpenAIProvider["OpenAIProvider"]
        DatabricksProvider["DatabricksProvider"]
        LocalProvider["LocalProvider"]
        ArborProvider["ArborProvider"]
    end

    subgraph "clients_finetune"
        TrainDataFormat["TrainDataFormat"]
        TrainingStatus["TrainingStatus"]
        save_data["save_data()"]
    end

    LM -->|"infer_provider()"| Provider
    LM -->|"launch() / kill()"| Provider
    LM -->|"finetune()"| Provider
    LM -->|"reinforce()"| Provider

    Provider --> OpenAIProvider
    Provider --> DatabricksProvider
    Provider --> LocalProvider
    Provider --> ArborProvider

    OpenAIProvider --> TrainDataFormat
    OpenAIProvider --> TrainingStatus
    OpenAIProvider --> save_data
    DatabricksProvider --> TrainDataFormat
    LocalProvider --> TrainDataFormat
    ArborProvider --> TrainDataFormat
    ArborProvider --> TrainingStatus
```

### How `LM` Uses Providers

The `LM` class (see [clients_lm.md](clients_lm.md)) delegates provider-specific operations:

- **Provider inference** — `LM.infer_provider()` calls `OpenAIProvider.is_provider_model()` and falls back to the base `Provider`.
- **Launch/kill** — `LM.launch()` and `LM.kill()` forward to `self.provider.launch/kill`.
- **Fine-tuning** — `LM.finetune()` asserts `provider.finetunable`, creates a `provider.TrainingJob`, and runs `_run_finetune_job` in a background thread. On success, it copies the LM with the new model name and sets the job result.
- **Reinforcement** — `LM.reinforce()` asserts `provider.reinforceable`, instantiates `provider.ReinforceJob`, and calls `initialize()`.

---

## Data Flow: Fine-Tuning End-to-End

```mermaid
flowchart TD
    A["User calls LM.finetune(train_data, format, kwargs)"] --> B{"provider.finetunable?"}
    B -- No --> C["AssertionError"]
    B -- Yes --> D["Create provider.TrainingJob"]
    D --> E["Start background thread"]
    E --> F["provider.finetune(job, ...)"]
    F --> G["validate_data_format()"]
    G --> H["save_data() → local .jsonl"]
    H --> I{"Provider type"}
    I -- OpenAI --> J["Upload + create job + poll"]
    I -- Databricks --> K["Upload to Unity Catalog + create run + deploy"]
    I -- Local --> L["train_sft_locally()"]
    I -- Arbor --> M["Upload + create job + poll"]
    J --> N["Return fine-tuned model name"]
    K --> N
    L --> N
    M --> N
    N --> O["LM.copy(model=new_model)"]
    O --> P["job.set_result(new_lm)"]
```

---

## Design Patterns & Conventions

1. **Static methods for provider operations** — `is_provider_model`, `launch`, `kill`, and `finetune` are static methods, allowing providers to be used without instantiation for discovery and lifecycle operations.

2. **Future-based async jobs** — `TrainingJob` extends `Future`, so callers can `await` or poll the job while training runs in a background thread.

3. **Resilient lifecycle methods** — `launch`/`kill` are designed to be safely called in any state.

4. **Provider prefix conventions** — Model strings use prefixes like `openai/`, `local:`, `huggingface/`, and `arbor:` to route to the correct provider. Each provider implements its own prefix stripping/adding logic.

5. **Lazy imports for optional dependencies** — Heavy or optional dependencies (`sglang`, `databricks.sdk`, `torch`, `transformers`, `trl`, `peft`) are imported inside methods, with helpful `ImportError` messages guiding installation.

6. **Data format validation** — Each provider validates that the requested `TrainDataFormat` is supported before proceeding.

---

## Extension Guide: Adding a New Provider

To add a new provider:

1. **Subclass `Provider`** and set `finetunable`/`reinforceable` flags in `__init__`.
2. **Implement `is_provider_model`** (static) if the provider should be auto-discovered.
3. **Implement `launch`/`kill`** (static) if the provider manages inference servers.
4. **Implement `finetune`** (static) if `finetunable` is `True`.
5. **Create a `TrainingJob` subclass** if custom cancellation/status logic is needed, and assign it to `self.TrainingJob`.
6. **Create a `ReinforceJob` subclass** if `reinforceable` is `True`, and assign it to `self.ReinforceJob`.

---

## Summary

The `clients_clients_providers` module is the pluggable backend layer of DSPy's client system. Its abstract `Provider`, `TrainingJob`, and `ReinforceJob` classes define a consistent contract, while concrete providers (`OpenAIProvider`, `DatabricksProvider`, `LocalProvider`, `ArborProvider`) implement backend-specific inference, fine-tuning, and reinforcement learning. The `LM` client consumes this layer to provide a uniform experience across diverse LLM backends.

**Related modules:**
- [clients_lm.md](clients_lm.md) — the `LM` and `BaseLM` clients that consume providers.
- [clients_finetune.md](clients_finetune.md) — data formats (`TrainDataFormat`, `TrainingStatus`, `GRPOChatData`) and helper utilities (`save_data`, `get_finetune_directory`).
- [clients_cache.md](clients_cache.md) — response caching used by the `LM` client.
