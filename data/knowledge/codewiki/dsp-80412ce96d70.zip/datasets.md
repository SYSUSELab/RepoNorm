# Datasets

## Overview

The `datasets` module provides a collection of ready-to-use datasets and data-loading utilities for DSPy. It serves two primary purposes:

1. **Dataset loading utilities** — a flexible `DataLoader` that converts data from many sources (HuggingFace Hub, CSV, JSON, Parquet, Pandas, retrieval modules) into lists of `dspy.Example` objects.
2. **Built-in benchmark datasets** — curated, pre-processed datasets (GSM8K, HotPotQA, MATH, Colors, AlfWorld) that are commonly used for evaluating and optimizing DSPy programs.

All datasets ultimately produce `dspy.Example` objects (see [primitives.md](primitives.md)), which are the universal data container used throughout DSPy for inputs, labels, and demonstrations.

## Architecture

The module is organized around a base `Dataset` abstraction that handles train/dev/test splitting, shuffling, and seeding. Concrete datasets either subclass `Dataset` (Colors, HotPotQA) or implement a lightweight standalone interface (GSM8K, MATH, AlfWorld). The `DataLoader` is a separate utility class that does not subclass `Dataset` in practice (it overrides `__init__` to do nothing) and focuses purely on converting external data sources into `dspy.Example` lists.

```mermaid
graph TD
    subgraph "datasets module"
        Dataset["Dataset (base)"]
        DataLoader["DataLoader"]
        Colors["Colors"]
        HotPotQA["HotPotQA"]
        GSM8K["GSM8K"]
        MATH["MATH"]
        AlfWorld["AlfWorld"]
    end

    Dataset --> Colors
    Dataset --> HotPotQA
    DataLoader -.->|"produces"| Example["dspy.Example"]
    Colors --> Example
    HotPotQA --> Example
    GSM8K --> Example
    MATH --> Example
    AlfWorld --> Example

    DataLoader -->|"loads from"| HF["HuggingFace Hub"]
    DataLoader -->|"loads from"| Files["CSV / JSON / Parquet"]
    DataLoader -->|"loads from"| Pandas["Pandas DataFrame"]
    DataLoader -->|"loads from"| RM["Retrieval Module"]

    GSM8K -->|"loads from"| HF
    HotPotQA -->|"loads from"| HF
    MATH -->|"loads from"| HF

    Example --> Primitives["primitives module"]
    Dataset --> Utils["dsp_utils module (dotdict)"]
```

## Sub-modules

The module is split into the following documented sub-modules:

| Sub-module | Description | Documentation |
| --- | --- | --- |
| **Core Dataset & DataLoader** | The `Dataset` base class (splitting, seeding, shuffling) and the `DataLoader` utility for ingesting external data sources. | [datasets_core.md](datasets_core.md) |
| **Built-in Benchmarks** | Ready-to-use benchmark datasets: `GSM8K`, `HotPotQA`, `MATH`, and `Colors`. | [datasets_benchmarks.md](datasets_benchmarks.md) |
| **AlfWorld** | The interactive AlfWorld environment dataset with a thread-pooled environment session manager. | [datasets_datasets_alfworld.md](datasets_datasets_alfworld.md) |

## High-Level Functionality

### Core Dataset & DataLoader
The `Dataset` base class provides the shared machinery for all datasets: lazy `train`/`dev`/`test` properties, deterministic shuffling via seeds, size-based sampling, and multi-seed preparation for cross-validation (`prepare_by_seed`). The `DataLoader` provides `from_huggingface`, `from_csv`, `from_json`, `from_parquet`, `from_pandas`, and `from_rm` methods, plus `sample` and `train_test_split` helpers. See [datasets_core.md](datasets_core.md) for details.

### Built-in Benchmarks
Four benchmark datasets are provided out of the box:
- **GSM8K** — grade-school math word problems with gold reasoning chains and a numeric-answer metric.
- **HotPotQA** — multi-hop question answering over Wikipedia, restricted to "hard" examples.
- **MATH** — competition mathematics problems with `\boxed{}` answer extraction and a math-equivalence metric.
- **Colors** — a synthetic color-naming dataset used for simple classification/instruction tasks.

See [datasets_benchmarks.md](datasets_benchmarks.md) for details.

### AlfWorld
`AlfWorld` wraps the interactive AlfWorld text environment, exposing a `trainset`/`devset` of environment indices and managing a pool of environment sessions. See [datasets_datasets_alfworld.md](datasets_datasets_alfworld.md) for details.

## Data Flow

```mermaid
sequenceDiagram
    participant User
    participant DataLoader
    participant HF as HuggingFace Hub
    participant Example as dspy.Example

    User->>DataLoader: from_huggingface("gsm8k", input_keys=("question",))
    DataLoader->>HF: load_dataset("gsm8k")
    HF-->>DataLoader: raw rows
    DataLoader->>Example: Example({...}).with_inputs("question")
    Example-->>DataLoader: dspy.Example
    DataLoader-->>User: list[dspy.Example] / Mapping[split, list]
```

## Relationship to Other Modules

- **[primitives.md](primitives.md)** — Every dataset produces `dspy.Example` objects, the core data primitive.
- **[dsp_utils.md](dsp_utils.md)** — The `Dataset.prepare_by_seed` helper uses `dotdict` for configuration.
- **[retrievers.md](retrievers.md)** — `DataLoader.from_rm` pulls examples from a configured retrieval module (`dspy.settings.rm`).
- **[evaluate.md](evaluate.md)** — Benchmark datasets (e.g., GSM8K, MATH) ship with metrics used by the evaluation module.
