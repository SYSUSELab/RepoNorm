# Utils Parallelization

## Introduction

The `utils_parallelization` module provides the concurrency and batching primitives that power DSPy's parallel execution model. It contains two complementary components:

- **`ParallelExecutor`** — a thread-pool based executor that runs a user function over a collection of items in parallel, with per-thread isolation of DSPy settings, error budgeting, straggler timeouts, and progress reporting.
- **`Unbatchify`** — the inverse of batching: it accepts single items from many callers, transparently groups them into batches, and dispatches them to a batch-processing function, returning each caller its individual result.

Together these utilities let DSPy programs scale evaluation, prediction, and optimization workloads across threads while preserving the thread-local configuration semantics defined by [`Settings`](dsp_utils.md).

---

## Module Architecture

```mermaid
graph TD
    subgraph "utils_parallelization"
        PE[ParallelExecutor]
        UB[Unbatchify]
    end

    subgraph "Consumers"
        PAR[Parallel<br/>predict/parallel.py]
        EVAL[Evaluate<br/>evaluate/evaluate.py]
        TP[Teleprompters<br/>teleprompt/*]
    end

    subgraph "Dependencies"
        SET[Settings<br/>dsp/utils/settings.py]
        UT[UsageTracker<br/>utils/usage_tracker.py]
        TQDM[tqdm]
        FUT[concurrent.futures]
    end

    PAR --> PE
    EVAL --> PE
    TP --> PE
    PE --> SET
    PE --> UT
    PE --> TQDM
    PE --> FUT
    UB --> FUT
```

The module sits at the bottom of the DSPy stack: it depends only on the settings singleton, the usage tracker, and the Python standard library. Higher-level modules such as [`predict`](predict_execution.md), [`evaluate`](evaluate.md), and [`teleprompt`](teleprompt_core.md) build on top of it.

---

## ParallelExecutor

`ParallelExecutor` is the workhorse for running a function across many inputs concurrently. It is designed to be safe regardless of whether `num_threads == 1` or `num_threads > 1`, always providing isolation between tasks.

### Constructor Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `num_threads` | `settings.num_threads` | Number of worker threads in the pool. |
| `max_errors` | `settings.max_errors` | Maximum number of errors tolerated before all jobs are cancelled. |
| `disable_progress_bar` | `False` | Suppresses the `tqdm` progress bar. |
| `provide_traceback` | `settings.provide_traceback` | When `True`, logs full tracebacks for failed items. |
| `compare_results` | `False` | Switches the progress bar to an "Average Metric" mode that sums the last element of each result. |
| `timeout` | `120` | Per-item straggler timeout in seconds. Set to `0` to disable. |
| `straggler_limit` | `3` | Only check for stragglers when this few futures remain outstanding. |

### Public API

```python
executor = ParallelExecutor(num_threads=8, max_errors=5)
results = executor.execute(function, data)
```

- **`execute(function, data)`** — clears stale `tqdm` instances, wraps the user function with error handling, and delegates to the internal parallel driver. Returns a list of results positionally aligned with `data`.

### Execution Flow

```mermaid
flowchart TD
    A[execute function, data] --> B[Clear tqdm instances]
    B --> C[_wrap_function]
    C --> D[_execute_parallel]
    D --> E[Capture parent thread-local overrides]
    E --> F[Submit all items to ThreadPoolExecutor]
    F --> G{Wait for futures<br/>FIRST_COMPLETED, 1s poll}
    G --> H[Collect results by index]
    H --> I[Update progress bar]
    I --> J{All done or cancelled?}
    J -- No --> K{Stragglers?<br/>not_done <= straggler_limit}
    K -- Yes --> L[Resubmit timed-out items<br/>at most once each]
    L --> G
    K -- No --> G
    J -- Yes --> M[Close progress bar]
    M --> N{Cancelled?}
    N -- Yes --> O[Raise Exception]
    N -- No --> P[Return results]
```

### Key Behaviors

#### Thread-Local Settings Isolation

Each worker thread receives a copy of the parent thread's `thread_local_overrides` (from [`Settings`](dsp_utils.md)). This means configuration set via `dspy.context(...)` in the spawning thread propagates into the worker threads, but changes made inside a worker do not leak back out. The original overrides are restored in a `finally` block via a context-variable token.

```python
original = thread_local_overrides.get()
token = thread_local_overrides.set({**original, **parent_overrides.copy()})
try:
    return index, function(item)
finally:
    thread_local_overrides.reset(token)
```

#### Usage Tracker Deep-Copy

When a `usage_tracker` is present in the parent overrides, it is **deep-copied** into each worker thread so that every thread accumulates its own usage data independently. This prevents cross-thread mutation races on the shared [`UsageTracker`](utils_usage_tracking.md) instance.

#### Error Budget and Cancellation

The wrapped function increments a shared `error_count` under a lock. Once `error_count >= max_errors`, the `cancel_jobs` event is set, causing:

1. Pending workers to short-circuit and return `None`.
2. The main loop to exit.
3. `execute` to raise `Exception("Execution cancelled due to errors or interruption.")`.

#### Straggler Timeouts

When only a few futures remain (`len(not_done) <= straggler_limit`), the executor checks how long each has been running. Any future exceeding `timeout` seconds is **resubmitted once** (tracked in the `resubmitted` set) with a fresh submission id. This guards against a single slow item blocking the whole batch.

#### Ctrl-C Handling

An `interrupt_manager` context manager installs a `SIGINT` handler (only in the main thread) that sets `cancel_jobs` and logs a warning before delegating to the original handler, enabling graceful cancellation.

#### Progress Reporting

Two modes are supported:

- **Default**: `Processed {n} / {total} examples`
- **`compare_results=True`**: `Average Metric: {sum:.2f} / {count} ({pct}%)`, where the sum is taken over the last element of each non-`None` result.

### Internal Methods

| Method | Purpose |
|--------|---------|
| `_wrap_function(user_function)` | Returns a `safe_func` that enforces cancellation and error accounting. |
| `_execute_parallel(function, data)` | Core driver: submits jobs, polls futures, handles stragglers, manages progress. |
| `_update_progress(pbar, nresults, ntotal)` | Formats and advances the progress bar. |

---

## Unbatchify

`Unbatchify` solves the opposite problem: many callers each want to process a **single** item, but the underlying function is far more efficient when given a **batch**. It transparently aggregates concurrent single-item calls into batches.

### Constructor Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `batch_fn` | *(required)* | Function taking `list[Any]` and returning `list[Any]` of equal length. |
| `max_batch_size` | `32` | Maximum items per batch. |
| `max_wait_time` | `0.1` | Maximum seconds to wait for a batch to fill. |

### Public API

```python
unbatch = Unbatchify(batch_fn=my_batch_function, max_batch_size=16)

# Thread-safe single-item call
result = unbatch(item)

# Context-manager usage
with Unbatchify(batch_fn=my_batch_function) as unbatch:
    result = unbatch(item)
```

- **`__call__(input_item)`** — enqueues the item with a `Future`, blocks on `future.result()`, and returns the individual output. Exceptions from `batch_fn` are re-raised to the caller.
- **`close()`** — signals the worker thread to stop and joins it. Pending queued items receive a `RuntimeError("Unbatchify is closed")`.
- **`__enter__` / `__exit__`** — enable context-manager usage with automatic cleanup.
- **`__del__`** — ensures the worker thread is terminated on garbage collection.

### Batching Flow

```mermaid
sequenceDiagram
    participant C1 as Caller 1
    participant C2 as Caller 2
    participant Q as input_queue
    participant W as Worker Thread
    participant BF as batch_fn

    C1->>Q: put(item1, future1)
    C2->>Q: put(item2, future2)
    W->>Q: get(timeout=max_wait_time)
    Q-->>W: item1, future1
    W->>Q: get(timeout=max_wait_time)
    Q-->>W: item2, future2
    Note over W: batch full or wait elapsed
    W->>BF: batch_fn([item1, item2])
    BF-->>W: [out1, out2]
    W->>C1: future1.set_result(out1)
    W->>C2: future2.set_result(out2)
```

### Worker Loop

The daemon worker thread runs continuously until `stop_event` is set:

1. Accumulate items from `input_queue` until `max_batch_size` is reached or `max_wait_time` elapses.
2. If a batch was collected, call `batch_fn(batch)` and distribute outputs to the corresponding futures via `zip(..., strict=False)`.
3. On exception, propagate the exception to **all** futures in the batch.
4. If no items were collected, sleep briefly (`0.01s`) to avoid busy-waiting.
5. On shutdown, drain the queue and fail remaining futures with a `RuntimeError`.

---

## Component Interaction

```mermaid
graph LR
    subgraph "ParallelExecutor"
        direction TB
        EX[execute] --> WF[_wrap_function]
        WF --> EP[_execute_parallel]
        EP --> WK[worker]
        WK --> TLS[thread_local_overrides]
        WK --> UT[UsageTracker deep-copy]
    end

    subgraph "Unbatchify"
        direction TB
        CALL[__call__] --> IQ[input_queue]
        IQ --> WT[_worker]
        WT --> BFN[batch_fn]
    end

    TLS -.->|reads/writes| SET[Settings singleton]
    UT -.->|isolated per thread| SET
```

Both components rely on the thread-local override mechanism of [`Settings`](dsp_utils.md). `ParallelExecutor` explicitly propagates overrides into worker threads, while `Unbatchify`'s worker thread inherits the overrides of whichever thread created the `Unbatchify` instance.

---

## Relationship to Higher-Level Modules

| Consumer | How it uses the module |
|----------|------------------------|
| [`Parallel`](predict_execution.md) | Wraps `ParallelExecutor` to run a module over a list of `(module, example)` pairs, supporting `Example`, `dict`, `list`, and `tuple` inputs. |
| [`Evaluate`](evaluate.md) | Uses `ParallelExecutor` with `compare_results=True` to compute aggregate metrics across a dataset. |
| [`teleprompt`](teleprompt_core.md) | Optimizers parallelize candidate evaluation and bootstrapping via the executor. |

The `Parallel` module is the canonical example of a consumer: it constructs a `ParallelExecutor`, defines a `process_pair` function that normalizes the various input types, and returns the positionally-aligned results.

---

## Design Considerations

- **Isolation over speed**: Even with `num_threads == 1`, `ParallelExecutor` still routes work through the thread pool to guarantee settings isolation, ensuring consistent behavior between serial and parallel runs.
- **Bounded error tolerance**: The `max_errors` budget prevents a single broken example from consuming all resources; cancellation is cooperative via the `cancel_jobs` event.
- **At-most-once resubmission**: Straggler resubmission is capped at one retry per item to avoid runaway duplication.
- **Graceful shutdown**: `executor.shutdown(wait=False)` avoids blocking on leftover tasks after cancellation.
- **Daemon worker**: `Unbatchify`'s worker is a daemon thread, so it never prevents interpreter exit, and `__del__`/`close()` provide explicit cleanup.

---

## See Also

- [Settings](dsp_utils.md) — thread-local configuration and override propagation.
- [UsageTracker](utils_usage_tracking.md) — per-thread usage accounting.
- [Parallel](predict_execution.md) — the primary consumer of `ParallelExecutor`.
- [Evaluate](evaluate.md) — metric aggregation using parallel execution.
