# DSP Retrieval (`dsp_retrieval`)

## Introduction

The `dsp_retrieval` module provides the low-level retrieval and text-processing primitives used across DSPy for **retrieval-augmented generation (RAG)**. It contains two distinct concerns:

1. **ColBERTv2 retrieval** — wrappers around the ColBERTv2 late-interaction retrieval model, supporting both a hosted HTTP server and a fully local index/reranker.
2. **DPR tokenization utilities** — a lightweight, dependency-free tokenizer derived from Facebook Research's Dense Passage Retrieval (DPR) implementation, used for answer matching, normalization, and span location.

These primitives are consumed by higher-level retrieval abstractions such as [`Retrieve`](retrievers.md) and [`Embeddings`](retrievers.md), and are wired into the global `dspy.settings.rm` retrieval-model slot.

## Purpose & Core Functionality

| Concern | Responsibility |
| --- | --- |
| Hosted ColBERTv2 | Query a remote ColBERTv2 server over HTTP (GET/POST) and return ranked passages. |
| Local ColBERTv2 | Build/load a local ColBERT index and search it, optionally with PID filtering. |
| Local Reranking | Score a fixed set of passages against a query using ColBERT late-interaction scoring. |
| DPR Tokenization | Tokenize, normalize, and locate answers within text for evaluation and matching. |

## Architecture Overview

```mermaid
graph TD
    subgraph dsp_retrieval["dsp_retrieval module"]
        CB2["ColBERTv2<br/>(hosted HTTP wrapper)"]
        CB2L["ColBERTv2RetrieverLocal<br/>(local index + search)"]
        CB2R["ColBERTv2RerankerLocal<br/>(local reranking)"]
        DPR["DPR Tokenizer<br/>(SimpleTokenizer / Tokens)"]
    end

    subgraph deps["Dependencies"]
        CACHE["Cache<br/>(request_cache)"]
        DOTDICT["dotdict"]
        REQ["requests"]
        COLBERT["colbert / faiss / torch"]
    end

    subgraph consumers["Consumers"]
        RETRIEVE["Retrieve"]
        EMB["Embeddings"]
        SETTINGS["dspy.settings.rm"]
    end

    CB2 --> REQ
    CB2 --> CACHE
    CB2 --> DOTDICT
    CB2L --> COLBERT
    CB2L --> DOTDICT
    CB2R --> COLBERT
    DPR --> DOTDICT

    RETRIEVE --> SETTINGS
    SETTINGS --> CB2
    SETTINGS --> CB2L
    EMB --> DPR
```

## Sub-modules

The module splits into two cohesive sub-modules:

### 1. ColBERTv2 Retrieval

Wraps the ColBERTv2 late-interaction retrieval model in three flavors: a hosted HTTP client (`ColBERTv2`), a local index builder/searcher (`ColBERTv2RetrieverLocal`), and a local reranker (`ColBERTv2RerankerLocal`). All results are returned as `dotdict` objects exposing `long_text`, `score`, and `pid`.

➡️ See [dsp_retrieval_colbertv2.md](dsp_retrieval_colbertv2.md) for full details.

### 2. DPR Tokenization

A self-contained tokenizer (`SimpleTokenizer`) and token container (`Tokens`) ported from Facebook Research's DPR, providing tokenization, n-gram extraction, entity grouping, answer matching (`has_answer`), and answer span location (`locate_answers`).

➡️ See [dsp_retrieval_dpr.md](dsp_retrieval_dpr.md) for full details.

## Data Flow

```mermaid
sequenceDiagram
    participant User
    participant Retrieve as Retrieve (retrievers)
    participant RM as dspy.settings.rm
    participant CB2 as ColBERTv2 / Local
    participant Cache as request_cache

    User->>Retrieve: forward(query, k)
    Retrieve->>RM: rm(query, k=k)
    RM->>CB2: __call__(query, k)
    CB2->>Cache: check cache (hosted only)
    Cache-->>CB2: cached / miss
    CB2-->>RM: list[dotdict] passages
    RM-->>Retrieve: passages
    Retrieve-->>User: Prediction(passages=[...])
```

## Integration with the Broader System

- **Retrieval models** (`ColBERTv2`, `ColBERTv2RetrieverLocal`) are assigned to `dspy.settings.rm` and invoked by the [`Retrieve`](retrievers.md) module.
- **Caching** for hosted requests is provided by the [`Cache`](clients_cache.md) module via the `@request_cache()` decorator.
- **`dotdict`** comes from the [`dsp_utils`](dsp_utils.md) module and gives dictionary results attribute-style access.
- **DPR tokenization** underpins answer-matching logic used by evaluation utilities such as [`SemanticF1`](evaluate.md).

## Key Design Notes

- The hosted `ColBERTv2` client enforces `k <= 100` for the public server and transparently caches responses.
- The local retriever requires a valid `ColBERTConfig` with `checkpoint` and `index_name`; it can either build a fresh index or load an existing one (`load_only=True`).
- The local reranker uses `bert-base-uncased` by default and returns a NumPy array of per-passage scores.
- The DPR tokenizer is intentionally minimal — it only tokenizes and warns if annotators are requested.
