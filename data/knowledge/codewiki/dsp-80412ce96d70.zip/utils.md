# utils

## Overview

The `utils` module is DSPy's cross-cutting toolbox. Unlike the higher-level modules (`predict`, `teleprompt`, `adapters`, etc.), it does not implement any part of the "programming with foundation models" workflow itself. Instead, it provides the **infrastructure primitives** that every other module depends on:

- **Observability** — a callback system for hooking into module/LM/adapter/tool/evaluate execution, and a controllable logging stream.
- **Concurrency** — a thread-pool executor with straggler handling and a dynamic batching helper.
- **Testing** — deterministic dummy language models and vectorizers for unit tests.
- **Accounting** — a usage tracker that aggregates token usage across LM calls.
- **Error types** — shared exception classes used across module boundaries.

Because these utilities are consumed everywhere, `utils` sits near the bottom of the dependency graph. It depends on a small set of core DSPy modules (`dsp_utils` for settings, `clients` for `LM`, `adapters` for formatting, `signatures` for fields) but is itself depended upon by nearly every other module.

## Architecture

The module is composed of seven files, grouped here into six documented sub-modules by responsibility:

```mermaid
graph TD
    subgraph utils
        Callback["callback.py<br/>BaseCallback, with_callbacks"]
        Dummies["dummies.py<br/>DummyLM, DummyVectorizer"]
        Exceptions["exceptions.py<br/>AdapterParseError"]
        Logging["logging_utils.py<br/>DSPyLoggingStream"]
        Parallelizer["parallelizer.py<br/>ParallelExecutor"]
        Unbatchify["unbatchify.py<br/>Unbatchify"]
        UsageTracker["usage_tracker.py<br/>UsageTracker"]
    end

    subgraph "Core DSPy dependencies"
        Settings["dsp_utils<br/>Settings"]
        LM["clients<br/>LM / BaseLM"]
        Adapters["adapters<br/>ChatAdapter"]
        Signatures["signatures<br/>OutputField"]
    end

    Callback -->|reads callbacks from| Settings
    Callback -->|dispatches to| LM
    Callback -->|dispatches to| Adapters
    Dummies -->|subclasses| LM
    Dummies -->|formats via| Adapters
    Dummies -->|uses| Signatures
    Parallelizer -->|propagates| Settings
    UsageTracker -->|stores in| Settings
```

### Component Relationships

```mermaid
graph LR
    subgraph "Execution path"
        Module["Module.forward()"]
        LM["LM.__call__()"]
        Adapter["Adapter.format()/parse()"]
        Tool["Tool.__call__()"]
        Evaluate["Evaluate.__call__()"]
    end

    subgraph "utils/callback.py"
        with_callbacks["with_callbacks (decorator)"]
        BaseCallback["BaseCallback"]
    end

    Module -.->|decorated with| with_callbacks
    LM -.->|decorated with| with_callbacks
    Adapter -.->|decorated with| with_callbacks
    Tool -.->|decorated with| with_callbacks
    Evaluate -.->|decorated with| with_callbacks
    with_callbacks -->|invokes handlers on| BaseCallback
```

## Sub-modules

| Sub-module | Description | Documentation |
| --- | --- | --- |
| **Callbacks** | The `BaseCallback` handler interface and the `with_callbacks` decorator that wires callbacks into module/LM/adapter/tool/evaluate execution. | [utils_callbacks.md](utils_callbacks.md) |
| **Dummies** | `DummyLM` and `DummyVectorizer` — deterministic stand-ins for LMs and embedding models used in tests. | [utils_dummies.md](utils_dummies.md) |
| **Parallelization** | `ParallelExecutor` (thread-pool execution with straggler timeouts) and `Unbatchify` (dynamic micro-batching). | [utils_parallelization.md](utils_parallelization.md) |
| **Usage Tracking** | `UsageTracker` and the `track_usage()` context manager for aggregating token usage. | [utils_usage_tracking.md](utils_usage_tracking.md) |
| **Logging** | `DSPyLoggingStream` and helpers to enable/disable and configure DSPy's event logging. | [utils_logging.md](utils_logging.md) |
| **Exceptions** | `AdapterParseError`, the shared exception raised when an adapter cannot parse an LM response. | [utils_exceptions.md](utils_exceptions.md) |

## High-Level Functionality

### Callbacks (`dspy/utils/callback.py`)

The callback system provides a uniform way to observe DSPy execution. `BaseCallback` defines paired `on_*_start` / `on_*_end` handlers for five kinds of operations: **modules**, **LMs**, **adapters** (split into `format` and `parse`), **tools**, and **evaluation**. The `with_callbacks` decorator wraps the relevant methods so that, when callbacks are configured (globally via `dspy.settings.configure(callbacks=[...])` or locally on an instance), the appropriate handlers fire before and after each call. A `ContextVar`-based `ACTIVE_CALL_ID` tracks the currently executing call so nested calls can be correlated.

See [utils_callbacks.md](utils_callbacks.md) for full details.

### Dummies (`dspy/utils/dummies.py`)

`DummyLM` is a subclass of `LM` that returns canned responses instead of calling a real model, supporting three modes: a list of answer dicts, a dict keyed by prompt content, and "follow examples" mode. `DummyVectorizer` is a lightweight n-gram hashing vectorizer used to build deterministic retrieval models for tests.

See [utils_dummies.md](utils_dummies.md) for full details.

### Parallelization (`dspy/utils/parallelizer.py`, `dspy/utils/unbatchify.py`)

`ParallelExecutor` runs a function over a dataset using a thread pool, isolating `dspy.settings` per thread, tracking errors against `max_errors`, and resubmitting stragglers that exceed a timeout. `Unbatchify` does the opposite: it accepts single items and dynamically groups them into batches for a batch-processing function, using a background worker thread and futures.

See [utils_parallelization.md](utils_parallelization.md) for full details.

### Usage Tracking (`dspy/utils/usage_tracker.py`)

`UsageTracker` accumulates per-LM token usage entries and can merge them into totals (including nested `*_tokens_details` dicts). The `track_usage()` context manager installs a fresh tracker into `dspy.settings` for the duration of a `with` block.

See [utils_usage_tracking.md](utils_usage_tracking.md) for full details.

### Logging (`dspy/utils/logging_utils.py`)

`DSPyLoggingStream` wraps `sys.stderr` and can be globally enabled/disabled, letting users silence DSPy's event logs. `configure_dspy_loggers()` installs a formatted handler on the DSPy root logger.

See [utils_logging.md](utils_logging.md) for full details.

### Exceptions (`dspy/utils/exceptions.py`)

`AdapterParseError` is the shared exception raised when an adapter fails to parse an LM response, carrying the adapter name, signature, raw response, and any partially parsed result.

See [utils_exceptions.md](utils_exceptions.md) for full details.

## How the Pieces Fit Together

The following diagram shows a typical execution flow and where each utility participates:

```mermaid
sequenceDiagram
    participant User
    participant Module
    participant Callback as BaseCallback
    participant LM
    participant Tracker as UsageTracker
    participant Parallel as ParallelExecutor

    User->>Parallel: execute(program, dataset)
    Parallel->>Module: forward() [thread-local settings]
    Module->>Callback: on_module_start
    Module->>LM: __call__()
    LM->>Callback: on_lm_start
    LM-->>Tracker: add_usage(...)
    LM->>Callback: on_lm_end
    Module->>Callback: on_module_end
    Parallel-->>User: results
```

## Relationship to Other Modules

- **[dsp_utils](dsp_utils.md)** — `ParallelExecutor` and `UsageTracker` read and propagate `dspy.settings` (including thread-local overrides); `with_callbacks` reads the configured `callbacks` list.
- **[clients](clients.md)** — `DummyLM` subclasses `LM`; `LM` and `BaseLM` are decorated with `with_callbacks` and report usage to the active `UsageTracker`.
- **[adapters](adapters.md)** — `Adapter.format`/`parse` are decorated with `with_callbacks`; `AdapterParseError` is raised by adapters and consumed by callers; `DummyLM` uses `ChatAdapter` for formatting.
- **[signatures](signatures.md)** — `DummyLM` builds `OutputField`s when formatting canned answers.
- **[evaluate](evaluate.md)** — `Evaluate.__call__` is decorated with `with_callbacks`; evaluation is typically run through `ParallelExecutor`.
- **[teleprompt](teleprompt.md)** — optimizers use `ParallelExecutor` for parallel evaluation and `track_usage()` to measure token consumption.

## Summary

`utils` is the shared infrastructure layer of DSPy. It supplies the callback/observability hooks, concurrency primitives, testing doubles, usage accounting, logging controls, and shared exceptions that the rest of the framework builds on. Although it contains no model-programming logic itself, almost every other module depends on it.
