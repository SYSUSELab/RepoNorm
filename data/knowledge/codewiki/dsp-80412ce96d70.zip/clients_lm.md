# clients_lm Module

## Introduction

The `clients_lm` module provides the core language model (LM) abstraction for DSPy. It defines the interface through which DSPy programs communicate with Large Language Models, handling request construction, response processing, caching, history tracking, streaming, and provider-specific behaviors such as fine-tuning and reinforcement learning.

The module consists of two primary classes:

- **`BaseLM`** (`dspy/clients/base_lm.py`) — An abstract base class defining the LM contract, response processing, history management, and callback integration.
- **`LM`** (`dspy/clients/lm.py`) — The concrete, production-ready implementation built on top of [LiteLLM](https://github.com/BerriAI/litellm), supporting hundreds of providers, caching, streaming, fine-tuning, and reinforcement learning.

Most users interact with `dspy.LM` directly. Advanced users can subclass `BaseLM` to inject custom provider logic.

---

## Architecture Overview

The module sits at the boundary between DSPy's high-level modules (e.g., `Predict`, `ChainOfThought`) and external LLM providers. It delegates provider-specific concerns to the `clients_providers` module and caching to the `clients_cache` module.

```mermaid
graph TD
    subgraph "DSPy Core"
        Predict["Predict / Modules"]
        Settings["Settings (dspy.settings)"]
        Callbacks["BaseCallback"]
        UsageTracker["UsageTracker"]
    end

    subgraph "clients_lm Module"
        BaseLM["BaseLM<br/>(base_lm.py)"]
        LM["LM<br/>(lm.py)"]
    end

    subgraph "Dependencies"
        LiteLLM["LiteLLM"]
        Cache["Cache / request_cache<br/>(clients_cache)"]
        Provider["Provider<br/>(clients_providers)"]
        OpenAIProvider["OpenAIProvider<br/>(clients_providers)"]
        TrainDataFormat["TrainDataFormat<br/>(clients_finetune)"]
        StreamListener["StreamListener<br/>(streaming)"]
    end

    Predict -->|"__call__ / acall"| LM
    LM -->|"inherits"| BaseLM
    BaseLM -->|"reads config"| Settings
    BaseLM -->|"invokes"| Callbacks
    LM -->|"uses"| LiteLLM
    LM -->|"caches via"| Cache
    LM -->|"delegates to"| Provider
    LM -->|"auto-detects"| OpenAIProvider
    LM -->|"fine-tunes with"| TrainDataFormat
    LM -->|"streams to"| StreamListener
    LM -->|"reports usage to"| UsageTracker
```

---

## Core Components

### BaseLM

`BaseLM` is the abstract foundation for all language models in DSPy. It defines the public calling interface and the shared response-processing pipeline, while leaving the actual provider communication to subclasses.

**Key responsibilities:**

| Responsibility | Method / Attribute |
| --- | --- |
| Public synchronous entry point | `__call__(prompt, messages, **kwargs)` |
| Public asynchronous entry point | `acall(prompt, messages, **kwargs)` |
| Provider-specific request logic (abstract) | `forward(...)` / `aforward(...)` |
| Normalize provider responses | `_process_lm_response(...)` |
| Per-instance history | `self.history` |
| Global history | `GLOBAL_HISTORY`, `update_global_history(...)` |
| History inspection | `inspect_history(n)` |
| Deep-copy with overrides | `copy(**kwargs)` |

**Constructor parameters:**

```python
BaseLM(model, model_type="chat", temperature=0.0, max_tokens=1000, cache=True, **kwargs)
```

**Response processing pipeline.** `_process_lm_response` converts a raw provider response (expected to follow the [OpenAI response format](https://platform.openai.com/docs/api-reference/responses/object)) into a normalized list of outputs. It:

1. Extracts `text`, optional `logprobs`, and optional `tool_calls` from each choice.
2. Collapses to a plain list of strings when every output contains only `text`.
3. Records a history entry (unless `settings.disable_history` is set) containing the prompt, messages, kwargs, response, outputs, usage, cost, timestamp, UUID, and model metadata.
4. Propagates the entry to the global history and to any `settings.caller_modules`.

**Extending BaseLM.** Subclasses only need to implement `forward` (and optionally `aforward`) and return an OpenAI-compatible response object:

```python
from openai import OpenAI
import dspy

class MyLM(dspy.BaseLM):
    def forward(self, prompt, messages=None, **kwargs):
        client = OpenAI()
        return client.chat.completions.create(
            model=self.model,
            messages=messages or [{"role": "user", "content": prompt}],
            **self.kwargs,
        )

lm = MyLM(model="gpt-4o-mini")
dspy.configure(lm=lm)
```

### LM

`LM` is the concrete implementation that most users rely on. It wraps LiteLLM to support a wide range of providers and adds caching, retries, streaming, fine-tuning, and reinforcement learning.

**Constructor parameters:**

| Parameter | Type | Default | Description |
| --- | --- | --- | --- |
| `model` | `str` | — | Model identifier in `"provider/model"` form (e.g., `"openai/gpt-4o"`). |
| `model_type` | `"chat"` \| `"text"` | `"chat"` | Selects chat vs. text completion. |
| `temperature` | `float` | `0.0` | Sampling temperature. |
| `max_tokens` | `int` | `4000` | Maximum tokens to generate. |
| `cache` | `bool` | `True` | Enable response caching. |
| `cache_in_memory` | `bool` | `True` | Enable additional in-memory LRU caching (deprecated). |
| `callbacks` | `list[BaseCallback]` | `None` | Per-instance callbacks. |
| `num_retries` | `int` | `3` | Retry count with exponential backoff. |
| `provider` | `Provider` | `None` | Explicit provider; inferred if omitted. |
| `finetuning_model` | `str` | `None` | Model to fine-tune (may differ from inference model). |
| `launch_kwargs` | `dict` | `None` | Arguments for provider `launch`/`kill`. |
| `train_kwargs` | `dict` | `None` | Default arguments for training jobs. |

**Reasoning-model handling.** The constructor detects OpenAI reasoning models (`o1`, `o3`, `o4`, optionally `-mini`) via a regex and enforces `temperature=1.0` and `max_tokens >= 20_000`, translating `max_tokens` into `max_completion_tokens`.

**Provider inference.** `infer_provider()` returns an `OpenAIProvider` when the model matches OpenAI's known models (including fine-tuned `ft:` models), otherwise a generic `Provider`.

---

## Request Flow

The following sequence diagram illustrates a synchronous LM call from a DSPy module through to a provider and back.

```mermaid
sequenceDiagram
    participant Module as DSPy Module
    participant LM as LM.__call__
    participant Base as BaseLM.__call__
    participant Fwd as LM.forward
    participant Cache as request_cache
    participant Lite as LiteLLM
    participant Proc as _process_lm_response

    Module->>LM: __call__(prompt, messages, **kwargs)
    LM->>Base: (inherited) with_callbacks wrapper
    Base->>Fwd: forward(prompt, messages, **kwargs)
    Fwd->>Fwd: merge self.kwargs + kwargs
    Fwd->>Cache: wrap completion fn (if cache enabled)
    Fwd->>Lite: completion(request, num_retries, cache)
    Lite-->>Fwd: response (OpenAI format)
    Fwd->>Fwd: warn if finish_reason == "length"
    Fwd->>Fwd: track usage (if enabled)
    Fwd-->>Base: response
    Base->>Proc: _process_lm_response(...)
    Proc->>Proc: normalize outputs, append history
    Proc-->>Base: outputs
    Base-->>Module: outputs
```

### Caching Strategy

`LM._get_cached_completion_fn` wraps the completion function with `request_cache` from the [clients_cache](clients_cache.md) module. It:

- Ignores `api_key`, `api_base`, and `base_url` when computing cache keys.
- Optionally disables the in-memory cache layer (`enable_memory_cache=False`).
- Configures LiteLLM's own cache flags (`no-cache` / `no-store`) based on whether caching is enabled and whether `litellm.cache` is set.

### Streaming

When `dspy.settings.send_stream` is set, `_get_stream_completion_fn` returns a streaming completion function that:

1. Calls `litellm.acompletion(..., stream=True)`.
2. Tags each chunk with the caller `predict_id` so the [StreamListener](streaming.md) can attribute chunks.
3. Sends chunks to the memory object stream.
4. Rebuilds the full response via `litellm.stream_chunk_builder`.

Both sync (`syncify`) and async variants are provided.

---

## Fine-Tuning and Reinforcement Learning

`LM` exposes two high-level training entry points that delegate to the configured `Provider` (see [clients_providers](clients_providers.md)).

```mermaid
graph LR
    LM["LM.finetune()"] -->|"asserts provider.finetunable"| Job["TrainingJob (Future)"]
    Job -->|"runs in thread"| Run["_run_finetune_job"]
    Run -->|"provider.finetune(...)"| Provider["Provider.finetune"]
    Provider -->|"returns model name"| Copy["LM.copy(model=...)"]
    Copy -->|"set_result"| Job

    LM2["LM.reinforce()"] -->|"asserts provider.reinforceable"| RJob["ReinforceJob"]
    RJob -->|"initialize()"| RJob
```

- **`finetune(train_data, train_data_format, train_kwargs)`** — Validates that the provider is `finetunable`, spawns a background thread running `_run_finetune_job`, and returns a `TrainingJob` (a `Future`). On success, the job's result is a new `LM` instance pointing at the fine-tuned model.
- **`reinforce(train_kwargs)`** — Validates that the provider is `reinforceable`, constructs a `ReinforceJob`, initializes it, and returns it.

The `TrainDataFormat` enum (from [clients_finetune](clients_finetune.md)) defines supported formats: `CHAT`, `COMPLETION`, and `GRPO_CHAT`.

---

## History and Observability

`BaseLM` maintains two levels of history:

| Level | Storage | Scope |
| --- | --- | --- |
| Per-instance | `self.history` | One LM instance. |
| Global | `GLOBAL_HISTORY` (capped at `MAX_HISTORY_SIZE = 10_000`) | All LMs in the process. |

History entries are appended in `_process_lm_response` and can be inspected with:

```python
lm.inspect_history(n=1)          # per-instance
dspy.inspect_history(n=1)        # global
```

History recording is suppressed when `settings.disable_history` is `True`. API keys are stripped from logged kwargs (any key starting with `api_`).

### Callbacks

`BaseLM.__call__` and `acall` are decorated with `@with_callbacks` (from [utils](utils.md)), which invokes `on_lm_start` / `on_lm_end` handlers on both global (`dspy.settings.callbacks`) and instance-level callbacks. See [BaseCallback](utils.md) for the full handler interface.

### Usage Tracking

When `dspy.settings.usage_tracker` is set and the response is not a cache hit, `LM.forward`/`aforward` records token usage via `UsageTracker.add_usage`. This enables aggregate token accounting across calls.

---

## State Serialization

`LM.dump_state()` returns a dictionary of the LM's configuration (model, model type, cache flags, retries, fine-tuning model, launch/train kwargs) merged with `self.kwargs`. This is used for serialization and reproducibility.

> **Note:** When modifying the `LM` constructor, `LM.copy()` must be updated accordingly, since `copy` deep-copies the instance and applies overrides.

---

## Component Interaction Summary

```mermaid
graph TD
    BaseLM["BaseLM"]
    LM["LM"]

    LM -->|"extends"| BaseLM

    BaseLM -->|"uses"| Settings["Settings"]
    BaseLM -->|"uses"| Callbacks["with_callbacks / BaseCallback"]
    BaseLM -->|"uses"| History["inspect_history / GLOBAL_HISTORY"]

    LM -->|"uses"| LiteLLM["LiteLLM"]
    LM -->|"uses"| Cache["request_cache (clients_cache)"]
    LM -->|"uses"| Provider["Provider (clients_providers)"]
    LM -->|"uses"| OpenAIProvider["OpenAIProvider (clients_providers)"]
    LM -->|"uses"| TrainDataFormat["TrainDataFormat (clients_finetune)"]
    LM -->|"uses"| UsageTracker["UsageTracker (utils)"]
    LM -->|"streams to"| StreamListener["StreamListener (streaming)"]
```

---

## Related Modules

- [clients_cache](clients_cache.md) — Two-level (memory + disk) caching used by `LM`.
- [clients_providers](clients_providers.md) — Provider implementations (`OpenAIProvider`, `DatabricksProvider`, `LocalProvider`, `ArborProvider`) and training job classes.
- [clients_finetune](clients_finetune.md) — `TrainDataFormat`, `TrainingStatus`, and GRPO data structures.
- [clients_embedding](clients_embedding.md) — The `Embedder` class for text embeddings.
- [streaming](streaming.md) — `StreamListener` and streaming message types.
- [utils](utils.md) — `BaseCallback`, `with_callbacks`, `UsageTracker`, and other utilities.
- [dsp_utils](dsp_utils.md) — The `Settings` singleton that drives global configuration.
