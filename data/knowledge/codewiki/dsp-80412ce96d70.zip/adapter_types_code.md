# Adapter Types: Code

## Introduction

The `adapter_types_code` module provides the `Code` custom type for DSPy signatures. It enables
signatures to declare fields that carry source code as their value, supporting both **code
generation** (as an output field) and **code analysis** (as an input field). The type handles the
common LLM behavior of wrapping code in Markdown fenced code blocks by automatically extracting the
raw code from such blocks.

`Code` is one of the concrete custom types built on top of the shared
[`Type` base class](adapter_types_base_type.md), alongside media types
([`Image`](adapter_types_media.md), [`Audio`](adapter_types_media.md)), [`Tool`](adapter_types_tool.md),
and [`History`](adapter_types_history.md).

---

## Core Component

### `Code`

`Code` is a Pydantic model that subclasses `Type`. It represents a snippet of source code together
with an associated programming language.

| Member | Kind | Description |
| --- | --- | --- |
| `code: str` | field | The raw source code string. |
| `language: ClassVar[str]` | class variable | The programming language of the code. Defaults to `"python"`. |
| `format()` | method | Returns the raw code string (no wrapper tags). |
| `serialize_model()` | Pydantic serializer | Overrides the base serializer to bypass the `<<CUSTOM-TYPE-START-IDENTIFIER>>` / `<<CUSTOM-TYPE-END-IDENTIFIER>>` tags. |
| `description()` | classmethod | Returns a human-readable description used in prompts, including the language and the expected Markdown code-block format. |
| `validate_input()` | Pydantic validator (`mode="before"`) | Normalizes input from `Code` instances, plain strings, or dicts, and strips Markdown fences. |
| `_filter_code()` | module function | Extracts code from Markdown code blocks. |
| `_code_class_getitem()` | module function | Patches `__class_getitem__` to support `dspy.Code["java"]` syntax. |

---

## Architecture

The `Code` type sits within the `dspy.adapters.types` package and depends on the shared `Type`
base class. It is consumed by the adapters (e.g. `ChatAdapter`, `JSONAdapter`) when serializing
signature fields for LLM calls.

```mermaid
graph TD
    subgraph "dspy.adapters.types"
        Type["Type (base_type.py)"]
        Code["Code (code.py)"]
        Image["Image (image.py)"]
        Audio["Audio (audio.py)"]
        Tool["Tool (tool.py)"]
        History["History (history.py)"]
    end

    subgraph "dspy.adapters"
        ChatAdapter["ChatAdapter"]
        JSONAdapter["JSONAdapter"]
        XMLAdapter["XMLAdapter"]
        TwoStepAdapter["TwoStepAdapter"]
    end

    Code -->|inherits| Type
    Image -->|inherits| Type
    Audio -->|inherits| Type
    Tool -->|inherits| Type

    ChatAdapter -->|serializes| Code
    JSONAdapter -->|serializes| Code
    XMLAdapter -->|serializes| Code
    TwoStepAdapter -->|serializes| Code
```

---

## Component Relationships

`Code` inherits the shared behavior of `Type` (custom-type extraction from annotations and the
default serializer) but overrides the serializer to emit plain code rather than the tagged custom
type format used by media types.

```mermaid
classDiagram
    class Type {
        +format() list|str
        +description() str
        +extract_custom_type_from_annotation(annotation)
        +serialize_model()
    }
    class Code {
        +str code
        +ClassVar str language
        +format() str
        +serialize_model() str
        +description() str
        +validate_input(data)
    }
    class Image {
        +str url
        +format() list
    }
    class Audio {
        +str data
        +str audio_format
        +format() list
    }
    class Tool {
        +Callable func
        +format() str
    }

    Type <|-- Code
    Type <|-- Image
    Type <|-- Audio
    Type <|-- Tool
```

---

## Data Flow

The following diagram shows how a `Code` value flows from user input through validation, storage,
and serialization into the prompt sent to the language model.

```mermaid
flowchart TD
    A["User input: str / dict / Code"] --> B["validate_input (mode=before)"]
    B -->|str| C["_filter_code(data)"]
    B -->|dict with 'code'| D["_filter_code(data['code'])"]
    B -->|Code instance| E["return as-is"]
    C --> F["Code(code=..., language=...)"]
    D --> F
    E --> F
    F --> G["serialize_model()"]
    G --> H["format() -> raw code string"]
    H --> I["Adapter builds prompt"]
    I --> J["LM call"]
```

### Validation Rules

`validate_input` accepts three input shapes:

1. **`Code` instance** — returned unchanged.
2. **`str`** — treated as the code body and passed through `_filter_code`.
3. **`dict`** — must contain a `"code"` key whose value is a string; otherwise a `ValueError` is
   raised. The value is passed through `_filter_code`.

Any other input type raises a `ValueError`.

### Markdown Extraction (`_filter_code`)

LLMs frequently return code wrapped in Markdown fences. `_filter_code` handles this in two passes:

```mermaid
flowchart TD
    A["Input string"] --> B{"Matches ```lang\\n...``` ?"}
    B -->|yes| C["Return captured group (stripped)"]
    B -->|no| D{"Matches ```...``` ?"}
    D -->|yes| E["Return captured group (stripped)"]
    D -->|no| F["Return original string (fallback)"]
```

1. **Fenced with language** — matches ```` ```python\n{code}\n``` ```` and strips the language
   identifier.
2. **Fenced without language** — matches ```` ```{code}``` ```` (single-line).
3. **Fallback** — returns the original string unchanged.

---

## Language Parameterization

`Code` supports a language parameter via subscript syntax, e.g. `dspy.Code["java"]`. This is
implemented by patching `__class_getitem__` on the class:

```python
def _code_class_getitem(cls, language):
    code_with_language_cls = create_model(f"{cls.__name__}_{language}", __base__=cls)
    code_with_language_cls.language = language
    return code_with_language_cls

Code.__class_getitem__ = classmethod(_code_class_getitem)
```

When `dspy.Code["java"]` is evaluated, a new Pydantic model subclass is dynamically created with the
`language` class variable set to `"java"`. This language value is then surfaced in the
`description()` output, guiding the model to produce code in the requested language.

```mermaid
sequenceDiagram
    participant User
    participant Code
    participant create_model

    User->>Code: dspy.Code["java"]
    Code->>create_model: create_model("Code_java", __base__=Code)
    create_model-->>Code: new subclass
    Code->>Code: subclass.language = "java"
    Code-->>User: Code_java class
```

---

## Usage Examples

### Code Generation (output field)

```python
import dspy

dspy.configure(lm=dspy.LM("openai/gpt-4o-mini"))


class CodeGeneration(dspy.Signature):
    """Generate python code to answer the question."""

    question: str = dspy.InputField(description="The question to answer")
    code: dspy.Code["java"] = dspy.OutputField(description="The code to execute")


predict = dspy.Predict(CodeGeneration)
result = predict(question="Given an array, find if any of the two numbers sum up to 10")
print(result.code)
```

### Code Analysis (input field)

```python
import dspy
import inspect

dspy.configure(lm=dspy.LM("openai/gpt-4o-mini"))


class CodeAnalysis(dspy.Signature):
    """Analyze the time complexity of the function."""

    code: dspy.Code["python"] = dspy.InputField(description="The function to analyze")
    result: str = dspy.OutputField(description="The time complexity of the function")


predict = dspy.Predict(CodeAnalysis)


def sleepsort(x):
    import time

    for i in x:
        time.sleep(i)
        print(i)


result = predict(code=inspect.getsource(sleepsort))
print(result.result)
```

---

## Integration with the Adapter System

`Code` is a member of the custom type family consumed by the DSPy adapters. When a signature field
is annotated with `Code`, the adapter:

1. Detects the custom type via `Type.extract_custom_type_from_annotation`.
2. Uses `Code.description()` to build the field description in the prompt.
3. Uses `Code.serialize_model()` (which calls `format()`) to render the value.

Unlike media types such as [`Image`](adapter_types_media.md) and [`Audio`](adapter_types_media.md),
which serialize to a list of content parts wrapped in custom-type identifier tags, `Code` overrides
`serialize_model()` to emit the raw code string directly.

For details on how adapters consume these types, see the adapter documentation
([`adapters_core`](adapters_core.md)).

---

## Related Modules

- [`adapter_types_base_type`](adapter_types_base_type.md) — the `Type` base class that `Code` extends.
- [`adapter_types_media`](adapter_types_media.md) — `Image` and `Audio` custom types.
- [`adapter_types_tool`](adapter_types_tool.md) — `Tool` and `ToolCalls` custom types.
- [`adapter_types_history`](adapter_types_history.md) — the `History` custom type.
- [`adapters_core`](adapters_core.md) — the adapters that serialize and consume custom types.
