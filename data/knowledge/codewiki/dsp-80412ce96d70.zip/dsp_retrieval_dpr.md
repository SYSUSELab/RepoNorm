# dsp_retrieval_dpr

## Introduction

The `dsp_retrieval_dpr` module provides the **tokenization and text-normalization primitives** used by DSPy's retrieval stack. It is a faithful port of the tokenizer implementation from Facebook Research's [Dense Passage Retrieval (DPR)](https://github.com/facebookresearch/DPR) project, adapted for use inside DSPy.

The module's core responsibility is to convert raw text into a structured, annotated token representation (`Tokens`) and to provide utilities for answer matching and answer localization within passages. These primitives are the foundation for retrieval evaluation (e.g., checking whether a retrieved passage contains the gold answer) and for any component that needs DPR-compatible tokenization.

> **Note:** This module is a *utility* module. It does not perform retrieval itself. For the retrieval components that consume these primitives, see [dsp_retrieval_colbertv2.md](dsp_retrieval_colbertv2.md) and [retrievers.md](retrievers.md).

---

## Module Structure

The module lives at `dspy/dsp/utils/dpr.py` and exposes three core classes plus a set of module-level helper functions.

| Component | Kind | Purpose |
|-----------|------|---------|
| `Tokens` | Class | Structured container for a tokenized text with optional annotations (POS, lemma, NER). |
| `Tokenizer` | Abstract base class | Defines the tokenizer interface (`tokenize`, `shutdown`). |
| `SimpleTokenizer` | Concrete class | Regex-based tokenizer that splits text into alphanumeric and non-whitespace tokens. |
| `has_answer` | Function | Checks whether any tokenized answer appears in a text. |
| `locate_answers` | Function | Returns character offsets of each answer occurrence in a text. |
| `DPR_tokenize` / `DPR_normalize` | Functions | Convenience wrappers around a shared `SimpleTokenizer` instance. |
| `strip_accents` | Function | Removes diacritic marks from text. |

---

## Architecture

The module is intentionally self-contained and has no internal DSPy dependencies. It depends only on the standard library (`copy`, `logging`, `unicodedata`) and the third-party `regex` package.

```mermaid
graph TD
    subgraph "dsp_retrieval_dpr (dspy/dsp/utils/dpr.py)"
        Tokens["Tokens<br/>(data container)"]
        Tokenizer["Tokenizer<br/>(abstract base)"]
        SimpleTokenizer["SimpleTokenizer<br/>(regex tokenizer)"]
        Helpers["Module-level helpers<br/>has_answer, locate_answers,<br/>DPR_tokenize, DPR_normalize,<br/>strip_accents"]
    end

    Tokenizer -->|inherits| SimpleTokenizer
    SimpleTokenizer -->|produces| Tokens
    Helpers -->|uses| SimpleTokenizer
    Helpers -->|uses| Tokens

    regex["regex (3rd-party)"] --> SimpleTokenizer
    unicodedata["unicodedata (stdlib)"] --> Helpers
    copy["copy (stdlib)"] --> Tokens
```

### Class Hierarchy

```mermaid
classDiagram
    class Tokenizer {
        +tokenize(text) Tokens
        +shutdown()
    }
    class SimpleTokenizer {
        +ALPHA_NUM
        +NON_WS
        +annotators: set
        +tokenize(text) Tokens
    }
    class Tokens {
        +TEXT = 0
        +TEXT_WS = 1
        +SPAN = 2
        +POS = 3
        +LEMMA = 4
        +NER = 5
        +data
        +annotators
        +opts
        +__len__()
        +slice(i, j) Tokens
        +untokenize() str
        +words(uncased) list
        +offsets() list
        +pos() list
        +lemmas() list
        +entities() list
        +ngrams(n, uncased, filter_fn, as_strings) list
        +entity_groups() list
    }
    Tokenizer <|-- SimpleTokenizer
    SimpleTokenizer ..> Tokens : creates
```

---

## Core Components

### `Tokens`

`Tokens` is the central data structure. Each token is stored as a tuple with a fixed positional layout, indexed by the class constants:

| Index | Constant | Meaning |
|-------|----------|---------|
| 0 | `TEXT` | The token text itself. |
| 1 | `TEXT_WS` | The token text *including* trailing whitespace (used for lossless `untokenize`). |
| 2 | `SPAN` | `(start, end)` character offsets in the original string. |
| 3 | `POS` | Part-of-speech tag (optional). |
| 4 | `LEMMA` | Lemmatized form (optional). |
| 5 | `NER` | Named-entity tag (optional). |

Key methods:

- **`slice(i, j)`** — Returns a shallow copy of the `Tokens` restricted to `[i, j)`. Used internally by `entity_groups`.
- **`untokenize()`** — Reconstructs the original text by joining `TEXT_WS` fields and stripping.
- **`words(uncased=False)`** — Returns the list of token texts, optionally lower-cased.
- **`offsets()`** — Returns the list of `[start, end)` character spans.
- **`pos()` / `lemmas()` / `entities()`** — Return annotation lists, or `None` if the corresponding annotator was not enabled.
- **`ngrams(n, uncased, filter_fn, as_strings)`** — Generates all n-grams up to length `n`, optionally filtered and stringified.
- **`entity_groups()`** — Groups consecutive tokens sharing the same NER tag into `(text, tag)` tuples.

### `Tokenizer`

An abstract base class defining the tokenizer contract:

- `tokenize(text)` — Must be overridden; returns a `Tokens` instance.
- `shutdown()` — No-op hook for releasing resources; also invoked from `__del__`.

### `SimpleTokenizer`

The only concrete tokenizer. It uses a compiled `regex` pattern combining two alternatives:

- `ALPHA_NUM = r"[\p{L}\p{N}\p{M}]+"` — runs of letters, numbers, and combining marks.
- `NON_WS = r"[^\p{Z}\p{C}]"` — any single non-separator, non-control character.

The pattern is compiled with `IGNORECASE | UNICODE | MULTILINE`. During `tokenize`, the tokenizer iterates over regex matches and, for each match, records the token text, the text *including* the whitespace up to the next match, and the character span. This whitespace-aware design enables lossless reconstruction via `Tokens.untokenize()`.

> **Important:** `SimpleTokenizer` only tokenizes. If `annotators` are passed, it logs a warning and ignores them (`self.annotators = set()`).

### Module-level Helpers

```mermaid
flowchart LR
    A["Raw text"] --> B["DPR_tokenize"]
    B --> C["Tokens"]
    C --> D["words(uncased=True)"]
    D --> E["DPR_normalize"]

    F["tokenized_answers"] --> G["has_answer"]
    H["text"] --> G
    G --> I["bool"]

    J["tokenized_answers"] --> K["locate_answers"]
    L["text"] --> K
    K --> M["list of (offset, endpos)"]
```

- **`DPR_tokenize(text)`** — Normalizes text to Unicode NFD form and tokenizes it with the shared `STokenizer` instance.
- **`DPR_normalize(text)`** — Returns the lower-cased word list of `DPR_tokenize(text)`.
- **`has_answer(tokenized_answers, text)`** — Normalizes `text` and checks whether any tokenized answer appears as a contiguous subsequence. Returns a boolean.
- **`locate_answers(tokenized_answers, text)`** — Tokenizes `text`, then for each answer finds all matching word subsequences and returns their `(offset, endpos)` character ranges.
- **`strip_accents(text)`** — Removes combining marks (Unicode category `Mn`) after NFD normalization.

A module-level singleton `STokenizer = SimpleTokenizer()` is shared by `DPR_tokenize` and `DPR_normalize`.

---

## Data Flow

The following diagram shows how text flows through the module during a typical answer-matching operation.

```mermaid
sequenceDiagram
    participant Caller
    participant DPR_tokenize
    participant STokenizer as STokenizer (SimpleTokenizer)
    participant Tokens
    participant has_answer

    Caller->>DPR_tokenize: text
    DPR_tokenize->>DPR_tokenize: unicodedata.normalize("NFD", text)
    DPR_tokenize->>STokenizer: tokenize(normalized_text)
    STokenizer->>STokenizer: regex.finditer(...)
    STokenizer->>Tokens: Tokens(data, annotators)
    Tokens-->>DPR_tokenize: Tokens instance
    DPR_tokenize-->>Caller: Tokens

    Caller->>has_answer: (tokenized_answers, text)
    has_answer->>DPR_tokenize: text
    DPR_tokenize-->>has_answer: Tokens
    has_answer->>has_answer: words(uncased=True)
    has_answer->>has_answer: subsequence match
    has_answer-->>Caller: bool
```

---

## Position in the Retrieval Stack

`dsp_retrieval_dpr` sits at the lowest layer of DSPy's retrieval utilities. It provides the tokenization primitives that higher-level retrieval components rely on for evaluation and answer matching.

```mermaid
graph TD
    subgraph "Retrieval Layer"
        ColBERT["ColBERTv2 / ColBERTv2RetrieverLocal<br/>(dsp_retrieval_colbertv2.md)"]
        Retrieve["Retrieve<br/>(retrievers.md)"]
        Embeddings["Embeddings<br/>(retrievers.md)"]
    end

    subgraph "Utility Layer"
        DPR["dsp_retrieval_dpr<br/>(this module)"]
    end

    ColBERT -.->|answer matching / eval| DPR
    Retrieve -.->|answer matching / eval| DPR
    Embeddings -.->|answer matching / eval| DPR
```

The retrieval components themselves (e.g., `ColBERTv2`, `Retrieve`, `Embeddings`) return passages as `dotdict` or `Prediction` objects. The DPR tokenizer is then used to verify whether those passages contain the expected answers — a common pattern in retrieval evaluation pipelines. See [dsp_retrieval_colbertv2.md](dsp_retrieval_colbertv2.md) and [retrievers.md](retrievers.md) for details on those components.

---

## Dependencies

| Dependency | Type | Usage |
|------------|------|-------|
| `copy` | stdlib | Shallow-copying `Tokens` in `slice`. |
| `logging` | stdlib | Warning when annotators are passed to `SimpleTokenizer`. |
| `unicodedata` | stdlib | NFD normalization and accent stripping. |
| `regex` | 3rd-party | Unicode-aware tokenization pattern. |

The module has **no internal DSPy dependencies**, making it safe to import in isolation.

---

## Usage Examples

### Tokenizing text

```python
from dspy.dsp.utils.dpr import DPR_tokenize

tokens = DPR_tokenize("Hello, world!")
print(tokens.words())        # ['Hello', ',', 'world', '!']
print(tokens.offsets())      # character spans for each token
print(tokens.untokenize())   # 'Hello, world!'
```

### Checking whether a passage contains an answer

```python
from dspy.dsp.utils.dpr import DPR_tokenize, has_answer

answers = [DPR_tokenize("Paris")]
text = "The capital of France is Paris."
print(has_answer(answers, text))  # True
```

### Locating answer offsets

```python
from dspy.dsp.utils.dpr import DPR_tokenize, locate_answers

answers = [DPR_tokenize("Paris")]
text = "Paris is the capital of France. Paris is beautiful."
print(locate_answers(answers, text))  # [(0, 5), (33, 38)]
```

---

## Related Modules

- [dsp_retrieval_colbertv2.md](dsp_retrieval_colbertv2.md) — ColBERTv2 retrieval wrappers that operate on passages.
- [retrievers.md](retrievers.md) — `Retrieve`, `Embeddings`, and other retriever components.
- [dsp_utils.md](dsp_utils.md) — Shared DSPy utilities including `dotdict` and `Settings`.
