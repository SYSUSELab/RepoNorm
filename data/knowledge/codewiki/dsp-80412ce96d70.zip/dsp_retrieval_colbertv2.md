# dsp_retrieval_colbertv2

## Introduction

The `dsp_retrieval_colbertv2` module provides retrieval and reranking capabilities based on **ColBERTv2**, a late-interaction neural retrieval model. It exposes three core components that cover the two primary ways of using ColBERTv2 within DSPy:

1. **`ColBERTv2`** — A lightweight HTTP client wrapper for querying a *hosted* ColBERTv2 server (via GET or POST requests).
2. **`ColBERTv2RetrieverLocal`** — A local retriever that builds/loads a ColBERT index over a provided passage collection and performs searches directly on the machine.
3. **`ColBERTv2RerankerLocal`** — A local reranker that scores a set of candidate passages against a query using ColBERT's late-interaction scoring.

Together these components allow DSPy programs to retrieve relevant passages either from a remote service or from a locally indexed corpus, and to refine candidate sets with a reranking pass.

---

## Module Architecture

The module is organized around a shared retrieval abstraction: all three components accept a `query` and return ranked passages (or scores), but they differ in *where* the computation happens and *what* they return.

```mermaid
graph TD
    subgraph "dsp_retrieval_colbertv2"
        CB["ColBERTv2<br/>(remote HTTP client)"]
        RET["ColBERTv2RetrieverLocal<br/>(local index + search)"]
        RER["ColBERTv2RerankerLocal<br/>(local scoring)"]
    end

    subgraph "External Dependencies"
        REQ["requests"]
        COLBERT["colbert (colbert-ai)"]
        TORCH["torch"]
        NUMPY["numpy"]
    end

    subgraph "DSPy Internals"
        CACHE["dspy.clients.cache::Cache<br/>(request_cache)"]
        DOTDICT["dspy.dsp.utils::dotdict"]
    end

    CB --> REQ
    CB --> CACHE
    CB --> DOTDICT
    RET --> COLBERT
    RET --> TORCH
    RET --> DOTDICT
    RER --> COLBERT
    RER --> TORCH
    RER --> NUMPY
```

### Component Responsibilities

| Component | Execution | Input | Output | Requires `colbert-ai` |
|-----------|-----------|-------|--------|-----------------------|
| `ColBERTv2` | Remote (HTTP) | `query`, `k` | `list[str]` or `list[dotdict]` | No |
| `ColBERTv2RetrieverLocal` | Local | `query`, `k`, optional `filtered_pids` | `list[dotdict]` | Yes |
| `ColBERTv2RerankerLocal` | Local | `query`, `passages` | `numpy.ndarray` of scores | Yes |

---

## Component Details

### `ColBERTv2` — Remote Retrieval Client

`ColBERTv2` is a thin wrapper around a hosted ColBERTv2 HTTP endpoint. It is the simplest way to add retrieval to a DSPy program when a ColBERTv2 server is already running.

**Constructor**

```python
ColBERTv2(url="http://0.0.0.0", port=None, post_requests=False)
```

- `url`: Base URL of the ColBERTv2 server.
- `port`: Optional port; when provided, it is appended to `url` as `f"{url}:{port}"`.
- `post_requests`: When `True`, uses HTTP POST; otherwise uses HTTP GET.

**Call signature**

```python
__call__(query: str, k: int = 10, simplify: bool = False)
```

- `query`: The search query string.
- `k`: Number of top passages to return.
- `simplify`: When `True`, returns a plain `list[str]` of passage texts; otherwise returns a `list[dotdict]` with full metadata (e.g. `text`, `long_text`, `score`, `pid`).

**Request flow**

```mermaid
sequenceDiagram
    participant User
    participant CB as ColBERTv2
    participant Cache as request_cache
    participant Server as ColBERTv2 Server

    User->>CB: __call__(query, k, simplify)
    alt post_requests
        CB->>Cache: colbertv2_post_request(url, query, k)
    else
        CB->>Cache: colbertv2_get_request(url, query, k)
    end
    Cache->>Server: HTTP request (if cache miss)
    Server-->>Cache: JSON {"topk": [...]}
    Cache-->>CB: topk list
    CB-->>User: list[str] or list[dotdict]
```

**Caching.** Both request helpers (`colbertv2_get_request_v2` and `colbertv2_post_request_v2`) are decorated with `@request_cache()`, which delegates to the DSPy [`Cache`](clients_cache.md) subsystem. This means repeated identical queries are served from the in-memory/on-disk cache rather than hitting the network. The GET variant asserts `k <= 100`, reflecting a limitation of the hosted server.

> **Note:** The GET helper normalizes each result by adding a `long_text` field derived from `text`, so downstream consumers can rely on a consistent `long_text` key regardless of transport.

---

### `ColBERTv2RetrieverLocal` — Local Index Retriever

`ColBERTv2RetrieverLocal` builds (or loads) a ColBERT index over a list of passages and performs searches locally. It is intended for scenarios where the corpus is available on the machine and a remote server is undesirable.

**Constructor**

```python
ColBERTv2RetrieverLocal(passages, colbert_config=None, load_only=False)
```

- `passages`: The collection of passages to index/search.
- `colbert_config`: A `ColBERTConfig` (from `colbert.infra.config`). **Required** — must define `checkpoint`, `index_name`, and `experiment`.
- `load_only`: When `False` (default), the index is built before loading; when `True`, an existing index is loaded directly.

The constructor validates that `colbert_config`, `colbert_config.checkpoint`, and `colbert_config.index_name` are all set, raising `AssertionError` otherwise.

**Lifecycle**

```mermaid
flowchart TD
    A[__init__] --> B{load_only?}
    B -- No --> C[build_index]
    B -- Yes --> D[get_index]
    C --> D
    D --> E[searcher ready]
    E --> F[forward / __call__]
```

- `build_index()`: Uses `colbert.Indexer` within a `Run`/`RunConfig` context to index the passage collection, overwriting any existing index.
- `get_index()`: Uses `colbert.Searcher` to load the index for querying.

**Search flow (`forward`)**

```python
forward(query: str, k: int = 7, **kwargs)
```

- If `filtered_pids` is supplied in `kwargs`, a `filter_fn` restricts results to the given passage IDs (validated to be a list of integers). The filter tensor is placed on CUDA when available, else CPU.
- Otherwise, a standard `searcher.search(query, k=k)` is performed.
- Results are returned as a list of `dotdict` objects with keys `long_text`, `score`, and `pid`.

> **Note:** There is a subtle behavior in the implementation — when `filtered_pids` is provided, the `results` variable is assigned from the filtered search but then immediately overwritten by the subsequent loop over `searcher_results`. Developers relying on filtering should verify the effective behavior against their installed version.

---

### `ColBERTv2RerankerLocal` — Local Reranker

`ColBERTv2RerankerLocal` scores a set of candidate passages against a query using ColBERT's late-interaction (MaxSim) scoring. It is typically used as a second stage after an initial retrieval step to reorder candidates by relevance.

**Constructor**

```python
ColBERTv2RerankerLocal(colbert_config=None, checkpoint="bert-base-uncased")
```

- `colbert_config`: A `ColBERTConfig`; its `checkpoint` attribute is overwritten with the `checkpoint` argument.
- `checkpoint`: The model checkpoint used for embeddings (default `bert-base-uncased`).

**Scoring flow (`forward`)**

```python
forward(query: str, passages: list[str] | None = None) -> np.ndarray
```

```mermaid
sequenceDiagram
    participant User
    participant RER as ColBERTv2RerankerLocal
    participant QT as QueryTokenizer
    participant DT as DocTokenizer
    participant Model as ColBERT

    User->>RER: forward(query, passages)
    RER->>QT: tensorize([query])
    RER->>DT: tensorize(passages)
    RER->>Model: query(query_ids, query_masks)
    RER->>Model: doc(doc_ids, doc_masks)
    RER->>Model: score(q_duplicated, doc_ids, doc_masks)
    Model-->>RER: tensor_scores
    RER-->>User: np.ndarray of passage scores
```

Key steps:
1. Asserts `passages` is non-empty.
2. Sets `colbert_config.nway = len(passages)`.
3. Tokenizes the query and documents.
4. Encodes query and documents with `ColBERT`.
5. Duplicates the query embedding to match the number of passages and computes scores.
6. Returns a NumPy array of per-passage scores.

---

## Data Flow Overview

The following diagram shows how the three components can be composed into a two-stage retrieval pipeline (retrieve → rerank), alongside the remote alternative.

```mermaid
flowchart LR
    Q[Query] --> Choice{Retrieval mode}
    Choice -- Remote --> CB[ColBERTv2]
    Choice -- Local --> RET[ColBERTv2RetrieverLocal]
    CB --> Candidates[Candidate passages]
    RET --> Candidates
    Candidates --> RER[ColBERTv2RerankerLocal]
    RER --> Ranked[Ranked passages + scores]
```

---

## Dependencies

### Internal DSPy Dependencies

| Dependency | Purpose | Documentation |
|------------|---------|---------------|
| `dspy.clients.cache::request_cache` / `Cache` | Caches HTTP retrieval requests for `ColBERTv2` | [clients_cache.md](clients_cache.md) |
| `dspy.dsp.utils::dotdict` | Attribute-accessible dict used for result objects | [dsp_utils.md](dsp_utils.md) |

### External Dependencies

| Package | Used by | Notes |
|---------|---------|-------|
| `requests` | `ColBERTv2` | HTTP GET/POST to the hosted server |
| `colbert-ai` (`colbert`) | `ColBERTv2RetrieverLocal`, `ColBERTv2RerankerLocal` | Install via `pip install colbert-ai[faiss-gpu,torch]` |
| `torch` | `ColBERTv2RetrieverLocal`, `ColBERTv2RerankerLocal` | Device selection and tensor ops |
| `numpy` | `ColBERTv2RerankerLocal` | Score array construction |

> **Installation note:** The local components print a helpful message if `colbert` is not importable, but they do **not** raise — the subsequent `from colbert import ...` will raise `ImportError`. Ensure `colbert-ai` is installed before using the local retriever or reranker.

---

## Related Modules

- **[dsp_retrieval_dpr.md](dsp_retrieval_dpr.md)** — The DPR tokenizer utilities (`SimpleTokenizer`, `Tokenizer`, `Tokens`) used for passage/query tokenization in retrieval pipelines.
- **[retrievers.md](retrievers.md)** — Higher-level DSPy retriever modules (e.g. `Retrieve`, `Embeddings`, `DatabricksRM`) that integrate retrieval into programs.
- **[clients_cache.md](clients_cache.md)** — The caching layer backing `request_cache`.
- **[dsp_utils.md](dsp_utils.md)** — Shared utilities including `dotdict` and `Settings`.

---

## Usage Examples

### Remote retrieval

```python
from dspy.dsp.colbertv2 import ColBERTv2

retriever = ColBERTv2(url="http://20.102.90.50:2017/wiki17_abstracts")
passages = retriever("What is the capital of France?", k=5, simplify=True)
```

### Local retrieval

```python
from colbert.infra.config import ColBERTConfig
from dspy.dsp.colbertv2 import ColBERTv2RetrieverLocal

config = ColBERTConfig(
    checkpoint="colbert-ir/colbertv2.0",
    index_name="my_index",
    experiment="my_experiment",
)
retriever = ColBERTv2RetrieverLocal(passages=my_passages, colbert_config=config)
results = retriever("What is the capital of France?", k=7)
```

### Local reranking

```python
from dspy.dsp.colbertv2 import ColBERTv2RerankerLocal

reranker = ColBERTv2RerankerLocal(checkpoint="colbert-ir/colbertv2.0")
scores = reranker("What is the capital of France?", passages=["Paris is the capital.", "Berlin is a city."])
```
