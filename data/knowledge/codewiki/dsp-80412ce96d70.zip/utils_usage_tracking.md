# Utils Usage Tracking

## Introduction

The `utils_usage_tracking` module provides lightweight, context-scoped tracking of Language Model (LM) token usage within DSPy. Its central component, `UsageTracker`, accumulates per-model usage entries (prompt tokens, completion tokens, and their detailed breakdowns) and exposes aggregated totals. A companion context manager, `track_usage()`, activates tracking for the duration of a `with` block by installing a tracker into DSPy's global [`Settings`](dsp_utils_settings.md) context.

This module is intentionally decoupled from the LM call path: it does not perform any LM calls itself. Instead, it is *consumed* by LM implementations (such as [`LM`](clients_lm.md)) which push usage data into the active tracker whenever a non-cached response is received.

---

## Module Structure

The module lives at `dspy/utils/usage_tracker.py` and contains two public symbols:

| Symbol | Kind | Purpose |
| --- | --- | --- |
| `UsageTracker` | Class | Stores and aggregates usage entries keyed by LM name. |
| `track_usage` | Context manager | Creates a `UsageTracker` and installs it into `settings.context(usage_tracker=...)`. |

```mermaid
graph TD
    subgraph "utils_usage_tracking"
        UT["UsageTracker"]
        TU["track_usage()"]
    end

    TU -->|creates| UT
    TU -->|installs via| Settings["Settings.context()"]
    Settings -->|exposes| UT
    LM["LM / BaseLM"] -->|reads settings.usage_tracker| UT
    LM -->|add_usage(model, usage)| UT
```

---

## Core Component: `UsageTracker`

`UsageTracker` is a simple accumulator. Internally it holds a `defaultdict(list)` mapping an LM identifier (e.g. `"openai/gpt-4o-mini"`) to a list of raw usage dictionaries.

```python
self.usage_data = defaultdict(list)
# {
#     "openai/gpt-4o-mini": [
#         {"prompt_tokens": 100, "completion_tokens": 200},
#         {"prompt_tokens": 300, "completion_tokens": 400},
#     ],
# }
```

### Public API

#### `add_usage(lm: str, usage_entry: dict)`

Appends a usage entry for the given LM. Empty entries are ignored. Before storage, the entry is passed through `_flatten_usage_entry` to normalize nested detail objects.

#### `get_total_tokens() -> dict[str, dict[str, Any]]`

Iterates over all tracked LMs and merges every recorded entry into a single aggregated dictionary per LM. Returns a mapping of `lm_name -> total_usage`.

### Internal Helpers

| Method | Responsibility |
| --- | --- |
| `_flatten_usage_entry(usage_entry)` | Shallow-copies the entry and converts `completion_tokens_details` / `prompt_tokens_details` into plain `dict`s, ensuring downstream merging works on consistent types. |
| `_merge_usage_entries(entry1, entry2)` | Recursively merges two usage dictionaries. Numeric fields are summed; nested dictionaries (e.g. token detail breakdowns) are merged recursively. Handles `None`/empty inputs gracefully. |

### Aggregation Logic

The merge routine is the heart of the tracker. It supports arbitrarily nested usage structures (as returned by providers like OpenAI) by recursing whenever either side of a key is a `dict`:

```mermaid
flowchart TD
    A["_merge_usage_entries(e1, e2)"] --> B{"e1 empty?"}
    B -->|yes| C["return copy(e2)"]
    B -->|no| D{"e2 empty?"}
    D -->|yes| E["return copy(e1)"]
    D -->|no| F["result = copy(e2)"]
    F --> G["for each key k in e1"]
    G --> H{"v or result[k] is dict?"}
    H -->|yes| I["recurse merge"]
    H -->|no| J["result[k] = (current or 0) + (v or 0)"]
    I --> K["next key"]
    J --> K
    K --> G
```

---

## Context Manager: `track_usage()`

`track_usage()` is a `@contextmanager` that wires a fresh `UsageTracker` into DSPy's thread-local settings for the duration of the block:

```python
@contextmanager
def track_usage():
    tracker = UsageTracker()
    with settings.context(usage_tracker=tracker):
        yield tracker
```

Because it uses [`Settings.context()`](dsp_utils_settings.md), the tracker is scoped to the current thread (and propagates to child threads spawned via DSPy's parallel primitives). This makes it safe to nest and to use concurrently across threads without cross-contamination.

### Usage Example

```python
import dspy
from dspy.utils.usage_tracker import track_usage

lm = dspy.LM("openai/gpt-4o-mini")
dspy.configure(lm=lm)

with track_usage() as tracker:
    dspy.Predict("q->a")(q="Why did the chicken cross the kitchen?")

print(tracker.get_total_tokens())
# {"openai/gpt-4o-mini": {"prompt_tokens": ..., "completion_tokens": ..., ...}}
```

---

## Integration with the LM Call Path

The tracker is passive until an LM pushes data into it. The integration point is in [`LM.forward` / `LM.aforward`](clients_lm.md), which checks for an active tracker after each non-cached response:

```python
if not getattr(results, "cache_hit", False) and dspy.settings.usage_tracker and hasattr(results, "usage"):
    settings.usage_tracker.add_usage(self.model, dict(results.usage))
```

Key behaviors:

- **Cache-aware**: Cached responses (`cache_hit == True`) are *not* recorded, avoiding double counting.
- **Opt-in**: If no `usage_tracker` is present in settings, nothing is recorded and there is zero overhead beyond a settings lookup.
- **Provider-agnostic**: Any [`BaseLM`](clients_lm.md) subclass that returns an OpenAI-style response with a `usage` attribute can participate.

```mermaid
sequenceDiagram
    participant User
    participant track_usage
    participant Settings
    participant LM
    participant UsageTracker

    User->>track_usage: with track_usage() as tracker
    track_usage->>UsageTracker: create()
    track_usage->>Settings: context(usage_tracker=tracker)
    User->>LM: __call__(prompt)
    LM->>LM: forward() -> provider response
    LM->>Settings: read usage_tracker
    Settings-->>LM: tracker
    LM->>UsageTracker: add_usage(model, usage)
    User->>UsageTracker: get_total_tokens()
    UsageTracker-->>User: aggregated totals
    track_usage->>Settings: reset context
```

---

## Data Flow

```mermaid
flowchart LR
    subgraph Provider
        R["LM response with .usage"]
    end
    R -->|dict(results.usage)| AU["UsageTracker.add_usage"]
    AU --> FL["_flatten_usage_entry"]
    FL --> STORE["usage_data[lm].append(...)"]
    STORE --> GT["get_total_tokens()"]
    GT --> MG["_merge_usage_entries (recursive)"]
    MG --> OUT["Aggregated totals per LM"]
```

---

## Design Notes & Guarantees

- **Thread-local scoping**: Relies on [`Settings.context()`](dsp_utils_settings.md), so trackers do not leak across threads or async tasks.
- **Nested-safe merging**: `_merge_usage_entries` handles nested detail dictionaries (e.g. `prompt_tokens_details.cached_tokens`) by recursing, so provider-specific breakdowns are preserved and summed correctly.
- **Defensive normalization**: `_flatten_usage_entry` converts detail objects to plain dicts, preventing type mismatches during merging.
- **No global state of its own**: The tracker holds no module-level state; all state lives on the instance and is scoped by the settings context.

---

## Related Modules

- [dsp_utils_settings](dsp_utils_settings.md) — the `Settings` singleton providing the thread-local `context()` mechanism used to install the tracker.
- [clients_lm](clients_lm.md) — `LM` / `BaseLM` implementations that call `add_usage` on the active tracker.
- [utils_parallelization](utils_parallelization.md) — parallel primitives that propagate settings overrides (and thus the tracker) to child threads.
