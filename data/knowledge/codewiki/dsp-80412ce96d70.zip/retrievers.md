# Retrievers

## Overview

The **retrievers** module provides DSPy's retrieval abstraction layer. Retrieval is a core
building block of retrieval-augmented generation (RAG) pipelines: given a query, a retriever
returns a set of relevant passages from a corpus. DSPy exposes retrieval through a single,
uniform interface — the [`Retrieve`](retrievers_core.md) module — so that programs can be
written once and run against many different backends (local embeddings, hosted vector
databases, or cloud vector search services).

The module contains four core components:

| Component | File | Role |
|-----------|------|------|
| [`Retrieve`](retrievers_core.md) | `dspy/retrievers/retrieve.py` | The base retrieval module and the public `dspy.Retrieve` API. Delegates to the globally configured retrieval model (`dspy.settings.rm`). |
| [`Embeddings`](retrievers_embeddings.md) | `dspy/retrievers/embeddings.py` | A self-contained, in-memory retriever that embeds a corpus and performs nearest-neighbor search (brute force or FAISS). |
| [`DatabricksRM`](retrievers_databricks.md) | `dspy/retrievers/databricks_rm.py` | A retriever backed by a Databricks Mosaic AI Vector Search Index. |
| [`WeaviateRM`](retrievers_weaviate.md) | `dspy/retrievers/weaviate_rm.py` | A retriever backed by a Weaviate vector database collection. |

## Architecture

The module follows a **strategy pattern**: `Retrieve` defines the stable, user-facing interface,
while concrete retrieval backends (`Embeddings`, `DatabricksRM`, `WeaviateRM`, and any custom
retriever) implement the actual search logic. `Retrieve` is a thin dispatcher that forwards
queries to whichever retrieval model is configured in `dspy.settings.rm`.

```mermaid
graph TD
    User["User code / DSPy program"] -->|"dspy.Retrieve(k=...)(query)"| Retrieve["Retrieve<br/>(retrieve.py)"]
    Retrieve -->|"reads dspy.settings.rm"| Settings["dspy.settings"]
    Settings -->|"rm(query, k=...)"| RM["Configured retrieval model"]

    RM --> Embeddings["Embeddings<br/>(embeddings.py)"]
    RM --> Databricks["DatabricksRM<br/>(databricks_rm.py)"]
    RM --> Weaviate["WeaviateRM<br/>(weaviate_rm.py)"]
    RM --> Custom["Custom retriever"]

    Embeddings -->|"uses"| Embedder["dspy.Embedder<br/>(clients/embedding.py)"]
    Embeddings -->|"uses"| Unbatchify["Unbatchify<br/>(utils/unbatchify.py)"]
    Databricks -->|"uses"| DatabricksSDK["databricks-sdk / requests"]
    Weaviate -->|"uses"| WeaviateClient["weaviate client"]

    Retrieve -->|"returns"| Prediction["dspy.Prediction"]
    Embeddings -->|"returns"| Prediction
    Databricks -->|"returns"| Prediction
    Weaviate -->|"returns"| Prediction
```

### Two ways to use retrieval

DSPy supports two complementary usage patterns, both of which ultimately produce a
`dspy.Prediction` containing retrieved passages:

1. **Global retrieval model** — Configure a retriever once via
   `dspy.settings.configure(rm=...)` and then call `dspy.Retrieve(k=...)`. The `Retrieve`
   module reads `dspy.settings.rm` at call time and delegates to it. This is the idiomatic
   DSPy pattern and is documented in [retrievers_core.md](retrievers_core.md).

2. **Direct backend usage** — Instantiate a concrete backend (e.g. `Embeddings`,
   `DatabricksRM`, `WeaviateRM`) and call it directly. This is useful when a program needs
   multiple, differently-configured retrievers.

## Component Relationships

```mermaid
classDiagram
    class Parameter
    class Retrieve {
        +name = "Search"
        +input_variable = "query"
        +k: int
        +callbacks: list
        +forward(query, k, **kwargs) Prediction
        +dump_state() dict
        +load_state(state)
    }
    class Embeddings {
        +corpus: list[str]
        +embedder
        +k: int
        +forward(query) Prediction
        +_build_faiss()
        +_faiss_search()
        +_rerank_and_predict()
    }
    class DatabricksRM {
        +databricks_index_name: str
        +k: int
        +forward(query, query_type, filters_json)
        +_query_via_databricks_sdk()
        +_query_via_requests()
    }
    class WeaviateRM {
        +weaviate_collection_name: str
        +k: int
        +forward(query_or_queries, k) Prediction
        +get_objects()
        +insert()
    }

    Parameter <|-- Retrieve
    Retrieve <|-- DatabricksRM
    Retrieve <|-- WeaviateRM
    Embeddings ..> Embedder : uses
    Embeddings ..> Unbatchify : uses
```

> Note: `DatabricksRM` and `WeaviateRM` subclass `dspy.Retrieve`, so they can be used both as
> the global `rm` and directly. `Embeddings` is a standalone class that exposes a compatible
> `forward`/`__call__` interface.

## Sub-modules

### Core retrieval abstraction — [`retrievers_core.md`](retrievers_core.md)

The [`Retrieve`](retrievers_core.md) class is the heart of the module. It defines the
`Search` parameter, manages serialization state (`k`), and forwards queries to the globally
configured retrieval model. It is the recommended entry point for most DSPy programs and
handles the normalization of backend responses into a `dspy.Prediction(passages=...)`.

### Local embeddings retriever — [`retrievers_embeddings.md`](retrievers_embeddings.md)

[`Embeddings`](retrievers_embeddings.md) implements a fully local, in-memory retriever. It
embeds the entire corpus up front using a `dspy.Embedder`, then answers queries by either
brute-force cosine similarity (small corpora) or an approximate FAISS index (large corpora,
above `brute_force_threshold`). It uses `Unbatchify` to transparently batch concurrent
single-query calls.

### Databricks Vector Search retriever — [`retrievers_databricks.md`](retrievers_databricks.md)

[`DatabricksRM`](retrievers_databricks.md) queries a Databricks Mosaic AI Vector Search
Index. It supports both text and vector queries, ANN and HYBRID search, metadata filtering,
and two transport mechanisms (the Databricks SDK or raw HTTP via `requests`). It also
supports the Databricks Mosaic Agent Framework output format via the `Document` dataclass.

### Weaviate retriever — [`retrievers_weaviate.md`](retrievers_weaviate.md)

[`WeaviateRM`](retrievers_weaviate.md) queries a Weaviate collection using hybrid search.
It supports both the v3 (`Client`) and v4 (`WeaviateClient`) Weaviate Python clients, tenant
scoping, and provides `get_objects`/`insert` helpers for corpus management.

## Data Flow

The following diagram shows the end-to-end flow of a retrieval call through the global
`Retrieve` module:

```mermaid
sequenceDiagram
    participant P as DSPy Program
    participant R as Retrieve
    participant S as dspy.settings
    participant RM as Retrieval Model
    participant PR as Prediction

    P->>R: __call__(query, k=...)
    R->>R: with_callbacks wrapper
    R->>R: forward(query, k)
    R->>S: read settings.rm
    alt rm is not configured
        R-->>P: AssertionError("No RM is loaded.")
    else rm is configured
        R->>RM: rm(query, k=k, **kwargs)
        RM-->>R: passages (iterable)
        R->>R: normalize to list of long_text
        R->>PR: Prediction(passages=[...])
        PR-->>P: Prediction
    end
```

## Dependencies

The retrievers module builds on several other DSPy modules and external libraries:

- **[predict](predict.md)** — `Retrieve` extends `Parameter` from `dspy.predict.parameter`.
- **[primitives](primitives.md)** — Results are wrapped in `dspy.Prediction`.
- **[clients](clients.md)** — `Embeddings` uses `dspy.Embedder` for computing embeddings.
- **[utils](utils.md)** — `Retrieve` uses the `with_callbacks` decorator; `Embeddings` uses
  `Unbatchify`; `WeaviateRM` uses `dotdict`.
- **External**: `numpy`, `faiss-cpu` (optional), `databricks-sdk` (optional), `requests`,
  `weaviate` (optional), `mlflow` (optional, for the Databricks Agent Framework).

## Extending the Module

To add a new retrieval backend, subclass `dspy.Retrieve` and implement `forward`. The base
class handles callbacks, state serialization, and the `k` default. A minimal backend looks
like:

```python
import dspy

class MyRetriever(dspy.Retrieve):
    def __init__(self, k=3):
        super().__init__(k=k)

    def forward(self, query, k=None, **kwargs):
        k = k or self.k
        passages = my_search_backend(query, k)
        return dspy.Prediction(passages=passages)
```

Then configure it globally with `dspy.settings.configure(rm=MyRetriever())` and use it via
`dspy.Retrieve`.
