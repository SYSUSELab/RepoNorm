# Adapter Types: Tool

## Introduction

The `adapter_types_tool` module provides the `Tool` and `ToolCalls` custom types used by DSPy adapters to support **tool calling (function calling)** with Large Language Models. These types bridge the gap between Python callables and the structured JSON schemas that LLM providers expect, while also handling the parsing and validation of tool-call arguments returned by models.

The module is part of the broader [adapter types](adapter_types.md) family, which defines the custom types that DSPy adapters understand and serialize. It builds directly on the base [`Type`](adapter_types_base_type.md) class and integrates with the DSPy callback system and settings.

---

## Core Components

| Component | Kind | Purpose |
|-----------|------|---------|
| `Tool` | Class | Wraps a Python callable, auto-infers its name/description/args, validates and parses arguments, and exposes provider-compatible schemas. |
| `ToolCalls` | Class | Represents a collection of tool calls (name + args) returned by an LLM, with formatting compatible with OpenAI's tool-call schema. |
| `ToolCalls.ToolCall` | Nested Pydantic model | A single tool call consisting of a `name` and an `args` dictionary. |
| `_resolve_json_schema_reference` | Function | Recursively expands `$ref`/`$defs` references in a JSON schema. |
| `convert_input_schema_to_tool_args` | Function | Converts a JSON input schema into DSPy `Tool` args, arg types, and arg descriptions. |

---

## Architecture

The module sits at the intersection of three concerns: **type definition** (inheriting from `Type`), **schema generation** (via Pydantic and `jsonschema`), and **execution** (calling the wrapped function, sync or async).

```mermaid
graph TD
    subgraph "adapter_types_tool"
        Tool["Tool"]
        ToolCalls["ToolCalls"]
        ToolCall["ToolCalls.ToolCall"]
        ResolveRef["_resolve_json_schema_reference"]
        ConvertSchema["convert_input_schema_to_tool_args"]
    end

    subgraph "Base Types"
        Type["Type (base_type.py)"]
    end

    subgraph "DSPy Infrastructure"
        Settings["settings (dsp_utils)"]
        Callbacks["with_callbacks (utils/callback)"]
    end

    subgraph "External Libraries"
        Pydantic["pydantic (BaseModel, TypeAdapter, create_model)"]
        JSONSchema["jsonschema (validate, ValidationError)"]
        MCP["mcp (optional)"]
        LangChain["langchain.tools.BaseTool (optional)"]
    end

    Tool -->|inherits| Type
    ToolCalls -->|inherits| ToolCall
    ToolCalls -->|inherits| Type
    Tool -->|uses| ResolveRef
    Tool -->|uses| Pydantic
    Tool -->|uses| JSONSchema
    Tool -->|decorated by| Callbacks
    Tool -->|reads| Settings
    Tool -->|converts from| MCP
    Tool -->|converts from| LangChain
    ConvertSchema -->|uses| ResolveRef
```

---

## Component Details

### `Tool`

`Tool` wraps a Python callable and makes it usable for LLM function calling. It inherits from [`Type`](adapter_types_base_type.md), so it participates in the adapter serialization pipeline.

#### Fields

| Field | Type | Description |
|-------|------|-------------|
| `func` | `Callable` | The wrapped function. |
| `name` | `str \| None` | Tool name; inferred from the function if not provided. |
| `desc` | `str \| None` | Tool description; inferred from the function docstring if not provided. |
| `args` | `dict[str, Any] \| None` | JSON schema per argument name. |
| `arg_types` | `dict[str, Any] \| None` | Python type per argument name. |
| `arg_desc` | `dict[str, str] \| None` | Description per argument name. |
| `has_kwargs` | `bool` | Whether the function accepts `**kwargs`. |

#### Initialization and Inference

When a `Tool` is constructed, `_parse_function` inspects the callable:

1. Resolves the callable to inspect (`func` itself, or `func.__call__` for callable objects).
2. Derives `name` from `__name__` (or the class name) and `desc` from the docstring.
3. Uses `inspect.signature` and `get_type_hints` to build a mapping of argument name → type.
4. For each argument, generates a JSON schema:
   - If the type (or its origin) is a Pydantic `BaseModel` subclass, uses `model_json_schema()`.
   - Otherwise, uses `TypeAdapter(v).json_schema()`.
   - Resolves `$ref` references via `_resolve_json_schema_reference`.
   - Attaches `default` values and `description` (from `arg_desc`) when present.
5. Sets `has_kwargs` if any parameter is `VAR_KEYWORD`.

User-supplied values for `name`, `desc`, `args`, and `arg_types` take precedence; inference is skipped for those.

#### Argument Validation and Parsing

`_validate_and_parse_args(**kwargs)` performs two steps:

- **Validation**: Each provided argument is validated against its JSON schema using `jsonschema.validate`. Unknown arguments raise `ValueError` unless the function accepts `**kwargs`.
- **Parsing**: Arguments are coerced to their declared Python types using a dynamically created Pydantic wrapper model (`create_model("Wrapper", value=(type, ...))`). This handles nested types such as `list[list[MyPydanticModel]]`.

#### Execution

| Method | Behavior |
|--------|----------|
| `__call__(**kwargs)` | Validates/parses args, calls the function. If the result is a coroutine, runs it synchronously when `settings.allow_tool_async_sync_conversion` is enabled; otherwise raises `ValueError`. |
| `acall(**kwargs)` | Async variant. Awaits coroutine results; sync functions are allowed and returned directly. |

Both methods are decorated with [`with_callbacks`](utils_callback.md), so start/end callbacks fire around execution.

#### Formatting and Conversion

| Method | Purpose |
|--------|---------|
| `format()` | Returns `str(self)`. |
| `format_as_litellm_function_call()` | Produces a LiteLLM/OpenAI-compatible function-call schema (`type`, `function.name`, `function.description`, `function.parameters`). |
| `from_mcp_tool(session, tool)` | Classmethod; builds a `Tool` from an MCP tool via `dspy.utils.mcp.convert_mcp_tool`. |
| `from_langchain(tool)` | Classmethod; builds a `Tool` from a LangChain `BaseTool` via `dspy.utils.langchain_tool.convert_langchain_tool`. |

#### String Representation

- `__repr__` → `Tool(name=..., desc=..., args=...)`
- `__str__` → a human-readable description used in prompts, e.g. `name, whose description is <desc>...</desc>. It takes arguments {...}.`

---

### `ToolCalls`

`ToolCalls` represents the set of tool calls an LLM decides to make. It inherits from [`Type`](adapter_types_base_type.md).

#### Fields

| Field | Type | Description |
|-------|------|-------------|
| `tool_calls` | `list[ToolCall]` | The list of individual tool calls. |

#### Nested `ToolCall` Model

```python
class ToolCall(BaseModel):
    name: str
    args: dict[str, Any]
```

#### Methods

| Method | Purpose |
|--------|---------|
| `from_dict_list(tool_calls_dicts)` | Classmethod; builds a `ToolCalls` from a list of `{"name": ..., "args": ...}` dictionaries. |
| `description()` | Classmethod; returns a human-readable description used in prompts. |
| `format()` | Returns a list of dictionaries compatible with OpenAI's tool-call schema. |

---

### Helper Functions

#### `_resolve_json_schema_reference(schema)`

Recursively expands all `$ref` references in a JSON schema using its `$defs` (or `definitions`) section, then removes the `$defs` key. Returns the schema unchanged if no definitions are present.

#### `convert_input_schema_to_tool_args(schema)`

Converts a JSON input schema into a tuple of `(args, arg_types, arg_desc)` suitable for constructing a `Tool`. It:

- Reads `properties`, `required`, and `$defs` from the schema.
- Resolves references per property.
- Maps JSON types to Python types via `_TYPE_MAPPING` (`string→str`, `integer→int`, `number→float`, `boolean→bool`, `array→list`, `object→dict`).
- Appends `" (Required)"` to descriptions of required arguments.

---

## Data Flow

The following diagram shows how a tool call flows from an LLM response back to a Python function invocation.

```mermaid
sequenceDiagram
    participant LLM as LLM Response
    participant Adapter as Adapter
    participant TC as ToolCalls
    participant Tool as Tool
    participant Func as Wrapped Function

    LLM->>Adapter: Raw tool-call output
    Adapter->>TC: from_dict_list([{name, args}])
    TC-->>Adapter: ToolCalls instance
    Adapter->>Tool: __call__(**args) / acall(**args)
    Tool->>Tool: _validate_and_parse_args(**args)
    Note over Tool: Validate against JSON schema,<br/>coerce to Python types
    Tool->>Func: func(**parsed_kwargs)
    Func-->>Tool: result
    Tool-->>Adapter: result
```

---

## Tool Construction Flow

```mermaid
flowchart TD
    Start([Tool(func)]) --> Parse["_parse_function(func, arg_desc)"]
    Parse --> Resolve["Resolve callable & docstring"]
    Resolve --> Hints["get_type_hints + inspect.signature"]
    Hints --> Loop{"For each argument"}
    Loop -->|BaseModel subclass| ModelSchema["model_json_schema()"]
    Loop -->|Other type| TypeAdapterSchema["TypeAdapter(v).json_schema()"]
    ModelSchema --> ResolveRef["_resolve_json_schema_reference"]
    TypeAdapterSchema --> ResolveRef
    ResolveRef --> Attach["Attach default & description"]
    Attach --> Loop
    Loop -->|Done| SetFields["Set name, desc, args, arg_types, has_kwargs"]
    SetFields --> End([Tool ready])
```

---

## Integration with the Adapter System

`Tool` and `ToolCalls` are consumed by DSPy adapters when serializing signatures and parsing model outputs:

- **Serialization**: Adapters call `Tool.format_as_litellm_function_call()` to expose tools to providers, and `ToolCalls.format()` to render tool-call content.
- **Parsing**: Adapters use `ToolCalls.from_dict_list()` to interpret model output, then invoke the corresponding `Tool` via `__call__`/`acall`.
- **Type detection**: The base [`Type.extract_custom_type_from_annotation`](adapter_types_base_type.md) allows adapters to detect `Tool`/`ToolCalls` nested arbitrarily deep within field annotations.

For details on how adapters use these types, see the [adapters core documentation](adapters_core.md).

---

## Dependencies

| Dependency | Role |
|------------|------|
| [`Type`](adapter_types_base_type.md) | Base class providing `format`, `description`, and serialization. |
| [`with_callbacks`](utils_callback.md) | Decorator adding start/end callback hooks to `__call__` and `acall`. |
| `settings` (dsp_utils) | Provides `allow_tool_async_sync_conversion` to control async-in-sync execution. |
| `pydantic` | `BaseModel`, `TypeAdapter`, `create_model` for schema generation and parsing. |
| `jsonschema` | `validate` and `ValidationError` for argument validation. |
| `mcp` (optional) | Source type for `from_mcp_tool`. |
| `langchain.tools.BaseTool` (optional) | Source type for `from_langchain`. |

---

## Related Documentation

- [Adapter Types Overview](adapter_types.md)
- [Base Type](adapter_types_base_type.md)
- [Adapters Core](adapters_core.md)
- [Callback Utilities](utils_callback.md)
