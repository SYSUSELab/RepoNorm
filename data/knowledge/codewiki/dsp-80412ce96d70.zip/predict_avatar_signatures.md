# predict_avatar_signatures

## Introduction

The `predict_avatar_signatures` module defines the **`Actor`** signature used by the [Avatar](predict_avatar_core.md) agent. The `Actor` signature is the declarative contract that instructs a language model to select a tool and produce the input query needed to accomplish a given goal. It is the reasoning "brain" that drives the iterative tool-use loop implemented in the Avatar module.

This module is intentionally minimal: it contains a single DSPy `Signature` subclass. Its purpose is to describe *what* the model should produce (an action consisting of a tool name and an input query), while the surrounding [Avatar](predict_avatar_core.md) module handles *how* that action is executed, iterated, and turned into a final answer.

---

## Module Overview

| Aspect | Description |
| --- | --- |
| **Core component** | `Actor` (a `dspy.Signature`) |
| **Primary responsibility** | Declare the input/output contract for tool selection and query generation |
| **Consumed by** | [Avatar](predict_avatar_core.md) (via `dspy.TypedPredictor`) |
| **Depends on** | [predict_avatar_models](predict_avatar_models.md) (`Action`), [signatures](signatures.md) (`dspy.Signature`, `dspy.InputField`, `dspy.OutputField`) |

---

## The `Actor` Signature

The `Actor` signature is defined in `dspy/predict/avatar/signatures.py`:

```python
import dspy
from dspy.predict.avatar.models import Action


class Actor(dspy.Signature):
    """You will be given `Tools` which will be a list of tools to use to accomplish the `Goal`.
    Given the user query, your task is to decide which tool to use and what input values to provide.

    You will output action needed to accomplish the `Goal`. `Action` should have a tool to use
    and the input query to pass to the tool.

    Note: You can opt to use no tools and provide the final answer directly. You can also one
    tool multiple times with different input queries if applicable."""

    goal: str = dspy.InputField(
        prefix="Goal:",
        desc="Task to be accomplished.",
    )
    tools: list[str] = dspy.InputField(
        prefix="Tools:",
        desc="list of tools to use",
    )
    action_1: Action = dspy.OutputField(
        prefix="Action 1:",
        desc="1st action to take.",
    )
```

### Fields

| Field | Direction | Type | Prefix | Description |
| --- | --- | --- | --- | --- |
| `goal` | Input | `str` | `Goal:` | The task to be accomplished. |
| `tools` | Input | `list[str]` | `Tools:` | The list of tool names available for use. |
| `action_1` | Output | [`Action`](predict_avatar_models.md) | `Action 1:` | The first action to take, containing a tool name and an input query. |

### The `Action` Output Type

The `action_1` output field is typed as an [`Action`](predict_avatar_models.md) Pydantic model, which carries two attributes:

- `tool_name` — the name of the tool to invoke.
- `tool_input_query` — the query to pass as input to that tool.

Because the output is a structured `Action` object rather than free text, the model is constrained to produce a machine-parseable tool selection. This is what allows the [Avatar](predict_avatar_core.md) loop to dispatch the action to the correct tool.

---

## Role in the Avatar Agent

The `Actor` signature is not used in isolation. The [Avatar](predict_avatar_core.md) module dynamically **extends** this signature at runtime to support multi-step reasoning:

1. **Initialization** — Avatar appends the user's own input fields to the `Actor` signature so the model has full context.
2. **Iteration** — After each tool call, Avatar calls `_update_signature` to:
   - Convert the previous `action_{idx}` output field into an input field (so the model sees what it already did).
   - Append a `result_{idx}` input field containing the tool's output.
   - Append a new `action_{idx+1}` output field for the next step.
3. **Termination** — When the model selects the special `Finish` tool, Avatar omits the next action field and instead appends the user's output fields, prompting the model to produce the final answer.

This means the `Actor` signature serves as a **template** that grows into a multi-turn action/result history as the agent progresses.

### Interaction Diagram

```mermaid
flowchart TD
    subgraph Avatar["Avatar Module (predict_avatar_core)"]
        A[forward loop] -->|builds args| B[TypedPredictor]
        B -->|uses| C[Actor Signature]
        C -->|produces| D[Action object]
        D -->|tool_name + query| E[_call_tool]
        E -->|tool_output| F[ActionOutput]
        F -->|result_idx| A
        A -->|_update_signature| C
    end

    subgraph Models["predict_avatar_models"]
        D -.->|typed as| G[Action]
        F -.->|typed as| H[ActionOutput]
        I[Tool] -.->|name/desc| C
    end
```

---

## Data Flow

The following sequence diagram illustrates how the `Actor` signature participates in a single Avatar iteration and how its fields evolve.

```mermaid
sequenceDiagram
    participant User
    participant Avatar
    participant Actor as Actor Signature
    participant Tool

    User->>Avatar: forward(goal, ...inputs)
    Avatar->>Actor: goal + tools + input fields
    Actor-->>Avatar: action_1 (Action)
    Avatar->>Tool: run(tool_input_query)
    Tool-->>Avatar: tool_output
    Avatar->>Actor: _update_signature(idx=1)
    Note over Actor: action_1 becomes input,<br/>result_1 added,<br/>action_2 added
    Avatar->>Actor: goal + tools + action_1 + result_1
    Actor-->>Avatar: action_2 (Action)
    alt tool_name == "Finish"
        Avatar->>Actor: _update_signature(omit_action=True)
        Note over Actor: output fields appended
        Actor-->>Avatar: final answer fields
    end
    Avatar-->>User: Prediction(outputs, actions)
```

---

## Dependency Graph

```mermaid
flowchart LR
    Actor["Actor (signatures.py)"]
    Action["Action (models.py)"]
    Signature["dspy.Signature"]
    InputField["dspy.InputField"]
    OutputField["dspy.OutputField"]
    Avatar["Avatar (avatar.py)"]

    Actor -->|subclass of| Signature
    Actor -->|uses| InputField
    Actor -->|uses| OutputField
    Actor -->|output typed as| Action
    Avatar -->|instantiates via TypedPredictor| Actor
```

---

## Design Notes

- **Structured output over free text.** By typing `action_1` as an `Action` model, the signature enforces structured tool selection, which is essential for reliable programmatic dispatch.
- **Single-action template.** The signature declares only `action_1`. The multi-step behavior is achieved by the [Avatar](predict_avatar_core.md) module mutating the signature at runtime, keeping the base signature simple and reusable.
- **Finish convention.** The signature's docstring explicitly allows the model to "opt to use no tools and provide the final answer directly." This is realized through the special `Finish` tool injected by Avatar, which signals loop termination.

---

## Related Modules

- [predict_avatar_core](predict_avatar_core.md) — The `Avatar` agent that consumes and dynamically extends this signature.
- [predict_avatar_models](predict_avatar_models.md) — Defines `Action`, `ActionOutput`, and `Tool`, the data models referenced by this signature.
- [signatures](signatures.md) — The base `Signature` / `SignatureMeta` infrastructure and field definitions.
- [predict_core](predict_core.md) — The `Predict` / `Parameter` primitives underlying `TypedPredictor`.
