# Adapter Types: History

## Introduction

The `adapter_types_history` module provides the `History` type, a core DSPy custom type used to represent **multi-turn conversation history** within a DSPy signature. It allows a `Predict` module (or any module built on top of it) to receive prior conversation turns as structured input, enabling stateful, context-aware interactions with language models.

`History` is one of several custom types in the `dspy/adapters/types/` package (alongside `Image`, `Audio`, `Code`, `Tool`, and `ToolCalls`). It is unique among them because it is not a media or tool type — instead, it is a **structural type** that the adapters recognize and expand into multiple chat messages.

---

## Core Component

### `History`

**Location:** `dspy/adapters/types/history.py`

`History` is a Pydantic `BaseModel` that wraps a list of message dictionaries.

```python
class History(pydantic.BaseModel):
    messages: list[dict[str, Any]]

    model_config = {
        "frozen": True,
        "str_strip_whitespace": True,
        "validate_assignment": True,
        "extra": "forbid",
    }
```

#### Fields

| Field      | Type                    | Description                                                                                          |
| ---------- | ----------------------- | ---------------------------------------------------------------------------------------------------- |
| `messages` | `list[dict[str, Any]]`  | A list of message dictionaries. Each dictionary's keys must correspond to the fields of the signature. |

#### Model Configuration

| Setting                 | Value   | Purpose                                                                 |
| ----------------------- | ------- | ----------------------------------------------------------------------- |
| `frozen`                | `True`  | Instances are immutable after creation.                                 |
| `str_strip_whitespace`  | `True`  | Leading/trailing whitespace is stripped from string values.             |
| `validate_assignment`   | `True`  | Re-validates on attribute assignment (relevant for nested structures).  |
| `extra`                 | `forbid`| Rejects any unexpected fields, ensuring strict schema conformance.      |

> **Note:** Unlike other custom types such as `Image`, `Audio`, and `Code`, `History` does **not** subclass the `Type` base class and does **not** implement a `format()` method. This is because `History` is not serialized into a single content part — instead, the adapters detect it and expand it into a sequence of `user`/`assistant` messages. See [Adapter Types Base Type](adapter_types_base_type.md) for details on the `Type` base class.

---

## How History Fits Into the Type System

The `dspy/adapters/types/` package contains a family of custom types. The diagram below shows how `History` relates to its siblings.

```mermaid
graph TD
    Type["Type (base_type.py)<br/>abstract base class"]
    Image["Image"]
    Audio["Audio"]
    Code["Code"]
    Tool["Tool"]
    ToolCalls["ToolCalls"]
    History["History<br/>(standalone BaseModel)"]

    Type --> Image
    Type --> Audio
    Type --> Code
    Type --> Tool
    Type --> ToolCalls

    History -.->|"not a subclass;<br/>handled specially by adapters"| Type

    style History fill:#ffe6cc,stroke:#d79b00,stroke-width:2px
    style Type fill:#dae8fc,stroke:#6c8ebf
```

While `Image`, `Audio`, `Code`, `Tool`, and `ToolCalls` all inherit from `Type` and implement `format()` to produce OpenAI-style content parts, `History` is a plain `BaseModel` that the adapter layer treats as a **message-expansion directive**.

---

## Usage

### Declaring a History Field in a Signature

To use conversation history, declare an input field annotated with `dspy.History`:

```python
import dspy

dspy.settings.configure(lm=dspy.LM("openai/gpt-4o-mini"))

class MySignature(dspy.Signature):
    question: str = dspy.InputField()
    history: dspy.History = dspy.InputField()
    answer: str = dspy.OutputField()
```

The keys of each message dictionary in `History.messages` must match the **non-history fields** of the signature (e.g., `question` and `answer` above).

### Providing History Explicitly

```python
history = dspy.History(
    messages=[
        {"question": "What is the capital of France?", "answer": "Paris"},
        {"question": "What is the capital of Germany?", "answer": "Berlin"},
    ]
)

predict = dspy.Predict(MySignature)
outputs = predict(question="What is the capital of France?", history=history)
```

### Capturing History from Prior Calls

A common pattern is to build up history from previous predictions:

```python
predict = dspy.Predict(MySignature)
outputs = predict(question="What is the capital of France?")

history = dspy.History(messages=[{"question": "What is the capital of France?", **outputs}])
outputs_with_history = predict(question="Are you sure?", history=history)
```

---

## How Adapters Process History

The `History` type is consumed by the adapter layer. The base `Adapter` class (see [Adapters Core](adapters_core.md)) detects a history field and expands it into multi-turn messages.

### Detection

The base adapter locates the history field by scanning input fields for an annotation equal to `History`:

```python
def _get_history_field_name(self, signature):
    for name, field in signature.input_fields.items():
        if field.annotation == History:
            return name
    return None
```

### Expansion into Messages

When a history field is present, the adapter:

1. **Removes** the history field from the signature (`signature.delete(history_field_name)`).
2. **Formats** each message in `History.messages` into a `user` message (using the input fields) followed by an `assistant` message (using the output fields).
3. **Removes** the history field from the inputs dictionary so it is not rendered as a normal field.
4. **Appends** the current request as the final `user` message.

```mermaid
sequenceDiagram
    participant Caller
    participant Adapter
    participant Signature
    participant LM

    Caller->>Adapter: __call__(signature, demos, inputs)
    Adapter->>Adapter: _get_history_field_name(signature)
    alt History field present
        Adapter->>Signature: delete(history_field_name)
        Adapter->>Adapter: format_conversation_history(...)
        Note over Adapter: Expand each message into<br/>user + assistant turns
        Adapter->>Adapter: del inputs[history_field_name]
    end
    Adapter->>Adapter: format(signature, demos, inputs)
    Adapter->>LM: messages=[system, demos..., history..., current]
    LM-->>Adapter: completion
    Adapter->>Adapter: parse(...)
    Adapter-->>Caller: outputs
```

### Resulting Message Structure

The final message list passed to the LM follows this structure:

```
[
    {"role": "system",    "content": <field descriptions + structure + task>},
    # few-shot demos
    {"role": "user",      "content": <demo input>},
    {"role": "assistant", "content": <demo output>},
    # conversation history (from History.messages)
    {"role": "user",      "content": <history turn 1 input>},
    {"role": "assistant", "content": <history turn 1 output>},
    {"role": "user",      "content": <history turn 2 input>},
    {"role": "assistant", "content": <history turn 2 output>},
    # current request
    {"role": "user",      "content": <current input>},
]
```

The exact rendering of each `user`/`assistant` message depends on the concrete adapter in use (e.g., `ChatAdapter` uses `[[ ## field ## ]]` markers, while `JSONAdapter` uses JSON objects). See [Adapters Core](adapters_core.md) for adapter-specific formatting.

---

## Data Flow

The following diagram illustrates how a `History` object flows from user code through the adapter into the LM call.

```mermaid
flowchart LR
    A["User code<br/>dspy.History(messages=[...])"] --> B["Predict module<br/>inputs['history'] = History"]
    B --> C["Adapter.__call__"]
    C --> D{"History field<br/>detected?"}
    D -->|Yes| E["format_conversation_history()"]
    E --> F["Expand to user/assistant<br/>message pairs"]
    F --> G["Remove history field<br/>from signature & inputs"]
    D -->|No| H["Standard formatting"]
    G --> I["format() → messages list"]
    H --> I
    I --> J["LM call"]
    J --> K["parse() → outputs dict"]
```

---

## Relationship to Other Modules

| Module / Component | Relationship |
| ------------------ | ------------ |
| [Adapter Types Base Type](adapter_types_base_type.md) | `History` is a sibling custom type but does **not** subclass `Type`. |
| [Adapters Core](adapters_core.md) | The `Adapter` base class detects and expands `History` fields into multi-turn messages. |
| [Adapter Types Tool](adapter_types_tool.md) | Another custom type family (`Tool`, `ToolCalls`) handled specially by adapters. |
| [Adapter Types Media](adapter_types_media.md) | `Image` and `Audio` custom types that implement `format()`. |
| [Adapter Types Code](adapter_types_code.md) | The `Code` custom type. |
| [Predict](predict.md) | `dspy.Predict` is the primary consumer that passes `History` inputs to adapters. |
| [Signatures](signatures.md) | `History` is declared as a field annotation within a `Signature`. |

---

## Key Design Notes

- **Immutability:** `History` is frozen, so once constructed it cannot be mutated. To add turns, create a new `History` instance.
- **Strict schema:** `extra="forbid"` ensures that message dictionaries cannot contain unexpected keys, catching schema mismatches early.
- **No `format()` method:** Unlike other custom types, `History` relies on the adapter's `format_conversation_history` logic rather than a per-type `format()` method. This is because a single `History` object expands into *multiple* messages, not a single content part.
- **Field-key alignment:** The keys in each message dictionary must align with the signature's input/output field names (excluding the history field itself), otherwise the adapter's formatting will not produce meaningful turns.
