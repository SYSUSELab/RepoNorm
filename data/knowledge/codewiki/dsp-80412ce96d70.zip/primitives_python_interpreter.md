# Python Interpreter Module

## Introduction

The `primitives_python_interpreter` module provides a secure, sandboxed Python execution environment for DSPy. It enables DSPy programs to generate and execute arbitrary Python code safely by running it inside a WebAssembly-based sandbox powered by [Deno](https://deno.land/) and [Pyodide](https://pyodide.org/).

This module is a foundational primitive used by code-generating and agentic DSPy modules such as [`ProgramOfThought`](predict_reasoning.md) and [`CodeAct`](predict_agents.md), which rely on executing model-generated Python code to solve problems.

**Key capabilities:**

- Execute Python code in an isolated sandbox (no direct host access by default).
- Fine-grained permission control for file reads, file writes, environment variables, and network access.
- Variable injection into the sandboxed execution context.
- Bidirectional file synchronization between the host and the sandbox.
- A persistent Deno subprocess that can be reused across multiple executions.

---

## Core Components

| Component | Type | Description |
|-----------|------|-------------|
| `PythonInterpreter` | Class | Manages the Deno subprocess and provides the sandboxed execution API. |
| `InterpreterError` | Exception | Raised for sandbox-related failures (missing Deno, unsupported values, execution errors). |

---

## Architecture Overview

The interpreter acts as a bridge between the host Python process and a Deno subprocess running Pyodide. Communication happens over the subprocess's standard input/output streams using newline-delimited JSON messages.

```mermaid
graph TB
    subgraph Host["Host Python Process"]
        PI["PythonInterpreter"]
        Caller["Caller<br/>(ProgramOfThought / CodeAct)"]
    end

    subgraph Subprocess["Deno Subprocess"]
        Runner["runner.js"]
        Pyodide["Pyodide Runtime<br/>(WASM Python)"]
        Sandbox["/sandbox/<br/>virtual filesystem"]
    end

    Caller -->|"execute(code, variables)"| PI
    PI -->|"JSON over stdin"| Runner
    Runner -->|"JSON over stdout"| PI
    Runner --> Pyodide
    Pyodide --> Sandbox
    PI -.->|"mount / sync files"| Sandbox
```

### Component Relationships

```mermaid
classDiagram
    class PythonInterpreter {
        +list enable_read_paths
        +list enable_write_paths
        +list enable_env_vars
        +list enable_network_access
        +bool sync_files
        +list deno_command
        +Popen deno_process
        +execute(code, variables) Any
        +shutdown() None
        +__call__(code, variables) Any
        +__enter__() PythonInterpreter
        +__exit__(...) None
        -_get_runner_path() str
        -_mount_files() None
        -_sync_files() None
        -_ensure_deno_process() None
        -_inject_variables(code, variables) str
        -_serialize_value(value) str
    }

    class InterpreterError {
        <<RuntimeError>>
    }

    PythonInterpreter ..> InterpreterError : raises
```

---

## Execution Flow

The `execute` method (also exposed via `__call__`) orchestrates the full lifecycle of a single code execution.

```mermaid
sequenceDiagram
    participant C as Caller
    participant PI as PythonInterpreter
    participant D as Deno Subprocess

    C->>PI: execute(code, variables)
    PI->>PI: _inject_variables(code, variables)
    PI->>PI: _ensure_deno_process()
    Note over PI,D: Launch Deno if not running
    PI->>PI: _mount_files()
    PI->>D: {"code": "<injected code>"}
    D-->>PI: {"output": ...} or {"error": ...}
    alt errorType == "FinalAnswer"
        PI->>PI: output = errorArgs
    else errorType == "SyntaxError"
        PI->>C: raise SyntaxError
    else other error
        PI->>C: raise InterpreterError
    end
    PI->>PI: _sync_files()
    PI-->>C: output
```

### Step-by-step

1. **Variable injection** — `_inject_variables` prepends Python assignment statements for each provided variable. Variable names must be valid identifiers, and values must be serializable (see [Value Serialization](#value-serialization)).
2. **Process management** — `_ensure_deno_process` launches the Deno subprocess if it is not already running (or has died).
3. **File mounting** — `_mount_files` registers host files/directories into the sandbox's virtual filesystem at `/sandbox/<basename>`.
4. **Code dispatch** — The injected code is sent as a JSON message over stdin.
5. **Result parsing** — A single JSON line is read from stdout and interpreted:
   - `FinalAnswer` error type → the `errorArgs` are treated as the output (the sandbox uses a `final_answer()` convention to return values).
   - `SyntaxError` → a Python `SyntaxError` is raised.
   - Any other error → an `InterpreterError` is raised.
6. **File sync** — `_sync_files` writes sandbox changes back to the host for writable paths.

---

## Sandbox Permissions

The interpreter builds the Deno command line based on the permissions requested at construction time. By default, only read access is granted.

| Constructor argument | Deno flag | Purpose |
|----------------------|-----------|---------|
| `enable_read_paths` | `--allow-read` (always on) | Files/directories readable in the sandbox. |
| `enable_write_paths` | `--allow-write=<paths>` | Files/directories writable in the sandbox. |
| `enable_env_vars` | `--allow-env=<vars>` | Environment variables exposed to the sandbox. |
| `enable_network_access` | `--allow-net=<domains>` | Domains/IPs reachable from the sandbox. |
| `deno_command` | *(overrides all)* | Fully custom Deno launch command. |

> **Note:** A custom `deno_command` bypasses the automatic flag construction entirely, giving full control over the sandbox configuration.

---

## Value Serialization

Variables passed to `execute` are serialized into Python literals via `_serialize_value`:

| Python type | Serialization |
|-------------|---------------|
| `str` | `repr(value)` |
| `int`, `float`, `bool` | `str(value)` |
| `None` | `"None"` |
| `list`, `dict` | `json.dumps(value)` |
| anything else | raises `InterpreterError` |

This restricts the injectable value types to JSON-compatible primitives and containers, keeping the injection surface safe.

---

## File Mounting and Synchronization

```mermaid
flowchart LR
    subgraph Host
        RF["Read paths"]
        WF["Write paths"]
    end
    subgraph Sandbox["/sandbox/"]
        VF["Virtual files"]
    end
    RF -->|mount_file| VF
    WF -->|mount_file| VF
    VF -->|sync_file| WF
```

- **Mounting** (`_mount_files`): Runs once per interpreter instance. Each path is mapped to `/sandbox/<basename>`. Non-existent write paths are created; non-existent read paths raise `FileNotFoundError`.
- **Syncing** (`_sync_files`): Runs after each successful execution when `sync_files=True` and write paths are configured. Changes made inside the sandbox are written back to the host files.

---

## Lifecycle Management

`PythonInterpreter` supports the context manager protocol:

```python
with PythonInterpreter() as interp:
    output = interp("print('Hello'); 1 + 2")
```

- `__enter__` returns the interpreter itself.
- `__exit__` calls `shutdown()`, which sends a `{"shutdown": true}` message, closes stdin, and waits for the subprocess to terminate.

The interpreter can also be used directly via `__call__` / `execute`, but callers are then responsible for invoking `shutdown()`.

---

## Error Handling

```mermaid
flowchart TD
    A["execute()"] --> B{"Deno installed?"}
    B -->|No| C["InterpreterError<br/>(install instructions)"]
    B -->|Yes| D{"Valid output?"}
    D -->|No| E["InterpreterError<br/>(no output / stderr)"]
    D -->|Yes| F{"errorType?"}
    F -->|FinalAnswer| G["Return errorArgs"]
    F -->|SyntaxError| H["raise SyntaxError"]
    F -->|Other| I["raise InterpreterError"]
    F -->|None| J["Return output"]
```

| Condition | Exception |
|-----------|-----------|
| Deno executable not found | `InterpreterError` with installation instructions |
| Invalid variable name | `InterpreterError` |
| Unsupported value type | `InterpreterError` |
| Non-existent read path during mount | `FileNotFoundError` |
| No output from subprocess | `InterpreterError` |
| Sandbox `SyntaxError` | `SyntaxError` |
| Other sandbox errors | `InterpreterError` |

---

## Usage Examples

### Basic execution

```python
from dspy.primitives.python_interpreter import PythonInterpreter

code_string = "print('Hello'); 1 + 2"
with PythonInterpreter() as interp:
    output = interp(code_string)
```

### With variable injection

```python
with PythonInterpreter() as interp:
    result = interp("x + y", variables={"x": 3, "y": 4})
    # result == 7
```

### With file and network permissions

```python
with PythonInterpreter(
    enable_read_paths=["/data/input.csv"],
    enable_write_paths=["/data/output.csv"],
    enable_env_vars=["API_KEY"],
    enable_network_access=["api.example.com"],
) as interp:
    interp("import os; print(os.environ['API_KEY'])")
```

---

## Integration with DSPy Modules

The interpreter is consumed by higher-level DSPy modules that generate and run code:

```mermaid
graph LR
    PoT["ProgramOfThought<br/>(predict_reasoning.md)"] --> PI["PythonInterpreter"]
    CA["CodeAct<br/>(predict_agents.md)"] --> PI
    PI --> Deno["Deno + Pyodide Sandbox"]
```

- **[`ProgramOfThought`](predict_reasoning.md)** — Generates Python code to compute answers, executes it via the interpreter, and retries on errors up to `max_iters`. It calls `interpreter.shutdown()` when finished.
- **[`CodeAct`](predict_agents.md)** — An agentic module that iteratively generates code, executes it, and uses tool functions defined inside the sandbox. It injects tool source code into the interpreter before each run.

Both modules accept an optional `interpreter` argument, allowing a shared `PythonInterpreter` instance to be reused across calls.

---

## Prerequisites

- **Deno** must be installed. Installation instructions:
  - Linux/macOS: `curl -fsSL https://deno.land/install.sh | sh`
  - macOS (Homebrew): `brew install deno`
  - See the [Deno installation guide](https://docs.deno.com/runtime/getting_started/installation/).

The interpreter relies on a bundled `runner.js` file located alongside `python_interpreter.py`, which bootstraps Pyodide inside the Deno runtime.

---

## Related Modules

- [predict_reasoning.md](predict_reasoning.md) — `ProgramOfThought` and other reasoning modules.
- [predict_agents.md](predict_agents.md) — `CodeAct` and `ReAct` agentic modules.
- [primitives_module_system.md](primitives_module_system.md) — The `Module` base class used by code-generating modules.
- [primitives_data_containers.md](primitives_data_containers.md) — `Prediction` and `Example` containers used to return results.
