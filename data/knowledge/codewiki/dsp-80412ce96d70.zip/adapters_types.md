# Adapters Types Module

## Introduction

The `adapters_types` module defines the **custom type system** used by DSPy adapters to represent rich, non-primitive data within signatures. While standard Python types (`str`, `int`, `list`, etc.) cover most cases, real-world LLM applications frequently need to pass and receive structured media and control-flow data such as images, audio, code blocks, conversation history, and tool calls.

This module provides:

- A common base class (`Type`) that all custom types inherit from.
- Concrete custom types: `Image`, `Audio`, `Code`, `History`, `Tool`, and `ToolCalls`.
- A serialization/deserialization protocol that lets adapters embed custom types into LM messages and recover them from LM responses.

The types defined here are consumed by the [adapters_core](adapters_core.md) module (e.g., `ChatAdapter`, `JSONAdapter`) during message formatting and parsing. For the broader adapter architecture, see [adapters_core.md](adapters_core.md).

---

## Module Architecture

The module is organized around a single base class with several concrete subclasses, plus a set of helper functions for encoding media and splitting message content.

```mermaid
graph TD
    Type["Type (base_type.py)<br/>pydantic.BaseModel"]
    Image["Image (image.py)"]
    Audio["Audio (audio.py)"]
    Code["Code (code.py)"]
    Tool["Tool (tool.py)"]
    ToolCalls["ToolCalls (tool.py)"]
    History["History (history.py)<br/>pydantic.BaseModel"]

    Type --> Image
    Type --> Audio
    Type --> Code
    Type --> Tool
    Type --> ToolCalls

    subgraph "Helper functions"
        Split["split_message_content_for_custom_types"]
        EncodeImg["encode_image / is_image"]
        EncodeAudio["encode_audio"]
        FilterCode["_filter_code"]
        ResolveSchema["_resolve_json_schema_reference"]
        ConvertSchema["convert_input_schema_to_tool_args"]
    end

    Type -.uses.-> Split
    Image -.uses.-> EncodeImg
    Audio -.uses.-> EncodeAudio
    Code -.uses.-> FilterCode
    Tool -.uses.-> ResolveSchema
    Tool -.uses.-> ConvertSchema
```

> **Note:** `History` is a standalone `pydantic.BaseModel` rather than a subclass of `Type`, because it is handled specially by the adapter's conversation-history formatting logic (see [adapters_core.md](adapters_core.md)).

---

## The `Type` Base Class

**File:** `dspy/adapters/types/base_type.py`

`Type` is the parent class of all DSPy custom types. It extends `pydantic.BaseModel` and defines the contract that subclasses must fulfill.

### Key responsibilities

| Member | Purpose |
| --- | --- |
| `format()` | Returns a list of content-part dictionaries (OpenAI-style) or a string. Subclasses **must** implement this. |
| `description()` | Class method returning a human-readable description used in prompts. Defaults to `""`. |
| `extract_custom_type_from_annotation(annotation)` | Recursively scans a (possibly nested) type annotation to find all custom `Type` subclasses. |
| `serialize_model()` | Pydantic model serializer that wraps list-formatted output in reserved sentinel identifiers. |

### Serialization protocol

When a custom type is serialized, its `format()` output is wrapped between two reserved sentinel strings:

```
<<CUSTOM-TYPE-START-IDENTIFIER>> ... <<CUSTOM-TYPE-END-IDENTIFIER>>
```

These sentinels allow the adapter to later locate and split the custom-type content out of a plain string message. The `split_message_content_for_custom_types` helper performs this reverse operation.

```mermaid
sequenceDiagram
    participant Sig as Signature field
    participant Type as Type.serialize_model()
    participant Adapter as Adapter.format()
    participant Split as split_message_content_for_custom_types()
    participant LM as LM messages

    Sig->>Type: value with custom type
    Type->>Type: format() -> list[dict]
    Type->>Adapter: "<<START>>[...]<<END>>"
    Adapter->>Split: raw string content
    Split->>Split: regex find sentinels
    Split->>LM: list of content blocks
```

### `split_message_content_for_custom_types`

This function iterates over user messages, finds the sentinel-delimited blocks, parses the embedded JSON (using `json_repair` for robustness), and replaces the string content with a list of content blocks. For example, a message containing an image becomes:

```python
[
    {"type": "text", "text": "{text_before_image}"},
    {"type": "image_url", "image_url": {"url": "{image_url}"}},
    {"type": "text", "text": "{text_after_image}"},
]
```

---

## Concrete Custom Types

### `Image`

**File:** `dspy/adapters/types/image.py`

Represents an image, stored as a `url` field. The URL may be a remote URL, a local file path, a data URI, or a base64-encoded string.

- **`format()`** → `[{"type": "image_url", "image_url": {"url": ...}}]`
- **Constructors:** `from_url(url, download=False)`, `from_file(file_path)`, `from_PIL(pil_image)`
- **Validation:** accepts either a plain string URL or a `{"url": ...}` dict.
- **Helpers:** `encode_image(...)` normalizes many input forms (PIL image, bytes, file path, URL, data URI) into a data URI or URL; `is_image(obj)` and `is_url(string)` provide type checks.

Optional dependency: **Pillow** (`PIL`) is required for PIL-image and raw-bytes handling.

### `Audio`

**File:** `dspy/adapters/types/audio.py`

Represents audio data with two fields: `data` (base64-encoded) and `audio_format` (e.g., `"wav"`).

- **`format()`** → `[{"type": "input_audio", "input_audio": {"data": ..., "format": ...}}]`
- **Constructors:** `from_url(url)`, `from_file(file_path)`, `from_array(array, sampling_rate, format="wav")`
- **Helper:** `encode_audio(...)` accepts file paths, URLs, data URIs, dicts, `Audio` instances, numpy-like arrays, and raw bytes.

Optional dependency: **soundfile** (`sf`) is required for `from_array` and array-based encoding.

### `Code`

**File:** `dspy/adapters/types/code.py`

Represents a code snippet with a `code` string field and a class-level `language` attribute (default `"python"`).

- **`format()`** → returns the raw code string.
- **`serialize_model()`** is overridden to **bypass** the sentinel wrapping, so code is emitted verbatim.
- **`description()`** instructs the LM to use markdown code-block formatting.
- **`validate_input()`** extracts code from markdown fences via `_filter_code`.
- **Generic syntax:** `dspy.Code["java"]` is supported via a patched `__class_getitem__` that dynamically creates a subclass with the given `language`.

### `History`

**File:** `dspy/adapters/types/history.py`

Represents conversation history as a list of message dictionaries (`messages: list[dict[str, Any]]`). Each message should contain keys matching the associated signature's fields.

- It is a plain `pydantic.BaseModel` (not a `Type` subclass).
- The adapter detects a `History`-typed input field and expands it into multi-turn user/assistant messages (see `Adapter.format_conversation_history` in [adapters_core.md](adapters_core.md)).

### `Tool`

**File:** `dspy/adapters/types/tool.py`

Wraps a Python callable so it can be exposed to LLMs for function/tool calling.

- **Fields:** `func`, `name`, `desc`, `args` (JSON schema per arg), `arg_types`, `arg_desc`, `has_kwargs`.
- **`_parse_function()`** introspects the function signature and type hints to auto-infer name, description, and JSON-schema args (resolving `$ref` via `_resolve_json_schema_reference`).
- **`format_as_litellm_function_call()`** produces the LiteLLM/OpenAI function-calling schema.
- **`__call__` / `acall`** validate and coerce arguments (via `_validate_and_parse_args`) before invoking the function. Async tools are supported; sync invocation of async tools requires `settings.allow_tool_async_sync_conversion`.
- **`from_mcp_tool()`** and **`from_langchain()`** convert external tool definitions into DSPy tools.
- Decorated with `with_callbacks` (see [utils.md](utils.md)) so tool invocations emit callback events.

### `ToolCalls`

**File:** `dspy/adapters/types/tool.py`

Represents the tool calls returned by an LM.

- **Nested `ToolCall`** model: `name: str`, `args: dict[str, Any]`.
- **`from_dict_list()`** builds a `ToolCalls` from a list of `{"name": ..., "args": ...}` dicts.
- **`format()`** emits an OpenAI-compatible `tool_calls` content block.

---

## Component Interaction

The following diagram shows how the custom types flow through an adapter call. The adapter formats inputs (embedding custom types), calls the LM, then parses outputs back into custom types.

```mermaid
flowchart LR
    subgraph Inputs
        Img[Image]
        Aud[Audio]
        CodeIn[Code]
        Hist[History]
        Tools[Tool / list of Tool]
    end

    subgraph Adapter["Adapter (adapters_core)"]
        Format["format()"]
        Split["split_message_content_for_custom_types()"]
        Parse["parse()"]
    end

    LM["LM (clients)"]

    subgraph Outputs
        CodeOut[Code]
        ToolCallsOut[ToolCalls]
    end

    Img --> Format
    Aud --> Format
    CodeIn --> Format
    Hist --> Format
    Tools --> Format
    Format --> Split
    Split --> LM
    LM --> Parse
    Parse --> CodeOut
    Parse --> ToolCallsOut
```

---

## Data Flow: Custom Type Round-Trip

```mermaid
sequenceDiagram
    participant User
    participant Predict as Predict (predict)
    participant Adapter as Adapter
    participant Type as Custom Type
    participant LM as LM

    User->>Predict: inputs (e.g., Image, History)
    Predict->>Adapter: __call__(signature, demos, inputs)
    Adapter->>Type: serialize_model() / format()
    Type-->>Adapter: sentinel-wrapped content
    Adapter->>Adapter: split_message_content_for_custom_types()
    Adapter->>LM: messages (content blocks)
    LM-->>Adapter: raw completion
    Adapter->>Adapter: parse() -> output fields
    Adapter->>Type: reconstruct custom types (e.g., ToolCalls)
    Adapter-->>Predict: parsed outputs
    Predict-->>User: Prediction
```

---

## Dependencies

```mermaid
graph TD
    adapters_types["adapters_types"]

    adapters_types --> pydantic["pydantic"]
    adapters_types --> json_repair["json_repair"]
    adapters_types --> requests["requests"]
    adapters_types --> jsonschema["jsonschema"]
    adapters_types --> PIL["Pillow (optional)"]
    adapters_types --> soundfile["soundfile (optional)"]

    adapters_types -.consumed by.-> adapters_core["adapters_core"]
    adapters_types -.uses.-> settings["dsp_utils (settings)"]
    adapters_types -.uses.-> callbacks["utils (with_callbacks)"]
    adapters_types -.uses.-> mcp["utils (mcp conversion)"]
    adapters_types -.uses.-> langchain["utils (langchain conversion)"]
```

| Dependency | Role |
| --- | --- |
| `pydantic` | Base model, validators, serializers, dynamic model creation. |
| `json_repair` | Lenient JSON parsing of LM output and embedded custom-type content. |
| `requests` | Downloading images/audio from URLs. |
| `jsonschema` | Validating tool arguments against their JSON schema. |
| `Pillow` (optional) | PIL image and raw-bytes encoding. |
| `soundfile` (optional) | Encoding numpy-like audio arrays. |

---

## Relationship to Other Modules

- **[adapters_core.md](adapters_core.md)** — The `Adapter`, `ChatAdapter`, `JSONAdapter`, `XMLAdapter`, and `TwoStepAdapter` classes consume these types during `format()` and `parse()`. They detect `History`, `Tool`, and `ToolCalls` fields to drive conversation-history expansion and native function calling.
- **[signatures.md](signatures.md)** — Custom types are used as field annotations in `Signature` definitions (e.g., `image: dspy.Image`, `tools: list[dspy.Tool]`).
- **[predict.md](predict.md)** — `Predict` and related modules pass inputs/outputs containing custom types through adapters.
- **[clients.md](clients.md)** — The `LM` receives the formatted messages and returns completions that adapters parse back into custom types.
- **[utils.md](utils.md)** — Provides `with_callbacks` (used by `Tool`) and MCP/LangChain conversion helpers.

---

## Summary

The `adapters_types` module is the extensibility layer for DSPy's data model. By subclassing `Type` and implementing `format()`, developers can introduce new media or structured types that adapters automatically serialize into LM messages and recover from responses. The built-in types (`Image`, `Audio`, `Code`, `History`, `Tool`, `ToolCalls`) cover the most common multimodal and tool-calling use cases, while the sentinel-based serialization protocol and `split_message_content_for_custom_types` helper ensure custom content is preserved through the string-based message pipeline.
