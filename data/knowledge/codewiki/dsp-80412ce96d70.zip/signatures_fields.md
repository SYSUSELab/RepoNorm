# Signatures Fields

## Introduction

The `signatures_fields` module (`dspy/signatures/field.py`) provides the field-definition primitives used to declare the **inputs** and **outputs** of a DSPy `Signature`. It bridges DSPy's declarative field semantics (prefixes, descriptions, formats, parsers) with Pydantic's field system, which DSPy uses as its underlying data-modeling engine.

The module exposes two layers of API:

1. **Modern Pydantic-based fields** — `InputField(...)` and `OutputField(...)`, which wrap `pydantic.Field` and stash DSPy-specific metadata inside `json_schema_extra`.
2. **Legacy field classes** — `OldField`, `OldInputField`, and `OldOutputField`, a more ergonomic datatype that infers `prefix` and `desc` when omitted, plus a conversion helper `new_to_old_field`.

Together with the [`signatures_signature`](signatures_signature.md) module (which consumes these fields via `SignatureMeta`), this module forms the foundation of DSPy's declarative programming interface.

---

## Architecture Overview

The module sits at the bottom of the signature subsystem. Fields are declared by users, validated and normalized by `SignatureMeta`, and finally consumed by adapters and predictors.

```mermaid
graph TD
    User["User Code<br/>class MySig(Signature):<br/>  q = InputField()<br/>  a = OutputField()"]
    Field["signatures_fields<br/>InputField / OutputField<br/>OldField / OldInputField / OldOutputField"]
    Sig["signatures_signature<br/>Signature / SignatureMeta"]
    Pydantic["pydantic.Field / FieldInfo"]
    Adapters["adapters<br/>ChatAdapter / JSONAdapter / XMLAdapter"]
    Predict["predict<br/>Predict / ChainOfThought"]

    User --> Field
    Field --> Pydantic
    Field --> Sig
    Sig --> Adapters
    Sig --> Predict
    Adapters --> Predict
```

### Key Responsibilities

| Responsibility | Component |
| --- | --- |
| Declare input/output fields with DSPy metadata | `InputField`, `OutputField` |
| Translate Pydantic constraints into human-readable text | `_translate_pydantic_field_constraints` |
| Route DSPy-specific kwargs into `json_schema_extra` | `move_kwargs` |
| Provide ergonomic legacy field objects | `OldField`, `OldInputField`, `OldOutputField` |
| Convert modern fields back to legacy objects | `new_to_old_field` |

---

## Component Reference

### Constants

#### `DSPY_FIELD_ARG_NAMES`

```python
DSPY_FIELD_ARG_NAMES = ["desc", "prefix", "format", "parser", "__dspy_field_type"]
```

The set of argument names that are DSPy-specific (rather than Pydantic-native). Any kwarg matching one of these names is moved into `json_schema_extra` instead of being passed directly to `pydantic.Field`. This avoids name clashes with Pydantic's own field arguments.

#### `PYDANTIC_CONSTRAINT_MAP`

```python
PYDANTIC_CONSTRAINT_MAP = {
    "gt": "greater than: ",
    "ge": "greater than or equal to: ",
    "lt": "less than: ",
    "le": "less than or equal to: ",
    "min_length": "minimum length: ",
    "max_length": "maximum length: ",
    "multiple_of": "a multiple of the given number: ",
    "allow_inf_nan": "allow 'inf', '-inf', 'nan' values: ",
}
```

Maps Pydantic constraint keywords to human-readable phrases. These phrases are embedded into the field's `json_schema_extra["constraints"]` so that language models can be informed of the constraints in natural language.

---

### Functions

#### `move_kwargs(**kwargs)`

Splits a mixed set of keyword arguments into Pydantic-native kwargs and DSPy-specific `json_schema_extra` entries.

**Behavior:**
- Iterates over `kwargs`; keys in `DSPY_FIELD_ARG_NAMES` go to `json_schema_extra`, everything else goes to `pydantic_kwargs`.
- If a Pydantic `description` is provided but no DSPy `desc`, the description is copied into `json_schema_extra["desc"]`.
- Calls `_translate_pydantic_field_constraints` and, if any constraints are found, stores them under `json_schema_extra["constraints"]`.
- Attaches the assembled `json_schema_extra` dict to `pydantic_kwargs`.

**Returns:** a dict suitable for `pydantic.Field(**...)`.

```mermaid
flowchart LR
    A["kwargs"] --> B{"key in<br/>DSPY_FIELD_ARG_NAMES?"}
    B -- yes --> C["json_schema_extra[key]"]
    B -- no --> D["pydantic_kwargs[key]"]
    C --> E["copy description -> desc"]
    D --> E
    E --> F["translate constraints"]
    F --> G["pydantic_kwargs['json_schema_extra']"]
```

#### `_translate_pydantic_field_constraints(**kwargs)`

Extracts Pydantic constraints (keys present in `PYDANTIC_CONSTRAINT_MAP`) and joins their human-readable translations with `", "`.

**Returns:** a comma-separated string of constraint descriptions (empty string if none).

#### `InputField(**kwargs)`

```python
def InputField(**kwargs):
    return pydantic.Field(**move_kwargs(**kwargs, __dspy_field_type="input"))
```

Creates a Pydantic field tagged as a DSPy **input**. The `__dspy_field_type="input"` marker is what `SignatureMeta` later uses to classify the field.

#### `OutputField(**kwargs)`

```python
def OutputField(**kwargs):
    return pydantic.Field(**move_kwargs(**kwargs, __dspy_field_type="output"))
```

Creates a Pydantic field tagged as a DSPy **output**.

#### `new_to_old_field(field)`

Converts a modern Pydantic `FieldInfo` (produced by `InputField`/`OutputField`) into the corresponding legacy field object (`OldInputField` or `OldOutputField`), copying `prefix`, `desc`, and `format` from `json_schema_extra`.

---

### Classes

#### `OldField`

> A more ergonomic datatype that infers prefix and desc if omitted.

**Constructor:**

```python
def __init__(self, *, prefix=None, desc=None, input, format=None)
```

| Parameter | Type | Description |
| --- | --- | --- |
| `prefix` | `str \| None` | Field prefix. May be `None` initially and set later via `finalize`. |
| `desc` | `str \| None` | Field description. |
| `input` | `bool` | Whether the field is an input (used by subclasses). |
| `format` | `str \| None` | Optional format hint. |

**Methods:**

- `finalize(key, inferred_prefix)` — Sets `prefix` to `inferred_prefix + ":"` if not provided, and sets `desc` to `f"${{{key}}}"` if not provided.
- `__repr__` — Returns `OldField(prefix=..., desc=...)`.
- `__eq__` — Compares `__dict__` equality with another object.

#### `OldInputField(OldField)`

Subclass of `OldField` that fixes `input=True`. Constructor signature: `(prefix=None, desc=None, format=None)`.

#### `OldOutputField(OldField)`

Subclass of `OldField` that fixes `input=False`. Constructor signature: `(prefix=None, desc=None, format=None)`.

```mermaid
classDiagram
    class OldField {
        +prefix
        +desc
        +format
        +finalize(key, inferred_prefix)
        +__repr__()
        +__eq__(other)
    }
    class OldInputField {
        +input = True
    }
    class OldOutputField {
        +input = False
    }
    OldField <|-- OldInputField
    OldField <|-- OldOutputField
```

---

## Data Flow

The following sequence shows how a field declaration flows from user code through this module and into the signature machinery.

```mermaid
sequenceDiagram
    participant U as User
    participant F as signatures_fields
    participant P as pydantic.Field
    participant S as SignatureMeta

    U->>F: InputField(desc="question", prefix="Q:")
    F->>F: move_kwargs(desc, prefix, __dspy_field_type="input")
    F->>P: pydantic.Field(json_schema_extra={...})
    P-->>F: FieldInfo
    F-->>U: FieldInfo
    U->>S: class MySig(Signature): q = <FieldInfo>
    S->>S: _validate_fields() checks __dspy_field_type
    S->>S: infer prefix/desc if missing
```

---

## Relationship to Other Modules

- **[signatures_signature](signatures_signature.md)** — `SignatureMeta` consumes the `FieldInfo` objects produced here. It validates that every field carries a `__dspy_field_type` of `"input"` or `"output"`, infers missing prefixes/descriptions, and exposes `input_fields`, `output_fields`, and `fields` properties. The `Signature.insert`/`append`/`prepend` methods rely on `field.json_schema_extra["__dspy_field_type"]` to decide placement.
- **[adapters_core](adapters_core.md)** — Adapters (`ChatAdapter`, `JSONAdapter`, `XMLAdapter`) read `prefix`, `desc`, `format`, and `constraints` from `json_schema_extra` to render prompts and parse model outputs.
- **[predict_core](predict_core.md)** — `Predict` and related predictors instantiate signatures and use their field metadata to build LM calls.

---

## Usage Examples

### Modern API

```python
from dspy import Signature, InputField, OutputField

class QA(Signature):
    """Answer the question."""

    question = InputField(desc="The question to answer")
    context = InputField(desc="Supporting context")
    answer = OutputField(desc="The final answer", min_length=1)
```

Here `min_length=1` is a Pydantic constraint that `_translate_pydantic_field_constraints` renders as `"minimum length: 1"` inside `json_schema_extra["constraints"]`.

### Legacy API

```python
from dspy.signatures.field import OldInputField, OldOutputField

q = OldInputField(desc="The question")
a = OldOutputField()  # prefix and desc inferred later via finalize()
```

---

## Summary

The `signatures_fields` module is a thin but essential translation layer:

- It lets users declare signature fields with DSPy semantics (`desc`, `prefix`, `format`, `parser`) while remaining fully compatible with Pydantic.
- It converts Pydantic constraints into natural-language hints for language models.
- It provides a legacy, ergonomic field API for backward compatibility.

All higher-level signature behavior — validation, ordering, and prompt rendering — is implemented in [`signatures_signature`](signatures_signature.md) and the adapter modules, which build directly on the field objects defined here.
