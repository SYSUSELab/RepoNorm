# Clients Cache

## Introduction

The `clients_cache` module provides DSPy's caching infrastructure for language model (LM) and embedding calls. It implements a **two-tier caching system** that dramatically reduces latency and cost by reusing previously computed responses for identical requests.

The module is centered around the `Cache` class and the `request_cache` decorator, which together intercept function calls (such as LM completions and embedding computations), compute deterministic cache keys from request parameters, and store/retrieve results from both in-memory and on-disk caches.

**Key capabilities:**

- **Two-level caching**: A fast in-memory LRU cache backed by a persistent on-disk cache.
- **Deterministic cache keys**: Request dictionaries are normalized and hashed (SHA-256) to produce stable keys, with special handling for Pydantic models, callables, and JSON-incompatible types.
- **Transparent integration**: The `request_cache` decorator wraps completion/embedding functions so caching is applied automatically without changing call sites.
- **Configurable behavior**: Caching can be toggled per-call, per-instance, or globally, and specific arguments (e.g., API keys) can be excluded from cache keys.
- **Persistence**: The in-memory cache can be serialized to and restored from disk via `cloudpickle`.

## Architecture

The cache module sits between DSPy's high-level clients (`LM`, `Embedder`) and the underlying provider calls (LiteLLM). It intercepts requests before they reach the network and short-circuits them when a cached response exists.

```mermaid
graph TD
    subgraph "DSPy Clients"
        LM["LM / BaseLM<br/>(dspy/clients/lm.py)"]
        Embedder["Embedder<br/>(dspy/clients/embedding.py)"]
    end

    subgraph "clients_cache module"
        RC["request_cache<br/>(decorator)"]
        Cache["Cache<br/>(dspy/clients/cache.py)"]
        MemCache["LRUCache<br/>(in-memory)"]
        DiskCache["FanoutCache<br/>(on-disk)"]
    end

    subgraph "External"
        LiteLLM["LiteLLM<br/>completion / embedding"]
    end

    LM -->|"wraps completion_fn"| RC
    Embedder -->|"wraps compute_embeddings"| RC
    RC -->|"get / put"| Cache
    Cache --> MemCache
    Cache --> DiskCache
    RC -->|"cache miss"| LiteLLM
    LiteLLM -->|"response"| RC
```

## Core Components

### `Cache`

The `Cache` class is the central storage abstraction. It manages two independent cache layers and exposes a simple `get`/`put` interface keyed by hashed request dictionaries.

| Attribute | Description |
|-----------|-------------|
| `enable_disk_cache` | Whether the on-disk (`FanoutCache`) layer is active. |
| `enable_memory_cache` | Whether the in-memory (`LRUCache`) layer is active. |
| `memory_cache` | An `LRUCache` (or plain `dict` if disabled) holding recent responses. |
| `disk_cache` | A `FanoutCache` (or plain `dict` if disabled) persisting responses to disk. |
| `_lock` | A reentrant lock (`threading.RLock`) guarding memory cache mutations. |

**Constructor parameters:**

- `enable_disk_cache` — Toggle the persistent disk layer.
- `enable_memory_cache` — Toggle the fast in-memory layer.
- `disk_cache_dir` — Directory used by `FanoutCache` for persistence.
- `disk_size_limit_bytes` — Maximum disk cache size (default 10 MB).
- `memory_max_entries` — Maximum number of in-memory entries (default 1,000,000).

**Key methods:**

- `cache_key(request, ignored_args_for_cache_key)` — Produces a SHA-256 hex digest of the normalized, sorted JSON representation of the request. Values are transformed before hashing:
  - Pydantic **classes** → `model_json_schema()`
  - Pydantic **instances** → `model_dump()`
  - **Callables** → source code (or a name-based fallback for lambdas)
  - **Dicts** → recursively transformed
- `get(request, ignored_args_for_cache_key)` — Looks up a response. Checks memory first, then disk (promoting disk hits into memory). Returns a **deep copy** so callers cannot mutate the cached object. Clears `usage` on cache hits since no LM call was made.
- `put(request, value, ignored_args_for_cache_key, enable_memory_cache)` — Stores a value in memory and/or disk. Disk write failures (e.g., unpicklable values, full disk) are logged and swallowed.
- `reset_memory_cache()` — Clears the in-memory layer.
- `save_memory_cache(filepath)` / `load_memory_cache(filepath)` — Serialize/restore the memory cache using `cloudpickle`.
- `__contains__(key)` — Membership test across both layers.

### `request_cache` (decorator)

The `request_cache` decorator is the integration point used by clients. It wraps a function and applies caching based on a designated request argument.

```mermaid
sequenceDiagram
    participant Caller as LM / Embedder
    participant Wrapper as request_cache wrapper
    participant Cache as Cache
    participant Fn as Underlying function (LiteLLM)

    Caller->>Wrapper: call(*args, **kwargs)
    Wrapper->>Wrapper: process_request() → modified_request
    Wrapper->>Cache: get(modified_request, ignored_args)
    alt Cache hit
        Cache-->>Wrapper: cached response (deep copy)
        Wrapper-->>Caller: return cached response
    else Cache miss
        Wrapper->>Fn: fn(*args, **kwargs)
        Fn-->>Wrapper: result
        Wrapper->>Cache: put(original_request, result, ...)
        Wrapper-->>Caller: return result
    end
```

**Parameters:**

- `cache_arg_name` — Name of the argument containing the request dict. If omitted, the entire `kwargs` (plus positional args) forms the request.
- `ignored_args_for_cache_key` — Arguments excluded from the cache key. Defaults to `["api_key", "api_base", "base_url"]` so credentials never affect cache identity.
- `enable_memory_cache` — Whether new results are written to the memory layer at call time (useful to prevent unbounded growth).
- `maxsize` — **Deprecated / no-op**; retained for backward compatibility and emits a warning.

**Behavioral details:**

- The fully qualified function name (`fn.__module__.__qualname__`) is injected into the request as `_fn_identifier`, ensuring different functions never collide in the cache.
- The request is **deep-copied** before use because LiteLLM may mutate kwargs in place.
- Both **sync** and **async** functions are supported; the decorator detects coroutine functions via `inspect.iscoroutinefunction` and returns the appropriate wrapper.

## Data Flow

The following diagram illustrates how a request flows through the caching layers, including the promotion of disk hits into memory and the handling of cache misses.

```mermaid
flowchart TD
    Start([Request received]) --> KeyGen["cache_key(request)<br/>normalize + SHA-256"]
    KeyGen --> KeyOK{Key generated?}
    KeyOK -->|No| Miss[Return None / compute]
    KeyOK -->|Yes| MemCheck{"In memory cache?"}
    MemCheck -->|Yes| MemHit["Deep copy response<br/>clear usage"]
    MemCheck -->|No| DiskCheck{"In disk cache?"}
    DiskCheck -->|Yes| Promote["Read from disk<br/>promote to memory"]
    Promote --> MemHit
    DiskCheck -->|No| Miss
    MemHit --> Return([Return cached response])
    Miss --> Compute["Call underlying function"]
    Compute --> Store["put() into memory + disk"]
    Store --> Return2([Return fresh response])
```

## Integration with Clients

### `LM` (Language Model)

The `LM` class (see [clients_lm.md](clients_lm.md)) uses `request_cache` inside `_get_cached_completion_fn` to wrap LiteLLM's completion functions:

- When `cache=True` and `cache_in_memory=True`, the completion function is wrapped with memory caching enabled.
- When `cache=True` but `cache_in_memory=False`, the wrapper disables memory writes (disk-only).
- When `cache=False`, no wrapping occurs and LiteLLM's own cache is bypassed via `{"no-cache": True, "no-store": True}`.

The `cache` and `cache_in_memory` flags can be overridden per-call via `forward(..., cache=..., cache_in_memory=...)`.

### `Embedder` (Embeddings)

The `Embedder` class (see [clients_embedding.md](clients_embedding.md)) selects between cached and uncached embedding functions based on its `caching` flag:

- `_cached_compute_embeddings` / `_cached_acompute_embeddings` — used when caching is enabled.
- `_compute_embeddings` / `_acompute_embeddings` — used when caching is disabled.

## Component Relationships

```mermaid
classDiagram
    class Cache {
        +bool enable_disk_cache
        +bool enable_memory_cache
        +LRUCache memory_cache
        +FanoutCache disk_cache
        +RLock _lock
        +cache_key(request, ignored) str
        +get(request, ignored) Any
        +put(request, value, ignored, enable_memory_cache)
        +reset_memory_cache()
        +save_memory_cache(filepath)
        +load_memory_cache(filepath)
        +__contains__(key) bool
    }

    class request_cache {
        <<decorator>>
        +cache_arg_name
        +ignored_args_for_cache_key
        +enable_memory_cache
        +maxsize (deprecated)
    }

    request_cache --> Cache : uses dspy.cache
    Cache --> LRUCache : memory layer
    Cache --> FanoutCache : disk layer
```

## Dependencies

| Dependency | Purpose |
|------------|---------|
| `cachetools.LRUCache` | In-memory LRU eviction policy. |
| `diskcache.FanoutCache` | Sharded, persistent on-disk cache. |
| `cloudpickle` | Serialization of the memory cache (supports lambdas/closures). |
| `pydantic` | Detecting and serializing Pydantic models for cache keys. |
| `ujson` | Fast, deterministic JSON serialization for hashing. |
| `hashlib.sha256` | Producing stable cache keys. |
| `threading.RLock` | Thread-safe access to the memory cache. |

## Design Considerations

- **Determinism**: Cache keys rely on sorted JSON serialization (`sort_keys=True`) so that logically identical requests with different key ordering map to the same key.
- **Credential safety**: API keys and base URLs are excluded from cache keys by default, preventing cache fragmentation and accidental credential leakage into keys.
- **Mutation safety**: Responses are deep-copied on retrieval, and requests are deep-copied before hashing/storing, protecting the cache from in-place mutations by callers or LiteLLM.
- **Graceful degradation**: Failures in key generation or disk writes are logged at debug level and never raise, ensuring caching is best-effort and never breaks the primary call path.
- **Usage tracking correctness**: On a cache hit, the `usage` field is cleared so that token accounting reflects only actual LM calls.

## Related Modules

- [clients_lm.md](clients_lm.md) — The `LM` and `BaseLM` classes that consume the cache for completions.
- [clients_embedding.md](clients_embedding.md) — The `Embedder` class that consumes the cache for embeddings.
- [clients_clients_providers.md](clients_clients_providers.md) — Provider implementations that ultimately perform the network calls being cached.
