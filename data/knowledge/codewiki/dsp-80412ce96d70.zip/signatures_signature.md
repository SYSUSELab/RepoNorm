# Signatures Signature Module

## Introduction

The `signatures_signature` module is the heart of DSPy's declarative programming model. It defines the `Signature` class and its metaclass `SignatureMeta`, which together allow developers to specify the **input/output contract** of a language model task in a clean, type-annotated, Pythonic way. A `Signature` describes *what* a module should do (its fields and instructions) without specifying *how* it is executed — the actual execution is handled by modules such as [`Predict`](predict_core.md) and adapters such as [`ChatAdapter`](adapters_core.md).

This module is responsible for:

- Defining the `Signature` base class (a Pydantic `BaseModel` subclass).
- Providing the `SignatureMeta` metaclass that validates fields, infers prefixes/descriptions, and enables dynamic signature creation.
- Offering factory helpers (`make_signature`, `ensure_signature`) and string-based signature parsing.
- Supporting runtime manipulation of signatures (adding/removing/updating fields, instructions, and state serialization).

> **Related modules:** Field definitions live in [`signatures_fields`](signatures_fields.md). Signatures are consumed by [`predict_core`](predict_core.md), [`adapters_core`](adapters_core.md), and optimized by [`teleprompt`](teleprompt.md) modules.

---

## Architecture Overview

The module is built around a metaclass-driven design. `SignatureMeta` intercepts class creation and class instantiation, while `Signature` provides the runtime API for field manipulation and serialization.

```mermaid
graph TD
    subgraph "signatures_signature module"
        SM[SignatureMeta<br/>metaclass]
        S[Signature<br/>BaseModel subclass]
        MS[make_signature<br/>factory]
        ES[ensure_signature<br/>normalizer]
        PS[_parse_signature<br/>_parse_field_string<br/>_parse_type_node]
        IP[infer_prefix]
        DI[_default_instructions]
    end

    subgraph "signatures_fields module"
        IF[InputField]
        OF[OutputField]
        FI[FieldInfo / pydantic.Field]
    end

    subgraph "External"
        BM[Pydantic BaseModel]
        TYP[typing module]
        AST[ast module]
    end

    SM -->|metaclass of| S
    S -->|inherits| BM
    SM -->|__call__ delegates to| MS
    MS -->|uses| PS
    MS -->|creates via create_model| S
    PS -->|uses| AST
    PS -->|resolves types via| TYP
    ES -->|delegates to| S
    S -->|uses| IF
    S -->|uses| OF
    IF -->|returns| FI
    OF -->|returns| FI
    SM -->|infers prefixes via| IP
    SM -->|defaults instructions via| DI
```

### Key Design Decisions

| Aspect | Mechanism |
|--------|-----------|
| **Declarative fields** | Fields are declared as class attributes using `InputField()` / `OutputField()`, which are Pydantic `FieldInfo` objects tagged with `__dspy_field_type`. |
| **Metaclass interception** | `SignatureMeta.__call__` intercepts `Signature(...)` calls to dynamically build new signature *classes* rather than instances. |
| **Pydantic integration** | `Signature` subclasses `pydantic.BaseModel`, so field validation, JSON schema generation, and type coercion come for free. |
| **String signatures** | `"input1, input2 -> output1, output2"` strings are parsed via Python's `ast` module into typed fields. |
| **Custom type resolution** | Custom types can be resolved from the caller's frame (best-effort) or passed explicitly via `custom_types`. |

---

## Core Components

### `SignatureMeta`

`SignatureMeta` is the metaclass (derived from `type(BaseModel)`) that governs the lifecycle of every `Signature` class.

```mermaid
flowchart TD
    A[Signature call or class definition] --> B{cls is Signature?}
    B -->|Yes, called as Signature args| C[make_signature]
    B -->|No| D[super().__call__]
    A --> E[__new__ invoked on class creation]
    E --> F[Collect FieldInfo attributes in order]
    F --> G[Default missing annotations to str]
    G --> H[Build ordered __annotations__]
    H --> I[super().__new__ via Pydantic]
    I --> J{__doc__ is None?}
    J -->|Yes| K[Inherit doc from base or use _default_instructions]
    J -->|No| L[Keep doc]
    K --> M[_validate_fields]
    L --> M
    M --> N[Infer prefix and desc for each field]
    N --> O[Return class]
```

#### Responsibilities

1. **`__call__`** — When `Signature` itself is called (e.g., `Signature("a -> b")`), it does **not** create an instance. Instead it delegates to `make_signature`, producing a new `Signature` subclass. It also attempts to auto-detect custom types from the caller's frame via `_detect_custom_types_from_caller`.

2. **`_detect_custom_types_from_caller`** — Uses `sys._getframe` to walk up to 100 stack frames, extracting type names referenced in the signature string (including dotted names like `Module.Type`) and resolving them from local/global namespaces. This is a best-effort convenience; explicit `custom_types` is recommended for reliability.

3. **`__new__`** — Runs during class creation. It:
   - Preserves field declaration order.
   - Defaults unannotated fields to `str`.
   - Lets Pydantic construct the class.
   - Inherits `__doc__` (instructions) from base classes if absent, otherwise falls back to `_default_instructions`.
   - Calls `_validate_fields` to ensure every field is an `InputField` or `OutputField`.
   - Ensures every field has a `prefix` (via `infer_prefix`) and a `desc`.

4. **Properties** — `instructions`, `input_fields`, `output_fields`, `fields`, and `signature` provide read access to the class metadata. `instructions` is also settable.

5. **`_validate_fields`** — Raises `TypeError` if any field lacks a valid `__dspy_field_type` of `"input"` or `"output"`.

6. **`__repr__`** — Produces a human-readable representation of the signature, its instructions, and its fields.

---

### `Signature`

`Signature` is the base class that users subclass to declare tasks. It is a Pydantic `BaseModel` with `SignatureMeta` as its metaclass.

```python
class MySignature(dspy.Signature):
    """Given a question, produce an answer."""
    question: str = InputField(desc="The question to answer")
    answer: int = OutputField(desc="The numeric answer")
```

#### Class Methods

| Method | Purpose |
|--------|---------|
| `with_instructions(instructions)` | Returns a new `Signature` class with the same fields but new instructions. |
| `with_updated_fields(name, type_=None, **kwargs)` | Returns a new `Signature` with a single field's `json_schema_extra` (and optionally type) updated. |
| `prepend(name, field, type_=None)` | Inserts a field at the beginning of its input/output group. |
| `append(name, field, type_=None)` | Inserts a field at the end of its input/output group. |
| `delete(name)` | Returns a new `Signature` with the named field removed. |
| `insert(index, name, field, type_=None)` | Inserts a field at a specific index within its input/output group. |
| `equals(other)` | Compares instructions and field JSON schemas of two signatures. |
| `dump_state()` | Serializes instructions and field prefixes/descriptions to a dict. |
| `load_state(state)` | Reconstructs a `Signature` from a state dict produced by `dump_state`. |

#### Properties (via metaclass)

| Property | Returns |
|----------|---------|
| `instructions` | The cleaned docstring / instructions string. |
| `input_fields` | Dict of input `FieldInfo` objects. |
| `output_fields` | Dict of output `FieldInfo` objects. |
| `fields` | Combined dict (inputs first, then outputs). |
| `signature` | String form `"input1, input2 -> output1, output2"`. |

---

## Data Flow

The following diagram illustrates how a signature string flows through parsing, type resolution, and class creation.

```mermaid
sequenceDiagram
    participant User
    participant SM as SignatureMeta.__call__
    participant MS as make_signature
    participant PS as _parse_signature
    participant TN as _parse_type_node
    participant CM as pydantic.create_model
    participant Sig as Signature subclass

    User->>SM: Signature("q: str -> a: int", "instructions")
    SM->>SM: _detect_custom_types_from_caller (optional)
    SM->>MS: make_signature(str, instructions, custom_types)
    MS->>PS: _parse_signature(str, names)
    PS->>PS: _parse_field_string (AST parse)
    PS->>TN: _parse_type_node for each annotation
    TN-->>PS: resolved Python types
    PS-->>MS: {name: (type, FieldInfo)}
    MS->>MS: validate & fix fields
    MS->>CM: create_model(name, __base__=Signature, __doc__, **fields)
    CM-->>Sig: new Signature class
    Sig-->>User: Signature class
```

### String Signature Parsing

The parsing pipeline converts a string like `"question: str, context: list[str] -> answer: int"` into typed fields:

```mermaid
flowchart LR
    A["question: str, context: list[str] -> answer: int"] --> B[_parse_signature]
    B --> C[split on '->']
    C --> D[_parse_field_string inputs]
    C --> E[_parse_field_string outputs]
    D --> F[ast.parse def f(...)]
    E --> F
    F --> G[_parse_type_node per annotation]
    G --> H[InputField / OutputField]
    H --> I[fields dict]
```

`_parse_type_node` handles a wide range of AST node types:

| AST Node | Example | Result |
|----------|---------|--------|
| `ast.Name` | `int` | `int` |
| `ast.Attribute` | `typing.List` | `typing.List` |
| `ast.Subscript` | `list[str]` | `list[str]` |
| `ast.BinOp` (`\|`) | `int \| None` | `Optional[int]` |
| `ast.Tuple` | `(int, str)` | `(int, str)` |
| `ast.Constant` | `None` | `None` |
| `ast.Call` (`Field`) | `Field(desc="...")` | `FieldInfo` |

---

## Component Interaction

The diagram below shows how the module's components interact with each other and with external modules.

```mermaid
graph LR
    subgraph signatures_signature
        Signature
        SignatureMeta
        make_signature
        ensure_signature
        infer_prefix
    end

    subgraph signatures_fields
        InputField
        OutputField
    end

    subgraph predict_core
        Predict
        Parameter
    end

    subgraph adapters_core
        Adapter
        ChatAdapter
    end

    subgraph teleprompt
        Optimizers
    end

    SignatureMeta -.->|metaclass| Signature
    Signature -->|declares fields with| InputField
    Signature -->|declares fields with| OutputField
    make_signature -->|creates| Signature
    ensure_signature -->|normalizes to| Signature
    SignatureMeta -->|uses| infer_prefix
    Predict -->|consumes| Signature
    Parameter -->|references| Signature
    Adapter -->|formats| Signature
    ChatAdapter -->|formats| Signature
    Optimizers -->|mutate via with_instructions / with_updated_fields| Signature
```

---

## Process Flows

### Creating a Signature from a String

```mermaid
flowchart TD
    A[Signature 'a, b -> c'] --> B{args[0] is str?}
    B -->|Yes| C[Detect custom types from caller frame]
    B -->|No| D[Use provided custom_types]
    C --> E[make_signature]
    D --> E
    E --> F[_parse_signature]
    F --> G[Validate field tuples]
    G --> H{instructions provided?}
    H -->|No| I[_default_instructions]
    H -->|Yes| J[Use provided instructions]
    I --> K[create_model]
    J --> K
    K --> L[New Signature class]
```

### Modifying a Signature

```mermaid
flowchart TD
    A[Existing Signature class] --> B{Operation}
    B -->|with_instructions| C[Signature fields, new instructions]
    B -->|with_updated_fields| D[deepcopy fields, update json_schema_extra]
    B -->|insert / prepend / append| E[Split input/output lists, insert, rebuild]
    B -->|delete| F[Remove field, rebuild]
    C --> G[New Signature class]
    D --> G
    E --> G
    F --> G
```

### State Serialization Round-Trip

```mermaid
flowchart LR
    A[Signature class] -->|dump_state| B["{instructions, fields: [{prefix, description}]}"]
    B -->|load_state| C[Signature copy with restored instructions/prefixes/descs]
```

---

## Dependencies

### Internal Dependencies

| Dependency | Usage |
|------------|-------|
| [`signatures_fields`](signatures_fields.md) | `InputField`, `OutputField` are used to declare fields; `OldField`/`OldInputField`/`OldOutputField` provide legacy compatibility. |

### External Dependencies

| Dependency | Usage |
|------------|-------|
| `pydantic` (`BaseModel`, `Field`, `create_model`, `FieldInfo`) | Base class, field construction, dynamic model creation. |
| `typing` | Type resolution namespace and generic alias handling. |
| `ast` | Parsing string-based signatures. |
| `importlib` | Dynamic module import for module-based annotations (e.g., `dspy.Image`). |
| `inspect` | Cleaning docstrings into instructions. |
| `re` | Prefix inference from attribute names. |
| `sys` | Frame introspection for custom type detection. |

### Downstream Consumers

| Module | How it uses `Signature` |
|--------|-------------------------|
| [`predict_core`](predict_core.md) | `Predict` and `Parameter` wrap a `Signature` to define LM tasks. |
| [`adapters_core`](adapters_core.md) | Adapters format signatures into prompts and parse outputs. |
| [`teleprompt`](teleprompt.md) | Optimizers mutate signatures via `with_instructions` / `with_updated_fields`. |
| [`evaluate`](evaluate_program_evaluation.md) | Evaluation programs operate on signatures. |

---

## Usage Examples

### Class-Based Signature

```python
import dspy
from dspy.signatures.field import InputField, OutputField

class QA(dspy.Signature):
    """Answer a question given context."""
    context: list[str] = InputField(desc="Relevant passages")
    question: str = InputField(desc="The question")
    answer: str = OutputField(desc="The answer")
```

### String-Based Signature

```python
sig = dspy.Signature("question: str -> answer: int", "Answer with a number.")
print(sig.signature)  # "question -> answer"
```

### Custom Types

```python
class MyType:
    pass

sig = dspy.Signature("input: MyType -> output", custom_types={"MyType": MyType})
```

### Runtime Modification

```python
new_sig = QA.with_instructions("Answer concisely.")
updated = QA.with_updated_fields("answer", desc="A short answer")
extended = QA.append("confidence", OutputField(desc="Confidence score"))
```

### State Serialization

```python
state = QA.dump_state()
restored = QA.load_state(state)
assert QA.equals(restored)
```

---

## Summary

The `signatures_signature` module provides DSPy's declarative task specification layer. Through the `SignatureMeta` metaclass and the `Signature` base class, it:

- Enables both class-based and string-based signature definitions.
- Integrates tightly with Pydantic for validation and schema generation.
- Supports dynamic creation, modification, and serialization of signatures.
- Serves as the contract consumed by prediction modules, adapters, and optimizers throughout DSPy.

For field-level details, see [`signatures_fields`](signatures_fields.md). For how signatures are executed, see [`predict_core`](predict_core.md) and [`adapters_core`](adapters_core.md).
