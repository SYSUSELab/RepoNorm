# Datasets Benchmarks

## Introduction

The `datasets_benchmarks` module provides a collection of ready-to-use benchmark datasets for evaluating and optimizing DSPy programs. These datasets wrap well-known academic benchmarks (GSM8K, HotPotQA, MATH) and a synthetic reasoning task (Colors), exposing them through a consistent interface that integrates seamlessly with the DSPy ecosystem.

Each benchmark is designed to be:
- **Self-contained**: Automatically downloads and preprocesses data from HuggingFace or generates it locally.
- **DSPy-native**: Returns `dspy.Example` objects with properly configured input keys.
- **Evaluation-ready**: Ships with task-specific metrics where applicable (e.g., `gsm8k_metric`, `MATH.metric`).

This module builds on the core dataset abstractions documented in [datasets_core.md](datasets_core.md) and the `Example` primitive documented in [primitives.md](primitives.md).

---

## Module Architecture

The module consists of four benchmark classes, each targeting a distinct reasoning or retrieval task. Two of them (`HotPotQA`, `Colors`) extend the base `Dataset` class, while `GSM8K` and `MATH` implement a standalone interface.

```mermaid
graph TD
    subgraph "datasets_benchmarks"
        GSM8K["GSM8K<br/>(grade-school math)"]
        HotPotQA["HotPotQA<br/>(multi-hop QA)"]
        MATH["MATH<br/>(competition math)"]
        Colors["Colors<br/>(synthetic reasoning)"]
    end

    subgraph "datasets_core"
        Dataset["Dataset<br/>(base class)"]
        DataLoader["DataLoader"]
    end

    subgraph "primitives"
        Example["Example"]
    end

    subgraph "External"
        HF["HuggingFace<br/>datasets"]
        MathEq["math_equivalence<br/>(optional)"]
    end

    HotPotQA -->|extends| Dataset
    Colors -->|extends| Dataset
    Dataset -->|produces| Example
    GSM8K -->|produces| Example
    MATH -->|produces| Example

    GSM8K -->|load_dataset| HF
    HotPotQA -->|load_dataset| HF
    MATH -->|load_dataset| HF
    MATH -->|metric| MathEq
```

---

## Component Overview

| Benchmark | Base Class | Task Type | Data Source | Splits | Metric |
|-----------|-----------|-----------|-------------|--------|--------|
| `GSM8K` | *(standalone)* | Grade-school math word problems | HuggingFace `gsm8k` | train/dev/test | `gsm8k_metric` |
| `HotPotQA` | `Dataset` | Multi-hop question answering | HuggingFace `hotpot_qa` | train/dev/test | *(user-defined)* |
| `MATH` | *(standalone)* | Competition mathematics | HuggingFace `DigitalLearningGmbH/MATH-lighteval` | train/dev/test | `MATH.metric` |
| `Colors` | `Dataset` | Synthetic color reasoning | Built-in list | train/dev | *(user-defined)* |

---

## GSM8K

`GSM8K` loads the [GSM8K](https://huggingface.co/datasets/gsm8k) grade-school math benchmark and preprocesses each example into a structured form containing the question, the gold reasoning chain, and the final numeric answer.

### Data Processing Flow

```mermaid
flowchart LR
    A["load_dataset('gsm8k', 'main')"] --> B["Parse answer field<br/>split on '####'"]
    B --> C["Extract gold_reasoning<br/>(text before ####)"]
    B --> D["Extract answer<br/>(numeric after ####)"]
    C --> E["Build example dicts"]
    D --> E
    E --> F["Shuffle with seed 0"]
    F --> G["train = first 200"]
    F --> H["dev = next 300"]
    F --> I["test = all official test"]
    G --> J["dspy.Example.with_inputs('question')"]
    H --> J
    I --> J
```

### Key Characteristics

- **Fixed splits**: `train` (200 examples), `dev` (300 examples), `test` (full official test set).
- **Deterministic shuffling**: Uses `random.Random(0)` for reproducibility.
- **Input keys**: Only `question` is marked as an input; `gold_reasoning` and `answer` serve as labels.
- **Answer normalization**: Commas are stripped and values are cast to integers to ensure consistent comparison.

### Metric: `gsm8k_metric`

The module provides a module-level metric function for evaluating predictions:

```python
def gsm8k_metric(gold, pred, trace=None):
    return int(parse_integer_answer(str(gold.answer))) == int(parse_integer_answer(str(pred.answer)))
```

The helper `parse_integer_answer` extracts the last numeric token from a string, handling multi-line outputs by defaulting to the first line. This makes the metric robust to verbose model outputs that include reasoning before the final answer.

---

## HotPotQA

`HotPotQA` extends the base `Dataset` class and loads the [HotPotQA](https://huggingface.co/datasets/hotpot_qa) multi-hop question answering benchmark in its `fullwiki` configuration.

### Configuration Options

| Parameter | Default | Description |
|-----------|---------|-------------|
| `only_hard_examples` | `True` | Restricts to "hard" difficulty examples (asserted to be `True`). |
| `keep_details` | `"dev_titles"` | Controls which fields are retained. `True` keeps all; `"dev_titles"` keeps `question`, `answer`, `supporting_facts`; otherwise only `question` and `answer`. |
| `unofficial_dev` | `True` | If `True`, carves a dev split from the training data; otherwise `dev` is `None`. |

### Split Strategy

```mermaid
flowchart TD
    A["Load fullwiki train split"] --> B["Filter level == 'hard'"]
    B --> C["Select fields per keep_details"]
    C --> D["Extract gold_titles from supporting_facts"]
    D --> E["Shuffle with seed 0"]
    E --> F["train = first 75%"]
    E --> G["dev = remaining 25%<br/>(if unofficial_dev)"]
    H["Load fullwiki validation split"] --> I["Assert level == 'hard'"]
    I --> J["test = all validation examples"]
```

### Notes

- The `gold_titles` field is derived from `supporting_facts` and represents the set of Wikipedia article titles needed to answer the question.
- When `keep_details == "dev_titles"`, `gold_titles` is removed from training examples but retained in the test set.
- The class includes a `__main__` block demonstrating usage with `dotdict` configuration arguments (see [dsp_utils.md](dsp_utils.md)).

---

## MATH

`MATH` loads the [MATH-lighteval](https://huggingface.co/datasets/DigitalLearningGmbH/MATH-lighteval) dataset for a specified subset (e.g., `"algebra"`, `"geometry"`).

### Sub-splitting Strategy

Because current language models are often trained on MATH's official train split, `MATH` sub-splits the **test** split into train/dev/test to avoid data leakage:

```mermaid
flowchart LR
    A["Load subset test split"] --> B["Extract answer via extract_answer()"]
    B --> C["Build dspy.Example<br/>question / reasoning / answer"]
    C --> D["Shuffle with seed 0"]
    D --> E["size = min(350, len/3)"]
    E --> F["train = [0:size]"]
    E --> G["dev = [size:2*size]"]
    E --> H["test = [2*size:]"]
```

### Answer Extraction

The `extract_answer` function parses LaTeX `\boxed{...}` expressions, correctly handling nested braces and stripping formatting commands like `\text{...}` and `\!`:

```python
def extract_answer(s):
    start = s.find("\\boxed{")
    # ... brace-matching logic ...
    answer = re.sub(r"\\text\{[^}]*\}", "", answer)
    answer = re.sub(r"\\!", "", answer)
    return answer.strip()
```

### Metric: `MATH.metric`

The instance method delegates to the official `math_equivalence.is_equiv` function, which requires an optional dependency:

```bash
pip install git+https://github.com/hendrycks/math.git
```

> **Note**: The official `math_equivalence.is_equiv` does not have perfect recall for certain reference formats (e.g., interval notation like `\left[\frac{1}{2}, \frac{4}{3}\right]`).

---

## Colors

`Colors` is a synthetic reasoning benchmark built from a curated list of ~150 color names (originally sourced from matplotlib). It is designed to test a model's ability to reason about color names and their relationships.

### Design Rationale

The dataset is **sorted by suffix** before splitting, which ensures that similar colors (e.g., "sky blue", "deep sky blue", "light sky blue") are grouped together. This prevents near-duplicate colors from appearing in both train and dev splits, making the evaluation more meaningful.

```mermaid
flowchart TD
    A["all_colors list"] --> B{"sort_by_suffix?"}
    B -->|Yes| C["Sort by reversed string"]
    B -->|No| D["Keep original order"]
    C --> E["train = first 60%"]
    D --> E
    E --> F["dev = remaining 40%"]
    F --> G["Shuffle both with seed 0"]
```

### Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `sort_by_suffix` | `True` | Sorts colors by their reversed string before splitting. |

### Splits

- **train**: 60% of colors
- **dev**: 40% of colors
- **test**: *(not defined)*

Each example is a simple dict `{"color": <color_name>}` that the base `Dataset` class converts into a `dspy.Example`.

---

## Integration with the DSPy Ecosystem

The benchmarks in this module are consumed throughout DSPy for optimization and evaluation workflows.

```mermaid
graph LR
    subgraph "datasets_benchmarks"
        Bench["Benchmark<br/>(GSM8K / HotPotQA / MATH / Colors)"]
    end

    subgraph "Optimization"
        Teleprompt["Teleprompters<br/>(BootstrapFewShot, MIPROv2, ...)"]
    end

    subgraph "Evaluation"
        Evaluate["Evaluate"]
    end

    subgraph "Core"
        Example["Example"]
        Dataset["Dataset"]
    end

    Bench -->|train/dev sets| Teleprompt
    Bench -->|test set + metric| Evaluate
    Bench -->|produces| Example
    Dataset -->|base class| Bench
```

### Typical Usage

```python
import dspy
from dspy.datasets.gsm8k import GSM8K, gsm8k_metric

# Load the benchmark
gsm8k = GSM8K()

# Configure a program
program = dspy.ChainOfThought("question -> answer")

# Optimize using the training set
optimizer = dspy.BootstrapFewShot(metric=gsm8k_metric)
optimized = optimizer.compile(program, trainset=gsm8k.train)

# Evaluate on the test set
evaluate = dspy.Evaluate(devset=gsm8k.test, metric=gsm8k_metric)
score = evaluate(optimized)
```

### Related Modules

- **[datasets_core.md](datasets_core.md)**: The base `Dataset` and `DataLoader` classes that `HotPotQA` and `Colors` extend.
- **[primitives.md](primitives.md)**: The `Example` primitive used to represent all dataset items.
- **[evaluate.md](evaluate.md)**: The `Evaluate` class used to score programs against these benchmarks.
- **[teleprompt.md](teleprompt.md)**: Optimizers that consume the train/dev splits.
- **[dsp_utils.md](dsp_utils.md)**: Utility types like `dotdict` used in configuration.

---

## Summary

The `datasets_benchmarks` module offers a consistent, DSPy-native interface to four widely-used benchmarks spanning arithmetic reasoning (GSM8K, MATH), multi-hop retrieval QA (HotPotQA), and synthetic relational reasoning (Colors). By handling data download, preprocessing, deterministic splitting, and metric definition, it lets developers focus on building and optimizing DSPy programs rather than wrangling raw datasets.
