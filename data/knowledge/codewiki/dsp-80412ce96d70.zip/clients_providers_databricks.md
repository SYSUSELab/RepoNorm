# Databricks Provider

## Introduction

The `clients_providers_databricks` module implements DSPy's integration with the **Databricks** platform for model fine-tuning and deployment. It provides a concrete [`Provider`](clients_providers.md) implementation (`DatabricksProvider`) that enables DSPy programs to fine-tune foundation models on Databricks, upload training data to Unity Catalog, and deploy the resulting models as Databricks serving endpoints.

Unlike proprietary model providers (e.g., OpenAI), Databricks is a *platform* rather than a model vendor, so this provider is **not auto-discovered** via model-name inference. It must be explicitly selected when fine-tuning.

**Source:** `dspy/clients/databricks.py`

---

## Core Components

| Component | Type | Responsibility |
|-----------|------|----------------|
| `DatabricksProvider` | `Provider` subclass | Fine-tuning orchestration, data upload, and model deployment on Databricks |
| `TrainingJobDatabricks` | `TrainingJob` subclass | Tracks the lifecycle/status of a Databricks fine-tuning run |

### Supporting Helpers (module-private)

| Helper | Responsibility |
|--------|----------------|
| `_get_workspace_client()` | Lazily constructs a Databricks `WorkspaceClient` |
| `_create_directory_in_databricks_unity_catalog()` | Validates and creates a Unity Catalog volume directory |
| `_save_data_to_local_file()` | Serializes training data to a local `.jsonl` file |
| `_validate_chat_data()` | Validates chat-format training records |
| `_validate_completion_data()` | Validates completion-format training records |

---

## Architecture

The module plugs into DSPy's provider abstraction. `DatabricksProvider` extends the abstract [`Provider`](clients_providers.md) base class and is invoked by [`LM`](clients_lm.md) when a fine-tuning job is requested.

```mermaid
graph TD
    LM["LM (dspy/clients/lm.py)"]
    Provider["Provider (abstract base)"]
    TrainingJob["TrainingJob (abstract base)"]
    DBP["DatabricksProvider"]
    TJDB["TrainingJobDatabricks"]
    FM["databricks.model_training.foundation_model"]
    SDK["databricks.sdk.WorkspaceClient"]
    UC["Unity Catalog (Volumes)"]
    Serving["Databricks Model Serving"]

    LM -->|"finetune()"| DBP
    Provider -->|extends| DBP
    TrainingJob -->|extends| TJDB
    DBP -->|"TrainingJob ="| TJDB
    DBP -->|"fm.create / fm.get"| FM
    DBP -->|"files.upload / volumes.read"| SDK
    SDK --> UC
    DBP -->|"deploy_finetuned_model()"| Serving
    TJDB -->|"status()"| FM
```

---

## Component Details

### `DatabricksProvider`

A `Provider` subclass with `finetunable = True` and `TrainingJob = TrainingJobDatabricks`. It implements the following static methods.

#### `is_provider_model(model) -> bool`

Always returns `False`. Databricks is not a proprietary model provider, so models are **never auto-inferred**. Users must explicitly pass a `DatabricksProvider` instance to [`LM`](clients_lm.md).

#### `finetune(job, model, train_data, train_data_format, train_kwargs) -> str`

The primary entry point invoked by [`LM._run_finetune_job`](clients_lm.md). It:

1. Normalizes `train_data_format` (accepts `"chat"` / `"completion"` strings or a [`TrainDataFormat`](clients_finetune.md) enum).
2. Requires `train_data_path` in `train_kwargs` and uploads the data via `upload_data()`.
3. Requires `register_to` in `train_kwargs` (the Unity Catalog model destination).
4. Pops optional overrides: `databricks_host`, `databricks_token`, `skip_deploy`, `deploy_timeout`.
5. Calls `fm.create(...)` to start the fine-tuning run and polls `fm.get(...)` every 60 seconds until the run is `Completed` or `Failed`.
6. Unless `skip_deploy=True`, deploys the model via `deploy_finetuned_model()` and returns the model identifier in the form `databricks/<endpoint_name>`.

#### `upload_data(train_data, databricks_unity_catalog_path, data_format) -> str`

Serializes `train_data` to a local `.jsonl` file (validating each record), ensures the target Unity Catalog directory exists, and uploads the file via the Workspace SDK. Returns the full target path.

#### `deploy_finetuned_model(model, data_format, databricks_host, databricks_token, deploy_timeout)`

Creates or updates a Databricks **serving endpoint** for the fine-tuned model:

1. Resolves the latest model version via `WorkspaceClient.model_versions.list`.
2. Queries the model-optimization-info API to confirm the model is eligible for provisioned throughput and to obtain the `throughput_chunk_size`.
3. Creates a new endpoint (POST) or updates an existing one (PUT), using a sanitized name (dots replaced with underscores).
4. Polls the endpoint with a minimal OpenAI-compatible request until it responds, up to `deploy_timeout` seconds (default 900).

### `TrainingJobDatabricks`

Extends [`TrainingJob`](clients_providers.md) (itself a `Future`). It stores the underlying `finetuning_run` handle and tracks deployment progress via `launch_started`, `launch_completed`, and `endpoint_name`.

#### `status()`

Returns the current status of the Databricks fine-tuning run by calling `fm.get(self.finetuning_run).status`. Returns `None` if no run is associated.

---

## Data Flow

The end-to-end fine-tuning and deployment flow:

```mermaid
sequenceDiagram
    participant User
    participant LM as LM
    participant DBP as DatabricksProvider
    participant Local as Local FS
    participant UC as Unity Catalog
    participant FM as foundation_model
    participant Serving as Model Serving

    User->>LM: finetune(train_data, format, kwargs)
    LM->>DBP: finetune(job, model, data, format, kwargs)
    DBP->>Local: _save_data_to_local_file() + validate
    DBP->>UC: _create_directory_in_databricks_unity_catalog()
    DBP->>UC: files.upload(jsonl)
    DBP->>FM: fm.create(model, train_data_path, register_to)
    loop poll every 60s
        DBP->>FM: fm.get(run)
    end
    alt skip_deploy = False
        DBP->>Serving: deploy_finetuned_model()
        loop poll until ready
            DBP->>Serving: minimal completion request
        end
    end
    DBP-->>LM: "databricks/<endpoint_name>"
    LM-->>User: TrainingJob (Future) resolves to new LM
```

---

## Data Validation

Training records are validated before upload based on the [`TrainDataFormat`](clients_finetune.md):

```mermaid
flowchart TD
    Start[Training record] --> Fmt{data_format}
    Fmt -->|CHAT| ChatCheck["_validate_chat_data()"]
    Fmt -->|COMPLETION| CompCheck["_validate_completion_data()"]
    ChatCheck --> ChatReq["Requires 'messages' list<br/>each with 'role' and 'content'"]
    CompCheck --> CompReq["Requires 'prompt'<br/>and 'response' or 'completion'"]
    ChatReq --> Write[Write JSONL line]
    CompReq --> Write
```

---

## Dependencies

### Internal Dependencies

| Dependency | Purpose |
|------------|---------|
| [`Provider`, `TrainingJob`](clients_providers.md) | Abstract base classes implemented/extended here |
| [`TrainDataFormat`, `get_finetune_directory`](clients_finetune.md) | Data format enum and local finetune cache directory |
| [`LM`](clients_lm.md) | Invokes `finetune()` and consumes the returned model name |

### External Dependencies

| Package | Required For | Install |
|---------|--------------|---------|
| `databricks-sdk` | Workspace client, Unity Catalog file operations | `pip install databricks-sdk` |
| `databricks_genai` | `databricks.model_training.foundation_model` (fine-tuning) | `pip install databricks_genai` |
| `requests` | Serving endpoint REST API calls | (bundled) |
| `ujson` | Fast JSONL serialization | (bundled) |
| `openai` | Readiness polling of serving endpoints | (bundled) |

> **Note:** The Databricks SDK and GenAI packages are imported lazily inside methods. If they are missing, a descriptive `ImportError` is raised at call time rather than at module import.

---

## Usage Example

```python
import dspy
from dspy.clients.databricks import DatabricksProvider

lm = dspy.LM(
    model="databricks/databricks-meta-llama-3-1-70b-instruct",
    provider=DatabricksProvider(),
    finetuning_model="databricks-meta-llama-3-1-70b-instruct",
)

job = lm.finetune(
    train_data=[{"messages": [{"role": "user", "content": "hi"}, {"role": "assistant", "content": "hello"}]}],
    train_data_format="chat",
    train_kwargs={
        "train_data_path": "/Volumes/my_catalog/my_schema/my_volume/finetune",
        "register_to": "my_catalog.my_schema.my_model",
        "databricks_host": "https://<workspace>.cloud.databricks.com",
        "databricks_token": "<token>",
    },
)

finetuned_lm = job.result()  # resolves to an LM pointing at the new endpoint
```

---

## Related Documentation

- [clients_providers.md](clients_providers.md) — Provider abstraction and other provider implementations
- [clients_lm.md](clients_lm.md) — The `LM` class that drives fine-tuning
- [clients_finetune.md](clients_finetune.md) — `TrainDataFormat` and finetune utilities
- [clients_providers_openai.md](clients_providers_openai.md) — OpenAI provider (for comparison)
- [clients_providers_local.md](clients_providers_local.md) — Local provider
- [clients_providers_arbor.md](clients_providers_arbor.md) — Arbor provider (reinforcement learning)
