# Utils Callbacks

## Introduction

The `utils_callbacks` module provides DSPy's **callback (hook) system**, enabling developers to observe and react to the lifecycle of core DSPy components without modifying their source code. It exposes a single extensible base class, `BaseCallback`, and a `with_callbacks` decorator that instruments component methods to fire the appropriate handlers before and after execution.

Callbacks are the primary mechanism for cross-cutting concerns such as logging, tracing, profiling, token accounting, and debugging. They can be registered **globally** (via `dspy.settings.configure`) or **locally** (per component instance), and they fire for modules, language models, adapters, tools, and evaluation runs.

> **Related modules:** Callbacks integrate deeply with the [Settings](dsp_utils_settings.md) configuration system, the [LM client](clients_lm.md), the [Adapter](adapters_core.md) layer, the [Evaluate](evaluate_program_evaluation.md) harness, and the [Tool](adapter_types_tool.md) type.

---

## Core Components

| Component | Location | Role |
|-----------|----------|------|
| `BaseCallback` | `dspy/utils/callback.py` | Base class defining all lifecycle handler hooks. Subclass and override the handlers you care about. |
| `with_callbacks` | `dspy/utils/callback.py` | Decorator that wraps instance methods to invoke start/end handlers around execution. |
| `ACTIVE_CALL_ID` | `dspy/utils/callback.py` | A `ContextVar` tracking the currently active call ID, enabling parent/child call correlation. |
| `_get_on_start_handler` / `_get_on_end_handler` | `dspy/utils/callback.py` | Internal dispatch helpers that select the correct handler based on the instance type and method name. |

---

## Architecture

The callback system is built around a **decorator + dispatch** pattern. Component methods are decorated with `with_callbacks`, which resolves the set of active callbacks, generates a unique `call_id`, and dispatches to the correct handler based on the runtime type of the instance.

```mermaid
graph TD
    subgraph "Callback Definition"
        BC[BaseCallback]
        BC --> M[on_module_start / on_module_end]
        BC --> L[on_lm_start / on_lm_end]
        BC --> AF[on_adapter_format_start / _end]
        BC --> AP[on_adapter_parse_start / _end]
        BC --> T[on_tool_start / on_tool_end]
        BC --> E[on_evaluate_start / on_evaluate_end]
    end

    subgraph "Instrumentation"
        WC[with_callbacks decorator]
        WC --> SW[sync_wrapper]
        WC --> AW[async_wrapper]
    end

    subgraph "Dispatch"
        GS[_get_on_start_handler]
        GE[_get_on_end_handler]
    end

    subgraph "Instrumented Components"
        MOD[Module.forward]
        LM[LM.__call__ / acall]
        AD[Adapter.format / parse]
        TL[Tool.__call__ / acall]
        EV[Evaluate.__call__]
    end

    MOD --> WC
    LM --> WC
    AD --> WC
    TL --> WC
    EV --> WC

    WC --> GS
    WC --> GE
    GS --> BC
    GE --> BC
```

### Handler Dispatch Mapping

The dispatch helpers map the runtime instance type (and, for adapters, the method name) to the correct handler pair:

```mermaid
graph LR
    I[Instance] --> Q{Type?}
    Q -->|dspy.LM| LMH[on_lm_start / on_lm_end]
    Q -->|dspy.Evaluate| EVH[on_evaluate_start / on_evaluate_end]
    Q -->|dspy.Adapter| AQ{Method?}
    AQ -->|format| AFH[on_adapter_format_start / _end]
    AQ -->|parse| APH[on_adapter_parse_start / _end]
    Q -->|dspy.Tool| TH[on_tool_start / on_tool_end]
    Q -->|anything else| MH[on_module_start / on_module_end]
```

---

## Callback Registration

Callbacks can be registered at two scopes, and both are combined at call time:

```mermaid
graph TD
    subgraph "Global Scope"
        SC[dspy.settings.configure callbacks=[...]]
    end
    subgraph "Instance Scope"
        IC[Component constructor callbacks=[...]]
    end
    SC --> COMB[_get_active_callbacks]
    IC --> COMB
    COMB --> EXEC[Execute on each instrumented call]
```

- **Global callbacks** are stored in the [Settings](dsp_utils_settings.md) singleton under the `callbacks` key and apply to every instrumented component.
- **Instance callbacks** are stored on the component instance (e.g., `LM.callbacks`, `Adapter.callbacks`) and apply only to that instance.

The combined list is retrieved by `_get_active_callbacks(instance)`:

```python
dspy.settings.get("callbacks", []) + getattr(instance, "callbacks", [])
```

If no callbacks are registered, the wrapper short-circuits and calls the original function directly, avoiding any overhead.

---

## Execution Flow

When an instrumented method is invoked, the wrapper performs the following sequence:

```mermaid
sequenceDiagram
    participant Caller
    participant Wrapper as with_callbacks wrapper
    participant Start as Start Handlers
    participant Fn as Original Method
    participant End as End Handlers

    Caller->>Wrapper: invoke method(args, kwargs)
    Wrapper->>Wrapper: resolve active callbacks
    alt no callbacks
        Wrapper->>Fn: call directly
        Fn-->>Caller: return result
    else callbacks present
        Wrapper->>Wrapper: generate call_id (uuid4)
        Wrapper->>Start: on_*_start(call_id, instance, inputs)
        Wrapper->>Wrapper: set ACTIVE_CALL_ID = call_id
        Wrapper->>Fn: call method
        alt success
            Fn-->>Wrapper: results
        else exception
            Fn-->>Wrapper: raise exception
        end
        Wrapper->>Wrapper: restore parent ACTIVE_CALL_ID
        Wrapper->>End: on_*_end(call_id, outputs, exception)
        Wrapper-->>Caller: return results / re-raise
    end
```

### Key Behaviors

1. **Unique call IDs** — Each invocation generates a `uuid4().hex` `call_id`, allowing start/end handlers to be correlated.
2. **Input extraction** — `inspect.getcallargs` captures the method arguments into a dictionary, with `self`/`instance` removed.
3. **Nested call tracking** — `ACTIVE_CALL_ID` is a `ContextVar` that stores the parent call ID before the current call begins and restores it in the `finally` block. This enables building call trees (e.g., a module call that internally triggers an LM call).
4. **Exception safety** — End handlers always run (via `finally`), receiving the exception object if one occurred. The exception is re-raised after handlers complete.
5. **Handler isolation** — Each callback invocation is wrapped in a `try/except`; a failing callback logs a warning but never breaks the instrumented call.
6. **Sync/async parity** — `with_callbacks` detects coroutine functions via `inspect.iscoroutinefunction` and produces either a `sync_wrapper` or `async_wrapper` with identical semantics.

---

## Data Flow

```mermaid
flowchart LR
    A[Component method call] --> B[with_callbacks wrapper]
    B --> C{Callbacks registered?}
    C -->|No| D[Direct call]
    C -->|Yes| E[Generate call_id]
    E --> F[Extract inputs via getcallargs]
    F --> G[Dispatch start handler]
    G --> H[Set ACTIVE_CALL_ID]
    H --> I[Execute original method]
    I --> J{Exception?}
    J -->|Yes| K[Capture exception]
    J -->|No| L[Capture outputs]
    K --> M[Restore parent call_id]
    L --> M
    M --> N[Dispatch end handler]
    N --> O[Return / re-raise]
```

---

## Usage Examples

### Global Callback via Settings

```python
import dspy
from dspy.utils.callback import BaseCallback

class LoggingCallback(BaseCallback):
    def on_lm_start(self, call_id, instance, inputs):
        print(f"LM called with inputs: {inputs}")

    def on_lm_end(self, call_id, outputs, exception):
        print(f"LM finished with outputs: {outputs}")

dspy.settings.configure(callbacks=[LoggingCallback()])

cot = dspy.ChainOfThought("question -> answer")
cot(question="What is the meaning of life?")
```

### Local Callback via Constructor

```python
lm_1 = dspy.LM("gpt-3.5-turbo", callbacks=[LoggingCallback()])
lm_1(question="What is the meaning of life?")  # Logs

lm_2 = dspy.LM("gpt-3.5-turbo")
lm_2(question="What is the meaning of life?")  # No logging
```

---

## Handler Reference

`BaseCallback` defines the following overridable handlers. All handlers default to no-ops.

| Handler | Triggered When | Key Arguments |
|---------|----------------|---------------|
| `on_module_start` / `on_module_end` | `forward()` of a `dspy.Module` subclass is called | `call_id`, `instance`, `inputs` / `outputs`, `exception` |
| `on_lm_start` / `on_lm_end` | `__call__` of a `dspy.LM` instance is called | `call_id`, `instance`, `inputs` / `outputs`, `exception` |
| `on_adapter_format_start` / `on_adapter_format_end` | `format()` of a `dspy.Adapter` is called | `call_id`, `instance`, `inputs` / `outputs`, `exception` |
| `on_adapter_parse_start` / `on_adapter_parse_end` | `parse()` of a `dspy.Adapter` is called | `call_id`, `instance`, `inputs` / `outputs`, `exception` |
| `on_tool_start` / `on_tool_end` | A `dspy.Tool` is called | `call_id`, `instance`, `inputs` / `outputs`, `exception` |
| `on_evaluate_start` / `on_evaluate_end` | `Evaluate.__call__` is invoked | `call_id`, `instance`, `inputs` / `outputs`, `exception` |

> **Note:** For adapters, only `format` and `parse` methods are supported. Any other adapter method decorated with `with_callbacks` raises a `ValueError`.

---

## Integration Points

The callback system is wired into DSPy components through the `with_callbacks` decorator:

```mermaid
graph TD
    WC[with_callbacks]
    WC -->|decorates| MOD[Module.forward]
    WC -->|decorates| LM[LM.__call__ / acall]
    WC -->|decorates via __init_subclass__| AD[Adapter.format / parse]
    WC -->|decorates| TL[Tool.__call__ / acall]
    WC -->|decorates| EV[Evaluate.__call__]
```

- **Adapters** apply the decorator automatically in `Adapter.__init_subclass__`, so every adapter subclass gets instrumented `format` and `parse` methods without manual decoration. See [adapters_core](adapters_core.md).
- **LM** and **Tool** decorate their call methods directly. See [clients_lm](clients_lm.md) and [adapter_types_tool](adapter_types_tool.md).
- **Evaluate** decorates `__call__` and passes `callback_metadata` for richer handler context. See [evaluate_program_evaluation](evaluate_program_evaluation.md).
- **Settings** stores the global callback list and provides the `callbacks` configuration key. See [dsp_utils_settings](dsp_utils_settings.md).

---

## Design Considerations

- **Zero-overhead when unused** — If no callbacks are registered, the wrapper bypasses all instrumentation logic.
- **Fault tolerance** — Callback errors are logged as warnings and never propagate to the caller, ensuring observability code cannot break application logic.
- **Context propagation** — `ACTIVE_CALL_ID` uses `contextvars`, so call IDs propagate correctly across `async` boundaries and thread-local contexts.
- **Composability** — Multiple callbacks can be registered simultaneously; each receives every event in registration order (global callbacks first, then instance callbacks).
