# Streaming Messages

## Introduction

The `streaming_messages` module (`dspy/streaming/messages.py`) provides the data structures and callback machinery that power **status message streaming** in DSPy. While the sibling [`streaming_listener`](streaming_listener.md) module is responsible for capturing and yielding the *content* of a predictor's output fields token-by-token, this module focuses on a complementary concern: emitting human-readable **status messages** that describe *what the program is currently doing* (e.g., "Calling tool X...", "Querying the LLM...").

The module exposes four core components:

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `StreamResponse` | `dataclass` | A single streamed chunk of an output field, tagged with the predictor and field it belongs to. |
| `StatusMessage` | `dataclass` | A wrapper around a human-readable status string for status streaming. |
| `StatusMessageProvider` | class | A customizable base class whose methods return status strings for different execution stages. |
| `StatusStreamingCallback` | `BaseCallback` subclass | A DSPy callback that hooks into module/LM/tool lifecycle events and pushes `StatusMessage` objects onto the active stream. |

Together these components let users observe the *progress* of a DSPy program in real time, independent of the actual model output.

---

## Architecture Overview

The module sits at the intersection of three subsystems: the **callback system** (which fires lifecycle events), the **settings singleton** (which holds the active stream), and the **streaming pipeline** (which consumes the emitted messages).

```mermaid
graph TD
    subgraph "streaming_messages module"
        SR[StreamResponse]
        SM[StatusMessage]
        SMP[StatusMessageProvider]
        SSC[StatusStreamingCallback]
    end

    BC[BaseCallback<br/>dspy/utils/callback.py]
    SET[Settings<br/>dspy/dsp/utils/settings.py]
    SL[StreamListener<br/>streaming_listener.py]

    SSC -->|inherits| BC
    SSC -->|reads settings.send_stream| SET
    SSC -->|uses| SMP
    SSC -->|emits| SM
    SL -->|emits| SR
    SM -.->|consumed by| STREAM[streamify pipeline]
    SR -.->|consumed by| STREAM
```

### Key relationships

- **`StatusStreamingCallback` inherits from [`BaseCallback`](utils.md)** — it overrides the lifecycle hooks (`on_module_start/end`, `on_lm_start/end`, `on_tool_start/end`) to translate events into status messages.
- **`StatusStreamingCallback` reads `settings.send_stream`** — the active stream is stored on the global [`Settings`](dsp_utils.md) singleton. If no stream is configured, the callback is a no-op.
- **`StatusMessageProvider` is pluggable** — users subclass it to customize the status strings, and inject it into the callback.
- **`StreamResponse` is produced by [`StreamListener`](streaming_listener.md)** — it is the content-streaming counterpart to `StatusMessage`. Both are pushed onto the same stream.

---

## Component Details

### `StreamResponse`

```python
@dataclass
class StreamResponse:
    predict_name: str
    signature_field_name: str
    chunk: str
```

A lightweight dataclass representing a single streamed chunk of a predictor's output field. It is produced by the [`StreamListener`](streaming_listener.md) (not by this module's callback) and carries enough metadata for downstream consumers to route the chunk to the correct field:

- `predict_name`: the name of the predictor that produced the chunk.
- `signature_field_name`: the output field being streamed.
- `chunk`: the actual text fragment.

> **Note:** Although `StreamResponse` is defined in this file, its *production* logic lives in [`streaming_listener`](streaming_listener.md). This module only defines the data container.

### `StatusMessage`

```python
@dataclass
class StatusMessage:
    """Dataclass that wraps a status message for status streaming."""
    message: str
```

A minimal wrapper around a human-readable status string. Wrapping the string in a dedicated type allows consumers of the stream to distinguish status messages from content chunks (`StreamResponse`) by type inspection.

### `StatusMessageProvider`

A base class for defining **customizable status messages**. Each method corresponds to a lifecycle stage and must return a string (or `None`/`pass` to emit nothing).

| Method | Triggered when | Default return |
|--------|----------------|----------------|
| `tool_start_status_message(instance, inputs)` | Before a `dspy.Tool` is called | `"Calling tool {name}..."` |
| `tool_end_status_message(outputs)` | After a `dspy.Tool` is called | `"Tool calling finished! Querying the LLM with tool calling results..."` |
| `module_start_status_message(instance, inputs)` | Before a `dspy.Module`/`dspy.Predict` is called | `None` (no message) |
| `module_end_status_message(outputs)` | After a `dspy.Module`/`dspy.Predict` is called | `None` (no message) |
| `lm_start_status_message(instance, inputs)` | Before a `dspy.LM` is called | `None` (no message) |
| `lm_end_status_message(outputs)` | After a `dspy.LM` is called | `None` (no message) |

Only the tool-related methods return messages by default; all others are intentionally silent so that users opt in to the verbosity they want.

**Example — custom provider:**

```python
class MyStatusMessageProvider(StatusMessageProvider):
    def lm_start_status_message(self, instance, inputs):
        return f"Calling LM with inputs {inputs}..."

    def module_end_status_message(self, outputs):
        return f"Module finished with output: {outputs}!"

program = dspy.streamify(
    dspy.Predict("q->a"),
    status_message_provider=MyStatusMessageProvider(),
)
```

### `StatusStreamingCallback`

A [`BaseCallback`](utils.md) subclass that bridges DSPy lifecycle events to the active stream. It is constructed with an optional `StatusMessageProvider` (defaulting to the base provider).

```python
class StatusStreamingCallback(BaseCallback):
    def __init__(self, status_message_provider: StatusMessageProvider | None = None):
        self.status_message_provider = status_message_provider or StatusMessageProvider()
```

Each overridden hook follows the same pattern:

1. Read `settings.send_stream`.
2. If the stream is `None`, return early (no-op).
3. Apply any special-case filtering (see below).
4. Ask the provider for a status string.
5. If the string is truthy, push a `StatusMessage` onto the stream via `sync_send_to_stream`.

#### Special-case filtering

- **`on_tool_start`**: skips when `instance.name == "finish"` — the internal `finish` tool is an implementation detail and should not surface a status message.
- **`on_tool_end`**: skips when `outputs == "Completed."` — this sentinel indicates the tool-calling loop has terminated, so no further status is needed.

#### The `sync_send_to_stream` helper

```python
def sync_send_to_stream(stream, message):
    """Send message to stream in a sync context, regardless of event loop state."""
```

This module-level helper solves a subtle concurrency problem: DSPy callbacks may fire from **synchronous** code, but the stream's `send` method is **async**. The helper detects whether an event loop is already running:

- **If a loop is running** (e.g., inside an async program): it offloads the coroutine to a *new* event loop running in a separate thread via `ThreadPoolExecutor`, avoiding the "cannot run event loop while another is running" error.
- **If no loop is running**: it uses `asyncer.syncify` to run the coroutine directly.

```mermaid
flowchart TD
    A[sync_send_to_stream called] --> B{asyncio.get_running_loop<br/>succeeds?}
    B -->|Yes, loop running| C[Spawn ThreadPoolExecutor]
    C --> D[Create new event loop in thread]
    D --> E[run_until_complete stream.send]
    E --> F[Return result]
    B -->|No, RuntimeError| G[syncify stream.send]
    G --> F
```

---

## Data Flow

The following sequence diagram shows how a status message travels from a lifecycle event to the consumer of the stream.

```mermaid
sequenceDiagram
    participant Prog as DSPy Program
    participant CB as StatusStreamingCallback
    participant Prov as StatusMessageProvider
    participant Set as settings.send_stream
    participant Helper as sync_send_to_stream
    participant Cons as Stream Consumer

    Prog->>CB: on_lm_start(call_id, instance, inputs)
    CB->>Set: read send_stream
    alt stream is None
        CB-->>Prog: return (no-op)
    else stream configured
        CB->>Prov: lm_start_status_message(instance, inputs)
        Prov-->>CB: "Calling LM..."
        CB->>Helper: sync_send_to_stream(stream, StatusMessage(...))
        Helper->>Cons: await stream.send(StatusMessage)
    end
```

### Message types on the stream

A single stream may carry two distinct message types, which consumers distinguish by type:

```mermaid
graph LR
    subgraph Stream
        SR[StreamResponse<br/>content chunks]
        SM[StatusMessage<br/>progress updates]
    end
    SL[StreamListener] -->|produces| SR
    SSC[StatusStreamingCallback] -->|produces| SM
```

---

## Integration with the Broader System

### Callback system

`StatusStreamingCallback` is one of many possible [`BaseCallback`](utils.md) implementations. It is registered like any other callback — either globally via `dspy.settings.configure(callbacks=[...])` or locally on a component. Because it only overrides the module/LM/tool hooks, it composes cleanly with other callbacks.

### Settings singleton

The callback depends on the global [`Settings`](dsp_utils.md) object for two things:

- `settings.send_stream` — the active stream to push messages onto.
- `settings.adapter` — used indirectly by the sibling [`StreamListener`](streaming_listener.md) to determine field delimiters.

Because `Settings` is thread-safe and supports thread-local overrides via `context()`, status streaming works correctly across threads spawned by DSPy primitives.

### Streaming pipeline

This module is consumed by the `dspy.streamify` entry point, which wires together:

1. A [`StreamListener`](streaming_listener.md) (for content chunks → `StreamResponse`).
2. A `StatusStreamingCallback` (for progress updates → `StatusMessage`).

Both feed the same async stream, giving consumers a unified view of program execution.

---

## Summary

The `streaming_messages` module is a small but essential piece of DSPy's streaming infrastructure:

- **`StreamResponse`** and **`StatusMessage`** are the two message types that flow through a stream.
- **`StatusMessageProvider`** offers a clean extension point for customizing progress messages.
- **`StatusStreamingCallback`** connects DSPy's lifecycle events to the stream, with careful handling of sync/async boundaries via `sync_send_to_stream`.

For the content-streaming counterpart, see [`streaming_listener`](streaming_listener.md). For the callback base class and settings singleton, see [`utils`](utils.md) and [`dsp_utils`](dsp_utils.md) respectively.
