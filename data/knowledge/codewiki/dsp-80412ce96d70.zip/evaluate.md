# Evaluate Module

## Overview

The `evaluate` module provides the core evaluation infrastructure for DSPy programs. It enables developers to measure the performance of a DSPy program against a labeled dataset using a user-defined metric function, and it also ships with a set of **automatic, LLM-based evaluation metrics** that require no hand-written scoring logic.

The module is organized around two complementary concerns:

1. **Program evaluation** — running a program over a dataset, applying a metric, aggregating scores, and presenting results (with optional parallel execution and tabular display).
2. **Automatic evaluation metrics** — ready-to-use `Module` implementations that use an LLM (via `ChainOfThought`) to judge the quality of a system's responses (semantic F1, answer completeness, groundedness, etc.).

## Architecture

```mermaid
graph TD
    subgraph evaluate["evaluate module"]
        E["Evaluate<br/>(evaluate.py)"]
        ER["EvaluationResult<br/>(evaluate.py)"]
        SF1["SemanticF1<br/>(auto_evaluation.py)"]
        CG["CompleteAndGrounded<br/>(auto_evaluation.py)"]
        SIG["Signatures:<br/>SemanticRecallPrecision<br/>DecompositionalSemanticRecallPrecision<br/>AnswerCompleteness<br/>AnswerGroundedness"]
    end

    E -->|produces| ER
    E -->|uses| PE["ParallelExecutor<br/>(utils)"]
    E -->|calls| M["dspy.Module<br/>(program under test)"]
    E -->|applies| MET["metric Callable"]

    SF1 -->|wraps| COT["ChainOfThought<br/>(predict)"]
    CG -->|wraps| COT
    COT -->|uses| SIG
    SF1 -->|returns score| MET
    CG -->|returns score| MET

    ER -->|extends| PRED["Prediction<br/>(primitives)"]
```

The module has two independent sub-modules that are typically used together: the `Evaluate` runner produces scores, and the automatic metrics can be plugged in as the `metric` argument to `Evaluate`.

## Sub-modules

### 1. Program Evaluation (`Evaluate` / `EvaluationResult`)

The evaluation runner. `Evaluate` orchestrates running a program over a `devset`, applying a metric to each `(example, prediction)` pair, aggregating the results into a percentage score, and optionally rendering a results table. It supports parallel execution via `ParallelExecutor`, error tolerance via `max_errors`, and a configurable `failure_score` for failed examples.

See [evaluate_program_evaluation.md](evaluate_program_evaluation.md) for full details.

### 2. Automatic Evaluation Metrics

A collection of LLM-as-judge metrics built on top of `ChainOfThought` and DSPy `Signature`s. These include:

- **`SemanticF1`** — computes an F1 score over semantic recall/precision of a system response against ground truth, with an optional decompositional variant.
- **`CompleteAndGrounded`** — combines answer completeness (vs. ground truth) and groundedness (vs. retrieved context) into a single F1 score.

See [evaluate_auto_metrics.md](evaluate_auto_metrics.md) for full details.

## How the Pieces Fit Together

```mermaid
sequenceDiagram
    participant User
    participant Evaluate
    participant ParallelExecutor
    participant Program as dspy.Module
    participant Metric as metric (e.g. SemanticF1)

    User->>Evaluate: __call__(program, metric, devset)
    Evaluate->>ParallelExecutor: execute(process_item, devset)
    loop for each example (parallel)
        ParallelExecutor->>Program: program(**example.inputs())
        Program-->>ParallelExecutor: prediction
        ParallelExecutor->>Metric: metric(example, prediction)
        Metric-->>ParallelExecutor: score
    end
    ParallelExecutor-->>Evaluate: results
    Evaluate->>Evaluate: aggregate score, build table
    Evaluate-->>User: EvaluationResult(score, results)
```

## Relationship to Other Modules

- **`predict`** — the automatic metrics rely on [`ChainOfThought`](predict.md) to perform step-by-step reasoning before producing a score.
- **`primitives`** — `EvaluationResult` extends [`Prediction`](primitives.md), and the program under test is a [`Module`](primitives.md).
- **`utils`** — parallel execution is delegated to [`ParallelExecutor`](utils.md), and `Evaluate.__call__` is instrumented with the [`with_callbacks`](utils.md) decorator for observability.
- **`signatures`** — the automatic metrics are defined as DSPy [`Signature`](signatures.md) classes.

## Quick Reference

| Component | File | Purpose |
|-----------|------|---------|
| `Evaluate` | `evaluate.py` | Runs a program over a dataset and computes aggregate metrics |
| `EvaluationResult` | `evaluate.py` | Container for the aggregate score and per-example results |
| `SemanticF1` | `auto_evaluation.py` | LLM-judged semantic F1 metric |
| `CompleteAndGrounded` | `auto_evaluation.py` | Combined completeness + groundedness metric |
| `SemanticRecallPrecision` | `auto_evaluation.py` | Signature for recall/precision judging |
| `DecompositionalSemanticRecallPrecision` | `auto_evaluation.py` | Decompositional variant of the above |
| `AnswerCompleteness` | `auto_evaluation.py` | Signature for completeness judging |
| `AnswerGroundedness` | `auto_evaluation.py` | Signature for groundedness judging |
