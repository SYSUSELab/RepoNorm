# Adapter Types: Media (`adapter_types_media`)

## Introduction

The `adapter_types_media` module provides DSPy's built-in **multimodal custom types** — `Image` and `Audio` — that allow signatures to accept and emit rich media content alongside plain text. These types extend the base [`Type`](adapter_types_base_type.md) class and implement the `format()` contract so that DSPy adapters (e.g. [`ChatAdapter`](adapters_core.md), [`JSONAdapter`](adapters_core.md)) can serialize media into the content-part arrays expected by modern LLM APIs (OpenAI-style `image_url` / `input_audio` parts).

The module solves three core problems:

1. **Uniform representation** — Media is normalized into a single canonical form (a URL or a base64 data URI) regardless of whether the source is a local file, a remote URL, a PIL image, a NumPy array, or raw bytes.
2. **Adapter interoperability** — By implementing `format()`, media types plug directly into the adapter serialization pipeline without adapter-specific special-casing.
3. **Ergonomic construction** — Convenience constructors (`from_url`, `from_file`, `from_PIL`, `from_array`) and a Pydantic `model_validator` allow users to pass plain strings, dicts, or native objects.

---

## Module Structure

The module consists of two files, each defining one media type plus its supporting encoding helpers:

| File | Core Component | Purpose |
|------|----------------|---------|
| `dspy/adapters/types/image.py` | `Image` | Image media type + image encoding helpers |
| `dspy/adapters/types/audio.py` | `Audio` | Audio media type + audio encoding helpers |

Both types inherit from [`Type`](adapter_types_base_type.md), the shared base class for all DSPy custom types.

---

## Architecture

```mermaid
graph TD
    subgraph "adapter_types_media"
        Image["Image<br/>(url: str)"]
        Audio["Audio<br/>(data: str, audio_format: str)"]
        ImgHelpers["encode_image()<br/>_encode_image_from_file()<br/>_encode_image_from_url()<br/>_encode_pil_image()<br/>is_url() / is_image()"]
        AudHelpers["encode_audio()"]
    end

    subgraph "adapter_types_base_type"
        Type["Type<br/>(pydantic.BaseModel)"]
    end

    subgraph "External Libraries"
        Pydantic["pydantic"]
        PIL["Pillow (PIL)"]
        SoundFile["soundfile"]
        Requests["requests"]
    end

    subgraph "Consumers"
        ChatAdapter["ChatAdapter"]
        JSONAdapter["JSONAdapter"]
        Signature["Signature fields"]
    end

    Image -->|inherits| Type
    Audio -->|inherits| Type
    Image --> ImgHelpers
    Audio --> AudHelpers

    Image -.->|optional| PIL
    Audio -.->|optional| SoundFile
    ImgHelpers --> Requests
    AudHelpers --> Requests
    Image --> Pydantic
    Audio --> Pydantic

    Signature -->|annotates fields with| Image
    Signature -->|annotates fields with| Audio
    ChatAdapter -->|calls format()| Image
    ChatAdapter -->|calls format()| Audio
    JSONAdapter -->|calls format()| Image
    JSONAdapter -->|calls format()| Audio
```

---

## Component Relationships

```mermaid
classDiagram
    class Type {
        <<abstract>>
        +format() list~dict~ | str
        +description() str
        +extract_custom_type_from_annotation(annotation)
        +serialize_model()
    }

    class Image {
        +str url
        +format() list~dict~
        +validate_input(values)
        +from_url(url, download) Image
        +from_file(file_path) Image
        +from_PIL(pil_image) Image
        +__str__() str
        +__repr__() str
    }

    class Audio {
        +str data
        +str audio_format
        +format() list~dict~
        +validate_input(values) Audio
        +from_url(url) Audio
        +from_file(file_path) Audio
        +from_array(array, sampling_rate, format) Audio
        +__str__() str
        +__repr__() str
    }

    Type <|-- Image
    Type <|-- Audio
```

---

## The `Image` Type

`Image` represents an image as a single `url` field, which may hold either a remote URL or a base64 data URI.

### Configuration

```python
model_config = {
    "frozen": True,               # immutable instances
    "str_strip_whitespace": True, # trim whitespace on strings
    "validate_assignment": True,  # re-validate on attribute assignment
    "extra": "forbid",            # reject unknown fields
}
```

### Construction Paths

| Method | Input | Behavior |
|--------|-------|----------|
| `Image("https://...")` | URL string | Wrapped into `{"url": ...}` by the validator |
| `Image({"url": "..."})` | dict | Accepted directly |
| `Image.from_url(url, download=False)` | URL | Encodes to data URI if `download=True`, else keeps URL |
| `Image.from_file(file_path)` | local path | Reads file, base64-encodes to data URI |
| `Image.from_PIL(pil_image)` | PIL Image | Serializes to PNG/format data URI |

### Input Validation

The `validate_input` Pydantic `model_validator(mode="before")` normalizes inputs:

```mermaid
flowchart TD
    A[Input value] --> B{Is it a str?}
    B -->|Yes| C["Wrap as {'url': value}"]
    B -->|No| D{Is it a dict with only 'url'?}
    D -->|Yes| E[Accept as-is]
    D -->|No| F{Is it an Image instance?}
    F -->|Yes| G[model_dump]
    F -->|No| H[Raise TypeError]
```

### Formatting Output

`Image.format()` returns an OpenAI-compatible content part:

```python
[{"type": "image_url", "image_url": {"url": image_url}}]
```

If encoding fails, a `ValueError` is raised with a descriptive message.

### Encoding Helpers

The module exposes a set of module-level helpers used by `Image` and available to callers:

- **`encode_image(image, download_images=False)`** — The central dispatcher. Accepts a dict, string (data URI / file path / URL), PIL Image, raw bytes, or `Image` instance and returns a data URI (or the URL unchanged when `download_images=False`).
- **`_encode_image_from_file(file_path)`** — Reads a file and produces a `data:<mime>;base64,...` URI using `mimetypes`.
- **`_encode_image_from_url(image_url)`** — Downloads via `requests` and encodes using the response `Content-Type`.
- **`_encode_pil_image(image)`** — Serializes a PIL image to bytes and encodes it.
- **`is_url(string)`** — Validates `http`, `https`, or `gs` schemes.
- **`is_image(obj)`** — Detects whether an object is a PIL image, data URI, file path, or URL.

> **Note:** Pillow (`PIL`) is an optional dependency. When unavailable, `PIL_AVAILABLE` is `False` and PIL-based paths raise or are skipped.

---

## The `Audio` Type

`Audio` represents audio as base64-encoded `data` plus an `audio_format` string (e.g. `"wav"`, `"mp3"`).

### Configuration

```python
model_config = {
    "frozen": True,   # immutable instances
    "extra": "forbid",# reject unknown fields
}
```

### Construction Paths

| Method | Input | Behavior |
|--------|-------|----------|
| `Audio(data=..., audio_format=...)` | base64 + format | Direct construction |
| `Audio.from_url(url)` | URL | Downloads, validates `audio/*` MIME, base64-encodes |
| `Audio.from_file(file_path)` | local path | Reads file, validates MIME, base64-encodes |
| `Audio.from_array(array, sampling_rate, format="wav")` | NumPy-like array | Writes via `soundfile` (PCM_16), base64-encodes |

### Input Validation

The `validate_input` validator delegates to `encode_audio()` for non-`Audio` inputs, allowing users to pass strings, dicts, arrays, or bytes directly.

### Formatting Output

`Audio.format()` returns an OpenAI-compatible content part:

```python
[{
    "type": "input_audio",
    "input_audio": {"data": data, "format": self.audio_format}
}]
```

### Encoding Helper

- **`encode_audio(audio, sampling_rate=16000, format="wav")`** — Central dispatcher returning `{"data": ..., "audio_format": ...}`. Handles dicts, `Audio` instances, data URIs, file paths, HTTP URLs, array-like objects (via `soundfile`), and raw bytes.

> **Note:** `soundfile` is an optional dependency. When unavailable, `SF_AVAILABLE` is `False` and array-based encoding raises `ImportError`.

---

## Data Flow: From User Input to LLM Message

The following sequence diagram shows how a media value flows from a signature input through an adapter to the final LLM message.

```mermaid
sequenceDiagram
    participant User
    participant Signature as Signature Field
    participant Adapter as ChatAdapter / JSONAdapter
    participant Media as Image / Audio
    participant Encoder as encode_image / encode_audio
    participant LLM as LLM API

    User->>Signature: Provide value (URL, path, PIL, array, bytes)
    Signature->>Media: Pydantic validation (validate_input)
    Media->>Encoder: Normalize to canonical form
    Encoder-->>Media: data URI / URL / base64 dict
    Adapter->>Media: format()
    Media-->>Adapter: content-part list
    Adapter->>LLM: Serialized message with media parts
```

---

## Integration with Adapters

Media types integrate with the adapter layer through the base `Type.format()` contract. Adapters such as [`ChatAdapter`](adapters_core.md) and [`JSONAdapter`](adapters_core.md) call `format_field_value()` on field values, which invokes `format()` on any custom `Type` instance.

```mermaid
graph LR
    A[Signature input field] --> B[format_field_value]
    B --> C{Is value a Type?}
    C -->|Yes| D[value.format()]
    C -->|No| E[Standard serialization]
    D --> F[Content-part list]
    F --> G[Adapter message assembly]
    E --> G
    G --> H[LLM request]
```

Because both `Image` and `Audio` implement `format()` to return OpenAI-style content parts, they work transparently with any adapter that supports multimodal content. The `serialize_model()` method inherited from [`Type`](adapter_types_base_type.md) wraps the formatted output in custom-type identifiers for text-based serialization paths.

---

## Dependency Graph

```mermaid
graph TD
    Image["Image"] --> BaseType["Type (base_type.py)"]
    Audio["Audio"] --> BaseType
    Image --> Pydantic["pydantic"]
    Audio --> Pydantic
    Image --> Requests["requests"]
    Audio --> Requests
    Image -.->|optional| PIL["Pillow"]
    Audio -.->|optional| SF["soundfile"]
    Image --> StdLib["base64, io, mimetypes, os, urllib.parse"]
    Audio --> StdLib
```

### Dependency Summary

| Dependency | Required? | Used By | Purpose |
|------------|-----------|---------|---------|
| `pydantic` | Yes | Both | Model definition, validation, serialization |
| `requests` | Yes | Both | Downloading remote media |
| `Pillow` (`PIL`) | Optional | `Image` | PIL image and raw-bytes encoding |
| `soundfile` | Optional | `Audio` | NumPy-array audio encoding |
| Python stdlib | Yes | Both | `base64`, `io`, `mimetypes`, `os`, `urllib.parse` |

---

## Error Handling

Both types raise descriptive errors during construction and formatting:

- **`Image`** — `ValueError` for unsupported file strings/types or failed formatting; `TypeError` for invalid validator input.
- **`Audio`** — `ValueError` for unsupported MIME types, missing files, malformed data URIs, or unsupported types; `ImportError` when `soundfile` is required but unavailable.

These errors surface through the adapter pipeline and may trigger adapter fallbacks (e.g. `ChatAdapter` falling back to `JSONAdapter`).

---

## Related Modules

- [adapter_types_base_type.md](adapter_types_base_type.md) — The `Type` base class defining the `format()` contract.
- [adapter_types_code.md](adapter_types_code.md) — The `Code` custom type.
- [adapter_types_tool.md](adapter_types_tool.md) — The `Tool` and `ToolCalls` custom types.
- [adapter_types_history.md](adapter_types_history.md) — The `History` custom type.
- [adapters_core.md](adapters_core.md) — Adapters (`ChatAdapter`, `JSONAdapter`, etc.) that consume media types.
