# DSP Utils Settings Module

## Introduction

The `dsp_utils_settings` module provides the **global configuration system** for DSPy. It is centered around the `Settings` singleton class, which manages all runtime configuration values (such as the active language model, adapter, retrieval model, callbacks, and execution parameters) in a **thread-safe** and **async-aware** manner.

The module solves a fundamental problem in DSPy: how to share configuration across an entire program while still allowing:
- A single, globally-visible configuration set by one "owner" thread.
- Temporary, thread-local overrides via a context manager.
- Safe propagation of overrides into child threads and async tasks.

The module exposes a single module-level instance, `settings`, which is imported and used throughout the DSPy codebase.

---

## Core Components

| Component | Location | Role |
|-----------|----------|------|
| `Settings` | `dspy/dsp/utils/settings.py` | Singleton configuration manager (global + thread-local) |
| `settings` | `dspy/dsp/utils/settings.py` | Module-level singleton instance of `Settings` |
| `DEFAULT_CONFIG` | `dspy/dsp/utils/settings.py` | Default configuration values |
| `dotdict` | `dspy/dsp/utils/utils.py` | Dict subclass supporting attribute access (see [dsp_utils_utilities](dsp_utils_utilities.md)) |

---

## Architecture Overview

The `Settings` class is a **singleton** that combines two layers of configuration:

1. **Global configuration** (`main_thread_config`) — shared across all threads, set via `configure()`.
2. **Thread-local overrides** (`thread_local_overrides`) — a `contextvars.ContextVar` holding per-context overrides, set via `context()`.

```mermaid
graph TD
    subgraph "Settings Singleton"
        S[Settings instance]
        S --> G[main_thread_config<br/>global dotdict]
        S --> T[thread_local_overrides<br/>ContextVar of dotdict]
        S --> L[global_lock<br/>threading.Lock]
        S --> O[config_owner_thread_id<br/>config_owner_async_task]
    end

    D[DEFAULT_CONFIG] -->|deepcopy| G

    U1[Thread A - owner] -->|configure| G
    U2[Thread B] -->|context| T
    U3[Async Task] -->|context| T

    S -->|__getattr__| R[Resolved value:<br/>override > global]
```

### Configuration Resolution

When any attribute is read from `settings`, the resolution order is:

```mermaid
flowchart TD
    A[settings.attr] --> B{attr in<br/>thread_local_overrides?}
    B -->|Yes| C[Return override value]
    B -->|No| D{attr in<br/>main_thread_config?}
    D -->|Yes| E[Return global value]
    D -->|No| F[Raise AttributeError]
```

---

## The `Settings` Class

### Singleton Pattern

`Settings` implements the singleton pattern via `__new__`, ensuring only one instance exists:

```python
class Settings:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
```

The module-level `settings = Settings()` is the canonical access point used everywhere in DSPy.

### Attribute Access Protocol

`Settings` behaves like a dictionary with attribute access, backed by `dotdict`:

| Operation | Method | Behavior |
|-----------|--------|----------|
| `settings.lm` | `__getattr__` | Resolve override → global |
| `settings.lm = x` | `__setattr__` | Delegates to `configure(lm=x)` |
| `settings["lm"]` | `__getitem__` | Same as attribute access |
| `settings["lm"] = x` | `__setitem__` | Same as attribute assignment |
| `"lm" in settings` | `__contains__` | Checks override or global |
| `settings.get("lm", default)` | `get` | Safe access with default |
| `settings.copy()` | `copy` | Merged snapshot (global + overrides) |
| `settings.config` | `config` property | Same as `copy()` |

> **Note:** Assigning an attribute (`settings.lm = x`) is equivalent to calling `configure(lm=x)` and is therefore subject to the same ownership restrictions described below.

---

## Configuration Ownership Rules

The module enforces strict rules about **who** may call `configure()`. This prevents race conditions and inconsistent global state.

```mermaid
flowchart TD
    A[configure called] --> B{owner thread<br/>set?}
    B -->|No| C[Set owner = current thread]
    B -->|Yes| D{current == owner?}
    C --> E{In async task?}
    D -->|No| X1[RuntimeError:<br/>only owner thread can configure]
    D -->|Yes| E
    E -->|No| OK[Allow configure]
    E -->|Yes| F{owner async task set?}
    F -->|No| G[Set owner async task]
    F -->|Yes| H{In IPython?}
    H -->|Yes| OK
    H -->|No| I{current == owner async task?}
    I -->|Yes| OK
    I -->|No| X2[RuntimeError:<br/>use dspy.context instead]
```

### Rules Summary

1. **Only one thread** (the first to call `configure`) becomes the owner and may change global settings.
2. **Other threads** see the global values but cannot modify them — they must use `context()`.
3. **Async tasks**: only the first async task that calls `configure` may do so again; other tasks must use `context()`.
4. **IPython exception**: `configure()` is permitted from IPython environments even within async tasks, for interactive convenience.

---

## Thread-Local Context Overrides

The `context()` context manager provides temporary, thread-local configuration changes that do **not** affect global state.

```python
with dspy.settings.context(lm=my_lm, temperature=0.7):
    # Only this thread sees these overrides
    result = program(...)
# Overrides are reverted here
```

### How Overrides Propagate

```mermaid
sequenceDiagram
    participant Main as Main Thread
    participant Ctx as context() block
    participant Child as Child Thread (ParallelExecutor)

    Main->>Ctx: enter context(lm=X)
    Ctx->>Ctx: save original_overrides
    Ctx->>Ctx: set new_overrides (global + original + kwargs)
    Main->>Child: spawn thread
    Child->>Child: inherits overrides (copied by ParallelExecutor)
    Child-->>Main: work done
    Ctx->>Ctx: reset(token) → restore original_overrides
```

Key implementation details:

- `original_overrides` is saved before applying new ones.
- `new_overrides` merges `main_thread_config` + `original_overrides` + `kwargs`, so nested contexts compose correctly.
- A `ContextVar` token is used to reset state in the `finally` block, guaranteeing cleanup even on exceptions.
- Overrides propagate to child threads **only when** spawned via a `ParallelExecutor` that copies overrides (see [utils](utils.md) for `ParallelExecutor`).

---

## Default Configuration

`DEFAULT_CONFIG` is a `dotdict` defining all recognized settings keys and their defaults:

| Key | Default | Purpose |
|-----|---------|---------|
| `lm` | `None` | Active language model |
| `adapter` | `None` | Active adapter (see [adapters](adapters.md)) |
| `rm` | `None` | Active retrieval model |
| `branch_idx` | `0` | Branch index for parallel execution |
| `trace` | `[]` | Execution trace |
| `callbacks` | `[]` | Registered callbacks (see [utils](utils.md)) |
| `async_max_workers` | `8` | Max async workers |
| `send_stream` | `None` | Streaming sink |
| `disable_history` | `False` | Disable history tracking |
| `track_usage` | `False` | Enable usage tracking |
| `usage_tracker` | `None` | Usage tracker instance |
| `caller_predict` | `None` | Current Predict caller |
| `caller_modules` | `None` | Current module call stack |
| `stream_listeners` | `[]` | Streaming listeners (see [streaming](streaming.md)) |
| `provide_traceback` | `False` | Include tracebacks in error logs |
| `num_threads` | `8` | Threads for parallel processing |
| `max_errors` | `10` | Max errors before halting |
| `allow_tool_async_sync_conversion` | `False` | Allow async tools in sync mode |

The global `main_thread_config` is initialized as a **deep copy** of `DEFAULT_CONFIG`, so mutations to one do not affect the other.

---

## Dependencies

```mermaid
graph LR
    Settings --> dotdict
    Settings --> contextvars
    Settings --> threading
    Settings --> asyncio
    Settings --> copy

    dotdict --> utils[dsp_utils_utilities]
```

- **`dotdict`** (from [dsp_utils_utilities](dsp_utils_utilities.md)): Provides attribute-style access to configuration dictionaries. `Settings` relies on it for both `main_thread_config` and `thread_local_overrides`.
- **`contextvars`**: Enables thread-local and async-task-local override storage.
- **`threading`**: Provides the global lock and thread identity checks.
- **`asyncio`**: Used to detect and track the owning async task.

---

## Integration with the DSPy System

The `settings` singleton is a central hub consumed across the framework:

```mermaid
graph TD
    Settings[settings singleton]
    Settings --> Predict[predict module]
    Settings --> Adapters[adapters module]
    Settings --> Clients[clients module]
    Settings --> Evaluate[evaluate module]
    Settings --> Teleprompt[teleprompt module]
    Settings --> Streaming[streaming module]
    Settings --> Parallelizer[utils.ParallelExecutor]

    Parallelizer -.->|copies overrides| Settings
```

- **Predict / Modules**: Read `settings.lm`, `settings.adapter`, and `settings.caller_predict` during forward passes.
- **Adapters**: Use `settings.adapter` to format/parse LM interactions (see [adapters](adapters.md)).
- **Clients**: The active `LM` is stored in `settings.lm` (see [clients](clients.md)).
- **Streaming**: `settings.stream_listeners` and `settings.send_stream` drive streaming behavior (see [streaming](streaming.md)).
- **ParallelExecutor**: Copies thread-local overrides into spawned threads (see [utils](utils.md)).

---

## Usage Examples

### Global Configuration (Owner Thread)

```python
import dspy

lm = dspy.LM("openai/gpt-4o-mini")
dspy.configure(lm=lm)
```

### Temporary Override

```python
with dspy.settings.context(lm=cheap_lm):
    answer = program(question="...")
```

### Reading Configuration

```python
current_lm = dspy.settings.lm
all_config = dspy.settings.config  # merged snapshot
```

---

## Design Considerations

| Concern | Approach |
|---------|----------|
| **Thread safety** | Global lock + owner-thread tracking |
| **Async safety** | Owner-async-task tracking + IPython exception |
| **Isolation** | `contextvars.ContextVar` for thread/task-local overrides |
| **Composability** | Nested contexts merge overrides correctly |
| **Cleanup** | `try/finally` with `ContextVar.reset(token)` |
| **Immutability of defaults** | `deepcopy` of `DEFAULT_CONFIG` |

### Known Limitations

- Concurrent `configure()` calls from the owner thread mixed with reads from user threads are not synchronized beyond the ownership check (a TODO in the source notes future warnings).
- Overrides propagate to child threads **only** through DSPy primitives (`Parallel`, `asyncify`, `ParallelExecutor`) that explicitly copy overrides — plain `threading.Thread` will not inherit them.

---

## Related Modules

- [dsp_utils_utilities](dsp_utils_utilities.md) — `dotdict`, `dotdict_lax`, `NullContextManager`
- [adapters](adapters.md) — Adapter implementations consuming `settings.adapter`
- [clients](clients.md) — Language model clients stored in `settings.lm`
- [streaming](streaming.md) — Streaming listeners and callbacks
- [utils](utils.md) — `ParallelExecutor` and callback infrastructure
