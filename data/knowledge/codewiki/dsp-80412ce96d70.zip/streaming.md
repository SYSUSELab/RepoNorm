# Streaming

## Overview

The **streaming** module provides incremental output streaming for DSPy programs. Instead of waiting for a program to finish and returning a complete `Prediction`, the streaming module lets callers consume results *as they are produced* — token-by-token from the underlying language model, plus human-readable status messages describing what the program is currently doing.

The module is built around a single public entry point, `dspy.streamify()`, which wraps any DSPy program and returns an async (or sync) generator. The generator yields a heterogeneous stream of values:

- **`StreamResponse`** — a chunk of a specific output field of a specific predictor (e.g. the `answer` field of a `Predict`).
- **`StatusMessage`** — a progress/status string emitted at well-defined lifecycle points (LM start/end, module start/end, tool start/end).
- **`Prediction`** — the final, fully-parsed prediction, optionally included at the end of the stream.

This design decouples three concerns:

1. **What to stream** — which output fields of which predictors should be surfaced incrementally (handled by `StreamListener`).
2. **What to say about progress** — status messages describing program execution (handled by `StatusMessageProvider` / `StatusStreamingCallback`).
3. **How to wire it together** — the `streamify()` wrapper that runs the program, intercepts the LM token stream, and multiplexes everything into one generator.

## Architecture

The streaming module sits between the DSPy program execution layer and the caller. It relies on the callback system (`dspy.utils.callback.BaseCallback`) and the global settings (`dspy.dsp.utils.settings.Settings`) to observe execution, and on the adapters (`ChatAdapter`, `JSONAdapter`, `XMLAdapter`) to know how to delimit output fields in the raw LM text.

```mermaid
graph TD
    Caller["Caller (async for ...)"] --> Streamify["streamify()"]
    Streamify --> Program["DSPy Program (Module / Predict)"]
    Streamify --> Listeners["StreamListener[]"]
    Streamify --> StatusCb["StatusStreamingCallback"]

    Program -->|"runs via callbacks"| Settings["settings.send_stream"]
    Program -->|"LM token chunks"| LM["LM / ModelResponseStream"]

    LM -->|"chunks routed by predict_id"| Listeners
    Listeners -->|"StreamResponse"| Streamify

    StatusCb -->|"StatusMessage"| Settings
    Settings -->|"StatusMessage"| Streamify

    Streamify -->|"StreamResponse | StatusMessage | Prediction"| Caller
```

### Data flow

```mermaid
sequenceDiagram
    participant C as Caller
    participant S as streamify generator
    participant P as DSPy Program
    participant L as StreamListener
    participant SC as StatusStreamingCallback

    C->>S: async for value in program(...)
    S->>P: await program(*args, **kwargs)
    P->>SC: on_module_start / on_lm_start
    SC-->>S: StatusMessage (via send_stream)
    P->>L: LM token chunks (ModelResponseStream)
    L-->>S: StreamResponse (field chunks)
    P->>SC: on_lm_end / on_module_end
    SC-->>S: StatusMessage
    P-->>S: final Prediction
    S-->>C: yields StreamResponse / StatusMessage / Prediction
```

### Key integration points

| Concern | Component | Notes |
| --- | --- | --- |
| Entry point | `streamify()` | Wraps program, sets up memory object stream, multiplexes outputs. |
| Field-level capture | [`StreamListener`](streaming_listener.md) | Parses raw LM text to extract a target output field. |
| Status messages | [`StatusMessageProvider` / `StatusStreamingCallback`](streaming_messages.md) | Emits progress strings at lifecycle events. |
| Callback plumbing | `dspy.utils.callback.BaseCallback` | Base class providing `on_*_start` / `on_*_end` hooks. |
| Global config | `dspy.dsp.utils.settings.Settings` | Holds `send_stream`, `callbacks`, `stream_listeners`, `adapter`. |
| Adapters | `ChatAdapter`, `JSONAdapter`, `XMLAdapter` | Define field delimiters used by `StreamListener`. |

## Sub-modules

The streaming module is organized into two sub-modules, each documented separately:

### 1. Status Messages — [`streaming_messages.md`](streaming_messages.md)

Defines the status-message streaming subsystem:

- **`StreamResponse`** — dataclass carrying a single streamed chunk (`predict_name`, `signature_field_name`, `chunk`).
- **`StatusMessage`** — dataclass wrapping a status string.
- **`StatusMessageProvider`** — base class for customizing status messages at each lifecycle stage (tool, module, LM start/end).
- **`StatusStreamingCallback`** — a `BaseCallback` implementation that translates lifecycle events into `StatusMessage`s and pushes them onto the active stream via `sync_send_to_stream`.

See [`streaming_messages.md`](streaming_messages.md) for full details.

### 2. Stream Listener — [`streaming_listener.md`](streaming_listener.md)

Defines the field-level streaming capture subsystem:

- **`StreamListener`** — listens to the raw LM token stream and extracts the content of a single target output field, emitting `StreamResponse` objects. It is adapter-aware (Chat/JSON/XML) and handles buffering, start/end identifier detection, cache hits, and reuse.
- **`find_predictor_for_stream_listeners`** — utility that auto-resolves which predictor each listener should attach to when the predictor is not explicitly specified.

See [`streaming_listener.md`](streaming_listener.md) for full details.

## The `streamify()` Entry Point

`streamify()` is the public API of the module. Its responsibilities:

1. **Resolve listeners** — if `stream_listeners` are provided, call `find_predictor_for_stream_listeners` to map each listener to a predictor (keyed by `id(predictor)`).
2. **Normalize the program** — if `is_async_program` is `False`, wrap the program with `asyncify` so it can be awaited inside the generator.
3. **Install the status callback** — append a `StatusStreamingCallback` to the active callbacks (unless one is already present).
4. **Run and multiplex** — create an in-memory object stream, run the program in a task group, and forward values to the caller:
   - `ModelResponseStream` chunks are routed to the matching listeners (by `predict_id`); if no listeners are configured, chunks are yielded directly for backwards compatibility.
   - `StatusMessage` values are yielded as-is.
   - The final `Prediction` is yielded according to `include_final_prediction_in_output_stream` (with fallbacks for cache hits and no-capture cases).
5. **Sync/async output** — if `async_streaming=False`, the async generator is converted to a sync generator via `apply_sync_streaming`.

### Parameters

| Parameter | Type | Description |
| --- | --- | --- |
| `program` | `Module` | The DSPy program to wrap. |
| `status_message_provider` | `StatusMessageProvider \| None` | Custom status message generator. |
| `stream_listeners` | `list[StreamListener] \| None` | Listeners capturing specific output fields. |
| `include_final_prediction_in_output_stream` | `bool` | Whether to include the final `Prediction` (default `True`). |
| `is_async_program` | `bool` | Whether the program is already async. |
| `async_streaming` | `bool` | Return an async generator (`True`) or sync generator (`False`). |

### Example

```python
import asyncio
import dspy

dspy.settings.configure(lm=dspy.LM("openai/gpt-4o-mini", cache=False))

predict = dspy.Predict("question->answer, reasoning")
stream_listeners = [
    dspy.streaming.StreamListener(signature_field_name="answer"),
    dspy.streaming.StreamListener(signature_field_name="reasoning"),
]
stream_predict = dspy.streamify(predict, stream_listeners=stream_listeners)

async def use_streaming():
    output = stream_predict(question="why did a chicken cross the kitchen?")
    async for value in output:
        print(value)

asyncio.run(use_streaming())
```

## Adapter Support

Field-level streaming depends on the adapter's field delimiters. `StreamListener` supports the following adapters (see [`streaming_listener.md`](streaming_listener.md) for the exact identifiers):

| Adapter | Start identifier | End identifier |
| --- | --- | --- |
| `ChatAdapter` | `[[ ## {field} ## ]]` | next `[[ ## ... ## ]]` header |
| `JSONAdapter` | `"{field}":` | `",` or `"}` |
| `XMLAdapter` | `<{field}>` | `</{field}>` |

Using an unsupported adapter raises a `ValueError` at stream time.

## Related Modules

- **[adapters](adapters.md)** — `ChatAdapter`, `JSONAdapter`, `XMLAdapter` define the field delimiters that `StreamListener` relies on.
- **[clients](clients.md)** — `LM` / `BaseLM` produce the `ModelResponseStream` token chunks consumed by the streaming pipeline.
- **[primitives](primitives.md)** — `Module` and `Prediction` are the program and final-output types involved in streaming.
- **[utils](utils.md)** — `BaseCallback` (callback base class) and `DSPyLoggingStream` (event logging stream) are used by the streaming machinery.
