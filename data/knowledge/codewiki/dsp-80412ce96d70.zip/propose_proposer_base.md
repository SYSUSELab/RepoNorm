# Proposer Base

## Introduction

The `propose_proposer_base` module defines the **abstract foundation** for instruction proposers in DSPy. It provides the `Proposer` abstract base class (ABC), which establishes the contract that all concrete instruction-proposal strategies must fulfill.

Instruction proposers are a core part of DSPy's prompt optimization pipeline: given a program, a training set, and (optionally) few-shot demonstration candidates, a proposer generates new natural-language instructions for each predictor in the program. These candidate instructions are then evaluated and selected by optimizers such as [MIPROv2](teleprompt_mipro_optimizer_v2.md) and [COPRO](teleprompt_copro_optimizer.md).

This module is intentionally minimal — it defines the interface only. The primary concrete implementation is [GroundedProposer](propose_grounded_proposer.md), which grounds instruction generation in dataset summaries, program source code, task demos, and prompting tips.

---

## Core Component

### `Proposer` (Abstract Base Class)

`Proposer` is an `ABC` (from Python's `abc` module) that defines the interface for all instruction proposers.

```python
class Proposer(ABC):
    def __init__(self):
        pass

    @abstractmethod
    def propose_instructions_for_program(self):
        pass

    def propose_instruction_for_predictor(self):
        pass
```

#### Methods

| Method | Type | Description |
|--------|------|-------------|
| `__init__` | concrete | No-op initializer. Subclasses extend this to configure their proposal strategy (e.g., prompt model, dataset summary, program awareness). |
| `propose_instructions_for_program` | **abstract** | The primary contract. Must return the full set of new instructions for an entire program, given the specified criteria. Subclasses must implement this. |
| `propose_instruction_for_predictor` | concrete (overridable) | Generates a single instruction for one predictor. Provided as an overridable hook; the base implementation is a no-op. |

> **Note:** The base signatures are intentionally untyped and parameterless. Concrete subclasses (such as `GroundedProposer`) override these methods with richer signatures that accept `trainset`, `program`, `demo_candidates`, `trial_logs`, `N`, and `T` (temperature).

---

## Architecture

The `Proposer` ABC sits at the top of the instruction-proposal hierarchy. Concrete proposers inherit from it and are consumed by teleprompt optimizers.

```mermaid
classDiagram
    class Proposer {
        <<abstract>>
        +__init__()
        +propose_instructions_for_program()* 
        +propose_instruction_for_predictor()
    }

    class GroundedProposer {
        +prompt_model
        +program_aware
        +use_dataset_summary
        +use_task_demos
        +use_instruct_history
        +use_tip
        +propose_instructions_for_program(trainset, program, demo_candidates, trial_logs, N, T)
        +propose_instruction_for_predictor(...)
    }

    Proposer <|-- GroundedProposer
```

---

## Position in the Optimization Pipeline

Proposers are invoked during the **instruction proposal** stage of prompt optimization. The diagram below shows how the `Proposer` abstraction fits into the broader DSPy optimization flow, using MIPROv2 as the representative consumer.

```mermaid
flowchart TD
    A[Teleprompter.compile] --> B[Bootstrap few-shot examples]
    B --> C[Propose instruction candidates]
    C --> D[Proposer.propose_instructions_for_program]
    D --> E[GroundedProposer]
    E --> F[GenerateModuleInstruction]
    F --> G[Candidate instructions per predictor]
    G --> H[Optimize prompt parameters]
    H --> I[Best program]

    subgraph Proposer Abstraction
        D
        E
    end
```

The `Proposer` ABC defines the `propose_instructions_for_program` entry point that optimizers call. The concrete `GroundedProposer` implements it by delegating to signature-based generators (e.g., `GenerateModuleInstruction`) and grounding context such as dataset summaries and program source code.

---

## Dependencies

The base module itself has **no internal DSPy dependencies** — it only imports `ABC` and `abstractmethod` from the Python standard library. This makes it a lightweight, stable interface that other modules can depend on without pulling in heavy transitive dependencies.

```mermaid
flowchart LR
    subgraph propose_proposer_base
        P[Proposer ABC]
    end

    subgraph propose_grounded_proposer
        GP[GroundedProposer]
    end

    subgraph teleprompt
        MIPRO[MIPROv2]
        COPRO[COPRO]
    end

    GP -- inherits --> P
    MIPRO -- uses --> GP
    COPRO -- uses --> GP
```

### Related Modules

| Module | Relationship |
|--------|--------------|
| [propose_grounded_proposer](propose_grounded_proposer.md) | Primary concrete subclass (`GroundedProposer`) implementing the abstract contract. |
| [propose_dataset_summary](propose_dataset_summary.md) | Provides dataset summaries used by grounded proposers to inform instruction generation. |
| [teleprompt_mipro_optimizer_v2](teleprompt_mipro_optimizer_v2.md) | Optimizer that instantiates and drives a `GroundedProposer` during its instruction-proposal step. |
| [teleprompt_copro_optimizer](teleprompt_copro_optimizer.md) | Optimizer that generates instruction candidates via signature-based prompting (a related proposal strategy). |

---

## Extending the Proposer

To implement a custom instruction-proposal strategy, subclass `Proposer` and implement the abstract method:

```python
from dspy.propose.propose_base import Proposer

class MyProposer(Proposer):
    def __init__(self, prompt_model, **kwargs):
        super().__init__()
        self.prompt_model = prompt_model

    def propose_instructions_for_program(
        self, trainset, program, demo_candidates, trial_logs, N, T
    ) -> dict[int, list[str]]:
        # Return a mapping of predictor index -> list of candidate instructions
        ...
```

### Implementation Guidelines

1. **Return shape:** `propose_instructions_for_program` should return a mapping from predictor index to a list of candidate instruction strings (as done by `GroundedProposer`).
2. **Call `super().__init__()`:** Always invoke the base initializer to preserve the ABC contract.
3. **Leverage grounding context:** Concrete proposers typically accept a `prompt_model`, the `program`, and the `trainset` to ground generation.
4. **Respect temperature (`T`):** Optimizers pass a temperature parameter to control proposal diversity.

---

## Summary

The `propose_proposer_base` module provides the minimal, dependency-free `Proposer` abstract base class that defines the interface for all instruction-proposal strategies in DSPy. By separating the interface from implementations, it enables optimizers to remain agnostic to the specific proposal technique while allowing new strategies (such as `GroundedProposer`) to be plugged in seamlessly.
