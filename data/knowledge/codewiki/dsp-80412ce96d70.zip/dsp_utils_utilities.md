# DSP Utils Utilities

## Introduction

The `dsp_utils_utilities` module (`dspy/dsp/utils/utils.py`) provides a collection of low-level, general-purpose helper utilities used throughout the DSPy codebase. These utilities fall into three broad categories:

1. **Attribute-accessible dictionaries** — `dotdict` and `dotdict_lax`, which allow dictionary keys to be accessed as object attributes.
2. **Context management** — `NullContextManager`, a no-op context manager used as a placeholder when a context manager is expected but no behavior is needed.
3. **General-purpose helpers** — a wide range of functions for batching, grouping, zipping, deduplication, directory creation, and progress reporting.

These utilities are foundational and are consumed by higher-level modules such as retrieval ([dsp_retrieval](dsp_retrieval.md)), settings ([dsp_utils_settings](dsp_utils_settings.md)), and various clients and adapters. Because they are dependency-free (relying only on the Python standard library and `tqdm`), they can be safely imported anywhere in the codebase.

---

## Module Architecture

The module is a flat collection of independent utilities with no internal coupling between them. The diagram below shows the three logical groupings and their primary consumers.

```mermaid
graph TD
    subgraph "dsp_utils_utilities (dspy/dsp/utils/utils.py)"
        DD[dotdict]
        DDL[dotdict_lax]
        NCM[NullContextManager]
        HELPERS[General Helpers<br/>batch, grouper, zipstar,<br/>deduplicate, flatten, etc.]
    end

    DD --> COLBERT[dsp_retrieval<br/>ColBERTv2]
    DD --> SETTINGS[dsp_utils_settings<br/>Settings]
    DDL --> CONSUMERS[Various DSPy modules]
    NCM --> CONSUMERS
    HELPERS --> CONSUMERS

    style DD fill:#cde4ff
    style DDL fill:#cde4ff
    style NCM fill:#cde4ff
    style HELPERS fill:#e4ffcd
```

---

## Core Components

### `dotdict`

`dotdict` is a subclass of the built-in `dict` that enables attribute-style access to dictionary keys. It is the strict variant: accessing a missing key raises an `AttributeError` (rather than returning `None`).

**Key behaviors:**

| Operation | Behavior |
|-----------|----------|
| `obj.key` | Returns `obj["key"]`; raises `AttributeError` if missing |
| `obj.key = value` | Sets `obj["key"] = value` |
| `del obj.key` | Deletes `obj["key"]` |
| Dunder attributes (`__x__`) | Delegated to the base `dict`/`object` implementation |

**Special handling of dunder names:** Any key that starts and ends with `__` (e.g., `__class__`, `__deepcopy__`) is routed to the standard attribute machinery via `super()`. This prevents collisions between Python's internal attribute protocol and user-defined dictionary keys.

**Deep copy support:** A custom `__deepcopy__` is implemented to avoid infinite recursion. It deep-copies the underlying `dict` and wraps the result back into a `dotdict`:

```python
def __deepcopy__(self, memo):
    # Use the default dict copying method to avoid infinite recursion.
    return dotdict(copy.deepcopy(dict(self), memo))
```

This is important because the default `dict` deep-copy behavior combined with `__getattr__`/`__setattr__` overrides can otherwise recurse indefinitely.

**Usage example:**

```python
from dspy.dsp.utils.utils import dotdict

d = dotdict({"name": "Alice", "age": 30})
print(d.name)        # "Alice"
d.city = "Paris"     # sets d["city"]
print(d["city"])     # "Paris"
```

A notable consumer is `ColBERTv2` in [dsp_retrieval](dsp_retrieval.md), which wraps each retrieved passage in a `dotdict` so callers can access fields like `psg.long_text` directly.

---

### `dotdict_lax`

`dotdict_lax` is the permissive counterpart to `dotdict`. It is implemented by simply aliasing the `dict` methods to the attribute protocol:

```python
class dotdict_lax(dict):
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__
```

**Key difference from `dotdict`:** Accessing a missing key returns `None` (the default of `dict.get`) instead of raising an `AttributeError`. This makes it convenient for optional configuration values where a missing key should be treated as absent rather than an error.

| Aspect | `dotdict` | `dotdict_lax` |
|--------|-----------|---------------|
| Missing key access | Raises `AttributeError` | Returns `None` |
| Dunder handling | Explicitly delegated to `super()` | Not special-cased |
| Deep copy | Custom `__deepcopy__` | Inherited from `dict` |
| Use case | Strict, validated access | Lenient, optional access |

---

### `NullContextManager`

`NullContextManager` is a no-op context manager. It is used as a placeholder wherever a context manager is required by an API but no actual resource management or state change is needed.

```python
class NullContextManager:
    def __init__(self, dummy_resource=None):
        self.dummy_resource = dummy_resource

    def __enter__(self):
        return self.dummy_resource

    def __exit__(self, *args):
        pass
```

**Behavior:**
- `__enter__` returns the optional `dummy_resource` passed at construction (or `None`).
- `__exit__` does nothing and never suppresses exceptions.

This is functionally similar to Python's standard `contextlib.nullcontext`, but predates or complements it within the DSPy codebase. It is useful for conditionally swapping in a real context manager versus a no-op without branching the surrounding code.

**Usage example:**

```python
from dspy.dsp.utils.utils import NullContextManager

# Use a real context manager or a no-op depending on a flag
ctx = some_context() if use_real else NullContextManager()
with ctx:
    do_work()
```

---

## General-Purpose Helpers

Beyond the three core components, the module provides a suite of standalone helper functions. These are summarized below for completeness.

### Batching and Grouping

| Function | Purpose |
|----------|---------|
| `batch(group, bsize, provide_offset=False)` | Yields successive slices of `group` of size `bsize`; optionally yields `(offset, batch)` tuples. |
| `grouper(iterable, n, fillvalue=None)` | Collects data into fixed-length chunks, padding the final chunk with `fillvalue`. |
| `groupby_first_item(lst)` | Groups a list of tuples by their first element into a `defaultdict(list)`. |
| `process_grouped_by_first_item(lst)` | Generator that yields `(group_key, items)` for input already grouped by first item. |
| `lengths2offsets(lengths)` | Yields `(start, end)` offset pairs from a sequence of lengths. |

### Zipping and Flattening

| Function | Purpose |
|----------|---------|
| `flatten(data_list)` | Concatenates a list of lists into a single flat list. |
| `zipstar(data_list, lazy=False)` | Faster equivalent of `A, B, C = zip(*data_list)`; returns lists/tuples or a lazy iterator. |
| `zip_first(list1, list2)` | Zips two sequences and asserts the resulting length matches `list1`. |

### Sequence and I/O Utilities

| Function | Purpose |
|----------|---------|
| `deduplicate(seq)` | Removes duplicates from a list while preserving order. |
| `create_directory(path)` | Creates a directory, printing a message if it already exists. |
| `file_tqdm(file)` | Iterates over a file line-by-line while displaying a `tqdm` progress bar based on file size. |
| `print_message(*s, condition=True, pad=False, sep=None)` | Prints a timestamped message; returns the formatted string. |
| `timestamp(daydir=False)` | Returns a formatted timestamp string, optionally using `/` separators for day directories. |
| `int_or_float(val)` | Converts a string to `float` if it contains a `.`, otherwise to `int`. |
| `load_batch_backgrounds(args, qids)` | Loads and joins background passages for a batch of query IDs. |

---

## Data Flow

The following diagram illustrates how the core components are typically used in a data-processing pipeline, using `dotdict` as the representative example.

```mermaid
sequenceDiagram
    participant Caller
    participant Helper as Helper Function
    participant DD as dotdict
    participant Consumer

    Caller->>Helper: batch(items, bsize)
    Helper-->>Caller: yields batches
    Caller->>DD: dotdict({"field": value})
    DD-->>Caller: attribute-accessible dict
    Caller->>Consumer: pass dotdict
    Consumer->>DD: obj.field
    DD-->>Consumer: value (or AttributeError)
```

---

## Component Interaction

The core components are largely independent, but they share a common role as building blocks for other DSPy modules. The interaction diagram below shows how they relate to one another and to external consumers.

```mermaid
graph LR
    subgraph "Core Components"
        DD[dotdict]
        DDL[dotdict_lax]
        NCM[NullContextManager]
    end

    subgraph "External Consumers"
        COLBERT[ColBERTv2<br/>dsp_retrieval]
        SETTINGS[Settings<br/>dsp_utils_settings]
        CLIENTS[clients]
        ADAPTERS[adapters]
    end

    DD -->|wraps passages| COLBERT
    DD -->|config copy| SETTINGS
    DDL -->|lenient config| CLIENTS
    NCM -->|no-op context| ADAPTERS
```

---

## Design Notes and Best Practices

- **Prefer `dotdict` for strict access.** When a missing key indicates a programming error, use `dotdict` so that failures surface as `AttributeError` rather than silently returning `None`.
- **Use `dotdict_lax` for optional configuration.** When keys are genuinely optional, `dotdict_lax` avoids verbose `get()` calls.
- **Beware of dunder keys.** `dotdict` special-cases dunder names, so keys like `__init__` will not be accessible via attribute syntax. Use item access (`obj["__init__"]`) for such keys.
- **`NullContextManager` vs. `contextlib.nullcontext`.** Both are functionally equivalent; `NullContextManager` is retained for internal consistency and to support the optional `dummy_resource` return value.
- **No external dependencies.** The module depends only on the standard library and `tqdm`, making it safe to import from any layer of the codebase without introducing circular dependencies.

---

## Related Modules

- [dsp_utils_settings](dsp_utils_settings.md) — Uses `dotdict` for configuration snapshots and thread-local overrides.
- [dsp_retrieval](dsp_retrieval.md) — `ColBERTv2` wraps retrieved passages in `dotdict` for attribute access.
- [dsp_retrieval_dpr](dsp_retrieval_dpr.md) — Tokenization utilities that complement the general helpers here.
- [clients](clients.md) — Client configuration frequently relies on attribute-accessible dictionaries.
