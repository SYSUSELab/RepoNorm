# Utils Exceptions Module

## Introduction

The `utils_exceptions` module provides the exception types used across DSPy's adapter layer. Its primary (and currently only) component is `AdapterParseError`, a specialized exception raised when an adapter fails to parse a Language Model (LM) response into the structured output fields defined by a DSPy `Signature`.

This module sits at the boundary between the **adapters** subsystem (which formats prompts and parses LM responses) and the **signatures** subsystem (which defines the expected input/output structure). When an adapter cannot reconcile the raw LM text with the expected output fields, it raises `AdapterParseError` to surface a rich, diagnostic error message to the caller.

---

## Core Component: `AdapterParseError`

`AdapterParseError` is a subclass of Python's built-in `Exception`. It is designed to carry enough context to debug parsing failures without requiring the developer to re-run the LM call.

### Definition

```python
class AdapterParseError(Exception):
    """Exception raised when adapter cannot parse the LM response."""

    def __init__(
        self,
        adapter_name: str,
        signature: Signature,
        lm_response: str,
        message: str | None = None,
        parsed_result: str | None = None,
    ):
        ...
```

### Constructor Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `adapter_name` | `str` | Yes | The name of the adapter that failed (e.g., `"ChatAdapter"`, `"JSONAdapter"`). |
| `signature` | `Signature` | Yes | The DSPy signature whose output fields were expected in the LM response. |
| `lm_response` | `str` | Yes | The raw, unparsed text returned by the language model. |
| `message` | `str \| None` | No | An optional custom message prepended to the generated error text (useful for field-specific failures). |
| `parsed_result` | `str \| None` | No | The fields that *were* successfully parsed, if any. Used to highlight the mismatch between expected and actual output. |

### Instance Attributes

After construction, the following attributes are available on the exception instance:

- `adapter_name` — the failing adapter's name.
- `signature` — the expected `Signature`.
- `lm_response` — the raw LM output.
- `parsed_result` — the partially parsed result (or `None`).

### Generated Error Message

The constructor builds a human-readable diagnostic message that includes:

1. The optional custom `message` (if provided).
2. The adapter name that failed.
3. The raw LM response.
4. The list of **expected** output fields (derived from `signature.output_fields.keys()`).
5. The list of **actually parsed** output fields (only if `parsed_result` is provided).

Example message format:

```
Adapter ChatAdapter failed to parse the LM response.

LM Response: <raw text>

Expected to find output fields in the LM response: [answer, reasoning]

Actual output fields parsed from the LM response: [answer]
```

---

## Architecture & Relationships

`AdapterParseError` is raised by concrete adapters during their `parse()` step and depends on the `Signature` abstraction to know which output fields are expected.

```mermaid
graph TD
    subgraph Signatures
        SIG[Signature]
    end

    subgraph Adapters
        BASE[Adapter]
        CHAT[ChatAdapter]
        JSON[JSONAdapter]
        XML[XMLAdapter]
        TWO[TwoStepAdapter]
    end

    subgraph Utils
        APE[AdapterParseError]
    end

    CHAT -->|raises| APE
    JSON -->|raises| APE
    XML -->|raises| APE
    TWO -->|raises| APE
    BASE -.->|parse contract| APE
    APE -->|reads output_fields| SIG
```

### Key Relationships

- **`Signature`** ([signatures_signature.md](signatures_signature.md)): `AdapterParseError` reads `signature.output_fields` to enumerate the expected fields in its error message. It is the source of truth for what a valid parse should contain.
- **`Adapter`** ([adapters_core.md](adapters_core.md)): The base class defines the `parse()` contract. Any adapter implementation may raise `AdapterParseError` when parsing fails.
- **`ChatAdapter`** ([adapters_core.md](adapters_core.md)): A concrete example that raises `AdapterParseError` in two scenarios — when a field value fails type parsing, and when the set of parsed fields does not match the expected output fields.

---

## Data Flow

The following sequence diagram illustrates how `AdapterParseError` is produced during an adapter's parse phase.

```mermaid
sequenceDiagram
    participant Caller
    participant Adapter as ChatAdapter
    participant LM as Language Model
    participant Sig as Signature
    participant Err as AdapterParseError

    Caller->>Adapter: __call__(lm, signature, ...)
    Adapter->>LM: send formatted messages
    LM-->>Adapter: raw text response
    Adapter->>Adapter: parse(signature, completion)
    Adapter->>Sig: read output_fields
    alt parsing succeeds
        Adapter-->>Caller: dict of output fields
    else field value fails to parse
        Adapter->>Err: AdapterParseError(adapter_name, signature, lm_response, message)
        Err-->>Caller: raise
    else parsed fields mismatch expected
        Adapter->>Err: AdapterParseError(adapter_name, signature, lm_response, parsed_result)
        Err-->>Caller: raise
    end
```

---

## Usage Patterns

### Raising the Exception

Adapters raise `AdapterParseError` in two common situations:

**1. A specific field failed to parse** — pass a custom `message` describing the failure:

```python
raise AdapterParseError(
    adapter_name="ChatAdapter",
    signature=signature,
    lm_response=completion,
    message=f"Failed to parse field {k} with value {v} from the LM response. Error message: {e}",
)
```

**2. The parsed fields do not match the expected output fields** — pass the `parsed_result` to highlight the mismatch:

```python
if fields.keys() != signature.output_fields.keys():
    raise AdapterParseError(
        adapter_name="ChatAdapter",
        signature=signature,
        lm_response=completion,
        parsed_result=fields,
    )
```

### Catching the Exception

Callers (e.g., higher-level adapters or retry logic) can catch `AdapterParseError` to implement fallback behavior. For example, `ChatAdapter` falls back to `JSONAdapter` when parsing fails, unless the error is a context-window issue.

```python
try:
    return super().__call__(lm, lm_kwargs, signature, demos, inputs)
except Exception as e:
    # fallback to JSONAdapter
    ...
```

---

## Process Flow: Error Construction

```mermaid
flowchart TD
    A[Adapter.parse fails] --> B[Instantiate AdapterParseError]
    B --> C[Store adapter_name, signature, lm_response, parsed_result]
    C --> D{message provided?}
    D -->|Yes| E[Prepend message + newline]
    D -->|No| F[Skip custom message]
    E --> G[Append adapter name + LM response]
    F --> G
    G --> H[Append expected output fields from signature]
    H --> I{parsed_result provided?}
    I -->|Yes| J[Append actual parsed fields]
    I -->|No| K[Skip parsed fields]
    J --> L[Call super().__init__ with final message]
    K --> L
```

---

## Integration Points

| Component | Relationship |
|-----------|--------------|
| [signatures_signature.md](signatures_signature.md) | Provides `Signature.output_fields` used to build the expected-fields list. |
| [adapters_core.md](adapters_core.md) | `Adapter` base class and concrete adapters (`ChatAdapter`, `JSONAdapter`, `XMLAdapter`, `TwoStepAdapter`) raise this exception during parsing. |
| [predict_core.md](predict_core.md) | `Predict` modules invoke adapters and may propagate `AdapterParseError` to user code. |

---

## Summary

The `utils_exceptions` module provides a single, focused exception type — `AdapterParseError` — that standardizes how parsing failures are reported across all DSPy adapters. By capturing the adapter name, the expected signature, the raw LM response, and any partial parse results, it delivers actionable diagnostics that make debugging malformed LM outputs significantly easier. Its tight coupling with the `Signature` abstraction ensures error messages always reflect the exact output fields the adapter was expecting.
