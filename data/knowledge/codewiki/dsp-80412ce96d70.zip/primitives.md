# Primitives

## Overview

The `primitives` module provides the foundational data structures and base classes that underpin the entire DSPy framework. These primitives define how DSPy programs are structured, how data flows through them, how they are serialized, and how untrusted code can be executed safely.

At its core, the module answers four fundamental questions:

1. **How is a DSPy program structured?** — via `Module` and `BaseModule`, which provide the composable, hierarchical building blocks for all DSPy programs.
2. **How is data represented?** — via `Example` and `Prediction`, which are flexible, dict-like containers for inputs, labels, and model outputs.
3. **How are programs persisted?** — via the save/load machinery on `BaseModule`, supporting both state-only and full-program serialization.
4. **How is generated code executed safely?** — via `PythonInterpreter`, a sandboxed Python runtime backed by Deno and Pyodide.

These primitives are consumed by virtually every other module in DSPy. For example, the [predict](predict.md) module builds `Predict` on top of `Parameter` and `Module`; the [evaluate](evaluate.md) module operates on `Example` objects; and the [predict](predict.md) module's `ProgramOfThought` relies on `PythonInterpreter`.

## Architecture

The primitives module is organized around a small set of tightly related classes. `Module` extends `BaseModule`, `Prediction` extends `Example`, and `PythonInterpreter` stands alone as a sandboxing utility.

```mermaid
graph TD
    subgraph "Program Structure"
        BaseModule["BaseModule<br/>(base_module.py)"]
        Module["Module<br/>(module.py)"]
        ProgramMeta["ProgramMeta<br/>(metaclass)"]
        Module -->|extends| BaseModule
        ProgramMeta -.->|metaclass of| Module
    end

    subgraph "Data Containers"
        Example["Example<br/>(example.py)"]
        Prediction["Prediction<br/>(prediction.py)"]
        Completions["Completions<br/>(prediction.py)"]
        Prediction -->|extends| Example
        Prediction -->|holds| Completions
    end

    subgraph "Execution"
        PythonInterpreter["PythonInterpreter<br/>(python_interpreter.py)"]
        InterpreterError["InterpreterError"]
        PythonInterpreter -->|raises| InterpreterError
    end

    Module -->|produces| Prediction
    Module -->|consumes| Example
    Module -->|uses| PythonInterpreter
```

### Component Relationships

```mermaid
graph LR
    subgraph "External Dependencies"
        Settings["dspy.dsp.utils.settings.Settings"]
        Parameter["dspy.predict.parameter.Parameter"]
        Callbacks["dspy.utils.callback.with_callbacks"]
        UsageTracker["dspy.utils.usage_tracker.track_usage"]
        Parallel["dspy.predict.parallel.Parallel"]
    end

    Module --> Settings
    Module --> Callbacks
    Module --> UsageTracker
    Module --> Parallel
    BaseModule --> Parameter
    Prediction --> Example
```

## Sub-modules

The primitives module is composed of the following sub-modules, each documented in detail:

| Sub-module | Description | Documentation |
| --- | --- | --- |
| **Module System** | The `BaseModule` and `Module` classes that form the composable backbone of DSPy programs, including parameter discovery, state management, and serialization. | [primitives_module_system.md](primitives_module_system.md) |
| **Data Containers** | The `Example`, `Prediction`, and `Completions` classes that represent inputs, labels, and model outputs as flexible dict-like objects. | [primitives_data_containers.md](primitives_data_containers.md) |
| **Python Interpreter** | The `PythonInterpreter` sandboxed execution environment and its `InterpreterError` exception. | [primitives_python_interpreter.md](primitives_python_interpreter.md) |

## High-Level Functionality

### Module System

The module system is the structural foundation of DSPy. `BaseModule` provides the low-level machinery for discovering nested parameters and sub-modules (via `named_parameters` and `named_sub_modules`), deep-copying, resetting, and persisting programs. `Module` builds on this to provide the user-facing program abstraction: it wraps `forward`/`aforward` with callback and usage-tracking support, exposes `predictors()` and `set_lm()`, and offers batch execution through `Parallel`.

A key design feature is the `ProgramMeta` metaclass, which guarantees that every `Module` instance is properly initialized (with `callbacks`, `history`, and `_compiled` attributes) even if a subclass forgets to call `super().__init__()`.

See [primitives_module_system.md](primitives_module_system.md) for full details.

### Data Containers

`Example` is a dict-like container that supports both attribute and item access, tracks which keys are inputs (via `with_inputs`), and separates inputs from labels. `Prediction` extends `Example` to represent model outputs, adding support for multiple `Completions`, LM usage tracking, and score-based arithmetic and comparison operations (useful for feedback-augmented evaluation).

See [primitives_data_containers.md](primitives_data_containers.md) for full details.

### Python Interpreter

`PythonInterpreter` executes arbitrary Python code in a sandboxed environment using Deno and Pyodide. It supports fine-grained permission controls (read/write paths, environment variables, network access) and file synchronization, making it suitable for safely running LLM-generated code.

See [primitives_python_interpreter.md](primitives_python_interpreter.md) for full details.

## Data Flow

The following diagram illustrates how the primitives interact during a typical DSPy program execution:

```mermaid
sequenceDiagram
    participant User
    participant Module
    participant Example
    participant Prediction
    participant Interpreter as PythonInterpreter

    User->>Module: module(**inputs)
    Module->>Module: __call__ (callbacks + usage tracking)
    Module->>Module: forward()
    Module->>Example: read inputs
    Module->>Interpreter: (optional) execute generated code
    Interpreter-->>Module: execution result
    Module->>Prediction: construct output
    Prediction-->>Module: Prediction object
    Module-->>User: Prediction
```

## Related Modules

- [predict](predict.md) — builds `Predict`, `Parameter`, and higher-level reasoning modules on top of `Module`.
- [evaluate](evaluate.md) — consumes `Example` and `Prediction` objects for program evaluation.
- [dsp_utils](dsp_utils.md) — provides `Settings`, which `Module` uses for context and configuration.
- [utils](utils.md) — provides callbacks, usage tracking, and parallel execution used by `Module`.
