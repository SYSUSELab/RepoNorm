# Grounded Proposer

## Introduction

The **Grounded Proposer** module (`dspy/propose/grounded_proposer.py`) is a core component of DSPy's instruction optimization pipeline. It is responsible for generating new, high-quality natural-language **instructions** for the predictors (modules) within a DSPy program.

Unlike naive instruction generation, the Grounded Proposer is *grounded* in multiple sources of context:

- **Program awareness** — it inspects the source code and structure of the program being optimized.
- **Data awareness** — it uses a generated summary of the training dataset.
- **Task demos** — it incorporates few-shot example inputs/outputs.
- **Instruction history** — it learns from previously attempted instructions and their scores.
- **Prompting tips** — it applies randomly selected stylistic "tips" to diversify proposals.

This module is the concrete implementation of the abstract [`Proposer`](propose_proposer_base.md) interface and is primarily consumed by the [`MIPROv2`](teleprompt_mipro_optimizer_v2.md) teleprompter during its instruction-proposal step.

---

## Architecture Overview

The module is composed of four core components that work together in a layered fashion:

| Component | Type | Responsibility |
|-----------|------|----------------|
| `GroundedProposer` | `Proposer` subclass | Orchestrates the full proposal process across all predictors and demo sets. |
| `GenerateModuleInstruction` | `dspy.Module` | Generates a single instruction for a single predictor, gathering all grounding context. |
| `DescribeProgram` | `dspy.Signature` | Describes what task the overall program solves. |
| `DescribeModule` | `dspy.Signature` | Describes the role of a specific module within the program. |

Additionally, a dynamically-constructed signature class (`GenerateSingleModuleInstruction`) is created by the `generate_instruction_class` factory function, which is the actual LM prompt used to produce the final instruction.

```mermaid
graph TD
    subgraph "Grounded Proposer Module"
        GP[GroundedProposer<br/>Proposer subclass]
        GMI[GenerateModuleInstruction<br/>dspy.Module]
        DP[DescribeProgram<br/>Signature]
        DM[DescribeModule<br/>Signature]
        GIC[generate_instruction_class<br/>factory → Predict]
    end

    subgraph "External Dependencies"
        PB[Proposer<br/>propose_base]
        DSG[create_dataset_summary<br/>dataset_summary_generator]
        UTILS[propose/utils]
        TPUTILS[teleprompt/utils]
    end

    GP -->|inherits| PB
    GP -->|creates| GMI
    GP -->|uses| DSG
    GP -->|uses| UTILS
    GP -->|uses| TPUTILS
    GMI -->|uses| DP
    GMI -->|uses| DM
    GMI -->|creates| GIC
```

---

## Component Details

### `GroundedProposer`

The top-level orchestrator. It is instantiated with a `prompt_model`, the `program` to optimize, and the `trainset`, along with a rich set of configuration flags controlling which grounding signals are enabled.

**Key responsibilities:**

1. **Initialization-time grounding setup** — On construction, it optionally:
   - Extracts the program's source code via `get_dspy_source_code` (when `program_aware=True`).
   - Generates a dataset summary via `create_dataset_summary` (when `use_dataset_summary=True`).
   - Both operations are wrapped in `try/except` blocks that gracefully degrade to non-aware mode on failure.

2. **`propose_instructions_for_program(...)`** — The main entry point. It iterates over every predictor in the program and every demo set, producing a list of candidate instructions per predictor. It returns a `dict[int, list[str]]` mapping predictor index → list of proposed instructions.

3. **`propose_instruction_for_predictor(...)`** — Produces a single instruction for one predictor. It:
   - Builds an instruction history string from `trial_logs`.
   - Instantiates a fresh `GenerateModuleInstruction` configured for the current round.
   - Temporarily perturbs the prompt model's temperature (`T + epsilon`) to encourage diversity.
   - Runs generation inside a `dspy.settings.context(lm=self.prompt_model)` block.

**Randomization controls:**

- `set_tip_randomly` — randomly selects a tip from the `TIPS` dictionary each round.
- `set_history_randomly` — randomly decides (50% chance) whether to use instruction history.

### `GenerateModuleInstruction`

A `dspy.Module` that performs the actual per-predictor instruction generation. Its `forward` method:

1. **Gathers task demos** — Collects augmented examples from the current and adjacent demo sets, up to `num_demos_in_context`.
2. **Describes the program** (if `program_aware`) — Calls `DescribeProgram` to summarize the program, then constructs a compact module signature string (e.g., `Predict(question) -> answer`) and calls `DescribeModule`.
3. **Generates the instruction** — Invokes the dynamically-built `GenerateSingleModuleInstruction` predictor with all available grounding fields.
4. **Post-processes** — Strips any leading prefix (e.g., `"PROPOSED INSTRUCTION:"`) via `strip_prefix`.

### `DescribeProgram` and `DescribeModule`

These are `dspy.Signature` definitions used as intermediate reasoning steps:

- **`DescribeProgram`** takes `program_code` and `program_example` and outputs a `program_description`.
- **`DescribeModule`** takes `program_code`, `program_example`, `program_description`, and a `module` identifier, and outputs a `module_description`.

### `generate_instruction_class(...)`

A factory function that dynamically constructs the `GenerateSingleModuleInstruction` signature based on the enabled grounding flags. Fields are conditionally included:

| Flag | Fields Added |
|------|--------------|
| `use_dataset_summary` | `dataset_description` |
| `program_aware` | `program_code`, `program_description`, `module`, `module_description` |
| `use_task_demos` | `task_demos` |
| `use_instruct_history` | `previous_instructions` |
| `use_tip` | `tip` |

Always-present fields: `basic_instruction` (input) and `proposed_instruction` (output). The function returns a `dspy.Predict` wrapping the constructed signature.

---

## Data Flow

The following diagram illustrates how grounding signals flow from their sources into the final proposed instruction.

```mermaid
flowchart TD
    subgraph Inputs
        TS[trainset]
        PROG[program]
        DC[demo_candidates]
        TL[trial_logs]
    end

    subgraph "GroundedProposer.__init__"
        TS -->|create_dataset_summary| DS[data_summary]
        PROG -->|get_dspy_source_code| PCS[program_code_string]
    end

    subgraph "propose_instruction_for_predictor"
        TL -->|create_predictor_level_history_string| IH[instruction_history]
        TIPS[TIPS dict] -->|random choice| TIP[selected_tip]
    end

    subgraph "GenerateModuleInstruction.forward"
        DC -->|gather_examples_from_sets| TD[task_demos]
        PCS --> DP[DescribeProgram]
        TD --> DP
        DP --> PD[program_description]
        PD --> DM[DescribeModule]
        PCS --> DM
        TD --> DM
        DM --> MD[module_description]
    end

    DS --> GEN[GenerateSingleModuleInstruction]
    PCS --> GEN
    PD --> GEN
    MD --> GEN
    TD --> GEN
    IH --> GEN
    TIP --> GEN
    GEN -->|strip_prefix| OUT[proposed_instruction]
```

---

## Process Flow

The end-to-end proposal process, from the perspective of a caller such as `MIPROv2`, proceeds as follows:

```mermaid
sequenceDiagram
    participant MIPRO as MIPROv2
    participant GP as GroundedProposer
    participant GMI as GenerateModuleInstruction
    participant LM as Prompt Model

    MIPRO->>GP: __init__(prompt_model, program, trainset, ...)
    GP->>LM: create_dataset_summary(trainset)
    LM-->>GP: data_summary
    GP->>GP: get_dspy_source_code(program)

    MIPRO->>GP: propose_instructions_for_program(trainset, program, demo_candidates, trial_logs, N, T)
    loop For each predictor
        loop For each demo set (up to N)
            GP->>GP: propose_instruction_for_predictor(...)
            GP->>GP: create_predictor_level_history_string(...)
            GP->>GMI: __init__(program_code_string, flags...)
            GP->>LM: set temperature = T + epsilon
            GP->>GMI: forward(demo_candidates, pred_i, ...)
            GMI->>LM: DescribeProgram(...)
            LM-->>GMI: program_description
            GMI->>LM: DescribeModule(...)
            LM-->>GMI: module_description
            GMI->>LM: GenerateSingleModuleInstruction(...)
            LM-->>GMI: proposed_instruction
            GMI-->>GP: Prediction(proposed_instruction)
            GP->>LM: restore original temperature
        end
    end
    GP-->>MIPRO: dict[pred_i, list[str]]
```

---

## Dependencies

### Internal Dependencies

| Dependency | Purpose | Documentation |
|------------|---------|---------------|
| `Proposer` | Abstract base class defining the proposer interface. | [propose_proposer_base.md](propose_proposer_base.md) |
| `create_dataset_summary` | Generates a natural-language summary of the training dataset. | [propose_dataset_summary.md](propose_dataset_summary.md) |
| `create_example_string` | Formats an example into a field-prefixed string. | `dspy/propose/utils.py` |
| `create_predictor_level_history_string` | Aggregates and ranks prior instructions by score. | `dspy/propose/utils.py` |
| `get_dspy_source_code` | Extracts source code of a program and its sub-modules. | `dspy/propose/utils.py` |
| `strip_prefix` | Removes leading field prefixes from LM output. | `dspy/propose/utils.py` |
| `get_prompt_model` / `get_signature` | Teleprompt utilities for resolving the prompt LM and reading signatures. | [teleprompt_utils.md](teleprompt_utils.md) |

### External / Framework Dependencies

| Dependency | Purpose | Documentation |
|------------|---------|---------------|
| `dspy.Signature` | Defines the input/output contracts for the helper signatures. | [signatures_signature.md](signatures_signature.md) |
| `dspy.Predict` | Executes signatures against an LM. | [predict_core.md](predict_core.md) |
| `dspy.Module` | Base class for `GenerateModuleInstruction`. | [primitives_module_system.md](primitives_module_system.md) |
| `dspy.settings` | Provides the LM context for generation. | [dsp_utils_settings.md](dsp_utils_settings.md) |

### Consumers

| Consumer | How it uses this module | Documentation |
|----------|-------------------------|---------------|
| `MIPROv2` | Instantiates `GroundedProposer` in `_propose_instructions` to generate instruction candidates. | [teleprompt_mipro_optimizer_v2.md](teleprompt_mipro_optimizer_v2.md) |

---

## Configuration Reference

### `GroundedProposer.__init__` Parameters

| Parameter | Default | Description |
|-----------|---------|-------------|
| `prompt_model` | — | The LM used to generate instructions. Falls back to `dspy.settings.lm` if `None`. |
| `program` | — | The DSPy program being optimized. |
| `trainset` | — | Training examples used for the dataset summary. |
| `view_data_batch_size` | `10` | Number of examples per batch when summarizing the dataset. |
| `use_dataset_summary` | `True` | Whether to ground proposals in a dataset summary. |
| `program_aware` | `True` | Whether to ground proposals in the program's source code. |
| `use_task_demos` | `True` | Whether to include few-shot task demos. |
| `num_demos_in_context` | `3` | Maximum number of demos to include. |
| `use_instruct_history` | `True` | Whether to include prior instructions and scores. |
| `use_tip` | `True` | Whether to include a prompting tip. |
| `set_tip_randomly` | `True` | Randomly select a tip each round. |
| `set_history_randomly` | `True` | Randomly toggle history usage each round. |
| `verbose` | `False` | Enable verbose logging. |
| `rng` | `None` | Random number generator (defaults to the `random` module). |

### Prompting Tips (`TIPS`)

The `TIPS` dictionary provides stylistic variations applied to instruction generation:

| Key | Description |
|-----|-------------|
| `none` | No tip. |
| `creative` | Encourages creative instructions. |
| `simple` | Keeps instructions clear and concise. |
| `description` | Makes instructions informative and descriptive. |
| `high_stakes` | Frames the task as a high-stakes scenario. |
| `persona` | Includes a relevant persona (e.g., "You are a ..."). |

---

## Error Handling and Graceful Degradation

The module is designed to degrade gracefully when grounding signals are unavailable:

- If `get_dspy_source_code` fails, `program_aware` is set to `False` and a message is printed.
- If `create_dataset_summary` fails, `use_dataset_summary` is set to `False`.
- Inside `GenerateModuleInstruction.forward`, if program description fails, `program_aware` is disabled for that run.
- If no demo candidates are provided, `use_task_demos` is disabled and `num_demos` defaults to `N`.

This ensures that instruction proposal can always proceed, even with reduced grounding context.

---

## Related Modules

- [propose_proposer_base.md](propose_proposer_base.md) — The abstract `Proposer` interface.
- [propose_dataset_summary.md](propose_dataset_summary.md) — Dataset summary generation used for data-aware grounding.
- [teleprompt_mipro_optimizer_v2.md](teleprompt_mipro_optimizer_v2.md) — The primary consumer of this module.
- [predict_core.md](predict_core.md) — The `Predict` module used to execute signatures.
- [primitives_module_system.md](primitives_module_system.md) — The `Module` base class.
- [signatures_signature.md](signatures_signature.md) — The `Signature` system.
