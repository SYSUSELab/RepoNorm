# Propose Module

## Overview

The **propose** module is responsible for **automatically generating natural-language instructions** (prompts) for the predictors inside a DSPy program. It is the instruction-generation engine that powers optimizers such as [`MIPROv2`](teleprompt.md) — during optimization, MIPROv2 delegates the "propose instruction candidates" step to this module.

Rather than asking a language model to invent instructions from scratch, the proposer **grounds** each generated instruction in concrete context:

- a **summary of the training dataset** (topics, format, task nature),
- a **description of the program code** and the specific module being optimized,
- **few-shot demonstrations** sampled from bootstrapped candidate sets,
- a **history of previously tried instructions** and their scores,
- an optional **prompting "tip"** (persona, high-stakes, creative, etc.).

The result is a set of candidate instructions per predictor, which downstream optimizers evaluate and select from.

## Architecture

The module is organized around a small abstract interface and a concrete grounded implementation, supported by a dataset-summarization helper and a set of text utilities.

```mermaid
graph TD
    subgraph propose["dspy/propose"]
        PB["Proposer<br/>(abstract base)"]
        GP["GroundedProposer<br/>(concrete implementation)"]
        GMI["GenerateModuleInstruction<br/>(dspy.Module)"]
        DSG["create_dataset_summary<br/>DatasetDescriptor<br/>ObservationSummarizer"]
        UT["utils<br/>strip_prefix, create_example_string,<br/>get_dspy_source_code, ..."]
    end

    GP -->|inherits| PB
    GP -->|uses| GMI
    GP -->|uses| DSG
    GP -->|uses| UT
    GMI -->|uses| UT
    DSG -->|uses| UT

    MIPRO["MIPROv2<br/>(teleprompt)"] -->|instantiates| GP
    GP -->|uses| SIG["dspy.Signature / dspy.Predict"]
    GP -->|uses| MOD["dspy.Module / Parameter"]
```

### Component Relationships

```mermaid
graph LR
    subgraph Inputs
        TS["trainset"]
        PROG["program"]
        DC["demo_candidates"]
        TL["trial_logs"]
    end

    subgraph GroundedProposer
        PIFP["propose_instructions_for_program"]
        PIFPR["propose_instruction_for_predictor"]
    end

    subgraph GenerateModuleInstruction
        DP["DescribeProgram"]
        DM["DescribeModule"]
        GSI["GenerateSingleModuleInstruction"]
    end

    TS --> PIFP
    PROG --> PIFP
    DC --> PIFP
    TL --> PIFP
    PIFP --> PIFPR
    PIFPR --> DP
    PIFPR --> DM
    PIFPR --> GSI
    GSI --> OUT["proposed_instruction"]
```

## Sub-modules

The module splits into three cohesive sub-modules. Each is documented in detail in its own file:

| Sub-module | Responsibility | Documentation |
| --- | --- | --- |
| **Proposer interface** | Abstract base class defining the contract for all proposers. | [propose_proposer_base.md](propose_proposer_base.md) |
| **Grounded proposer** | The concrete, context-aware instruction generator (`GroundedProposer`, `GenerateModuleInstruction`, and its helper signatures). | [propose_grounded_proposer.md](propose_grounded_proposer.md) |
| **Dataset summary generator** | Produces a natural-language summary of the training dataset used to ground instruction generation. | [propose_dataset_summary.md](propose_dataset_summary.md) |

## High-Level Workflow

The end-to-end instruction proposal flow, as driven by `GroundedProposer.propose_instructions_for_program`:

```mermaid
sequenceDiagram
    participant Opt as Optimizer (e.g. MIPROv2)
    participant GP as GroundedProposer
    participant DSG as Dataset Summary Generator
    participant GMI as GenerateModuleInstruction
    participant LM as Prompt LM

    Opt->>GP: __init__(program, trainset, ...)
    GP->>DSG: create_dataset_summary(trainset)
    DSG->>LM: DatasetDescriptor / ObservationSummarizer
    LM-->>DSG: dataset summary
    DSG-->>GP: data_summary
    GP->>GP: get_dspy_source_code(program)

    Opt->>GP: propose_instructions_for_program(...)
    loop for each predictor & demo set
        GP->>GMI: forward(demo_candidates, pred_i, ...)
        GMI->>LM: DescribeProgram / DescribeModule
        LM-->>GMI: program & module descriptions
        GMI->>LM: GenerateSingleModuleInstruction
        LM-->>GMI: proposed_instruction
        GMI-->>GP: proposed_instruction
    end
    GP-->>Opt: {pred_i: [instructions]}
```

## Integration with the Broader System

- **Optimizers** — [`MIPROv2`](teleprompt.md) is the primary consumer. It constructs a `GroundedProposer` in its `_propose_instructions` step, passing flags such as `program_aware`, `use_dataset_summary`, `use_task_demos`, and `use_tip` that map directly onto the proposer's configuration.
- **Primitives** — the proposer operates on [`dspy.Module`](primitives.md) programs and their [`Parameter`](predict.md) predictors, reading and rewriting `Signature.instructions`.
- **Signatures & Predict** — all generation steps are implemented as [`dspy.Signature`](signatures.md) + [`dspy.Predict`](predict.md) pairs, so the proposer itself is a DSPy program.
- **Clients / LM** — the prompt model is resolved via `get_prompt_model` and used through `dspy.settings.context(lm=...)`; see [clients](clients.md).

## Key Design Notes

- **Graceful degradation** — every grounding feature (program awareness, dataset summary, task demos, instruction history, tips) is optional and wrapped in try/except. If a feature fails, the proposer logs the error and continues without it.
- **Randomized configuration** — `set_tip_randomly` and `set_history_randomly` let the proposer explore different grounding configurations across calls, improving diversity of candidate instructions.
- **Temperature perturbation** — each instruction is generated at `T + epsilon` (epsilon in `[0.01, 0.05]`) to add controlled randomness.
- **Prefix stripping** — generated outputs are cleaned with `strip_prefix` to remove the model's echoed field prefixes.
