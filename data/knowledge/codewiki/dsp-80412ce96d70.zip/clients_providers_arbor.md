# Arbor Provider (`clients_providers_arbor`)

## Introduction

The `clients_providers_arbor` module implements DSPy's integration with the **Arbor** inference and training server. It provides a concrete [`Provider`](clients_providers.md) implementation (`ArborProvider`) that supports three capabilities beyond standard inference:

1. **Model launching/killing** — start and stop inference servers for a given model via the Arbor HTTP API.
2. **Supervised fine-tuning (SFT)** — upload training data and run remote fine-tuning jobs through the OpenAI-compatible fine-tuning API exposed by Arbor.
3. **Reinforcement learning (GRPO)** — run Group Relative Policy Optimization training steps against a live model, including checkpointing and model hot-swapping.

The module lives under the broader [`clients`](clients.md) subsystem and is one of several provider implementations (alongside [`clients_providers_openai`](clients_providers_openai.md), [`clients_providers_databricks`](clients_providers_databricks.md), and [`clients_providers_local`](clients_providers_local.md)).

> **Source file:** `dspy/clients/lm_local_arbor.py`

---

## Core Components

| Component | Kind | Responsibility |
|-----------|------|----------------|
| `ArborProvider` | `Provider` subclass | Static interface for launch/kill, SFT, GRPO, and status polling. |
| `ArborTrainingJob` | `TrainingJob` subclass | Tracks a remote SFT job (file id + job id) and supports cancellation. |
| `ArborReinforceJob` | `ReinforceJob` subclass | Drives GRPO training: initialize, step, checkpoint, terminate. |
| `GRPOTrainKwargs` | `TypedDict` | Typed contract for GRPO training hyperparameters (requires `num_generations`). |

---

## Architecture

The Arbor provider plugs into the generic provider abstraction defined in [`clients_providers`](clients_providers.md). The `LM` class (see [`clients_lm`](clients_lm.md)) delegates `launch`, `kill`, `finetune`, and `reinforce` calls to the active provider.

```mermaid
classDiagram
    class Provider {
        +bool finetunable
        +bool reinforceable
        +TrainingJob TrainingJob
        +ReinforceJob ReinforceJob
        +launch(lm, launch_kwargs)
        +kill(lm, launch_kwargs)
        +finetune(job, model, train_data, ...)
    }
    class TrainingJob {
        <<Future>>
        +str provider_job_id
        +cancel()
        +status()
    }
    class ReinforceJob {
        +LM lm
        +dict train_kwargs
        +initialize()
        +step(train_data, train_data_format)
        +save_checkpoint(name, score)
        +terminate()
    }
    class ArborProvider {
        +finetunable = True
        +reinforceable = True
        +launch(lm, launch_kwargs)
        +kill(lm, launch_kwargs)
        +finetune(job, model, train_data, ...)
        +get_training_status(job_id)
        +wait_for_job(job, ...)
    }
    class ArborTrainingJob {
        +str provider_file_id
        +str provider_job_id
        +cancel()
        +status()
    }
    class ArborReinforceJob {
        +dict DEFAULT_TRAIN_KWARGS
        +initialize()
        +step(train_data, train_data_format)
        +save_checkpoint(name, score)
        +terminate()
    }
    class GRPOTrainKwargs {
        <<TypedDict>>
        +int num_generations
    }

    Provider <|-- ArborProvider
    TrainingJob <|-- ArborTrainingJob
    ReinforceJob <|-- ArborReinforceJob
    ArborProvider ..> ArborTrainingJob : creates
    ArborProvider ..> ArborReinforceJob : creates
    ArborReinforceJob ..> GRPOTrainKwargs : uses
```

---

## Dependencies

```mermaid
graph TD
    Arbor["clients_providers_arbor<br/>(ArborProvider, ArborTrainingJob,<br/>ArborReinforceJob, GRPOTrainKwargs)"]
    Provider["clients_providers<br/>(Provider, TrainingJob, ReinforceJob)"]
    Finetune["clients_finetune<br/>(TrainDataFormat, TrainingStatus,<br/>GRPOGroup, save_data)"]
    LM["clients_lm<br/>(LM, BaseLM)"]
    OpenAI["openai SDK"]
    Requests["requests"]
    DSPy["dspy.settings"]

    Arbor --> Provider
    Arbor --> Finetune
    Arbor -.uses.-> LM
    Arbor --> OpenAI
    Arbor --> Requests
    Arbor --> DSPy
```

- **`clients_providers`** — base classes `Provider`, `TrainingJob`, `ReinforceJob` that define the provider contract.
- **`clients_finetune`** — shared data types (`TrainDataFormat`, `TrainingStatus`, `GRPOGroup`, `GRPOChatData`) and the `save_data` helper that serializes training data to JSONL.
- **`clients_lm`** — the `LM` object passed into `launch`, `kill`, and `ReinforceJob`; its `kwargs["api_base"]` and `model` are read throughout.
- **`openai` SDK** — used for the OpenAI-compatible fine-tuning endpoints (`files`, `fine_tuning.jobs`).
- **`requests`** — used for Arbor-specific endpoints (`chat/launch`, `chat/kill`, `fine_tuning/grpo/*`).
- **`dspy.settings`** — supplies `arbor_api_base`, the base URL of the Arbor server.

---

## Configuration

The Arbor server base URL is resolved by `ArborProvider._get_arbor_base_api()`, which reads `dspy.settings.arbor_api_base`:

```python
import dspy
dspy.settings.arbor_api_base = "http://localhost:8000/v1/"
```

If this setting is missing, `_get_arbor_base_api()` raises a `ValueError` with setup instructions. Note that the OpenAI SDK's `base_url` is temporarily swapped to this value for each fine-tuning call and restored afterward.

---

## Model Naming Convention

Arbor models use a prefixed naming scheme. Two helpers normalize names:

| Helper | Behavior |
|--------|----------|
| `_remove_provider_prefix(model)` | Strips leading `openai/` and `arbor:` prefixes. |
| `_add_provider_prefix(model)` | Ensures the model is prefixed with `openai/arbor:`. |

This allows the same `LM` object to be used for both inference (via the `openai/arbor:` route) and training (via the bare model name sent to the Arbor API).

---

## Process Flows

### Supervised Fine-Tuning (SFT)

`ArborProvider.finetune` orchestrates the full SFT lifecycle. It is invoked by `LM._run_finetune_job` on a background thread (see [`clients_lm`](clients_lm.md)).

```mermaid
sequenceDiagram
    participant LM as LM
    participant P as ArborProvider
    participant FS as Local FS
    participant Arbor as Arbor Server

    LM->>P: finetune(job, model, train_data, format, kwargs)
    P->>P: _get_arbor_base_api() (validate config)
    P->>P: _remove_provider_prefix(model)
    P->>P: validate_data_format(format)
    P->>FS: save_data(train_data) -> data_path
    P->>Arbor: openai.files.create(data_path)
    Arbor-->>P: provider_file_id
    P->>Arbor: openai.fine_tuning.jobs.create(...)
    Arbor-->>P: provider_job_id
    P->>P: wait_for_job(job) (poll events)
    P->>Arbor: retrieve job -> fine_tuned_model
    Arbor-->>P: finetuned_model
    P-->>LM: "openai/arbor:<model>"
```

Supported data formats (validated by `validate_data_format`): `CHAT`, `COMPLETION`, and `GRPO_CHAT` (see [`clients_finetune`](clients_finetune.md)).

### GRPO Reinforcement Learning

`ArborReinforceJob` implements the `ReinforceJob` interface. It is created via `LM.reinforce(train_kwargs)`, which calls `initialize()` immediately.

```mermaid
sequenceDiagram
    participant LM as LM
    participant J as ArborReinforceJob
    participant Arbor as Arbor Server

    LM->>J: reinforce(train_kwargs)
    J->>Arbor: POST fine_tuning/grpo/initialize
    Arbor-->>J: (job initialized)
    loop For each GRPO group
        J->>Arbor: POST fine_tuning/grpo/step
        Arbor-->>J: current_model
        J->>J: lm.model = add_provider_prefix(current_model)
    end
    J->>Arbor: POST fine_tuning/grpo/checkpoint
    Arbor-->>J: last_checkpoint, checkpoints
    J->>Arbor: POST fine_tuning/grpo/terminate
    Arbor-->>J: current_model
```

Key behaviors:

- **`initialize()`** merges user `train_kwargs` with `DEFAULT_TRAIN_KWARGS` (temperature, beta, learning rate, LoRA, etc.) and POSTs to `fine_tuning/grpo/initialize`. It requires `num_generations` to be present.
- **`step(train_data, train_data_format)`** asserts the format is `GRPO_CHAT`, then runs one GRPO step per group via `_run_grpo_step_one_group`, updating `lm.model` to the returned `current_model` after each step.
- **`save_checkpoint(name, score)`** records the checkpoint's model path and optional score in `self.checkpoints`.
- **`terminate()`** finalizes training and updates `lm.model` to the final model.

### Job Status & Cancellation

`ArborTrainingJob` and `ArborReinforceJob` both expose `status()` and `cancel()`:

- `status()` maps the provider's raw status string to a `TrainingStatus` enum via `get_training_status`.
- `cancel()` refuses to cancel terminal jobs, cancels the remote job, and (for SFT) deletes the uploaded file.

```mermaid
flowchart TD
    A[status()] --> B{job_id is None?}
    B -- yes --> C[TrainingStatus.not_started]
    B -- no --> D{does_job_exist?}
    D -- no --> E[AssertionError]
    D -- yes --> F[retrieve provider job]
    F --> G[map provider status -> TrainingStatus]
```

---

## Component Reference

### `ArborProvider`

Static-method provider implementing the [`Provider`](clients_providers.md) contract.

| Method | Purpose |
|--------|---------|
| `launch(lm, launch_kwargs)` | POSTs to `chat/launch` to start an inference server. |
| `kill(lm, launch_kwargs)` | POSTs to `chat/kill` to stop the inference server. |
| `finetune(job, model, train_data, format, kwargs)` | Full SFT orchestration (see flow above). |
| `does_job_exist(job_id, ...)` | Checks job existence via OpenAI SDK. |
| `does_file_exist(file_id, ...)` | Checks uploaded file existence. |
| `is_terminal_training_status(status)` | True for `succeeded`, `failed`, `cancelled`. |
| `get_training_status(job_id, ...)` | Maps provider status → `TrainingStatus`. |
| `validate_data_format(format)` | Ensures format is supported. |
| `upload_data(data_path, ...)` | Uploads JSONL training file. |
| `_start_remote_training(...)` | Creates the remote fine-tuning job. |
| `wait_for_job(job, ..., poll_frequency=20)` | Polls events and prints progress until terminal. |
| `get_trained_model(job, ...)` | Retrieves the fine-tuned model name. |

### `ArborTrainingJob`

Extends `TrainingJob` (a `Future`). Adds `provider_file_id` and `provider_job_id` tracking, plus a `cancel()` that cleans up both the remote job and the uploaded file.

### `ArborReinforceJob`

Extends `ReinforceJob`. Holds `DEFAULT_TRAIN_KWARGS` (a comprehensive GRPO hyperparameter default set) and implements `initialize`, `step`, `save_checkpoint`, `terminate`, `cancel`, and `status`.

### `GRPOTrainKwargs`

A `TypedDict` requiring `num_generations: int`. Additional GRPO hyperparameters are accepted as untyped keys and merged with `DEFAULT_TRAIN_KWARGS`.

---

## Related Documentation

- [`clients_providers`](clients_providers.md) — base `Provider`, `TrainingJob`, `ReinforceJob` abstractions.
- [`clients_lm`](clients_lm.md) — `LM`/`BaseLM` that dispatch to providers.
- [`clients_finetune`](clients_finetune.md) — shared training data types and serialization.
- [`clients_providers_openai`](clients_providers_openai.md) — OpenAI provider implementation.
- [`clients_providers_databricks`](clients_providers_databricks.md) — Databricks provider implementation.
- [`clients_providers_local`](clients_providers_local.md) — local SGLang provider implementation.
- [`teleprompt`](teleprompt.md) — teleprompters (e.g., `GRPO`, `BootstrapFinetune`) that drive these jobs.
