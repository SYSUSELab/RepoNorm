# Retrievers: Databricks

## Introduction

The `retrievers_databricks` module provides the `DatabricksRM` retriever, a DSPy retrieval module that queries a **Databricks Mosaic AI Vector Search Index** to return the top-k most relevant documents for a given query. It supports both text and vector queries, optional metadata filtering, and can operate either as a standard DSPy retriever or in a mode compatible with the Databricks Mosaic Agent Framework.

The module is part of the broader [retrievers](retrievers_core.md) family and builds on the base `Retrieve` abstraction. It is closely related to the [Databricks client provider](clients_providers_databricks.md), which handles LLM inference against Databricks endpoints.

---

## Core Components

| Component | Type | Description |
|-----------|------|-------------|
| `DatabricksRM` | Class | A DSPy retriever that queries a Databricks Vector Search Index. |
| `Document` | Dataclass | A lightweight document container used when operating in Databricks Agent Framework mode. |

### `Document`

A simple dataclass representing a retrieved document with three fields:

- `page_content` (`str`): The textual content of the document.
- `metadata` (`dict[str, Any]`): Associated metadata (e.g., `doc_id`, `doc_uri`, and any extra columns).
- `type` (`str`): The document type (always `"Document"`).

It exposes a `to_dict()` method that serializes the instance into a plain dictionary, which is the format expected by the Databricks Mosaic Agent Framework.

### `DatabricksRM`

`DatabricksRM` extends `dspy.Retrieve` (see [retrievers_core](retrievers_core.md)) and overrides `forward` to query a Databricks Vector Search Index. Key responsibilities:

- **Authentication resolution**: Resolves credentials from constructor arguments or environment variables (`DATABRICKS_TOKEN`, `DATABRICKS_HOST`, `DATABRICKS_CLIENT_ID`, `DATABRICKS_CLIENT_SECRET`).
- **Dual query backends**: Uses the `databricks-sdk` Python library when installed, otherwise falls back to raw HTTP requests via the `requests` library.
- **Query handling**: Accepts either a text query (`str`) or a numeric query vector (`list[float]`).
- **Result shaping**: Returns a `dspy.Prediction` (standard mode) or a list of dictionaries (Agent Framework mode).

---

## Architecture

The following diagram shows how `DatabricksRM` fits into the DSPy retrieval stack and its external dependencies.

```mermaid
graph TD
    subgraph DSPy Core
        Retrieve["Retrieve (base class)"]
        Prediction["Prediction"]
        Settings["dspy.settings"]
    end

    subgraph retrievers_databricks
        DatabricksRM["DatabricksRM"]
        Document["Document (dataclass)"]
    end

    subgraph External
        SDK["databricks-sdk (WorkspaceClient)"]
        Requests["requests (HTTP)"]
        MLflow["mlflow (optional)"]
        VSIndex["Databricks Vector Search Index"]
    end

    Retrieve --> DatabricksRM
    DatabricksRM --> Prediction
    DatabricksRM --> Document
    DatabricksRM --> SDK
    DatabricksRM --> Requests
    DatabricksRM --> MLflow
    SDK --> VSIndex
    Requests --> VSIndex
    Settings -.-> DatabricksRM
```

---

## Component Interaction

The `forward` method orchestrates the retrieval process, selecting a backend and shaping the output based on configuration.

```mermaid
sequenceDiagram
    participant Caller
    participant DatabricksRM
    participant Backend as SDK / requests
    participant Index as Vector Search Index

    Caller->>DatabricksRM: forward(query, query_type, filters_json)
    DatabricksRM->>DatabricksRM: Normalize query (text vs vector)
    DatabricksRM->>DatabricksRM: Map legacy query_type -> "ANN"
    alt databricks-sdk installed
        DatabricksRM->>Backend: _query_via_databricks_sdk(...)
    else SDK not installed
        DatabricksRM->>Backend: _query_via_requests(...)
    end
    Backend->>Index: query_index / POST /query
    Index-->>Backend: JSON results
    Backend-->>DatabricksRM: results dict
    DatabricksRM->>DatabricksRM: Validate columns (id, text)
    DatabricksRM->>DatabricksRM: Sort by score, take top-k
    alt use_with_databricks_agent_framework
        DatabricksRM-->>Caller: list[dict] (Document.to_dict())
    else standard mode
        DatabricksRM-->>Caller: Prediction(docs, doc_ids, ...)
    end
```

---

## Data Flow

The diagram below illustrates how a query flows through the module and how results are transformed into the final output.

```mermaid
flowchart TD
    A["Query (str or list[float])"] --> B{"query_type in ['vector','text']?"}
    B -- Yes --> C["Set query_type = 'ANN'"]
    B -- No --> D["Keep query_type"]
    C --> E{"Query is str?"}
    D --> E
    E -- Yes --> F["query_text = query, query_vector = None"]
    E -- No --> G["query_vector = query, query_text = None"]
    F --> H{"databricks-sdk installed?"}
    G --> H
    H -- Yes --> I["_query_via_databricks_sdk"]
    H -- No --> J["_query_via_requests"]
    I --> K["Raw results dict"]
    J --> K
    K --> L["Validate id/text columns present"]
    L --> M["Build item dicts from data_array"]
    M --> N["Sort by score desc, take top-k"]
    N --> O{"Agent Framework mode?"}
    O -- Yes --> P["Return list of Document dicts"]
    O -- No --> Q["Return Prediction(docs, doc_ids, doc_uris, extra_columns)"]
```

---

## Query Backends

`DatabricksRM` supports two interchangeable backends for querying the index. The choice is automatic based on whether the `databricks-sdk` package is importable.

| Backend | Method | Authentication | Notes |
|---------|--------|----------------|-------|
| Databricks SDK | `_query_via_databricks_sdk` | Service principal (`client_id` + `client_secret`) or token (`host` + `token`) | Preferred when `databricks-sdk` is installed. Uses `WorkspaceClient.vector_search_indexes.query_index`. |
| HTTP requests | `_query_via_requests` | Bearer token | Fallback. POSTs to `/api/2.0/vector-search/indexes/{index_name}/query`. |

Both backends require **exactly one** of `query_text` or `query_vector` to be specified, raising a `ValueError` otherwise.

---

## Configuration & Authentication

Credentials are resolved with the following precedence: explicit constructor arguments → environment variables.

```mermaid
flowchart LR
    A["Constructor arg"] --> C{"Provided?"}
    B["Environment variable"] --> C
    C -- Yes --> D["Use value"]
    C -- No --> E["Resolve via Databricks SDK"]
```

| Parameter | Environment Variable | Purpose |
|-----------|----------------------|---------|
| `databricks_token` | `DATABRICKS_TOKEN` | Workspace authentication token. |
| `databricks_endpoint` | `DATABRICKS_HOST` | Workspace URL hosting the index. |
| `databricks_client_id` | `DATABRICKS_CLIENT_ID` | Service principal ID. |
| `databricks_client_secret` | `DATABRICKS_CLIENT_SECRET` | Service principal secret. |

> **Note:** If the `databricks-sdk` is not installed and neither token/endpoint nor client credentials are supplied, the constructor raises a `ValueError`.

---

## Databricks Mosaic Agent Framework Mode

When `use_with_databricks_agent_framework=True`:

1. The constructor calls `mlflow.models.set_retriever_schema(primary_key="doc_id", text_column="page_content", doc_uri="doc_uri")`. If `mlflow` is not installed, a `ValueError` is raised.
2. `forward` returns a **list of dictionaries** (via `Document.to_dict()`) instead of a `Prediction`, with each entry containing `page_content`, `metadata` (including `doc_id`, `doc_uri`, and extra columns), and `type`.

This mode is intended for integration with Databricks' agent tooling, which expects a specific retriever schema.

---

## Result Shaping

### Standard Mode

Returns a `dspy.Prediction` (see [primitives_data_containers](primitives_data_containers.md)) with the following fields:

- `docs`: List of document texts.
- `doc_ids`: List of document IDs.
- `doc_uris`: List of document URIs (or `None` if `docs_uri_column_name` is not set).
- `extra_columns`: List of dictionaries containing any additional requested columns.

### Agent Framework Mode

Returns a list of dictionaries, each shaped as:

```python
{
    "page_content": "...",
    "metadata": {"doc_id": "...", "doc_uri": "...", ...extra_columns},
    "type": "Document",
}
```

---

## Column Handling

The module performs several column-related operations:

- **Column set construction**: `self.columns` is the deduplicated union of `docs_id_column_name`, `text_column_name`, and any user-supplied `columns`.
- **Validation**: After querying, the module verifies that both `docs_id_column_name` and `text_column_name` exist in the index manifest, raising an `Exception` if not.
- **ID extraction** (`_extract_doc_ids`): Handles the special case where `docs_id_column_name == "metadata"`, parsing the JSON `metadata` field to extract `document_id`.
- **Extra columns** (`_get_extra_columns`): Collects all columns except id, text, and uri; when the id column is `metadata`, it merges the parsed metadata (excluding `document_id`).

---

## Usage Example

```python
from dspy.retrievers.databricks_rm import DatabricksRM

retriever = DatabricksRM(
    databricks_index_name="your_index_name",
    docs_id_column_name="id",
    text_column_name="field2",
    k=3,
)

# Text query
result = retriever(query="Example query text")

# Vector query
result = retriever(query=[0.1, 0.2, 0.3], query_type="HYBRID")
```

---

## Related Modules

- [retrievers_core](retrievers_core.md) — The base `Retrieve` abstraction that `DatabricksRM` extends.
- [retrievers_embeddings](retrievers_embeddings.md) — Embedding-based retrieval.
- [retrievers_weaviate](retrievers_weaviate.md) — Weaviate vector store retriever.
- [clients_providers_databricks](clients_providers_databricks.md) — Databricks LLM provider and training jobs.
- [primitives_data_containers](primitives_data_containers.md) — `Prediction` and related data containers.
