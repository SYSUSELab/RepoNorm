# clients_finetune

## Introduction

The `clients_finetune` module provides the **data-formatting, validation, and persistence utilities** that underpin DSPy's fine-tuning and reinforcement-learning workflows. It defines the canonical data structures (chat, completion, and GRPO chat formats), the lifecycle states of a training job, and the helper functions used to serialize training data to disk and validate it before it is handed off to a provider.

This module is a *supporting* layer: it does not itself call any provider API. Instead, it is consumed by the LM/provider layer (see [clients_lm](clients_lm.md) and [clients_providers](clients_providers.md)) and by the fine-tuning teleprompters (see [teleprompt](teleprompt.md)) to guarantee that training data conforms to the expected schema.

---

## Core Components

The module is implemented in a single file, `dspy/clients/utils_finetune.py`, and exposes the following components:

| Component | Kind | Purpose |
|-----------|------|---------|
| `TrainingStatus` | `str` Enum | Canonical lifecycle states of a training job. |
| `TrainDataFormat` | `str` Enum | Supported training-data serialization formats. |
| `Message` | `TypedDict` | A single chat message (`user` / `assistant` / `system`). |
| `MessageAssistant` | `TypedDict` | An assistant-role message (used as the GRPO completion). |
| `GRPOChatData` | `TypedDict` | One GRPO training sample: messages + completion + reward. |
| `infer_data_format` | function | Maps an `Adapter` to a `TrainDataFormat`. |
| `get_finetune_directory` | function | Resolves/creates the on-disk finetune cache directory. |
| `save_data` | function | Hashes and writes training data to a `.jsonl` file. |
| `validate_data_format` | function | Validates a dataset against a target format. |
| `find_data_errors_completion` | function | Validator for the `completion` format. |
| `find_data_error_chat` | function | Validator for the `chat` format. |
| `find_data_error_chat_message` | function | Per-message validator for the `chat` format. |

---

## Data Structures

### `TrainingStatus`

A `str`-based `Enum` describing the state of a fine-tuning job. It is returned by `TrainingJob.status()` implementations (see [clients_providers](clients_providers.md)).

```mermaid
stateDiagram-v2
    [*] --> not_started
    not_started --> pending
    pending --> running
    running --> succeeded
    running --> failed
    running --> cancelled
    pending --> cancelled
```

| Value | Meaning |
|-------|---------|
| `not_started` | Job created but not yet submitted. |
| `pending` | Submitted, awaiting provider resources. |
| `running` | Actively training. |
| `succeeded` | Completed successfully. |
| `failed` | Terminated with an error. |
| `cancelled` | Cancelled by the user. |

### `TrainDataFormat`

A `str`-based `Enum` enumerating the supported serialization formats:

| Value | Description |
|-------|-------------|
| `chat` | OpenAI-style chat fine-tuning data: `{"messages": [...]}`. |
| `completion` | Legacy prompt/completion pairs: `{"prompt": ..., "completion": ...}`. |
| `grpo_chat` | GRPO reinforcement-learning samples (messages + completion + reward). |

### Message TypedDicts

```python
class Message(TypedDict):
    role: Literal["user"] | Literal["assistant"] | Literal["system"]
    content: str

class MessageAssistant(TypedDict):
    role: Literal["assistant"]
    content: str

class GRPOChatData(TypedDict):
    messages: list[Message]
    completion: MessageAssistant
    reward: float
```

`GRPOChatData` represents a single reinforcement-learning sample. A `GRPOGroup` (a `list[GRPOChatData]`) groups samples that share the same prompt for relative-reward computation, as used by the GRPO optimizer (see [teleprompt](teleprompt.md)).

---

## Architecture & Data Flow

The module sits between the **teleprompter** that produces training data and the **provider** that consumes it.

```mermaid
flowchart TD
    subgraph Teleprompters
        BF[BootstrapFinetune]
        GRPO[GRPO]
    end

    subgraph clients_finetune
        IDF[infer_data_format]
        SAVE[save_data]
        VAL[validate_data_format]
        DIR[get_finetune_directory]
        FMT[TrainDataFormat / TrainingStatus]
        GRPOData[GRPOChatData]
    end

    subgraph Clients
        LM[LM.finetune / LM.reinforce]
        PROV[Provider.finetune]
        JOB[TrainingJob]
    end

    BF -->|adapter| IDF
    IDF --> FMT
    BF -->|train_data| SAVE
    SAVE --> DIR
    BF -->|train_data, format| VAL
    VAL --> FMT
    BF --> LM
    GRPO --> GRPOData
    GRPOData --> LM
    LM --> PROV
    PROV --> JOB
    JOB -->|status| FMT
```

### Fine-tuning data preparation flow

```mermaid
sequenceDiagram
    participant TP as BootstrapFinetune
    participant UF as utils_finetune
    participant LM as LM
    participant P as Provider

    TP->>UF: infer_data_format(adapter)
    UF-->>TP: TrainDataFormat.CHAT
    TP->>UF: save_data(train_data)
    UF->>UF: get_finetune_directory()
    UF-->>TP: file_path (.jsonl)
    TP->>UF: validate_data_format(data, format)
    UF-->>TP: (raises on error, else returns)
    TP->>LM: lm.finetune(train_data, format, kwargs)
    LM->>P: provider.finetune(job, ...)
    P-->>LM: fine-tuned model id
    LM-->>TP: TrainingJob (Future)
```

---

## Function Reference

### `infer_data_format(adapter: Adapter) -> str`

Maps a DSPy `Adapter` to the corresponding `TrainDataFormat`. Currently only `ChatAdapter` is supported and maps to `TrainDataFormat.CHAT`; any other adapter raises `ValueError`. This is the bridge between the adapter layer (see [adapters](adapters.md)) and the training-data format.

### `get_finetune_directory() -> str`

Resolves the directory used to store finetune artifacts:

1. Uses the `DSPY_FINETUNEDIR` environment variable if set.
2. Otherwise defaults to `<DSPY_CACHEDIR>/finetune`.
3. Creates the directory if it does not exist and returns its absolute path.

### `save_data(data: list[dict[str, Any]]) -> str`

Serializes training data to a JSONL file:

- Computes a content hash via `datasets.fingerprint.Hasher` to derive a deterministic filename (`<hash>.jsonl`).
- Writes each record as a single JSON line using `ujson`.
- Returns the absolute file path.

Because the filename is content-addressed, identical datasets are deduplicated on disk.

### `validate_data_format(data, data_format)`

Validates a dataset against the target `TrainDataFormat`:

- Dispatches to `find_data_error_chat` or `find_data_errors_completion` based on the format.
- Collects per-record errors into a list of `{"index", "error"}` dictionaries.
- On any error, writes them to `<finetune_dir>/data_format_errors.log` and raises `ValueError` pointing at the log file.

> **Note:** `TrainDataFormat.GRPO_CHAT` is defined but not yet wired into `validate_data_format`'s dispatch table; passing it raises an assertion error.

### Validators

| Function | Format | Checks |
|----------|--------|--------|
| `find_data_errors_completion` | `completion` | Exactly the keys `prompt` and `completion`, both `str`. |
| `find_data_error_chat` | `chat` | Exactly the key `messages`, which must be a `list`. |
| `find_data_error_chat_message` | `chat` | Each message has exactly `role` and `content`; `role` ∈ {`assistant`, `system`, `user`}; `content` is `str`. |

The chat validators are adapted from the [OpenAI chat fine-tuning data prep cookbook](https://cookbook.openai.com/examples/chat_finetuning_data_prep).

---

## Integration Points

### With the LM / Provider layer

`LM.finetune()` and `LM.reinforce()` (see [clients_lm](clients_lm.md)) accept `train_data` and a `train_data_format` produced by this module. The provider's `finetune` method (see [clients_providers](clients_providers.md)) consumes the validated data and returns a `TrainingJob` whose `status()` returns a `TrainingStatus`.

### With the adapter layer

`infer_data_format` depends on `dspy.ChatAdapter` (see [adapters](adapters.md)). The `ChatAdapter.format_finetune_data` method produces the `{"messages": [...]}` structure that matches `TrainDataFormat.CHAT`.

### With teleprompters

`BootstrapFinetune` (see [teleprompt](teleprompt.md)) uses `infer_data_format`, `save_data`, and `validate_data_format` to prepare and persist training data before invoking `LM.finetune`. The `GRPO` optimizer produces `GRPOChatData` samples for reinforcement learning.

---

## Dependency Diagram

```mermaid
flowchart LR
    UF[utils_finetune]
    UF -->|imports| DSPY[dspy]
    UF -->|Adapter| AD[adapters]
    UF -->|DSPY_CACHEDIR| CACHE[utils/caching]
    UF -->|Hasher| DS[datasets.fingerprint]
    UF -->|ujson| UJSON[ujson]

    BF[bootstrap_finetune] -->|uses| UF
    GRPO[grpo] -->|uses| UF
    LM[clients/lm] -->|uses| UF
    PROV[clients/provider] -->|uses| UF
```

---

## Summary

The `clients_finetune` module is the **schema and persistence contract** for DSPy fine-tuning. It:

1. Defines the canonical **data formats** (`TrainDataFormat`) and **job states** (`TrainingStatus`).
2. Provides **content-addressed persistence** (`save_data`) and **directory management** (`get_finetune_directory`).
3. Enforces **schema correctness** (`validate_data_format` and its validators) before data reaches a provider.
4. Bridges the **adapter layer** to the **training-data format** via `infer_data_format`.

For the components that consume this module, see [clients_lm](clients_lm.md), [clients_providers](clients_providers.md), [adapters](adapters.md), and [teleprompt](teleprompt.md).
