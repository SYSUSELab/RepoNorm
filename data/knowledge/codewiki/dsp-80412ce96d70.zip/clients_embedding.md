# Clients Embedding Module

## Introduction

The `clients_embedding` module provides DSPy's unified interface for computing text embeddings. Its core component, the `Embedder` class, abstracts over two fundamentally different embedding backends:

1. **Hosted embedding models** (e.g., OpenAI's `text-embedding-3-small`) accessed through the [litellm](https://github.com/BerriAI/litellm) integration.
2. **Custom embedding functions** supplied by the user as plain Python callables (e.g., a local `sentence-transformers` model).

The module handles batching, caching, synchronous and asynchronous execution, and consistent output shaping (single 1D vector vs. 2D matrix), so downstream consumers such as retrievers can rely on a stable contract regardless of the underlying provider.

---

## Architecture Overview

The `Embedder` sits between user code / retrievers and the underlying embedding providers. It delegates caching to the shared DSPy cache layer and delegates actual embedding computation to either litellm or a user callable.

```mermaid
graph TD
    User["User Code / Retriever"] -->|"__call__ / acall"| Embedder

    subgraph clients_embedding
        Embedder["Embedder"]
        Pre["_preprocess"]
        Post["_postprocess"]
        Compute["_compute_embeddings"]
        ACompute["_acompute_embeddings"]
        CachedCompute["_cached_compute_embeddings"]
        CachedACompute["_cached_acompute_embeddings"]
    end

    Embedder --> Pre
    Embedder --> Post
    Embedder -->|"caching=True"| CachedCompute
    Embedder -->|"caching=False"| Compute
    Embedder -->|"async, caching=True"| CachedACompute
    Embedder -->|"async, caching=False"| ACompute

    CachedCompute -->|"@request_cache"| Cache["dspy.cache (Cache)"]
    CachedACompute -->|"@request_cache"| Cache

    Compute -->|"str model"| LiteLLM["litellm.embedding"]
    ACompute -->|"str model"| LiteLLMAsync["litellm.aembedding"]
    Compute -->|"callable model"| Callable["User Callable"]
    ACompute -->|"callable model"| Callable

    LiteLLM --> LiteLLMCache["litellm.cache"]
```

---

## Core Component: `Embedder`

The `Embedder` class is the single public entry point of this module. It is exported as `dspy.Embedder`.

### Constructor

```python
Embedder(
    model: str | Callable,
    batch_size: int = 200,
    caching: bool = True,
    **kwargs: dict[str, Any],
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `model` | `str \| Callable` | — | Either a litellm-supported hosted embedding model name (e.g. `"openai/text-embedding-3-small"`) or a callable that maps a list of strings to embeddings. |
| `batch_size` | `int` | `200` | Default number of inputs processed per batch. |
| `caching` | `bool` | `True` | Whether to cache embedding responses for hosted models. |
| `**kwargs` | `dict` | `{}` | Default keyword arguments forwarded to the embedding model on every call. |

The constructor stores these values as `self.model`, `self.batch_size`, `self.caching`, and `self.default_kwargs`. No network calls or model loading occur at construction time.

### Callable Contract for Custom Models

When `model` is a callable, it must:

- Accept a **list of strings** as its first positional argument.
- Return embeddings as either:
  - a 2D `numpy` array of `float32`, or
  - a 2D list of `float32` values.
- Produce one row per input string.

Additional keyword arguments passed to the `Embedder` are forwarded to the callable.

---

## Execution Flow

Both `__call__` (sync) and `acall` (async) follow the same three-stage pipeline: **preprocess → compute per batch → postprocess**.

```mermaid
flowchart TD
    Start([Input: str or list of str]) --> Pre["_preprocess"]
    Pre --> Single{"Single string?"}
    Single -->|Yes| Wrap["Wrap in list, is_single_input=True"]
    Single -->|No| Keep["Keep list, is_single_input=False"]
    Wrap --> Validate["Validate all inputs are strings"]
    Keep --> Validate
    Validate --> Merge["Merge default_kwargs with call kwargs"]
    Merge --> Split["Split into batches of batch_size"]
    Split --> Loop{"For each batch"}
    Loop -->|caching=True| Cached["_cached_compute_embeddings"]
    Loop -->|caching=False| Plain["_compute_embeddings"]
    Cached --> Collect["Extend embeddings_list"]
    Plain --> Collect
    Collect --> Loop
    Loop -->|done| Post["_postprocess: np.array(dtype=float32)"]
    Post --> Shape{"is_single_input?"}
    Shape -->|Yes| OneD["Return embeddings[0] (1D)"]
    Shape -->|No| TwoD["Return 2D array"]
```

### `_preprocess`

Normalizes inputs and prepares batching:

1. If `inputs` is a `str`, it is wrapped in a list and `is_single_input` is set to `True`.
2. Validates that **all** inputs are strings, raising `ValueError("All inputs must be strings.")` otherwise.
3. Resolves `batch_size` and `caching` from call-time arguments, falling back to instance defaults.
4. Merges `self.default_kwargs` with call-time `kwargs` (call-time values win).
5. Splits inputs into consecutive batches of `batch_size`.

Returns a tuple: `(input_batches, caching, merged_kwargs, is_single_input)`.

### `_postprocess`

Converts the accumulated list of embeddings into a `float32` numpy array. If the original input was a single string, it returns the first row (a 1D vector); otherwise it returns the full 2D matrix.

### `__call__` / `acall`

```python
def __call__(self, inputs, batch_size=None, caching=None, **kwargs) -> np.ndarray
async def acall(self, inputs, batch_size=None, caching=None, **kwargs) -> np.ndarray
```

Both methods:

1. Run `_preprocess`.
2. Select the cached or uncached compute function based on the resolved `caching` flag.
3. Iterate over batches, extending a flat `embeddings_list`.
4. Run `_postprocess` and return the result.

The async variant awaits `_acompute_embeddings` / `_cached_acompute_embeddings` for each batch.

---

## Compute Functions

The module defines four module-level functions that perform the actual embedding work. They are not part of the public API but are central to the module's behavior.

| Function | Sync/Async | Cached | Backend |
|----------|-----------|--------|---------|
| `_compute_embeddings` | Sync | No | litellm / callable |
| `_cached_compute_embeddings` | Sync | Yes | litellm / callable |
| `_acompute_embeddings` | Async | No | litellm / callable |
| `_cached_acompute_embeddings` | Async | Yes | litellm / callable |

### Backend Dispatch

Each compute function dispatches on the type of `model`:

- **`str`** → calls `litellm.embedding(...)` (or `litellm.aembedding(...)` for async) and extracts `data["embedding"]` from each response item. litellm's own cache is only used when `caching` is enabled **and** `litellm.cache is not None`.
- **`callable`** → invokes `model(batch_inputs, **kwargs)` directly.
- **anything else** → raises `ValueError` describing the expected types.

### Caching Layer

The cached variants are decorated with `@request_cache(ignored_args_for_cache_key=["api_key", "api_base", "base_url"])`. This means:

- Cache keys are derived from the function's fully-qualified name plus the request arguments, **excluding** `api_key`, `api_base`, and `base_url` (so credentials and endpoints do not fragment the cache).
- The cache is the shared DSPy cache (`dspy.cache`), a two-level in-memory + on-disk cache. See [clients_cache.md](clients_cache.md) for details on the `Cache` class and the `request_cache` decorator.

> **Note:** The `caching` flag controls two independent caches. The `@request_cache` decorator governs the DSPy-level cache, while the `caching` argument passed into litellm governs litellm's internal cache. Both must be enabled for litellm-level caching to take effect.

---

## Usage Examples

### Hosted Model

```python
import dspy

embedder = dspy.Embedder("openai/text-embedding-3-small", batch_size=100)
embeddings = embedder(["hello", "world"])

assert embeddings.shape == (2, 1536)
```

### Local Model via `sentence-transformers`

```python
# pip install sentence_transformers
import dspy
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("sentence-transformers/static-retrieval-mrl-en-v1", device="cpu")

embedder = dspy.Embedder(model.encode)
embeddings = embedder(["hello", "world"], batch_size=1)

assert embeddings.shape == (2, 1024)
```

### Custom Function

```python
import dspy
import numpy as np

def my_embedder(texts):
    return np.random.rand(len(texts), 10)

embedder = dspy.Embedder(my_embedder)
embeddings = embedder(["hello", "world"], batch_size=1)

assert embeddings.shape == (2, 10)
```

### Async Usage

```python
embeddings = await embedder.acall(["hello", "world"])
```

---

## Integration with Retrievers

The primary consumer of `Embedder` within DSPy is the `Embeddings` retriever (`dspy/retrievers/embeddings.py`). It accepts any `embedder` object that satisfies the same callable contract and uses it to embed both the corpus and incoming queries.

```mermaid
sequenceDiagram
    participant R as Embeddings Retriever
    participant E as Embedder
    participant B as Backend (litellm / callable)

    R->>E: embedder(corpus)
    E->>B: batch compute
    B-->>E: embeddings
    E-->>R: 2D float32 array
    Note over R: Normalize + optionally build FAISS index

    R->>E: embedder(queries)
    E->>B: batch compute
    B-->>E: embeddings
    E-->>R: 2D float32 array
    Note over R: Rerank candidates, return top-k passages
```

Because `Embedder` returns normalized-shape `float32` arrays, the retriever can apply its own L2 normalization and similarity search without special-casing the backend. See [retrievers.md](retrievers.md) for the full retriever documentation.

For testing, `DummyVectorizer` (`dspy/utils/dummies.py`) provides a lightweight n-gram-based vectorizer that conforms to the same callable contract, allowing retriever tests to run without any real embedding model.

---

## Dependencies

```mermaid
graph LR
    Embedder --> litellm["litellm"]
    Embedder --> numpy["numpy"]
    Embedder --> request_cache["dspy.clients.cache.request_cache"]
    request_cache --> Cache["dspy.clients.cache.Cache"]
    Cache --> cachetools["cachetools.LRUCache"]
    Cache --> diskcache["diskcache.FanoutCache"]
```

| Dependency | Purpose |
|------------|---------|
| `litellm` | Hosted embedding model calls (`embedding`, `aembedding`) and optional litellm-level caching. |
| `numpy` | Output array construction and `float32` dtype enforcement. |
| `dspy.clients.cache.request_cache` | Decorator that wires the cached compute functions into the shared DSPy cache. |

---

## Key Design Notes

- **Unified output contract:** Regardless of backend, callers always receive a `float32` numpy array — 1D for a single string input, 2D for a list.
- **Batching is transparent:** Inputs are automatically chunked by `batch_size`, and results are concatenated in order.
- **Two-tier caching:** DSPy-level caching (via `request_cache`) and litellm-level caching are independent and both gated by the `caching` flag.
- **Credential-agnostic cache keys:** `api_key`, `api_base`, and `base_url` are excluded from cache keys so that rotating credentials does not invalidate cached embeddings.
- **Sync and async parity:** `__call__` and `acall` share identical preprocessing/postprocessing logic, differing only in whether the compute function is awaited.

---

## Related Documentation

- [clients_cache.md](clients_cache.md) — The `Cache` class and `request_cache` decorator used for embedding caching.
- [retrievers.md](retrievers.md) — The `Embeddings` retriever that consumes `Embedder`.
- [clients_lm.md](clients_lm.md) — The analogous `LM` / `BaseLM` client abstraction for language models.
