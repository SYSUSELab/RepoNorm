# Teleprompt Core

## Introduction

The **Teleprompt Core** module provides the foundational abstractions and shared utilities that power DSPy's entire optimizer (teleprompter) ecosystem. It defines the `Teleprompter` base class — the common interface that every optimizer implements — and a rich collection of helper functions used across the various optimizer families (few-shot, prompt, weight, and meta optimizers).

This module is intentionally low-level: it does not implement any specific optimization strategy itself. Instead, it standardizes *how* optimizers are structured and offers reusable building blocks (minibatching, few-shot demo generation, candidate evaluation, program persistence, logging, and token accounting) so that concrete optimizers can focus on their algorithms.

> **Related modules:**
> - [teleprompt_fewshot](teleprompt_fewshot.md) — `LabeledFewShot`, `BootstrapFewShot`, `BootstrapFewShotWithRandomSearch`, `BootstrapFewShotWithOptuna`, `KNNFewShot`, `InferRules`
> - [teleprompt_prompt](teleprompt_prompt.md) — `COPRO`, `SignatureOptimizer`, `MIPROv2`, `SIMBA`
> - [teleprompt_weight](teleprompt_weight.md) — `BootstrapFinetune`, `GRPO`
> - [teleprompt_meta](teleprompt_meta.md) — `Ensemble`, `BetterTogether`, `AvatarOptimizer`
> - [primitives_module_system](primitives_module_system.md) — `Module`, `BaseModule`
> - [primitives_data_containers](primitives_data_containers.md) — `Example`, `Prediction`
> - [evaluate_program_evaluation](evaluate_program_evaluation.md) — `Evaluate`, `EvaluationResult`

---

## Architecture Overview

The Teleprompt Core sits at the base of the optimizer hierarchy. Every concrete optimizer inherits from `Teleprompter` and consumes the shared utilities in `utils.py`.

```mermaid
graph TD
    subgraph "Teleprompt Core"
        TP[Teleprompter<br/>base class]
        U[utils.py<br/>helper functions]
    end

    subgraph "Concrete Optimizers"
        FS[teleprompt_fewshot]
        PR[teleprompt_prompt]
        WT[teleprompt_weight]
        MT[teleprompt_meta]
    end

    subgraph "DSPy Primitives"
        MOD[Module]
        EX[Example]
        PRED[Prediction]
    end

    subgraph "Evaluation"
        EV[Evaluate]
    end

    FS -->|inherits| TP
    PR -->|inherits| TP
    WT -->|inherits| TP
    MT -->|inherits| TP

    FS -->|uses| U
    PR -->|uses| U
    WT -->|uses| U
    MT -->|uses| U

    TP -->|operates on| MOD
    U -->|operates on| MOD
    U -->|operates on| EX
    U -->|invokes| EV
    EV -->|produces| PRED
```

---

## Core Components

### `Teleprompter` (base class)

**File:** `dspy/teleprompt/teleprompt.py`

`Teleprompter` is the abstract base class that defines the contract for all DSPy optimizers. It establishes a uniform `compile(...)` interface so that optimizers can be swapped interchangeably within a pipeline.

```python
class Teleprompter:
    def __init__(self):
        pass

    def compile(self, student, *, trainset, teacher=None, valset=None, **kwargs) -> Module:
        raise NotImplementedError

    def get_params(self) -> dict[str, Any]:
        return self.__dict__
```

#### Key responsibilities

| Method | Purpose |
| --- | --- |
| `compile(student, *, trainset, teacher=None, valset=None, **kwargs)` | The single entry point every optimizer must implement. Takes an uncompiled `student` program and returns an optimized `Module`. Raises `NotImplementedError` in the base class. |
| `get_params()` | Returns the optimizer's configuration as a dictionary (defaults to `self.__dict__`). Useful for logging, serialization, and reproducibility. |

#### `compile` parameters

- **`student`** (`Module`): The program to be optimized. Concrete optimizers typically operate on a `reset_copy()` or `deepcopy()` of this program.
- **`trainset`** (`list[Example]`): The training examples used to drive optimization.
- **`teacher`** (`Module | None`): An optional teacher program that provides supervision (e.g., bootstrapped demonstrations). When `None`, the student often acts as its own teacher.
- **`valset`** (`list[Example] | None`): An optional validation set used to select the best candidate.
- **`**kwargs`**: Optimizer-specific options.

> **Design note:** The base class deliberately does *not* implement `compile`. Each optimizer family defines its own algorithm while honoring this shared signature, enabling polymorphic use of optimizers.

---

### Utility Functions

**File:** `dspy/teleprompt/utils.py`

The utilities fall into four functional groups: **training**, **logging**, **token accounting**, and **miscellaneous helpers**.

```mermaid
graph LR
    subgraph "Training Utils"
        A1[create_minibatch]
        A2[eval_candidate_program]
        A3[eval_candidate_program_with_pruning]
        A4[get_program_with_highest_avg_score]
        A5[calculate_last_n_proposed_quality]
        A6[create_n_fewshot_demo_sets]
    end
    subgraph "Logging Utils"
        B1[print_full_program]
        B2[save_candidate_program]
        B3[save_file_to_log_dir]
        B4[setup_logging]
        B5[get_task_model_history_for_full_example]
    end
    subgraph "Token Utils"
        C1[get_token_usage]
        C2[log_token_usage]
    end
    subgraph "Misc Utils"
        D1[get_prompt_model]
        D2[get_signature]
        D3[set_signature]
        D4[old_getfile / new_getfile]
    end
```

#### Training Utilities

##### `create_minibatch(trainset, batch_size=50, rng=None)`
Samples a random subset of the training set. The batch size is clamped to the dataset length, and an optional `rng` (e.g., `random.Random(seed)`) enables deterministic sampling.

```python
minibatch = create_minibatch(trainset, batch_size=50, rng=random.Random(0))
```

##### `eval_candidate_program(batch_size, trainset, candidate_program, evaluate, rng=None)`
Evaluates a candidate program either on the **full** trainset (when `batch_size >= len(trainset)`) or on a **minibatch**. It attaches `callback_metadata` (`eval_full` / `eval_minibatch`) for tracing. On exception, it logs the error and returns a zero-score `Prediction`.

##### `eval_candidate_program_with_pruning(trial, trial_logs, trainset, candidate_program, evaluate, trial_num, batch_size=100)`
An Optuna-aware evaluation routine that evaluates a candidate in **incremental batches** and reports intermediate scores via `trial.report(...)`. If `trial.should_prune()` returns `True`, evaluation stops early and the trial is marked as pruned. Returns `(score, trial_logs, total_eval_size, pruned)`.

##### `get_program_with_highest_avg_score(param_score_dict, fully_evaled_param_combos)`
Used by Bayesian + minibatching optimizers. Computes the mean score for each categorical parameter combination and returns the program with the highest mean that has **not** yet been fully evaluated. Falls back to the last valid program if none qualify.

##### `calculate_last_n_proposed_quality(base_program, trial_logs, evaluate, trainset, devset, n)`
Measures whether recent proposals are improving over time by computing the average and best train/dev scores of the last `n` trials. Currently requires full evaluations (`full_eval=True`).

##### `create_n_fewshot_demo_sets(...)`
Generates multiple candidate few-shot demonstration sets for each predictor in the student. It mirrors the logic used by `BootstrapFewShotWithRandomSearch` so that optimizers sharing a random seed produce identical demo sets. It produces:

- **seed `-3`**: zero-shot (`student.reset_copy()`)
- **seed `-2`**: labels-only via `LabeledFewShot`
- **seed `-1`**: unshuffled few-shot via `BootstrapFewShot`
- **seeds `0..N`**: shuffled few-shot with randomized demo counts

> See [teleprompt_fewshot](teleprompt_fewshot.md) for `LabeledFewShot` and `BootstrapFewShot`.

#### Logging Utilities

| Function | Description |
| --- | --- |
| `print_full_program(program)` | Prints each predictor's instructions and output-field prefix. |
| `save_candidate_program(program, log_dir, trial_num, note=None)` | Serializes a candidate program to `<log_dir>/evaluated_programs/program_<trial_num>[_<note>].json`. Returns the save path (or `None` if `log_dir` is `None`). |
| `save_file_to_log_dir(source_file_path, log_dir)` | Copies an arbitrary file into the log directory. |
| `setup_logging(log_dir)` | Configures a root logger writing `WARNING`-level messages to `<log_dir>/logs.txt` and the console. |
| `get_task_model_history_for_full_example(candidate_program, task_model, devset, evaluate)` | Runs a single example and returns the task model's full interaction history. |

#### Token Accounting Utilities

##### `get_token_usage(model) -> tuple[int, int]`
Aggregates `prompt_tokens` and `completion_tokens` across a model's `history`, returning `(total_input_tokens, total_output_tokens)`. Returns `(0, 0)` if the model has no history.

##### `log_token_usage(trial_logs, trial_num, model_dict)`
Iterates over a `{model_name: model}` mapping and stores per-model token usage under `trial_logs[trial_num]["token_usage"]`.

#### Miscellaneous Helpers

| Function | Description |
| --- | --- |
| `get_prompt_model(prompt_model)` | Returns the provided prompt model, or falls back to `dspy.settings.lm`. |
| `get_signature(predictor)` | Returns `predictor.signature` (asserts the attribute exists). |
| `set_signature(predictor, updated_signature)` | Assigns a new signature to a predictor. |
| `old_getfile` / `new_getfile` | Patched versions of `inspect.getfile` that correctly resolve source files for classes defined in Jupyter notebooks. `inspect.getfile` is monkey-patched to `new_getfile` at import time. |

---

## Data Flow

The following diagram illustrates how a typical optimizer uses the core utilities during a `compile` cycle.

```mermaid
sequenceDiagram
    participant User
    participant Optimizer as Concrete Optimizer
    participant Core as Teleprompt Core Utils
    participant Eval as Evaluate
    participant Student as Module (student)

    User->>Optimizer: compile(student, trainset, ...)
    Optimizer->>Core: create_n_fewshot_demo_sets(...)
    Core-->>Optimizer: demo_candidates
    loop For each candidate
        Optimizer->>Core: eval_candidate_program(batch_size, ...)
        Core->>Eval: evaluate(candidate, devset)
        Eval-->>Core: EvaluationResult(score, results)
        Core-->>Optimizer: score
        Optimizer->>Core: save_candidate_program(program, log_dir, trial_num)
    end
    Optimizer->>Core: get_program_with_highest_avg_score(...)
    Core-->>Optimizer: best program
    Optimizer->>Core: log_token_usage(trial_logs, trial_num, model_dict)
    Optimizer-->>User: optimized Module
```

---

## Component Interaction

The core module acts as a shared substrate. Concrete optimizers depend on it, and it in turn depends on DSPy primitives and the evaluation subsystem.

```mermaid
graph TD
    TP[Teleprompter] -->|compile returns| MOD[Module]
    TP -->|consumes| EX[Example]

    U[utils.py] -->|create_minibatch / eval_candidate_program| EX
    U -->|create_n_fewshot_demo_sets| BFS[BootstrapFewShot]
    U -->|create_n_fewshot_demo_sets| LFS[LabeledFewShot]
    U -->|eval_candidate_program| EV[Evaluate]
    U -->|get_signature / set_signature| SIG[Signature]
    U -->|get_prompt_model| SET[Settings]

    BFS -->|inherits| TP
    LFS -->|inherits| TP
```

> **Note:** `create_n_fewshot_demo_sets` imports `BootstrapFewShot` and `LabeledFewShot` from `dspy.teleprompt.bootstrap`, creating a dependency from the core utilities back into the few-shot optimizer family. This is a deliberate coupling to guarantee demo-set reproducibility across optimizers.

---

## Process Flow: Candidate Evaluation with Pruning

```mermaid
flowchart TD
    Start([Start trial]) --> Split[Split trainset into batches]
    Split --> Loop{More batches?}
    Loop -->|Yes| Eval[Evaluate candidate on batch]
    Eval --> Accum[Accumulate weighted score]
    Accum --> Report[trial.report weighted avg]
    Report --> Prune{trial.should_prune?}
    Prune -->|Yes| MarkPruned[Mark trial pruned<br/>return early]
    Prune -->|No| Loop
    Loop -->|No| Full[Record full eval score]
    Full --> End([Return score, logs, size, pruned])
    MarkPruned --> End
```

---

## Design Principles

1. **Single interface, many algorithms.** `Teleprompter.compile` is the universal contract; every optimizer family implements it differently.
2. **Reproducibility first.** Utilities accept explicit `rng`/`seed` arguments so that optimizers sharing a seed produce identical demo sets and minibatches.
3. **Observability built-in.** Logging, program persistence, and token accounting are first-class utilities, enabling detailed trial logs for every optimizer.
4. **Graceful degradation.** Evaluation helpers catch exceptions and return zero-score predictions rather than crashing the optimization loop (subject to `max_errors`).
5. **Notebook-friendly.** The `inspect.getfile` monkey-patch ensures source resolution works inside Jupyter environments.

---

## Summary

The **Teleprompt Core** module is the backbone of DSPy's optimization framework. It provides:

- The **`Teleprompter`** abstract base class defining the `compile` contract.
- **Training utilities** for minibatching, candidate evaluation (with Optuna pruning), best-program selection, and few-shot demo-set generation.
- **Logging utilities** for program persistence and trial logging.
- **Token accounting utilities** for tracking model usage.
- **Miscellaneous helpers** for signature access and notebook-compatible source resolution.

All concrete optimizers — across the [few-shot](teleprompt_fewshot.md), [prompt](teleprompt_prompt.md), [weight](teleprompt_weight.md), and [meta](teleprompt_meta.md) families — build upon these foundations.
