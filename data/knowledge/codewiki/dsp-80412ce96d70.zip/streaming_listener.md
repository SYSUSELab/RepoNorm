# Streaming Listener Module

## Introduction

The `streaming_listener` module provides the core mechanism for **field-level streaming** in DSPy. While language models stream tokens incrementally, DSPy programs typically produce structured outputs (multiple named fields defined by a `Signature`). The `StreamListener` class bridges this gap: it watches the raw token stream emitted by an LM and extracts the tokens belonging to a *specific output field*, emitting clean `StreamResponse` objects as that field is generated.

This enables user interfaces to display, for example, only the `answer` field of a `ChainOfThought` predictor as it is being written, without exposing the intermediate `reasoning` field or the adapter's structural markers.

The module is part of the broader [streaming](streaming.md) subsystem and works closely with the [adapters](adapters.md) that define how structured outputs are serialized into text.

---

## Core Component

### `StreamListener`

`StreamListener` is the single core class in this module. It is a stateful, per-field parser that consumes raw `ModelResponseStream` chunks and produces `StreamResponse` objects.

```python
class StreamListener:
    def __init__(
        self,
        signature_field_name: str,
        predict: Any = None,
        predict_name: str | None = None,
        allow_reuse: bool = False,
    ): ...
```

#### Constructor Parameters

| Parameter | Type | Description |
|-----------|------|-------------|
| `signature_field_name` | `str` | The name of the output field to listen to (e.g. `"answer"`). |
| `predict` | `Any` | The predictor instance to listen to. If `None`, `streamify()` resolves it automatically by searching the program for a predictor whose signature contains the field. |
| `predict_name` | `str \| None` | The name of the predictor. Also auto-resolved when omitted. |
| `allow_reuse` | `bool` | If `True`, the listener resets its state after a stream ends so it can be reused for subsequent streams. Note: reuse can hurt performance because the same chunk is dispatched to multiple listeners. |

#### Internal State

The listener maintains several pieces of state that track its position within the token stream:

- `field_start_queue` — buffers tokens while searching for the field's start identifier.
- `field_end_queue` — a bounded buffer (max 10 tokens) holding recent tokens so the end identifier can be detected without leaking it into the output.
- `stream_start` / `stream_end` — flags marking the boundaries of the target field's content.
- `cache_hit` — set when the entire response arrives in a single chunk (e.g. a cache hit or a model that emits multi-token chunks).

---

## Adapter-Aware Parsing

The listener is **adapter-aware**. Different adapters serialize structured output using different delimiters, so the listener maintains a mapping of start/end identifiers per adapter:

| Adapter | Start Identifier | End Identifier | Start Indicator |
|---------|------------------|----------------|-----------------|
| `ChatAdapter` | `[[ ## {field} ## ]]` | `\[\[ ## (\w+) ## \]\]` | `[` |
| `JSONAdapter` | `"{field}":` | `\w*"(,\|\s*})` | `"` |
| `XMLAdapter` | `<{field}>` | `</{field}>` | `<` |

Only adapters listed in `ADAPTER_SUPPORT_STREAMING` (`ChatAdapter`, `XMLAdapter`, `JSONAdapter`) are supported. Any other adapter raises a `ValueError` at `receive()` time.

> See [adapters](adapters.md) for details on how each adapter formats and parses structured output.

---

## Streaming Process Flow

The `receive()` method is the heart of the listener. It is called once per streamed chunk and implements a small state machine.

```mermaid
flowchart TD
    A[receive chunk] --> B{stream_end?}
    B -- yes, allow_reuse --> C[Reset state]
    B -- yes, no reuse --> Z[return None]
    B -- no --> D[Extract delta.content]
    C --> D
    D --> E{content is None?}
    E -- yes --> Z
    E -- no --> F{start_identifier in chunk?}
    F -- yes --> G{end_identifier also present?}
    G -- yes --> H[cache_hit = True; stream_start = stream_end = True]
    G -- no --> I
    F -- no --> I{searching for start?}
    I -- yes --> J[Buffer tokens in field_start_queue]
    J --> K{full start_identifier found?}
    K -- yes --> L[stream_start = True; strip prefix]
    K -- partial match --> Z
    K -- no match --> M[Reset queue]
    L --> N
    I -- no, stream_started --> N[Buffer token in field_end_queue]
    N --> O{end_identifier found?}
    O -- yes --> P[stream_end = True; flush buffer]
    O -- no --> Q[Emit oldest buffered token]
    P --> R[return StreamResponse]
    Q --> R
```

### Step-by-step

1. **Reuse handling** — If the previous stream ended and `allow_reuse` is set, the listener clears its state and prepares for a new stream. Otherwise it returns immediately.
2. **Chunk extraction** — The delta content is read from `chunk.choices[0].delta.content`. `None` content (e.g. role-only chunks) is ignored.
3. **Cache-hit / single-chunk detection** — If both the start and end identifiers appear in a single chunk, the whole response arrived at once. The listener marks `cache_hit`, `stream_start`, and `stream_end` and returns.
4. **Start detection** — Tokens are buffered in `field_start_queue` until the full start identifier is assembled. Partial matches are retained; mismatches reset the queue. Once matched, the prefix (including the start identifier and, for JSON, a leading quote) is stripped.
5. **Content streaming** — Once started, each token is pushed into the bounded `field_end_queue`. When the queue exceeds 10 tokens, the oldest token is emitted as a `StreamResponse`. This delay ensures the end identifier is never leaked into the output.
6. **End detection** — When the end identifier is matched in the buffered tokens, `stream_end` is set and `flush()` emits the remaining buffered tokens (trimmed of the end identifier).

---

## Flushing and Boundary Trimming

The `flush()` method drains the `field_end_queue` and trims adapter-specific trailing markers so that only the field's actual value is returned:

- **`JSONAdapter`** — trims at the closing `",` or `"}` boundary.
- **`XMLAdapter`** — trims at the closing `</{field}>` tag.
- **`ChatAdapter`** (or `None`) — trims at the next `[[` marker.

This guarantees the consumer receives clean field content regardless of the adapter in use.

---

## Predictor Resolution

The module-level helper `find_predictor_for_stream_listeners(program, stream_listeners)` automatically binds listeners to predictors when the user has not specified one explicitly.

```mermaid
flowchart LR
    A[stream_listeners] --> B[Collect unresolved field names]
    B --> C[Iterate program.named_predictors]
    C --> D{field in output_fields?}
    D -- yes --> E{unique?}
    E -- no --> F[raise ValueError: not unique]
    E -- yes --> G{annotation is str?}
    G -- no --> H[raise ValueError: must be str]
    G -- yes --> I[Bind listener to predictor]
    I --> J[Group by predictor id]
```

### Resolution Rules

1. Listeners that already specify `predict` are skipped.
2. For each unresolved listener, the program's named predictors are scanned for one whose signature contains the target field.
3. **Uniqueness** — If more than one predictor exposes the field, a `ValueError` is raised; the user must specify the predictor explicitly.
4. **Type constraint** — The field must be annotated as `str`. Non-string fields raise a `ValueError`, since streaming only makes sense for textual output.
5. The result is a `defaultdict(list)` mapping `id(predictor)` → list of listeners, so multiple listeners can attach to the same predictor.

---

## Component Interaction

```mermaid
graph TD
    subgraph Streaming Subsystem
        SL[StreamListener]
        SR[StreamResponse]
        SM[StatusMessage / StatusStreamingCallback]
    end

    subgraph Adapters
        CA[ChatAdapter]
        JA[JSONAdapter]
        XA[XMLAdapter]
    end

    subgraph Core
        SIG[Signature]
        MOD[Module / Predict]
        SET[settings]
    end

    SL -->|reads adapter config| SET
    SL -->|identifiers per adapter| CA
    SL -->|identifiers per adapter| JA
    SL -->|identifiers per adapter| XA
    SL -->|emits| SR
    SL -->|resolved against| MOD
    MOD -->|output_fields| SIG
    SM -.->|parallel status stream| SR
```

- **`settings.adapter`** determines which identifier set the listener uses at runtime.
- **`Signature.output_fields`** defines the valid field names and their types.
- **`StreamResponse`** is the output dataclass (`predict_name`, `signature_field_name`, `chunk`) consumed by the streaming front-end.
- **`StatusStreamingCallback`** (in [streaming_messages](streaming_messages.md)) provides a complementary *status* stream (tool/LM/module lifecycle messages) that flows alongside field-level streaming.

---

## Data Flow

```mermaid
sequenceDiagram
    participant LM as Language Model
    participant Adapter as Adapter
    participant SL as StreamListener
    participant UI as Consumer / UI

    LM->>Adapter: raw token chunks
    Adapter->>SL: ModelResponseStream chunks
    loop each chunk
        SL->>SL: detect start identifier
        SL->>SL: buffer & emit field tokens
        SL->>SL: detect end identifier
        SL-->>UI: StreamResponse(predict_name, field, chunk)
    end
    SL->>SL: flush() remaining tokens
    SL-->>UI: final StreamResponse
```

---

## Usage Example

```python
import dspy
from dspy.streaming.streaming_listener import StreamListener

# Listen to the "answer" field of a ChainOfThought predictor
listener = StreamListener(signature_field_name="answer")

program = dspy.ChainOfThought("question -> answer")
stream = dspy.streamify(program, stream_listeners=[listener])

for chunk in stream(question="What is the capital of France?"):
    if isinstance(chunk, dspy.streaming.StreamResponse):
        print(chunk.chunk, end="", flush=True)
```

When `predict` is omitted, `streamify()` invokes `find_predictor_for_stream_listeners` to bind the listener automatically.

---

## Error Handling

| Condition | Exception |
|-----------|-----------|
| Unsupported adapter used with `receive()` | `ValueError` |
| Unsupported adapter used with `flush()` | `ValueError` |
| Field name not unique across predictors | `ValueError` |
| Field not found in any predictor | `ValueError` |
| Field annotation is not `str` | `ValueError` |

---

## Related Modules

- [streaming_messages](streaming_messages.md) — `StreamResponse`, `StatusMessage`, and `StatusStreamingCallback` for status streaming.
- [adapters](adapters.md) — `ChatAdapter`, `JSONAdapter`, `XMLAdapter` define the serialization formats the listener parses.
- [signatures](signatures.md) — `Signature` defines the output fields the listener targets.
- [primitives](primitives.md) — `Module` and `Predict` provide `named_predictors()` used for resolution.
- [dsp_utils](dsp_utils.md) — `settings` holds the active adapter used at runtime.
