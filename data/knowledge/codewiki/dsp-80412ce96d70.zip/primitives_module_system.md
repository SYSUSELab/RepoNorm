# Primitives Module System

## Introduction

The **Primitives Module System** is the foundational abstraction layer of DSPy. It defines the core building blocks that every DSPy program is composed of: the `BaseModule` (a parameter/sub-module container with serialization capabilities) and the `Module` (the user-facing program abstraction that orchestrates execution, callbacks, usage tracking, and batching).

This module answers the question: *"What is a DSPy program, and how does it hold, traverse, save, and execute its components?"* Every higher-level construct — `Predict`, `ChainOfThought`, `ReAct`, optimizers, and evaluators — ultimately derives from `Module` and relies on the traversal and serialization machinery defined here.

> **Scope of this document:** This page covers `dspy/primitives/base_module.py` (`BaseModule`) and `dspy/primitives/module.py` (`Module`, `ProgramMeta`). For the data containers used by modules, see [primitives_data_containers.md](primitives_data_containers.md). For the code execution primitive, see [primitives_python_interpreter.md](primitives_python_interpreter.md).

---

## Core Components

| Component | File | Role |
|-----------|------|------|
| `BaseModule` | `dspy/primitives/base_module.py` | Container base class: parameter/sub-module traversal, deep copy, state dump/load, save/load to disk. |
| `Module` | `dspy/primitives/module.py` | User-facing program abstraction: `__call__`/`acall`, callbacks, usage tracking, batching, LM management. |
| `ProgramMeta` | `dspy/primitives/module.py` | Metaclass guaranteeing every `Module` instance is properly initialized. |

---

## Architecture Overview

The module system is built as a two-layer hierarchy. `BaseModule` provides the *structural* capabilities (what a module *contains*), while `Module` adds the *behavioral* capabilities (what a module *does* when called).

```mermaid
graph TD
    subgraph "Primitives Module System"
        BM["BaseModule<br/>(structural layer)"]
        M["Module<br/>(behavioral layer)"]
        PM["ProgramMeta<br/>(metaclass)"]
    end

    PM -.->|"instantiates"| M
    M -->|"inherits"| BM

    subgraph "External Dependencies"
        PARAM["Parameter<br/>(predict_parameter)"]
        PRED["Predict<br/>(predict_core)"]
        EX["Example<br/>(data containers)"]
        PREDN["Prediction<br/>(data containers)"]
        SET["Settings<br/>(dsp_utils_settings)"]
        CB["BaseCallback<br/>(utils)"]
        UT["UsageTracker<br/>(utils)"]
        PAR["Parallel<br/>(predict_execution)"]
    end

    BM -->|"traverses"| PARAM
    BM -->|"traverses"| M
    M -->|"uses"| PRED
    M -->|"uses"| EX
    M -->|"uses"| PREDN
    M -->|"reads config"| SET
    M -->|"invokes"| CB
    M -->|"tracks"| UT
    M -->|"delegates batch"| PAR
```

### Layer Responsibilities

- **`BaseModule`** — Knows nothing about execution. It only understands *structure*: how to find parameters and sub-modules nested inside lists, tuples, and dicts; how to deep-copy itself; and how to serialize/deserialize its state.
- **`Module`** — Adds execution semantics on top of `BaseModule`. It defines the `forward`/`aforward` contract, wraps calls with callbacks and usage tracking, manages the LM used by its predictors, and provides parallel batch execution.

---

## BaseModule: The Structural Layer

`BaseModule` is the container abstraction. It treats a module as a tree of attributes that may contain `Parameter` objects, nested `Module`/`BaseModule` instances, or collections thereof.

### Parameter and Sub-module Traversal

Two traversal methods form the backbone of the system:

| Method | Purpose | Recursion behavior |
|--------|---------|--------------------|
| `named_parameters()` | Yields `(name, Parameter)` pairs | Recurses into sub-modules **unless** they are `_compiled` (frozen). Handles lists, tuples, and dicts. |
| `named_sub_modules(type_, skip_compiled)` | Yields `(name, BaseModule)` pairs | Breadth-first traversal using a `deque` and a `seen` set to avoid cycles/duplicates. |

The naming convention encodes the access path, e.g. `children[4]['key'].sub_module`. This path-based naming is what allows `map_named_predictors` and `set_attribute_by_name` to write back into deeply nested structures.

```mermaid
flowchart TD
    Start["named_parameters()"] --> CheckSelf{"self is a Parameter?"}
    CheckSelf -->|yes| AddSelf["add 'self'"]
    CheckSelf -->|no| IterAttrs["iterate self.__dict__"]
    AddSelf --> IterAttrs
    IterAttrs --> TypeCheck{"value type?"}
    TypeCheck -->|Parameter| AddParam["add (name, param)"]
    TypeCheck -->|Module| Compiled{"_compiled?"}
    Compiled -->|no| Recurse["recurse into sub-module<br/>prefix name"]
    Compiled -->|yes| Skip["skip (frozen)"]
    TypeCheck -->|list/tuple| IterList["add name[i] for each item"]
    TypeCheck -->|dict| IterDict["add name['key'] for each item"]
    AddParam --> Dedup["dedupe by id()"]
    Recurse --> Dedup
    IterList --> Dedup
    IterDict --> Dedup
    Dedup --> Result["list of (name, Parameter)"]
```

> **Key design note:** `named_parameters` deliberately differs from `named_sub_modules`. The former is *non-recursive into compiled modules* and deduplicates by object identity, while the latter is a general-purpose BFS over the whole module tree.

### Deep Copy Semantics

`deepcopy()` implements a *selective* deep copy: it attempts a full `copy.deepcopy`, but on failure falls back to a manual reconstruction that deep-copies `BaseModule` attributes and gracefully degrades to shallow/reference copies for un-copyable attributes (logging a warning). This makes modules resilient to holding non-picklable objects (e.g., live clients).

`reset_copy()` builds on `deepcopy()` and then calls `reset()` on every parameter — the standard mechanism used by optimizers to produce a fresh, untrained copy of a program.

### Serialization: State vs. Program

`BaseModule` supports two distinct persistence modes via `save()`:

```mermaid
flowchart TD
    Save["save(path, save_program, modules_to_serialize)"] --> Mode{"save_program?"}
    Mode -->|False| StateMode["State-only mode"]
    Mode -->|True| ProgMode["Program mode"]

    StateMode --> Ext{".json or .pkl?"}
    Ext -->|.json| Json["ujson.dump(state + metadata)"]
    Ext -->|.pkl| Pkl["cloudpickle.dump(state)"]
    Ext -->|other| Err["ValueError"]

    ProgMode --> DirCheck["validate path is a suffix-less dir"]
    DirCheck --> Reg["register_pickle_by_value(modules_to_serialize)"]
    Reg --> Dump["cloudpickle.dump(self) -> program.pkl"]
    Dump --> Meta["write metadata.json"]
```

| Mode | `save_program` | Output | Captures |
|------|----------------|--------|----------|
| State-only | `False` | `.json` or `.pkl` file | Only `dump_state()` output + dependency versions |
| Program | `True` | Directory (`program.pkl` + `metadata.json`) | Full architecture + state via cloudpickle |

Both modes embed **dependency versions** (via `get_dependency_versions()`). On `load()`, the system compares saved vs. current versions and emits a warning on mismatch — a safeguard against silent behavior changes across environments.

The `modules_to_serialize` argument registers custom modules with cloudpickle's `register_pickle_by_value`, ensuring user-defined modules are serialized *by value* rather than by reference.

### State Contract

`dump_state()` / `load_state()` define the serialization contract that subclasses override:

```python
def dump_state(self):
    return {name: param.dump_state() for name, param in self.named_parameters()}

def load_state(self, state):
    for name, param in self.named_parameters():
        param.load_state(state[name])
```

Each `Parameter` (e.g., `Predict`) is responsible for its own `dump_state`/`load_state`. See [predict_core.md](predict_core.md) for the `Predict` implementation.

---

## Module: The Behavioral Layer

`Module` extends `BaseModule` with execution semantics. It is the class users subclass to build custom DSPy programs.

### ProgramMeta: Guaranteed Initialization

`ProgramMeta` is a metaclass that intercepts instantiation to solve a common footgun: subclasses that forget to call `super().__init__()`. It:

1. Creates the instance via `cls.__new__` (bypassing `__init__`).
2. Calls `Module._base_init(obj)` to inject `_compiled`, `callbacks`, and `history`.
3. Calls the subclass `__init__`.
4. Backfills `callbacks` and `history` if the subclass `__init__` removed them.

```mermaid
sequenceDiagram
    participant User
    participant PM as ProgramMeta.__call__
    participant Obj as Module instance

    User->>PM: MyModule(args)
    PM->>Obj: cls.__new__(cls)
    PM->>Obj: Module._base_init(obj)
    Note over Obj: sets _compiled, callbacks, history
    PM->>Obj: cls.__init__(obj, args)
    PM->>Obj: backfill callbacks/history if missing
    PM-->>User: initialized instance
```

This guarantees that *every* module — even one with a broken `__init__` — has the attributes the framework depends on.

### The Call Contract: `__call__` and `acall`

Users invoke modules via `module(...)`, never `module.forward(...)` directly (a warning is emitted if they do — see `__getattribute__`). The `__call__` wrapper performs three cross-cutting concerns:

```mermaid
flowchart TD
    Call["module(*args, **kwargs)"] --> CBStart["@with_callbacks: on_module_start"]
    CBStart --> CallerCtx["push self onto settings.caller_modules"]
    CallerCtx --> Track{"settings.track_usage<br/>and no active tracker?"}
    Track -->|yes| Usage["open track_usage() context"]
    Track -->|no| Fwd["self.forward(*args, **kwargs)"]
    Usage --> Fwd
    Fwd --> SetUsage["output.set_lm_usage(total_tokens)"]
    SetUsage --> CBEnd["@with_callbacks: on_module_end"]
    Fwd --> CBEnd
    CBEnd --> Return["return output"]
```

1. **Callbacks** — The `@with_callbacks` decorator (from `dspy/utils/callback.py`) fires `on_module_start`/`on_module_end` around the call. See [utils.md](utils.md) for `BaseCallback`.
2. **Caller tracking** — The module appends itself to `settings.caller_modules`, enabling the framework to know the call stack of modules (used by streaming and adapters).
3. **Usage tracking** — When `settings.track_usage` is enabled and no tracker is already active, a `UsageTracker` context is opened and the aggregated token usage is attached to the output `Prediction` via `set_lm_usage`.

`acall` is the async mirror, delegating to `aforward`.

### Predictor Management

`Module` provides convenience methods over the `named_parameters` traversal, filtered to `Predict` instances:

| Method | Description |
|--------|-------------|
| `named_predictors()` | `(name, Predict)` pairs |
| `predictors()` | List of `Predict` instances |
| `set_lm(lm)` | Assigns an LM to every predictor |
| `get_lm()` | Returns the unique LM, or raises if multiple differ |
| `map_named_predictors(func)` | Applies `func` to each predictor and writes it back via `set_attribute_by_name` |

`set_attribute_by_name` uses the `magicattr` library to resolve path-based names like `children[4]['key'].sub_module` back to the actual attribute, enabling in-place replacement of nested predictors.

### Batch Execution

`Module.batch()` is a thin orchestration layer over the `Parallel` executor (see [predict_execution.md](predict_execution.md)). It:

1. Builds `(self, example.inputs())` execution pairs.
2. Constructs a `Parallel` executor with the requested thread/error settings.
3. Returns results, and optionally failed examples and exceptions.

```mermaid
sequenceDiagram
    participant User
    participant M as Module.batch
    participant P as Parallel
    participant PE as ParallelExecutor

    User->>M: batch(examples, num_threads, ...)
    M->>M: build exec_pairs [(self, inputs)]
    M->>P: Parallel(...)
    M->>P: forward(exec_pairs)
    P->>PE: execute(process_pair, exec_pairs)
    PE-->>P: results (+ failed, exceptions)
    P-->>M: results
    M-->>User: results
```

### History and Introspection

- `history` — A list of LM call records accumulated during execution.
- `inspect_history(n)` — Pretty-prints the last `n` history entries via `pretty_print_history`.
- `__repr__` — Renders each named predictor as `name = Predict(signature)`.

---

## Data Flow: A Single Module Call

The following diagram traces the full lifecycle of a module invocation, showing how the structural and behavioral layers interact with external subsystems.

```mermaid
flowchart LR
    subgraph Input
        Args["args / kwargs"]
    end

    subgraph "Module (behavioral)"
        Call["__call__"]
        CB["callbacks"]
        Ctx["settings.context<br/>caller_modules"]
        Fwd["forward()"]
    end

    subgraph "BaseModule (structural)"
        NP["named_parameters()"]
    end

    subgraph "External"
        Pred["Predict.forward"]
        Adapter["Adapter"]
        LM["LM"]
        Tracker["UsageTracker"]
    end

    Args --> Call
    Call --> CB
    Call --> Ctx
    Ctx --> Fwd
    Fwd --> Pred
    Pred --> Adapter
    Adapter --> LM
    LM --> Tracker
    Tracker -->|"set_lm_usage"| Call
    Fwd -->|"uses"| NP
```

---

## Component Interaction Summary

```mermaid
graph LR
    subgraph "primitives_module_system"
        BM["BaseModule"]
        M["Module"]
    end

    M -->|"is-a"| BM
    M -->|"manages"| Predict["Predict / Parameter"]
    M -->|"returns"| Prediction["Prediction"]
    M -->|"accepts"| Example["Example"]
    M -->|"reads"| Settings["Settings"]
    M -->|"notifies"| Callback["BaseCallback"]
    M -->|"tracks via"| Usage["UsageTracker"]
    M -->|"batches via"| Parallel["Parallel"]
    BM -->|"serializes"| Cloudpickle["cloudpickle / ujson"]
    BM -->|"versions"| Deps["get_dependency_versions"]
```

---

## Relationship to Other Modules

| Related Module | Relationship |
|----------------|--------------|
| [predict_core.md](predict_core.md) | `Predict` subclasses `Module` and `Parameter`; it is the primary leaf node traversed by `named_parameters`. |
| [predict_execution.md](predict_execution.md) | `Parallel` powers `Module.batch()`; `BestOfN`, `Refine`, etc. are themselves `Module` subclasses. |
| [primitives_data_containers.md](primitives_data_containers.md) | `Example` is the input type for `batch()`; `Prediction` is the output type carrying LM usage. |
| [dsp_utils_settings.md](dsp_utils_settings.md) | `Settings` provides `caller_modules`, `track_usage`, `trace`, and thread-local `context()`. |
| [utils.md](utils.md) | `BaseCallback` (via `@with_callbacks`) and `UsageTracker` provide cross-cutting concerns. |
| [signatures.md](signatures.md) | Signatures define the input/output fields that `Predict` (and thus `Module`) operates on. |
| [teleprompt.md](teleprompt.md) | Optimizers use `deepcopy()`/`reset_copy()` and `named_predictors()` to clone and mutate programs. |

---

## Key Design Decisions

1. **Two-layer separation** — Structural concerns (`BaseModule`) are isolated from execution concerns (`Module`), allowing the traversal/serialization machinery to be reused independently of execution.
2. **Path-based naming** — Encoding access paths as strings (`children[4]['key'].sub_module`) enables generic traversal and write-back without bespoke per-class logic.
3. **Compiled-module freezing** — `_compiled` modules are skipped during parameter traversal, allowing pre-compiled sub-programs to be treated as opaque, frozen units.
4. **Selective deep copy** — Graceful degradation from deep → shallow → reference copy makes modules robust to non-picklable attributes.
5. **Dual persistence modes** — State-only (portable, version-checked) vs. program (full architecture via cloudpickle) gives users a trade-off between portability and completeness.
6. **Metaclass initialization guarantee** — `ProgramMeta` ensures framework-critical attributes always exist, even with buggy subclass `__init__` methods.
7. **Cross-cutting concerns via wrappers** — Callbacks, caller tracking, and usage tracking are applied uniformly in `__call__`/`acall`, keeping `forward` implementations clean.
