# Retrievers Core

## Introduction

The `retrievers_core` module provides the foundational retrieval abstraction for DSPy. At its heart is the `Retrieve` class, a lightweight, configurable module that acts as the bridge between a DSPy program and a configured **Retrieval Model (RM)**. Rather than implementing any specific retrieval backend itself, `Retrieve` delegates the actual search work to whatever RM is registered in the global DSPy settings, normalizes the returned passages, and packages them into a `Prediction` object that downstream modules can consume.

This design cleanly separates the *interface* for retrieval (this module) from the *implementations* of retrieval (e.g., [retrievers_embeddings](retrievers_embeddings.md), [retrievers_databricks](retrievers_databricks.md), [retrievers_weaviate](retrievers_weaviate.md), and [dsp_retrieval](dsp_retrieval.md)).

---

## Core Component: `Retrieve`

`Retrieve` is a subclass of `Parameter` (from [predict_core](predict_core.md)) and is decorated with `with_callbacks` (from [utils](utils.md)) to support the DSPy callback system.

### Class Attributes

| Attribute | Value | Purpose |
|-----------|-------|---------|
| `name` | `"Search"` | Human-readable name used in prompts and traces. |
| `input_variable` | `"query"` | The name of the input field expected by the module. |
| `desc` | `"takes a search query and returns one or more potentially relevant passages from a corpus"` | Description used when the retriever is embedded in a signature. |

### Constructor

```python
def __init__(self, k=3, callbacks=None):
    self.stage = random.randbytes(8).hex()
    self.k = k
    self.callbacks = callbacks or []
```

- **`k`** — the default number of passages to retrieve.
- **`callbacks`** — an optional list of callback handlers invoked around each call.
- **`stage`** — a random hex identifier generated per instance, useful for distinguishing retriever instances in traces/logs.

### State Management

`Retrieve` participates in DSPy's serialization protocol:

- **`dump_state()`** — returns a dictionary containing the serializable configuration (`k`).
- **`load_state(state)`** — restores configuration values from a previously dumped state.
- **`reset()`** — a no-op, present to satisfy the module interface.

### The `forward` Method

The `forward` method is the heart of the module:

```python
def forward(self, query: str, k: int | None = None, **kwargs) -> list[str] | Prediction | list[Prediction]:
    k = k if k is not None else self.k

    import dspy

    if not dspy.settings.rm:
        raise AssertionError("No RM is loaded.")

    passages = dspy.settings.rm(query, k=k, **kwargs)

    from collections.abc import Iterable
    if not isinstance(passages, Iterable):
        passages = [passages]
    passages = [psg.long_text for psg in passages]

    return Prediction(passages=passages)
```

Key behaviors:

1. **Per-call override** — the `k` argument overrides the instance default when provided.
2. **RM resolution** — the active retrieval model is fetched from `dspy.settings.rm`. If none is configured, an `AssertionError` is raised.
3. **Delegation** — the query (plus any extra `kwargs`) is forwarded to the RM's `__call__`.
4. **Normalization** — the result is coerced into an iterable, then each passage's `long_text` field is extracted into a flat list of strings.
5. **Packaging** — the list of passage strings is wrapped in a `Prediction(passages=...)`.

### The `__call__` Method

`__call__` is wrapped with `@with_callbacks` and simply delegates to `forward`. This ensures that any configured callbacks (global or instance-level) fire around the retrieval operation.

---

## Architecture

The following diagram shows how `Retrieve` sits between a DSPy program and the configured retrieval backend.

```mermaid
graph TD
    Program["DSPy Program / Module"] -->|"query"| Retrieve["Retrieve (retrievers_core)"]
    Retrieve -->|"reads rm"| Settings["dspy.settings (dsp_utils_settings)"]
    Settings -->|"rm instance"| RM["Retrieval Model (RM)"]
    Retrieve -->|"query, k, kwargs"| RM
    RM -->|"passages"| Retrieve
    Retrieve -->|"Prediction(passages=...)"| Program

    subgraph "RM Implementations"
        RM --> Embeddings["Embeddings (retrievers_embeddings)"]
        RM --> Databricks["DatabricksRM (retrievers_databricks)"]
        RM --> Weaviate["WeaviateRM (retrievers_weaviate)"]
        RM --> ColBERT["ColBERTv2 (dsp_retrieval)"]
    end
```

---

## Component Dependencies

`Retrieve` depends on several other DSPy modules. The diagram below maps these relationships.

```mermaid
graph LR
    Retrieve["Retrieve"] -->|"inherits"| Parameter["Parameter (predict_core)"]
    Retrieve -->|"returns"| Prediction["Prediction (primitives_data_containers)"]
    Retrieve -->|"decorated by"| with_callbacks["with_callbacks (utils)"]
    Retrieve -->|"reads config from"| Settings["dspy.settings (dsp_utils_settings)"]
    Retrieve -->|"delegates to"| RM["Configured RM"]
```

| Dependency | Module | Role |
|------------|--------|------|
| `Parameter` | [predict_core](predict_core.md) | Base class providing the module/parameter interface. |
| `Prediction` | [primitives_data_containers](primitives_data_containers.md) | Output container holding the retrieved `passages`. |
| `with_callbacks` | [utils](utils.md) | Decorator enabling callback hooks on `__call__`. |
| `dspy.settings` | [dsp_utils_settings](dsp_utils_settings.md) | Global/thread-local configuration holding the active `rm`. |

---

## Data Flow

The sequence below illustrates a single retrieval call from a program through to the returned prediction.

```mermaid
sequenceDiagram
    participant P as DSPy Program
    participant R as Retrieve
    participant S as dspy.settings
    participant RM as Retrieval Model

    P->>R: __call__(query, k=...)
    R->>R: with_callbacks start handlers
    R->>R: forward(query, k)
    R->>S: read settings.rm
    alt No RM configured
        R-->>P: AssertionError("No RM is loaded.")
    else RM configured
        R->>RM: rm(query, k=k, **kwargs)
        RM-->>R: passages (iterable of objects)
        R->>R: normalize to [psg.long_text, ...]
        R->>R: Prediction(passages=...)
        R-->>P: Prediction
    end
    R->>R: with_callbacks end handlers
```

---

## Process Flow: Passage Normalization

The `forward` method performs a small but important normalization pipeline to guarantee a consistent output shape regardless of the underlying RM's return type.

```mermaid
flowchart TD
    Start["passages = rm(query, k=k, **kwargs)"] --> CheckIter{"Is passages an Iterable?"}
    CheckIter -->|No| Wrap["passages = [passages]"]
    CheckIter -->|Yes| Keep["keep as-is"]
    Wrap --> Extract
    Keep --> Extract["passages = [psg.long_text for psg in passages]"]
    Extract --> Build["return Prediction(passages=passages)"]
```

This ensures that even RMs returning a single passage object (rather than a list) are handled gracefully, and that all downstream consumers receive a uniform `Prediction` with a `passages` field.

---

## Usage Example

```python
import dspy

# Configure a retrieval model (any RM implementation)
dspy.settings.configure(rm=my_retriever_model)

# Create a Retrieve module
retrieve = dspy.Retrieve(k=5)

# Perform a retrieval
result = retrieve("What are the stages of public works planning?")
print(result.passages)  # list of passage strings
```

The `Retrieve` module is also commonly used inside larger programs:

```python
class RAG(dspy.Module):
    def __init__(self, num_passages=3):
        super().__init__()
        self.retrieve = dspy.Retrieve(k=num_passages)
        self.generate = dspy.ChainOfThought("context, question -> answer")

    def forward(self, question):
        context = self.retrieve(question).passages
        return self.generate(context=context, question=question)
```

---

## Relationship to Other Retriever Modules

`retrievers_core` defines the *interface*; the sibling modules provide *implementations* that can be plugged in as the configured RM:

| Module | Description |
|--------|-------------|
| [retrievers_embeddings](retrievers_embeddings.md) | In-memory embedding-based retrieval with optional FAISS indexing. |
| [retrievers_databricks](retrievers_databricks.md) | Databricks Mosaic AI Vector Search integration. |
| [retrievers_weaviate](retrievers_weaviate.md) | Weaviate vector database integration. |
| [dsp_retrieval](dsp_retrieval.md) | ColBERTv2 and DPR-based retrieval utilities. |

Because `Retrieve` only depends on the `rm` callable's contract (accepting a query and `k`, returning objects with a `long_text` attribute), any of these implementations—or a custom one—can be used interchangeably.

---

## Notes and Caveats

- **`single_query_passage` helper** — a module-level function that transposes a list of passage dictionaries into a column-oriented dictionary and renames `long_text` to `passages`. It is defined but not used by `Retrieve.forward` directly; it exists as a utility for converting batched passage results into a `Prediction`.
- **RM contract** — the configured RM must return objects exposing a `long_text` attribute. RMs that return plain strings or differently-named fields will not work without adaptation.
- **No caching** — `Retrieve` itself performs no caching; caching (if any) is the responsibility of the underlying RM.
- **TODO in source** — the source notes a possible future enhancement to use `Prediction.from_completions` with per-query passage sets.
