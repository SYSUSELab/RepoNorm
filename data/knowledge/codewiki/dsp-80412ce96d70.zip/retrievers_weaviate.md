# Weaviate Retriever Module

## Introduction

The `retrievers_weaviate` module provides `WeaviateRM`, a retrieval module (RM) that integrates [Weaviate](https://weaviate.io/) — an open-source vector database — with DSPy. It allows DSPy programs to retrieve the top-k most relevant passages from a Weaviate collection for a given query, using Weaviate's hybrid search capabilities.

This module is one of several retriever backends available in DSPy. For an overview of the retriever abstraction and how retrievers plug into DSPy programs, see the [Retrievers Core documentation](retrievers_core.md). For alternative backends, see [Databricks RM](retrievers_databricks.md) and [Embeddings](retrievers_embeddings.md).

---

## Purpose and Core Functionality

`WeaviateRM` extends `dspy.Retrieve` (see [Retrievers Core](retrievers_core.md)) and implements the retrieval interface against a Weaviate collection. Its responsibilities are:

1. **Query execution** — Run hybrid (keyword + vector) searches against a Weaviate collection and return the top-k matching passages.
2. **Multi-query support** — Accept either a single query string or a list of queries and aggregate the results.
3. **Multi-tenancy** — Optionally scope queries to a specific Weaviate tenant.
4. **Data management** — Provide helper methods to read objects (`get_objects`) and insert new objects (`insert`) into the collection.
5. **Client version compatibility** — Support both the Weaviate Python client v3 (`weaviate.Client`) and v4 (`weaviate.WeaviateClient`).

---

## Architecture

`WeaviateRM` sits within the DSPy retrieval subsystem. It inherits from `Retrieve`, which itself is a `Parameter` (a DSPy primitive). The module depends on the external `weaviate` Python client and returns `Prediction` objects.

```mermaid
graph TD
    subgraph DSPy Core
        Retrieve["Retrieve<br/>(retrievers_core)"]
        Parameter["Parameter<br/>(predict_core)"]
        Prediction["Prediction<br/>(primitives_data_containers)"]
        dotdict["dotdict<br/>(dsp_utils_utilities)"]
    end

    subgraph retrievers_weaviate
        WeaviateRM["WeaviateRM"]
    end

    subgraph External
        WeaviateClient["weaviate Python client<br/>(v3 Client / v4 WeaviateClient)"]
        WeaviateDB[("Weaviate<br/>Vector Database")]
    end

    Parameter --> Retrieve
    Retrieve --> WeaviateRM
    WeaviateRM --> Prediction
    WeaviateRM --> dotdict
    WeaviateRM --> WeaviateClient
    WeaviateClient --> WeaviateDB
```

### Key Relationships

| Component | Role | Reference |
|-----------|------|-----------|
| `Retrieve` | Base class defining the retrieval interface (`forward`, `k`, callbacks) | [retrievers_core.md](retrievers_core.md) |
| `Parameter` | DSPy primitive that `Retrieve` extends | [predict_core.md](predict_core.md) |
| `Prediction` | Return type wrapping retrieved passages | [primitives_data_containers.md](primitives_data_containers.md) |
| `dotdict` | Attribute-accessible dict used to wrap each passage | [dsp_utils_utilities.md](dsp_utils_utilities.md) |
| `weaviate` client | External dependency for communicating with the database | — |

---

## Component: `WeaviateRM`

### Constructor

```python
WeaviateRM(
    weaviate_collection_name: str,
    weaviate_client: weaviate.WeaviateClient | weaviate.Client,
    weaviate_collection_text_key: str | None = "content",
    k: int = 3,
    tenant_id: str | None = None,
)
```

| Parameter | Type | Description |
|-----------|------|-------------|
| `weaviate_collection_name` | `str` | Name of the Weaviate collection to query. |
| `weaviate_client` | `WeaviateClient \| Client` | An initialized Weaviate client (v4 or v3). |
| `weaviate_collection_text_key` | `str \| None` | Property key holding the passage text. Defaults to `"content"`. |
| `k` | `int` | Default number of top passages to retrieve. Defaults to `3`. |
| `tenant_id` | `str \| None` | Optional tenant to scope retrieval to. |

During initialization, the module:

1. Resolves the collection via `weaviate_client.collections.get(...)`.
2. Detects the client version by inspecting attributes:
   - `collections` attribute → `"WeaviateClient"` (v4)
   - `query` attribute → `"Client"` (v3)
   - Otherwise raises `ValueError("Unsupported Weaviate client type")`.
3. Calls `super().__init__(k=k)` to initialize the base `Retrieve`.

> **Note:** The `weaviate` package is an optional dependency. If it is not installed, importing this module raises an `ImportError` instructing the user to install `dspy-ai[weaviate]`.

### Methods

#### `forward(query_or_queries, k=None, **kwargs) -> Prediction`

Performs the retrieval. Accepts a single query string or a list of queries, filters out empty queries, and runs a hybrid search for each. Results are aggregated into a list of `dotdict` objects, each with a `long_text` key.

- **`k`** overrides the instance default when provided.
- **`tenant_id`** can be passed via `kwargs` to override the instance-level tenant.
- Additional `**kwargs` are forwarded to the Weaviate hybrid query.

The behavior branches on the detected client type:

```mermaid
flowchart TD
    Start([forward called]) --> ResolveK["Resolve k = k or self.k"]
    ResolveK --> Normalize["Normalize query_or_queries to list"]
    Normalize --> Filter["Filter out empty queries"]
    Filter --> Loop{"For each query"}
    Loop --> ClientType{"Client type?"}
    ClientType -->|WeaviateClient v4| V4["collection.query.hybrid(...)<br/>optionally .with_tenant(tenant)"]
    ClientType -->|Client v3| V3["client.query.get(...)<br/>.with_hybrid(...).with_limit(k).do()"]
    V4 --> Parse["Extract text via collection_text_key"]
    V3 --> Parse
    Parse --> Wrap["Wrap each result in dotdict(long_text=...)"]
    Wrap --> Loop
    Loop -->|done| Return["Return aggregated passages"]
```

#### `get_objects(num_samples, fields) -> list[dict]`

Retrieves up to `num_samples` objects from the collection using the cursor/iterator API, returning only the requested `fields`.

- **Supported only for the v4 client** (`WeaviateClient`). Raises `ValueError` for v3.
- Tenancy scoping is not yet applied (marked as a TODO in the source).

#### `insert(new_object_properties)`

Inserts a new object into the collection with a generated UUID.

- **Supported only for the v4 client.** Raises `AttributeError` for v3.
- Tenancy scoping is not yet applied (marked as a TODO in the source).

---

## Data Flow

The following diagram shows how a query flows from a DSPy program through `WeaviateRM` to the Weaviate database and back.

```mermaid
sequenceDiagram
    participant Program as DSPy Program
    participant Retrieve as dspy.Retrieve
    participant RM as WeaviateRM
    participant Client as Weaviate Client
    participant DB as Weaviate DB

    Program->>Retrieve: __call__(query, k)
    Retrieve->>RM: forward(query, k)
    RM->>RM: normalize queries, resolve k & tenant
    loop each query
        RM->>Client: hybrid(query, limit=k)
        Client->>DB: hybrid search request
        DB-->>Client: matching objects
        Client-->>RM: results
        RM->>RM: extract text, wrap in dotdict
    end
    RM-->>Retrieve: list[dotdict(long_text=...)]
    Retrieve->>Retrieve: map to Prediction(passages=[...])
    Retrieve-->>Program: Prediction
```

> **Important:** `WeaviateRM.forward` returns a list of `dotdict` passages (each with a `long_text` field), **not** a `Prediction`. The base `Retrieve.forward` wraps these into a `Prediction(passages=...)`. This matches the convention used by other DSPy retrievers — see [Retrievers Core](retrievers_core.md).

---

## Usage

### As the default retriever

```python
import weaviate
import dspy

llm = dspy.Cohere(model="command-r-plus", api_key=api_key)
weaviate_client = weaviate.connect_to_local()  # or connect_to_wcs / custom / embedded
retriever_model = WeaviateRM("my_collection_name", weaviate_client=weaviate_client)
dspy.settings.configure(lm=llm, rm=retriever_model)

retrieve = dspy.Retrieve(k=1)
topK_passages = retrieve("what are the stages in planning, sanctioning and execution of public works").passages
```

### Inside a module's `forward()`

```python
self.retrieve = WeaviateRM("my_collection_name", weaviate_client=weaviate_client, k=num_passages)
```

### Expected collection payload

The collection is assumed to contain a property (default key `"content"`) holding the passage text. The text key can be customized via `weaviate_collection_text_key`.

---

## Client Version Compatibility

`WeaviateRM` transparently supports two generations of the Weaviate Python client. The table below summarizes the differences.

| Feature | v4 (`WeaviateClient`) | v3 (`Client`) |
|---------|----------------------|---------------|
| Detection attribute | `collections` | `query` |
| Query API | `collection.query.hybrid(...)` | `client.query.get(...).with_hybrid(...).do()` |
| Tenant scoping | `.with_tenant(tenant)` | `.with_tenant(tenant)` |
| `get_objects` | ✅ Supported | ❌ Raises `ValueError` |
| `insert` | ✅ Supported | ❌ Raises `AttributeError` |

---

## Dependencies

```mermaid
graph LR
    WeaviateRM --> dspy["dspy (Retrieve, settings)"]
    WeaviateRM --> dotdict["dspy.dsp.utils.dotdict"]
    WeaviateRM --> Prediction["dspy.primitives.prediction.Prediction"]
    WeaviateRM -.optional.-> weaviate["weaviate (external)"]
    WeaviateRM -.optional.-> uuid["uuid (stdlib)"]
```

- **`dspy`** — base `Retrieve` class and settings.
- **`dspy.dsp.utils.dotdict`** — attribute-accessible dict for passages.
- **`dspy.primitives.prediction.Prediction`** — return type.
- **`weaviate`** — optional external dependency (install via `pip install dspy-ai[weaviate]`).
- **`uuid`** — standard library, used to generate object UUIDs on insert.

---

## Related Modules

- [Retrievers Core](retrievers_core.md) — the `Retrieve` base class and retrieval abstraction.
- [Retrievers Embeddings](retrievers_embeddings.md) — local embeddings-based retriever.
- [Retrievers Databricks](retrievers_databricks.md) — Databricks Vector Search retriever.
- [Primitives Data Containers](primitives_data_containers.md) — `Prediction` and `Example`.
- [DSP Utils Utilities](dsp_utils_utilities.md) — `dotdict` and related helpers.
