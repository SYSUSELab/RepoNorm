# Predict Core Module

## Introduction

The `predict_core` module is the foundational building block of DSPy's prediction system. It provides the two most fundamental abstractions that all other prediction modules are built upon:

- **`Predict`** — The atomic, single-step prediction module that maps a `Signature` (input/output specification) to an LM call, handling preprocessing, adapter selection, streaming, and postprocessing.
- **`Parameter`** — A marker base class that identifies objects as trainable/optimizable parameters within a DSPy program.

Every higher-level module in the `predict` package (e.g., `ChainOfThought`, `ReAct`, `ProgramOfThought`) ultimately composes or subclasses `Predict`. Understanding this module is essential to understanding how DSPy programs execute and how they are optimized.

---

## Module Overview

The `predict_core` module consists of two files:

| File | Core Component | Responsibility |
|------|----------------|----------------|
| `dspy/predict/predict.py` | `Predict` | Executes a single LM call against a signature; manages demos, config, LM selection, streaming, and state serialization. |
| `dspy/predict/parameter.py` | `Parameter` | Empty marker class used by `BaseModule.named_parameters()` to discover optimizable parameters. |

---

## Architecture

`Predict` sits at the intersection of several subsystems. It inherits from both `Module` (execution/parameter discovery) and `Parameter` (optimization marker), and it orchestrates the `Adapter`, `LM`, `Signature`, and `Settings` subsystems.

```mermaid
graph TD
    subgraph predict_core["predict_core"]
        Predict["Predict<br/>(Module, Parameter)"]
        Parameter["Parameter<br/>(marker)"]
    end

    subgraph primitives["primitives"]
        Module["Module"]
        BaseModule["BaseModule"]
        Prediction["Prediction"]
    end

    subgraph signatures["signatures"]
        Signature["Signature"]
    end

    subgraph adapters["adapters"]
        Adapter["Adapter"]
        ChatAdapter["ChatAdapter"]
    end

    subgraph clients["clients"]
        BaseLM["BaseLM"]
        LM["LM"]
    end

    subgraph settings["dsp_utils"]
        Settings["Settings"]
    end

    Predict -->|inherits| Module
    Predict -->|inherits| Parameter
    Module -->|inherits| BaseModule
    Predict -->|produces| Prediction
    Predict -->|uses| Signature
    Predict -->|uses| Adapter
    Adapter -->|subclass| ChatAdapter
    Predict -->|uses| BaseLM
    BaseLM -->|subclass| LM
    Predict -->|reads config| Settings
    BaseModule -->|discovers| Parameter
```

### Key Relationships

- **`Predict` → `Module`**: `Predict` inherits `__call__`/`acall` (which wrap `forward`/`aforward` with callbacks, usage tracking, and caller-module context) from `Module`. See [primitives.md](primitives.md) for details on `Module` and `BaseModule`.
- **`Predict` → `Parameter`**: By inheriting `Parameter`, a `Predict` instance is discovered by `BaseModule.named_parameters()` and thus becomes a target for optimizers/teleprompters. See [teleprompt.md](teleprompt.md).
- **`Predict` → `Adapter`**: The adapter converts the signature + demos + inputs into LM messages and parses the LM output back into structured fields. See [adapters_core.md](adapters_core.md).
- **`Predict` → `BaseLM`/`LM`**: The LM performs the actual model call. See [clients_lm.md](clients_lm.md).
- **`Predict` → `Settings`**: Global/thread-local configuration (`settings.lm`, `settings.adapter`, `settings.trace`, `settings.stream_listeners`, `settings.send_stream`) drives runtime behavior. See [dsp_utils_settings.md](dsp_utils_settings.md).

---

## The `Predict` Class

### Construction

```python
Predict(signature: str | type[Signature], callbacks: list[BaseCallback] | None = None, **config)
```

- `signature` is normalized via `ensure_signature(...)`, allowing either a string shorthand (e.g., `"question -> answer"`) or a `Signature` subclass.
- `**config` stores default LM kwargs (e.g., `temperature`, `n`) that are merged into each call.
- A random `stage` hex string is generated (used for tracking/identification).
- `reset()` initializes `lm`, `traces`, `train`, and `demos`.

### Execution Flow

The core execution path is `__call__` → `Module.__call__` → `forward` → `_forward_preprocess` → `Adapter` → `_forward_postprocess`.

```mermaid
sequenceDiagram
    participant User
    participant Predict
    participant Module
    participant Preprocess as _forward_preprocess
    participant Adapter
    participant LM
    participant Postprocess as _forward_postprocess

    User->>Predict: predict(**kwargs)
    Predict->>Predict: reject positional args
    Predict->>Module: super().__call__(**kwargs)
    Module->>Predict: forward(**kwargs)
    Predict->>Preprocess: resolve lm, config, signature, demos
    Preprocess-->>Predict: (lm, config, signature, demos, kwargs)
    Predict->>Predict: _should_stream()
    alt streaming enabled
        Predict->>Adapter: adapter(lm, ..., caller_predict=self)
    else no streaming
        Predict->>Adapter: adapter(lm, ..., send_stream=None)
    end
    Adapter->>LM: lm(messages=..., **lm_kwargs)
    LM-->>Adapter: raw completions
    Adapter-->>Predict: parsed field dicts
    Predict->>Postprocess: Prediction.from_completions(...)
    Postprocess-->>User: Prediction
```

### `_forward_preprocess`

This method resolves the "three privileged keyword arguments" and validates the LM:

1. **`signature`** — overrides the instance signature for this call.
2. **`demos`** — overrides the instance demos (few-shot examples).
3. **`config`** — merged on top of `self.config`.
4. **`lm`** — resolved from call kwarg → `self.lm` → `settings.lm`. Raises a descriptive error if none is set, or if a string (rather than a `BaseLM` instance) is passed.
5. **Temperature adjustment** — if `temperature` is unset or `<= 0.15` and `n > 1`, temperature is bumped to `0.7` to preserve sampling randomness.
6. **Predicted outputs** — a `prediction` kwarg in OpenAI's predicted-outputs format is moved from inputs into the LM config.
7. **Missing input warning** — logs a warning if not all signature input fields are provided.

### `_forward_postprocess`

Wraps the adapter's completions into a `Prediction` via `Prediction.from_completions(...)`, and appends a trace entry `(self, kwargs, pred)` to `settings.trace` when tracing is enabled. See [primitives.md](primitives.md) for `Prediction`.

### Streaming

`_should_stream()` decides whether to stream based on `settings.send_stream` and `settings.stream_listeners`. Streaming is only enabled if a listener is registered specifically for this `Predict` instance. When streaming, the call is wrapped in `settings.context(caller_predict=self)`; otherwise `send_stream=None` is forced. See [streaming.md](streaming.md).

### State Management

`Predict` supports serialization for saving/loading compiled programs:

- **`dump_state()`** — serializes `traces`, `train`, `demos` (with `BaseModel` fields converted via `serialize_object`), the signature state, and the LM state.
- **`load_state(state)`** — restores the above; `signature` and `lm` are handled specially. Loading a legacy `extended_signature` raises `NotImplementedError` (removed in DSPy 2.6+).

The `serialize_object` helper recursively converts Pydantic models, lists, tuples, and dicts into JSON-compatible structures.

### Configuration Helpers

- `update_config(**kwargs)` — merges new defaults into `self.config`.
- `get_config()` — returns the current config.

---

## The `Parameter` Class

```python
class Parameter:
    pass
```

`Parameter` is an intentionally empty marker class. Its sole purpose is to be used with `isinstance` checks in `BaseModule.named_parameters()` (see [primitives.md](primitives.md)). Any object that should be treated as a trainable/optimizable parameter of a DSPy program must inherit from `Parameter`.

Because `Predict` inherits from `Parameter`, every `Predict` instance inside a module is automatically discovered by:

- `Module.named_predictors()` / `Module.predictors()`
- `Module.set_lm()` / `Module.get_lm()`
- `Module.dump_state()` / `Module.load_state()`

This is what allows optimizers (teleprompters) to find and mutate predictors. See [teleprompt.md](teleprompt.md).

---

## Component Interaction Diagram

```mermaid
classDiagram
    class Parameter {
        <<marker>>
    }
    class BaseModule {
        +named_parameters()
        +dump_state()
        +load_state()
    }
    class Module {
        +__call__()
        +acall()
        +forward()
        +aforward()
        +named_predictors()
    }
    class Predict {
        +signature
        +config
        +lm
        +demos
        +forward()
        +aforward()
        +_forward_preprocess()
        +_forward_postprocess()
        +dump_state()
        +load_state()
    }
    class Adapter {
        +__call__()
        +acall()
        +format()
        +parse()
    }
    class BaseLM {
        +__call__()
        +forward()
    }

    BaseModule <|-- Module
    Parameter <|-- Predict
    Module <|-- Predict
    Predict ..> Adapter : uses
    Predict ..> BaseLM : uses
```

---

## Data Flow

The following diagram shows how data flows from a user call through to a `Prediction`:

```mermaid
flowchart LR
    A["User kwargs<br/>(input fields)"] --> B["_forward_preprocess"]
    B --> C["Resolved:<br/>lm, config, signature, demos"]
    C --> D["Adapter.format()"]
    D --> E["LM messages"]
    E --> F["LM call"]
    F --> G["Raw completions"]
    G --> H["Adapter.parse()"]
    H --> I["Field dicts"]
    I --> J["Prediction.from_completions()"]
    J --> K["Prediction"]
    K --> L["Optional trace append"]
```

---

## Positional Argument Enforcement

`Predict` explicitly forbids positional arguments in both `__call__` and `acall`, raising a `ValueError` with a helpful message listing the expected input field names. This enforces the keyword-argument convention that matches signature input fields.

---

## Related Modules

- [primitives.md](primitives.md) — `Module`, `BaseModule`, `Prediction`, `Example` (the execution and parameter-discovery foundation).
- [signatures.md](signatures.md) — `Signature` and `SignatureMeta` (the input/output specification).
- [adapters_core.md](adapters_core.md) — `Adapter`, `ChatAdapter`, `JSONAdapter` (message formatting and parsing).
- [clients_lm.md](clients_lm.md) — `BaseLM`, `LM` (the underlying language model interface).
- [dsp_utils_settings.md](dsp_utils_settings.md) — `Settings` (global/thread-local configuration).
- [streaming.md](streaming.md) — `StreamListener` and streaming callbacks.
- [predict_reasoning.md](predict_reasoning.md) — `ChainOfThought`, `ProgramOfThought`, `MultiChainComparison` (built on `Predict`).
- [predict_agents.md](predict_agents.md) — `ReAct`, `CodeAct` (built on `Predict`).
- [predict_execution.md](predict_execution.md) — `Parallel`, `BestOfN`, `Refine`, `KNN` (execution strategies built on `Predict`).
- [teleprompt.md](teleprompt.md) — optimizers that discover and mutate `Predict` parameters.
