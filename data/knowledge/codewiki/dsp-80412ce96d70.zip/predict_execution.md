# Predict Execution Module

## Introduction

The **predict_execution** module provides a collection of execution strategies that wrap, orchestrate, or augment the behavior of DSPy modules. Unlike the core `Predict` primitive (see [predict_core.md](predict_core.md)) which performs a single LM call, or the reasoning modules (see [predict_reasoning.md](predict_reasoning.md)) which add structured reasoning, the components in this module focus on **how** a module is executed:

- **Parallel** — runs a module over many inputs concurrently.
- **BestOfN** — samples a module multiple times and selects the best result by reward.
- **Refine** — like `BestOfN`, but generates natural-language feedback to improve subsequent attempts.
- **KNN** — a k-nearest-neighbor retriever over a training set, commonly used for few-shot example selection.

These components are building blocks for higher-level optimization and inference workflows, and they are frequently consumed by teleprompters (see [teleprompt.md](teleprompt.md)) and evaluation utilities (see [evaluate.md](evaluate.md)).

---

## Module Architecture

The module is organized around four independent execution strategies that share common infrastructure from the primitives, clients, and utilities layers.

```mermaid
graph TD
    subgraph predict_execution["predict_execution module"]
        Parallel["Parallel<br/>(parallel.py)"]
        BestOfN["BestOfN<br/>(best_of_n.py)"]
        Refine["Refine<br/>(refine.py)"]
        OfferFeedback["OfferFeedback<br/>(refine.py)"]
        KNN["KNN<br/>(knn.py)"]
    end

    subgraph primitives["primitives"]
        Module["Module"]
        Example["Example"]
        Prediction["Prediction"]
    end

    subgraph utils["utils"]
        ParallelExecutor["ParallelExecutor"]
        Settings["Settings"]
    end

    subgraph clients["clients"]
        Embedder["Embedder"]
        LM["LM"]
    end

    subgraph signatures["signatures"]
        Signature["Signature"]
    end

    Parallel --> ParallelExecutor
    Parallel --> Example
    Parallel --> Settings

    BestOfN --> Module
    BestOfN --> Prediction
    BestOfN --> LM

    Refine --> Module
    Refine --> OfferFeedback
    Refine --> Prediction
    Refine --> LM
    OfferFeedback --> Signature

    KNN --> Embedder
    KNN --> Example
```

---

## Component Overview

| Component | File | Base / Type | Primary Responsibility |
|-----------|------|-------------|------------------------|
| `Parallel` | `dspy/predict/parallel.py` | Plain class | Concurrent execution of a module over many inputs |
| `BestOfN` | `dspy/predict/best_of_n.py` | `Module` | Sample N times, return best by reward |
| `Refine` | `dspy/predict/refine.py` | `Module` | Sample N times with feedback-driven refinement |
| `OfferFeedback` | `dspy/predict/refine.py` | `Signature` | Generate per-module advice from a failed trajectory |
| `KNN` | `dspy/predict/knn.py` | Plain class | k-nearest-neighbor retrieval over a training set |

---

## Parallel

`Parallel` executes a module across a list of inputs using a thread pool. It is the engine behind `Module.batch(...)` (see [primitives.md](primitives.md)).

### Key Responsibilities

- Dispatch `(module, example)` pairs to a `ParallelExecutor`.
- Normalize heterogeneous input types (`Example`, `dict`, `list`, `tuple`) into module calls.
- Aggregate results and optionally collect failed examples and exceptions.

### Configuration

| Parameter | Default | Description |
|-----------|---------|-------------|
| `num_threads` | `settings.num_threads` | Number of worker threads |
| `max_errors` | `settings.max_errors` | Errors tolerated before cancellation |
| `access_examples` | `True` | If `True`, calls `module(**example.inputs())`; otherwise `module(example)` |
| `return_failed_examples` | `False` | Return `(results, failed_examples, exceptions)` |
| `provide_traceback` | `None` | Include tracebacks in error logs |
| `disable_progress_bar` | `False` | Suppress the tqdm progress bar |

### Execution Flow

```mermaid
flowchart TD
    A["forward(exec_pairs, num_threads)"] --> B["Create ParallelExecutor"]
    B --> C["Define process_pair(pair)"]
    C --> D{"example type?"}
    D -->|Example| E["module(**example.inputs())<br/>or module(example)"]
    D -->|dict| F["module(**example)"]
    D -->|list + Parallel| G["module(example)"]
    D -->|tuple| H["module(*example)"]
    D -->|other| I["raise ValueError"]
    E --> J["executor.execute(process_pair, exec_pairs)"]
    F --> J
    G --> J
    H --> J
    J --> K{"return_failed_examples?"}
    K -->|Yes| L["return results, failed_examples, exceptions"]
    K -->|No| M["return results"]
```

### Relationship to `ParallelExecutor`

`Parallel` is a thin orchestration layer. The heavy lifting — thread isolation of `dspy.settings`, straggler timeouts, error counting, and progress reporting — is delegated to `ParallelExecutor` (see [utils.md](utils.md)). This separation ensures that thread-local configuration overrides propagate correctly to worker threads.

---

## BestOfN

`BestOfN` runs a wrapped module up to `N` times with varying temperatures and returns the prediction with the highest reward, or the first prediction that meets a threshold.

### Key Responsibilities

- Generate a temperature schedule from the base LM temperature.
- Deep-copy the module per attempt and assign a temperature-adjusted LM.
- Evaluate each prediction with a user-supplied `reward_fn`.
- Track the best prediction and its execution trace.

### Configuration

| Parameter | Description |
|-----------|-------------|
| `module` | The `Module` to run repeatedly |
| `N` | Maximum number of attempts |
| `reward_fn` | `Callable[[dict, Prediction], float]` scoring function |
| `threshold` | Reward threshold for early stopping |
| `fail_count` | Attempts allowed to fail before raising (defaults to `N`) |

### Execution Flow

```mermaid
flowchart TD
    A["forward(**kwargs)"] --> B["Get LM, build temperature schedule"]
    B --> C["For each temperature t"]
    C --> D["lm_ = lm.copy(temperature=t)"]
    D --> E["mod = module.deepcopy(); mod.set_lm(lm_)"]
    E --> F["pred = mod(**kwargs) within trace context"]
    F --> G["reward = reward_fn(kwargs, pred)"]
    G --> H{"reward > best_reward?"}
    H -->|Yes| I["Update best_pred, best_trace, best_reward"]
    H -->|No| J{"reward >= threshold?"}
    I --> J
    J -->|Yes| K["break"]
    J -->|No| L{"more temps?"}
    L -->|Yes| C
    L -->|No| M["Extend trace with best_trace"]
    K --> M
    M --> N["return best_pred"]
    F -->|Exception| O["Log; if idx > fail_count raise, else decrement"]
    O --> L
```

> **Note:** The `reward_fn` is wrapped in a lambda so it is not registered as a DSPy parameter during optimization.

---

## Refine

`Refine` extends the `BestOfN` pattern by generating **natural-language feedback** when an attempt fails to meet the threshold. This feedback is injected as a `hint_` input field into subsequent attempts, allowing the module to learn from its own mistakes within a single call.

### Key Responsibilities

- Capture the module source code and reward function source code via `inspect`.
- Build a per-module trajectory from the execution trace.
- Invoke `OfferFeedback` to produce concrete advice for each sub-module.
- Inject advice into subsequent attempts via a dynamically generated `WrapperAdapter`.

### Configuration

Identical to `BestOfN` (`module`, `N`, `reward_fn`, `threshold`, `fail_count`), plus internal capture of `module_code` and `reward_fn_code`.

### Execution Flow

```mermaid
flowchart TD
    A["forward(**kwargs)"] --> B["Get LM, build temperature schedule"]
    B --> C["For each temperature t"]
    C --> D["Deep-copy module, set temperature-adjusted LM"]
    D --> E{"advice available?"}
    E -->|No| F["outputs = mod(**kwargs)"]
    E -->|Yes| G["Use WrapperAdapter to inject hint_ field"]
    G --> F
    F --> H["reward = reward_fn(kwargs, outputs)"]
    H --> I{"reward > best_reward?"}
    I -->|Yes| J["Update best"]
    I -->|No| K{"reward >= threshold?"}
    J --> K
    K -->|Yes| L["break"]
    K -->|No| M{"last attempt?"}
    M -->|Yes| L
    M -->|No| N["Build trajectory + reward metadata"]
    N --> O["advice = Predict(OfferFeedback)(...).advice"]
    O --> C
    L --> P["Extend trace, return best_pred"]
```

### The `OfferFeedback` Signature

`OfferFeedback` is a DSPy `Signature` (see [signatures.md](signatures.md)) that takes the program code, module definitions, inputs, trajectory, outputs, reward code, threshold, and reward value, and produces:

- `discussion` — blame assignment across modules.
- `advice` — a `dict[str, str]` mapping module names to concrete, actionable advice (or `N/A`).

### Helper Functions

| Function | Purpose |
|----------|---------|
| `inspect_modules(program)` | Formats each predictor's signature, input/output fields, and instructions into a readable string |
| `recursive_mask(o)` | Recursively replaces non-JSON-serializable objects with placeholder strings before serialization |

### The `WrapperAdapter` Pattern

When advice is available, `Refine` creates a subclass of the active adapter that appends a `hint_` input field to the signature and populates it with the module-specific advice. This is a runtime signature mutation technique that avoids modifying the underlying module definition.

---

## KNN

`KNN` is a k-nearest-neighbor retriever that finds the most similar examples from a training set given an input. It is commonly used for dynamic few-shot example selection.

### Key Responsibilities

- Vectorize the training set once at construction time.
- Vectorize the query input at call time.
- Compute cosine-style similarity via dot product and return the top-`k` examples.

### Configuration

| Parameter | Description |
|-----------|-------------|
| `k` | Number of nearest neighbors to retrieve |
| `trainset` | List of `Example` objects to search |
| `vectorizer` | An `Embedder` used for vectorization |

### Execution Flow

```mermaid
flowchart TD
    A["__init__(k, trainset, vectorizer)"] --> B["Cast each example to 'key: value | ...' string"]
    B --> C["trainset_vectors = embedding(strings)"]
    D["__call__(**kwargs)"] --> E["Build query string from kwargs"]
    E --> F["input_vector = embedding([query])"]
    F --> G["scores = dot(trainset_vectors, input_vector.T)"]
    G --> H["nearest = argsort(scores)[-k:][::-1]"]
    H --> I["return [trainset[i] for i in nearest]"]
```

> **Note:** Only input keys (`example._input_keys`) are used when casting training examples to strings, ensuring that labels do not leak into the embedding.

---

## Component Interaction

The following diagram shows how the execution strategies interact with the broader DSPy ecosystem.

```mermaid
graph LR
    subgraph User["User Code"]
        U1["module.batch(examples)"]
        U2["BestOfN(module, N, ...)"]
        U3["Refine(module, N, ...)"]
        U4["KNN(k, trainset, embedder)"]
    end

    U1 --> Parallel
    U2 --> BestOfN
    U3 --> Refine
    U4 --> KNN

    Parallel --> ParallelExecutor
    ParallelExecutor --> Settings

    BestOfN --> Module
    Refine --> Module
    Refine --> OfferFeedback

    KNN --> Embedder

    Module --> LM
    OfferFeedback --> LM
```

---

## Dependencies

### Internal Dependencies

| Dependency | Used By | Purpose |
|------------|---------|---------|
| `dspy.utils.parallelizer.ParallelExecutor` | `Parallel` | Thread pool execution with isolation |
| `dspy.dsp.utils.settings.Settings` | `Parallel`, `BestOfN`, `Refine` | Global/thread-local configuration |
| `dspy.primitives.module.Module` | `BestOfN`, `Refine` | Base class for wrapped modules |
| `dspy.primitives.example.Example` | `Parallel`, `KNN` | Input data container |
| `dspy.primitives.prediction.Prediction` | `BestOfN`, `Refine` | Reward function input |
| `dspy.clients.embedding.Embedder` | `KNN` | Vectorization backend |
| `dspy.signatures.Signature` | `OfferFeedback` | Declarative I/O specification |
| `dspy.adapters.utils.get_field_description_string` | `Refine` | Field description formatting |

### External Dependencies

| Library | Used By | Purpose |
|---------|---------|---------|
| `numpy` | `KNN` | Vector math and similarity computation |
| `ujson` | `Refine` | Fast JSON serialization of advice payloads |
| `threading` | `Parallel` | Error locking and cancellation events |
| `inspect` | `Refine` | Source code introspection |

---

## Usage Examples

### Parallel Execution via `Module.batch`

```python
import dspy

dspy.settings.configure(lm=dspy.LM("openai/gpt-4o-mini"))
qa = dspy.ChainOfThought("question -> answer")

results = qa.batch(
    [dspy.Example(question=q).with_inputs("question") for q in questions],
    num_threads=8,
    return_failed_examples=True,
)
```

### BestOfN

```python
def one_word_answer(args, pred):
    return 1.0 if len(pred.answer.split()) == 1 else 0.0

best_of_3 = dspy.BestOfN(module=qa, N=3, reward_fn=one_word_answer, threshold=1.0)
result = best_of_3(question="What is the capital of Belgium?").answer
```

### Refine

```python
refined = dspy.Refine(module=qa, N=3, reward_fn=one_word_answer, threshold=1.0)
result = refined(question="What is the capital of Belgium?").answer
```

### KNN Retrieval

```python
from sentence_transformers import SentenceTransformer

knn = dspy.KNN(
    k=3,
    trainset=trainset,
    vectorizer=dspy.Embedder(SentenceTransformer("all-MiniLM-L6-v2").encode),
)
similar_examples = knn(input="hello")
```

---

## Design Considerations

### Thread Safety

`Parallel` relies on `ParallelExecutor` to isolate `dspy.settings` per thread. Thread-local overrides set via `dspy.context(...)` propagate to worker threads, but global `dspy.configure(...)` calls are restricted to the owning thread (see [dsp_utils.md](dsp_utils.md)).

### Trace Management

Both `BestOfN` and `Refine` capture the execution trace within a `dspy.context(trace=[])` block and extend the global trace with the best attempt's trace. This ensures that only the winning attempt's trace is recorded, keeping history clean.

### Reward Function Isolation

In both `BestOfN` and `Refine`, the `reward_fn` is wrapped in a lambda (`lambda *args: reward_fn(*args)`) to prevent it from being registered as a DSPy parameter during optimization.

### Failure Handling

Both `BestOfN` and `Refine` implement a `fail_count` mechanism: individual attempt failures are logged and tolerated up to `fail_count` times before the exception is re-raised. This makes the strategies resilient to transient LM errors.

---

## Related Modules

- [predict_core.md](predict_core.md) — The `Predict` primitive and `Parameter`.
- [predict_reasoning.md](predict_reasoning.md) — `ChainOfThought`, `ProgramOfThought`, `MultiChainComparison`.
- [predict_agents.md](predict_agents.md) — `ReAct`, `CodeAct`.
- [primitives.md](primitives.md) — `Module`, `Example`, `Prediction`.
- [utils.md](utils.md) — `ParallelExecutor` and other utilities.
- [clients.md](clients.md) — `LM`, `Embedder`, and providers.
- [signatures.md](signatures.md) — `Signature` and field definitions.
- [teleprompt.md](teleprompt.md) — Optimizers that consume these execution strategies.
- [evaluate.md](evaluate.md) — Evaluation utilities that use `Parallel`.
