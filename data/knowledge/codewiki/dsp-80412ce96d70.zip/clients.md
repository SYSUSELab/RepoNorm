# Clients

## Overview

The **clients** module is the interface layer between DSPy programs and the underlying Large Language Model (LLM) and embedding providers. It abstracts away the differences between providers (OpenAI, Databricks, local SGLang servers, Arbor, etc.) and exposes a uniform API that the rest of DSPy uses to make model calls, compute embeddings, cache responses, and manage fine-tuning / reinforcement-learning jobs.

The module is built around three core concerns:

1. **Language model invocation** — `BaseLM` and its primary subclass `LM` provide synchronous and asynchronous chat/text completion, streaming, history tracking, and usage accounting.
2. **Provider abstraction** — `Provider` and its subclasses encapsulate provider-specific behavior such as model discovery, launching/killing inference servers, and fine-tuning / RL training.
3. **Supporting infrastructure** — `Cache` provides two-level (memory + disk) response caching, and `Embedder` provides a unified embedding interface.

## Architecture

```mermaid
graph TD
    subgraph "DSPy Programs"
        Predict["Predict / Modules"]
    end

    subgraph "clients module"
        BaseLM["BaseLM<br/>(base_lm.py)"]
        LM["LM<br/>(lm.py)"]
        Embedder["Embedder<br/>(embedding.py)"]
        Cache["Cache<br/>(cache.py)"]
        Provider["Provider<br/>(provider.py)"]
    end

    subgraph "Providers"
        OpenAI["OpenAIProvider"]
        Databricks["DatabricksProvider"]
        Local["LocalProvider"]
        Arbor["ArborProvider"]
    end

    subgraph "External"
        LiteLLM["litellm"]
        OpenAIAPI["OpenAI API"]
        DBAPI["Databricks API"]
        SGLang["SGLang Server"]
        ArborAPI["Arbor Server"]
    end

    Predict --> LM
    Predict --> Embedder
    LM --> BaseLM
    LM --> Provider
    LM --> Cache
    Embedder --> Cache
    Embedder --> LiteLLM
    LM --> LiteLLM

    Provider --> OpenAI
    Provider --> Databricks
    Provider --> Local
    Provider --> Arbor

    OpenAI --> OpenAIAPI
    Databricks --> DBAPI
    Local --> SGLang
    Arbor --> ArborAPI
    LiteLLM --> OpenAIAPI
```

## Core Components

### BaseLM and LM

`BaseLM` (`dspy/clients/base_lm.py`) is the abstract base class for all language models. It defines the `forward` / `aforward` contract (subclasses must return an OpenAI-compatible response object), handles response post-processing, maintains per-instance and global history, and integrates with DSPy callbacks and settings.

`LM` (`dspy/clients/lm.py`) is the concrete, user-facing implementation. It wraps [litellm](https://github.com/BerriAI/litellm) to support hundreds of providers, adds retry logic with exponential backoff, streaming support, response caching, usage tracking, and fine-tuning / reinforcement-learning entry points (`finetune`, `reinforce`, `launch`, `kill`).

See [clients_lm.md](clients_lm.md) for full details.

### Provider Abstraction

The `Provider` class (`dspy/clients/provider.py`) defines the interface for provider-specific behavior. It also defines the `TrainingJob` (a `Future` subclass) and `ReinforceJob` abstractions used to track asynchronous fine-tuning and RL jobs.

Concrete providers include:

| Provider | File | Capabilities |
| --- | --- | --- |
| `OpenAIProvider` | `dspy/clients/openai.py` | Fine-tuning via OpenAI API |
| `DatabricksProvider` | `dspy/clients/databricks.py` | Fine-tuning + serving endpoint deployment |
| `LocalProvider` | `dspy/clients/lm_local.py` | Launch/kill local SGLang servers, local SFT |
| `ArborProvider` | `dspy/clients/lm_local_arbor.py` | Fine-tuning + GRPO reinforcement learning |

See [clients_clients_providers.md](clients_clients_providers.md) for full details.

### Cache

`Cache` (`dspy/clients/cache.py`) implements a two-level caching strategy (in-memory LRU + on-disk `FanoutCache`) and exposes the `request_cache` decorator used to transparently cache LM and embedding calls. See [clients_cache.md](clients_cache.md) for full details.

### Embedder

`Embedder` (`dspy/clients/embedding.py`) provides a unified interface for hosted embedding models (via litellm) and custom callables, with batching, caching, and sync/async support. See [clients_embedding.md](clients_embedding.md) for full details.

### Fine-tuning Utilities

`dspy/clients/utils_finetune.py` defines shared data structures used across providers, most notably the `TrainDataFormat` enum (`CHAT`, `COMPLETION`, `GRPO_CHAT`) and the `TrainingStatus` enum. See [clients_clients_finetune.md](clients_clients_finetune.md) for full details.

## Component Interaction Flow

The following diagram shows how a typical LM call flows through the module:

```mermaid
sequenceDiagram
    participant P as Predict/Module
    participant LM as LM
    participant C as Cache
    participant L as litellm
    participant Prov as Provider

    P->>LM: __call__(prompt/messages)
    LM->>LM: forward() builds request
    LM->>C: request_cache lookup
    alt cache hit
        C-->>LM: cached response
    else cache miss
        LM->>L: completion(request)
        L-->>LM: response
        LM->>C: store response
    end
    LM->>LM: _process_lm_response()
    LM->>LM: update history + usage tracker
    LM-->>P: outputs

    Note over LM,Prov: Fine-tuning / RL path
    P->>LM: finetune(train_data)
    LM->>Prov: provider.finetune(job, ...)
    Prov-->>LM: TrainingJob (Future)
```

## Relationship to Other Modules

- **predict** — `Predict` and other modules in the [predict](predict.md) module call `LM.__call__` to generate predictions.
- **signatures** — The [signatures](signatures.md) module defines the input/output structure that adapters format into prompts passed to `LM`.
- **adapters** — The [adapters](adapters.md) module converts signatures and examples into the messages/prompts consumed by `LM`.
- **retrievers** — The [retrievers](retrievers.md) module uses `Embedder` for embedding-based retrieval.
- **utils** — `BaseLM` relies on `dspy.utils.callback` and `dspy.utils.inspect_history`; `LM` uses `dspy.utils.usage_tracker`.
- **dsp_utils** — `BaseLM` reads global configuration from `dspy.dsp.utils.settings`.
- **teleprompt** — Optimizers such as `BootstrapFinetune` and `GRPO` in the [teleprompt](teleprompt.md) module drive the `finetune` and `reinforce` workflows exposed by `LM`.

## Sub-module Documentation

| Sub-module | Description |
| --- | --- |
| [clients_lm.md](clients_lm.md) | `BaseLM` and `LM` — language model invocation, streaming, history, fine-tuning entry points |
| [clients_clients_providers.md](clients_clients_providers.md) | `Provider` base class and concrete providers (OpenAI, Databricks, Local, Arbor) |
| [clients_cache.md](clients_cache.md) | Two-level `Cache` and the `request_cache` decorator |
| [clients_embedding.md](clients_embedding.md) | `Embedder` for hosted and custom embedding models |
| [clients_clients_finetune.md](clients_clients_finetune.md) | Shared fine-tuning data structures (`TrainDataFormat`, `TrainingStatus`, etc.) |
