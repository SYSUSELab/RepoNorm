# predict_agents

## Introduction

The `predict_agents` module provides DSPy's **tool-using agent** abstractions. It implements two closely related paradigms for building agents that iteratively reason, act, and observe:

- **`ReAct`** — "Reasoning and Acting": the language model interleaves *thoughts*, *tool selections*, and *tool arguments* across multiple episodes, gathering information via tools until it decides to finish.
- **`CodeAct`** — an extension of `ReAct` that replaces discrete tool calls with **executable Python code** run inside a sandboxed interpreter, allowing the agent to compose tools and standard-library logic programmatically.

Both modules are generalized over any DSPy `Signature`, thanks to signature polymorphism, and both support synchronous and asynchronous execution.

> **Related documentation:** For the underlying prediction primitives, see [predict_core](predict_core.md). For the reasoning modules that `CodeAct` builds upon, see [predict_reasoning](predict_reasoning.md). For the tool type system, see [adapter_types](adapter_types.md). For the sandboxed interpreter, see [primitives](primitives.md).

---

## Module Overview

| Component | File | Base Classes | Purpose |
|-----------|------|--------------|---------|
| `ReAct` | `dspy/predict/react.py` | `Module` | Iterative thought → tool-call → observation agent loop |
| `CodeAct` | `dspy/predict/code_act.py` | `ReAct`, `ProgramOfThought` | Agent loop that generates and executes Python code |

The module sits within the broader `predict` package, which is organized into four sub-modules:

```mermaid
graph TD
    subgraph predict["dspy.predict"]
        core["predict_core<br/>Predict, Parameter"]
        reasoning["predict_reasoning<br/>ChainOfThought, ProgramOfThought,<br/>MultiChainComparison"]
        agents["predict_agents (this module)<br/>ReAct, CodeAct"]
        execution["predict_execution<br/>Parallel, BestOfN, Refine, KNN"]
    end

    agents -->|uses| core
    agents -->|uses| reasoning
    agents -->|uses| execution
```

---

## Architecture

Both agent classes are DSPy `Module`s that internally compose lower-level modules. `ReAct` builds on `Predict` and `ChainOfThought`; `CodeAct` inherits from both `ReAct` and `ProgramOfThought` and adds a `PythonInterpreter`.

```mermaid
graph TD
    subgraph ReAct
        R["ReAct (Module)"]
        R --> R_react["self.react<br/>dspy.Predict"]
        R --> R_extract["self.extract<br/>dspy.ChainOfThought"]
        R --> R_tools["self.tools<br/>dict[str, Tool]"]
    end

    subgraph CodeAct
        C["CodeAct (ReAct, ProgramOfThought)"]
        C --> C_codeact["self.codeact<br/>dspy.Predict"]
        C --> C_extractor["self.extractor<br/>dspy.ChainOfThought"]
        C --> C_tools["self.tools<br/>dict[str, Tool]"]
        C --> C_interp["self.interpreter<br/>PythonInterpreter"]
    end

    R_react --> Predict["dspy.Predict"]
    R_extract --> CoT["dspy.ChainOfThought"]
    C_codeact --> Predict
    C_extractor --> CoT
    C_interp --> PyInterp["PythonInterpreter<br/>(Deno + Pyodide sandbox)"]
```

### Component Relationships

```mermaid
classDiagram
    class Module {
        +forward(**kwargs)
        +aforward(**kwargs)
        +__call__(**kwargs)
        +acall(**kwargs)
    }
    class ReAct {
        +signature
        +max_iters
        +tools: dict[str, Tool]
        +react: Predict
        +extract: ChainOfThought
        +forward(**input_args)
        +aforward(**input_args)
        +truncate_trajectory(trajectory)
    }
    class CodeAct {
        +signature
        +max_iters
        +tools: dict[str, Tool]
        +codeact: Predict
        +extractor: ChainOfThought
        +interpreter: PythonInterpreter
        +forward(**kwargs)
    }
    class ProgramOfThought {
        +interpreter: PythonInterpreter
        +forward(**kwargs)
    }
    Module <|-- ReAct
    ReAct <|-- CodeAct
    ProgramOfThought <|-- CodeAct
```

---

## ReAct

`ReAct` implements the classic reasoning-and-acting loop. It is defined in `dspy/predict/react.py`.

### Construction

```python
ReAct(signature, tools: list[Callable], max_iters: int = 10)
```

- **`signature`** — any DSPy signature (string or `Signature` class). Input fields become the agent's task inputs; output fields define what must be produced.
- **`tools`** — a list of functions, callable objects, or `dspy.Tool` instances. Each is normalized into a `Tool` and indexed by name.
- **`max_iters`** — maximum number of reasoning episodes before extraction is forced.

During initialization, `ReAct`:

1. Normalizes all tools into `dspy.Tool` objects and builds a `{name: Tool}` dictionary.
2. Synthesizes a **`react_signature`** that appends `trajectory` (input), `next_thought`, `next_tool_name` (a `Literal` over the available tool names), and `next_tool_args` (a `dict`) to the original input fields.
3. Injects a special **`finish`** tool that signals task completion.
4. Builds a **`fallback_signature`** (original inputs + outputs + `trajectory`) used by the extraction step.
5. Instantiates `self.react = dspy.Predict(react_signature)` and `self.extract = dspy.ChainOfThought(fallback_signature)`.

### The Agent Loop

```mermaid
flowchart TD
    Start([forward called]) --> Init["trajectory = {}<br/>max_iters = input or default"]
    Init --> Loop{"idx < max_iters?"}
    Loop -->|yes| Call["self.react(trajectory=..., **inputs)"]
    Call --> Valid{"Valid tool<br/>selected?"}
    Valid -->|no| Break["log warning, break"]
    Valid -->|yes| Record["record thought, tool_name, tool_args"]
    Record --> Exec["execute tool(**args)"]
    Exec --> Obs["record observation<br/>(or execution error)"]
    Obs --> Finish{"tool_name == 'finish'?"}
    Finish -->|yes| Break
    Finish -->|no| Loop
    Loop -->|no| Extract
    Break --> Extract["self.extract(trajectory=..., **inputs)"]
    Extract --> Return["return Prediction(trajectory=..., **extract)"]
```

Each iteration appends four keys to the trajectory: `thought_{idx}`, `tool_name_{idx}`, `tool_args_{idx}`, and `observation_{idx}`. Tool execution errors are captured into the observation rather than raised, keeping the loop resilient.

### Trajectory Formatting and Truncation

- **`_format_trajectory(trajectory)`** uses the active adapter (`dspy.settings.adapter` or `ChatAdapter`) to render the trajectory dictionary into a user-message string.
- **`_call_with_potential_trajectory_truncation`** (and its async twin) wraps every sub-module call. If a `ContextWindowExceededError` is raised, it truncates the oldest tool call and retries (up to 3 attempts).
- **`truncate_trajectory(trajectory)`** removes the four oldest keys (one complete tool call). It raises a `ValueError` if only one tool call remains, since truncation is no longer possible. Users may override this method to implement custom truncation.

### Async Support

`aforward` mirrors `forward` but awaits `self.react.acall(...)` and `self.tools[...].acall(...)`, enabling concurrent tool execution.

---

## CodeAct

`CodeAct` (in `dspy/predict/code_act.py`) extends `ReAct` and `ProgramOfThought`. Instead of selecting a single tool per turn, the model generates **Python code** that may call any of the provided tools (which are injected into the interpreter's namespace) plus the standard library.

### Construction

```python
CodeAct(signature, tools: list[Callable], max_iters: int = 5, interpreter: PythonInterpreter | None = None)
```

- **`tools`** — must be plain functions; callable objects are rejected with a `ValueError` (because the source code is injected into the interpreter via `inspect.getsource`).
- **`interpreter`** — an optional `PythonInterpreter`; if omitted, a new sandboxed interpreter is created.

During initialization, `CodeAct`:

1. Validates that every tool wraps a function.
2. Builds instructions via `_build_instructions`, describing the task and listing available functions.
3. Synthesizes a **`codeact_signature`** with `trajectory` (input), `generated_code` (output), and `finished` (boolean output).
4. Builds an **`extract_signature`** for the final answer extraction.
5. Instantiates `self.codeact = dspy.Predict(...)`, `self.extractor = dspy.ChainOfThought(...)`, and the interpreter.

### The CodeAct Loop

```mermaid
flowchart TD
    Start([forward called]) --> Inject["inject tool source code<br/>into interpreter"]
    Inject --> Loop{"idx < max_iters?"}
    Loop -->|yes| Gen["self.codeact(trajectory=..., **kwargs)"]
    Gen --> Parse["_parse_code(code_data)"]
    Parse --> ParseErr{"parse error?"}
    ParseErr -->|yes| ObsParse["record observation: parse failed"]
    ObsParse --> Loop
    ParseErr -->|no| Exec["_execute_code(code)"]
    Exec --> ExecErr{"execution error?"}
    ExecErr -->|no| RecOut["record code_output"]
    ExecErr -->|yes| ObsExec["record observation: execution failed"]
    RecOut --> Fin{"finished?"}
    ObsExec --> Fin
    Fin -->|yes| Break
    Fin -->|no| Loop
    Loop -->|no| Extract
    Break --> Extract["self.extractor(trajectory=..., **kwargs)"]
    Extract --> Shutdown["interpreter.shutdown()"]
    Shutdown --> Return["return Prediction(trajectory=..., **extract)"]
```

### Key Differences from ReAct

| Aspect | `ReAct` | `CodeAct` |
|--------|---------|-----------|
| Action unit | Single tool call | Generated Python code block |
| Tool invocation | `tool(**args)` directly | Tools injected into interpreter namespace |
| Tool constraint | Functions or callables | Functions only |
| Termination signal | `finish` tool | `finished=True` output field |
| Default `max_iters` | 10 | 5 |
| Sandbox | None | `PythonInterpreter` (Deno + Pyodide) |
| Trajectory keys | `thought_*`, `tool_name_*`, `tool_args_*`, `observation_*` | `generated_code_*`, `code_output_*`, `observation_*` |

---

## Data Flow

The following diagram shows how data flows through a `ReAct` invocation, from user inputs to the final `Prediction`.

```mermaid
sequenceDiagram
    participant User
    participant ReAct
    participant Predict as self.react (Predict)
    participant Tool as Tool
    participant CoT as self.extract (ChainOfThought)

    User->>ReAct: forward(question="...")
    loop up to max_iters
        ReAct->>Predict: react(trajectory=formatted, question=...)
        Predict-->>ReAct: next_thought, next_tool_name, next_tool_args
        ReAct->>Tool: tool(**next_tool_args)
        Tool-->>ReAct: observation
        Note over ReAct: append thought/tool/args/observation to trajectory
    end
    ReAct->>CoT: extract(trajectory=formatted, question=...)
    CoT-->>ReAct: answer
    ReAct-->>User: Prediction(trajectory=..., answer=...)
```

---

## Dependencies

```mermaid
graph LR
    subgraph predict_agents
        ReAct
        CodeAct
    end

    ReAct --> Tool["dspy.adapters.types.tool.Tool"]
    ReAct --> Module["dspy.primitives.module.Module"]
    ReAct --> Signature["dspy.signatures.signature.ensure_signature"]
    ReAct --> Predict["dspy.Predict"]
    ReAct --> CoT["dspy.ChainOfThought"]
    ReAct --> ChatAdapter["dspy.ChatAdapter"]
    ReAct --> Settings["dspy.settings"]

    CodeAct --> ReAct
    CodeAct --> ProgramOfThought["dspy.predict.program_of_thought.ProgramOfThought"]
    CodeAct --> PythonInterpreter["dspy.primitives.python_interpreter.PythonInterpreter"]
    CodeAct --> Tool
    CodeAct --> Predict
    CodeAct --> CoT
```

### External Dependencies

- **`litellm.ContextWindowExceededError`** — caught by `ReAct` to trigger trajectory truncation.
- **Deno + Pyodide** — required at runtime by `CodeAct` (via `PythonInterpreter`) to execute generated code in a sandbox.

---

## Usage Examples

### ReAct

```python
import dspy

def get_weather(city: str) -> str:
    return f"The weather in {city} is sunny."

react = dspy.ReAct(signature="question->answer", tools=[get_weather])
pred = react(question="What is the weather in Tokyo?")
```

### CodeAct

```python
from dspy.predict import CodeAct

def factorial(n):
    if n == 1:
        return 1
    return n * factorial(n - 1)

act = CodeAct("n->factorial", tools=[factorial])
act(n=5)  # 120
```

---

## Extension Points

- **Custom trajectory truncation** — override `ReAct.truncate_trajectory` to implement domain-specific context-window management.
- **Custom interpreters** — pass a pre-configured `PythonInterpreter` to `CodeAct` to control sandbox permissions (read/write paths, env vars, network access).
- **Tool conversion** — `Tool` supports conversion from MCP tools (`Tool.from_mcp_tool`) and LangChain tools (`Tool.from_langchain`), so agents can consume tools from those ecosystems.

---

## Design Notes

The `react.py` source file includes a set of documented "Thoughts and Planned Improvements" that highlight known design considerations:

- **Trajectory formatting timing** — trajectories are formatted at `forward` time, so demonstrations do not automatically reflect adapter changes. A future fix may support `format=fn` on the `trajectory` input field or a native "variadic" input field.
- **`__init__` simplification** — moving tool-related logic (exception handling, the `finish` tool) into the `Tool` class.
- **Context-window behavior** — defining a clearer default when trajectories grow too long.
- **Instruction structure** — the instruction is currently a free-form string that optimizers can rewrite; a more structured template is under consideration.
- **Stateful tools** — idiomatically supporting tools that maintain state across iterations within a single `forward` call but reset between calls.

---

## Related Modules

| Module | Relationship |
|--------|--------------|
| [predict_core](predict_core.md) | Provides `Predict` and `Parameter`, the prediction primitives used internally. |
| [predict_reasoning](predict_reasoning.md) | Provides `ChainOfThought` and `ProgramOfThought`, used for extraction and as a `CodeAct` base class. |
| [predict_execution](predict_execution.md) | Provides execution strategies (`Parallel`, `BestOfN`, `Refine`) that can wrap agents. |
| [adapter_types](adapter_types.md) | Defines `Tool` and `ToolCalls`, the tool type system. |
| [primitives](primitives.md) | Defines `Module`, `Prediction`, and `PythonInterpreter`. |
| [signatures](signatures.md) | Defines `Signature` and `ensure_signature`. |
| [adapters](adapters.md) | Provides `ChatAdapter` and other adapters used for trajectory formatting. |
