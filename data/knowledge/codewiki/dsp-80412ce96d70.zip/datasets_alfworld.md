# datasets_alfworld

## Introduction

The `datasets_alfworld` module provides integration between DSPy and the **ALFWorld** benchmark — a text-based, interactive environment for evaluating agents on embodied, multi-step household tasks (e.g., "put a hot apple in the microwave"). Unlike static datasets, ALFWorld is a *simulator*: each example is an environment instance that an agent must interact with through a sequence of textual actions until the task is completed.

Because the underlying ALFWorld simulator is a heavy, stateful, and non-thread-safe Python environment, this module wraps it in a **process pool** so that many environments can be stepped concurrently. The module exposes:

- `AlfWorld` — the user-facing dataset class that builds train/dev splits of environment indices.
- `EnvPool` — a pool of worker processes, each hosting an independent ALFWorld environment.
- `_EnvSession` — a context manager that safely acquires, uses, and releases a single worker from the pool.

> **Note:** This module is part of the broader [datasets](datasets.md) subsystem. For the general dataset abstraction and loading utilities, see [datasets_core](datasets_core.md). For the benchmark datasets that follow the standard `Dataset` interface, see [datasets_benchmarks](datasets_benchmarks.md).

---

## Architecture Overview

The module is organized around a producer/consumer pattern where the main process communicates with isolated worker processes over queues. Each worker owns exactly one ALFWorld environment instance.

```mermaid
graph TD
    subgraph MainProcess["Main Process"]
        AlfWorld["AlfWorld<br/>(dataset facade)"]
        Pool["EnvPool<br/>(worker manager)"]
        Session["_EnvSession<br/>(context manager)"]
        AlfWorld --> Pool
        Pool --> Session
    end

    subgraph Worker0["Worker Process 0"]
        W0["env_worker<br/>AlfredTWEnv instance"]
    end
    subgraph Worker1["Worker Process 1"]
        W1["env_worker<br/>AlfredTWEnv instance"]
    end
    subgraph WorkerN["Worker Process N"]
        WN["env_worker<br/>AlfredTWEnv instance"]
    end

    Session -- "inq: init/step/close" --> W0
    W0 -- "outq: obs/rew/done/info" --> Session
    Session -- "inq" --> W1
    W1 -- "outq" --> Session
    Session -- "inq" --> WN
    WN -- "outq" --> Session
```

### Key Design Decisions

| Decision | Rationale |
|----------|-----------|
| **Multiprocessing with `spawn`** | ALFWorld environments are stateful and not thread-safe; process isolation prevents cross-contamination and GIL contention. `spawn` avoids forking issues with the simulator's native dependencies. |
| **Queue-based IPC** | Simple, robust request/response protocol (`init`, `step`, `close`) between the main process and workers. |
| **Context-manager sessions** | Guarantees a worker is returned to the pool even if an exception occurs during stepping. |
| **Index-based examples** | Each `dspy.Example` carries only an `idx`; the actual environment state lives in the worker, keeping examples lightweight and serializable. |

---

## Component Reference

### `AlfWorld`

The user-facing dataset class. It constructs the environment pool and produces shuffled train/dev splits of environment indices.

```python
class AlfWorld:
    def __init__(self, max_threads=20):
        self.POOL = EnvPool(size=max_threads)

        import dspy
        dataset = [dspy.Example(idx=idx).with_inputs("idx") for idx in range(3500)]
        random.Random(0).shuffle(dataset)

        trainset, devset = dataset[:3000], dataset[-500:]
        assert len(trainset) + len(devset) <= len(dataset)

        self.trainset = trainset
        self.devset = devset

    def __del__(self):
        self.POOL.close_all()
```

**Behavior:**

1. **Pool creation** — Instantiates an `EnvPool` with `max_threads` worker processes (default `20`).
2. **Dataset construction** — Creates `3500` `dspy.Example` objects, each holding a single `idx` field marked as an input via `.with_inputs("idx")`.
3. **Deterministic shuffle** — Uses `random.Random(0)` so splits are reproducible across runs.
4. **Splits** — The first `3000` examples form `trainset`; the last `500` form `devset`.
5. **Cleanup** — `__del__` calls `POOL.close_all()` to terminate all worker processes.

> **Important:** The `idx` values are indices into the ALFWorld task set. The actual task definition is only materialized when a worker calls `env.skip(idx)` followed by `env.reset()` during `init`.

**Attributes:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `POOL` | `EnvPool` | The pool of ALFWorld worker processes. |
| `trainset` | `list[dspy.Example]` | 3000 shuffled examples for training. |
| `devset` | `list[dspy.Example]` | 500 shuffled examples for evaluation. |

---

### `EnvPool`

Manages a fixed-size pool of worker processes, each running an independent ALFWorld environment. Workers are handed out on demand and returned after use.

```python
class EnvPool:
    def __init__(self, size=2):
        self.size = size
        self.workers = []
        self.available = queue.Queue()

        try:
            import multiprocess as mp
        except ImportError:
            raise ImportError("multiprocess is not installed. ...")

        try:
            mp.set_start_method("spawn", force=True)
        except RuntimeError:
            pass

        ctx = mp.get_context("spawn")
        for i in range(size):
            inq = ctx.Queue()
            outq = ctx.Queue()
            p = ctx.Process(target=env_worker, args=(inq, outq), daemon=True)
            p.start()
            self.workers.append((inq, outq, p))
            self.available.put(i)
```

**Key methods:**

| Method | Description |
|--------|-------------|
| `_acquire()` | Blocks until a worker is available, returns `(wid, inq, outq)`. |
| `_release(wid)` | Returns a worker id to the available queue. |
| `session()` | Returns an `_EnvSession` context manager for safe acquire/release. |
| `close_all()` | Sends `close` to every worker, waits for `CLOSED`, closes queues, and joins processes. |

**Implementation notes:**

- Uses the `multiprocess` library (a `multiprocessing` drop-in that supports `dill`-based pickling), which is required because ALFWorld's environment objects may not be picklable with the standard library.
- Forces the `spawn` start method to avoid fork-related issues with the simulator's native code.
- Each worker is a `daemon` process, so it is terminated automatically if the parent exits unexpectedly.
- The `available` queue holds worker ids; `_acquire`/`_release` implement a simple counting-semaphore pattern.

---

### `_EnvSession`

A context manager that acquires a single worker from the pool, exposes `init` and `step`, and releases the worker on exit.

```python
class _EnvSession:
    def __init__(self, pool: EnvPool):
        self.pool = pool
        self.wid = None
        self.inq = None
        self.outq = None

    def __enter__(self):
        self.wid, self.inq, self.outq = self.pool._acquire()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.pool._release(self.wid)

    def init(self, idx):
        self.inq.put(("init", idx))
        return self.outq.get()  # (task_def, info)

    def step(self, action):
        self.inq.put(("step", action))
        return self.outq.get()  # (obs, rew, done, info)
```

**Usage pattern:**

```python
with pool.session() as sess:
    task_def, info = sess.init(5)          # initialize environment for task idx=5
    obs, rew, done, info = sess.step("go north")
    while not done:
        obs, rew, done, info = sess.step(next_action)
```

The `__exit__` method always releases the worker, even when an exception is raised inside the `with` block, preventing worker leaks.

---

### `env_worker` (module-level function)

The entry point executed inside each worker process. It lazily imports ALFWorld and YAML, loads the bundled `base_config.yml`, and then enters a command loop.

```python
def env_worker(inq, outq):
    try:
        import io
        from contextlib import redirect_stderr, redirect_stdout
        import alfworld.agents.environment as environment
        import yaml
    except ImportError:
        raise ImportError(
            "alfworld is not installed. "
            "Please install it via `pip install alfworld==0.3.5` then run `alfworld-download`."
        )

    buf = io.StringIO()
    base_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(base_dir, "base_config.yml")

    with open(config_path) as f:
        config = yaml.safe_load(f)

    with redirect_stdout(buf), redirect_stderr(buf):
        base_env = environment.AlfredTWEnv(config, train_eval="train")

    env = None
    while True:
        cmd, data = inq.get()
        if cmd == "init":
            env = base_env.init_env(batch_size=1)
            env.skip(data)
            task_def, info = env.reset()
            outq.put((task_def[0], info))
        elif cmd == "step":
            obs, rew, done, info = env.step([data])
            outq.put((obs, rew, done, info))
        elif cmd == "close":
            outq.put("CLOSED")
            break
        else:
            outq.put("UNKNOWN_CMD")
```

**Command protocol:**

| Command | Payload | Response |
|---------|---------|----------|
| `init` | task index (`int`) | `(task_def, info)` |
| `step` | action string | `(obs, rew, done, info)` |
| `close` | `None` | `"CLOSED"` |
| *(unknown)* | — | `"UNKNOWN_CMD"` |

**Notes:**

- ALFWorld's verbose logging is redirected to an in-memory buffer (`io.StringIO`) to keep worker stdout/stderr clean.
- The `AlfredTWEnv` is created once per worker; each `init` call creates a fresh single-batch environment via `init_env(batch_size=1)` and skips to the requested task index.
- The `base_config.yml` file is expected to live alongside `alfworld.py` in the module directory.

---

## Data Flow

The following sequence diagram shows a complete interaction from dataset construction through a single environment episode.

```mermaid
sequenceDiagram
    participant User
    participant AlfWorld
    participant EnvPool
    participant Session as _EnvSession
    participant Worker as env_worker

    User->>AlfWorld: AlfWorld(max_threads=20)
    AlfWorld->>EnvPool: EnvPool(size=20)
    EnvPool->>Worker: spawn N processes
    AlfWorld->>AlfWorld: build 3500 Examples, shuffle, split
    AlfWorld-->>User: trainset, devset

    User->>EnvPool: session()
    EnvPool->>Session: _EnvSession(pool)
    User->>Session: __enter__()
    Session->>EnvPool: _acquire()
    EnvPool-->>Session: (wid, inq, outq)

    User->>Session: init(idx)
    Session->>Worker: inq.put(("init", idx))
    Worker->>Worker: init_env + skip(idx) + reset()
    Worker-->>Session: (task_def, info)

    loop until done
        User->>Session: step(action)
        Session->>Worker: inq.put(("step", action))
        Worker->>Worker: env.step([action])
        Worker-->>Session: (obs, rew, done, info)
    end

    User->>Session: __exit__()
    Session->>EnvPool: _release(wid)

    User->>AlfWorld: __del__()
    AlfWorld->>EnvPool: close_all()
    EnvPool->>Worker: inq.put(("close", None))
    Worker-->>EnvPool: "CLOSED"
```

---

## Component Interaction

```mermaid
classDiagram
    class AlfWorld {
        +EnvPool POOL
        +list trainset
        +list devset
        +__init__(max_threads)
        +__del__()
    }
    class EnvPool {
        +int size
        +list workers
        +Queue available
        +__init__(size)
        +_acquire()
        +_release(wid)
        +session()
        +close_all()
    }
    class _EnvSession {
        +EnvPool pool
        +int wid
        +Queue inq
        +Queue outq
        +__enter__()
        +__exit__()
        +init(idx)
        +step(action)
    }
    class env_worker {
        <<function>>
        +env_worker(inq, outq)
    }

    AlfWorld --> EnvPool : creates
    EnvPool --> _EnvSession : session()
    EnvPool --> env_worker : spawns
    _EnvSession --> EnvPool : acquire/release
    _EnvSession ..> env_worker : IPC via queues
```

---

## Dependencies

```mermaid
graph LR
    alfworld["datasets_alfworld"]
    dspy["dspy (Example)"]
    mp["multiprocess"]
    alf["alfworld==0.3.5"]
    yaml["yaml (PyYAML)"]

    alfworld --> dspy
    alfworld --> mp
    alfworld --> alf
    alfworld --> yaml
```

| Dependency | Purpose | Install |
|------------|---------|---------|
| `dspy` | Provides `dspy.Example` for dataset items. | core package |
| `multiprocess` | Process pool with `dill`-based pickling. | `pip install multiprocess` |
| `alfworld` | The ALFWorld simulator (`AlfredTWEnv`). | `pip install alfworld==0.3.5` then `alfworld-download` |
| `PyYAML` | Loads `base_config.yml`. | `pip install pyyaml` |

Both `multiprocess` and `alfworld` are imported lazily and raise descriptive `ImportError`s if missing.

---

## Usage Example

```python
from dspy.datasets.alfworld.alfworld import AlfWorld

# Build the dataset (spawns a pool of 20 worker processes)
dataset = AlfWorld(max_threads=20)

print(len(dataset.trainset))  # 3000
print(len(dataset.devset))    # 500

# Interact with a single environment
with dataset.POOL.session() as sess:
    task_def, info = sess.init(idx=0)
    print("Task:", task_def)

    done = False
    while not done:
        action = "look"  # replace with your agent's action
        obs, rew, done, info = sess.step(action)
        print(obs, rew, done)

# Pool is closed automatically on garbage collection, or explicitly:
dataset.POOL.close_all()
```

---

## Process Flow: Worker Lifecycle

```mermaid
flowchart TD
    Start([spawn worker]) --> Import{alfworld installed?}
    Import -- No --> Err[raise ImportError]
    Import -- Yes --> Load[load base_config.yml]
    Load --> Create[create AlfredTWEnv]
    Create --> Loop{wait for command}
    Loop -- init --> InitEnv[init_env + skip + reset]
    InitEnv --> Send1[put task_def, info]
    Send1 --> Loop
    Loop -- step --> Step[env.step action]
    Step --> Send2[put obs, rew, done, info]
    Send2 --> Loop
    Loop -- close --> Closed[put CLOSED]
    Closed --> End([exit process])
```

---

## Related Modules

- [datasets](datasets.md) — top-level dataset subsystem overview.
- [datasets_core](datasets_core.md) — the `Dataset` base class and `DataLoader` utilities.
- [datasets_benchmarks](datasets_benchmarks.md) — static benchmark datasets (`GSM8K`, `HotPotQA`, `MATH`, `Colors`).
- [primitives](primitives.md) — the `Example` primitive used for dataset items.
