# predict_avatar_core

## Introduction

The `predict_avatar_core` module provides the central `Avatar` class — a DSPy module that implements an **agentic, tool-using reasoning loop**. Given a user-defined signature (goal + inputs/outputs) and a set of tools, `Avatar` iteratively decides which tool to invoke, executes it, feeds the result back into the reasoning context, and finally produces the requested outputs.

Unlike a single-shot `Predict`, `Avatar` performs multi-step planning: it dynamically grows its actor signature on each iteration so the underlying language model can see the full history of prior actions and their results before deciding the next action.

This module is the orchestration layer of the broader `predict_avatar` package. It depends on:

- [predict_avatar_models](predict_avatar_models.md) — the `Tool`, `Action`, and `ActionOutput` data models.
- [predict_avatar_signatures](predict_avatar_signatures.md) — the `Actor` signature that drives tool selection.
- [primitives](primitives.md) — `dspy.Module` base class and `dspy.Prediction`.
- [signatures](signatures.md) — `ensure_signature` and field helpers.

---

## Core Component: `Avatar`

`Avatar` is a subclass of `dspy.Module` that implements the `forward` method as an iterative tool-use loop.

### Constructor

```python
Avatar(signature, tools, max_iters=3, verbose=False)
```

| Parameter   | Type                | Description                                                                 |
|-------------|---------------------|-----------------------------------------------------------------------------|
| `signature` | `str \| type[Signature]` | The task signature. Its docstring becomes the `goal`; its input/output fields define the task contract. |
| `tools`     | `list[Tool]`        | The tools available to the agent. A synthetic `Finish` tool is appended automatically. |
| `max_iters` | `int`               | Maximum number of tool-use iterations before forcing a final answer. Default `3`. |
| `verbose`   | `bool`              | If `True`, prints progress messages during execution.                       |

### Initialization Flow

During construction, `Avatar`:

1. Normalizes the signature via `ensure_signature` and extracts `input_fields` / `output_fields`.
2. Creates a synthetic `Finish` tool (`tool=None`, `name="Finish"`) and appends it to the tool list.
3. Starts from the base `Actor` signature and **prepends** each input field (in reverse order) so the actor can see all task inputs.
4. Instantiates a `dspy.TypedPredictor` over the actor signature and keeps a deep copy (`actor_clone`) for resetting state between calls.

```mermaid
flowchart TD
    A[Avatar.__init__] --> B[ensure_signature]
    B --> C[Extract input/output fields]
    C --> D[Create Finish tool]
    D --> E[Append Finish to tools]
    E --> F[Start from Actor signature]
    F --> G[Prepend input fields in reverse]
    G --> H[Create TypedPredictor actor]
    H --> I[Deep-copy actor_clone]
```

---

## Architecture

```mermaid
graph TB
    subgraph predict_avatar_core
        Avatar
    end

    subgraph predict_avatar_models
        Tool
        Action
        ActionOutput
    end

    subgraph predict_avatar_signatures
        Actor
    end

    subgraph primitives
        Module
        Prediction
    end

    subgraph signatures
        ensure_signature
    end

    Avatar -->|subclass of| Module
    Avatar -->|uses| Tool
    Avatar -->|uses| Action
    Avatar -->|uses| ActionOutput
    Avatar -->|builds from| Actor
    Avatar -->|returns| Prediction
    Avatar -->|normalizes via| ensure_signature
```

---

## Internal Methods

### `_get_field(field_info)`

Converts a Pydantic `FieldInfo` (carrying DSPy metadata in `json_schema_extra`) back into a `dspy.InputField` or `dspy.OutputField`. This is used when re-attaching the original task's input/output fields onto the dynamically grown actor signature. Raises `ValueError` for unknown field types.

### `_update_signature(idx, omit_action=False)`

Mutates the actor's signature to reflect the current iteration:

- Marks `action_{idx}` as an **input** field of type `Action` (the action already taken).
- Appends `result_{idx}` as an **input** field holding the tool's output.
- If `omit_action=False`: appends `action_{idx+1}` as an **output** field of type `Action` (the next action to decide).
- If `omit_action=True` (i.e., the `Finish` tool was chosen): appends the original task **output fields** so the actor produces the final answer.

### `_call_tool(tool_name, tool_input_query)`

Looks up a tool by name and invokes `tool.tool.run(tool_input_query)`, returning the string result.

### `forward(**kwargs)`

The main execution loop. See the process flow below.

---

## Process Flow

```mermaid
flowchart TD
    Start([forward kwargs]) --> Init[Build args: goal, tools, inputs]
    Init --> Loop{tool_name != Finish<br/>and iters remain?}
    Loop -->|Yes| Actor[actor args -> action_idx]
    Actor --> GetTool[Extract tool_name, tool_input_query]
    GetTool --> Check{tool_name == Finish?}
    Check -->|No| CallTool[_call_tool]
    CallTool --> Append[Append ActionOutput]
    Append --> UpdateSig[_update_signature idx]
    UpdateSig --> AddArgs[args action_idx, result_idx]
    AddArgs --> Incr[idx += 1, max_iters -= 1]
    Incr --> Loop
    Check -->|Yes| OmitSig[_update_signature idx, omit_action=True]
    OmitSig --> Break[args result_idx = 'Gathered all info']
    Break --> Final
    Loop -->|No| Final[final_answer = actor args]
    Final --> Reset[actor = deepcopy actor_clone]
    Reset --> Return[Return Prediction with outputs + actions]
```

### Step-by-step

1. **Argument setup** — `goal` is set from the signature docstring; `tools` is the list of tool names; all provided input fields are copied into `args`.
2. **Iteration loop** — While the last chosen tool is not `Finish` and iterations remain:
   - Call the actor to obtain `action_{idx}`.
   - If the tool is not `Finish`: execute it, record an `ActionOutput`, grow the signature, and add the action/result to `args`.
   - If the tool is `Finish`: switch the signature to output mode, record a sentinel result, and break.
3. **Final answer** — Call the actor once more to produce the task's output fields.
4. **State reset** — Restore `self.actor` from `actor_clone` so subsequent calls start fresh.
5. **Return** — A `dspy.Prediction` containing the output fields plus an `actions` list of all `ActionOutput` records.

---

## Data Flow

```mermaid
sequenceDiagram
    participant Caller
    participant Avatar
    participant Actor as TypedPredictor(Actor)
    participant Tool

    Caller->>Avatar: forward(goal inputs)
    loop Until Finish or max_iters
        Avatar->>Actor: actor(args)
        Actor-->>Avatar: action_idx (Action)
        Avatar->>Tool: run(tool_input_query)
        Tool-->>Avatar: tool_output
        Avatar->>Avatar: _update_signature(idx)
    end
    Avatar->>Actor: actor(args) [final]
    Actor-->>Avatar: output fields
    Avatar-->>Caller: Prediction(outputs, actions)
```

---

## Key Design Notes

- **Dynamic signature growth**: Each iteration appends new input/output fields to the actor signature, giving the LM full conversational memory of prior actions and results without external memory management.
- **Synthetic `Finish` tool**: The agent signals completion by selecting the `Finish` tool, which flips the signature into output-producing mode.
- **State isolation**: `actor_clone` ensures that the mutated signature from one `forward` call does not leak into the next.
- **Iteration control**: `max_iters` can be overridden per-call via `kwargs["max_iters"]`; otherwise the constructor value is used.

---

## Related Modules

- [predict_avatar_models](predict_avatar_models.md) — `Tool`, `Action`, `ActionOutput` definitions.
- [predict_avatar_signatures](predict_avatar_signatures.md) — the `Actor` signature.
- [predict_core](predict_core.md) — the base `Predict` / `TypedPredictor` machinery.
- [primitives](primitives.md) — `Module`, `Prediction`, and `Example`.
- [signatures](signatures.md) — `Signature`, `ensure_signature`, and field types.
- [teleprompt_avatar](teleprompt_avatar.md) — the `AvatarOptimizer` that optimizes `Avatar` programs.
