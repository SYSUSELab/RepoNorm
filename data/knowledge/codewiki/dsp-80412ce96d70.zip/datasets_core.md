# Datasets Core Module

## Introduction

The `datasets_core` module provides the foundational abstractions for loading, splitting, and managing datasets within DSPy. It consists of two primary components:

- **`Dataset`** (`dspy/datasets/dataset.py`): An abstract base class that defines the standard interface for train/dev/test splits, deterministic shuffling, seed-based sampling, and reproducible multi-seed dataset preparation.
- **`DataLoader`** (`dspy/datasets/dataloader.py`): A concrete utility class that loads data from a wide variety of sources (HuggingFace, CSV, JSON, Parquet, Pandas, and retrieval modules) and converts them into DSPy `Example` objects.

Together, these components form the data backbone that benchmark datasets (e.g., `GSM8K`, `HotPotQA`, `MATH`, `Colors`) and optimization workflows (e.g., teleprompters) build upon. For the concrete benchmark implementations, see [datasets_benchmarks.md](datasets_benchmarks.md).

---

## Architecture Overview

The module sits between raw data sources and DSPy's core primitives. `Dataset` produces lists of `Example` objects, which are the universal data container consumed by modules, predictors, and optimizers.

```mermaid
graph TD
    subgraph "datasets_core"
        Dataset["Dataset<br/>(abstract base)"]
        DataLoader["DataLoader<br/>(extends Dataset)"]
    end

    subgraph "External Sources"
        HF["HuggingFace Hub"]
        CSV["CSV Files"]
        JSON["JSON Files"]
        Parquet["Parquet Files"]
        Pandas["Pandas DataFrame"]
        RM["Retrieval Module"]
    end

    subgraph "DSPy Primitives"
        Example["Example"]
        dotdict["dotdict"]
    end

    subgraph "Consumers"
        Benchmarks["Benchmark Datasets<br/>(GSM8K, HotPotQA, MATH, Colors)"]
        Teleprompters["Teleprompters / Optimizers"]
        Evaluate["Evaluate"]
    end

    HF --> DataLoader
    CSV --> DataLoader
    JSON --> DataLoader
    Parquet --> DataLoader
    Pandas --> DataLoader
    RM --> DataLoader

    DataLoader --> Example
    Dataset --> Example
    Dataset --> dotdict

    Dataset --> Benchmarks
    DataLoader --> Benchmarks
    Dataset --> Teleprompters
    DataLoader --> Teleprompters
    Dataset --> Evaluate
```

---

## Component Relationships

`DataLoader` inherits from `Dataset`, reusing its split-management machinery while adding source-specific loading methods. Benchmark datasets typically either subclass `Dataset` (e.g., `Colors`) or implement a standalone loader that produces `Example` lists directly (e.g., `GSM8K`).

```mermaid
classDiagram
    class Dataset {
        +int train_size
        +int train_seed
        +int dev_size
        +int dev_seed
        +int test_size
        +int test_seed
        +list input_keys
        +bool do_shuffle
        +str name
        +reset_seeds(...)
        +train() property
        +dev() property
        +test() property
        +_shuffle_and_sample(split, data, size, seed)
        +prepare_by_seed(...) classmethod
    }

    class DataLoader {
        +from_huggingface(...)
        +from_csv(...)
        +from_pandas(...)
        +from_json(...)
        +from_parquet(...)
        +from_rm(...)
        +sample(dataset, n)
        +train_test_split(dataset, ...)
    }

    class Example {
        +with_inputs(*keys)
        +inputs()
        +labels()
        +copy()
    }

    class dotdict {
        +__getattr__
        +__setattr__
    }

    Dataset <|-- DataLoader
    Dataset ..> Example : creates
    Dataset ..> dotdict : returns
    DataLoader ..> Example : creates
```

---

## The `Dataset` Class

`Dataset` is the abstract base class for all DSPy datasets. It manages three canonical splits — **train**, **dev**, and **test** — each with its own size and seed, and lazily materializes them on first access.

### Key Attributes

| Attribute | Description |
|-----------|-------------|
| `train_size` / `train_seed` | Number of training examples and the RNG seed used to shuffle/sample them. |
| `dev_size` / `dev_seed` | Number of development examples and its seed. |
| `test_size` / `test_seed` | Number of test examples and its seed. |
| `input_keys` | List of keys that should be marked as inputs on each `Example`. |
| `do_shuffle` | Whether to shuffle data before sampling (default `True`). |
| `name` | The class name, used for identification. |

### Lazy Split Properties

The `train`, `dev`, and `test` properties lazily compute and cache their results in `_train_`, `_dev_`, and `_test_`. On first access, each split is produced by `_shuffle_and_sample`, which:

1. Converts the raw data to a list.
2. Shuffles it deterministically using a `random.Random(seed)` instance (if `do_shuffle` is enabled).
3. Truncates to the requested `size`.
4. Wraps each record in an `Example`, attaching a unique `dspy_uuid` and the `dspy_split` name.
5. Applies `with_inputs(*input_keys)` when `input_keys` is configured.

> **Note:** Subclasses are expected to populate the private `_train`, `_dev`, and `_test` attributes with raw data (lists of dicts). The public properties then transform them into `Example` objects.

### Seed Management

`reset_seeds(...)` updates the size/seed configuration and invalidates the cached splits by deleting `_train_`, `_dev_`, and `_test_`. This forces recomputation on the next property access — essential for generating multiple independent train/eval splits from the same underlying data.

### Multi-Seed Preparation

The classmethod `prepare_by_seed` produces multiple train/eval splits for cross-validation-style workflows:

```mermaid
flowchart TD
    Start["prepare_by_seed(train_seeds, train_size, dev_size, ...)"] --> Init["Instantiate dataset"]
    Init --> EvalSet["Compute shared eval_set = dataset.dev"]
    EvalSet --> Loop{"For each train_seed"}
    Loop --> Reset["reset_seeds(train_seed=...)"]
    Reset --> Slice["Slice eval_set[eval_offset : eval_offset + examples_per_seed]"]
    Slice --> Train["Append dataset.train"]
    Train --> Offset{"divide_eval_per_seed?"}
    Offset -->|Yes| Inc["eval_offset += examples_per_seed"]
    Offset -->|No| Loop
    Inc --> Loop
    Loop -->|Done| Return["Return dotdict(train_sets, eval_sets)"]
```

- `train_seeds` defaults to `[1, 2, 3, 4, 5]`.
- When `divide_eval_per_seed=True`, the dev set is partitioned evenly across seeds so each seed gets a disjoint evaluation slice.
- Returns a `dotdict` with `train_sets` and `eval_sets` lists.

---

## The `DataLoader` Class

`DataLoader` extends `Dataset` and provides a suite of `from_*` methods that convert external data sources into lists (or mappings) of `dspy.Example` objects. Each loader accepts an `input_keys` tuple that is applied via `with_inputs`, and most accept an optional `fields` filter to select a subset of columns.

### Loading Methods

| Method | Source | Returns |
|--------|--------|---------|
| `from_huggingface(dataset_name, *args, input_keys, fields, **kwargs)` | HuggingFace Hub | `Mapping[str, list[Example]]` or `list[Example]` |
| `from_csv(file_path, fields, input_keys)` | CSV file | `list[Example]` |
| `from_pandas(df, fields, input_keys)` | Pandas DataFrame | `list[Example]` |
| `from_json(file_path, fields, input_keys)` | JSON file | `list[Example]` |
| `from_parquet(file_path, fields, input_keys)` | Parquet file | `list[Example]` |
| `from_rm(num_samples, fields, input_keys)` | Configured retrieval module | `list[Example]` |

### Validation Rules

- `fields` must be a `tuple` when provided to `from_huggingface`; otherwise a `ValueError` is raised.
- `input_keys` must be a `tuple`; otherwise a `ValueError` is raised.
- `from_rm` requires `dspy.settings.rm` to be configured and to implement `get_objects`; otherwise a descriptive `ValueError` is raised.

### Utility Methods

- **`sample(dataset, n, *args, **kwargs)`** — Returns `n` randomly sampled examples from a list, validating that the input is a list.
- **`train_test_split(dataset, train_size=0.75, test_size=None, random_state=None)`** — Splits a list of examples into train/test sets. `train_size` and `test_size` may be floats (proportions in `(0, 1)`) or ints (absolute counts). Raises `ValueError` for invalid sizes or when `train_size + test_size` exceeds the dataset length.

```mermaid
flowchart LR
    A["Input dataset (list[Example])"] --> B{"random_state set?"}
    B -->|Yes| C["Seed RNG"]
    B -->|No| D["Shuffle copy"]
    C --> D
    D --> E{"train_size type"}
    E -->|float 0-1| F["train_end = len * train_size"]
    E -->|int| G["train_end = train_size"]
    E -->|invalid| H["Raise ValueError"]
    F --> I{"test_size provided?"}
    G --> I
    I -->|Yes| J["Compute test_end"]
    I -->|No| K["test_end = len - train_end"]
    J --> L["Return {train, test}"]
    K --> L
```

---

## Data Flow

The following diagram illustrates the end-to-end flow from a raw source to a consumer such as a teleprompter or evaluator.

```mermaid
sequenceDiagram
    participant User
    participant DataLoader
    participant Source as External Source
    participant Dataset
    participant Example
    participant Consumer as Optimizer/Evaluator

    User->>DataLoader: from_huggingface("gsm8k", input_keys=("question",))
    DataLoader->>Source: load_dataset(...)
    Source-->>DataLoader: raw rows
    DataLoader->>Example: Example({...}).with_inputs("question")
    Example-->>DataLoader: Example objects
    DataLoader-->>User: list[Example]

    User->>Dataset: dataset.train
    Dataset->>Dataset: _shuffle_and_sample("train", ...)
    Dataset->>Example: attach dspy_uuid, dspy_split
    Example-->>Dataset: enriched Examples
    Dataset-->>User: list[Example]

    User->>Consumer: pass train/dev/test splits
```

---

## Integration with the Broader System

- **`Example`** ([primitives.md](primitives.md)) is the universal data container. `Dataset` and `DataLoader` both produce `Example` objects, attaching `dspy_uuid` and `dspy_split` metadata for internal tracking.
- **`dotdict`** ([dsp_utils.md](dsp_utils.md)) is used as the return type of `prepare_by_seed`, providing attribute-style access to `train_sets` and `eval_sets`.
- **Benchmark datasets** ([datasets_benchmarks.md](datasets_benchmarks.md)) such as `GSM8K`, `HotPotQA`, `MATH`, and `Colors` either subclass `Dataset` or produce `Example` lists directly, leveraging the same conventions.
- **Teleprompters and optimizers** ([teleprompt.md](teleprompt.md)) consume the train/dev/test splits produced by these classes to drive few-shot bootstrapping, instruction optimization, and evaluation.
- **`Evaluate`** ([evaluate.md](evaluate.md)) consumes the dev/test splits for metric-based assessment.

---

## Summary

The `datasets_core` module establishes DSPy's data-handling contract:

1. **`Dataset`** defines deterministic, seed-controlled, lazily-materialized train/dev/test splits and multi-seed preparation for reproducible experimentation.
2. **`DataLoader`** provides a uniform interface for ingesting data from diverse sources and normalizing it into `Example` objects.

By centralizing split management and source loading, the module ensures that every downstream component — from benchmark datasets to optimizers — operates on consistently structured, reproducible data.
