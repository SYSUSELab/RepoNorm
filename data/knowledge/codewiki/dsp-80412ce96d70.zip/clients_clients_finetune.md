# Clients Finetune Module

## Introduction

The `clients_clients_finetune` module provides the **data format definitions, validation utilities, and persistence helpers** that underpin DSPy's fine-tuning and reinforcement-learning (GRPO) workflows. It is the shared "contract layer" between the higher-level optimizers (such as `BootstrapFinetune` and `GRPO`) and the provider-specific fine-tuning implementations (OpenAI, Databricks, Arbor, etc.).

The module is intentionally small and focused. It answers three questions:

1. **What shape should training data take?** — via the `TrainDataFormat` enum and the `Message` / `GRPOChatData` typed dictionaries.
2. **Is the data valid?** — via `validate_data_format` and its per-format error finders.
3. **Where does the data live on disk?** — via `get_finetune_directory` and `save_data`.

> **Note:** This module is a leaf dependency. It does not perform any actual fine-tuning; it only prepares and validates the data that providers consume. For the orchestration logic, see [teleprompt_bootstrap_finetune](teleprompt_bootstrap_finetune.md) and [teleprompt_grpo](teleprompt_grpo.md). For the provider interface that consumes this data, see [clients_clients_providers](clients_clients_providers.md).

---

## Core Components

### `TrainDataFormat` (Enum)

The central abstraction of the module. It enumerates the supported serialization formats for training data:

| Value | String | Description |
|-------|--------|-------------|
| `TrainDataFormat.CHAT` | `"chat"` | OpenAI-style chat fine-tuning data: a list of `{"messages": [...]}` records. |
| `TrainDataFormat.COMPLETION` | `"completion"` | Legacy completion fine-tuning data: `{"prompt": ..., "completion": ...}` records. |
| `TrainDataFormat.GRPO_CHAT` | `"grpo_chat"` | Reinforcement-learning data: chat messages paired with a completion and a scalar reward. |

The format is inferred from the adapter in use (see `infer_data_format`) and passed down to `Provider.finetune(...)` / `ReinforceJob.step(...)`.

### Typed Dictionaries

These `TypedDict` definitions describe the in-memory shape of GRPO training records:

- **`Message`** — a single chat turn with `role` (`"user" | "assistant" | "system"`) and `content`.
- **`MessageAssistant`** — a restricted `Message` whose role is always `"assistant"`; used for the model's completion.
- **`GRPOChatData`** — one rollout: `messages` (the prompt), `completion` (the assistant response), and a `reward` (float).
- **`GRPOGroup`** — a `list[GRPOChatData]`; a group of rollouts for the same prompt, used to compute relative advantages in GRPO.

### `TrainingStatus` (Enum)

Tracks the lifecycle of a fine-tuning job: `not_started`, `pending`, `running`, `succeeded`, `failed`, `cancelled`. Consumed by `TrainingJob.status()` implementations in providers.

### Utility Functions

| Function | Purpose |
|----------|---------|
| `infer_data_format(adapter)` | Maps an `Adapter` instance to a `TrainDataFormat`. Currently only `ChatAdapter` is supported. |
| `get_finetune_directory()` | Resolves (and creates) the directory where fine-tuning artifacts are stored. Honors the `DSPY_FINETUNEDIR` env var, defaulting to `<DSPY_CACHEDIR>/finetune`. |
| `save_data(data)` | Hashes the data, writes it to a content-addressed `.jsonl` file, and returns the absolute path. |
| `write_lines(file_path, data)` | Low-level helper that writes a list of dicts as newline-delimited JSON. |
| `validate_data_format(data, data_format)` | Dispatches to the correct per-format validator and raises `ValueError` with a log file path on failure. |
| `find_data_errors_completion(data_dict)` | Validates a single completion-format record. |
| `find_data_error_chat(messages)` | Validates a single chat-format record (list of messages). |
| `find_data_error_chat_message(message)` | Validates a single chat message (role + content). |

---

## Architecture

The module sits between the optimizers that *produce* training data and the providers that *consume* it.

```mermaid
graph TD
    subgraph Optimizers
        BF[BootstrapFinetune]
        GRPO[GRPO]
    end

    subgraph "clients_clients_finetune"
        TDF[TrainDataFormat]
        IDF[infer_data_format]
        VDF[validate_data_format]
        SD[save_data]
        GFD[get_finetune_directory]
        TYPES["Message / GRPOChatData / GRPOGroup"]
    end

    subgraph Providers
        P[Provider.finetune]
        RJ[ReinforceJob.step]
    end

    subgraph Adapters
        CA[ChatAdapter]
    end

    BF --> IDF
    BF --> SD
    GRPO --> TDF
    GRPO --> TYPES
    IDF --> CA
    IDF --> TDF
    VDF --> TDF
    SD --> GFD
    TDF --> P
    TDF --> RJ
    TYPES --> RJ
```

### Component Relationships

```mermaid
classDiagram
    class TrainDataFormat {
        <<enum>>
        CHAT
        COMPLETION
        GRPO_CHAT
    }
    class TrainingStatus {
        <<enum>>
        not_started
        pending
        running
        succeeded
        failed
        cancelled
    }
    class Message {
        <<TypedDict>>
        role
        content
    }
    class MessageAssistant {
        <<TypedDict>>
        role = assistant
        content
    }
    class GRPOChatData {
        <<TypedDict>>
        messages: list[Message]
        completion: MessageAssistant
        reward: float
    }
    GRPOChatData --> Message
    GRPOChatData --> MessageAssistant
    TrainDataFormat ..> GRPOChatData : GRPO_CHAT uses
```

---

## Data Flow

### Fine-Tuning Data Preparation (BootstrapFinetune path)

```mermaid
sequenceDiagram
    participant BF as BootstrapFinetune
    participant IDF as infer_data_format
    participant AD as ChatAdapter
    participant SD as save_data
    participant P as Provider.finetune

    BF->>AD: adapter = self.adapter[lm] or ChatAdapter()
    BF->>IDF: infer_data_format(adapter)
    IDF-->>BF: TrainDataFormat.CHAT
    BF->>BF: build_call_data_from_trace(...)
    BF->>SD: save_data(data)
    SD->>SD: hash(data) -> <hash>.jsonl
    SD-->>BF: file_path
    BF->>P: finetune(job, model, train_data, train_data_format, train_kwargs)
```

### GRPO Data Preparation (Reinforcement path)

```mermaid
sequenceDiagram
    participant GRPO as GRPO
    participant AD as ChatAdapter
    participant RJ as ReinforceJob

    GRPO->>AD: adapter.format(signature, inputs, demos=[])
    AD-->>GRPO: inp_messages
    GRPO->>AD: adapter.format_finetune_data(...)
    AD-->>GRPO: all_messages
    GRPO->>GRPO: build GRPOChatData{messages, completion, reward}
    GRPO->>GRPO: group into GRPOGroup (num_rollouts_per_grpo_step)
    GRPO->>RJ: step(train_data, train_data_format=GRPO_CHAT)
```

---

## Validation Process Flow

`validate_data_format` is the gatekeeper that ensures data conforms to the expected schema before it is handed to a provider. It dispatches to format-specific validators and, on failure, writes a detailed error log.

```mermaid
flowchart TD
    Start([validate_data_format]) --> CheckFormat{data_format in<br/>find_err_funcs?}
    CheckFormat -- No --> RaiseUnsupported[raise ValueError:<br/>format not supported]
    CheckFormat -- Yes --> CheckList{isinstance data, list?}
    CheckList -- No --> RaiseNotList[raise ValueError:<br/>not a list]
    CheckList -- Yes --> Loop[for each data_dict]
    Loop --> IsDict{isinstance dict?}
    IsDict -- No --> AddErr1[record 'not a dictionary']
    IsDict -- Yes --> FindErr[find_err_func data_dict]
    FindErr --> HasErr{error found?}
    AddErr1 --> HasErr
    HasErr -- Yes --> Collect[append to data_dict_errors]
    HasErr -- No --> Next[continue]
    Collect --> Next
    Next --> More{more items?}
    More -- Yes --> Loop
    More -- No --> AnyErrors{data_dict_errors<br/>non-empty?}
    AnyErrors -- Yes --> WriteLog[write data_format_errors.log]
    WriteLog --> RaiseErr[raise ValueError:<br/>see log file]
    AnyErrors -- No --> Done([valid])
```

### Format-Specific Rules

**Completion format** (`find_data_errors_completion`):
- Must contain exactly the keys `prompt` and `completion`.
- Both values must be `str`.

**Chat format** (`find_data_error_chat` → `find_data_error_chat_message`):
- Must contain exactly the key `messages`, whose value is a `list`.
- Each message must contain exactly `role` and `content`.
- `role` must be one of `assistant`, `system`, `user`.
- `content` must be a `str`.

> The chat validation logic is adapted from the [OpenAI chat fine-tuning data prep cookbook](https://cookbook.openai.com/examples/chat_finetuning_data_prep).

---

## Persistence & Caching

Training data is persisted as content-addressed JSONL files, which makes repeated fine-tuning runs idempotent and cache-friendly.

```mermaid
flowchart LR
    Data[list of dicts] --> Hasher[datasets.fingerprint.Hasher.hash]
    Hasher --> Hash[hash string]
    Hash --> Filename["<hash>.jsonl"]
    Filename --> Dir[get_finetune_directory]
    Dir --> Env{DSPY_FINETUNEDIR<br/>set?}
    Env -- Yes --> CustomDir[custom dir]
    Env -- No --> DefaultDir["DSPY_CACHEDIR/finetune"]
    CustomDir --> Write[write JSONL]
    DefaultDir --> Write
    Write --> Path[return absolute path]
```

Key behaviors:
- **Content addressing:** identical data always maps to the same file name, avoiding redundant writes.
- **Directory resolution:** `DSPY_FINETUNEDIR` overrides the default `<DSPY_CACHEDIR>/finetune` location; the directory is created on demand.
- **Serialization:** uses `ujson` for fast newline-delimited JSON output.

---

## Integration Points

| Consumer | How it uses this module |
|----------|-------------------------|
| [`BootstrapFinetune`](teleprompt_bootstrap_finetune.md) | Calls `infer_data_format` to determine the format, then `save_data` to persist trace-derived training data before invoking `LM.finetune`. |
| [`GRPO`](teleprompt_grpo.md) | Builds `GRPOChatData` / `GRPOGroup` structures and passes `TrainDataFormat.GRPO_CHAT` to `ReinforceJob.step`. |
| [`Provider`](clients_clients_providers.md) | Receives `train_data_format` in `finetune(...)` and `ReinforceJob.step(...)` to decide how to serialize requests to the backend. |
| [`ChatAdapter`](adapters_core.md) | The only adapter currently recognized by `infer_data_format`; provides `format` and `format_finetune_data` used to build chat records. |
| [`LM`](clients_lm.md) | Exposes `finetune(...)` and `reinforce(...)` which thread the format through to the provider. |

---

## Design Notes & Constraints

- **Adapter coupling:** `infer_data_format` currently only supports `ChatAdapter`. Adding a new format requires extending both the enum and the inference function.
- **GRPO format is chat-only:** GRPO training asserts that the adapter is a `ChatAdapter`; other adapters are rejected.
- **Validation is strict:** chat records must contain *exactly* the expected keys — extra keys cause validation failure.
- **Error observability:** validation failures are logged to `data_format_errors.log` in the fine-tune directory, with per-record index and error message, rather than dumping all errors into the exception.
- **No network I/O:** this module is purely local — it never contacts a provider or model.

---

## Related Documentation

- [clients_lm](clients_lm.md) — `LM` and `BaseLM`, including `finetune` / `reinforce` entry points.
- [clients_clients_providers](clients_clients_providers.md) — provider implementations that consume `TrainDataFormat`.
- [teleprompt_bootstrap_finetune](teleprompt_bootstrap_finetune.md) — supervised fine-tuning orchestration.
- [teleprompt_grpo](teleprompt_grpo.md) — reinforcement-learning (GRPO) orchestration.
- [adapters_core](adapters_core.md) — `Adapter` and `ChatAdapter` formatting logic.
