# Clients Providers

## Overview

The **clients_providers** module implements the concrete provider backends that power DSPy's language model (LM) lifecycle management. While the abstract [`Provider`](clients_clients_providers.md) interface (defined in `dspy/clients/provider.py`) specifies *what* a provider must do, this module provides the *how* for four distinct backends:

- **OpenAI** — remote fine-tuning and inference via the OpenAI API.
- **Databricks** — fine-tuning and serving endpoints on the Databricks platform.
- **Local (SGLang)** — launching local inference servers and running local SFT training.
- **Arbor** — a remote training/inference server supporting both supervised fine-tuning (SFT) and GRPO reinforcement learning.

Each provider is responsible for three broad capabilities:

1. **Model discovery** — deciding whether a given model string belongs to the provider (`is_provider_model`).
2. **Inference lifecycle** — launching and killing inference servers (`launch` / `kill`).
3. **Training lifecycle** — fine-tuning models (`finetune`) and, for reinforcement-learning-capable providers, running GRPO steps (`ReinforceJob`).

## Architecture

All providers inherit from the abstract `Provider` base class and are paired with a `TrainingJob` (and optionally a `ReinforceJob`) subclass that tracks the asynchronous state of a training run.

```mermaid
classDiagram
    class Provider {
        +bool finetunable
        +bool reinforceable
        +TrainingJob TrainingJob
        +ReinforceJob ReinforceJob
        +is_provider_model(model) bool
        +launch(lm, launch_kwargs)
        +kill(lm, launch_kwargs)
        +finetune(job, model, train_data, train_data_format, train_kwargs) str
    }

    class TrainingJob {
        <<Future>>
        +thread
        +model
        +train_data
        +train_data_format
        +train_kwargs
        +cancel()
        +status() TrainingStatus
    }

    class ReinforceJob {
        +lm
        +train_kwargs
        +checkpoints
        +initialize()
        +step(train_data, train_data_format)
        +terminate()
        +save_checkpoint(name)
    }

    Provider <|-- OpenAIProvider
    Provider <|-- DatabricksProvider
    Provider <|-- LocalProvider
    Provider <|-- ArborProvider

    TrainingJob <|-- TrainingJobOpenAI
    TrainingJob <|-- TrainingJobDatabricks
    TrainingJob <|-- ArborTrainingJob

    ReinforceJob <|-- ArborReinforceJob

    OpenAIProvider --> TrainingJobOpenAI
    DatabricksProvider --> TrainingJobDatabricks
    ArborProvider --> ArborTrainingJob
    ArborProvider --> ArborReinforceJob
    LocalProvider --> TrainingJob
```

### Provider Capability Matrix

| Provider | Inference Launch/Kill | Fine-tuning | Reinforcement (GRPO) | Model Auto-discovery |
|----------|:---------------------:|:-----------:|:--------------------:|:--------------------:|
| `OpenAIProvider` | ✗ | ✓ | ✗ | ✓ |
| `DatabricksProvider` | ✗ | ✓ | ✗ | ✗ |
| `LocalProvider` | ✓ (SGLang) | ✓ (local SFT) | ✗ | ✗ |
| `ArborProvider` | ✓ (remote) | ✓ | ✓ | ✗ |

## Shared Foundations

All providers build on shared abstractions and utilities that are documented in the sibling module [`clients_clients_providers`](clients_clients_providers.md):

- **`Provider`** — the abstract base class defining the provider contract.
- **`TrainingJob`** — a `Future` subclass representing an asynchronous training run.
- **`ReinforceJob`** — the abstract base for reinforcement-learning jobs.
- **`TrainDataFormat`** / **`TrainingStatus`** — enums describing data layouts and job states.
- **`save_data`** / **`get_finetune_directory`** — helpers for persisting training data to the local finetune cache.

The training data formats and status enums are shared across every provider, ensuring a consistent contract between DSPy teleprompters (e.g. [`BootstrapFinetune`](teleprompt.md), [`GRPO`](teleprompt.md)) and the underlying backends.

## Sub-modules

The module is organized into four provider-specific sub-modules. Each is documented in detail in its own file:

### 1. OpenAI Provider — [`clients_providers_openai.md`](clients_providers_openai.md)
Implements `OpenAIProvider` and `TrainingJobOpenAI`. Handles model auto-discovery against a curated list of OpenAI models (including fine-tuned `ft:` models), uploads training data, starts remote fine-tuning jobs, polls job events, and retrieves the resulting fine-tuned model.

### 2. Databricks Provider — [`clients_providers_databricks.md`](clients_providers_databricks.md)
Implements `DatabricksProvider` and `TrainingJobDatabricks`. Manages the full Databricks lifecycle: uploading data to Unity Catalog, creating foundation-model fine-tuning runs, and deploying the resulting model as a provisioned-throughput serving endpoint.

### 3. Local Provider — [`clients_providers_local.md`](clients_providers_local.md)
Implements `LocalProvider`. Launches and kills local SGLang inference servers (with log capture and readiness polling) and runs local supervised fine-tuning using HuggingFace `transformers` and `trl`, including optional PEFT/LoRA merging.

### 4. Arbor Provider — [`clients_providers_arbor.md`](clients_providers_arbor.md)
Implements `ArborProvider`, `ArborTrainingJob`, `ArborReinforceJob`, and `GRPOTrainKwargs`. Provides a remote server-backed provider supporting both SFT and GRPO reinforcement learning, with checkpointing, job polling, and model-prefix management.

## Provider Selection and Data Flow

DSPy selects a provider based on the model string. The `is_provider_model` hook allows providers to claim models for auto-discovery, while explicit prefixes (e.g. `openai/`, `databricks/`, `arbor:`) route requests to specific backends.

```mermaid
flowchart TD
    A[Model string] --> B{Provider auto-discovery}
    B -->|matches OpenAI list| C[OpenAIProvider]
    B -->|no match| D[Explicit prefix routing]
    D -->|openai/| C
    D -->|databricks/| E[DatabricksProvider]
    D -->|local:| F[LocalProvider]
    D -->|arbor:| G[ArborProvider]

    C --> H[finetune / launch]
    E --> H
    F --> H
    G --> H

    H --> I[TrainingJob / ReinforceJob]
    I --> J[status polling]
    J --> K[retrieve trained model]
```

## Training Lifecycle (Common Pattern)

Despite their differences, all providers follow a common fine-tuning workflow, illustrated below:

```mermaid
sequenceDiagram
    participant TP as Teleprompter
    participant P as Provider
    participant J as TrainingJob
    participant Backend as Remote/Local Backend

    TP->>P: finetune(job, model, train_data, format, kwargs)
    P->>P: validate_data_format(format)
    P->>P: save_data(train_data)
    P->>Backend: upload_data(data_path)
    P->>Backend: start_remote_training(...)
    P->>J: set provider_job_id
    loop until terminal status
        P->>Backend: poll job status / events
        Backend-->>P: status
    end
    P->>Backend: get_trained_model(job)
    Backend-->>P: fine-tuned model name
    P-->>TP: model string
```

## Related Modules

- [`clients_clients_providers`](clients_clients_providers.md) — abstract `Provider`, `TrainingJob`, and `ReinforceJob` base classes.
- [`clients_finetune`](clients_finetune.md) — shared finetuning utilities (`TrainDataFormat`, `TrainingStatus`, `save_data`, `GRPOChatData`).
- [`clients_lm`](clients_lm.md) — the `LM` class that consumes providers for inference and training.
- [`teleprompt`](teleprompt.md) — optimizers such as `BootstrapFinetune` and `GRPO` that drive provider training.
