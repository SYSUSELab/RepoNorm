# Program Evaluation (`evaluate_program_evaluation`)

## Introduction

The `evaluate_program_evaluation` module provides the core machinery for **measuring the performance of a DSPy program** against a labeled dataset using a user-supplied metric function. It is the backbone of DSPy's evaluation story: optimizers, teleprompters, and end users all rely on it to obtain a quantitative score for a program.

The module exposes two primary components:

- **`Evaluate`** — a configurable evaluator that runs a program over a `devset`, applies a metric to each `(example, prediction)` pair, aggregates the scores, and optionally renders a results table.
- **`EvaluationResult`** — a `Prediction` subclass that carries the aggregate `score` and the per-example `results` list.

> For automatic, LLM-judged metrics (e.g. `SemanticF1`, `CompleteAndGrounded`) that are commonly passed as the `metric` argument, see [evaluate_auto_metrics](evaluate_auto_metrics.md).

---

## Module Architecture

The module is intentionally small and delegates heavy lifting to other subsystems: parallel execution, callbacks, and the `Prediction`/`Example` primitives.

```mermaid
graph TD
    subgraph "evaluate_program_evaluation"
        E[Evaluate]
        ER[EvaluationResult]
    end

    subgraph "dspy.utils"
        PE[ParallelExecutor]
        CB[with_callbacks]
    end

    subgraph "dspy.primitives"
        PR[Prediction]
        EX[Example]
    end

    subgraph "dspy"
        MOD[Module / program]
        SET[settings]
    end

    E -->|uses| PE
    E -->|decorated by| CB
    E -->|calls| MOD
    E -->|reads| SET
    ER -->|subclass of| PR
    PR -->|subclass of| EX
    E -->|produces| ER
    E -->|iterates| EX
```

### Component Responsibilities

| Component | Responsibility |
|-----------|----------------|
| `Evaluate` | Orchestrates evaluation: resolves config, runs the program in parallel, applies the metric, aggregates scores, and optionally displays a table. |
| `EvaluationResult` | Immutable-ish result container holding the aggregate `score` (float percentage) and the list of `(example, prediction, score)` tuples. |
| `ParallelExecutor` | Provides thread-isolated, fault-tolerant parallel execution with progress bars, error limits, and straggler timeouts. |
| `with_callbacks` | Wraps `Evaluate.__call__` so that global/instance callbacks fire on start and end of evaluation. |
| `Prediction` / `Example` | Data primitives used for inputs, predictions, and the result container. |

---

## Core Components

### `Evaluate`

`Evaluate` is the public entry point. It is constructed with a `devset` and (optionally) a `metric`, then invoked with a `program`.

#### Constructor Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `devset` | `list[dspy.Example]` | — | The evaluation dataset. |
| `metric` | `Callable \| None` | `None` | Metric function `(example, prediction) -> score`. |
| `num_threads` | `int \| None` | `None` | Threads for parallel evaluation; falls back to `settings.num_threads`. |
| `display_progress` | `bool` | `False` | Show a `tqdm` progress bar. |
| `display_table` | `bool \| int` | `False` | Render a results table; an `int` truncates to that many rows. |
| `max_errors` | `int \| None` | `None` | Max errors before aborting; falls back to `settings.max_errors`. |
| `provide_traceback` | `bool \| None` | `None` | Include tracebacks in error logs. |
| `failure_score` | `float` | `0.0` | Score assigned when an example raises an exception. |

#### `__call__` Parameters

`__call__` accepts per-invocation overrides for `metric`, `devset`, `num_threads`, `display_progress`, and `display_table`. Any value left as `None` falls back to the constructor value. It also accepts `callback_metadata` for callback handlers.

#### Return Value

Returns an `EvaluationResult` with:

- `score`: a float percentage (e.g. `67.30`).
- `results`: a list of `(example, prediction, score)` tuples.

### `EvaluationResult`

```python
class EvaluationResult(Prediction):
    def __init__(self, score: float, results: list[tuple[Example, Example, Any]]):
        super().__init__(score=score, results=results)
```

Because it subclasses `Prediction` (which subclasses `Example`), the result supports attribute access (`result.score`), item access (`result["score"]`), and the arithmetic/comparison operators inherited from `Prediction` (useful for feedback-augmented scores). See [primitives](primitives.md) for the full `Prediction`/`Example` API.

---

## Evaluation Flow

The following sequence diagram shows how a single `Evaluate.__call__` invocation proceeds.

```mermaid
sequenceDiagram
    participant User
    participant Eval as Evaluate
    participant CB as with_callbacks
    participant PE as ParallelExecutor
    participant Prog as Program (Module)
    participant Metric as metric()

    User->>Eval: __call__(program, ...)
    Eval->>CB: start callbacks (call_id, inputs)
    Eval->>Eval: resolve metric/devset/threads/display
    Eval->>PE: execute(process_item, devset)
    loop for each example (parallel)
        PE->>Prog: program(**example.inputs())
        Prog-->>PE: prediction
        PE->>Metric: metric(example, prediction)
        Metric-->>PE: score
    end
    PE-->>Eval: results list
    Eval->>Eval: substitute failure_score for None
    Eval->>Eval: aggregate ncorrect / ntotal
    opt display_table
        Eval->>Eval: build & display DataFrame
    end
    Eval->>CB: end callbacks (outputs)
    Eval-->>User: EvaluationResult(score, results)
```

### Step-by-step

1. **Callback start** — `with_callbacks` fires `on_start` handlers with the resolved inputs.
2. **Config resolution** — per-call arguments override constructor defaults.
3. **Parallel execution** — a `ParallelExecutor` is created with `compare_results=True` (so the progress bar shows the running average metric) and the resolved `max_errors`/`provide_traceback`.
4. **Per-item processing** — `process_item(example)` runs `program(**example.inputs())` then `metric(example, prediction)`.
5. **Failure handling** — any `None` result (from an exception or cancellation) is replaced with `(Prediction(), failure_score)`.
6. **Aggregation** — `ncorrect = sum(scores)`, `ntotal = len(devset)`, and the average is logged.
7. **Optional table** — if `display_table` is truthy and `pandas` is installed, a DataFrame is built and displayed.
8. **Callback end** — `on_end` handlers fire with the `EvaluationResult`.
9. **Return** — an `EvaluationResult` with `score = round(100 * ncorrect / ntotal, 2)`.

---

## Result Table Rendering

When `display_table` is enabled, the module builds a pandas `DataFrame` and renders it either in an IPython notebook or the console.

```mermaid
flowchart TD
    A[results list] --> B{prediction is dict-like?}
    B -->|yes| C[merge_dicts example + prediction]
    B -->|no| D[dict example + prediction + correct]
    C --> E[build DataFrame]
    D --> E
    E --> F[truncate_cell each cell to 25 words]
    F --> G[rename 'correct' -> metric_name]
    G --> H{display_table is int?}
    H -->|yes| I[head N rows + truncation notice]
    H -->|no| J[full DataFrame]
    I --> K[stylize_metric_name]
    J --> K
    K --> L{IPython notebook?}
    L -->|yes| M[display with notebook options]
    L -->|no| N[print to console]
```

### Helper Functions

| Function | Purpose |
|----------|---------|
| `prediction_is_dictlike` | Detects whether a prediction supports `.items()` for merging. |
| `merge_dicts` | Merges example and prediction dicts, prefixing collisions with `example_` / `pred_`. |
| `truncate_cell` | Truncates a cell's content to 25 words. |
| `stylize_metric_name` | Formats metric cells with a ✔️ and the numeric value. |
| `display_dataframe` | Displays the DataFrame in a notebook or console. |
| `configure_dataframe_for_ipython_notebook_display` | Sets pandas display options for notebooks. |
| `is_in_ipython_notebook_environment` | Best-effort detection of an IPython kernel. |

> **Note:** Table display requires `pandas`. If it is not installed, a warning is logged and the table is skipped.

---

## Dependencies

```mermaid
graph LR
    subgraph "evaluate_program_evaluation"
        E[Evaluate]
    end
    E --> PE[ParallelExecutor]
    E --> CB[with_callbacks]
    E --> PR[Prediction]
    E --> EX[Example]
    E --> SET[dspy.settings]
    E -.optional.-> PD[pandas]
    E -.optional.-> IPY[IPython]
    E --> TQDM[tqdm]
```

| Dependency | Module | Role |
|------------|--------|------|
| `ParallelExecutor` | [utils](utils.md) | Thread-isolated parallel execution, error limits, straggler handling. |
| `with_callbacks` | [utils](utils.md) | Callback lifecycle around `__call__`. |
| `Prediction` | [primitives](primitives.md) | Base class for `EvaluationResult`. |
| `Example` | [primitives](primitives.md) | Input/output data container. |
| `dspy.settings` | [dsp_utils](dsp_utils.md) | Defaults for `num_threads`, `max_errors`, `provide_traceback`. |
| `pandas` | external (optional) | Result table construction/display. |
| `IPython` | external (optional) | Notebook-aware table display. |
| `tqdm` | external | Progress bar (also used inside `ParallelExecutor`). |

---

## Error Handling & Robustness

- **Per-example isolation** — exceptions raised by the program or metric are caught by `ParallelExecutor._wrap_function`; the item yields `None` and is later replaced with `failure_score`.
- **Error budget** — once `max_errors` is reached, `cancel_jobs` is set and execution aborts with an exception.
- **Straggler timeouts** — `ParallelExecutor` resubmits slow tasks (default `timeout=120s`, `straggler_limit=3`).
- **Interrupt handling** — `SIGINT` (Ctrl-C) in the main thread cancels outstanding jobs.
- **Traceback control** — set `provide_traceback=True` to log full tracebacks for failures.

---

## Usage Example

```python
import dspy

# Define a metric
def exact_match(example, pred, trace=None):
    return example.answer == pred.answer

# Build the evaluator
evaluator = dspy.Evaluate(
    devset=my_devset,
    metric=exact_match,
    num_threads=8,
    display_progress=True,
    display_table=5,
)

# Run evaluation
result = evaluator(my_program)
print(result.score)          # e.g. 67.30
print(len(result.results))   # number of examples
```

---

## Related Modules

- [evaluate_auto_metrics](evaluate_auto_metrics.md) — LLM-judged metrics (`SemanticF1`, `CompleteAndGrounded`, etc.) commonly used as the `metric` argument.
- [primitives](primitives.md) — `Example`, `Prediction`, `Module`, and `BaseModule`.
- [utils](utils.md) — `ParallelExecutor`, `with_callbacks`, and other utilities.
- [dsp_utils](dsp_utils.md) — `Settings` and thread-local overrides.
- [teleprompt](teleprompt.md) — optimizers that consume `Evaluate` for scoring candidate programs.
