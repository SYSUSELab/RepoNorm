# Teleprompt Few-Shot Optimizers

## Introduction

The **teleprompt_fewshot** module is a collection of DSPy optimizers (teleprompters) that improve program performance by automatically constructing and selecting **few-shot demonstrations** for a program's predictors. Rather than modifying model weights or hand-crafting prompts, these optimizers populate the `demos` attribute of each `Predict` module with curated `Example` objects drawn from a training set.

The module provides a spectrum of strategies, ranging from the simplest possible baseline (random labeled examples) to sophisticated bootstrapping and search-based approaches:

- **`LabeledFewShot`** — the simplest baseline: sample `k` labeled examples directly from the trainset.
- **`BootstrapFewShot`** — the foundational optimizer: run a *teacher* program to generate successful traces, then use those traces as demonstrations.
- **`BootstrapFewShotWithRandomSearch`** — runs `BootstrapFewShot` across many random seeds and selects the best-scoring candidate program.
- **`BootstrapFewShotWithOptuna`** — uses Optuna hyperparameter search to select the best subset of bootstrapped demos.
- **`KNNFewShot`** — retrieves the `k` nearest neighbors at *test time* using an in-memory KNN retriever.
- **`InferRules`** — extends bootstrapping by inducing natural-language rules from examples and injecting them into signatures.

All optimizers inherit from the shared [`Teleprompter`](teleprompt_core.md) base class and return a compiled `Module` whose predictors carry the selected demonstrations.

---

## Architecture Overview

The module is organized around a layered inheritance and composition hierarchy. `LabeledFewShot` and `BootstrapFewShot` are the two foundational building blocks; the remaining optimizers compose or extend them.

```mermaid
graph TD
    Teleprompter["Teleprompter<br/>(teleprompt_core)"]

    Teleprompter --> LabeledFewShot
    Teleprompter --> BootstrapFewShot
    Teleprompter --> KNNFewShot

    BootstrapFewShot --> BootstrapFewShotWithRandomSearch
    BootstrapFewShot --> BootstrapFewShotWithOptuna
    BootstrapFewShot --> InferRules

    LabeledFewShot -.->|used by| BootstrapFewShot
    LabeledFewShot -.->|used by| BootstrapFewShotWithRandomSearch
    BootstrapFewShot -.->|used by| BootstrapFewShotWithRandomSearch
    BootstrapFewShot -.->|used by| BootstrapFewShotWithOptuna
    BootstrapFewShot -.->|used by| KNNFewShot
    BootstrapFewShot -.->|used by| InferRules

    classDef base fill:#e1f5ff,stroke:#0288d1
    classDef core fill:#fff3e0,stroke:#f57c00
    classDef derived fill:#f3e5f5,stroke:#7b1fa2
    class Teleprompter base
    class LabeledFewShot,BootstrapFewShot core
    class BootstrapFewShotWithRandomSearch,BootstrapFewShotWithOptuna,KNNFewShot,InferRules derived
```

### Component Roles

| Component | File | Role |
|-----------|------|------|
| `LabeledFewShot` | `vanilla.py` | Baseline: samples labeled demos directly. |
| `BootstrapFewShot` | `bootstrap.py` | Core: generates demos via teacher traces. |
| `BootstrapFewShotWithRandomSearch` | `random_search.py` | Search: many seeds, pick best. |
| `BootstrapFewShotWithOptuna` | `teleprompt_optuna.py` | Search: Optuna-driven demo selection. |
| `KNNFewShot` | `knn_fewshot.py` | Retrieval: test-time nearest-neighbor demos. |
| `InferRules` / `RulesInductionProgram` | `infer_rules.py` | Rule induction on top of bootstrapping. |

---

## Dependencies

The module depends on several other DSPy subsystems. The diagram below shows the primary external dependencies.

```mermaid
graph LR
    subgraph teleprompt_fewshot
        LFS[LabeledFewShot]
        BFS[BootstrapFewShot]
        BFSRS[BootstrapFewShotWithRandomSearch]
        BFSO[BootstrapFewShotWithOptuna]
        KNNFS[KNNFewShot]
        IR[InferRules]
    end

    subgraph primitives
        Module[Module]
        Example[Example]
    end

    subgraph predict
        Predict[Predict]
        KNN[KNN]
    end

    subgraph evaluate
        Evaluate[Evaluate]
    end

    subgraph clients
        Embedder[Embedder]
    end

    subgraph teleprompt_core
        Teleprompter[Teleprompter]
    end

    LFS --> Teleprompter
    BFS --> Teleprompter
    KNNFS --> Teleprompter
    BFSRS --> Teleprompter
    BFSO --> Teleprompter
    IR --> BFS

    BFS --> Module
    BFS --> Example
    BFS --> Predict
    BFSRS --> Evaluate
    BFSO --> Evaluate
    IR --> Evaluate
    KNNFS --> KNN
    KNNFS --> Embedder
    KNN --> Embedder
```

Key dependency notes:

- **`Module` / `Predict`** ([primitives_module_system.md](primitives_module_system.md), [predict_core.md](predict_core.md)): Optimizers manipulate `predictor.demos` on each `Predict` instance discovered via `student.named_predictors()`.
- **`Example`** ([primitives_data_containers.md](primitives_data_containers.md)): The unit of demonstration data. Bootstrapped demos are constructed as `dspy.Example(augmented=True, **inputs, **outputs)`.
- **`Evaluate`** ([evaluate_program_evaluation.md](evaluate_program_evaluation.md)): Used by search-based optimizers to score candidate programs.
- **`KNN` / `Embedder`** ([predict_execution.md](predict_execution.md), [clients_embedding.md](clients_embedding.md)): Used by `KNNFewShot` for test-time retrieval.
- **`Teleprompter`** ([teleprompt_core.md](teleprompt_core.md)): The abstract base class defining the `compile` contract.

---

## Core Optimizers

### LabeledFewShot

The simplest optimizer. It copies the student, then assigns `k` examples from the trainset to every predictor's `demos` attribute.

```python
class LabeledFewShot(Teleprompter):
    def __init__(self, k=16):
        self.k = k

    def compile(self, student, *, trainset, sample=True):
        self.student = student.reset_copy()
        self.trainset = trainset
        if len(self.trainset) == 0:
            return self.student
        rng = random.Random(0)
        for predictor in self.student.predictors():
            if sample:
                predictor.demos = rng.sample(self.trainset, min(self.k, len(self.trainset)))
            else:
                predictor.demos = self.trainset[: min(self.k, len(self.trainset))]
        return self.student
```

**Behavior:**
- Uses a fixed seed (`random.Random(0)`) for reproducibility.
- `sample=True` performs random sampling; `sample=False` takes the first `k` examples.
- Returns the student unchanged if the trainset is empty.

**Role in the module:** Serves as the baseline and as a building block for `BootstrapFewShot` (to seed the teacher with labeled demos) and `BootstrapFewShotWithRandomSearch` (the "labels only" candidate).

---

### BootstrapFewShot

The foundational optimizer. It runs a *teacher* program over the trainset, captures successful execution traces, and converts those traces into demonstrations for the *student*.

```mermaid
flowchart TD
    Start([compile]) --> Prep["_prepare_student_and_teacher<br/>reset_copy student, deepcopy teacher"]
    Prep --> Seed{"teacher compiled?"}
    Seed -->|No| Label["LabeledFewShot seeds teacher<br/>with max_labeled_demos"]
    Seed -->|Yes| Map
    Label --> Map["_prepare_predictor_mappings<br/>validate structure & signatures"]
    Map --> Boot["_bootstrap<br/>iterate trainset, run teacher"]
    Boot --> One["_bootstrap_one_example<br/>capture trace, apply metric"]
    One --> Train["_train<br/>attach augmented + raw demos"]
    Train --> Done([compiled student])
```

**Key methods:**

| Method | Purpose |
|--------|---------|
| `compile(student, *, teacher, trainset)` | Orchestrates the full bootstrap pipeline. |
| `_prepare_student_and_teacher` | Creates a `reset_copy` of the student and a `deepcopy` of the teacher; seeds the teacher with `LabeledFewShot` if uncompiled. |
| `_prepare_predictor_mappings` | Validates that student and teacher have identical structure and signatures; builds `name2predictor` / `predictor2name` maps. |
| `_bootstrap` | Iterates over the trainset, attempting up to `max_rounds` per example until `max_bootstrapped_demos` are collected. |
| `_bootstrap_one_example` | Runs the teacher on one example, captures the trace, applies the metric, and records successful demos. |
| `_train` | Combines augmented (bootstrapped) demos with raw labeled demos and assigns them to student predictors. |

**Bootstrapping details:**
- On retry rounds (`round_idx > 0`), the LM temperature is increased (`0.7 + 0.001 * round_idx`) to escape caching and encourage diversity.
- The example under test is temporarily removed from each predictor's demos during bootstrapping to avoid leakage.
- Errors are counted under a lock (`error_lock`); the program aborts once `max_errors` (or `dspy.settings.max_errors`) is exceeded.
- When multiple traces exist for the same predictor, a deterministic 50/50 sampling (seeded by a hash of the demos) selects one.

**Constructor parameters:**

| Parameter | Default | Description |
|-----------|---------|-------------|
| `metric` | `None` | Comparison function `(example, prediction, trace) -> bool/float`. |
| `metric_threshold` | `None` | Minimum numeric metric value to accept a demo. |
| `teacher_settings` | `None` | Settings applied to the teacher LM. |
| `max_bootstrapped_demos` | `4` | Max bootstrapped demos per predictor. |
| `max_labeled_demos` | `16` | Max labeled demos per predictor. |
| `max_rounds` | `1` | Retry attempts per example. |
| `max_errors` | `None` | Error budget before aborting. |

---

### BootstrapFewShotWithRandomSearch

Runs `BootstrapFewShot` across a range of random seeds and selects the highest-scoring candidate program.

```mermaid
flowchart LR
    subgraph Seeds["Seed range: -3 .. num_candidate_programs"]
        S3["seed = -3<br/>zero-shot"]
        S2["seed = -2<br/>labels only"]
        S1["seed = -1<br/>unshuffled few-shot"]
        S0["seed >= 0<br/>shuffled + random size"]
    end
    S3 --> Eval[Evaluate on valset]
    S2 --> Eval
    S1 --> Eval
    S0 --> Eval
    Eval --> Best["Track best score<br/>stop_at_score early exit"]
    Best --> Attach["Attach candidate_programs<br/>sorted by score"]
```

**Special seeds:**
- `-3`: zero-shot (no demos).
- `-2`: labels only (via `LabeledFewShot`).
- `-1`: unshuffled few-shot (via `BootstrapFewShot`).
- `>= 0`: shuffled trainset with a random demo size between `min_num_samples` and `max_num_samples`.

**Behavior:**
- Evaluates each candidate on `valset` (defaults to `trainset`).
- Supports `restrict` to run only specific seeds.
- Supports `stop_at_score` for early termination.
- Attaches all candidates to the best program as `candidate_programs`, sorted by descending score.

---

### BootstrapFewShotWithOptuna

Uses [Optuna](https://optuna.org/) to search over which bootstrapped demo to select for each predictor.

```mermaid
flowchart TD
    Compile([compile]) --> BFS["BootstrapFewShot.compile<br/>produces compiled_teleprompter"]
    BFS --> Study["optuna.create_study(maximize)"]
    Study --> Obj["objective(trial)<br/>suggest demo_index per predictor"]
    Obj --> Eval["Evaluate candidate program"]
    Eval --> Study
    Study --> Best["Return best trial's program"]
```

**Behavior:**
- First runs a full `BootstrapFewShot` to gather a pool of demos per predictor.
- For each trial, Optuna suggests a `demo_index_for_{name}` for every predictor, selecting a single demo.
- The candidate program is evaluated on `valset`; the best-scoring program is returned.

---

### KNNFewShot

A retrieval-based optimizer that attaches the `k` nearest neighbors to each input **at test time**, rather than pre-selecting a fixed demo set.

```mermaid
sequenceDiagram
    participant User
    participant Compiled as Compiled Student
    participant KNN as KNN Retriever
    participant BFS as BootstrapFewShot

    User->>Compiled: forward(**kwargs)
    Compiled->>KNN: __call__(**kwargs)
    KNN-->>Compiled: k nearest trainset examples
    Compiled->>BFS: compile(student, trainset=knn_trainset)
    BFS-->>Compiled: compiled program
    Compiled-->>User: prediction
```

**Behavior:**
- Wraps the student's `forward` method via `types.MethodType`.
- On each call, retrieves the `k` nearest neighbors using the `KNN` retriever and the provided `Embedder`.
- Runs `BootstrapFewShot` on the retrieved subset, then executes the compiled program.
- Accepts arbitrary `**few_shot_bootstrap_args` forwarded to `BootstrapFewShot`.

**Note:** Because bootstrapping happens per-call, `KNNFewShot` is more expensive at inference time than static optimizers.

---

### InferRules

Extends `BootstrapFewShot` by inducing natural-language rules from examples and injecting them into each predictor's signature instructions.

```mermaid
flowchart TD
    Compile([compile]) --> Split["Split trainset into train/valset<br/>if valset not provided"]
    Split --> Super["super().compile<br/>BootstrapFewShot"]
    Super --> Loop["For each candidate (num_candidates)"]
    Loop --> Induce["induce_natural_language_rules<br/>per predictor"]
    Induce --> Update["update_program_instructions<br/>append rules to signature"]
    Update --> Eval["evaluate_program on valset"]
    Eval --> Best["Track best program"]
    Best --> Loop
    Loop --> Return([best_program])
```

**Key methods:**

| Method | Purpose |
|--------|---------|
| `induce_natural_language_rules` | Calls `RulesInductionProgram` to generate rules; trims demos on context-window errors. |
| `update_program_instructions` | Appends induced rules to the predictor's signature instructions. |
| `format_examples` | Formats demos into input/output text blocks for the induction prompt. |
| `get_predictor_demos` | Filters trainset examples to the predictor's signature fields. |
| `evaluate_program` | Scores a candidate program using `Evaluate`. |

**`RulesInductionProgram`** is a `dspy.Module` wrapping a `ChainOfThought` over a dynamically-defined `CustomRulesInduction` signature. It uses a temperature sampled uniformly from `[0.9, 1.0]` for diversity.

---

## Data Flow

The following diagram illustrates how data flows through a typical bootstrapping optimizer.

```mermaid
flowchart LR
    Trainset["Trainset<br/>(list[Example])"] --> Teacher["Teacher Program"]
    Teacher --> Trace["Execution Trace<br/>(predictor, inputs, outputs)"]
    Trace --> Metric{"Metric passes?"}
    Metric -->|Yes| Demo["Bootstrapped Demo<br/>Example(augmented=True)"]
    Metric -->|No| Discard["Discard"]
    Demo --> Name2Traces["name2traces<br/>per-predictor demos"]
    Name2Traces --> Train["_train<br/>augmented + raw demos"]
    Trainset --> Raw["Raw labeled demos"]
    Raw --> Train
    Train --> Student["Compiled Student<br/>predictor.demos populated"]
```

---

## Component Interaction

The optimizers interact with the broader DSPy runtime through a consistent set of interfaces.

```mermaid
graph TD
    Optimizer["Optimizer<br/>(Teleprompter subclass)"]
    Optimizer -->|reset_copy / deepcopy| Module["Module"]
    Optimizer -->|named_predictors| Predict["Predict"]
    Optimizer -->|sets .demos| Predict
    Optimizer -->|reads .signature| Signature["Signature"]
    Optimizer -->|constructs| Example["Example"]
    Optimizer -->|dspy.settings.context| Settings["Settings"]
    Optimizer -->|Evaluate| Eval["Evaluate"]
    Optimizer -->|metric| Metric["User Metric"]
```

**Common patterns across all optimizers:**
1. **Copy the student** via `student.reset_copy()` (or `deepcopy`) to avoid mutating the original.
2. **Discover predictors** via `student.named_predictors()`.
3. **Populate demos** by assigning to `predictor.demos`.
4. **Mark compiled** by setting `student._compiled = True` (in `BootstrapFewShot`).
5. **Use `dspy.settings.context`** to scope LM and teacher settings during bootstrapping.

---

## Process Flow: End-to-End Bootstrapping

```mermaid
sequenceDiagram
    participant User
    participant Opt as BootstrapFewShot
    participant Teacher
    participant Student
    participant Metric

    User->>Opt: compile(student, teacher, trainset)
    Opt->>Student: reset_copy()
    Opt->>Teacher: deepcopy()
    Opt->>Teacher: LabeledFewShot seed (if uncompiled)
    Opt->>Opt: _prepare_predictor_mappings()
    loop For each example in trainset
        Opt->>Teacher: __call__(example.inputs())
        Teacher-->>Opt: prediction + trace
        Opt->>Metric: metric(example, prediction, trace)
        Metric-->>Opt: success?
        Opt->>Opt: record demos in name2traces
    end
    Opt->>Student: _train() assigns demos
    Opt-->>User: compiled student
```

---

## Choosing an Optimizer

| Scenario | Recommended Optimizer |
|----------|----------------------|
| Quick baseline / no LM calls | `LabeledFewShot` |
| General-purpose improvement | `BootstrapFewShot` |
| Want the best of many random configurations | `BootstrapFewShotWithRandomSearch` |
| Fine-grained demo selection with search | `BootstrapFewShotWithOptuna` |
| Dynamic, input-dependent demos | `KNNFewShot` |
| Want explicit natural-language guidance | `InferRules` |

---

## Related Modules

- [teleprompt_core.md](teleprompt_core.md) — The `Teleprompter` base class and shared utilities (`create_n_fewshot_demo_sets`, etc.).
- [teleprompt_prompt.md](teleprompt_prompt.md) — Prompt/instruction optimizers (`COPRO`, `MIPROv2`, `SIMBA`).
- [teleprompt_weight.md](teleprompt_weight.md) — Weight/fine-tuning optimizers (`BootstrapFinetune`, `GRPO`).
- [teleprompt_meta.md](teleprompt_meta.md) — Meta-optimizers (`Ensemble`, `BetterTogether`).
- [predict_core.md](predict_core.md) — The `Predict` module whose `demos` are populated.
- [predict_execution.md](predict_execution.md) — The `KNN` retriever used by `KNNFewShot`.
- [primitives_data_containers.md](primitives_data_containers.md) — `Example` and `Prediction` containers.
- [evaluate_program_evaluation.md](evaluate_program_evaluation.md) — The `Evaluate` class used for scoring candidates.
- [clients_embedding.md](clients_embedding.md) — The `Embedder` used for vectorization.
