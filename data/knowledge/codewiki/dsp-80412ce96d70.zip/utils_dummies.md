# Utils Dummies Module

## Introduction

The `utils_dummies` module provides lightweight, deterministic stand-ins for real language models and retrieval components, enabling fast, offline, and reproducible unit testing of DSPy programs. It contains two core components:

- **`DummyLM`** — a fake language model that returns pre-configured answers instead of calling a real LLM API.
- **`DummyVectorizer`** — a simple n-gram based vectorizer used to build a dummy retrieval model (`dummy_rm`).

These dummies allow developers to test predictors, modules, and optimizers without incurring API costs, network latency, or non-determinism. They are primarily used in the DSPy test suite and in user code that needs to mock model behavior.

---

## Architecture Overview

`DummyLM` subclasses the real [`LM`](clients_lm.md) client, so it inherits the full LM interface (history tracking, callbacks, `acall`, etc.) while overriding the actual completion logic. `DummyVectorizer` is a standalone utility that produces normalized sparse vectors, which `dummy_rm` uses to rank passages.

```mermaid
graph TD
    subgraph utils_dummies
        DLM[DummyLM]
        DV[DummyVectorizer]
        DRM[dummy_rm]
    end

    subgraph clients_lm
        LM[LM]
        BLM[BaseLM]
    end

    subgraph adapters_core
        CA[ChatAdapter]
        FHW[FieldInfoWithName]
    end

    subgraph utils_callbacks
        WC[with_callbacks]
    end

    subgraph dsp_utils_utilities
        DD[dotdict]
    end

    subgraph signatures_fields
        OF[OutputField]
    end

    DLM -->|inherits| LM
    LM -->|inherits| BLM
    DLM -->|uses| CA
    DLM -->|uses| FHW
    DLM -->|decorated by| WC
    DLM -->|uses| OF
    DRM -->|uses| DV
    DRM -->|returns| DD
```

---

## Core Components

### DummyLM

`DummyLM` is a subclass of [`LM`](clients_lm.md) that simulates a chat language model. It is constructed with a fixed set of answers and returns them in a controlled manner, formatted exactly as the [`ChatAdapter`](adapters_core.md) would format real model output.

#### Constructor

```python
DummyLM(
    answers: list[dict[str, str]] | dict[str, dict[str, str]],
    follow_examples: bool = False,
)
```

Internally it calls `super().__init__("dummy", "chat", 0.0, 1000, True)`, configuring a chat-type model with zero temperature and a 1000-token limit. If `answers` is a list, it is converted into an iterator so each call consumes the next answer.

#### Operating Modes

`DummyLM` supports three distinct modes of operation:

| Mode | `answers` type | Behavior |
|------|----------------|----------|
| **1. List of dictionaries** | `list[dict[str, str]]` | Returns the next dictionary in the list on each call. |
| **2. Dictionary of dictionaries** | `dict[str, dict[str, str]]` | Matches a key against the final message content and returns the corresponding value. |
| **3. Follow examples** | any (with `follow_examples=True`) | If the prompt matches an example input, returns that example's output. |

**Mode 1 — List of dictionaries**

```python
lm = DummyLM([{"answer": "red"}, {"answer": "blue"}])
dspy.settings.configure(lm=lm)
predictor("What color is the sky?")   # -> [[## answer ##]]\nred
predictor("What color is the sky?")   # -> [[## answer ##]]\nblue
```

**Mode 2 — Dictionary of dictionaries**

```python
lm = DummyLM({"What color is the sky?": {"answer": "blue"}})
dspy.settings.configure(lm=lm)
predictor("What color is the sky?")   # -> [[## answer ##]]\nblue
```

**Mode 3 — Follow examples**

```python
lm = DummyLM([{"answer": "red"}], follow_examples=True)
dspy.settings.configure(lm=lm)
predictor(
    "What color is the sky?",
    demos=dspy.Example(input="What color is the sky?", output="blue"),
)
# -> [[## answer ##]]\nblue
```

#### Key Methods

- **`__call__(prompt=None, messages=None, **kwargs)`** — The main entry point, decorated with [`with_callbacks`](utils_callbacks.md). It:
  1. Builds the request, honoring the `n` kwarg (number of completions).
  2. Selects an answer based on the active mode.
  3. Formats the answer using `ChatAdapter().format_field_with_value(...)` so the output matches real adapter output.
  4. Appends an entry to `self.history` and the global history, with `usage=0` and `cost=0`.
  5. Returns the list of outputs.

- **`acall(prompt=None, messages=None, **kwargs)`** — Async wrapper that simply delegates to `__call__`.

- **`_use_example(messages)`** — Implements Mode 3. It scans message headers using `field_header_pattern` to identify output fields (those appearing fewer times than the most frequent field), then finds the last turn whose content contains those output fields and whose preceding input matches the final input.

- **`get_convo(index)`** — Returns the `(messages, outputs)` tuple for the `index`-th recorded interaction.

#### Answer Formatting

All answers are formatted through `ChatAdapter.format_field_with_value`, producing the canonical DSPy chat format:

```
[[ ## answer ## ]]
red
```

This ensures that downstream parsing by the [`ChatAdapter`](adapters_core.md) works identically to a real model response.

---

### DummyVectorizer

`DummyVectorizer` is a deterministic, n-gram based vectorizer used to produce embeddings for the dummy retrieval model. It uses a polynomial rolling hash to map n-grams into a fixed-length sparse vector, then normalizes each vector.

#### Constructor

```python
DummyVectorizer(max_length=100, n_gram=2)
```

- `max_length` — Dimensionality of the output vectors.
- `n_gram` — Size of the character n-grams used for hashing.
- A fixed random seed (`123`) and a large prime modulus (`10**9 + 7`) make the coefficients deterministic across runs.

#### Key Methods

- **`_hash(gram)`** — Computes a polynomial hash of an n-gram, modulo `max_length`, to determine the vector index.
- **`__call__(texts: list[str]) -> np.ndarray`** — For each text:
  1. Extracts all character n-grams.
  2. Increments the count at the hashed index for each gram.
  3. Mean-centers each vector (subtracts the row mean).
  4. L2-normalizes each vector (with an epsilon to avoid division by zero).
  5. Returns a `float32` NumPy array of shape `(len(texts), max_length)`.

---

### dummy_rm

`dummy_rm` is a factory function that builds a simple retrieval model using `DummyVectorizer`.

```python
def dummy_rm(passages=()) -> callable
```

- If no passages are provided, the returned function raises `ValueError("No passages defined")`.
- Otherwise, it vectorizes all passages once, then returns an `inner(query, *, k, **kwargs)` function that:
  1. Vectorizes the query.
  2. Computes dot-product scores against all passage vectors.
  3. Returns the top-`k` passages as [`dotdict`](dsp_utils_utilities.md) objects with a `long_text` attribute.

---

## Data Flow

The following diagram illustrates how `DummyLM` processes a request and how `dummy_rm` ranks passages.

```mermaid
sequenceDiagram
    participant P as Predictor/Module
    participant DLM as DummyLM
    participant CA as ChatAdapter
    participant H as History

    P->>DLM: __call__(prompt/messages, n=...)
    DLM->>DLM: select answer (mode 1/2/3)
    DLM->>CA: format_field_with_value(fields)
    CA-->>DLM: formatted string
    DLM->>H: append entry (usage=0, cost=0)
    DLM-->>P: [formatted outputs]
```

```mermaid
flowchart LR
    Q[Query] --> DV1[DummyVectorizer]
    P[Passages] --> DV2[DummyVectorizer]
    DV1 --> S[Dot-product scores]
    DV2 --> S
    S --> T[Top-k selection]
    T --> R[dotdict long_text results]
```

---

## Component Interaction

`DummyLM` integrates with several other modules:

```mermaid
graph LR
    DLM[DummyLM] -->|subclass| LM[LM]
    DLM -->|formatting| CA[ChatAdapter]
    DLM -->|field metadata| FHW[FieldInfoWithName]
    DLM -->|output field type| OF[OutputField]
    DLM -->|callback hooks| WC[with_callbacks]
    DLM -->|history| H[history / global history]
    DRM[dummy_rm] -->|vectorization| DV[DummyVectorizer]
    DRM -->|result objects| DD[dotdict]
```

- **Inheritance from [`LM`](clients_lm.md):** `DummyLM` reuses the LM constructor, `history` list, `update_global_history`, and `kwargs` merging behavior, but overrides `__call__`/`acall` to avoid real API calls.
- **Formatting via [`ChatAdapter`](adapters_core.md):** Guarantees output parity with real chat completions.
- **Callback support via [`with_callbacks`](utils_callbacks.md):** The `__call__` method participates in the global/instance callback system, so tests can verify callback behavior.
- **Result objects via [`dotdict`](dsp_utils_utilities.md):** `dummy_rm` returns attribute-accessible dictionaries.

---

## Usage in Testing

`DummyLM` is the standard tool for testing DSPy programs. Typical patterns:

```python
import dspy
from dspy.utils.dummies import DummyLM

# Configure a dummy LM globally
dspy.settings.configure(lm=DummyLM([{"answer": "red"}, {"answer": "blue"}]))

# Run a predictor and assert on the output
result = predictor("What color is the sky?")
assert result.answer == "red"
```

For retrieval-based tests:

```python
from dspy.utils.dummies import dummy_rm

rm = dummy_rm(["passage one", "passage two", "passage three"])
results = rm("passage", k=2)
assert len(results) == 2
```

---

## Related Modules

- [clients_lm](clients_lm.md) — The real `LM` and `BaseLM` classes that `DummyLM` extends.
- [adapters_core](adapters_core.md) — `ChatAdapter` and `FieldInfoWithName`, used for output formatting.
- [utils_callbacks](utils_callbacks.md) — The `with_callbacks` decorator applied to `DummyLM.__call__`.
- [dsp_utils_utilities](dsp_utils_utilities.md) — `dotdict`, used for retrieval result objects.
- [signatures_fields](signatures_fields.md) — `OutputField`, used to describe dummy output fields.
