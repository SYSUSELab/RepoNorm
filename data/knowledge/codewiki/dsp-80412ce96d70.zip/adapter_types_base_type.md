# Adapter Types Base Type

## Introduction

The `adapter_types_base_type` module provides the foundational `Type` class that serves as the parent class for all DSPy custom types. It defines the contract that custom types must follow to be properly formatted and serialized when interacting with Language Models (LMs) through DSPy adapters.

This module is the cornerstone of DSPy's extensible type system, enabling developers to create custom types (such as images, audio, tools, and code) that can be seamlessly integrated into DSPy signatures and correctly formatted for LM consumption.

## Core Component

### `Type` Class

The `Type` class is a Pydantic `BaseModel` subclass that establishes the interface for all DSPy custom types.

```python
class Type(pydantic.BaseModel):
    """Base class to support creating custom types for DSPy signatures."""
```

#### Key Responsibilities

1. **Format Contract**: Defines the `format()` method that subclasses must implement to return content in a format compatible with the OpenAI API's content parts array.
2. **Type Discovery**: Provides utilities to extract custom types from arbitrarily nested type annotations.
3. **Serialization**: Automatically wraps formatted content with reserved identifiers for later parsing.

#### Methods

| Method | Type | Description |
|--------|------|-------------|
| `format()` | Instance | Abstract method returning `list[dict[str, Any]] \| str`. Subclasses must implement this to define how the type is rendered for the LM. |
| `description()` | Class | Returns a description string for the custom type. Defaults to an empty string. |
| `extract_custom_type_from_annotation(annotation)` | Class | Recursively extracts all custom types from a (possibly nested) type annotation. |
| `serialize_model()` | Instance | Pydantic model serializer that wraps list-formatted output with reserved identifiers. |

#### Reserved Identifiers

The module defines two module-level constants used to delimit custom type content during serialization:

```python
CUSTOM_TYPE_START_IDENTIFIER = "<<CUSTOM-TYPE-START-IDENTIFIER>>"
CUSTOM_TYPE_END_IDENTIFIER = "<<CUSTOM-TYPE-END-IDENTIFIER>>"
```

These markers allow the adapter layer to locate and split custom type content embedded within user messages.

## Architecture

The `Type` class sits at the base of the DSPy custom type hierarchy. All specialized types inherit from it and implement the `format()` contract.

```mermaid
classDiagram
    class BaseModel {
        <<pydantic>>
    }
    class Type {
        +format() list~dict~ | str
        +description() str
        +extract_custom_type_from_annotation(annotation) list
        +serialize_model()
    }
    class Image {
        +url: str
        +format()
        +from_url()
        +from_file()
        +from_PIL()
    }
    class Audio {
        +format()
    }
    class Code {
        +format()
    }
    class Tool {
        +func: Callable
        +format()
        +acall()
    }
    class History {
        +messages: list
    }

    BaseModel <|-- Type
    Type <|-- Image
    Type <|-- Audio
    Type <|-- Code
    Type <|-- Tool
    Type <|-- History
```

> **Note**: `History` inherits directly from `pydantic.BaseModel` rather than `Type`, as it represents structured conversation data rather than a formattable content part. See [adapter_types_history.md](adapter_types_history.md) for details.

## Component Relationships

The `Type` class interacts with several other modules in the DSPy ecosystem:

```mermaid
graph TD
    Type["Type (base_type.py)"]
    Image["Image"]
    Audio["Audio"]
    Code["Code"]
    Tool["Tool"]
    History["History"]
    ChatAdapter["ChatAdapter"]
    JSONAdapter["JSONAdapter"]
    SplitFn["split_message_content_for_custom_types"]
    Signature["Signature"]

    Type --> Image
    Type --> Audio
    Type --> Code
    Type --> Tool
    History -.->|inherits BaseModel| Type

    ChatAdapter -->|uses| Type
    JSONAdapter -->|uses| Type
    ChatAdapter -->|calls| SplitFn
    SplitFn -->|parses| Type
    Signature -->|annotated with| Type
```

## Data Flow

The following diagram illustrates how custom types flow from a DSPy signature through the adapter layer to the LM:

```mermaid
sequenceDiagram
    participant User
    participant Signature
    participant Adapter as ChatAdapter
    participant Type as Type Subclass
    participant Split as split_message_content_for_custom_types
    participant LM

    User->>Signature: Provide input with custom type
    Signature->>Adapter: format(signature, inputs)
    Adapter->>Type: format_field_value()
    Type->>Type: format() -> list[dict]
    Type->>Type: serialize_model() wraps with identifiers
    Adapter->>Split: split_message_content_for_custom_types(messages)
    Split->>Split: regex match START/END identifiers
    Split->>Split: json_repair.loads() content
    Split-->>Adapter: content blocks list
    Adapter->>LM: Send formatted messages
```

## Serialization and Parsing Flow

The `serialize_model` method and `split_message_content_for_custom_types` function work together to embed and extract custom type content:

```mermaid
flowchart TD
    A[Type.format returns list] --> B{Is list?}
    B -->|Yes| C[Wrap with START/END identifiers]
    B -->|No| D[Return raw string]
    C --> E[Embedded in user message content]
    E --> F[split_message_content_for_custom_types]
    F --> G[Regex find START...END blocks]
    G --> H[json_repair.loads block content]
    H --> I[Append parsed content blocks]
    I --> J[Final messages with content blocks]
```

### `split_message_content_for_custom_types`

This module-level function is responsible for splitting user message content into a list of content blocks around custom type markers. This enables proper formatting of custom types (like `dspy.Image`) for better LM quality.

**Behavior:**
- Only processes messages with `role == "user"`.
- Uses a regex pattern to find content between `CUSTOM_TYPE_START_IDENTIFIER` and `CUSTOM_TYPE_END_IDENTIFIER`.
- Parses the enclosed content as JSON using `json_repair` (with a fallback to raw text on parse failure).
- Splits surrounding text into `{"type": "text", "text": ...}` blocks.

**Example transformation:**

```python
# Input content:
"Describe this image: <<CUSTOM-TYPE-START-IDENTIFIER>>[{"type": "image_url", ...}]<<CUSTOM-TYPE-END-IDENTIFIER>>"

# Output content:
[
    {"type": "text", "text": "Describe this image: "},
    {"type": "image_url", "image_url": {"url": "..."}},
]
```

## Type Extraction

The `extract_custom_type_from_annotation` class method enables DSPy to discover custom types even when they are deeply nested within complex annotations.

```mermaid
flowchart TD
    A[annotation] --> B{isinstance type and issubclass?}
    B -->|Yes| C[Return annotation]
    B -->|No| D[get_origin]
    D --> E{origin is None?}
    E -->|Yes| F[Return empty list]
    E -->|No| G[Iterate get_args]
    G --> H[Recurse into each arg]
    H --> I[Collect results]
```

**Example:** For an annotation like `list[dict[str, Tool]]`, the method recursively descends through the type arguments and returns `[Tool]`.

> **Python version note**: The direct-match check is wrapped in a `try/except TypeError` to accommodate differences between Python 3.10 and 3.11 in how `isinstance` behaves with nested types.

## Integration with Adapters

The `Type` class is consumed by DSPy adapters, primarily the [ChatAdapter](adapters_core.md) and [JSONAdapter](adapters_core.md). Adapters use the `format()` method to render custom type values and rely on `split_message_content_for_custom_types` to produce properly structured content blocks.

For details on how adapters orchestrate formatting and parsing, refer to the [adapters_core.md](adapters_core.md) documentation.

## Related Modules

| Module | Description |
|--------|-------------|
| [adapter_types_media.md](adapter_types_media.md) | `Image` and `Audio` types built on `Type` |
| [adapter_types_code.md](adapter_types_code.md) | `Code` type for code execution |
| [adapter_types_tool.md](adapter_types_tool.md) | `Tool` and `ToolCalls` types for function calling |
| [adapter_types_history.md](adapter_types_history.md) | `History` type for conversation tracking |
| [adapters_core.md](adapters_core.md) | Core adapter implementations that consume custom types |

## Summary

The `adapter_types_base_type` module provides the essential `Type` base class and supporting utilities that power DSPy's extensible custom type system. By defining a clear `format()` contract, reserved serialization identifiers, and robust type extraction and content-splitting utilities, it enables seamless integration of rich, multimodal content into DSPy signatures and their LM interactions.
