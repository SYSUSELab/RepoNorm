# ALFWorld Dataset Module

## Introduction

The `datasets_datasets_alfworld` module provides DSPy integration with the **ALFWorld** benchmark — a text-based, interactive environment for embodied AI tasks. Unlike static datasets (e.g., [GSM8K](datasets_benchmarks.md), [HotPotQA](datasets_benchmarks.md)), ALFWorld is a *simulated environment* where an agent must issue a sequence of natural-language actions (e.g., `"go north"`, `"take apple"`) to accomplish household tasks such as *Pick & Place*, *Clean & Place*, or *Heat & Place*.

The module exposes a single public class, `AlfWorld`, which:

1. Spawns a **pool of worker processes**, each hosting an independent ALFWorld environment instance.
2. Provides a shuffled `trainset` / `devset` of `dspy.Example` objects, each identified by a task `idx`.
3. Allows agents to interact with the environment through a safe, context-managed session API (`init` / `step`).

Because ALFWorld environments are heavyweight (they load PDDL logic, TextWorld grammars, and game files), the module uses **multiprocessing** to isolate each environment and enable parallel rollouts.

---

## Architecture Overview

The module is composed of three core components that form a layered architecture:

| Component | Role |
|-----------|------|
| `AlfWorld` | Public entry point; builds the dataset splits and owns the environment pool. |
| `EnvPool` | Manages a fixed-size pool of worker processes, each running one environment. |
| `_EnvSession` | Context manager that safely acquires/releases a single worker for a rollout. |
| `env_worker` (function) | The target function executed in each spawned process; owns the actual ALFWorld env. |

```mermaid
graph TD
    subgraph "Main Process"
        A["AlfWorld"]
        B["EnvPool"]
        C["_EnvSession"]
        A -->|creates| B
        B -->|session| C
    end

    subgraph "Worker Process 0"
        W0["env_worker"]
        E0["AlfredTWEnv instance"]
        W0 --> E0
    end

    subgraph "Worker Process 1"
        W1["env_worker"]
        E1["AlfredTWEnv instance"]
        W1 --> E1
    end

    subgraph "Worker Process N"
        WN["env_worker"]
        EN["AlfredTWEnv instance"]
        WN --> EN
    end

    C -->|"init / step via inq"| W0
    C -->|"init / step via inq"| W1
    C -->|"init / step via inq"| WN
    W0 -->|"results via outq"| C
    W1 -->|"results via outq"| C
    WN -->|"results via outq"| C
```

---

## Component Details

### `AlfWorld`

The public class that users instantiate. It performs two responsibilities:

**1. Dataset construction.** It generates 3,500 `dspy.Example` objects, each carrying only an `idx` field (the task identifier). The examples are shuffled with a fixed seed (`random.Random(0)`) for reproducibility, then split into:

- `trainset`: first 3,000 examples
- `devset`: last 500 examples

Each example is created via `dspy.Example(idx=idx).with_inputs("idx")`, marking `idx` as the sole input key. See [Example](primitives.md) for details on the `Example` primitive.

**2. Environment pool ownership.** The constructor creates an `EnvPool` sized by `max_threads` (default `20`). The pool is closed automatically in `__del__`.

```python
import dspy
from dspy.datasets.alfworld import AlfWorld

alfworld = AlfWorld(max_threads=20)
print(len(alfworld.trainset), len(alfworld.devset))  # 3000 500
```

> **Note:** Although the parameter is named `max_threads`, the pool uses **processes**, not threads. The name is a legacy of the API surface.

### `EnvPool`

A process pool that manages `size` independent ALFWorld environments. Key design points:

- **Spawn start method.** The pool forces `multiprocess.set_start_method("spawn", force=True)` before creating any processes. This is required because ALFWorld environments are not fork-safe (they may hold CUDA contexts, file handles, etc.).
- **Two queues per worker.** Each worker has an input queue (`inq`) for commands and an output queue (`outq`) for results.
- **Availability tracking.** A `queue.Queue` of worker IDs tracks which workers are free. `_acquire()` blocks until a worker is available; `_release()` returns it.

| Method | Purpose |
|--------|---------|
| `session()` | Returns an `_EnvSession` context manager. |
| `_acquire()` | Blocks until a worker is free; returns `(wid, inq, outq)`. |
| `_release(wid)` | Marks a worker as available again. |
| `close_all()` | Sends `"close"` to every worker, waits for `"CLOSED"`, joins processes. |

### `_EnvSession`

A context manager wrapping a single acquired worker. It exposes two operations that map directly to the worker's command protocol:

- `init(idx)` → sends `("init", idx)`; returns `(task_def, info)`.
- `step(action)` → sends `("step", action)`; returns `(obs, rew, done, info)`.

On `__exit__`, the worker is released back to the pool — even if an exception occurred during the rollout.

### `env_worker` (worker process function)

Runs inside each spawned process. It:

1. Lazily imports `alfworld.agents.environment` and `yaml`, raising a helpful `ImportError` if ALFWorld is not installed.
2. Loads `base_config.yml` (bundled alongside the module) to configure the environment.
3. Instantiates a single `AlfredTWEnv` (TextWorld variant) in `train_eval="train"` mode, suppressing stdout/stderr into a buffer.
4. Enters a command loop handling `init`, `step`, and `close`.

---

## Command Protocol & Data Flow

Communication between the main process and workers follows a simple request/response protocol over the paired queues.

```mermaid
sequenceDiagram
    participant U as User / Agent
    participant S as _EnvSession
    participant W as env_worker (process)
    participant E as AlfredTWEnv

    U->>S: with pool.session() as sess
    S->>S: _acquire() (blocks if none free)
    U->>S: sess.init(idx)
    S->>W: inq.put(("init", idx))
    W->>E: init_env(batch_size=1); skip(idx); reset()
    E-->>W: task_def, info
    W-->>S: outq.put((task_def, info))
    S-->>U: (task_def, info)

    loop Until done
        U->>S: sess.step(action)
        S->>W: inq.put(("step", action))
        W->>E: env.step([action])
        E-->>W: obs, rew, done, info
        W-->>S: outq.put((obs, rew, done, info))
        S-->>U: (obs, rew, done, info)
    end

    U->>S: exit context
    S->>S: _release(wid)
```

### Worker lifecycle

```mermaid
stateDiagram-v2
    [*] --> Spawned: ctx.Process.start()
    Spawned --> Idle: env_worker loads config + AlfredTWEnv
    Idle --> Initialized: cmd == "init"
    Initialized --> Stepping: cmd == "step"
    Stepping --> Stepping: cmd == "step"
    Stepping --> Initialized: cmd == "init" (new task)
    Idle --> Closed: cmd == "close"
    Initialized --> Closed: cmd == "close"
    Stepping --> Closed: cmd == "close"
    Closed --> [*]: outq.put("CLOSED"); break
```

---

## Configuration

The environment is configured via `base_config.yml`, bundled in the module directory. Key sections relevant to the TextWorld environment:

| Section | Key | Description |
|---------|-----|-------------|
| `dataset` | `data_path` | Path to training game files (`$ALFWORLD_DATA/json_2.1.1/train`). |
| `dataset` | `eval_id_data_path` / `eval_ood_data_path` | In-distribution / out-of-distribution eval paths. |
| `env` | `type` | Environment variant (`AlfredTWEnv`, `AlfredThorEnv`, `AlfredHybrid`). |
| `env` | `task_types` | Task categories: 1=Pick&Place, 2=Examine in Light, 3=Clean&Place, 4=Heat&Place, 5=Cool&Place, 6=Pick Two&Place. |
| `env` | `expert_timeout_steps` | Max steps for the expert solver. |
| `general` | `random_seed` | Global random seed (default `42`). |
| `general` | `use_cuda` | Whether to use CUDA (disable on CPU-only machines). |

The config relies on the `$ALFWORLD_DATA` environment variable, which is set by running `alfworld-download` after installation.

---

## Dependencies

```mermaid
graph LR
    AlfWorld --> EnvPool
    EnvPool --> _EnvSession
    EnvPool -->|spawns| env_worker
    env_worker -->|imports| alfworld["alfworld.agents.environment"]
    env_worker -->|reads| config["base_config.yml"]
    AlfWorld -->|creates| Example["dspy.Example"]
    EnvPool -->|requires| multiprocess["multiprocess"]
```

### External dependencies

| Dependency | Purpose | Install |
|------------|---------|---------|
| `alfworld` | The ALFWorld environment and TextWorld engine. | `pip install alfworld==0.3.5` then `alfworld-download` |
| `multiprocess` | Process pool with spawn support (dill-based). | `pip install multiprocess` |
| `yaml` | Parses `base_config.yml`. | (bundled with ALFWorld) |

### Internal dependencies

- [`dspy.Example`](primitives.md) — used to wrap each task `idx` as a DSPy example.
- [`dspy.Dataset` / `dspy.DataLoader`](datasets_core.md) — the broader dataset framework this module conceptually belongs to, though `AlfWorld` builds its splits directly rather than subclassing `Dataset`.

---

## Usage Example

A typical rollout loop that solves a task by interacting with the environment:

```python
from dspy.datasets.alfworld import AlfWorld

alfworld = AlfWorld(max_threads=4)

# Pick a task from the dev set
example = alfworld.devset[0]
idx = example.idx

with alfworld.POOL.session() as sess:
    task_def, info = sess.init(idx)
    print("Task:", task_def)

    done = False
    while not done:
        action = decide_action(task_def, info)  # your agent logic
        obs, rew, done, info = sess.step(action)
        print(f"obs={obs} reward={rew} done={done}")
```

> **Important:** Always use the `session()` context manager. It guarantees the worker is released back to the pool, preventing pool exhaustion. Never call `_acquire()` / `_release()` directly.

---

## Design Considerations & Caveats

- **Process isolation over threads.** Each environment runs in its own process because ALFWorld is not thread-safe and may hold non-forkable resources. This means state cannot be shared across workers — each `init(idx)` starts a fresh episode.
- **Spawn cost.** Spawning processes is expensive; the pool is created eagerly in `AlfWorld.__init__`. Choose `max_threads` based on available CPU/memory.
- **Blocking acquisition.** `_acquire()` blocks when all workers are busy. If your agent holds a session for a long time, other rollouts will wait.
- **Cleanup.** `close_all()` is invoked from `__del__`, but relying on garbage collection is fragile. For long-running programs, explicitly call `alfworld.POOL.close_all()` when finished.
- **Fixed split.** The train/dev split is deterministic (seed `0`) and hard-coded to 3,000/500. It does not honor the `train_size` / `dev_size` parameters of the base [`Dataset`](datasets_core.md) class.

---

## Related Modules

- [datasets_core](datasets_core.md) — `Dataset` and `DataLoader` base classes.
- [datasets_benchmarks](datasets_benchmarks.md) — static benchmarks (GSM8K, HotPotQA, MATH, Colors).
- [primitives](primitives.md) — `Example`, `Prediction`, and other core primitives.
- [predict](predict.md) — modules such as `ReAct` and `CodeAct` commonly used as agents driving ALFWorld rollouts.
