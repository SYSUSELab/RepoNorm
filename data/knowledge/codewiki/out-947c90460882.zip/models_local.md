# Local Models (`models_local`)

## Introduction

The `models_local` module provides Outlines integrations for **local, in-process
inference engines**. Unlike the API-based models (see [models_api.md](models_api.md))
or the server-based models (see [models_server.md](models_server.md)), these
integrations run the model directly inside the Python process, giving Outlines
full access to the model's logits. This makes them **steerable models**: they
support constrained generation through logits processors rather than relying on
provider-side structured output features.

The module wraps four distinct local inference backends:

| Backend | Class | Underlying library | Tensor library |
| --- | --- | --- | --- |
| Hugging Face Transformers | `Transformers`, `TransformersMultiModal` | `transformers` | `torch` / `jax` / `tensorflow` |
| llama.cpp | `LlamaCpp` | `llama-cpp-python` | `numpy` |
| Apple MLX | `MLXLM` | `mlx-lm` | `mlx` |
| vLLM (offline) | `VLLMOffline` | `vllm` | `numpy` (via vLLM) |

Each integration follows the same architectural pattern established by the
[models_base.md](models_base.md) module: a `Model` subclass, a `ModelTypeAdapter`
subclass, and (where applicable) a `Tokenizer` implementation.

---

## Architecture

All local model integrations inherit from the abstract `Model` and
`ModelTypeAdapter` base classes defined in [models_base.md](models_base.md). The
`Model` base class provides the user-facing `__call__`, `batch`, and `stream`
methods, which delegate to the `generate`, `generate_batch`, and
`generate_stream` methods implemented by each concrete model.

```mermaid
classDiagram
    class Model {
        <<abstract>>
        +type_adapter: ModelTypeAdapter
        +tensor_library_name: str
        +__call__()
        +batch()
        +stream()
        +generate()*
        +generate_batch()*
        +generate_stream()*
    }
    class ModelTypeAdapter {
        <<abstract>>
        +format_input()*
        +format_output_type()*
    }
    class Tokenizer {
        <<protocol>>
        +encode()
        +decode()
        +convert_token_to_string()
    }

    Model <|-- Transformers
    Model <|-- LlamaCpp
    Model <|-- MLXLM
    Model <|-- VLLMOffline

    Transformers <|-- TransformersMultiModal

    ModelTypeAdapter <|-- TransformersTypeAdapter
    ModelTypeAdapter <|-- TransformersMultiModalTypeAdapter
    ModelTypeAdapter <|-- LlamaCppTypeAdapter
    ModelTypeAdapter <|-- MLXLMTypeAdapter
    ModelTypeAdapter <|-- VLLMOfflineTypeAdapter

    Tokenizer <|.. TransformerTokenizer
    Tokenizer <|.. LlamaCppTokenizer

    Transformers --> TransformersTypeAdapter
    Transformers --> TransformerTokenizer
    TransformersMultiModal --> TransformersMultiModalTypeAdapter
    LlamaCpp --> LlamaCppTypeAdapter
    LlamaCpp --> LlamaCppTokenizer
    MLXLM --> MLXLMTypeAdapter
    MLXLM --> TransformerTokenizer
    VLLMOffline --> VLLMOfflineTypeAdapter
```

### Module Position in the System

The `models_local` module sits between the user-facing generator layer and the
underlying inference libraries. It is one of three sibling model families.

```mermaid
graph TD
    User[User Code] --> Generator[SteerableGenerator]
    Generator -->|logits processor| Local[models_local]
    Generator -->|response_format| API[models_api]
    Generator -->|guided decoding| Server[models_server]

    Local --> Transformers[transformers]
    Local --> LlamaCpp[llama-cpp-python]
    Local --> MLX[mlx-lm]
    Local --> VLLM[vllm offline]

    Local -.uses.-> Base[models_base]
    Local -.uses.-> Tokenizer[models_base Tokenizer]
    Local -.uses.-> Inputs[inputs]
    Local -.uses.-> Processors[processors]
    Local -.uses.-> DSL[types_dsl]
```

---

## Common Design Pattern

Every local integration implements the same three-part contract:

1. **`Model` subclass** — wraps the underlying engine object and implements
   `generate`, `generate_batch`, and `generate_stream`.
2. **`ModelTypeAdapter` subclass** — uses `@singledispatchmethod` to convert
   user inputs (`str`, `Chat`, `list`, `dict`) into the format the engine
   expects, and converts the `output_type` into the engine's constrained
   generation argument.
3. **`from_<backend>` factory function** — a module-level convenience function
   that instantiates the model wrapper.

Because these are **steerable** models, `format_output_type` receives an
`OutlinesLogitsProcessor` (see [processors.md](processors.md)) rather than a
Python type. The processor is wrapped in the engine-specific container
(`LogitsProcessorList` for Transformers and llama.cpp, a plain list for MLX).

```mermaid
sequenceDiagram
    participant U as User
    participant G as SteerableGenerator
    participant M as Local Model
    participant TA as TypeAdapter
    participant E as Engine

    U->>G: model(prompt, output_type)
    G->>G: build OutlinesLogitsProcessor
    G->>M: generate(prompt, logits_processor)
    M->>TA: format_input(prompt)
    TA-->>M: engine-formatted input
    M->>TA: format_output_type(logits_processor)
    TA-->>M: engine-formatted processor
    M->>E: engine.generate(input, processor)
    E-->>M: raw token ids / text
    M->>M: decode
    M-->>G: generated text
    G-->>U: generated text
```

---

## Backend Integrations

### Transformers (`outlines/models/transformers.py`)

The most feature-rich integration, wrapping Hugging Face `transformers` models.

**Key components:**

- **`Transformers`** — wraps a `PreTrainedModel` and `PreTrainedTokenizer`. It
  auto-detects the tensor library (`jax`, `tensorflow`, or `torch`) based on the
  model type, which is required for the logits processor to manipulate tensors
  correctly. It supports single and batch generation, and handles both
  encoder-decoder and decoder-only architectures in `_generate_output_seq`.
- **`TransformersMultiModal`** — extends `Transformers` to support vision,
  audio, and video inputs via a `ProcessorMixin`. It overrides
  `_prepare_model_inputs` to merge batched multimodal prompts.
- **`TransformersTypeAdapter`** — formats `str` and `Chat` inputs; for `Chat` it
  applies the tokenizer's chat template.
- **`TransformersMultiModalTypeAdapter`** — formats `list` inputs (a prompt plus
  `Image`/`Audio`/`Video` assets) and `Chat` inputs containing assets. It
  separates images from messages before applying the chat template.
- **`TransformerTokenizer`** — implements the `Tokenizer` protocol, including
  workarounds for Llama-family tokenizers (the `SPIECE_UNDERLINE` hack).

**Factory:** `from_transformers(model, tokenizer_or_processor)` — dispatches to
`Transformers` or `TransformersMultiModal` based on whether a tokenizer or a
processor is passed.

> **Note:** Streaming is not implemented for Transformers models (pending
> upstream support in `transformers`).

### llama.cpp (`outlines/models/llamacpp.py`)

Wraps the `llama-cpp-python` library for CPU/GPU inference of GGUF models.

**Key components:**

- **`LlamaCpp`** — wraps a `llama_cpp.Llama` instance. Uses `numpy` as its
  tensor library. Supports single generation and streaming, but **not batch
  generation**. It calls `self.model.reset()` after each generation.
- **`LlamaCppTypeAdapter`** — formats `str` and `Chat` inputs. Chat messages
  must contain only string content (no multimodal support).
- **`LlamaCppTokenizer`** — implements the `Tokenizer` protocol. It builds a
  vocabulary either from the underlying HF tokenizer (when available) or by
  decoding every token id. It provides a stable `__getstate__` for use with
  [caching.md](caching.md) but raises `NotImplementedError` on `__setstate__`.

**Factory:** `from_llamacpp(model)`.

### MLX (`outlines/models/mlxlm.py`)

Wraps the `mlx-lm` library for Apple Silicon inference.

**Key components:**

- **`MLXLM`** — wraps an `mlx.nn.Module` and a tokenizer. Uses `mlx` as its
  tensor library. It keeps two tokenizer references: `mlx_tokenizer` (used by
  `mlx-lm`'s generate function) and `tokenizer` (a `TransformerTokenizer` used
  by the logits processor). Supports single generation and streaming, but
  **not batch generation**.
- **`MLXLMTypeAdapter`** — only supports `str` inputs. `format_output_type`
  returns a plain list of processors (not a `LogitsProcessorList`).

**Factory:** `from_mlxlm(model, tokenizer)`.

### vLLM Offline (`outlines/models/vllm_offline.py`)

Wraps the `vllm.LLM` class for high-throughput offline batch inference.

**Key components:**

- **`VLLMOffline`** — wraps a `vllm.LLM` instance. Unlike the other local
  integrations, vLLM performs constrained generation **natively** via
  `GuidedDecodingParams` rather than through an Outlines logits processor. It
  supports single and batch generation, but **not streaming**.
- **`VLLMOfflineTypeAdapter`** — formats `str` and `Chat` inputs (text only;
  assets are rejected). Its `format_output_type` converts the output type into
  a dict of arguments for `GuidedDecodingParams`:
  - `CFG` → `{"grammar": ...}`
  - `JsonSchema` → `{"json": ..., "whitespace_pattern": ...}`
  - everything else → `{"regex": ...}`

  This conversion reuses `python_types_to_terms` and `to_regex` from
  [types_dsl.md](types_dsl.md), and delegates `Chat` formatting to
  `OpenAITypeAdapter` from [models_api.md](models_api.md).

**Factory:** `from_vllm_offline(model)`.

---

## Input Handling

Local models accept different input types depending on their capabilities. The
type adapters validate inputs and raise `TypeError`/`NotImplementedError` for
unsupported types.

```mermaid
graph LR
    subgraph Inputs
        S[str]
        C[Chat]
        L[list: prompt + assets]
        D[dict - deprecated]
    end

    S --> T[Transformers]
    C --> T
    L --> TM[TransformersMultiModal]
    D -.deprecated.-> TM
    C --> TM

    S --> LC[LlamaCpp]
    C --> LC

    S --> M[MLXLM]

    S --> V[VLLMOffline]
    C --> V
```

The `Chat`, `Image`, `Audio`, and `Video` input types are defined in
[inputs.md](inputs.md). Multimodal assets are only supported by
`TransformersMultiModal`; `LlamaCpp` and `VLLMOffline` reject non-text content.

---

## Constrained Generation Flow

Because local models expose their logits, Outlines constrains generation by
injecting an `OutlinesLogitsProcessor` into the engine's sampling loop. The
processor is built by the `SteerableGenerator` (see [generator.md](generator.md))
from a Python type via the DSL ([types_dsl.md](types_dsl.md)).

```mermaid
flowchart TD
    A[User output_type] --> B[SteerableGenerator]
    B --> C{python_types_to_terms}
    C -->|CFG| D[get_cfg_logits_processor]
    C -->|JsonSchema| E[get_json_schema_logits_processor]
    C -->|other| F[get_regex_logits_processor]
    D --> G[OutlinesLogitsProcessor]
    E --> G
    F --> G
    G --> H[Model.generate]
    H --> I{Backend}
    I -->|Transformers| J[LogitsProcessorList]
    I -->|LlamaCpp| K[LogitsProcessorList]
    I -->|MLXLM| L[list of processors]
    I -->|VLLMOffline| M[GuidedDecodingParams]
```

The `OutlinesLogitsProcessor` uses a `TensorAdapter` (see [processors.md](processors.md))
selected by the model's `tensor_library_name` to manipulate logits in the
correct array library. This is why each local model declares its tensor library:

| Model | `tensor_library_name` |
| --- | --- |
| `Transformers` | `torch` / `jax` / `tensorflow` (auto-detected) |
| `LlamaCpp` | `numpy` |
| `MLXLM` | `mlx` |
| `VLLMOffline` | (native guided decoding, no processor) |

---

## Capability Matrix

| Capability | Transformers | TransformersMultiModal | LlamaCpp | MLXLM | VLLMOffline |
| --- | :---: | :---: | :---: | :---: | :---: |
| Single generation | ✅ | ✅ | ✅ | ✅ | ✅ |
| Batch generation | ✅ | ✅ | ❌ | ❌ | ✅ |
| Streaming | ❌ | ❌ | ✅ | ✅ | ❌ |
| Chat input | ✅ | ✅ | ✅ | ❌ | ✅ |
| Multimodal input | ❌ | ✅ | ❌ | ❌ | ❌ |
| Logits-processor steering | ✅ | ✅ | ✅ | ✅ | ❌ (native) |

---

## Dependencies

```mermaid
graph TD
    subgraph models_local
        TR[transformers.py]
        LC[llamacpp.py]
        ML[mlxlm.py]
        VO[vllm_offline.py]
    end

    TR --> Base[models_base]
    TR --> Tok[models_base Tokenizer]
    TR --> Inp[inputs]
    TR --> Proc[processors]

    LC --> Base
    LC --> Tok
    LC --> Inp
    LC --> Proc

    ML --> Base
    ML --> TR
    ML --> Proc

    VO --> Base
    VO --> Inp
    VO --> DSL[types_dsl]
    VO --> OAI[models_api OpenAITypeAdapter]
```

- **`models_base`** ([models_base.md](models_base.md)) — `Model`,
  `ModelTypeAdapter`, and the `Tokenizer` protocol.
- **`inputs`** ([inputs.md](inputs.md)) — `Chat`, `Image`, `Audio`, `Video`.
- **`processors`** ([processors.md](processors.md)) — `OutlinesLogitsProcessor`
  and tensor adapters.
- **`types_dsl`** ([types_dsl.md](types_dsl.md)) — `python_types_to_terms`,
  `to_regex`, `CFG`, `JsonSchema`.
- **`generator`** ([generator.md](generator.md)) — `SteerableGenerator` that
  drives these models.
- **`caching`** ([caching.md](caching.md)) — relies on stable tokenizer
  serialization (e.g., `LlamaCppTokenizer.__getstate__`).

---

## Usage Examples

### Transformers

```python
from transformers import AutoModelForCausalLM, AutoTokenizer
from outlines import from_transformers

model = AutoModelForCausalLM.from_pretrained("model-name")
tokenizer = AutoTokenizer.from_pretrained("model-name")
outlines_model = from_transformers(model, tokenizer)

response = outlines_model("Write a haiku about the sea.", output_type=str)
```

### Transformers (multimodal)

```python
from transformers import AutoProcessor, AutoModelForVision2Seq
from outlines import from_transformers, Image

model = AutoModelForVision2Seq.from_pretrained("model-name")
processor = AutoProcessor.from_pretrained("model-name")
outlines_model = from_transformers(model, processor)

response = outlines_model([
    "Describe this image.",
    Image(my_image),
])
```

### llama.cpp

```python
from llama_cpp import Llama
from outlines import from_llamacpp

llm = Llama.from_pretrained("repo-id", filename="model.gguf")
outlines_model = from_llamacpp(llm)

response = outlines_model("Write a haiku about the sea.")
```

### MLX

```python
from mlx_lm import load
from outlines import from_mlxlm

model, tokenizer = load("model-name")
outlines_model = from_mlxlm(model, tokenizer)

response = outlines_model("Write a haiku about the sea.")
```

### vLLM (offline)

```python
from vllm import LLM
from outlines import from_vllm_offline

llm = LLM(model="model-name")
outlines_model = from_vllm_offline(llm)

response = outlines_model("Write a haiku about the sea.")
```

---

## Related Documentation

- [models_base.md](models_base.md) — base `Model`, `ModelTypeAdapter`, `Tokenizer`
- [models_api.md](models_api.md) — API-based model integrations
- [models_server.md](models_server.md) — server-based model integrations
- [inputs.md](inputs.md) — `Chat`, `Image`, `Audio`, `Video` input types
- [processors.md](processors.md) — logits processors and tensor adapters
- [generator.md](generator.md) — `SteerableGenerator` and generation flow
- [types_dsl.md](types_dsl.md) — output type DSL and conversions
- [caching.md](caching.md) — tokenizer caching and serialization
