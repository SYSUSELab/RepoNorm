# Types DSL Module

## Introduction

The `types_dsl` module (`outlines/types/dsl.py`) provides the **regular expression DSL and output type system** that powers structured generation in Outlines. It defines a small, composable algebra of `Term` objects that describe the *language* an LLM's output must belong to — whether that language is a regular expression, a JSON schema, a context-free grammar, or a choice between literals.

The module is organized around three logical steps:

1. **Definition** — `Term` subclasses describe output types. Some are standalone (`JsonSchema`, `CFG`, `Regex`, `Choice`), while others are combinators that form the regex DSL (`Alternatives`, `Sequence`, `KleeneStar`, `KleenePlus`, `Optional`, and the `Quantify*` family).
2. **Conversion** — `python_types_to_terms` translates arbitrary Python types (Pydantic models, dataclasses, `TypedDict`, `Literal`, `Union`, `Enum`, containers, callables, …) into `Term` instances.
3. **Lowering** — `to_regex` converts a `Term` into a regular expression string that backends can compile into a logits processor.

This module is the *front-end* of the structured-generation pipeline. It produces the regex/JSON-schema/CFG strings that are consumed by the [backends](backends.md) module and ultimately enforced by [logits processors](processors.md).

---

## Architecture Overview

The DSL is a tree of immutable `Term` nodes. Leaf terms describe atomic languages; combinator terms compose them. A single lowering function (`to_regex`) walks the tree and emits a regex string.

```mermaid
graph TD
    Term["Term (abstract base)"]

    Term --> String
    Term --> Regex
    Term --> CFG
    Term --> JsonSchema
    Term --> Choice

    Term --> Combinators["Combinator Terms"]
    Combinators --> Alternatives
    Combinators --> Sequence
    Combinators --> KleeneStar
    Combinators --> KleenePlus
    Combinators --> Optional
    Combinators --> QuantifyExact
    Combinators --> QuantifyMinimum
    Combinators --> QuantifyMaximum
    Combinators --> QuantifyBetween

    subgraph "Leaf Terms"
        String
        Regex
        CFG
        JsonSchema
        Choice
    end

    subgraph "Regex DSL Combinators"
        Alternatives
        Sequence
        KleeneStar
        KleenePlus
        Optional
        QuantifyExact
        QuantifyMinimum
        QuantifyMaximum
        QuantifyBetween
    end
```

### Term Categories

| Category | Terms | Purpose |
|----------|-------|---------|
| **Atomic / standalone** | `String`, `Regex`, `CFG`, `JsonSchema`, `Choice` | Describe a base language directly |
| **Concatenation** | `Sequence` | Match terms one after another |
| **Alternation** | `Alternatives` | Match any one of several terms |
| **Repetition** | `KleeneStar`, `KleenePlus`, `Optional` | Zero-or-more, one-or-more, zero-or-one |
| **Bounded repetition** | `QuantifyExact`, `QuantifyMinimum`, `QuantifyMaximum`, `QuantifyBetween` | Exact / min / max / range counts |

---

## Core Components

### `Term` — the abstract base

`Term` is the root of the DSL hierarchy. Every node in a type tree is a `Term`. It provides:

- **Operator overloading** for ergonomic composition:
  - `a + b` → `Sequence([a, b])` (string operands are auto-wrapped in `String`)
  - `a | b` → `Alternatives([a, b])`
- **Pydantic integration** via `__get_pydantic_core_schema__` and `__get_pydantic_json_schema__`, allowing a `Term` to be used directly as a field type in a Pydantic model. It is serialized to JSON Schema as `{"type": "string", "pattern": <regex>}`.
- **Validation** through `validate(value)` and `matches(value)`, both of which compile `to_regex(self)` and perform a `fullmatch`.
- **Fluent builder methods** that delegate to the module-level factory functions: `.optional()`, `.exactly(n)`, `.at_least(n)`, `.at_most(n)`, `.between(a, b)`, `.one_or_more()`, `.zero_or_more()`.
- **Tree visualization** via `display_ascii_tree()` / `__str__()`, useful for debugging complex type trees.

```mermaid
classDiagram
    class Term {
        +__add__(other) Sequence
        +__or__(other) Alternatives
        +validate(value) str
        +matches(value) bool
        +display_ascii_tree() str
        +optional() Optional
        +exactly(count) QuantifyExact
        +at_least(count) QuantifyMinimum
        +at_most(count) QuantifyMaximum
        +between(min, max) QuantifyBetween
        +one_or_more() KleenePlus
        +zero_or_more() KleeneStar
    }
    Term <|-- String
    Term <|-- Regex
    Term <|-- CFG
    Term <|-- JsonSchema
    Term <|-- Choice
    Term <|-- Alternatives
    Term <|-- Sequence
    Term <|-- KleeneStar
    Term <|-- KleenePlus
    Term <|-- Optional
    Term <|-- QuantifyExact
    Term <|-- QuantifyMinimum
    Term <|-- QuantifyMaximum
    Term <|-- QuantifyBetween
```

### Leaf Terms

#### `String`
Wraps a literal string. Lowered via `re.escape`, so the value is matched literally.

#### `Regex`
Wraps a raw regular expression pattern string. Lowered by wrapping the pattern in parentheses.

#### `CFG`
Represents a context-free grammar definition (e.g. a Lark grammar). Supports `CFG.from_file(path)` and structural equality. Note that `CFG` is **not** lowered by `to_regex` — it is passed to backends that support CFG compilation (see [backends](backends.md)).

#### `JsonSchema`
Represents a JSON schema. The constructor accepts a `dict`, JSON `str`, Pydantic model, `TypedDict`, dataclass, or a genSON `SchemaBuilder`, normalizing all of them to a JSON string. It:
- Preprocesses union types via `preprocess_schema_for_union_types` (a workaround for `outlines-core` limitations with `["string", "null"]` type arrays).
- Validates the schema with `jsonschema.Draft7Validator.check_schema`.
- Supports `JsonSchema.from_file(path)`.
- Is lowered by delegating to `outlines_core.json_schema.build_regex_from_schema`.

#### `Choice`
Represents a choice between arbitrary items. Each item is converted to a `Term` via `python_types_to_terms` and lowered to a regex alternation.

### Combinator Terms

| Term | Fields | Regex lowering |
|------|--------|----------------|
| `Sequence` | `terms: List[Term]` | concatenation of children |
| `Alternatives` | `terms: List[Term]` | `(a|b|c)` |
| `KleeneStar` | `term: Term` | `(x)*` |
| `KleenePlus` | `term: Term` | `(x)+` |
| `Optional` | `term: Term` | `(x)?` |
| `QuantifyExact` | `term`, `count` | `(x){count}` |
| `QuantifyMinimum` | `term`, `min_count` | `(x){min,}` |
| `QuantifyMaximum` | `term`, `max_count` | `(x){,max}` |
| `QuantifyBetween` | `term`, `min_count`, `max_count` | `(x){min,max}` |

`QuantifyBetween` validates that `min_count <= max_count` in `__post_init__`.

### Factory Functions

The module exposes lowercase factory functions that mirror the class names and auto-wrap string arguments into `String`:

- `regex(pattern)`, `cfg(definition)`, `json_schema(schema)`
- `either(*terms)`, `optional(term)`
- `exactly(count, term)`, `at_least(count, term)`, `at_most(count, term)`, `between(min, max, term)`
- `zero_or_more(term)`, `one_or_more(term)`

---

## Python Type Conversion

`python_types_to_terms(ptype, recursion_depth=0)` is the bridge from idiomatic Python typing to the DSL. It is recursive (guarded by a depth limit of 10 to catch recursive type definitions) and dispatches on the input type.

```mermaid
flowchart TD
    Start([python_types_to_terms]) --> IsTerm{Is a Term?}
    IsTerm -->|yes| ReturnTerm[Return as-is]
    IsTerm -->|no| Basic{Basic scalar type?}
    Basic -->|int/float/bool/str| Scalar[Return predefined Regex from types]
    Basic -->|dict| DictCFG[Return CFG json grammar]
    Basic -->|time/date/datetime| Temporal[Return predefined Regex]
    Basic -->|no| Instance{Instance of str/int/float?}
    Instance -->|str| StrInst[String]
    Instance -->|int/float| NumInst[Regex of value]
    Instance -->|no| Structured{dataclass / TypedDict / Pydantic?}
    Structured -->|yes| JsonSch[JsonSchema from TypeAdapter]
    Structured -->|no| Genson{genSON builder?}
    Genson -->|yes| JsonSch2[JsonSchema]
    Genson -->|no| Enum{Enum?}
    Enum -->|yes| AltEnum[Alternatives of members]
    Enum -->|no| Generic{Generic alias?}
    Generic -->|Literal| HandleLiteral
    Generic -->|Union| HandleUnion
    Generic -->|List| HandleList
    Generic -->|Tuple| HandleTuple
    Generic -->|Dict| HandleDict
    Generic -->|Callable| HandleCallable[JsonSchema from signature]
    Generic -->|none| Raise[TypeError]
```

### Conversion Rules

| Python type | Resulting `Term` |
|-------------|------------------|
| `int` | `types.integer` (`Regex`) |
| `float` | `types.number` (`Regex`) |
| `bool` | `types.boolean` (`Regex`) |
| `str` | `types.string` (`Regex`) |
| `dict` | `CFG(grammars.json)` |
| `datetime` / `date` / `time` | corresponding predefined `Regex` |
| `str` instance | `String(value)` |
| `int`/`float` instance | `Regex(str(value))` |
| dataclass / `TypedDict` / Pydantic model | `JsonSchema` from `TypeAdapter(...).json_schema()` |
| genSON `SchemaBuilder` | `JsonSchema` |
| `Enum` | `Alternatives` over members (values + public functions) |
| `Literal[...]` | `Alternatives` over the literal values |
| `Union[...]` / `Optional[T]` | `Alternatives` (with `String("None")` for `Optional`) |
| `List[T]` | `Sequence` producing `[T, T, ...]` |
| `Tuple[...]` | `Sequence` (fixed-length or variadic with `Ellipsis`) |
| `Dict[K, V]` | `Sequence` producing `{K:V, K:V, ...}` |
| `Callable` | `JsonSchema` derived from the function signature |

Helper functions `_handle_literal`, `_handle_union`, `_handle_list`, `_handle_tuple`, and `_handle_dict` implement the container/union logic. `_get_enum_members` collects both enum values and public methods.

> **Note:** Only *homogeneous* lists are supported; heterogeneous `List`/`Tuple` type arguments raise `TypeError`.

---

## Lowering to Regex

`to_regex(term)` recursively converts a `Term` tree into a regular expression string. It is the single point where the DSL is "compiled" into the format expected by backends.

```mermaid
flowchart LR
    Term[Term tree] --> to_regex
    to_regex --> RegexStr[Regex string]
    RegexStr --> Backend[Backend.get_regex_logits_processor]
    Backend --> LP[LogitsProcessor]
    LP --> Model[Model generation]
```

Key lowering behaviors:

- `String` → `re.escape(value)`
- `Regex` → `(pattern)`
- `JsonSchema` → `outlines_core.json_schema.build_regex_from_schema(...)`
- `Choice` → alternation of each item converted via `python_types_to_terms`
- Combinators → parenthesized regex operators (`*`, `+`, `?`, `{n}`, `{n,}`, `{,m}`, `{n,m}`, `|`, concatenation)
- `CFG` → **not supported** by `to_regex`; raises `TypeError`. CFGs are handled separately by CFG-capable backends.

---

## Integration with the Broader System

The DSL is the entry point of the structured-generation pipeline. Its outputs feed directly into the backend and processor layers.

```mermaid
graph TD
    User["User code / Pydantic model"] --> PTT["python_types_to_terms"]
    PTT --> TermTree["Term tree"]
    TermTree --> ToRegex["to_regex"]
    ToRegex --> RegexStr["Regex string"]

    TermTree -->|JsonSchema| SchemaStr["JSON schema string"]
    TermTree -->|CFG| CFGStr["CFG definition"]

    RegexStr --> Backend["BaseBackend.get_regex_logits_processor"]
    SchemaStr --> Backend2["BaseBackend.get_json_schema_logits_processor"]
    CFGStr --> Backend3["BaseBackend.get_cfg_logits_processor"]

    Backend --> LP["OutlinesLogitsProcessor"]
    Backend2 --> LP
    Backend3 --> LP
    LP --> Gen["Model generation"]
```

### Related Modules

- **[backends](backends.md)** — `BaseBackend` and its implementations (`LLGuidanceBackend`, `OutlinesCoreBackend`, `XGrammarBackend`) consume the regex/JSON-schema/CFG strings produced by this module and compile them into logits processors.
- **[processors](processors.md)** — `OutlinesLogitsProcessor` and the tensor adapters enforce the constraints during generation.
- **[models](models.md)** — Models use the type adapters to convert user-provided output types into the DSL terms before generation.
- **[applications](applications.md)** — High-level `Application` helpers build on top of the type system.

### Supporting Utilities

- `outlines/types/utils.py` — type-inspection predicates (`is_int`, `is_pydantic_model`, `is_union`, …) and `get_schema_from_signature` used by the conversion logic.
- `outlines/types/json_schema_utils.py` — `preprocess_schema_for_union_types`, a workaround for union-type handling in `outlines-core`.
- `outlines/types/__init__.py` — defines the predefined `Regex` constants (`string`, `integer`, `number`, `boolean`, `date`, `time`, `datetime`, `email`, `uuid4`, `ipv4`, etc.) referenced by `python_types_to_terms`.
- `outlines/grammars.py` — provides the `json` and `arithmetic` Lark grammars used for `dict` and CFG conversions.

---

## Usage Examples

### Composing a DSL term

```python
from outlines.types.dsl import either, exactly, one_or_more, regex

# A 3-digit area code followed by a hyphen and 4+ digits
phone = exactly(3, regex(r"\d")) + "-" + one_or_more(regex(r"\d"))
```

### Using a `Term` as a Pydantic field type

```python
from pydantic import BaseModel
from outlines.types import Regex

age_type = Regex("[0-9]+")

class User(BaseModel):
    name: str
    age: age_type
```

### Converting a Python type

```python
from typing import Literal, Optional
from outlines.types.dsl import python_types_to_terms, to_regex

term = python_types_to_terms(Optional[Literal["a", "b"]])
print(to_regex(term))  # (a|b|None)
```

### Inspecting a type tree

```python
from outlines.types.dsl import python_types_to_terms

term = python_types_to_terms(list[int])
print(term)  # ASCII tree of the Sequence/KleeneStar structure
```

---

## Design Notes

- **Immutability & composition:** Most terms are `@dataclass`es, making them easy to construct, compare, and compose. `JsonSchema` and `CFG` are regular classes because they carry custom construction/validation logic.
- **Recursion safety:** `python_types_to_terms` enforces a maximum recursion depth of 10 to avoid infinite loops on self-referential types.
- **Single lowering path:** All regex-based constraints funnel through `to_regex`, keeping backend integration uniform.
- **Pydantic-first:** The `Term` base class implements the Pydantic core-schema protocol, so DSL terms are first-class field types in Pydantic models.
