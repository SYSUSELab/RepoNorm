# Models API Module

## Introduction

The `models_api` module provides Outlines integrations with **remote, API-based
model providers**. Unlike local models (see [models_local.md](models_local.md))
or self-hosted server models (see [models_server.md](models_server.md)), these
models are accessed through a third-party HTTP client library and perform
generation on the provider's infrastructure.

Because the provider controls the generation process, these models are
**black-box models**: Outlines cannot inject a logits processor to steer
token-by-token generation. Instead, structured output is requested by
translating the user's `output_type` into the provider's native
structured-output mechanism (e.g. JSON Schema response formats, enums, or
multiple-choice constraints). The actual generation is delegated to the
provider's API.

The module currently supports the following providers:

| Provider | Model class | Async variant | Structured output support |
|----------|-------------|---------------|---------------------------|
| OpenAI | `OpenAI` | — | JSON Schema, JSON mode |
| Anthropic | `Anthropic` | — | None |
| Gemini | `Gemini` | — | JSON Schema, enums, lists |
| Dottxt | `Dottxt` | — | JSON Schema (required) |
| Ollama | `Ollama` | `AsyncOllama` | JSON Schema |

## Architecture

All API models follow the same architectural pattern established by the base
classes in [models_base.md](models_base.md):

1. A **model class** (subclass of `Model` or `AsyncModel`) wraps a provider
   client and implements `generate`, `generate_batch`, and `generate_stream`.
2. A **type adapter** (subclass of `ModelTypeAdapter`) translates the
   user-facing `model_input` and `output_type` into the provider-specific
   arguments expected by the client.

```mermaid
graph TD
    subgraph "User-facing API"
        U[User: model input + output_type]
    end

    subgraph "models_api module"
        M[Model / AsyncModel subclass]
        TA[ModelTypeAdapter subclass]
    end

    subgraph "Base abstractions (models_base)"
        BM[Model / AsyncModel]
        BTA[ModelTypeAdapter]
    end

    subgraph "Provider SDK"
        C[Provider Client]
    end

    U --> M
    M -->|format_input| TA
    M -->|format_output_type| TA
    TA -->|messages / contents| C
    TA -->|response_format / config| C
    C -->|generated text| M
    M --> U

    BM -.inherits.-> M
    BTA -.inherits.-> TA
```

### Component Relationships

```mermaid
classDiagram
    class Model {
        <<abstract>>
        +type_adapter: ModelTypeAdapter
        +generate()
        +generate_batch()
        +generate_stream()
        +__call__()
        +batch()
        +stream()
    }
    class AsyncModel {
        <<abstract>>
        +generate()
        +generate_batch()
        +generate_stream()
    }
    class ModelTypeAdapter {
        <<abstract>>
        +format_input()
        +format_output_type()
    }

    Model <|-- OpenAI
    Model <|-- Anthropic
    Model <|-- Gemini
    Model <|-- Dottxt
    Model <|-- Ollama
    AsyncModel <|-- AsyncOllama

    ModelTypeAdapter <|-- OpenAITypeAdapter
    ModelTypeAdapter <|-- AnthropicTypeAdapter
    ModelTypeAdapter <|-- GeminiTypeAdapter
    ModelTypeAdapter <|-- DottxtTypeAdapter
    ModelTypeAdapter <|-- OllamaTypeAdapter

    OpenAI --> OpenAITypeAdapter
    Anthropic --> AnthropicTypeAdapter
    Gemini --> GeminiTypeAdapter
    Dottxt --> DottxtTypeAdapter
    Ollama --> OllamaTypeAdapter
    AsyncOllama --> OllamaTypeAdapter
```

## Common Design Pattern

Every API model follows the same lifecycle. The `Model.__call__` method (defined
in [models_base.md](models_base.md)) wraps the model in a `BlackBoxGenerator`,
which simply forwards the `output_type` to `generate` without compiling a logits
processor.

```mermaid
sequenceDiagram
    participant User
    participant Model
    participant TypeAdapter
    participant Client as Provider Client

    User->>Model: generate(model_input, output_type, **kwargs)
    Model->>TypeAdapter: format_input(model_input)
    TypeAdapter-->>Model: messages / contents
    Model->>TypeAdapter: format_output_type(output_type)
    TypeAdapter-->>Model: response_format / config
    Model->>Client: create(messages, response_format, **kwargs)
    Client-->>Model: completion
    Model-->>User: generated text
```

### Input Formatting

All type adapters implement `format_input` using `functools.singledispatchmethod`
to dispatch on the input type. The supported input types are:

- **`str`** — a plain prompt, wrapped into a single user message.
- **`list`** — a prompt followed by `Image` assets (multimodal input).
- **`Chat`** — a full conversation history (see [inputs.md](inputs.md)).

Each provider then maps these into its own message format. For example, Gemini
renames the `assistant` role to `model`, while Anthropic places images before
the text in the content list.

### Output Type Formatting

`format_output_type` translates the user's `output_type` into the provider's
native structured-output argument. The supported output types vary by provider
and are summarized in the table below.

| Output type | OpenAI | Anthropic | Gemini | Dottxt | Ollama |
|-------------|:------:|:---------:|:------:|:------:|:------:|
| `None` | ✅ | ✅ | ✅ | ❌ | ✅ |
| `JsonSchema` | ✅ | ❌ | ❌ | ✅ | ✅ |
| Pydantic model | ✅ | ❌ | ✅ | ✅ | ✅ |
| TypedDict | ✅ | ❌ | ✅ | ✅ | ✅ |
| Dataclass | ✅ | ❌ | ✅ | ✅ | ✅ |
| genSON builder | ✅ | ❌ | ❌ | ✅ | ✅ |
| `Regex` | ❌ | ❌ | ❌ | ❌ | ❌ |
| `CFG` | ❌ | ❌ | ❌ | ❌ | ❌ |
| `Choice` / `Enum` / `Literal` | ❌ | ❌ | ✅ | ❌ | ❌ |
| `list[...]` | ❌ | ❌ | ✅ | ❌ | ❌ |

> **Note:** `Regex` and `CFG` output types are **not supported** by any API
> provider, since they require token-level control that black-box APIs do not
> expose. Use a local model or Dottxt for these. See
> [types_dsl.md](types_dsl.md) for details on these types.

## Provider Integrations

### OpenAI

`OpenAI` wraps the `openai.OpenAI` (or `AzureOpenAI`) client. It supports
**JSON Schema** structured outputs and **JSON mode**.

- `format_json_output_type` converts a schema into the `response_format`
  argument with `type: "json_schema"` and `strict: True`. It uses
  `set_additional_properties_false_json_schema` to recursively set
  `additionalProperties: False`, which OpenAI requires.
- `format_json_mode_type` produces `{"response_format": {"type": "json_object"}}`
  when a native `dict` is passed as the output type.
- Refusals are surfaced as `ValueError`, and invalid schemas raise `TypeError`.

### Anthropic

`Anthropic` wraps the `anthropic.Anthropic` client. It supports **no structured
output** — passing any non-`None` `output_type` raises `NotImplementedError`.
It supports multimodal input via base64-encoded images.

### Gemini

`Gemini` wraps the `google.genai.Client`. It supports the richest set of output
types among the API providers:

- **JSON Schema** via `response_mime_type: "application/json"`.
- **Enums / multiple choice** via `response_mime_type: "text/x.enum"`. `Choice`,
  `Literal`, and `Enum` types are all converted to an `Enum` using
  `get_enum_from_choice` / `get_enum_from_literal`.
- **Homogeneous lists** of Pydantic models, TypedDicts, or dataclasses.

Gemini does **not** accept raw `JsonSchema` objects or genSON builders directly;
these must be passed as Pydantic models, TypedDicts, or dataclasses.

### Dottxt

`Dottxt` wraps the `dottxt.Dottxt` client. It is a **constrained-generation-only**
provider: an `output_type` is **required**, and passing `None` raises `TypeError`.
It supports JSON Schema output (from `JsonSchema`, Pydantic models, TypedDicts,
dataclasses, and genSON builders) but does **not** support streaming or batch
generation.

### Ollama

`Ollama` and `AsyncOllama` wrap the `ollama.Client` and `ollama.AsyncClient`
respectively. They support JSON Schema output passed via the `format` argument.
The `from_ollama` factory inspects the client type and returns the appropriate
sync or async model.

## Factory Functions

Each provider exposes a `from_<provider>` factory function that constructs the
Outlines model from a pre-configured provider client. This lets users control
authentication, base URLs, and other client settings themselves.

```mermaid
graph LR
    subgraph "Provider SDK clients"
        OC[openai.OpenAI]
        AC[anthropic.Anthropic]
        GC[google.genai.Client]
        DC[dottxt.Dottxt]
        OLC[ollama.Client / AsyncClient]
    end

    OC -->|from_openai| O[OpenAI]
    AC -->|from_anthropic| A[Anthropic]
    GC -->|from_gemini| G[Gemini]
    DC -->|from_dottxt| D[Dottxt]
    OLC -->|from_ollama| OL[Ollama / AsyncOllama]
```

| Factory | Returns |
|---------|---------|
| `from_openai(client, model_name=None)` | `OpenAI` |
| `from_anthropic(client, model_name=None)` | `Anthropic` |
| `from_gemini(client, model_name=None)` | `Gemini` |
| `from_dottxt(client, model_name=None, model_revision=None)` | `Dottxt` |
| `from_ollama(client, model_name=None)` | `Ollama` or `AsyncOllama` |

## Capability Matrix

The following diagram summarizes which generation methods each provider
supports.

```mermaid
graph TD
    subgraph "generate (single)"
        G1[OpenAI ✅]
        G2[Anthropic ✅]
        G3[Gemini ✅]
        G4[Dottxt ✅]
        G5[Ollama ✅]
        G6[AsyncOllama ✅]
    end

    subgraph "generate_stream"
        S1[OpenAI ✅]
        S2[Anthropic ✅]
        S3[Gemini ✅]
        S4[Dottxt ❌]
        S5[Ollama ✅]
        S6[AsyncOllama ✅]
    end

    subgraph "generate_batch"
        B1[All providers ❌]
    end
```

> **Note:** No API provider supports batch generation, since the underlying
> client libraries do not expose a batch inference API. Calling
> `generate_batch` raises `NotImplementedError`.

## Dependencies

```mermaid
graph TD
    models_api[models_api module]

    models_api --> models_base[models_base: Model, AsyncModel, ModelTypeAdapter]
    models_api --> inputs[inputs: Chat, Image]
    models_api --> types_dsl[types_dsl: JsonSchema, Regex, CFG, Choice]
    models_api --> types_utils[types.utils: type predicates]
    models_api --> models_utils[models.utils: set_additional_properties_false_json_schema]
    models_api --> generator[generator: BlackBoxGenerator]

    models_api -.optional.-> openai_sdk[openai SDK]
    models_api -.optional.-> anthropic_sdk[anthropic SDK]
    models_api -.optional.-> google_sdk[google-genai SDK]
    models_api -.optional.-> dottxt_sdk[dottxt SDK]
    models_api -.optional.-> ollama_sdk[ollama SDK]
```

The provider SDKs are imported lazily (inside methods or under `TYPE_CHECKING`),
so installing Outlines does not require every provider SDK to be present.

## Related Modules

- [models_base.md](models_base.md) — the `Model`, `AsyncModel`, and
  `ModelTypeAdapter` base classes.
- [models_local.md](models_local.md) — local model integrations (Transformers,
  LlamaCpp, MLXLM, VLLMOffline).
- [models_server.md](models_server.md) — self-hosted server integrations (VLLM,
  SGLang, TGI).
- [inputs.md](inputs.md) — `Chat`, `Image`, and other input types.
- [types_dsl.md](types_dsl.md) — the output type DSL (`JsonSchema`, `Regex`,
  `CFG`, `Choice`, etc.).
- [generator.md](generator.md) — the `BlackBoxGenerator` used to wrap API
  models.
