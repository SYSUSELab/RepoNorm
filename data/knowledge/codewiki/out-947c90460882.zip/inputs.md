# Inputs Module

## Introduction

The `inputs` module (`outlines/inputs.py`) defines the data structures used to represent the **inputs** that can be passed to a model. While a plain string prompt is sufficient for text-only models, multimodal and chat-based models require richer input types that can carry images, videos, audio, and structured conversation histories.

This module provides four lightweight dataclasses:

| Class | Purpose |
|-------|---------|
| `Image` | Wraps a PIL image and pre-computes its base64 encoding and MIME type. |
| `Video` | Wraps a video asset for video-capable models. |
| `Audio` | Wraps an audio asset for audio-capable models. |
| `Chat` | Represents a conversation as an ordered list of role/content messages. |

These objects are **not** consumed directly by models. Instead, they are passed as the `model_input` argument to a model, and the model's associated **type adapter** (see [models.md](models.md)) translates them into the exact format each backend expects (e.g. OpenAI's `messages` list, Anthropic's `messages` argument, or a Transformers processor's `text`/`images` dict).

---

## Architecture

The inputs module sits at the boundary between user code and the model layer. It is a pure data module with no dependencies on other Outlines modules, which keeps it importable from anywhere.

```mermaid
graph TD
    User["User Code"] -->|"str / list / Chat / Image / Video / Audio"| Model["Model (models.md)"]
    Model --> TypeAdapter["ModelTypeAdapter (models.md)"]
    TypeAdapter -->|"format_input()"| Backend["Backend / API Client"]

    subgraph inputs["inputs.py"]
        Image
        Video
        Audio
        Chat
    end

    User -.-> inputs
    TypeAdapter -.->|"reads fields"| inputs
```

### Key design principles

1. **Zero internal dependencies** — `inputs.py` only imports from the standard library (`base64`, `dataclasses`, `io`, `typing`) and `PIL`. It does not import any other Outlines module, avoiding circular imports.
2. **Dataclasses** — All four classes are `@dataclass`es, giving them automatic `__init__`, `__eq__`, and `__repr__` (with `Chat` overriding `__repr__`).
3. **Eager normalization** — `Image` performs all expensive work (encoding) in `__post_init__`, so downstream adapters can read pre-computed fields without re-encoding.

---

## Component Overview

### `Image`

Wraps a `PIL.Image.Image` and prepares it for transmission to a multimodal model.

```python
@dataclass
class Image:
    image: PILImage.Image
```

**Post-init processing** (`__post_init__`):

1. Validates that the image has a readable `format` attribute; raises `TypeError` otherwise.
2. Serializes the image to an in-memory `BytesIO` buffer using its original format.
3. Base64-encodes the bytes and stores the result as `image_str`.
4. Derives the MIME type and stores it as `image_format` (e.g. `"image/png"`).

**Derived attributes** (set automatically, not constructor arguments):

| Attribute | Description |
|-----------|-------------|
| `image_str` | Base64-encoded string of the image bytes. |
| `image_format` | MIME type string, e.g. `image/png`. |

These derived fields are exactly what API adapters need. For example, `OpenAITypeAdapter._create_img_content` builds a data URL as `f"data:{image.image_format};base64,{image.image_str}"`, and `AnthropicTypeAdapter` uses the same two fields to build a base64 source block.

### `Video`

```python
@dataclass
class Video:
    video: Any
```

A thin wrapper around an arbitrary video object. Unlike `Image`, it performs no normalization — the raw `video` value is passed through to the adapter, which is responsible for interpreting it. This keeps the module agnostic to the many video representations different backends accept.

### `Audio`

```python
@dataclass
class Audio:
    audio: Any
```

Identical in shape to `Video`: a pass-through wrapper around an arbitrary audio object.

### `Chat`

Represents a conversation as an ordered list of messages. Each message is a `dict` with `role` and `content` keys.

```python
@dataclass
class Chat:
    messages: List[Dict[str, Any]] = None
```

- `role` is one of `"user"`, `"assistant"`, or `"system"`.
- `content` is either a `str` or a `list` whose first element is the text prompt and whose remaining elements are assets (`Image`, `Video`, `Audio`).

**Methods:**

| Method | Description |
|--------|-------------|
| `append(message)` | Append a raw message dict. |
| `extend(messages)` | Append a list of message dicts. |
| `pop()` | Remove and return the last message. |
| `add_system_message(content)` | Append a `{"role": "system", ...}` message. |
| `add_user_message(content)` | Append a `{"role": "user", ...}` message. |
| `add_assistant_message(content)` | Append a `{"role": "assistant", ...}` message. |
| `__str__` | Newline-joined string of all messages. |
| `__repr__` | `Chat(messages=[...])`. |

`__post_init__` normalizes a `None` `messages` argument to an empty list, so `Chat()` is valid.

---

## Data Flow

The following diagram shows how an input object flows from user code through a type adapter to a backend-specific payload.

```mermaid
sequenceDiagram
    participant U as User
    participant M as Model
    participant TA as ModelTypeAdapter
    participant B as Backend / API

    U->>M: model(["Describe this", Image(img)])
    M->>TA: format_input(["Describe this", Image(img)])
    TA->>TA: inspect asset types (Image/Audio/Video)
    TA->>TA: read image.image_str, image.image_format
    TA-->>M: backend-specific payload
    M->>B: send payload
    B-->>M: response
    M-->>U: response
```

### How adapters consume inputs

Different adapters interpret the same input objects differently:

```mermaid
graph LR
    subgraph Input["User Input"]
        L["list: [prompt, Image]"]
        C["Chat"]
    end

    L --> OA["OpenAITypeAdapter"]
    L --> AN["AnthropicTypeAdapter"]
    L --> TM["TransformersMultiModalTypeAdapter"]
    C --> OA
    C --> AN
    C --> TM

    OA --> OAO["messages with image_url data URL"]
    AN --> ANO["messages with base64 source block"]
    TM --> TMO["dict: text + images"]
```

- **`OpenAITypeAdapter`** — Accepts `str`, `list`, and `Chat`. For a list, it builds a `messages` entry whose content is a list of `{"type": "text"}` and `{"type": "image_url"}` parts, embedding the image as a data URL.
- **`AnthropicTypeAdapter`** — Accepts `str`, `list`, and `Chat`. Builds a `messages` argument with `{"type": "image", "source": {"type": "base64", ...}}` blocks.
- **`TransformersMultiModalTypeAdapter`** — Accepts `list` and `Chat` (and a deprecated `dict`). For a `Chat`, it strips images from messages, applies the tokenizer's chat template to the text-only messages, then re-attaches the images. For a list, it returns a `{"text": ..., "images"/"audio"/"videos": [...]}` dict.

> **Note:** `TransformersMultiModalTypeAdapter` enforces that all assets in a list are of the **same type**; mixing `Image` and `Audio` raises a `ValueError`.

---

## Component Interaction

The `Chat` class is the most interactive component, since adapters iterate over its `messages` list. The diagram below shows the internal structure of a `Chat` and how its content is decomposed.

```mermaid
graph TD
    Chat --> M1["{role: system, content: str}"]
    Chat --> M2["{role: user, content: [prompt, Image, Image]}"]
    Chat --> M3["{role: assistant, content: str}"]

    M2 --> P["content[0] = text prompt"]
    M2 --> A1["content[1] = Image"]
    M2 --> A2["content[2] = Image"]

    A1 --> IS["image_str (base64)"]
    A1 --> IF["image_format (MIME)"]
```

Adapters rely on this convention: **`content[0]` is always the text prompt** and **`content[1:]` are assets**. This is why `TransformersMultiModalTypeAdapter.format_chat_input` can split `message["content"][0]` from `message["content"][1:]`.

---

## Process Flow: Constructing and Using Inputs

```mermaid
flowchart TD
    Start([User builds input]) --> Choice{Input kind?}

    Choice -->|Text only| Str["str prompt"]
    Choice -->|Multimodal| Img["Image(pil_image)"]
    Choice -->|Conversation| ChatC["Chat()"]

    Img --> Post["__post_init__: encode to base64, derive MIME"]
    Post --> List["list: [prompt, Image]"]

    ChatC --> AddMsg["add_system/user/assistant_message()"]
    AddMsg --> ChatReady["Chat with messages"]

    Str --> ModelCall["model(model_input)"]
    List --> ModelCall
    ChatReady --> ModelCall

    ModelCall --> Adapter["TypeAdapter.format_input()"]
    Adapter --> Payload["Backend-specific payload"]
    Payload --> End([Sent to model])
```

---

## Relationship to Other Modules

| Module | Relationship |
|--------|--------------|
| [models.md](models.md) | Models accept `Image`, `Video`, `Audio`, and `Chat` as `model_input`. Each model's `ModelTypeAdapter` converts these objects into backend-specific formats. |
| [generator.md](generator.md) | Generators wrap models; inputs ultimately flow through generators to the underlying model. |
| [types_dsl.md](types_dsl.md) | Defines **output** types (e.g. `JsonSchema`, `Regex`). Inputs and output types are complementary: inputs describe what goes *in*, output types describe what comes *out*. |

---

## Usage Examples

### Text-only prompt

```python
response = model("Write a haiku about the sea.")
```

### Multimodal prompt with an image

```python
from PIL import Image as PILImage
from outlines import Image

img = Image(PILImage.open("cat.png"))
response = model(["Describe the image below", img])
```

### Chat with a system message and an image

```python
from outlines import Chat, Image

chat = Chat([
    {"role": "system", "content": "You are a helpful assistant."},
])
chat.add_user_message(["Describe the image below", Image(img)])
chat.add_assistant_message("This is a black cat sitting on a couch.")

response = model(chat)
```

### Building a chat incrementally

```python
chat = Chat()
chat.add_system_message("You are a helpful assistant.")
chat.add_user_message("What is the capital of France?")
# ... call model, then:
chat.add_assistant_message("The capital of France is Paris.")
```

---

## Summary

The `inputs` module is a small, dependency-free data layer that standardizes how multimodal and chat inputs are represented across all Outlines models. Its design pushes all backend-specific formatting into the model type adapters, keeping the input classes simple, reusable, and easy to construct. The `Image` class is the only one that performs eager work (base64 encoding and MIME derivation), while `Video`, `Audio`, and `Chat` are thin, pass-through containers.
