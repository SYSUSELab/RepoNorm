# Tensor Adapters

## Introduction

The `processors_tensor_adapters` module provides a unified abstraction layer for manipulating tensors across multiple numerical computing libraries. It enables the Outlines library to support diverse model backends (PyTorch, JAX, MLX, NumPy, TensorFlow) without duplicating tensor manipulation logic throughout the codebase.

The module defines an abstract `TensorAdapter` interface and five concrete implementations, each wrapping the tensor operations of a specific library. These adapters are consumed primarily by the [logits processors](processors_logits_processor.md) to apply token masks and bias generation regardless of the underlying tensor library used by a model.

## Purpose and Core Functionality

The central problem this module solves is **library heterogeneity**. Different model backends in Outlines use different tensor libraries:

- **PyTorch** — used by `transformers`, `vllm`, `sglang`, `tgi` models
- **JAX** — used by JAX-based models
- **MLX** — used by Apple Silicon `mlx-lm` models
- **NumPy** — used for CPU-based array operations
- **TensorFlow** — used by TensorFlow-based models

Rather than writing conditional logic (`if torch: ... elif jax: ...`) throughout the logits processing pipeline, the module encapsulates each library's API behind a common interface. The `OutlinesLogitsProcessor` selects the appropriate adapter at initialization based on a `tensor_library_name` string, then operates exclusively through the adapter's methods.

## Architecture

The module follows a classic **Strategy pattern** with an abstract base class and concrete strategy implementations.

```mermaid
classDiagram
    class TensorAdapter {
        <<abstract>>
        +str library_name
        +shape(tensor) list[int]
        +unsqueeze(tensor) TensorType
        +squeeze(tensor) TensorType
        +to_list(tensor) list
        +to_scalar(tensor) Any
        +full_like(tensor, fill_value) TensorType
        +concatenate(tensors) TensorType
        +get_device(tensor) str
        +to_device(tensor, device) TensorType
        +boolean_ones_like(tensor) TensorType
        +apply_mask(tensor, mask, value) TensorType
        +argsort_descending(tensor) TensorType
    }

    class TorchTensorAdapter {
        +library_name = "torch"
    }
    class JAXTensorAdapter {
        +library_name = "jax"
    }
    class MLXTensorAdapter {
        +library_name = "mlx"
    }
    class NumpyTensorAdapter {
        +library_name = "numpy"
    }
    class TensorFlowTensorAdapter {
        +library_name = "tensorflow"
    }

    TensorAdapter <|-- TorchTensorAdapter
    TensorAdapter <|-- JAXTensorAdapter
    TensorAdapter <|-- MLXTensorAdapter
    TensorAdapter <|-- NumpyTensorAdapter
    TensorAdapter <|-- TensorFlowTensorAdapter
```

### Component Responsibilities

| Component | File | Responsibility |
|-----------|------|----------------|
| `TensorAdapter` | `base.py` | Defines the abstract interface all adapters must implement |
| `TorchTensorAdapter` | `torch.py` | Wraps PyTorch tensor operations |
| `JAXTensorAdapter` | `jax.py` | Wraps JAX (`jax.numpy`) operations |
| `MLXTensorAdapter` | `mlx.py` | Wraps MLX (`mlx.core`) operations |
| `NumpyTensorAdapter` | `numpy.py` | Wraps NumPy operations |
| `TensorFlowTensorAdapter` | `tensorflow.py` | Wraps TensorFlow operations |

## The `TensorAdapter` Interface

The abstract base class defines twelve operations that every adapter must implement. These operations fall into several functional categories:

### Shape and Dimension Manipulation
- **`shape(tensor)`** — Returns the tensor's shape as a `list[int]`.
- **`unsqueeze(tensor)`** — Adds a dimension at axis 0 (used to promote 1D tensors to 2D).
- **`squeeze(tensor)`** — Removes the dimension at axis 0 (used to demote 2D tensors back to 1D).

### Conversion
- **`to_list(tensor)`** — Converts a tensor to a Python list.
- **`to_scalar(tensor)`** — Extracts the single element of a tensor.

### Construction
- **`full_like(tensor, fill_value)`** — Creates a tensor of the same shape filled with a scalar value.
- **`boolean_ones_like(tensor)`** — Creates a boolean tensor of ones with the same shape.
- **`concatenate(tensors)`** — Concatenates a list of tensors along axis 0.

### Device Management
- **`get_device(tensor)`** — Returns the device name of a tensor.
- **`to_device(tensor, device)`** — Moves a tensor to a specified device.

### Masking and Sorting
- **`apply_mask(tensor, mask, value)`** — Fills elements where the mask is `True` with a value.
- **`argsort_descending(tensor)`** — Returns indices that sort the tensor in descending order along axis -1.

> **Important cross-library note:** The `full_like` and `concatenate` methods must be able to handle **PyTorch tensors** as input, regardless of the adapter's own library. This is a temporary requirement driven by the version of `outlines-core` in use, which passes torch tensors. See the `MLXTensorAdapter` implementation for an example of handling this gracefully.

## Data Flow

The adapters sit between the logits processor and the model's native tensor library. The following diagram shows how a logits processor uses an adapter to normalize, process, and restore tensor shapes.

```mermaid
sequenceDiagram
    participant Model
    participant LP as OutlinesLogitsProcessor
    participant TA as TensorAdapter
    participant Sub as process_logits (subclass)

    Model->>LP: __call__(input_ids, logits)
    LP->>TA: shape(input_ids), shape(logits)
    alt input_ids is 1D and logits is 2D single-sequence
        LP->>TA: unsqueeze(input_ids)
    end
    alt logits is 2D
        LP->>Sub: process_logits(input_ids, logits)
    else logits is 1D
        LP->>TA: unsqueeze(input_ids), unsqueeze(logits)
        LP->>Sub: process_logits(...)
        LP->>TA: squeeze(processed_logits)
    end
    Sub->>TA: apply_mask / argsort_descending / ...
    Sub-->>LP: processed_logits
    LP-->>Model: processed_logits
```

The adapter is instantiated once when the logits processor is created, based on the `tensor_library_name` argument. All subsequent tensor operations during generation flow through this single adapter instance.

## Component Interaction

The following diagram illustrates how the tensor adapters integrate with the broader Outlines processing pipeline.

```mermaid
flowchart TD
    subgraph Models
        M1[Transformers / vLLM / SGLang]
        M2[MLX-LM]
        M3[JAX Models]
        M4[TensorFlow Models]
    end

    subgraph Processors
        LP[OutlinesLogitsProcessor]
        REG[Tensor Adapter Registry]
    end

    subgraph TensorAdapters[processors_tensor_adapters]
        TA[TensorAdapter ABC]
        TORCH[TorchTensorAdapter]
        JAX[JAXTensorAdapter]
        MLX[MLXTensorAdapter]
        NP[NumpyTensorAdapter]
        TF[TensorFlowTensorAdapter]
    end

    M1 -->|tensor_library_name='torch'| LP
    M2 -->|tensor_library_name='mlx'| LP
    M3 -->|tensor_library_name='jax'| LP
    M4 -->|tensor_library_name='tensorflow'| LP

    LP --> REG
    REG --> TORCH
    REG --> JAX
    REG --> MLX
    REG --> NP
    REG --> TF

    TORCH -.implements.-> TA
    JAX -.implements.-> TA
    MLX -.implements.-> TA
    NP -.implements.-> TA
    TF -.implements.-> TA
```

## Adapter Selection Process

When an `OutlinesLogitsProcessor` is constructed, it resolves the correct adapter from a registry keyed by library name. If the requested library is unavailable, a `NotImplementedError` is raised.

```mermaid
flowchart TD
    A[OutlinesLogitsProcessor.__init__] --> B{tensor_library_name == 'torch'?}
    B -->|Yes| C[Suppress torch._dynamo errors]
    B -->|No| D[Lookup adapter in registry]
    C --> D
    D --> E{Adapter found?}
    E -->|No| F[Raise NotImplementedError]
    E -->|Yes| G[Instantiate adapter]
    G --> H[Store as self.tensor_adapter]
```

## Implementation Notes per Adapter

Each concrete adapter wraps a specific library's API. The table below summarizes the key library-specific mappings.

| Operation | Torch | JAX | MLX | NumPy | TensorFlow |
|-----------|-------|-----|-----|-------|------------|
| `unsqueeze` | `tensor.unsqueeze(0)` | `jnp.expand_dims` | `mx.expand_dims` | `np.expand_dims` | `tf.expand_dims` |
| `squeeze` | `tensor.squeeze(0)` | `jnp.squeeze` | `tensor[0]` (conditional) | `np.squeeze` | `tf.squeeze` |
| `full_like` | `torch.full_like` | `jnp.full_like` | `mx.full(shape, val)` | `np.full_like` | `tf.fill(tf.shape, val)` |
| `concatenate` | `torch.cat` | `jnp.concatenate` | `mx.concatenate` | `np.concatenate` | `tf.concat` |
| `apply_mask` | `torch.masked_fill` | `.at[mask].set` | `mx.where` | `result[mask] = value` | `tf.where` |
| `argsort_descending` | `torch.argsort(descending=True)` | `jnp.argsort(-tensor)` | `mx.argsort(-tensor)` | `np.argsort(-tensor)` | `tf.argsort(direction='DESCENDING')` |
| `get_device` | `tensor.device` | `None` | `None` | `None` | `tensor.device` |
| `to_device` | `tensor.to(device)` | no-op | no-op | no-op | `tf.device` context |

### Notable Implementation Details

- **`MLXTensorAdapter.squeeze`** conditionally removes the leading axis only when its size is 1, unlike other adapters that unconditionally squeeze axis 0.
- **`MLXTensorAdapter.concatenate`** explicitly converts non-MLX inputs (e.g., torch tensors) to MLX arrays before concatenating, satisfying the cross-library requirement.
- **`JAXTensorAdapter.apply_mask`** uses JAX's functional update syntax (`.at[mask].set(value)`) since JAX arrays are immutable.
- **`TensorFlowTensorAdapter.to_list` / `to_scalar`** call `.numpy()` first to materialize eager tensors.
- **`JAXTensorAdapter`, `MLXTensorAdapter`, and `NumpyTensorAdapter`** return `None` from `get_device` and treat `to_device` as a no-op, as these libraries do not expose device placement in the same way.

## Relationship to Other Modules

- **[processors_logits_processor](processors_logits_processor.md)** — The primary consumer. `OutlinesLogitsProcessor` instantiates and uses a `TensorAdapter` to normalize tensor shapes and apply masks during generation.
- **[backends](backends.md)** — Backends produce logits processors (via `get_json_schema_logits_processor`, `get_regex_logits_processor`, `get_cfg_logits_processor`) that ultimately rely on tensor adapters for tensor manipulation.
- **[models](models.md)** — Models determine which tensor library is in use and pass the corresponding `tensor_library_name` to the logits processor, thereby selecting the adapter.

## Extending the Module

To add support for a new tensor library:

1. Create a new file in `outlines/processors/tensor_adapters/` (e.g., `mylib.py`).
2. Subclass `TensorAdapter` and set the `library_name` class attribute.
3. Implement all twelve abstract methods, ensuring `full_like` and `concatenate` can accept torch tensors.
4. Register the new adapter in the tensor adapter registry used by `OutlinesLogitsProcessor`.

```mermaid
flowchart LR
    A[Create adapter subclass] --> B[Set library_name]
    B --> C[Implement 12 abstract methods]
    C --> D[Handle torch inputs in full_like/concatenate]
    D --> E[Register in adapter registry]
    E --> F[Available for use]
```
