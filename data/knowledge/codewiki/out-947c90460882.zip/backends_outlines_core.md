# Outlines Core Backend

## Introduction

The `backends_outlines_core` module provides the **Outlines Core** backend implementation for the Outlines structured generation framework. It enables constrained text generation by biasing model logits according to a regular expression, JSON schema, or (in principle) a context-free grammar, using the high-performance [`outlines_core`](https://github.com/dottxt-ai/outlines-core) Rust library.

The module exposes two core components:

- **`OutlinesCoreBackend`** — a concrete implementation of [`BaseBackend`](backends_base.md) that translates high-level constraints (JSON schema, regex) into logits processors.
- **`OutlinesCoreLogitsProcessor`** — a concrete implementation of [`OutlinesLogitsProcessor`](processors_base_logits_processor.md) that applies token bitmasks to bias logits during generation.

This backend is one of several interchangeable backends (alongside [LLGuidance](backends_llguidance.md) and [XGrammar](backends_xgrammar.md)) that Outlines supports for structured generation.

---

## Architecture Overview

The Outlines Core backend sits between the user-facing model abstraction and the low-level `outlines_core` Rust library. It converts model-specific tokenizers into an `outlines_core.Vocabulary`, builds an `Index` from a constraint, and produces a logits processor that biases generation.

```mermaid
graph TD
    subgraph "User / Model Layer"
        M[SteerableModel<br/>Transformers / LlamaCpp / MLXLM]
    end

    subgraph "Backend Layer"
        BB[BaseBackend<br/>abstract]
        OCB[OutlinesCoreBackend]
    end

    subgraph "Processor Layer"
        OLP[OutlinesLogitsProcessor<br/>abstract]
        OCLP[OutlinesCoreLogitsProcessor]
    end

    subgraph "Tensor Abstraction"
        TA[TensorAdapter<br/>torch / numpy / mlx]
    end

    subgraph "outlines_core (Rust)"
        VOC[Vocabulary]
        IDX[Index]
        GUIDE[Guide]
        KERNELS[Kernels<br/>bitmask allocation & application]
    end

    M --> OCB
    BB -.implements.-> OCB
    OCB -->|creates| OCLP
    OLP -.implements.-> OCLP
    OCLP --> TA
    OCB -->|builds| VOC
    OCB -->|builds| IDX
    OCLP -->|uses| GUIDE
    OCLP -->|uses| KERNELS
    IDX --> GUIDE
    VOC --> IDX
```

---

## Component Relationships

The following diagram shows how the two core components interact with each other and with external dependencies.

```mermaid
classDiagram
    class BaseBackend {
        <<abstract>>
        +get_json_schema_logits_processor(json_schema)
        +get_regex_logits_processor(regex)
        +get_cfg_logits_processor(grammar)
    }

    class OutlinesCoreBackend {
        +int eos_token_id
        +Vocabulary vocabulary
        +str tensor_library_name
        +get_json_schema_logits_processor(json_schema)
        +get_regex_logits_processor(regex)
        +get_cfg_logits_processor(grammar)
        +create_outlines_core_vocabulary(vocab, eos_token_id, eos_token)$
    }

    class OutlinesLogitsProcessor {
        <<abstract>>
        +TensorAdapter tensor_adapter
        +reset()
        +process_logits(input_ids, logits)*
        +__call__(input_ids, logits)
    }

    class OutlinesCoreLogitsProcessor {
        +Index index
        +str tensor_library_name
        +bool is_first_token
        +reset()
        +_setup(batch_size, vocab_size)
        +_bias_logits_torch(batch_size, logits)
        +_bias_logits_numpy(batch_size, logits)
        +_bias_logits_mlx(batch_size, logits)
        +process_logits(input_ids, logits)
    }

    BaseBackend <|-- OutlinesCoreBackend
    OutlinesLogitsProcessor <|-- OutlinesCoreLogitsProcessor
    OutlinesCoreBackend ..> OutlinesCoreLogitsProcessor : creates
```

---

## Core Components

### `OutlinesCoreBackend`

The backend is responsible for **translating constraints into logits processors**. It is constructed from a `SteerableModel` and extracts the tokenizer vocabulary and EOS token information from the model.

**Supported models:**

| Model Type | Vocabulary Source | EOS Source |
|------------|-------------------|------------|
| `Transformers` | `model.hf_tokenizer.get_vocab()` | `model.hf_tokenizer.eos_token_id` / `eos_token` |
| `LlamaCpp` | `model.tokenizer.vocabulary` | `model.tokenizer.eos_token_id` / `eos_token` |
| `MLXLM` | `model.mlx_tokenizer._tokenizer.get_vocab()` | `model.mlx_tokenizer._tokenizer.eos_token_id` / `eos_token` |

Any other model type raises a `ValueError`.

**Key methods:**

- **`get_json_schema_logits_processor(json_schema)`** — Builds a regex from the JSON schema via `outlines_core.json_schema.build_regex_from_schema`, then delegates to `get_regex_logits_processor`.
- **`get_regex_logits_processor(regex)`** — Creates an `outlines_core.Index` from the regex and the backend's vocabulary, then wraps it in an `OutlinesCoreLogitsProcessor`.
- **`get_cfg_logits_processor(grammar)`** — **Not supported.** Raises `NotImplementedError` because Outlines Core does not support context-free grammars.
- **`create_outlines_core_vocabulary(vocab, eos_token_id, eos_token)`** *(static)* — Converts a standard `Dict[str, int]` vocabulary into an `outlines_core.Vocabulary`. Each token maps to a single-element list of its token ID, and the EOS token is removed from the mapping (it is passed separately as `eos_token_id`).

### `OutlinesCoreLogitsProcessor`

The logits processor **applies token bitmasks to bias logits** at each generation step. It maintains one `Guide` and one bitmask per sequence in the batch.

**Lifecycle:**

1. **Initialization** — Stores the `Index`, tensor library name, and sets `is_first_token = True`. Calls the parent `OutlinesLogitsProcessor.__init__` to set up the appropriate `TensorAdapter`.
2. **First token (`_setup`)** — On the first call to `process_logits`, the batch size and vocabulary size are known, so the processor:
   - Imports the correct `allocate_token_bitmask` kernel for the tensor library.
   - Selects the matching `_bias_logits_*` method.
   - Creates one `Guide` per batch element and one bitmask per batch element.
3. **Subsequent tokens** — For each sequence, the last generated token ID is read and the corresponding `Guide` is advanced (unless already finished).
4. **Biasing** — `bias_logits` (one of the library-specific methods) fills the next-token bitmask and applies it to the logits.

**Tensor library support:**

| Library | Bitmask Allocation | Bias Method | In-place? |
|---------|--------------------|-------------|-----------|
| `torch` | `outlines_core.kernels.torch.allocate_token_bitmask` | `_bias_logits_torch` | Yes (`apply_token_bitmask_inplace`) |
| `numpy` | `outlines_core.kernels.numpy.allocate_token_bitmask` | `_bias_logits_numpy` | Yes (`apply_token_bitmask_inplace`) |
| `mlx` | `outlines_core.kernels.mlx.allocate_token_bitmask` | `_bias_logits_mlx` | No (builds a new array via `apply_token_bitmask` + `concatenate`) |

Any other tensor library raises a `ValueError`.

**`reset()`** — Resets `is_first_token` to `True` so the processor can be reused for a new generation.

---

## Data Flow

The following sequence diagram illustrates the end-to-end flow from a user request to biased logits.

```mermaid
sequenceDiagram
    participant User
    participant Model as SteerableModel
    participant Backend as OutlinesCoreBackend
    participant Core as outlines_core
    participant Proc as OutlinesCoreLogitsProcessor
    participant Adapter as TensorAdapter

    User->>Backend: get_json_schema_logits_processor(schema)
    Backend->>Core: build_regex_from_schema(schema)
    Core-->>Backend: regex
    Backend->>Core: Index(regex, vocabulary)
    Core-->>Backend: index
    Backend->>Proc: OutlinesCoreLogitsProcessor(index, tensor_lib)
    Proc-->>Backend: processor
    Backend-->>User: processor

    Note over Model,Proc: During generation
    Model->>Proc: __call__(input_ids, logits)
    Proc->>Adapter: shape(input_ids), shape(logits)
    Adapter-->>Proc: batch_size, vocab_size
    alt First token
        Proc->>Proc: _setup(batch_size, vocab_size)
        Proc->>Core: allocate_token_bitmask(vocab_size)
        Core-->>Proc: bitmasks
        Proc->>Core: Guide(index) x batch_size
        Core-->>Proc: guides
    else Subsequent tokens
        Proc->>Adapter: to_scalar(input_ids[i][-1])
        Adapter-->>Proc: last_token_id
        Proc->>Core: guide.advance(last_token_id)
    end
    Proc->>Core: fill_next_token_bitmask(guide, bitmask)
    Proc->>Core: apply_token_bitmask(logits, bitmask)
    Core-->>Proc: biased logits
    Proc-->>Model: biased logits
```

---

## Process Flow: Logits Processing

```mermaid
flowchart TD
    A[process_logits called] --> B[Get batch_size and vocab_size]
    B --> C{is_first_token?}
    C -->|Yes| D[_setup: allocate bitmasks & guides]
    D --> E[Set is_first_token = False]
    C -->|No| F[For each sequence in batch]
    F --> G[Read last token id]
    G --> H{Guide finished?}
    H -->|No| I[guide.advance token_id]
    H -->|Yes| J[Skip advance]
    I --> K[bias_logits]
    J --> K
    E --> K
    K --> L{Which tensor library?}
    L -->|torch| M[fill bitmask + apply inplace]
    L -->|numpy| N[fill bitmask + apply inplace]
    L -->|mlx| O[fill bitmask + apply + concatenate]
    M --> P[Return biased logits]
    N --> P
    O --> P
```

---

## Dependencies

### Internal Dependencies

| Dependency | Purpose | Documentation |
|------------|---------|---------------|
| `BaseBackend` | Abstract interface the backend implements | [backends_base.md](backends_base.md) |
| `OutlinesLogitsProcessor` | Abstract base for logits processors | [processors_base_logits_processor.md](processors_base_logits_processor.md) |
| `TensorAdapter` | Library-agnostic tensor manipulation | [processors_tensor_adapters_base.md](processors_tensor_adapters_base.md) |
| `SteerableModel` | Model abstraction providing tokenizer & tensor library | [models_base.md](models_base.md) |
| `Transformers`, `LlamaCpp`, `MLXLM` | Concrete supported models | [models_transformers.md](models_transformers.md), [models_llamacpp.md](models_llamacpp.md), [models_mlxlm.md](models_mlxlm.md) |

### External Dependencies

| Dependency | Purpose |
|------------|---------|
| `outlines_core` | Rust library providing `Guide`, `Index`, `Vocabulary`, and tensor kernels |
| `outlines_core.outlines_core` | Submodule for JSON schema → regex conversion |
| `outlines_core.kernels.{torch,numpy,mlx}` | Bitmask allocation and application kernels |

---

## Backend Comparison

The Outlines Core backend is one of three interchangeable backends. The table below summarizes the differences.

```mermaid
graph LR
    subgraph Backends
        OC[Outlines Core]
        LG[LLGuidance]
        XG[XGrammar]
    end
    OC -->|supports| R1[Regex]
    OC -->|supports| R2[JSON Schema]
    OC -->|NOT supported| R3[CFG]
    LG -->|supports| R1
    LG -->|supports| R2
    LG -->|supports| R3
    XG -->|supports| R1
    XG -->|supports| R2
    XG -->|supports| R3
```

| Feature | Outlines Core | [LLGuidance](backends_llguidance.md) | [XGrammar](backends_xgrammar.md) |
|---------|---------------|--------------------------------------|----------------------------------|
| Regex | ✅ | ✅ | ✅ |
| JSON Schema | ✅ | ✅ | ✅ |
| Context-Free Grammar | ❌ (`NotImplementedError`) | ✅ | ✅ |
| Supported Models | Transformers, LlamaCpp, MLXLM | Transformers, LlamaCpp, MLXLM | Transformers only |
| Tensor Libraries | torch, numpy, mlx | (via base processor) | (via base processor) |

---

## Usage Example

```python
from outlines import models
from outlines.backends.outlines_core import OutlinesCoreBackend

# Load a supported model
model = models.transformers("mistralai/Mistral-7B-v0.1")

# Create the backend
backend = OutlinesCoreBackend(model)

# Build a logits processor from a JSON schema
processor = backend.get_json_schema_logits_processor(
    '{"type": "object", "properties": {"name": {"type": "string"}}}'
)

# Or from a regex
processor = backend.get_regex_logits_processor(r"\d{3}-\d{4}")
```

---

## Notes and Limitations

- **No CFG support** — `get_cfg_logits_processor` raises `NotImplementedError`. Use the [LLGuidance](backends_llguidance.md) or [XGrammar](backends_xgrammar.md) backend if context-free grammars are required.
- **Model restrictions** — Only `Transformers`, `LlamaCpp`, and `MLXLM` models are supported. Other model types raise a `ValueError` at backend construction.
- **Tensor library restrictions** — Only `torch`, `numpy`, and `mlx` are supported by the logits processor. Other libraries raise a `ValueError` during `_setup`.
- **Lazy setup** — Bitmasks and guides are allocated on the first token because the batch size is unknown at construction time.
- **Import workaround** — The module imports both `outlines_core` and `outlines_core.outlines_core` due to a known import issue in the library.
- **MLX non-in-place** — Unlike torch and numpy, the MLX bias path builds a new array and concatenates, since MLX does not support in-place bitmask application.
