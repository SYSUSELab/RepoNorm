# Models Module

## Introduction

The **models** module (`outlines/models/`) is the layer of Outlines that wraps every supported
language-model backend behind a single, uniform interface. Whether the underlying model is a local
`transformers` model running on your GPU, a remote OpenAI endpoint, or a self-hosted vLLM server,
the rest of Outlines interacts with it through the same small set of abstractions.

The module's responsibilities are:

1. **Uniform model interface** — every model exposes `generate`, `generate_batch`, and
   `generate_stream` (plus convenience `__call__`, `batch`, and `stream` methods), so downstream code
   never needs to know which provider it is talking to.
2. **Input/output translation** — each model ships a **type adapter** that converts the high-level
   inputs (`str`, `list`, `Chat`, `Image`, ...) and output types (Pydantic models, JSON schemas,
   regexes, CFGs, ...) into the exact arguments the underlying client or library expects.
3. **Tokenizer abstraction** — local models expose a `Tokenizer` that provides the vocabulary and
   encode/decode primitives required by the constrained-decoding backends.
4. **Two generation paradigms** — the module cleanly separates *steerable* models (where Outlines
   controls decoding via logits processors) from *black-box* models (where the provider enforces the
   output format).

The module is organized into four logical groups, each documented separately:

| Group | Documentation | Models |
|-------|---------------|--------|
| Base abstractions | [models_base.md](models_base.md) | `Model`, `AsyncModel`, `ModelTypeAdapter`, `Tokenizer` |
| Local / steerable models | [models_local.md](models_local.md) | `Transformers`, `TransformersMultiModal`, `LlamaCpp`, `MLXLM`, `VLLMOffline` |
| Black-box API models | [models_api.md](models_api.md) | `OpenAI`, `Anthropic`, `Gemini`, `Dottxt`, `Ollama` |
| Server-based models | [models_server.md](models_server.md) | `VLLM`, `SGLang`, `TGI` (sync + async) |

---

## Architecture Overview

Every model in the module is built from the same three ingredients: a **base class** (`Model` or
`AsyncModel`), a **type adapter** (`ModelTypeAdapter`), and — for local models — a **tokenizer**
(`Tokenizer`). The base class defines the public API, the type adapter handles translation, and the
tokenizer feeds the constrained-decoding backends.

```mermaid
graph TD
    subgraph "models/base.py"
        Model["Model (ABC)"]
        AsyncModel["AsyncModel (ABC)"]
        MTA["ModelTypeAdapter (ABC)"]
    end

    subgraph "models/tokenizer.py"
        Tok["Tokenizer (Protocol)"]
    end

    subgraph "Local / steerable"
        T["Transformers"]
        TM["TransformersMultiModal"]
        LC["LlamaCpp"]
        MLX["MLXLM"]
        VO["VLLMOffline"]
    end

    subgraph "Black-box API"
        OA["OpenAI"]
        AN["Anthropic"]
        GE["Gemini"]
        DX["Dottxt"]
        OL["Ollama / AsyncOllama"]
    end

    subgraph "Server-based"
        VL["VLLM / AsyncVLLM"]
        SG["SGLang / AsyncSGLang"]
        TG["TGI / AsyncTGI"]
    end

    Model --> T
    Model --> TM
    Model --> LC
    Model --> MLX
    Model --> VO
    Model --> OA
    Model --> AN
    Model --> GE
    Model --> DX
    Model --> OL
    Model --> VL
    Model --> SG
    Model --> TG
    AsyncModel --> OL
    AsyncModel --> VL
    AsyncModel --> SG
    AsyncModel --> TG

    T -.->|"uses"| MTA
    T -.->|"uses"| Tok
    LC -.->|"uses"| Tok
    MLX -.->|"uses"| Tok
```

### The two generation paradigms

The single most important design decision in this module is the split between **steerable** and
**black-box** models. This distinction determines how an output type is enforced.

```mermaid
graph LR
    subgraph Steerable["Steerable models (local)"]
        direction TB
        S1["Outlines owns the logits"]
        S2["Output type → logits processor"]
        S3["Applied at every decoding step"]
        S1 --> S2 --> S3
    end
    subgraph BlackBox["Black-box models (remote)"]
        direction TB
        B1["Provider owns the logits"]
        B2["Output type → provider argument"]
        B3["Enforced server-side"]
        B1 --> B2 --> B3
    end
```

- **Steerable models** (`Transformers`, `LlamaCpp`, `MLXLM`, `VLLMOffline`) expose a
  `tensor_library_name` attribute and a `Tokenizer`. Their type adapters turn an output type into a
  **logits processor** (via the [backends](backends.md) module) that is passed to the model's
  `generate` method.
- **Black-box models** (`OpenAI`, `Anthropic`, `Gemini`, `Dottxt`, `Ollama`, and the server-based
  `VLLM`, `SGLang`, `TGI`) do not expose logits. Their type adapters turn an output type into a
  provider-specific argument (e.g. OpenAI's `response_format`, vLLM's `guided_json`).

The [generator](generator.md) module inspects the model instance and selects the appropriate
generation strategy automatically.

### The type-adapter pattern

Every model delegates all input/output translation to a `ModelTypeAdapter` subclass. This keeps the
model classes thin and makes the translation logic independently testable.

```mermaid
classDiagram
    class ModelTypeAdapter {
        <<abstract>>
        +format_input(model_input) Any
        +format_output_type(output_type) Any
    }
    class OpenAITypeAdapter
    class AnthropicTypeAdapter
    class GeminiTypeAdapter
    class DottxtTypeAdapter
    class OllamaTypeAdapter
    class TransformersTypeAdapter
    class TransformersMultiModalTypeAdapter
    class LlamaCppTypeAdapter
    class MLXLMTypeAdapter
    class VLLMTypeAdapter
    class SGLangTypeAdapter
    class TGITypeAdapter
    class VLLMOfflineTypeAdapter

    ModelTypeAdapter <|-- OpenAITypeAdapter
    ModelTypeAdapter <|-- AnthropicTypeAdapter
    ModelTypeAdapter <|-- GeminiTypeAdapter
    ModelTypeAdapter <|-- DottxtTypeAdapter
    ModelTypeAdapter <|-- OllamaTypeAdapter
    ModelTypeAdapter <|-- TransformersTypeAdapter
    ModelTypeAdapter <|-- TransformersMultiModalTypeAdapter
    ModelTypeAdapter <|-- LlamaCppTypeAdapter
    ModelTypeAdapter <|-- MLXLMTypeAdapter
    ModelTypeAdapter <|-- VLLMTypeAdapter
    ModelTypeAdapter <|-- SGLangTypeAdapter
    ModelTypeAdapter <|-- TGITypeAdapter
    ModelTypeAdapter <|-- VLLMOfflineTypeAdapter
```

`format_input` validates and normalizes the user input; `format_output_type` converts the requested
output type into the model-specific representation. See [models_base.md](models_base.md) for the
full contract.

---

## Sub-modules

### Base abstractions

**Files:** `outlines/models/base.py`, `outlines/models/tokenizer.py` — see
[models_base.md](models_base.md)

Defines the abstract `Model` and `AsyncModel` base classes, the `ModelTypeAdapter` interface, and the
`Tokenizer` protocol. These are the contracts every concrete model implements. The base classes also
provide the convenience `__call__`, `batch`, and `stream` methods that internally construct a
[generator](generator.md).

### Local / steerable models

**Files:** `outlines/models/transformers.py`, `outlines/models/llamacpp.py`,
`outlines/models/mlxlm.py`, `outlines/models/vllm_offline.py` — see [models_local.md](models_local.md)

Wraps models that run locally and whose logits Outlines can directly manipulate. These models expose
a `tensor_library_name` (`torch`, `numpy`, `mlx`, `jax`, `tensorflow`) and a `Tokenizer`, enabling
the [backends](backends.md) module to compile output types into logits processors. Includes the
`Transformers`/`TransformersMultiModal` wrappers (with `TransformerTokenizer`), `LlamaCpp` (with
`LlamaCppTokenizer`), `MLXLM`, and the offline `vLLM` integration.

### Black-box API models

**Files:** `outlines/models/openai.py`, `outlines/models/anthropic.py`,
`outlines/models/gemini.py`, `outlines/models/dottxt.py`, `outlines/models/ollama.py` — see
[models_api.md](models_api.md)

Wraps remote provider SDKs. Constrained generation is delegated to the provider: each type adapter
converts the output type into the provider's native structured-output argument (JSON schema,
response format, enum, etc.). Includes `OpenAI`, `Anthropic`, `Gemini`, `Dottxt`, and the
synchronous/asynchronous `Ollama` clients.

### Server-based models

**Files:** `outlines/models/vllm.py`, `outlines/models/sglang.py`, `outlines/models/tgi.py` — see
[models_server.md](models_server.md)

Wraps self-hosted inference servers. These models talk to a server over an OpenAI-compatible or
HuggingFace client and translate output types into server-specific guided-decoding arguments
(`guided_json`, `guided_regex`, `guided_grammar`, `grammar`, `ebnf`, ...). Includes `VLLM`,
`SGLang`, and `TGI`, each with a synchronous and an asynchronous variant.

---

## Data Flow

The following diagram shows how a user input and output type flow through a model, from the public
API down to the underlying client or library.

```mermaid
sequenceDiagram
    participant U as User
    participant M as Model
    participant TA as TypeAdapter
    participant C as Client / Library

    U->>M: model(prompt, output_type)
    M->>M: Generator(self, output_type)
    M->>TA: format_input(prompt)
    TA-->>M: provider-specific input
    M->>TA: format_output_type(output_type)
    alt Steerable model
        TA-->>M: logits processor
    else Black-box model
        TA-->>M: provider argument (response_format, guided_json, ...)
    end
    M->>C: generate(...)
    C-->>M: raw response
    M-->>U: text / structured output
```

---

## Relationship to other modules

The models module is a central hub: it depends on several other modules and is depended upon by
others.

```mermaid
graph LR
    Models["models.md"] --> Inputs["inputs.md<br/>(Chat, Image, Audio, Video)"]
    Models --> Types["types_dsl.md<br/>(JsonSchema, Regex, CFG, Choice)"]
    Models --> Backends["backends.md<br/>(logits processors for steerable models)"]
    Models --> Processors["processors.md<br/>(OutlinesLogitsProcessor)"]
    Models --> Caching["caching.md<br/>(CloudpickleDisk for tokenizers)"]

    Generator["generator.md"] --> Models
    Applications["applications.md"] --> Models
```

| Related module | Relationship |
|----------------|--------------|
| [inputs.md](inputs.md) | Models consume `Chat`, `Image`, `Audio`, and `Video` inputs; type adapters translate them into provider formats. |
| [types_dsl.md](types_dsl.md) | Output types (`JsonSchema`, `Regex`, `CFG`, `Choice`, ...) are what type adapters convert into provider arguments or logits processors. |
| [backends.md](backends.md) | Steerable models are constructed with a backend that compiles output types into logits processors. |
| [processors.md](processors.md) | Steerable models pass `OutlinesLogitsProcessor` instances to their underlying library during generation. |
| [generator.md](generator.md) | The generator wraps a model and an output type; the model's `__call__`/`batch`/`stream` methods construct a generator internally. |
| [applications.md](applications.md) | Higher-level applications are built on top of models and generators. |
| [caching.md](caching.md) | Tokenizers (e.g. `TransformerTokenizer`) are hashable and picklable to support caching. |

---

## Model compatibility matrix

The table below summarizes the capabilities of each model group.

| Model | Sync | Async | Batch | Stream | Structured output |
|-------|:----:|:-----:|:-----:|:------:|-------------------|
| `Transformers` / `TransformersMultiModal` | ✅ | ❌ | ✅ | ❌ | Logits processor (JSON, regex, CFG) |
| `LlamaCpp` | ✅ | ❌ | ❌ | ✅ | Logits processor (JSON, regex, CFG) |
| `MLXLM` | ✅ | ❌ | ❌ | ✅ | Logits processor (JSON, regex, CFG) |
| `VLLMOffline` | ✅ | ❌ | ✅ | ❌ | Guided decoding (JSON, regex, CFG) |
| `OpenAI` | ✅ | ❌ | ❌ | ✅ | `response_format` (JSON schema) |
| `Anthropic` | ✅ | ❌ | ❌ | ✅ | ❌ (not supported) |
| `Gemini` | ✅ | ❌ | ❌ | ✅ | `response_schema` (JSON, enum) |
| `Dottxt` | ✅ | ❌ | ❌ | ❌ | JSON schema only |
| `Ollama` / `AsyncOllama` | ✅ | ✅ | ❌ | ✅ | `format` (JSON schema) |
| `VLLM` / `AsyncVLLM` | ✅ | ✅ | ❌ | ✅ | `guided_json` / `guided_regex` / `guided_grammar` |
| `SGLang` / `AsyncSGLang` | ✅ | ✅ | ❌ | ✅ | `regex` / `ebnf` / JSON schema |
| `TGI` / `AsyncTGI` | ✅ | ✅ | ❌ | ✅ | `grammar` (JSON, regex) |

---

## Usage Examples

### Local steerable model

```python
from transformers import AutoModelForCausalLM, AutoTokenizer
from outlines import from_transformers, Generator
from pydantic import BaseModel

class Character(BaseModel):
    name: str
    age: int

model = from_transformers(
    AutoModelForCausalLM.from_pretrained("model-name"),
    AutoTokenizer.from_pretrained("model-name"),
)
generator = Generator(model, Character)
result = generator("Generate a character.")
```

### Black-box API model

```python
from openai import OpenAI
from outlines import from_openai, Generator

client = OpenAI()
model = from_openai(client, "gpt-4o")
generator = Generator(model, Character)
result = generator("Generate a character.")
```

### Server-based model

```python
from openai import OpenAI
from outlines import from_vllm, Generator

client = OpenAI(base_url="http://localhost:8000/v1", api_key="EMPTY")
model = from_vllm(client, "model-name")
generator = Generator(model, Character)
result = generator("Generate a character.")
```

---

## Related Documentation

- [models_base.md](models_base.md) — `Model`, `AsyncModel`, `ModelTypeAdapter`, and `Tokenizer`.
- [models_local.md](models_local.md) — Local steerable models and their tokenizers.
- [models_api.md](models_api.md) — Black-box API model integrations.
- [models_server.md](models_server.md) — Self-hosted server integrations.
- [generator.md](generator.md) — How models are wrapped into generators.
- [backends.md](backends.md) — Constrained-decoding engines used by steerable models.
- [processors.md](processors.md) — Logits processors applied during decoding.
- [types_dsl.md](types_dsl.md) — The output-type DSL.
- [inputs.md](inputs.md) — Input data structures (`Chat`, `Image`, ...).
