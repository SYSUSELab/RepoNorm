# Models Base Module

## Introduction

The `models_base` module defines the foundational abstractions for all model
integrations in Outlines. It provides three core building blocks:

- **`Model`** — the abstract base class for all *synchronous* models.
- **`AsyncModel`** — the abstract base class for all *asynchronous* models.
- **`ModelTypeAdapter`** — the abstract base class responsible for translating
  user-facing inputs and output types into the specific format expected by a
  given model backend.

Additionally, the module's sibling file `outlines/models/tokenizer.py` defines
the **`Tokenizer`** protocol, which standardizes how models encode and decode
text.

Together these abstractions allow Outlines to present a single, uniform
interface (`model(prompt, output_type)`, `model.batch(...)`,
`model.stream(...)`) regardless of whether the underlying model is a local
`transformers` model, a remote OpenAI endpoint, or a vLLM server.

> **Scope note:** This document covers only the base abstractions. Concrete
> implementations are documented in the sibling modules
> [models_local](models_local.md), [models_api](models_api.md), and
> [models_server](models_server.md).

---

## Architecture Overview

The base module sits at the center of the model layer. Concrete models inherit
from `Model`/`AsyncModel`, supply a `ModelTypeAdapter`, and are consumed by the
[generator](generator.md) module, which decides whether to build a logits
processor (steerable models) or pass the output type straight through
(black-box models).

```mermaid
graph TD
    subgraph "models_base (this module)"
        Model["Model (ABC)"]
        AsyncModel["AsyncModel (ABC)"]
        MTA["ModelTypeAdapter (ABC)"]
        Tokenizer["Tokenizer (Protocol)"]
    end

    subgraph "Concrete models"
        Local["models_local<br/>Transformers, LlamaCpp, MLXLM, VLLMOffline"]
        API["models_api<br/>OpenAI, Anthropic, Gemini, Dottxt, Ollama"]
        Server["models_server<br/>VLLM, SGLang, TGI"]
    end

    subgraph "Consumers"
        Generator["generator<br/>SteerableGenerator / BlackBoxGenerator"]
        Processor["processors<br/>OutlinesLogitsProcessor"]
        Backend["backends<br/>BaseBackend"]
    end

    Local -->|inherits| Model
    API -->|inherits| Model
    Server -->|inherits| Model
    API -->|inherits| AsyncModel
    Server -->|inherits| AsyncModel

    Local -->|implements| MTA
    API -->|implements| MTA
    Server -->|implements| MTA

    Local -->|implements| Tokenizer

    Model -->|uses| MTA
    AsyncModel -->|uses| MTA

    Generator -->|wraps| Model
    Generator -->|wraps| AsyncModel
    Generator -->|builds| Processor
    Processor -->|created by| Backend
```

---

## Core Components

### `Model` (Synchronous Base Class)

`Model` is an abstract base class (`ABC`) that defines the public interface for
all synchronous models. It provides three **concrete** convenience methods and
three **abstract** methods that subclasses must implement.

#### Class Attributes

| Attribute | Type | Required | Description |
|-----------|------|----------|-------------|
| `type_adapter` | `ModelTypeAdapter` | Yes | Formats inputs and output types for the specific model. |
| `tensor_library_name` | `str` | Only for steerable models | The tensor library used by the model (`"torch"`, `"jax"`, `"numpy"`, `"mlx"`, `"tensorflow"`). Used to build the correct logits processor. |

#### Public Methods (Concrete)

These methods are the user-facing entry points. Each one lazily constructs a
[`Generator`](generator.md) and delegates to it, so the following are
equivalent:

```python
# Direct model call
model("prompt", Foo)

# Explicit generator
generator = Generator(model, Foo)
generator("prompt")
```

| Method | Signature | Description |
|--------|-----------|-------------|
| `__call__` | `(model_input, output_type=None, backend=None, **inference_kwargs)` | Generate a single response. |
| `batch` | `(model_input: List, output_type=None, backend=None, **inference_kwargs)` | Generate responses for several inputs at once. |
| `stream` | `(model_input, output_type=None, backend=None, **inference_kwargs)` | Return an `Iterator` that yields response chunks. |

The `backend` argument selects which [backend](backends.md) is used to build
the logits processor. It is only relevant for *steerable* models when an
`output_type` is provided.

#### Abstract Methods (Subclass Responsibility)

| Method | Signature | Description |
|--------|-----------|-------------|
| `generate` | `(model_input, output_type=None, **inference_kwargs)` | Generate a single response. |
| `generate_batch` | `(model_input: List, output_type=None, **inference_kwargs)` | Generate a batch of responses. |
| `generate_stream` | `(model_input, output_type=None, **inference_kwargs)` | Generate a stream of responses. |

> **Important:** The `output_type` passed to the abstract methods differs by
> model category:
> - **Steerable models** receive a **logits processor** (an
>   [`OutlinesLogitsProcessor`](processors.md)).
> - **Black-box models** receive a **type** (e.g. a Pydantic model, `JsonSchema`,
>   `Regex`, `CFG`).
>
> These methods are **not** intended to be called directly by end users — use
> `__call__`, `batch`, or `stream` instead.

---

### `AsyncModel` (Asynchronous Base Class)

`AsyncModel` mirrors `Model` but exposes `async` versions of the same methods.
It is used by API-based and server-based models that support concurrent
requests (e.g. `AsyncOpenAI`, `AsyncVLLM`, `AsyncSGLang`, `AsyncTGI`,
`AsyncOllama`).

#### Class Attributes

Identical to `Model`: `type_adapter` (required) and `tensor_library_name`
(required for steerable models).

#### Public Methods (Concrete, `async`)

| Method | Signature | Returns |
|--------|-----------|---------|
| `__call__` | `async (model_input, output_type=None, backend=None, **inference_kwargs)` | `Any` |
| `batch` | `async (model_input: List, output_type=None, backend=None, **inference_kwargs)` | `List[Any]` |
| `stream` | `async (model_input, output_type=None, backend=None, **inference_kwargs)` | `AsyncIterator[Any]` |

#### Abstract Methods (Subclass Responsibility)

| Method | Signature |
|--------|-----------|
| `generate` | `async (model_input, output_type=None, **inference_kwargs)` |
| `generate_batch` | `async (model_input: List, output_type=None, **inference_kwargs)` |
| `generate_stream` | `async (model_input, output_type=None, **inference_kwargs)` |

---

### `ModelTypeAdapter` (Abstract Base Class)

`ModelTypeAdapter` is the abstraction that decouples the *user-facing* input and
output types from the *model-specific* format. Every model must assign an
instance to its `type_adapter` attribute.

It defines two abstract methods:

| Method | Signature | Responsibility |
|--------|-----------|----------------|
| `format_input` | `(model_input: Any) -> Any` | Convert user input into the model's expected format. For API models this typically builds the `messages` argument; for local models it may cast `str` to `list`. Also validates that the input type is supported. |
| `format_output_type` | `(output_type: Optional[Any] = None) -> Any` | Convert the user's output type into the model's expected format. For black-box models this builds a `response_format` argument; for steerable models it formats the logits processor. |

#### Implementation Pattern

Concrete adapters typically use `functools.singledispatchmethod` to dispatch
`format_input` based on the input type. For example, the `OpenAITypeAdapter`
registers handlers for `str`, `list`, and `Chat`:

```python
class OpenAITypeAdapter(ModelTypeAdapter):
    @singledispatchmethod
    def format_input(self, model_input):
        raise TypeError(...)

    @format_input.register(str)
    def format_str_model_input(self, model_input: str) -> list: ...

    @format_input.register(Chat)
    def format_chat_model_input(self, model_input: Chat) -> list: ...

    def format_output_type(self, output_type=None) -> dict: ...
```

This pattern lets each model declare exactly which input types it supports and
raise a clear `TypeError` for unsupported ones.

---

### `Tokenizer` (Protocol)

Defined in `outlines/models/tokenizer.py`, `Tokenizer` is a `Protocol` (and
`Hashable`) that standardizes text encoding/decoding across local models. It is
implemented by `TransformerTokenizer` and `LlamaCppTokenizer`.

#### Attributes

| Attribute | Type | Description |
|-----------|------|-------------|
| `eos_token` | `str` | The end-of-sequence token string. |
| `eos_token_id` | `int` | The end-of-sequence token id. |
| `pad_token_id` | `int` | The padding token id. |
| `vocabulary` | `Dict[str, int]` | Mapping from token strings to ids. |
| `special_tokens` | `Set[str]` | The set of special tokens. |

#### Methods

| Method | Signature | Description |
|--------|-----------|-------------|
| `encode` | `(prompt: Union[str, List[str]]) -> Tuple[NDArray[np.int64], NDArray[np.int64]]` | Translate prompts into arrays of token ids and attention masks. |
| `decode` | `(token_ids: NDArray[np.int64]) -> List[str]` | Translate an array of token ids into a string or list of strings. |
| `convert_token_to_string` | `(token: str) -> str` | Convert a token to its equivalent string (e.g. handle BPE whitespace markers like `Ġ`). |

---

## Component Interaction

The following sequence diagram shows how a user call flows through the base
abstractions. The `Model.__call__` method constructs a `Generator`, which
either builds a logits processor (steerable) or passes the output type through
(black-box), then invokes the model's abstract `generate` method.

```mermaid
sequenceDiagram
    participant User
    participant Model as Model.__call__
    participant Gen as Generator
    participant TA as ModelTypeAdapter
    participant Backend as BaseBackend
    participant Impl as generate() (subclass)

    User->>Model: model(prompt, output_type, backend)
    Model->>Gen: Generator(model, output_type, backend)
    alt Steerable model
        Gen->>Backend: get_*_logits_processor(...)
        Backend-->>Gen: OutlinesLogitsProcessor
    else Black-box model
        Gen-->>Gen: store output_type as-is
    end
    Model->>Gen: __call__(prompt, **kwargs)
    Gen->>Impl: model.generate(prompt, output_type/processor)
    Impl->>TA: format_input(prompt)
    TA-->>Impl: formatted input
    Impl->>TA: format_output_type(output_type)
    TA-->>Impl: formatted output type
    Impl-->>Gen: response
    Gen-->>Model: response
    Model-->>User: response
```

---

## Data Flow: Input and Output Formatting

The `ModelTypeAdapter` is the pivot point for all data transformation. The
diagram below contrasts the two model categories.

```mermaid
flowchart LR
    subgraph User["User-facing types"]
        UIn["str / list / Chat / dict"]
        UOut["Pydantic / JsonSchema / Regex / CFG / None"]
    end

    subgraph Adapter["ModelTypeAdapter"]
        FI["format_input()"]
        FO["format_output_type()"]
    end

    subgraph Steerable["Steerable model"]
        LP["OutlinesLogitsProcessor"]
        Gen["model.generate()"]
    end

    subgraph BlackBox["Black-box model"]
        RF["response_format / messages"]
        Client["client.chat.completions.create()"]
    end

    UIn --> FI
    UOut --> FO
    FI --> Gen
    FI --> Client
    FO -->|steerable| LP
    FO -->|black-box| RF
    LP --> Gen
    RF --> Client
```

---

## Class Hierarchy

```mermaid
classDiagram
    class Model {
        <<abstract>>
        +ModelTypeAdapter type_adapter
        +str tensor_library_name
        +__call__(model_input, output_type, backend, **kwargs)
        +batch(model_input, output_type, backend, **kwargs)
        +stream(model_input, output_type, backend, **kwargs)
        +generate(model_input, output_type, **kwargs)*
        +generate_batch(model_input, output_type, **kwargs)*
        +generate_stream(model_input, output_type, **kwargs)*
    }

    class AsyncModel {
        <<abstract>>
        +ModelTypeAdapter type_adapter
        +str tensor_library_name
        +__call__(model_input, output_type, backend, **kwargs)
        +batch(model_input, output_type, backend, **kwargs)
        +stream(model_input, output_type, backend, **kwargs)
        +generate(model_input, output_type, **kwargs)*
        +generate_batch(model_input, output_type, **kwargs)*
        +generate_stream(model_input, output_type, **kwargs)*
    }

    class ModelTypeAdapter {
        <<abstract>>
        +format_input(model_input)*
        +format_output_type(output_type)*
    }

    class Tokenizer {
        <<protocol>>
        +str eos_token
        +int eos_token_id
        +int pad_token_id
        +Dict vocabulary
        +Set special_tokens
        +encode(prompt)
        +decode(token_ids)
        +convert_token_to_string(token)
    }

    Model --> ModelTypeAdapter : uses
    AsyncModel --> ModelTypeAdapter : uses
```

---

## Design Principles

1. **Uniform interface, heterogeneous backends.** All models expose the same
   `__call__` / `batch` / `stream` API, hiding the differences between local,
   API, and server models.

2. **Separation of concerns via type adapters.** Input/output translation is
   isolated in `ModelTypeAdapter`, keeping model classes focused on inference.

3. **Steerable vs. black-box distinction.** The base classes do not enforce
   constrained generation; instead, the `output_type` semantics differ by model
   category, and the [generator](generator.md) module decides how to handle it.

4. **Lazy generator construction.** `Model.__call__` imports and constructs a
   `Generator` on demand, avoiding circular imports and keeping the base module
   lightweight.

5. **Protocol-based tokenization.** `Tokenizer` uses structural typing
   (`Protocol`), so any object implementing the required attributes and methods
   can be used without explicit inheritance.

---

## Related Modules

| Module | Relationship |
|--------|--------------|
| [generator](generator.md) | Consumes `Model`/`AsyncModel`; builds logits processors for steerable models. |
| [processors](processors.md) | `OutlinesLogitsProcessor` is the `output_type` passed to steerable models. |
| [backends](backends.md) | `BaseBackend` creates logits processors from JSON schema, regex, or CFG. |
| [models_local](models_local.md) | Local model implementations (`Transformers`, `LlamaCpp`, `MLXLM`, `VLLMOffline`). |
| [models_api](models_api.md) | API-based implementations (`OpenAI`, `Anthropic`, `Gemini`, `Dottxt`, `Ollama`). |
| [models_server](models_server.md) | Server-based implementations (`VLLM`, `SGLang`, `TGI`). |
| [types_dsl](types_dsl.md) | Output types (`JsonSchema`, `Regex`, `CFG`, etc.) consumed by type adapters. |
| [inputs](inputs.md) | Input types (`Chat`, `Image`, `Audio`, `Video`) handled by `format_input`. |
