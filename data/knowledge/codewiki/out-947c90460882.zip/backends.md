# Backends

## Introduction

The **backends** module provides the abstraction layer that connects Outlines' structured generation
primitives (JSON schemas, regular expressions, and context-free grammars) to concrete
*constrained-decoding engines*. Each backend knows how to translate a high-level constraint into a
**logits processor** — an object that biases the next-token distribution of a language model so that
only tokens consistent with the constraint can be sampled.

This separation of concerns means that:

- The rest of Outlines (models, generators, types) only needs to talk to a single, stable interface
  (`BaseBackend`).
- New constrained-decoding engines can be plugged in by implementing that interface, without touching
  model or generator code.
- The same constraint (e.g. a JSON schema) can be enforced by different engines depending on which
  one is available or best suited for the model at hand.

The module ships three concrete backends:

| Backend | Engine | Supported models | Constraint types |
| --- | --- | --- | --- |
| [`LLGuidanceBackend`](#llguidance-backend) | [LLGuidance](https://github.com/guidance-ai/llguidance) | Transformers, LlamaCpp, MLXLM | JSON schema, regex, CFG |
| [`OutlinesCoreBackend`](#outlines-core-backend) | [outlines-core](https://github.com/dottxt-ai/outlines-core) | Transformers, LlamaCpp, MLXLM | JSON schema, regex |
| [`XGrammarBackend`](#xgrammar-backend) | [XGrammar](https://github.com/mlc-ai/xgrammar) | Transformers only | JSON schema, regex, CFG |

## Architecture Overview

Every backend follows the same two-part pattern:

1. A **backend** (`BaseBackend` subclass) that is constructed from an Outlines model and exposes three
   factory methods — `get_json_schema_logits_processor`, `get_regex_logits_processor`, and
   `get_cfg_logits_processor`.
2. A **logits processor** (`OutlinesLogitsProcessor` subclass) that performs the actual per-step
   token masking during generation.

```mermaid
graph TD
    subgraph "Outlines core"
        Model["Model<br/>(Transformers, LlamaCpp, MLXLM, ...)"]
        DSL["types/dsl<br/>(JsonSchema, Regex, CFG)"]
        Gen["generator<br/>(SteerableGenerator)"]
    end

    subgraph "backends module"
        Base["BaseBackend<br/>(abstract)"]
        LLG["LLGuidanceBackend"]
        OC["OutlinesCoreBackend"]
        XG["XGrammarBackend"]
    end

    subgraph "processors module"
        OLP["OutlinesLogitsProcessor<br/>(abstract)"]
        TA["TensorAdapter<br/>(torch / numpy / mlx / jax / tf)"]
    end

    DSL --> Gen
    Gen -->|"selects backend"| Base
    Model -->|"constructs"| Base
    Base --> LLG
    Base --> OC
    Base --> XG

    LLG -->|"creates"| OLP
    OC -->|"creates"| OLP
    XG -->|"creates"| OLP
    OLP --> TA
    OLP -->|"biases logits"| Model
```

### The `BaseBackend` contract

`BaseBackend` (in `outlines/backends/base.py`) is an abstract base class that defines the interface
every backend must implement. It declares three abstract factory methods, each returning a
`LogitsProcessorType` (an opaque alias for the engine-specific processor):

```mermaid
classDiagram
    class BaseBackend {
        <<abstract>>
        +get_json_schema_logits_processor(json_schema: str) LogitsProcessorType
        +get_regex_logits_processor(regex: str) LogitsProcessorType
        +get_cfg_logits_processor(grammar: str) LogitsProcessorType
    }
    class LLGuidanceBackend
    class OutlinesCoreBackend
    class XGrammarBackend

    BaseBackend <|-- LLGuidanceBackend
    BaseBackend <|-- OutlinesCoreBackend
    BaseBackend <|-- XGrammarBackend
```

A backend is instantiated with a **steerable model** (a model that exposes a `tensor_library_name`
and a tokenizer). The backend inspects the model type to build the engine-specific tokenizer /
vocabulary it needs, then uses that to compile constraints into logits processors.

### The logits-processor contract

All three backends return processors that subclass
[`OutlinesLogitsProcessor`](processors.md) (from the `processors` module). That base class:

- Standardizes `input_ids` and `logits` to 2D tensors via a library-specific
  [`TensorAdapter`](processors.md) (torch, numpy, mlx, jax, tensorflow).
- Delegates the actual masking to a `process_logits(input_ids, logits)` method implemented by each
  backend's processor.
- Provides a `reset()` hook so a processor can be reused for a new generation.

```mermaid
sequenceDiagram
    participant Gen as Generator
    participant BE as Backend
    participant LP as LogitsProcessor
    participant M as Model

    Gen->>BE: get_json_schema_logits_processor(schema)
    BE->>BE: compile schema into engine grammar
    BE-->>Gen: LogitsProcessor instance
    Gen->>M: generate(prompt, logits_processor=LP)
    loop each decoding step
        M->>LP: __call__(input_ids, logits)
        LP->>LP: process_logits(...)  %% mask invalid tokens
        LP-->>M: biased logits
    end
    M-->>Gen: constrained text
```

## Sub-modules

The backends module is organized into one file per engine. Each is documented in detail below.

### LLGuidance backend

**File:** `outlines/backends/llguidance.py` — see [backends_llguidance.md](backends_llguidance.md)

Wraps the [LLGuidance](https://github.com/guidance-ai/llguidance) library. It supports the widest
range of models (Transformers, LlamaCpp, and MLXLM) and all three constraint types (JSON schema,
regex, and CFG). It builds an `LLGTokenizer` from the model's tokenizer and uses `LLMatcher`
instances plus a token bitmask to bias logits. Tensor-library-specific bias functions are provided
for torch, numpy, and mlx.

### Outlines Core backend

**File:** `outlines/backends/outlines_core.py` — see [backends_outlines_core.md](backends_outlines_core.md)

Wraps the [outlines-core](https://github.com/dottxt-ai/outlines-core) library. It supports
Transformers, LlamaCpp, and MLXLM models for JSON schema and regex constraints (CFG is **not**
supported and raises `NotImplementedError`). It builds an `outlines_core.Vocabulary` from the model
tokenizer and uses `Index`/`Guide` objects with token bitmasks to bias logits.

### XGrammar backend

**File:** `outlines/backends/xgrammar.py` — see [backends_xgrammar.md](backends_xgrammar.md)

Wraps the [XGrammar](https://github.com/mlc-ai/xgrammar) library. It supports **only** Transformers
models (torch tensors) and all three constraint types. It compiles constraints with a
`GrammarCompiler` built from a `TokenizerInfo` and delegates masking to XGrammar's HuggingFace
`LogitsProcessor`.

## Backend selection

The choice of backend is driven by the model and the available dependencies. The table below
summarizes the compatibility matrix that the backends enforce at construction time:

```mermaid
graph LR
    subgraph Models
        T[Transformers]
        L[LlamaCpp]
        M[MLXLM]
    end
    subgraph Backends
        LLG[LLGuidance]
        OC[OutlinesCore]
        XG[XGrammar]
    end
    T --> LLG
    T --> OC
    T --> XG
    L --> LLG
    L --> OC
    M --> LLG
    M --> OC
```

| Constraint | LLGuidance | Outlines Core | XGrammar |
| --- | :---: | :---: | :---: |
| JSON schema | ✅ | ✅ | ✅ |
| Regex | ✅ | ✅ | ✅ |
| CFG | ✅ | ❌ | ✅ |

## Relationship to other modules

- **[models](models.md)** — Backends are constructed from Outlines model wrappers
  (`Transformers`, `LlamaCpp`, `MLXLM`, ...). The model supplies the tokenizer, vocabulary, and
  `tensor_library_name` that the backend needs.
- **[processors](processors.md)** — Every backend returns an `OutlinesLogitsProcessor` subclass.
  The base processor and its `TensorAdapter` implementations handle tensor-shape normalization and
  library-specific operations.
- **[types_dsl](types_dsl.md)** — The high-level constraint types (`JsonSchema`, `Regex`, `CFG`)
  are what ultimately get compiled by a backend into a logits processor.
- **[generator](generator.md)** — The generator orchestrates backend selection and passes the
  resulting logits processor to the model during generation.
