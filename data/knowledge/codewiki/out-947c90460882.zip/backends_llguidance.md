# LLGuidance Backend

## Introduction

The `backends_llguidance` module provides the **LLGuidance backend** for Outlines, enabling constrained text generation by biasing model logits according to a grammar specification. It is one of several interchangeable backends (alongside [Outlines Core](backends_outlines_core.md) and [XGrammar](backends_xgrammar.md)) that implement the common [`BaseBackend`](backends_base.md) interface.

The backend leverages the [`llguidance`](https://github.com/guidance-ai/llguidance) library to compile JSON schemas, regular expressions, and context-free grammars into `LLMatcher` instances. These matchers produce token bitmasks that are applied to the model's logits at each generation step, ensuring the generated output strictly conforms to the requested structure.

The module exposes two core components:

| Component | Responsibility |
|-----------|----------------|
| `LLGuidanceBackend` | Translates high-level constraints (JSON schema, regex, CFG) into logits processors and builds the LLGuidance tokenizer from an Outlines model. |
| `LLGuidanceLogitsProcessor` | Applies the grammar constraints to logits during generation by managing `LLMatcher` instances and token bitmasks. |

---

## Architecture Overview

The LLGuidance backend sits between the Outlines model layer and the `llguidance` library. It is instantiated by the generator when a user requests structured output with `backend="llguidance"`.

```mermaid
graph TD
    User["User / Generator"] -->|"output_type + backend='llguidance'"| Backend["LLGuidanceBackend"]
    Backend -->|"grammar_from(...)"| LLG["llguidance library"]
    Backend -->|"creates"| Tokenizer["LLGTokenizer"]
    Backend -->|"returns"| Processor["LLGuidanceLogitsProcessor"]
    Processor -->|"inherits"| BaseProcessor["OutlinesLogitsProcessor"]
    Processor -->|"uses"| Matchers["LLMatcher instances"]
    Processor -->|"applies bitmask"| Logits["Model Logits"]
    Model["SteerableModel<br/>(Transformers / LlamaCpp / MLXLM)"] -->|"tensor_library_name"| Backend
    Model -->|"tokenizer"| Backend
    Model -->|"calls __call__"| Processor
```

### Component Relationships

```mermaid
classDiagram
    class BaseBackend {
        <<abstract>>
        +get_json_schema_logits_processor(json_schema)
        +get_regex_logits_processor(regex)
        +get_cfg_logits_processor(grammar)
    }
    class LLGuidanceBackend {
        +llg
        +tensor_library_name
        +llg_tokenizer
        +_create_llg_tokenizer(model)
        +get_json_schema_logits_processor(json_schema)
        +get_regex_logits_processor(regex)
        +get_cfg_logits_processor(grammar)
    }
    class OutlinesLogitsProcessor {
        <<abstract>>
        +tensor_adapter
        +reset()
        +process_logits(input_ids, logits)
        +__call__(input_ids, logits)
    }
    class LLGuidanceLogitsProcessor {
        +grammar
        +llg_tokenizer
        +tensor_library_name
        +is_first_token
        +ll_matchers
        +bitmask
        +reset()
        +_setup(batch_size)
        +_bias_logits_torch(...)
        +_bias_logits_numpy(...)
        +_bias_logits_mlx(...)
        +process_logits(input_ids, logits)
    }

    BaseBackend <|-- LLGuidanceBackend
    OutlinesLogitsProcessor <|-- LLGuidanceLogitsProcessor
    LLGuidanceBackend ..> LLGuidanceLogitsProcessor : creates
```

---

## LLGuidanceBackend

The `LLGuidanceBackend` class is the entry point for the module. It is responsible for:

1. **Building an LLGuidance tokenizer** from the Outlines model's tokenizer.
2. **Compiling grammar specifications** into the format expected by `LLMatcher`.
3. **Producing logits processors** for each supported constraint type.

### Initialization

```python
LLGuidanceBackend(model: SteerableModel)
```

The constructor imports the `llguidance` library, reads the `tensor_library_name` from the model, and creates the LLGuidance tokenizer via `_create_llg_tokenizer`.

### Tokenizer Creation

The `_create_llg_tokenizer` method maps the Outlines model type to the appropriate `llguidance` tokenizer factory:

| Outlines Model | LLGuidance Factory | Notes |
|----------------|--------------------|-------|
| [`Transformers`](models_transformers.md) | `llguidance.hf.from_tokenizer` | Uses the HuggingFace tokenizer. |
| [`LlamaCpp`](models_llamacpp.md) | `llguidance.llamacpp.lltokenizer_from_vocab` | Extracts the vocab from the underlying `llama_cpp` model. |
| [`MLXLM`](models_mlxlm.md) | `llguidance.hf.from_tokenizer` | Uses the wrapped `mlx_lm` tokenizer. |

Any other model type raises a `ValueError`, as LLGuidance only supports these three model families.

### Logits Processor Factory Methods

All three factory methods follow the same pattern: they compile a grammar specification using `self.llg.grammar_from(...)` and wrap it in an `LLGuidanceLogitsProcessor`.

```mermaid
flowchart LR
    A["get_json_schema_logits_processor"] -->|"grammar_from('json_schema', ...)"| G["grammar_spec"]
    B["get_regex_logits_processor"] -->|"grammar_from('regex', ...)"| G
    C["get_cfg_logits_processor"] -->|"grammar_from('grammar'/'lark', ...)"| G
    G --> P["LLGuidanceLogitsProcessor"]
```

| Method | Grammar Type | Fallback Behavior |
|--------|--------------|-------------------|
| `get_json_schema_logits_processor(json_schema)` | `json_schema` | None |
| `get_regex_logits_processor(regex)` | `regex` | None |
| `get_cfg_logits_processor(grammar)` | `grammar` | Falls back to `lark` if `grammar` parsing raises `ValueError`. |

> **Note:** The CFG method attempts to parse the grammar as an EBNF-style `grammar` first, and if that fails, retries as a `lark` grammar. This provides flexibility for users who supply either grammar dialect.

---

## LLGuidanceLogitsProcessor

The `LLGuidanceLogitsProcessor` extends [`OutlinesLogitsProcessor`](processors_base_logits_processor.md) and implements the actual logit biasing logic. It is the component that runs during every generation step.

### Supported Tensor Libraries

The processor supports a subset of the tensor libraries handled by the base class:

```python
SUPPORTED_TENSOR_LIBRARIES = ["numpy", "mlx", "torch"]
```

An unsupported library name raises a `TypeError` at construction time.

### Lazy Setup

A key design decision is that the `LLMatcher` instances and token bitmask are **not** created at initialization. Instead, they are created lazily on the first call to `process_logits`, because the batch size is only known at that point.

```mermaid
sequenceDiagram
    participant Model
    participant Processor as LLGuidanceLogitsProcessor
    participant LLG as llguidance

    Model->>Processor: __call__(input_ids, logits)
    Processor->>Processor: process_logits(input_ids, logits)
    alt is_first_token
        Processor->>Processor: _setup(batch_size)
        Processor->>LLG: create LLMatcher per sequence
        Processor->>LLG: allocate_token_bitmask(batch_size, vocab_size)
        Processor->>Processor: is_first_token = False
    else subsequent token
        loop for each sequence in batch
            Processor->>LLG: ll_matchers[i].consume_token(last_token)
            Processor->>Processor: warn if matcher error
        end
    end
    Processor->>Processor: _bias_logits(input_ids, logits)
    Processor-->>Model: biased logits
```

### The `_setup` Method

`_setup(batch_size)` performs the following:

1. Creates one `LLMatcher` per sequence in the batch, each initialized with the grammar and the LLGuidance tokenizer.
2. Allocates a token bitmask sized `(batch_size, vocab_size)` using the library-specific allocator.
3. Selects the appropriate `_bias_logits_*` implementation based on `tensor_library_name`.

### The `process_logits` Method

This is the core method invoked at each generation step:

- **First token:** Calls `_setup` to initialize matchers and bitmask. The matchers do **not** consume any token yet, since no tokens have been generated.
- **Subsequent tokens:** For each sequence in the batch, the last generated token is consumed by the corresponding `LLMatcher`. If the matcher reports an error (e.g., the token violates the grammar), a warning is emitted.
- Finally, the selected `_bias_logits` function applies the bitmask to the logits.

### Tensor-Library-Specific Biasing

The processor dispatches to one of three implementations, each using the corresponding `llguidance` submodule:

| Method | Library | Strategy |
|--------|---------|----------|
| `_bias_logits_torch` | `torch` | Fills the bitmask and applies it **in place** via `apply_token_bitmask_inplace`. |
| `_bias_logits_numpy` | `numpy` | Fills the bitmask and applies it **in place** via `apply_token_bitmask_inplace`. |
| `_bias_logits_mlx` | `mlx` | Fills the bitmask, applies it per-sequence via `apply_token_bitmask`, and concatenates the results. |

All three iterate over the batch dimension, calling `fill_next_token_bitmask` for each matcher before applying the mask.

### Reset Behavior

The `reset` method sets `is_first_token = True`, ensuring that `_setup` is called again for the next generation. This is important because logits processors are reused across generations but must reinitialize their matchers and bitmask for each new sequence.

---

## Data Flow

The following diagram illustrates the end-to-end flow from a user request to constrained generation.

```mermaid
flowchart TD
    A["User: model(prompt, JsonSchema, backend='llguidance')"] --> B["Generator creates LLGuidanceBackend"]
    B --> C["Backend builds LLGTokenizer from model"]
    C --> D["Backend.get_json_schema_logits_processor(schema)"]
    D --> E["llg.grammar_from('json_schema', schema)"]
    E --> F["LLGuidanceLogitsProcessor(grammar_spec, tokenizer, lib)"]
    F --> G["Model.generate(logits_processor=...)"]
    G --> H{"First token?"}
    H -->|Yes| I["_setup: create LLMatchers + bitmask"]
    H -->|No| J["consume_token(last_token) per sequence"]
    I --> K["_bias_logits: apply bitmask"]
    J --> K
    K --> L["Return biased logits"]
    L --> M["Model samples next token"]
    M --> H
```

---

## Integration with the Outlines Ecosystem

The LLGuidance backend integrates with several other modules:

- **[Base Backend](backends_base.md):** `LLGuidanceBackend` implements the abstract `BaseBackend` interface, making it interchangeable with other backends.
- **[Base Logits Processor](processors_base_logits_processor.md):** `LLGuidanceLogitsProcessor` extends `OutlinesLogitsProcessor`, inheriting the standardized `__call__` entrypoint and the `tensor_adapter` mechanism.
- **[Tensor Adapters](processors_tensor_adapters.md):** The processor uses the `tensor_adapter` to inspect shapes and manipulate tensors in a library-agnostic way.
- **[Models](models_base.md):** The backend requires a `SteerableModel` (e.g., [`Transformers`](models_transformers.md), [`LlamaCpp`](models_llamacpp.md), [`MLXLM`](models_mlxlm.md)) to obtain the tokenizer and tensor library name.
- **[Generator](generator.md):** The generator selects the backend by name and wires the produced logits processor into the model's generation call.

### Backend Comparison

| Feature | LLGuidance | [Outlines Core](backends_outlines_core.md) | [XGrammar](backends_xgrammar.md) |
|---------|-----------|-------------------------------------------|----------------------------------|
| JSON Schema | ✅ | ✅ | ✅ |
| Regex | ✅ | ✅ | ✅ |
| CFG | ✅ (EBNF + Lark) | ✅ | ✅ |
| Supported tensor libs | numpy, mlx, torch | (see module) | (see module) |
| Supported models | Transformers, LlamaCpp, MLXLM | (see module) | (see module) |

---

## Key Design Considerations

1. **Lazy initialization:** Matchers and bitmasks are created on the first generation step to accommodate unknown batch sizes.
2. **Per-sequence matchers:** Each sequence in a batch gets its own `LLMatcher`, enabling correct batched constrained generation.
3. **In-place vs. out-of-place biasing:** Torch and NumPy use in-place bitmask application for efficiency, while MLX builds a new concatenated tensor.
4. **Error surfacing:** Grammar violations detected by `LLMatcher.get_error()` are surfaced as warnings rather than hard failures, allowing generation to continue.
5. **Grammar dialect flexibility:** The CFG factory transparently falls back from EBNF to Lark syntax.
