# Logits Processor Module

## Introduction

The `processors_logits_processor` module provides the foundational abstraction for **logits processors** in Outlines. A logits processor is a callable that intercepts the raw logits produced by a language model at each generation step and *biases* them — typically by masking out tokens that would violate a structured constraint (a JSON schema, a regular expression, or a context-free grammar).

The central component of this module is the abstract base class [`OutlinesLogitsProcessor`](#outlineslogitsprocessor), which defines a **library-agnostic** interface for logits processing. It decouples the *logic* of constraining generation from the *tensor library* (PyTorch, NumPy, MLX, JAX, TensorFlow) used by the underlying model, by delegating all tensor manipulation to a pluggable [`TensorAdapter`](processors_tensor_adapters.md).

This module sits at the boundary between the model layer and the structured-generation backends:

- **Upstream**, concrete backends (Outlines Core, XGrammar, LLGuidance) subclass `OutlinesLogitsProcessor` to implement the actual constraint logic.
- **Downstream**, models call the processor's `__call__` method during sampling.
- **Sideways**, the processor relies on the tensor adapter layer to normalize tensor shapes and operations across libraries.

---

## Architecture Overview

The module is intentionally small: it exposes a single abstract base class whose responsibility is to **standardize the interface and tensor shapes** so that concrete processors only need to implement the constraint-specific logic.

```mermaid
graph TD
    subgraph "Model Layer"
        M[Model / SteerableGenerator]
    end

    subgraph "processors_logits_processor"
        BLP[OutlinesLogitsProcessor<br/>abstract base]
    end

    subgraph "Concrete Backends"
        OCLP[OutlinesCoreLogitsProcessor]
        XGLP[XGrammarLogitsProcessor]
        LLGLP[LLGuidanceLogitsProcessor]
    end

    subgraph "processors_tensor_adapters"
        TA[TensorAdapter<br/>abstract base]
        TORCH[TorchTensorAdapter]
        NUMPY[NumpyTensorAdapter]
        MLX[MLXTensorAdapter]
        JAX[JAXTensorAdapter]
        TF[TensorFlowTensorAdapter]
    end

    M -->|calls __call__| BLP
    OCLP -->|inherits| BLP
    XGLP -->|inherits| BLP
    LLGLP -->|inherits| BLP
    BLP -->|delegates tensor ops| TA
    TA --> TORCH
    TA --> NUMPY
    TA --> MLX
    TA --> JAX
    TA --> TF
```

---

## Core Component: `OutlinesLogitsProcessor`

`OutlinesLogitsProcessor` is the abstract base class for all logits processors. It implements a shared `__call__` entrypoint (invoked by models) and delegates the actual constraint logic to the abstract `process_logits` method that subclasses must implement.

### Responsibilities

| Responsibility | Where it lives |
| --- | --- |
| Select and instantiate the correct tensor adapter | `__init__` |
| Normalize `input_ids` / `logits` to 2D tensors | `__call__` |
| Restore the original tensor dimensionality | `__call__` |
| Apply constraint-specific masking | `process_logits` (abstract) |
| Reset state between generations | `reset` (overridable) |

### Class Diagram

```mermaid
classDiagram
    class OutlinesLogitsProcessor {
        +TensorAdapter tensor_adapter
        +__init__(tensor_library_name: str)
        +reset()
        +process_logits(input_ids, logits)* TensorType
        +__call__(input_ids, logits) TensorType
    }

    class OutlinesCoreLogitsProcessor {
        +Index index
        +bool is_first_token
        +reset()
        +_setup(batch_size, vocab_size)
        +process_logits(input_ids, logits)
    }

    class XGrammarLogitsProcessor {
        +compiled_grammar
        +reset()
        +process_logits(input_ids, logits)
    }

    class LLGuidanceLogitsProcessor {
        +str grammar
        +llg_tokenizer
        +bool is_first_token
        +reset()
        +_setup(batch_size)
        +process_logits(input_ids, logits)
    }

    OutlinesLogitsProcessor <|-- OutlinesCoreLogitsProcessor
    OutlinesLogitsProcessor <|-- XGrammarLogitsProcessor
    OutlinesLogitsProcessor <|-- LLGuidanceLogitsProcessor
```

### Initialization

The constructor accepts a single argument, `tensor_library_name`, which selects the tensor adapter used for all subsequent tensor operations:

```python
def __init__(self, tensor_library_name: str):
    ...
    tensor_adapter_class = tensor_adapters.get(tensor_library_name)
    if tensor_adapter_class is None:
        raise NotImplementedError(f"Library {tensor_library_name} is not available")
    self.tensor_adapter = tensor_adapter_class()
```

Supported values are `"jax"`, `"mlx"`, `"numpy"`, `"tensorflow"`, and `"torch"`. The library name **must match the library used by the model** — the processor will manipulate the model's native tensors directly.

> **Note:** When `tensor_library_name == "torch"`, the constructor sets `torch._dynamo.config.suppress_errors = True` as a workaround for a warning that can escalate to an error under Python 3.12.

### The `__call__` Entrypoint

`__call__` is the method invoked by models during generation. Its job is to **normalize tensor shapes** so that `process_logits` can always assume 2D inputs, then restore the original shape afterward.

```mermaid
flowchart TD
    A[Model calls __call__<br/>input_ids, logits] --> B{input_ids 1D AND<br/>logits 2D with batch=1?}
    B -->|Yes| C[unsqueeze input_ids to 2D]
    B -->|No| D[continue]
    C --> D
    D --> E{logits is 2D?}
    E -->|Yes| F[process_logits input_ids, logits]
    E -->|No, 1D| G[unsqueeze both to 2D<br/>process_logits<br/>squeeze result back to 1D]
    E -->|Other| H[raise ValueError]
    F --> I[return processed_logits]
    G --> I
    H --> I
```

Key behaviors:

1. **MLX-LM compatibility:** If `input_ids` is 1D but `logits` is 2D with a single sequence, `input_ids` is unsqueezed to 2D.
2. **Shape assertion:** The leading dimensions of `logits` and `input_ids` must match (excluding the vocabulary dimension).
3. **Shape restoration:** 1D logits are temporarily promoted to 2D, processed, then squeezed back to 1D.

### The `process_logits` Contract

Subclasses implement `process_logits(input_ids, logits) -> logits`, which receives **2D tensors** and returns **2D tensors**. The docstring documents several important design considerations for universal processors:

- Logits processors are used **once** and never re-applied for a new sequence generator.
- Some models pass only `output_ids`; others (llamacpp, transformers) prefix with `input_ids`.
- Some sampling methods (e.g., beam search) produce **unstable sequence ordering** in models like vLLM.

### The `reset` Method

`reset()` is a no-op by default. Subclasses override it when the processor holds per-generation state (e.g., a partially-consumed grammar matcher) that must be cleared before a new generation begins.

---

## Concrete Implementations

The base class is subclassed by each structured-generation backend. Each subclass supplies its own constraint engine while reusing the shape-normalization and tensor-adapter machinery.

### `OutlinesCoreLogitsProcessor`

Wraps the [Outlines Core](backends_outlines_core.md) `Index`/`Guide` API. It lazily sets up per-sequence guides and bitmasks on the **first token** (because the batch size is unknown at construction time), then advances each guide with the last generated token on subsequent steps.

```mermaid
sequenceDiagram
    participant Model
    participant P as OutlinesCoreLogitsProcessor
    participant G as Guide (per sequence)

    Model->>P: __call__(input_ids, logits)
    P->>P: process_logits(...)
    alt first token
        P->>P: _setup(batch_size, vocab_size)
        P->>G: create Guide per sequence
    else subsequent token
        P->>G: advance(last_token_id)
    end
    P->>P: bias_logits(batch_size, logits)
    P-->>Model: biased logits
```

- Supports `torch`, `numpy`, and `mlx` tensor libraries (via `outlines_core.kernels.*`).
- Does **not** support context-free grammars (the backend raises `NotImplementedError`).

### `XGrammarLogitsProcessor`

A thin wrapper around `xgrammar.contrib.hf.LogitsProcessor`. It is **torch-only** (the base constructor is called with `"torch"`) and lazily instantiates the underlying processor on the first `process_logits` call. `reset()` clears the wrapped processor so a fresh one is created for the next generation.

### `LLGuidanceLogitsProcessor`

Wraps the [LLGuidance](backends_llguidance.md) `LLMatcher` API. Like the Outlines Core processor, it performs lazy `_setup` on the first token to create one `LLMatcher` per sequence and allocate a bitmask. On subsequent steps it consumes the last token into each matcher and warns if the matcher reports an error.

- Supports `torch`, `numpy`, and `mlx` tensor libraries.
- Validates the tensor library at construction time against `SUPPORTED_TENSOR_LIBRARIES`.

---

## Tensor Adapter Integration

All tensor manipulation in `OutlinesLogitsProcessor` is routed through the `tensor_adapter` attribute, an instance of a [`TensorAdapter`](processors_tensor_adapters.md) subclass. This is the mechanism that makes the base class library-agnostic.

```mermaid
graph LR
    BLP[OutlinesLogitsProcessor] -->|shape, unsqueeze, squeeze| TA[TensorAdapter]
    BLP -->|to_scalar, to_list| TA
    BLP -->|full_like, concatenate| TA
    BLP -->|apply_mask, boolean_ones_like| TA
    BLP -->|argsort_descending| TA
    BLP -->|get_device, to_device| TA
```

The adapter interface (defined in [`processors_tensor_adapters`](processors_tensor_adapters.md)) provides a uniform set of operations — `shape`, `unsqueeze`, `squeeze`, `to_list`, `to_scalar`, `full_like`, `concatenate`, `get_device`, `to_device`, `boolean_ones_like`, `apply_mask`, and `argsort_descending` — each implemented per library. For example:

| Operation | Torch | NumPy |
| --- | --- | --- |
| `unsqueeze` | `tensor.unsqueeze(0)` | `numpy.expand_dims(tensor, axis=0)` |
| `concatenate` | `torch.cat(tensors, dim=0)` | `numpy.concatenate(tensors, axis=0)` |
| `apply_mask` | `torch.masked_fill(...)` | `result[mask] = value` |
| `argsort_descending` | `torch.argsort(tensor, descending=True)` | `numpy.argsort(-tensor)` |

> **Important:** `full_like` and `concatenate` must be able to handle **torch tensors** regardless of the active library, because Outlines Core currently emits torch tensors. See the `TensorAdapter` docstring for details.

---

## Data Flow

The following diagram shows how a single generation step flows from the model through the processor and back.

```mermaid
sequenceDiagram
    participant Model
    participant LP as OutlinesLogitsProcessor
    participant TA as TensorAdapter
    participant Sub as process_logits (subclass)

    Model->>LP: __call__(input_ids, logits)
    LP->>TA: shape(input_ids), shape(logits)
    LP->>LP: normalize to 2D
    LP->>Sub: process_logits(input_ids_2d, logits_2d)
    Sub->>TA: tensor operations (mask, bias, ...)
    TA-->>Sub: processed tensors
    Sub-->>LP: processed_logits_2d
    LP->>TA: squeeze (if original was 1D)
    LP-->>Model: processed_logits
```

---

## Relationship to Other Modules

| Module | Relationship |
| --- | --- |
| [`processors_tensor_adapters`](processors_tensor_adapters.md) | Provides the `TensorAdapter` implementations used by `OutlinesLogitsProcessor` to manipulate tensors across libraries. |
| [`backends_outlines_core`](backends_outlines_core.md) | Defines `OutlinesCoreLogitsProcessor` and `OutlinesCoreBackend`, which produce processors from JSON schemas / regexes. |
| [`backends_xgrammar`](backends_xgrammar.md) | Defines `XGrammarLogitsProcessor` and `XGrammarBackend`. |
| [`backends_llguidance`](backends_llguidance.md) | Defines `LLGuidanceLogitsProcessor` and `LLGuidanceBackend`. |
| [`backends_base`](backends_base.md) | Defines `BaseBackend`, the abstract factory that creates logits processors from schemas, regexes, and grammars. |
| [`models_base`](models_base.md) | Models invoke the processor's `__call__` during generation and expose `tensor_library_name`. |
| [`types_dsl`](types_dsl.md) | The structured types (JSON schema, regex, CFG) that ultimately drive the constraints applied by processors. |

---

## Design Principles

1. **Library agnosticism.** The base class never imports a tensor library directly; all operations go through the adapter.
2. **Shape normalization.** `__call__` guarantees `process_logits` always sees 2D tensors, simplifying subclass logic.
3. **Lazy setup.** Processors that need the batch size (Outlines Core, LLGuidance) defer setup to the first token.
4. **Single-use semantics.** Processors are designed to be used once per generation; `reset()` exists for reuse across generations.
5. **Backend isolation.** Each backend owns its constraint engine; the base class only standardizes the interface.
