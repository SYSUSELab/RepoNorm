# Generator Module

## Introduction

The `generator` module (`outlines/generator.py`) is the central orchestration layer of Outlines. It encapsulates a **model** and an **output type** into a single, reusable object that can be called to produce constrained or unconstrained generations.

Its primary responsibilities are:

1. **Bridging models and output types** — pairing an Outlines model with a desired output type (JSON schema, regex, CFG, Python type, etc.).
2. **Compiling output types into logits processors** — for *steerable* models, the output type is compiled into a logits processor via a backend, which is then applied during generation.
3. **Passing output types through** — for *black-box* models, the output type is forwarded directly to the model without local compilation.
4. **Providing a uniform interface** — exposing `__call__`, `batch`, and `stream` methods across all model kinds.

The module exposes three generator classes plus a factory function:

| Component | Purpose |
|-----------|---------|
| `SteerableGenerator` | For models where Outlines controls constrained generation (local models). Builds and stores a logits processor. |
| `BlackBoxGenerator` | Synchronous generator for models where constrained generation is handled by the provider (e.g. OpenAI, Anthropic). |
| `AsyncBlackBoxGenerator` | Asynchronous variant of `BlackBoxGenerator`. |
| `Generator(...)` | Factory function that inspects the model type and returns the appropriate generator. |

---

## Architecture Overview

The generator sits between the **models** layer and the **backends** / **processors** layers. It is the glue that turns a declarative output type into a runtime constraint.

```mermaid
graph TD
    User["User code"] -->|"Generator(model, output_type)"| Factory["Generator() factory"]
    Factory -->|"SteerableModel"| SG["SteerableGenerator"]
    Factory -->|"BlackBoxModel"| BBG["BlackBoxGenerator"]
    Factory -->|"AsyncBlackBoxModel"| ABBG["AsyncBlackBoxGenerator"]

    SG -->|"python_types_to_terms / to_regex"| DSL["outlines.types.dsl"]
    SG -->|"get_*_logits_processor"| Backends["outlines.backends"]
    Backends -->|"builds"| LP["LogitsProcessorType"]
    SG -->|"stores & passes"| LP
    SG -->|"generate(prompt, logits_processor)"| Model["SteerableModel"]
    BBG -->|"generate(prompt, output_type)"| BBModel["BlackBoxModel"]
    ABBG -->|"generate(prompt, output_type)"| ABBModel["AsyncBlackBoxModel"]

    LP -->|"applied during decoding"| Model
```

### Key design principle: two generation paradigms

Outlines distinguishes between two fundamentally different ways of constraining generation:

- **Steerable models** (local models such as `Transformers`, `LlamaCpp`, `VLLM`, `MLXLM`): Outlines has direct access to the logits and can apply a **logits processor** at each decoding step. The output type is compiled locally into a processor.
- **Black-box models** (remote APIs such as `OpenAI`, `Anthropic`, `Gemini`): Outlines cannot touch the logits. The output type is passed to the provider, which is responsible for enforcing it.

The `Generator` factory transparently selects the correct generator class based on the model instance.

---

## Component Details

### `Generator` (factory function)

The entry point for creating generators. It validates arguments and dispatches to the correct generator class.

```python
def Generator(
    model: Union[Model, AsyncModel],
    output_type: Optional[Any] = None,
    backend: Optional[str] = None,
    *,
    processor: Optional[LogitsProcessorType] = None,
) -> Union[SteerableGenerator, BlackBoxGenerator, AsyncBlackBoxGenerator]:
```

**Parameters:**

| Parameter | Description |
|-----------|-------------|
| `model` | An instance of an Outlines model (`SteerableModel`, `BlackBoxModel`, or `AsyncBlackBoxModel`). |
| `output_type` | The output type expressed as a Python type or a DSL type from `outlines.types.dsl`. |
| `backend` | Name of the backend used to build the logits processor. Only used for steerable models when `output_type` is provided. |
| `processor` | A pre-built logits processor. Mutually exclusive with `output_type`. Intended for advanced users. |

**Validation rules:**

- `output_type` and `processor` are **mutually exclusive** — providing both raises `ValueError`.
- `processor` is only supported for `SteerableModel` instances; passing it with a black-box model raises `NotImplementedError`.
- An unrecognized model type raises `ValueError`.

**Dispatch logic:**

```mermaid
flowchart TD
    Start["Generator(model, output_type, backend, processor)"] --> Check["Count provided output params"]
    Check -->|"> 1"| Err1["ValueError: at most one of output_type or processor"]
    Check -->|"<= 1"| IsSteer{"isinstance(model, SteerableModel)?"}
    IsSteer -->|"Yes"| HasProc{"processor provided?"}
    HasProc -->|"Yes"| FromProc["SteerableGenerator.from_processor(model, processor)"]
    HasProc -->|"No"| NewSG["SteerableGenerator(model, output_type, backend)"]
    IsSteer -->|"No"| HasProc2{"processor provided?"}
    HasProc2 -->|"Yes"| Err2["NotImplementedError: model does not support logits processors"]
    HasProc2 -->|"No"| IsAsync{"isinstance(model, AsyncBlackBoxModel)?"}
    IsAsync -->|"Yes"| ABBG["AsyncBlackBoxGenerator(model, output_type)"]
    IsAsync -->|"No"| IsBB{"isinstance(model, BlackBoxModel)?"}
    IsBB -->|"Yes"| BBG["BlackBoxGenerator(model, output_type)"]
    IsBB -->|"No"| Err3["ValueError: invalid model type"]
```

> **Note:** The `Generator` factory is also invoked implicitly by the `__call__`, `batch`, and `stream` convenience methods on the model base classes. See [models.md](models.md) for details.

---

### `SteerableGenerator`

Represents a generator for which Outlines **controls constrained generation**. It is responsible for building and storing the logits processor (which can be expensive to construct) and passing it to the model at call time.

**Attributes:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `model` | `SteerableModel` | The underlying model. |
| `logits_processor` | `Optional[LogitsProcessorType]` | The compiled logits processor, or `None` for unconstrained generation. |

#### Construction paths

There are two mutually exclusive ways to create a `SteerableGenerator`:

**1. Via `__init__` (from an output type):**

```python
SteerableGenerator(model, output_type, backend_name=None)
```

The output type is first normalized into a DSL `Term` using `python_types_to_terms`, then compiled based on its kind:

```mermaid
flowchart TD
    OT["output_type"] --> None{"is None?"}
    None -->|"Yes"| NoLP["logits_processor = None"]
    None -->|"No"| PTT["python_types_to_terms(output_type)"]
    PTT --> IsCFG{"isinstance(term, CFG)?"}
    IsCFG -->|"Yes"| CFG["get_cfg_logits_processor(backend, model, term.definition)"]
    IsCFG -->|"No"| IsJSON{"isinstance(term, JsonSchema)?"}
    IsJSON -->|"Yes"| JSON["get_json_schema_logits_processor(backend, model, term.schema)"]
    IsJSON -->|"No"| Regex["to_regex(term) → get_regex_logits_processor(backend, model, regex)"]
```

**2. Via `from_processor` (from a pre-built processor):**

```python
SteerableGenerator.from_processor(model, processor)
```

This classmethod bypasses compilation entirely and stores the provided processor directly. It is intended for advanced users who want to reuse a processor or build one manually.

#### Methods

| Method | Signature | Description |
|--------|-----------|-------------|
| `__call__` | `(prompt, **inference_kwargs) -> Any` | Resets the logits processor (if any) and generates a single response. |
| `batch` | `(prompts, **inference_kwargs) -> List[Any]` | Resets the processor and generates a batch of responses. |
| `stream` | `(prompt, **inference_kwargs) -> Iterator[Any]` | Resets the processor and streams responses. |

> **Important:** Every call resets the logits processor via `self.logits_processor.reset()` before delegating to the model. This ensures the processor starts from a clean state for each new generation. See [processors.md](processors.md) for the `reset` contract.

---

### `BlackBoxGenerator`

A **synchronous** generator for models where Outlines does **not** control constrained generation. The output type is passed directly to the model rather than being compiled into a logits processor.

**Attributes:**

| Attribute | Type | Description |
|-----------|------|-------------|
| `model` | `BlackBoxModel` | The underlying model. |
| `output_type` | `Optional[Any]` | The output type forwarded to the model. |

**Methods:**

| Method | Signature | Description |
|--------|-----------|-------------|
| `__call__` | `(prompt, **inference_kwargs) -> Any` | Calls `model.generate(prompt, output_type, ...)`. |
| `batch` | `(prompts, **inference_kwargs) -> List[Any]` | Calls `model.generate_batch(prompts, output_type, ...)`. |
| `stream` | `(prompt, **inference_kwargs) -> Iterator[Any]` | Calls `model.generate_stream(prompt, output_type, ...)`. |

---

### `AsyncBlackBoxGenerator`

The **asynchronous** counterpart to `BlackBoxGenerator`. It mirrors the same interface but uses `async`/`await` and returns an `AsyncIterator` from `stream`.

**Methods:**

| Method | Signature | Description |
|--------|-----------|-------------|
| `__call__` | `async (prompt, **inference_kwargs) -> Any` | Awaits `model.generate(prompt, output_type, ...)`. |
| `batch` | `async (prompts, **inference_kwargs) -> List[Any]` | Awaits `model.generate_batch(prompts, output_type, ...)`. |
| `stream` | `async (prompt, **inference_kwargs) -> AsyncIterator[Any]` | Async-iterates over `model.generate_stream(prompt, output_type, ...)`. |

---

## Data Flow

The following diagram shows the end-to-end flow for a steerable model with a structured output type (e.g. a Pydantic model):

```mermaid
sequenceDiagram
    participant U as User
    participant G as Generator factory
    participant SG as SteerableGenerator
    participant DSL as types.dsl
    participant B as Backend
    participant LP as LogitsProcessor
    participant M as SteerableModel

    U->>G: Generator(model, MyPydanticModel)
    G->>SG: SteerableGenerator(model, MyPydanticModel)
    SG->>DSL: python_types_to_terms(MyPydanticModel)
    DSL-->>SG: JsonSchema(term)
    SG->>B: get_json_schema_logits_processor(backend, model, schema)
    B->>LP: build processor
    LP-->>SG: logits_processor
    U->>SG: generator("prompt")
    SG->>LP: reset()
    SG->>M: generate("prompt", logits_processor)
    M-->>U: constrained response
```

For a black-box model, the flow is simpler — no compilation occurs:

```mermaid
sequenceDiagram
    participant U as User
    participant G as Generator factory
    participant BBG as BlackBoxGenerator
    participant M as BlackBoxModel

    U->>G: Generator(model, MyPydanticModel)
    G->>BBG: BlackBoxGenerator(model, MyPydanticModel)
    U->>BBG: generator("prompt")
    BBG->>M: generate("prompt", MyPydanticModel)
    M-->>U: response
```

---

## Dependencies

The generator module depends on several other modules. Each is documented separately to avoid duplication:

```mermaid
graph LR
    Gen["generator.py"] --> Models["models.md<br/>(SteerableModel, BlackBoxModel, AsyncBlackBoxModel)"]
    Gen --> Backends["backends.md<br/>(get_*_logits_processor)"]
    Gen --> Types["types_dsl.md<br/>(CFG, JsonSchema, python_types_to_terms, to_regex)"]
    Gen --> Processors["processors.md<br/>(LogitsProcessorType, OutlinesLogitsProcessor)"]
```

| Dependency | What the generator uses |
|------------|-------------------------|
| [models.md](models.md) | `SteerableModel`, `BlackBoxModel`, `AsyncBlackBoxModel`, `Model`, `AsyncModel` — the model abstractions the generator wraps. |
| [backends.md](backends.md) | `get_cfg_logits_processor`, `get_json_schema_logits_processor`, `get_regex_logits_processor` — compile output types into logits processors. |
| [types_dsl.md](types_dsl.md) | `CFG`, `JsonSchema`, `python_types_to_terms`, `to_regex` — normalize and classify output types. |
| [processors.md](processors.md) | `LogitsProcessorType`, `OutlinesLogitsProcessor` — the processor interface applied during decoding. |

---

## Component Interaction Summary

```mermaid
classDiagram
    class Generator {
        <<factory>>
        +Generator(model, output_type, backend, processor)
    }
    class SteerableGenerator {
        +model: SteerableModel
        +logits_processor: Optional~LogitsProcessorType~
        +__init__(model, output_type, backend_name)
        +from_processor(model, processor)$
        +__call__(prompt, **kwargs)
        +batch(prompts, **kwargs)
        +stream(prompt, **kwargs)
    }
    class BlackBoxGenerator {
        +model: BlackBoxModel
        +output_type: Optional~Any~
        +__call__(prompt, **kwargs)
        +batch(prompts, **kwargs)
        +stream(prompt, **kwargs)
    }
    class AsyncBlackBoxGenerator {
        +model: AsyncBlackBoxModel
        +output_type: Optional~Any~
        +__call__(prompt, **kwargs)
        +batch(prompts, **kwargs)
        +stream(prompt, **kwargs)
    }

    Generator ..> SteerableGenerator : creates
    Generator ..> BlackBoxGenerator : creates
    Generator ..> AsyncBlackBoxGenerator : creates
```

---

## Usage Examples

### Steerable model with a structured output type

```python
from pydantic import BaseModel
from outlines import Generator

class Character(BaseModel):
    name: str
    age: int

generator = Generator(model, Character)
result = generator("Generate a character.")
```

### Steerable model with a pre-built processor

```python
from outlines import Generator

generator = Generator(model, processor=my_logits_processor)
result = generator("prompt")
```

### Black-box model

```python
from outlines import Generator

generator = Generator(openai_model, Character)
result = generator("Generate a character.")
```

### Async black-box model

```python
from outlines import Generator

generator = Generator(async_model, Character)
result = await generator("Generate a character.")
```

---

## Error Handling Reference

| Condition | Exception | Message |
|-----------|-----------|---------|
| Both `output_type` and `processor` provided | `ValueError` | "At most one of output_type or processor can be provided" |
| `processor` provided with a non-steerable model | `NotImplementedError` | "This model does not support logits processors" |
| Model is not a recognized Outlines model type | `ValueError` | "The model argument must be an instance of SteerableModel, BlackBoxModel or AsyncBlackBoxModel" |

---

## Related Documentation

- [models.md](models.md) — Model abstractions and their `generate`/`generate_batch`/`generate_stream` contracts.
- [backends.md](backends.md) — Backend implementations that compile output types into logits processors.
- [processors.md](processors.md) — Logits processor base classes and tensor adapters.
- [types_dsl.md](types_dsl.md) — The DSL used to express output types.
- [applications.md](applications.md) — Higher-level applications built on top of generators.
