# XGrammar Backend

## Introduction

The `backends_xgrammar` module provides the **XGrammar backend** for Outlines, enabling
constrained text generation by biasing the logits of a `transformers` model according to a
grammar specification. It is one of several interchangeable backends (alongside
[LLGuidance](backends_llguidance.md) and [Outlines Core](backends_outlines_core.md)) that
implement the common [`BaseBackend`](backends_base.md) interface.

The backend compiles a user-supplied constraint — a JSON schema, a regular expression, or a
context-free grammar — into a compiled grammar using the `xgrammar` library, then wraps it in
a logits processor that masks invalid tokens at each generation step.

> **Key constraint:** The XGrammar backend **only supports `Transformers` models**. Unlike
> LLGuidance and Outlines Core, it does not support `LlamaCpp` or `MLXLM` models.

---

## Module Structure

The module is defined in a single file, `outlines/backends/xgrammar.py`, and exposes two
public classes:

| Component | Role |
|-----------|------|
| `XGrammarBackend` | Compiles constraints into grammars and produces logits processors. |
| `XGrammarLogitsProcessor` | Wraps `xgrammar.contrib.hf.LogitsProcessor` to bias logits during generation. |

---

## Architecture

The XGrammar backend follows the standard Outlines backend pattern: a `BaseBackend`
subclass that produces `OutlinesLogitsProcessor` instances, which are then consumed by a
model's generation loop.

```mermaid
classDiagram
    class BaseBackend {
        <<abstract>>
        +get_json_schema_logits_processor(json_schema)
        +get_regex_logits_processor(regex)
        +get_cfg_logits_processor(grammar)
    }
    class XGrammarBackend {
        +grammar_compiler
        +__init__(model: SteerableModel)
        +get_json_schema_logits_processor(json_schema)
        +get_regex_logits_processor(regex)
        +get_cfg_logits_processor(grammar)
    }
    class OutlinesLogitsProcessor {
        <<abstract>>
        +tensor_adapter
        +reset()
        +process_logits(input_ids, logits)
        +__call__(input_ids, logits)
    }
    class XGrammarLogitsProcessor {
        +compiled_grammar
        +xgrammar_logits_processor
        +reset()
        +process_logits(input_ids, logits)
    }

    BaseBackend <|-- XGrammarBackend
    OutlinesLogitsProcessor <|-- XGrammarLogitsProcessor
    XGrammarBackend ..> XGrammarLogitsProcessor : creates
```

### Component Relationships

```mermaid
graph TD
    User[User / Outlines API] -->|constraint| XGB[XGrammarBackend]
    XGB -->|compile_json_schema / compile_regex / compile_grammar| GC[xgrammar.GrammarCompiler]
    GC -->|compiled_grammar| XGB
    XGB -->|creates| XGLP[XGrammarLogitsProcessor]
    XGLP -->|wraps| XGRLP[xgrammar.contrib.hf.LogitsProcessor]
    Model[Transformers model] -->|input_ids, logits| XGLP
    XGLP -->|biased logits| Model
```

---

## Core Components

### `XGrammarBackend`

The backend is responsible for initializing the XGrammar tokenizer information and grammar
compiler, and for producing logits processors from the three supported constraint types.

**Initialization** (`__init__(model: SteerableModel)`):

1. Imports `xgrammar` and `transformers.AutoConfig`.
2. Validates that `model` is a [`Transformers`](models_transformers.md) instance; otherwise
   raises `ValueError`.
3. Reads the model's `vocab_size` from its Hugging Face config
   (`model.model.config._name_or_path`).
4. Builds an `xgr.TokenizerInfo` from the Hugging Face tokenizer via
   `xgr.TokenizerInfo.from_huggingface(...)`.
5. Stores an `xgr.GrammarCompiler` instance in `self.grammar_compiler`.

**Constraint factory methods:**

| Method | xgrammar call | Returns |
|--------|---------------|---------|
| `get_json_schema_logits_processor(json_schema)` | `grammar_compiler.compile_json_schema(...)` | `XGrammarLogitsProcessor` |
| `get_regex_logits_processor(regex)` | `grammar_compiler.compile_regex(...)` | `XGrammarLogitsProcessor` |
| `get_cfg_logits_processor(grammar)` | `grammar_compiler.compile_grammar(...)` | `XGrammarLogitsProcessor` |

Each method compiles the constraint into a `compiled_grammar` and passes it to a new
`XGrammarLogitsProcessor`.

### `XGrammarLogitsProcessor`

A subclass of [`OutlinesLogitsProcessor`](processors_base_logits_processor.md) that wraps
`xgrammar.contrib.hf.LogitsProcessor`.

- **`__init__(compiled_grammar: str)`** — Stores the compiled grammar and calls
  `super().__init__("torch")`, fixing the tensor library to `torch` (consistent with the
  Transformers-only support).
- **`reset()`** — Clears the underlying `xgrammar_logits_processor` so a fresh processor is
  created for the next generation.
- **`process_logits(input_ids, logits)`** — Lazily instantiates
  `xgr.contrib.hf.LogitsProcessor(compiled_grammar)` on first call, then delegates to it to
  bias the logits.

The base class `OutlinesLogitsProcessor` handles tensor shape normalization (1D ↔ 2D) and
dispatches to `process_logits` via its `__call__` method. See
[processors_base_logits_processor.md](processors_base_logits_processor.md) for details.

---

## Data Flow

The following sequence diagram shows how a constraint flows from the user through the
backend to the model's generation loop.

```mermaid
sequenceDiagram
    participant U as User
    participant B as XGrammarBackend
    participant GC as xgrammar.GrammarCompiler
    participant LP as XGrammarLogitsProcessor
    participant M as Transformers Model

    U->>B: get_json_schema_logits_processor(schema)
    B->>GC: compile_json_schema(schema)
    GC-->>B: compiled_grammar
    B->>LP: XGrammarLogitsProcessor(compiled_grammar)
    LP-->>B: logits processor
    B-->>U: logits processor

    U->>M: generate(prompt, output_type=logits_processor)
    loop each generation step
        M->>LP: __call__(input_ids, logits)
        LP->>LP: process_logits(input_ids, logits)
        LP->>LP: lazily create xgr.contrib.hf.LogitsProcessor
        LP-->>M: biased logits
    end
    M-->>U: constrained text
```

---

## Constraint Types

The backend supports three constraint types, each mapping to a corresponding term in the
[types DSL](types_dsl.md):

| Constraint | DSL Term | Backend Method |
|------------|----------|----------------|
| JSON Schema | [`JsonSchema`](types_dsl.md) | `get_json_schema_logits_processor` |
| Regular Expression | [`Regex`](types_dsl.md) | `get_regex_logits_processor` |
| Context-Free Grammar | [`CFG`](types_dsl.md) | `get_cfg_logits_processor` |

---

## Backend Comparison

XGrammar is one of three interchangeable backends. The table below highlights the key
differences:

| Feature | XGrammar | [LLGuidance](backends_llguidance.md) | [Outlines Core](backends_outlines_core.md) |
|---------|----------|--------------------------------------|--------------------------------------------|
| Supported models | `Transformers` only | `Transformers`, `LlamaCpp`, `MLXLM` | `Transformers`, `LlamaCpp`, `MLXLM` |
| JSON Schema | ✅ | ✅ | ✅ |
| Regex | ✅ | ✅ | ✅ |
| CFG | ✅ | ✅ | ❌ (raises `NotImplementedError`) |
| Tensor library | `torch` (fixed) | Model-dependent | Model-dependent |

---

## Dependencies

```mermaid
graph LR
    XGB[xgrammar.py] --> Base[backends/base.py::BaseBackend]
    XGB --> Models[models/__init__.py::SteerableModel]
    XGB --> Transformers[models/transformers.py::Transformers]
    XGB --> BLPP[processors/base_logits_processor.py::OutlinesLogitsProcessor]
    XGB -.->|runtime import| XGR[xgrammar library]
    XGB -.->|runtime import| HF[transformers.AutoConfig]
```

- **Internal dependencies:**
  - [`BaseBackend`](backends_base.md) — abstract interface implemented by the backend.
  - [`Transformers`](models_transformers.md) — the only supported model type.
  - [`OutlinesLogitsProcessor`](processors_base_logits_processor.md) — base class for the
    logits processor.
  - `SteerableModel` — type hint for the model argument.
- **External dependencies:**
  - `xgrammar` — provides `TokenizerInfo`, `GrammarCompiler`, and
    `contrib.hf.LogitsProcessor`.
  - `transformers` — provides `AutoConfig` for reading the vocabulary size.

---

## Usage Example

```python
from outlines import models
from outlines.backends.xgrammar import XGrammarBackend

# Only Transformers models are supported
model = models.transformers("meta-llama/Llama-3.2-1B-Instruct")
backend = XGrammarBackend(model)

# Create a logits processor from a JSON schema
logits_processor = backend.get_json_schema_logits_processor(
    '{"type": "object", "properties": {"name": {"type": "string"}}}'
)

# Pass the processor to the model's generate method
result = model.generate("Extract the name:", output_type=logits_processor)
```

---

## Related Documentation

- [backends_base.md](backends_base.md) — The `BaseBackend` abstract interface.
- [backends_llguidance.md](backends_llguidance.md) — The LLGuidance backend.
- [backends_outlines_core.md](backends_outlines_core.md) — The Outlines Core backend.
- [processors_base_logits_processor.md](processors_base_logits_processor.md) — The
  `OutlinesLogitsProcessor` base class.
- [models_transformers.md](models_transformers.md) — The `Transformers` model wrapper.
- [types_dsl.md](types_dsl.md) — The constraint DSL (`JsonSchema`, `Regex`, `CFG`, etc.).
