# Models Server Module

## Introduction

The **models_server** module provides Outlines integrations for **self-hosted inference servers** that expose an OpenAI-compatible or HuggingFace-compatible HTTP API. It enables structured generation against models served by:

- **vLLM** — a high-throughput LLM serving engine
- **SGLang** — a fast serving framework for LLMs and multimodal models
- **TGI** (Text Generation Inference) — HuggingFace's production inference server

Unlike the [models_local](models_local.md) module (which runs models in-process) or the [models_api](models_api.md) module (which targets hosted third-party APIs), this module assumes the model is running behind a network endpoint that you control. The wrappers here are thin adapters that translate Outlines' high-level input/output types into the request arguments expected by each server's client library.

All models in this module are **black-box models**: constrained generation is delegated to the server's own structured-output backend (e.g. vLLM's `guided_json`, SGLang's `ebnf`, TGI's `grammar`), rather than being enforced locally via logits processors.

---

## Architecture Overview

The module follows the same three-part pattern used across all Outlines model integrations:

1. A **`Model` / `AsyncModel`** subclass that wraps a client and implements `generate`, `generate_batch`, and `generate_stream`.
2. A **`ModelTypeAdapter`** subclass that formats user input and output types into client arguments.
3. A **`from_*` factory function** that dispatches on the client type to return the sync or async wrapper.

```mermaid
graph TD
    subgraph "models_server"
        VLLM["VLLM / AsyncVLLM"]
        SGLang["SGLang / AsyncSGLang"]
        TGI["TGI / AsyncTGI"]
        VLLMTA["VLLMTypeAdapter"]
        SGLangTA["SGLangTypeAdapter"]
        TGITA["TGITypeAdapter"]
    end

    subgraph "models_base"
        Model["Model (ABC)"]
        AsyncModel["AsyncModel (ABC)"]
        ModelTypeAdapter["ModelTypeAdapter (ABC)"]
    end

    subgraph "models_api"
        OpenAITA["OpenAITypeAdapter"]
    end

    VLLM --> Model
    AsyncVLLM --> AsyncModel
    SGLang --> Model
    AsyncSGLang --> AsyncModel
    TGI --> Model
    AsyncTGI --> AsyncModel

    VLLMTA --> ModelTypeAdapter
    SGLangTA --> ModelTypeAdapter
    TGITA --> ModelTypeAdapter

    VLLMTA -.delegates input.-> OpenAITA
    SGLangTA -.delegates input.-> OpenAITA
```

### Component Relationships

| Server | Sync Model | Async Model | Type Adapter | Client Library |
|--------|-----------|-------------|--------------|----------------|
| vLLM | `VLLM` | `AsyncVLLM` | `VLLMTypeAdapter` | `openai.OpenAI` / `openai.AsyncOpenAI` |
| SGLang | `SGLang` | `AsyncSGLang` | `SGLangTypeAdapter` | `openai.OpenAI` / `openai.AsyncOpenAI` |
| TGI | `TGI` | `AsyncTGI` | `TGITypeAdapter` | `huggingface_hub.InferenceClient` / `AsyncInferenceClient` |

---

## Base Class Contract

All models in this module inherit from the abstract base classes defined in [models_base](models_base.md):

- **`Model`** — defines the public `__call__`, `batch`, and `stream` methods (which internally build a `Generator`) and requires subclasses to implement `generate`, `generate_batch`, and `generate_stream`.
- **`AsyncModel`** — the async equivalent, with `await`-able `__call__`, `batch`, and `stream`.
- **`ModelTypeAdapter`** — requires `format_input` and `format_output_type`.

Because these models are black-box, the `output_type` passed to `generate` is a **type** (e.g. a Pydantic model, `JsonSchema`, `CFG`, or `Regex`), not a logits processor. The `BlackBoxGenerator` (see [generator](generator.md)) simply forwards the output type to the model's `generate` method.

```mermaid
sequenceDiagram
    participant User
    participant Model as VLLM/SGLang/TGI
    participant TA as TypeAdapter
    participant Client as Server Client

    User->>Model: generate(input, output_type, **kwargs)
    Model->>TA: format_input(input)
    TA-->>Model: messages / prompt
    Model->>TA: format_output_type(output_type)
    TA-->>Model: structured-output args
    Model->>Client: create(**client_args)
    Client-->>Model: response
    Model-->>User: str | list[str]
```

---

## vLLM Integration

**File:** `outlines/models/vllm.py`

The vLLM integration wraps the `openai.OpenAI` (or `openai.AsyncOpenAI`) client, since a vLLM server exposes an OpenAI-compatible chat completions endpoint.

### `VLLMTypeAdapter`

- **`format_input`** — delegates entirely to `OpenAITypeAdapter().format_input`, producing the `messages` list. Supported inputs are `str`, `list` (prompt + images), and `Chat`.
- **`format_output_type`** — converts the user's output type into vLLM's guided-decoding arguments via `python_types_to_terms`:

| Outlines term | vLLM argument |
|---------------|---------------|
| `CFG` | `{"guided_grammar": <definition>}` |
| `JsonSchema` | `{"guided_json": <schema>, "whitespace_pattern": ...}` |
| anything else | `{"guided_regex": to_regex(term)}` |

### `VLLM` / `AsyncVLLM`

- Constructor takes a client and an optional `model_name`.
- `generate` builds client args via `_build_client_args`, calls `chat.completions.create`, and returns a single string (one choice) or a list of strings (multiple choices). A `refusal` in any message raises `ValueError`.
- `generate_stream` yields `delta.content` chunks from a streaming response.
- `generate_batch` raises `NotImplementedError` — vLLM does not support batch inference through this wrapper.
- `_build_client_args` merges the formatted output type into `extra_body`, and injects `model_name` if no `model` kwarg is provided.

### `from_vllm`

Factory that returns `VLLM` for an `OpenAI` client or `AsyncVLLM` for an `AsyncOpenAI` client; raises `ValueError` otherwise.

---

## SGLang Integration

**File:** `outlines/models/sglang.py`

The SGLang integration also wraps the OpenAI-compatible client.

### `SGLangTypeAdapter`

- **`format_input`** — delegates to `OpenAITypeAdapter().format_input`.
- **`format_output_type`** — maps terms to SGLang-specific arguments:

| Outlines term | SGLang argument | Notes |
|---------------|-----------------|-------|
| `CFG` | `{"extra_body": {"ebnf": <definition>}}` | Emits a warning: SGLang expects **EBNF**, not the Lark grammar generally used in Outlines. Only compatible with the sglang/llguidance backends. |
| `JsonSchema` | `OpenAITypeAdapter().format_json_output_type(...)` | Uses OpenAI-style `response_format`. |
| anything else | `{"extra_body": {"regex": to_regex(term)}}` | |

### `SGLang` / `AsyncSGLang`

- Same structure as the vLLM wrappers: `generate`, `generate_stream`, and a `generate_batch` that raises `NotImplementedError`.
- `_build_client_args` merges the output-type args directly into `inference_kwargs` (rather than nesting under `extra_body` at the top level, since the adapter already wraps them).

### `from_sglang`

Factory returning `SGLang` or `AsyncSGLang` based on the client type.

---

## TGI Integration

**File:** `outlines/models/tgi.py`

The TGI integration wraps HuggingFace's `InferenceClient` / `AsyncInferenceClient` and uses the `text_generation` endpoint.

### `TGITypeAdapter`

- **`format_input`** — a `singledispatchmethod` that only accepts `str`. Any other input type raises `NotImplementedError`. This means TGI does **not** support `Chat` or multimodal inputs through this wrapper.
- **`format_output_type`** — maps terms to TGI's `grammar` argument:

| Outlines term | TGI argument |
|---------------|--------------|
| `CFG` | raises `NotImplementedError` (unsupported) |
| `JsonSchema` | `{"grammar": {"type": "json", "value": <schema>}}` |
| anything else | `{"grammar": {"type": "regex", "value": to_regex(term)}}` |

### `TGI` / `AsyncTGI`

- Constructor takes only a client (no `model_name`).
- `generate` calls `client.text_generation(**client_args)` and returns a string.
- `generate_stream` yields chunks from a streaming `text_generation` call.
- `generate_batch` raises `NotImplementedError`.
- `_build_client_args` builds a `prompt` argument (not `messages`) plus the grammar args.

### `from_tgi`

Factory returning `TGI` or `AsyncTGI` based on the client type; raises `ValueError` for unsupported clients.

---

## Structured Output Support Matrix

The following table summarizes which structured output types each server supports through this module. All conversions rely on `python_types_to_terms` and `to_regex` from the [types_dsl](types_dsl.md) module.

| Output type | vLLM | SGLang | TGI |
|-------------|------|--------|-----|
| `JsonSchema` (Pydantic, dataclass, TypedDict, dict, etc.) | ✅ `guided_json` | ✅ `response_format` | ✅ `grammar: json` |
| `Regex` / regex-convertible terms | ✅ `guided_regex` | ✅ `regex` | ✅ `grammar: regex` |
| `CFG` | ✅ `guided_grammar` | ⚠️ `ebnf` (EBNF only, warns) | ❌ unsupported |
| `Chat` / multimodal input | ✅ | ✅ | ❌ (str only) |
| Batch inference | ❌ | ❌ | ❌ |
| Streaming | ✅ | ✅ | ✅ |

---

## Data Flow

The following diagram shows how a user request flows through the module for a JSON-schema-constrained generation.

```mermaid
flowchart LR
    A["User: model.generate(prompt, MyPydanticModel)"] --> B["TypeAdapter.format_input"]
    B --> C["OpenAITypeAdapter → messages"]
    A --> D["TypeAdapter.format_output_type"]
    D --> E["python_types_to_terms → JsonSchema"]
    E --> F["Server-specific arg<br/>(guided_json / response_format / grammar)"]
    C --> G["_build_client_args"]
    F --> G
    G --> H["client.chat.completions.create / text_generation"]
    H --> I["Parse response choices"]
    I --> J["Return str or list[str]"]
```

---

## Usage Examples

### vLLM

```python
from openai import OpenAI
from outlines.models.vllm import from_vllm

client = OpenAI(base_url="http://localhost:8000/v1", api_key="EMPTY")
model = from_vllm(client, model_name="meta-llama/Llama-3-8B-Instruct")

result = model("List two colors", output_type=MyPydanticModel)
```

### SGLang

```python
from openai import OpenAI
from outlines.models.sglang import from_sglang

client = OpenAI(base_url="http://localhost:30000/v1", api_key="EMPTY")
model = from_sglang(client, model_name="meta-llama/Llama-3-8B-Instruct")

result = model("List two colors", output_type=MyPydanticModel)
```

### TGI

```python
from huggingface_hub import InferenceClient
from outlines.models.tgi import from_tgi

client = InferenceClient(model="http://localhost:8080")
model = from_tgi(client)

result = model("List two colors", output_type=MyPydanticModel)
```

---

## Design Notes & Constraints

- **Black-box only.** No local logits processors are used; structured generation is enforced server-side. This means the set of supported output types depends on the server's backend (see the support matrix above).
- **No batch inference.** All three integrations raise `NotImplementedError` for `generate_batch`. Use the async wrappers with `asyncio.gather` for concurrency instead.
- **Input type restrictions.** vLLM and SGLang accept `str`, `list`, and `Chat` (via `OpenAITypeAdapter`); TGI accepts only `str`.
- **Shared input formatting.** vLLM and SGLang reuse `OpenAITypeAdapter` from [models_api](models_api.md) for input formatting, keeping chat/multimodal handling consistent with the OpenAI integration.
- **Refusal handling.** vLLM and SGLang raise `ValueError` if the server returns a refusal message.

---

## Related Modules

- [models_base](models_base.md) — `Model`, `AsyncModel`, `ModelTypeAdapter` base classes
- [models_api](models_api.md) — hosted API integrations (OpenAI, Anthropic, Gemini, etc.) and the shared `OpenAITypeAdapter`
- [models_local](models_local.md) — in-process model integrations (Transformers, llama.cpp, MLX, vLLM offline)
- [generator](generator.md) — `BlackBoxGenerator` and `SteerableGenerator`
- [types_dsl](types_dsl.md) — `python_types_to_terms`, `to_regex`, `CFG`, `JsonSchema`, and other DSL terms
- [inputs](inputs.md) — `Chat`, `Image`, and other input types
