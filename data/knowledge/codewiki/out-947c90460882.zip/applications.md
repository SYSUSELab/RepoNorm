# Applications Module

## Introduction

The `applications` module provides the `Application` class, a high-level abstraction that encapsulates a **prompt template** and an **output type** into a single, reusable object. It serves as the primary user-facing entry point for building structured, reusable LLM workflows in Outlines.

An `Application` combines:
- A **template** (a `Template` or any callable) that renders a prompt from input variables.
- An **output type** (e.g., a Pydantic model, JSON schema, regex, or CFG) that constrains the generated response.

When called with a model and template variables, the `Application` renders the prompt, lazily constructs (and caches) an appropriate generator, and produces a structured response.

---

## Core Component

### `Application`

The `Application` class is the sole component of this module. It acts as a thin orchestration layer that ties together templates, models, and generators.

| Attribute | Type | Description |
|-----------|------|-------------|
| `template` | `Union[Template, Callable]` | Renders the prompt string from keyword arguments. |
| `output_type` | `Optional[Any]` | The expected output type passed to the generator. |
| `generator` | `Optional[Union[BlackBoxGenerator, SteerableGenerator]]` | Cached generator instance, created lazily. |
| `model` | `Optional[Model]` | The model associated with the cached generator. |

#### Constructor

```python
Application(template: Union[Template, Callable], output_type: Optional[Any] = None)
```

- **`template`**: The template used to build the prompt. Can be a `Template` instance (see [templates.md](templates.md)) or any callable that returns a prompt string.
- **`output_type`**: The output type provided to the generator. This may be a Python type, a Pydantic model, or a type from the `outlines.types` DSL (see [types_dsl.md](types_dsl.md)).

#### `__call__`

```python
Application.__call__(model: Model, template_vars: Dict[str, Any], **inference_kwargs) -> Any
```

The main entry point. It performs the following steps:

1. **Validates** that a model was provided (raises `ValueError` otherwise).
2. **Lazily creates a generator** via `Generator(model, self.output_type)` if the model has changed since the last call. The generator is cached to avoid rebuilding it on every invocation.
3. **Renders the prompt** by calling `self.template(**template_vars)`.
4. **Generates the response** by invoking the cached generator with the rendered prompt and any additional inference keyword arguments.

---

## Architecture

The `Application` class sits at the top of the Outlines stack, orchestrating templates, models, and generators.

```mermaid
graph TD
    User["User Code"] -->|"application(model, vars, **kwargs)"| App["Application"]
    App -->|"template(**template_vars)"| Template["Template / Callable"]
    App -->|"Generator(model, output_type)"| Gen["Generator Factory"]
    Gen -->|"black-box model"| BBG["BlackBoxGenerator"]
    Gen -->|"steerable model"| SG["SteerableGenerator"]
    BBG -->|"generate / generate_batch / generate_stream"| Model["Model"]
    SG -->|"generate / generate_batch / generate_stream"| Model
    Model -->|"constrained output"| Result["Structured Response"]
    App --> Result
```

### Component Relationships

```mermaid
classDiagram
    class Application {
        +template: Union[Template, Callable]
        +output_type: Optional[Any]
        +generator: Optional[Generator]
        +model: Optional[Model]
        +__call__(model, template_vars, **kwargs) Any
    }
    class Template {
        +__call__(**kwargs) str
        +from_string(content, filters) Template
        +from_file(path, filters) Template
    }
    class Model {
        <<abstract>>
        +generate(...)
        +generate_batch(...)
        +generate_stream(...)
    }
    class BlackBoxGenerator {
        +__call__(prompt, **kwargs)
        +batch(prompts, **kwargs)
        +stream(prompt, **kwargs)
    }
    class SteerableGenerator {
        +logits_processor
        +__call__(prompt, **kwargs)
        +batch(prompts, **kwargs)
        +stream(prompt, **kwargs)
    }

    Application --> Template : uses
    Application --> Model : uses
    Application --> BlackBoxGenerator : creates
    Application --> SteerableGenerator : creates
```

---

## Data Flow

The following sequence diagram illustrates the lifecycle of a single `Application` call, including the lazy generator caching behavior.

```mermaid
sequenceDiagram
    participant U as User
    participant A as Application
    participant T as Template
    participant G as Generator Factory
    participant M as Model

    U->>A: __call__(model, {"num": 3}, max_new_tokens=20)
    A->>A: validate model is not None
    alt model changed since last call
        A->>G: Generator(model, output_type)
        G-->>A: generator (BlackBox or Steerable)
        A->>A: cache generator & model
    end
    A->>T: template(**template_vars)
    T-->>A: rendered prompt string
    A->>G: generator(prompt, **inference_kwargs)
    G->>M: generate(prompt, output_type/processor, **kwargs)
    M-->>G: structured response
    G-->>A: structured response
    A-->>U: structured response
```

---

## Process Flow: Generator Selection

The type of generator created depends on the model and the output type. This determines whether constrained generation is applied via a logits processor.

```mermaid
flowchart TD
    Start["Application.__call__"] --> CheckModel{"model is None?"}
    CheckModel -->|Yes| Error["raise ValueError"]
    CheckModel -->|No| CheckChanged{"model != self.model?"}
    CheckChanged -->|Yes| CreateGen["Generator(model, output_type)"]
    CheckChanged -->|No| ReuseGen["Reuse cached generator"]
    CreateGen --> GenType{"Model type?"}
    GenType -->|Black-box| BB["BlackBoxGenerator<br/>(output_type passed to model)"]
    GenType -->|Steerable| SG["SteerableGenerator<br/>(output_type compiled to logits processor)"]
    BB --> Render
    SG --> Render
    ReuseGen --> Render["Render prompt via template"]
    Render --> Generate["generator(prompt, **inference_kwargs)"]
    Generate --> End["Return structured response"]
```

---

## Usage Example

```python
from pydantic import BaseModel
from transformers import AutoModelForCausalLM, AutoTokenizer
from outlines import models, Application
from outlines.types import JsonType
from outlines.templates import Template

class OutputModel(BaseModel):
    result: int

model = models.from_transformers(
    AutoModelForCausalLM.from_pretrained("microsoft/Phi-3-mini-4k-instruct"),
    AutoTokenizer.from_pretrained("microsoft/Phi-3-mini-4k-instruct")
)

template_string = "What is 2 times {{ num }}?"
template = Template.from_string(template_string)

application = Application(template, JsonType(OutputModel))

result = application(model, {"num": 3}, max_new_tokens=20)
print(result)  # Expected output: { "result" : 6 }
```

---

## Dependencies

The `Application` class depends on the following modules:

| Dependency | Purpose | Documentation |
|------------|---------|---------------|
| `outlines.templates.Template` | Renders prompt strings from variables. | [templates.md](templates.md) |
| `outlines.generator` | Provides `BlackBoxGenerator` and `SteerableGenerator` for constrained generation. | [generator.md](generator.md) |
| `outlines.models.base.Model` | Abstract base class for all models. | [models.md](models.md) |
| `outlines.types` (DSL) | Defines output types (JSON, regex, CFG, etc.). | [types_dsl.md](types_dsl.md) |

### Dependency Graph

```mermaid
graph LR
    App["applications.Application"] --> Templates["templates.Template"]
    App --> Generator["generator.BlackBoxGenerator / SteerableGenerator"]
    App --> Models["models.base.Model"]
    Generator --> Backends["backends.*"]
    Generator --> Processors["processors.*"]
    Generator --> TypesDSL["types.dsl"]
    Models --> Inputs["inputs.*"]
```

---

## Key Design Notes

- **Lazy generator creation**: The generator is only built when the model changes, avoiding the expensive construction of logits processors on every call. This is especially important for steerable models where building a logits processor can be costly.
- **Model change detection**: The `Application` compares the incoming model against the cached `self.model` using `!=`. If they differ, a new generator is created.
- **Flexible templates**: The `template` attribute accepts either a `Template` instance or any callable, allowing users to supply custom prompt-building logic.
- **Optional output type**: When `output_type` is `None`, the generator performs unconstrained generation.

---

## Related Modules

- [generator.md](generator.md) — Generator classes that perform constrained generation.
- [templates.md](templates.md) — Prompt template abstraction.
- [models.md](models.md) — Model base classes and implementations.
- [types_dsl.md](types_dsl.md) — Output type DSL (JSON, regex, CFG, etc.).
- [backends.md](backends.md) — Backends that compile output types into logits processors.
- [processors.md](processors.md) — Logits processors and tensor adapters.
