# Processors

## Introduction

The `processors` module provides the low-level machinery that **controls text generation** in steerable models. Its central abstraction is the *logits processor*: a callable that receives the raw logits produced by a language model at each generation step and returns a modified version of those logits, biasing the model toward (or away from) specific tokens. This is the mechanism that makes structured generation possible — for example, forcing a model to emit only tokens that keep a JSON document valid, or that match a regular expression.

Because Outlines supports many model backends (Transformers, vLLM, llama.cpp, MLX, TensorFlow, JAX, …), each of which uses a *different tensor library*, the module is split into two cooperating layers:

1. **Logits processors** — library-agnostic generation logic (`OutlinesLogitsProcessor` and its subclasses).
2. **Tensor adapters** — thin, library-specific shims that let the processors manipulate tensors (numpy, torch, jax, mlx, tensorflow) through a single uniform interface.

This separation means a single logits processor implementation can run unchanged on top of any supported tensor library.

## Architecture Overview

```mermaid
graph TD
    subgraph "Model Backends"
        TR[Transformers]
        VLLM[vLLM / SGLang / TGI]
        LLAMA[llama.cpp]
        MLX[MLX-LM]
    end

    subgraph "processors module"
        BLP["OutlinesLogitsProcessor<br/>(base_logits_processor.py)"]
        TA["TensorAdapter<br/>(tensor_adapters/base.py)"]
        subgraph "Concrete Adapters"
            TORCH[TorchTensorAdapter]
            NUMPY[NumpyTensorAdapter]
            JAX[JAXTensorAdapter]
            MLXA[MLXTensorAdapter]
            TF[TensorFlowTensorAdapter]
        end
        REG["tensor_adapters registry<br/>(tensor_adapters/__init__.py)"]
    end

    TR -->|calls __call__| BLP
    VLLM -->|calls __call__| BLP
    LLAMA -->|calls __call__| BLP
    MLX -->|calls __call__| BLP

    BLP -->|delegates tensor ops| TA
    TA -.implements.-> TORCH
    TA -.implements.-> NUMPY
    TA -.implements.-> JAX
    TA -.implements.-> MLXA
    TA -.implements.-> TF
    REG -->|selects by library name| BLP
```

### How the pieces fit together

- A model backend instantiates a concrete logits processor, passing the **name of the tensor library** it uses (e.g. `"torch"`).
- The processor looks up the matching adapter class in the `tensor_adapters` registry and instantiates it.
- At each generation step the backend calls the processor's `__call__` method with `input_ids` and `logits`.
- `__call__` normalizes the tensor shapes to 2D, delegates the actual masking logic to the subclass's `process_logits`, and restores the original shape before returning.

## Sub-modules

The module is organized into two sub-modules, each documented in detail:

### Logits Processors

The base class `OutlinesLogitsProcessor` defines the shared `__call__` entrypoint and the abstract `process_logits` hook that concrete processors implement. It is the contract every generation-control strategy must satisfy.

See [processors_logits_processor.md](processors_logits_processor.md) for the full API, the shape-normalization logic, and guidance on implementing custom processors.

### Tensor Adapters

The `TensorAdapter` abstract base class and its five concrete implementations (`TorchTensorAdapter`, `NumpyTensorAdapter`, `JAXTensorAdapter`, `MLXTensorAdapter`, `TensorFlowTensorAdapter`) provide a uniform, library-agnostic API for the tensor operations the processors need (shape inspection, masking, concatenation, device movement, sorting, …).

See [processors_tensor_adapters.md](processors_tensor_adapters.md) for the adapter interface, the registry mechanism, and per-library implementation notes.

## Component Interaction Flow

The following sequence diagram shows a single generation step from the model's perspective:

```mermaid
sequenceDiagram
    participant Model as Model Backend
    participant LP as OutlinesLogitsProcessor
    participant TA as TensorAdapter
    participant Sub as Concrete Processor

    Model->>LP: __call__(input_ids, logits)
    LP->>TA: shape(input_ids), shape(logits)
    TA-->>LP: shapes
    Note over LP: Normalize to 2D<br/>(unsqueeze if needed)
    LP->>Sub: process_logits(input_ids_2d, logits_2d)
    Sub->>TA: apply_mask / boolean_ones_like / ...
    TA-->>Sub: masked tensors
    Sub-->>LP: processed_logits_2d
    Note over LP: Restore original shape<br/>(squeeze if needed)
    LP-->>Model: processed_logits
```

## Relationship to Other Modules

- **Models** ([models.md](models.md)) — Model backends (e.g. `Transformers`, `VLLM`, `LlamaCpp`) instantiate and invoke logits processors during generation. The `tensor_library_name` passed to a processor is determined by the backend's tensor library.
- **Backends** ([backends.md](backends.md)) — The structured-generation backends (`LLGuidanceBackend`, `XGrammarBackend`, `OutlinesCoreBackend`) produce the masks/state that concrete logits processors apply. Their `*LogitsProcessor` classes are the primary consumers of this module's base class.
- **Types DSL** ([types_dsl.md](types_dsl.md) if available) — The structured types (JSON Schema, Regex, CFG, …) are compiled by the backends into the masks that processors enforce.

## Design Notes

- **Single-use processors**: Logits processors are used once per sequence generator and are never re-applied to a new generator. Stateful processors should implement `reset()`.
- **Shape normalization**: `__call__` guarantees that `process_logits` always receives 2D tensors, hiding the differences between backends that pass only output ids and those that prefix with input ids.
- **Torch workaround**: When the tensor library is `"torch"`, the base processor disables `torch._dynamo` error suppression to avoid a warning that can become an error under Python 3.12.
- **Torch-tensor interop**: Because the underlying `outlines-core` library may still emit torch tensors, adapters' `full_like` and `concatenate` methods are required to accept torch tensors regardless of the target library.
