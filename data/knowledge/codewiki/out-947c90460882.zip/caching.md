# Caching Module

## Introduction

The `outlines.caching` module provides a persistent, disk-backed memoization layer for function calls within the Outlines library. Its primary purpose is to **avoid unnecessary and expensive computations and API calls** — particularly those involving large language models, which can be slow and costly to invoke repeatedly.

The module is built on top of the [`diskcache`](https://grantjenks.com/docs/diskcache/) library and extends it with a custom disk serialization backend (`CloudpickleDisk`) that uses `cloudpickle` to serialize arbitrary Python objects, including lambdas, closures, and complex types that standard `pickle` cannot handle.

Key capabilities:

- **Persistent caching** of function return values across process runs.
- **Async-aware** memoization (supports both sync and coroutine functions).
- **Configurable cache location** via environment variables.
- **Automatic cache invalidation** on library version upgrades.
- **Runtime toggling** of caching (globally or via a context manager).

---

## Architecture Overview

The caching module is a self-contained utility that sits beneath the higher-level model and generator layers. Models such as [`Transformers`](models.md) and [`OpenAI`](models.md) — and the [`Generator`](generator.md) abstraction that wraps them — benefit from caching when their underlying functions are decorated with `@cache`.

```mermaid
graph TD
    subgraph "Caching Module"
        CD[CloudpickleDisk]
        GC[get_cache]
        C[cache decorator]
        DC[disable_cache]
        CC[clear_cache]
        CDIS[cache_disabled]
    end

    subgraph "Consumers"
        M[Model / Generator]
        B[Backends]
    end

    M -->|decorated with| C
    B -->|decorated with| C
    C -->|uses| GC
    GC -->|creates| CD
    GC -->|returns| Cache[(diskcache.Cache)]
    DC -->|toggles| FLAG[_caching_enabled]
    CDIS -->|temporarily toggles| FLAG
    CC -->|clears| Cache
    C -->|reads flag| FLAG
```

---

## Core Components

### `CloudpickleDisk`

A subclass of `diskcache.Disk` that replaces the default serialization mechanism with `cloudpickle`. This allows the cache to store and retrieve arbitrary Python objects that standard `pickle` cannot serialize.

| Method | Purpose |
|--------|---------|
| `__init__(directory, compress_level=1, **kwargs)` | Initializes the disk with a configurable compression level. |
| `put(key)` | Serializes the cache key using `cloudpickle.dumps` before storing. |
| `get(key, raw)` | Deserializes the stored key using `cloudpickle.loads`. |
| `store(value, read, key=UNKNOWN)` | Serializes the value with `cloudpickle` unless it is a raw file read. |
| `fetch(mode, filename, value, read)` | Deserializes the fetched value with `cloudpickle` unless it is a raw file read. |

> **Note:** This class is marked `# pragma: no cover`, indicating it is not exercised by the standard test suite (likely due to filesystem/disk dependencies).

### `get_cache()`

A memoized factory function (decorated with `functools.lru_cache(1)`) that returns the singleton `diskcache.Cache` instance used throughout the library.

**Cache directory resolution order:**

1. `OUTLINES_CACHE_DIR` environment variable (highest precedence).
2. `XDG_CACHE_HOME/.cache/outlines` if `XDG_CACHE_HOME` is set.
3. `~/.cache/outlines` if the home directory is not `/`.
4. `<tempdir>/.cache/outlines` as a fallback (e.g., inside Docker containers without a user home).

The cache is configured with:
- `eviction_policy="none"` — entries are never automatically evicted.
- `cull_limit=0` — no automatic culling.
- `disk=CloudpickleDisk` — custom serialization backend.

**Version-based invalidation:** On each call, the function compares the stored `__version__` key against the current `outlines._version.__version__`. If they differ, the entire cache is cleared and the new version is written. This ensures stale entries from older library versions do not cause incorrect behavior.

### `cache(expire=None, typed=False, ignore=())`

The primary decorator for memoizing function calls. It is modeled on `diskcache`'s `memoize`.

**Parameters:**

| Parameter | Description |
|-----------|-------------|
| `expire` | Seconds until cached arguments expire. |
| `typed` | If `True`, cache different argument types separately. |
| `ignore` | Positional or keyword arguments to exclude from the cache key. |

**Behavior:**

- Detects whether the decorated function is a coroutine function (`asyncio.iscoroutinefunction`) and generates an appropriate `async` or sync wrapper.
- Computes a cache key via `args_to_key(base, args, kwargs, typed, ignore)`, where `base` is the fully-qualified function name.
- On a cache miss (`ENOVAL`), invokes the wrapped function and stores the result.
- Respects the global `_caching_enabled` flag — when disabled, the function is called directly without touching the cache.

The wrapper exposes three attributes for introspection:
- `__cache_key__` — the key-generation function.
- `__memory__` — the underlying `Cache` instance.
- `__wrapped__` — the original function.

### `disable_cache()`

Globally disables caching for the current session by setting the module-level `_caching_enabled` flag to `False`. This is useful for workflows where non-deterministic sampling is desired.

> This does **not** delete existing cache entries (use `clear_cache()` for that) and does **not** overwrite the cache with values produced during the session.

### `clear_cache()`

Erases the entire cache by calling `memory.clear()` on the singleton `Cache` instance.

### `cache_disabled()`

A context manager that temporarily disables caching within a `with` block, restoring the previous state on exit. This is useful for scoped operations that should bypass the cache without affecting global state.

```mermaid
stateDiagram-v2
    [*] --> Enabled: module import (_caching_enabled = True)
    Enabled --> Disabled: disable_cache()
    Disabled --> Enabled: (manual reset)
    Enabled --> TempDisabled: enter cache_disabled()
    TempDisabled --> Enabled: exit cache_disabled()
```

---

## Data Flow

The following diagram illustrates the flow of a cached function call:

```mermaid
flowchart TD
    A[Function call] --> B{_caching_enabled?}
    B -- No --> C[Call function directly]
    B -- Yes --> D[Compute cache key via args_to_key]
    D --> E{Key in cache?}
    E -- Yes --> F[Return cached result]
    E -- No --> G[Call function]
    G --> H[Store result in cache]
    H --> F
    C --> I[Return result]
    F --> I
```

---

## Integration with the Broader System

The caching module is a cross-cutting concern used by higher-level abstractions. It does not depend on models, backends, or generators; instead, those layers optionally decorate their expensive functions with `@cache`.

```mermaid
graph LR
    subgraph "Higher-level layers"
        GEN[Generator]
        MOD[Models: Transformers, OpenAI, ...]
        BE[Backends: LLGuidance, XGrammar, ...]
    end
    subgraph "Caching layer"
        CACHE[cache decorator + diskcache]
    end
    GEN -.->|optional @cache| CACHE
    MOD -.->|optional @cache| CACHE
    BE -.->|optional @cache| CACHE
```

Relevant related documentation:

- [Generator](generator.md) — the abstraction that orchestrates model calls and benefits from caching.
- [Models](models.md) — model wrappers (e.g., `Transformers`, `OpenAI`) whose expensive calls may be memoized.
- [Backends](backends.md) — logits-processor backends that may cache compiled grammars or schemas.

---

## Usage Examples

### Basic memoization

```python
from outlines.caching import cache

@cache()
def expensive_computation(x):
    ...
    return result
```

### Disabling the cache globally

```python
import outlines.caching as cache

cache.disable_cache()
```

### Temporarily disabling the cache

```python
from outlines.caching import cache_disabled

with cache_disabled():
    # caching is bypassed here
    ...
```

### Clearing the cache

```python
from outlines.caching import clear_cache

clear_cache()
```

### Custom cache location

```bash
export OUTLINES_CACHE_DIR=/path/to/cache
```

---

## Design Considerations

- **Persistence over memory:** Using `diskcache` means cached results survive process restarts, which is valuable for expensive model downloads or API calls.
- **No eviction:** The cache is configured with `eviction_policy="none"` and `cull_limit=0`, so it grows unbounded until manually cleared or invalidated by a version change. Users should manage disk usage accordingly.
- **Cloudpickle for flexibility:** Standard `pickle` cannot serialize many objects encountered in ML workflows (e.g., lambdas, local classes). `cloudpickle` removes this limitation at the cost of slightly larger payloads.
- **Version safety:** Automatic clearing on version mismatch prevents subtle bugs caused by incompatible cached data structures.
- **Async support:** Both synchronous and asynchronous functions are supported transparently.
