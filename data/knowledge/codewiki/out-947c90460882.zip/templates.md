# Templates Module

## Introduction

The `templates` module provides a lightweight, Jinja2-powered abstraction for building and rendering prompt templates. Its central component, the `Template` dataclass, wraps a `jinja2.Template` and exposes a convenient API for constructing templates from strings or files, rendering them with keyword arguments, and injecting custom filters.

The module is designed to make prompt engineering ergonomic: developers can author reusable prompt templates that interpolate variables, embed function metadata (name, description, source, signature, arguments), and render JSON schemas — all with strict, predictable rendering behavior.

> **Note:** This module is a standalone utility. It does not depend on the model, backend, or generator layers, but its output (rendered prompt strings) is typically consumed as `model_input` by the [models module](models_base.md) and the [generator module](generator.md).

---

## Core Component

### `Template`

`Template` is a `@dataclass` that holds a single field:

| Field | Type | Description |
|-------|------|-------------|
| `template` | `jinja2.Template` | The underlying Jinja2 template object. |

It is intentionally a class (rather than a plain function) so that callers can retain a reference to the underlying template object for introspection or reuse.

#### Public API

| Member | Kind | Description |
|--------|------|-------------|
| `__call__(*args, **kwargs) -> str` | method | Renders the template with the provided keyword arguments and returns the resulting string. |
| `from_string(content, filters={})` | classmethod | Builds a `Template` from a Jinja template string. |
| `from_file(path, filters={})` | classmethod | Builds a `Template` from a Jinja template file on disk. |

---

## Architecture

The module is organized around a small set of cooperating functions that build a configured Jinja2 environment and then produce templates from either strings or files.

```mermaid
graph TD
    Template["Template (dataclass)"]
    from_string["Template.from_string()"]
    from_file["Template.from_file()"]
    build_string["build_template_from_string()"]
    build_file["build_template_from_file()"]
    create_env["create_jinja_env()"]
    jinja["jinja2.Environment"]

    Template --> from_string
    Template --> from_file
    from_string --> build_string
    from_file --> build_file
    build_string --> create_env
    build_file --> create_env
    create_env --> jinja
    jinja --> Template
```

### Component Responsibilities

- **`Template`** — The user-facing entry point. Wraps a `jinja2.Template` and provides rendering plus two factory classmethods.
- **`build_template_from_string`** — Cleans and normalizes raw template text (dedenting, whitespace normalization, trailing newline preservation) before compiling it into a Jinja template.
- **`build_template_from_file`** — Configures a `FileSystemLoader` rooted at the template file's directory and loads the template by basename.
- **`create_jinja_env`** — Constructs a `jinja2.Environment` with strict, whitespace-friendly settings and registers the built-in filters.

---

## Template Construction Flow

The following diagram illustrates the end-to-end process of creating and rendering a template.

```mermaid
flowchart TD
    Start([User calls from_string / from_file]) --> Which{Source type?}
    Which -->|String| Clean["inspect.cleandoc + whitespace normalization"]
    Which -->|File| Loader["Create FileSystemLoader for file directory"]
    Clean --> Env["create_jinja_env(loader=None, filters)"]
    Loader --> Env
    Env --> Register["Register built-in filters + user overrides"]
    Register --> Compile["env.from_string / env.get_template"]
    Compile --> Wrap["Wrap in Template dataclass"]
    Wrap --> Render["Template.__call__(**kwargs)"]
    Render --> Output([Rendered prompt string])
```

### String Normalization Details

When building from a string, `build_template_from_string` performs several normalization steps to make multi-line prompt authoring predictable:

1. **Dedent** — `inspect.cleandoc` removes common leading indentation.
2. **Trailing newline preservation** — If the original content ended with a blank line (`\n\n`), a single `\n` is re-appended (since `cleandoc` strips it).
3. **Whitespace collapsing** — Runs of whitespace are collapsed to a single space, *except* whitespace immediately following a newline. This prevents accidental whitespace from being introduced after line-continuation backslashes (`\`).

---

## Built-in Filters

`create_jinja_env` registers a set of pre-defined Jinja filters that make it easy to embed Python callable metadata and schemas into prompts. Users may pass their own `filters` dictionary to override or extend these.

| Filter | Function | Description |
|--------|----------|-------------|
| `name` | `get_fn_name` | Returns the name of a callable (falls back to the type name if `__name__` is absent). |
| `description` | `get_fn_description` | Returns the first line of a callable's docstring. |
| `source` | `get_fn_source` | Returns the dedented source code of a callable, starting from its `def`. |
| `signature` | `get_fn_signature` | Returns the parameter list of a callable's signature. |
| `args` | `get_fn_args` | Returns the callable's arguments with annotations and defaults. |
| `schema` | `get_schema` | Renders a JSON schema for a `dict` or Pydantic `BaseModel`. |

All callable-oriented filters raise `TypeError` when applied to non-callables.

### Schema Rendering (`get_schema`)

`get_schema` is a `functools.singledispatch` function, allowing type-specific rendering:

```mermaid
graph LR
    get_schema["get_schema (singledispatch)"]
    dict_impl["get_schema_dict (dict)"]
    pydantic_impl["get_schema_pydantic (BaseModel)"]

    get_schema --> dict_impl
    get_schema --> pydantic_impl
```

- **`dict`** — Pretty-prints the dictionary as indented JSON.
- **Pydantic `BaseModel`** — Extracts the JSON schema (supporting both `model_json_schema` for Pydantic v2 and `schema` for v1), then recursively resolves `$ref` references via `parse_pydantic_schema`, producing a simplified `{field: description}` mapping rendered as indented JSON.

---

## Jinja Environment Configuration

`create_jinja_env` builds the environment with the following settings, chosen to produce clean prompt output:

| Setting | Value | Purpose |
|---------|-------|---------|
| `loader` | Provided or `None` | Enables file-based includes/inheritance when a loader is supplied. |
| `trim_blocks` | `True` | Removes the first newline after a block tag. |
| `lstrip_blocks` | `True` | Strips leading whitespace before block tags. |
| `keep_trailing_newline` | `True` | Preserves a single trailing newline. |
| `undefined` | `jinja2.StrictUndefined` | Raises errors on undefined variables instead of silently rendering empty strings. |

> **Security note:** `from_file` restricts includes and inheritance to the folder (and subfolders) of the template file, because the `FileSystemLoader` is rooted at the file's directory.

---

## Deprecated `Vision` Helper

The module also exposes a `Vision(prompt, image)` factory function that is **deprecated** and scheduled for removal in outlines v1.2.0. It emits a `DeprecationWarning` and returns a list `[prompt, Image(image)]`.

Users should migrate to passing a prompt alongside an [`outlines.inputs.Image`](inputs.md) instance directly to a multimodal model:

```python
import openai
from outlines import Image, from_openai

model = from_openai("gpt-4o")
response = model(
    ["A beautiful image of a cat", Image(my_image)],
    max_tokens=100,
)
```

---

## Dependencies

```mermaid
graph TD
    templates["outlines/templates.py"]
    jinja2["jinja2"]
    pydantic["pydantic.BaseModel"]
    PIL["PIL.Image"]
    inputs["outlines.inputs.Image"]

    templates --> jinja2
    templates --> pydantic
    templates --> PIL
    templates --> inputs
```

| Dependency | Usage |
|------------|-------|
| `jinja2` | Template engine, environment, loaders, and `StrictUndefined`. |
| `pydantic.BaseModel` | Schema rendering for Pydantic models. |
| `PIL.Image` | Type hint for the deprecated `Vision` helper. |
| [`outlines.inputs.Image`](inputs.md) | Wraps images for multimodal model input in the deprecated `Vision` helper. |

---

## Integration with the Broader System

Templates produce plain strings (or lists containing strings and [`Image`](inputs.md) instances). These outputs are passed as `model_input` to models and generators:

```mermaid
graph LR
    Template["Template.__call__()"]
    ModelInput["model_input"]
    Model["Model (models_base.md)"]
    Generator["Generator (generator.md)"]

    Template -->|rendered string| ModelInput
    ModelInput --> Model
    ModelInput --> Generator
```

- The rendered string is a valid `model_input` for any model documented in the [models module](models_base.md).
- For multimodal prompts, the deprecated `Vision` helper returns a list combining a prompt string and an [`Image`](inputs.md), which is the expected input shape for vision-capable models.

---

## Usage Examples

### From a string

```python
from outlines.templates import Template

template = Template.from_string("Hello {{ name }}!")
print(template(name="world"))  # "Hello world!"
```

### From a file

```python
from pathlib import Path
from outlines.templates import Template

template = Template.from_file(Path("prompts/greeting.jinja"))
print(template(name="world"))
```

### Using built-in filters

```python
from outlines.templates import Template

def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b

template = Template.from_string(
    "Function: {{ fn | name }}\n"
    "Description: {{ fn | description }}\n"
    "Signature: {{ fn | signature }}"
)
print(template(fn=add))
```

### Custom filters

```python
from outlines.templates import Template

template = Template.from_string(
    "{{ value | shout }}",
    filters={"shout": lambda s: s.upper()},
)
print(template(value="hello"))  # "HELLO"
```

---

## Related Documentation

- [Inputs Module](inputs.md) — `Image`, `Chat`, and other multimodal input types.
- [Models Module](models_base.md) — Base `Model` and `AsyncModel` classes that consume rendered prompts.
- [Generator Module](generator.md) — `Generator` classes that drive model inference.
