# Rule details

- **Rule:**
  ```text
  The v0_legacy ExLlamaV2 model must raise NotImplementedError from its stream method, and its ExllamaV2Params TypedDict must remain total=False with the optional keys stop_conditions, seed, gen_settings, and max_new_tokens.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying the v0_legacy ExLlamaV2 model's stream method or its ExllamaV2Params parameter surface.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
ExllamaV2Params is declared as a total=False TypedDict with the optional keys stop_conditions, seed, gen_settings, and max_new_tokens, matching the required parameter surface.
```

- **Sources:**
  - `outlines/v0_legacy/models/exllamav2.py:27-31`

### Evidence 2 — current_observation

```text
ExLlamaV2Model.stream raises NotImplementedError stating v0 models do not support streaming, matching the required stream guard.
```

- **Sources:**
  - `outlines/v0_legacy/models/exllamav2.py:84-88`
