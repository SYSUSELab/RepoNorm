# Rule details

- **Rule:** When modifying the self-consistency example, keep the majority-vote aggregation pattern: generate n=10 answers, extract the last integer from each via regex, and report the most frequent answer with a consensus percentage.
- **Applies to:**
  - `examples/self_consistency.py`
- **Condition:** When editing the self-consistency example's sampling count or aggregation logic.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The example generates n=10 answers, extracts the last integer from each via regex, and reports the most frequent answer with a consensus percentage, matching the majority-vote aggregation pattern.
```

- **Sources:**
  - `examples/self_consistency.py`
