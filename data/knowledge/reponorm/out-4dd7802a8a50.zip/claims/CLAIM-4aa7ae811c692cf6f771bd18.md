# Rule details

- **Rule:** Read the Docs additionally installs dependencies from requirements-doc.txt.
- **Applies to:**
  - `requirements-doc.txt`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`

## Supporting evidence

### Evidence 1 — explicit

```text
      - requirements: requirements-doc.txt

```

- **Sources:**
  - `.readthedocs.yaml:10`
