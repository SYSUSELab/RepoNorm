# Rule details

- **Rule:**
  ```text
  The BabyAGI one_cycle example must pop the highest-priority task, complete it, create new tasks from the result with incrementing task ids, re-prioritize the task list, and return the executed task, result, prioritized tasks, and updated next_task_id.
  ```
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:**
  ```text
  When modifying the BabyAGI one_cycle task-execution loop.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
one_cycle pops the highest-priority task, completes it, creates new tasks with incrementing ids, re-prioritizes, and returns the executed task, result, prioritized tasks, and updated next_task_id.
```

- **Sources:**
  - `examples/babyagi.py`
