# Rule details

- **Rule:** The workflow configures git user.name and user.email from the github.actor before publishing.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Set up Git
        run: |
          git config user.name ${{ github.actor }}
          git config user.email ${{ github.actor }}@users.noreply.github.com

```

- **Sources:**
  - `.github/workflows/publish_documentation.yml:35-38`
