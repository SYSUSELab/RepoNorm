# Rule details

- **Rule:** Example scripts that demonstrate a bounded agent loop must document the fixed cycle limit and the absence of vector-store retrieval, bounding the example's demonstrated scope.
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When adding or modifying the babyagi example.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The example documents the fixed five-cycle limit and notes that vector-store retrieval is not used, bounding the demonstrated scope.
```

- **Sources:**
  - `examples/babyagi.py`
