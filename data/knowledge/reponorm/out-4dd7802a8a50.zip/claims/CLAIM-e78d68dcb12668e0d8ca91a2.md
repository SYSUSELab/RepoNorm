# Rule details

- **Rule:** The workflow installs Ollama by running the install script, checking the version, and pulling the tinyllama model.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
    - name: Install Ollama
      run: |
        curl -fsSL https://ollama.com/install.sh | sh
        ollama --version
        ollama pull tinyllama

```

- **Sources:**
  - `.github/workflows/tests_nightly.yml:28-32`
