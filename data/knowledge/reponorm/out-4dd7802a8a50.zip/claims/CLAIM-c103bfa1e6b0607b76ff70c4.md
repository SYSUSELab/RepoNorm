# Rule details

- **Rule:**
  ```text
  The v0_legacy setup_numpy helper must import numpy in a try block and select private numpy helpers (_calculate_shapes, _parse_gufunc_signature, _parse_input_dimensions, _update_dim_sizes) from numpy.lib._function_base_impl for numpy major version >= 2 versus numpy.lib.function_base otherwise.
  ```
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:**
  ```text
  When modifying the v0_legacy setup_numpy helper or its numpy private-helper imports.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
setup_numpy imports numpy in a try block and selects the private helpers from numpy.lib._function_base_impl for major version >= 2 versus numpy.lib.function_base otherwise.
```

- **Sources:**
  - `outlines/v0_legacy/base.py:43-85`
