# Rule details

- **Rule:** The dev container declares GPU host requirements as optional.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
    "gpu": "optional"

```

- **Sources:**
  - `.devcontainer/devcontainer.json:8`
