# Rule details

- **Rule:** The vLLM vision test image fixture must build a 256x256 RGB white PNG in memory and reopen it from the BytesIO buffer, supplying vision inputs without on-disk assets.
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when modifying the vLLM vision test image fixture or adding vision inputs to vLLM tests
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The image fixture builds a 256x256 RGB white PNG in memory and reopens it from the BytesIO buffer, supplying vision inputs without on-disk assets.
```

- **Sources:**
  - `tests/models/test_vllm.py`
