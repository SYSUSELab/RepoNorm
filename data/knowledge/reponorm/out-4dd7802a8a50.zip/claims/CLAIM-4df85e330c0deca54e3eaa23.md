# Rule details

- **Rule:**
  ```text
  The tokenizer_seq2seq fixture must construct its tokenizer via transformers.AutoTokenizer.from_pretrained using the module-level TEST_MODEL_SEQ2SEQ constant rather than a hard-coded model name.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:**
  ```text
  when modifying the tokenizer_seq2seq fixture or adding seq2seq tokenizer tests
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The tokenizer_seq2seq fixture calls transformers.AutoTokenizer.from_pretrained(TEST_MODEL_SEQ2SEQ), using the module-level constant rather than a hard-coded model name.
```

- **Sources:**
  - `tests/models/test_transformers_tokenizer.py`
