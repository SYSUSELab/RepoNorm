# Rule details

- **Rule:**
  ```text
  format_vision_model_input must build an Anthropic messages payload with a user message containing an image source using base64, media_type from model_input.image_format, data from model_input.image_str, followed by a text block with model_input.prompt.
  ```
- **Applies to:**
  - `outlines/models/anthropic.py`
- **Condition:** When modifying the Anthropic vision model input formatting.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
format_vision_model_input builds an Anthropic messages payload with a user message containing a base64 image source (media_type from image_format, data from image_str) followed by a text block with the prompt.
```

- **Sources:**
  - `outlines/models/anthropic.py:58-76`
