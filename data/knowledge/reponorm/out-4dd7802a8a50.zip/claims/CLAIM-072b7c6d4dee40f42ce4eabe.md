# Rule details

- **Rule:** On failure, the workflow sends a Slack notification using 8398a7/action-slack@v3 with the job status and commit, author, and ref fields.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Condition:** workflow predicate: failure()
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      if: failure()
      uses: 8398a7/action-slack@v3
      with:
        status: ${{ job.status }}
        fields: commit,author,ref

```

- **Sources:**
  - `.github/workflows/tests_nightly.yml:54-58`
