# Rule details

- **Rule:** The legacy json test must assert that calling json with a greedy sampler on an OpenAI model raises NotImplementedError stating the OpenAI API only supports the multinomial sampler, while emitting the json deprecation warning.
- **Applies to:**
  - `tests/v0_legacy/generate/test_json_legacy.py`
- **Condition:** When modifying or extending the legacy json OpenAI wrong sampler test.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test wraps json(openai_model, JSON_SCHEMA_STRING, samplers.greedy()) in pytest.raises(NotImplementedError, match=multinomial-only message) inside pytest.warns(DeprecationWarning, match=json deprecation), asserting exactly the legacy json sampler restriction and deprecation warning.
```

- **Sources:**
  - `tests/v0_legacy/generate/test_json_legacy.py:153-163`
