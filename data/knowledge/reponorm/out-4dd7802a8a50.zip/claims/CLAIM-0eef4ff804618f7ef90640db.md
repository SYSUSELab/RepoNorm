# Rule details

- **Rule:**
  ```text
  The TGI test module must select a real InferenceClient/AsyncInferenceClient when TGI_SERVER_URL is set, otherwise warn and fall back to MockTGIInferenceClient/MockAsyncTGIInferenceClient, and only register mock_responses on the mock clients when no server URL is provided.
  ```
- **Applies to:**
  - `tests/models/test_tgi.py`
- **Condition:** When modifying or extending the TGI test module's client selection and mock setup.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The TGI test module selects real InferenceClient/AsyncInferenceClient when TGI_SERVER_URL is set, otherwise warns and falls back to mock clients, registering mock_responses only on the mocks.
```

- **Sources:**
  - `tests/models/test_tgi.py`
