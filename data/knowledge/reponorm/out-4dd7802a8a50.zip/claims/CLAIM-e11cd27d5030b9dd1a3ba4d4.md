# Rule details

- **Rule:**
  ```text
  The documentation build step installs requirements-doc.txt via pip and runs mkdocs build, with GOOGLE_ANALYTICS_KEY supplied from the GOOGLE_ANALYTICS_KEY secret.
  ```
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
          GOOGLE_ANALYTICS_KEY: ${{ secrets.GOOGLE_ANALYTICS_KEY }}
        run: |
          pip install -r requirements-doc.txt
          mkdocs build

```

- **Sources:**
  - `.github/workflows/build_documentation.yml:20-23`
