# Rule details

- **Rule:** The dev container is based on the mcr.microsoft.com/devcontainers/python:3.12 image.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
  "image": "mcr.microsoft.com/devcontainers/python:3.12",

```

- **Sources:**
  - `.devcontainer/devcontainer.json:3`
