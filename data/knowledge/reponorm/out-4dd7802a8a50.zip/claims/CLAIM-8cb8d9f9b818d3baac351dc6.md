# Rule details

- **Rule:**
  ```text
  FSM.__repr__ must return 'FSM(fsm=<inner repr>)' and CFG.__repr__ must return "CFG(definition='{self.definition}')", fixing the debug representation format for these DSL nodes.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying the debug representation of FSM or CFG DSL nodes.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
CFG.__repr__ returns f"CFG(definition='{self.definition}')", matching the fixed representation format required by the rule.
```

- **Sources:**
  - `outlines/types/dsl.py:260-261`

### Evidence 2 — current_observation

```text
FSM.__repr__ returns the fixed format 'FSM(fsm=<inner repr>)', matching the required DSL node debug representation.
```

- **Sources:**
  - `outlines/types/dsl.py:303-304`
