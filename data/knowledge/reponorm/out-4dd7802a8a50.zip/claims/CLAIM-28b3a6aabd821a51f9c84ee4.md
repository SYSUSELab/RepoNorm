# Rule details

- **Rule:** Flake8 ignores error codes E203, E231, E501, E741, W503, W504, C901, and E731.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
ignore = E203,E231,E501,E741,W503,W504,C901,E731

```

- **Sources:**
  - `setup.cfg:4`
