# Rule details

- **Rule:** The release workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      uses: actions/setup-python@v2
      with:
        python-version: "3.10"

```

- **Sources:**
  - `.github/workflows/release_pypi.yaml:15-17`
