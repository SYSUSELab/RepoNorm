# Rule details

- **Rule:** The dev container enables the nvidia-cuda devcontainer feature with installCudnn set to true.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      "installCudnn": true,

```

- **Sources:**
  - `.devcontainer/devcontainer.json:13`
