# Rule details

- **Rule:**
  ```text
  Coverage measurement omits the listed files that require a GPU or Apple Silicon, the listed models that make API calls, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `outlines/v0_legacy/models/anthropic.py`
  - `outlines/v0_legacy/models/dottxt.py`
  - `outlines/v0_legacy/models/exllamav2.py`
  - `outlines/v0_legacy/models/gemini.py`
  - `outlines/v0_legacy/models/mlxlm.py`
  - `outlines/v0_legacy/models/openai.py`
  - `outlines/v0_legacy/models/vllm_offline.py`
  - `tests/*`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
omit = [
    "outlines/_version.py",
    "outlines/models/anthropic.py",
    "outlines/models/dottxt.py",
    "outlines/models/gemini.py",
    "outlines/models/mlxlm.py",
    "outlines/models/openai.py",
    "outlines/models/vllm_offline.py",
    "outlines/processors/tensor_adapters/mlx.py",
    "outlines/v0_legacy/models/anthropic.py",
    "outlines/v0_legacy/models/dottxt.py",
    "outlines/v0_legacy/models/exllamav2.py",
    "outlines/v0_legacy/models/gemini.py",
    "outlines/v0_legacy/models/mlxlm.py",
    "outlines/v0_legacy/models/openai.py",
    "outlines/v0_legacy/models/vllm_offline.py",
    "tests/*",
]

```

- **Sources:**
  - `pyproject.toml:177-194`
