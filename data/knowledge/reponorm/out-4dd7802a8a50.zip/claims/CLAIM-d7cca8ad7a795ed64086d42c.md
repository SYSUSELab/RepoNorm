# Rule details

- **Rule:**
  ```text
  Changes to the legacy choice_openai function must preserve its JSON schema contract: a single required "result" string enum with additionalProperties False, and suppression of DeprecationWarning while calling the legacy json generator.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/choice.py`
- **Condition:**
  ```text
  When modifying the legacy choice_openai function or its schema construction.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
choice_openai builds a JSON schema with a single required "result" string enum and additionalProperties False, and suppresses DeprecationWarning around the legacy json generator call, matching the r13 schema contract.
```

- **Sources:**
  - `outlines/v0_legacy/generate/choice.py`
