# Rule details

- **Rule:** DSL term operators must normalize operands: adding a string wraps it in String, and reflected add/or place the other operand first, defining the expected Sequence/Alternatives construction order.
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** When modifying or extending DSL term operator tests.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test body asserts a + b == Sequence([a, b]), a + c == Sequence([a, String(c)]), and the reflected __radd__/__ror__ orderings, exactly matching the operand-normalization contract for DSL term operators.
```

- **Sources:**
  - `tests/types/test_dsl.py:149-185`
