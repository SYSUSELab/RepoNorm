# Rule details

- **Rule:** The TGI model wrapper must store the supplied huggingface InferenceClient and pair it with a TGITypeAdapter, delegating type conversion to the dedicated adapter rather than handling it inline.
- **Applies to:**
  - `outlines/models/tgi.py`
- **Condition:** When modifying the TGI model wrapper's initialization or type conversion wiring.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
TGI.__init__ stores the supplied client and pairs it with a TGITypeAdapter, delegating type conversion to the dedicated adapter.
```

- **Sources:**
  - `outlines/models/tgi.py:102-111`
