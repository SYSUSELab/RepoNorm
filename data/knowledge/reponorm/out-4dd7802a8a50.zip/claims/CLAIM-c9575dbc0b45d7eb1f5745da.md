# Rule details

- **Rule:** mypy excludes the "examples" directory from type checking.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
exclude=["examples"]

```

- **Sources:**
  - `pyproject.toml:126`
