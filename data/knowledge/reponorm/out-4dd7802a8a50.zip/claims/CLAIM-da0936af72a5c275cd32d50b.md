# Rule details

- **Rule:**
  ```text
  The async vLLM test must assert that generating with a CFG(YES_NO_GRAMMAR) constraint and max_tokens=10 returns a string restricted to exactly 'yes' or 'no', establishing the expected constrained-output behavior for the async vLLM model.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** When modifying or extending the async vLLM CFG generation test.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The async test awaits async_model("foo?", CFG(YES_NO_GRAMMAR), max_tokens=10) and asserts isinstance(result, str) and result in ["yes", "no"], exactly the constrained-output behavior the rule requires.
```

- **Sources:**
  - `tests/models/test_vllm.py:304-307`
