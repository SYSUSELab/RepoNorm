# Rule details

- **Rule:**
  ```text
  Ollama.generate_stream must mirror generate by injecting kwargs['model'] from self.model_name when absent, passing stream=True, and yielding chunk.response for each chunk.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:**
  ```text
  When modifying Ollama.generate_stream or adding streaming generation to the Ollama adapter.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Ollama.generate_stream injects kwargs['model'] from self.model_name when absent, passes stream=True, and yields chunk.response per chunk, matching the rule.
```

- **Sources:**
  - `outlines/models/ollama.py:173-208`
