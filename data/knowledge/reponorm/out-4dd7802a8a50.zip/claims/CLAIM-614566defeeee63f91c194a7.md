# Rule details

- **Rule:**
  ```text
  The cache decorator must accept expire, typed, and ignore parameters, build its cache key from a key_function if provided or from the decorated function's arguments otherwise, and be based on diskcache's memoize.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:** When modifying the cache decorator or adding caching behavior in outlines/caching.py.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The cache decorator in outlines/caching.py is defined as `def cache(expire: Optional[float] = None, typed=False, ignore=())` and its docstring states the cache key is built from a key_function callable if provided or from the decorated function's arguments otherwise, based on diskcache's memoize, matching the rule.
```

- **Sources:**
  - `outlines/caching.py:86-153`
