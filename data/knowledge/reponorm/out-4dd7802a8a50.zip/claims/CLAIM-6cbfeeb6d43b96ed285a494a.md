# Rule details

- **Rule:** Example scripts that demonstrate tool-calling agents must define the tool function to query the external API and return a processed extract, illustrating the tool-calling pattern used in the react example.
- **Applies to:**
  - `examples/react.py`
- **Condition:** When adding or modifying the react tool-calling example.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The example defines search_wikipedia(query) which queries the Wikipedia API and returns a processed extract (first two sentences joined), illustrating the tool-calling pattern required by the rule.
```

- **Sources:**
  - `examples/react.py`
