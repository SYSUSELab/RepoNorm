# Rule details

- **Rule:** Backend tensor adapters must subclass the shared TensorAdapter base imported from the base tensor adapter module rather than defining an independent adapter type.
- **Applies to:**
  - `outlines/processors/tensor_adapters/numpy.py`
- **Condition:**
  ```text
  when adding or modifying a backend tensor adapter module under tensor_adapters
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The numpy tensor adapter module imports TensorAdapter from the base tensor adapter module and defines NumpyTensorAdapter(TensorAdapter), subclassing the shared base rather than an independent adapter type.
```

- **Sources:**
  - `outlines/processors/tensor_adapters/numpy.py`
