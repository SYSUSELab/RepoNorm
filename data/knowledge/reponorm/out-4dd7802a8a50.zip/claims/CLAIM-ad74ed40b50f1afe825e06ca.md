# Rule details

- **Rule:** The workflow checks out the repository with actions/checkout@v4 using fetch-depth: 0.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0

```

- **Sources:**
  - `.github/workflows/publish_documentation.yml:19-21`
