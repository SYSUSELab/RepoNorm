# Rule details

- **Rule:** The FSM Term dataclass must require its fsm field to be an instance of interegular.fsm.FSM, constraining accepted types for FSM-based output types.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying the FSM Term dataclass or adding FSM-based output types in outlines/types/dsl.py.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The FSM Term dataclass declares its fsm field typed as interegular.fsm.FSM, constraining accepted types as the rule requires.
```

- **Sources:**
  - `outlines/types/dsl.py:288-304`
