# Rule details

- **Rule:**
  ```text
  The release workflow checks that the package version matches the release name by grepping for "^Version: ${GITHUB_REF:10}$" in outlines.egg-info/PKG-INFO.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      run: |
        grep -Rq "^Version: ${GITHUB_REF:10}$" outlines.egg-info/PKG-INFO

```

- **Sources:**
  - `.github/workflows/release_pypi.yaml:21-22`
