# Rule details

- **Rule:**
  ```text
  Tests are run with `uv run pytest -x --cov=outlines`.
  ```
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
    - name: Run tests
      run: |
        uv run pytest -x --cov=outlines

```

- **Sources:**
  - `.github/workflows/tests_nightly.yml:48-50`
