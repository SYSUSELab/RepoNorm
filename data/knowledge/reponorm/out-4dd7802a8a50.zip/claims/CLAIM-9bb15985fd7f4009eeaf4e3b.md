# Rule details

- **Rule:**
  ```text
  get_terminals_info must walk sub-FSMs from an FSM state sequence and return both all terminal infos and the subset whose sub-FSM is in a final state, with PartialTerminalInfo carrying index, terminal name, fsm_reads_more, and in_final.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying get_terminals_info or terminal info extraction in outlines/fsm/parsing.py.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
PartialScanner.get_terminals_info walks sub-FSMs from an FSM state sequence via get_sub_fsms_from_seq, constructs PartialTerminalInfo with index, terminal name, fsm_reads_more, and in_final, and returns both all terminal infos and the subset whose sub-FSM is in a final state. This matches the r4 rule exactly.
```

- **Sources:**
  - `outlines/fsm/parsing.py:591-606`
