# Rule details

- **Rule:**
  ```text
  _compute_termset_fsm_info must group parser states by the ordered tuple of terminal names from each contextual lexer scanner, store each termset's scanner FSM and fsms_to_trans_finals, and record the frozenset of parse states using each termset.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying _compute_termset_fsm_info or termset grouping logic in outlines/fsm/parsing.py.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_compute_termset_fsm_info groups parser states by the ordered tuple of terminal names, stores each termset's scanner FSM and fsms_to_trans_finals, and records the frozenset of parse states per termset.
```

- **Sources:**
  - `outlines/fsm/parsing.py:238-269`
