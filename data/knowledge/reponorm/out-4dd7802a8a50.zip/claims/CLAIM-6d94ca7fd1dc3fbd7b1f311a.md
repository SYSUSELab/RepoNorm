# Rule details

- **Rule:** Contributors may consider opening a Draft PR when work is still in progress but feedback from other contributors is desired.
- **Applies to:**
  - `**`
- **Condition:** when work is still in progress but feedback from other contributors is desired
- **Normative strength:** `recommended`

## Supporting evidence

### Evidence 1 — explicit

```text
Consider opening a **Draft PR** if your work is still in progress but you would
like some feedback from other contributors.

```

- **Sources:**
  - `.github/PULL_REQUEST_TEMPLATE/pull_request_template.md:18-19`
