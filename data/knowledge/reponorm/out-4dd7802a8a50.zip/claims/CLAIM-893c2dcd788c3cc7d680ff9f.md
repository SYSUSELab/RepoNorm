# Rule details

- **Rule:**
  ```text
  When adding a schema renderer, register it with functools.singledispatch on get_schema; the default implementation must continue to raise NotImplementedError naming the unsupported type.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  Adding or modifying a schema renderer registered on get_schema.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
get_schema is a functools.singledispatch whose default raises NotImplementedError naming the unsupported type, and registered renderers preserve that default.
```

- **Sources:**
  - `outlines/templates.py`
