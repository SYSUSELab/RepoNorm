# Rule details

- **Rule:** The parsing example must initialize parser state by parsing an empty string and maintain a states stack plus token sequence/index for incremental parser-state tracking.
- **Applies to:**
  - `examples/parsing.py`
- **Condition:** When modifying the parsing example's parser-state initialization or incremental tracking.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The example initializes parser state via parser.parse("") and maintains states_stack plus token_seq/token_idx for incremental parser-state tracking, matching the rule.
```

- **Sources:**
  - `examples/parsing.py`
