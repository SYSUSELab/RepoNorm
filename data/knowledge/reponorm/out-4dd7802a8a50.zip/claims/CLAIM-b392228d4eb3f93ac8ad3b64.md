# Rule details

- **Rule:** For YAML files, indent size is 2.
- **Applies to:**
  - `**/*.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
indent_size = 2

```

- **Sources:**
  - `.editorconfig:15`
