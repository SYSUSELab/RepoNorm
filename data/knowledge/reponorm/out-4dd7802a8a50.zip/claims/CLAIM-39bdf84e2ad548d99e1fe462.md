# Rule details

- **Rule:**
  ```text
  When modifying the beam-cloud example, preserve the deployment convention that outlines is imported only when `env.is_remote()` is true and models are pre-loaded at container start; do not move heavy imports to unconditional module scope.
  ```
- **Applies to:**
  - `examples/beam-cloud/app.py`
- **Condition:** When editing the beam-cloud example's imports or container-start model loading.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The file imports outlines only inside the env.is_remote() guard and pre-loads models in load_models at container start, preserving the remote-only heavy-import convention.
```

- **Sources:**
  - `examples/beam-cloud/app.py`
