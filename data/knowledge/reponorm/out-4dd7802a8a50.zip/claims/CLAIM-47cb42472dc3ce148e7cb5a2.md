# Rule details

- **Rule:**
  ```text
  Torch tensor adapters must import torch lazily inside __init__ and store it on the instance, avoiding a module-level torch import.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/torch.py`
- **Condition:**
  ```text
  When modifying or adding a torch tensor adapter in outlines/processors/tensor_adapters/torch.py.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
TorchTensorAdapter.__init__ imports torch lazily inside the method body and stores it on the instance, avoiding a module-level torch import.
```

- **Sources:**
  - `outlines/processors/tensor_adapters/torch.py:9-12`
