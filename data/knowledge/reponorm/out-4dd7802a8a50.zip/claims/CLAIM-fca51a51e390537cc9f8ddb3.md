# Rule details

- **Rule:**
  ```text
  When modifying the vLLM offline integration example, keep the tokenizer adaptation via `adapt_tokenizer`, construct `JSONLogitsProcessor` with `tensor_library_name="torch"` and a `whitespace_pattern`, and pass it through `vllm.SamplingParams(logits_processors=[...])`; do not bypass the logits-processor wiring.
  ```
- **Applies to:**
  - `examples/vllm_offline_integration.py`
- **Condition:** When editing the vLLM offline integration example's generation wiring.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
examples/vllm_offline_integration.py adapts the tokenizer via adapt_tokenizer, constructs JSONLogitsProcessor with tensor_library_name="torch" and whitespace_pattern=r" ?", and passes it through vllm.SamplingParams(logits_processors=[logits_processor]), matching the r13 rule.
```

- **Sources:**
  - `examples/vllm_offline_integration.py`
