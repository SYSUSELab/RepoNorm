# Rules for `docs/examples`

## Rule 115 — `docs/examples/**/*.py`

- **Rule:**
  ```text
  Extraction examples must construct the prompt via Template.from_string with the documented variable names and pass the model and output schema to Generator, so the example stays runnable and consistent with the library API.
  ```
- **Applies to:**
  - `docs/examples/**/*.py`
- **Condition:** When adding or modifying an extraction example that loads a model and produces structured output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cccc6f18023891069744ab4a.md)
