# Rules for `environment.yml`

## Rule 003 — `environment.yml`

- **Rule:**
  ```text
  The environment installs the local project in editable mode with its test extras via pip (-e ".[test]").
  ```
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0546bd20f185ba96d4684b2f.md)
