# Rules for `pyproject.toml`

## Rule 062 — `pyproject.toml`

- **Rule:**
  ```text
  The project version is dynamically determined rather than statically declared, as declared by dynamic = ["version"].
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-722778490fcbc51ba2e37ed9.md)
