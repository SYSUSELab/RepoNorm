# Rules for `outlines/v0_legacy/samplers.py`

## Rule 060 — `outlines/v0_legacy/samplers.py`

- **Rule:**
  ```text
  The v0_legacy Sampler base class must declare sampling_params as an abstract property returning SamplingParameters, defining the interface legacy samplers must implement.
  ```
- **Applies to:**
  - `outlines/v0_legacy/samplers.py`
- **Condition:**
  ```text
  When modifying the v0_legacy Sampler base class or adding a new legacy sampler subclass.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6f84862bf295ad16b4d62939.md)
