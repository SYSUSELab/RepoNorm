# Rules for `outlines/v0_legacy/generate/json.py`

## Rule 004 — `outlines/v0_legacy/generate/json.py`

- **Rule:**
  ```text
  Changes to the legacy v0_legacy generate.json function must preserve its deprecation warning (removal in v1.1.0), its routing of OpenAI models to json_openai, and its format_sequence behavior (model_validate_json for Pydantic schemas, pyjson.loads otherwise).
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/json.py`
- **Condition:**
  ```text
  When modifying the legacy json generation function or its format_sequence attachment.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-056d280c5b6ad79007131479.md)

## Rule 108 — `outlines/v0_legacy/generate/json.py`

- **Rule:**
  ```text
  The v0_legacy OpenAI JSON generator must reject any sampler other than multinomial with NotImplementedError and, for Pydantic schemas, set additionalProperties False and wrap the schema in a strict json_schema response_format.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/json.py`
- **Condition:**
  ```text
  When modifying the v0_legacy json_openai generator's sampler validation or Pydantic schema handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c7e69a3d05968ac43051797f.md)
