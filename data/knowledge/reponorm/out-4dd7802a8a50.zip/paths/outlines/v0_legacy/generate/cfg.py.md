# Rules for `outlines/v0_legacy/generate/cfg.py`

## Rule 138 — `outlines/v0_legacy/generate/cfg.py`

- **Rule:** The legacy cfg function must emit a DeprecationWarning stating removal in v1.1.0, raise NotImplementedError for OpenAI and LlamaCpp models, and return GeneratorVisionV0Adapter for TransformersVision but GeneratorV0Adapter otherwise.
- **Applies to:**
  - `outlines/v0_legacy/generate/cfg.py`
- **Condition:** When modifying the legacy cfg function or its model-to-adapter compatibility matrix.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f53a272e12198d07465341bd.md)
