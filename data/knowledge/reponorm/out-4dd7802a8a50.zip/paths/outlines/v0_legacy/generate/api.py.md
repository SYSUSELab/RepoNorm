# Rules for `outlines/v0_legacy/generate/api.py`

## Rule 027 — `outlines/v0_legacy/generate/api.py`

- **Rule:**
  ```text
  Changes to the legacy GeneratorVisionV0Adapter.stream must preserve merging of prompts and media via merge_prompts_and_media before delegating to the parent stream, so vision streaming requires paired prompt/media inputs.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:** When modifying GeneratorVisionV0Adapter.stream or its input handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2fe7b892672f02d7e8b65cdb.md)

## Rule 043 — `outlines/v0_legacy/generate/api.py`

- **Rule:**
  ```text
  The legacy generate API __call__ must mirror input shape in its return: a list of sequences is formatted individually per sequence, while a single sequence is formatted directly.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:**
  ```text
  When modifying GeneratorV0Adapter.__call__ or its result formatting, preserve the list-versus-single return shape mirroring the input.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-54c44d7986ee8028d68ad754.md)
