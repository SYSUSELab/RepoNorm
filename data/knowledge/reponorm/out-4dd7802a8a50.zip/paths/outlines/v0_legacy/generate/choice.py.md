# Rules for `outlines/v0_legacy/generate/choice.py`

## Rule 120 — `outlines/v0_legacy/generate/choice.py`

- **Rule:**
  ```text
  Changes to the legacy choice_openai function must preserve its JSON schema contract: a single required "result" string enum with additionalProperties False, and suppression of DeprecationWarning while calling the legacy json generator.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/choice.py`
- **Condition:**
  ```text
  When modifying the legacy choice_openai function or its schema construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d7cca8ad7a795ed64086d42c.md)
