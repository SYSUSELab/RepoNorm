# Rules for `outlines/v0_legacy/function.py`

## Rule 028 — `outlines/v0_legacy/function.py`

- **Rule:**
  ```text
  Changes to the legacy v0_legacy compatibility surface must keep it separate from the current API: the v0_legacy function module imports from outlines.v0_legacy and outlines.v0_legacy.models.transformers, preserving the legacy API as a distinct compatibility surface.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying imports or module structure of the legacy v0_legacy function module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-35358971bc265b46cedd5b6a.md)

## Rule 075 — `outlines/v0_legacy/function.py`

- **Rule:**
  ```text
  Changes to the legacy download_from_github function must preserve its path validation: require a {USERNAME}/{REPO_NAME}/{PATH_TO_FILE} path with at least three segments, reject paths ending in .py, map HTTP 404 to ValueError, and otherwise call raise_for_status.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying the legacy download_from_github function or its path/HTTP error handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b18d2884c3f122fd8087a8a.md)
