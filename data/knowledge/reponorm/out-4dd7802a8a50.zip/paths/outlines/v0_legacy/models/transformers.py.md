# Rules for `outlines/v0_legacy/models/transformers.py`

## Rule 012 — `outlines/v0_legacy/models/transformers.py`

- **Rule:**
  ```text
  Tokenizer loading in the legacy transformers factory must default padding_side to "left" via setdefault, preserving the repository convention while allowing caller override.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers.py`
- **Condition:** When modifying the legacy transformers tokenizer loading factory or its padding defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1305e9814adab06e58b13bd6.md)

## Rule 085 — `outlines/v0_legacy/models/transformers.py`

- **Rule:**
  ```text
  The legacy transformers function must let an explicit device argument override any device_map entry in model_kwargs, so callers passing both should expect device to win.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers.py`
- **Condition:**
  ```text
  When modifying the legacy transformers function's device handling, preserve the precedence of the explicit device argument over model_kwargs device_map.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-95d1b18abca15660ab13f157.md)
