# Rules for `outlines/v0_legacy/models/transformers_vision.py`

## Rule 013 — `outlines/v0_legacy/models/transformers_vision.py`

- **Rule:**
  ```text
  Changes to the legacy TransformersVision._prepare_model_inputs must preserve formatting input via the type adapter, running the processor with padding=True and return_tensors="pt", moving results to the model device, and returning the original model_input["text"] alongside processed inputs.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers_vision.py`
- **Condition:**
  ```text
  When modifying TransformersVision._prepare_model_inputs or its processor invocation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-1775f32eefea8c63f3ba9f71.md)

## Rule 124 — `outlines/v0_legacy/models/transformers_vision.py`

- **Rule:**
  ```text
  The v0_legacy transformers_vision entry point is deprecated as of v1.0.0 with removal planned in v1.1.0, and its warning must direct users to instantiate TransformersMultiModal via outlines.from_transformers.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers_vision.py`
- **Condition:**
  ```text
  When modifying the v0_legacy transformers_vision entry point or its deprecation warning.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-dcc6323a8ce866280691d1b7.md)
