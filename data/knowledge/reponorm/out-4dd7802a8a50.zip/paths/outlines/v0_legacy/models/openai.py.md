# Rules for `outlines/v0_legacy/models/openai.py`

## Rule 134 — `outlines/v0_legacy/models/openai.py`

- **Rule:**
  ```text
  The legacy azure_openai function must replace the config's model with deployment_name (or build a new OpenAIConfig(model=deployment_name)), so the deployment name overrides any model name in the supplied config.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/openai.py`
- **Condition:**
  ```text
  When modifying the legacy azure_openai function's config handling, preserve deployment_name overriding the model name in the supplied config.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e9d34b9342be986795a5e947.md)

## Rule 136 — `outlines/_version.py`

- **Rule:**
  ```text
  Coverage measurement omits the listed files that require a GPU or Apple Silicon, the listed models that make API calls, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `outlines/v0_legacy/models/anthropic.py`
  - `outlines/v0_legacy/models/dottxt.py`
  - `outlines/v0_legacy/models/exllamav2.py`
  - `outlines/v0_legacy/models/gemini.py`
  - `outlines/v0_legacy/models/mlxlm.py`
  - `outlines/v0_legacy/models/openai.py`
  - `outlines/v0_legacy/models/vllm_offline.py`
  - `tests/*`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-eead5ea0355919bc2b1ae59a.md)
