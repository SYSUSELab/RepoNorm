# Rules for `outlines/fsm/parsing.py`

## Rule 001 — `outlines/fsm/parsing.py`

- **Rule:** PartialParsingFrontend must not reintroduce the commented-out state-transition-map approach, which is documented as 'very wasteful' by a TODO.
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** when modifying PartialParsingFrontend's state-transition handling or considering the commented-out state-transition-map approach
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-01e00617d390b8550440c399.md)

## Rule 041 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  _compute_termset_fsm_info must group parser states by the ordered tuple of terminal names from each contextual lexer scanner, store each termset's scanner FSM and fsms_to_trans_finals, and record the frozenset of parse states using each termset.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying _compute_termset_fsm_info or termset grouping logic in outlines/fsm/parsing.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4f19a960a4afe51513ddc9d0.md)

## Rule 073 — `outlines/fsm/parsing.py`

- **Rule:** PartialScanner must be implemented as a Scanner specialization in outlines/fsm/parsing.py rather than as a separate parser type.
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** when modifying partial-parse scanning or adding scanner behavior in the fsm parsing module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-88246d170310bb7b4f5d77bf.md)

## Rule 091 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  get_terminals_info must walk sub-FSMs from an FSM state sequence and return both all terminal infos and the subset whose sub-FSM is in a final state, with PartialTerminalInfo carrying index, terminal name, fsm_reads_more, and in_final.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying get_terminals_info or terminal info extraction in outlines/fsm/parsing.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9bb15985fd7f4009eeaf4e3b.md)
