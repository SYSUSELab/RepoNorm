# Rules for `outlines/processors/tensor_adapters/numpy.py`

## Rule 064 — `outlines/processors/tensor_adapters/numpy.py`

- **Rule:** Backend tensor adapters must subclass the shared TensorAdapter base imported from the base tensor adapter module rather than defining an independent adapter type.
- **Applies to:**
  - `outlines/processors/tensor_adapters/numpy.py`
- **Condition:**
  ```text
  when adding or modifying a backend tensor adapter module under tensor_adapters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-761abf90d6eef4af28ccde23.md)
