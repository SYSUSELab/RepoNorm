# Rules for `outlines/processors/tensor_adapters/__init__.py`

## Rule 097 — `outlines/processors/tensor_adapters/__init__.py`

- **Rule:** When adding a new tensor backend adapter, register it in the tensor adapter registry dict and extend the adapter Union type so both the runtime lookup and the static type cover the new backend.
- **Applies to:**
  - `outlines/processors/tensor_adapters/__init__.py`
- **Condition:** Adding or renaming a tensor backend adapter in the tensor adapter registry.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-aa1ed1a387bb741edbab750f.md)
