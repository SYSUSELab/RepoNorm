# Rules for `outlines/caching.py`

## Rule 050 — `outlines/caching.py`

- **Rule:**
  ```text
  The cache decorator must accept expire, typed, and ignore parameters, build its cache key from a key_function if provided or from the decorated function's arguments otherwise, and be based on diskcache's memoize.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:** When modifying the cache decorator or adding caching behavior in outlines/caching.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-614566defeeee63f91c194a7.md)
