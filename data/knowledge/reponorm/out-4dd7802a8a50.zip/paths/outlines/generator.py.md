# Rules for `outlines/generator.py`

## Rule 143 — `outlines/generator.py`

- **Rule:**
  ```text
  When changing SteerableGenerator.__init__ output-type dispatch, keep the mapping: CFG terms to CFGLogitsProcessor, FSM terms to RegexGuide.from_interegular_fsm with GuideLogitsProcessor, other terms via to_regex to RegexLogitsProcessor, and None to no logits processor.
  ```
- **Applies to:**
  - `outlines/generator.py`
- **Condition:**
  ```text
  Modifying SteerableGenerator.__init__ output-type-to-processor selection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fe4ef2dd0d6421008c329171.md)
