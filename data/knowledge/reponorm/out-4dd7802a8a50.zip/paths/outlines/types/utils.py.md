# Rules for `outlines/types/utils.py`

## Rule 006 — `outlines/types/utils.py`

- **Rule:**
  ```text
  is_float must recognize a value as float when it is float, when its origin is float, when it is Annotated with float as the first argument, or when it has a __supertype__ attribute equal to float, covering NewType-style wrappers.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  When modifying is_float or adding float type detection in outlines/types/utils.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-08d3cf78bc97134de77482b1.md)
