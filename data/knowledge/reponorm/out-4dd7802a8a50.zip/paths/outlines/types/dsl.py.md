# Rules for `outlines/types/dsl.py`

## Rule 049 — `outlines/types/dsl.py`

- **Rule:** The FSM Term dataclass must require its fsm field to be an instance of interegular.fsm.FSM, constraining accepted types for FSM-based output types.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying the FSM Term dataclass or adding FSM-based output types in outlines/types/dsl.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5ecff7d300fd027b5cf16fe0.md)

## Rule 077 — `outlines/types/dsl.py`

- **Rule:**
  ```text
  FSM.__repr__ must return 'FSM(fsm=<inner repr>)' and CFG.__repr__ must return "CFG(definition='{self.definition}')", fixing the debug representation format for these DSL nodes.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying the debug representation of FSM or CFG DSL nodes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8cb8d9f9b818d3baac351dc6.md)

## Rule 093 — `outlines/types/dsl.py`

- **Rule:**
  ```text
  The Sequence DSL node's __repr__ must return the exact format 'Sequence(terms=...)' containing the repr of its terms list, preserving the debug representation contract for this DSL node.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  When modifying or adding a DSL node class in outlines/types/dsl.py that defines __repr__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a7784f073327a0956430e830.md)
