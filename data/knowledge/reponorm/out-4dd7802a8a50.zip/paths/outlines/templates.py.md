# Rules for `outlines/templates.py`

## Rule 030 — `outlines/templates.py`

- **Rule:**
  ```text
  When modifying parse_pydantic_schema, preserve recursive $ref resolution: nested $ref entries are resolved by splitting the ref string on '/' and indexing definitions[refs[2]], using the property description when present and falling back to '<name>' otherwise.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  changing how parse_pydantic_schema resolves nested Pydantic model schemas or $ref entries
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-381b4996ed898b2c9d33f1fc.md)

## Rule 070 — `outlines/templates.py`

- **Rule:**
  ```text
  When changing get_fn_source, preserve the contract that non-callables raise TypeError and that source extraction starts at the first def, since callers rely on this source-filter behavior.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  Modifying get_fn_source's handling of non-callables or its source extraction starting point.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-84f3eecae97287342d960c44.md)

## Rule 074 — `outlines/templates.py`

- **Rule:**
  ```text
  When adding a schema renderer, register it with functools.singledispatch on get_schema; the default implementation must continue to raise NotImplementedError naming the unsupported type.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  Adding or modifying a schema renderer registered on get_schema.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-893c2dcd788c3cc7d680ff9f.md)
