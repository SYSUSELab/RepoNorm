# Rules for `outlines/models/ollama.py`

## Rule 052 — `outlines/models/ollama.py`

- **Rule:**
  ```text
  Ollama.generate_stream must mirror generate by injecting kwargs['model'] from self.model_name when absent, passing stream=True, and yielding chunk.response for each chunk.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:**
  ```text
  When modifying Ollama.generate_stream or adding streaming generation to the Ollama adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-65f465d37b9a6cce9a1d9b2d.md)
