# Rules for `outlines/models/sglang.py`

## Rule 022 — `outlines/models/sglang.py`

- **Rule:**
  ```text
  When modifying AsyncSGLang.generate_stream, preserve the streaming protocol: build client args via _build_client_args, call chat.completions.create with stream=True, and yield only chunk.choices[0].delta.content when present, skipping chunks without choices or content.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:**
  ```text
  changing the streaming loop or chunk handling in AsyncSGLang.generate_stream
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29d94343d49e3e32f8fea57b.md)
