# Rules for `outlines/models/vllm.py`

## Rule 063 — `outlines/models/openai.py`

- **Rule:** The OpenAI and AsyncVLLM model wrappers must remain thin wrappers around the openai.OpenAI client whose purpose is converting user-specified input and output types into client arguments, rather than implementing generation logic themselves.
- **Applies to:**
  - `outlines/models/openai.py`
  - `outlines/models/vllm.py`
- **Condition:** When modifying the OpenAI or AsyncVLLM model wrappers' responsibilities or client interaction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-74459009088dc3b7fdd4825f.md)
