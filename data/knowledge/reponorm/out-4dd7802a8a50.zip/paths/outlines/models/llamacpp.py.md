# Rules for `outlines/models/llamacpp.py`

## Rule 088 — `outlines/models/llamacpp.py`

- **Rule:**
  ```text
  LlamaCppTypeAdapter must prepare arguments to llama-cpp-python's Llama.__call__ as the string prompt plus a LogitsProcessorList, preserving the adapter's argument-shaping contract.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  When modifying LlamaCppTypeAdapter or its argument preparation for Llama.__call__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9a754cd462f9b5fc6d819389.md)
