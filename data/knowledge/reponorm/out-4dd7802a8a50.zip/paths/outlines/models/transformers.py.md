# Rules for `outlines/models/transformers.py`

## Rule 014 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  The transformers tokenizer's __getstate__ must return only {'tokenizer': self.tokenizer}, intentionally excluding other model state from pickling.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying the transformers tokenizer's pickling or serialization state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-184b37d555dc580672017f05.md)

## Rule 051 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  _generate_output_seq must slice decoder-only output_ids to drop the prompt prefix while keeping encoder-decoder output_ids whole, and reshape to (batch_size, num_samples, -1) when num_return_sequences > 1 with list prompts.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying _generate_output_seq or output-shaping logic in the transformers model adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-65e056fb96e0549ce6cc2c88.md)

## Rule 066 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  The transformers model's _prepare_model_inputs must format input via the type adapter, encode prompts into input_ids and attention_mask, and move both tensors to self.model.device before returning them alongside the prompts.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying transformers model input preparation or device placement.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7a18f13205b209040e223e11.md)

## Rule 137 — `outlines/models/transformers.py`

- **Rule:** The registered dict input formatter must raise ValueError when the input dict lacks a 'text' key, enforcing that multimodal dict inputs include 'text'.
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying or adding a dict input formatter for multimodal inputs in the transformers model adapter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f12276866d674e8e354fd1bf.md)
