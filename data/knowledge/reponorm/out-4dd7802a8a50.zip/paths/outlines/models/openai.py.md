# Rules for `outlines/models/openai.py`

## Rule 055 — `outlines/models/openai.py`

- **Rule:**
  ```text
  Model adapters that wrap a legacy or third-party client object must delegate __str__ to the stored wrapped instance when present, falling back to super().__str__() otherwise, so string rendering of the adapter reflects the wrapped client.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When modifying or adding a model adapter class that stores a wrapped legacy client instance and defines __str__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-68124ed91123dd086e1aca86.md)

## Rule 063 — `outlines/models/openai.py`

- **Rule:** The OpenAI and AsyncVLLM model wrappers must remain thin wrappers around the openai.OpenAI client whose purpose is converting user-specified input and output types into client arguments, rather than implementing generation logic themselves.
- **Applies to:**
  - `outlines/models/openai.py`
  - `outlines/models/vllm.py`
- **Condition:** When modifying the OpenAI or AsyncVLLM model wrappers' responsibilities or client interaction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-74459009088dc3b7fdd4825f.md)

## Rule 136 — `outlines/_version.py`

- **Rule:**
  ```text
  Coverage measurement omits the listed files that require a GPU or Apple Silicon, the listed models that make API calls, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `outlines/v0_legacy/models/anthropic.py`
  - `outlines/v0_legacy/models/dottxt.py`
  - `outlines/v0_legacy/models/exllamav2.py`
  - `outlines/v0_legacy/models/gemini.py`
  - `outlines/v0_legacy/models/mlxlm.py`
  - `outlines/v0_legacy/models/openai.py`
  - `outlines/v0_legacy/models/vllm_offline.py`
  - `tests/*`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eead5ea0355919bc2b1ae59a.md)
