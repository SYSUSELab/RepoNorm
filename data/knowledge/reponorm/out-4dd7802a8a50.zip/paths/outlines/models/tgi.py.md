# Rules for `outlines/models/tgi.py`

## Rule 092 — `outlines/models/tgi.py`

- **Rule:** The TGI model wrapper must store the supplied huggingface InferenceClient and pair it with a TGITypeAdapter, delegating type conversion to the dedicated adapter rather than handling it inline.
- **Applies to:**
  - `outlines/models/tgi.py`
- **Condition:** When modifying the TGI model wrapper's initialization or type conversion wiring.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a1ffcfd89482fd8fb756bbfe.md)

## Rule 100 — `outlines/models/tgi.py`

- **Rule:**
  ```text
  TGITypeAdapter.format_input must be a singledispatchmethod whose base implementation raises NotImplementedError instructing that only string input is supported with TGI, defining the extension point for input type handling.
  ```
- **Applies to:**
  - `outlines/models/tgi.py`
- **Condition:**
  ```text
  When modifying TGITypeAdapter.format_input or adding input type handling for TGI.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ae2f0d118e878af437d16108.md)
