# Rules for `.devcontainer/devcontainer.json`

## Rule 009 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the conda devcontainer feature.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0ea9194b677ac20f761801f4.md)

## Rule 019 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the nvidia-cuda devcontainer feature with cudaVersion 12.4.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-27f428c1d190cfcbd772196a.md)

## Rule 023 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the nvidia-cuda devcontainer feature with installCudnn set to true.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-2bed7940b4dd13c070a4fe93.md)

## Rule 071 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container declares GPU host requirements as optional.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-85813bdfe4d61e26edeed66f.md)

## Rule 079 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container runs with the --device=nvidia.com/gpu=all argument.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8e7205735bf08bb76890d834.md)

## Rule 080 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the rust devcontainer feature.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-90490a81539988b1d009daf2.md)

## Rule 096 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container is based on the mcr.microsoft.com/devcontainers/python:3.12 image.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a9adc92d25fec285c450a8c8.md)
