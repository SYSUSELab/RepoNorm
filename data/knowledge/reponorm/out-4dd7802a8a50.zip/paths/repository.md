# Rules for `repository root`

## Rule 016 — `**`

- **Rule:** The tests job installs Ollama and pulls the tinyllama model.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1e74ed1d8215c01cec5fd12f.md)

## Rule 017 — `**`

- **Rule:** For all files, line endings use LF.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1f810053009293fef7d44798.md)

## Rule 018 — `**`

- **Rule:** EditorConfig is rooted at this file (root = true), so this file is the top-most EditorConfig configuration.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-203b41f4e1d980128dcea7a5.md)

## Rule 020 — `**/*.py`

- **Rule:** Flake8 ignores error codes E203, E231, E501, E741, W503, W504, C901, and E731.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28b3a6aabd821a51f9c84ee4.md)

## Rule 021 — `**`

- **Rule:** For all files, a final newline is inserted.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28b762ae997fb1fac293857d.md)

## Rule 032 — `**/*.py`

- **Rule:** Ruff lint ignores the E731 and F401 rules.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-3a7093ad62eb23a72bc92c98.md)

## Rule 047 — `**`

- **Rule:**
  ```text
  The tests job runs pytest with -x, coverage over the outlines package, and excludes tests marked api_call.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-59b49aea7dd00a0bef03f9de.md)

## Rule 048 — `**/*.py`

- **Rule:**
  ```text
  The project declares a supported Python version range of >=3.9,<3.13 via requires-python.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5cec4ad4de4dddd52e29f96e.md)

## Rule 059 — `**`

- **Rule:** Contributors may consider opening a Draft PR when work is still in progress but feedback from other contributors is desired.
- **Applies to:**
  - `**`
- **Condition:** when work is still in progress but feedback from other contributors is desired
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-6d94ca7fd1dc3fbd7b1f311a.md)

## Rule 069 — `**/*.py`

- **Rule:** Flake8 enforces a maximum line length of 88 characters.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-84acc8fcdeab7f3ccfb683b2.md)

## Rule 086 — `**/__init__.py`

- **Rule:**
  ```text
  Flake8 ignores F401 and F403 in __init__.py files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-96de3480249351958a08f254.md)

## Rule 104 — `**/*.yaml`

- **Rule:** For YAML files, indent size is 2.
- **Applies to:**
  - `**/*.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b392228d4eb3f93ac8ad3b64.md)

## Rule 125 — `**/*.py`

- **Rule:**
  ```text
  Coverage excludes lines matching "pragma: no cover", "if TYPE_CHECKING:", and "\\.\\.\\." from coverage measurement.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e0578452b76f2d5f764c7b99.md)

## Rule 129 — `**`

- **Rule:** The coverage job uploads the htmlcov directory as the html-report artifact only when the job has failed.
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: ${{ failure() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e64684742e8cae00ed3726d3.md)

## Rule 133 — `**`

- **Rule:** For all files, trailing whitespace is trimmed.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e8ae57cb96ec6d370fc12f41.md)
