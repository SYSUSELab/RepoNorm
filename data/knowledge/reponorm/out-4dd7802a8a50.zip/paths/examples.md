# Rules for `examples`

## Rule 033 — `examples/**`

- **Rule:** The mypy pre-commit hook excludes files under the examples/ directory.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3dc5cbe1b4a1c237ddca3c41.md)

## Rule 110 — `examples/**`

- **Rule:** mypy excludes the "examples" directory from type checking.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c9575dbc0b45d7eb1f5745da.md)
