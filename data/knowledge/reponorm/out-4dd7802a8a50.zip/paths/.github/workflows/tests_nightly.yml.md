# Rules for `.github/workflows/tests_nightly.yml`

## Rule 005 — `.github/workflows/tests_nightly.yml`

- **Rule:** On failure, the workflow sends a Slack notification using 8398a7/action-slack@v3 with the job status and commit, author, and ref fields.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Condition:** workflow predicate: failure()
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-072b7c6d4dee40f42ce4eabe.md)

## Rule 087 — `.github/workflows/tests_nightly.yml`

- **Rule:** The test environment is set up by upgrading pip, installing uv, creating a uv venv, and installing the package in editable mode with the test extra.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9955fd1044f9e17b67b409c5.md)

## Rule 105 — `.github/workflows/tests_nightly.yml`

- **Rule:**
  ```text
  Tests are run with `uv run pytest -x --cov=outlines`.
  ```
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bbf738bc6c074a2a320bf36a.md)

## Rule 131 — `.github/workflows/tests_nightly.yml`

- **Rule:** The workflow installs Ollama by running the install script, checking the version, and pulling the tinyllama model.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e78d68dcb12668e0d8ca91a2.md)
