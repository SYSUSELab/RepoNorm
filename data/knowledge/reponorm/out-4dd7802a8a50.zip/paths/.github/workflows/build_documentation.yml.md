# Rules for `.github/workflows/build_documentation.yml`

## Rule 126 — `.github/workflows/build_documentation.yml`

- **Rule:**
  ```text
  The documentation build step installs requirements-doc.txt via pip and runs mkdocs build, with GOOGLE_ANALYTICS_KEY supplied from the GOOGLE_ANALYTICS_KEY secret.
  ```
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e11cd27d5030b9dd1a3ba4d4.md)
