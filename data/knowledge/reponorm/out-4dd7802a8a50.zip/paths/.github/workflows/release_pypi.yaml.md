# Rules for `.github/workflows/release_pypi.yaml`

## Rule 090 — `.github/workflows/release_pypi.yaml`

- **Rule:** The release workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9b905a7be54461bccee8c939.md)

## Rule 117 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow checks that the package version matches the release name by grepping for "^Version: ${GITHUB_REF:10}$" in outlines.egg-info/PKG-INFO.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cfc567b88d496463edca12a8.md)

## Rule 132 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow builds the SDist and wheel by running ./.github/scripts/build_sdist_and_wheel.sh.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e86b2a82b5c63c9b829d552c.md)

## Rule 140 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow publishes to PyPI using pypa/gh-action-pypi-publish with user __token__ and password from secrets.PYPI_TOKEN.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f983e979d6bc61911b9518a7.md)
