# Rules for `.github/workflows/asv_benchmark_pr.yml`

## Rule 083 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow runs asv continuous comparing upstream/main to HEAD with --no-stats --interleave-rounds -a repeat=3, tolerating errors.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-91c0fd0bd91874aa837dd690.md)

## Rule 119 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow installs asv, virtualenv, and lf-asv-formatter as dependencies.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d3eec24436358cbcb281e794.md)
