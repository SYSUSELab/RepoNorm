# Rules for `SUMMARY.md`

## Rule 101 — `SUMMARY.md`

- **Rule:** The literate-nav plugin uses SUMMARY.md as the navigation file.
- **Applies to:**
  - `SUMMARY.md`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b0c663ba882057068484d8b1.md)
