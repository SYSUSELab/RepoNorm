# Rules for `scripts/gen_ref_pages.py`

## Rule 007 — `scripts/gen_ref_pages.py`

- **Rule:**
  ```text
  The gen-files plugin runs the script scripts/gen_ref_pages.py during the documentation build.
  ```
- **Applies to:**
  - `scripts/gen_ref_pages.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0a74e8c60694a2ccb9164ed1.md)

## Rule 056 — `scripts/gen_ref_pages.py`

- **Rule:**
  ```text
  API reference page generation must skip modules whose path parts include `_version` or `v0_legacy`, keeping legacy code intentionally undocumented in the generated API reference.
  ```
- **Applies to:**
  - `scripts/gen_ref_pages.py`
- **Condition:**
  ```text
  When modifying the API reference page generation logic in scripts/gen_ref_pages.py, preserve the exclusion of modules whose path parts include `_version` or `v0_legacy`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-68fb2714f63e6d4ad4540ed8.md)
