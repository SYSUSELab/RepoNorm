# Rules for `examples/react.py`

## Rule 058 — `examples/react.py`

- **Rule:** Example scripts that demonstrate tool-calling agents must define the tool function to query the external API and return a processed extract, illustrating the tool-calling pattern used in the react example.
- **Applies to:**
  - `examples/react.py`
- **Condition:** When adding or modifying the react tool-calling example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6cbfeeb6d43b96ed285a494a.md)
