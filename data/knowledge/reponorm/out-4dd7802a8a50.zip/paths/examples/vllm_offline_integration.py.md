# Rules for `examples/vllm_offline_integration.py`

## Rule 142 — `examples/vllm_offline_integration.py`

- **Rule:**
  ```text
  When modifying the vLLM offline integration example, keep the tokenizer adaptation via `adapt_tokenizer`, construct `JSONLogitsProcessor` with `tensor_library_name="torch"` and a `whitespace_pattern`, and pass it through `vllm.SamplingParams(logits_processors=[...])`; do not bypass the logits-processor wiring.
  ```
- **Applies to:**
  - `examples/vllm_offline_integration.py`
- **Condition:** When editing the vLLM offline integration example's generation wiring.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fca51a51e390537cc9f8ddb3.md)
