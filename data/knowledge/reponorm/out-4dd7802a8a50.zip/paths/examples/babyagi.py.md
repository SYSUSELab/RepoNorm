# Rules for `examples/babyagi.py`

## Rule 068 — `examples/babyagi.py`

- **Rule:** Example task-list parsing must split on newlines and then on the first '.', keeping only lines that contain a period and stripping the numeric prefix; lines without a period are silently dropped.
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When modifying task-list parsing or formatting in the BabyAGI example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-80f6727ea50c9a918df48d21.md)

## Rule 114 — `examples/babyagi.py`

- **Rule:** Example scripts that demonstrate a bounded agent loop must document the fixed cycle limit and the absence of vector-store retrieval, bounding the example's demonstrated scope.
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When adding or modifying the babyagi example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cca7eec6258ffc1f9bca94ab.md)

## Rule 128 — `examples/babyagi.py`

- **Rule:**
  ```text
  The BabyAGI one_cycle example must pop the highest-priority task, complete it, create new tasks from the result with incrementing task ids, re-prioritize the task list, and return the executed task, result, prioritized tasks, and updated next_task_id.
  ```
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:**
  ```text
  When modifying the BabyAGI one_cycle task-execution loop.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e62e3ba232eef1f3b8b05c41.md)
