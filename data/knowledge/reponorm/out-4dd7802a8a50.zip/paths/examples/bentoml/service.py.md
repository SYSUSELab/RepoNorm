# Rules for `examples/bentoml/service.py`

## Rule 029 — `examples/bentoml/service.py`

- **Rule:**
  ```text
  Example scripts that demonstrate structured generation in a deployment service must construct the generator with outlines.json_schema(json_schema) and call it with the prompt, returning the generated result.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
  - `examples/cerebrium/main.py`
- **Condition:** When adding or modifying a deployment example that demonstrates structured generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-36c7198011fb92adf9b269df.md)

## Rule 099 — `examples/bentoml/service.py`

- **Rule:**
  ```text
  When modifying the BentoML service example, keep the declared deployment resource requirements: a 300-second traffic timeout, one `nvidia-l4` GPU, and `bento_model_ref` bound via `bentoml.models.get(BENTO_MODEL_TAG)`.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
- **Condition:** When editing the BentoML service example's deployment configuration or model binding.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ae01a741160e2a42a5841494.md)
