# Rules for `examples/math_generate_code.py`

## Rule 116 — `examples/math_generate_code.py`

- **Rule:**
  ```text
  Example scripts that demonstrate code generation followed by execution must build the prompt via Template.from_string with question/code few-shot examples, call the model, and execute the returned code with execute_code.
  ```
- **Applies to:**
  - `examples/math_generate_code.py`
- **Condition:** When adding or modifying the math code-generation example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ce75c268a23a2f2877214422.md)
