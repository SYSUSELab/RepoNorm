# Rules for `tests/types/test_dsl.py`

## Rule 057 — `tests/types/test_dsl.py`

- **Rule:**
  ```text
  The CFG type must strip the definition, expose `_display_node` as `CFG('<definition>')`, `__repr__` as `CFG(definition='<definition>')`, and implement value-based equality against other CFG instances but not strings.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** when adding or modifying CFG display or equality tests in the DSL type tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6acb5319946960b41636668f.md)

## Rule 089 — `tests/types/test_dsl.py`

- **Rule:**
  ```text
  The DSL test module must define a nested `PydanticModel` with fields `a: int` and `b: str`, providing a concrete Pydantic model used to exercise DSL handling of Pydantic types.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** when adding or modifying DSL tests that exercise Pydantic type handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9a78b6649e342313893b8075.md)

## Rule 106 — `tests/types/test_dsl.py`

- **Rule:**
  ```text
  Every DSL term type (String, Regex, JsonSchema, KleeneStar/Plus, Optional, Alternatives, Sequence, and Quantify variants) must have a stable repr and a display_ascii_tree rendering with specific box-drawing output, and QuantifyBetween must reject max_count < min_count with a ValueError.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** When modifying or extending DSL term repr, tree rendering, or QuantifyBetween validation tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bec59a09f2e2b29b0d883591.md)

## Rule 109 — `tests/types/test_dsl.py`

- **Rule:** DSL term operators must normalize operands: adding a string wraps it in String, and reflected add/or place the other operand first, defining the expected Sequence/Alternatives construction order.
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** When modifying or extending DSL term operator tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c94afd7ae7af88d75700b049.md)
