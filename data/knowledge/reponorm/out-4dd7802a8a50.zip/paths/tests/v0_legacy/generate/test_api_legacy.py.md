# Rules for `tests/v0_legacy/generate/test_api_legacy.py`

## Rule 025 — `tests/v0_legacy/generate/test_api_legacy.py`

- **Rule:** Tests that exercise a model adapter's streaming entry point for a vision (v0) adapter must expect NotImplementedError with the message 'Streaming is not implemented for Transformers models'; do not add streaming support expectations for vision adapters without changing that contract.
- **Applies to:**
  - `tests/v0_legacy/generate/test_api_legacy.py`
- **Condition:** When modifying or extending the legacy v0 vision adapter streaming test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2f87e2fe817d40b44ac8c78b.md)
