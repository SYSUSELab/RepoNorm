# Rules for `tests/models/test_llamacpp_type_adapter.py`

## Rule 112 — `tests/models/test_llamacpp_type_adapter.py`

- **Rule:**
  ```text
  The llamacpp type adapter test module must import llama_cpp and LogitsProcessorList alongside LlamaCppTypeAdapter, LlamaCppTokenizer, and RegexLogitsProcessor, testing the adapter against the real llama_cpp logits-processor interface.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_type_adapter.py`
- **Condition:** When modifying or extending the llamacpp type adapter test module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cb4fba7517c54e39bc689557.md)
