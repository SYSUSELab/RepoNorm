# Rules for `tests/models/test_llamacpp_tokenizer.py`

## Rule 127 — `tests/models/test_llamacpp_tokenizer.py`

- **Rule:**
  ```text
  Tests for LlamaCppTokenizer.encode must assert that list (batch) inputs raise NotImplementedError while single-string inputs return token_ids and attention_mask of equal length, documenting the batch-unsupported boundary.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when modifying LlamaCppTokenizer.encode or the tests that pin its batch behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e4453aeca699961dc8a7462f.md)
