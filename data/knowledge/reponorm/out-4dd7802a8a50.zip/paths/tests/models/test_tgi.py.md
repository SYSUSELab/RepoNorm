# Rules for `tests/models/test_tgi.py`

## Rule 010 — `tests/models/test_tgi.py`

- **Rule:**
  ```text
  The TGI test module must select a real InferenceClient/AsyncInferenceClient when TGI_SERVER_URL is set, otherwise warn and fall back to MockTGIInferenceClient/MockAsyncTGIInferenceClient, and only register mock_responses on the mock clients when no server URL is provided.
  ```
- **Applies to:**
  - `tests/models/test_tgi.py`
- **Condition:** When modifying or extending the TGI test module's client selection and mock setup.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0eef4ff804618f7ef90640db.md)
