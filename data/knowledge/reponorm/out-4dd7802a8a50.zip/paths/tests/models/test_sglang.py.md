# Rules for `tests/models/test_sglang.py`

## Rule 045 — `tests/models/test_sglang.py`

- **Rule:**
  ```text
  The SGLang test module must provide a `sync_model` fixture that constructs `SGLang(openai_client, model_name=sglang_model_name)` as the shared client/model setup for SGLang tests.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** When modifying or extending SGLang test fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-593e399f822fd9dd9604a846.md)
