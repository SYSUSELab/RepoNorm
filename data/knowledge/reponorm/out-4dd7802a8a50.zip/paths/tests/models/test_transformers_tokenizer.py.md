# Rules for `tests/models/test_transformers_tokenizer.py`

## Rule 040 — `tests/models/test_transformers_tokenizer.py`

- **Rule:**
  ```text
  The tokenizer_seq2seq fixture must construct its tokenizer via transformers.AutoTokenizer.from_pretrained using the module-level TEST_MODEL_SEQ2SEQ constant rather than a hard-coded model name.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:**
  ```text
  when modifying the tokenizer_seq2seq fixture or adding seq2seq tokenizer tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4df85e330c0deca54e3eaa23.md)

## Rule 130 — `tests/models/test_transformers_tokenizer.py`

- **Rule:**
  ```text
  Tests for TransformerTokenizer must pin the equality and hash contract: __eq__ returns NotImplemented for non-tokenizer objects and compares model_name and kwargs, and hash is an int that is equal for tokenizers built from the same configuration and different for a seq2seq tokenizer.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** when modifying TransformerTokenizer equality or hash behavior, or the tests that pin it
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e74a5bd002e7d0e5782784f1.md)
