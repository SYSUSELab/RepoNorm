# Rules for `tests/models/test_vllm.py`

## Rule 081 — `tests/models/test_vllm.py`

- **Rule:** The vLLM vision test image fixture must build a 256x256 RGB white PNG in memory and reopen it from the BytesIO buffer, supplying vision inputs without on-disk assets.
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when modifying the vLLM vision test image fixture or adding vision inputs to vLLM tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-907ab6aaab6642eb075ccbf0.md)

## Rule 121 — `tests/models/test_vllm.py`

- **Rule:**
  ```text
  The async vLLM test must assert that generating with a CFG(YES_NO_GRAMMAR) constraint and max_tokens=10 returns a string restricted to exactly 'yes' or 'no', establishing the expected constrained-output behavior for the async vLLM model.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** When modifying or extending the async vLLM CFG generation test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-da0936af72a5c275cd32d50b.md)
