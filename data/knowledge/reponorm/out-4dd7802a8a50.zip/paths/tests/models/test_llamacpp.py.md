# Rules for `tests/models/test_llamacpp.py`

## Rule 008 — `tests/models/test_llamacpp.py`

- **Rule:** Tests for LlamaCpp streaming choice must assert that the first streamed token is one of the allowed Literal values, preserving constrained streaming output membership.
- **Applies to:**
  - `tests/models/test_llamacpp.py`
- **Condition:** When modifying or extending the LlamaCpp streaming choice test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0cdc11c95afe77d1238ec602.md)
