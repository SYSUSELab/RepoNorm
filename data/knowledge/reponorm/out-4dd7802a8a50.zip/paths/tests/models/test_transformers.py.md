# Rules for `tests/models/test_transformers.py`

## Rule 084 — `tests/models/test_transformers.py`

- **Rule:** The transformers JSON test must assert that generating with a Pydantic Character model yields a result containing the 'name' field, verifying structured JSON output includes declared fields.
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** When modifying or extending the transformers JSON structured output test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-95895d15803fb3b53db4b33d.md)
