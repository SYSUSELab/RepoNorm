# Full rule catalog

## Rule 051 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  _generate_output_seq must slice decoder-only output_ids to drop the prompt prefix while keeping encoder-decoder output_ids whole, and reshape to (batch_size, num_samples, -1) when num_return_sequences > 1 with list prompts.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  When modifying _generate_output_seq or output-shaping logic in the transformers model adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-65e056fb96e0549ce6cc2c88.md)

## Rule 052 — `outlines/models/ollama.py`

- **Rule:**
  ```text
  Ollama.generate_stream must mirror generate by injecting kwargs['model'] from self.model_name when absent, passing stream=True, and yielding chunk.response for each chunk.
  ```
- **Applies to:**
  - `outlines/models/ollama.py`
- **Condition:**
  ```text
  When modifying Ollama.generate_stream or adding streaming generation to the Ollama adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-65f465d37b9a6cce9a1d9b2d.md)

## Rule 053 — `.github/workflows/publish_documentation.yml`

- **Rule:**
  ```text
  When the event is a release, the workflow runs mike deploy --push --update-aliases ${{ github.ref_name }} latest and mike set-default --push latest, with GOOGLE_ANALYTICS_KEY set from secrets.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'release'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-66df36327254f2fc35b9eff1.md)

## Rule 054 — `outlines/models/anthropic.py`

- **Rule:**
  ```text
  Anthropic generation must not support structured output: passing a non-None output_type must raise NotImplementedError, and the return value must be the first content block's text.
  ```
- **Applies to:**
  - `outlines/models/anthropic.py`
- **Condition:** When modifying Anthropic.generate or adding structured-output handling to the Anthropic model adapter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-679c0f25e674f64f6ad74c1e.md)

## Rule 055 — `outlines/models/openai.py`

- **Rule:**
  ```text
  Model adapters that wrap a legacy or third-party client object must delegate __str__ to the stored wrapped instance when present, falling back to super().__str__() otherwise, so string rendering of the adapter reflects the wrapped client.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When modifying or adding a model adapter class that stores a wrapped legacy client instance and defines __str__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-68124ed91123dd086e1aca86.md)

## Rule 056 — `scripts/gen_ref_pages.py`

- **Rule:**
  ```text
  API reference page generation must skip modules whose path parts include `_version` or `v0_legacy`, keeping legacy code intentionally undocumented in the generated API reference.
  ```
- **Applies to:**
  - `scripts/gen_ref_pages.py`
- **Condition:**
  ```text
  When modifying the API reference page generation logic in scripts/gen_ref_pages.py, preserve the exclusion of modules whose path parts include `_version` or `v0_legacy`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-68fb2714f63e6d4ad4540ed8.md)

## Rule 057 — `tests/types/test_dsl.py`

- **Rule:**
  ```text
  The CFG type must strip the definition, expose `_display_node` as `CFG('<definition>')`, `__repr__` as `CFG(definition='<definition>')`, and implement value-based equality against other CFG instances but not strings.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** when adding or modifying CFG display or equality tests in the DSL type tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6acb5319946960b41636668f.md)

## Rule 058 — `examples/react.py`

- **Rule:** Example scripts that demonstrate tool-calling agents must define the tool function to query the external API and return a processed extract, illustrating the tool-calling pattern used in the react example.
- **Applies to:**
  - `examples/react.py`
- **Condition:** When adding or modifying the react tool-calling example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6cbfeeb6d43b96ed285a494a.md)

## Rule 059 — `**`

- **Rule:** Contributors may consider opening a Draft PR when work is still in progress but feedback from other contributors is desired.
- **Applies to:**
  - `**`
- **Condition:** when work is still in progress but feedback from other contributors is desired
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-6d94ca7fd1dc3fbd7b1f311a.md)

## Rule 060 — `outlines/v0_legacy/samplers.py`

- **Rule:**
  ```text
  The v0_legacy Sampler base class must declare sampling_params as an abstract property returning SamplingParameters, defining the interface legacy samplers must implement.
  ```
- **Applies to:**
  - `outlines/v0_legacy/samplers.py`
- **Condition:**
  ```text
  When modifying the v0_legacy Sampler base class or adding a new legacy sampler subclass.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6f84862bf295ad16b4d62939.md)

## Rule 061 — `outlines/v0_legacy/models/exllamav2.py`

- **Rule:**
  ```text
  The legacy ExLlamaV2 generate_stream must enqueue each prompt in a batch as a separate ExLlamaV2DynamicJob with a shared seed incremented per prompt when not None, and must map job serials back to original prompt indices via an order dict.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying ExLlamaV2Model.generate_stream for batched streaming, preserve per-prompt seed incrementing and the serial-to-original-index mapping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-70a174a3c5f75f5c7ed8ebc9.md)

## Rule 062 — `pyproject.toml`

- **Rule:**
  ```text
  The project version is dynamically determined rather than statically declared, as declared by dynamic = ["version"].
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-722778490fcbc51ba2e37ed9.md)

## Rule 063 — `outlines/models/openai.py`

- **Rule:** The OpenAI and AsyncVLLM model wrappers must remain thin wrappers around the openai.OpenAI client whose purpose is converting user-specified input and output types into client arguments, rather than implementing generation logic themselves.
- **Applies to:**
  - `outlines/models/openai.py`
  - `outlines/models/vllm.py`
- **Condition:** When modifying the OpenAI or AsyncVLLM model wrappers' responsibilities or client interaction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-74459009088dc3b7fdd4825f.md)

## Rule 064 — `outlines/processors/tensor_adapters/numpy.py`

- **Rule:** Backend tensor adapters must subclass the shared TensorAdapter base imported from the base tensor adapter module rather than defining an independent adapter type.
- **Applies to:**
  - `outlines/processors/tensor_adapters/numpy.py`
- **Condition:**
  ```text
  when adding or modifying a backend tensor adapter module under tensor_adapters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-761abf90d6eef4af28ccde23.md)
