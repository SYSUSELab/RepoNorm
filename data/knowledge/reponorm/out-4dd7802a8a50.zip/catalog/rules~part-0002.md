# Full rule catalog

## Rule 019 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the nvidia-cuda devcontainer feature with cudaVersion 12.4.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-27f428c1d190cfcbd772196a.md)

## Rule 020 — `**/*.py`

- **Rule:** Flake8 ignores error codes E203, E231, E501, E741, W503, W504, C901, and E731.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28b3a6aabd821a51f9c84ee4.md)

## Rule 021 — `**`

- **Rule:** For all files, a final newline is inserted.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28b762ae997fb1fac293857d.md)

## Rule 022 — `outlines/models/sglang.py`

- **Rule:**
  ```text
  When modifying AsyncSGLang.generate_stream, preserve the streaming protocol: build client args via _build_client_args, call chat.completions.create with stream=True, and yield only chunk.choices[0].delta.content when present, skipping chunks without choices or content.
  ```
- **Applies to:**
  - `outlines/models/sglang.py`
- **Condition:**
  ```text
  changing the streaming loop or chunk handling in AsyncSGLang.generate_stream
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-29d94343d49e3e32f8fea57b.md)

## Rule 023 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the nvidia-cuda devcontainer feature with installCudnn set to true.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2bed7940b4dd13c070a4fe93.md)

## Rule 024 — `examples/dating_profile.py`

- **Rule:**
  ```text
  When modifying the dating profile example, keep the `Example` dataclass wrapper around `DatingProfile` with a `description` field, and keep the generation call using `Template.from_file("prompts/dating_profile.txt")` with `outlines.json_schema(DatingProfile)` and `max_tokens=500`.
  ```
- **Applies to:**
  - `examples/dating_profile.py`
- **Condition:** When editing the dating profile example's example structure or generation call.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c0ad75b6617f07383e6944a.md)

## Rule 025 — `tests/v0_legacy/generate/test_api_legacy.py`

- **Rule:** Tests that exercise a model adapter's streaming entry point for a vision (v0) adapter must expect NotImplementedError with the message 'Streaming is not implemented for Transformers models'; do not add streaming support expectations for vision adapters without changing that contract.
- **Applies to:**
  - `tests/v0_legacy/generate/test_api_legacy.py`
- **Condition:** When modifying or extending the legacy v0 vision adapter streaming test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2f87e2fe817d40b44ac8c78b.md)

## Rule 026 — `examples/modal_example.py`

- **Rule:**
  ```text
  When modifying the Modal example's `generate` function, keep the remote-deployment call pattern: decorate with `@app.function(image=outlines_image, gpu="A100-40GB")` and construct the model inside the function via `outlines.from_transformers` with keyword `tokenizer` and `model` arguments.
  ```
- **Applies to:**
  - `examples/modal_example.py`
- **Condition:** When editing the Modal example's function decoration or model construction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2faf6ac482ac2e66919b07f3.md)

## Rule 027 — `outlines/v0_legacy/generate/api.py`

- **Rule:**
  ```text
  Changes to the legacy GeneratorVisionV0Adapter.stream must preserve merging of prompts and media via merge_prompts_and_media before delegating to the parent stream, so vision streaming requires paired prompt/media inputs.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:** When modifying GeneratorVisionV0Adapter.stream or its input handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2fe7b892672f02d7e8b65cdb.md)

## Rule 028 — `outlines/v0_legacy/function.py`

- **Rule:**
  ```text
  Changes to the legacy v0_legacy compatibility surface must keep it separate from the current API: the v0_legacy function module imports from outlines.v0_legacy and outlines.v0_legacy.models.transformers, preserving the legacy API as a distinct compatibility surface.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying imports or module structure of the legacy v0_legacy function module.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-35358971bc265b46cedd5b6a.md)

## Rule 029 — `examples/bentoml/service.py`

- **Rule:**
  ```text
  Example scripts that demonstrate structured generation in a deployment service must construct the generator with outlines.json_schema(json_schema) and call it with the prompt, returning the generated result.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
  - `examples/cerebrium/main.py`
- **Condition:** When adding or modifying a deployment example that demonstrates structured generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-36c7198011fb92adf9b269df.md)

## Rule 030 — `outlines/templates.py`

- **Rule:**
  ```text
  When modifying parse_pydantic_schema, preserve recursive $ref resolution: nested $ref entries are resolved by splitting the ref string on '/' and indexing definitions[refs[2]], using the property description when present and falling back to '<name>' otherwise.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  changing how parse_pydantic_schema resolves nested Pydantic model schemas or $ref entries
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-381b4996ed898b2c9d33f1fc.md)

## Rule 031 — `examples/beam-cloud/app.py`

- **Rule:**
  ```text
  When modifying the beam-cloud example, preserve the deployment convention that outlines is imported only when `env.is_remote()` is true and models are pre-loaded at container start; do not move heavy imports to unconditional module scope.
  ```
- **Applies to:**
  - `examples/beam-cloud/app.py`
- **Condition:** When editing the beam-cloud example's imports or container-start model loading.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-39bdf84e2ad548d99e1fe462.md)

## Rule 032 — `**/*.py`

- **Rule:** Ruff lint ignores the E731 and F401 rules.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-3a7093ad62eb23a72bc92c98.md)

## Rule 033 — `examples/**`

- **Rule:** The mypy pre-commit hook excludes files under the examples/ directory.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3dc5cbe1b4a1c237ddca3c41.md)

## Rule 034 — `examples/modal_example.py`

- **Rule:** Example scripts must pin external model and dependency versions explicitly (e.g. a fixed model id such as 'mistralai/Mistral-7B-Instruct-v0.2' and pinned package versions in the image build) rather than relying on floating defaults.
- **Applies to:**
  - `examples/modal_example.py`
- **Condition:** When adding or modifying an example that loads a model or installs dependencies in a container image.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-435b710719489c9f235b3686.md)
