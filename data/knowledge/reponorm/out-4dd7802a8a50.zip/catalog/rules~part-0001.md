# Full rule catalog

## Rule 001 — `outlines/fsm/parsing.py`

- **Rule:** PartialParsingFrontend must not reintroduce the commented-out state-transition-map approach, which is documented as 'very wasteful' by a TODO.
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** when modifying PartialParsingFrontend's state-transition handling or considering the commented-out state-transition-map approach
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-01e00617d390b8550440c399.md)

## Rule 002 — `examples/modal_example.py`

- **Rule:** Example scripts that demonstrate remote execution must expose a local entrypoint that invokes the remote function with a default prompt, documenting the expected remote-call pattern.
- **Applies to:**
  - `examples/modal_example.py`
- **Condition:** When adding or modifying the Modal remote-execution example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-037328730568bbb75f93e3ee.md)

## Rule 003 — `environment.yml`

- **Rule:**
  ```text
  The environment installs the local project in editable mode with its test extras via pip (-e ".[test]").
  ```
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0546bd20f185ba96d4684b2f.md)

## Rule 004 — `outlines/v0_legacy/generate/json.py`

- **Rule:**
  ```text
  Changes to the legacy v0_legacy generate.json function must preserve its deprecation warning (removal in v1.1.0), its routing of OpenAI models to json_openai, and its format_sequence behavior (model_validate_json for Pydantic schemas, pyjson.loads otherwise).
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/json.py`
- **Condition:**
  ```text
  When modifying the legacy json generation function or its format_sequence attachment.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-056d280c5b6ad79007131479.md)

## Rule 005 — `.github/workflows/tests_nightly.yml`

- **Rule:** On failure, the workflow sends a Slack notification using 8398a7/action-slack@v3 with the job status and commit, author, and ref fields.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Condition:** workflow predicate: failure()
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-072b7c6d4dee40f42ce4eabe.md)

## Rule 006 — `outlines/types/utils.py`

- **Rule:**
  ```text
  is_float must recognize a value as float when it is float, when its origin is float, when it is Annotated with float as the first argument, or when it has a __supertype__ attribute equal to float, covering NewType-style wrappers.
  ```
- **Applies to:**
  - `outlines/types/utils.py`
- **Condition:**
  ```text
  When modifying is_float or adding float type detection in outlines/types/utils.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-08d3cf78bc97134de77482b1.md)

## Rule 007 — `scripts/gen_ref_pages.py`

- **Rule:**
  ```text
  The gen-files plugin runs the script scripts/gen_ref_pages.py during the documentation build.
  ```
- **Applies to:**
  - `scripts/gen_ref_pages.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0a74e8c60694a2ccb9164ed1.md)

## Rule 008 — `tests/models/test_llamacpp.py`

- **Rule:** Tests for LlamaCpp streaming choice must assert that the first streamed token is one of the allowed Literal values, preserving constrained streaming output membership.
- **Applies to:**
  - `tests/models/test_llamacpp.py`
- **Condition:** When modifying or extending the LlamaCpp streaming choice test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0cdc11c95afe77d1238ec602.md)

## Rule 009 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the conda devcontainer feature.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0ea9194b677ac20f761801f4.md)

## Rule 010 — `tests/models/test_tgi.py`

- **Rule:**
  ```text
  The TGI test module must select a real InferenceClient/AsyncInferenceClient when TGI_SERVER_URL is set, otherwise warn and fall back to MockTGIInferenceClient/MockAsyncTGIInferenceClient, and only register mock_responses on the mock clients when no server URL is provided.
  ```
- **Applies to:**
  - `tests/models/test_tgi.py`
- **Condition:** When modifying or extending the TGI test module's client selection and mock setup.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0eef4ff804618f7ef90640db.md)

## Rule 011 — `outlines/_version.py`

- **Rule:**
  ```text
  setuptools_scm writes the generated version file to outlines/_version.py.
  ```
- **Applies to:**
  - `outlines/_version.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-123ceee18fc612051ebb8cf4.md)

## Rule 012 — `outlines/v0_legacy/models/transformers.py`

- **Rule:**
  ```text
  Tokenizer loading in the legacy transformers factory must default padding_side to "left" via setdefault, preserving the repository convention while allowing caller override.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers.py`
- **Condition:** When modifying the legacy transformers tokenizer loading factory or its padding defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1305e9814adab06e58b13bd6.md)

## Rule 013 — `outlines/v0_legacy/models/transformers_vision.py`

- **Rule:**
  ```text
  Changes to the legacy TransformersVision._prepare_model_inputs must preserve formatting input via the type adapter, running the processor with padding=True and return_tensors="pt", moving results to the model device, and returning the original model_input["text"] alongside processed inputs.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers_vision.py`
- **Condition:**
  ```text
  When modifying TransformersVision._prepare_model_inputs or its processor invocation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1775f32eefea8c63f3ba9f71.md)

## Rule 014 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  The transformers tokenizer's __getstate__ must return only {'tokenizer': self.tokenizer}, intentionally excluding other model state from pickling.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying the transformers tokenizer's pickling or serialization state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-184b37d555dc580672017f05.md)

## Rule 015 — `outlines/v0_legacy/models/exllamav2.py`

- **Rule:**
  ```text
  ExLlamaV2Model.reformat_output must normalize exllamav2 outputs to outlines conventions: collapse single-element lists and regroup flat lists into per-sample sublists when num_samples > 1, asserting divisibility.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying ExLlamaV2Model.reformat_output or any code that consumes its normalized output shape.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1e478436a0db1a838fac655e.md)

## Rule 016 — `**`

- **Rule:** The tests job installs Ollama and pulls the tinyllama model.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1e74ed1d8215c01cec5fd12f.md)

## Rule 017 — `**`

- **Rule:** For all files, line endings use LF.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1f810053009293fef7d44798.md)

## Rule 018 — `**`

- **Rule:** EditorConfig is rooted at this file (root = true), so this file is the top-most EditorConfig configuration.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-203b41f4e1d980128dcea7a5.md)
