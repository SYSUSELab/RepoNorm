# Full rule catalog

## Rule 082 — `tests/models/test_transformers_type_adapter.py`

- **Rule:**
  ```text
  The transformers type adapter test module must import `TransformersTypeAdapter` from `outlines.models.transformers` and `RegexLogitsProcessor` from `outlines.processors.structured`, anchoring the expected module locations for these classes.
  ```
- **Applies to:**
  - `tests/models/test_transformers_type_adapter.py`
- **Condition:** When modifying or extending the transformers type adapter test module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9171be61ff278f4013966bd4.md)

## Rule 083 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow runs asv continuous comparing upstream/main to HEAD with --no-stats --interleave-rounds -a repeat=3, tolerating errors.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-91c0fd0bd91874aa837dd690.md)

## Rule 084 — `tests/models/test_transformers.py`

- **Rule:** The transformers JSON test must assert that generating with a Pydantic Character model yields a result containing the 'name' field, verifying structured JSON output includes declared fields.
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** When modifying or extending the transformers JSON structured output test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-95895d15803fb3b53db4b33d.md)

## Rule 085 — `outlines/v0_legacy/models/transformers.py`

- **Rule:**
  ```text
  The legacy transformers function must let an explicit device argument override any device_map entry in model_kwargs, so callers passing both should expect device to win.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers.py`
- **Condition:**
  ```text
  When modifying the legacy transformers function's device handling, preserve the precedence of the explicit device argument over model_kwargs device_map.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-95d1b18abca15660ab13f157.md)

## Rule 086 — `**/__init__.py`

- **Rule:**
  ```text
  Flake8 ignores F401 and F403 in __init__.py files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-96de3480249351958a08f254.md)

## Rule 087 — `.github/workflows/tests_nightly.yml`

- **Rule:** The test environment is set up by upgrading pip, installing uv, creating a uv venv, and installing the package in editable mode with the test extra.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9955fd1044f9e17b67b409c5.md)

## Rule 088 — `outlines/models/llamacpp.py`

- **Rule:**
  ```text
  LlamaCppTypeAdapter must prepare arguments to llama-cpp-python's Llama.__call__ as the string prompt plus a LogitsProcessorList, preserving the adapter's argument-shaping contract.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  When modifying LlamaCppTypeAdapter or its argument preparation for Llama.__call__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9a754cd462f9b5fc6d819389.md)

## Rule 089 — `tests/types/test_dsl.py`

- **Rule:**
  ```text
  The DSL test module must define a nested `PydanticModel` with fields `a: int` and `b: str`, providing a concrete Pydantic model used to exercise DSL handling of Pydantic types.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** when adding or modifying DSL tests that exercise Pydantic type handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9a78b6649e342313893b8075.md)

## Rule 090 — `.github/workflows/release_pypi.yaml`

- **Rule:** The release workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9b905a7be54461bccee8c939.md)

## Rule 091 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  get_terminals_info must walk sub-FSMs from an FSM state sequence and return both all terminal infos and the subset whose sub-FSM is in a final state, with PartialTerminalInfo carrying index, terminal name, fsm_reads_more, and in_final.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying get_terminals_info or terminal info extraction in outlines/fsm/parsing.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9bb15985fd7f4009eeaf4e3b.md)

## Rule 092 — `outlines/models/tgi.py`

- **Rule:** The TGI model wrapper must store the supplied huggingface InferenceClient and pair it with a TGITypeAdapter, delegating type conversion to the dedicated adapter rather than handling it inline.
- **Applies to:**
  - `outlines/models/tgi.py`
- **Condition:** When modifying the TGI model wrapper's initialization or type conversion wiring.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a1ffcfd89482fd8fb756bbfe.md)

## Rule 093 — `outlines/types/dsl.py`

- **Rule:**
  ```text
  The Sequence DSL node's __repr__ must return the exact format 'Sequence(terms=...)' containing the repr of its terms list, preserving the debug representation contract for this DSL node.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:**
  ```text
  When modifying or adding a DSL node class in outlines/types/dsl.py that defines __repr__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a7784f073327a0956430e830.md)

## Rule 094 — `tests/**`

- **Rule:**
  ```text
  pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a855f1e1f4936f7e9cd6ee4d.md)

## Rule 095 — `tests/v0_legacy/generate/test_json_legacy.py`

- **Rule:**
  ```text
  The legacy json generation test module must define a JSON_SCHEMA_STRING constant describing an object with a required string `foo` property, and reuse it as the canonical schema fixture across legacy json generation tests.
  ```
- **Applies to:**
  - `tests/v0_legacy/generate/test_json_legacy.py`
- **Condition:** when adding or modifying legacy json generation tests that need a JSON schema fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a8f6f62d7f289ab50b7cebbf.md)

## Rule 096 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container is based on the mcr.microsoft.com/devcontainers/python:3.12 image.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a9adc92d25fec285c450a8c8.md)

## Rule 097 — `outlines/processors/tensor_adapters/__init__.py`

- **Rule:** When adding a new tensor backend adapter, register it in the tensor adapter registry dict and extend the adapter Union type so both the runtime lookup and the static type cover the new backend.
- **Applies to:**
  - `outlines/processors/tensor_adapters/__init__.py`
- **Condition:** Adding or renaming a tensor backend adapter in the tensor adapter registry.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aa1ed1a387bb741edbab750f.md)

## Rule 098 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow checks out the repository with actions/checkout@v4 using fetch-depth: 0.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ad74ed40b50f1afe825e06ca.md)
