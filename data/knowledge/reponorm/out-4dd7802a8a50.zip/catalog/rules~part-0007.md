# Full rule catalog

## Rule 099 — `examples/bentoml/service.py`

- **Rule:**
  ```text
  When modifying the BentoML service example, keep the declared deployment resource requirements: a 300-second traffic timeout, one `nvidia-l4` GPU, and `bento_model_ref` bound via `bentoml.models.get(BENTO_MODEL_TAG)`.
  ```
- **Applies to:**
  - `examples/bentoml/service.py`
- **Condition:** When editing the BentoML service example's deployment configuration or model binding.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ae01a741160e2a42a5841494.md)

## Rule 100 — `outlines/models/tgi.py`

- **Rule:**
  ```text
  TGITypeAdapter.format_input must be a singledispatchmethod whose base implementation raises NotImplementedError instructing that only string input is supported with TGI, defining the extension point for input type handling.
  ```
- **Applies to:**
  - `outlines/models/tgi.py`
- **Condition:**
  ```text
  When modifying TGITypeAdapter.format_input or adding input type handling for TGI.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ae2f0d118e878af437d16108.md)

## Rule 101 — `SUMMARY.md`

- **Rule:** The literate-nav plugin uses SUMMARY.md as the navigation file.
- **Applies to:**
  - `SUMMARY.md`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b0c663ba882057068484d8b1.md)

## Rule 102 — `.github/workflows/publish_documentation.yml`

- **Rule:**
  ```text
  The workflow caches the .cache path using actions/cache@v3 with key mkdocs-material-${{ env.cache_id }} and restore-keys mkdocs-material-.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b1ae5e76cf1515d825c6d87a.md)

## Rule 103 — `outlines/models/vllm_offline.py`

- **Rule:**
  ```text
  When modifying load_lora, preserve the deprecation contract: it is deprecated since v1.0.0, warns that support will be removed in v1.1.0, and directs users to pass lora_request when calling the model or generator.
  ```
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:**
  ```text
  changing or removing the load_lora method or its deprecation warning
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b38f0b310032e1d0e8c17e7e.md)

## Rule 104 — `**/*.yaml`

- **Rule:** For YAML files, indent size is 2.
- **Applies to:**
  - `**/*.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b392228d4eb3f93ac8ad3b64.md)

## Rule 105 — `.github/workflows/tests_nightly.yml`

- **Rule:**
  ```text
  Tests are run with `uv run pytest -x --cov=outlines`.
  ```
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bbf738bc6c074a2a320bf36a.md)

## Rule 106 — `tests/types/test_dsl.py`

- **Rule:**
  ```text
  Every DSL term type (String, Regex, JsonSchema, KleeneStar/Plus, Optional, Alternatives, Sequence, and Quantify variants) must have a stable repr and a display_ascii_tree rendering with specific box-drawing output, and QuantifyBetween must reject max_count < min_count with a ValueError.
  ```
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** When modifying or extending DSL term repr, tree rendering, or QuantifyBetween validation tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bec59a09f2e2b29b0d883591.md)

## Rule 107 — `outlines/v0_legacy/base.py`

- **Rule:**
  ```text
  The v0_legacy setup_numpy helper must import numpy in a try block and select private numpy helpers (_calculate_shapes, _parse_gufunc_signature, _parse_input_dimensions, _update_dim_sizes) from numpy.lib._function_base_impl for numpy major version >= 2 versus numpy.lib.function_base otherwise.
  ```
- **Applies to:**
  - `outlines/v0_legacy/base.py`
- **Condition:**
  ```text
  When modifying the v0_legacy setup_numpy helper or its numpy private-helper imports.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c103bfa1e6b0607b76ff70c4.md)

## Rule 108 — `outlines/v0_legacy/generate/json.py`

- **Rule:**
  ```text
  The v0_legacy OpenAI JSON generator must reject any sampler other than multinomial with NotImplementedError and, for Pydantic schemas, set additionalProperties False and wrap the schema in a strict json_schema response_format.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/json.py`
- **Condition:**
  ```text
  When modifying the v0_legacy json_openai generator's sampler validation or Pydantic schema handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c7e69a3d05968ac43051797f.md)

## Rule 109 — `tests/types/test_dsl.py`

- **Rule:** DSL term operators must normalize operands: adding a string wraps it in String, and reflected add/or place the other operand first, defining the expected Sequence/Alternatives construction order.
- **Applies to:**
  - `tests/types/test_dsl.py`
- **Condition:** When modifying or extending DSL term operator tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c94afd7ae7af88d75700b049.md)

## Rule 110 — `examples/**`

- **Rule:** mypy excludes the "examples" directory from type checking.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c9575dbc0b45d7eb1f5745da.md)

## Rule 111 — `outlines/v0_legacy/models/exllamav2.py`

- **Rule:**
  ```text
  The v0_legacy ExLlamaV2 model must raise NotImplementedError from its stream method, and its ExllamaV2Params TypedDict must remain total=False with the optional keys stop_conditions, seed, gen_settings, and max_new_tokens.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying the v0_legacy ExLlamaV2 model's stream method or its ExllamaV2Params parameter surface.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cacb9161de54c935a18bab17.md)

## Rule 112 — `tests/models/test_llamacpp_type_adapter.py`

- **Rule:**
  ```text
  The llamacpp type adapter test module must import llama_cpp and LogitsProcessorList alongside LlamaCppTypeAdapter, LlamaCppTokenizer, and RegexLogitsProcessor, testing the adapter against the real llama_cpp logits-processor interface.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_type_adapter.py`
- **Condition:** When modifying or extending the llamacpp type adapter test module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cb4fba7517c54e39bc689557.md)

## Rule 113 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow configures git user.name and user.email from the github.actor before publishing.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc214b2c6b4f76eae93004b4.md)

## Rule 114 — `examples/babyagi.py`

- **Rule:** Example scripts that demonstrate a bounded agent loop must document the fixed cycle limit and the absence of vector-store retrieval, bounding the example's demonstrated scope.
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When adding or modifying the babyagi example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cca7eec6258ffc1f9bca94ab.md)
