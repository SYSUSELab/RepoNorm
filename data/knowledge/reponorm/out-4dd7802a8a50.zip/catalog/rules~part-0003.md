# Full rule catalog

## Rule 035 — `examples/cfg.py`

- **Rule:**
  ```text
  When modifying the cfg example's validation loop, keep the pattern of iterating over the nlamb, calc, dyck, and json grammars, generating a batch of 10 sequences per grammar, and validating each by parsing with `generator.logits_processor.guide.parser`, treating parse failure or context-window overflow as FAILURE.
  ```
- **Applies to:**
  - `examples/cfg.py`
- **Condition:** When editing the cfg example's grammar iteration or validation logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-463809da3665e742d34fbbe6.md)

## Rule 036 — `outlines/processors/tensor_adapters/torch.py`

- **Rule:**
  ```text
  Torch tensor adapters must import torch lazily inside __init__ and store it on the instance, avoiding a module-level torch import.
  ```
- **Applies to:**
  - `outlines/processors/tensor_adapters/torch.py`
- **Condition:**
  ```text
  When modifying or adding a torch tensor adapter in outlines/processors/tensor_adapters/torch.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-47cb42472dc3ce148e7cb5a2.md)

## Rule 037 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow sets up Python using actions/setup-python@v4 with python-version 3.x.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-49f8d8dd3d03dba64ebb900e.md)

## Rule 038 — `examples/self_consistency.py`

- **Rule:** When modifying the self-consistency example, keep the majority-vote aggregation pattern: generate n=10 answers, extract the last integer from each via regex, and report the most frequent answer with a consensus percentage.
- **Applies to:**
  - `examples/self_consistency.py`
- **Condition:** When editing the self-consistency example's sampling count or aggregation logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-49fbcd279ea603c3060e4bef.md)

## Rule 039 — `requirements-doc.txt`

- **Rule:** Read the Docs additionally installs dependencies from requirements-doc.txt.
- **Applies to:**
  - `requirements-doc.txt`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Detail:** [Open claim details](../claims/CLAIM-4aa7ae811c692cf6f771bd18.md)

## Rule 040 — `tests/models/test_transformers_tokenizer.py`

- **Rule:**
  ```text
  The tokenizer_seq2seq fixture must construct its tokenizer via transformers.AutoTokenizer.from_pretrained using the module-level TEST_MODEL_SEQ2SEQ constant rather than a hard-coded model name.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:**
  ```text
  when modifying the tokenizer_seq2seq fixture or adding seq2seq tokenizer tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4df85e330c0deca54e3eaa23.md)

## Rule 041 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  _compute_termset_fsm_info must group parser states by the ordered tuple of terminal names from each contextual lexer scanner, store each termset's scanner FSM and fsms_to_trans_finals, and record the frozenset of parse states using each termset.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying _compute_termset_fsm_info or termset grouping logic in outlines/fsm/parsing.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4f19a960a4afe51513ddc9d0.md)

## Rule 042 — `examples/beam-cloud/app.py`

- **Rule:**
  ```text
  When modifying the Beam endpoint example, keep the declared serverless deployment shape: `gpu="A10G"`, `cpu=1`, `memory="16Gi"`, an image adding `outlines`, `torch`, `transformers`, and `accelerate`, model caching via `context.on_start_value`, and generation with `Literal["Positive", "Negative"]`.
  ```
- **Applies to:**
  - `examples/beam-cloud/app.py`
- **Condition:** When editing the Beam endpoint example's deployment resources, image, model caching, or generation signature.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-50bd45866b50ea3f9006382d.md)

## Rule 043 — `outlines/v0_legacy/generate/api.py`

- **Rule:**
  ```text
  The legacy generate API __call__ must mirror input shape in its return: a list of sequences is formatted individually per sequence, while a single sequence is formatted directly.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/api.py`
- **Condition:**
  ```text
  When modifying GeneratorV0Adapter.__call__ or its result formatting, preserve the list-versus-single return shape mirroring the input.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-54c44d7986ee8028d68ad754.md)

## Rule 044 — `examples/cerebrium/main.py`

- **Rule:** Example scripts that demonstrate structured generation with a Mistral model must format the prompt using the Mistral instruction template before passing it to the generator.
- **Applies to:**
  - `examples/cerebrium/main.py`
- **Condition:** When adding or modifying an example that uses a Mistral model for structured generation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-57ffb0d9b2e9dddea3d3b7d9.md)

## Rule 045 — `tests/models/test_sglang.py`

- **Rule:**
  ```text
  The SGLang test module must provide a `sync_model` fixture that constructs `SGLang(openai_client, model_name=sglang_model_name)` as the shared client/model setup for SGLang tests.
  ```
- **Applies to:**
  - `tests/models/test_sglang.py`
- **Condition:** When modifying or extending SGLang test fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-593e399f822fd9dd9604a846.md)

## Rule 046 — `mkdocs.yml`

- **Rule:** The MkDocs site uses the material theme.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-59712acd6a0de51294107b16.md)

## Rule 047 — `**`

- **Rule:**
  ```text
  The tests job runs pytest with -x, coverage over the outlines package, and excludes tests marked api_call.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-59b49aea7dd00a0bef03f9de.md)

## Rule 048 — `**/*.py`

- **Rule:**
  ```text
  The project declares a supported Python version range of >=3.9,<3.13 via requires-python.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5cec4ad4de4dddd52e29f96e.md)

## Rule 049 — `outlines/types/dsl.py`

- **Rule:** The FSM Term dataclass must require its fsm field to be an instance of interegular.fsm.FSM, constraining accepted types for FSM-based output types.
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying the FSM Term dataclass or adding FSM-based output types in outlines/types/dsl.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5ecff7d300fd027b5cf16fe0.md)

## Rule 050 — `outlines/caching.py`

- **Rule:**
  ```text
  The cache decorator must accept expire, typed, and ignore parameters, build its cache key from a key_function if provided or from the decorated function's arguments otherwise, and be based on diskcache's memoize.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:** When modifying the cache decorator or adding caching behavior in outlines/caching.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-614566defeeee63f91c194a7.md)
