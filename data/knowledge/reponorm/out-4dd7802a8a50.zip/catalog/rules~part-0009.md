# Full rule catalog

## Rule 130 — `tests/models/test_transformers_tokenizer.py`

- **Rule:**
  ```text
  Tests for TransformerTokenizer must pin the equality and hash contract: __eq__ returns NotImplemented for non-tokenizer objects and compares model_name and kwargs, and hash is an int that is equal for tokenizers built from the same configuration and different for a seq2seq tokenizer.
  ```
- **Applies to:**
  - `tests/models/test_transformers_tokenizer.py`
- **Condition:** when modifying TransformerTokenizer equality or hash behavior, or the tests that pin it
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e74a5bd002e7d0e5782784f1.md)

## Rule 131 — `.github/workflows/tests_nightly.yml`

- **Rule:** The workflow installs Ollama by running the install script, checking the version, and pulling the tinyllama model.
- **Applies to:**
  - `.github/workflows/tests_nightly.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e78d68dcb12668e0d8ca91a2.md)

## Rule 132 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow builds the SDist and wheel by running ./.github/scripts/build_sdist_and_wheel.sh.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e86b2a82b5c63c9b829d552c.md)

## Rule 133 — `**`

- **Rule:** For all files, trailing whitespace is trimmed.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e8ae57cb96ec6d370fc12f41.md)

## Rule 134 — `outlines/v0_legacy/models/openai.py`

- **Rule:**
  ```text
  The legacy azure_openai function must replace the config's model with deployment_name (or build a new OpenAIConfig(model=deployment_name)), so the deployment name overrides any model name in the supplied config.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/openai.py`
- **Condition:**
  ```text
  When modifying the legacy azure_openai function's config handling, preserve deployment_name overriding the model name in the supplied config.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e9d34b9342be986795a5e947.md)

## Rule 135 — `examples/parsing.py`

- **Rule:**
  ```text
  When modifying the parser-masking example, keep the end-to-end integration: load `PartialLark` from the `tests` package with `partial_python.lark` and `PartialPythonIndenter` using `start="file_input"`, then generate with a `LogitsProcessorList` containing `ParserLogitsProcessor(parser)` and `renormalize_logits=True`.
  ```
- **Applies to:**
  - `examples/parsing.py`
- **Condition:** When editing the parser-based masking example's parser loading or generation call.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eb8679c909854719c9b2d9c8.md)

## Rule 136 — `outlines/_version.py`

- **Rule:**
  ```text
  Coverage measurement omits the listed files that require a GPU or Apple Silicon, the listed models that make API calls, and tests/*.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `outlines/models/anthropic.py`
  - `outlines/models/dottxt.py`
  - `outlines/models/gemini.py`
  - `outlines/models/mlxlm.py`
  - `outlines/models/openai.py`
  - `outlines/models/vllm_offline.py`
  - `outlines/processors/tensor_adapters/mlx.py`
  - `outlines/v0_legacy/models/anthropic.py`
  - `outlines/v0_legacy/models/dottxt.py`
  - `outlines/v0_legacy/models/exllamav2.py`
  - `outlines/v0_legacy/models/gemini.py`
  - `outlines/v0_legacy/models/mlxlm.py`
  - `outlines/v0_legacy/models/openai.py`
  - `outlines/v0_legacy/models/vllm_offline.py`
  - `tests/*`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eead5ea0355919bc2b1ae59a.md)

## Rule 137 — `outlines/models/transformers.py`

- **Rule:** The registered dict input formatter must raise ValueError when the input dict lacks a 'text' key, enforcing that multimodal dict inputs include 'text'.
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying or adding a dict input formatter for multimodal inputs in the transformers model adapter.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f12276866d674e8e354fd1bf.md)

## Rule 138 — `outlines/v0_legacy/generate/cfg.py`

- **Rule:** The legacy cfg function must emit a DeprecationWarning stating removal in v1.1.0, raise NotImplementedError for OpenAI and LlamaCpp models, and return GeneratorVisionV0Adapter for TransformersVision but GeneratorV0Adapter otherwise.
- **Applies to:**
  - `outlines/v0_legacy/generate/cfg.py`
- **Condition:** When modifying the legacy cfg function or its model-to-adapter compatibility matrix.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f53a272e12198d07465341bd.md)

## Rule 139 — `outlines/v0_legacy/models/exllamav2.py`

- **Rule:**
  ```text
  The legacy ExLlamaV2 tokenizer's convert_token_to_string must return the token unchanged, performing no token-to-string conversion for this backend.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/exllamav2.py`
- **Condition:**
  ```text
  When modifying OutlinesExLlamaV2Tokenizer.convert_token_to_string, preserve the identity behavior rather than adding conversion logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f86abda96c59905a7f824103.md)

## Rule 140 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow publishes to PyPI using pypa/gh-action-pypi-publish with user __token__ and password from secrets.PYPI_TOKEN.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f983e979d6bc61911b9518a7.md)

## Rule 141 — `examples/pick_odd_one_out.py`

- **Rule:** Example scripts that demonstrate structured generation with a JSON schema enum output type must call json.loads on the raw generator result to obtain the structured value.
- **Applies to:**
  - `examples/pick_odd_one_out.py`
- **Condition:** When adding or modifying the odd-one-out example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fab37d4821a0563af9a39f20.md)

## Rule 142 — `examples/vllm_offline_integration.py`

- **Rule:**
  ```text
  When modifying the vLLM offline integration example, keep the tokenizer adaptation via `adapt_tokenizer`, construct `JSONLogitsProcessor` with `tensor_library_name="torch"` and a `whitespace_pattern`, and pass it through `vllm.SamplingParams(logits_processors=[...])`; do not bypass the logits-processor wiring.
  ```
- **Applies to:**
  - `examples/vllm_offline_integration.py`
- **Condition:** When editing the vLLM offline integration example's generation wiring.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fca51a51e390537cc9f8ddb3.md)

## Rule 143 — `outlines/generator.py`

- **Rule:**
  ```text
  When changing SteerableGenerator.__init__ output-type dispatch, keep the mapping: CFG terms to CFGLogitsProcessor, FSM terms to RegexGuide.from_interegular_fsm with GuideLogitsProcessor, other terms via to_regex to RegexLogitsProcessor, and None to no logits processor.
  ```
- **Applies to:**
  - `outlines/generator.py`
- **Condition:**
  ```text
  Modifying SteerableGenerator.__init__ output-type-to-processor selection.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fe4ef2dd0d6421008c329171.md)
