# Full rule catalog

## Rule 115 — `docs/examples/**/*.py`

- **Rule:**
  ```text
  Extraction examples must construct the prompt via Template.from_string with the documented variable names and pass the model and output schema to Generator, so the example stays runnable and consistent with the library API.
  ```
- **Applies to:**
  - `docs/examples/**/*.py`
- **Condition:** When adding or modifying an extraction example that loads a model and produces structured output.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cccc6f18023891069744ab4a.md)

## Rule 116 — `examples/math_generate_code.py`

- **Rule:**
  ```text
  Example scripts that demonstrate code generation followed by execution must build the prompt via Template.from_string with question/code few-shot examples, call the model, and execute the returned code with execute_code.
  ```
- **Applies to:**
  - `examples/math_generate_code.py`
- **Condition:** When adding or modifying the math code-generation example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ce75c268a23a2f2877214422.md)

## Rule 117 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow checks that the package version matches the release name by grepping for "^Version: ${GITHUB_REF:10}$" in outlines.egg-info/PKG-INFO.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cfc567b88d496463edca12a8.md)

## Rule 118 — `tests/v0_legacy/generate/test_json_legacy.py`

- **Rule:** The legacy json test must assert that calling json with a greedy sampler on an OpenAI model raises NotImplementedError stating the OpenAI API only supports the multinomial sampler, while emitting the json deprecation warning.
- **Applies to:**
  - `tests/v0_legacy/generate/test_json_legacy.py`
- **Condition:** When modifying or extending the legacy json OpenAI wrong sampler test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d01f6e40edf02e890e9b6aa2.md)

## Rule 119 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow installs asv, virtualenv, and lf-asv-formatter as dependencies.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d3eec24436358cbcb281e794.md)

## Rule 120 — `outlines/v0_legacy/generate/choice.py`

- **Rule:**
  ```text
  Changes to the legacy choice_openai function must preserve its JSON schema contract: a single required "result" string enum with additionalProperties False, and suppression of DeprecationWarning while calling the legacy json generator.
  ```
- **Applies to:**
  - `outlines/v0_legacy/generate/choice.py`
- **Condition:**
  ```text
  When modifying the legacy choice_openai function or its schema construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d7cca8ad7a795ed64086d42c.md)

## Rule 121 — `tests/models/test_vllm.py`

- **Rule:**
  ```text
  The async vLLM test must assert that generating with a CFG(YES_NO_GRAMMAR) constraint and max_tokens=10 returns a string restricted to exactly 'yes' or 'no', establishing the expected constrained-output behavior for the async vLLM model.
  ```
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** When modifying or extending the async vLLM CFG generation test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-da0936af72a5c275cd32d50b.md)

## Rule 122 — `outlines/models/vllm_offline.py`

- **Rule:**
  ```text
  VLLMOffline.__init__ must store the vllm.LLM instance, create a VLLMOfflineTypeAdapter, and initialize lora_request to None.
  ```
- **Applies to:**
  - `outlines/models/vllm_offline.py`
- **Condition:**
  ```text
  When modifying VLLMOffline.__init__ or adding initialization state to the vLLM offline adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-db4825d6d375a95fd54655f4.md)

## Rule 123 — `examples/parsing.py`

- **Rule:** The parsing example must initialize parser state by parsing an empty string and maintain a states stack plus token sequence/index for incremental parser-state tracking.
- **Applies to:**
  - `examples/parsing.py`
- **Condition:** When modifying the parsing example's parser-state initialization or incremental tracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dc91bdeb3585bc076444c0ae.md)

## Rule 124 — `outlines/v0_legacy/models/transformers_vision.py`

- **Rule:**
  ```text
  The v0_legacy transformers_vision entry point is deprecated as of v1.0.0 with removal planned in v1.1.0, and its warning must direct users to instantiate TransformersMultiModal via outlines.from_transformers.
  ```
- **Applies to:**
  - `outlines/v0_legacy/models/transformers_vision.py`
- **Condition:**
  ```text
  When modifying the v0_legacy transformers_vision entry point or its deprecation warning.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dcc6323a8ce866280691d1b7.md)

## Rule 125 — `**/*.py`

- **Rule:**
  ```text
  Coverage excludes lines matching "pragma: no cover", "if TYPE_CHECKING:", and "\\.\\.\\." from coverage measurement.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e0578452b76f2d5f764c7b99.md)

## Rule 126 — `.github/workflows/build_documentation.yml`

- **Rule:**
  ```text
  The documentation build step installs requirements-doc.txt via pip and runs mkdocs build, with GOOGLE_ANALYTICS_KEY supplied from the GOOGLE_ANALYTICS_KEY secret.
  ```
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e11cd27d5030b9dd1a3ba4d4.md)

## Rule 127 — `tests/models/test_llamacpp_tokenizer.py`

- **Rule:**
  ```text
  Tests for LlamaCppTokenizer.encode must assert that list (batch) inputs raise NotImplementedError while single-string inputs return token_ids and attention_mask of equal length, documenting the batch-unsupported boundary.
  ```
- **Applies to:**
  - `tests/models/test_llamacpp_tokenizer.py`
- **Condition:** when modifying LlamaCppTokenizer.encode or the tests that pin its batch behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e4453aeca699961dc8a7462f.md)

## Rule 128 — `examples/babyagi.py`

- **Rule:**
  ```text
  The BabyAGI one_cycle example must pop the highest-priority task, complete it, create new tasks from the result with incrementing task ids, re-prioritize the task list, and return the executed task, result, prioritized tasks, and updated next_task_id.
  ```
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:**
  ```text
  When modifying the BabyAGI one_cycle task-execution loop.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e62e3ba232eef1f3b8b05c41.md)

## Rule 129 — `**`

- **Rule:** The coverage job uploads the htmlcov directory as the html-report artifact only when the job has failed.
- **Applies to:**
  - `**`
- **Condition:** workflow predicate: ${{ failure() }}
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e64684742e8cae00ed3726d3.md)
