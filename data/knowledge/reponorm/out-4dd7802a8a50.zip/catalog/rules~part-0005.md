# Full rule catalog

## Rule 065 — `examples/parsing.py`

- **Rule:**
  ```text
  When modifying `ParserLogitsProcessor.__call__` in the parsing example, preserve the invalid-token handling that catches `EOFError`, `UnexpectedToken`, `UnexpectedCharacters`, and `DedentError` as invalid-token signals; do not narrow the caught exception set without equivalent invalid-token coverage.
  ```
- **Applies to:**
  - `examples/parsing.py`
- **Condition:** When editing the parser logits processor's token-masking loop or its exception handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-77cb1890dc17e56fee3ab25b.md)

## Rule 066 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  The transformers model's _prepare_model_inputs must format input via the type adapter, encode prompts into input_ids and attention_mask, and move both tensors to self.model.device before returning them alongside the prompts.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When modifying transformers model input preparation or device placement.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7a18f13205b209040e223e11.md)

## Rule 067 — `outlines/models/anthropic.py`

- **Rule:**
  ```text
  format_vision_model_input must build an Anthropic messages payload with a user message containing an image source using base64, media_type from model_input.image_format, data from model_input.image_str, followed by a text block with model_input.prompt.
  ```
- **Applies to:**
  - `outlines/models/anthropic.py`
- **Condition:** When modifying the Anthropic vision model input formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7d13428f0cbac9e76b1eddd7.md)

## Rule 068 — `examples/babyagi.py`

- **Rule:** Example task-list parsing must split on newlines and then on the first '.', keeping only lines that contain a period and stripping the numeric prefix; lines without a period are silently dropped.
- **Applies to:**
  - `examples/babyagi.py`
- **Condition:** When modifying task-list parsing or formatting in the BabyAGI example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-80f6727ea50c9a918df48d21.md)

## Rule 069 — `**/*.py`

- **Rule:** Flake8 enforces a maximum line length of 88 characters.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-84acc8fcdeab7f3ccfb683b2.md)

## Rule 070 — `outlines/templates.py`

- **Rule:**
  ```text
  When changing get_fn_source, preserve the contract that non-callables raise TypeError and that source extraction starts at the first def, since callers rely on this source-filter behavior.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  Modifying get_fn_source's handling of non-callables or its source extraction starting point.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-84f3eecae97287342d960c44.md)

## Rule 071 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container declares GPU host requirements as optional.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-85813bdfe4d61e26edeed66f.md)

## Rule 072 — `.github/workflows/publish_documentation.yml`

- **Rule:**
  ```text
  When the event is a push, the workflow runs mike deploy --push --update-aliases ${{ github.ref_name }} unstable, with GOOGLE_ANALYTICS_KEY set from secrets.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-866ff7fbd6528a500ecaf4bb.md)

## Rule 073 — `outlines/fsm/parsing.py`

- **Rule:** PartialScanner must be implemented as a Scanner specialization in outlines/fsm/parsing.py rather than as a separate parser type.
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** when modifying partial-parse scanning or adding scanner behavior in the fsm parsing module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-88246d170310bb7b4f5d77bf.md)

## Rule 074 — `outlines/templates.py`

- **Rule:**
  ```text
  When adding a schema renderer, register it with functools.singledispatch on get_schema; the default implementation must continue to raise NotImplementedError naming the unsupported type.
  ```
- **Applies to:**
  - `outlines/templates.py`
- **Condition:**
  ```text
  Adding or modifying a schema renderer registered on get_schema.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-893c2dcd788c3cc7d680ff9f.md)

## Rule 075 — `outlines/v0_legacy/function.py`

- **Rule:**
  ```text
  Changes to the legacy download_from_github function must preserve its path validation: require a {USERNAME}/{REPO_NAME}/{PATH_TO_FILE} path with at least three segments, reject paths ending in .py, map HTTP 404 to ValueError, and otherwise call raise_for_status.
  ```
- **Applies to:**
  - `outlines/v0_legacy/function.py`
- **Condition:**
  ```text
  When modifying the legacy download_from_github function or its path/HTTP error handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8b18d2884c3f122fd8087a8a.md)

## Rule 076 — `tests/test_utils/mock_openai_client.py`

- **Rule:** The MockStreamingChunk test helper must initialize choices to an empty list when content is None and otherwise build a single MagicMock choice whose delta.content is the supplied content, preserving the mock streaming chunk shape used by OpenAI streaming tests.
- **Applies to:**
  - `tests/test_utils/mock_openai_client.py`
- **Condition:** when modifying MockStreamingChunk or the OpenAI streaming test helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8bf9ad8bd716eff8f2158748.md)

## Rule 077 — `outlines/types/dsl.py`

- **Rule:**
  ```text
  FSM.__repr__ must return 'FSM(fsm=<inner repr>)' and CFG.__repr__ must return "CFG(definition='{self.definition}')", fixing the debug representation format for these DSL nodes.
  ```
- **Applies to:**
  - `outlines/types/dsl.py`
- **Condition:** When modifying the debug representation of FSM or CFG DSL nodes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8cb8d9f9b818d3baac351dc6.md)

## Rule 078 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow installs documentation dependencies with pip install -r requirements-doc.txt and builds the documentation with mkdocs build.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8d5d08abe81f10e2c88e7786.md)

## Rule 079 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container runs with the --device=nvidia.com/gpu=all argument.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8e7205735bf08bb76890d834.md)

## Rule 080 — `.devcontainer/devcontainer.json`

- **Rule:** The dev container enables the rust devcontainer feature.
- **Applies to:**
  - `.devcontainer/devcontainer.json`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-90490a81539988b1d009daf2.md)

## Rule 081 — `tests/models/test_vllm.py`

- **Rule:** The vLLM vision test image fixture must build a 256x256 RGB white PNG in memory and reopen it from the BytesIO buffer, supplying vision inputs without on-disk assets.
- **Applies to:**
  - `tests/models/test_vllm.py`
- **Condition:** when modifying the vLLM vision test image fixture or adding vision inputs to vLLM tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-907ab6aaab6642eb075ccbf0.md)
