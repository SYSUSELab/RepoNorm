# Rule details

- **Rule:** When modifying the exception hierarchy, preserve that TemplateRuntimeError subclasses TemplateError and remains the generic runtime error Jinja may raise.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** Changing TemplateRuntimeError's base class or its role as the generic runtime error.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
TemplateRuntimeError is defined as a subclass of TemplateError, preserving the required exception hierarchy relationship.
```

- **Sources:**
  - `src/jinja2/exceptions.py:147-150`
