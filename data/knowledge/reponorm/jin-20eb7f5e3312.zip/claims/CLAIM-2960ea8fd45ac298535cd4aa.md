# Rule details

- **Rule:** When modifying FileSystemBytecodeCache, preserve the platform-specific default cache directory selection: the user's temp directory on Windows and a per-user directory under the system temp directory on UNIX.
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying the default cache directory selection for FileSystemBytecodeCache
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
FileSystemBytecodeCache docstring describes platform-specific default cache directory selection (temp dir on Windows, per-user dir on UNIX).
```

- **Sources:**
  - `src/jinja2/bccache.py:186-284`
