# Rule details

- **Rule:** The tox testenv:typing environment installs its dependencies from requirements/typing.txt.
- **Applies to:**
  - `requirements/typing.txt`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
deps = -r requirements/typing.txt

```

- **Sources:**
  - `tox.ini:19`
