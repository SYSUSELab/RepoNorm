# Rule details

- **Rule:** Namespace is a container holding arbitrary attributes, initializable from a dictionary or keyword arguments.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when modifying Namespace initialization or attribute storage
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Namespace in src/jinja2/utils.py is a container holding arbitrary attributes and is initializable from a dictionary or keyword arguments.
```

- **Sources:**
  - `src/jinja2/utils.py:734-755`
