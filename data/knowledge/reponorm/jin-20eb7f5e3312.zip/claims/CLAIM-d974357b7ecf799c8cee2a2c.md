# Rule details

- **Rule:** mypy is configured to check the files under src/jinja2.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
files = src/jinja2

```

- **Sources:**
  - `setup.cfg:88`
