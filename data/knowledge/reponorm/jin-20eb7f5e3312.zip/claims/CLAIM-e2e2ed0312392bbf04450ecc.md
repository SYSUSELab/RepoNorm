# Rule details

- **Rule:**
  ```text
  Parser.parse_primary must treat both lowercase and capitalized spellings as literals: true/True and false/False become Const booleans, none/None become Const None, and adjacent string tokens are concatenated into a single Const with the first token's lineno.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.parse_primary or template literal parsing.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Parser.parse_primary maps true/True and false/False to Const booleans, none/None to Const None, and concatenates adjacent string tokens into one Const with the first token's lineno.
```

- **Sources:**
  - `src/jinja2/parser.py:644-676`
