# Rule details

- **Rule:**
  ```text
  Environment._load_template must key the cache by (weakref.ref(self.loader), name); on a cache hit with auto_reload disabled or an up-to-date template it must update template.globals with the passed globals and return the cached template, otherwise load and store the template.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Environment._load_template or the template cache
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_load_template keys the cache by (weakref.ref(self.loader), name) and updates template.globals on a cache hit before returning the cached template.
```

- **Sources:**
  - `src/jinja2/environment.py:941-963`
