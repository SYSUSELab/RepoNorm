# Rule details

- **Rule:** LRUCache.setdefault must return the existing value if the key is present and only insert the default on KeyError, never overwriting existing entries.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying LRUCache.setdefault or cache insertion semantics.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
LRUCache.setdefault returns the existing value and only inserts the default on KeyError, never overwriting existing entries.
```

- **Sources:**
  - `src/jinja2/utils.py:470-478`
