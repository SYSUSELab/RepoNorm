# Rule details

- **Rule:**
  ```text
  The package_loader fixture in tests/conftest.py must return a PackageLoader initialized with package 'res' and templates directory 'templates', because this defines the shared fixture contract for tests that load templates from a package.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  When adding or modifying the package_loader fixture in tests/conftest.py
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
package_loader fixture returns loaders.PackageLoader('res', 'templates'), matching the shared fixture contract.
```

- **Sources:**
  - `tests/conftest.py:22-24`
