# Rule details

- **Rule:**
  ```text
  Comparison test aliases must be asserted through the `is` test operator with parametrized op strings (e.g. 'eq 2') and expected booleans, covering eq/ne/lt/le/gt/ge aliases.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When adding or modifying comparison-alias tests in tests/test_tests.py.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_compare_aliases is parametrized over eq/ne/lt/le/gt/ge op strings using the `is` operator and asserts exact boolean results, matching the comparison-alias rule.
```

- **Sources:**
  - `tests/test_tests.py:154-156`
