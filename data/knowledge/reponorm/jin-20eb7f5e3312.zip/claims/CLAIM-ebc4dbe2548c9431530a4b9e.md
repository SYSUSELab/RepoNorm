# Rule details

- **Rule:**
  ```text
  When modifying sandboxed call handling, preserve that SandboxedEnvironment.call first checks for a format method and routes to format_string, otherwise verifies is_safe_callable and raises SecurityError.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** Changing sandboxed call dispatch, format-method routing, or safety verification.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The call method checks for a format method and routes to format_string, otherwise verifies is_safe_callable and raises SecurityError, matching the rule.
```

- **Sources:**
  - `src/jinja2/sandbox.py:377-393`
