# Rule details

- **Rule:**
  ```text
  select_autoescape must normalize enabled and disabled extensions by stripping leading dots and lowercasing them, operating case-insensitively for security reasons, with default_for_string controlling string templates and default controlling unmatched filenames.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying select_autoescape or autoescape extension matching behavior.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
select_autoescape normalizes extensions by stripping leading dots and lowercasing, and honors default_for_string and default parameters.
```

- **Sources:**
  - `src/jinja2/utils.py:570-623`
