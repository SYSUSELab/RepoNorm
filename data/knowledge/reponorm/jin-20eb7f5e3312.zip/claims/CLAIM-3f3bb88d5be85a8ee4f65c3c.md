# Rule details

- **Rule:**
  ```text
  The tox testenv:style environment runs `pre-commit run --all-files --show-diff-on-failure` as its command.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`

## Supporting evidence

### Evidence 1 — explicit

```text
commands = pre-commit run --all-files --show-diff-on-failure

```

- **Sources:**
  - `tox.ini:16`
