# Rule details

- **Rule:**
  ```text
  _CommentFinder can only find comments for gettext calls forwards; once a later-line comment is found, an earlier-line comment will not return a usable value.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When modifying _CommentFinder or i18n comment extraction ordering behavior.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_CommentFinder implements forward-only comment lookup, documented as unable to return usable values for earlier-line comments once a later-line comment is found.
```

- **Sources:**
  - `src/jinja2/ext.py:723-760`
