# Rule details

- **Rule:**
  ```text
  Tests for idtracking must exercise symbol tracking over node trees by importing nodes and symbols_for_node.
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:** When modifying or adding idtracking tests that exercise symbol tracking over node trees.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_idtracking.py imports nodes and symbols_for_node and exercises symbol tracking over node trees, satisfying the idtracking test contract.
```

- **Sources:**
  - `tests/test_idtracking.py`
