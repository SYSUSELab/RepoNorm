# Rule details

- **Rule:** Adding an undefined value in a native template must raise UndefinedError during rendering rather than producing a native result.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying the native-template undefined-value test in the native types test module
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_adding_undefined_native_return deliberately renders {{ 3 + missing }} inside pytest.raises(UndefinedError), asserting the rule's expected error behavior.
```

- **Sources:**
  - `tests/test_nativetypes.py:26-30`
