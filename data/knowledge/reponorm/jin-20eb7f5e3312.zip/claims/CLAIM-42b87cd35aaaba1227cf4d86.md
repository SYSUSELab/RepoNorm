# Rule details

- **Rule:** Async filter tests must exercise filters through the async environment's awaitable pipeline, so map/selectattr/join chains over async iterables render the same results as their sync counterparts.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When adding or modifying async filter tests that chain map, selectattr, sum, or join over async iterables.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_join_attribute composes the join filter with an attribute argument over the async environment and asserts the rendered result 'foo, bar'.
```

- **Sources:**
  - `tests/test_async_filters.py:117-119`
