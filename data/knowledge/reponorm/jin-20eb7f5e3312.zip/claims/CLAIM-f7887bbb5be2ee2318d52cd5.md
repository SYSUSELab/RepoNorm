# Rule details

- **Rule:**
  ```text
  Tests that exercise Jinja's identifier validity rules must assert that unicode letters are valid identifier starts, digits and hyphens are invalid, and certain unicode characters (\u1885, \u1886, \u2118, \u212e) are valid starts though not matched by \w, while \xb7 is only valid as a continue character, because this defines the lexer's identifier contract.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for Jinja identifier validity rules in the lexer
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_name parametrizes identifier validity cases and asserts valid names parse while invalid ones raise TemplateSyntaxError, matching the lexer identifier validity rules.
```

- **Sources:**
  - `tests/test_lexnparse.py:157-164`
