# Rule details

- **Rule:** YAML, JSON, JavaScript, CSS, and HTML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
indent_size = 2

```

- **Sources:**
  - `.editorconfig:13`
