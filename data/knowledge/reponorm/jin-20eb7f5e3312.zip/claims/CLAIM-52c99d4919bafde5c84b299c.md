# Rule details

- **Rule:**
  ```text
  The `reverse` filter must reverse strings ('foobar'|reverse|join -> 'raboof') and lists ([1,2,3]|reverse|list -> [3, 2, 1]).
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the `reverse` filter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_reverse asserts both string reversal ('foobar'|reverse|join -> 'raboof') and list reversal ([1,2,3]|reverse|list -> [3,2,1]), matching the rule.
```

- **Sources:**
  - `tests/test_filters.py:288-292`
