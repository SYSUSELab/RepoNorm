# Rule details

- **Rule:** Tests that exercise Jinja's select filter must assert that falsy values (None, False, 0) are dropped, because this defines the select filter's truthiness contract.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When adding or modifying tests for the select filter's handling of falsy values
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_bool_select renders select over [None, False, 0, 1, 2, 3, 4, 5] and asserts output '1|2|3|4|5', confirming falsy values are dropped.
```

- **Sources:**
  - `tests/test_async_filters.py:141-143`
