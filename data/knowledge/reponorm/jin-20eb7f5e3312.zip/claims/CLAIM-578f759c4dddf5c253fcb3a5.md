# Rule details

- **Rule:** Coverage source measurement is limited to the jinja2 and tests directories.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
source =
    jinja2
    tests

```

- **Sources:**
  - `setup.cfg:55-57`
