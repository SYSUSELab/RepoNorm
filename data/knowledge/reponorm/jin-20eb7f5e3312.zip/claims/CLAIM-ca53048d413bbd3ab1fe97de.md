# Rule details

- **Rule:**
  ```text
  Environment.select_template must preserve its documented compatibility boundaries: raise TemplatesNotFound for an empty names list, raise UndefinedError when names is Undefined, return Template objects unchanged, and since 3.0 update cached template globals rather than ignoring new values.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying select_template or its error handling and cached-globals update behavior.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Environment.select_template raises TemplatesNotFound for empty names, raises UndefinedError for Undefined names, returns Template objects unchanged, and passes globals to _load_template for cached-globals update.
```

- **Sources:**
  - `src/jinja2/environment.py:1003-1054`
