# Rule details

- **Rule:**
  ```text
  Lexer rule assembly must sort root tag rules by length so longer delimiters (e.g. `<%`) are matched before shorter ones, because `|` is ungreedy; and lstrip_blocks must be suppressed when non-whitespace precedes the newline via lstrip_unless_re.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when adding or reordering lexer tag rules or modifying lstrip_blocks handling
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Lexer.__init__ assembles root tag rules and sorts by length so longer delimiters match first, and configures lstrip_unless_re to suppress lstrip_blocks when non-whitespace precedes the newline.
```

- **Sources:**
  - `src/jinja2/lexer.py:477-596`
