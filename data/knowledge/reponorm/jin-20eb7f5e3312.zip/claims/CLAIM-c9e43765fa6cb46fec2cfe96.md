# Rule details

- **Rule:**
  ```text
  ModuleLoader.get_module_filename must derive the module file name from get_template_key(name) plus '.py', coupling module template keys to their generated Python filenames.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ModuleLoader.get_module_filename or module template key/filename generation.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
ModuleLoader.get_module_filename returns ModuleLoader.get_template_key(name) + '.py', deriving the module filename from the template key plus '.py'.
```

- **Sources:**
  - `src/jinja2/loaders.py:623-624`
