# Rule details

- **Rule:** Tests that exercise Jinja's macro scoping across template inheritance must assert that a macro defined in a child template is callable inside an overridden block, because this defines the macro-scoping contract for inheritance.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:** When adding or modifying tests for macro scoping across template inheritance
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_fixed_macro_scoping_bug asserts a child-defined macro is callable inside an overridden block, yielding ['outer_box', 'my_macro'].
```

- **Sources:**
  - `tests/test_inheritance.py:356-398`
