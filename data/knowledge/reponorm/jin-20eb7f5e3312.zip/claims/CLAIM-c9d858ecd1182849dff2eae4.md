# Rule details

- **Rule:**
  ```text
  do_striptags must check for __html__ and call it to obtain the HTML string before stripping tags, so objects implementing the HTML protocol are stripped based on their HTML representation rather than str().
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_striptags or its handling of objects implementing __html__.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
do_striptags checks hasattr(value, '__html__'), calls __html__() to obtain the HTML string, then strips tags from Markup(str(value)), matching the HTML-protocol-before-stripping rule.
```

- **Sources:**
  - `src/jinja2/filters.py:1010-1015`
