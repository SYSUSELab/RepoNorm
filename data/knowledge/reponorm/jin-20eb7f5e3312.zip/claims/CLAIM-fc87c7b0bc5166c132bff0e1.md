# Rule details

- **Rule:**
  ```text
  InternationalizationExtension._uninstall must remove exactly the four gettext-related callables (gettext, ngettext, pgettext, npgettext) from environment.globals, keeping install/uninstall symmetric and leaving unrelated globals untouched.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** When modifying InternationalizationExtension install/uninstall or the set of globals it injects.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_uninstall pops exactly the four gettext-related callables (gettext, ngettext, pgettext, npgettext) from environment.globals, matching the install/uninstall symmetry rule and leaving unrelated globals untouched.
```

- **Sources:**
  - `src/jinja2/ext.py:339-341`
