# Rule details

- **Rule:**
  ```text
  Character-set generation for the identifier pattern must derive valid identifier characters by testing ('a'+s).isidentifier() rather than relying on regex \w, because \w matches some non-identifier characters that str.isidentifier rejects during lexing.
  ```
- **Applies to:**
  - `scripts/generate_identifier_pattern.py`
- **Condition:** When changing how the generator enumerates or filters candidate identifier characters.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
get_characters filters candidate characters using ('a'+s).isidentifier() and not re.match(r'\w', s), deriving validity via isidentifier rather than relying on \w.
```

- **Sources:**
  - `scripts/generate_identifier_pattern.py:7-23`
