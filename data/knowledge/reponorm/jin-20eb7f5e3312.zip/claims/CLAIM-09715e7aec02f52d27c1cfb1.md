# Rule details

- **Rule:** Tests that exercise Jinja's autoescape scoping must assert that variables set inside an {% autoescape %} block are scoped to that block and that the outer value is restored after {% endautoescape %}, because this defines the scoping contract for the autoescape extension.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for the autoescape extension's variable scoping behavior
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_scoping asserts the variable set inside {% autoescape %} is scoped to the block and the outer value is restored after {% endautoescape %}.
```

- **Sources:**
  - `tests/test_ext.py:667-673`
