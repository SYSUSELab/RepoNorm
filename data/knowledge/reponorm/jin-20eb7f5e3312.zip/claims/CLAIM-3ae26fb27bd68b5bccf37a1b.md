# Rule details

- **Rule:**
  ```text
  The babel.extractors entry point registers the jinja2 extractor as jinja2.ext:babel_extract[i18n].
  ```
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
babel.extractors =
    jinja2 = jinja2.ext:babel_extract[i18n]

```

- **Sources:**
  - `setup.cfg:43-44`
