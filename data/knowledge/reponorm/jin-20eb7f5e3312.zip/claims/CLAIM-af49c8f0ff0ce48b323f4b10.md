# Rule details

- **Rule:** The tests job installs tox and runs the tox environment selected by the matrix's tox value.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - run: pip install tox
      - run: tox -e ${{ matrix.tox }}

```

- **Sources:**
  - `.github/workflows/tests.yaml:54-55`
