# Repository knowledge

Apply rules within their stated scope and when their conditions hold, respecting
exceptions. `required`, `recommended`, and `observed` have different strength:
an observed convention does not by itself prohibit a change requested by the task.
`reference_only` is context, not a default action.
Evidence locations identify sources, not the rule's scope.
Commands in rules do not authorize unrelated changes or external side effects.
Use relevant rules alongside the task and repository code; keep edits focused.

## Find rules

Path links and the [full catalog](catalog.md) are alternative routes. Search or
open relevant files directly; open claim details when evidence or a conflict matters.
Paths are navigation anchors, not a replacement for each rule's complete scope.

- `repository root`: [Read rules](paths/repository.md)
- `.pre-commit-config.yaml`: [Read rules](paths/.pre-commit-config.yaml.md)
- `docs/conf.py`: [Read rules](paths/docs/conf.py.md)
- `docs/examples/cache_extension.py`: [Read rules](paths/docs/examples/cache_extension.py.md)
- `examples/basic`: [Read rules](paths/examples/basic.md)
- `jinja2`: [Read rules](paths/jinja2.md)
- `requirements/docs.txt`: [Read rules](paths/requirements/docs.txt.md)
- `requirements/typing.txt`: [Read rules](paths/requirements/typing.txt.md)
- `scripts/generate_identifier_pattern.py`: [Read rules](paths/scripts/generate_identifier_pattern.py.md)
- `setup.cfg`: [Read rules](paths/setup.cfg.md)
- `src/jinja2`: [Read rules](paths/src/jinja2.md)
- `src/jinja2/__init__.py`: [Read rules](paths/src/jinja2/__init__.py.md)
- `src/jinja2/bccache.py`: [Read rules](paths/src/jinja2/bccache.py.md)
- `src/jinja2/environment.py`: [Read rules](paths/src/jinja2/environment.py.md)
- `src/jinja2/exceptions.py`: [Read rules](paths/src/jinja2/exceptions.py.md)
- `src/jinja2/ext.py`: [Read rules](paths/src/jinja2/ext.py.md)
- `src/jinja2/filters.py`: [Read rules](paths/src/jinja2/filters.py.md)
- `src/jinja2/lexer.py`: [Read rules](paths/src/jinja2/lexer.py.md)
- `src/jinja2/loaders.py`: [Read rules](paths/src/jinja2/loaders.py.md)
- `src/jinja2/meta.py`: [Read rules](paths/src/jinja2/meta.py.md)
- `src/jinja2/nodes.py`: [Read rules](paths/src/jinja2/nodes.py.md)
- `src/jinja2/parser.py`: [Read rules](paths/src/jinja2/parser.py.md)
- `src/jinja2/runtime.py`: [Read rules](paths/src/jinja2/runtime.py.md)
- `src/jinja2/sandbox.py`: [Read rules](paths/src/jinja2/sandbox.py.md)
- `src/jinja2/tests.py`: [Read rules](paths/src/jinja2/tests.py.md)
- `src/jinja2/utils.py`: [Read rules](paths/src/jinja2/utils.py.md)
- `src/jinja2/visitor.py`: [Read rules](paths/src/jinja2/visitor.py.md)
- `tests`: [Read rules](paths/tests.md)
- `tests/conftest.py`: [Read rules](paths/tests/conftest.py.md)
- `tests/test_async.py`: [Read rules](paths/tests/test_async.py.md)
- `tests/test_async_filters.py`: [Read rules](paths/tests/test_async_filters.py.md)
- `tests/test_compile.py`: [Read rules](paths/tests/test_compile.py.md)
- `tests/test_debug.py`: [Read rules](paths/tests/test_debug.py.md)
- `tests/test_ext.py`: [Read rules](paths/tests/test_ext.py.md)
- `tests/test_filters.py`: [Read rules](paths/tests/test_filters.py.md)
- `tests/test_idtracking.py`: [Read rules](paths/tests/test_idtracking.py.md)
- `tests/test_inheritance.py`: [Read rules](paths/tests/test_inheritance.py.md)
- `tests/test_lexnparse.py`: [Read rules](paths/tests/test_lexnparse.py.md)
- `tests/test_nativetypes.py`: [Read rules](paths/tests/test_nativetypes.py.md)
- `tests/test_tests.py`: [Read rules](paths/tests/test_tests.py.md)
