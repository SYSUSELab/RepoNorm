# Full rule catalog

## Rule 001 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  When modifying BytecodeCache.get_source_checksum, preserve the computation of sha1 of the UTF-8 encoded source as a hex digest, which defines the cache key basis for bytecode caching.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying the source checksum computation for bytecode caching
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0183bf07703eff95178aea00.md)

## Rule 002 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Template._get_default_module_async must return a fresh module built from ctx.parent values when ctx has globals not present in self.globals, otherwise lazily create and cache self._module via make_module_async.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Template._get_default_module_async or async module caching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0197c2838251d742ed5c79d6.md)

## Rule 003 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.parse_expression must dispatch to parse_condexpr when with_condexpr is true and to parse_or otherwise, so callers can suppress conditional-expression parsing.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.parse_expression or adding a caller that relies on suppressing conditional-expression parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-03ba7d8d20620385e960b8b4.md)

## Rule 004 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  When adding or modifying a lexer rule, represent it as a _Rule NamedTuple whose pattern, tokens (string, tuple of strings, or tuple of Failure), and optional command fields follow the existing rule protocol.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** when adding or modifying a lexer rule in the lexer module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-05ac3c57d95b090598751fbd.md)

## Rule 005 — `src/jinja2/bccache.py`

- **Rule:** BytecodeCache.clear is not used by Jinja itself but is expected to be implemented so applications can clear a particular environment's bytecode cache, defining an optional-but-expected extension method.
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying BytecodeCache.clear or the bytecode-cache clearing contract it defines.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-069ed89fa24880a36f4a75f7.md)

## Rule 006 — `**/*.css`

- **Rule:** YAML, JSON, JavaScript, CSS, and HTML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-06f3a771a8b8ffcfd8aadd95.md)

## Rule 007 — `tests/test_ext.py`

- **Rule:** Tests that exercise Jinja's autoescape scoping must assert that variables set inside an {% autoescape %} block are scoped to that block and that the outer value is restored after {% endautoescape %}, because this defines the scoping contract for the autoescape extension.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for the autoescape extension's variable scoping behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09715e7aec02f52d27c1cfb1.md)

## Rule 008 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Environment.make_globals must return a ChainMap of template-specific globals over environment globals so template-level global changes do not mutate environment globals; callers must not modify globals after a template is loaded.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Environment.make_globals or template global handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09fe9ed5ec74ac247b60dae4.md)

## Rule 009 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  do_float must return the configured default (0.0 by default) when float() raises TypeError or ValueError, so conversion failures are silent rather than propagated.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_float or its default handling for failed numeric conversions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c8285f775995cc2da8851cf.md)

## Rule 010 — `tests/test_lexnparse.py`

- **Rule:**
  ```text
  A parenthesized comparison inside arithmetic must render as a boolean coerced to int, e.g. {{ i * (j < 5) }} with i=2, j=3 yields '2'.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying parenthesized-comparison-in-arithmetic tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1560d56c280434ea7c86f4b5.md)

## Rule 011 — `src/jinja2/utils.py`

- **Rule:** The cycle helper must raise RuntimeError when constructed with no items, enforcing that at least one item is provided.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when modifying the Cycler constructor or cycle helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1b552c6f0d6ec1267bfb6238.md)

## Rule 012 — `**`

- **Rule:** Read the Docs builds use Ubuntu 20.04 as the build OS.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1ba3c9477127f0f840e7d62e.md)

## Rule 013 — `src/jinja2/sandbox.py`

- **Rule:**
  ```text
  The @unsafe decorator must set the unsafe_callable attribute to True on the decorated function or method, which the sandbox inspects to deny calls.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying the @unsafe decorator or adding sandbox checks that rely on the unsafe_callable marker.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1fcfeee568d43ed76c464a7c.md)

## Rule 014 — `tests/test_idtracking.py`

- **Rule:**
  ```text
  Tests for idtracking must exercise symbol tracking over node trees by importing nodes and symbols_for_node.
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:** When modifying or adding idtracking tests that exercise symbol tracking over node trees.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-210c4092fd0ddeb8d5b56ba2.md)

## Rule 015 — `src/jinja2/ext.py`

- **Rule:** The new-style npgettext wrapper is generated by a factory function that returns a callable accepting a context, singular, plural, and count.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  when modifying _make_new_npgettext or the npgettext wrapper signature
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-24a2c476eee0ebcf43b3f2d7.md)

## Rule 016 — `examples/basic/**/*.py`

- **Rule:**
  ```text
  Example scripts under examples/basic/ that demonstrate a Jinja feature must configure the Environment with the exact option combination the feature requires (e.g. line_statement_prefix plus custom variable delimiters, or jinja2.ext.i18n with gettext/ngettext globals) rather than relying on defaults.
  ```
- **Applies to:**
  - `examples/basic/**/*.py`
- **Condition:** When adding or modifying an example script that demonstrates a Jinja feature requiring non-default Environment options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-250736a427bc04a6ed5a7ed9.md)
