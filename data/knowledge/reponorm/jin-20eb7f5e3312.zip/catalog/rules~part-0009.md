# Full rule catalog

## Rule 131 — `src/jinja2/ext.py`

- **Rule:**
  ```text
  InternationalizationExtension._uninstall must remove exactly the four gettext-related callables (gettext, ngettext, pgettext, npgettext) from environment.globals, keeping install/uninstall symmetric and leaving unrelated globals untouched.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** When modifying InternationalizationExtension install/uninstall or the set of globals it injects.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fc87c7b0bc5166c132bff0e1.md)

## Rule 132 — `tests/test_async_filters.py`

- **Rule:** Tests that exercise Jinja's select filter must assert that falsy values (None, False, 0) are dropped, because this defines the select filter's truthiness contract.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When adding or modifying tests for the select filter's handling of falsy values
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fd0fef2001e75111631cfe6e.md)

## Rule 133 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  Lexer rule assembly must sort root tag rules by length so longer delimiters (e.g. `<%`) are matched before shorter ones, because `|` is ungreedy; and lstrip_blocks must be suppressed when non-whitespace precedes the newline via lstrip_unless_re.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when adding or reordering lexer tag rules or modifying lstrip_blocks handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fe4c813be55e160de16d986f.md)

## Rule 134 — `requirements/typing.txt`

- **Rule:** The tox testenv:typing environment installs its dependencies from requirements/typing.txt.
- **Applies to:**
  - `requirements/typing.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fff74fae962728f25501edd6.md)
