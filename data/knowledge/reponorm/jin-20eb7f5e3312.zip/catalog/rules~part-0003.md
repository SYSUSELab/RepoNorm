# Full rule catalog

## Rule 034 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Template.render must detect an async environment and run render_async on an event loop, creating and closing a new loop only when no running loop exists.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when modifying Template.render or the async rendering bridge
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-55fafae20900edc8438c8509.md)

## Rule 035 — `docs/conf.py`

- **Rule:**
  ```text
  The docs build configuration must derive `release`/`version` from `pallets_sphinx_themes.get_version("Jinja2")`, set `html_title` to `f"Jinja Documentation ({version})"`, and embed the version in the LaTeX output filename.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:** When modifying the docs build configuration's version derivation, HTML title, or LaTeX output filename.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-564d67bfd73a8dd5caf1d1e0.md)

## Rule 036 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  select_autoescape must normalize enabled and disabled extensions by stripping leading dots and lowercasing them, operating case-insensitively for security reasons, with default_for_string controlling string templates and default controlling unmatched filenames.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying select_autoescape or autoescape extension matching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-567f7565c4de649da6fdef9f.md)

## Rule 037 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  fail_eof builds an end-token stack from the current parser state and optional end_tokens before delegating to _fail_ut_eof for end-of-template error reporting.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.fail_eof or end-of-template error reporting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-56eebd8868b6919dae8ff8c9.md)

## Rule 038 — `src/jinja2/visitor.py`

- **Rule:**
  ```text
  NodeVisitor.__call__ must remain an abstract/overridable dispatch entry point in the visitor protocol.
  ```
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:** When modifying NodeVisitor or adding visitor subclasses that rely on the dispatch entry point.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-577ba1cfe59a56403343d90c.md)

## Rule 039 — `jinja2/**`

- **Rule:** Coverage source measurement is limited to the jinja2 and tests directories.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-578f759c4dddf5c253fcb3a5.md)

## Rule 040 — `src/jinja2/exceptions.py`

- **Rule:**
  ```text
  TemplateError.__init__ must accept an optional message and forward it to super().__init__, so exceptions may be constructed without a message.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:**
  ```text
  when modifying TemplateError.__init__ or the optional-message exception construction contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-59705d77dcf3d574072ebc3d.md)

## Rule 041 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  When modifying the parser's not handling, preserve that parse_not recursively consumes 'not' tokens so repeated 'not not x' nests Not nodes.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  Changing parse_not's recursion or Not node construction for chained negation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5e24663f3c69ef95547465e7.md)

## Rule 042 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  do_random catches IndexError from random.choice and returns context.environment.undefined with the message 'No random item, sequence was empty.', so empty sequences yield Undefined rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_random or random filter empty-sequence handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5e46141b402802a84246ae1f.md)

## Rule 043 — `src/jinja2/tests.py`

- **Rule:**
  ```text
  tests.test_divisibleby returns value % num == 0, defining the divisibleby test semantics.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_divisibleby or divisibleby test semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5e64b987cda0db2877a55c32.md)

## Rule 044 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  FileSystemLoader.list_templates must walk every configured searchpath with os.walk(followlinks=self.followlinks), normalize each discovered path to a forward-slash path relative to its searchpath, strip a leading './', deduplicate across searchpaths, and return the sorted result.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying FileSystemLoader.list_templates or the path-normalization/deduplication logic it uses to enumerate templates across searchpaths.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6015408ff6fe2a3bca7a1ed0.md)

## Rule 045 — `src/jinja2/tests.py`

- **Rule:**
  ```text
  The `number` test must be defined as isinstance(value, Number), so it accepts any registered numbers.Number (including complex and Decimal), not just int/float.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  When modifying the `number` test or adding a new numeric test that must match the existing acceptance criteria.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-603a55430c63ec95b8a59464.md)

## Rule 046 — `.pre-commit-config.yaml`

- **Rule:** Pre-commit autoupdate is scheduled monthly.
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-639cde7539a659e1c6e87df7.md)

## Rule 047 — `src/jinja2/ext.py`

- **Rule:**
  ```text
  _install_callables must update environment globals gettext, ngettext, pgettext, npgettext; when newstyle_gettext is enabled it wraps gettext/ngettext and, if provided, pgettext/npgettext with new-style adapters, and an explicit newstyle argument overrides environment.newstyle_gettext.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When modifying _install_callables or the i18n callable installation and new-style gettext wrapping it implements.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-63dd8546fa56c59c72e7fd61.md)

## Rule 048 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  The lexer module defines operators and reverse_operators with an assertion that len(operators) == len(reverse_operators) ('operators dropped'), and builds operator_re by sorting operator keys by descending length so multi-character operators match before single-character ones.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when modifying lexer operator tables or operator_re construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-687390320271df6c7bfc2619.md)

## Rule 049 — `tests/test_filters.py`

- **Rule:** The urlize filter's target parameter must be rendered as an anchor target attribute while rel="noopener" is always added, so callers cannot opt out of rel=noopener via target.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the urlize target-parameter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-68b94bf7efcfd5d7b3c1a9aa.md)
