# Full rule catalog

## Rule 017 — `src/jinja2/bccache.py`

- **Rule:** When modifying FileSystemBytecodeCache, preserve the platform-specific default cache directory selection: the user's temp directory on Windows and a per-user directory under the system temp directory on UNIX.
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying the default cache directory selection for FileSystemBytecodeCache
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2960ea8fd45ac298535cd4aa.md)

## Rule 018 — `src/jinja2/meta.py`

- **Rule:**
  ```text
  find_referenced_templates must yield None for any dynamic (non-constant) template reference, including dynamic entries inside tuple/list literals, so dependency tracking treats None as an unresolvable dependency.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:**
  ```text
  When modifying find_referenced_templates or the dependency-tracking logic that consumes its output for dynamic template references.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2b15304441769d2dc032012c.md)

## Rule 019 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Extension stream-filtering must preserve the protocol that Environment._tokenize applies each extension's filter_stream to the token stream and wraps any non-TokenStream return value in a TokenStream before continuing.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment._tokenize or adding an extension that overrides filter_stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c65a7c0e006aea8b15f026d.md)

## Rule 020 — `src/jinja2/exceptions.py`

- **Rule:** When modifying the exception hierarchy, preserve that TemplateRuntimeError subclasses TemplateError and remains the generic runtime error Jinja may raise.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** Changing TemplateRuntimeError's base class or its role as the generic runtime error.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c7a1bfaac41e9dd375dc318.md)

## Rule 021 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.parse_math1 must handle additive operators (add/sub) at a precedence level below parse_concat, using _math_nodes to map token types to AST node classes and constructing each binary node with the left operand's starting lineno.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.parse_math1 or adding a new additive operator that must respect the existing precedence level.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3371939e8969d1471e27d476.md)

## Rule 022 — `**`

- **Rule:** Read the Docs installs the repository itself via pip from the current directory.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3503130396900f69e66037a8.md)

## Rule 023 — `setup.cfg`

- **Rule:**
  ```text
  The babel.extractors entry point registers the jinja2 extractor as jinja2.ext:babel_extract[i18n].
  ```
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3ae26fb27bd68b5bccf37a1b.md)

## Rule 024 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  is_undefined must remain an instance check against Undefined so custom filters and tests (e.g. a custom default filter) can detect undefined variables.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying is_undefined or adding custom filters/tests that must react to undefined variables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3c2f1b78967395e1553bb16f.md)

## Rule 025 — `**`

- **Rule:**
  ```text
  The tox testenv:style environment runs `pre-commit run --all-files --show-diff-on-failure` as its command.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Detail:** [Open claim details](../claims/CLAIM-3f3bb88d5be85a8ee4f65c3c.md)

## Rule 026 — `tests/test_async_filters.py`

- **Rule:** Async filter tests must exercise filters through the async environment's awaitable pipeline, so map/selectattr/join chains over async iterables render the same results as their sync counterparts.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When adding or modifying async filter tests that chain map, selectattr, sum, or join over async iterables.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-42b87cd35aaaba1227cf4d86.md)

## Rule 027 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  bccache must define bc_version = 5 and bc_magic combining 'j2' with the pickled version and Python major/minor version, so cached bytecode is invalidated across Python version upgrades.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying bccache version constants or bytecode cache invalidation logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4c56088b57e660c0129f11f8.md)

## Rule 028 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  FileSystemBytecodeCache must keep the default filename pattern '__jinja2_%s.cache' with %s substituted by the cache key, so multiple caches can safely share one directory.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying FileSystemBytecodeCache filename construction or its default pattern.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4d1508f23330d99aef703ad2.md)

## Rule 029 — `tests/test_filters.py`

- **Rule:** The first filter must return the first element of an iterable, asserted as '0' for range(10).
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying the first-filter test in the filter test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-51cc44d408ebbdeff8a6dcc1.md)

## Rule 030 — `tests/test_filters.py`

- **Rule:**
  ```text
  The `reverse` filter must reverse strings ('foobar'|reverse|join -> 'raboof') and lists ([1,2,3]|reverse|list -> [3, 2, 1]).
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the `reverse` filter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-52c99d4919bafde5c84b299c.md)

## Rule 031 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  When modifying the bytecode cache extension point, preserve that BytecodeCache subclasses must override load_bytecode and dump_bytecode, both receiving a Bucket.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  Changing BytecodeCache's documented extension contract or the Bucket interface passed to load_bytecode/dump_bytecode.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-53ac5ccca230a0a19c23d097.md)

## Rule 032 — `requirements/docs.txt`

- **Rule:** Read the Docs installs documentation dependencies from requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-552ed8fc603a8a3458f62547.md)

## Rule 033 — `tests/conftest.py`

- **Rule:**
  ```text
  The package_loader fixture in tests/conftest.py must return a PackageLoader initialized with package 'res' and templates directory 'templates', because this defines the shared fixture contract for tests that load templates from a package.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  When adding or modifying the package_loader fixture in tests/conftest.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-55c05eea01f6baa9c9c53187.md)
