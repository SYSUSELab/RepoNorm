# Full rule catalog

## Rule 067 — `tests/test_nativetypes.py`

- **Rule:**
  ```text
  Tests that exercise Jinja's nativetypes rendering must assert that rendering a dunder attribute like __class__ yields a native Python type instance, because this defines the nativetypes contract for attribute access.
  ```
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying tests for nativetypes rendering of dunder attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8a89bf9cfa7112f8e8911f34.md)

## Rule 068 — `docs/examples/cache_extension.py`

- **Rule:**
  ```text
  The documented cache extension must call `super().__init__(environment)` and register `fragment_cache_prefix` and `fragment_cache` defaults via `environment.extend`.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** When modifying the cache extension's initialization or its environment defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8afe274747ccacaae3c3a699.md)

## Rule 069 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  sync_do_sum must support an attribute parameter that maps make_attrgetter over the iterable before summing, and a start parameter (default 0) passed as the initial value to sum.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying sync_do_sum or the sum filter's attribute/start parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8b7768df62a305c4086ce2df.md)

## Rule 070 — `src/jinja2/bccache.py`

- **Rule:** When modifying Bucket or bytecode cache subclasses, preserve the internal checksum assigned by the bytecode cache that automatically rejects outdated cache material, so subclasses do not need to implement cache invalidation themselves.
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying Bucket or bytecode cache subclass invalidation behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8c01508edc7092b580d28227.md)

## Rule 071 — `tests/test_compile.py`

- **Rule:** Compiled template output for multiple 'import ... with context' statements must be deterministic: the first ten 'barN': entries appear in ascending N order.
- **Applies to:**
  - `tests/test_compile.py`
- **Condition:**
  ```text
  When modifying the deterministic import-with-context compilation test in tests/test_compile.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8e5984a1d301f5c75cc60638.md)

## Rule 072 — `tests/test_debug.py`

- **Rule:** The debug test helper must assert that a formatted traceback matches an expected regex pattern, failing with the full traceback and expected pattern when no match is found.
- **Applies to:**
  - `tests/test_debug.py`
- **Condition:**
  ```text
  When modifying the traceback-matching debug test helper in tests/test_debug.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-95c7d698a8dc476dd80495ef.md)

## Rule 073 — `src/jinja2/meta.py`

- **Rule:**
  ```text
  The introspection environment must initialize an undeclared_identifiers set on the instance as the accumulator used to report undeclared names during meta analysis.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:** When modifying the introspection environment initialization or the undeclared-name accumulator used during meta analysis.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-961e1094f45e92b406b9a17b.md)

## Rule 074 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  LRUCache.__setstate__ must update the instance dict and then call _postinit, so unpickling re-runs post-initialization logic.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying LRUCache.__setstate__ or unpickling/post-initialization behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9d38ea4b0312adbc0a300236.md)

## Rule 075 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Template test parsing in Parser.parse_test must accept a leading `not` negation, dotted test names, optional call arguments, and a bare-argument form, while explicitly rejecting chained `is` tests with a failure.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.parse_test or the grammar for `is` test expressions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9e4d48137094e2998724698f.md)

## Rule 076 — `tests/test_inheritance.py`

- **Rule:** Required blocks may only contain comments or whitespace; templates where a required block contains data, nested blocks, or if-statements must raise TemplateSyntaxError with message 'Required blocks can only contain comments or whitespace'.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:** When adding or modifying the invalid-required-block test in the inheritance test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9fec71725d868ea43c7656a4.md)

## Rule 077 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.is_tuple_end must treat variable_end, block_end, and rparen as tuple terminators and additionally accept caller-supplied extra_end_rules via test_any, defining tuple-end detection boundaries.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.is_tuple_end or adding a caller that supplies extra_end_rules.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a14b646275f6437555daa3bf.md)

## Rule 078 — `tests/test_lexnparse.py`

- **Rule:**
  ```text
  With trim_blocks=True and lstrip_blocks=True, nested if blocks must render to 'a b c ' with the trailing space preserved, demonstrating combined whitespace-trimming behavior for nested block tags.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying nested-block whitespace-trimming tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a2eb4fe206a13bbb8cba4997.md)

## Rule 079 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying filter argument validation, preserve that do_dictsort accepts only by='key' or by='value' and raises FilterArgumentError for any other value before sorting.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing do_dictsort's accepted by values or its error handling for invalid arguments.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a36046adf954e805a764dcfa.md)

## Rule 080 — `**/*.py`

- **Rule:** flake8 ignores E203, E501, E722, and W503.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a4cdf2dba99afcbd5315e4ab.md)

## Rule 081 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  OptionalLStrip must remain a tuple subclass with __slots__ = () used to mark a lexer state point where lstrip may be applied; instances fail to create without the slots declaration.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When modifying OptionalLStrip or adding a new lexer state marker that must be instantiable.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a55a132d2f1201a90d8890c8.md)
