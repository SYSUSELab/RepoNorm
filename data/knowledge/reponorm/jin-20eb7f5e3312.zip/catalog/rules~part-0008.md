# Full rule catalog

## Rule 115 — `src/jinja2/ext.py`

- **Rule:**
  ```text
  Extension.bind must create a new instance via object.__new__(self.__class__) and copy __dict__, then set environment, so bound extensions share state with the original except for the environment attribute.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** When modifying Extension.bind or extension binding/environment association behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d78474ac5e1898d12e0b51b1.md)

## Rule 116 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  The async to_list helper collects generate_async output into a list, providing the async counterpart to synchronous template rendering.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Template.generate.to_list or async template rendering helpers
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d7b4df4d209b35065d1e9006.md)

## Rule 117 — `src/jinja2/**`

- **Rule:** mypy is configured to check the files under src/jinja2.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d974357b7ecf799c8cee2a2c.md)

## Rule 118 — `**`

- **Rule:**
  ```text
  The tox testenv:style environment sets skip_install to true.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-de7043724ca778c8b8a85953.md)

## Rule 119 — `**/*.py`

- **Rule:** flake8 enforces a maximum line length of 80.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e06ab2a82b69f8e8da990be4.md)

## Rule 120 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.parse_primary must treat both lowercase and capitalized spellings as literals: true/True and false/False become Const booleans, none/None become Const None, and adjacent string tokens are concatenated into a single Const with the first token's lineno.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.parse_primary or template literal parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e2e2ed0312392bbf04450ecc.md)

## Rule 121 — `scripts/generate_identifier_pattern.py`

- **Rule:** Range collapsing for the identifier pattern must group sorted unique characters into sequential code-point ranges using itertools.groupby on ord(char) - index, yielding (start, end) pairs.
- **Applies to:**
  - `scripts/generate_identifier_pattern.py`
- **Condition:** When changing how the generator collapses character sets into ranges.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e31ffdbf81ee0b9f8b3f871e.md)

## Rule 122 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  Cycler.current must return self.items[self.pos], i.e. the item that will be returned by the next call to next.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying Cycler.current or adding a new iterator property that must match the next-item semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e44ea74cacdd84a1ebe13ca5.md)

## Rule 123 — `src/jinja2/exceptions.py`

- **Rule:**
  ```text
  TemplatesNotFound builds its default message by joining the names, using each Undefined name's _undefined_message, and passes names[-1] (or None when empty) as the first argument to the parent exception while storing the full list in self.templates.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:**
  ```text
  when modifying TemplatesNotFound.__init__ message construction or argument passing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ea8b7726e9ca56324a1c6509.md)

## Rule 124 — `src/jinja2/sandbox.py`

- **Rule:**
  ```text
  When modifying sandboxed call handling, preserve that SandboxedEnvironment.call first checks for a format method and routes to format_string, otherwise verifies is_safe_callable and raises SecurityError.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** Changing sandboxed call dispatch, format-method routing, or safety verification.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ebc4dbe2548c9431530a4b9e.md)

## Rule 125 — `tests/test_tests.py`

- **Rule:**
  ```text
  Comparison test aliases must be asserted through the `is` test operator with parametrized op strings (e.g. 'eq 2') and expected booleans, covering eq/ne/lt/le/gt/ge aliases.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When adding or modifying comparison-alias tests in tests/test_tests.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed47478d587ba0aabf60aec5.md)

## Rule 126 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Environment._load_template must key the cache by (weakref.ref(self.loader), name); on a cache hit with auto_reload disabled or an up-to-date template it must update template.globals with the passed globals and return the cached template, otherwise load and store the template.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Environment._load_template or the template cache
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f1260d1652b98e6ee19a5fdc.md)

## Rule 127 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Environment.add_extension must update the environment's extensions mapping via load_extensions so extensions can be registered after environment creation.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment.add_extension or the post-creation extension registration path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f1be17523229e5c3c58197b5.md)

## Rule 128 — `tests/test_inheritance.py`

- **Rule:**
  ```text
  Multi-level template inheritance with super() must resolve across nested blocks, rendering '--INTRO--|BEFORE|[(INNER)]|AFTER' for a three-level chain.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying multi-level inheritance super() tests in tests/test_inheritance.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f245833d5eeba6feca0099ac.md)

## Rule 129 — `tests/test_lexnparse.py`

- **Rule:**
  ```text
  Tests that exercise Jinja's identifier validity rules must assert that unicode letters are valid identifier starts, digits and hyphens are invalid, and certain unicode characters (\u1885, \u1886, \u2118, \u212e) are valid starts though not matched by \w, while \xb7 is only valid as a continue character, because this defines the lexer's identifier contract.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for Jinja identifier validity rules in the lexer
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f7887bbb5be2ee2318d52cd5.md)

## Rule 130 — `tests/test_compile.py`

- **Rule:** Tests for compiled template filter ordering must assert that compiled output references filters in a deterministic order matching the template's filter usage order.
- **Applies to:**
  - `tests/test_compile.py`
- **Condition:**
  ```text
  When modifying or adding compiled template filter-ordering tests in tests/test_compile.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f945ed86fa64421730dc4e1e.md)
