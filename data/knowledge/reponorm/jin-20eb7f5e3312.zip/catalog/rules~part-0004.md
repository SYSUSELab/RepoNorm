# Full rule catalog

## Rule 050 — `src/jinja2/loaders.py`

- **Rule:** PackageLoader supports only packages installed as directories or zip/egg files; PEP 420 namespace packages have limited support with the template directory assumed in one contributor, and zip files contributing to a namespace are unsupported. Since 3.0 it no longer depends on setuptools.
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** when modifying PackageLoader package discovery or template directory resolution
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-69e687bed39720b832a1207a.md)

## Rule 051 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  HasHTML is declared as a te.Protocol used to detect objects with an __html__ method for HTML-safe filter output.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when modifying HasHTML or HTML-safe filter output detection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6b96dac7f0b2131a55a178a5.md)

## Rule 052 — `src/jinja2/ext.py`

- **Rule:** When modifying the extension API, preserve that Extension.attr returns an ExtensionAttribute node scoped to the extension identifier, as the supported way for extensions to pass constants into generated template code.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Changing Extension.attr's node construction or the scoping of extension constants.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6c898047480a7bb3419c2a81.md)

## Rule 053 — `tests/test_inheritance.py`

- **Rule:** Tests that exercise Jinja's macro scoping across template inheritance must assert that a macro defined in a child template is callable inside an overridden block, because this defines the macro-scoping contract for inheritance.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:** When adding or modifying tests for macro scoping across template inheritance
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6cf9c63c855c7cde7c3515c2.md)

## Rule 054 — `tests/test_ext.py`

- **Rule:**
  ```text
  A macro defined in a non-autoescape environment must not be escaped when called inside an autoescape block; the rendered output remains raw '<html>'.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying autoescape macro behavior tests in tests/test_ext.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6d3e742109008e86966b4f10.md)

## Rule 055 — `tests/test_filters.py`

- **Rule:**
  ```text
  The `last` filter must return the final element of a list (e.g. rendering '9' for range(10)).
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the `last` filter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6eb0eede84bb992ad51911c4.md)

## Rule 056 — `src/jinja2/ext.py`

- **Rule:** The pgettext helper in the extension must return the source string unchanged, acting as a default no-op translation function.
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When modifying InternationalizationExtension._install_null.pgettext or adding a new null translation fallback.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6f6e3af30eb7f3294a8ed6e7.md)

## Rule 057 — `src/jinja2/ext.py`

- **Rule:**
  ```text
  _CommentFinder can only find comments for gettext calls forwards; once a later-line comment is found, an earlier-line comment will not return a usable value.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:**
  ```text
  When modifying _CommentFinder or i18n comment extraction ordering behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-73ad1bfcad66ab418baed2da.md)

## Rule 058 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.parse_postfix must loop over dot/lbracket/lparen tokens so calls are accepted after both postfix expressions and filters/tests, serving as the shared extension point for chained attribute, subscript, and call syntax.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.parse_postfix or adding chained attribute, subscript, or call syntax
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-749f22dc0c34d18e1b48fd82.md)

## Rule 059 — `src/jinja2/parser.py`

- **Rule:** Parser is the central parsing class passed to extensions, usable to parse expressions or statements.
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** when modifying Parser or the extension-facing parsing API
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-75af7e9246283b4f6db262d5.md)

## Rule 060 — `setup.cfg`

- **Rule:** Package discovery uses setuptools' find: directive, so packages are auto-discovered rather than listed explicitly.
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7bddd06a33b53897bff24f1a.md)

## Rule 061 — `**`

- **Rule:** Files in the repository are configured to trim trailing whitespace.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-80dfb5def178e436e9bc8468.md)

## Rule 062 — `**`

- **Rule:** The pre-commit configuration enables the fix-byte-order-marker hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-84e36d72633e2268c49557e2.md)

## Rule 063 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  _normalize_newlines replaces all newlines in strings and template data with the configured newline_sequence using newline_re, so lexer output depends on the environment's newline setting.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when modifying Lexer._normalize_newlines or newline handling in the lexer
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8563d948c05b4225f88f6b40.md)

## Rule 064 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Template.is_up_to_date must return True when the internal _uptodate callback is None, otherwise delegate to calling _uptodate(), so absence of a callback means the template is considered current.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Template.is_up_to_date or the _uptodate callback handling it implements.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-85e7860dc5ca5e148c8f0086.md)

## Rule 065 — `tests/test_filters.py`

- **Rule:**
  ```text
  The `sort` filter must support comma-separated dotted/indexed attribute paths for multi-key sorting, e.g. sort(attribute='value1.0,value2.0').
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the multi-key sort attribute test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-86972dee0d60688d0d0b6f00.md)

## Rule 066 — `tests/test_async.py`

- **Rule:** Async loop scope tests must assert that a loop variable (item) is not visible after the for loop ends, rendering empty output when referenced outside the loop.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying the async loop scope test in the async test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-886ee0da092e4985298348aa.md)
