# Full rule catalog

## Rule 082 — `scripts/generate_identifier_pattern.py`

- **Rule:**
  ```text
  Character-set generation for the identifier pattern must derive valid identifier characters by testing ('a'+s).isidentifier() rather than relying on regex \w, because \w matches some non-identifier characters that str.isidentifier rejects during lexing.
  ```
- **Applies to:**
  - `scripts/generate_identifier_pattern.py`
- **Condition:** When changing how the generator enumerates or filters candidate identifier characters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a7571cbf1e74f09db3a8be38.md)

## Rule 083 — `src/jinja2/nodes.py`

- **Rule:** MarkSafeIfAutoescape must remain an Expr node with a single 'expr' field that marks the wrapped expression as safe (Markup) only when autoescaping is active.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying MarkSafeIfAutoescape or the autoescape-conditional safety marking it implements.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a7a1ff1822e1edc8b0ad2e1c.md)

## Rule 084 — `src/jinja2/tests.py`

- **Rule:**
  ```text
  test_lower must coerce the value with str before calling islower(), so non-string values are stringified before the lowercase check.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_lower or the stringification behavior of the lowercase test
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a7ced2b43912a1785d553c34.md)

## Rule 085 — `tests/test_async.py`

- **Rule:**
  ```text
  Async loop filter tests must assert that 'for item in range(10) if item is even' yields [0][2][4][6][8] and that loop.index inside the filtered loop is 1-based over the filtered sequence, producing [1:0][2:2][3:4][4:6][5:8].
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying the async loop filter test in the async test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a94293f6919a09b16b9f017e.md)

## Rule 086 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  LRUCache.__contains__ must check key membership in the underlying _mapping, defining containment semantics for the cache wrapper.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  when modifying LRUCache.__contains__ or the cache wrapper containment semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aec18691e40c16951b05f94f.md)

## Rule 087 — `**`

- **Rule:** The tests job installs tox and runs the tox environment selected by the matrix's tox value.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-af49c8f0ff0ce48b323f4b10.md)

## Rule 088 — `src/jinja2/utils.py`

- **Rule:** Namespace is a container holding arbitrary attributes, initializable from a dictionary or keyword arguments.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when modifying Namespace initialization or attribute storage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b056a06fbb9ee058a9e5e9ae.md)

## Rule 089 — `examples/basic/**/*.py`

- **Rule:** Example scripts under examples/basic/ that demonstrate error debugging must construct an Environment with FileSystemLoader and render a deliberately broken template to serve as a runnable debugging demonstration rather than a library invariant.
- **Applies to:**
  - `examples/basic/**/*.py`
- **Condition:** When adding or modifying an example script that demonstrates template error debugging.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b9540ff75056b94a07f3da20.md)

## Rule 090 — `tests/**`

- **Rule:** Pytest test discovery is restricted to the tests directory via testpaths = tests.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ba02e408344a7c0f86a6b30f.md)

## Rule 091 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  str_join must define the runtime's canonical string-join semantics: it converts each item to str and concatenates via concat, so iterable joining in templates follows this conversion-and-concatenation behavior.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying str_join or template string-joining behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bd9e8edf73e846e18124865f.md)

## Rule 092 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Template.from_module_dict must be a classmethod that constructs a Template from a module dict and globals by delegating to _from_namespace, serving as the module loader's template-construction entry point.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Template.from_module_dict or the module loader's template construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bf5034bc393950c65e403cd7.md)

## Rule 093 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  DictLoader.get_source must return (source, None, uptodate) where uptodate is a closure comparing the current mapping value to the captured source, and must raise TemplateNotFound when the template name is absent.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying DictLoader.get_source or its uptodate/TemplateNotFound behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c2dd799779805a501a9073b4.md)

## Rule 094 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  Undefined._undefined_message must prioritize an explicit hint, then distinguish missing-object, non-string-name, and attribute cases to build the error message; custom undefined subclasses must preserve this precedence to keep messages consistent.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When modifying or subclassing undefined error-message construction in the runtime module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c2e5ec31a5bc4d03434131d1.md)

## Rule 095 — `tests/test_lexnparse.py`

- **Rule:**
  ```text
  With custom angle-bracket delimiters plus lstrip_blocks and trim_blocks, leading whitespace before a block tag must be stripped while trailing spaces after the block are preserved.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying the lstrip-blocks angle-bracket test in the lexer/parser test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c54702705ebb9a8a22d86043.md)

## Rule 096 — `tests/test_filters.py`

- **Rule:**
  ```text
  Filter chaining first|upper|escape must escape the uppercased first element, rendering '&lt;FOO&gt;'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying filter-chaining tests in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c73955b6676f7b065c84e5c1.md)

## Rule 097 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  open_if_exists must return None when the path is not a regular file and otherwise open it with the given mode (default 'rb'), defining the safe-open helper contract used by loaders.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  when modifying open_if_exists or loader code that relies on its safe-open contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c7bc9ab6cc400b5af0ea32dc.md)
