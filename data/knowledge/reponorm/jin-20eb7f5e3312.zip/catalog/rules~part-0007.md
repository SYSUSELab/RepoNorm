# Full rule catalog

## Rule 098 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  filters.do_pprint returns pformat(value), pretty-printing a variable for debugging.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_pprint or pretty-printing behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c8198959a8789fff0e82834e.md)

## Rule 099 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  get_eval_context requires that a node passed without an explicit EvalContext has an attached environment; otherwise it raises RuntimeError.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  when modifying get_eval_context or callers relying on implicit context from node.environment
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c8b9cdfd171c15597a2256c8.md)

## Rule 100 — `requirements/docs.txt`

- **Rule:** The docs tox environment installs its dependencies from requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c8e8d2d317e94f529981b3ce.md)

## Rule 101 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  do_striptags must check for __html__ and call it to obtain the HTML string before stripping tags, so objects implementing the HTML protocol are stripped based on their HTML representation rather than str().
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_striptags or its handling of objects implementing __html__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c9d858ecd1182849dff2eae4.md)

## Rule 102 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  ModuleLoader.get_module_filename must derive the module file name from get_template_key(name) plus '.py', coupling module template keys to their generated Python filenames.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ModuleLoader.get_module_filename or module template key/filename generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c9e43765fa6cb46fec2cfe96.md)

## Rule 103 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Environment.select_template must preserve its documented compatibility boundaries: raise TemplatesNotFound for an empty names list, raise UndefinedError when names is Undefined, return Template objects unchanged, and since 3.0 update cached template globals rather than ignoring new values.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying select_template or its error handling and cached-globals update behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca53048d413bbd3ab1fe97de.md)

## Rule 104 — `tests/test_tests.py`

- **Rule:** Tests that exercise Jinja's built-in test functions (defined, even, greaterthan) must assert the exact boolean result of the test, because these tests render Python booleans as the strings 'True'/'False' and the test contract is the boolean outcome, not a truthy/falsy coercion.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When adding or modifying assertions for built-in Jinja test functions in tests/test_tests.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc3c688347b207ea43f50056.md)

## Rule 105 — `src/jinja2/utils.py`

- **Rule:** LRUCache.setdefault must return the existing value if the key is present and only insert the default on KeyError, never overwriting existing entries.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying LRUCache.setdefault or cache insertion semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc87b09b832b7a15ef8dab32.md)

## Rule 106 — `src/jinja2/__init__.py`

- **Rule:**
  ```text
  flake8 ignores F401 in src/jinja2/__init__.py.
  ```
- **Applies to:**
  - `src/jinja2/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cfb11db6d85e63b22c4484ab.md)

## Rule 107 — `setup.cfg`

- **Rule:** The package requires Python 3.7 or newer.
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cfb2320f33b9543c7036ec09.md)

## Rule 108 — `tests/test_nativetypes.py`

- **Rule:** Adding an undefined value in a native template must raise UndefinedError during rendering rather than producing a native result.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying the native-template undefined-value test in the native types test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cfed0d66c03b2c7f5936117c.md)

## Rule 109 — `src/jinja2/nodes.py`

- **Rule:** Sub must be a BinExpr subclass whose operator is '-', mapping the subtraction AST node to its operator string.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying Sub or the subtraction AST node operator mapping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d1b90e33cddcde9a3aee2863.md)

## Rule 110 — `tests/test_ext.py`

- **Rule:** Tests that exercise Jinja's extension rebinding must assert that after Environment.overlay(), each extension's .environment attribute points to its own environment, because this defines the extension-rebinding contract for environment overlays.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for extension rebinding after Environment.overlay()
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d38f042e220447627970a76f.md)

## Rule 111 — `src/jinja2/tests.py`

- **Rule:**
  ```text
  test_odd returns value % 2 == 1, so negative odd integers (e.g. -3) evaluate as not odd under this implementation.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_odd or odd-number test semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d39cff91ebdf5f01328c6971.md)

## Rule 112 — `.pre-commit-config.yaml`

- **Rule:** Pre-commit autoupdate targets branch 3.0.x.
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d3c1020e21b46065c0024bbd.md)

## Rule 113 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  LoggingUndefined.__str__ must call _log_message(self) before delegating to super().__str__(), so stringifying an undefined value emits a log message as a side effect.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying LoggingUndefined.__str__ or the undefined logging side effect.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d6534d2b08a6e6820770a613.md)

## Rule 114 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  ChoiceLoader.get_source must try each loader in order and return the first successful source, swallowing TemplateNotFound from earlier loaders and raising TemplateNotFound(template) only if all loaders fail.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ChoiceLoader.get_source or the loader-fallback ordering and error-swallowing behavior it implements.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d713f1b441ea0b559ad4643a.md)
