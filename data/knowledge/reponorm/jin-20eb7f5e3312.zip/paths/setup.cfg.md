# Rules for `setup.cfg`

## Rule 023 — `setup.cfg`

- **Rule:**
  ```text
  The babel.extractors entry point registers the jinja2 extractor as jinja2.ext:babel_extract[i18n].
  ```
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3ae26fb27bd68b5bccf37a1b.md)

## Rule 060 — `setup.cfg`

- **Rule:** Package discovery uses setuptools' find: directive, so packages are auto-discovered rather than listed explicitly.
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7bddd06a33b53897bff24f1a.md)

## Rule 107 — `setup.cfg`

- **Rule:** The package requires Python 3.7 or newer.
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cfb2320f33b9543c7036ec09.md)
