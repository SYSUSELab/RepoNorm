# Rules for `tests/test_ext.py`

## Rule 007 — `tests/test_ext.py`

- **Rule:** Tests that exercise Jinja's autoescape scoping must assert that variables set inside an {% autoescape %} block are scoped to that block and that the outer value is restored after {% endautoescape %}, because this defines the scoping contract for the autoescape extension.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for the autoescape extension's variable scoping behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-09715e7aec02f52d27c1cfb1.md)

## Rule 054 — `tests/test_ext.py`

- **Rule:**
  ```text
  A macro defined in a non-autoescape environment must not be escaped when called inside an autoescape block; the rendered output remains raw '<html>'.
  ```
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:**
  ```text
  When modifying autoescape macro behavior tests in tests/test_ext.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6d3e742109008e86966b4f10.md)

## Rule 110 — `tests/test_ext.py`

- **Rule:** Tests that exercise Jinja's extension rebinding must assert that after Environment.overlay(), each extension's .environment attribute points to its own environment, because this defines the extension-rebinding contract for environment overlays.
- **Applies to:**
  - `tests/test_ext.py`
- **Condition:** When adding or modifying tests for extension rebinding after Environment.overlay()
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d38f042e220447627970a76f.md)
