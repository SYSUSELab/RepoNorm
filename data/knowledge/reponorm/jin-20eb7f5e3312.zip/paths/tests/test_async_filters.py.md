# Rules for `tests/test_async_filters.py`

## Rule 026 — `tests/test_async_filters.py`

- **Rule:** Async filter tests must exercise filters through the async environment's awaitable pipeline, so map/selectattr/join chains over async iterables render the same results as their sync counterparts.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When adding or modifying async filter tests that chain map, selectattr, sum, or join over async iterables.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-42b87cd35aaaba1227cf4d86.md)

## Rule 132 — `tests/test_async_filters.py`

- **Rule:** Tests that exercise Jinja's select filter must assert that falsy values (None, False, 0) are dropped, because this defines the select filter's truthiness contract.
- **Applies to:**
  - `tests/test_async_filters.py`
- **Condition:** When adding or modifying tests for the select filter's handling of falsy values
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fd0fef2001e75111631cfe6e.md)
