# Rules for `tests/conftest.py`

## Rule 033 — `tests/conftest.py`

- **Rule:**
  ```text
  The package_loader fixture in tests/conftest.py must return a PackageLoader initialized with package 'res' and templates directory 'templates', because this defines the shared fixture contract for tests that load templates from a package.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  When adding or modifying the package_loader fixture in tests/conftest.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-55c05eea01f6baa9c9c53187.md)
