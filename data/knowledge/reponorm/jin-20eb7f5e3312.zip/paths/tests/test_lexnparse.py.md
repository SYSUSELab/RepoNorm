# Rules for `tests/test_lexnparse.py`

## Rule 010 — `tests/test_lexnparse.py`

- **Rule:**
  ```text
  A parenthesized comparison inside arithmetic must render as a boolean coerced to int, e.g. {{ i * (j < 5) }} with i=2, j=3 yields '2'.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying parenthesized-comparison-in-arithmetic tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1560d56c280434ea7c86f4b5.md)

## Rule 078 — `tests/test_lexnparse.py`

- **Rule:**
  ```text
  With trim_blocks=True and lstrip_blocks=True, nested if blocks must render to 'a b c ' with the trailing space preserved, demonstrating combined whitespace-trimming behavior for nested block tags.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:**
  ```text
  When modifying nested-block whitespace-trimming tests in tests/test_lexnparse.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a2eb4fe206a13bbb8cba4997.md)

## Rule 095 — `tests/test_lexnparse.py`

- **Rule:**
  ```text
  With custom angle-bracket delimiters plus lstrip_blocks and trim_blocks, leading whitespace before a block tag must be stripped while trailing spaces after the block are preserved.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying the lstrip-blocks angle-bracket test in the lexer/parser test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c54702705ebb9a8a22d86043.md)

## Rule 129 — `tests/test_lexnparse.py`

- **Rule:**
  ```text
  Tests that exercise Jinja's identifier validity rules must assert that unicode letters are valid identifier starts, digits and hyphens are invalid, and certain unicode characters (\u1885, \u1886, \u2118, \u212e) are valid starts though not matched by \w, while \xb7 is only valid as a continue character, because this defines the lexer's identifier contract.
  ```
- **Applies to:**
  - `tests/test_lexnparse.py`
- **Condition:** When adding or modifying tests for Jinja identifier validity rules in the lexer
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f7887bbb5be2ee2318d52cd5.md)
