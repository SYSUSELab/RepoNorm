# Rules for `tests/test_idtracking.py`

## Rule 014 — `tests/test_idtracking.py`

- **Rule:**
  ```text
  Tests for idtracking must exercise symbol tracking over node trees by importing nodes and symbols_for_node.
  ```
- **Applies to:**
  - `tests/test_idtracking.py`
- **Condition:** When modifying or adding idtracking tests that exercise symbol tracking over node trees.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-210c4092fd0ddeb8d5b56ba2.md)
