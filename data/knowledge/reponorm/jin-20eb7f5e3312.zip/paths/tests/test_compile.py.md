# Rules for `tests/test_compile.py`

## Rule 071 — `tests/test_compile.py`

- **Rule:** Compiled template output for multiple 'import ... with context' statements must be deterministic: the first ten 'barN': entries appear in ascending N order.
- **Applies to:**
  - `tests/test_compile.py`
- **Condition:**
  ```text
  When modifying the deterministic import-with-context compilation test in tests/test_compile.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8e5984a1d301f5c75cc60638.md)

## Rule 130 — `tests/test_compile.py`

- **Rule:** Tests for compiled template filter ordering must assert that compiled output references filters in a deterministic order matching the template's filter usage order.
- **Applies to:**
  - `tests/test_compile.py`
- **Condition:**
  ```text
  When modifying or adding compiled template filter-ordering tests in tests/test_compile.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f945ed86fa64421730dc4e1e.md)
