# Rules for `tests/test_filters.py`

## Rule 029 — `tests/test_filters.py`

- **Rule:** The first filter must return the first element of an iterable, asserted as '0' for range(10).
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:** When adding or modifying the first-filter test in the filter test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-51cc44d408ebbdeff8a6dcc1.md)

## Rule 030 — `tests/test_filters.py`

- **Rule:**
  ```text
  The `reverse` filter must reverse strings ('foobar'|reverse|join -> 'raboof') and lists ([1,2,3]|reverse|list -> [3, 2, 1]).
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the `reverse` filter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-52c99d4919bafde5c84b299c.md)

## Rule 049 — `tests/test_filters.py`

- **Rule:** The urlize filter's target parameter must be rendered as an anchor target attribute while rel="noopener" is always added, so callers cannot opt out of rel=noopener via target.
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the urlize target-parameter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-68b94bf7efcfd5d7b3c1a9aa.md)

## Rule 055 — `tests/test_filters.py`

- **Rule:**
  ```text
  The `last` filter must return the final element of a list (e.g. rendering '9' for range(10)).
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the `last` filter test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6eb0eede84bb992ad51911c4.md)

## Rule 065 — `tests/test_filters.py`

- **Rule:**
  ```text
  The `sort` filter must support comma-separated dotted/indexed attribute paths for multi-key sorting, e.g. sort(attribute='value1.0,value2.0').
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying the multi-key sort attribute test in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-86972dee0d60688d0d0b6f00.md)

## Rule 096 — `tests/test_filters.py`

- **Rule:**
  ```text
  Filter chaining first|upper|escape must escape the uppercased first element, rendering '&lt;FOO&gt;'.
  ```
- **Applies to:**
  - `tests/test_filters.py`
- **Condition:**
  ```text
  When modifying filter-chaining tests in tests/test_filters.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c73955b6676f7b065c84e5c1.md)
