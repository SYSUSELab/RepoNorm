# Rules for `tests/test_async.py`

## Rule 066 — `tests/test_async.py`

- **Rule:** Async loop scope tests must assert that a loop variable (item) is not visible after the for loop ends, rendering empty output when referenced outside the loop.
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying the async loop scope test in the async test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-886ee0da092e4985298348aa.md)

## Rule 085 — `tests/test_async.py`

- **Rule:**
  ```text
  Async loop filter tests must assert that 'for item in range(10) if item is even' yields [0][2][4][6][8] and that loop.index inside the filtered loop is 1-based over the filtered sequence, producing [1:0][2:2][3:4][4:6][5:8].
  ```
- **Applies to:**
  - `tests/test_async.py`
- **Condition:** When adding or modifying the async loop filter test in the async test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a94293f6919a09b16b9f017e.md)
