# Rules for `tests/test_debug.py`

## Rule 072 — `tests/test_debug.py`

- **Rule:** The debug test helper must assert that a formatted traceback matches an expected regex pattern, failing with the full traceback and expected pattern when no match is found.
- **Applies to:**
  - `tests/test_debug.py`
- **Condition:**
  ```text
  When modifying the traceback-matching debug test helper in tests/test_debug.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-95c7d698a8dc476dd80495ef.md)
