# Rules for `tests/test_inheritance.py`

## Rule 053 — `tests/test_inheritance.py`

- **Rule:** Tests that exercise Jinja's macro scoping across template inheritance must assert that a macro defined in a child template is callable inside an overridden block, because this defines the macro-scoping contract for inheritance.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:** When adding or modifying tests for macro scoping across template inheritance
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6cf9c63c855c7cde7c3515c2.md)

## Rule 076 — `tests/test_inheritance.py`

- **Rule:** Required blocks may only contain comments or whitespace; templates where a required block contains data, nested blocks, or if-statements must raise TemplateSyntaxError with message 'Required blocks can only contain comments or whitespace'.
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:** When adding or modifying the invalid-required-block test in the inheritance test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9fec71725d868ea43c7656a4.md)

## Rule 128 — `tests/test_inheritance.py`

- **Rule:**
  ```text
  Multi-level template inheritance with super() must resolve across nested blocks, rendering '--INTRO--|BEFORE|[(INNER)]|AFTER' for a three-level chain.
  ```
- **Applies to:**
  - `tests/test_inheritance.py`
- **Condition:**
  ```text
  When modifying multi-level inheritance super() tests in tests/test_inheritance.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f245833d5eeba6feca0099ac.md)
