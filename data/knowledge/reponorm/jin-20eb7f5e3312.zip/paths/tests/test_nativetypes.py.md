# Rules for `tests/test_nativetypes.py`

## Rule 067 — `tests/test_nativetypes.py`

- **Rule:**
  ```text
  Tests that exercise Jinja's nativetypes rendering must assert that rendering a dunder attribute like __class__ yields a native Python type instance, because this defines the nativetypes contract for attribute access.
  ```
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying tests for nativetypes rendering of dunder attributes
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8a89bf9cfa7112f8e8911f34.md)

## Rule 108 — `tests/test_nativetypes.py`

- **Rule:** Adding an undefined value in a native template must raise UndefinedError during rendering rather than producing a native result.
- **Applies to:**
  - `tests/test_nativetypes.py`
- **Condition:** When adding or modifying the native-template undefined-value test in the native types test module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cfed0d66c03b2c7f5936117c.md)
