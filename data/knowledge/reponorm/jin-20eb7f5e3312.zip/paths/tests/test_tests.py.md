# Rules for `tests/test_tests.py`

## Rule 104 — `tests/test_tests.py`

- **Rule:** Tests that exercise Jinja's built-in test functions (defined, even, greaterthan) must assert the exact boolean result of the test, because these tests render Python booleans as the strings 'True'/'False' and the test contract is the boolean outcome, not a truthy/falsy coercion.
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When adding or modifying assertions for built-in Jinja test functions in tests/test_tests.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cc3c688347b207ea43f50056.md)

## Rule 125 — `tests/test_tests.py`

- **Rule:**
  ```text
  Comparison test aliases must be asserted through the `is` test operator with parametrized op strings (e.g. 'eq 2') and expected booleans, covering eq/ne/lt/le/gt/ge aliases.
  ```
- **Applies to:**
  - `tests/test_tests.py`
- **Condition:**
  ```text
  When adding or modifying comparison-alias tests in tests/test_tests.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ed47478d587ba0aabf60aec5.md)
