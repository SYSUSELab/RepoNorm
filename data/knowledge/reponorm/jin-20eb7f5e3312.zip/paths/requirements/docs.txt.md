# Rules for `requirements/docs.txt`

## Rule 032 — `requirements/docs.txt`

- **Rule:** Read the Docs installs documentation dependencies from requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-552ed8fc603a8a3458f62547.md)

## Rule 100 — `requirements/docs.txt`

- **Rule:** The docs tox environment installs its dependencies from requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c8e8d2d317e94f529981b3ce.md)
