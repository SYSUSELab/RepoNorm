# Rules for `requirements/typing.txt`

## Rule 134 — `requirements/typing.txt`

- **Rule:** The tox testenv:typing environment installs its dependencies from requirements/typing.txt.
- **Applies to:**
  - `requirements/typing.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fff74fae962728f25501edd6.md)
