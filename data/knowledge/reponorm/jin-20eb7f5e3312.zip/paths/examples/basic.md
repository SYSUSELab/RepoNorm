# Rules for `examples/basic`

## Rule 016 — `examples/basic/**/*.py`

- **Rule:**
  ```text
  Example scripts under examples/basic/ that demonstrate a Jinja feature must configure the Environment with the exact option combination the feature requires (e.g. line_statement_prefix plus custom variable delimiters, or jinja2.ext.i18n with gettext/ngettext globals) rather than relying on defaults.
  ```
- **Applies to:**
  - `examples/basic/**/*.py`
- **Condition:** When adding or modifying an example script that demonstrates a Jinja feature requiring non-default Environment options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-250736a427bc04a6ed5a7ed9.md)

## Rule 089 — `examples/basic/**/*.py`

- **Rule:** Example scripts under examples/basic/ that demonstrate error debugging must construct an Environment with FileSystemLoader and render a deliberately broken template to serve as a runnable debugging demonstration rather than a library invariant.
- **Applies to:**
  - `examples/basic/**/*.py`
- **Condition:** When adding or modifying an example script that demonstrates template error debugging.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b9540ff75056b94a07f3da20.md)
