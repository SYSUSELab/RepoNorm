# Rules for `tests`

## Rule 039 — `jinja2/**`

- **Rule:** Coverage source measurement is limited to the jinja2 and tests directories.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-578f759c4dddf5c253fcb3a5.md)

## Rule 090 — `tests/**`

- **Rule:** Pytest test discovery is restricted to the tests directory via testpaths = tests.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ba02e408344a7c0f86a6b30f.md)
