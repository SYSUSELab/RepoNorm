# Rules for `scripts/generate_identifier_pattern.py`

## Rule 082 — `scripts/generate_identifier_pattern.py`

- **Rule:**
  ```text
  Character-set generation for the identifier pattern must derive valid identifier characters by testing ('a'+s).isidentifier() rather than relying on regex \w, because \w matches some non-identifier characters that str.isidentifier rejects during lexing.
  ```
- **Applies to:**
  - `scripts/generate_identifier_pattern.py`
- **Condition:** When changing how the generator enumerates or filters candidate identifier characters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a7571cbf1e74f09db3a8be38.md)

## Rule 121 — `scripts/generate_identifier_pattern.py`

- **Rule:** Range collapsing for the identifier pattern must group sorted unique characters into sequential code-point ranges using itertools.groupby on ord(char) - index, yielding (start, end) pairs.
- **Applies to:**
  - `scripts/generate_identifier_pattern.py`
- **Condition:** When changing how the generator collapses character sets into ranges.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e31ffdbf81ee0b9f8b3f871e.md)
