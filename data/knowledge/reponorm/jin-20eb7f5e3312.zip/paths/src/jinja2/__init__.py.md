# Rules for `src/jinja2/__init__.py`

## Rule 106 — `src/jinja2/__init__.py`

- **Rule:**
  ```text
  flake8 ignores F401 in src/jinja2/__init__.py.
  ```
- **Applies to:**
  - `src/jinja2/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cfb11db6d85e63b22c4484ab.md)
