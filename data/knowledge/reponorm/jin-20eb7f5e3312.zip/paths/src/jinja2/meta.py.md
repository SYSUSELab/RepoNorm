# Rules for `src/jinja2/meta.py`

## Rule 018 — `src/jinja2/meta.py`

- **Rule:**
  ```text
  find_referenced_templates must yield None for any dynamic (non-constant) template reference, including dynamic entries inside tuple/list literals, so dependency tracking treats None as an unresolvable dependency.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:**
  ```text
  When modifying find_referenced_templates or the dependency-tracking logic that consumes its output for dynamic template references.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2b15304441769d2dc032012c.md)

## Rule 073 — `src/jinja2/meta.py`

- **Rule:**
  ```text
  The introspection environment must initialize an undeclared_identifiers set on the instance as the accumulator used to report undeclared names during meta analysis.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:** When modifying the introspection environment initialization or the undeclared-name accumulator used during meta analysis.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-961e1094f45e92b406b9a17b.md)
