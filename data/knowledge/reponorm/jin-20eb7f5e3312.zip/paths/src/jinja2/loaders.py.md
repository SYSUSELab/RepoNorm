# Rules for `src/jinja2/loaders.py`

## Rule 044 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  FileSystemLoader.list_templates must walk every configured searchpath with os.walk(followlinks=self.followlinks), normalize each discovered path to a forward-slash path relative to its searchpath, strip a leading './', deduplicate across searchpaths, and return the sorted result.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying FileSystemLoader.list_templates or the path-normalization/deduplication logic it uses to enumerate templates across searchpaths.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6015408ff6fe2a3bca7a1ed0.md)

## Rule 050 — `src/jinja2/loaders.py`

- **Rule:** PackageLoader supports only packages installed as directories or zip/egg files; PEP 420 namespace packages have limited support with the template directory assumed in one contributor, and zip files contributing to a namespace are unsupported. Since 3.0 it no longer depends on setuptools.
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:** when modifying PackageLoader package discovery or template directory resolution
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-69e687bed39720b832a1207a.md)

## Rule 093 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  DictLoader.get_source must return (source, None, uptodate) where uptodate is a closure comparing the current mapping value to the captured source, and must raise TemplateNotFound when the template name is absent.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying DictLoader.get_source or its uptodate/TemplateNotFound behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c2dd799779805a501a9073b4.md)

## Rule 102 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  ModuleLoader.get_module_filename must derive the module file name from get_template_key(name) plus '.py', coupling module template keys to their generated Python filenames.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ModuleLoader.get_module_filename or module template key/filename generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c9e43765fa6cb46fec2cfe96.md)

## Rule 114 — `src/jinja2/loaders.py`

- **Rule:**
  ```text
  ChoiceLoader.get_source must try each loader in order and return the first successful source, swallowing TemplateNotFound from earlier loaders and raising TemplateNotFound(template) only if all loaders fail.
  ```
- **Applies to:**
  - `src/jinja2/loaders.py`
- **Condition:**
  ```text
  When modifying ChoiceLoader.get_source or the loader-fallback ordering and error-swallowing behavior it implements.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d713f1b441ea0b559ad4643a.md)
