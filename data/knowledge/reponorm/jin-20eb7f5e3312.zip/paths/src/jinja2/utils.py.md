# Rules for `src/jinja2/utils.py`

## Rule 011 — `src/jinja2/utils.py`

- **Rule:** The cycle helper must raise RuntimeError when constructed with no items, enforcing that at least one item is provided.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when modifying the Cycler constructor or cycle helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1b552c6f0d6ec1267bfb6238.md)

## Rule 024 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  is_undefined must remain an instance check against Undefined so custom filters and tests (e.g. a custom default filter) can detect undefined variables.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying is_undefined or adding custom filters/tests that must react to undefined variables.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3c2f1b78967395e1553bb16f.md)

## Rule 036 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  select_autoescape must normalize enabled and disabled extensions by stripping leading dots and lowercasing them, operating case-insensitively for security reasons, with default_for_string controlling string templates and default controlling unmatched filenames.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying select_autoescape or autoescape extension matching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-567f7565c4de649da6fdef9f.md)

## Rule 074 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  LRUCache.__setstate__ must update the instance dict and then call _postinit, so unpickling re-runs post-initialization logic.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying LRUCache.__setstate__ or unpickling/post-initialization behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9d38ea4b0312adbc0a300236.md)

## Rule 086 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  LRUCache.__contains__ must check key membership in the underlying _mapping, defining containment semantics for the cache wrapper.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  when modifying LRUCache.__contains__ or the cache wrapper containment semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aec18691e40c16951b05f94f.md)

## Rule 088 — `src/jinja2/utils.py`

- **Rule:** Namespace is a container holding arbitrary attributes, initializable from a dictionary or keyword arguments.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** when modifying Namespace initialization or attribute storage
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b056a06fbb9ee058a9e5e9ae.md)

## Rule 097 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  open_if_exists must return None when the path is not a regular file and otherwise open it with the given mode (default 'rb'), defining the safe-open helper contract used by loaders.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  when modifying open_if_exists or loader code that relies on its safe-open contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c7bc9ab6cc400b5af0ea32dc.md)

## Rule 105 — `src/jinja2/utils.py`

- **Rule:** LRUCache.setdefault must return the existing value if the key is present and only insert the default on KeyError, never overwriting existing entries.
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying LRUCache.setdefault or cache insertion semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc87b09b832b7a15ef8dab32.md)

## Rule 122 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  Cycler.current must return self.items[self.pos], i.e. the item that will be returned by the next call to next.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** When modifying Cycler.current or adding a new iterator property that must match the next-item semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e44ea74cacdd84a1ebe13ca5.md)
