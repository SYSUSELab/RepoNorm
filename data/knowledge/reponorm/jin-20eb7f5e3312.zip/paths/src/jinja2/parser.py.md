# Rules for `src/jinja2/parser.py`

## Rule 003 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.parse_expression must dispatch to parse_condexpr when with_condexpr is true and to parse_or otherwise, so callers can suppress conditional-expression parsing.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.parse_expression or adding a caller that relies on suppressing conditional-expression parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-03ba7d8d20620385e960b8b4.md)

## Rule 021 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.parse_math1 must handle additive operators (add/sub) at a precedence level below parse_concat, using _math_nodes to map token types to AST node classes and constructing each binary node with the left operand's starting lineno.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.parse_math1 or adding a new additive operator that must respect the existing precedence level.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3371939e8969d1471e27d476.md)

## Rule 037 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  fail_eof builds an end-token stack from the current parser state and optional end_tokens before delegating to _fail_ut_eof for end-of-template error reporting.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.fail_eof or end-of-template error reporting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-56eebd8868b6919dae8ff8c9.md)

## Rule 041 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  When modifying the parser's not handling, preserve that parse_not recursively consumes 'not' tokens so repeated 'not not x' nests Not nodes.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  Changing parse_not's recursion or Not node construction for chained negation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5e24663f3c69ef95547465e7.md)

## Rule 058 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.parse_postfix must loop over dot/lbracket/lparen tokens so calls are accepted after both postfix expressions and filters/tests, serving as the shared extension point for chained attribute, subscript, and call syntax.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.parse_postfix or adding chained attribute, subscript, or call syntax
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-749f22dc0c34d18e1b48fd82.md)

## Rule 059 — `src/jinja2/parser.py`

- **Rule:** Parser is the central parsing class passed to extensions, usable to parse expressions or statements.
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:** when modifying Parser or the extension-facing parsing API
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-75af7e9246283b4f6db262d5.md)

## Rule 075 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Template test parsing in Parser.parse_test must accept a leading `not` negation, dotted test names, optional call arguments, and a bare-argument form, while explicitly rejecting chained `is` tests with a failure.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  when modifying Parser.parse_test or the grammar for `is` test expressions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9e4d48137094e2998724698f.md)

## Rule 077 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.is_tuple_end must treat variable_end, block_end, and rparen as tuple terminators and additionally accept caller-supplied extra_end_rules via test_any, defining tuple-end detection boundaries.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.is_tuple_end or adding a caller that supplies extra_end_rules.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a14b646275f6437555daa3bf.md)

## Rule 120 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.parse_primary must treat both lowercase and capitalized spellings as literals: true/True and false/False become Const booleans, none/None become Const None, and adjacent string tokens are concatenated into a single Const with the first token's lineno.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.parse_primary or template literal parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e2e2ed0312392bbf04450ecc.md)
