# Rules for `src/jinja2/tests.py`

## Rule 043 — `src/jinja2/tests.py`

- **Rule:**
  ```text
  tests.test_divisibleby returns value % num == 0, defining the divisibleby test semantics.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_divisibleby or divisibleby test semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5e64b987cda0db2877a55c32.md)

## Rule 045 — `src/jinja2/tests.py`

- **Rule:**
  ```text
  The `number` test must be defined as isinstance(value, Number), so it accepts any registered numbers.Number (including complex and Decimal), not just int/float.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  When modifying the `number` test or adding a new numeric test that must match the existing acceptance criteria.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-603a55430c63ec95b8a59464.md)

## Rule 084 — `src/jinja2/tests.py`

- **Rule:**
  ```text
  test_lower must coerce the value with str before calling islower(), so non-string values are stringified before the lowercase check.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_lower or the stringification behavior of the lowercase test
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a7ced2b43912a1785d553c34.md)

## Rule 111 — `src/jinja2/tests.py`

- **Rule:**
  ```text
  test_odd returns value % 2 == 1, so negative odd integers (e.g. -3) evaluate as not odd under this implementation.
  ```
- **Applies to:**
  - `src/jinja2/tests.py`
- **Condition:**
  ```text
  when modifying test_odd or odd-number test semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d39cff91ebdf5f01328c6971.md)
