# Rules for `src/jinja2/runtime.py`

## Rule 091 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  str_join must define the runtime's canonical string-join semantics: it converts each item to str and concatenates via concat, so iterable joining in templates follows this conversion-and-concatenation behavior.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying str_join or template string-joining behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bd9e8edf73e846e18124865f.md)

## Rule 094 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  Undefined._undefined_message must prioritize an explicit hint, then distinguish missing-object, non-string-name, and attribute cases to build the error message; custom undefined subclasses must preserve this precedence to keep messages consistent.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** When modifying or subclassing undefined error-message construction in the runtime module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c2e5ec31a5bc4d03434131d1.md)

## Rule 113 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  LoggingUndefined.__str__ must call _log_message(self) before delegating to super().__str__(), so stringifying an undefined value emits a log message as a side effect.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:**
  ```text
  When modifying LoggingUndefined.__str__ or the undefined logging side effect.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d6534d2b08a6e6820770a613.md)
