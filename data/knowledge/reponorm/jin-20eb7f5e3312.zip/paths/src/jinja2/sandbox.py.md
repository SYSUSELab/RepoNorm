# Rules for `src/jinja2/sandbox.py`

## Rule 013 — `src/jinja2/sandbox.py`

- **Rule:**
  ```text
  The @unsafe decorator must set the unsafe_callable attribute to True on the decorated function or method, which the sandbox inspects to deny calls.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying the @unsafe decorator or adding sandbox checks that rely on the unsafe_callable marker.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1fcfeee568d43ed76c464a7c.md)

## Rule 124 — `src/jinja2/sandbox.py`

- **Rule:**
  ```text
  When modifying sandboxed call handling, preserve that SandboxedEnvironment.call first checks for a format method and routes to format_string, otherwise verifies is_safe_callable and raises SecurityError.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:** Changing sandboxed call dispatch, format-method routing, or safety verification.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ebc4dbe2548c9431530a4b9e.md)
