# Rules for `src/jinja2/bccache.py`

## Rule 001 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  When modifying BytecodeCache.get_source_checksum, preserve the computation of sha1 of the UTF-8 encoded source as a hex digest, which defines the cache key basis for bytecode caching.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying the source checksum computation for bytecode caching
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0183bf07703eff95178aea00.md)

## Rule 005 — `src/jinja2/bccache.py`

- **Rule:** BytecodeCache.clear is not used by Jinja itself but is expected to be implemented so applications can clear a particular environment's bytecode cache, defining an optional-but-expected extension method.
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying BytecodeCache.clear or the bytecode-cache clearing contract it defines.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-069ed89fa24880a36f4a75f7.md)

## Rule 017 — `src/jinja2/bccache.py`

- **Rule:** When modifying FileSystemBytecodeCache, preserve the platform-specific default cache directory selection: the user's temp directory on Windows and a per-user directory under the system temp directory on UNIX.
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying the default cache directory selection for FileSystemBytecodeCache
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2960ea8fd45ac298535cd4aa.md)

## Rule 027 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  bccache must define bc_version = 5 and bc_magic combining 'j2' with the pickled version and Python major/minor version, so cached bytecode is invalidated across Python version upgrades.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying bccache version constants or bytecode cache invalidation logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4c56088b57e660c0129f11f8.md)

## Rule 028 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  FileSystemBytecodeCache must keep the default filename pattern '__jinja2_%s.cache' with %s substituted by the cache key, so multiple caches can safely share one directory.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** When modifying FileSystemBytecodeCache filename construction or its default pattern.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4d1508f23330d99aef703ad2.md)

## Rule 031 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  When modifying the bytecode cache extension point, preserve that BytecodeCache subclasses must override load_bytecode and dump_bytecode, both receiving a Bucket.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  Changing BytecodeCache's documented extension contract or the Bucket interface passed to load_bytecode/dump_bytecode.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-53ac5ccca230a0a19c23d097.md)

## Rule 070 — `src/jinja2/bccache.py`

- **Rule:** When modifying Bucket or bytecode cache subclasses, preserve the internal checksum assigned by the bytecode cache that automatically rejects outdated cache material, so subclasses do not need to implement cache invalidation themselves.
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:** when modifying Bucket or bytecode cache subclass invalidation behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8c01508edc7092b580d28227.md)
