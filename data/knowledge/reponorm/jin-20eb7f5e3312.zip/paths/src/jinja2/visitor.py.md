# Rules for `src/jinja2/visitor.py`

## Rule 038 — `src/jinja2/visitor.py`

- **Rule:**
  ```text
  NodeVisitor.__call__ must remain an abstract/overridable dispatch entry point in the visitor protocol.
  ```
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:** When modifying NodeVisitor or adding visitor subclasses that rely on the dispatch entry point.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-577ba1cfe59a56403343d90c.md)
