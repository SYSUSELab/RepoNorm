# Rules for `src/jinja2/environment.py`

## Rule 002 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Template._get_default_module_async must return a fresh module built from ctx.parent values when ctx has globals not present in self.globals, otherwise lazily create and cache self._module via make_module_async.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Template._get_default_module_async or async module caching behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0197c2838251d742ed5c79d6.md)

## Rule 008 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Environment.make_globals must return a ChainMap of template-specific globals over environment globals so template-level global changes do not mutate environment globals; callers must not modify globals after a template is loaded.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Environment.make_globals or template global handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-09fe9ed5ec74ac247b60dae4.md)

## Rule 019 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Extension stream-filtering must preserve the protocol that Environment._tokenize applies each extension's filter_stream to the token stream and wraps any non-TokenStream return value in a TokenStream before continuing.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment._tokenize or adding an extension that overrides filter_stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2c65a7c0e006aea8b15f026d.md)

## Rule 034 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Template.render must detect an async environment and run render_async on an event loop, creating and closing a new loop only when no running loop exists.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when modifying Template.render or the async rendering bridge
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-55fafae20900edc8438c8509.md)

## Rule 064 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Template.is_up_to_date must return True when the internal _uptodate callback is None, otherwise delegate to calling _uptodate(), so absence of a callback means the template is considered current.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Template.is_up_to_date or the _uptodate callback handling it implements.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-85e7860dc5ca5e148c8f0086.md)

## Rule 092 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Template.from_module_dict must be a classmethod that constructs a Template from a module dict and globals by delegating to _from_namespace, serving as the module loader's template-construction entry point.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Template.from_module_dict or the module loader's template construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bf5034bc393950c65e403cd7.md)

## Rule 103 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Environment.select_template must preserve its documented compatibility boundaries: raise TemplatesNotFound for an empty names list, raise UndefinedError when names is Undefined, return Template objects unchanged, and since 3.0 update cached template globals rather than ignoring new values.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying select_template or its error handling and cached-globals update behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ca53048d413bbd3ab1fe97de.md)

## Rule 116 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  The async to_list helper collects generate_async output into a list, providing the async counterpart to synchronous template rendering.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Template.generate.to_list or async template rendering helpers
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d7b4df4d209b35065d1e9006.md)

## Rule 126 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Environment._load_template must key the cache by (weakref.ref(self.loader), name); on a cache hit with auto_reload disabled or an up-to-date template it must update template.globals with the passed globals and return the cached template, otherwise load and store the template.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  when modifying Environment._load_template or the template cache
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f1260d1652b98e6ee19a5fdc.md)

## Rule 127 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Environment.add_extension must update the environment's extensions mapping via load_extensions so extensions can be registered after environment creation.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying Environment.add_extension or the post-creation extension registration path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f1be17523229e5c3c58197b5.md)
