# Rules for `src/jinja2/filters.py`

## Rule 009 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  do_float must return the configured default (0.0 by default) when float() raises TypeError or ValueError, so conversion failures are silent rather than propagated.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_float or its default handling for failed numeric conversions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c8285f775995cc2da8851cf.md)

## Rule 042 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  do_random catches IndexError from random.choice and returns context.environment.undefined with the message 'No random item, sequence was empty.', so empty sequences yield Undefined rather than raising.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_random or random filter empty-sequence handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5e46141b402802a84246ae1f.md)

## Rule 051 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  HasHTML is declared as a te.Protocol used to detect objects with an __html__ method for HTML-safe filter output.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when modifying HasHTML or HTML-safe filter output detection
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6b96dac7f0b2131a55a178a5.md)

## Rule 069 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  sync_do_sum must support an attribute parameter that maps make_attrgetter over the iterable before summing, and a start parameter (default 0) passed as the initial value to sum.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying sync_do_sum or the sum filter's attribute/start parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b7768df62a305c4086ce2df.md)

## Rule 079 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying filter argument validation, preserve that do_dictsort accepts only by='key' or by='value' and raises FilterArgumentError for any other value before sorting.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  Changing do_dictsort's accepted by values or its error handling for invalid arguments.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a36046adf954e805a764dcfa.md)

## Rule 098 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  filters.do_pprint returns pformat(value), pretty-printing a variable for debugging.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when modifying do_pprint or pretty-printing behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c8198959a8789fff0e82834e.md)

## Rule 101 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  do_striptags must check for __html__ and call it to obtain the HTML string before stripping tags, so objects implementing the HTML protocol are stripped based on their HTML representation rather than str().
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying do_striptags or its handling of objects implementing __html__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c9d858ecd1182849dff2eae4.md)
