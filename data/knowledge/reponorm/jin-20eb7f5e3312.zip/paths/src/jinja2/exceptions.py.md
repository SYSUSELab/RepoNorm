# Rules for `src/jinja2/exceptions.py`

## Rule 020 — `src/jinja2/exceptions.py`

- **Rule:** When modifying the exception hierarchy, preserve that TemplateRuntimeError subclasses TemplateError and remains the generic runtime error Jinja may raise.
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** Changing TemplateRuntimeError's base class or its role as the generic runtime error.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2c7a1bfaac41e9dd375dc318.md)

## Rule 040 — `src/jinja2/exceptions.py`

- **Rule:**
  ```text
  TemplateError.__init__ must accept an optional message and forward it to super().__init__, so exceptions may be constructed without a message.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:**
  ```text
  when modifying TemplateError.__init__ or the optional-message exception construction contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-59705d77dcf3d574072ebc3d.md)

## Rule 123 — `src/jinja2/exceptions.py`

- **Rule:**
  ```text
  TemplatesNotFound builds its default message by joining the names, using each Undefined name's _undefined_message, and passes names[-1] (or None when empty) as the first argument to the parent exception while storing the full list in self.templates.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:**
  ```text
  when modifying TemplatesNotFound.__init__ message construction or argument passing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ea8b7726e9ca56324a1c6509.md)
