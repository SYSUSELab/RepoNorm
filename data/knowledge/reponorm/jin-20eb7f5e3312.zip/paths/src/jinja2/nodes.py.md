# Rules for `src/jinja2/nodes.py`

## Rule 083 — `src/jinja2/nodes.py`

- **Rule:** MarkSafeIfAutoescape must remain an Expr node with a single 'expr' field that marks the wrapped expression as safe (Markup) only when autoescaping is active.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When modifying MarkSafeIfAutoescape or the autoescape-conditional safety marking it implements.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a7a1ff1822e1edc8b0ad2e1c.md)

## Rule 099 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  get_eval_context requires that a node passed without an explicit EvalContext has an attached environment; otherwise it raises RuntimeError.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  when modifying get_eval_context or callers relying on implicit context from node.environment
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c8b9cdfd171c15597a2256c8.md)

## Rule 109 — `src/jinja2/nodes.py`

- **Rule:** Sub must be a BinExpr subclass whose operator is '-', mapping the subtraction AST node to its operator string.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** when modifying Sub or the subtraction AST node operator mapping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d1b90e33cddcde9a3aee2863.md)
