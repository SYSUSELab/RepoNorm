# Rules for `src/jinja2/lexer.py`

## Rule 004 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  When adding or modifying a lexer rule, represent it as a _Rule NamedTuple whose pattern, tokens (string, tuple of strings, or tuple of Failure), and optional command fields follow the existing rule protocol.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** when adding or modifying a lexer rule in the lexer module
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-05ac3c57d95b090598751fbd.md)

## Rule 048 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  The lexer module defines operators and reverse_operators with an assertion that len(operators) == len(reverse_operators) ('operators dropped'), and builds operator_re by sorting operator keys by descending length so multi-character operators match before single-character ones.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when modifying lexer operator tables or operator_re construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-687390320271df6c7bfc2619.md)

## Rule 063 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  _normalize_newlines replaces all newlines in strings and template data with the configured newline_sequence using newline_re, so lexer output depends on the environment's newline setting.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when modifying Lexer._normalize_newlines or newline handling in the lexer
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8563d948c05b4225f88f6b40.md)

## Rule 081 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  OptionalLStrip must remain a tuple subclass with __slots__ = () used to mark a lexer state point where lstrip may be applied; instances fail to create without the slots declaration.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:** When modifying OptionalLStrip or adding a new lexer state marker that must be instantiable.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a55a132d2f1201a90d8890c8.md)

## Rule 133 — `src/jinja2/lexer.py`

- **Rule:**
  ```text
  Lexer rule assembly must sort root tag rules by length so longer delimiters (e.g. `<%`) are matched before shorter ones, because `|` is ungreedy; and lstrip_blocks must be suppressed when non-whitespace precedes the newline via lstrip_unless_re.
  ```
- **Applies to:**
  - `src/jinja2/lexer.py`
- **Condition:**
  ```text
  when adding or reordering lexer tag rules or modifying lstrip_blocks handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fe4c813be55e160de16d986f.md)
