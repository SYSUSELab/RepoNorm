# Rules for `src/jinja2`

## Rule 117 — `src/jinja2/**`

- **Rule:** mypy is configured to check the files under src/jinja2.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d974357b7ecf799c8cee2a2c.md)
