# Rules for `docs/examples/cache_extension.py`

## Rule 068 — `docs/examples/cache_extension.py`

- **Rule:**
  ```text
  The documented cache extension must call `super().__init__(environment)` and register `fragment_cache_prefix` and `fragment_cache` defaults via `environment.extend`.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
- **Condition:** When modifying the cache extension's initialization or its environment defaults.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8afe274747ccacaae3c3a699.md)
