# Rules for `repository root`

## Rule 006 — `**/*.css`

- **Rule:** YAML, JSON, JavaScript, CSS, and HTML files use an indent size of 2.
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-06f3a771a8b8ffcfd8aadd95.md)

## Rule 012 — `**`

- **Rule:** Read the Docs builds use Ubuntu 20.04 as the build OS.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1ba3c9477127f0f840e7d62e.md)

## Rule 022 — `**`

- **Rule:** Read the Docs installs the repository itself via pip from the current directory.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3503130396900f69e66037a8.md)

## Rule 061 — `**`

- **Rule:** Files in the repository are configured to trim trailing whitespace.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-80dfb5def178e436e9bc8468.md)

## Rule 062 — `**`

- **Rule:** The pre-commit configuration enables the fix-byte-order-marker hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-84e36d72633e2268c49557e2.md)

## Rule 080 — `**/*.py`

- **Rule:** flake8 ignores E203, E501, E722, and W503.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a4cdf2dba99afcbd5315e4ab.md)

## Rule 087 — `**`

- **Rule:** The tests job installs tox and runs the tox environment selected by the matrix's tox value.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-af49c8f0ff0ce48b323f4b10.md)

## Rule 118 — `**`

- **Rule:**
  ```text
  The tox testenv:style environment sets skip_install to true.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-de7043724ca778c8b8a85953.md)

## Rule 119 — `**/*.py`

- **Rule:** flake8 enforces a maximum line length of 80.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e06ab2a82b69f8e8da990be4.md)
