# Full rule catalog

## Rule 001 — `tests/generate/test_integration_exllamav2.py`

- **Rule:** model.stream yields str tokens for both a single string prompt and a list-of-strings prompt, documenting the streaming output contract across prompt types.
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When modifying model.stream behavior or the streaming output contract exercised by test_model_stream_prompt_types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-01b69a8edbc446c398abe7e3.md)

## Rule 002 — `**/__init__.py`

- **Rule:**
  ```text
  Flake8 ignores F401 and F403 in __init__.py files at any depth.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0217c6b71ab78373db83bf76.md)

## Rule 003 — `**/*.py`

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.9 via requires-python = ">=3.9".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-039ea611fdaa8705400f7799.md)

## Rule 004 — `mkdocs.yml`

- **Rule:** The MkDocs theme is configured as material.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-03d99915e3a6423d4db3c90e.md)

## Rule 005 — `outlines/fsm/json_schema.py`

- **Rule:**
  ```text
  When modifying outlines/fsm/json_schema.py, preserve its role of building pydantic models dynamically from JSON schema and emitting warnings for unsupported constructs, as evidenced by its imports of inspect, json, warnings, Enum, typing Callable/Type/Union, and pydantic BaseModel/create_model.
  ```
- **Applies to:**
  - `outlines/fsm/json_schema.py`
- **Condition:**
  ```text
  Modifying outlines/fsm/json_schema.py or its schema-to-model conversion behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-046359c935de2335da0a9aff.md)

## Rule 006 — `outlines/models/mlxlm.py`

- **Rule:**
  ```text
  MLXLM must expose a _tokenizer attribute documented as an HF Tokenizer so MLX models reuse HuggingFace tokenizer semantics.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:** When modifying MLXLM or its tokenizer attribute.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-05de81971c38b8dc31fb7331.md)

## Rule 007 — `outlines/models/transformers_vision.py`

- **Rule:**
  ```text
  When modifying transformers_vision in outlines/models/transformers_vision.py, preserve the defaults: processor padding defaults to the left side, pad token defaults to [PAD], and when a device is provided it overrides the device_map entry in model_kwargs.
  ```
- **Applies to:**
  - `outlines/models/transformers_vision.py`
- **Condition:**
  ```text
  Modifying transformers_vision or its processor/model_kwargs defaults.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-06dd99e727f53e7eec176322.md)

## Rule 008 — `tests/generate/test_generator.py`

- **Rule:** Generator tests must use local test doubles (e.g. MockModel, MockFSM) for model and FSM dependencies rather than real providers, and must verify that SequenceGenerator.stream yields the generated sequence then raises StopIteration.
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:** when adding or modifying generator tests that exercise streaming or FSM behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-075cf22def3ff74b950256e7.md)

## Rule 009 — `.github/workflows/publish_documentation.yml`

- **Rule:**
  ```text
  The workflow caches the .cache path keyed by mkdocs-material-<cache_id> with restore key mkdocs-material-.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-090c11f09d1624b989c2d091.md)

## Rule 010 — `tests/models/test_transformers.py`

- **Rule:** Tests for TransformerTokenizer must assert that equality and hashing are based on the wrapped HF tokenizer state, so tokenizers wrapping the same HF tokenizer are equal and hash-equal, while one wrapping a modified HF tokenizer is unequal and hash-unequal.
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** When adding or modifying tests for TransformerTokenizer equality or hashing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-091271923c7cdcb24cbd71bb.md)

## Rule 011 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying the CFG parser construction in outlines/fsm/parsing.py, keep options['regex'] forced to True and the parser asserted as 'lalr'; do not allow callers to override these, and continue popping 'deterministic' and 'use_value_stack' as custom options rather than passing them to Lark.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  Modifying PartialLark.__init__ or the options handling for the CFG parser.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c6106bad8de15771a447907.md)

## Rule 012 — `tests/test_base.py`

- **Rule:**
  ```text
  The passthrough_args test helper must concatenate all positional string arguments and carry the docstring 'A passthrough function.', matching the docstring asserted by the vectorize tests.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  when adding or modifying the passthrough_args test helper used by vectorize tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0d6e80d887b925672550ad87.md)

## Rule 013 — `outlines/prompts.py`

- **Rule:**
  ```text
  Prompt.__call__ must bind and apply defaults when a signature is present, rendering with bound argument names, and otherwise render directly from kwargs.
  ```
- **Applies to:**
  - `outlines/prompts.py`
- **Condition:**
  ```text
  Modifying Prompt.__call__ argument resolution or rendering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0d995bfacf01a49347aaa87a.md)

## Rule 014 — `pyproject.toml`

- **Rule:** The project version is declared dynamically rather than statically in pyproject.toml.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0de415e50e140efa1388df9c.md)

## Rule 015 — `outlines/processors/structured.py`

- **Rule:** JSONLogitsProcessor must bias generation based on a JSON schema through RegexGuide inheritance, so contributors changing JSON schema biasing must preserve the RegexLogitsProcessor subclass relationship.
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:** When modifying JSONLogitsProcessor or the JSON schema biasing path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0e7f5595237558f9f3d27558.md)

## Rule 016 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow checks that the package version matches the release name by grepping for "^Version: ${GITHUB_REF:10}$" in outlines.egg-info/PKG-INFO.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-100e2e998b97f12a7cb242e2.md)
