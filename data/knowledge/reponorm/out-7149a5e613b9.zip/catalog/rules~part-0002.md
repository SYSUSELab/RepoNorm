# Full rule catalog

## Rule 017 — `tests/fsm/test_guide.py`

- **Rule:**
  ```text
  Tests for the FSM guide must assert that RegexGuide.from_regex reaches a final state and remains final on repeated tokens, that walk_fsm with full_match=True returns one accepted state per transition or an empty list when a transition is not accepted or the final state is not final, and that StopAtEOSGuide returns Generate with tokens None at start, Write with tokens [2] at final, transitions on token 2, stays at start on token 1, and reports is_final_state correctly.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
  - `tests/fsm/test_parsing.py`
- **Condition:**
  ```text
  when adding or modifying FSM guide tests that assert final-state persistence, walk_fsm acceptance semantics, or StopAtEOSGuide instruction and transition contracts
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-10d9b137b55a570b642d3182.md)

## Rule 018 — `tests/fsm/test_parsing.py`

- **Rule:**
  ```text
  The FSM parsing test module must import fsm_union and walk_fsm from outlines.fsm.parsing as a temporary compatibility shim, with a TODO to remove once implemented in Outlines-Core.
  ```
- **Applies to:**
  - `tests/fsm/test_parsing.py`
- **Condition:** when modifying imports in the FSM parsing tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1179062b895610347fc4fffb.md)

## Rule 019 — `outlines/models/openai.py`

- **Rule:**
  ```text
  When modifying OpenAI.__init__, preserve the per-instance cumulative token accounting contract: prompt_tokens and completion_tokens counters are initialized and documented as summed over all requests made with the model instance.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When changing token counter initialization or accounting semantics in OpenAI.__init__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-12512ce7fe051d199514ceaf.md)

## Rule 020 — `.github/workflows/release_docker.yml`

- **Rule:**
  ```text
  The workflow builds and pushes a Docker image tagged outlinesdev/outlines:latest and outlinesdev/outlines:<release tag or manual release_tag input>, with build arg BUILDKIT_CONTEXT_KEEP_GIT_DIR=true.
  ```
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-125feb7e0c27e091795e6082.md)

## Rule 021 — `tests/models/test_mlxlm.py`

- **Rule:** Tests for the MLX model must gate execution on both MLX import availability and Apple Silicon hardware availability, skipping with a reason when unavailable, and must assert NotImplementedError for batch inference and beam search.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying MLX model tests that require MLX runtime or exercise unsupported capabilities
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-14fe27a7a4c7c0d3e4774141.md)

## Rule 022 — `tests/models/test_transformers.py`

- **Rule:**
  ```text
  Tests for the transformers model must assert that the model call returns logits as a 2-D torch.FloatTensor with shape[0] equal to batch size and a kv_cache whose length equals config.n_layer with per-layer key tensor shape[1]==config.n_head, and that TransformerTokenizer.encode returns 2-D torch.LongTensor token_ids and attention_mask with matching shapes and left padding.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:** when adding or modifying transformers model or tokenizer tests that assert output tensor shapes and padding behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-158af57160f10f29b8519fee.md)

## Rule 023 — `**/*.py`

- **Rule:** Flake8 ignores error codes E203, E231, E501, E741, W503, W504, C901, and E731.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1db9bf455975434177bef7c0.md)

## Rule 024 — `tests/models/test_openai.py`

- **Rule:** OpenAI JSON generation tests with a pydantic model must assert that a valid JSON completion is parsed into the model and a non-JSON completion raises ValidationError.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when modifying or extending OpenAI JSON generation tests that use a pydantic model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1ecd5c3d64ab4567048966ff.md)

## Rule 025 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  _decode_generation must dispatch on tensor rank: 1D returns a single decoded string, 2D returns batch-decoded strings, 3D returns a list of per-sample decodes, and any other rank raises TypeError.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying _decode_generation or its rank-based dispatch
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1f8ddf406d0107f6e5bd8881.md)

## Rule 026 — `tests/generate/test_integration_transformers.py`

- **Rule:** Tests for the transformers integration must assert that generate.format(model, bool) returns a non-empty bool, verifying format-constrained generation produces the requested Python type.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** when adding or modifying transformers integration tests that exercise format-constrained generation with a Python type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1f9b8a9f3dca3734b759c463.md)

## Rule 027 — `**/*.py`

- **Rule:**
  ```text
  mypy is configured with an override for the listed modules that sets ignore_missing_imports = true.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-20e6590ef707468f65bc038d.md)

## Rule 028 — `tests/fsm/test_parsing.py`

- **Rule:**
  ```text
  Partial parsing tests must assert that incomplete inputs yield a 'partial' last token with fsm_state_seq and is_not_finished, that an empty value_stack is expected for unfinished parses, and that incremental continuation via parse_from_state works, while invalid inputs raise UnexpectedToken.
  ```
- **Applies to:**
  - `tests/fsm/test_parsing.py`
- **Condition:** when modifying partial parsing behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-22690e16f1562d0a386b6284.md)

## Rule 029 — `outlines/fsm/guide.py`

- **Rule:**
  ```text
  When modifying StopAtEOSGuide.is_final_state, preserve the invariant that it compares the given state to the single stored final_state, so the guide model assumes exactly one final state per guide.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  When changing final-state comparison or guide final-state storage in StopAtEOSGuide.is_final_state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-238786309a1b70b2b8f2e02d.md)

## Rule 030 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  _get_generation_kwargs must map GenerationParameters/SamplingParameters into a transformers GenerationConfig with max_new_tokens defaulting to 2**30 when None, do_sample set only when sampler=='multinomial', num_beams equal to num_samples for beam_search, and seed triggering a global set_seed.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying _get_generation_kwargs or the GenerationParameters/SamplingParameters to GenerationConfig mapping
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2d081b00654e854cf1f0e503.md)
