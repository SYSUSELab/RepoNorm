# Full rule catalog

## Rule 079 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  PartialLark._build_parser must preserve the inlined lark _construct_parsing_frontend type assertions and the side effects that mutate parser_conf.parser_type and lexer_conf.lexer_type, so contributors changing parser/lexer options keep these invariants intact.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying PartialLark._build_parser or the parser/lexer option construction path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7917386123b7ddfc8d88c862.md)

## Rule 080 — `tests/generate/test_generate.py`

- **Rule:**
  ```text
  The regex batch-stream test asserts that streaming generation for a batch of two sequences maintains per-sequence order: outputs[0] accumulates tokens[0] and outputs[1] accumulates tokens[1], and each accumulated output must fully match the regex pattern.
  ```
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  When modifying batch streaming generation behavior or per-sequence ordering exercised by test_generate_regex_batch_stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-794e6abef0c271dbaf5bec63.md)

## Rule 081 — `**`

- **Rule:** The pre-commit configuration enables the debug-statements hook from pre-commit/pre-commit-hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7990d953e65eda4a85bdc6cc.md)

## Rule 082 — `outlines/processors/structured.py`

- **Rule:**
  ```text
  When modifying GuideLogitsProcessor.process_logits, preserve the caching and masking contract: guide states are cached keyed by hash of generated token tuples, _seq_start_idx is initialized from the first input length, and logits are masked by setting disallowed token positions to -inf across the batch.
  ```
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:**
  ```text
  When changing guide state caching, sequence start indexing, or logits masking in GuideLogitsProcessor.process_logits.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7e418e25d9889202316e847b.md)

## Rule 083 — `outlines/fsm/guide.py`

- **Rule:** When modifying StopAtEOSGuide.copy, preserve the behavior of returning self rather than a new object, so guide instances remain immutable/shareable and callers must not rely on copy producing independent mutable state.
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:** When changing guide copy behavior or adding mutable state to guides.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7e684f4ddf909a2bc464d225.md)

## Rule 084 — `tests/fsm/test_guide.py`

- **Rule:** Multi-byte regex guide tests must assert exact FSM transition maps, including EOS handling to state -1 and non-final state 0, for multi-byte character classes.
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** when modifying RegexGuide multi-byte transition behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-806eee6131429f42a925072b.md)

## Rule 085 — `tests/models/test_mlxlm.py`

- **Rule:**
  ```text
  Tests that exercise MLX-backed models must be gated behind a HAS_MLX skipif with the reason 'MLX tests require Apple Silicon', so they only run where MLX is installed on Apple Silicon.
  ```
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying tests that exercise MLX-backed model or tokenizer behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-82d704aa32d1d9cb65721d31.md)

## Rule 086 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow installs documentation dependencies from requirements-doc.txt and builds the docs with mkdocs build.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-84ef44a68063283abce15fd8.md)

## Rule 087 — `tests/fsm/test_json_schema.py`

- **Rule:** JSON schema enum tests must exercise non-string enum members, including callables, strings, and integers, to verify schema generation handles mixed-type enums.
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:** when modifying enum handling in schema generation or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-85a137e770a7583092dd3ea5.md)

## Rule 088 — `tests/models/test_mlxlm.py`

- **Rule:** Tests for the MLX model must assert that concatenating streamed tokens equals the output of generate for the same prompt and parameters, establishing stream/generate equivalence.
- **Applies to:**
  - `tests/models/test_mlxlm.py`
- **Condition:** when adding or modifying MLX streaming tests that compare streamed output to generate output
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-876c0d92fc369f66b0e78389.md)

## Rule 089 — `outlines/prompts.py`

- **Rule:**
  ```text
  Prompt must remain a dataclass carrying a jinja2.Template and an Optional[inspect.Signature], returned instead of a plain function so the template defined in prompt functions stays accessible.
  ```
- **Applies to:**
  - `outlines/prompts.py`
- **Condition:** When changing how prompt functions return or expose their template and signature.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-87828337fe0b3ae7905891cf.md)

## Rule 090 — `outlines/generate/api.py`

- **Rule:**
  ```text
  The token_generator must reshape outputs by batch_size and num_samples: yield a scalar string when both are 1, a list when batch_size is 1, a list of first samples when num_samples is 1, and a nested list otherwise; it must also track is_stop_at_reached per sequence and strip stop sequences before formatting.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:**
  ```text
  when modifying SequenceGenerator.stream.token_generator or its output shaping and stop-sequence handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8a944f34f5588b3fc7aa00fb.md)

## Rule 091 — `.github/workflows/release_docker.yml`

- **Rule:**
  ```text
  The workflow logs in to Docker Hub using the DOCKERHUB_USERNAME and DOCKERHUB_TOKEN secrets.
  ```
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8f3ac65f8c321167a4227915.md)

## Rule 092 — `outlines/prompts.py`

- **Rule:**
  ```text
  get_fn_name must raise TypeError for non-callables and fall back to type(fn).__name__ when the callable lacks __name__, supporting callable objects in the name filter.
  ```
- **Applies to:**
  - `outlines/prompts.py`
- **Condition:**
  ```text
  Modifying get_fn_name callable name resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-904da96df0701609312fa1d7.md)

## Rule 093 — `**/*.py`

- **Rule:** Coverage measurement enables branch coverage.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-90e6f276b16bd31b4460049d.md)

## Rule 094 — `outlines/caching.py`

- **Rule:**
  ```text
  When modifying disable_cache in outlines/caching.py, preserve its semantics: it only flips a global flag for the session; it does not delete existing cache entries and does not overwrite the cache with values produced during the disabled session.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:**
  ```text
  Modifying disable_cache or cache-disabled session behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-93e7fc6c06d1dec32fc1d1f7.md)
