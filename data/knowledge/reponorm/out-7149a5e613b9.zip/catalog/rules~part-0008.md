# Full rule catalog

## Rule 113 — `tests/fsm/test_json_schema.py`

- **Rule:**
  ```text
  Tests for schema-to-regex conversion must assert that build_regex_from_schema accepts a JSON schema string and returns a str, and must preserve declaration-order object properties with nested array item typing when converting function signatures to schemas.
  ```
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:** when modifying signature-to-schema conversion or schema-to-regex conversion behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b6447772413dfa1068bf5279.md)

## Rule 114 — `outlines/samplers.py`

- **Rule:**
  ```text
  When modifying the top-k logits processor, preserve the safety property that it keeps min(k, vocab_size) tokens and masks all logits below the k-th top value with negative infinity, so k larger than the vocabulary is handled without error.
  ```
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:** Changing the top-k logits processor's masking logic or its handling of k relative to vocabulary size.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b6cd9e9dc95f28541604f866.md)

## Rule 115 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow checks out the repository with fetch-depth 0.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b6cfc2f175aa587be77456f5.md)

## Rule 116 — `tests/generate/test_api.py`

- **Rule:** Tests for vision sequence generator input validation must assert TypeError for mismatched prompt/media shapes such as a single prompt with a list of images or nested list mismatches, defining accepted vision input shapes.
- **Applies to:**
  - `tests/generate/test_api.py`
- **Condition:** when adding or modifying tests for vision sequence generator input shape validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b7aa7871b60fffa2e05e7647.md)

## Rule 117 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow builds the SDist and wheel by running ./.github/scripts/build_sdist_and_wheel.sh.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b92953616391397a3f77b8cc.md)

## Rule 118 — `mkdocs.yml`

- **Rule:** The mkdocstrings plugin uses the python default handler.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bbe582435bf4f34634e9a7a2.md)

## Rule 119 — `outlines/models/vllm.py`

- **Rule:**
  ```text
  vllm() must lazily import vllm.LLM inside the function, construct LLM(model_name, **vllm_model_params), and wrap it in VLLM, preserving lazy import and parameter pass-through.
  ```
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** When modifying vllm() or its model construction and parameter pass-through.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bd95a59ed66a4751d698ff0b.md)

## Rule 120 — `tests/test_prompts.py`

- **Rule:** Prompt functions decorated with @outlines.prompt are ordinary Python functions whose docstring is a template using {{var}} placeholders, and default argument values are usable in the template.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When adding or modifying a prompt function test that exercises template rendering with default arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bf59d09e0b3499260c66a65c.md)

## Rule 121 — `outlines/generate/generator.py`

- **Rule:**
  ```text
  is_generation_finished must treat a batch as finished only when every sequence's FSM is in a final state; the known batch-level completion limitation is documented and must not be silently changed without addressing the docstring.
  ```
- **Applies to:**
  - `outlines/generate/generator.py`
- **Condition:**
  ```text
  when modifying is_generation_finished or batch completion semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c66707855fd1c82316952fef.md)

## Rule 122 — `tests/test_prompts.py`

- **Rule:** Prompt template tests must assert that a for-loop without whitespace control leaves a trailing newline, while closing with -%} strips the following newline, and the same -%} behavior applies to conditionals.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When adding or modifying a prompt template test that exercises Jinja whitespace control in loops or conditionals.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c6d76c8568acf5f60daca087.md)

## Rule 123 — `tests/fsm/test_guide.py`

- **Rule:**
  ```text
  RegexGuide.from_regex must raise ValueError whose message contains "The vocabulary" when the regex uses a character class outside the tokenizer vocabulary, because tests assert that error text.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:**
  ```text
  when changing vocabulary validation in RegexGuide.from_regex
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c810ffcf664333021c2621e4.md)

## Rule 124 — `outlines/models/openai.py`

- **Rule:**
  ```text
  When a config is supplied to azure_openai, the deployment_name must replace the configured model; when no config is supplied, the constructed OpenAIConfig must use model=deployment_name.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  Modifying azure_openai's config handling or model resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cf85f7252d68a3a30322c266.md)

## Rule 125 — `tests/models/test_openai.py`

- **Rule:** OpenAI choice-call tests must assert that a malformed server response raises json.decoder.JSONDecodeError.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when modifying or extending OpenAI choice-call tests that simulate malformed server responses
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cf8bdf0376aeb25beeb86611.md)

## Rule 126 — `.github/workflows/publish_documentation.yml`

- **Rule:** When the event is a release, the workflow deploys the tag as latest using mike deploy --push --update-aliases and sets latest as the default with mike set-default --push.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'release'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d042b02a17283daf962b7eb6.md)

## Rule 127 — `tests/test_types.py`

- **Rule:** Tests that exercise custom type annotations in pydantic models must preserve the custom type handling in model generation.
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** When modifying tests that define pydantic models with custom type annotations
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d168896278960a8844e1efba.md)

## Rule 128 — `benchmarks/bench_regex_guide.py`

- **Rule:** Benchmark input fixtures must use a fixed, named set of regex samples (email, phone, date, time, ip, url, ssn, etc.) as benchmark inputs.
- **Applies to:**
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying regex guide benchmark input fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d1abaeff1aef91ca51a1e6d0.md)
