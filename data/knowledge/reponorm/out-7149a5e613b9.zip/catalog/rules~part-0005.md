# Full rule catalog

## Rule 064 — `outlines/models/llamacpp.py`

- **Rule:**
  ```text
  LlamaCppTokenizer.__getstate__ must return a tuple of vocabulary, eos_token_id, eos_token, pad_token_id, and sorted special_tokens to provide a stable representation for outlines.caching.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  When modifying LlamaCppTokenizer.__getstate__ or the cache-state tuple it returns.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5f22e155a5146f1d6c44af8d.md)

## Rule 065 — `outlines/models/llamacpp.py`

- **Rule:**
  ```text
  When modifying LlamaCppTokenizer pickling support, preserve the unsupported status: __setstate__ raises NotImplementedError("Cannot load a pickled llamacpp tokenizer").
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** When changing LlamaCppTokenizer serialization or unpickling behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6189e7d35b191cec5d01e65d.md)

## Rule 066 — `tests/generate/test_integration_llamacpp.py`

- **Rule:** Tests that exercise the llama.cpp backend must expect beam-search generation to raise NotImplementedError, because that backend does not support beam search.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** when adding or modifying llama.cpp backend integration tests that exercise beam-search sampling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-66b36b4c404d1428291bee86.md)

## Rule 067 — `tests/fsm/test_guide.py`

- **Rule:**
  ```text
  The MockTokenizer test helper must expose inverse_vocabulary as a property computed by reversing the vocabulary mapping, and decode must handle both nested and flat token id lists using that inverse mapping.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** when modifying or extending the MockTokenizer helper used by guide tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-67b05d83d9966976b0ac9770.md)

## Rule 068 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialTokensInfo, preserve the dataclass fields fsm_state_seq, is_not_finished, terminals_and_info, and final_terminals_and_info so in-progress terminals remain distinguished from final terminals for partial-token parsing.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing PartialTokensInfo fields or partial-token terminal tracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6a5079bb6276538675fdd24f.md)

## Rule 069 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  When modifying TransformerTokenizer.decode, preserve the contract that token_ids are batch-decoded with skip_special_tokens=True, so special tokens are stripped from returned text.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When changing decoding behavior or special-token handling in TransformerTokenizer.decode.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6c1d4309413196812a549ab9.md)

## Rule 070 — `tests/fsm/test_parsing.py`

- **Rule:**
  ```text
  Tests that exercise lark parsing must restore lark.lark.LarkOptions._defaults after the test, because lark mutates global default options.
  ```
- **Applies to:**
  - `tests/fsm/test_parsing.py`
- **Condition:** When adding or modifying tests that exercise lark parsing and may mutate global lark options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6eeaa3ce235b215182a74a24.md)

## Rule 071 — `tests/test_base.py`

- **Rule:**
  ```text
  The vectorize helper with output signature '(s)' expands each scalar result into a repeated dimension, so vectorizing a function returning a scalar over ['one','two'] yields [['one','one','one'],['two','two','two']].
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  When modifying vectorize expansion behavior or the '(s)' output-signature handling exercised by test_vectorize_expand.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6f31a19ccf7f35ed27b48c13.md)

## Rule 072 — `outlines/samplers.py`

- **Rule:**
  ```text
  When modifying BeamSearchSampler.__call__, preserve the special case where all sequence_weights are zero restricts top-k selection to the first vocab_size logits, treating that state as the beginning of the search.
  ```
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:**
  ```text
  When changing BeamSearchSampler top-k selection or sequence_weights handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6f6911cfe49405b2de0dabbd.md)

## Rule 073 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialParserState.__copy__ in outlines/fsm/parsing.py, preserve the copy semantics: parse_conf, lexer, and state_stack are copied, value_stack is deepcopied, and use_value_stack is preserved.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  Modifying PartialParserState.__copy__ or parser state copying behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-724ba491ba650518c20f57d5.md)

## Rule 074 — `tests/test_prompts.py`

- **Rule:**
  ```text
  The temp_prompt_file fixture writes base_template.txt, include.txt, and prompt.txt into a temp dir, exercising Jinja extends, block, include, and for-loop constructs in prompt templates.
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:**
  ```text
  When modifying the temp_prompt_file fixture or the Jinja template constructs it exercises.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-73d41bd750b3d3adbf645f90.md)

## Rule 075 — `tests/models/test_transformers.py`

- **Rule:**
  ```text
  When both an explicit device argument and a model_kwargs device_map are provided to transformers(), the explicit device argument must take precedence, leaving the model on the requested device.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:**
  ```text
  when modifying transformers() device selection or model_kwargs handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7414888eb6e36ea5f03d56d2.md)

## Rule 076 — `**/*.py`

- **Rule:** mypy enables the incomplete Unpack feature.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-76551dfccf229cb15baefcc6.md)

## Rule 077 — `environment.yml`

- **Rule:** The environment's dependencies include python==3.10.0.
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-772720d5dad762736235fec3.md)

## Rule 078 — `outlines/models/llamacpp.py`

- **Rule:**
  ```text
  When modifying LlamaCpp.prepare_generation_parameters, preserve the translation contract: subtract one from max_tokens because llama-cpp-python generates max_tokens + 1 tokens, raise NotImplementedError for beam search and multiple samples, disable streaming, and append the structure logits processor to a LogitsProcessorList.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  When changing parameter translation, sampling restrictions, or logits processor wiring in LlamaCpp.prepare_generation_parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-78fd7b623d6a3d772f685f1d.md)
