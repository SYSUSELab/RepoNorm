# Full rule catalog

## Rule 145 — `tests/models/test_openai.py`

- **Rule:**
  ```text
  Tests that patch outlines.models.openai.generate_chat must assert that the OpenAIConfig passed reflects constructor values and that a per-call samples argument overrides config.n.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:**
  ```text
  When adding or modifying tests that patch outlines.models.openai.generate_chat.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eb66f236c46ed63c0ce452a9.md)

## Rule 146 — `outlines/fsm/guide.py`

- **Rule:**
  ```text
  cached_create_states_mapping must delegate directly to uncached_create_states_mapping with no caching applied, remaining a no-op placeholder.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  Modifying cached_create_states_mapping or adding caching to it.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eb7c0b8c5fb29286c2f60111.md)

## Rule 147 — `tests/generate/test_integration_exllamav2.py`

- **Rule:** Backend integration tests for streaming generation must assert that iterating the generator yields only str tokens, establishing the streaming output type contract for that backend.
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:** When adding or modifying a backend integration test that iterates a streaming generation generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-efa06fb75827d50767294e8b.md)

## Rule 148 — `outlines/samplers.py`

- **Rule:** Custom sampler implementations must expose a samples attribute to satisfy the Sampler Protocol, so contributors adding or changing sampler classes must provide that attribute.
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:** When defining or modifying a sampler class intended to satisfy the Sampler Protocol.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f5fdd4b9ededdcb276fe3651.md)

## Rule 149 — `tests/fsm/test_cfg_guide.py`

- **Rule:** CFG guide next-token tests must advance the guide state through generated tokens and compare the sorted set of returned next tokens against the expected legal tokens, mapping None to the tokenizer eos token.
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** when modifying CFG guide next-token behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f61196d10c2a29e35f629d14.md)

## Rule 150 — `outlines/base.py`

- **Rule:** When modifying the vectorize helper, preserve the behavioral difference that wrapped coroutines are executed concurrently while synchronous calls run in a loop like NumPy's vectorize.
- **Applies to:**
  - `outlines/base.py`
- **Condition:** Changing the vectorize helper's execution strategy for wrapped functions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f65b97a4ac24b15b45c9f958.md)

## Rule 151 — `tests/test_prompts.py`

- **Rule:**
  ```text
  Prompt template tests must exercise functions with type annotations including nested generics (e.g. Dict[int, List[str]]) and multi-parameter signatures with defaults, so annotation rendering handles complex typing constructs.
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** when adding or modifying prompt template tests that cover function signature rendering
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f661c93c400e6499935fd0e1.md)

## Rule 152 — `benchmarks/bench_cfg_guide.py`

- **Rule:** Benchmark grammar fixtures must seed randomness with 42 and bench the json and arithmetic grammars from outlines.grammars.
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:** When adding or modifying CFG guide benchmark grammar fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f761891f7fcccdcfe70ff642.md)

## Rule 153 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialParser.parse_from_state, preserve the contract that lexer tokens are fed into the parser state, EOF is fed only when is_end is true and the last token is not partial, UnexpectedInput is re-raised with an attached InteractiveParser, and the state stack dump is printed only when self.debug is set.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When changing token feeding, EOF handling, or exception behavior in PartialParser.parse_from_state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f80c805b753d5332d5c0793f.md)

## Rule 154 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  Transformers.__call__ must return next_token_logits = logits[..., -1, :] together with the kv cache so callers receive only the last-position logits per sequence.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying Transformers.__call__ or its returned logits shape
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fe89ed93044c9256246d40a0.md)

## Rule 155 — `tests/test_grammars.py`

- **Rule:**
  ```text
  Test tokenizer helpers must expose inverse_vocabulary as a property computed by inverting self.vocabulary, establishing that test tokenizers provide a vocabulary mapping whose keys are tokens and values are ids.
  ```
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:** when adding or modifying test tokenizer helpers that provide a vocabulary mapping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ffe17f2e036c154eb82ea8c3.md)
