# Full rule catalog

## Rule 031 — `outlines/models/transformers_vision.py`

- **Rule:** TransformersVisionModel.stream must raise NotImplementedError; streaming is not supported for the transformers vision model.
- **Applies to:**
  - `outlines/models/transformers_vision.py`
- **Condition:** when modifying TransformersVisionModel.stream or adding streaming support to the vision model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2eead148f69b34596f1f564c.md)

## Rule 032 — `tests/generate/test_integration_transformers.py`

- **Rule:** Tests for the transformers JSON batch generation must assert that passing a list of prompts returns a list of BaseModel instances, one per prompt.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** when adding or modifying transformers integration tests that exercise JSON batch generation with a list of prompts
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2f2439720aa7821bd18ba51b.md)

## Rule 033 — `benchmarks/bench_json_schema.py`

- **Rule:** Benchmark classes must parametrize over the full set of available schema/grammar keys (e.g., schemas.keys()) so every named case is exercised.
- **Applies to:**
  - `benchmarks/bench_json_schema.py`
- **Condition:** When adding or modifying a benchmark class that selects among named schemas or grammars.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-340a37246f1b42e32c0fea1a.md)

## Rule 034 — `.github/workflows/release_pypi.yaml`

- **Rule:**
  ```text
  The release workflow publishes to PyPI using pypa/gh-action-pypi-publish with user __token__ and password from the PYPI_TOKEN secret.
  ```
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-35e1f1d5efa6190b7e479842.md)

## Rule 035 — `outlines/models/vllm.py`

- **Rule:**
  ```text
  When modifying the vLLM adapter's sampling configuration, preserve the workaround that sets repetition_penalty to 0 whenever top_k is 1, until the referenced upstream vLLM issue is fixed.
  ```
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:**
  ```text
  When changing top_k or repetition_penalty handling in the vLLM adapter.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-36eb21b99e86a1556b1b8658.md)

## Rule 036 — `.github/workflows/release_pypi.yaml`

- **Rule:** The release workflow sets up Python version 3.10 via actions/setup-python.
- **Applies to:**
  - `.github/workflows/release_pypi.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-398e2d2c017e8654105fb84a.md)

## Rule 037 — `tests/fsm/test_types.py`

- **Rule:**
  ```text
  The test_python_types parametrization must map int, float, bool, datetime.date, datetime.time, and datetime.datetime to INTEGER, FLOAT, BOOLEAN, DATE, TIME, and DATETIME respectively, asserting python_types_to_regex returns the matching regex.
  ```
- **Applies to:**
  - `tests/fsm/test_types.py`
- **Condition:**
  ```text
  when adding or modifying python_types_to_regex type-mapping tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3d39ecc3109aeb56ee40149d.md)

## Rule 038 — `tests/models/test_openai.py`

- **Rule:** OpenAI model tests must cover both sync and async client paths, importing AsyncOpenAI alongside OpenAI and OpenAIConfig, and choice selection must be driven by the patched model response.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying OpenAI model tests or choice selection behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3d5ba0059c8d45ba45e52622.md)

## Rule 039 — `tests/generate/test_generate.py`

- **Rule:** Batch generation tests with regex constraints must assert that batch generation with multiple inputs maintains FSM order and that every output fully matches the regex pattern.
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:** When adding or modifying a batch generation test that exercises regex-constrained generation with multiple inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3e4fcc99605ef0604d15a489.md)

## Rule 040 — `tests/test_base.py`

- **Rule:**
  ```text
  Tests for vectorize must assert that it accepts a signature string such as (m)->(m) or ()->() and applies the wrapped function elementwise over nested input arrays, preserving the array shape in the output.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** when adding or modifying tests for vectorize signature handling and elementwise application
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-42068b5ad77882a064a1381d.md)

## Rule 041 — `tests/generate/test_integration_exllamav2.py`

- **Rule:**
  ```text
  Backend integration tests for output reformatting must assert the exact regrouping behavior: a single string is returned unchanged, a one-element list is unwrapped to its element, and with num_samples=2 a flat list is regrouped into pairs.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When adding or modifying a backend integration test that exercises reformat_output with varying sample counts.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-42d22cf411d2eb4f8878b8fb.md)

## Rule 042 — `mkdocs.yml`

- **Rule:**
  ```text
  The extra_css setting includes stylesheets/extra.css.
  ```
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-449801259488a2118a5c4414.md)

## Rule 043 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow creates an ASV machine config named gh-runner with asv machine --machine gh-runner --yes.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-44cf7fa7e80a7fba02ddf0ad.md)

## Rule 044 — `tests/test_prompts.py`

- **Rule:** Prompt tests must define decorated templates using the schema filter on a model argument, showing prompt templates can render a model's schema.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** when adding or modifying prompt tests that exercise schema rendering filters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-45c6a6eaa3e5b5d8e9f8649f.md)

## Rule 045 — `tests/test_grammars.py`

- **Rule:**
  ```text
  Grammar tests must use a mock tokenizer whose decode maps token ids through inverse_vocabulary, asserting a one-to-one token-id-to-string mapping.
  ```
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:** when adding or modifying grammar tests that need token decoding
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-49080b147d59a59a000e060d.md)

## Rule 046 — `tests/generate/test_integration_llamacpp.py`

- **Rule:** Backend integration tests for text stop sequences must assert that the generated output contains no occurrence of the stop string, verifying stop-token enforcement.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:**
  ```text
  When adding or modifying a backend integration test that supplies a stop_at or stop string to generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-49d1d6f7868f08dbe63ef181.md)

## Rule 047 — `mkdocs.yml`

- **Rule:**
  ```text
  The mkdocstrings python handler sets show_submodules to true.
  ```
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4b2881042e7b79390781d8f5.md)
