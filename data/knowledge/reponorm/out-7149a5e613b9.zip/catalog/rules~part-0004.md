# Full rule catalog

## Rule 048 — `outlines/models/openai.py`

- **Rule:**
  ```text
  When modifying the OpenAI model module, preserve the centralized error-handling boundary: API calls are wrapped with an error_handler decorator intended to handle OpenAI API errors and missing API keys.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:** When changing API call wrapping or error handling in the OpenAI model module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4d7a879619bacbdb86f066eb.md)

## Rule 049 — `benchmarks/bench_cfg_guide.py`

- **Rule:**
  ```text
  Benchmark timing methods must disable caching (via cache_disabled) so measured durations reflect uncached construction/execution rather than cached results.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark timing method that constructs a guide or FSM from a schema/regex/grammar.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4ef54f6ec8eea0be236fa396.md)

## Rule 050 — `tests/fsm/test_parsing.py`

- **Rule:**
  ```text
  The _reconstruct_fsms test helper must assert exactly one symbol per transition and must not be relied upon for reconstructing FSMs with more than one transition per symbol, as documented by its NOTE.
  ```
- **Applies to:**
  - `tests/fsm/test_parsing.py`
- **Condition:**
  ```text
  when using or modifying the _reconstruct_fsms helper in parsing tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4fdb995cf2fb20fa82d86c71.md)

## Rule 051 — `mkdocs.yml`

- **Rule:** The git-committers plugin is configured for branch main.
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-504f07f553a018e146cbba0a.md)

## Rule 052 — `**/*.py`

- **Rule:** Flake8 enforces a maximum line length of 88 characters.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-50fb0f7e1d2e1a06e9e983f4.md)

## Rule 053 — `tests/fsm/test_cfg_guide.py`

- **Rule:**
  ```text
  The session-scoped tokenizer fixture in the CFG guide tests must load the real 'google/byt5-small' tokenizer via AutoTokenizer.from_pretrained, so tests depending on it require network/model availability.
  ```
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** when adding or modifying the session-scoped tokenizer fixture in the CFG guide tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-51013755a48f9eb9abde35a3.md)

## Rule 054 — `outlines/processors/base_logits_processor.py`

- **Rule:** MLX array detection must remain optional: if mlx.core cannot be imported the helper returns false rather than raising, so MLX stays a soft dependency for logits processing.
- **Applies to:**
  - `outlines/processors/base_logits_processor.py`
- **Condition:**
  ```text
  when modifying is_mlx_array_type or MLX detection in logits processing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-51e4f3a1fb7374ca4d145a64.md)

## Rule 055 — `tests/generate/test_generator.py`

- **Rule:**
  ```text
  Tests for bias_logits must assert that it sets logits at indices not listed in indices_to_mask to -math.inf while preserving listed indices, across single- and multi-row tensors.
  ```
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:**
  ```text
  when adding or modifying tests for bias_logits masking behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-53c7b86558d2fd1ecc18abe0.md)

## Rule 056 — `tests/test_types.py`

- **Rule:**
  ```text
  Tests for custom scalar types must verify both the JSON schema string pattern and the python_types_to_regex regex against valid and invalid examples, using parametrization over the type cases.
  ```
- **Applies to:**
  - `tests/test_types.py`
- **Condition:** when adding or modifying a test for a custom scalar type's schema pattern or regex
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5607fdb8d9a2900c0514a566.md)

## Rule 057 — `outlines/samplers.py`

- **Rule:**
  ```text
  When modifying keep_top_p_logits, preserve the validation that rejects p values less than or equal to 0 or greater than 1 with a ValueError, keeping the valid top-p range as (0, 1].
  ```
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:** When changing top-p sampling validation or parameter handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-584525002966f4cce3c41a73.md)

## Rule 058 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  to_tuple must canonicalize values by sorting elements by str and memoizing the mapping in old_to_new, so equivalent sets produce stable tuple ordering.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying to_tuple or the canonicalization of parser values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-586bd17847a375eb6f026ae5.md)

## Rule 059 — `outlines/generate/api.py`

- **Rule:**
  ```text
  SequenceGeneratorAdapter.__call__ must accept a prompt or list of prompts plus optional max_tokens, stop_at, seed, and model-specific params, prepare generation parameters, call model.generate with a copy of the logits processor, and format completions.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:**
  ```text
  When modifying SequenceGeneratorAdapter.__call__ or the generation call path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5a4ce415df36b1dd893b6b62.md)

## Rule 060 — `.github/workflows/release_docker.yml`

- **Rule:** The workflow cleans the docker cache by running docker system prune --all --force.
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5a7a0ee00b49a4088266b242.md)

## Rule 061 — `tests/generate/test_integration_llamacpp.py`

- **Rule:**
  ```text
  The llama.cpp integration test module must define TEST_MODEL as a local GGUF path './llama-test-model/TinyMistral-248M-v2-Instruct.Q4_K_M.gguf', documenting the expected local model artifact for llamacpp integration tests.
  ```
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** when adding or modifying llama.cpp integration tests that reference the local test model artifact
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5ae37fa01bee2286ddfc99fe.md)

## Rule 062 — `tests/generate/test_generate.py`

- **Rule:**
  ```text
  The get_inputs helper selects prompts by fixture name and, for fixtures ending in '_vision', returns a dict with 'prompts' and 'media' keys, encoding the multimodal input convention used across generation tests.
  ```
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  When modifying the get_inputs helper or adding new generation-test fixtures that require multimodal inputs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5d1d00a06836a93685ea8969.md)

## Rule 063 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialParsingFrontend in outlines/fsm/parsing.py, do not reintroduce the abandoned _state_transition_map design built from parse_table.states and a contextual lexer; the commented-out code and TODO document it as a known performance concern.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** Modifying PartialParsingFrontend or considering a state-transition-map optimization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5ee9751b49f8c88cb28ba0cb.md)
