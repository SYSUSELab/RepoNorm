# Full rule catalog

## Rule 129 — `.github/workflows/publish_documentation.yml`

- **Rule:** When the event is a push, the workflow deploys the branch as unstable using mike deploy --push --update-aliases.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d1c651a8f09a1222f4e32fa2.md)

## Rule 130 — `tests/fsm/test_guide.py`

- **Rule:**
  ```text
  Tests for the CFG guide must assert the exact token-allowance state machine: the allowed token sets after each token and the point at which must_terminate_state/can_terminate_state become true.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** When adding or modifying tests for CFGGuide token allowance and termination behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d1dd28ff38ce35a0e824fecb.md)

## Rule 131 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  Transformers.generate must keep the single-string path: encode one prompt as a 2D batch, move input_ids and attention_mask to the model device, drop attention_mask when the model forward signature does not accept it, squeeze the batch dimension for single-string prompts, and decode the generated ids.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying Transformers.generate or its single-string prompt handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d8b3a017f5b0f883b480e51c.md)

## Rule 132 — `tests/generate/test_integration_llamacpp.py`

- **Rule:** Integration tests that assert typed generation output must assert the returned value is an instance of the requested Python type (e.g. datetime.date, datetime.datetime, datetime.time) rather than comparing string representations.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
  - `tests/generate/test_integration_vllm.py`
- **Condition:** when adding or modifying an integration test that verifies generate.format output for a Python type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d9cb4efcea3bfd73b9ba5016.md)

## Rule 133 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialLALRParser.__init__ for deterministic parser_conf, preserve the tuple-keyed parse table rebuild, start/end state remapping, optional IntParseTable conversion with states_to_rulesets recording, and forced debug=True.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing PartialLALRParser initialization or deterministic parse-table construction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d9ed8b5a234ce85ee76770ef.md)

## Rule 134 — `tests/generate/test_integration_transformers.py`

- **Rule:** JSON generation with an integer enum returns a BaseModel whose enum-constrained field is an int restricted to the enum's integer values.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:**
  ```text
  When modifying integer-enum JSON generation behavior exercised by test_transformers_json_int_enum.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d9eec211486b92f1b2134f84.md)

## Rule 135 — `tests/models/test_transformers.py`

- **Rule:**
  ```text
  Tests for the transformers model must supply 2-D token tensors; passing 3-D input_ids raises AssertionError.
  ```
- **Applies to:**
  - `tests/models/test_transformers.py`
- **Condition:**
  ```text
  When adding or modifying tests that pass input_ids to the transformers model.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dbb920fe39c671ab2c756c1a.md)

## Rule 136 — `outlines/_version.py`

- **Rule:**
  ```text
  setuptools_scm writes the generated version file to outlines/_version.py.
  ```
- **Applies to:**
  - `outlines/_version.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dd443f130cfa330543778501.md)

## Rule 137 — `tests/fsm/test_json_schema.py`

- **Rule:** Tests for schema generation must cover both annotated parameters and the error case where a parameter lacks a type annotation, which must raise ValueError.
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:**
  ```text
  When adding or modifying tests for get_schema_from_signature or schema generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dee769faa48c7f5b57d62dee.md)

## Rule 138 — `tests/fsm/test_cfg_guide.py`

- **Rule:**
  ```text
  Guide tests must use Lark's interactive parser (parse_interactive + exhaust_lexer + feed_eof) to validate that each parametrized sample is a legal generation of its grammar, raising a descriptive Exception when the test data itself is invalid.
  ```
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** when adding or modifying CFG guide sample-validation tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df9a84487d96852ad9acf939.md)

## Rule 139 — `tests/generate/test_integration_exllamav2.py`

- **Rule:**
  ```text
  Backend integration tests for paged attention must be skipped unless flash-attn is available and must construct the model with cache_q4=True and paged=True, asserting the expected model type.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:** When adding or modifying a backend integration test that exercises paged attention.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e42f36e1fc353bd81dc746ac.md)

## Rule 140 — `**/*.py`

- **Rule:**
  ```text
  pytest treats warnings as errors by default, with exceptions for pydantic deprecation warnings, FutureWarnings from transformers and huggingface_hub, all UserWarnings, and pyairports DeprecationWarnings.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e5d13f3eddb06a69bba52a3e.md)

## Rule 141 — `outlines/caching.py`

- **Rule:**
  ```text
  When modifying outlines/caching.py, preserve the cache lifecycle: get_cache is lru_cache(1), defaults to HOMEDIR/.cache/outlines overridable via OUTLINES_CACHE_DIR, uses no eviction, and clears the cache when the outlines version changes.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:**
  ```text
  Modifying get_cache or the cache directory/version handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e6be0cde0cb3b9eddb3f2edc.md)

## Rule 142 — `outlines/models/openai.py`

- **Rule:**
  ```text
  When modifying the OpenAI call_api wrapper, preserve the decorator stack (error_handler and cache) and the responses.model_dump() return so caching and error normalization continue to operate on the serialized response dict rather than the raw SDK object.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When changing the OpenAI call_api wrapper's decorators or return value.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e8b90894f72dbfbcca5e8925.md)

## Rule 143 — `mkdocs.yml`

- **Rule:**
  ```text
  The mkdocstrings python handler uses docstring_style numpy.
  ```
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e8fec8c52ad51c67633642b6.md)

## Rule 144 — `tests/**`

- **Rule:**
  ```text
  pytest test discovery is restricted to the tests directory via testpaths = ["tests"].
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ea81df6e07518130dfce8261.md)
