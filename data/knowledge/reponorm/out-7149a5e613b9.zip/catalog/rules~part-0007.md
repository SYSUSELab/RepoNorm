# Full rule catalog

## Rule 095 — `.github/workflows/build_documentation.yml`

- **Rule:** The documentation build job runs on ubuntu-latest and sets up Python 3.10.
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9734669421260a05413f3d60.md)

## Rule 096 — `.github/workflows/build_documentation.yml`

- **Rule:**
  ```text
  The documentation build step installs dependencies from requirements-doc.txt and runs mkdocs build, with GOOGLE_ANALYTICS_KEY supplied from the GOOGLE_ANALYTICS_KEY secret.
  ```
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-99a4e82cf83080b6825e1482.md)

## Rule 097 — `mkdocs.yml`

- **Rule:**
  ```text
  The MkDocs theme custom_dir is docs/overrides.
  ```
- **Applies to:**
  - `mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9a08369acf93027627fef1ae.md)

## Rule 098 — `outlines/fsm/types.py`

- **Rule:**
  ```text
  When modifying python_types_to_regex, preserve the supported-type mapping contract: Annotated custom types use json_schema['pattern'], EnumMeta uses alternation of member names, and float, int, bool, date, time, and datetime are supported; any other Python type raises NotImplementedError directing users to open an issue.
  ```
- **Applies to:**
  - `outlines/fsm/types.py`
- **Condition:**
  ```text
  When changing supported type handling or the fallback error in python_types_to_regex.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9cf21204f50c02a6ea75d613.md)

## Rule 099 — `environment.yml`

- **Rule:**
  ```text
  The environment installs the local project in editable mode with its test extras via pip (-e ".[test]").
  ```
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9daf0d7c8d36cb1b577e1058.md)

## Rule 100 — `outlines/_version.py`

- **Rule:**
  ```text
  Coverage measurement omits outlines/_version.py and tests/* from coverage reporting.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9e6a0c06a8d05cf054847eae.md)

## Rule 101 — `outlines/generate/generator.py`

- **Rule:**
  ```text
  reorder_fsm_states must index fsm_states by each element of the ancestors tensor, so ancestors must contain valid integer indices into fsm_states and the output order follows ancestors order.
  ```
- **Applies to:**
  - `outlines/generate/generator.py`
- **Condition:**
  ```text
  When modifying reorder_fsm_states or the ancestors indexing it performs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3189b6aac084d56b6231281.md)

## Rule 102 — `outlines/types/email.py`

- **Rule:**
  ```text
  When modifying the email type, preserve Email as an annotated str whose JSON schema uses the RFC-style EMAIL_REGEX pattern, so email fields are validated by regex pattern in generated schemas.
  ```
- **Applies to:**
  - `outlines/types/email.py`
- **Condition:** Modifying the Email type in outlines/types/email.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3db302d35d0c7b2f7483710.md)

## Rule 103 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow sets up Python version 3.x.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a6d17084e8da6b09908719ae.md)

## Rule 104 — `tests/generate/test_integration_vllm.py`

- **Rule:** Tests for the vLLM generation API must assert that repeated calls with the same seed produce identical outputs and that a list of prompts yields a list of the same length.
- **Applies to:**
  - `tests/generate/test_integration_vllm.py`
- **Condition:** when adding or modifying vLLM generation API integration tests that check determinism or batch prompt handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a83edb0ddfd73b2e83a4f3d1.md)

## Rule 105 — `tests/models/test_openai.py`

- **Rule:**
  ```text
  module_patch must walk path components from longest to shortest, import the first importable module, patch the remaining attribute, and fall back to mock.patch(path) when no module is found.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:**
  ```text
  when modifying or extending module_patch in tests/models/test_openai.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a904d4b196d650f1de6f973a.md)

## Rule 106 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialParserConf, preserve the __serialize_fields__ declaration including rules, start, parser_type, deterministic, and use_value_stack so serialization preserves exactly those fields.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing PartialParserConf serialization fields or adding/removing configuration attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aa7a6f38134aba80c2574094.md)

## Rule 107 — `outlines/models/vllm.py`

- **Rule:** When modifying the vLLM generate adapter, preserve the batch/sample-dependent return shape: a string for a single batch with a single sample, a list for one batch with several samples, a list of first samples for several batches with one sample, and a nested list otherwise.
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** When changing the vLLM generate adapter's batching or sampling logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aabd7228c3f2fa7874cd9fa4.md)

## Rule 108 — `tests/test_function.py`

- **Rule:**
  ```text
  Tests for extract_function_from_file must assert that an AttributeError matching 'Could not find' is raised when the requested function name is absent from the file content.
  ```
- **Applies to:**
  - `tests/test_function.py`
- **Condition:**
  ```text
  when adding or modifying tests for extract_function_from_file error behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-abebd5069ce5f11f446e29b8.md)

## Rule 109 — `examples/**`

- **Rule:** mypy excludes the examples directory from type checking.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ac7969e2f2e96fbd7661acac.md)

## Rule 110 — `requirements-doc.txt`

- **Rule:** Read the Docs installs documentation dependencies from requirements-doc.txt.
- **Applies to:**
  - `requirements-doc.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b1d3ab165522df6db699c41d.md)

## Rule 111 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow installs asv, virtualenv, and lf-asv-formatter via pip.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b3a8f2fd1dc6c566eeda5116.md)

## Rule 112 — `outlines/processors/structured.py`

- **Rule:**
  ```text
  The structured processor module must import build_regex_from_schema from outlines_core.fsm.json_schema and convert_json_schema_to_str from outlines.fsm.json_schema, preserving the schema-to-regex dependency boundary.
  ```
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:** when modifying outlines/processors/structured.py or its schema-to-regex imports
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b5e2b00a99234c32cc938e56.md)
