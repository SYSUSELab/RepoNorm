# Repository knowledge

Apply rules within their stated scope and when their conditions hold, respecting
exceptions. `required`, `recommended`, and `observed` have different strength:
an observed convention does not by itself prohibit a change requested by the task.
`reference_only` is context, not a default action.
Evidence locations identify sources, not the rule's scope.
Commands in rules do not authorize unrelated changes or external side effects.
Use relevant rules alongside the task and repository code; keep edits focused.

## Find rules

Path links and the [full catalog](catalog.md) are alternative routes. Search or
open relevant files directly; open claim details when evidence or a conflict matters.
Paths are navigation anchors, not a replacement for each rule's complete scope.

- `repository root`: [Read rules](paths/repository.md)
- `.github/workflows/asv_benchmark_pr.yml`: [Read rules](paths/.github/workflows/asv_benchmark_pr.yml.md)
- `.github/workflows/build_documentation.yml`: [Read rules](paths/.github/workflows/build_documentation.yml.md)
- `.github/workflows/publish_documentation.yml`: [Read rules](paths/.github/workflows/publish_documentation.yml.md)
- `.github/workflows/release_docker.yml`: [Read rules](paths/.github/workflows/release_docker.yml.md)
- `.github/workflows/release_pypi.yaml`: [Read rules](paths/.github/workflows/release_pypi.yaml.md)
- `benchmarks/bench_cfg_guide.py`: [Read rules](paths/benchmarks/bench_cfg_guide.py.md)
- `benchmarks/bench_json_schema.py`: [Read rules](paths/benchmarks/bench_json_schema.py.md)
- `benchmarks/bench_regex_guide.py`: [Read rules](paths/benchmarks/bench_regex_guide.py.md)
- `environment.yml`: [Read rules](paths/environment.yml.md)
- `examples`: [Read rules](paths/examples.md)
- `mkdocs.yml`: [Read rules](paths/mkdocs.yml.md)
- `outlines/_version.py`: [Read rules](paths/outlines/_version.py.md)
- `outlines/base.py`: [Read rules](paths/outlines/base.py.md)
- `outlines/caching.py`: [Read rules](paths/outlines/caching.py.md)
- `outlines/fsm/guide.py`: [Read rules](paths/outlines/fsm/guide.py.md)
- `outlines/fsm/json_schema.py`: [Read rules](paths/outlines/fsm/json_schema.py.md)
- `outlines/fsm/parsing.py`: [Read rules](paths/outlines/fsm/parsing.py.md)
- `outlines/fsm/types.py`: [Read rules](paths/outlines/fsm/types.py.md)
- `outlines/generate/api.py`: [Read rules](paths/outlines/generate/api.py.md)
- `outlines/generate/generator.py`: [Read rules](paths/outlines/generate/generator.py.md)
- `outlines/models/llamacpp.py`: [Read rules](paths/outlines/models/llamacpp.py.md)
- `outlines/models/mlxlm.py`: [Read rules](paths/outlines/models/mlxlm.py.md)
- `outlines/models/openai.py`: [Read rules](paths/outlines/models/openai.py.md)
- `outlines/models/transformers.py`: [Read rules](paths/outlines/models/transformers.py.md)
- `outlines/models/transformers_vision.py`: [Read rules](paths/outlines/models/transformers_vision.py.md)
- `outlines/models/vllm.py`: [Read rules](paths/outlines/models/vllm.py.md)
- `outlines/processors/base_logits_processor.py`: [Read rules](paths/outlines/processors/base_logits_processor.py.md)
- `outlines/processors/structured.py`: [Read rules](paths/outlines/processors/structured.py.md)
- `outlines/prompts.py`: [Read rules](paths/outlines/prompts.py.md)
- `outlines/samplers.py`: [Read rules](paths/outlines/samplers.py.md)
- `outlines/types/email.py`: [Read rules](paths/outlines/types/email.py.md)
- `pyproject.toml`: [Read rules](paths/pyproject.toml.md)
- `requirements-doc.txt`: [Read rules](paths/requirements-doc.txt.md)
- `tests`: [Read rules](paths/tests.md)
- `tests/fsm/test_cfg_guide.py`: [Read rules](paths/tests/fsm/test_cfg_guide.py.md)
- `tests/fsm/test_guide.py`: [Read rules](paths/tests/fsm/test_guide.py.md)
- `tests/fsm/test_json_schema.py`: [Read rules](paths/tests/fsm/test_json_schema.py.md)
- `tests/fsm/test_parsing.py`: [Read rules](paths/tests/fsm/test_parsing.py.md)
- `tests/fsm/test_types.py`: [Read rules](paths/tests/fsm/test_types.py.md)
- `tests/generate/test_api.py`: [Read rules](paths/tests/generate/test_api.py.md)
- `tests/generate/test_generate.py`: [Read rules](paths/tests/generate/test_generate.py.md)
- `tests/generate/test_generator.py`: [Read rules](paths/tests/generate/test_generator.py.md)
- `tests/generate/test_integration_exllamav2.py`: [Read rules](paths/tests/generate/test_integration_exllamav2.py.md)
- `tests/generate/test_integration_llamacpp.py`: [Read rules](paths/tests/generate/test_integration_llamacpp.py.md)
- `tests/generate/test_integration_transformers.py`: [Read rules](paths/tests/generate/test_integration_transformers.py.md)
- `tests/generate/test_integration_vllm.py`: [Read rules](paths/tests/generate/test_integration_vllm.py.md)
- `tests/models/test_mlxlm.py`: [Read rules](paths/tests/models/test_mlxlm.py.md)
- `tests/models/test_openai.py`: [Read rules](paths/tests/models/test_openai.py.md)
- `tests/models/test_transformers.py`: [Read rules](paths/tests/models/test_transformers.py.md)
- `tests/test_base.py`: [Read rules](paths/tests/test_base.py.md)
- `tests/test_function.py`: [Read rules](paths/tests/test_function.py.md)
- `tests/test_grammars.py`: [Read rules](paths/tests/test_grammars.py.md)
- `tests/test_prompts.py`: [Read rules](paths/tests/test_prompts.py.md)
- `tests/test_types.py`: [Read rules](paths/tests/test_types.py.md)
