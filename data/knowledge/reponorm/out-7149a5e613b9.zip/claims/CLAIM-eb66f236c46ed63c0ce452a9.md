# Rule details

- **Rule:**
  ```text
  Tests that patch outlines.models.openai.generate_chat must assert that the OpenAIConfig passed reflects constructor values and that a per-call samples argument overrides config.n.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:**
  ```text
  When adding or modifying tests that patch outlines.models.openai.generate_chat.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_openai_call patches outlines.models.openai.generate_chat and asserts the OpenAIConfig passed reflects constructor values (max_tokens, temperature, n, stop), and that a per-call samples=3 overrides config.n.
```

- **Sources:**
  - `tests/models/test_openai.py`
