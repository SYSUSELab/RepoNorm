# Rule details

- **Rule:**
  ```text
  Backend integration tests for paged attention must be skipped unless flash-attn is available and must construct the model with cache_q4=True and paged=True, asserting the expected model type.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:** When adding or modifying a backend integration test that exercises paged attention.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_exl2_paged is skipped unless flash-attn is available and constructs the model with cache_q4=True and paged=True, asserting isinstance(model, ExLlamaV2Model).
```

- **Sources:**
  - `tests/generate/test_integration_exllamav2.py:325-331`
