# Rule details

- **Rule:** Read the Docs installs documentation dependencies from requirements-doc.txt.
- **Applies to:**
  - `requirements-doc.txt`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - requirements: requirements-doc.txt

```

- **Sources:**
  - `.readthedocs.yaml:10`
