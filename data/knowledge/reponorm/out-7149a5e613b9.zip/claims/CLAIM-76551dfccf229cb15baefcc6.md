# Rule details

- **Rule:** mypy enables the incomplete Unpack feature.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
enable_incomplete_feature = ["Unpack"]

```

- **Sources:**
  - `pyproject.toml:114`
