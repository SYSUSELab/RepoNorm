# Rule details

- **Rule:**
  ```text
  When modifying BeamSearchSampler.__call__, preserve the special case where all sequence_weights are zero restricts top-k selection to the first vocab_size logits, treating that state as the beginning of the search.
  ```
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:**
  ```text
  When changing BeamSearchSampler top-k selection or sequence_weights handling.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
BeamSearchSampler.__call__ preserves the special case where all sequence_weights are zero restricts top-k selection to the first vocab_size logits.
```

- **Sources:**
  - `outlines/samplers.py:286-347`
