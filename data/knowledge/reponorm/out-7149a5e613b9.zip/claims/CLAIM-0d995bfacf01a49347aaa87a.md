# Rule details

- **Rule:**
  ```text
  Prompt.__call__ must bind and apply defaults when a signature is present, rendering with bound argument names, and otherwise render directly from kwargs.
  ```
- **Applies to:**
  - `outlines/prompts.py`
- **Condition:**
  ```text
  Modifying Prompt.__call__ argument resolution or rendering.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Prompt.__call__ binds arguments via self.signature.bind and applies defaults when a signature is present, rendering with bound_arguments.arguments, and otherwise renders directly from kwargs, matching the rule.
```

- **Sources:**
  - `outlines/prompts.py:27-40`
