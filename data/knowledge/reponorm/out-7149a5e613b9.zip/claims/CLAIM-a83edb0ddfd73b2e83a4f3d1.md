# Rule details

- **Rule:** Tests for the vLLM generation API must assert that repeated calls with the same seed produce identical outputs and that a list of prompts yields a list of the same length.
- **Applies to:**
  - `tests/generate/test_integration_vllm.py`
- **Condition:** when adding or modifying vLLM generation API integration tests that check determinism or batch prompt handling
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_vllm_generation_api asserts repeated seed=1 calls produce identical strings and that a list of prompts returns a list of length 2.
```

- **Sources:**
  - `tests/generate/test_integration_vllm.py`
