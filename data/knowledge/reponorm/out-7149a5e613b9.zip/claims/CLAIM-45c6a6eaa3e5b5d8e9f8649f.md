# Rule details

- **Rule:** Prompt tests must define decorated templates using the schema filter on a model argument, showing prompt templates can render a model's schema.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** when adding or modifying prompt tests that exercise schema rendering filters
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/test_prompts.py defines decorated prompt templates using the schema filter on a model argument.
```

- **Sources:**
  - `tests/test_prompts.py`
