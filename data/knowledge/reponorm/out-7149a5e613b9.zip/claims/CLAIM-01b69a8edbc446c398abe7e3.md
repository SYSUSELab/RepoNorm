# Rule details

- **Rule:** model.stream yields str tokens for both a single string prompt and a list-of-strings prompt, documenting the streaming output contract across prompt types.
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When modifying model.stream behavior or the streaming output contract exercised by test_model_stream_prompt_types.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_model_stream_prompt_types calls model.stream with a single string prompt and with a list-of-strings prompt, asserting each yielded token is a str, documenting the streaming output contract across prompt types.
```

- **Sources:**
  - `tests/generate/test_integration_exllamav2.py:143-165`
