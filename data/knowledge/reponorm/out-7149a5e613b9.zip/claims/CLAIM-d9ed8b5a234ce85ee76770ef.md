# Rule details

- **Rule:**
  ```text
  When modifying PartialLALRParser.__init__ for deterministic parser_conf, preserve the tuple-keyed parse table rebuild, start/end state remapping, optional IntParseTable conversion with states_to_rulesets recording, and forced debug=True.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing PartialLALRParser initialization or deterministic parse-table construction.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The deterministic branch rebuilds the tuple-keyed parse table, remaps start/end states, converts to IntParseTable recording states_to_rulesets, and forces debug True.
```

- **Sources:**
  - `outlines/fsm/parsing.py:295-345`
