# Rule details

- **Rule:** OpenAI choice-call tests must assert that a malformed server response raises json.decoder.JSONDecodeError.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when modifying or extending OpenAI choice-call tests that simulate malformed server responses
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test asserts that a malformed non-JSON completion raises json.decoder.JSONDecodeError inside pytest.raises, matching the rule.
```

- **Sources:**
  - `tests/models/test_openai.py:81-85`
