# Rule details

- **Rule:**
  ```text
  When modifying outlines/caching.py, preserve the cache lifecycle: get_cache is lru_cache(1), defaults to HOMEDIR/.cache/outlines overridable via OUTLINES_CACHE_DIR, uses no eviction, and clears the cache when the outlines version changes.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:**
  ```text
  Modifying get_cache or the cache directory/version handling.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
get_cache is lru_cache(1), defaults to HOMEDIR/.cache/outlines overridable via OUTLINES_CACHE_DIR, uses eviction_policy='none', and clears the cache when the outlines version changes.
```

- **Sources:**
  - `outlines/caching.py:40-67`
