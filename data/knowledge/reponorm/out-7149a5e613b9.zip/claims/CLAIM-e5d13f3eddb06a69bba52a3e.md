# Rule details

- **Rule:**
  ```text
  pytest treats warnings as errors by default, with exceptions for pydantic deprecation warnings, FutureWarnings from transformers and huggingface_hub, all UserWarnings, and pyairports DeprecationWarnings.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
filterwarnings = [
    "error",
    "ignore::pydantic.warnings.PydanticDeprecatedSince20",
    "ignore::FutureWarning:transformers.*",
    "ignore::FutureWarning:huggingface_hub.*",
    "ignore::UserWarning",
    "ignore::DeprecationWarning:pyairports.*",
]

```

- **Sources:**
  - `pyproject.toml:103-110`
