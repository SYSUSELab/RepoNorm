# Rule details

- **Rule:** The project version is declared dynamically rather than statically in pyproject.toml.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
dynamic = ["version"]

```

- **Sources:**
  - `pyproject.toml:45`
