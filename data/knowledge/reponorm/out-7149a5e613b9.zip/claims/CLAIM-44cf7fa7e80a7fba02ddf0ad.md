# Rule details

- **Rule:** The workflow creates an ASV machine config named gh-runner with asv machine --machine gh-runner --yes.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      run: asv machine --machine gh-runner --yes

```

- **Sources:**
  - `.github/workflows/asv_benchmark_pr.yml:50`
