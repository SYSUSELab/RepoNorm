# Rule details

- **Rule:**
  ```text
  The vectorize helper with output signature '(s)' expands each scalar result into a repeated dimension, so vectorizing a function returning a scalar over ['one','two'] yields [['one','one','one'],['two','two','two']].
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  When modifying vectorize expansion behavior or the '(s)' output-signature handling exercised by test_vectorize_expand.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_vectorize_expand asserts that vectorize(test, '()->(s)') over ['one','two'] yields [['one','one','one'],['two','two','two']], matching the '(s)' expansion semantics.
```

- **Sources:**
  - `tests/test_base.py:234-240`
