# Rule details

- **Rule:**
  ```text
  The environment installs the local project in editable mode with its test extras via pip (-e ".[test]").
  ```
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
  - pip:
    - -e ".[test]"

```

- **Sources:**
  - `environment.yml:22-23`
