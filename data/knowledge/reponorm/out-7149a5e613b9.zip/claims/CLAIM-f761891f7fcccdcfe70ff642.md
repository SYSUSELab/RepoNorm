# Rule details

- **Rule:** Benchmark grammar fixtures must seed randomness with 42 and bench the json and arithmetic grammars from outlines.grammars.
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:** When adding or modifying CFG guide benchmark grammar fixtures.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
bench_cfg_guide.py sets random.seed(42) and benches the json and arithmetic grammars from outlines.grammars, conforming to the rule.
```

- **Sources:**
  - `benchmarks/bench_cfg_guide.py`
