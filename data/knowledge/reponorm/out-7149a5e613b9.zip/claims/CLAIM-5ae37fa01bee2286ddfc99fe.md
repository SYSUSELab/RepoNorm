# Rule details

- **Rule:**
  ```text
  The llama.cpp integration test module must define TEST_MODEL as a local GGUF path './llama-test-model/TinyMistral-248M-v2-Instruct.Q4_K_M.gguf', documenting the expected local model artifact for llamacpp integration tests.
  ```
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** when adding or modifying llama.cpp integration tests that reference the local test model artifact
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The llama.cpp integration test module defines the module-level constant TEST_MODEL as './llama-test-model/TinyMistral-248M-v2-Instruct.Q4_K_M.gguf', documenting the expected local GGUF artifact.
```

- **Sources:**
  - `tests/generate/test_integration_llamacpp.py`
