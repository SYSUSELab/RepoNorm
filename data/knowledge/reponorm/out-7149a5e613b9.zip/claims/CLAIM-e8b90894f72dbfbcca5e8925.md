# Rule details

- **Rule:**
  ```text
  When modifying the OpenAI call_api wrapper, preserve the decorator stack (error_handler and cache) and the responses.model_dump() return so caching and error normalization continue to operate on the serialized response dict rather than the raw SDK object.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When changing the OpenAI call_api wrapper's decorators or return value.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
call_api preserves the error_handler and cache decorator stack and returns responses.model_dump(), keeping caching and error normalization on the serialized response dict.
```

- **Sources:**
  - `outlines/models/openai.py:200-205`
