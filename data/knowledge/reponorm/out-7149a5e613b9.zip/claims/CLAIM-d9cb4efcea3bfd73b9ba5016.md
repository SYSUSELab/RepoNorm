# Rule details

- **Rule:** Integration tests that assert typed generation output must assert the returned value is an instance of the requested Python type (e.g. datetime.date, datetime.datetime, datetime.time) rather than comparing string representations.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
  - `tests/generate/test_integration_vllm.py`
- **Condition:** when adding or modifying an integration test that verifies generate.format output for a Python type
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The module contains typed-generation tests such as test_llamacpp_integer, test_llamacpp_float, test_llamacpp_bool, test_llamacpp_date, test_llamacpp_time, and test_llamacpp_datetime, each asserting isinstance of the returned value against the requested Python type.
```

- **Sources:**
  - `tests/generate/test_integration_llamacpp.py`

### Evidence 2 — current_observation

```text
Tests such as test_vllm_date, test_vllm_time, and test_vllm_datetime assert isinstance of the returned value against the requested Python type.
```

- **Sources:**
  - `tests/generate/test_integration_vllm.py`
