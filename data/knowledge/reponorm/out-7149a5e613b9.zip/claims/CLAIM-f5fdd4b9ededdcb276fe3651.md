# Rule details

- **Rule:** Custom sampler implementations must expose a samples attribute to satisfy the Sampler Protocol, so contributors adding or changing sampler classes must provide that attribute.
- **Applies to:**
  - `outlines/samplers.py`
- **Condition:** When defining or modifying a sampler class intended to satisfy the Sampler Protocol.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The `Sampler` Protocol class declares `samples: int` as a required attribute, satisfying the protocol contract that custom samplers expose a samples attribute.
```

- **Sources:**
  - `outlines/samplers.py:9-18`
