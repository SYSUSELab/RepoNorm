# Rule details

- **Rule:** Tests for schema generation must cover both annotated parameters and the error case where a parameter lacks a type annotation, which must raise ValueError.
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:**
  ```text
  When adding or modifying tests for get_schema_from_signature or schema generation.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_function_basic covers annotated scalar and list parameters, and test_function_no_type asserts ValueError for an unannotated parameter, covering both the annotated and missing-annotation error cases.
```

- **Sources:**
  - `tests/fsm/test_json_schema.py`
