# Rule details

- **Rule:**
  ```text
  When modifying disable_cache in outlines/caching.py, preserve its semantics: it only flips a global flag for the session; it does not delete existing cache entries and does not overwrite the cache with values produced during the disabled session.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:**
  ```text
  Modifying disable_cache or cache-disabled session behavior.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
disable_cache only flips the global _caching_enabled flag to False; it does not delete existing cache entries nor overwrite the cache with disabled-session values, preserving the documented semantics.
```

- **Sources:**
  - `outlines/caching.py:140-161`
