# Rule details

- **Rule:** When modifying the vLLM generate adapter, preserve the batch/sample-dependent return shape: a string for a single batch with a single sample, a list for one batch with several samples, a list of first samples for several batches with one sample, and a nested list otherwise.
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** When changing the vLLM generate adapter's batching or sampling logic.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
VLLM.generate returns a string for one batch/one sample, a list for one batch/several samples, a list of first samples for several batches/one sample, and a nested list otherwise.
```

- **Sources:**
  - `outlines/models/vllm.py:43-148`
