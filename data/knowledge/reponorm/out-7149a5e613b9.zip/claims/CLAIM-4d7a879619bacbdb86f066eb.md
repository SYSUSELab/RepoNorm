# Rule details

- **Rule:**
  ```text
  When modifying the OpenAI model module, preserve the centralized error-handling boundary: API calls are wrapped with an error_handler decorator intended to handle OpenAI API errors and missing API keys.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:** When changing API call wrapping or error handling in the OpenAI model module.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
error_handler is defined in outlines/models/openai.py as a decorator intended to handle OpenAI API errors and missing API keys, preserving the centralized error-handling boundary.
```

- **Sources:**
  - `outlines/models/openai.py:222-246`
