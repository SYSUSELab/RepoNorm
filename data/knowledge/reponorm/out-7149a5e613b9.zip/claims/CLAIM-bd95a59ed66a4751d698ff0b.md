# Rule details

- **Rule:**
  ```text
  vllm() must lazily import vllm.LLM inside the function, construct LLM(model_name, **vllm_model_params), and wrap it in VLLM, preserving lazy import and parameter pass-through.
  ```
- **Applies to:**
  - `outlines/models/vllm.py`
- **Condition:** When modifying vllm() or its model construction and parameter pass-through.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
vllm() imports LLM from vllm lazily inside the function, constructs LLM(model_name, **vllm_model_params), and wraps the result in VLLM, preserving lazy import and parameter pass-through.
```

- **Sources:**
  - `outlines/models/vllm.py:171-187`
