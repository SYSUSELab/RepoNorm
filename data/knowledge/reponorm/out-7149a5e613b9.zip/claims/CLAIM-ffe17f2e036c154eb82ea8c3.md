# Rule details

- **Rule:**
  ```text
  Test tokenizer helpers must expose inverse_vocabulary as a property computed by inverting self.vocabulary, establishing that test tokenizers provide a vocabulary mapping whose keys are tokens and values are ids.
  ```
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:** when adding or modifying test tokenizer helpers that provide a vocabulary mapping
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The MockTokenizer defines inverse_vocabulary as a property inverting self.vocabulary, whose keys are tokens and values are ids.
```

- **Sources:**
  - `tests/test_grammars.py`
