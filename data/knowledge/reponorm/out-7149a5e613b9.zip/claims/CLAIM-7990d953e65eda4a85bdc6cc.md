# Rule details

- **Rule:** The pre-commit configuration enables the debug-statements hook from pre-commit/pre-commit-hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
    -   id: debug-statements

```

- **Sources:**
  - `.pre-commit-config.yaml:6`
