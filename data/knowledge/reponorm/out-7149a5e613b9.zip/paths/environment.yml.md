# Rules for `environment.yml`

## Rule 077 — `environment.yml`

- **Rule:** The environment's dependencies include python==3.10.0.
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-772720d5dad762736235fec3.md)

## Rule 099 — `environment.yml`

- **Rule:**
  ```text
  The environment installs the local project in editable mode with its test extras via pip (-e ".[test]").
  ```
- **Applies to:**
  - `environment.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9daf0d7c8d36cb1b577e1058.md)
