# Rules for `tests/test_prompts.py`

## Rule 044 — `tests/test_prompts.py`

- **Rule:** Prompt tests must define decorated templates using the schema filter on a model argument, showing prompt templates can render a model's schema.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** when adding or modifying prompt tests that exercise schema rendering filters
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-45c6a6eaa3e5b5d8e9f8649f.md)

## Rule 074 — `tests/test_prompts.py`

- **Rule:**
  ```text
  The temp_prompt_file fixture writes base_template.txt, include.txt, and prompt.txt into a temp dir, exercising Jinja extends, block, include, and for-loop constructs in prompt templates.
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:**
  ```text
  When modifying the temp_prompt_file fixture or the Jinja template constructs it exercises.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-73d41bd750b3d3adbf645f90.md)

## Rule 120 — `tests/test_prompts.py`

- **Rule:** Prompt functions decorated with @outlines.prompt are ordinary Python functions whose docstring is a template using {{var}} placeholders, and default argument values are usable in the template.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When adding or modifying a prompt function test that exercises template rendering with default arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bf59d09e0b3499260c66a65c.md)

## Rule 122 — `tests/test_prompts.py`

- **Rule:** Prompt template tests must assert that a for-loop without whitespace control leaves a trailing newline, while closing with -%} strips the following newline, and the same -%} behavior applies to conditionals.
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** When adding or modifying a prompt template test that exercises Jinja whitespace control in loops or conditionals.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c6d76c8568acf5f60daca087.md)

## Rule 151 — `tests/test_prompts.py`

- **Rule:**
  ```text
  Prompt template tests must exercise functions with type annotations including nested generics (e.g. Dict[int, List[str]]) and multi-parameter signatures with defaults, so annotation rendering handles complex typing constructs.
  ```
- **Applies to:**
  - `tests/test_prompts.py`
- **Condition:** when adding or modifying prompt template tests that cover function signature rendering
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f661c93c400e6499935fd0e1.md)
