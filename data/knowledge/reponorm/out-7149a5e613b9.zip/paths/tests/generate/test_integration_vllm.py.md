# Rules for `tests/generate/test_integration_vllm.py`

## Rule 104 — `tests/generate/test_integration_vllm.py`

- **Rule:** Tests for the vLLM generation API must assert that repeated calls with the same seed produce identical outputs and that a list of prompts yields a list of the same length.
- **Applies to:**
  - `tests/generate/test_integration_vllm.py`
- **Condition:** when adding or modifying vLLM generation API integration tests that check determinism or batch prompt handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a83edb0ddfd73b2e83a4f3d1.md)

## Rule 132 — `tests/generate/test_integration_llamacpp.py`

- **Rule:** Integration tests that assert typed generation output must assert the returned value is an instance of the requested Python type (e.g. datetime.date, datetime.datetime, datetime.time) rather than comparing string representations.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
  - `tests/generate/test_integration_vllm.py`
- **Condition:** when adding or modifying an integration test that verifies generate.format output for a Python type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d9cb4efcea3bfd73b9ba5016.md)
