# Rules for `tests/generate/test_integration_exllamav2.py`

## Rule 001 — `tests/generate/test_integration_exllamav2.py`

- **Rule:** model.stream yields str tokens for both a single string prompt and a list-of-strings prompt, documenting the streaming output contract across prompt types.
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When modifying model.stream behavior or the streaming output contract exercised by test_model_stream_prompt_types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-01b69a8edbc446c398abe7e3.md)

## Rule 041 — `tests/generate/test_integration_exllamav2.py`

- **Rule:**
  ```text
  Backend integration tests for output reformatting must assert the exact regrouping behavior: a single string is returned unchanged, a one-element list is unwrapped to its element, and with num_samples=2 a flat list is regrouped into pairs.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:**
  ```text
  When adding or modifying a backend integration test that exercises reformat_output with varying sample counts.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-42d22cf411d2eb4f8878b8fb.md)

## Rule 139 — `tests/generate/test_integration_exllamav2.py`

- **Rule:**
  ```text
  Backend integration tests for paged attention must be skipped unless flash-attn is available and must construct the model with cache_q4=True and paged=True, asserting the expected model type.
  ```
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:** When adding or modifying a backend integration test that exercises paged attention.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e42f36e1fc353bd81dc746ac.md)

## Rule 147 — `tests/generate/test_integration_exllamav2.py`

- **Rule:** Backend integration tests for streaming generation must assert that iterating the generator yields only str tokens, establishing the streaming output type contract for that backend.
- **Applies to:**
  - `tests/generate/test_integration_exllamav2.py`
- **Condition:** When adding or modifying a backend integration test that iterates a streaming generation generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-efa06fb75827d50767294e8b.md)
