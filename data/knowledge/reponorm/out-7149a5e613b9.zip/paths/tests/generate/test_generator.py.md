# Rules for `tests/generate/test_generator.py`

## Rule 008 — `tests/generate/test_generator.py`

- **Rule:** Generator tests must use local test doubles (e.g. MockModel, MockFSM) for model and FSM dependencies rather than real providers, and must verify that SequenceGenerator.stream yields the generated sequence then raises StopIteration.
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:** when adding or modifying generator tests that exercise streaming or FSM behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-075cf22def3ff74b950256e7.md)

## Rule 055 — `tests/generate/test_generator.py`

- **Rule:**
  ```text
  Tests for bias_logits must assert that it sets logits at indices not listed in indices_to_mask to -math.inf while preserving listed indices, across single- and multi-row tensors.
  ```
- **Applies to:**
  - `tests/generate/test_generator.py`
- **Condition:**
  ```text
  when adding or modifying tests for bias_logits masking behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-53c7b86558d2fd1ecc18abe0.md)
