# Rules for `tests/generate/test_integration_transformers.py`

## Rule 026 — `tests/generate/test_integration_transformers.py`

- **Rule:** Tests for the transformers integration must assert that generate.format(model, bool) returns a non-empty bool, verifying format-constrained generation produces the requested Python type.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** when adding or modifying transformers integration tests that exercise format-constrained generation with a Python type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1f9b8a9f3dca3734b759c463.md)

## Rule 032 — `tests/generate/test_integration_transformers.py`

- **Rule:** Tests for the transformers JSON batch generation must assert that passing a list of prompts returns a list of BaseModel instances, one per prompt.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:** when adding or modifying transformers integration tests that exercise JSON batch generation with a list of prompts
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2f2439720aa7821bd18ba51b.md)

## Rule 134 — `tests/generate/test_integration_transformers.py`

- **Rule:** JSON generation with an integer enum returns a BaseModel whose enum-constrained field is an int restricted to the enum's integer values.
- **Applies to:**
  - `tests/generate/test_integration_transformers.py`
- **Condition:**
  ```text
  When modifying integer-enum JSON generation behavior exercised by test_transformers_json_int_enum.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d9eec211486b92f1b2134f84.md)
