# Rules for `tests/generate/test_integration_llamacpp.py`

## Rule 046 — `tests/generate/test_integration_llamacpp.py`

- **Rule:** Backend integration tests for text stop sequences must assert that the generated output contains no occurrence of the stop string, verifying stop-token enforcement.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:**
  ```text
  When adding or modifying a backend integration test that supplies a stop_at or stop string to generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-49d1d6f7868f08dbe63ef181.md)

## Rule 061 — `tests/generate/test_integration_llamacpp.py`

- **Rule:**
  ```text
  The llama.cpp integration test module must define TEST_MODEL as a local GGUF path './llama-test-model/TinyMistral-248M-v2-Instruct.Q4_K_M.gguf', documenting the expected local model artifact for llamacpp integration tests.
  ```
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** when adding or modifying llama.cpp integration tests that reference the local test model artifact
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5ae37fa01bee2286ddfc99fe.md)

## Rule 066 — `tests/generate/test_integration_llamacpp.py`

- **Rule:** Tests that exercise the llama.cpp backend must expect beam-search generation to raise NotImplementedError, because that backend does not support beam search.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
- **Condition:** when adding or modifying llama.cpp backend integration tests that exercise beam-search sampling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-66b36b4c404d1428291bee86.md)

## Rule 132 — `tests/generate/test_integration_llamacpp.py`

- **Rule:** Integration tests that assert typed generation output must assert the returned value is an instance of the requested Python type (e.g. datetime.date, datetime.datetime, datetime.time) rather than comparing string representations.
- **Applies to:**
  - `tests/generate/test_integration_llamacpp.py`
  - `tests/generate/test_integration_vllm.py`
- **Condition:** when adding or modifying an integration test that verifies generate.format output for a Python type
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d9cb4efcea3bfd73b9ba5016.md)
