# Rules for `tests/generate/test_generate.py`

## Rule 039 — `tests/generate/test_generate.py`

- **Rule:** Batch generation tests with regex constraints must assert that batch generation with multiple inputs maintains FSM order and that every output fully matches the regex pattern.
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:** When adding or modifying a batch generation test that exercises regex-constrained generation with multiple inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3e4fcc99605ef0604d15a489.md)

## Rule 062 — `tests/generate/test_generate.py`

- **Rule:**
  ```text
  The get_inputs helper selects prompts by fixture name and, for fixtures ending in '_vision', returns a dict with 'prompts' and 'media' keys, encoding the multimodal input convention used across generation tests.
  ```
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  When modifying the get_inputs helper or adding new generation-test fixtures that require multimodal inputs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5d1d00a06836a93685ea8969.md)

## Rule 080 — `tests/generate/test_generate.py`

- **Rule:**
  ```text
  The regex batch-stream test asserts that streaming generation for a batch of two sequences maintains per-sequence order: outputs[0] accumulates tokens[0] and outputs[1] accumulates tokens[1], and each accumulated output must fully match the regex pattern.
  ```
- **Applies to:**
  - `tests/generate/test_generate.py`
- **Condition:**
  ```text
  When modifying batch streaming generation behavior or per-sequence ordering exercised by test_generate_regex_batch_stream.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-794e6abef0c271dbaf5bec63.md)
