# Rules for `tests/test_grammars.py`

## Rule 045 — `tests/test_grammars.py`

- **Rule:**
  ```text
  Grammar tests must use a mock tokenizer whose decode maps token ids through inverse_vocabulary, asserting a one-to-one token-id-to-string mapping.
  ```
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:** when adding or modifying grammar tests that need token decoding
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-49080b147d59a59a000e060d.md)

## Rule 155 — `tests/test_grammars.py`

- **Rule:**
  ```text
  Test tokenizer helpers must expose inverse_vocabulary as a property computed by inverting self.vocabulary, establishing that test tokenizers provide a vocabulary mapping whose keys are tokens and values are ids.
  ```
- **Applies to:**
  - `tests/test_grammars.py`
- **Condition:** when adding or modifying test tokenizer helpers that provide a vocabulary mapping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ffe17f2e036c154eb82ea8c3.md)
