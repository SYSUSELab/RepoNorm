# Rules for `tests/models/test_openai.py`

## Rule 024 — `tests/models/test_openai.py`

- **Rule:** OpenAI JSON generation tests with a pydantic model must assert that a valid JSON completion is parsed into the model and a non-JSON completion raises ValidationError.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when modifying or extending OpenAI JSON generation tests that use a pydantic model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1ecd5c3d64ab4567048966ff.md)

## Rule 038 — `tests/models/test_openai.py`

- **Rule:** OpenAI model tests must cover both sync and async client paths, importing AsyncOpenAI alongside OpenAI and OpenAIConfig, and choice selection must be driven by the patched model response.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when adding or modifying OpenAI model tests or choice selection behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3d5ba0059c8d45ba45e52622.md)

## Rule 105 — `tests/models/test_openai.py`

- **Rule:**
  ```text
  module_patch must walk path components from longest to shortest, import the first importable module, patch the remaining attribute, and fall back to mock.patch(path) when no module is found.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:**
  ```text
  when modifying or extending module_patch in tests/models/test_openai.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a904d4b196d650f1de6f973a.md)

## Rule 125 — `tests/models/test_openai.py`

- **Rule:** OpenAI choice-call tests must assert that a malformed server response raises json.decoder.JSONDecodeError.
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:** when modifying or extending OpenAI choice-call tests that simulate malformed server responses
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cf8bdf0376aeb25beeb86611.md)

## Rule 145 — `tests/models/test_openai.py`

- **Rule:**
  ```text
  Tests that patch outlines.models.openai.generate_chat must assert that the OpenAIConfig passed reflects constructor values and that a per-call samples argument overrides config.n.
  ```
- **Applies to:**
  - `tests/models/test_openai.py`
- **Condition:**
  ```text
  When adding or modifying tests that patch outlines.models.openai.generate_chat.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eb66f236c46ed63c0ce452a9.md)
