# Rules for `tests/test_function.py`

## Rule 108 — `tests/test_function.py`

- **Rule:**
  ```text
  Tests for extract_function_from_file must assert that an AttributeError matching 'Could not find' is raised when the requested function name is absent from the file content.
  ```
- **Applies to:**
  - `tests/test_function.py`
- **Condition:**
  ```text
  when adding or modifying tests for extract_function_from_file error behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-abebd5069ce5f11f446e29b8.md)
