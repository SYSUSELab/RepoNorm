# Rules for `tests/test_base.py`

## Rule 012 — `tests/test_base.py`

- **Rule:**
  ```text
  The passthrough_args test helper must concatenate all positional string arguments and carry the docstring 'A passthrough function.', matching the docstring asserted by the vectorize tests.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  when adding or modifying the passthrough_args test helper used by vectorize tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0d6e80d887b925672550ad87.md)

## Rule 040 — `tests/test_base.py`

- **Rule:**
  ```text
  Tests for vectorize must assert that it accepts a signature string such as (m)->(m) or ()->() and applies the wrapped function elementwise over nested input arrays, preserving the array shape in the output.
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:** when adding or modifying tests for vectorize signature handling and elementwise application
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-42068b5ad77882a064a1381d.md)

## Rule 071 — `tests/test_base.py`

- **Rule:**
  ```text
  The vectorize helper with output signature '(s)' expands each scalar result into a repeated dimension, so vectorizing a function returning a scalar over ['one','two'] yields [['one','one','one'],['two','two','two']].
  ```
- **Applies to:**
  - `tests/test_base.py`
- **Condition:**
  ```text
  When modifying vectorize expansion behavior or the '(s)' output-signature handling exercised by test_vectorize_expand.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6f31a19ccf7f35ed27b48c13.md)
