# Rules for `tests/fsm/test_cfg_guide.py`

## Rule 053 — `tests/fsm/test_cfg_guide.py`

- **Rule:**
  ```text
  The session-scoped tokenizer fixture in the CFG guide tests must load the real 'google/byt5-small' tokenizer via AutoTokenizer.from_pretrained, so tests depending on it require network/model availability.
  ```
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** when adding or modifying the session-scoped tokenizer fixture in the CFG guide tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-51013755a48f9eb9abde35a3.md)

## Rule 138 — `tests/fsm/test_cfg_guide.py`

- **Rule:**
  ```text
  Guide tests must use Lark's interactive parser (parse_interactive + exhaust_lexer + feed_eof) to validate that each parametrized sample is a legal generation of its grammar, raising a descriptive Exception when the test data itself is invalid.
  ```
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** when adding or modifying CFG guide sample-validation tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df9a84487d96852ad9acf939.md)

## Rule 149 — `tests/fsm/test_cfg_guide.py`

- **Rule:** CFG guide next-token tests must advance the guide state through generated tokens and compare the sorted set of returned next tokens against the expected legal tokens, mapping None to the tokenizer eos token.
- **Applies to:**
  - `tests/fsm/test_cfg_guide.py`
- **Condition:** when modifying CFG guide next-token behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f61196d10c2a29e35f629d14.md)
