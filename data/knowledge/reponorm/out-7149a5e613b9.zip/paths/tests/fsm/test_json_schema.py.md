# Rules for `tests/fsm/test_json_schema.py`

## Rule 087 — `tests/fsm/test_json_schema.py`

- **Rule:** JSON schema enum tests must exercise non-string enum members, including callables, strings, and integers, to verify schema generation handles mixed-type enums.
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:** when modifying enum handling in schema generation or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-85a137e770a7583092dd3ea5.md)

## Rule 113 — `tests/fsm/test_json_schema.py`

- **Rule:**
  ```text
  Tests for schema-to-regex conversion must assert that build_regex_from_schema accepts a JSON schema string and returns a str, and must preserve declaration-order object properties with nested array item typing when converting function signatures to schemas.
  ```
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:** when modifying signature-to-schema conversion or schema-to-regex conversion behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b6447772413dfa1068bf5279.md)

## Rule 137 — `tests/fsm/test_json_schema.py`

- **Rule:** Tests for schema generation must cover both annotated parameters and the error case where a parameter lacks a type annotation, which must raise ValueError.
- **Applies to:**
  - `tests/fsm/test_json_schema.py`
- **Condition:**
  ```text
  When adding or modifying tests for get_schema_from_signature or schema generation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dee769faa48c7f5b57d62dee.md)
