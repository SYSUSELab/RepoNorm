# Rules for `tests/fsm/test_guide.py`

## Rule 017 — `tests/fsm/test_guide.py`

- **Rule:**
  ```text
  Tests for the FSM guide must assert that RegexGuide.from_regex reaches a final state and remains final on repeated tokens, that walk_fsm with full_match=True returns one accepted state per transition or an empty list when a transition is not accepted or the final state is not final, and that StopAtEOSGuide returns Generate with tokens None at start, Write with tokens [2] at final, transitions on token 2, stays at start on token 1, and reports is_final_state correctly.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
  - `tests/fsm/test_parsing.py`
- **Condition:**
  ```text
  when adding or modifying FSM guide tests that assert final-state persistence, walk_fsm acceptance semantics, or StopAtEOSGuide instruction and transition contracts
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-10d9b137b55a570b642d3182.md)

## Rule 067 — `tests/fsm/test_guide.py`

- **Rule:**
  ```text
  The MockTokenizer test helper must expose inverse_vocabulary as a property computed by reversing the vocabulary mapping, and decode must handle both nested and flat token id lists using that inverse mapping.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** when modifying or extending the MockTokenizer helper used by guide tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-67b05d83d9966976b0ac9770.md)

## Rule 084 — `tests/fsm/test_guide.py`

- **Rule:** Multi-byte regex guide tests must assert exact FSM transition maps, including EOS handling to state -1 and non-final state 0, for multi-byte character classes.
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** when modifying RegexGuide multi-byte transition behavior or its tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-806eee6131429f42a925072b.md)

## Rule 123 — `tests/fsm/test_guide.py`

- **Rule:**
  ```text
  RegexGuide.from_regex must raise ValueError whose message contains "The vocabulary" when the regex uses a character class outside the tokenizer vocabulary, because tests assert that error text.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:**
  ```text
  when changing vocabulary validation in RegexGuide.from_regex
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c810ffcf664333021c2621e4.md)

## Rule 130 — `tests/fsm/test_guide.py`

- **Rule:**
  ```text
  Tests for the CFG guide must assert the exact token-allowance state machine: the allowed token sets after each token and the point at which must_terminate_state/can_terminate_state become true.
  ```
- **Applies to:**
  - `tests/fsm/test_guide.py`
- **Condition:** When adding or modifying tests for CFGGuide token allowance and termination behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d1dd28ff38ce35a0e824fecb.md)
