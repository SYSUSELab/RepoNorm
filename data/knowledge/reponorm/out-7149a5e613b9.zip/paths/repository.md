# Rules for `repository root`

## Rule 002 — `**/__init__.py`

- **Rule:**
  ```text
  Flake8 ignores F401 and F403 in __init__.py files at any depth.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0217c6b71ab78373db83bf76.md)

## Rule 003 — `**/*.py`

- **Rule:**
  ```text
  The project declares a minimum supported Python version of 3.9 via requires-python = ">=3.9".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-039ea611fdaa8705400f7799.md)

## Rule 023 — `**/*.py`

- **Rule:** Flake8 ignores error codes E203, E231, E501, E741, W503, W504, C901, and E731.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1db9bf455975434177bef7c0.md)

## Rule 027 — `**/*.py`

- **Rule:**
  ```text
  mypy is configured with an override for the listed modules that sets ignore_missing_imports = true.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-20e6590ef707468f65bc038d.md)

## Rule 052 — `**/*.py`

- **Rule:** Flake8 enforces a maximum line length of 88 characters.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-50fb0f7e1d2e1a06e9e983f4.md)

## Rule 076 — `**/*.py`

- **Rule:** mypy enables the incomplete Unpack feature.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-76551dfccf229cb15baefcc6.md)

## Rule 081 — `**`

- **Rule:** The pre-commit configuration enables the debug-statements hook from pre-commit/pre-commit-hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7990d953e65eda4a85bdc6cc.md)

## Rule 093 — `**/*.py`

- **Rule:** Coverage measurement enables branch coverage.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-90e6f276b16bd31b4460049d.md)

## Rule 140 — `**/*.py`

- **Rule:**
  ```text
  pytest treats warnings as errors by default, with exceptions for pydantic deprecation warnings, FutureWarnings from transformers and huggingface_hub, all UserWarnings, and pyairports DeprecationWarnings.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e5d13f3eddb06a69bba52a3e.md)
