# Rules for `benchmarks/bench_json_schema.py`

## Rule 033 — `benchmarks/bench_json_schema.py`

- **Rule:** Benchmark classes must parametrize over the full set of available schema/grammar keys (e.g., schemas.keys()) so every named case is exercised.
- **Applies to:**
  - `benchmarks/bench_json_schema.py`
- **Condition:** When adding or modifying a benchmark class that selects among named schemas or grammars.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-340a37246f1b42e32c0fea1a.md)

## Rule 049 — `benchmarks/bench_cfg_guide.py`

- **Rule:**
  ```text
  Benchmark timing methods must disable caching (via cache_disabled) so measured durations reflect uncached construction/execution rather than cached results.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark timing method that constructs a guide or FSM from a schema/regex/grammar.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4ef54f6ec8eea0be236fa396.md)
