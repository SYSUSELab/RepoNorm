# Rules for `benchmarks/bench_cfg_guide.py`

## Rule 049 — `benchmarks/bench_cfg_guide.py`

- **Rule:**
  ```text
  Benchmark timing methods must disable caching (via cache_disabled) so measured durations reflect uncached construction/execution rather than cached results.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark timing method that constructs a guide or FSM from a schema/regex/grammar.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4ef54f6ec8eea0be236fa396.md)

## Rule 152 — `benchmarks/bench_cfg_guide.py`

- **Rule:** Benchmark grammar fixtures must seed randomness with 42 and bench the json and arithmetic grammars from outlines.grammars.
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
- **Condition:** When adding or modifying CFG guide benchmark grammar fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f761891f7fcccdcfe70ff642.md)
