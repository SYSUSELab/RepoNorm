# Rules for `benchmarks/bench_regex_guide.py`

## Rule 049 — `benchmarks/bench_cfg_guide.py`

- **Rule:**
  ```text
  Benchmark timing methods must disable caching (via cache_disabled) so measured durations reflect uncached construction/execution rather than cached results.
  ```
- **Applies to:**
  - `benchmarks/bench_cfg_guide.py`
  - `benchmarks/bench_json_schema.py`
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying a benchmark timing method that constructs a guide or FSM from a schema/regex/grammar.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4ef54f6ec8eea0be236fa396.md)

## Rule 128 — `benchmarks/bench_regex_guide.py`

- **Rule:** Benchmark input fixtures must use a fixed, named set of regex samples (email, phone, date, time, ip, url, ssn, etc.) as benchmark inputs.
- **Applies to:**
  - `benchmarks/bench_regex_guide.py`
- **Condition:** When adding or modifying regex guide benchmark input fixtures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-d1abaeff1aef91ca51a1e6d0.md)
