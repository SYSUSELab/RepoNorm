# Rules for `examples`

## Rule 109 — `examples/**`

- **Rule:** mypy excludes the examples directory from type checking.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ac7969e2f2e96fbd7661acac.md)
