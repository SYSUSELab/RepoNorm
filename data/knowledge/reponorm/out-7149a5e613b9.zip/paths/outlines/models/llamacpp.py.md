# Rules for `outlines/models/llamacpp.py`

## Rule 064 — `outlines/models/llamacpp.py`

- **Rule:**
  ```text
  LlamaCppTokenizer.__getstate__ must return a tuple of vocabulary, eos_token_id, eos_token, pad_token_id, and sorted special_tokens to provide a stable representation for outlines.caching.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  When modifying LlamaCppTokenizer.__getstate__ or the cache-state tuple it returns.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5f22e155a5146f1d6c44af8d.md)

## Rule 065 — `outlines/models/llamacpp.py`

- **Rule:**
  ```text
  When modifying LlamaCppTokenizer pickling support, preserve the unsupported status: __setstate__ raises NotImplementedError("Cannot load a pickled llamacpp tokenizer").
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:** When changing LlamaCppTokenizer serialization or unpickling behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6189e7d35b191cec5d01e65d.md)

## Rule 078 — `outlines/models/llamacpp.py`

- **Rule:**
  ```text
  When modifying LlamaCpp.prepare_generation_parameters, preserve the translation contract: subtract one from max_tokens because llama-cpp-python generates max_tokens + 1 tokens, raise NotImplementedError for beam search and multiple samples, disable streaming, and append the structure logits processor to a LogitsProcessorList.
  ```
- **Applies to:**
  - `outlines/models/llamacpp.py`
- **Condition:**
  ```text
  When changing parameter translation, sampling restrictions, or logits processor wiring in LlamaCpp.prepare_generation_parameters.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-78fd7b623d6a3d772f685f1d.md)
