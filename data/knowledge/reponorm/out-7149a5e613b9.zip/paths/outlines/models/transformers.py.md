# Rules for `outlines/models/transformers.py`

## Rule 025 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  _decode_generation must dispatch on tensor rank: 1D returns a single decoded string, 2D returns batch-decoded strings, 3D returns a list of per-sample decodes, and any other rank raises TypeError.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying _decode_generation or its rank-based dispatch
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1f8ddf406d0107f6e5bd8881.md)

## Rule 030 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  _get_generation_kwargs must map GenerationParameters/SamplingParameters into a transformers GenerationConfig with max_new_tokens defaulting to 2**30 when None, do_sample set only when sampler=='multinomial', num_beams equal to num_samples for beam_search, and seed triggering a global set_seed.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying _get_generation_kwargs or the GenerationParameters/SamplingParameters to GenerationConfig mapping
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2d081b00654e854cf1f0e503.md)

## Rule 069 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  When modifying TransformerTokenizer.decode, preserve the contract that token_ids are batch-decoded with skip_special_tokens=True, so special tokens are stripped from returned text.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** When changing decoding behavior or special-token handling in TransformerTokenizer.decode.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6c1d4309413196812a549ab9.md)

## Rule 131 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  Transformers.generate must keep the single-string path: encode one prompt as a 2D batch, move input_ids and attention_mask to the model device, drop attention_mask when the model forward signature does not accept it, squeeze the batch dimension for single-string prompts, and decode the generated ids.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:** when modifying Transformers.generate or its single-string prompt handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d8b3a017f5b0f883b480e51c.md)

## Rule 154 — `outlines/models/transformers.py`

- **Rule:**
  ```text
  Transformers.__call__ must return next_token_logits = logits[..., -1, :] together with the kv cache so callers receive only the last-position logits per sequence.
  ```
- **Applies to:**
  - `outlines/models/transformers.py`
- **Condition:**
  ```text
  when modifying Transformers.__call__ or its returned logits shape
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fe89ed93044c9256246d40a0.md)
