# Rules for `outlines/models/mlxlm.py`

## Rule 006 — `outlines/models/mlxlm.py`

- **Rule:**
  ```text
  MLXLM must expose a _tokenizer attribute documented as an HF Tokenizer so MLX models reuse HuggingFace tokenizer semantics.
  ```
- **Applies to:**
  - `outlines/models/mlxlm.py`
- **Condition:** When modifying MLXLM or its tokenizer attribute.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-05de81971c38b8dc31fb7331.md)
