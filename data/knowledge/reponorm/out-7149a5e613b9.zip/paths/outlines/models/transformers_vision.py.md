# Rules for `outlines/models/transformers_vision.py`

## Rule 007 — `outlines/models/transformers_vision.py`

- **Rule:**
  ```text
  When modifying transformers_vision in outlines/models/transformers_vision.py, preserve the defaults: processor padding defaults to the left side, pad token defaults to [PAD], and when a device is provided it overrides the device_map entry in model_kwargs.
  ```
- **Applies to:**
  - `outlines/models/transformers_vision.py`
- **Condition:**
  ```text
  Modifying transformers_vision or its processor/model_kwargs defaults.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-06dd99e727f53e7eec176322.md)

## Rule 031 — `outlines/models/transformers_vision.py`

- **Rule:** TransformersVisionModel.stream must raise NotImplementedError; streaming is not supported for the transformers vision model.
- **Applies to:**
  - `outlines/models/transformers_vision.py`
- **Condition:** when modifying TransformersVisionModel.stream or adding streaming support to the vision model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2eead148f69b34596f1f564c.md)
