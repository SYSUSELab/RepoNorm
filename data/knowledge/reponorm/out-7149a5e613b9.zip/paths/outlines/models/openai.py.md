# Rules for `outlines/models/openai.py`

## Rule 019 — `outlines/models/openai.py`

- **Rule:**
  ```text
  When modifying OpenAI.__init__, preserve the per-instance cumulative token accounting contract: prompt_tokens and completion_tokens counters are initialized and documented as summed over all requests made with the model instance.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When changing token counter initialization or accounting semantics in OpenAI.__init__.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-12512ce7fe051d199514ceaf.md)

## Rule 048 — `outlines/models/openai.py`

- **Rule:**
  ```text
  When modifying the OpenAI model module, preserve the centralized error-handling boundary: API calls are wrapped with an error_handler decorator intended to handle OpenAI API errors and missing API keys.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:** When changing API call wrapping or error handling in the OpenAI model module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4d7a879619bacbdb86f066eb.md)

## Rule 124 — `outlines/models/openai.py`

- **Rule:**
  ```text
  When a config is supplied to azure_openai, the deployment_name must replace the configured model; when no config is supplied, the constructed OpenAIConfig must use model=deployment_name.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  Modifying azure_openai's config handling or model resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cf85f7252d68a3a30322c266.md)

## Rule 142 — `outlines/models/openai.py`

- **Rule:**
  ```text
  When modifying the OpenAI call_api wrapper, preserve the decorator stack (error_handler and cache) and the responses.model_dump() return so caching and error normalization continue to operate on the serialized response dict rather than the raw SDK object.
  ```
- **Applies to:**
  - `outlines/models/openai.py`
- **Condition:**
  ```text
  When changing the OpenAI call_api wrapper's decorators or return value.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e8b90894f72dbfbcca5e8925.md)
