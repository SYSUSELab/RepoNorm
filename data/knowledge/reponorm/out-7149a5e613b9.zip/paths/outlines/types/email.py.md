# Rules for `outlines/types/email.py`

## Rule 102 — `outlines/types/email.py`

- **Rule:**
  ```text
  When modifying the email type, preserve Email as an annotated str whose JSON schema uses the RFC-style EMAIL_REGEX pattern, so email fields are validated by regex pattern in generated schemas.
  ```
- **Applies to:**
  - `outlines/types/email.py`
- **Condition:** Modifying the Email type in outlines/types/email.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a3db302d35d0c7b2f7483710.md)
