# Rules for `outlines/caching.py`

## Rule 094 — `outlines/caching.py`

- **Rule:**
  ```text
  When modifying disable_cache in outlines/caching.py, preserve its semantics: it only flips a global flag for the session; it does not delete existing cache entries and does not overwrite the cache with values produced during the disabled session.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:**
  ```text
  Modifying disable_cache or cache-disabled session behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-93e7fc6c06d1dec32fc1d1f7.md)

## Rule 141 — `outlines/caching.py`

- **Rule:**
  ```text
  When modifying outlines/caching.py, preserve the cache lifecycle: get_cache is lru_cache(1), defaults to HOMEDIR/.cache/outlines overridable via OUTLINES_CACHE_DIR, uses no eviction, and clears the cache when the outlines version changes.
  ```
- **Applies to:**
  - `outlines/caching.py`
- **Condition:**
  ```text
  Modifying get_cache or the cache directory/version handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e6be0cde0cb3b9eddb3f2edc.md)
