# Rules for `outlines/_version.py`

## Rule 100 — `outlines/_version.py`

- **Rule:**
  ```text
  Coverage measurement omits outlines/_version.py and tests/* from coverage reporting.
  ```
- **Applies to:**
  - `outlines/_version.py`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9e6a0c06a8d05cf054847eae.md)

## Rule 136 — `outlines/_version.py`

- **Rule:**
  ```text
  setuptools_scm writes the generated version file to outlines/_version.py.
  ```
- **Applies to:**
  - `outlines/_version.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-dd443f130cfa330543778501.md)
