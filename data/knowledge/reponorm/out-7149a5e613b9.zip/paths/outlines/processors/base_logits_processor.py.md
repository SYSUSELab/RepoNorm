# Rules for `outlines/processors/base_logits_processor.py`

## Rule 054 — `outlines/processors/base_logits_processor.py`

- **Rule:** MLX array detection must remain optional: if mlx.core cannot be imported the helper returns false rather than raising, so MLX stays a soft dependency for logits processing.
- **Applies to:**
  - `outlines/processors/base_logits_processor.py`
- **Condition:**
  ```text
  when modifying is_mlx_array_type or MLX detection in logits processing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-51e4f3a1fb7374ca4d145a64.md)
