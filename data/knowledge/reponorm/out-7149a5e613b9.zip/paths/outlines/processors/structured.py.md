# Rules for `outlines/processors/structured.py`

## Rule 015 — `outlines/processors/structured.py`

- **Rule:** JSONLogitsProcessor must bias generation based on a JSON schema through RegexGuide inheritance, so contributors changing JSON schema biasing must preserve the RegexLogitsProcessor subclass relationship.
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:** When modifying JSONLogitsProcessor or the JSON schema biasing path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0e7f5595237558f9f3d27558.md)

## Rule 082 — `outlines/processors/structured.py`

- **Rule:**
  ```text
  When modifying GuideLogitsProcessor.process_logits, preserve the caching and masking contract: guide states are cached keyed by hash of generated token tuples, _seq_start_idx is initialized from the first input length, and logits are masked by setting disallowed token positions to -inf across the batch.
  ```
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:**
  ```text
  When changing guide state caching, sequence start indexing, or logits masking in GuideLogitsProcessor.process_logits.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7e418e25d9889202316e847b.md)

## Rule 112 — `outlines/processors/structured.py`

- **Rule:**
  ```text
  The structured processor module must import build_regex_from_schema from outlines_core.fsm.json_schema and convert_json_schema_to_str from outlines.fsm.json_schema, preserving the schema-to-regex dependency boundary.
  ```
- **Applies to:**
  - `outlines/processors/structured.py`
- **Condition:** when modifying outlines/processors/structured.py or its schema-to-regex imports
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b5e2b00a99234c32cc938e56.md)
