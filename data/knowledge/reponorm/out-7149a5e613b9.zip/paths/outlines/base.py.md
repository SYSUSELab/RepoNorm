# Rules for `outlines/base.py`

## Rule 150 — `outlines/base.py`

- **Rule:** When modifying the vectorize helper, preserve the behavioral difference that wrapped coroutines are executed concurrently while synchronous calls run in a loop like NumPy's vectorize.
- **Applies to:**
  - `outlines/base.py`
- **Condition:** Changing the vectorize helper's execution strategy for wrapped functions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f65b97a4ac24b15b45c9f958.md)
