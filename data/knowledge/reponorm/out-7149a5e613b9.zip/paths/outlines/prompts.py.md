# Rules for `outlines/prompts.py`

## Rule 013 — `outlines/prompts.py`

- **Rule:**
  ```text
  Prompt.__call__ must bind and apply defaults when a signature is present, rendering with bound argument names, and otherwise render directly from kwargs.
  ```
- **Applies to:**
  - `outlines/prompts.py`
- **Condition:**
  ```text
  Modifying Prompt.__call__ argument resolution or rendering.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0d995bfacf01a49347aaa87a.md)

## Rule 089 — `outlines/prompts.py`

- **Rule:**
  ```text
  Prompt must remain a dataclass carrying a jinja2.Template and an Optional[inspect.Signature], returned instead of a plain function so the template defined in prompt functions stays accessible.
  ```
- **Applies to:**
  - `outlines/prompts.py`
- **Condition:** When changing how prompt functions return or expose their template and signature.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-87828337fe0b3ae7905891cf.md)

## Rule 092 — `outlines/prompts.py`

- **Rule:**
  ```text
  get_fn_name must raise TypeError for non-callables and fall back to type(fn).__name__ when the callable lacks __name__, supporting callable objects in the name filter.
  ```
- **Applies to:**
  - `outlines/prompts.py`
- **Condition:**
  ```text
  Modifying get_fn_name callable name resolution.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-904da96df0701609312fa1d7.md)
