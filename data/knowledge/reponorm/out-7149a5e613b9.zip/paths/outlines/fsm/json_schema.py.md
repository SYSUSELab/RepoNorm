# Rules for `outlines/fsm/json_schema.py`

## Rule 005 — `outlines/fsm/json_schema.py`

- **Rule:**
  ```text
  When modifying outlines/fsm/json_schema.py, preserve its role of building pydantic models dynamically from JSON schema and emitting warnings for unsupported constructs, as evidenced by its imports of inspect, json, warnings, Enum, typing Callable/Type/Union, and pydantic BaseModel/create_model.
  ```
- **Applies to:**
  - `outlines/fsm/json_schema.py`
- **Condition:**
  ```text
  Modifying outlines/fsm/json_schema.py or its schema-to-model conversion behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-046359c935de2335da0a9aff.md)
