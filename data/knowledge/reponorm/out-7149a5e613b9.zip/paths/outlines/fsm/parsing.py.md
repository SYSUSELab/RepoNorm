# Rules for `outlines/fsm/parsing.py`

## Rule 011 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying the CFG parser construction in outlines/fsm/parsing.py, keep options['regex'] forced to True and the parser asserted as 'lalr'; do not allow callers to override these, and continue popping 'deterministic' and 'use_value_stack' as custom options rather than passing them to Lark.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  Modifying PartialLark.__init__ or the options handling for the CFG parser.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c6106bad8de15771a447907.md)

## Rule 058 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  to_tuple must canonicalize values by sorting elements by str and memoizing the mapping in old_to_new, so equivalent sets produce stable tuple ordering.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying to_tuple or the canonicalization of parser values.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-586bd17847a375eb6f026ae5.md)

## Rule 063 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialParsingFrontend in outlines/fsm/parsing.py, do not reintroduce the abandoned _state_transition_map design built from parse_table.states and a contextual lexer; the commented-out code and TODO document it as a known performance concern.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** Modifying PartialParsingFrontend or considering a state-transition-map optimization.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5ee9751b49f8c88cb28ba0cb.md)

## Rule 068 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialTokensInfo, preserve the dataclass fields fsm_state_seq, is_not_finished, terminals_and_info, and final_terminals_and_info so in-progress terminals remain distinguished from final terminals for partial-token parsing.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing PartialTokensInfo fields or partial-token terminal tracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6a5079bb6276538675fdd24f.md)

## Rule 073 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialParserState.__copy__ in outlines/fsm/parsing.py, preserve the copy semantics: parse_conf, lexer, and state_stack are copied, value_stack is deepcopied, and use_value_stack is preserved.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  Modifying PartialParserState.__copy__ or parser state copying behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-724ba491ba650518c20f57d5.md)

## Rule 079 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  PartialLark._build_parser must preserve the inlined lark _construct_parsing_frontend type assertions and the side effects that mutate parser_conf.parser_type and lexer_conf.lexer_type, so contributors changing parser/lexer options keep these invariants intact.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When modifying PartialLark._build_parser or the parser/lexer option construction path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7917386123b7ddfc8d88c862.md)

## Rule 106 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialParserConf, preserve the __serialize_fields__ declaration including rules, start, parser_type, deterministic, and use_value_stack so serialization preserves exactly those fields.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing PartialParserConf serialization fields or adding/removing configuration attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aa7a6f38134aba80c2574094.md)

## Rule 133 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialLALRParser.__init__ for deterministic parser_conf, preserve the tuple-keyed parse table rebuild, start/end state remapping, optional IntParseTable conversion with states_to_rulesets recording, and forced debug=True.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:** When changing PartialLALRParser initialization or deterministic parse-table construction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d9ed8b5a234ce85ee76770ef.md)

## Rule 153 — `outlines/fsm/parsing.py`

- **Rule:**
  ```text
  When modifying PartialParser.parse_from_state, preserve the contract that lexer tokens are fed into the parser state, EOF is fed only when is_end is true and the last token is not partial, UnexpectedInput is re-raised with an attached InteractiveParser, and the state stack dump is printed only when self.debug is set.
  ```
- **Applies to:**
  - `outlines/fsm/parsing.py`
- **Condition:**
  ```text
  When changing token feeding, EOF handling, or exception behavior in PartialParser.parse_from_state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f80c805b753d5332d5c0793f.md)
