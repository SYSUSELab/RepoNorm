# Rules for `outlines/fsm/types.py`

## Rule 098 — `outlines/fsm/types.py`

- **Rule:**
  ```text
  When modifying python_types_to_regex, preserve the supported-type mapping contract: Annotated custom types use json_schema['pattern'], EnumMeta uses alternation of member names, and float, int, bool, date, time, and datetime are supported; any other Python type raises NotImplementedError directing users to open an issue.
  ```
- **Applies to:**
  - `outlines/fsm/types.py`
- **Condition:**
  ```text
  When changing supported type handling or the fallback error in python_types_to_regex.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9cf21204f50c02a6ea75d613.md)
