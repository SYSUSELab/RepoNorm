# Rules for `outlines/fsm/guide.py`

## Rule 029 — `outlines/fsm/guide.py`

- **Rule:**
  ```text
  When modifying StopAtEOSGuide.is_final_state, preserve the invariant that it compares the given state to the single stored final_state, so the guide model assumes exactly one final state per guide.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  When changing final-state comparison or guide final-state storage in StopAtEOSGuide.is_final_state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-238786309a1b70b2b8f2e02d.md)

## Rule 083 — `outlines/fsm/guide.py`

- **Rule:** When modifying StopAtEOSGuide.copy, preserve the behavior of returning self rather than a new object, so guide instances remain immutable/shareable and callers must not rely on copy producing independent mutable state.
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:** When changing guide copy behavior or adding mutable state to guides.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7e684f4ddf909a2bc464d225.md)

## Rule 146 — `outlines/fsm/guide.py`

- **Rule:**
  ```text
  cached_create_states_mapping must delegate directly to uncached_create_states_mapping with no caching applied, remaining a no-op placeholder.
  ```
- **Applies to:**
  - `outlines/fsm/guide.py`
- **Condition:**
  ```text
  Modifying cached_create_states_mapping or adding caching to it.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-eb7c0b8c5fb29286c2f60111.md)
