# Rules for `outlines/generate/generator.py`

## Rule 101 — `outlines/generate/generator.py`

- **Rule:**
  ```text
  reorder_fsm_states must index fsm_states by each element of the ancestors tensor, so ancestors must contain valid integer indices into fsm_states and the output order follows ancestors order.
  ```
- **Applies to:**
  - `outlines/generate/generator.py`
- **Condition:**
  ```text
  When modifying reorder_fsm_states or the ancestors indexing it performs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a3189b6aac084d56b6231281.md)

## Rule 121 — `outlines/generate/generator.py`

- **Rule:**
  ```text
  is_generation_finished must treat a batch as finished only when every sequence's FSM is in a final state; the known batch-level completion limitation is documented and must not be silently changed without addressing the docstring.
  ```
- **Applies to:**
  - `outlines/generate/generator.py`
- **Condition:**
  ```text
  when modifying is_generation_finished or batch completion semantics
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c66707855fd1c82316952fef.md)
