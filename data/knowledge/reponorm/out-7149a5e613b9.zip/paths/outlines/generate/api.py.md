# Rules for `outlines/generate/api.py`

## Rule 059 — `outlines/generate/api.py`

- **Rule:**
  ```text
  SequenceGeneratorAdapter.__call__ must accept a prompt or list of prompts plus optional max_tokens, stop_at, seed, and model-specific params, prepare generation parameters, call model.generate with a copy of the logits processor, and format completions.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:**
  ```text
  When modifying SequenceGeneratorAdapter.__call__ or the generation call path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5a4ce415df36b1dd893b6b62.md)

## Rule 090 — `outlines/generate/api.py`

- **Rule:**
  ```text
  The token_generator must reshape outputs by batch_size and num_samples: yield a scalar string when both are 1, a list when batch_size is 1, a list of first samples when num_samples is 1, and a nested list otherwise; it must also track is_stop_at_reached per sequence and strip stop sequences before formatting.
  ```
- **Applies to:**
  - `outlines/generate/api.py`
- **Condition:**
  ```text
  when modifying SequenceGenerator.stream.token_generator or its output shaping and stop-sequence handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8a944f34f5588b3fc7aa00fb.md)
