# Rules for `.github/workflows/publish_documentation.yml`

## Rule 009 — `.github/workflows/publish_documentation.yml`

- **Rule:**
  ```text
  The workflow caches the .cache path keyed by mkdocs-material-<cache_id> with restore key mkdocs-material-.
  ```
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-090c11f09d1624b989c2d091.md)

## Rule 086 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow installs documentation dependencies from requirements-doc.txt and builds the docs with mkdocs build.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-84ef44a68063283abce15fd8.md)

## Rule 103 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow sets up Python version 3.x.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a6d17084e8da6b09908719ae.md)

## Rule 115 — `.github/workflows/publish_documentation.yml`

- **Rule:** The workflow checks out the repository with fetch-depth 0.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b6cfc2f175aa587be77456f5.md)

## Rule 126 — `.github/workflows/publish_documentation.yml`

- **Rule:** When the event is a release, the workflow deploys the tag as latest using mike deploy --push --update-aliases and sets latest as the default with mike set-default --push.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'release'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d042b02a17283daf962b7eb6.md)

## Rule 129 — `.github/workflows/publish_documentation.yml`

- **Rule:** When the event is a push, the workflow deploys the branch as unstable using mike deploy --push --update-aliases.
- **Applies to:**
  - `.github/workflows/publish_documentation.yml`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d1c651a8f09a1222f4e32fa2.md)
