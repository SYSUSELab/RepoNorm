# Rules for `.github/workflows/release_docker.yml`

## Rule 020 — `.github/workflows/release_docker.yml`

- **Rule:**
  ```text
  The workflow builds and pushes a Docker image tagged outlinesdev/outlines:latest and outlinesdev/outlines:<release tag or manual release_tag input>, with build arg BUILDKIT_CONTEXT_KEEP_GIT_DIR=true.
  ```
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-125feb7e0c27e091795e6082.md)

## Rule 060 — `.github/workflows/release_docker.yml`

- **Rule:** The workflow cleans the docker cache by running docker system prune --all --force.
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5a7a0ee00b49a4088266b242.md)

## Rule 091 — `.github/workflows/release_docker.yml`

- **Rule:**
  ```text
  The workflow logs in to Docker Hub using the DOCKERHUB_USERNAME and DOCKERHUB_TOKEN secrets.
  ```
- **Applies to:**
  - `.github/workflows/release_docker.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8f3ac65f8c321167a4227915.md)
