# Rules for `.github/workflows/build_documentation.yml`

## Rule 095 — `.github/workflows/build_documentation.yml`

- **Rule:** The documentation build job runs on ubuntu-latest and sets up Python 3.10.
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9734669421260a05413f3d60.md)

## Rule 096 — `.github/workflows/build_documentation.yml`

- **Rule:**
  ```text
  The documentation build step installs dependencies from requirements-doc.txt and runs mkdocs build, with GOOGLE_ANALYTICS_KEY supplied from the GOOGLE_ANALYTICS_KEY secret.
  ```
- **Applies to:**
  - `.github/workflows/build_documentation.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-99a4e82cf83080b6825e1482.md)
