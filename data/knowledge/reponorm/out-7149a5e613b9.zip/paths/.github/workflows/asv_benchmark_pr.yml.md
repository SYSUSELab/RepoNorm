# Rules for `.github/workflows/asv_benchmark_pr.yml`

## Rule 043 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow creates an ASV machine config named gh-runner with asv machine --machine gh-runner --yes.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-44cf7fa7e80a7fba02ddf0ad.md)

## Rule 111 — `.github/workflows/asv_benchmark_pr.yml`

- **Rule:** The workflow installs asv, virtualenv, and lf-asv-formatter via pip.
- **Applies to:**
  - `.github/workflows/asv_benchmark_pr.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b3a8f2fd1dc6c566eeda5116.md)
