# Rules for `pyproject.toml`

## Rule 014 — `pyproject.toml`

- **Rule:** The project version is declared dynamically rather than statically in pyproject.toml.
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0de415e50e140efa1388df9c.md)
