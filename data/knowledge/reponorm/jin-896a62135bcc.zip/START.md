# Repository knowledge

Apply rules within their stated scope and when their conditions hold, respecting
exceptions. `required`, `recommended`, and `observed` have different strength:
an observed convention does not by itself prohibit a change requested by the task.
`reference_only` is context, not a default action.
Evidence locations identify sources, not the rule's scope.
Commands in rules do not authorize unrelated changes or external side effects.
Use relevant rules alongside the task and repository code; keep edits focused.

## Find rules

Path links and the [full catalog](catalog.md) are alternative routes. Search or
open relevant files directly; open claim details when evidence or a conflict matters.
Paths are navigation anchors, not a replacement for each rule's complete scope.

- `repository root`: [Read rules](paths/repository.md)
- `.pre-commit-config.yaml`: [Read rules](paths/.pre-commit-config.yaml.md)
- `docs/conf.py`: [Read rules](paths/docs/conf.py.md)
- `docs/examples/cache_extension.py`: [Read rules](paths/docs/examples/cache_extension.py.md)
- `docs/examples/inline_gettext_extension.py`: [Read rules](paths/docs/examples/inline_gettext_extension.py.md)
- `examples/basic`: [Read rules](paths/examples/basic.md)
- `jinja2`: [Read rules](paths/jinja2.md)
- `requirements/tests.txt`: [Read rules](paths/requirements/tests.txt.md)
- `setup.cfg`: [Read rules](paths/setup.cfg.md)
- `src/jinja2`: [Read rules](paths/src/jinja2.md)
- `src/jinja2/__init__.py`: [Read rules](paths/src/jinja2/__init__.py.md)
- `src/jinja2/async_utils.py`: [Read rules](paths/src/jinja2/async_utils.py.md)
- `src/jinja2/bccache.py`: [Read rules](paths/src/jinja2/bccache.py.md)
- `src/jinja2/compiler.py`: [Read rules](paths/src/jinja2/compiler.py.md)
- `src/jinja2/debug.py`: [Read rules](paths/src/jinja2/debug.py.md)
- `src/jinja2/environment.py`: [Read rules](paths/src/jinja2/environment.py.md)
- `src/jinja2/exceptions.py`: [Read rules](paths/src/jinja2/exceptions.py.md)
- `src/jinja2/ext.py`: [Read rules](paths/src/jinja2/ext.py.md)
- `src/jinja2/filters.py`: [Read rules](paths/src/jinja2/filters.py.md)
- `src/jinja2/idtracking.py`: [Read rules](paths/src/jinja2/idtracking.py.md)
- `src/jinja2/meta.py`: [Read rules](paths/src/jinja2/meta.py.md)
- `src/jinja2/nodes.py`: [Read rules](paths/src/jinja2/nodes.py.md)
- `src/jinja2/optimizer.py`: [Read rules](paths/src/jinja2/optimizer.py.md)
- `src/jinja2/parser.py`: [Read rules](paths/src/jinja2/parser.py.md)
- `src/jinja2/runtime.py`: [Read rules](paths/src/jinja2/runtime.py.md)
- `src/jinja2/sandbox.py`: [Read rules](paths/src/jinja2/sandbox.py.md)
- `src/jinja2/utils.py`: [Read rules](paths/src/jinja2/utils.py.md)
- `src/jinja2/visitor.py`: [Read rules](paths/src/jinja2/visitor.py.md)
- `tests`: [Read rules](paths/tests.md)
- `tests/conftest.py`: [Read rules](paths/tests/conftest.py.md)
- `tests/test_bytecode_cache.py`: [Read rules](paths/tests/test_bytecode_cache.py.md)
- `tests/test_compile.py`: [Read rules](paths/tests/test_compile.py.md)
- `tests/test_imports.py`: [Read rules](paths/tests/test_imports.py.md)
