# Rules for `docs/examples/inline_gettext_extension.py`

## Rule 036 — `docs/examples/cache_extension.py`

- **Rule:**
  ```text
  Extension examples must import their extension-authoring surface from `jinja2` (e.g., `nodes`, `Extension`) and may import lexer utilities such as `count_newlines` and `Token` from `jinja2.lexer`.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
  - `docs/examples/inline_gettext_extension.py`
- **Condition:**
  ```text
  When adding or modifying an extension example, import the extension-authoring surface from `jinja2` and lexer utilities from `jinja2.lexer` rather than reimplementing them.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8614cb7ef205d361114b5c4d.md)
