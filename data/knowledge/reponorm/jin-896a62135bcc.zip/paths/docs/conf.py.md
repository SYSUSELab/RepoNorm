# Rules for `docs/conf.py`

## Rule 031 — `docs/conf.py`

- **Rule:**
  ```text
  The docs build configuration must derive `release` and `version` from `pallets_sphinx_themes.get_version("Jinja2")` and use the `jinja` HTML theme with `autodoc_typehints = "description"`.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:**
  ```text
  When modifying the docs build configuration, preserve the version derivation from `pallets_sphinx_themes.get_version("Jinja2")` and the `jinja` theme with `autodoc_typehints = "description"`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-719f35a51cba82030d1bc6c8.md)
