# Rules for `repository root`

## Rule 001 — `**`

- **Rule:** The tox envlist includes py3{11,10,9,8,7}, pypy3{8,7}, style, typing, and docs environments.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-01c7a567ce712e5a9a38a6f2.md)

## Rule 005 — `**/*.css`

- **Rule:**
  ```text
  YAML, JSON, JavaScript, CSS, and HTML files use an indent size of 2 (indent_size = 2).
  ```
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1178cf6006b877bbb81e3290.md)

## Rule 028 — `**/*.py`

- **Rule:** flake8 selects the B, E, F, W, B9, and ISC rule codes.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-63a43db715c8e87e43bae035.md)

## Rule 043 — `**`

- **Rule:**
  ```text
  The tox testenv:style environment sets skip_install to true.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9d8d3172596604dffb017a80.md)

## Rule 051 — `**`

- **Rule:** CI runs the full test suite when a pull request is submitted.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-b951dc901d18726851c50a0a.md)

## Rule 069 — `**`

- **Rule:** The tests job installs tox and runs the tox environment named by the matrix tox value.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fd89df29cb3086b3472d5382.md)
