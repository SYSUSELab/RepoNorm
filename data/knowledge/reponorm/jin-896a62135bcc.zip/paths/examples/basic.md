# Rules for `examples/basic`

## Rule 037 — `examples/basic/**/*.py`

- **Rule:** Example scripts under examples/basic/ that demonstrate the debugger must construct an Environment with a FileSystemLoader pointing at the templates directory and render a template that triggers the debugger, so the example remains a runnable debugger walkthrough.
- **Applies to:**
  - `examples/basic/**/*.py`
- **Condition:** When modifying or adding an example under examples/basic/ that demonstrates the debugger.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-90471e58bb594e36eacf516c.md)
