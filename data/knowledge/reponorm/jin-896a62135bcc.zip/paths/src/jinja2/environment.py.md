# Rules for `src/jinja2/environment.py`

## Rule 027 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  `load_extensions` must accept strings or Extension classes, import string identifiers via `import_string`, instantiate each with the environment, and key the result dict by `extension.identifier`.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying `load_extensions` or extension loading, preserve string/class acceptance, import_string resolution, environment instantiation, and identifier-keyed result dict.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-63a26901711eefd8b313c030.md)

## Rule 056 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Environment.parse must return the AST and, on TemplateSyntaxError, route through handle_exception with the original source so parse failures are reported via the environment's exception handling rather than propagating raw.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when changing Environment.parse or its TemplateSyntaxError handling path
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c913360acef9e7f4021a50ab.md)
