# Rules for `src/jinja2/async_utils.py`

## Rule 047 — `src/jinja2/async_utils.py`

- **Rule:**
  ```text
  When modifying the async_utils wrapper, preserve the use of is_async(args) to choose async_func or normal_func and the stripping of the first argument when need_eval_context is set.
  ```
- **Applies to:**
  - `src/jinja2/async_utils.py`
- **Condition:**
  ```text
  When changing the async_utils wrapper's dispatch logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b07935dfe8795e9b19f61930.md)
