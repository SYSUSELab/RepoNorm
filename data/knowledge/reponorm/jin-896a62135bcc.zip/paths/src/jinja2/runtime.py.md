# Rules for `src/jinja2/runtime.py`

## Rule 017 — `src/jinja2/runtime.py`

- **Rule:** When modifying the async loop context, preserve that the last property is true when peeking the next item returns the missing sentinel, meaning the current iteration is the final one.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when changing async loop iteration state or the last property
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-444b98a8017d50f6b4568868.md)

## Rule 023 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  When modifying DebugUndefined.__str__, preserve that it produces a diagnostic message based on the undefined hint, the missing name, or the object type and name, wrapped as {{ message }}, so printed undefined values expose the reason for the failure.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when changing DebugUndefined string rendering or undefined diagnostics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5511db28de0c584e1597e834.md)

## Rule 066 — `src/jinja2/runtime.py`

- **Rule:** BlockReference.super must return an Undefined named 'super' with a 'there is no parent block called ...' message when depth+1 exceeds the stack, otherwise a BlockReference at depth+1, so super degrades to Undefined at the top block.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when changing BlockReference.super or the parent-block resolution stack behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f07be520b0cd722c986d4da6.md)
