# Rules for `src/jinja2/__init__.py`

## Rule 018 — `src/jinja2/__init__.py`

- **Rule:**
  ```text
  flake8 per-file-ignores exempts src/jinja2/__init__.py from F401.
  ```
- **Applies to:**
  - `src/jinja2/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4dd948a4f4d3d5d1fc1cf449.md)
