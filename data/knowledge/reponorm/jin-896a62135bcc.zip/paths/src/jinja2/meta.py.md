# Rules for `src/jinja2/meta.py`

## Rule 046 — `src/jinja2/meta.py`

- **Rule:**
  ```text
  `find_referenced_templates` must yield `None` for any dynamic template expression (including non-const tuple/list items and unknown dynamic forms) while yielding string constants for hardcoded extends/include/import names.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:**
  ```text
  When modifying `find_referenced_templates` or the reference-node handling, preserve the None-for-dynamic / string-for-constant yield contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-adbf78c4161d3b11718cec5b.md)
