# Rules for `src/jinja2/exceptions.py`

## Rule 016 — `src/jinja2/exceptions.py`

- **Rule:**
  ```text
  TemplatesNotFound must build its message from the names sequence using each Undefined name's _undefined_message joined by commas, store the names list on self.templates, and pass the last name to the base exception.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** Modifying TemplatesNotFound construction or its message/attribute contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3d707e53802cbb794de37a0a.md)
