# Rules for `src/jinja2/sandbox.py`

## Rule 044 — `src/jinja2/sandbox.py`

- **Rule:** Sandboxed attribute access must raise a SecurityError via an undefined object whose message names the attribute and object type, preserving the sandbox's unsafe-attribute error contract.
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  Modifying sandbox attribute access or the unsafe_undefined error path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a3d187187973709b29c0d0c0.md)

## Rule 059 — `src/jinja2/sandbox.py`

- **Rule:**
  ```text
  `SandboxedEnvironment.is_safe_attribute` must return False for attributes starting with underscore or internal attributes, defining the default sandbox attribute-access policy.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying `SandboxedEnvironment.is_safe_attribute` or sandbox attribute policy, preserve the False result for underscore-prefixed and internal attributes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d7d114b0d95923fd2461b162.md)
