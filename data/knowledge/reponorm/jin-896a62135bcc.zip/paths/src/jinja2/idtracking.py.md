# Rules for `src/jinja2/idtracking.py`

## Rule 022 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  RootVisitor.visit_With must visit each target and then each child in the with body, defining how with-statement symbols are tracked.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  When modifying RootVisitor.visit_With or with-statement symbol tracking.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-54e21b6c9b0d38ba09e06015.md)

## Rule 049 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  visit_NSRef must load the referenced name into the symbol tracking state so namespace references participate in symbol resolution like other name loads.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  Modifying FrameSymbolVisitor.visit_NSRef or the symbol-tracking load logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b42e1b4c3730964d01240d08.md)

## Rule 061 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  RootVisitor must alias visit_Template, visit_Block, visit_Macro, visit_FilterBlock, visit_Scope, visit_If, and visit_ScopedEvalContextModifier to _simple_visit so these node types share one traversal behavior.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** When modifying RootVisitor or adding/removing simple-visit node aliases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e8b9c689918d37151eff005c.md)

## Rule 062 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  `RootVisitor._simple_visit` must recursively visit each child node through `sym_visitor`, establishing the traversal convention for symbol tracking.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  When modifying `RootVisitor._simple_visit` or symbol-tracking traversal, preserve recursive child visitation through `sym_visitor`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ed41eb7d5176179557b5f64e.md)
