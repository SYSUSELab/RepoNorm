# Rules for `src/jinja2/utils.py`

## Rule 019 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  open_if_exists must return None when the path is not a regular file, otherwise open the file with the given mode (default 'rb').
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** Modifying file-opening utility behavior or its non-regular-file handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4e40cf69cf3c55f604257069.md)

## Rule 048 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  Cycler must cycle through positional items one at a time and restart at the end, be exposed as `cycler` in templates, and alias `__next__ = next` so it supports both next() and iteration protocols.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying the Cycler class or its template exposure as `cycler`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b2a69f579d977adcca204909.md)
