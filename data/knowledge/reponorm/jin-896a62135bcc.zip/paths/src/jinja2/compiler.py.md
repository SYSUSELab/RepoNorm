# Rules for `src/jinja2/compiler.py`

## Rule 010 — `src/jinja2/compiler.py`

- **Rule:** When modifying the compiler's output-child emission, preserve the eval-context-dependent escaping selection: volatile contexts must use a runtime autoescape check, autoescape contexts must use escape(), and other contexts must use str(), with finalize source prepended when present.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when changing how output children are compiled or how escaping/finalize is selected
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-278eae334aa93a488ed81cf2.md)

## Rule 013 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  `CodeGenerator.optimized` must report whether an optimizer is configured, so optimization is enabled by the presence of an optimizer instance.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying `CodeGenerator.optimized` or optimizer configuration, preserve the property's dependence on the presence of an optimizer instance.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2cb89f8b1e546fcb20c6f43f.md)

## Rule 015 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  Assignment-tracking code must only be emitted when the frame is a block frame, loop frame, or toplevel and there are tracked vars; single-name assignments write directly to _loop_vars, _block_vars, or context.vars, while multiple names use .update({...}).
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Modifying CodeGenerator.pop_assign_tracking or the assignment-tracking emission logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3752daaf675aa02c2b742855.md)

## Rule 020 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  visit_TemplateData must attempt constant folding via node.as_const and, when Impossible is raised, fall back to a runtime expression that applies Markup only if autoescape is enabled, preserving escaping semantics for non-constant template data.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Modifying CodeGenerator.visit_TemplateData or the constant-folding fallback for template data.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4f18884440157cac1b3f81e6.md)

## Rule 021 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  The compiler's `new_func` wrapper must run the optimizer only when `self.optimizer` is not None and the frame's `eval_ctx` is not volatile, and must re-visit the optimized node only if it differs from the original.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying the optimizer invocation wrapper or its guards in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-52127d215d2f6fb7921fc0b1.md)

## Rule 034 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  macro_body must reject an explicitly listed 'caller' argument without a default, and must declare kwargs/varargs parameters only when undeclared in the body and not already explicit parameters.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Modifying macro argument compilation or the caller/kwargs/varargs handling in the code generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7735d6aa3e8de3e0ae98e3a2.md)

## Rule 038 — `src/jinja2/compiler.py`

- **Rule:** When a template uses {% set %} with a non-constant value, the compiler must mark the eval context volatile so the generated code re-evaluates the context at runtime; constant values may be folded at compile time.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Modifying EvalContextModifier compilation or eval-context constant folding in the code generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-91cd910bbd751c2beff54dd3.md)

## Rule 068 — `src/jinja2/compiler.py`

- **Rule:** Tuple code generation must always emit a trailing comma for single-element tuples and a plain closing parenthesis otherwise, preserving valid Python tuple syntax in generated code.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  when changing CodeGenerator.visit_Tuple or tuple literal emission in generated code
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f6c30cfaf53f53bef40dd45b.md)
