# Rules for `src/jinja2/nodes.py`

## Rule 003 — `src/jinja2/nodes.py`

- **Rule:** The Dict literal node must represent dict literals and require its items field to be a list of Pair nodes.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying the Dict node definition or its items field contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-095538d388bf5c0776510d4b.md)

## Rule 008 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  `Node.as_const` must raise `Impossible` by default, so subclasses that support constant evaluation must override it; callers may pass an `EvalContext` or rely on a default context requiring an attached environment.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When adding or modifying constant-evaluation support on AST node subclasses.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1ebf4acc438cc99cf2d49a9c.md)

## Rule 009 — `src/jinja2/nodes.py`

- **Rule:** Statement node types must be defined as subclasses of Stmt (e.g., Continue is a Stmt node representing loop continuation).
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Adding new statement node types to the nodes module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-246725ed3ed803bf07bd417d.md)

## Rule 026 — `src/jinja2/nodes.py`

- **Rule:** The Compare node must declare fields ("expr", "ops") and type ops as a list of Operand, defining the AST shape for comparison expressions.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying the Compare AST node schema or its ops typing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5b7b47c5ec6708cb23a1afea.md)

## Rule 030 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  `EvalContext.revert` must clear `self.__dict__` and update it with the old mapping to restore a node's prior attribute state.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying `EvalContext.revert` or code that relies on restoring prior node attribute state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-71659cb287d8af070f595625.md)

## Rule 060 — `src/jinja2/nodes.py`

- **Rule:** AssignBlock must be a Stmt node with fields ("target", "filter", "body"), where filter is optional, representing block assignment with an optional filter.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying the AssignBlock AST node schema or its optional filter field.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d9eb9552ea6e17d9d867ac5b.md)

## Rule 063 — `src/jinja2/nodes.py`

- **Rule:** Stmt must be the abstract base node for all statement nodes, so concrete statement node types must inherit from it.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Adding or modifying statement node types in the AST hierarchy.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ed58e48addb00ceeae630340.md)
