# Rules for `src/jinja2/visitor.py`

## Rule 058 — `src/jinja2/visitor.py`

- **Rule:** When modifying NodeTransformer, preserve the replacement protocol: replace a node with the visitor function's return value, remove the node when the return value is None, and leave it unchanged when the original node is returned.
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:** When changing NodeTransformer's node replacement behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d46cca6c7fcabcfbd3280e6c.md)
