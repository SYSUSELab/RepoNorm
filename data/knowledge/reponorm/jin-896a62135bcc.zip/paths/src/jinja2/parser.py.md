# Rules for `src/jinja2/parser.py`

## Rule 011 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.subparse must push end_tokens onto self._end_token_stack and pop it in a finally block, returning early when the current token matches an end token, so nested parsing restores the end-token stack even on exceptions.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.subparse or any code that pushes/pops self._end_token_stack during nested template parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2978971293c63f3bf2e83d25.md)
