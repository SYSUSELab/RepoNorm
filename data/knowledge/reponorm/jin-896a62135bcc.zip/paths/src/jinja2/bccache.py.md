# Rules for `src/jinja2/bccache.py`

## Rule 042 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  `MemcachedBytecodeCache.load_bytecode` must swallow memcache client exceptions only when `ignore_memcache_errors` is true; otherwise it re-raises, and on success it loads bytecode from the retrieved value.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  When modifying `MemcachedBytecodeCache.load_bytecode` or its error handling, preserve the ignore_memcache_errors-gated swallowing and re-raise behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9a70e979517693705499f944.md)
