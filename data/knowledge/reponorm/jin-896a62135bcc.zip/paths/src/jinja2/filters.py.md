# Rules for `src/jinja2/filters.py`

## Rule 007 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  do_trim must strip leading and trailing characters from the value, defaulting to whitespace when chars is None, and coerce the input via soft_str before stripping.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** Modifying the trim filter or its input coercion behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1d07075205bcc502114cb9c6.md)

## Rule 025 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  The async rejectattr filter must delegate to async_select_or_reject with a negated predicate, preserving sync/async filter parity.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** Modifying the async rejectattr filter or its relationship to the sync variant.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-58e3ef0158b9db4565842336.md)

## Rule 040 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  `do_unique` must yield items in first-occurrence order, keyed by a set of attribute keys; `case_sensitive=False` applies ignore_case postprocessing and `attribute` selects the key via make_attrgetter.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying `do_unique` or its key/ordering logic, preserve first-occurrence ordering and the case_sensitive/attribute key-selection contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-94c0140f0de2bd78f85584fc.md)

## Rule 041 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  The slice filter must divide a sequence into the requested number of slices, distribute remainder items to the earliest slices, and append fill_with only to slices beyond the remainder count.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when changing sync_do_slice or the slice filter's distribution and fill_with behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-95c1bf8e7d273c23a4586171.md)

## Rule 052 — `src/jinja2/filters.py`

- **Rule:** When a sequence is empty, the first filter must return environment.undefined("No first item, sequence was empty.") rather than raising StopIteration.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** Modifying the first filter or its handling of empty sequences.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-baaf053a12eab28df3423c3c.md)

## Rule 054 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying do_filesizeformat, preserve that it uses base 1000 by default and base 1024 when binary=True, returns "1 Byte" for exactly one byte, formats values below the base as integer "Bytes", and extends the prefix list through YiB/YB.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when changing filesizeformat base selection, byte formatting, or prefix list
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c5039c7d30deaa169762f2ed.md)
