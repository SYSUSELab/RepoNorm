# Rules for `src/jinja2/ext.py`

## Rule 004 — `src/jinja2/ext.py`

- **Rule:**
  ```text
  The extension base __init__ must store the Environment instance on self.environment as the standard extension access point.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Modifying extension initialization or environment access in extensions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-103dd7ada6c8353227930676.md)
