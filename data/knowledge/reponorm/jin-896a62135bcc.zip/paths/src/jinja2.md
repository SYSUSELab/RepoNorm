# Rules for `src/jinja2`

## Rule 067 — `src/jinja2/**`

- **Rule:** mypy is configured to check the files under src/jinja2.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f2d73a9c78868e473072bcff.md)
