# Rules for `tests/test_bytecode_cache.py`

## Rule 024 — `tests/test_bytecode_cache.py`

- **Rule:** Tests for Jinja2 bytecode cache must import the public cache classes (Bucket, FileSystemBytecodeCache, MemcachedBytecodeCache) from jinja2.bccache, preserving the public API surface exercised by these tests.
- **Applies to:**
  - `tests/test_bytecode_cache.py`
- **Condition:**
  ```text
  When modifying or adding tests for bytecode cache behavior in tests/test_bytecode_cache.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5693234d15c8f9eccddd4964.md)
