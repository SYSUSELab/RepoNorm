# Rules for `tests/test_imports.py`

## Rule 039 — `tests/test_imports.py`

- **Rule:** Tests for template module exports must assert that top-level macros and set variables are exposed, while names starting with double underscore and macros defined inside a for loop are not exposed.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** when adding or modifying tests for template module export semantics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-92c28ab989ebf154cf865d5c.md)
