# Rules for `jinja2`

## Rule 006 — `jinja2/**`

- **Rule:** Coverage measurement is configured to restrict its source to the jinja2 and tests packages.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1afd991a416cc34d3c64bb08.md)
