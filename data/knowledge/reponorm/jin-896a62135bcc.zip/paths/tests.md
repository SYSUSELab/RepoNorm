# Rules for `tests`

## Rule 006 — `jinja2/**`

- **Rule:** Coverage measurement is configured to restrict its source to the jinja2 and tests packages.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1afd991a416cc34d3c64bb08.md)

## Rule 050 — `tests/**`

- **Rule:** pytest test discovery is restricted to the tests directory via testpaths = tests.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b8c3668eac35841a5c5a48ac.md)
