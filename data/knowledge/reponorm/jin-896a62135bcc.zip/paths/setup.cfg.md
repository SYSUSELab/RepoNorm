# Rules for `setup.cfg`

## Rule 032 — `setup.cfg`

- **Rule:** Package discovery uses find:, so packages are auto-discovered rather than explicitly listed.
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-759d7e96a25c4ec2b6fb1063.md)

## Rule 033 — `setup.cfg`

- **Rule:**
  ```text
  The package declares Python >= 3.7 as its supported runtime requirement.
  ```
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7735ceef5843a0e94fe6f488.md)

## Rule 053 — `setup.cfg`

- **Rule:**
  ```text
  The babel.extractors entry point registers the jinja2 extractor as jinja2.ext:babel_extract[i18n].
  ```
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c4efaee37f193660ecf036d3.md)

## Rule 055 — `setup.cfg`

- **Rule:** Package data files are included in distributions.
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c5cc36e34469b7af42bf2dbc.md)
