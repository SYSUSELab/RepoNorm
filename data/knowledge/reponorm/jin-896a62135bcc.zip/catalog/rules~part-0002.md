# Full rule catalog

## Rule 018 — `src/jinja2/__init__.py`

- **Rule:**
  ```text
  flake8 per-file-ignores exempts src/jinja2/__init__.py from F401.
  ```
- **Applies to:**
  - `src/jinja2/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4dd948a4f4d3d5d1fc1cf449.md)

## Rule 019 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  open_if_exists must return None when the path is not a regular file, otherwise open the file with the given mode (default 'rb').
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:** Modifying file-opening utility behavior or its non-regular-file handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4e40cf69cf3c55f604257069.md)

## Rule 020 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  visit_TemplateData must attempt constant folding via node.as_const and, when Impossible is raised, fall back to a runtime expression that applies Markup only if autoescape is enabled, preserving escaping semantics for non-constant template data.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Modifying CodeGenerator.visit_TemplateData or the constant-folding fallback for template data.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4f18884440157cac1b3f81e6.md)

## Rule 021 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  The compiler's `new_func` wrapper must run the optimizer only when `self.optimizer` is not None and the frame's `eval_ctx` is not volatile, and must re-visit the optimized node only if it differs from the original.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** When modifying the optimizer invocation wrapper or its guards in the compiler.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-52127d215d2f6fb7921fc0b1.md)

## Rule 022 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  RootVisitor.visit_With must visit each target and then each child in the with body, defining how with-statement symbols are tracked.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  When modifying RootVisitor.visit_With or with-statement symbol tracking.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-54e21b6c9b0d38ba09e06015.md)

## Rule 023 — `src/jinja2/runtime.py`

- **Rule:**
  ```text
  When modifying DebugUndefined.__str__, preserve that it produces a diagnostic message based on the undefined hint, the missing name, or the object type and name, wrapped as {{ message }}, so printed undefined values expose the reason for the failure.
  ```
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when changing DebugUndefined string rendering or undefined diagnostics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5511db28de0c584e1597e834.md)

## Rule 024 — `tests/test_bytecode_cache.py`

- **Rule:** Tests for Jinja2 bytecode cache must import the public cache classes (Bucket, FileSystemBytecodeCache, MemcachedBytecodeCache) from jinja2.bccache, preserving the public API surface exercised by these tests.
- **Applies to:**
  - `tests/test_bytecode_cache.py`
- **Condition:**
  ```text
  When modifying or adding tests for bytecode cache behavior in tests/test_bytecode_cache.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5693234d15c8f9eccddd4964.md)

## Rule 025 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  The async rejectattr filter must delegate to async_select_or_reject with a negated predicate, preserving sync/async filter parity.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** Modifying the async rejectattr filter or its relationship to the sync variant.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-58e3ef0158b9db4565842336.md)

## Rule 026 — `src/jinja2/nodes.py`

- **Rule:** The Compare node must declare fields ("expr", "ops") and type ops as a list of Operand, defining the AST shape for comparison expressions.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying the Compare AST node schema or its ops typing.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5b7b47c5ec6708cb23a1afea.md)

## Rule 027 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  `load_extensions` must accept strings or Extension classes, import string identifiers via `import_string`, instantiate each with the environment, and key the result dict by `extension.identifier`.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:**
  ```text
  When modifying `load_extensions` or extension loading, preserve string/class acceptance, import_string resolution, environment instantiation, and identifier-keyed result dict.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-63a26901711eefd8b313c030.md)

## Rule 028 — `**/*.py`

- **Rule:** flake8 selects the B, E, F, W, B9, and ISC rule codes.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-63a43db715c8e87e43bae035.md)

## Rule 029 — `tests/conftest.py`

- **Rule:** The env fixture in tests/conftest.py must return a fresh Environment() per test, ensuring isolated default environments.
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When adding or modifying the env fixture in tests/conftest.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6c6215013f9bcbece00639f1.md)

## Rule 030 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  `EvalContext.revert` must clear `self.__dict__` and update it with the old mapping to restore a node's prior attribute state.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:**
  ```text
  When modifying `EvalContext.revert` or code that relies on restoring prior node attribute state.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-71659cb287d8af070f595625.md)

## Rule 031 — `docs/conf.py`

- **Rule:**
  ```text
  The docs build configuration must derive `release` and `version` from `pallets_sphinx_themes.get_version("Jinja2")` and use the `jinja` HTML theme with `autodoc_typehints = "description"`.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:**
  ```text
  When modifying the docs build configuration, preserve the version derivation from `pallets_sphinx_themes.get_version("Jinja2")` and the `jinja` theme with `autodoc_typehints = "description"`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-719f35a51cba82030d1bc6c8.md)

## Rule 032 — `setup.cfg`

- **Rule:** Package discovery uses find:, so packages are auto-discovered rather than explicitly listed.
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-759d7e96a25c4ec2b6fb1063.md)

## Rule 033 — `setup.cfg`

- **Rule:**
  ```text
  The package declares Python >= 3.7 as its supported runtime requirement.
  ```
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7735ceef5843a0e94fe6f488.md)

## Rule 034 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  macro_body must reject an explicitly listed 'caller' argument without a default, and must declare kwargs/varargs parameters only when undeclared in the body and not already explicit parameters.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Modifying macro argument compilation or the caller/kwargs/varargs handling in the code generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7735d6aa3e8de3e0ae98e3a2.md)
