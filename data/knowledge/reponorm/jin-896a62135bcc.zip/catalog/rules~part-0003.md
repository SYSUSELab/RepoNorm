# Full rule catalog

## Rule 035 — `**`

- **Rule:**
  ```text
  The tox testenv:style environment runs `pre-commit run --all-files --show-diff-on-failure` as its command.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `repository_wide_mutation`
- **Detail:** [Open claim details](../claims/CLAIM-851c98fda69fe6f7c1455a0f.md)

## Rule 036 — `docs/examples/cache_extension.py`

- **Rule:**
  ```text
  Extension examples must import their extension-authoring surface from `jinja2` (e.g., `nodes`, `Extension`) and may import lexer utilities such as `count_newlines` and `Token` from `jinja2.lexer`.
  ```
- **Applies to:**
  - `docs/examples/cache_extension.py`
  - `docs/examples/inline_gettext_extension.py`
- **Condition:**
  ```text
  When adding or modifying an extension example, import the extension-authoring surface from `jinja2` and lexer utilities from `jinja2.lexer` rather than reimplementing them.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8614cb7ef205d361114b5c4d.md)

## Rule 037 — `examples/basic/**/*.py`

- **Rule:** Example scripts under examples/basic/ that demonstrate the debugger must construct an Environment with a FileSystemLoader pointing at the templates directory and render a template that triggers the debugger, so the example remains a runnable debugger walkthrough.
- **Applies to:**
  - `examples/basic/**/*.py`
- **Condition:** When modifying or adding an example under examples/basic/ that demonstrates the debugger.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-90471e58bb594e36eacf516c.md)

## Rule 038 — `src/jinja2/compiler.py`

- **Rule:** When a template uses {% set %} with a non-constant value, the compiler must mark the eval context volatile so the generated code re-evaluates the context at runtime; constant values may be folded at compile time.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** Modifying EvalContextModifier compilation or eval-context constant folding in the code generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-91cd910bbd751c2beff54dd3.md)

## Rule 039 — `tests/test_imports.py`

- **Rule:** Tests for template module exports must assert that top-level macros and set variables are exposed, while names starting with double underscore and macros defined inside a for loop are not exposed.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** when adding or modifying tests for template module export semantics
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-92c28ab989ebf154cf865d5c.md)

## Rule 040 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  `do_unique` must yield items in first-occurrence order, keyed by a set of attribute keys; `case_sensitive=False` applies ignore_case postprocessing and `attribute` selects the key via make_attrgetter.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  When modifying `do_unique` or its key/ordering logic, preserve first-occurrence ordering and the case_sensitive/attribute key-selection contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-94c0140f0de2bd78f85584fc.md)

## Rule 041 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  The slice filter must divide a sequence into the requested number of slices, distribute remainder items to the earliest slices, and append fill_with only to slices beyond the remainder count.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:**
  ```text
  when changing sync_do_slice or the slice filter's distribution and fill_with behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-95c1bf8e7d273c23a4586171.md)

## Rule 042 — `src/jinja2/bccache.py`

- **Rule:**
  ```text
  `MemcachedBytecodeCache.load_bytecode` must swallow memcache client exceptions only when `ignore_memcache_errors` is true; otherwise it re-raises, and on success it loads bytecode from the retrieved value.
  ```
- **Applies to:**
  - `src/jinja2/bccache.py`
- **Condition:**
  ```text
  When modifying `MemcachedBytecodeCache.load_bytecode` or its error handling, preserve the ignore_memcache_errors-gated swallowing and re-raise behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9a70e979517693705499f944.md)

## Rule 043 — `**`

- **Rule:**
  ```text
  The tox testenv:style environment sets skip_install to true.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9d8d3172596604dffb017a80.md)

## Rule 044 — `src/jinja2/sandbox.py`

- **Rule:** Sandboxed attribute access must raise a SecurityError via an undefined object whose message names the attribute and object type, preserving the sandbox's unsafe-attribute error contract.
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  Modifying sandbox attribute access or the unsafe_undefined error path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3d187187973709b29c0d0c0.md)

## Rule 045 — `.pre-commit-config.yaml`

- **Rule:**
  ```text
  pre-commit autoupdate is scheduled monthly via the ci.autoupdate_schedule setting.
  ```
- **Applies to:**
  - `.pre-commit-config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ac45c2fa565df9ed84444b24.md)

## Rule 046 — `src/jinja2/meta.py`

- **Rule:**
  ```text
  `find_referenced_templates` must yield `None` for any dynamic template expression (including non-const tuple/list items and unknown dynamic forms) while yielding string constants for hardcoded extends/include/import names.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:**
  ```text
  When modifying `find_referenced_templates` or the reference-node handling, preserve the None-for-dynamic / string-for-constant yield contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-adbf78c4161d3b11718cec5b.md)

## Rule 047 — `src/jinja2/async_utils.py`

- **Rule:**
  ```text
  When modifying the async_utils wrapper, preserve the use of is_async(args) to choose async_func or normal_func and the stripping of the first argument when need_eval_context is set.
  ```
- **Applies to:**
  - `src/jinja2/async_utils.py`
- **Condition:**
  ```text
  When changing the async_utils wrapper's dispatch logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b07935dfe8795e9b19f61930.md)

## Rule 048 — `src/jinja2/utils.py`

- **Rule:**
  ```text
  Cycler must cycle through positional items one at a time and restart at the end, be exposed as `cycler` in templates, and alias `__next__ = next` so it supports both next() and iteration protocols.
  ```
- **Applies to:**
  - `src/jinja2/utils.py`
- **Condition:**
  ```text
  When modifying the Cycler class or its template exposure as `cycler`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b2a69f579d977adcca204909.md)

## Rule 049 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  visit_NSRef must load the referenced name into the symbol tracking state so namespace references participate in symbol resolution like other name loads.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  Modifying FrameSymbolVisitor.visit_NSRef or the symbol-tracking load logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b42e1b4c3730964d01240d08.md)

## Rule 050 — `tests/**`

- **Rule:** pytest test discovery is restricted to the tests directory via testpaths = tests.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b8c3668eac35841a5c5a48ac.md)
