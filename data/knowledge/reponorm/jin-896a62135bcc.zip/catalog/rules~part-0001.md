# Full rule catalog

## Rule 001 — `**`

- **Rule:** The tox envlist includes py3{11,10,9,8,7}, pypy3{8,7}, style, typing, and docs environments.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-01c7a567ce712e5a9a38a6f2.md)

## Rule 002 — `requirements/docs.txt`

- **Rule:** Read the Docs documentation builds install the packages listed in requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Detail:** [Open claim details](../claims/CLAIM-030e38ae81f8def6d8ed2d55.md)

## Rule 003 — `src/jinja2/nodes.py`

- **Rule:** The Dict literal node must represent dict literals and require its items field to be a list of Pair nodes.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying the Dict node definition or its items field contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-095538d388bf5c0776510d4b.md)

## Rule 004 — `src/jinja2/ext.py`

- **Rule:**
  ```text
  The extension base __init__ must store the Environment instance on self.environment as the standard extension access point.
  ```
- **Applies to:**
  - `src/jinja2/ext.py`
- **Condition:** Modifying extension initialization or environment access in extensions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-103dd7ada6c8353227930676.md)

## Rule 005 — `**/*.css`

- **Rule:**
  ```text
  YAML, JSON, JavaScript, CSS, and HTML files use an indent size of 2 (indent_size = 2).
  ```
- **Applies to:**
  - `**/*.css`
  - `**/*.html`
  - `**/*.js`
  - `**/*.json`
  - `**/*.yaml`
  - `**/*.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1178cf6006b877bbb81e3290.md)

## Rule 006 — `jinja2/**`

- **Rule:** Coverage measurement is configured to restrict its source to the jinja2 and tests packages.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1afd991a416cc34d3c64bb08.md)

## Rule 007 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  do_trim must strip leading and trailing characters from the value, defaulting to whitespace when chars is None, and coerce the input via soft_str before stripping.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** Modifying the trim filter or its input coercion behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1d07075205bcc502114cb9c6.md)

## Rule 008 — `src/jinja2/nodes.py`

- **Rule:**
  ```text
  `Node.as_const` must raise `Impossible` by default, so subclasses that support constant evaluation must override it; callers may pass an `EvalContext` or rely on a default context requiring an attached environment.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When adding or modifying constant-evaluation support on AST node subclasses.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1ebf4acc438cc99cf2d49a9c.md)

## Rule 009 — `src/jinja2/nodes.py`

- **Rule:** Statement node types must be defined as subclasses of Stmt (e.g., Continue is a Stmt node representing loop continuation).
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Adding new statement node types to the nodes module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-246725ed3ed803bf07bd417d.md)

## Rule 010 — `src/jinja2/compiler.py`

- **Rule:** When modifying the compiler's output-child emission, preserve the eval-context-dependent escaping selection: volatile contexts must use a runtime autoescape check, autoescape contexts must use escape(), and other contexts must use str(), with finalize source prepended when present.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when changing how output children are compiled or how escaping/finalize is selected
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-278eae334aa93a488ed81cf2.md)

## Rule 011 — `src/jinja2/parser.py`

- **Rule:**
  ```text
  Parser.subparse must push end_tokens onto self._end_token_stack and pop it in a finally block, returning early when the current token matches an end token, so nested parsing restores the end-token stack even on exceptions.
  ```
- **Applies to:**
  - `src/jinja2/parser.py`
- **Condition:**
  ```text
  When modifying Parser.subparse or any code that pushes/pops self._end_token_stack during nested template parsing.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2978971293c63f3bf2e83d25.md)

## Rule 012 — `src/jinja2/optimizer.py`

- **Rule:** The optimizer must not perform optimizations such as loop unrolling because the AST lacks full scoping information; a second syntax tree storing scoping rules would be required.
- **Applies to:**
  - `src/jinja2/optimizer.py`
- **Condition:** When modifying the optimizer or considering scoping-dependent optimizations, preserve the limitation that loop unrolling and similar optimizations require a second syntax tree with scoping rules.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c3403feda11f5658faf8cb0.md)

## Rule 013 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  `CodeGenerator.optimized` must report whether an optimizer is configured, so optimization is enabled by the presence of an optimizer instance.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying `CodeGenerator.optimized` or optimizer configuration, preserve the property's dependence on the presence of an optimizer instance.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2cb89f8b1e546fcb20c6f43f.md)

## Rule 014 — `requirements/tests.txt`

- **Rule:** The tox testenv installs test dependencies from requirements/tests.txt.
- **Applies to:**
  - `requirements/tests.txt`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2fa17c7eee554bdd0cbab7cd.md)

## Rule 015 — `src/jinja2/compiler.py`

- **Rule:**
  ```text
  Assignment-tracking code must only be emitted when the frame is a block frame, loop frame, or toplevel and there are tracked vars; single-name assignments write directly to _loop_vars, _block_vars, or context.vars, while multiple names use .update({...}).
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  Modifying CodeGenerator.pop_assign_tracking or the assignment-tracking emission logic.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3752daaf675aa02c2b742855.md)

## Rule 016 — `src/jinja2/exceptions.py`

- **Rule:**
  ```text
  TemplatesNotFound must build its message from the names sequence using each Undefined name's _undefined_message joined by commas, store the names list on self.templates, and pass the last name to the base exception.
  ```
- **Applies to:**
  - `src/jinja2/exceptions.py`
- **Condition:** Modifying TemplatesNotFound construction or its message/attribute contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3d707e53802cbb794de37a0a.md)

## Rule 017 — `src/jinja2/runtime.py`

- **Rule:** When modifying the async loop context, preserve that the last property is true when peeking the next item returns the missing sentinel, meaning the current iteration is the final one.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when changing async loop iteration state or the last property
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-444b98a8017d50f6b4568868.md)
