# Full rule catalog

## Rule 068 — `src/jinja2/compiler.py`

- **Rule:** Tuple code generation must always emit a trailing comma for single-element tuples and a plain closing parenthesis otherwise, preserving valid Python tuple syntax in generated code.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  when changing CodeGenerator.visit_Tuple or tuple literal emission in generated code
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f6c30cfaf53f53bef40dd45b.md)

## Rule 069 — `**`

- **Rule:** The tests job installs tox and runs the tox environment named by the matrix tox value.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fd89df29cb3086b3472d5382.md)
