# Full rule catalog

## Rule 051 — `**`

- **Rule:** CI runs the full test suite when a pull request is submitted.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-b951dc901d18726851c50a0a.md)

## Rule 052 — `src/jinja2/filters.py`

- **Rule:** When a sequence is empty, the first filter must return environment.undefined("No first item, sequence was empty.") rather than raising StopIteration.
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** Modifying the first filter or its handling of empty sequences.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-baaf053a12eab28df3423c3c.md)

## Rule 053 — `setup.cfg`

- **Rule:**
  ```text
  The babel.extractors entry point registers the jinja2 extractor as jinja2.ext:babel_extract[i18n].
  ```
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c4efaee37f193660ecf036d3.md)

## Rule 054 — `src/jinja2/filters.py`

- **Rule:**
  ```text
  When modifying do_filesizeformat, preserve that it uses base 1000 by default and base 1024 when binary=True, returns "1 Byte" for exactly one byte, formats values below the base as integer "Bytes", and extends the prefix list through YiB/YB.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when changing filesizeformat base selection, byte formatting, or prefix list
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c5039c7d30deaa169762f2ed.md)

## Rule 055 — `setup.cfg`

- **Rule:** Package data files are included in distributions.
- **Applies to:**
  - `setup.cfg`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c5cc36e34469b7af42bf2dbc.md)

## Rule 056 — `src/jinja2/environment.py`

- **Rule:**
  ```text
  Environment.parse must return the AST and, on TemplateSyntaxError, route through handle_exception with the original source so parse failures are reported via the environment's exception handling rather than propagating raw.
  ```
- **Applies to:**
  - `src/jinja2/environment.py`
- **Condition:** when changing Environment.parse or its TemplateSyntaxError handling path
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c913360acef9e7f4021a50ab.md)

## Rule 057 — `requirements/docs.txt`

- **Rule:** The docs tox environment installs dependencies from requirements/docs.txt.
- **Applies to:**
  - `requirements/docs.txt`
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Detail:** [Open claim details](../claims/CLAIM-d0854eb3357069b3f8ea41ab.md)

## Rule 058 — `src/jinja2/visitor.py`

- **Rule:** When modifying NodeTransformer, preserve the replacement protocol: replace a node with the visitor function's return value, remove the node when the return value is None, and leave it unchanged when the original node is returned.
- **Applies to:**
  - `src/jinja2/visitor.py`
- **Condition:** When changing NodeTransformer's node replacement behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d46cca6c7fcabcfbd3280e6c.md)

## Rule 059 — `src/jinja2/sandbox.py`

- **Rule:**
  ```text
  `SandboxedEnvironment.is_safe_attribute` must return False for attributes starting with underscore or internal attributes, defining the default sandbox attribute-access policy.
  ```
- **Applies to:**
  - `src/jinja2/sandbox.py`
- **Condition:**
  ```text
  When modifying `SandboxedEnvironment.is_safe_attribute` or sandbox attribute policy, preserve the False result for underscore-prefixed and internal attributes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d7d114b0d95923fd2461b162.md)

## Rule 060 — `src/jinja2/nodes.py`

- **Rule:** AssignBlock must be a Stmt node with fields ("target", "filter", "body"), where filter is optional, representing block assignment with an optional filter.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Modifying the AssignBlock AST node schema or its optional filter field.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d9eb9552ea6e17d9d867ac5b.md)

## Rule 061 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  RootVisitor must alias visit_Template, visit_Block, visit_Macro, visit_FilterBlock, visit_Scope, visit_If, and visit_ScopedEvalContextModifier to _simple_visit so these node types share one traversal behavior.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:** When modifying RootVisitor or adding/removing simple-visit node aliases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e8b9c689918d37151eff005c.md)

## Rule 062 — `src/jinja2/idtracking.py`

- **Rule:**
  ```text
  `RootVisitor._simple_visit` must recursively visit each child node through `sym_visitor`, establishing the traversal convention for symbol tracking.
  ```
- **Applies to:**
  - `src/jinja2/idtracking.py`
- **Condition:**
  ```text
  When modifying `RootVisitor._simple_visit` or symbol-tracking traversal, preserve recursive child visitation through `sym_visitor`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed41eb7d5176179557b5f64e.md)

## Rule 063 — `src/jinja2/nodes.py`

- **Rule:** Stmt must be the abstract base node for all statement nodes, so concrete statement node types must inherit from it.
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** Adding or modifying statement node types in the AST hierarchy.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed58e48addb00ceeae630340.md)

## Rule 064 — `src/jinja2/debug.py`

- **Rule:**
  ```text
  fake_traceback must synthesize a traceback pointing at template source by compiling a raise statement at the template line, replacing co_name with "top-level template code" for root or "block <name>" for block_ functions, and using version-conditional code replacement for Python 3.8+.
  ```
- **Applies to:**
  - `src/jinja2/debug.py`
- **Condition:**
  ```text
  When modifying fake_traceback or template traceback synthesis.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ede5a3dc6e0c81f1ced1279b.md)

## Rule 065 — `tests/test_compile.py`

- **Rule:**
  ```text
  The test_compile.py module must import Environment from jinja2.environment and DictLoader from jinja2.loaders, exercising compilation through those public entry points.
  ```
- **Applies to:**
  - `tests/test_compile.py`
- **Condition:** When modifying or adding compilation tests that use Environment and DictLoader public entry points.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ee15036d7b4c04ef7cf59d84.md)

## Rule 066 — `src/jinja2/runtime.py`

- **Rule:** BlockReference.super must return an Undefined named 'super' with a 'there is no parent block called ...' message when depth+1 exceeds the stack, otherwise a BlockReference at depth+1, so super degrades to Undefined at the top block.
- **Applies to:**
  - `src/jinja2/runtime.py`
- **Condition:** when changing BlockReference.super or the parent-block resolution stack behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f07be520b0cd722c986d4da6.md)

## Rule 067 — `src/jinja2/**`

- **Rule:** mypy is configured to check the files under src/jinja2.
- **Applies to:**
  - `src/jinja2/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f2d73a9c78868e473072bcff.md)
