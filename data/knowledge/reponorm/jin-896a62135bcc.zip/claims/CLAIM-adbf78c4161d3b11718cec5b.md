# Rule details

- **Rule:**
  ```text
  `find_referenced_templates` must yield `None` for any dynamic template expression (including non-const tuple/list items and unknown dynamic forms) while yielding string constants for hardcoded extends/include/import names.
  ```
- **Applies to:**
  - `src/jinja2/meta.py`
- **Condition:**
  ```text
  When modifying `find_referenced_templates` or the reference-node handling, preserve the None-for-dynamic / string-for-constant yield contract.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
find_referenced_templates yields None for dynamic template expressions (non-const tuple/list items and unknown dynamic forms) and yields string constants for hardcoded extends/include/import names, matching the rule.
```

- **Sources:**
  - `src/jinja2/meta.py:61-111`
