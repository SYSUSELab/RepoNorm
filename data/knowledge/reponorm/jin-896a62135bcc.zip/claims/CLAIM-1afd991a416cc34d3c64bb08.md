# Rule details

- **Rule:** Coverage measurement is configured to restrict its source to the jinja2 and tests packages.
- **Applies to:**
  - `jinja2/**`
  - `tests/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
source =
    jinja2
    tests

```

- **Sources:**
  - `setup.cfg:55-57`
