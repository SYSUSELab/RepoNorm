# Rule details

- **Rule:** Tuple code generation must always emit a trailing comma for single-element tuples and a plain closing parenthesis otherwise, preserving valid Python tuple syntax in generated code.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  when changing CodeGenerator.visit_Tuple or tuple literal emission in generated code
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
CodeGenerator.visit_Tuple writes '(' then items separated by ', ', and closes with ',)' when idx == 0 (single element) else ')', exactly preserving the trailing comma for single-element tuples and plain parenthesis otherwise.
```

- **Sources:**
  - `src/jinja2/compiler.py:1644-1651`
