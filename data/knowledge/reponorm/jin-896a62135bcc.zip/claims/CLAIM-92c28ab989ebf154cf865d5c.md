# Rule details

- **Rule:** Tests for template module exports must assert that top-level macros and set variables are exposed, while names starting with double underscore and macros defined inside a for loop are not exposed.
- **Applies to:**
  - `tests/test_imports.py`
- **Condition:** when adding or modifying tests for template module export semantics
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
TestImports.test_exports asserts top-level macro and set variable exposure while double-underscore and loop-defined macros are not exposed, matching the export semantics rule.
```

- **Sources:**
  - `tests/test_imports.py:79-93`
