# Rule details

- **Rule:** The tox testenv installs test dependencies from requirements/tests.txt.
- **Applies to:**
  - `requirements/tests.txt`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
deps = -r requirements/tests.txt

```

- **Sources:**
  - `tox.ini:10`
