# Rule details

- **Rule:**
  ```text
  fake_traceback must synthesize a traceback pointing at template source by compiling a raise statement at the template line, replacing co_name with "top-level template code" for root or "block <name>" for block_ functions, and using version-conditional code replacement for Python 3.8+.
  ```
- **Applies to:**
  - `src/jinja2/debug.py`
- **Condition:**
  ```text
  When modifying fake_traceback or template traceback synthesis.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
fake_traceback compiles a raise at the template line, replaces co_name with 'top-level template code' or 'block <name>', and uses version-conditional code replacement for Python 3.8+, matching the rule.
```

- **Sources:**
  - `src/jinja2/debug.py:76-147`
