# Rule details

- **Rule:**
  ```text
  `Node.as_const` must raise `Impossible` by default, so subclasses that support constant evaluation must override it; callers may pass an `EvalContext` or rely on a default context requiring an attached environment.
  ```
- **Applies to:**
  - `src/jinja2/nodes.py`
- **Condition:** When adding or modifying constant-evaluation support on AST node subclasses.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
`Expr.as_const` raises `Impossible` by default, matching the base contract that subclasses must override for constant evaluation.
```

- **Sources:**
  - `src/jinja2/nodes.py:470-481`
