# Rule details

- **Rule:**
  ```text
  When modifying do_filesizeformat, preserve that it uses base 1000 by default and base 1024 when binary=True, returns "1 Byte" for exactly one byte, formats values below the base as integer "Bytes", and extends the prefix list through YiB/YB.
  ```
- **Applies to:**
  - `src/jinja2/filters.py`
- **Condition:** when changing filesizeformat base selection, byte formatting, or prefix list
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
do_filesizeformat uses base 1000/1024 by binary flag, special-cases one byte as '1 Byte', formats sub-base as integer Bytes, and lists prefixes through YiB/YB.
```

- **Sources:**
  - `src/jinja2/filters.py:633-663`
