# Rule details

- **Rule:** When modifying the compiler's output-child emission, preserve the eval-context-dependent escaping selection: volatile contexts must use a runtime autoescape check, autoescape contexts must use escape(), and other contexts must use str(), with finalize source prepended when present.
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:** when changing how output children are compiled or how escaping/finalize is selected
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_output_child_pre selects escape() for autoescape, a runtime autoescape check for volatile, str() otherwise, and prepends finalize source when present.
```

- **Sources:**
  - `src/jinja2/compiler.py:1452-1466`
