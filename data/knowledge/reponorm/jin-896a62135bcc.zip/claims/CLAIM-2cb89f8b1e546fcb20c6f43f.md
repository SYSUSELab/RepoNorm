# Rule details

- **Rule:**
  ```text
  `CodeGenerator.optimized` must report whether an optimizer is configured, so optimization is enabled by the presence of an optimizer instance.
  ```
- **Applies to:**
  - `src/jinja2/compiler.py`
- **Condition:**
  ```text
  When modifying `CodeGenerator.optimized` or optimizer configuration, preserve the property's dependence on the presence of an optimizer instance.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
CodeGenerator.optimized returns self.optimizer is not None, so optimization is gated on the presence of an optimizer instance, matching the rule.
```

- **Sources:**
  - `src/jinja2/compiler.py:375-376`
