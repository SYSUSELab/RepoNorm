# Rules for `dspy/dsp/colbertv2.py`

## Rule 129 — `dspy/dsp/colbertv2.py`

- **Rule:**
  ```text
  ColBERTv2RetrieverLocal.get_index must attempt to import colbert and print an installation hint on ImportError, then import Searcher and Run/RunConfig and construct a Searcher within a Run context using the required RunConfig experiment/index/collection parameters.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:**
  ```text
  When modifying ColBERTv2RetrieverLocal.get_index or its colbert optional-dependency handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c2f2f498318844c9522a0a9e.md)

## Rule 162 — `dspy/dsp/colbertv2.py`

- **Rule:**
  ```text
  ColBERTv2.__init__ must treat colbert as an optional dependency: on ImportError print an installation hint, and overwrite self.colbert_config.checkpoint with the constructor checkpoint argument.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:**
  ```text
  When modifying ColBERTv2.__init__ import handling or checkpoint configuration.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ff5f8685d6186f03f562918c.md)
