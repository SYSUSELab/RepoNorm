# Rules for `dspy/dsp/utils/dpr.py`

## Rule 058 — `dspy/dsp/utils/dpr.py`

- **Rule:** The dpr utils module must retain its vendored DPR provenance and instantiate a module-level STokenizer = SimpleTokenizer().
- **Applies to:**
  - `dspy/dsp/utils/dpr.py`
- **Condition:** When modifying the dpr utils module or its tokenizer instantiation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5ca1e1c6d02d956002b2130d.md)

## Rule 158 — `dspy/dsp/utils/dpr.py`

- **Rule:**
  ```text
  SimpleTokenizer must define ALPHA_NUM as r'[\p{L}\p{N}\p{M}]+' and NON_WS as r'[^\p{Z}\p{C}]', using Unicode property classes for tokenization.
  ```
- **Applies to:**
  - `dspy/dsp/utils/dpr.py`
- **Condition:**
  ```text
  When modifying SimpleTokenizer's ALPHA_NUM or NON_WS regex patterns.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-f7cf678956bcec3c7289b913.md)
