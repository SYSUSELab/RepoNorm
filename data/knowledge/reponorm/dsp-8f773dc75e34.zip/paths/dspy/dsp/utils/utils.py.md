# Rules for `dspy/dsp/utils/utils.py`

## Rule 065 — `dspy/dsp/utils/utils.py`

- **Rule:**
  ```text
  timestamp(daydir=True) must produce a date-directory format using '/' separators, while daydir=False must use '-' and '_' separators, so callers relying on path layout must account for this branch.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:** When modifying timestamp formatting or callers that depend on its path layout.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-656b3dd191eba039653c7e7a.md)
