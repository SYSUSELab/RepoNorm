# Rules for `dspy/adapters/utils.py`

## Rule 111 — `dspy/adapters/utils.py`

- **Rule:**
  ```text
  When modifying find_enum_member, preserve that member.value is checked before member name, deliberately handling the rare case where an explicitly-valued enum member's value equals another member's name, and that ValueError is raised when the identifier matches neither a value nor a name.
  ```
- **Applies to:**
  - `dspy/adapters/utils.py`
- **Condition:** Changing enum member resolution order or error behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ad1319497e682bc5654897cf.md)
