# Rules for `dspy/adapters/__init__.py`

## Rule 106 — `dspy/adapters/__init__.py`

- **Rule:**
  ```text
  When changing dspy.adapters' public surface, keep the exported adapter types (Adapter, ChatAdapter, JSONAdapter, XMLAdapter, TwoStepAdapter, Type, History, Image, Audio, Code, Tool, ToolCalls) listed in __all__ so the supported adapter API remains importable.
  ```
- **Applies to:**
  - `dspy/adapters/__init__.py`
- **Condition:** Modifying the dspy.adapters package exports or adding/removing adapter types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a6aeaf3b96bf43cd27c5e593.md)
