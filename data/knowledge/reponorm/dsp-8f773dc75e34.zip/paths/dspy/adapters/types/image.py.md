# Rules for `dspy/adapters/types/image.py`

## Rule 073 — `dspy/adapters/types/image.py`

- **Rule:**
  ```text
  When modifying Image.__repr__, preserve base64 payload redaction: base64 data must be summarized by encoded length and image type rather than printed verbatim, while non-base64 URLs remain shown verbatim.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  Changing how Image.__repr__ formats or logs image content.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-6ff0a45c15482ab99f4d38fb.md)
