# Rules for `dspy/teleprompt/signature_opt.py`

## Rule 053 — `dspy/teleprompt/signature_opt.py`

- **Rule:**
  ```text
  When modifying SignatureOptimizer in dspy/teleprompt/signature_opt.py, preserve the deprecation boundary: __init__ must print a red warning that SignatureOptimizer is deprecated in favor of COPRO and will be removed in a future release before delegating to the superclass initializer.
  ```
- **Applies to:**
  - `dspy/teleprompt/signature_opt.py`
- **Condition:** When changing SignatureOptimizer initialization or its deprecation messaging.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-546fcc5c69d12ac1177fa86b.md)
