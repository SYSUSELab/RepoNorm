# Rules for `dspy/teleprompt/bootstrap.py`

## Rule 080 — `dspy/teleprompt/bootstrap.py`

- **Rule:**
  ```text
  Bootstrap module design constraints must be preserved: metrics should be bool-like/sortable, some example sets are intentionally not shuffled, and max_rounds via branch_idx is used to bypass cache rather than only temperature.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap.py`
- **Condition:** When modifying bootstrap metric handling, example shuffling, or cache-bypass logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7d751fa4dac07500f06efc5b.md)
