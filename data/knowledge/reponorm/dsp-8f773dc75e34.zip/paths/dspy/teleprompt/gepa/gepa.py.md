# Rules for `dspy/teleprompt/gepa/gepa.py`

## Rule 001 — `dspy/teleprompt/gepa/gepa.py`

- **Rule:**
  ```text
  `to_dict` serializes GEPA state including candidates, parents, scores, per-instance best candidates (converted to lists), eval counts, log_dir, seed, and best_idx, defining the persisted state schema.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  When modifying DspyGEPAResult.to_dict or the persisted GEPA state schema.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-00f1c15fdcd8bf36883a74cf.md)

## Rule 051 — `dspy/teleprompt/gepa/gepa.py`

- **Rule:**
  ```text
  GEPA's DspyGEPAResult.best_candidate must be a property returning the candidate dict at best_idx, so callers read it without invoking a method and best_idx must remain valid.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  when modifying DspyGEPAResult.best_candidate or best_idx maintenance
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-514f728aa3b1ce0a0f6f5566.md)

## Rule 060 — `dspy/teleprompt/gepa/gepa.py`

- **Rule:**
  ```text
  best_idx returns the index of the maximum value in val_aggregate_scores, so ties resolve to the first highest-scoring index.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  When modifying DspyGEPAResult.best_idx or its tie-breaking behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-5e561eff8e69e6f33ed80aa5.md)

## Rule 088 — `dspy/teleprompt/gepa/gepa.py`

- **Rule:**
  ```text
  DspyGEPAResult.from_gepa_result rebuilds candidates through adapter.build_program while passing through parents, scores, best outputs, discovery counts, total metric calls, log_dir from run_dir, and seed, defining the adapter boundary for GEPA results.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  When modifying DspyGEPAResult.from_gepa_result or the GEPA result adaptation boundary.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-89e03f987b3ba84a99e3f0c7.md)

## Rule 150 — `dspy/teleprompt/gepa/gepa.py`

- **Rule:**
  ```text
  DspyGEPAResult is a frozen dataclass whose fields (candidates, parents, val_aggregate_scores, val_subscores, per_val_instance_best_candidates, discovery_eval_counts, best_outputs_valset, total_metric_calls, num_full_val_evals, log_dir, seed) define the public result contract of GEPA optimization runs.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:** When modifying DspyGEPAResult fields or its frozen dataclass contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e12eec3e9a2c6b13a6448218.md)
