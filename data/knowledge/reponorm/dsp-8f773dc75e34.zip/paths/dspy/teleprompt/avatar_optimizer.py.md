# Rules for `dspy/teleprompt/avatar_optimizer.py`

## Rule 009 — `dspy/teleprompt/avatar_optimizer.py`

- **Rule:**
  ```text
  thread_safe_evaluator must run process_example over the devset with a ThreadPoolExecutor sized by num_threads or dspy.settings.num_threads, accumulate scores, and return either the average metric or (avg_metric, results) when return_outputs is set.
  ```
- **Applies to:**
  - `dspy/teleprompt/avatar_optimizer.py`
- **Condition:**
  ```text
  When modifying thread_safe_evaluator concurrency sizing or return shape.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0cbe125bbcea3e35b302fa84.md)
