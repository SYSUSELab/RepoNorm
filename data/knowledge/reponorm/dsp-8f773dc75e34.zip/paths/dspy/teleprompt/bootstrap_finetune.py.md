# Rules for `dspy/teleprompt/bootstrap_finetune.py`

## Rule 032 — `dspy/teleprompt/bootstrap_finetune.py`

- **Rule:**
  ```text
  all_predictors_have_lms must return True only if every predictor in the program has an LM set, defining the precondition used by finetune bootstrapping to decide whether LMs are ready; changes must preserve this all-predictors condition.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When modifying all_predictors_have_lms or the finetune bootstrapping precondition that checks LM readiness.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-366c18c467f351bba3cb6628.md)
