# Rules for `dspy/propose/grounded_proposer.py`

## Rule 036 — `dspy/propose/grounded_proposer.py`

- **Rule:**
  ```text
  DescribeModule must remain a dspy.Signature with input fields program_code, program_example, program_description, module and output field module_description, each carrying explicit prefixes that structure the proposer prompt.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:** When modifying DescribeModule fields or their prefixes used by the proposer prompt.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3ac2f109db1cf6f5aa5f5267.md)

## Rule 115 — `dspy/propose/grounded_proposer.py`

- **Rule:**
  ```text
  When modifying the GenerateSingleModuleInstruction signature in dspy/propose/grounded_proposer.py, gate InputFields consistently with the constructor flags use_dataset_summary, program_aware, use_instruct_history, and use_tip so the prompt schema varies per configuration as intended.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:** When adding or changing InputFields on GenerateSingleModuleInstruction or its constructor flags.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-af73a111b355ed4ec5e023ee.md)
