# Rules for `dspy/propose/utils.py`

## Rule 089 — `dspy/propose/utils.py`

- **Rule:**
  ```text
  create_predictor_level_history_string must load trial programs from program_path, aggregate and average scores per instruction, deduplicate instructions, sort by average score descending, take the top N, reverse the list, and format each entry as 'instruction | Score: score'.
  ```
- **Applies to:**
  - `dspy/propose/utils.py`
- **Condition:** When modifying predictor-level history aggregation or its output formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8a727908d18fdada3a601aef.md)
