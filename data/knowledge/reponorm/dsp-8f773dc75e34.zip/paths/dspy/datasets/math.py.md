# Rules for `dspy/datasets/math.py`

## Rule 136 — `dspy/datasets/math.py`

- **Rule:**
  ```text
  MATH.metric must require the external math_equivalence package and raise an ImportError with the install command when it is missing; changes must preserve this optional-dependency guard and its actionable error message.
  ```
- **Applies to:**
  - `dspy/datasets/math.py`
- **Condition:**
  ```text
  When modifying MATH.metric or its dependency handling for the math_equivalence package.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cde748d043912216fdd574fb.md)
