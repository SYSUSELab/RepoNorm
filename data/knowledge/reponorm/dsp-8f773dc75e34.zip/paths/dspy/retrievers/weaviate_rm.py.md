# Rules for `dspy/retrievers/weaviate_rm.py`

## Rule 041 — `dspy/retrievers/weaviate_rm.py`

- **Rule:**
  ```text
  WeaviateRM.forward must branch on self._client_type: 'WeaviateClient' uses collection.query.hybrid with optional with_tenant, while 'Client' uses the legacy query.get(...).with_hybrid(...).with_limit(...).do() path, and both extract the configured text key into dotdict long_text passages.
  ```
- **Applies to:**
  - `dspy/retrievers/weaviate_rm.py`
- **Condition:** When modifying WeaviateRM.forward or its client-type branching.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4399202a2a7a7c3f9518d0f5.md)
