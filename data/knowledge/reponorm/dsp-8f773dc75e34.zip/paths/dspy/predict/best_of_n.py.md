# Rules for `dspy/predict/best_of_n.py`

## Rule 159 — `dspy/predict/best_of_n.py`

- **Rule:**
  ```text
  BestOfN.forward must build a deduplicated temperature schedule from the LM's configured temperature, deep-copy the module per attempt, stop early when reward meets threshold, retry on exception until fail_count is exhausted before re-raising, and extend the best trace into dspy.settings.trace.
  ```
- **Applies to:**
  - `dspy/predict/best_of_n.py`
- **Condition:** When modifying BestOfN.forward attempt scheduling, retry, or trace handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f83ddcb158e1a27c9c443ce3.md)
