# Rules for `dspy/streaming/messages.py`

## Rule 063 — `dspy/streaming/messages.py`

- **Rule:**
  ```text
  sync_send_to_stream._send must await stream.send(message), using an async send protocol to push messages onto a stream.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  When modifying sync_send_to_stream._send or its async send protocol.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-62f036eeef35c7ff9b053c82.md)
