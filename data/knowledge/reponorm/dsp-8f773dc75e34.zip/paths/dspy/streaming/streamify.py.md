# Rules for `dspy/streaming/streamify.py`

## Rule 090 — `dspy/streaming/streamify.py`

- **Rule:**
  ```text
  async_streamer must yield ModelResponseStream chunks directly when no listeners are configured, otherwise delegate each chunk to predict_id_to_listener listeners and yield the first truthy listener output; StatusMessage values are always yielded, and final Predictions are yielded only if include_final_prediction_in_output_stream or no listener has stream_start/cache_hit conditions.
  ```
- **Applies to:**
  - `dspy/streaming/streamify.py`
- **Condition:**
  ```text
  When modifying async_streamer or its listener delegation and final-prediction gating.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8c3174344a7468aa06fc207a.md)
