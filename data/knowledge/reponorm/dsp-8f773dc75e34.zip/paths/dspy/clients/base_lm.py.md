# Rules for `dspy/clients/base_lm.py`

## Rule 030 — `dspy/clients/base_lm.py`

- **Rule:**
  ```text
  base_lm.py must define MAX_HISTORY_SIZE = 10_000 and a module-level GLOBAL_HISTORY list so history is capped at a fixed size rather than growing unbounded.
  ```
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:**
  ```text
  When modifying history storage or size limits in base_lm.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-33c51685a4372cf0a4c30efd.md)

## Rule 047 — `dspy/clients/base_lm.py`

- **Rule:** BaseLM.copy must deep-copy the LM, reset history to empty, and route kwargs to attributes when present or to the kwargs dict otherwise.
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:** When modifying BaseLM.copy or subclass copy behavior, preserve deep-copy semantics, empty history reset, and kwargs routing to attributes or kwargs dict.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4c2b5f5a0b0a028d2624e258.md)
