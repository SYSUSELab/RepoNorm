# Rules for `dspy/clients/openai.py`

## Rule 148 — `dspy/clients/openai.py`

- **Rule:**
  ```text
  When modifying TrainingJobOpenAI.__init__, preserve per-client provider job/file tracking state by initializing provider_file_id and provider_job_id to None.
  ```
- **Applies to:**
  - `dspy/clients/openai.py`
- **Condition:** Changing OpenAI client initialization or provider job/file tracking state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-df119a7721ba135431450d55.md)
