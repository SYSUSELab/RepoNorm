# Rules for `dspy/clients/lm.py`

## Rule 023 — `dspy/clients/lm.py`

- **Rule:**
  ```text
  When modifying litellm_completion, preserve default no-cache/no-store behavior, exponential_backoff_retry usage, and delegation to the stream completion function when one is configured.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:**
  ```text
  Changing litellm_completion defaults, retry behavior, or streaming delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-24c17e9ebf1319994a0c92d7.md)

## Rule 108 — `dspy/clients/lm.py`

- **Rule:**
  ```text
  When modifying stream_completion, preserve that it calls litellm.acompletion with stream=True, attaches caller_predict_id to each chunk for stream listeners, forwards chunks via stream.send, and returns litellm.stream_chunk_builder over collected chunks.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** Changing the streaming completion path or chunk forwarding behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aa3908fac7c1594152d45dc6.md)
