# Rules for `dspy/clients/databricks.py`

## Rule 022 — `dspy/clients/databricks.py`

- **Rule:**
  ```text
  TrainingJobDatabricks.status must require the databricks_genai package and raise an ImportError with an install hint when it is missing, and must return None when no finetuning run is set.
  ```
- **Applies to:**
  - `dspy/clients/databricks.py`
- **Condition:** When modifying TrainingJobDatabricks.status or its optional-dependency handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-243726a98f6153e399e83ca2.md)
