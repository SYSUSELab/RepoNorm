# Rules for `dspy/clients/cache.py`

## Rule 012 — `dspy/clients/cache.py`

- **Rule:** When modifying the two-level cache in dspy/clients/cache.py, preserve the ordering and layering: an in-memory cachetools.LRUCache consulted before an on-disk diskcache.FanoutCache, so that in-memory hits short-circuit disk access.
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:** When changing cache lookup, storage, or eviction behavior in the Cache class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0fe430d6131dcebd873b0725.md)
