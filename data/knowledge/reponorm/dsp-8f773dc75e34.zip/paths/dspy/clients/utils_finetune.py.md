# Rules for `dspy/clients/utils_finetune.py`

## Rule 052 — `dspy/clients/utils_finetune.py`

- **Rule:** The finetune utilities must define a Message TypedDict whose role is constrained to the literals 'user', 'assistant', or 'system' and whose content is a string, establishing the canonical chat message shape used by finetune data preparation.
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:** When modifying finetune data preparation or the Message TypedDict shape.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-52d014428f0d650ed6975690.md)
