# Rules for `dspy/primitives/python_interpreter.py`

## Rule 059 — `dspy/primitives/python_interpreter.py`

- **Rule:** When modifying the Deno-backed PythonInterpreter.execute protocol, preserve the JSON-line stdin/stdout exchange, single restart on BrokenPipeError, FinalAnswer-to-output mapping, SyntaxError propagation, and InterpreterError wrapping for other errors.
- **Applies to:**
  - `dspy/primitives/python_interpreter.py`
- **Condition:** Changing the interpreter execution protocol, error handling, or restart behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5cfb0f39cc620e0cad05072e.md)

## Rule 134 — `dspy/primitives/python_interpreter.py`

- **Rule:**
  ```text
  PythonInterpreter.__exit__ must call self.shutdown() so the interpreter is torn down on context-manager exit regardless of exception type.
  ```
- **Applies to:**
  - `dspy/primitives/python_interpreter.py`
- **Condition:** When modifying PythonInterpreter context-manager exit or shutdown behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cb8b85a257b3ea82c59df64d.md)

## Rule 152 — `dspy/primitives/python_interpreter.py`

- **Rule:**
  ```text
  _sync_files must be a no-op unless both enable_write_paths and sync_files are set; otherwise it must send a JSON sync_file message mapping /sandbox/<basename> to the host path over the deno process stdin.
  ```
- **Applies to:**
  - `dspy/primitives/python_interpreter.py`
- **Condition:**
  ```text
  When modifying sandbox file synchronization or its enable_write_paths/sync_files gating.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ea4f7b62d5cd0df0e53140b6.md)
