# Rules for `dspy/signatures/signature.py`

## Rule 024 — `dspy/signatures/signature.py`

- **Rule:**
  ```text
  infer_prefix must convert attribute names to human-readable prefixes, preserving all-uppercase acronyms like HTML/API while title-casing other words and inserting underscores around digits; changes must preserve this acronym and digit handling.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When modifying infer_prefix or the attribute-name-to-prefix conversion it performs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-271636bbc35a10e488e7b3ac.md)
