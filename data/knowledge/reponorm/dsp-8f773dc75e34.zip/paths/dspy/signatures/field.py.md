# Rules for `dspy/signatures/field.py`

## Rule 037 — `dspy/signatures/field.py`

- **Rule:**
  ```text
  Field.finalize must only default prefix to inferred_prefix + ':' and desc to '${key}' when those attributes are None, never overwriting explicit values.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:** When modifying Field.finalize or adding new defaulted field attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3ac57857001876858c6427b3.md)

## Rule 048 — `dspy/signatures/field.py`

- **Rule:**
  ```text
  OldField.__eq__ must compare self.__dict__ == __value.__dict__, so field equality is based on instance dictionaries and contributors changing Field attributes must consider this equality contract.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:**
  ```text
  When modifying OldField.__eq__ or Field attributes that affect equality.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5034da76f61bd53af69e21ec.md)

## Rule 095 — `dspy/signatures/field.py`

- **Rule:**
  ```text
  Field.__init__ must accept prefix=None and defer prefix assignment until finalize; do not require a non-None prefix at construction time.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:**
  ```text
  When modifying Field construction or finalize logic, preserve the deferred-prefix contract so prefix may be None at __init__ and set later.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9721b977a1fd0f42c3c93f3d.md)

## Rule 110 — `dspy/signatures/field.py`

- **Rule:**
  ```text
  move_kwargs must route DSPY_FIELD_ARG_NAMES into json_schema_extra, route other kwargs into pydantic kwargs, copy a pydantic 'description' to dspy 'desc' only when desc is absent, and store translated constraints under json_schema_extra['constraints']; changes must preserve these routing and precedence rules.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:**
  ```text
  When modifying move_kwargs or the field kwargs translation between pydantic and dspy.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aac1fcdc27e730b0fd6774fc.md)
