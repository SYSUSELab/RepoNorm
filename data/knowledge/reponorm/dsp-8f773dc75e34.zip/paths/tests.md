# Rules for `tests`

## Rule 004 — `tests/**/*.py`

- **Rule:**
  ```text
  Ruff lint rules S101, TID252, and ARG001 are ignored for Python files under tests/**.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0797fd557acbe2ae83395e20.md)

## Rule 031 — `tests/**`

- **Rule:** The test job runs pytest over the tests/ directory via uv run -p .venv pytest -vv tests/.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-342f73b9f3cd4d314e6e076f.md)

## Rule 087 — `dspy/**/*.py`

- **Rule:** Ruff linting/formatting applies to Python files under dspy/ and tests/ as included by the include setting.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8876e3c28ccb3249fe435f00.md)

## Rule 137 — `tests/**`

- **Rule:** Setuptools package discovery excludes the tests directory and its subpackages.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ce7c1a1c4e56b152d1fe5b71.md)
