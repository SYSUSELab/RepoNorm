# Rules for `dspy`

## Rule 049 — `dspy/**`

- **Rule:** Setuptools package discovery includes the dspy package and its subpackages.
- **Applies to:**
  - `dspy/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5046935612992f8ce4fca928.md)

## Rule 087 — `dspy/**/*.py`

- **Rule:** Ruff linting/formatting applies to Python files under dspy/ and tests/ as included by the include setting.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8876e3c28ccb3249fe435f00.md)
