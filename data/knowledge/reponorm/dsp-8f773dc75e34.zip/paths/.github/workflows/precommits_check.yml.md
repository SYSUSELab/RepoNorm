# Rules for `.github/workflows/precommits_check.yml`

## Rule 044 — `.github/workflows/precommits_check.yml`

- **Rule:** The Pre-Commit Checks step installs pre-commit and runs 'pre-commit run -v --files' against the changed files.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4655559d401d7d8e9e69546a.md)

## Rule 097 — `.github/workflows/precommits_check.yml`

- **Rule:**
  ```text
  Pull request titles are checked against the regexp '(break|build|ci|docs|feat|fix|perf|refactor|style|test|ops|hotfix|release|maint|init|enh|revert)\([a-z,A-Z,0-9,\-,\_,\/,:]+\)(:)\s{1}([\w\s]+)'.
  ```
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9d23a9fa455b966e5a2ecdd0.md)
