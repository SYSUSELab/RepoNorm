# Rules for `.github/workflows/build_and_release.yml`

## Rule 019 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-22a655b249c8c042c7ee59d0.md)

## Rule 035 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-38ae78fc4afbc7813790c4f1.md)

## Rule 082 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job publishes the distribution to TestPyPI using pypa/gh-action-pypi-publish@release/v1 with repository-url https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8139cef589b1d303b6c1f06a.md)

## Rule 096 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The extract-tag job runs on ubuntu-latest and extracts the tag name from GITHUB_REF into the job output `version`.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-99dd382c9962fe41b708530c.md)

## Rule 142 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The build-and-publish-test-pypi job computes the TestPyPI version by running .github/workflows/build_utils/test_version.py with package name "dspy-ai-test" and the extracted tag version.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d4d840e6ab116a13d04eaff8.md)

## Rule 146 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-pypi job installs setuptools, wheel, twine, and build via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dd97bea9a6a2eef9c11c0691.md)

## Rule 153 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job installs setuptools, wheel, twine, build, semver, and packaging via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ea9c4aa12e32c45e4cc53faf.md)
