# Rules for `.github/workflows/build_utils/test_version.py`

## Rule 130 — `.github/workflows/build_utils/test_version.py`

- **Rule:**
  ```text
  increment_version must parse the current version with PyPIVersion, and when a pre-release component exists, reconstruct a semver.Version from release plus the joined pre tuple before calling bump_prerelease.
  ```
- **Applies to:**
  - `.github/workflows/build_utils/test_version.py`
- **Condition:** When modifying the version-bump logic that handles pre-release components.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c3aaf21218c99a021dcec7a7.md)
