# Rules for `.github/.internal_dspyai/pyproject.toml`

## Rule 020 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the version in `.github/.internal_dspyai/pyproject.toml` to the extracted tag version using a sed command targeting the `#replace_package_version_marker`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-23cf2ded2b4bbb574e539fd1.md)

## Rule 092 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the package name in `.github/.internal_dspyai/pyproject.toml` to `dspy-ai` using a sed command targeting the `#replace_package_name_marker`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-92a21c8e670ed9255858e4b3.md)

## Rule 104 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the dspy dependency in `.github/.internal_dspyai/pyproject.toml` to the extracted tag version using a sed command targeting the `#replace_dspy_version_marker`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a4a46967d04eb67a30f35c43.md)
