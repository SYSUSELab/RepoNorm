# Rules for `.github/.internal_dspyai/dist`

## Rule 038 — `.github/.internal_dspyai/dist/**`

- **Rule:**
  ```text
  The workflow publishes the dspy-ai distribution to PyPI using `pypa/gh-action-pypi-publish@release/v1` with attestations disabled and packages-dir set to `.github/.internal_dspyai/dist/`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/dist/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3b99750852773afb0ec8bb92.md)
