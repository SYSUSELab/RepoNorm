# Rules for `tests/conftest.py`

## Rule 029 — `tests/conftest.py`

- **Rule:**
  ```text
  Async tests in this repository must run under the asyncio backend via the anyio_backend fixture defined in tests/conftest.py.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** when adding or modifying async tests or the shared anyio backend fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-32f467010c83c5f564ee438a.md)

## Rule 126 — `tests/conftest.py`

- **Rule:**
  ```text
  tests/conftest.py pytest_configure must register each flag in SKIP_DEFAULT_FLAGS as a pytest marker via config.addinivalue_line, defining the repository's custom skip-marker registration convention.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  when adding or modifying pytest_configure or the SKIP_DEFAULT_FLAGS list in tests/conftest.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-be4bbf4ee6a87de0987df362.md)
