# Rules for `tests/test_utils/server/__init__.py`

## Rule 074 — `tests/test_utils/server/__init__.py`

- **Rule:**
  ```text
  _get_litellm_config_path must resolve litellm_server_config.yaml relative to the test utils server module directory, defining where the LiteLLM test server config is expected.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:**
  ```text
  when adding or modifying _get_litellm_config_path or the LiteLLM test server config location
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-70dc50e46b4890505e2e37e2.md)

## Rule 085 — `tests/test_utils/server/__init__.py`

- **Rule:**
  ```text
  The litellm_test_server fixture must start a real LiteLLM proxy subprocess on a random port with a request-log file path passed via an environment variable, wait for the port, yield (server_url, log_file_path), and kill the process on teardown.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:**
  ```text
  when modifying or extending the litellm_test_server fixture used by integration tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-874e7716940db26d0dd7758e.md)

## Rule 107 — `tests/test_utils/server/__init__.py`

- **Rule:** Server-backed tests must wait for readiness by polling host/port with socket.connect in a loop, retrying every 0.5s and raising TimeoutError naming the port and timeout on expiry.
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when adding or modifying test utilities that wait for a server to become reachable
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a8d7b3c44d1b66b26525f8e2.md)
