# Rules for `tests/test_utils/server/litellm_server.py`

## Rule 006 — `tests/test_utils/server/litellm_server.py`

- **Rule:** The litellm test server must map substrings in request message content to specific litellm exceptions: '429' to RateLimitError, '504' to Timeout, '400' to BadRequestError, and '401' to AuthenticationError.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when adding or modifying the litellm test server's error-injection behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-081480d20db0dcf6626b9deb.md)

## Rule 010 — `tests/test_utils/server/litellm_server.py`

- **Rule:** DSPyTestModel must subclass litellm's CustomLLM extension point in the litellm test server.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when defining or modifying the test model used by the litellm test server
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0cbf6123fdae9195f42c5ee0.md)

## Rule 116 — `tests/test_utils/server/litellm_server.py`

- **Rule:**
  ```text
  _append_request_to_log_file must require the LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR environment variable, raising ValueError if unset, and append a JSON blob of model and messages to the log file.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying request logging in the litellm test server
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-afb3ec70b13e0c75f364759b.md)
