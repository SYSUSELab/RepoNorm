# Rules for `tests/predict/test_predict.py`

## Rule 138 — `tests/predict/test_predict.py`

- **Rule:** Tests that exercise adapter handling of non-primitive annotated signature fields must define a custom type used for both input and output fields, because the adapter must serialize and validate non-primitive annotations on both sides.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying or adding tests for adapter handling of custom-typed signature fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cef8c52f822a146c0b0cbaa2.md)
