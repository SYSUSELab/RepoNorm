# Rules for `tests/adapters/test_tool.py`

## Rule 054 — `tests/adapters/test_tool.py`

- **Rule:** Tests that exercise tool argument parsing with nested pydantic-style inputs must assert the concrete return value produced by the tool, because nested dict arguments are parsed into model instances before invocation.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying or adding tests for Tool argument parsing with nested model/dict inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-55ad88793a34680fa64958ec.md)
