# Rules for `tests/adapters/test_code.py`

## Rule 160 — `tests/adapters/test_code.py`

- **Rule:** Tests that verify dspy.Code parsing of dirty code must assert that code.code contains only the extracted code with markdown fences and surrounding reasoning text stripped, because this extraction behavior is the parsing contract.
- **Applies to:**
  - `tests/adapters/test_code.py`
- **Condition:** When modifying or adding tests for dspy.Code parsing of code containing markdown fences or surrounding text.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fad8a1b6dc758b081b437993.md)
