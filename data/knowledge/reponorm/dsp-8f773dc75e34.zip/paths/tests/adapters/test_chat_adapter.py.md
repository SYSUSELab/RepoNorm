# Rules for `tests/adapters/test_chat_adapter.py`

## Rule 119 — `tests/adapters/test_chat_adapter.py`

- **Rule:** Tests that assert ChatAdapter.format output with tools must expect exactly two messages (a system message with the ToolCalls description and a user message with the question, tool names, and JSON-schema-like argument descriptions), because this message structure is the adapter's formatting contract.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** When modifying or adding tests for ChatAdapter.format when tools are present.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b459e01be42f96530990f209.md)
