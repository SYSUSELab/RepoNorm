# Rules for `tests/reliability/utils.py`

## Rule 018 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  Reliability test utilities must expose a known_failing_models decorator factory that takes a list of model names and returns a decorator allowing the wrapped reliability test to fail for those named models.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when adding or modifying reliability test utilities that mark tests as expected to fail for specific models
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-204cee86e2fa7c24390d2c24.md)

## Rule 026 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  parse_reliability_conf_yaml must be lru_cache'd, require model_name per model_list entry, record only entries with litellm_params, require an adapter key, and wrap any failure in a ValueError naming the config file path.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when adding or modifying reliability config parsing utilities
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-29644a209ca720295a1ba76e.md)
