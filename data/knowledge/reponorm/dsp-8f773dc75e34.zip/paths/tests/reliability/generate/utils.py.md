# Rules for `tests/reliability/generate/utils.py`

## Rule 118 — `tests/reliability/generate/utils.py`

- **Rule:** Reliability test utilities must build a program-generation program by returning dspy.ChainOfThought(ProgramGeneration), the convention for generating DSPy test programs via chain-of-thought.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying the reliability suite's program-generation helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b24808a98522aa39e0dacf30.md)

## Rule 127 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  The reliability suite's _split_schema must classify each top-level property as input only when __dspy_field_type == "input"; properties with __dspy_field_type == "output" or no field type default to outputs, so missing field-type metadata is treated as output.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when adding or modifying _split_schema or its callers in the reliability suite
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-c15f6d020c00826002a2ec29.md)

## Rule 135 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  The reliability test suite's program-loading helper _import_program_module_from_path must temporarily prepend the program's directory to sys.path, load the module via importlib.util.spec_from_file_location, and execute it.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying the reliability suite's program-loading helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc41345c7ba37f7d839d4741.md)

## Rule 144 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  _clean_json_schema_property must recursively strip desc, __dspy_field_type, title, prefix, and required keys from nested properties to produce the canonical cleaned schema shape.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying reliability schema-cleaning helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-da77f61bd5902af08b458d0c.md)

## Rule 151 — `tests/reliability/generate/utils.py`

- **Rule:** Reliability schema helpers must fully dereference signature JSON schemas by popping $defs and expanding refs before validation.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying reliability test helpers that prepare signature JSON schemas for validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e160aa4b31f91f3e80211d12.md)

## Rule 161 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  For nested properties, _split_schema must recurse and reattach nested inputs only when the parent field type is input, and nested outputs when the parent is output or has no field type, preserving the parent's cleaned schema alongside nested properties.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when adding or modifying _split_schema handling of nested properties in the reliability suite
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fc5fd27b838bda8848752319.md)
