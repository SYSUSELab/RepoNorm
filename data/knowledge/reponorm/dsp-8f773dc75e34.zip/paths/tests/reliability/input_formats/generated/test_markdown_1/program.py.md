# Rules for `tests/reliability/input_formats/generated/test_markdown_1/program.py`

## Rule 102 — `tests/reliability/input_formats/generated/test_markdown_1/program.py`

- **Rule:**
  ```text
  The generated markdown program must build its signature by appending dspy.InputField/OutputField entries derived from Pydantic model_fields, using input_field.description for both input and output descriptions, defining the generated-program construction pattern.
  ```
- **Applies to:**
  - `tests/reliability/input_formats/generated/test_markdown_1/program.py`
- **Condition:**
  ```text
  When adding or modifying generated markdown programs that construct signatures from Pydantic model_fields.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../claims/CLAIM-a3af496e9bd289c6ade0872c.md)
