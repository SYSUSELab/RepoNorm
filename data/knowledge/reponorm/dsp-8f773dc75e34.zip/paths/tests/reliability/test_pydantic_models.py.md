# Rules for `tests/reliability/test_pydantic_models.py`

## Rule 045 — `tests/reliability/test_pydantic_models.py`

- **Rule:** The reliability test suite must define a Colorful Signature with a str input and a Color output field to exercise Pydantic enum output handling.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying the reliability test that exercises Pydantic enum output handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-46b62f40c8a9b6fc3072ac59.md)

## Rule 084 — `tests/reliability/test_pydantic_models.py`

- **Rule:**
  ```text
  Reliability tests using pydantic answer models must assert answer.certainty is within [0,1] and len(answer.comments) >= 2, and grade both answer.value and answer.comments via assert_program_output_correct.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying reliability tests that use the pydantic answer model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-86d0789ec6f6c1e0aa16ff8b.md)
