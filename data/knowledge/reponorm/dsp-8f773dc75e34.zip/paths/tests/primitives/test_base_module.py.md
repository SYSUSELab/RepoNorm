# Rules for `tests/primitives/test_base_module.py`

## Rule 055 — `tests/primitives/test_base_module.py`

- **Rule:** Tests that verify per-predictor history recording under concurrency must assert history length on the program, its sub-predictors, and its chain-of-thought predictor after parallel execution, because history is recorded per predictor rather than only at the module level.
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When modifying or adding tests that exercise module history under concurrent execution (e.g., dspy.Parallel).
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-587ea1af4bcaf5c9f1b87463.md)
