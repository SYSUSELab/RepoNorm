# Rules for `tests/primitives/test_example.py`

## Rule 109 — `tests/primitives/test_example.py`

- **Rule:** Tests that assert exact string representations of core primitives (such as Example repr/str) must treat the asserted string as a stable display contract and update the assertion deliberately when the primitive's formatting changes.
- **Applies to:**
  - `tests/primitives/test_example.py`
- **Condition:** When modifying the repr or str implementation of a core primitive that has an exact-string assertion in its test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aa986e42dea82ed906a79b69.md)
