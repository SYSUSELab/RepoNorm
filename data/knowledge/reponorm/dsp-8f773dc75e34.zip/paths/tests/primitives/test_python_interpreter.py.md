# Rules for `tests/primitives/test_python_interpreter.py`

## Rule 093 — `tests/primitives/test_python_interpreter.py`

- **Rule:** Tests that assert captured stdout from PythonInterpreter.execute must expect the trailing newline produced by print, because execute returns raw captured stdout rather than stripped output.
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** When modifying or adding tests that assert the return value of PythonInterpreter.execute for code that prints.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-95093830dd53529e64428f7b.md)
