# Rules for `tests/utils/test_saving.py`

## Rule 025 — `tests/utils/test_saving.py`

- **Rule:** Tests that save and load user-defined dspy.Module subclasses must define a CustomModel subclass of dspy.Module and exercise save/load behavior on it, not only on built-in modules.
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when adding or modifying a test that saves and loads a user-defined dspy.Module subclass
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-28ef588596dd19881ca38c6d.md)

## Rule 069 — `tests/utils/test_saving.py`

- **Rule:** Tests that load a saved Predict with mismatched python/dspy/cloudpickle versions must assert that exactly three 'There is a mismatch of' warnings are logged and that a Predict with an equal signature still loads.
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when adding or modifying a test that loads a saved Predict with mismatched python/dspy/cloudpickle versions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6cf7c374ec204b1aa9f323fd.md)

## Rule 157 — `tests/utils/test_saving.py`

- **Rule:**
  ```text
  Tests that save and load a dspy.Predict with save_program=True must assert that metadata.json and program.pkl are produced and that dspy.load returns a dspy.Predict whose signature equals the original's.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:**
  ```text
  when adding or modifying a test that saves and loads a dspy.Predict with save_program=True
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f3d37718b0222c245297685c.md)
