# Rules for `tests/utils/test_asyncify.py`

## Rule 070 — `tests/utils/test_asyncify.py`

- **Rule:**
  ```text
  Asyncify tests must launch n concurrent ask_the_question coroutines via asyncio.gather to exercise concurrent async behavior.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** when adding or modifying asyncify tests that exercise concurrent async behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6dc698ef7e573062b0d65eac.md)

## Rule 105 — `tests/utils/test_asyncify.py`

- **Rule:**
  ```text
  Asyncify tests must assert that total runtime for number_of_tasks with async_max_workers=capacity falls strictly between floor(number_of_tasks/capacity)*wait and ceil(number_of_tasks/capacity)*wait + 2*wait, encoding the expected asyncify concurrency bound.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** when adding or modifying asyncify tests that verify concurrency bounds
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a58abc0a2f3d18302f406cb7.md)
