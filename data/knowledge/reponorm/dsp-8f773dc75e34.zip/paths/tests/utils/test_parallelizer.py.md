# Rules for `tests/utils/test_parallelizer.py`

## Rule 034 — `tests/utils/test_parallelizer.py`

- **Rule:** Parallelizer tests must inject a deterministic single-item failure by raising ValueError only for item 3, to exercise error propagation.
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** when adding or modifying parallelizer tests that exercise error propagation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3827cebae8d38a8f109d4843.md)
