# Rules for `tests/utils/test_settings.py`

## Rule 005 — `tests/utils/test_settings.py`

- **Rule:** Tests that run dspy.context inside thread workers must assert that after the workers finish, dspy.settings.lm.model and callbacks remain those configured by the outer dspy.configure, proving thread workers do not leak context changes.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that runs dspy.context inside a ThreadPoolExecutor or other thread workers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-07b12a0ff8d0ca66661bce18.md)

## Rule 046 — `tests/utils/test_settings.py`

- **Rule:** Settings tests must verify that dspy.settings.lm.model equals the model of the LM entered via dspy.context, confirming context-scoped LM overrides are visible inside the context.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying settings tests that verify context-scoped LM overrides
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-46c39bcff588dd42970eb320.md)

## Rule 068 — `tests/utils/test_settings.py`

- **Rule:** Tests for dspy.context must assert context-local isolation of the selected LM and trace, verifying dspy.settings.lm.model and dspy.settings.trace reflect only the context's values.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying tests that verify dspy.context isolates LM selection and trace state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6c6405ff72b9500384d3b269.md)

## Rule 086 — `tests/utils/test_settings.py`

- **Rule:** Tests that exercise dspy.context in a different async task from the initial one must enter dspy.context with an LM inside an async function, since dspy.context is allowed in different async tasks from the initial one.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that uses dspy.context inside an async task other than the initial one
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8802b6b21bfbdb30f5e47929.md)

## Rule 121 — `tests/utils/test_settings.py`

- **Rule:** Tests that exercise dspy.configure thread/task restrictions must assert that configure is forbidden in child threads while remaining callable repeatedly in the same async task and usable via dspy.context in other tasks.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying tests covering dspy.configure call-site restrictions across threads and async tasks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b8237e583a6c7e1ef448cbe9.md)
