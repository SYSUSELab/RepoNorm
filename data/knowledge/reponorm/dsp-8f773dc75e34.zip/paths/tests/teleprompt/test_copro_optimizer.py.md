# Rules for `tests/teleprompt/test_copro_optimizer.py`

## Rule 120 — `tests/teleprompt/test_copro_optimizer.py`

- **Rule:**
  ```text
  Tests that verify COPRO statistics tracking must assert that the optimized student receives total_calls and results_best attributes when track_stats is enabled, because these attributes are the observable contract of the statistics-tracking feature.
  ```
- **Applies to:**
  - `tests/teleprompt/test_copro_optimizer.py`
- **Condition:** When modifying or adding tests for COPRO optimizer statistics tracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b68c6be3c1b09951df58491d.md)
