# Rules for `repository root`

## Rule 014 — `**/*.py`

- **Rule:**
  ```text
  The project declares requires-python = ">=3.10, <3.14".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-17b3b57a1f231ca309836083.md)

## Rule 015 — `**/*.py`

- **Rule:** Ruff's formatter is configured to use double quotes for strings (quote-style = "double").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1c715382a389f2a45c3f5a2a.md)

## Rule 016 — `**`

- **Rule:** Contributors are recommended to open an issue (if one doesn't already exist) and discuss proposed changes before making any changes.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-1d9852be7dd14073f722be78.md)

## Rule 021 — `**/*.py`

- **Rule:** Python 3.10 or later is required for the DSPy development environment.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-23e543c507971cdfa49a8d34.md)

## Rule 027 — `**/*.py`

- **Rule:** Ruff linting ignores rules B027, FBT003, C901, E501, UP035, RUF005, B904, F403, E721, UP031, and RUF022.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-298c1d04965e1b174960c7d2.md)

## Rule 067 — `**`

- **Rule:** The pre-commit configuration enables the check-toml, check-merge-conflict, and debug-statements hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-68e5f2bc569ab90a3e27ce6f.md)

## Rule 099 — `**/*.py`

- **Rule:** Ruff's formatter is configured to use automatic line-ending detection (line-ending = "auto").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9f9e605eb69b0fe81ae2d0eb.md)

## Rule 100 — `**/*.py`

- **Rule:** Ruff's flake8-tidy-imports rule bans all relative imports.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3551c1311ad27f84a2e93dd.md)

## Rule 103 — `**`

- **Rule:** Pre-commit installs only the pre-commit hook type by default.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a476048e67bea72ff86e039f.md)

## Rule 112 — `**/*.py`

- **Rule:** Ruff's formatter is configured to indent with spaces (indent-style = "space").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ad834c437d44a9c3bbe2db34.md)

## Rule 123 — `**`

- **Rule:**
  ```text
  The workflow publishes the dspy distribution to PyPI using `pypa/gh-action-pypi-publish@release/v1` with attestations disabled.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bbf60ebfeb3d6d0cda670706.md)

## Rule 128 — `**/__init__.py`

- **Rule:**
  ```text
  Ruff lint rule F401 is ignored for __init__.py files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c2cf7189d2e6c01df366f887.md)

## Rule 133 — `**/*.py`

- **Rule:** Ruff's formatter is configured not to skip magic trailing commas (skip-magic-trailing-comma = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca5f361695bcd78bc95dd4ce.md)

## Rule 139 — `**/*.py`

- **Rule:** Ruff's formatter is configured not to format code inside docstrings (docstring-code-format = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cf7ecf7c718282b5cfaac987.md)

## Rule 143 — `**/*.py`

- **Rule:** Ruff linting selects the rule sets E, W, F, I, C, B, UP, N, RUF, and Q.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-d94ba2d1400e1e181c9073f8.md)

## Rule 147 — `**`

- **Rule:**
  ```text
  The release workflow builds a binary wheel by running `python3 -m build`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df06c6c4f5657c42868c97fe.md)

## Rule 156 — `**/*.py`

- **Rule:**
  ```text
  Ruff's isort lint rule treats the `dspy` package as first-party when classifying imports.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ef1403e771bf3c7098217a50.md)
