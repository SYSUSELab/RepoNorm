# Rules for `docs/scripts/generate_api_docs.py`

## Rule 007 — `docs/scripts/generate_api_docs.py`

- **Rule:** When generating API documentation pages with mkdocstrings, emit the ::: directive as the last line of the page content so that the generated HTML does not leave an unclosed div.
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Modifying the API documentation page generator that emits mkdocstrings ::: directives.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-094d2dbd8104fdde5fa297a9.md)
