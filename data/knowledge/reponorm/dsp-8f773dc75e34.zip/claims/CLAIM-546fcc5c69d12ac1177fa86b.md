# Rule details

- **Rule:**
  ```text
  When modifying SignatureOptimizer in dspy/teleprompt/signature_opt.py, preserve the deprecation boundary: __init__ must print a red warning that SignatureOptimizer is deprecated in favor of COPRO and will be removed in a future release before delegating to the superclass initializer.
  ```
- **Applies to:**
  - `dspy/teleprompt/signature_opt.py`
- **Condition:** When changing SignatureOptimizer initialization or its deprecation messaging.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
SignatureOptimizer.__init__ prints the red deprecation warning naming COPRO as the replacement and future removal, then delegates to super().__init__, preserving the deprecation boundary.
```

- **Sources:**
  - `dspy/teleprompt/signature_opt.py:36-49`
