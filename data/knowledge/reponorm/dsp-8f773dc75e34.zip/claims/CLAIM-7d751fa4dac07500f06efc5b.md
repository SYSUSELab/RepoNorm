# Rule details

- **Rule:**
  ```text
  Bootstrap module design constraints must be preserved: metrics should be bool-like/sortable, some example sets are intentionally not shuffled, and max_rounds via branch_idx is used to bypass cache rather than only temperature.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap.py`
- **Condition:** When modifying bootstrap metric handling, example shuffling, or cache-bypass logic.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The bootstrap module comments document that metrics should be bool-like/sortable, that some example sets are intentionally not shuffled, and that max_rounds via branch_idx bypasses cache rather than only temperature.
```

- **Sources:**
  - `dspy/teleprompt/bootstrap.py`
