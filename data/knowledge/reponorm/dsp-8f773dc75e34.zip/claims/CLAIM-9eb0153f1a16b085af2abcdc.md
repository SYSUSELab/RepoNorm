# Rule details

- **Rule:**
  ```text
  When modifying the FAISS index construction in Embeddings._build_faiss, preserve the derived partition count int(2*sqrt(len(corpus))), the 32-byte PQ code configuration with 8-bit subquantizers, and nprobe = min(16, partitions); when faiss is unavailable, raise ImportError that advises installing faiss-cpu or raising brute_force_threshold rather than silently degrading.
  ```
- **Applies to:**
  - `dspy/retrievers/embeddings.py`
- **Condition:** When changing FAISS index construction or the missing-faiss fallback path in the embeddings retriever.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Embeddings._build_faiss preserves the derived partition count, 32-byte PQ configuration with 8-bit subquantizers, and nprobe = min(16, partitions), matching the FAISS construction invariants.
```

- **Sources:**
  - `dspy/retrievers/embeddings.py:52-73`
