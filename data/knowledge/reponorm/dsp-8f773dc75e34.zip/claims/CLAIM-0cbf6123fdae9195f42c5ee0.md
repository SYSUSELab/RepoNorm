# Rule details

- **Rule:** DSPyTestModel must subclass litellm's CustomLLM extension point in the litellm test server.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when defining or modifying the test model used by the litellm test server
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
DSPyTestModel is defined as a class inheriting from litellm's CustomLLM extension point in the litellm test server, satisfying the rule.
```

- **Sources:**
  - `tests/test_utils/server/litellm_server.py`
