# Rule details

- **Rule:**
  ```text
  wrapped_program must isolate each program call inside dspy.context(trace=[]) and then copy dspy.settings.trace, so the returned trace reflects only that call's trace rather than accumulated global trace state.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:**
  ```text
  When modifying wrapped_program or any code that captures trace state around a program call.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
wrapped_program isolates the call inside dspy.context(trace=[]) and copies dspy.settings.trace, so the returned trace reflects only that call.
```

- **Sources:**
  - `dspy/teleprompt/simba_utils.py:23-43`
