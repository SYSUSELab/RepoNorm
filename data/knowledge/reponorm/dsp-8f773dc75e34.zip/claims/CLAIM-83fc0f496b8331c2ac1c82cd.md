# Rule details

- **Rule:** ScoreWithFeedback is a Prediction subclass with typed fields score: float and feedback: str, so GEPA feedback results are expected to carry both a numeric score and textual feedback.
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:** When modifying ScoreWithFeedback or the GEPA feedback result schema.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
ScoreWithFeedback subclasses Prediction with typed fields score: float and feedback: str, matching the GEPA feedback result schema.
```

- **Sources:**
  - `dspy/teleprompt/gepa/gepa_utils.py:24-26`
