# Rule details

- **Rule:**
  ```text
  The workflow tests the locally built wheel by activating the test environment, installing `dist/*.whl` with pytest and pytest-asyncio, running `pytest tests/metadata/test_metadata.py tests/predict`, then deactivating and removing the test environment.
  ```
- **Applies to:**
  - `tests/metadata/test_metadata.py`
  - `tests/predict/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Test package installation and functionality
        run: |
          source test_before_pypi/bin/activate
          # Install the locally built wheel and testing dependencies
          pip install dist/*.whl pytest pytest-asyncio
          pytest tests/metadata/test_metadata.py tests/predict
          deactivate
          rm -r test_before_pypi

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:99-106`
