# Rule details

- **Rule:** Tests that exercise dspy.configure thread/task restrictions must assert that configure is forbidden in child threads while remaining callable repeatedly in the same async task and usable via dspy.context in other tasks.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying tests covering dspy.configure call-site restrictions across threads and async tasks
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_forbid_configure_call_in_child_thread asserts dspy.configure raises RuntimeError in a child thread, and test_dspy_configure_allowance_async asserts repeated configure in the same async task and context allowance in other tasks.
```

- **Sources:**
  - `tests/utils/test_settings.py`
