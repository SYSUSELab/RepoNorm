# Rule details

- **Rule:** Tests that exercise adapter handling of non-primitive annotated signature fields must define a custom type used for both input and output fields, because the adapter must serialize and validate non-primitive annotations on both sides.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying or adding tests for adapter handling of custom-typed signature fields.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test file defines signatures using custom non-primitive types on both input and output sides (e.g., Item used for items input and translated_items output; TimedEvent for events input and next_event_time output), matching the both-sides custom-type invariant.
```

- **Sources:**
  - `tests/predict/test_predict.py`
