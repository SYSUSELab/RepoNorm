# Rule details

- **Rule:**
  ```text
  train_test_split must validate train_size/test_size as either a float proportion in (0,1) or an int absolute count, raising ValueError otherwise; when test_size is omitted it is derived as the remainder, and train_size+test_size exceeding the dataset length is rejected.
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  When modifying DataLoader.train_test_split, preserve the float/int size validation, ValueError on invalid types, remainder derivation when test_size is omitted, and rejection of sizes exceeding dataset length.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
train_test_split validates train_size/test_size as float proportion or int count with ValueError otherwise, derives test_size as remainder when omitted, and rejects sizes exceeding dataset length, matching the rule.
```

- **Sources:**
  - `dspy/datasets/dataloader.py:152-198`
