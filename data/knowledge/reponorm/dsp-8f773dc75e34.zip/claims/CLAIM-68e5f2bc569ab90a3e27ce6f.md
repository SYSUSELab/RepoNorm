# Rule details

- **Rule:** The pre-commit configuration enables the check-toml, check-merge-conflict, and debug-statements hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: check-toml

```

- **Sources:**
  - `.pre-commit-config.yaml:24`

### Evidence 2 — explicit

```text
      - id: check-merge-conflict

```

- **Sources:**
  - `.pre-commit-config.yaml:27`

### Evidence 3 — explicit

```text
      - id: debug-statements

```

- **Sources:**
  - `.pre-commit-config.yaml:28`
