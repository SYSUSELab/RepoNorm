# Rule details

- **Rule:**
  ```text
  _clean_json_schema_property must recursively strip desc, __dspy_field_type, title, prefix, and required keys from nested properties to produce the canonical cleaned schema shape.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying reliability schema-cleaning helpers
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The file defines _clean_json_schema_property, which recursively strips desc, __dspy_field_type, title, prefix, and required keys from each property dict including nested properties, matching the canonical cleaning rule.
```

- **Sources:**
  - `tests/reliability/generate/utils.py`
