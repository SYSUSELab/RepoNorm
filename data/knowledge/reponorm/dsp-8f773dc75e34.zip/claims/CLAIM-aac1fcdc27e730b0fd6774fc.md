# Rule details

- **Rule:**
  ```text
  move_kwargs must route DSPY_FIELD_ARG_NAMES into json_schema_extra, route other kwargs into pydantic kwargs, copy a pydantic 'description' to dspy 'desc' only when desc is absent, and store translated constraints under json_schema_extra['constraints']; changes must preserve these routing and precedence rules.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:**
  ```text
  When modifying move_kwargs or the field kwargs translation between pydantic and dspy.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
move_kwargs routes DSPY_FIELD_ARG_NAMES to json_schema_extra, other kwargs to pydantic kwargs, copies description to desc only when desc is absent, and stores constraints under json_schema_extra['constraints'].
```

- **Sources:**
  - `dspy/signatures/field.py:20-40`
