# Rule details

- **Rule:**
  ```text
  BestOfN.forward must build a deduplicated temperature schedule from the LM's configured temperature, deep-copy the module per attempt, stop early when reward meets threshold, retry on exception until fail_count is exhausted before re-raising, and extend the best trace into dspy.settings.trace.
  ```
- **Applies to:**
  - `dspy/predict/best_of_n.py`
- **Condition:** When modifying BestOfN.forward attempt scheduling, retry, or trace handling.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
BestOfN.forward builds a deduplicated temperature schedule from the LM temperature, deep-copies the module per attempt, stops early when reward meets threshold, retries on exception until fail_count is exhausted before re-raising, and extends the best trace into dspy.settings.trace.
```

- **Sources:**
  - `dspy/predict/best_of_n.py:54-87`
