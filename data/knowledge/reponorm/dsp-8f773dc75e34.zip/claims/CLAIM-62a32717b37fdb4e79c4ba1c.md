# Rule details

- **Rule:**
  ```text
  GEPA feedback functions must return the same score as the module's score; make_reflective_dataset asserts this equality and rejects mismatched feedback scores.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  when modifying DspyAdapter.make_reflective_dataset or any GEPA feedback function that produces scores
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
make_reflective_dataset asserts that the feedback function's score equals the module's score, enforcing the GEPA feedback score equality rule.
```

- **Sources:**
  - `dspy/teleprompt/gepa/gepa_utils.py:126-231`
