# Rule details

- **Rule:**
  ```text
  thread_safe_evaluator must run process_example over the devset with a ThreadPoolExecutor sized by num_threads or dspy.settings.num_threads, accumulate scores, and return either the average metric or (avg_metric, results) when return_outputs is set.
  ```
- **Applies to:**
  - `dspy/teleprompt/avatar_optimizer.py`
- **Condition:**
  ```text
  When modifying thread_safe_evaluator concurrency sizing or return shape.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
thread_safe_evaluator runs process_example over the devset with a ThreadPoolExecutor sized by num_threads or dspy.settings.num_threads, accumulates scores, and returns the average metric or (avg_metric, results) when return_outputs is set.
```

- **Sources:**
  - `dspy/teleprompt/avatar_optimizer.py:122-145`
