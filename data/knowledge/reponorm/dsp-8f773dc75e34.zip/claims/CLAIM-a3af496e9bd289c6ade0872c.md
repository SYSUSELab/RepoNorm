# Rule details

- **Rule:**
  ```text
  The generated markdown program must build its signature by appending dspy.InputField/OutputField entries derived from Pydantic model_fields, using input_field.description for both input and output descriptions, defining the generated-program construction pattern.
  ```
- **Applies to:**
  - `tests/reliability/input_formats/generated/test_markdown_1/program.py`
- **Condition:**
  ```text
  When adding or modifying generated markdown programs that construct signatures from Pydantic model_fields.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The generated program builds its signature by appending dspy.InputField/OutputField entries derived from ProgramInputs/ProgramOutputs model_fields, using input_field.description for both input and output descriptions, matching the construction pattern.
```

- **Sources:**
  - `tests/reliability/input_formats/generated/test_markdown_1/program.py`
