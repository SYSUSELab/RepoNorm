# Rule details

- **Rule:**
  ```text
  Reliability test input generation programs must be built as dspy.ChainOfThought over the _TestInputsGeneration signature.
  ```
- **Applies to:**
  - `tests/reliability/generate/**/*.py`
- **Condition:** when constructing a program to generate reliability test inputs
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_get_test_inputs_generation_program returns dspy.ChainOfThought over the _TestInputsGeneration signature, matching the required test-input generation convention.
```

- **Sources:**
  - `tests/reliability/generate/utils.py`
