# Rule details

- **Rule:**
  ```text
  sync_send_to_stream._send must await stream.send(message), using an async send protocol to push messages onto a stream.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  When modifying sync_send_to_stream._send or its async send protocol.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
sync_send_to_stream._send is an async function whose body awaits stream.send(message), matching the required async send protocol.
```

- **Sources:**
  - `dspy/streaming/messages.py:30-31`
