# Rule details

- **Rule:**
  ```text
  When modifying Image.__repr__, preserve base64 payload redaction: base64 data must be summarized by encoded length and image type rather than printed verbatim, while non-base64 URLs remain shown verbatim.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  Changing how Image.__repr__ formats or logs image content.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Image.__repr__ redacts base64 payloads by reporting encoded length and image type while rendering non-base64 URLs verbatim, matching the redaction rule.
```

- **Sources:**
  - `dspy/adapters/types/image.py:69-74`
