# Rule details

- **Rule:** GEPA candidate instruction strings are applied by deep-copying the student program and replacing each named predictor's signature instructions with the candidate string; the original program must not be mutated.
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  When modifying DspyAdapter.build_program or the candidate-to-program application path.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
build_program deep-copies the student program and replaces each named predictor's signature instructions with the candidate string, leaving the original program unmutated.
```

- **Sources:**
  - `dspy/teleprompt/gepa/gepa_utils.py:74-79`
