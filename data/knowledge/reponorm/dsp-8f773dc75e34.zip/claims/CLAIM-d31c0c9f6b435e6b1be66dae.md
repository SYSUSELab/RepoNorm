# Rule details

- **Rule:**
  ```text
  DataLoader.from_parquet must load the parquet file as the 'train' split, default the field list to all dataset features when none are supplied, and wrap each row in dspy.Example.with_inputs(*input_keys).
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  When modifying DataLoader.from_parquet or its parquet-loading helpers.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
DataLoader.from_parquet loads the parquet file as the 'train' split, defaults fields to all dataset features when none are given, and wraps each row in dspy.Example.with_inputs(*input_keys).
```

- **Sources:**
  - `dspy/datasets/dataloader.py:106-119`
