# Rule details

- **Rule:**
  ```text
  Reliability tests using pydantic answer models must assert answer.certainty is within [0,1] and len(answer.comments) >= 2, and grade both answer.value and answer.comments via assert_program_output_correct.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying reliability tests that use the pydantic answer model
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_qa_with_pydantic_answer_model asserts answer.certainty within [0,1] and len(answer.comments) >= 2, and grades answer.value and answer.comments via assert_program_output_correct.
```

- **Sources:**
  - `tests/reliability/test_pydantic_models.py`
