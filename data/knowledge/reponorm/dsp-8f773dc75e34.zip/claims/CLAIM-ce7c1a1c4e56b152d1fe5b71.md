# Rule details

- **Rule:** Setuptools package discovery excludes the tests directory and its subpackages.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
exclude = ["tests", "tests.*"]

```

- **Sources:**
  - `pyproject.toml:76`
