# Rule details

- **Rule:** Tests that verify per-predictor history recording under concurrency must assert history length on the program, its sub-predictors, and its chain-of-thought predictor after parallel execution, because history is recorded per predictor rather than only at the module level.
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When modifying or adding tests that exercise module history under concurrent execution (e.g., dspy.Parallel).
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_module_history_with_concurrency runs the program through dspy.Parallel and asserts history length on the program, its cot, and its predict, matching the per-predictor history invariant.
```

- **Sources:**
  - `tests/primitives/test_base_module.py`
