# Rule details

- **Rule:**
  ```text
  tests/conftest.py pytest_configure must register each flag in SKIP_DEFAULT_FLAGS as a pytest marker via config.addinivalue_line, defining the repository's custom skip-marker registration convention.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  when adding or modifying pytest_configure or the SKIP_DEFAULT_FLAGS list in tests/conftest.py
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/conftest.py pytest_configure iterates SKIP_DEFAULT_FLAGS and registers each flag as a pytest marker via config.addinivalue_line, matching the rule.
```

- **Sources:**
  - `tests/conftest.py`
