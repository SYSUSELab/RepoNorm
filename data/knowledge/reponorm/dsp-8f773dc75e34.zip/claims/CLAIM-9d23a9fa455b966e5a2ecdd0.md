# Rule details

- **Rule:**
  ```text
  Pull request titles are checked against the regexp '(break|build|ci|docs|feat|fix|perf|refactor|style|test|ops|hotfix|release|maint|init|enh|revert)\([a-z,A-Z,0-9,\-,\_,\/,:]+\)(:)\s{1}([\w\s]+)'.
  ```
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Check Pull Request Title
        uses: Slashgear/action-check-pr-title@main
        with:
          regexp: '(break|build|ci|docs|feat|fix|perf|refactor|style|test|ops|hotfix|release|maint|init|enh|revert)\([a-z,A-Z,0-9,\-,\_,\/,:]+\)(:)\s{1}([\w\s]+)' # Regex the title should match.

```

- **Sources:**
  - `.github/workflows/precommits_check.yml:15-18`
