# Rule details

- **Rule:**
  ```text
  _sync_files must be a no-op unless both enable_write_paths and sync_files are set; otherwise it must send a JSON sync_file message mapping /sandbox/<basename> to the host path over the deno process stdin.
  ```
- **Applies to:**
  - `dspy/primitives/python_interpreter.py`
- **Condition:**
  ```text
  When modifying sandbox file synchronization or its enable_write_paths/sync_files gating.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
PythonInterpreter._sync_files is a no-op unless enable_write_paths and sync_files are set, and otherwise sends a JSON sync_file message mapping /sandbox/<basename> to the host path over deno stdin.
```

- **Sources:**
  - `dspy/primitives/python_interpreter.py:108-118`
