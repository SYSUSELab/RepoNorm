# Rule details

- **Rule:**
  ```text
  PythonInterpreter.__exit__ must call self.shutdown() so the interpreter is torn down on context-manager exit regardless of exception type.
  ```
- **Applies to:**
  - `dspy/primitives/python_interpreter.py`
- **Condition:** When modifying PythonInterpreter context-manager exit or shutdown behavior.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
PythonInterpreter.__exit__ calls self.shutdown(), tearing down the interpreter on context-manager exit regardless of exception type.
```

- **Sources:**
  - `dspy/primitives/python_interpreter.py:224-230`
