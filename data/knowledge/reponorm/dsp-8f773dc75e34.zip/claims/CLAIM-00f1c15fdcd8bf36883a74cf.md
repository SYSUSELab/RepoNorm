# Rule details

- **Rule:**
  ```text
  `to_dict` serializes GEPA state including candidates, parents, scores, per-instance best candidates (converted to lists), eval counts, log_dir, seed, and best_idx, defining the persisted state schema.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  When modifying DspyGEPAResult.to_dict or the persisted GEPA state schema.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
DspyGEPAResult.to_dict serializes candidates, parents, val_aggregate_scores, best_outputs_valset, val_subscores, per_val_instance_best_candidates as lists, discovery_eval_counts, total_metric_calls, num_full_val_evals, log_dir, seed, and best_idx, preserving the persisted state schema.
```

- **Sources:**
  - `dspy/teleprompt/gepa/gepa.py:99-118`
