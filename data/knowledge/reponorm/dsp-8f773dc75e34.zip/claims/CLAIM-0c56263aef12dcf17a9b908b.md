# Rule details

- **Rule:**
  ```text
  The ruff-check hook excludes dspy/__metadata__.py and files under tests/reliability/ from its file selection.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        exclude: ^(dspy/__metadata__\.py|tests/reliability/.*\.py)$

```

- **Sources:**
  - `.pre-commit-config.yaml:16`
