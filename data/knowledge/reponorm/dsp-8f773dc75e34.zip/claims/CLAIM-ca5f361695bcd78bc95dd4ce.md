# Rule details

- **Rule:** Ruff's formatter is configured not to skip magic trailing commas (skip-magic-trailing-comma = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
skip-magic-trailing-comma = false

```

- **Sources:**
  - `pyproject.toml:163`
