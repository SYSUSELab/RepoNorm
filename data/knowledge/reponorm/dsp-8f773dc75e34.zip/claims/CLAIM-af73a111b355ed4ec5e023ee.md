# Rule details

- **Rule:**
  ```text
  When modifying the GenerateSingleModuleInstruction signature in dspy/propose/grounded_proposer.py, gate InputFields consistently with the constructor flags use_dataset_summary, program_aware, use_instruct_history, and use_tip so the prompt schema varies per configuration as intended.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:** When adding or changing InputFields on GenerateSingleModuleInstruction or its constructor flags.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
GenerateSingleModuleInstruction conditionally includes InputFields gated by the constructor flags use_dataset_summary, program_aware, use_instruct_history, and use_tip, preserving the flag-gated prompt schema.
```

- **Sources:**
  - `dspy/propose/grounded_proposer.py:82-130`
