# Rule details

- **Rule:** Tests that run dspy.context inside thread workers must assert that after the workers finish, dspy.settings.lm.model and callbacks remain those configured by the outer dspy.configure, proving thread workers do not leak context changes.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that runs dspy.context inside a ThreadPoolExecutor or other thread workers
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_dspy_context_parallel runs dspy.context inside ThreadPoolExecutor workers and asserts after completion that dspy.settings.lm.model and callbacks remain those from the outer dspy.configure, proving thread isolation.
```

- **Sources:**
  - `tests/utils/test_settings.py`
