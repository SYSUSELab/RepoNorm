# Rule details

- **Rule:**
  ```text
  _append_request_to_log_file must require the LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR environment variable, raising ValueError if unset, and append a JSON blob of model and messages to the log file.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying request logging in the litellm test server
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_append_request_to_log_file requires LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR, raises ValueError if unset, and appends a JSON blob of model and messages.
```

- **Sources:**
  - `tests/test_utils/server/litellm_server.py`
