# Rule details

- **Rule:**
  ```text
  Asyncify tests must launch n concurrent ask_the_question coroutines via asyncio.gather to exercise concurrent async behavior.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** when adding or modifying asyncify tests that exercise concurrent async behavior
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
run_n_tasks uses asyncio.gather to launch n concurrent ask_the_question coroutines.
```

- **Sources:**
  - `tests/utils/test_asyncify.py`
