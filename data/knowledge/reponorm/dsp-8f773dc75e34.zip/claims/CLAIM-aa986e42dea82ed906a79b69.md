# Rule details

- **Rule:** Tests that assert exact string representations of core primitives (such as Example repr/str) must treat the asserted string as a stable display contract and update the assertion deliberately when the primitive's formatting changes.
- **Applies to:**
  - `tests/primitives/test_example.py`
- **Condition:** When modifying the repr or str implementation of a core primitive that has an exact-string assertion in its test.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test file contains exact-string assertions comparing repr() and str() of Example to literal strings, pinning the display contract.
```

- **Sources:**
  - `tests/primitives/test_example.py`
