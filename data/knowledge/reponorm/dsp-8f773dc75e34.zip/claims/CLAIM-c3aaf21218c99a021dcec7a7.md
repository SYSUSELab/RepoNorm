# Rule details

- **Rule:**
  ```text
  increment_version must parse the current version with PyPIVersion, and when a pre-release component exists, reconstruct a semver.Version from release plus the joined pre tuple before calling bump_prerelease.
  ```
- **Applies to:**
  - `.github/workflows/build_utils/test_version.py`
- **Condition:** When modifying the version-bump logic that handles pre-release components.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
increment_version parses with PyPIVersion and, when a pre-release exists, reconstructs semver.Version from release plus the joined pre tuple before bump_prerelease.
```

- **Sources:**
  - `.github/workflows/build_utils/test_version.py:36-44`
