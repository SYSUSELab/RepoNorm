# Rule details

- **Rule:**
  ```text
  When modifying prepare_models_for_resampling, preserve the temperature schedule: n LM copies start from the base LM's temperature followed by 0.5 + i*(0.5/n), deduplicated while preserving order and truncated to n.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:** Changing how resampling model copies or their temperatures are constructed.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
prepare_models_for_resampling still builds n copies starting from the base LM temperature followed by 0.5 + i*(0.5/n), deduplicated in order via dict.fromkeys and truncated to n, preserving the temperature schedule.
```

- **Sources:**
  - `dspy/teleprompt/simba_utils.py:15-19`
