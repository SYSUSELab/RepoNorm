# Rule details

- **Rule:**
  ```text
  Asyncify tests must assert that total runtime for number_of_tasks with async_max_workers=capacity falls strictly between floor(number_of_tasks/capacity)*wait and ceil(number_of_tasks/capacity)*wait + 2*wait, encoding the expected asyncify concurrency bound.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** when adding or modifying asyncify tests that verify concurrency bounds
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
verify_asyncify asserts total runtime falls strictly between floor(number_of_tasks/capacity)*wait and ceil(number_of_tasks/capacity)*wait + 2*wait.
```

- **Sources:**
  - `tests/utils/test_asyncify.py`
