# Rule details

- **Rule:**
  ```text
  Ruff lint rules I001, E402, and F405 are ignored for dspy/__init__.py.
  ```
- **Applies to:**
  - `dspy/__init__.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
"dspy/__init__.py" = [
    "I001",  # Allow unsorted or unformatted imports (isort)
    "E402",  # Allow imports not at the top of the file (needed for certain __init__ patterns)
    "F405",  # Allow undefined names from wildcard imports (common in __init__ files)
]

```

- **Sources:**
  - `pyproject.toml:179-183`
