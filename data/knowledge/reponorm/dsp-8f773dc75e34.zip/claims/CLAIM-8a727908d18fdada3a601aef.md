# Rule details

- **Rule:**
  ```text
  create_predictor_level_history_string must load trial programs from program_path, aggregate and average scores per instruction, deduplicate instructions, sort by average score descending, take the top N, reverse the list, and format each entry as 'instruction | Score: score'.
  ```
- **Applies to:**
  - `dspy/propose/utils.py`
- **Condition:** When modifying predictor-level history aggregation or its output formatting.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
create_predictor_level_history_string loads trial programs, aggregates and averages scores per instruction, deduplicates, sorts descending, takes top N, reverses, and formats as 'instruction | Score: score'.
```

- **Sources:**
  - `dspy/propose/utils.py:78-127`
