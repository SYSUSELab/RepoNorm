# Full rule catalog

## Rule 051 — `dspy/teleprompt/gepa/gepa.py`

- **Rule:**
  ```text
  GEPA's DspyGEPAResult.best_candidate must be a property returning the candidate dict at best_idx, so callers read it without invoking a method and best_idx must remain valid.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  when modifying DspyGEPAResult.best_candidate or best_idx maintenance
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-514f728aa3b1ce0a0f6f5566.md)

## Rule 052 — `dspy/clients/utils_finetune.py`

- **Rule:** The finetune utilities must define a Message TypedDict whose role is constrained to the literals 'user', 'assistant', or 'system' and whose content is a string, establishing the canonical chat message shape used by finetune data preparation.
- **Applies to:**
  - `dspy/clients/utils_finetune.py`
- **Condition:** When modifying finetune data preparation or the Message TypedDict shape.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-52d014428f0d650ed6975690.md)

## Rule 053 — `dspy/teleprompt/signature_opt.py`

- **Rule:**
  ```text
  When modifying SignatureOptimizer in dspy/teleprompt/signature_opt.py, preserve the deprecation boundary: __init__ must print a red warning that SignatureOptimizer is deprecated in favor of COPRO and will be removed in a future release before delegating to the superclass initializer.
  ```
- **Applies to:**
  - `dspy/teleprompt/signature_opt.py`
- **Condition:** When changing SignatureOptimizer initialization or its deprecation messaging.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-546fcc5c69d12ac1177fa86b.md)

## Rule 054 — `tests/adapters/test_tool.py`

- **Rule:** Tests that exercise tool argument parsing with nested pydantic-style inputs must assert the concrete return value produced by the tool, because nested dict arguments are parsed into model instances before invocation.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** When modifying or adding tests for Tool argument parsing with nested model/dict inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-55ad88793a34680fa64958ec.md)

## Rule 055 — `tests/primitives/test_base_module.py`

- **Rule:** Tests that verify per-predictor history recording under concurrency must assert history length on the program, its sub-predictors, and its chain-of-thought predictor after parallel execution, because history is recorded per predictor rather than only at the module level.
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When modifying or adding tests that exercise module history under concurrent execution (e.g., dspy.Parallel).
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-587ea1af4bcaf5c9f1b87463.md)

## Rule 056 — `dspy/datasets/alfworld/alfworld.py`

- **Rule:**
  ```text
  EnvPool must be used as a pool of processes each with a unique env_worker, acquired via a context manager session; callers must use 'with pool.session() as sess' and then call init/step on the session rather than on the pool directly.
  ```
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** When modifying EnvPool or any caller that acquires and uses an environment session.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5a3c464ffd65395f7e16105c.md)

## Rule 057 — `dspy/teleprompt/simba_utils.py`

- **Rule:** Program execution and metric evaluation exceptions must be swallowed and printed, leaving prediction as None and score as 0.0; downstream bucketing and strategy code must tolerate failed predictions and zero scores.
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:**
  ```text
  When modifying wrapped_program or any downstream bucketing/strategy code that consumes its prediction and score outputs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5a90140812633d3e58c583cb.md)

## Rule 058 — `dspy/dsp/utils/dpr.py`

- **Rule:** The dpr utils module must retain its vendored DPR provenance and instantiate a module-level STokenizer = SimpleTokenizer().
- **Applies to:**
  - `dspy/dsp/utils/dpr.py`
- **Condition:** When modifying the dpr utils module or its tokenizer instantiation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5ca1e1c6d02d956002b2130d.md)

## Rule 059 — `dspy/primitives/python_interpreter.py`

- **Rule:** When modifying the Deno-backed PythonInterpreter.execute protocol, preserve the JSON-line stdin/stdout exchange, single restart on BrokenPipeError, FinalAnswer-to-output mapping, SyntaxError propagation, and InterpreterError wrapping for other errors.
- **Applies to:**
  - `dspy/primitives/python_interpreter.py`
- **Condition:** Changing the interpreter execution protocol, error handling, or restart behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5cfb0f39cc620e0cad05072e.md)

## Rule 060 — `dspy/teleprompt/gepa/gepa.py`

- **Rule:**
  ```text
  best_idx returns the index of the maximum value in val_aggregate_scores, so ties resolve to the first highest-scoring index.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  When modifying DspyGEPAResult.best_idx or its tie-breaking behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5e561eff8e69e6f33ed80aa5.md)

## Rule 061 — `dspy/datasets/alfworld/alfworld.py`

- **Rule:**
  ```text
  _EnvSession.__init__ must store an EnvPool and initialize wid, inq, and outq to None, deferring per-environment worker state acquisition until later.
  ```
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:**
  ```text
  When modifying _EnvSession construction or AlfWorld environment setup, preserve storing the EnvPool and initializing wid, inq, and outq to None rather than acquiring worker state at construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-61ae42a7f3b9530ed638bb16.md)

## Rule 062 — `dspy/teleprompt/gepa/gepa_utils.py`

- **Rule:**
  ```text
  GEPA feedback functions must return the same score as the module's score; make_reflective_dataset asserts this equality and rejects mismatched feedback scores.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  when modifying DspyAdapter.make_reflective_dataset or any GEPA feedback function that produces scores
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-62a32717b37fdb4e79c4ba1c.md)

## Rule 063 — `dspy/streaming/messages.py`

- **Rule:**
  ```text
  sync_send_to_stream._send must await stream.send(message), using an async send protocol to push messages onto a stream.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  When modifying sync_send_to_stream._send or its async send protocol.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-62f036eeef35c7ff9b053c82.md)

## Rule 064 — `tests/reliability/complex_types/generated/test_many_types_1/program.py`

- **Rule:** Generated reliability test programs must build their dspy signature dynamically by iterating over the Pydantic input/output model fields and appending dspy.InputField/OutputField entries, so the program signature mirrors the Pydantic models.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
- **Condition:** When modifying or regenerating reliability test programs that pair Pydantic input/output models with a dspy signature.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-64e14ae8761739557b68e685.md)
