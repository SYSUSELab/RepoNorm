# Full rule catalog

## Rule 125 — `dspy/datasets/dataloader.py`

- **Rule:**
  ```text
  train_test_split must validate train_size/test_size as either a float proportion in (0,1) or an int absolute count, raising ValueError otherwise; when test_size is omitted it is derived as the remainder, and train_size+test_size exceeding the dataset length is rejected.
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  When modifying DataLoader.train_test_split, preserve the float/int size validation, ValueError on invalid types, remainder derivation when test_size is omitted, and rejection of sizes exceeding dataset length.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bc8f354673b0d0b87ca2aa9f.md)

## Rule 126 — `tests/conftest.py`

- **Rule:**
  ```text
  tests/conftest.py pytest_configure must register each flag in SKIP_DEFAULT_FLAGS as a pytest marker via config.addinivalue_line, defining the repository's custom skip-marker registration convention.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  when adding or modifying pytest_configure or the SKIP_DEFAULT_FLAGS list in tests/conftest.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-be4bbf4ee6a87de0987df362.md)

## Rule 127 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  The reliability suite's _split_schema must classify each top-level property as input only when __dspy_field_type == "input"; properties with __dspy_field_type == "output" or no field type default to outputs, so missing field-type metadata is treated as output.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when adding or modifying _split_schema or its callers in the reliability suite
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c15f6d020c00826002a2ec29.md)

## Rule 128 — `**/__init__.py`

- **Rule:**
  ```text
  Ruff lint rule F401 is ignored for __init__.py files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c2cf7189d2e6c01df366f887.md)

## Rule 129 — `dspy/dsp/colbertv2.py`

- **Rule:**
  ```text
  ColBERTv2RetrieverLocal.get_index must attempt to import colbert and print an installation hint on ImportError, then import Searcher and Run/RunConfig and construct a Searcher within a Run context using the required RunConfig experiment/index/collection parameters.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:**
  ```text
  When modifying ColBERTv2RetrieverLocal.get_index or its colbert optional-dependency handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c2f2f498318844c9522a0a9e.md)

## Rule 130 — `.github/workflows/build_utils/test_version.py`

- **Rule:**
  ```text
  increment_version must parse the current version with PyPIVersion, and when a pre-release component exists, reconstruct a semver.Version from release plus the joined pre tuple before calling bump_prerelease.
  ```
- **Applies to:**
  - `.github/workflows/build_utils/test_version.py`
- **Condition:** When modifying the version-bump logic that handles pre-release components.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c3aaf21218c99a021dcec7a7.md)

## Rule 131 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config sets num_retries to 0.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c61a5e8707925dde8f120777.md)

## Rule 132 — `tests/reliability/generate/__main__.py`

- **Rule:**
  ```text
  The reliability generate CLI must expose required `--dst_path` and optional `--num_inputs` (default 1), `--program_instructions`, and `--input_instructions`, forwarding them to `generate_test_cases`.
  ```
- **Applies to:**
  - `tests/reliability/generate/__main__.py`
- **Condition:**
  ```text
  When modifying the reliability generate CLI entry point, preserve the required `--dst_path` argument and optional arguments with their defaults, forwarding to `generate_test_cases`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c66c6bb37d17ef76521fe99d.md)

## Rule 133 — `**/*.py`

- **Rule:** Ruff's formatter is configured not to skip magic trailing commas (skip-magic-trailing-comma = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca5f361695bcd78bc95dd4ce.md)

## Rule 134 — `dspy/primitives/python_interpreter.py`

- **Rule:**
  ```text
  PythonInterpreter.__exit__ must call self.shutdown() so the interpreter is torn down on context-manager exit regardless of exception type.
  ```
- **Applies to:**
  - `dspy/primitives/python_interpreter.py`
- **Condition:** When modifying PythonInterpreter context-manager exit or shutdown behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cb8b85a257b3ea82c59df64d.md)

## Rule 135 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  The reliability test suite's program-loading helper _import_program_module_from_path must temporarily prepend the program's directory to sys.path, load the module via importlib.util.spec_from_file_location, and execute it.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying the reliability suite's program-loading helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc41345c7ba37f7d839d4741.md)

## Rule 136 — `dspy/datasets/math.py`

- **Rule:**
  ```text
  MATH.metric must require the external math_equivalence package and raise an ImportError with the install command when it is missing; changes must preserve this optional-dependency guard and its actionable error message.
  ```
- **Applies to:**
  - `dspy/datasets/math.py`
- **Condition:**
  ```text
  When modifying MATH.metric or its dependency handling for the math_equivalence package.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cde748d043912216fdd574fb.md)

## Rule 137 — `tests/**`

- **Rule:** Setuptools package discovery excludes the tests directory and its subpackages.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ce7c1a1c4e56b152d1fe5b71.md)

## Rule 138 — `tests/predict/test_predict.py`

- **Rule:** Tests that exercise adapter handling of non-primitive annotated signature fields must define a custom type used for both input and output fields, because the adapter must serialize and validate non-primitive annotations on both sides.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** When modifying or adding tests for adapter handling of custom-typed signature fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cef8c52f822a146c0b0cbaa2.md)

## Rule 139 — `**/*.py`

- **Rule:** Ruff's formatter is configured not to format code inside docstrings (docstring-code-format = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cf7ecf7c718282b5cfaac987.md)

## Rule 140 — `dspy/datasets/dataloader.py`

- **Rule:**
  ```text
  DataLoader.from_parquet must load the parquet file as the 'train' split, default the field list to all dataset features when none are supplied, and wrap each row in dspy.Example.with_inputs(*input_keys).
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  When modifying DataLoader.from_parquet or its parquet-loading helpers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d31c0c9f6b435e6b1be66dae.md)
