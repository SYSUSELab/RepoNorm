# Full rule catalog

## Rule 065 — `dspy/dsp/utils/utils.py`

- **Rule:**
  ```text
  timestamp(daydir=True) must produce a date-directory format using '/' separators, while daydir=False must use '-' and '_' separators, so callers relying on path layout must account for this branch.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:** When modifying timestamp formatting or callers that depend on its path layout.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-656b3dd191eba039653c7e7a.md)

## Rule 066 — `.github/workflows/build_utils/test_version.py`

- **Rule:**
  ```text
  get_latest_version must treat a missing tag_version release as not needing increment (return tag_version, False), and when the tag exists return the latest uploaded version with increment True; a 404 response also means no increment.
  ```
- **Applies to:**
  - `.github/workflows/build_utils/test_version.py`
- **Condition:** When modifying the logic that determines whether a version increment is needed based on release existence.
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Detail:** [Open claim details](../claims/CLAIM-68df99a49456ac460a1054a6.md)

## Rule 067 — `**`

- **Rule:** The pre-commit configuration enables the check-toml, check-merge-conflict, and debug-statements hooks.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-68e5f2bc569ab90a3e27ce6f.md)

## Rule 068 — `tests/utils/test_settings.py`

- **Rule:** Tests for dspy.context must assert context-local isolation of the selected LM and trace, verifying dspy.settings.lm.model and dspy.settings.trace reflect only the context's values.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying tests that verify dspy.context isolates LM selection and trace state
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6c6405ff72b9500384d3b269.md)

## Rule 069 — `tests/utils/test_saving.py`

- **Rule:** Tests that load a saved Predict with mismatched python/dspy/cloudpickle versions must assert that exactly three 'There is a mismatch of' warnings are logged and that a Predict with an equal signature still loads.
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when adding or modifying a test that loads a saved Predict with mismatched python/dspy/cloudpickle versions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6cf7c374ec204b1aa9f323fd.md)

## Rule 070 — `tests/utils/test_asyncify.py`

- **Rule:**
  ```text
  Asyncify tests must launch n concurrent ask_the_question coroutines via asyncio.gather to exercise concurrent async behavior.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** when adding or modifying asyncify tests that exercise concurrent async behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6dc698ef7e573062b0d65eac.md)

## Rule 071 — `dspy/adapters/types/__init__.py`

- **Rule:**
  ```text
  When adding a new adapter type to the adapters.types package, both the imports and the __all__ list must be updated so the type is publicly available.
  ```
- **Applies to:**
  - `dspy/adapters/types/__init__.py`
- **Condition:** Adding or removing a public adapter type in the adapters.types package.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6ea45f0e2631e20cf123b40c.md)

## Rule 072 — `dspy/teleprompt/gepa/gepa_utils.py`

- **Rule:**
  ```text
  The gepa_utils module defines DspyAdapter as a GEPAAdapter parameterized over Example, TraceData, and Prediction, establishing the adapter contract between DSPy programs and the GEPA optimizer.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:** When modifying DspyAdapter or the adapter contract between DSPy programs and the GEPA optimizer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6f3f2580663cc10f2a08ea14.md)

## Rule 073 — `dspy/adapters/types/image.py`

- **Rule:**
  ```text
  When modifying Image.__repr__, preserve base64 payload redaction: base64 data must be summarized by encoded length and image type rather than printed verbatim, while non-base64 URLs remain shown verbatim.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  Changing how Image.__repr__ formats or logs image content.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6ff0a45c15482ab99f4d38fb.md)

## Rule 074 — `tests/test_utils/server/__init__.py`

- **Rule:**
  ```text
  _get_litellm_config_path must resolve litellm_server_config.yaml relative to the test utils server module directory, defining where the LiteLLM test server config is expected.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:**
  ```text
  when adding or modifying _get_litellm_config_path or the LiteLLM test server config location
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-70dc50e46b4890505e2e37e2.md)

## Rule 075 — `dspy/teleprompt/gepa/gepa_utils.py`

- **Rule:**
  ```text
  When a prediction is a `FailedPrediction`, the reflective dataset builds a structure instruction from `ChatAdapter().format(...)` and sets Feedback to a parse-failure message, defining the fallback feedback path for unparseable outputs.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  When modifying DspyAdapter.make_reflective_dataset or the fallback feedback path for unparseable outputs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-71ec3f928a6d37474242fc3b.md)

## Rule 076 — `dspy/teleprompt/gepa/gepa_utils.py`

- **Rule:**
  ```text
  The GEPA feedback callable protocol requires a __call__ accepting predictor_output, predictor_inputs, module_inputs, module_outputs, and captured_trace, and returning a ScoreWithFeedback; captured_trace is shaped as a list of (Predictor, PredictorInputs, Prediction) tuples.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  When modifying PredictorFeedbackFn.__call__ or the GEPA feedback callable protocol.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-722e683590107e3a22974fd1.md)

## Rule 077 — `dspy/teleprompt/gepa/gepa_utils.py`

- **Rule:** GEPA candidate instruction strings are applied by deep-copying the student program and replacing each named predictor's signature instructions with the candidate string; the original program must not be mutated.
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  When modifying DspyAdapter.build_program or the candidate-to-program application path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7b2e7f7f659be7d755a752bb.md)

## Rule 078 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model-2" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7b5ebc4fdd4b5180f876187c.md)

## Rule 079 — `tests/metadata/test_metadata.py`

- **Rule:**
  ```text
  The workflow tests the locally built wheel by activating the test environment, installing `dist/*.whl` with pytest and pytest-asyncio, running `pytest tests/metadata/test_metadata.py tests/predict`, then deactivating and removing the test environment.
  ```
- **Applies to:**
  - `tests/metadata/test_metadata.py`
  - `tests/predict/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7b628a278bab76db5ae55d8a.md)
