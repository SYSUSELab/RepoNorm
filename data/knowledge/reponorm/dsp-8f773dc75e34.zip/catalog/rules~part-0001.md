# Full rule catalog

## Rule 001 — `dspy/teleprompt/gepa/gepa.py`

- **Rule:**
  ```text
  `to_dict` serializes GEPA state including candidates, parents, scores, per-instance best candidates (converted to lists), eval counts, log_dir, seed, and best_idx, defining the persisted state schema.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  When modifying DspyGEPAResult.to_dict or the persisted GEPA state schema.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-00f1c15fdcd8bf36883a74cf.md)

## Rule 002 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  The build-and-publish-pypi job rewrites __version__ in ./dspy/__metadata__.py after the #replace_package_version_marker line using the extracted tag version.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-01dc8d3cd21b9a57b9dbbc1e.md)

## Rule 003 — `dspy/teleprompt/gepa/gepa_utils.py`

- **Rule:**
  ```text
  gepa_utils defines DSPyTrace as list[tuple[Any, dict[str, Any], Prediction]] and carries a TODO noting the DSPyAdapter currently uses GEPA's default propose_new_texts rather than a MIPROv2-style instruction proposal.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  When modifying the DSPyTrace type alias or the instruction proposal path in gepa_utils.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-039c8f3aefc639255324d1dc.md)

## Rule 004 — `tests/**/*.py`

- **Rule:**
  ```text
  Ruff lint rules S101, TID252, and ARG001 are ignored for Python files under tests/**.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0797fd557acbe2ae83395e20.md)

## Rule 005 — `tests/utils/test_settings.py`

- **Rule:** Tests that run dspy.context inside thread workers must assert that after the workers finish, dspy.settings.lm.model and callbacks remain those configured by the outer dspy.configure, proving thread workers do not leak context changes.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that runs dspy.context inside a ThreadPoolExecutor or other thread workers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-07b12a0ff8d0ca66661bce18.md)

## Rule 006 — `tests/test_utils/server/litellm_server.py`

- **Rule:** The litellm test server must map substrings in request message content to specific litellm exceptions: '429' to RateLimitError, '504' to Timeout, '400' to BadRequestError, and '401' to AuthenticationError.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when adding or modifying the litellm test server's error-injection behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-081480d20db0dcf6626b9deb.md)

## Rule 007 — `docs/scripts/generate_api_docs.py`

- **Rule:** When generating API documentation pages with mkdocstrings, emit the ::: directive as the last line of the page content so that the generated HTML does not leave an unclosed div.
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:** Modifying the API documentation page generator that emits mkdocstrings ::: directives.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-094d2dbd8104fdde5fa297a9.md)

## Rule 008 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  The ruff-check hook excludes dspy/__metadata__.py and files under tests/reliability/ from its file selection.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c56263aef12dcf17a9b908b.md)

## Rule 009 — `dspy/teleprompt/avatar_optimizer.py`

- **Rule:**
  ```text
  thread_safe_evaluator must run process_example over the devset with a ThreadPoolExecutor sized by num_threads or dspy.settings.num_threads, accumulate scores, and return either the average metric or (avg_metric, results) when return_outputs is set.
  ```
- **Applies to:**
  - `dspy/teleprompt/avatar_optimizer.py`
- **Condition:**
  ```text
  When modifying thread_safe_evaluator concurrency sizing or return shape.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0cbe125bbcea3e35b302fa84.md)

## Rule 010 — `tests/test_utils/server/litellm_server.py`

- **Rule:** DSPyTestModel must subclass litellm's CustomLLM extension point in the litellm test server.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when defining or modifying the test model used by the litellm test server
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0cbf6123fdae9195f42c5ee0.md)

## Rule 011 — `dspy/teleprompt/simba_utils.py`

- **Rule:**
  ```text
  append_a_demo_ must truncate input values longer than demo_input_field_maxlen with a '<TRUNCATED FOR BREVITY>' marker and keep only the last demo per predictor.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:**
  ```text
  When modifying append_a_demo_ or its demo-augmentation truncation behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0edf95039b5bda45c78956b7.md)

## Rule 012 — `dspy/clients/cache.py`

- **Rule:** When modifying the two-level cache in dspy/clients/cache.py, preserve the ordering and layering: an in-memory cachetools.LRUCache consulted before an on-disk diskcache.FanoutCache, so that in-memory hits short-circuit disk access.
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:** When changing cache lookup, storage, or eviction behavior in the Cache class.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0fe430d6131dcebd873b0725.md)

## Rule 013 — `tests/metadata/test_metadata.py`

- **Rule:**
  ```text
  The build-and-publish-test-pypi job creates a venv named test_before_testpypi, installs the locally built wheel plus pytest and pytest-asyncio, and runs `pytest tests/metadata/test_metadata.py tests/predict`.
  ```
- **Applies to:**
  - `tests/metadata/test_metadata.py`
  - `tests/predict/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1446fb3682a8374d02215ba9.md)

## Rule 014 — `**/*.py`

- **Rule:**
  ```text
  The project declares requires-python = ">=3.10, <3.14".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-17b3b57a1f231ca309836083.md)

## Rule 015 — `**/*.py`

- **Rule:** Ruff's formatter is configured to use double quotes for strings (quote-style = "double").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1c715382a389f2a45c3f5a2a.md)

## Rule 016 — `**`

- **Rule:** Contributors are recommended to open an issue (if one doesn't already exist) and discuss proposed changes before making any changes.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-1d9852be7dd14073f722be78.md)

## Rule 017 — `dspy/teleprompt/gepa/gepa_utils.py`

- **Rule:**
  ```text
  GEPA's evaluate uses bootstrap_trace_data with capture_failed_parses=True and failure_score when capture_traces is set, and otherwise runs Evaluate with max_errors=len(batch)*100 and return_all_scores=True, defining the two evaluation paths and their error tolerances.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:** When modifying DspyAdapter.evaluate or the GEPA evaluation paths and error tolerances.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1e572cad5fd2e751f9293953.md)
