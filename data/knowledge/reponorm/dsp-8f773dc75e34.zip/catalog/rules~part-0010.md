# Full rule catalog

## Rule 141 — `dspy/predict/aggregation.py`

- **Rule:**
  ```text
  When modifying default_normalize, preserve that it returns normalize_text(s) or None, so empty or falsy normalized text becomes None.
  ```
- **Applies to:**
  - `dspy/predict/aggregation.py`
- **Condition:** Changing normalization behavior for aggregation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d386a096325508ef329245cb.md)

## Rule 142 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The build-and-publish-test-pypi job computes the TestPyPI version by running .github/workflows/build_utils/test_version.py with package name "dspy-ai-test" and the extracted tag version.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d4d840e6ab116a13d04eaff8.md)

## Rule 143 — `**/*.py`

- **Rule:** Ruff linting selects the rule sets E, W, F, I, C, B, UP, N, RUF, and Q.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-d94ba2d1400e1e181c9073f8.md)

## Rule 144 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  _clean_json_schema_property must recursively strip desc, __dspy_field_type, title, prefix, and required keys from nested properties to produce the canonical cleaned schema shape.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying reliability schema-cleaning helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-da77f61bd5902af08b458d0c.md)

## Rule 145 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dd70a4415be506c37a3d0d02.md)

## Rule 146 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-pypi job installs setuptools, wheel, twine, and build via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dd97bea9a6a2eef9c11c0691.md)

## Rule 147 — `**`

- **Rule:**
  ```text
  The release workflow builds a binary wheel by running `python3 -m build`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df06c6c4f5657c42868c97fe.md)

## Rule 148 — `dspy/clients/openai.py`

- **Rule:**
  ```text
  When modifying TrainingJobOpenAI.__init__, preserve per-client provider job/file tracking state by initializing provider_file_id and provider_job_id to None.
  ```
- **Applies to:**
  - `dspy/clients/openai.py`
- **Condition:** Changing OpenAI client initialization or provider job/file tracking state.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df119a7721ba135431450d55.md)

## Rule 149 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  Ruff excludes dspy/__metadata__.py and tests/reliability/*.py from its checks.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df1497a7451cab7de547a4ca.md)

## Rule 150 — `dspy/teleprompt/gepa/gepa.py`

- **Rule:**
  ```text
  DspyGEPAResult is a frozen dataclass whose fields (candidates, parents, val_aggregate_scores, val_subscores, per_val_instance_best_candidates, discovery_eval_counts, best_outputs_valset, total_metric_calls, num_full_val_evals, log_dir, seed) define the public result contract of GEPA optimization runs.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:** When modifying DspyGEPAResult fields or its frozen dataclass contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e12eec3e9a2c6b13a6448218.md)

## Rule 151 — `tests/reliability/generate/utils.py`

- **Rule:** Reliability schema helpers must fully dereference signature JSON schemas by popping $defs and expanding refs before validation.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying reliability test helpers that prepare signature JSON schemas for validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e160aa4b31f91f3e80211d12.md)

## Rule 152 — `dspy/primitives/python_interpreter.py`

- **Rule:**
  ```text
  _sync_files must be a no-op unless both enable_write_paths and sync_files are set; otherwise it must send a JSON sync_file message mapping /sandbox/<basename> to the host path over the deno process stdin.
  ```
- **Applies to:**
  - `dspy/primitives/python_interpreter.py`
- **Condition:**
  ```text
  When modifying sandbox file synchronization or its enable_write_paths/sync_files gating.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ea4f7b62d5cd0df0e53140b6.md)

## Rule 153 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job installs setuptools, wheel, twine, build, semver, and packaging via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ea9c4aa12e32c45e4cc53faf.md)

## Rule 154 — `dspy/teleprompt/simba_utils.py`

- **Rule:**
  ```text
  wrapped_program must isolate each program call inside dspy.context(trace=[]) and then copy dspy.settings.trace, so the returned trace reflects only that call's trace rather than accumulated global trace state.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:**
  ```text
  When modifying wrapped_program or any code that captures trace state around a program call.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ebc46b57ec3193dc11e22efd.md)

## Rule 155 — `dspy/teleprompt/gepa/gepa_utils.py`

- **Rule:**
  ```text
  GEPA's DspyAdapter must store student, metric_fn, feedback_map, failure_score, num_threads, add_format_failure_as_feedback, and rng, defaulting rng to random.Random(0) and caching named_predictors from the student module.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:**
  ```text
  when modifying DspyAdapter.__init__ or its stored configuration fields
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ec3723393a11d0ece7b34f18.md)

## Rule 156 — `**/*.py`

- **Rule:**
  ```text
  Ruff's isort lint rule treats the `dspy` package as first-party when classifying imports.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ef1403e771bf3c7098217a50.md)

## Rule 157 — `tests/utils/test_saving.py`

- **Rule:**
  ```text
  Tests that save and load a dspy.Predict with save_program=True must assert that metadata.json and program.pkl are produced and that dspy.load returns a dspy.Predict whose signature equals the original's.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:**
  ```text
  when adding or modifying a test that saves and loads a dspy.Predict with save_program=True
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f3d37718b0222c245297685c.md)
