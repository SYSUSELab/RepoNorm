# Full rule catalog

## Rule 095 — `dspy/signatures/field.py`

- **Rule:**
  ```text
  Field.__init__ must accept prefix=None and defer prefix assignment until finalize; do not require a non-None prefix at construction time.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:**
  ```text
  When modifying Field construction or finalize logic, preserve the deferred-prefix contract so prefix may be None at __init__ and set later.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9721b977a1fd0f42c3c93f3d.md)

## Rule 096 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The extract-tag job runs on ubuntu-latest and extracts the tag name from GITHUB_REF into the job output `version`.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-99dd382c9962fe41b708530c.md)

## Rule 097 — `.github/workflows/precommits_check.yml`

- **Rule:**
  ```text
  Pull request titles are checked against the regexp '(break|build|ci|docs|feat|fix|perf|refactor|style|test|ops|hotfix|release|maint|init|enh|revert)\([a-z,A-Z,0-9,\-,\_,\/,:]+\)(:)\s{1}([\w\s]+)'.
  ```
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9d23a9fa455b966e5a2ecdd0.md)

## Rule 098 — `dspy/retrievers/embeddings.py`

- **Rule:**
  ```text
  When modifying the FAISS index construction in Embeddings._build_faiss, preserve the derived partition count int(2*sqrt(len(corpus))), the 32-byte PQ code configuration with 8-bit subquantizers, and nprobe = min(16, partitions); when faiss is unavailable, raise ImportError that advises installing faiss-cpu or raising brute_force_threshold rather than silently degrading.
  ```
- **Applies to:**
  - `dspy/retrievers/embeddings.py`
- **Condition:** When changing FAISS index construction or the missing-faiss fallback path in the embeddings retriever.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9eb0153f1a16b085af2abcdc.md)

## Rule 099 — `**/*.py`

- **Rule:** Ruff's formatter is configured to use automatic line-ending detection (line-ending = "auto").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9f9e605eb69b0fe81ae2d0eb.md)

## Rule 100 — `**/*.py`

- **Rule:** Ruff's flake8-tidy-imports rule bans all relative imports.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3551c1311ad27f84a2e93dd.md)

## Rule 101 — `dspy/datasets/alfworld/alfworld.py`

- **Rule:** AlfWorld step(action) must communicate via queues: it puts ("step", action) on self.inq and returns self.outq.get(), defining the request/response protocol for environment stepping; changes must preserve this queue-based protocol.
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:**
  ```text
  When modifying _EnvSession.step or the queue-based communication between the session and its worker process.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3a89987029c5caf68de408c.md)

## Rule 102 — `tests/reliability/input_formats/generated/test_markdown_1/program.py`

- **Rule:**
  ```text
  The generated markdown program must build its signature by appending dspy.InputField/OutputField entries derived from Pydantic model_fields, using input_field.description for both input and output descriptions, defining the generated-program construction pattern.
  ```
- **Applies to:**
  - `tests/reliability/input_formats/generated/test_markdown_1/program.py`
- **Condition:**
  ```text
  When adding or modifying generated markdown programs that construct signatures from Pydantic model_fields.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3af496e9bd289c6ade0872c.md)

## Rule 103 — `**`

- **Rule:** Pre-commit installs only the pre-commit hook type by default.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a476048e67bea72ff86e039f.md)

## Rule 104 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the dspy dependency in `.github/.internal_dspyai/pyproject.toml` to the extracted tag version using a sed command targeting the `#replace_dspy_version_marker`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a4a46967d04eb67a30f35c43.md)

## Rule 105 — `tests/utils/test_asyncify.py`

- **Rule:**
  ```text
  Asyncify tests must assert that total runtime for number_of_tasks with async_max_workers=capacity falls strictly between floor(number_of_tasks/capacity)*wait and ceil(number_of_tasks/capacity)*wait + 2*wait, encoding the expected asyncify concurrency bound.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** when adding or modifying asyncify tests that verify concurrency bounds
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a58abc0a2f3d18302f406cb7.md)

## Rule 106 — `dspy/adapters/__init__.py`

- **Rule:**
  ```text
  When changing dspy.adapters' public surface, keep the exported adapter types (Adapter, ChatAdapter, JSONAdapter, XMLAdapter, TwoStepAdapter, Type, History, Image, Audio, Code, Tool, ToolCalls) listed in __all__ so the supported adapter API remains importable.
  ```
- **Applies to:**
  - `dspy/adapters/__init__.py`
- **Condition:** Modifying the dspy.adapters package exports or adding/removing adapter types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a6aeaf3b96bf43cd27c5e593.md)

## Rule 107 — `tests/test_utils/server/__init__.py`

- **Rule:** Server-backed tests must wait for readiness by polling host/port with socket.connect in a loop, retrying every 0.5s and raising TimeoutError naming the port and timeout on expiry.
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when adding or modifying test utilities that wait for a server to become reachable
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a8d7b3c44d1b66b26525f8e2.md)

## Rule 108 — `dspy/clients/lm.py`

- **Rule:**
  ```text
  When modifying stream_completion, preserve that it calls litellm.acompletion with stream=True, attaches caller_predict_id to each chunk for stream listeners, forwards chunks via stream.send, and returns litellm.stream_chunk_builder over collected chunks.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** Changing the streaming completion path or chunk forwarding behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aa3908fac7c1594152d45dc6.md)

## Rule 109 — `tests/primitives/test_example.py`

- **Rule:** Tests that assert exact string representations of core primitives (such as Example repr/str) must treat the asserted string as a stable display contract and update the assertion deliberately when the primitive's formatting changes.
- **Applies to:**
  - `tests/primitives/test_example.py`
- **Condition:** When modifying the repr or str implementation of a core primitive that has an exact-string assertion in its test.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aa986e42dea82ed906a79b69.md)
