# Full rule catalog

## Rule 018 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  Reliability test utilities must expose a known_failing_models decorator factory that takes a list of model names and returns a decorator allowing the wrapped reliability test to fail for those named models.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when adding or modifying reliability test utilities that mark tests as expected to fail for specific models
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-204cee86e2fa7c24390d2c24.md)

## Rule 019 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-22a655b249c8c042c7ee59d0.md)

## Rule 020 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the version in `.github/.internal_dspyai/pyproject.toml` to the extracted tag version using a sed command targeting the `#replace_package_version_marker`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-23cf2ded2b4bbb574e539fd1.md)

## Rule 021 — `**/*.py`

- **Rule:** Python 3.10 or later is required for the DSPy development environment.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-23e543c507971cdfa49a8d34.md)

## Rule 022 — `dspy/clients/databricks.py`

- **Rule:**
  ```text
  TrainingJobDatabricks.status must require the databricks_genai package and raise an ImportError with an install hint when it is missing, and must return None when no finetuning run is set.
  ```
- **Applies to:**
  - `dspy/clients/databricks.py`
- **Condition:** When modifying TrainingJobDatabricks.status or its optional-dependency handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-243726a98f6153e399e83ca2.md)

## Rule 023 — `dspy/clients/lm.py`

- **Rule:**
  ```text
  When modifying litellm_completion, preserve default no-cache/no-store behavior, exponential_backoff_retry usage, and delegation to the stream completion function when one is configured.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:**
  ```text
  Changing litellm_completion defaults, retry behavior, or streaming delegation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-24c17e9ebf1319994a0c92d7.md)

## Rule 024 — `dspy/signatures/signature.py`

- **Rule:**
  ```text
  infer_prefix must convert attribute names to human-readable prefixes, preserving all-uppercase acronyms like HTML/API while title-casing other words and inserting underscores around digits; changes must preserve this acronym and digit handling.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When modifying infer_prefix or the attribute-name-to-prefix conversion it performs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-271636bbc35a10e488e7b3ac.md)

## Rule 025 — `tests/utils/test_saving.py`

- **Rule:** Tests that save and load user-defined dspy.Module subclasses must define a CustomModel subclass of dspy.Module and exercise save/load behavior on it, not only on built-in modules.
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** when adding or modifying a test that saves and loads a user-defined dspy.Module subclass
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-28ef588596dd19881ca38c6d.md)

## Rule 026 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  parse_reliability_conf_yaml must be lru_cache'd, require model_name per model_list entry, record only entries with litellm_params, require an adapter key, and wrap any failure in a ValueError naming the config file path.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** when adding or modifying reliability config parsing utilities
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-29644a209ca720295a1ba76e.md)

## Rule 027 — `**/*.py`

- **Rule:** Ruff linting ignores rules B027, FBT003, C901, E501, UP035, RUF005, B904, F403, E721, UP031, and RUF022.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-298c1d04965e1b174960c7d2.md)

## Rule 028 — `tests/reliability/reliability_tests_conf.yaml`

- **Rule:**
  ```text
  The configuration must specify a DSPy adapter to use when testing, e.g. `"chat"` (for `dspy.ChatAdapter`) or `"json"` (for `dspy.JSONAdapter`).
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-29f20b73e269c9f9857cbf81.md)

## Rule 029 — `tests/conftest.py`

- **Rule:**
  ```text
  Async tests in this repository must run under the asyncio backend via the anyio_backend fixture defined in tests/conftest.py.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** when adding or modifying async tests or the shared anyio backend fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-32f467010c83c5f564ee438a.md)

## Rule 030 — `dspy/clients/base_lm.py`

- **Rule:**
  ```text
  base_lm.py must define MAX_HISTORY_SIZE = 10_000 and a module-level GLOBAL_HISTORY list so history is capped at a fixed size rather than growing unbounded.
  ```
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:**
  ```text
  When modifying history storage or size limits in base_lm.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-33c51685a4372cf0a4c30efd.md)

## Rule 031 — `tests/**`

- **Rule:** The test job runs pytest over the tests/ directory via uv run -p .venv pytest -vv tests/.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-342f73b9f3cd4d314e6e076f.md)

## Rule 032 — `dspy/teleprompt/bootstrap_finetune.py`

- **Rule:**
  ```text
  all_predictors_have_lms must return True only if every predictor in the program has an LM set, defining the precondition used by finetune bootstrapping to decide whether LMs are ready; changes must preserve this all-predictors condition.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When modifying all_predictors_have_lms or the finetune bootstrapping precondition that checks LM readiness.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-366c18c467f351bba3cb6628.md)

## Rule 033 — `dspy/__init__.py`

- **Rule:**
  ```text
  Ruff lint rules I001, E402, and F405 are ignored for dspy/__init__.py.
  ```
- **Applies to:**
  - `dspy/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3772f8bba7efd216107ffb7f.md)

## Rule 034 — `tests/utils/test_parallelizer.py`

- **Rule:** Parallelizer tests must inject a deterministic single-item failure by raising ValueError only for item 3, to exercise error propagation.
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** when adding or modifying parallelizer tests that exercise error propagation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3827cebae8d38a8f109d4843.md)

## Rule 035 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-38ae78fc4afbc7813790c4f1.md)
