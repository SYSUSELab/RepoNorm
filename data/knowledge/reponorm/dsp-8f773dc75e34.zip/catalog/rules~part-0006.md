# Full rule catalog

## Rule 080 — `dspy/teleprompt/bootstrap.py`

- **Rule:**
  ```text
  Bootstrap module design constraints must be preserved: metrics should be bool-like/sortable, some example sets are intentionally not shuffled, and max_rounds via branch_idx is used to bypass cache rather than only temperature.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap.py`
- **Condition:** When modifying bootstrap metric handling, example shuffling, or cache-bypass logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7d751fa4dac07500f06efc5b.md)

## Rule 081 — `primitives/*.js`

- **Rule:**
  ```text
  The dspy package includes the JS files matching primitives/*.js as package data.
  ```
- **Applies to:**
  - `primitives/*.js`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7d9e5dad6402e4f15f45374c.md)

## Rule 082 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job publishes the distribution to TestPyPI using pypa/gh-action-pypi-publish@release/v1 with repository-url https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8139cef589b1d303b6c1f06a.md)

## Rule 083 — `dspy/teleprompt/gepa/gepa_utils.py`

- **Rule:** ScoreWithFeedback is a Prediction subclass with typed fields score: float and feedback: str, so GEPA feedback results are expected to carry both a numeric score and textual feedback.
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa_utils.py`
- **Condition:** When modifying ScoreWithFeedback or the GEPA feedback result schema.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-83fc0f496b8331c2ac1c82cd.md)

## Rule 084 — `tests/reliability/test_pydantic_models.py`

- **Rule:**
  ```text
  Reliability tests using pydantic answer models must assert answer.certainty is within [0,1] and len(answer.comments) >= 2, and grade both answer.value and answer.comments via assert_program_output_correct.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying reliability tests that use the pydantic answer model
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-86d0789ec6f6c1e0aa16ff8b.md)

## Rule 085 — `tests/test_utils/server/__init__.py`

- **Rule:**
  ```text
  The litellm_test_server fixture must start a real LiteLLM proxy subprocess on a random port with a request-log file path passed via an environment variable, wait for the port, yield (server_url, log_file_path), and kill the process on teardown.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:**
  ```text
  when modifying or extending the litellm_test_server fixture used by integration tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-874e7716940db26d0dd7758e.md)

## Rule 086 — `tests/utils/test_settings.py`

- **Rule:** Tests that exercise dspy.context in a different async task from the initial one must enter dspy.context with an LM inside an async function, since dspy.context is allowed in different async tasks from the initial one.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that uses dspy.context inside an async task other than the initial one
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8802b6b21bfbdb30f5e47929.md)

## Rule 087 — `dspy/**/*.py`

- **Rule:** Ruff linting/formatting applies to Python files under dspy/ and tests/ as included by the include setting.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8876e3c28ccb3249fe435f00.md)

## Rule 088 — `dspy/teleprompt/gepa/gepa.py`

- **Rule:**
  ```text
  DspyGEPAResult.from_gepa_result rebuilds candidates through adapter.build_program while passing through parents, scores, best outputs, discovery counts, total metric calls, log_dir from run_dir, and seed, defining the adapter boundary for GEPA results.
  ```
- **Applies to:**
  - `dspy/teleprompt/gepa/gepa.py`
- **Condition:**
  ```text
  When modifying DspyGEPAResult.from_gepa_result or the GEPA result adaptation boundary.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-89e03f987b3ba84a99e3f0c7.md)

## Rule 089 — `dspy/propose/utils.py`

- **Rule:**
  ```text
  create_predictor_level_history_string must load trial programs from program_path, aggregate and average scores per instruction, deduplicate instructions, sort by average score descending, take the top N, reverse the list, and format each entry as 'instruction | Score: score'.
  ```
- **Applies to:**
  - `dspy/propose/utils.py`
- **Condition:** When modifying predictor-level history aggregation or its output formatting.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8a727908d18fdada3a601aef.md)

## Rule 090 — `dspy/streaming/streamify.py`

- **Rule:**
  ```text
  async_streamer must yield ModelResponseStream chunks directly when no listeners are configured, otherwise delegate each chunk to predict_id_to_listener listeners and yield the first truthy listener output; StatusMessage values are always yielded, and final Predictions are yielded only if include_final_prediction_in_output_stream or no listener has stream_start/cache_hit conditions.
  ```
- **Applies to:**
  - `dspy/streaming/streamify.py`
- **Condition:**
  ```text
  When modifying async_streamer or its listener delegation and final-prediction gating.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8c3174344a7468aa06fc207a.md)

## Rule 091 — `pyproject.toml`

- **Rule:**
  ```text
  The build-and-publish-pypi job rewrites the package name in pyproject.toml after the #replace_package_name_marker line to "dspy".
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-927e3859199237b20ff56c1e.md)

## Rule 092 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the package name in `.github/.internal_dspyai/pyproject.toml` to `dspy-ai` using a sed command targeting the `#replace_package_name_marker`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-92a21c8e670ed9255858e4b3.md)

## Rule 093 — `tests/primitives/test_python_interpreter.py`

- **Rule:** Tests that assert captured stdout from PythonInterpreter.execute must expect the trailing newline produced by print, because execute returns raw captured stdout rather than stripped output.
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** When modifying or adding tests that assert the return value of PythonInterpreter.execute for code that prints.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-95093830dd53529e64428f7b.md)

## Rule 094 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  The build-and-publish-pypi job rewrites __name__ in ./dspy/__metadata__.py after the #replace_package_name_marker line to "dspy".
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-961b31d3c3aefe074b089e0a.md)
