# Full rule catalog

## Rule 110 — `dspy/signatures/field.py`

- **Rule:**
  ```text
  move_kwargs must route DSPY_FIELD_ARG_NAMES into json_schema_extra, route other kwargs into pydantic kwargs, copy a pydantic 'description' to dspy 'desc' only when desc is absent, and store translated constraints under json_schema_extra['constraints']; changes must preserve these routing and precedence rules.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:**
  ```text
  When modifying move_kwargs or the field kwargs translation between pydantic and dspy.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aac1fcdc27e730b0fd6774fc.md)

## Rule 111 — `dspy/adapters/utils.py`

- **Rule:**
  ```text
  When modifying find_enum_member, preserve that member.value is checked before member name, deliberately handling the rare case where an explicitly-valued enum member's value equals another member's name, and that ValueError is raised when the identifier matches neither a value nor a name.
  ```
- **Applies to:**
  - `dspy/adapters/utils.py`
- **Condition:** Changing enum member resolution order or error behavior.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ad1319497e682bc5654897cf.md)

## Rule 112 — `**/*.py`

- **Rule:** Ruff's formatter is configured to indent with spaces (indent-style = "space").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ad834c437d44a9c3bbe2db34.md)

## Rule 113 — `dspy/teleprompt/simba_utils.py`

- **Rule:**
  ```text
  When modifying prepare_models_for_resampling, preserve the temperature schedule: n LM copies start from the base LM's temperature followed by 0.5 + i*(0.5/n), deduplicated while preserving order and truncated to n.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:** Changing how resampling model copies or their temperatures are constructed.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-adc6a65c2f2ac9750ef8ee11.md)

## Rule 114 — `tests/reliability/reliability_tests_conf.yaml`

- **Rule:**
  ```text
  Any model that lacks configured `litellm_params` in the configuration file is ignored during testing.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-add6eb39d7a1d4e6abecc01b.md)

## Rule 115 — `dspy/propose/grounded_proposer.py`

- **Rule:**
  ```text
  When modifying the GenerateSingleModuleInstruction signature in dspy/propose/grounded_proposer.py, gate InputFields consistently with the constructor flags use_dataset_summary, program_aware, use_instruct_history, and use_tip so the prompt schema varies per configuration as intended.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:** When adding or changing InputFields on GenerateSingleModuleInstruction or its constructor flags.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-af73a111b355ed4ec5e023ee.md)

## Rule 116 — `tests/test_utils/server/litellm_server.py`

- **Rule:**
  ```text
  _append_request_to_log_file must require the LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR environment variable, raising ValueError if unset, and append a JSON blob of model and messages to the log file.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying request logging in the litellm test server
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-afb3ec70b13e0c75f364759b.md)

## Rule 117 — `.github/.internal_dspyai/**`

- **Rule:**
  ```text
  The workflow builds the dspy-ai binary wheel by running `python3 -m build .github/.internal_dspyai/`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b08da07c1be9f827150971e3.md)

## Rule 118 — `tests/reliability/generate/utils.py`

- **Rule:** Reliability test utilities must build a program-generation program by returning dspy.ChainOfThought(ProgramGeneration), the convention for generating DSPy test programs via chain-of-thought.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying the reliability suite's program-generation helper
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b24808a98522aa39e0dacf30.md)

## Rule 119 — `tests/adapters/test_chat_adapter.py`

- **Rule:** Tests that assert ChatAdapter.format output with tools must expect exactly two messages (a system message with the ToolCalls description and a user message with the question, tool names, and JSON-schema-like argument descriptions), because this message structure is the adapter's formatting contract.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** When modifying or adding tests for ChatAdapter.format when tools are present.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b459e01be42f96530990f209.md)

## Rule 120 — `tests/teleprompt/test_copro_optimizer.py`

- **Rule:**
  ```text
  Tests that verify COPRO statistics tracking must assert that the optimized student receives total_calls and results_best attributes when track_stats is enabled, because these attributes are the observable contract of the statistics-tracking feature.
  ```
- **Applies to:**
  - `tests/teleprompt/test_copro_optimizer.py`
- **Condition:** When modifying or adding tests for COPRO optimizer statistics tracking.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b68c6be3c1b09951df58491d.md)

## Rule 121 — `tests/utils/test_settings.py`

- **Rule:** Tests that exercise dspy.configure thread/task restrictions must assert that configure is forbidden in child threads while remaining callable repeatedly in the same async task and usable via dspy.context in other tasks.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying tests covering dspy.configure call-site restrictions across threads and async tasks
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b8237e583a6c7e1ef448cbe9.md)

## Rule 122 — `tests/reliability/generate/**/*.py`

- **Rule:**
  ```text
  Reliability test input generation programs must be built as dspy.ChainOfThought over the _TestInputsGeneration signature.
  ```
- **Applies to:**
  - `tests/reliability/generate/**/*.py`
- **Condition:** when constructing a program to generate reliability test inputs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ba82f7f624fb3027d6e06ec4.md)

## Rule 123 — `**`

- **Rule:**
  ```text
  The workflow publishes the dspy distribution to PyPI using `pypa/gh-action-pypi-publish@release/v1` with attestations disabled.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bbf60ebfeb3d6d0cda670706.md)

## Rule 124 — `pyproject.toml`

- **Rule:**
  ```text
  The build-and-publish-pypi job rewrites the version in pyproject.toml after the #replace_package_version_marker line using the extracted tag version.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bc212bb3bc2f007b16f8567e.md)
