# Full rule catalog

## Rule 036 — `dspy/propose/grounded_proposer.py`

- **Rule:**
  ```text
  DescribeModule must remain a dspy.Signature with input fields program_code, program_example, program_description, module and output field module_description, each carrying explicit prefixes that structure the proposer prompt.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:** When modifying DescribeModule fields or their prefixes used by the proposer prompt.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3ac2f109db1cf6f5aa5f5267.md)

## Rule 037 — `dspy/signatures/field.py`

- **Rule:**
  ```text
  Field.finalize must only default prefix to inferred_prefix + ':' and desc to '${key}' when those attributes are None, never overwriting explicit values.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:** When modifying Field.finalize or adding new defaulted field attributes.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3ac57857001876858c6427b3.md)

## Rule 038 — `.github/.internal_dspyai/dist/**`

- **Rule:**
  ```text
  The workflow publishes the dspy-ai distribution to PyPI using `pypa/gh-action-pypi-publish@release/v1` with attestations disabled and packages-dir set to `.github/.internal_dspyai/dist/`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/dist/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3b99750852773afb0ec8bb92.md)

## Rule 039 — `docs/scripts/generate_api_summary.py`

- **Rule:**
  ```text
  The API summary navigation must be generated from the docs/api directory tree: directory names are mapped through INDEX_NAME to display titles, only .md files become nav entries keyed by file stem, and submodule sections must be emitted before file entries.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:**
  ```text
  When modifying generate_api_nav, build_nav_structure, format_nav_section, or INDEX_NAME in the API summary generator.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3c179f8e8eaa269d497f801d.md)

## Rule 040 — `tests/reliability/generate/**/*.py`

- **Rule:**
  ```text
  Reliability test input files must be named input<N>.json and numbered sequentially; find_max_input_number treats a missing directory as zero and matches only that filename pattern.
  ```
- **Applies to:**
  - `tests/reliability/generate/**/*.py`
- **Condition:** when generating or locating reliability test input files
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3fd51c73784bc8d7d3bb6d08.md)

## Rule 041 — `dspy/retrievers/weaviate_rm.py`

- **Rule:**
  ```text
  WeaviateRM.forward must branch on self._client_type: 'WeaviateClient' uses collection.query.hybrid with optional with_tenant, while 'Client' uses the legacy query.get(...).with_hybrid(...).with_limit(...).do() path, and both extract the configured text key into dotdict long_text passages.
  ```
- **Applies to:**
  - `dspy/retrievers/weaviate_rm.py`
- **Condition:** When modifying WeaviateRM.forward or its client-type branching.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4399202a2a7a7c3f9518d0f5.md)

## Rule 042 — `tests/reliability/generate/**/*.py`

- **Rule:**
  ```text
  Tests that exercise generated-program imports must use _temporarily_prepend_to_system_path, which copies sys.path, inserts the path at index 0, and restores the original list in finally, rather than mutating sys.path directly.
  ```
- **Applies to:**
  - `tests/reliability/generate/**/*.py`
- **Condition:** when a test needs to import a generated program by temporarily modifying sys.path
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-43c11b577f85432279e7ba01.md)

## Rule 043 — `docs/scripts/generate_api_summary.py`

- **Rule:** Running the API summary generator must rewrite the checked-in mkdocs.yml in place, preserving pre-nav and post-theme sections while stripping the existing '- API Reference:' nav entry and its continuation lines before inserting the regenerated section.
- **Applies to:**
  - `docs/scripts/generate_api_summary.py`
- **Condition:**
  ```text
  When modifying main() or read_mkdocs_sections in the API summary generator that rewrites mkdocs.yml.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-460612df8b084988e3e3298f.md)

## Rule 044 — `.github/workflows/precommits_check.yml`

- **Rule:** The Pre-Commit Checks step installs pre-commit and runs 'pre-commit run -v --files' against the changed files.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4655559d401d7d8e9e69546a.md)

## Rule 045 — `tests/reliability/test_pydantic_models.py`

- **Rule:** The reliability test suite must define a Colorful Signature with a str input and a Color output field to exercise Pydantic enum output handling.
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when adding or modifying the reliability test that exercises Pydantic enum output handling
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-46b62f40c8a9b6fc3072ac59.md)

## Rule 046 — `tests/utils/test_settings.py`

- **Rule:** Settings tests must verify that dspy.settings.lm.model equals the model of the LM entered via dspy.context, confirming context-scoped LM overrides are visible inside the context.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying settings tests that verify context-scoped LM overrides
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-46c39bcff588dd42970eb320.md)

## Rule 047 — `dspy/clients/base_lm.py`

- **Rule:** BaseLM.copy must deep-copy the LM, reset history to empty, and route kwargs to attributes when present or to the kwargs dict otherwise.
- **Applies to:**
  - `dspy/clients/base_lm.py`
- **Condition:** When modifying BaseLM.copy or subclass copy behavior, preserve deep-copy semantics, empty history reset, and kwargs routing to attributes or kwargs dict.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4c2b5f5a0b0a028d2624e258.md)

## Rule 048 — `dspy/signatures/field.py`

- **Rule:**
  ```text
  OldField.__eq__ must compare self.__dict__ == __value.__dict__, so field equality is based on instance dictionaries and contributors changing Field attributes must consider this equality contract.
  ```
- **Applies to:**
  - `dspy/signatures/field.py`
- **Condition:**
  ```text
  When modifying OldField.__eq__ or Field attributes that affect equality.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5034da76f61bd53af69e21ec.md)

## Rule 049 — `dspy/**`

- **Rule:** Setuptools package discovery includes the dspy package and its subpackages.
- **Applies to:**
  - `dspy/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5046935612992f8ce4fca928.md)

## Rule 050 — `tests/reliability/complex_types/generated/test_many_types_1/program.py`

- **Rule:** Reliability tests for complex types must define Pydantic models that exercise tuple, enum, datetime, and literal types together, asserting round-trip handling of these complex field types.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
- **Condition:** When modifying or adding reliability tests for complex types, define Pydantic models that exercise tuple, enum, datetime, and literal types together.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-50f3990c048aca2ba3c92f46.md)
