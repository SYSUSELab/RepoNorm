# Full rule catalog

## Rule 158 — `dspy/dsp/utils/dpr.py`

- **Rule:**
  ```text
  SimpleTokenizer must define ALPHA_NUM as r'[\p{L}\p{N}\p{M}]+' and NON_WS as r'[^\p{Z}\p{C}]', using Unicode property classes for tokenization.
  ```
- **Applies to:**
  - `dspy/dsp/utils/dpr.py`
- **Condition:**
  ```text
  When modifying SimpleTokenizer's ALPHA_NUM or NON_WS regex patterns.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f7cf678956bcec3c7289b913.md)

## Rule 159 — `dspy/predict/best_of_n.py`

- **Rule:**
  ```text
  BestOfN.forward must build a deduplicated temperature schedule from the LM's configured temperature, deep-copy the module per attempt, stop early when reward meets threshold, retry on exception until fail_count is exhausted before re-raising, and extend the best trace into dspy.settings.trace.
  ```
- **Applies to:**
  - `dspy/predict/best_of_n.py`
- **Condition:** When modifying BestOfN.forward attempt scheduling, retry, or trace handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f83ddcb158e1a27c9c443ce3.md)

## Rule 160 — `tests/adapters/test_code.py`

- **Rule:** Tests that verify dspy.Code parsing of dirty code must assert that code.code contains only the extracted code with markdown fences and surrounding reasoning text stripped, because this extraction behavior is the parsing contract.
- **Applies to:**
  - `tests/adapters/test_code.py`
- **Condition:** When modifying or adding tests for dspy.Code parsing of code containing markdown fences or surrounding text.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fad8a1b6dc758b081b437993.md)

## Rule 161 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  For nested properties, _split_schema must recurse and reattach nested inputs only when the parent field type is input, and nested outputs when the parent is output or has no field type, preserving the parent's cleaned schema alongside nested properties.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when adding or modifying _split_schema handling of nested properties in the reliability suite
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fc5fd27b838bda8848752319.md)

## Rule 162 — `dspy/dsp/colbertv2.py`

- **Rule:**
  ```text
  ColBERTv2.__init__ must treat colbert as an optional dependency: on ImportError print an installation hint, and overwrite self.colbert_config.checkpoint with the constructor checkpoint argument.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:**
  ```text
  When modifying ColBERTv2.__init__ import handling or checkpoint configuration.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ff5f8685d6186f03f562918c.md)
