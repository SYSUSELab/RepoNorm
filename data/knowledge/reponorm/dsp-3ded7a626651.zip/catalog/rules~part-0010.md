# Full rule catalog

## Rule 146 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  The reliability generator must randomly choose between dspy.ChainOfThought and dspy.Predict and build the signature by appending InputField/OutputField from ProgramInputs/ProgramOutputs model_fields.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the generated-program construction protocol in reliability tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e585e7d96d0401771a7c1946.md)

## Rule 147 — `tests/reliability/generate/__init__.py`

- **Rule:**
  ```text
  generate_test_cases must reuse an existing program when _directory_contains_program is true (regenerating only inputs) and otherwise generate a new program before always generating inputs and loading cases.
  ```
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:**
  ```text
  When modifying generate_test_cases or its program-reuse branch.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e6d702085073f3e2a8b108b2.md)

## Rule 148 — `tests/reliability/generate/utils.py`

- **Rule:** The reliability test utility must build its program-generation program as dspy.ChainOfThought(ProgramGeneration), so contributors changing program generation must keep ChainOfThought over the ProgramGeneration signature.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying how reliability test programs are generated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e793927773a722f9d700bfd0.md)

## Rule 149 — `**/*.py`

- **Rule:** Ruff's formatter is configured to use double quotes for strings (quote-style = "double").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e7c321e14b1c08413a12bc63.md)

## Rule 150 — `tests/adapters/test_tool.py`

- **Rule:** Tool.acall must filter kwargs to only those matching the wrapped function's signature, dropping extra keyword arguments (e.g. acall(x=1, y=2, z=3) returns only {'y':2,'z':3} for a function accepting y and z).
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** when modifying Tool.acall argument handling or async tool invocation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e7daa45bb8bc2366d2627177.md)

## Rule 151 — `.github/workflows/build_and_release.yml`

- **Rule:** The PyPI job installs dependencies with python3 -m pip install --upgrade setuptools wheel twine build.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ea0523deb12b4ddd01bcbe05.md)

## Rule 152 — `dspy/utils/callback.py`

- **Rule:**
  ```text
  When modifying BaseCallback in dspy/utils/callback.py, preserve the callback registration contract: handlers fire before/after component execution and can be registered globally via dspy.settings.configure(callbacks=[...]) or locally per component (e.g. dspy.LM(..., callbacks=[...])), with local callbacks scoped to that instance.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:** When changing callback registration, scoping, or before/after execution hooks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ebf5f800b676f6d96cc8379e.md)

## Rule 153 — `.github/workflows/precommits_check.yml`

- **Rule:** The Pre-Commit Checks step runs pre-commit run -v --files on the changed files list.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ec7422a7b5d954bd98cf2931.md)

## Rule 154 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The PyPI job updates the package name in pyproject.toml to dspy by replacing the line after the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed16041ba4f4891810dfa961.md)

## Rule 155 — `tests/adapters/test_chat_adapter.py`

- **Rule:** ChatAdapter.acall must return the parsed adapter output list when awaited with a DummyLM.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** Modifying the async ChatAdapter call path or its return value contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eec49f657608791d951b8066.md)

## Rule 156 — `pyproject.toml`

- **Rule:**
  ```text
  The project declares requires-python = ">=3.9, <3.14".
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eeec21db03e23e0a8e7cdca3.md)

## Rule 157 — `tests/signatures/test_signature.py`

- **Rule:**
  ```text
  Signature.prepend and Signature.append must place new input fields at the first and last positions of input_fields respectively, and likewise place new output fields at the first and last positions of output_fields.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** when modifying Signature.prepend/append or field-ordering behavior for input and output fields
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f0785d5e795c812cd67ba324.md)

## Rule 158 — `.github/workflows/build_and_release.yml`

- **Rule:** The TestPyPI job builds the distribution with python3 -m build.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f316cad2badd3fe328707cbf.md)

## Rule 159 — `dspy/datasets/alfworld/alfworld.py`

- **Rule:**
  ```text
  When modifying env_worker in dspy/datasets/alfworld/alfworld.py, preserve the worker-process protocol: a single AlfredTWEnv instance is created in the worker, missing alfworld raises ImportError with the pip install alfworld==0.3.5 hint, and 'init', 'step', and 'close' commands are handled over the inq/outq queues.
  ```
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:**
  ```text
  When changing env_worker's command handling, environment construction, or dependency-error path.
  ```
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`
- **Detail:** [Open claim details](../claims/CLAIM-fa7b6aef67a097886b34ac6b.md)

## Rule 160 — `dspy/adapters/types/base_type.py`

- **Rule:**
  ```text
  When modifying BaseType.serialize_model, preserve the list-valued format() wrapping: list outputs must be wrapped in CUSTOM_TYPE_START_IDENTIFIER/CUSTOM_TYPE_END_IDENTIFIER markers, while non-list formatted values are returned unchanged.
  ```
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:**
  ```text
  when changing BaseType.serialize_model or the format() output handling for custom types
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fe1a2ba4b93a8178cf30a4d8.md)

## Rule 161 — `dspy/streaming/messages.py`

- **Rule:**
  ```text
  When modifying StatusStreamingCallback.on_module_end, preserve the early-return behavior: it returns without emitting a status message when settings.send_stream is None, so streaming status callbacks are silently skipped unless a stream is configured.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  Modifying StatusStreamingCallback.on_module_end or its stream-configuration guard.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ffd202c1e5c9397496720ac3.md)
