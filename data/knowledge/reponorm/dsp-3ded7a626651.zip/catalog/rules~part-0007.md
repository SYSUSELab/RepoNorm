# Full rule catalog

## Rule 100 — `docs/mkdocs.yml`

- **Rule:** The MkDocs Material palette uses the slate scheme with a toggle to switch to light mode, primary color black, and accent color lime.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9d35e75366b2aacef94c29c9.md)

## Rule 101 — `dspy/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  The dspy-ai package declares requires-python ">=3.9", so the package supports Python 3.9 and later.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9dd761919f131b448fd741d0.md)

## Rule 102 — `tests/teleprompt/test_ensemble.py`

- **Rule:** Tests that exercise DSPy ensemble behavior must use a minimal dspy.Module subclass stand-in (e.g. MockProgram) rather than real programs, so ensemble logic is tested in isolation.
- **Applies to:**
  - `tests/teleprompt/test_ensemble.py`
- **Condition:** when adding or modifying ensemble tests that need a program stand-in
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a22791adaea9c65c71f40fcd.md)

## Rule 103 — `dspy/adapters/types/image.py`

- **Rule:**
  ```text
  `_encode_image_from_file` reads the file, guesses MIME type from the path via `mimetypes`, raises `ValueError` when the MIME type cannot be determined, and returns a `data:<mime>;base64,<data>` URI.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  When modifying image encoding from files, preserve the MIME-type guessing, the `ValueError` on undetermined MIME type, and the `data:<mime>;base64,<data>` URI format.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a351a66ed0bf8e06e88b69b7.md)

## Rule 104 — `.github/workflows/precommits_check.yml`

- **Rule:** The workflow obtains the list of changed files using jitterbit/get-changed-files and exposes it as the files step output.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a761c491358b633acaa37ed0.md)

## Rule 105 — `dspy/__init__.py`

- **Rule:**
  ```text
  When modifying dspy/__init__.py, preserve the top-level re-exports of adapter classes (Adapter, ChatAdapter, JSONAdapter, XMLAdapter, TwoStepAdapter) and types (Image, Audio, History, BaseType, Tool, ToolCalls), and keep the BootstrapRS alias to BootstrapFewShotWithRandomSearch and the cache alias to DSPY_CACHE.
  ```
- **Applies to:**
  - `dspy/__init__.py`
- **Condition:** Modifying the top-level dspy package exports or aliases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a80a8c5d69698e8bacefdf7e.md)

## Rule 106 — `dspy/datasets/gsm8k.py`

- **Rule:**
  ```text
  When a contributor modifies gsm8k_metric, it must compare gold and pred answers by parsing integer answers from str(gold.answer) and str(pred.answer), so GSM8K evaluation depends on answer fields being integer-parseable strings.
  ```
- **Applies to:**
  - `dspy/datasets/gsm8k.py`
- **Condition:**
  ```text
  Modifying gsm8k_metric or adding a new GSM8K-style metric that parses numeric answers.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aa70d14ed28cad9a2cdbbeba.md)

## Rule 107 — `dspy/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  setuptools package discovery includes the packages matching "dsp.*", "dspy.*", "dsp", and "dspy".
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aa88d3eb498a2072ecc143d0.md)

## Rule 108 — `tests/utils/test_mcp.py`

- **Rule:**
  ```text
  convert_mcp_tool must map MCP tool schemas to DSPy tools with integer/array args as int/list arg_types, missing descriptions as 'No description provided. (Required)', nested Pydantic object args accepted as JSON dicts, and MCP tool errors surfaced as RuntimeError with a 'Failed to call a MCP tool' message.
  ```
- **Applies to:**
  - `tests/utils/test_mcp.py`
- **Condition:**
  ```text
  When modifying convert_mcp_tool or the MCP-to-DSPy tool conversion path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ab50297243f672bcd9c55635.md)

## Rule 109 — `dspy/adapters/types/image.py`

- **Rule:**
  ```text
  `Image.from_PIL` constructs an image by encoding the PIL image into a URL via `encode_image`, so PIL images are represented as encoded URL strings in the adapter image type.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  When modifying PIL image conversion, preserve representation as an encoded URL string via `encode_image`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ac93a39e53da9491326d846d.md)

## Rule 110 — `**/*.py`

- **Rule:** Ruff linting ignores rules B027, FBT003, C901, E501, UP006, UP035, RUF005, B904, F403, E721, UP031, and RUF022.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-acbfa2e899e9aa3cae10f19c.md)

## Rule 111 — `dspy/adapters/chat_adapter.py`

- **Rule:**
  ```text
  ChatAdapter.__call__ must fall back to JSONAdapter when the superclass call raises, except that ContextWindowExceededError and calls where self is already a JSONAdapter must re-raise the original exception.
  ```
- **Applies to:**
  - `dspy/adapters/chat_adapter.py`
- **Condition:**
  ```text
  When modifying ChatAdapter.__call__ or its exception handling around the superclass adapter call.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-acc201691ba26e7fdab4d315.md)

## Rule 112 — `tests/conftest.py`

- **Rule:**
  ```text
  pytest_configure must register each flag in SKIP_DEFAULT_FLAGS as a pytest marker via config.addinivalue_line, so contributors adding opt-out flags must add them to SKIP_DEFAULT_FLAGS rather than registering markers ad hoc.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When adding or modifying an opt-out pytest flag or marker in the test configuration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-af1ea3c8b8b20edbdaf01e75.md)

## Rule 113 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The TestPyPI job updates the package name in pyproject.toml to dspy-ai-test by replacing the line after the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-af6d16622d0eb88e89a21eeb.md)

## Rule 114 — `dspy/adapters/base.py`

- **Rule:**
  ```text
  When modifying Adapter.format_field_structure, preserve its role as a required override: the base declaration raises NotImplementedError so adapter subclasses must define the system-message field format.
  ```
- **Applies to:**
  - `dspy/adapters/base.py`
- **Condition:**
  ```text
  Modifying Adapter.format_field_structure or the adapter subclass contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-af746150c62785e2b65b727e.md)

## Rule 115 — `tests/reliability/test_pydantic_models.py`

- **Rule:**
  ```text
  Reliability tests must import assert_program_output_correct and known_failing_models from tests.reliability.utils, establishing a shared reliability-test helper module used across reliability tests.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  When modifying reliability test imports or shared helper usage in tests/reliability/test_pydantic_models.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-afe18e9d396acbe7c8158fa0.md)
