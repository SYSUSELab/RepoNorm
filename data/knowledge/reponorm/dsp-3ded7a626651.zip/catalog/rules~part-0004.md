# Full rule catalog

## Rule 050 — `tests/utils/test_parallelizer.py`

- **Rule:**
  ```text
  ParallelExecutor with max_errors=1 must raise an exception matching 'Execution cancelled due to errors or interruption.' when errors exceed the limit, defining the cancellation error contract that tests and callers rely on.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** When modifying ParallelExecutor error handling or the cancellation error message.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-57b0a67862dd2fb05bf61897.md)

## Rule 051 — `dspy/.internal_dspyai/dist/**`

- **Rule:**
  ```text
  The workflow publishes the dspy-ai distribution to PyPI using `pypa/gh-action-pypi-publish@release/v1` with `attestations: false` and `packages-dir: ./dspy/.internal_dspyai/dist/`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/dist/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-58d33cb1dc044109c6ffdb31.md)

## Rule 052 — `dspy/teleprompt/infer_rules.py`

- **Rule:**
  ```text
  When modifying CustomRulesInduction, preserve the dynamic __doc__ contract: __doc__ is set using num_rules to instruct extraction of a list of num_rules concise, non-redundant natural-language rules, with inputs examples_text and output natural_language_rules.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when changing CustomRulesInduction or its dynamic __doc__ construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5a3872bb735db482970bcbfb.md)

## Rule 053 — `dspy/predict/chain_of_thought_with_hint.py`

- **Rule:**
  ```text
  `chain_of_thought_with_hint.py` builds on the base `Predict` `Module` imported from `.predict` rather than a separate abstraction.
  ```
- **Applies to:**
  - `dspy/predict/chain_of_thought_with_hint.py`
- **Condition:**
  ```text
  When modifying the chain-of-thought-with-hint module, preserve its dependence on the base `Predict` `Module` from `.predict`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5a8947240289d5a8fd10df4e.md)

## Rule 054 — `tests/reliability/test_pydantic_models.py`

- **Rule:**
  ```text
  The reliability ToolCalling signature constrains next_tool_name, response_status, and user_intent to fixed Literal sets, and tool-calling tests must assert predicted tool names fall within the declared literal set; contributors changing the tool-calling protocol must update both the signature literals and the tests together.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when modifying the reliability ToolCalling signature literals or tests asserting predicted tool names
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5b95f2899db43c1904680b6d.md)

## Rule 055 — `docs/mkdocs.yml`

- **Rule:** The extra CSS includes stylesheets/extra.css.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5bd42a44adf8adf42a56af07.md)

## Rule 056 — `dspy/datasets/alfworld/alfworld.py`

- **Rule:** dspy.datasets.alfworld.alfworld must import os, queue, and random as its standard-library dependencies.
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** When modifying imports in dspy.datasets.alfworld.alfworld.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5eeb9a47b8b5658372a05599.md)

## Rule 057 — `dspy/teleprompt/simba_utils.py`

- **Rule:**
  ```text
  `wrap_program` takes a `dspy.Module` and a metric callable and returns a `wrapped_program`, defining the extension point for adapting programs to the SimBA optimizer.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:**
  ```text
  When modifying SimBA program adaptation, preserve `wrap_program`'s signature accepting a `dspy.Module` and metric callable and returning a wrapped program.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-60a0ff457f3e862d9fca4104.md)

## Rule 058 — `tests/reliability/reliability_tests_conf.yaml`

- **Rule:**
  ```text
  Models lacking configured `litellm_params` in the configuration file are ignored during testing.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-618b55ff9de03780ebe10adb.md)

## Rule 059 — `dspy/adapters/base.py`

- **Rule:**
  ```text
  When modifying Adapter._get_tool_call_output_field_name, preserve the selection rule: return the name of the first output field whose annotation is ToolCalls, or None if no such field exists.
  ```
- **Applies to:**
  - `dspy/adapters/base.py`
- **Condition:**
  ```text
  when changing _get_tool_call_output_field_name or tool-call output field detection
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-62089838044d1243966717bc.md)

## Rule 060 — `tests/reliability/test_pydantic_models.py`

- **Rule:** Reliability tests must exercise structured output extraction from a Signature whose output field is typed as a Pydantic model (ExtractEntityFromDescriptionOutput).
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** When modifying the entity-extraction reliability test or its Pydantic-typed Signature.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-633472de3f709ae27bb0c0f1.md)

## Rule 061 — `dspy/clients/lm.py`

- **Rule:**
  ```text
  When modifying litellm_text_completion in dspy/clients/lm.py, preserve the model-string and credential contract: parse 'provider/model' with provider defaulting to 'openai' when no slash is present, read API key/base from the request or {provider}_API_KEY/{provider}_API_BASE environment variables, and call litellm.text_completion with 'text-completion-openai/{model}' and exponential-backoff retry.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:**
  ```text
  When changing model-string parsing, credential resolution, or the litellm call in litellm_text_completion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6512166d027cc844ba01c48b.md)

## Rule 062 — `dspy/clients/cache.py`

- **Rule:**
  ```text
  When modifying request_cache, preserve the default ignored_args_for_cache_key of ['api_key','api_base','base_url'] so connection-credential arguments are excluded from cache keys unless explicitly overridden.
  ```
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:**
  ```text
  when changing request_cache or the cache key argument exclusion defaults
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-663329ea2d0bb139cce1dde9.md)

## Rule 063 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The PyPI job updates the version in ./dspy/__metadata__.py by replacing the line after the #replace_package_version_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-67e18ea84b63fa59a196ecab.md)

## Rule 064 — `.github/workflows/build_and_release.yml`

- **Rule:** The TestPyPI publish step uses the pypa/gh-action-pypi-publish action with repository-url set to https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6a3f4b8cc0a0a4d099aee145.md)

## Rule 065 — `docs/mkdocs.yml`

- **Rule:** The extra JavaScript includes js/runllm-widget.js.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6a4e99bc1278690d68940931.md)
