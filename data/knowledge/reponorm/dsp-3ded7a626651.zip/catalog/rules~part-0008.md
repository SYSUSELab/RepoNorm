# Full rule catalog

## Rule 116 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  _json_input_to_program_input must parse a JSON string, validate it against a pydantic input schema via model_validate, and return a dict built from program_input.__fields__ so keys follow the pydantic model's declared fields.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _json_input_to_program_input or JSON-to-program-input conversion in reliability tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b0862cf62683d58e9d9126ba.md)

## Rule 117 — `tests/test_utils/server/__init__.py`

- **Rule:**
  ```text
  The test server helper allocates a free port by binding a socket to port 0 and reading getsockname, and _wait_for_port polls a TCP connection every 0.5 seconds until timeout, raising TimeoutError if the server never accepts; contributors modifying server test helpers must preserve this port-allocation and readiness contract.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when modifying test server port allocation or readiness polling helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b0af98fcb33126fb7b0843c2.md)

## Rule 118 — `docs/mkdocs.yml`

- **Rule:** The site favicon is static/img/logo.png.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b260f2635833ae99b26a15bc.md)

## Rule 119 — `dspy/signatures/utils.py`

- **Rule:**
  ```text
  `get_dspy_field_type` reads the `'__dspy_field_type'` key from a field's `json_schema_extra` and raises `ValueError` if it is absent, making that metadata key the required marker for input/output fields.
  ```
- **Applies to:**
  - `dspy/signatures/utils.py`
- **Condition:**
  ```text
  When modifying signature field typing, preserve the requirement that fields carry the `'__dspy_field_type'` key in `json_schema_extra`, raising `ValueError` when absent.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b46b39cec861528eed73927f.md)

## Rule 120 — `tests/predict/test_predict.py`

- **Rule:**
  ```text
  Predict with dspy.History must produce exactly one LM call with four messages where history question/answer appear in messages[1]/[2] and the new question in messages[3], for both chat and json adapters.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** Modifying Predict handling of dspy.History or the message layout produced for chat and json adapters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b4e50d2601bb1efd7300ef74.md)

## Rule 121 — `**/*.py`

- **Rule:**
  ```text
  Ruff's isort lint rule treats the `dspy` package as first-party when classifying imports.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bb3fc10ab84600816d37729d.md)

## Rule 122 — `tests/teleprompt/test_utils.py`

- **Rule:**
  ```text
  Tests for eval_candidate_program failure handling must assert that when the evaluate callable raises, the function returns (0.0, [0.0]*len(trainset)) when return_all_scores is True and the scalar 0.0 otherwise.
  ```
- **Applies to:**
  - `tests/teleprompt/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for eval_candidate_program failure return shape under return_all_scores
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bf82af896bc043c497c852ba.md)

## Rule 123 — `docs/scripts/generate_api_docs.py`

- **Rule:**
  ```text
  Method names included in generated API documentation must be routines that satisfy the should_document_method filter; get_public_methods is the single gate that decides which class members appear in the generated docs.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  When modifying the API documentation generator's method-selection logic or the should_document_method filter, preserve the invariant that only routines passing should_document_method are emitted as documented methods.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c49aee56ec9a11250ca3d789.md)

## Rule 124 — `dspy/utils/unbatchify.py`

- **Rule:**
  ```text
  Unbatchify.__exit__ must delegate to self.close() so resource cleanup is guaranteed on context exit regardless of exception type.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:**
  ```text
  When modifying Unbatchify.__exit__ or its context-manager cleanup path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c6aa5cf4ec1bc79d80e15ec8.md)

## Rule 125 — `**/*.py`

- **Rule:** Ruff's formatter is configured to not skip magic trailing commas (skip-magic-trailing-comma = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c76ee00180c1bf3310e1f174.md)

## Rule 126 — `dspy/utils/usage_tracker.py`

- **Rule:**
  ```text
  `track_usage` is a context manager that installs a fresh `UsageTracker` via `settings.context(usage_tracker=tracker)` and yields it, so usage tracking is scoped to the context block.
  ```
- **Applies to:**
  - `dspy/utils/usage_tracker.py`
- **Condition:**
  ```text
  When modifying usage tracking, preserve the context-manager scoping that installs a fresh `UsageTracker` via `settings.context` and yields it.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c8ffe4d9f38e1598bc740bb3.md)

## Rule 127 — `tests/adapters/test_tool.py`

- **Rule:** Tests that exercise DSPy tool construction from a function must assert that the tool name derives from the function name, description from the docstring, and args schema from the signature including type and default values.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** when adding or modifying tests that verify Tool construction from a Python function
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca8af2ee2b01b57eee3115f3.md)

## Rule 128 — `tests/signatures/test_signature.py`

- **Rule:**
  ```text
  Signature string parsing must treat comma-separated names before '->' as input fields and names after '->' as output fields.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** Modifying Signature string parsing or the arrow/comma field-splitting convention.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cbff5bcbb21b34592bcccf9c.md)

## Rule 129 — `dspy/utils/callback.py`

- **Rule:**
  ```text
  When modifying BaseCallback.on_adapter_format_end, preserve the callback contract: it receives call_id, optional outputs, and optional exception; outputs are None when the adapter's format() is interrupted by an exception, and call_id links the start/end handlers.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:**
  ```text
  Modifying BaseCallback.on_adapter_format_end or the adapter format callback protocol.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc298c6d0e27f11e076599e1.md)

## Rule 130 — `tests/utils/test_usage_tracker.py`

- **Rule:**
  ```text
  The usage-tracker context-manager test must remain gated on the OPENAI_API_KEY environment variable so it is skipped without a live key.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:**
  ```text
  When modifying test_track_usage_context_manager or its skip/gating decorators.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc861a07755eedaed13be373.md)
