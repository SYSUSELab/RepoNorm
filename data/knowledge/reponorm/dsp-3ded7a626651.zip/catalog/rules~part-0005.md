# Full rule catalog

## Rule 066 — `dspy/teleprompt/copro_optimizer.py`

- **Rule:**
  ```text
  When modifying COPRO.__init__, preserve the validation that raises ValueError when breadth <= 1, enforcing breadth greater than 1; other params (depth, init_temperature, track_stats) are stored without validation.
  ```
- **Applies to:**
  - `dspy/teleprompt/copro_optimizer.py`
- **Condition:**
  ```text
  Modifying COPRO.__init__ or its breadth validation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6c2ea44daf7c2fc6dc617551.md)

## Rule 067 — `tests/adapters/test_chat_adapter.py`

- **Rule:**
  ```text
  ChatAdapter formatting with few-shot image examples must produce exactly 6 messages with image_url content blocks in user messages at indices 1, 3, and 5, and assistant messages containing the completed marker.
  ```
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** Modifying ChatAdapter message formatting for few-shot image examples or the completed marker placement.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6d28aab75b32365d36d7e43d.md)

## Rule 068 — `tests/examples/test_baleen.py`

- **Rule:** Tests that exercise dspy example modules must define the example as a subclass of dspy.Module, establishing the example as a dspy module.
- **Applies to:**
  - `tests/examples/test_baleen.py`
- **Condition:** When modifying example module tests that define dspy modules.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6dc386d77b907660c40782b6.md)

## Rule 069 — `dspy/utils/usage_tracker.py`

- **Rule:** UsageTracker must store usage entries in a defaultdict(list) keyed by LM name, so callers can append per-call token usage without pre-initializing keys.
- **Applies to:**
  - `dspy/utils/usage_tracker.py`
- **Condition:** When modifying UsageTracker initialization or the per-LM usage storage structure.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6e40e391e9a449d74b5c0a25.md)

## Rule 070 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job builds the package with uv run -p .venv python -m build, installs the built wheel from dist/*.whl, and verifies with uv run -p .venv python -c "import dspy".
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-71c9137610174b89acf28e14.md)

## Rule 071 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The PyPI job updates the version in pyproject.toml by replacing the line after the #replace_package_version_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-72579594cab58f426abf07e0.md)

## Rule 072 — `dspy/clients/embedding.py`

- **Rule:**
  ```text
  The embedding client module routes embedding requests through the shared request cache by importing `request_cache` from `dspy.clients.cache`.
  ```
- **Applies to:**
  - `dspy/clients/embedding.py`
- **Condition:** When modifying embedding request handling, preserve routing through the shared request cache rather than bypassing it.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7310c8b5bffbe84c693a8367.md)

## Rule 073 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-73751b598d3462641612b4df.md)

## Rule 074 — `tests/predict/test_aggregation.py`

- **Rule:** majority() must return the first completion when no answer reaches a majority (tie-breaking by first occurrence).
- **Applies to:**
  - `tests/predict/test_aggregation.py`
- **Condition:** when modifying majority aggregation or its tie-breaking behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-737c346e1543ec04f9c6fe25.md)

## Rule 075 — `**`

- **Rule:** The pre-commit configuration enables the check-merge-conflict hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-74ce4ac690110d57cea28f63.md)

## Rule 076 — `dspy/adapters/chat_adapter.py`

- **Rule:**
  ```text
  ChatAdapter.format_field_structure must place input and output fields in separate sections using '[[ ## field_name ## ]]' markers and append a '[[ ## completed ## ]]' marker to terminate the output fields section.
  ```
- **Applies to:**
  - `dspy/adapters/chat_adapter.py`
- **Condition:**
  ```text
  When modifying ChatAdapter.format_field_structure or the chat adapter field-section formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-74ea8e6d8251fc4359ab7529.md)

## Rule 077 — `tests/**`

- **Rule:**
  ```text
  The test job runs extra tests via uv run -p .venv pytest tests/ -m extra --extra after syncing the test_extras extra.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7554fe9e5660ebaf1cb456a0.md)

## Rule 078 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The mkdocs-jupyter plugin is configured with ignore_h1_titles True.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-75673f0192259689ff982964.md)

## Rule 079 — `.github/workflows/run_tests.yml`

- **Rule:** The fix job runs ruff check with --fix-only --diff --exit-non-zero-on-fix, and on failure prints guidance to run pre-commit run --all-files and exits 1.
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7ab3615fc727f33d0badc544.md)

## Rule 080 — `docs/mkdocs.yml`

- **Rule:** The social plugin is enabled.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7accba64304663f965e5decb.md)

## Rule 081 — `tests/datasets/test_dataset.py`

- **Rule:**
  ```text
  tests/datasets/test_dataset.py must define a CSV dummy_data string with content, question, and answer columns used as the dataset fixture.
  ```
- **Applies to:**
  - `tests/datasets/test_dataset.py`
- **Condition:**
  ```text
  When modifying dataset test fixtures or CSV dummy_data columns.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7e34db3747ef4abfe5394020.md)

## Rule 082 — `dspy/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow sets the version in `./dspy/.internal_dspyai/pyproject.toml` to the extracted tag version using a sed command keyed on the `#replace_package_version_marker`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-805fea3376fdbe7a23c6da60.md)

## Rule 083 — `tests/adapters/test_json_adapter.py`

- **Rule:**
  ```text
  JSONAdapter must format a dspy.Image input as a user message content list of exactly three chunks ordered text, image_url, text, with the image_url chunk shaped as {'type':'image_url','image_url':{'url':...}}.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** when modifying JSONAdapter image formatting or multimodal message construction
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-827e7031d843d6acdfaaa692.md)
