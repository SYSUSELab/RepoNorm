# Full rule catalog

## Rule 131 — `tests/reliability/test_pydantic_models.py`

- **Rule:**
  ```text
  Reliability structured-output tests must preserve the asserted Pydantic answer-model invariants: certainty within [0,1], at least two comments, and graded correctness of value and comments.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  When modifying test_qa_with_pydantic_answer_model or the Pydantic answer model it exercises.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cf6d36e09a50aadd9f150ba4.md)

## Rule 132 — `tests/utils/test_asyncify.py`

- **Rule:**
  ```text
  The asyncify test must wrap a sync function with dspy.asyncify and await verify_asyncify with multiple concurrency/size parameter pairs, asserting asyncify preserves behavior under varying concurrency.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** When modifying asyncify behavior or its concurrency/size parameter coverage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d04428a0abb6847e92cf4446.md)

## Rule 133 — `dspy/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow updates the dspy dependency in `./dspy/.internal_dspyai/pyproject.toml` to the extracted tag version using a sed command keyed on the `#replace_dspy_version_marker`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d11769b639d7d53f92fc51c2.md)

## Rule 134 — `dspy/clients/__init__.py`

- **Rule:**
  ```text
  _litellm_track_cache_hit_callback must set completion_response.cache_hit from kwargs.get('cache_hit', False), making cache_hit a boolean attribute on the completion response.
  ```
- **Applies to:**
  - `dspy/clients/__init__.py`
- **Condition:**
  ```text
  When modifying the litellm cache-hit tracking callback or the completion response cache_hit attribute.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d240d68cf905e5084df94481.md)

## Rule 135 — `tests/test_utils/server/litellm_server.py`

- **Rule:**
  ```text
  The mock LiteLLM server's completion method must log every request via _append_request_to_log_file(kwargs) before returning a mock response, so tests can assert on persisted request payloads; contributors modifying the mock server must preserve this logging.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying the mock LiteLLM server's completion handling or request logging
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d24ed657239ad602f6c0182e.md)

## Rule 136 — `tests/predict/test_program_of_thought.py`

- **Rule:** Tests that exercise dspy multi-output signatures must declare a signature with an input list and described maximum/minimum outputs, illustrating multi-output signature usage.
- **Applies to:**
  - `tests/predict/test_program_of_thought.py`
- **Condition:** When modifying program-of-thought tests that cover multi-output signatures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d3a1ce319b4b4936d5d503d0.md)

## Rule 137 — `dspy/evaluate/evaluate.py`

- **Rule:** When modifying dspy/evaluate/evaluate.py, preserve the optional-IPython boundary: IPython.display HTML/display are imported inside a try/except ImportError, so contributors must not assume IPython is installed when using Evaluate.
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** When changing imports or display behavior in dspy/evaluate/evaluate.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d56b3b891529827f05a47584.md)

## Rule 138 — `tests/reliability/generate/__init__.py`

- **Rule:**
  ```text
  The reliability generate package's public surface is defined by tests/reliability/generate/__init__.py re-exporting GeneratedTestCase, generate_test_inputs, generate_test_program, load_generated_cases, and load_generated_program from its utils module; contributors adding or renaming generation utilities must update this package export list.
  ```
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:** when adding, renaming, or removing public generation utilities in the reliability generate package
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d83d0ef36b980466285ddd00.md)

## Rule 139 — `tests/primitives/test_python_interpreter.py`

- **Rule:**
  ```text
  PythonInterpreter must wrap a raised ValueError into InterpreterError with a message matching 'ValueError: [<token>]', preserving the exception-formatting contract.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** when modifying PythonInterpreter exception wrapping or its error-message formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-da9a97900bb6bfccb05a4482.md)

## Rule 140 — `tests/reliability/reliability_tests_conf.yaml`

- **Rule:**
  ```text
  The configuration must specify a DSPy adapter to use when testing, e.g. `"chat"` for `dspy.ChatAdapter` or `"json"` for `dspy.JSONAdapter`.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-dadc244676ef2ca7129bab40.md)

## Rule 141 — `dspy/utils/callback.py`

- **Rule:**
  ```text
  When modifying BaseCallback.on_adapter_format_start, preserve the callback pairing protocol: the call_id parameter is documented as usable to connect start/end handlers for adapter format events.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:**
  ```text
  when changing on_adapter_format_start or the adapter format callback pairing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-deea0c5d44fe09262ede618e.md)

## Rule 142 — `tests/**`

- **Rule:** The test job runs pytest on the tests/ directory via uv run -p .venv pytest tests/.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df71aa664d341e186bca9169.md)

## Rule 143 — `dspy/clients/__init__.py`

- **Rule:**
  ```text
  When modifying the disk cache configuration, preserve DSPY_CACHEDIR and DSPY_CACHE_LIMIT as the supported environment-variable boundary, read at import time with defaults ~/.dspy_cache and 30 GB.
  ```
- **Applies to:**
  - `dspy/clients/__init__.py`
- **Condition:** when changing disk cache location or size limit configuration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e18ef768b0fb5eebffde89ef.md)

## Rule 144 — `tests/reliability/reliability_conf.yaml`

- **Rule:**
  ```text
  The reliability test configuration defines a model_list whose entries include model_name values judge, gpt-4o, gpt-4o-mini, gpt-4-turbo, gpt-o1, gpt-o1-mini, claude-3.5-sonnet, claude-3.5-haiku, gemini-1.5-pro, gemini-1.5-flash, llama-3.1-405b-instruct, llama-3.1-70b-instruct, llama-3.1-8b-instruct, llama-3.2-3b-instruct, and deepseek-r1.
  ```
- **Applies to:**
  - `tests/reliability/reliability_conf.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e29024b9d7cd8870baf77eb6.md)

## Rule 145 — `tests/signatures/test_adapter_image.py`

- **Rule:**
  ```text
  dspy.Image.from_url with download=True on a PDF URL must produce a data URI containing 'data:application/pdf' and ';base64,', and using the image in a predictor must yield exactly one image-url message with application/pdf present.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:**
  ```text
  Modifying dspy.Image.from_url download handling for PDF URLs or the predictor message produced for such images.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e46baab11ed3d1cefae2658c.md)
