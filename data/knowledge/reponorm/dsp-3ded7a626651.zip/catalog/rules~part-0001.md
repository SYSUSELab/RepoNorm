# Full rule catalog

## Rule 001 — `dspy/clients/provider.py`

- **Rule:**
  ```text
  When modifying Provider.kill, preserve the documented no-op contract: the method is a pass that assumes LM.launch_kwargs contains the information needed to launch and/or kill an LM, which is why the parameter is named launch_kwargs rather than kill_kwargs.
  ```
- **Applies to:**
  - `dspy/clients/provider.py`
- **Condition:** when changing Provider.kill or the LM launch/kill parameter naming
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0063ec5ee79d4f819e53d459.md)

## Rule 002 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model-2" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-007397d83d5b29a36480a469.md)

## Rule 003 — `.github/workflows/precommits_check.yml`

- **Rule:** Pull request titles are checked against a regexp requiring a conventional-commit-style type prefix such as break, build, ci, docs, feat, fix, perf, refactor, style, test, ops, hotfix, release, maint, init, enh, or revert, followed by a parenthesized scope and a colon plus description.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-091b079f7ec930defa9e2453.md)

## Rule 004 — `dspy/teleprompt/bettertogether.py`

- **Rule:**
  ```text
  When modifying BetterTogether._compile_weight_optimizer in dspy/teleprompt/bettertogether.py, preserve the post-compile train_kwargs remapping: capture original_lms before compiling, then remap weight_optimizer.train_kwargs from each original LM to the corresponding new LM, because train_kwargs were configured for the original LMs.
  ```
- **Applies to:**
  - `dspy/teleprompt/bettertogether.py`
- **Condition:**
  ```text
  When changing compilation flow or LM bookkeeping in _compile_weight_optimizer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-092c6a54bd94871073fd7944.md)

## Rule 005 — `dspy/datasets/gsm8k.py`

- **Rule:**
  ```text
  When modifying parse_integer_answer in dspy/datasets/gsm8k.py, preserve the silent-fallback contract: take the last whitespace token containing a digit, strip decimals and non-digits, and return 0 on ValueError/IndexError instead of raising.
  ```
- **Applies to:**
  - `dspy/datasets/gsm8k.py`
- **Condition:**
  ```text
  When changing answer extraction or error handling in parse_integer_answer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-09afa8e18cfee8e38438ca2d.md)

## Rule 006 — `dspy/clients/embedding.py`

- **Rule:**
  ```text
  `Embedder._preprocess` normalizes a single string input into a list, rejects non-string inputs with `ValueError`, merges `default_kwargs` with call kwargs, splits inputs into `batch_size` chunks, and returns `is_single_input` so callers can unwrap single-input results.
  ```
- **Applies to:**
  - `dspy/clients/embedding.py`
- **Condition:**
  ```text
  When modifying embedding input preprocessing, preserve string normalization, non-string rejection, kwargs merging, batch splitting, and the `is_single_input` return contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0bdc6fcf33676f5a7106fd25.md)

## Rule 007 — `tests/utils/resources/mcp_server.py`

- **Rule:**
  ```text
  get_account_name must be registered as an MCP tool via the @mcp.tool() decorator and extract the name from an Account's profile, defining the tool's input schema and return value.
  ```
- **Applies to:**
  - `tests/utils/resources/mcp_server.py`
- **Condition:**
  ```text
  when modifying the MCP test server's tool registration or get_account_name behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c1cc353c66612fb874cccb5.md)

## Rule 008 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config sets num_retries to 0.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0d9e6fe6820362358e041db7.md)

## Rule 009 — `dspy/**/*.py`

- **Rule:** Ruff linting/formatting applies to Python files under dspy/ and tests/ as included by the include setting.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0dcee3b53bd57970ff289f00.md)

## Rule 010 — `dspy/propose/grounded_proposer.py`

- **Rule:**
  ```text
  GroundedProposer.__init__ must degrade gracefully: on program source extraction failure it prints an error and sets program_aware=False; on dataset summary creation failure it prints an error and sets use_dataset_summary=False, so proposer construction never raises on these failures.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:**
  ```text
  When modifying GroundedProposer.__init__ error handling for program source extraction or dataset summary creation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0e91f8ea3d9cd3426e6cb910.md)

## Rule 011 — `**/*.py`

- **Rule:** Ruff's formatter is configured to indent with spaces (indent-style = "space").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0f82944dacd3a7ed8153ca2c.md)

## Rule 012 — `dspy/retrievers/databricks_rm.py`

- **Rule:**
  ```text
  The Databricks retriever `Document` dataclass carries `page_content`, `metadata`, and a `type` field, defining the document shape returned by this retriever.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:**
  ```text
  When modifying the Databricks retriever's document model, preserve the `page_content`, `metadata`, and `type` fields.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-103b550b688e4da603bfcd2d.md)

## Rule 013 — `dspy/primitives/module.py`

- **Rule:**
  ```text
  When modifying BaseModule.reset_copy, preserve deep-copy semantics: the returned copy has its parameters reset via param.reset() while the original module's parameters remain untouched.
  ```
- **Applies to:**
  - `dspy/primitives/module.py`
- **Condition:**
  ```text
  Modifying BaseModule.reset_copy or its parameter-reset behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-114a5628549216854f156440.md)

## Rule 014 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The search plugin is configured with lang en, separator '[\s\-\.]+', min_search_length 2, prebuild_index true, indexing 'full', properties [title, tags, content, sections], and search_index_only false.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1167247d70e0861dd075e9ff.md)

## Rule 015 — `tests/predict/test_predict.py`

- **Rule:**
  ```text
  Predict.load_state(dumped_state) must overwrite the target Predict's signature instructions with the dumped instance's instructions, so instructions are part of serialized state.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  when modifying Predict state serialization or load_state behavior for signature instructions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-13fbebc74b55c85621723b34.md)

## Rule 016 — `**/*.py`

- **Rule:** Python 3.9 or later is required for the DSPy development environment.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-15ad07f663a8fbfa838041d4.md)
