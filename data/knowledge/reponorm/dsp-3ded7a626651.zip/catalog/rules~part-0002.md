# Full rule catalog

## Rule 017 — `tests/retrievers/test_embeddings.py`

- **Rule:** Tests that exercise Embeddings retrieval must assert that Embeddings(corpus, embedder, k=1) returns list-typed passages and indices of length 1, and that the top passage for a query matches the expected corpus entry.
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** when modifying or adding tests for Embeddings retrieval
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1b670b9fc424a14fef54e081.md)

## Rule 018 — `dspy/propose/utils.py`

- **Rule:**
  ```text
  `strip_prefix` removes a leading optional prefix of up to five word-like tokens followed by a colon via regex, then strips surrounding double quotes from the result.
  ```
- **Applies to:**
  - `dspy/propose/utils.py`
- **Condition:**
  ```text
  When modifying `strip_prefix` or its callers, preserve the regex-based prefix removal (up to five word-like tokens plus colon) and the subsequent double-quote stripping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1c433e718fe90e4b08113092.md)

## Rule 019 — `**`

- **Rule:**
  ```text
  The check-added-large-files pre-commit hook runs with args ["--maxkb=1024"].
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1d1c80d9a99db9ed0c05d555.md)

## Rule 020 — `tests/propose/test_grounded_proposer.py`

- **Rule:**
  ```text
  GroundedProposer.propose_instruction_for_predictor must accept demo_candidates as optional (None or nested example lists) without changing its return type.
  ```
- **Applies to:**
  - `tests/propose/test_grounded_proposer.py`
- **Condition:**
  ```text
  When modifying propose_instruction_for_predictor or its test, keep demo_candidates optional and preserve the model-proposed instruction string return.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-201ec1dc7b4f03aeb06b68f8.md)

## Rule 021 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  _clean_schema must recursively strip __dspy_field_type and title keys from JSON schema properties, including nested dicts, so generated schemas omit DSPy-internal and title metadata.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _clean_schema or schema-cleaning behavior used by reliability tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-20cc42f31b8bfaa2ca35904a.md)

## Rule 022 — `tests/teleprompt/test_knn_fewshot.py`

- **Rule:**
  ```text
  Tests for KNNFewShot.compile must assert that the compiled student predictor has exactly one demo matching trainset[0]'s input/output and that forwarding a similar query returns one of the DummyLM responses.
  ```
- **Applies to:**
  - `tests/teleprompt/test_knn_fewshot.py`
- **Condition:** When adding or modifying tests for KNNFewShot.compile demo selection and forwarding behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-22b79b2219d51bf96904c588.md)

## Rule 023 — `dspy/clients/provider.py`

- **Rule:**
  ```text
  When modifying Provider.is_provider_model, preserve the default False return and the documented requirement that subclasses override it to enable model provider auto-discovery.
  ```
- **Applies to:**
  - `dspy/clients/provider.py`
- **Condition:**
  ```text
  when changing Provider.is_provider_model or provider auto-discovery behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-233ee67aff19e1e9f7ba0e11.md)

## Rule 024 — `dspy/predict/chain_of_thought_with_hint.py`

- **Rule:**
  ```text
  When modifying ChainOfThoughtWithHint.forward, preserve hint handling: when a hint kwarg is present, append it to the last input field's string value, run the module inside dspy.context(trace=[]) so the hinted call is not recorded, then replace the trace entry with the original kwargs so the hint is not persisted in the trace.
  ```
- **Applies to:**
  - `dspy/predict/chain_of_thought_with_hint.py`
- **Condition:** Modifying ChainOfThoughtWithHint.forward or its hint/trace handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-23729c40987c8ef1832aa3fa.md)

## Rule 025 — `tests/reliability/reliability_tests_conf.yaml`

- **Rule:**
  ```text
  Populate `reliability_tests_conf.yaml` in the reliability tests directory with LiteLLM model/provider names and access credentials for each LLM to test and for the LLM judge, placing them in the `litellm_params` section of each model in the defined `model_list`.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-2515b4b431c1dd629cc9aa5a.md)

## Rule 026 — `dspy/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  The dspy-ai package declares a runtime dependency on dspy>=2.6.5.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-255cd3d017a9d368fcdae665.md)

## Rule 027 — `dspy/teleprompt/copro_optimizer.py`

- **Rule:**
  ```text
  Predictors passed to the COPRO optimizer must expose a `signature` attribute; `_get_signature` asserts its presence before returning it.
  ```
- **Applies to:**
  - `dspy/teleprompt/copro_optimizer.py`
- **Condition:**
  ```text
  When modifying COPRO's signature resolution or the predictor interface it consumes, preserve the requirement that the predictor exposes a `signature` attribute.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2869a605bfb3b853681c6300.md)

## Rule 028 — `**/*.py`

- **Rule:** Ruff linting enables the rule sets E, W, F, I, C, B, UP, N, RUF, and Q.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-28a53889ac312fb0befa4e5e.md)

## Rule 029 — `dspy/utils/usage_tracker.py`

- **Rule:**
  ```text
  UsageTracker._flatten_usage_entry must copy the usage entry and convert completion_tokens_details and prompt_tokens_details to plain dicts when present, defining the flattened usage record shape.
  ```
- **Applies to:**
  - `dspy/utils/usage_tracker.py`
- **Condition:**
  ```text
  When modifying UsageTracker._flatten_usage_entry normalization logic in dspy/utils/usage_tracker.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c4350ee350c7de7ac48c27c.md)

## Rule 030 — `tests/test_utils/server/__init__.py`

- **Rule:**
  ```text
  read_litellm_test_server_request_logs must read a LiteLLM server request-log jsonlines file and return one parsed dict per request, defining the log format used by DSPy integration tests.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** When modifying how integration tests read LiteLLM server request logs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2c8ee07cfadaf3fe398e5ea1.md)

## Rule 031 — `dspy/datasets/dataloader.py`

- **Rule:** When modifying DataLoader.sample in dspy/datasets/dataloader.py, preserve the input-validation contract: raise ValueError when the dataset argument is not a list, so callers must pass a list of dspy.Example objects.
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:** When changing argument handling or validation in DataLoader.sample.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2ebb6ce60fdf1b4dd39eef43.md)
