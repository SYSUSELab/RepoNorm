# Full rule catalog

## Rule 032 — `dspy/primitives/__init__.py`

- **Rule:**
  ```text
  dspy.primitives.__all__ must export Example, BaseModule, Prediction, Completions, Program, Module, and PythonInterpreter as the stable primitives namespace.
  ```
- **Applies to:**
  - `dspy/primitives/__init__.py`
- **Condition:**
  ```text
  When modifying dspy.primitives.__init__ exports or the primitives public namespace.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2feb9941203673c23666cbc7.md)

## Rule 033 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  generate_test_program must retry up to 5 times with caching disabled and temperature=0.5, rename conflicting output fields, validate the generated program by loading it before copying to dst_path, and write a cleaned schema.json; contributors modifying generation must preserve these retry, validation, and cleanup steps.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying the reliability test-program generation pipeline or its retry and validation behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-303a8db5f8d883c8948e510c.md)

## Rule 034 — `**/*.py`

- **Rule:** Ruff's formatter is configured to not format code inside docstrings (docstring-code-format = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-31200a50a8da917971db74be.md)

## Rule 035 — `pyproject.toml`

- **Rule:**
  ```text
  The dspy package includes the JavaScript files matching primitives/*.js as package data.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3197efba78e85db0ff2ea46c.md)

## Rule 036 — `**/*.py`

- **Rule:**
  ```text
  Coverage reporting excludes lines matching the configured exclude_lines patterns, including "pragma: no cover", "def __repr__", "if self.debug:", "raise AssertionError", "raise NotImplementedError", "if __name__ == '__main__':", "logger", "try", "except", the regex "^\s*self\.\w+(:\s*[^=]+)?\s*=.*$", and "continue".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-33329d0ff3cb63a5a2002039.md)

## Rule 037 — `dspy/__init__.py`

- **Rule:**
  ```text
  Ruff per-file ignores for dspy/__init__.py disable I001, E402, and F405.
  ```
- **Applies to:**
  - `dspy/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3baef81d6cf17a5dee8992ca.md)

## Rule 038 — `pyproject.toml`

- **Rule:** Package discovery for setuptools searches from the repository root directory (".").
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3ee4aa68d890321b2090fe5d.md)

## Rule 039 — `tests/callback/test_callback.py`

- **Rule:** Callbacks registered on a module must be invoked for both start and end events of a single forward call.
- **Applies to:**
  - `tests/callback/test_callback.py`
- **Condition:** Modifying callback invocation semantics or the number of callback invocations per forward call.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-40385ee0f6187e3cd8dc1c19.md)

## Rule 040 — `tests/reliability/reliability_conf.yaml`

- **Rule:** The reliability test configuration sets adapter to chat.
- **Applies to:**
  - `tests/reliability/reliability_conf.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-430484a74890aa525277a2cd.md)

## Rule 041 — `dspy/datasets/dataloader.py`

- **Rule:**
  ```text
  DataLoader.from_parquet must default fields to all dataset features when none are supplied and always wrap each row in dspy.Example(...).with_inputs(*input_keys).
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  When modifying DataLoader.from_parquet field defaulting or row-to-Example conversion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-448e127eb232dba269b00fb3.md)

## Rule 042 — `tests/reliability/utils.py`

- **Rule:** The reliability judge program must be dspy.Predict over JudgeSignature.
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  When modifying _get_judge_program or the reliability judge construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-44d355ba105b702758af4985.md)

## Rule 043 — `dspy/datasets/alfworld/__init__.py`

- **Rule:** dspy.datasets.alfworld must re-export AlfWorld from dspy.datasets.alfworld.alfworld so it is available at the package level.
- **Applies to:**
  - `dspy/datasets/alfworld/__init__.py`
- **Condition:** when modifying the dspy.datasets.alfworld package exports
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-454ab63d4672f0e8be24614e.md)

## Rule 044 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  Reliability test-input generation must use dspy.ChainOfThought over the _TestInputsGeneration signature.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _get_test_inputs_generation_program or the test-input generation program construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-45c9a806928a5e815266c079.md)

## Rule 045 — `dspy/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the package name in `./dspy/.internal_dspyai/pyproject.toml` to `dspy-ai` using a sed command keyed on the `#replace_package_name_marker`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-45d61da57a133cea00fe7e2b.md)

## Rule 046 — `tests/examples/test_baleen.py`

- **Rule:**
  ```text
  gold_passages_retrieved must normalize gold and predicted context titles by splitting on ' | ' and taking the first segment, then return whether gold titles are a subset of found titles.
  ```
- **Applies to:**
  - `tests/examples/test_baleen.py`
- **Condition:** Modifying the retrieval evaluation metric or its title normalization and subset comparison.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4ab15ce235b71767814db7bc.md)

## Rule 047 — `dspy/adapters/types/image.py`

- **Rule:**
  ```text
  When modifying Image.__str__, preserve delegation to serialize_model() so that string conversion of an image uses the model serialization format rather than a separate ad-hoc representation.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  when changing Image.__str__ or the image string representation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-51bfbf3af64e0745218678db.md)

## Rule 048 — `**`

- **Rule:**
  ```text
  The workflow merges the release branch into main with `git merge --no-ff release-${{ needs.extract-tag.outputs.version }}` and pushes to main with `git push origin main`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-55a55af5d7708671d3e62b43.md)

## Rule 049 — `**/__init__.py`

- **Rule:**
  ```text
  Ruff per-file ignores for __init__.py disable F401.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-570e0f3f06a75f05547a5bb2.md)
