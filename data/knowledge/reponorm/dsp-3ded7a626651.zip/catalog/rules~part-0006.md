# Full rule catalog

## Rule 084 — `dspy/.internal_dspyai/**`

- **Rule:**
  ```text
  The workflow builds the dspy-ai binary wheel by running `python3 -m build ./dspy/.internal_dspyai/`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-86b88ebb6c5160e303febccd.md)

## Rule 085 — `dspy/utils/langchain_tool.py`

- **Rule:**
  ```text
  langchain_tool must import BaseTool only under TYPE_CHECKING so LangChain remains an optional runtime dependency for this module.
  ```
- **Applies to:**
  - `dspy/utils/langchain_tool.py`
- **Condition:**
  ```text
  when modifying imports or LangChain integration in dspy/utils/langchain_tool.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-895c8cd68ffc48c4bc7ff7ac.md)

## Rule 086 — `tests/caching/test_litellm_cache.py`

- **Rule:**
  ```text
  Tests that exercise dspy cache-key generation failures must assert that when litellm.completion raises RuntimeError, the LM call is not retried and mock_completion.call_count remains exactly 1.
  ```
- **Applies to:**
  - `tests/caching/test_litellm_cache.py`
- **Condition:** When modifying caching tests that cover cache-key generation failure paths.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8af01cfbf7fec95bf2d664d5.md)

## Rule 087 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  Ruff excludes dspy/__metadata__.py, dspy/retrieve/*.py, tests/reliability/*.py, and tests/retrieve/*.py from its checks.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `dspy/retrieve/*.py`
  - `tests/reliability/*.py`
  - `tests/retrieve/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8b4a63c36333829d1765e1a4.md)

## Rule 088 — `tests/reliability/test_generated.py`

- **Rule:**
  ```text
  Generated reliability cases are loaded relative to the test directory via _DIR_PATH computed from the test file location, using load_generated_cases and run_generated_case from tests.reliability.generate.utils; contributors moving or adding generated cases must keep them resolvable relative to the test file.
  ```
- **Applies to:**
  - `tests/reliability/test_generated.py`
- **Condition:** when adding, moving, or modifying generated reliability cases or the test harness that loads them
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8c6296c783e76abfe85377d9.md)

## Rule 089 — `tests/predict/test_predict.py`

- **Rule:** Predict call path must return the LM output as result.output when invoked with an input.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** Modifying the basic Predict call path or its result.output contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8d417d9bcf36d80afd3d6aa2.md)

## Rule 090 — `.github/workflows/build_and_release.yml`

- **Rule:** The PyPI job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8e66214383e3c4dafeff67e1.md)

## Rule 091 — `dspy/retrievers/weaviate_rm.py`

- **Rule:**
  ```text
  When modifying WeaviateRM in dspy/retrievers/weaviate_rm.py, preserve the retriever contract: it subclasses dspy.Retrieve and assumes a Weaviate collection populated with a 'content' payload field, with constructor args weaviate_collection_name, weaviate_client, k (default 3), and tenant_id.
  ```
- **Applies to:**
  - `dspy/retrievers/weaviate_rm.py`
- **Condition:** When changing WeaviateRM's constructor signature or its assumptions about the Weaviate collection payload.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-91e93e86246f2dea11cdc3e8.md)

## Rule 092 — `tests/**/*.py`

- **Rule:**
  ```text
  Ruff per-file ignores for tests/**/*.py disable S101, TID252, and ARG001.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-926e26e4c2626faf61975918.md)

## Rule 093 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  rename_conflicting_fields must append '_output' to any output property whose name collides with an input property and update the output schema's required list accordingly, so contributors adding schema fields must not introduce input/output name clashes without this renaming.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When adding or modifying input/output schema fields in the reliability test generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-93672ab99c615379fe5bf1ff.md)

## Rule 094 — `dspy/predict/avatar/signatures.py`

- **Rule:** dspy.predict.avatar.signatures must import dspy and Action from dspy.predict.avatar.models, preserving the dependency direction for avatar signature definitions.
- **Applies to:**
  - `dspy/predict/avatar/signatures.py`
- **Condition:** When modifying imports in dspy.predict.avatar.signatures or the avatar signature dependency direction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9372436a4cb6bb161ed6b757.md)

## Rule 095 — `tests/signatures/test_adapter_image.py`

- **Rule:** Tests that exercise dspy optional image fields must assert that passing image=None yields the expected output and that LM history contains zero messages with an image URL pattern, verifying optional images are omitted from requests.
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** When modifying tests for optional image fields in signatures or adapters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-95a50210b12af8282dafb96a.md)

## Rule 096 — `dspy/adapters/xml_adapter.py`

- **Rule:**
  ```text
  When modifying XMLAdapter.parse, preserve the strict output-field contract: extract only fields matching signature.output_fields, keep the first occurrence of each field, cast values via _parse_field_value, and raise AdapterParseError when parsed field keys do not exactly match the signature's output fields.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:** when changing XMLAdapter.parse or its output-field extraction and validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9a2de8aed755f90ec0bcb4b7.md)

## Rule 097 — `dspy/dsp/utils/utils.py`

- **Rule:**
  ```text
  `create_directory` prints a note and skips `makedirs` when the path already exists, otherwise prints a creating message and calls `os.makedirs`, making directory creation idempotent with user-visible messaging.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:**
  ```text
  When modifying directory creation, preserve idempotence: skip `makedirs` with a note when the path exists, otherwise create with a message.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9ba2417b0d86998ff0646697.md)

## Rule 098 — `**/*.py`

- **Rule:** Ruff's flake8-tidy-imports rule bans all relative imports.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9c92a61af393574b06cd43d4.md)

## Rule 099 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The PyPI job updates the package name in ./dspy/__metadata__.py to dspy by replacing the line after the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9cec14ccf3ff8d0baaae29c2.md)
