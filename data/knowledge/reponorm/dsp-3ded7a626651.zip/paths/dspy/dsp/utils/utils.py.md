# Rules for `dspy/dsp/utils/utils.py`

## Rule 097 — `dspy/dsp/utils/utils.py`

- **Rule:**
  ```text
  `create_directory` prints a note and skips `makedirs` when the path already exists, otherwise prints a creating message and calls `os.makedirs`, making directory creation idempotent with user-visible messaging.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:**
  ```text
  When modifying directory creation, preserve idempotence: skip `makedirs` with a note when the path exists, otherwise create with a message.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9ba2417b0d86998ff0646697.md)
