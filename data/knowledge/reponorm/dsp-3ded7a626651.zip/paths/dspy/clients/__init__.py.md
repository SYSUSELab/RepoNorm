# Rules for `dspy/clients/__init__.py`

## Rule 134 — `dspy/clients/__init__.py`

- **Rule:**
  ```text
  _litellm_track_cache_hit_callback must set completion_response.cache_hit from kwargs.get('cache_hit', False), making cache_hit a boolean attribute on the completion response.
  ```
- **Applies to:**
  - `dspy/clients/__init__.py`
- **Condition:**
  ```text
  When modifying the litellm cache-hit tracking callback or the completion response cache_hit attribute.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d240d68cf905e5084df94481.md)

## Rule 143 — `dspy/clients/__init__.py`

- **Rule:**
  ```text
  When modifying the disk cache configuration, preserve DSPY_CACHEDIR and DSPY_CACHE_LIMIT as the supported environment-variable boundary, read at import time with defaults ~/.dspy_cache and 30 GB.
  ```
- **Applies to:**
  - `dspy/clients/__init__.py`
- **Condition:** when changing disk cache location or size limit configuration
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e18ef768b0fb5eebffde89ef.md)
