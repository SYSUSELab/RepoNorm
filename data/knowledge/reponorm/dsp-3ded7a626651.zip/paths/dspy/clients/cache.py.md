# Rules for `dspy/clients/cache.py`

## Rule 062 — `dspy/clients/cache.py`

- **Rule:**
  ```text
  When modifying request_cache, preserve the default ignored_args_for_cache_key of ['api_key','api_base','base_url'] so connection-credential arguments are excluded from cache keys unless explicitly overridden.
  ```
- **Applies to:**
  - `dspy/clients/cache.py`
- **Condition:**
  ```text
  when changing request_cache or the cache key argument exclusion defaults
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-663329ea2d0bb139cce1dde9.md)
