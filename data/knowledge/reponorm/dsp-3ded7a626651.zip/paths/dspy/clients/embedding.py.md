# Rules for `dspy/clients/embedding.py`

## Rule 006 — `dspy/clients/embedding.py`

- **Rule:**
  ```text
  `Embedder._preprocess` normalizes a single string input into a list, rejects non-string inputs with `ValueError`, merges `default_kwargs` with call kwargs, splits inputs into `batch_size` chunks, and returns `is_single_input` so callers can unwrap single-input results.
  ```
- **Applies to:**
  - `dspy/clients/embedding.py`
- **Condition:**
  ```text
  When modifying embedding input preprocessing, preserve string normalization, non-string rejection, kwargs merging, batch splitting, and the `is_single_input` return contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0bdc6fcf33676f5a7106fd25.md)

## Rule 072 — `dspy/clients/embedding.py`

- **Rule:**
  ```text
  The embedding client module routes embedding requests through the shared request cache by importing `request_cache` from `dspy.clients.cache`.
  ```
- **Applies to:**
  - `dspy/clients/embedding.py`
- **Condition:** When modifying embedding request handling, preserve routing through the shared request cache rather than bypassing it.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7310c8b5bffbe84c693a8367.md)
