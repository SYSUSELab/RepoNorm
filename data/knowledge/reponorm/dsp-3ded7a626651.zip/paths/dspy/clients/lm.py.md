# Rules for `dspy/clients/lm.py`

## Rule 061 — `dspy/clients/lm.py`

- **Rule:**
  ```text
  When modifying litellm_text_completion in dspy/clients/lm.py, preserve the model-string and credential contract: parse 'provider/model' with provider defaulting to 'openai' when no slash is present, read API key/base from the request or {provider}_API_KEY/{provider}_API_BASE environment variables, and call litellm.text_completion with 'text-completion-openai/{model}' and exponential-backoff retry.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:**
  ```text
  When changing model-string parsing, credential resolution, or the litellm call in litellm_text_completion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6512166d027cc844ba01c48b.md)
