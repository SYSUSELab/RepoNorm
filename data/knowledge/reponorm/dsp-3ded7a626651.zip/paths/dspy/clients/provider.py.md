# Rules for `dspy/clients/provider.py`

## Rule 001 — `dspy/clients/provider.py`

- **Rule:**
  ```text
  When modifying Provider.kill, preserve the documented no-op contract: the method is a pass that assumes LM.launch_kwargs contains the information needed to launch and/or kill an LM, which is why the parameter is named launch_kwargs rather than kill_kwargs.
  ```
- **Applies to:**
  - `dspy/clients/provider.py`
- **Condition:** when changing Provider.kill or the LM launch/kill parameter naming
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0063ec5ee79d4f819e53d459.md)

## Rule 023 — `dspy/clients/provider.py`

- **Rule:**
  ```text
  When modifying Provider.is_provider_model, preserve the default False return and the documented requirement that subclasses override it to enable model provider auto-discovery.
  ```
- **Applies to:**
  - `dspy/clients/provider.py`
- **Condition:**
  ```text
  when changing Provider.is_provider_model or provider auto-discovery behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-233ee67aff19e1e9f7ba0e11.md)
