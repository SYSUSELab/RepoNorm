# Rules for `dspy/utils/usage_tracker.py`

## Rule 029 — `dspy/utils/usage_tracker.py`

- **Rule:**
  ```text
  UsageTracker._flatten_usage_entry must copy the usage entry and convert completion_tokens_details and prompt_tokens_details to plain dicts when present, defining the flattened usage record shape.
  ```
- **Applies to:**
  - `dspy/utils/usage_tracker.py`
- **Condition:**
  ```text
  When modifying UsageTracker._flatten_usage_entry normalization logic in dspy/utils/usage_tracker.py.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2c4350ee350c7de7ac48c27c.md)

## Rule 069 — `dspy/utils/usage_tracker.py`

- **Rule:** UsageTracker must store usage entries in a defaultdict(list) keyed by LM name, so callers can append per-call token usage without pre-initializing keys.
- **Applies to:**
  - `dspy/utils/usage_tracker.py`
- **Condition:** When modifying UsageTracker initialization or the per-LM usage storage structure.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6e40e391e9a449d74b5c0a25.md)

## Rule 126 — `dspy/utils/usage_tracker.py`

- **Rule:**
  ```text
  `track_usage` is a context manager that installs a fresh `UsageTracker` via `settings.context(usage_tracker=tracker)` and yields it, so usage tracking is scoped to the context block.
  ```
- **Applies to:**
  - `dspy/utils/usage_tracker.py`
- **Condition:**
  ```text
  When modifying usage tracking, preserve the context-manager scoping that installs a fresh `UsageTracker` via `settings.context` and yields it.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c8ffe4d9f38e1598bc740bb3.md)
