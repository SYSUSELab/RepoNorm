# Rules for `dspy/utils/unbatchify.py`

## Rule 124 — `dspy/utils/unbatchify.py`

- **Rule:**
  ```text
  Unbatchify.__exit__ must delegate to self.close() so resource cleanup is guaranteed on context exit regardless of exception type.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:**
  ```text
  When modifying Unbatchify.__exit__ or its context-manager cleanup path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c6aa5cf4ec1bc79d80e15ec8.md)
