# Rules for `dspy/utils/callback.py`

## Rule 129 — `dspy/utils/callback.py`

- **Rule:**
  ```text
  When modifying BaseCallback.on_adapter_format_end, preserve the callback contract: it receives call_id, optional outputs, and optional exception; outputs are None when the adapter's format() is interrupted by an exception, and call_id links the start/end handlers.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:**
  ```text
  Modifying BaseCallback.on_adapter_format_end or the adapter format callback protocol.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc298c6d0e27f11e076599e1.md)

## Rule 141 — `dspy/utils/callback.py`

- **Rule:**
  ```text
  When modifying BaseCallback.on_adapter_format_start, preserve the callback pairing protocol: the call_id parameter is documented as usable to connect start/end handlers for adapter format events.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:**
  ```text
  when changing on_adapter_format_start or the adapter format callback pairing
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-deea0c5d44fe09262ede618e.md)

## Rule 152 — `dspy/utils/callback.py`

- **Rule:**
  ```text
  When modifying BaseCallback in dspy/utils/callback.py, preserve the callback registration contract: handlers fire before/after component execution and can be registered globally via dspy.settings.configure(callbacks=[...]) or locally per component (e.g. dspy.LM(..., callbacks=[...])), with local callbacks scoped to that instance.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:** When changing callback registration, scoping, or before/after execution hooks.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ebf5f800b676f6d96cc8379e.md)
