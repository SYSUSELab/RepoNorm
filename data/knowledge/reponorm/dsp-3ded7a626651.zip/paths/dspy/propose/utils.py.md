# Rules for `dspy/propose/utils.py`

## Rule 018 — `dspy/propose/utils.py`

- **Rule:**
  ```text
  `strip_prefix` removes a leading optional prefix of up to five word-like tokens followed by a colon via regex, then strips surrounding double quotes from the result.
  ```
- **Applies to:**
  - `dspy/propose/utils.py`
- **Condition:**
  ```text
  When modifying `strip_prefix` or its callers, preserve the regex-based prefix removal (up to five word-like tokens plus colon) and the subsequent double-quote stripping.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1c433e718fe90e4b08113092.md)
