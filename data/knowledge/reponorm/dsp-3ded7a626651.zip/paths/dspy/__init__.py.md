# Rules for `dspy/__init__.py`

## Rule 037 — `dspy/__init__.py`

- **Rule:**
  ```text
  Ruff per-file ignores for dspy/__init__.py disable I001, E402, and F405.
  ```
- **Applies to:**
  - `dspy/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3baef81d6cf17a5dee8992ca.md)

## Rule 105 — `dspy/__init__.py`

- **Rule:**
  ```text
  When modifying dspy/__init__.py, preserve the top-level re-exports of adapter classes (Adapter, ChatAdapter, JSONAdapter, XMLAdapter, TwoStepAdapter) and types (Image, Audio, History, BaseType, Tool, ToolCalls), and keep the BootstrapRS alias to BootstrapFewShotWithRandomSearch and the cache alias to DSPY_CACHE.
  ```
- **Applies to:**
  - `dspy/__init__.py`
- **Condition:** Modifying the top-level dspy package exports or aliases.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a80a8c5d69698e8bacefdf7e.md)
