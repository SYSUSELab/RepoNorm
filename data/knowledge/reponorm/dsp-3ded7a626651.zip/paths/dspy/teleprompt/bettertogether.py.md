# Rules for `dspy/teleprompt/bettertogether.py`

## Rule 004 — `dspy/teleprompt/bettertogether.py`

- **Rule:**
  ```text
  When modifying BetterTogether._compile_weight_optimizer in dspy/teleprompt/bettertogether.py, preserve the post-compile train_kwargs remapping: capture original_lms before compiling, then remap weight_optimizer.train_kwargs from each original LM to the corresponding new LM, because train_kwargs were configured for the original LMs.
  ```
- **Applies to:**
  - `dspy/teleprompt/bettertogether.py`
- **Condition:**
  ```text
  When changing compilation flow or LM bookkeeping in _compile_weight_optimizer.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-092c6a54bd94871073fd7944.md)
