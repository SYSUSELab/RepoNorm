# Rules for `dspy/teleprompt/simba_utils.py`

## Rule 057 — `dspy/teleprompt/simba_utils.py`

- **Rule:**
  ```text
  `wrap_program` takes a `dspy.Module` and a metric callable and returns a `wrapped_program`, defining the extension point for adapting programs to the SimBA optimizer.
  ```
- **Applies to:**
  - `dspy/teleprompt/simba_utils.py`
- **Condition:**
  ```text
  When modifying SimBA program adaptation, preserve `wrap_program`'s signature accepting a `dspy.Module` and metric callable and returning a wrapped program.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-60a0ff457f3e862d9fca4104.md)
