# Rules for `dspy/teleprompt/infer_rules.py`

## Rule 052 — `dspy/teleprompt/infer_rules.py`

- **Rule:**
  ```text
  When modifying CustomRulesInduction, preserve the dynamic __doc__ contract: __doc__ is set using num_rules to instruct extraction of a list of num_rules concise, non-redundant natural-language rules, with inputs examples_text and output natural_language_rules.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when changing CustomRulesInduction or its dynamic __doc__ construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5a3872bb735db482970bcbfb.md)
