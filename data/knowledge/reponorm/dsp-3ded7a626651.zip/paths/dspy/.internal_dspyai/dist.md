# Rules for `dspy/.internal_dspyai/dist`

## Rule 051 — `dspy/.internal_dspyai/dist/**`

- **Rule:**
  ```text
  The workflow publishes the dspy-ai distribution to PyPI using `pypa/gh-action-pypi-publish@release/v1` with `attestations: false` and `packages-dir: ./dspy/.internal_dspyai/dist/`.
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/dist/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-58d33cb1dc044109c6ffdb31.md)
