# Rules for `dspy/evaluate/evaluate.py`

## Rule 137 — `dspy/evaluate/evaluate.py`

- **Rule:** When modifying dspy/evaluate/evaluate.py, preserve the optional-IPython boundary: IPython.display HTML/display are imported inside a try/except ImportError, so contributors must not assume IPython is installed when using Evaluate.
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** When changing imports or display behavior in dspy/evaluate/evaluate.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d56b3b891529827f05a47584.md)
