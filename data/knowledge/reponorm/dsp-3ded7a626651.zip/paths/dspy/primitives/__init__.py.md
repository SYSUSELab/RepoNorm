# Rules for `dspy/primitives/__init__.py`

## Rule 032 — `dspy/primitives/__init__.py`

- **Rule:**
  ```text
  dspy.primitives.__all__ must export Example, BaseModule, Prediction, Completions, Program, Module, and PythonInterpreter as the stable primitives namespace.
  ```
- **Applies to:**
  - `dspy/primitives/__init__.py`
- **Condition:**
  ```text
  When modifying dspy.primitives.__init__ exports or the primitives public namespace.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2feb9941203673c23666cbc7.md)
