# Rules for `dspy/primitives/module.py`

## Rule 013 — `dspy/primitives/module.py`

- **Rule:**
  ```text
  When modifying BaseModule.reset_copy, preserve deep-copy semantics: the returned copy has its parameters reset via param.reset() while the original module's parameters remain untouched.
  ```
- **Applies to:**
  - `dspy/primitives/module.py`
- **Condition:**
  ```text
  Modifying BaseModule.reset_copy or its parameter-reset behavior.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-114a5628549216854f156440.md)
