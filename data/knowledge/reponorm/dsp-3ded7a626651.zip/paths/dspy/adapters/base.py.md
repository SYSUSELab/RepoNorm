# Rules for `dspy/adapters/base.py`

## Rule 059 — `dspy/adapters/base.py`

- **Rule:**
  ```text
  When modifying Adapter._get_tool_call_output_field_name, preserve the selection rule: return the name of the first output field whose annotation is ToolCalls, or None if no such field exists.
  ```
- **Applies to:**
  - `dspy/adapters/base.py`
- **Condition:**
  ```text
  when changing _get_tool_call_output_field_name or tool-call output field detection
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-62089838044d1243966717bc.md)

## Rule 114 — `dspy/adapters/base.py`

- **Rule:**
  ```text
  When modifying Adapter.format_field_structure, preserve its role as a required override: the base declaration raises NotImplementedError so adapter subclasses must define the system-message field format.
  ```
- **Applies to:**
  - `dspy/adapters/base.py`
- **Condition:**
  ```text
  Modifying Adapter.format_field_structure or the adapter subclass contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-af746150c62785e2b65b727e.md)
