# Rules for `dspy/adapters/chat_adapter.py`

## Rule 076 — `dspy/adapters/chat_adapter.py`

- **Rule:**
  ```text
  ChatAdapter.format_field_structure must place input and output fields in separate sections using '[[ ## field_name ## ]]' markers and append a '[[ ## completed ## ]]' marker to terminate the output fields section.
  ```
- **Applies to:**
  - `dspy/adapters/chat_adapter.py`
- **Condition:**
  ```text
  When modifying ChatAdapter.format_field_structure or the chat adapter field-section formatting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-74ea8e6d8251fc4359ab7529.md)

## Rule 111 — `dspy/adapters/chat_adapter.py`

- **Rule:**
  ```text
  ChatAdapter.__call__ must fall back to JSONAdapter when the superclass call raises, except that ContextWindowExceededError and calls where self is already a JSONAdapter must re-raise the original exception.
  ```
- **Applies to:**
  - `dspy/adapters/chat_adapter.py`
- **Condition:**
  ```text
  When modifying ChatAdapter.__call__ or its exception handling around the superclass adapter call.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-acc201691ba26e7fdab4d315.md)
