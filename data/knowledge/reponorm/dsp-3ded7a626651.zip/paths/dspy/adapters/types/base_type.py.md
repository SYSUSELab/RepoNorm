# Rules for `dspy/adapters/types/base_type.py`

## Rule 160 — `dspy/adapters/types/base_type.py`

- **Rule:**
  ```text
  When modifying BaseType.serialize_model, preserve the list-valued format() wrapping: list outputs must be wrapped in CUSTOM_TYPE_START_IDENTIFIER/CUSTOM_TYPE_END_IDENTIFIER markers, while non-list formatted values are returned unchanged.
  ```
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:**
  ```text
  when changing BaseType.serialize_model or the format() output handling for custom types
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fe1a2ba4b93a8178cf30a4d8.md)
