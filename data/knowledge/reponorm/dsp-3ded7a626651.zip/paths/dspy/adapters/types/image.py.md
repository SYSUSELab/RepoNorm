# Rules for `dspy/adapters/types/image.py`

## Rule 047 — `dspy/adapters/types/image.py`

- **Rule:**
  ```text
  When modifying Image.__str__, preserve delegation to serialize_model() so that string conversion of an image uses the model serialization format rather than a separate ad-hoc representation.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  when changing Image.__str__ or the image string representation
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-51bfbf3af64e0745218678db.md)

## Rule 103 — `dspy/adapters/types/image.py`

- **Rule:**
  ```text
  `_encode_image_from_file` reads the file, guesses MIME type from the path via `mimetypes`, raises `ValueError` when the MIME type cannot be determined, and returns a `data:<mime>;base64,<data>` URI.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  When modifying image encoding from files, preserve the MIME-type guessing, the `ValueError` on undetermined MIME type, and the `data:<mime>;base64,<data>` URI format.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a351a66ed0bf8e06e88b69b7.md)

## Rule 109 — `dspy/adapters/types/image.py`

- **Rule:**
  ```text
  `Image.from_PIL` constructs an image by encoding the PIL image into a URL via `encode_image`, so PIL images are represented as encoded URL strings in the adapter image type.
  ```
- **Applies to:**
  - `dspy/adapters/types/image.py`
- **Condition:**
  ```text
  When modifying PIL image conversion, preserve representation as an encoded URL string via `encode_image`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ac93a39e53da9491326d846d.md)
