# Rules for `dspy/adapters/xml_adapter.py`

## Rule 096 — `dspy/adapters/xml_adapter.py`

- **Rule:**
  ```text
  When modifying XMLAdapter.parse, preserve the strict output-field contract: extract only fields matching signature.output_fields, keep the first occurrence of each field, cast values via _parse_field_value, and raise AdapterParseError when parsed field keys do not exactly match the signature's output fields.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:** when changing XMLAdapter.parse or its output-field extraction and validation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9a2de8aed755f90ec0bcb4b7.md)
