# Rules for `dspy/streaming/messages.py`

## Rule 161 — `dspy/streaming/messages.py`

- **Rule:**
  ```text
  When modifying StatusStreamingCallback.on_module_end, preserve the early-return behavior: it returns without emitting a status message when settings.send_stream is None, so streaming status callbacks are silently skipped unless a stream is configured.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  Modifying StatusStreamingCallback.on_module_end or its stream-configuration guard.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ffd202c1e5c9397496720ac3.md)
