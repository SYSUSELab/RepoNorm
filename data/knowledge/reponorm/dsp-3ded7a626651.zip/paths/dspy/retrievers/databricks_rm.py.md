# Rules for `dspy/retrievers/databricks_rm.py`

## Rule 012 — `dspy/retrievers/databricks_rm.py`

- **Rule:**
  ```text
  The Databricks retriever `Document` dataclass carries `page_content`, `metadata`, and a `type` field, defining the document shape returned by this retriever.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:**
  ```text
  When modifying the Databricks retriever's document model, preserve the `page_content`, `metadata`, and `type` fields.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-103b550b688e4da603bfcd2d.md)
