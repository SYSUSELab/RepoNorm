# Rules for `dspy/predict/avatar/signatures.py`

## Rule 094 — `dspy/predict/avatar/signatures.py`

- **Rule:** dspy.predict.avatar.signatures must import dspy and Action from dspy.predict.avatar.models, preserving the dependency direction for avatar signature definitions.
- **Applies to:**
  - `dspy/predict/avatar/signatures.py`
- **Condition:** When modifying imports in dspy.predict.avatar.signatures or the avatar signature dependency direction.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9372436a4cb6bb161ed6b757.md)
