# Rules for `dspy/predict/chain_of_thought_with_hint.py`

## Rule 024 — `dspy/predict/chain_of_thought_with_hint.py`

- **Rule:**
  ```text
  When modifying ChainOfThoughtWithHint.forward, preserve hint handling: when a hint kwarg is present, append it to the last input field's string value, run the module inside dspy.context(trace=[]) so the hinted call is not recorded, then replace the trace entry with the original kwargs so the hint is not persisted in the trace.
  ```
- **Applies to:**
  - `dspy/predict/chain_of_thought_with_hint.py`
- **Condition:** Modifying ChainOfThoughtWithHint.forward or its hint/trace handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-23729c40987c8ef1832aa3fa.md)

## Rule 053 — `dspy/predict/chain_of_thought_with_hint.py`

- **Rule:**
  ```text
  `chain_of_thought_with_hint.py` builds on the base `Predict` `Module` imported from `.predict` rather than a separate abstraction.
  ```
- **Applies to:**
  - `dspy/predict/chain_of_thought_with_hint.py`
- **Condition:**
  ```text
  When modifying the chain-of-thought-with-hint module, preserve its dependence on the base `Predict` `Module` from `.predict`.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5a8947240289d5a8fd10df4e.md)
