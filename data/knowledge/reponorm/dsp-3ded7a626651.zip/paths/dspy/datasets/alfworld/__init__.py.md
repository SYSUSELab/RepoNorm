# Rules for `dspy/datasets/alfworld/__init__.py`

## Rule 043 — `dspy/datasets/alfworld/__init__.py`

- **Rule:** dspy.datasets.alfworld must re-export AlfWorld from dspy.datasets.alfworld.alfworld so it is available at the package level.
- **Applies to:**
  - `dspy/datasets/alfworld/__init__.py`
- **Condition:** when modifying the dspy.datasets.alfworld package exports
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-454ab63d4672f0e8be24614e.md)
