# Rules for `dspy/datasets/dataloader.py`

## Rule 031 — `dspy/datasets/dataloader.py`

- **Rule:** When modifying DataLoader.sample in dspy/datasets/dataloader.py, preserve the input-validation contract: raise ValueError when the dataset argument is not a list, so callers must pass a list of dspy.Example objects.
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:** When changing argument handling or validation in DataLoader.sample.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2ebb6ce60fdf1b4dd39eef43.md)

## Rule 041 — `dspy/datasets/dataloader.py`

- **Rule:**
  ```text
  DataLoader.from_parquet must default fields to all dataset features when none are supplied and always wrap each row in dspy.Example(...).with_inputs(*input_keys).
  ```
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:**
  ```text
  When modifying DataLoader.from_parquet field defaulting or row-to-Example conversion.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-448e127eb232dba269b00fb3.md)
