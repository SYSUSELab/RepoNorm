# Rules for `.github/workflows/build_and_release.yml`

## Rule 063 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The PyPI job updates the version in ./dspy/__metadata__.py by replacing the line after the #replace_package_version_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-67e18ea84b63fa59a196ecab.md)

## Rule 064 — `.github/workflows/build_and_release.yml`

- **Rule:** The TestPyPI publish step uses the pypa/gh-action-pypi-publish action with repository-url set to https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6a3f4b8cc0a0a4d099aee145.md)

## Rule 071 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The PyPI job updates the version in pyproject.toml by replacing the line after the #replace_package_version_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-72579594cab58f426abf07e0.md)

## Rule 090 — `.github/workflows/build_and_release.yml`

- **Rule:** The PyPI job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8e66214383e3c4dafeff67e1.md)

## Rule 099 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The PyPI job updates the package name in ./dspy/__metadata__.py to dspy by replacing the line after the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9cec14ccf3ff8d0baaae29c2.md)

## Rule 113 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The TestPyPI job updates the package name in pyproject.toml to dspy-ai-test by replacing the line after the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-af6d16622d0eb88e89a21eeb.md)

## Rule 151 — `.github/workflows/build_and_release.yml`

- **Rule:** The PyPI job installs dependencies with python3 -m pip install --upgrade setuptools wheel twine build.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ea0523deb12b4ddd01bcbe05.md)

## Rule 154 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The PyPI job updates the package name in pyproject.toml to dspy by replacing the line after the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ed16041ba4f4891810dfa961.md)

## Rule 158 — `.github/workflows/build_and_release.yml`

- **Rule:** The TestPyPI job builds the distribution with python3 -m build.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f316cad2badd3fe328707cbf.md)
