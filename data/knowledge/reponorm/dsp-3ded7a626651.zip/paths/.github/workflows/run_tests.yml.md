# Rules for `.github/workflows/run_tests.yml`

## Rule 070 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job builds the package with uv run -p .venv python -m build, installs the built wheel from dist/*.whl, and verifies with uv run -p .venv python -c "import dspy".
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-71c9137610174b89acf28e14.md)

## Rule 079 — `.github/workflows/run_tests.yml`

- **Rule:** The fix job runs ruff check with --fix-only --diff --exit-non-zero-on-fix, and on failure prints guidance to run pre-commit run --all-files and exits 1.
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7ab3615fc727f33d0badc544.md)
