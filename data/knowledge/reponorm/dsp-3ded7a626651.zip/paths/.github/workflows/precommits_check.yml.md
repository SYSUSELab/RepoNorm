# Rules for `.github/workflows/precommits_check.yml`

## Rule 003 — `.github/workflows/precommits_check.yml`

- **Rule:** Pull request titles are checked against a regexp requiring a conventional-commit-style type prefix such as break, build, ci, docs, feat, fix, perf, refactor, style, test, ops, hotfix, release, maint, init, enh, or revert, followed by a parenthesized scope and a colon plus description.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-091b079f7ec930defa9e2453.md)

## Rule 104 — `.github/workflows/precommits_check.yml`

- **Rule:** The workflow obtains the list of changed files using jitterbit/get-changed-files and exposes it as the files step output.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a761c491358b633acaa37ed0.md)

## Rule 153 — `.github/workflows/precommits_check.yml`

- **Rule:** The Pre-Commit Checks step runs pre-commit run -v --files on the changed files list.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ec7422a7b5d954bd98cf2931.md)
