# Rules for `pyproject.toml`

## Rule 035 — `pyproject.toml`

- **Rule:**
  ```text
  The dspy package includes the JavaScript files matching primitives/*.js as package data.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3197efba78e85db0ff2ea46c.md)

## Rule 038 — `pyproject.toml`

- **Rule:** Package discovery for setuptools searches from the repository root directory (".").
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3ee4aa68d890321b2090fe5d.md)

## Rule 156 — `pyproject.toml`

- **Rule:**
  ```text
  The project declares requires-python = ">=3.9, <3.14".
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eeec21db03e23e0a8e7cdca3.md)
