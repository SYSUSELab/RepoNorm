# Rules for `tests/conftest.py`

## Rule 112 — `tests/conftest.py`

- **Rule:**
  ```text
  pytest_configure must register each flag in SKIP_DEFAULT_FLAGS as a pytest marker via config.addinivalue_line, so contributors adding opt-out flags must add them to SKIP_DEFAULT_FLAGS rather than registering markers ad hoc.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:** When adding or modifying an opt-out pytest flag or marker in the test configuration.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-af1ea3c8b8b20edbdaf01e75.md)
