# Rules for `tests/primitives/test_python_interpreter.py`

## Rule 139 — `tests/primitives/test_python_interpreter.py`

- **Rule:**
  ```text
  PythonInterpreter must wrap a raised ValueError into InterpreterError with a message matching 'ValueError: [<token>]', preserving the exception-formatting contract.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** when modifying PythonInterpreter exception wrapping or its error-message formatting
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-da9a97900bb6bfccb05a4482.md)
