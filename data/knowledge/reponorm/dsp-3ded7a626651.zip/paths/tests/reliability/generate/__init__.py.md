# Rules for `tests/reliability/generate/__init__.py`

## Rule 138 — `tests/reliability/generate/__init__.py`

- **Rule:**
  ```text
  The reliability generate package's public surface is defined by tests/reliability/generate/__init__.py re-exporting GeneratedTestCase, generate_test_inputs, generate_test_program, load_generated_cases, and load_generated_program from its utils module; contributors adding or renaming generation utilities must update this package export list.
  ```
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:** when adding, renaming, or removing public generation utilities in the reliability generate package
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d83d0ef36b980466285ddd00.md)

## Rule 147 — `tests/reliability/generate/__init__.py`

- **Rule:**
  ```text
  generate_test_cases must reuse an existing program when _directory_contains_program is true (regenerating only inputs) and otherwise generate a new program before always generating inputs and loading cases.
  ```
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:**
  ```text
  When modifying generate_test_cases or its program-reuse branch.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e6d702085073f3e2a8b108b2.md)
