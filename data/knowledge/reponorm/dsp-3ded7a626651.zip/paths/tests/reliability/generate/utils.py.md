# Rules for `tests/reliability/generate/utils.py`

## Rule 021 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  _clean_schema must recursively strip __dspy_field_type and title keys from JSON schema properties, including nested dicts, so generated schemas omit DSPy-internal and title metadata.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _clean_schema or schema-cleaning behavior used by reliability tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-20cc42f31b8bfaa2ca35904a.md)

## Rule 033 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  generate_test_program must retry up to 5 times with caching disabled and temperature=0.5, rename conflicting output fields, validate the generated program by loading it before copying to dst_path, and write a cleaned schema.json; contributors modifying generation must preserve these retry, validation, and cleanup steps.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying the reliability test-program generation pipeline or its retry and validation behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-303a8db5f8d883c8948e510c.md)

## Rule 044 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  Reliability test-input generation must use dspy.ChainOfThought over the _TestInputsGeneration signature.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _get_test_inputs_generation_program or the test-input generation program construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-45c9a806928a5e815266c079.md)

## Rule 093 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  rename_conflicting_fields must append '_output' to any output property whose name collides with an input property and update the output schema's required list accordingly, so contributors adding schema fields must not introduce input/output name clashes without this renaming.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When adding or modifying input/output schema fields in the reliability test generator.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-93672ab99c615379fe5bf1ff.md)

## Rule 116 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  _json_input_to_program_input must parse a JSON string, validate it against a pydantic input schema via model_validate, and return a dict built from program_input.__fields__ so keys follow the pydantic model's declared fields.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _json_input_to_program_input or JSON-to-program-input conversion in reliability tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b0862cf62683d58e9d9126ba.md)

## Rule 146 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  The reliability generator must randomly choose between dspy.ChainOfThought and dspy.Predict and build the signature by appending InputField/OutputField from ProgramInputs/ProgramOutputs model_fields.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying the generated-program construction protocol in reliability tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e585e7d96d0401771a7c1946.md)

## Rule 148 — `tests/reliability/generate/utils.py`

- **Rule:** The reliability test utility must build its program-generation program as dspy.ChainOfThought(ProgramGeneration), so contributors changing program generation must keep ChainOfThought over the ProgramGeneration signature.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying how reliability test programs are generated.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-e793927773a722f9d700bfd0.md)
