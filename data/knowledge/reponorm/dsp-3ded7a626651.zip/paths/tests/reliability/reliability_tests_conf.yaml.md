# Rules for `tests/reliability/reliability_tests_conf.yaml`

## Rule 025 — `tests/reliability/reliability_tests_conf.yaml`

- **Rule:**
  ```text
  Populate `reliability_tests_conf.yaml` in the reliability tests directory with LiteLLM model/provider names and access credentials for each LLM to test and for the LLM judge, placing them in the `litellm_params` section of each model in the defined `model_list`.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../claims/CLAIM-2515b4b431c1dd629cc9aa5a.md)

## Rule 058 — `tests/reliability/reliability_tests_conf.yaml`

- **Rule:**
  ```text
  Models lacking configured `litellm_params` in the configuration file are ignored during testing.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../../../claims/CLAIM-618b55ff9de03780ebe10adb.md)

## Rule 140 — `tests/reliability/reliability_tests_conf.yaml`

- **Rule:**
  ```text
  The configuration must specify a DSPy adapter to use when testing, e.g. `"chat"` for `dspy.ChatAdapter` or `"json"` for `dspy.JSONAdapter`.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../../../claims/CLAIM-dadc244676ef2ca7129bab40.md)
