# Rules for `tests/reliability/utils.py`

## Rule 042 — `tests/reliability/utils.py`

- **Rule:** The reliability judge program must be dspy.Predict over JudgeSignature.
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  When modifying _get_judge_program or the reliability judge construction.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-44d355ba105b702758af4985.md)
