# Rules for `tests/signatures/test_signature.py`

## Rule 128 — `tests/signatures/test_signature.py`

- **Rule:**
  ```text
  Signature string parsing must treat comma-separated names before '->' as input fields and names after '->' as output fields.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** Modifying Signature string parsing or the arrow/comma field-splitting convention.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cbff5bcbb21b34592bcccf9c.md)

## Rule 157 — `tests/signatures/test_signature.py`

- **Rule:**
  ```text
  Signature.prepend and Signature.append must place new input fields at the first and last positions of input_fields respectively, and likewise place new output fields at the first and last positions of output_fields.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** when modifying Signature.prepend/append or field-ordering behavior for input and output fields
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f0785d5e795c812cd67ba324.md)
