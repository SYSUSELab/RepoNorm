# Rules for `tests/signatures/test_adapter_image.py`

## Rule 095 — `tests/signatures/test_adapter_image.py`

- **Rule:** Tests that exercise dspy optional image fields must assert that passing image=None yields the expected output and that LM history contains zero messages with an image URL pattern, verifying optional images are omitted from requests.
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:** When modifying tests for optional image fields in signatures or adapters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-95a50210b12af8282dafb96a.md)

## Rule 145 — `tests/signatures/test_adapter_image.py`

- **Rule:**
  ```text
  dspy.Image.from_url with download=True on a PDF URL must produce a data URI containing 'data:application/pdf' and ';base64,', and using the image in a predictor must yield exactly one image-url message with application/pdf present.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:**
  ```text
  Modifying dspy.Image.from_url download handling for PDF URLs or the predictor message produced for such images.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e46baab11ed3d1cefae2658c.md)
