# Rules for `tests/predict/test_program_of_thought.py`

## Rule 136 — `tests/predict/test_program_of_thought.py`

- **Rule:** Tests that exercise dspy multi-output signatures must declare a signature with an input list and described maximum/minimum outputs, illustrating multi-output signature usage.
- **Applies to:**
  - `tests/predict/test_program_of_thought.py`
- **Condition:** When modifying program-of-thought tests that cover multi-output signatures.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d3a1ce319b4b4936d5d503d0.md)
