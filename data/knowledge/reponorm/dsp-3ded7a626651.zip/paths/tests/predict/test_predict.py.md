# Rules for `tests/predict/test_predict.py`

## Rule 015 — `tests/predict/test_predict.py`

- **Rule:**
  ```text
  Predict.load_state(dumped_state) must overwrite the target Predict's signature instructions with the dumped instance's instructions, so instructions are part of serialized state.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:**
  ```text
  when modifying Predict state serialization or load_state behavior for signature instructions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-13fbebc74b55c85621723b34.md)

## Rule 089 — `tests/predict/test_predict.py`

- **Rule:** Predict call path must return the LM output as result.output when invoked with an input.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** Modifying the basic Predict call path or its result.output contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8d417d9bcf36d80afd3d6aa2.md)

## Rule 120 — `tests/predict/test_predict.py`

- **Rule:**
  ```text
  Predict with dspy.History must produce exactly one LM call with four messages where history question/answer appear in messages[1]/[2] and the new question in messages[3], for both chat and json adapters.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** Modifying Predict handling of dspy.History or the message layout produced for chat and json adapters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b4e50d2601bb1efd7300ef74.md)
