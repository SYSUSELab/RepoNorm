# Rules for `tests/utils/test_mcp.py`

## Rule 108 — `tests/utils/test_mcp.py`

- **Rule:**
  ```text
  convert_mcp_tool must map MCP tool schemas to DSPy tools with integer/array args as int/list arg_types, missing descriptions as 'No description provided. (Required)', nested Pydantic object args accepted as JSON dicts, and MCP tool errors surfaced as RuntimeError with a 'Failed to call a MCP tool' message.
  ```
- **Applies to:**
  - `tests/utils/test_mcp.py`
- **Condition:**
  ```text
  When modifying convert_mcp_tool or the MCP-to-DSPy tool conversion path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ab50297243f672bcd9c55635.md)
