# Rules for `tests/utils/resources/mcp_server.py`

## Rule 007 — `tests/utils/resources/mcp_server.py`

- **Rule:**
  ```text
  get_account_name must be registered as an MCP tool via the @mcp.tool() decorator and extract the name from an Account's profile, defining the tool's input schema and return value.
  ```
- **Applies to:**
  - `tests/utils/resources/mcp_server.py`
- **Condition:**
  ```text
  when modifying the MCP test server's tool registration or get_account_name behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-0c1cc353c66612fb874cccb5.md)
