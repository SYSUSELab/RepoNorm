# Rules for `tests/utils/test_parallelizer.py`

## Rule 050 — `tests/utils/test_parallelizer.py`

- **Rule:**
  ```text
  ParallelExecutor with max_errors=1 must raise an exception matching 'Execution cancelled due to errors or interruption.' when errors exceed the limit, defining the cancellation error contract that tests and callers rely on.
  ```
- **Applies to:**
  - `tests/utils/test_parallelizer.py`
- **Condition:** When modifying ParallelExecutor error handling or the cancellation error message.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-57b0a67862dd2fb05bf61897.md)
