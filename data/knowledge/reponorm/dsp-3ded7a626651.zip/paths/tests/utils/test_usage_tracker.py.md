# Rules for `tests/utils/test_usage_tracker.py`

## Rule 130 — `tests/utils/test_usage_tracker.py`

- **Rule:**
  ```text
  The usage-tracker context-manager test must remain gated on the OPENAI_API_KEY environment variable so it is skipped without a live key.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:**
  ```text
  When modifying test_track_usage_context_manager or its skip/gating decorators.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc861a07755eedaed13be373.md)
