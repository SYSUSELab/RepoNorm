# Rules for `tests/utils/test_asyncify.py`

## Rule 132 — `tests/utils/test_asyncify.py`

- **Rule:**
  ```text
  The asyncify test must wrap a sync function with dspy.asyncify and await verify_asyncify with multiple concurrency/size parameter pairs, asserting asyncify preserves behavior under varying concurrency.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** When modifying asyncify behavior or its concurrency/size parameter coverage.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d04428a0abb6847e92cf4446.md)
