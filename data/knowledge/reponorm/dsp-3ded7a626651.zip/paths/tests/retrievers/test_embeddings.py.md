# Rules for `tests/retrievers/test_embeddings.py`

## Rule 017 — `tests/retrievers/test_embeddings.py`

- **Rule:** Tests that exercise Embeddings retrieval must assert that Embeddings(corpus, embedder, k=1) returns list-typed passages and indices of length 1, and that the top passage for a query matches the expected corpus entry.
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** when modifying or adding tests for Embeddings retrieval
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1b670b9fc424a14fef54e081.md)
