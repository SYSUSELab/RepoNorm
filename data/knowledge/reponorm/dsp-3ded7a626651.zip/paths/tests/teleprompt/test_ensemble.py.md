# Rules for `tests/teleprompt/test_ensemble.py`

## Rule 102 — `tests/teleprompt/test_ensemble.py`

- **Rule:** Tests that exercise DSPy ensemble behavior must use a minimal dspy.Module subclass stand-in (e.g. MockProgram) rather than real programs, so ensemble logic is tested in isolation.
- **Applies to:**
  - `tests/teleprompt/test_ensemble.py`
- **Condition:** when adding or modifying ensemble tests that need a program stand-in
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a22791adaea9c65c71f40fcd.md)
