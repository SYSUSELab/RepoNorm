# Rules for `tests/teleprompt/test_knn_fewshot.py`

## Rule 022 — `tests/teleprompt/test_knn_fewshot.py`

- **Rule:**
  ```text
  Tests for KNNFewShot.compile must assert that the compiled student predictor has exactly one demo matching trainset[0]'s input/output and that forwarding a similar query returns one of the DummyLM responses.
  ```
- **Applies to:**
  - `tests/teleprompt/test_knn_fewshot.py`
- **Condition:** When adding or modifying tests for KNNFewShot.compile demo selection and forwarding behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-22b79b2219d51bf96904c588.md)
