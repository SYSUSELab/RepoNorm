# Rules for `tests/test_utils/server/litellm_server.py`

## Rule 135 — `tests/test_utils/server/litellm_server.py`

- **Rule:**
  ```text
  The mock LiteLLM server's completion method must log every request via _append_request_to_log_file(kwargs) before returning a mock response, so tests can assert on persisted request payloads; contributors modifying the mock server must preserve this logging.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying the mock LiteLLM server's completion handling or request logging
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-d24ed657239ad602f6c0182e.md)
