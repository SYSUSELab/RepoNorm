# Rules for `tests/test_utils/server/__init__.py`

## Rule 030 — `tests/test_utils/server/__init__.py`

- **Rule:**
  ```text
  read_litellm_test_server_request_logs must read a LiteLLM server request-log jsonlines file and return one parsed dict per request, defining the log format used by DSPy integration tests.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** When modifying how integration tests read LiteLLM server request logs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-2c8ee07cfadaf3fe398e5ea1.md)

## Rule 117 — `tests/test_utils/server/__init__.py`

- **Rule:**
  ```text
  The test server helper allocates a free port by binding a socket to port 0 and reading getsockname, and _wait_for_port polls a TCP connection every 0.5 seconds until timeout, raising TimeoutError if the server never accepts; contributors modifying server test helpers must preserve this port-allocation and readiness contract.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when modifying test server port allocation or readiness polling helpers
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-b0af98fcb33126fb7b0843c2.md)
