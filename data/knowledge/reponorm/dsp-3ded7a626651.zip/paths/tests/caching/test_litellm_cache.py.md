# Rules for `tests/caching/test_litellm_cache.py`

## Rule 086 — `tests/caching/test_litellm_cache.py`

- **Rule:**
  ```text
  Tests that exercise dspy cache-key generation failures must assert that when litellm.completion raises RuntimeError, the LM call is not retried and mock_completion.call_count remains exactly 1.
  ```
- **Applies to:**
  - `tests/caching/test_litellm_cache.py`
- **Condition:** When modifying caching tests that cover cache-key generation failure paths.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8af01cfbf7fec95bf2d664d5.md)
