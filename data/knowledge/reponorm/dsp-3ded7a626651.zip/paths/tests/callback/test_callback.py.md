# Rules for `tests/callback/test_callback.py`

## Rule 039 — `tests/callback/test_callback.py`

- **Rule:** Callbacks registered on a module must be invoked for both start and end events of a single forward call.
- **Applies to:**
  - `tests/callback/test_callback.py`
- **Condition:** Modifying callback invocation semantics or the number of callback invocations per forward call.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-40385ee0f6187e3cd8dc1c19.md)
