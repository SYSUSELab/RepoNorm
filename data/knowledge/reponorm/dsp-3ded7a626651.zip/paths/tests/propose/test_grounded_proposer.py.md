# Rules for `tests/propose/test_grounded_proposer.py`

## Rule 020 — `tests/propose/test_grounded_proposer.py`

- **Rule:**
  ```text
  GroundedProposer.propose_instruction_for_predictor must accept demo_candidates as optional (None or nested example lists) without changing its return type.
  ```
- **Applies to:**
  - `tests/propose/test_grounded_proposer.py`
- **Condition:**
  ```text
  When modifying propose_instruction_for_predictor or its test, keep demo_candidates optional and preserve the model-proposed instruction string return.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-201ec1dc7b4f03aeb06b68f8.md)
