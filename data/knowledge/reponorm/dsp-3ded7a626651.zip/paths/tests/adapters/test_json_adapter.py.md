# Rules for `tests/adapters/test_json_adapter.py`

## Rule 083 — `tests/adapters/test_json_adapter.py`

- **Rule:**
  ```text
  JSONAdapter must format a dspy.Image input as a user message content list of exactly three chunks ordered text, image_url, text, with the image_url chunk shaped as {'type':'image_url','image_url':{'url':...}}.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** when modifying JSONAdapter image formatting or multimodal message construction
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-827e7031d843d6acdfaaa692.md)
