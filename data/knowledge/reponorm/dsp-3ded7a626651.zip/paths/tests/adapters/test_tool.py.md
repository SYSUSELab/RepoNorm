# Rules for `tests/adapters/test_tool.py`

## Rule 127 — `tests/adapters/test_tool.py`

- **Rule:** Tests that exercise DSPy tool construction from a function must assert that the tool name derives from the function name, description from the docstring, and args schema from the signature including type and default values.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** when adding or modifying tests that verify Tool construction from a Python function
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ca8af2ee2b01b57eee3115f3.md)

## Rule 150 — `tests/adapters/test_tool.py`

- **Rule:** Tool.acall must filter kwargs to only those matching the wrapped function's signature, dropping extra keyword arguments (e.g. acall(x=1, y=2, z=3) returns only {'y':2,'z':3} for a function accepting y and z).
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** when modifying Tool.acall argument handling or async tool invocation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-e7daa45bb8bc2366d2627177.md)
