# Rules for `tests/retrieve`

## Rule 087 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  Ruff excludes dspy/__metadata__.py, dspy/retrieve/*.py, tests/reliability/*.py, and tests/retrieve/*.py from its checks.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `dspy/retrieve/*.py`
  - `tests/reliability/*.py`
  - `tests/retrieve/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8b4a63c36333829d1765e1a4.md)
