# Rules for `tests`

## Rule 009 — `dspy/**/*.py`

- **Rule:** Ruff linting/formatting applies to Python files under dspy/ and tests/ as included by the include setting.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0dcee3b53bd57970ff289f00.md)

## Rule 077 — `tests/**`

- **Rule:**
  ```text
  The test job runs extra tests via uv run -p .venv pytest tests/ -m extra --extra after syncing the test_extras extra.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7554fe9e5660ebaf1cb456a0.md)

## Rule 092 — `tests/**/*.py`

- **Rule:**
  ```text
  Ruff per-file ignores for tests/**/*.py disable S101, TID252, and ARG001.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-926e26e4c2626faf61975918.md)

## Rule 142 — `tests/**`

- **Rule:** The test job runs pytest on the tests/ directory via uv run -p .venv pytest tests/.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-df71aa664d341e186bca9169.md)
