# Rules for `repository root`

## Rule 011 — `**/*.py`

- **Rule:** Ruff's formatter is configured to indent with spaces (indent-style = "space").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0f82944dacd3a7ed8153ca2c.md)

## Rule 016 — `**/*.py`

- **Rule:** Python 3.9 or later is required for the DSPy development environment.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-15ad07f663a8fbfa838041d4.md)

## Rule 019 — `**`

- **Rule:**
  ```text
  The check-added-large-files pre-commit hook runs with args ["--maxkb=1024"].
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1d1c80d9a99db9ed0c05d555.md)

## Rule 028 — `**/*.py`

- **Rule:** Ruff linting enables the rule sets E, W, F, I, C, B, UP, N, RUF, and Q.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-28a53889ac312fb0befa4e5e.md)

## Rule 034 — `**/*.py`

- **Rule:** Ruff's formatter is configured to not format code inside docstrings (docstring-code-format = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-31200a50a8da917971db74be.md)

## Rule 036 — `**/*.py`

- **Rule:**
  ```text
  Coverage reporting excludes lines matching the configured exclude_lines patterns, including "pragma: no cover", "def __repr__", "if self.debug:", "raise AssertionError", "raise NotImplementedError", "if __name__ == '__main__':", "logger", "try", "except", the regex "^\s*self\.\w+(:\s*[^=]+)?\s*=.*$", and "continue".
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-33329d0ff3cb63a5a2002039.md)

## Rule 048 — `**`

- **Rule:**
  ```text
  The workflow merges the release branch into main with `git merge --no-ff release-${{ needs.extract-tag.outputs.version }}` and pushes to main with `git push origin main`.
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-55a55af5d7708671d3e62b43.md)

## Rule 049 — `**/__init__.py`

- **Rule:**
  ```text
  Ruff per-file ignores for __init__.py disable F401.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-570e0f3f06a75f05547a5bb2.md)

## Rule 075 — `**`

- **Rule:** The pre-commit configuration enables the check-merge-conflict hook.
- **Applies to:**
  - `**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-74ce4ac690110d57cea28f63.md)

## Rule 098 — `**/*.py`

- **Rule:** Ruff's flake8-tidy-imports rule bans all relative imports.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9c92a61af393574b06cd43d4.md)

## Rule 110 — `**/*.py`

- **Rule:** Ruff linting ignores rules B027, FBT003, C901, E501, UP006, UP035, RUF005, B904, F403, E721, UP031, and RUF022.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-acbfa2e899e9aa3cae10f19c.md)

## Rule 121 — `**/*.py`

- **Rule:**
  ```text
  Ruff's isort lint rule treats the `dspy` package as first-party when classifying imports.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bb3fc10ab84600816d37729d.md)

## Rule 125 — `**/*.py`

- **Rule:** Ruff's formatter is configured to not skip magic trailing commas (skip-magic-trailing-comma = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c76ee00180c1bf3310e1f174.md)

## Rule 149 — `**/*.py`

- **Rule:** Ruff's formatter is configured to use double quotes for strings (quote-style = "double").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e7c321e14b1c08413a12bc63.md)
