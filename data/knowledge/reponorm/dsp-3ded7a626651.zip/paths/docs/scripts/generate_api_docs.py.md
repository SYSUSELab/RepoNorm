# Rules for `docs/scripts/generate_api_docs.py`

## Rule 123 — `docs/scripts/generate_api_docs.py`

- **Rule:**
  ```text
  Method names included in generated API documentation must be routines that satisfy the should_document_method filter; get_public_methods is the single gate that decides which class members appear in the generated docs.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  When modifying the API documentation generator's method-selection logic or the should_document_method filter, preserve the invariant that only routines passing should_document_method are emitted as documented methods.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c49aee56ec9a11250ca3d789.md)
