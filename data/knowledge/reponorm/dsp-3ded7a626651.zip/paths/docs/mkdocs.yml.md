# Rules for `docs/mkdocs.yml`

## Rule 014 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The search plugin is configured with lang en, separator '[\s\-\.]+', min_search_length 2, prebuild_index true, indexing 'full', properties [title, tags, content, sections], and search_index_only false.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1167247d70e0861dd075e9ff.md)

## Rule 055 — `docs/mkdocs.yml`

- **Rule:** The extra CSS includes stylesheets/extra.css.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-5bd42a44adf8adf42a56af07.md)

## Rule 065 — `docs/mkdocs.yml`

- **Rule:** The extra JavaScript includes js/runllm-widget.js.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6a4e99bc1278690d68940931.md)

## Rule 078 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The mkdocs-jupyter plugin is configured with ignore_h1_titles True.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-75673f0192259689ff982964.md)

## Rule 080 — `docs/mkdocs.yml`

- **Rule:** The social plugin is enabled.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7accba64304663f965e5decb.md)

## Rule 100 — `docs/mkdocs.yml`

- **Rule:** The MkDocs Material palette uses the slate scheme with a toggle to switch to light mode, primary color black, and accent color lime.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9d35e75366b2aacef94c29c9.md)

## Rule 118 — `docs/mkdocs.yml`

- **Rule:** The site favicon is static/img/logo.png.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b260f2635833ae99b26a15bc.md)
