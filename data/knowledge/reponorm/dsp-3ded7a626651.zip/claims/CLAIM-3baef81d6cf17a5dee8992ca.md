# Rule details

- **Rule:**
  ```text
  Ruff per-file ignores for dspy/__init__.py disable I001, E402, and F405.
  ```
- **Applies to:**
  - `dspy/__init__.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
"dspy/__init__.py" = ["I001", "E402", "F405"]

```

- **Sources:**
  - `pyproject.toml:182`
