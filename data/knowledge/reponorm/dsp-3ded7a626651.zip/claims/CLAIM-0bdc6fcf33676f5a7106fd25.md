# Rule details

- **Rule:**
  ```text
  `Embedder._preprocess` normalizes a single string input into a list, rejects non-string inputs with `ValueError`, merges `default_kwargs` with call kwargs, splits inputs into `batch_size` chunks, and returns `is_single_input` so callers can unwrap single-input results.
  ```
- **Applies to:**
  - `dspy/clients/embedding.py`
- **Condition:**
  ```text
  When modifying embedding input preprocessing, preserve string normalization, non-string rejection, kwargs merging, batch splitting, and the `is_single_input` return contract.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Embedder._preprocess normalizes single string input, rejects non-strings with ValueError, merges default_kwargs with call kwargs, splits into batch_size chunks, and returns is_single_input.
```

- **Sources:**
  - `dspy/clients/embedding.py:83-102`
