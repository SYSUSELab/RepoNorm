# Rule details

- **Rule:**
  ```text
  The test job runs extra tests via uv run -p .venv pytest tests/ -m extra --extra after syncing the test_extras extra.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: uv sync -p .venv --extra dev --extra test_extras
      - name: Run extra tests
        run: uv run -p .venv pytest tests/ -m extra --extra

```

- **Sources:**
  - `.github/workflows/run_tests.yml:87-89`
