# Rule details

- **Rule:**
  ```text
  dspy.Image.from_url with download=True on a PDF URL must produce a data URI containing 'data:application/pdf' and ';base64,', and using the image in a predictor must yield exactly one image-url message with application/pdf present.
  ```
- **Applies to:**
  - `tests/signatures/test_adapter_image.py`
- **Condition:**
  ```text
  Modifying dspy.Image.from_url download handling for PDF URLs or the predictor message produced for such images.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_pdf_url_support asserts the data URI contains 'data:application/pdf' and ';base64,' and that predictor messages contain application/pdf, matching the PDF URL support rule.
```

- **Sources:**
  - `tests/signatures/test_adapter_image.py:342-366`
