# Rule details

- **Rule:**
  ```text
  _clean_schema must recursively strip __dspy_field_type and title keys from JSON schema properties, including nested dicts, so generated schemas omit DSPy-internal and title metadata.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  When modifying _clean_schema or schema-cleaning behavior used by reliability tests.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_clean_schema recursively strips __dspy_field_type and title keys, recursing into nested dicts via isinstance(v, dict), matching the recursive strip rule.
```

- **Sources:**
  - `tests/reliability/generate/utils.py:589-606`
