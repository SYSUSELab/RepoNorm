# Rule details

- **Rule:** The extra CSS includes stylesheets/extra.css.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
extra_css:
    - stylesheets/extra.css

```

- **Sources:**
  - `docs/mkdocs.yml:180-181`
