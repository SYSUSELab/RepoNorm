# Rule details

- **Rule:**
  ```text
  Method names included in generated API documentation must be routines that satisfy the should_document_method filter; get_public_methods is the single gate that decides which class members appear in the generated docs.
  ```
- **Applies to:**
  - `docs/scripts/generate_api_docs.py`
- **Condition:**
  ```text
  When modifying the API documentation generator's method-selection logic or the should_document_method filter, preserve the invariant that only routines passing should_document_method are emitted as documented methods.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
get_public_methods returns names of class members that are routines (inspect.isroutine) and pass should_document_method, matching the rule that documented methods are routines satisfying the filter.
```

- **Sources:**
  - `docs/scripts/generate_api_docs.py:117-124`
