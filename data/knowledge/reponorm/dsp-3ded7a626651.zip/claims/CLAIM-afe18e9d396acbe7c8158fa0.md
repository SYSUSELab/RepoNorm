# Rule details

- **Rule:**
  ```text
  Reliability tests must import assert_program_output_correct and known_failing_models from tests.reliability.utils, establishing a shared reliability-test helper module used across reliability tests.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  When modifying reliability test imports or shared helper usage in tests/reliability/test_pydantic_models.py.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The module imports assert_program_output_correct and known_failing_models from tests.reliability.utils, matching the shared reliability-test helper import rule.
```

- **Sources:**
  - `tests/reliability/test_pydantic_models.py`
