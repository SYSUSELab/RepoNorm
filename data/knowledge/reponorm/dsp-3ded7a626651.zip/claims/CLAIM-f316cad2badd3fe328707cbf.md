# Rule details

- **Rule:** The TestPyPI job builds the distribution with python3 -m build.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: python3 -m build

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:48`
