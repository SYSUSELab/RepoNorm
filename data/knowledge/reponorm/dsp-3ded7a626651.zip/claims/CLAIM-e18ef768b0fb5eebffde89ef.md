# Rule details

- **Rule:**
  ```text
  When modifying the disk cache configuration, preserve DSPY_CACHEDIR and DSPY_CACHE_LIMIT as the supported environment-variable boundary, read at import time with defaults ~/.dspy_cache and 30 GB.
  ```
- **Applies to:**
  - `dspy/clients/__init__.py`
- **Condition:** when changing disk cache location or size limit configuration
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
dspy/clients/__init__.py reads DSPY_CACHEDIR and DSPY_CACHE_LIMIT at import time with defaults ~/.dspy_cache and 30 GB.
```

- **Sources:**
  - `dspy/clients/__init__.py`
