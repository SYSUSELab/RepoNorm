# Rule details

- **Rule:** The social plugin is enabled.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
plugins:
    - social

```

- **Sources:**
  - `docs/mkdocs.yml:183-184`
