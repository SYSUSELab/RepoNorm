# Rule details

- **Rule:**
  ```text
  When modifying BaseCallback.on_adapter_format_start, preserve the callback pairing protocol: the call_id parameter is documented as usable to connect start/end handlers for adapter format events.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:**
  ```text
  when changing on_adapter_format_start or the adapter format callback pairing
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
on_adapter_format_start accepts call_id and its docstring documents using it to connect start/end handlers, preserving the callback pairing protocol.
```

- **Sources:**
  - `dspy/utils/callback.py:129-143`
