# Rule details

- **Rule:**
  ```text
  Signature string parsing must treat comma-separated names before '->' as input fields and names after '->' as output fields.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** Modifying Signature string parsing or the arrow/comma field-splitting convention.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_signature_parsing constructs Signature("input1, input2 -> output") and asserts input1/input2 are in input_fields and output is in output_fields, directly conforming to the arrow/comma parsing rule.
```

- **Sources:**
  - `tests/signatures/test_signature.py:50-54`
