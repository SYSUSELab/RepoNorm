# Rule details

- **Rule:**
  ```text
  When modifying WeaviateRM in dspy/retrievers/weaviate_rm.py, preserve the retriever contract: it subclasses dspy.Retrieve and assumes a Weaviate collection populated with a 'content' payload field, with constructor args weaviate_collection_name, weaviate_client, k (default 3), and tenant_id.
  ```
- **Applies to:**
  - `dspy/retrievers/weaviate_rm.py`
- **Condition:** When changing WeaviateRM's constructor signature or its assumptions about the Weaviate collection payload.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
WeaviateRM subclasses dspy.Retrieve, documents the 'content' payload assumption, and its constructor accepts weaviate_collection_name, weaviate_client, k (default 3), and tenant_id, matching the retriever contract.
```

- **Sources:**
  - `dspy/retrievers/weaviate_rm.py:18-139`
