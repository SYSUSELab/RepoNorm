# Rule details

- **Rule:**
  ```text
  GroundedProposer.__init__ must degrade gracefully: on program source extraction failure it prints an error and sets program_aware=False; on dataset summary creation failure it prints an error and sets use_dataset_summary=False, so proposer construction never raises on these failures.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:**
  ```text
  When modifying GroundedProposer.__init__ error handling for program source extraction or dataset summary creation.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
GroundedProposer.__init__ catches program source extraction failure by printing and setting program_aware=False, and dataset summary failure by printing and setting use_dataset_summary=False, matching graceful degradation.
```

- **Sources:**
  - `dspy/propose/grounded_proposer.py:272-324`
