# Rule details

- **Rule:**
  ```text
  Reliability structured-output tests must preserve the asserted Pydantic answer-model invariants: certainty within [0,1], at least two comments, and graded correctness of value and comments.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  When modifying test_qa_with_pydantic_answer_model or the Pydantic answer model it exercises.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_qa_with_pydantic_answer_model asserts certainty within [0,1], at least two comments, and graded correctness of value and comments, preserving the structured-output invariants.
```

- **Sources:**
  - `tests/reliability/test_pydantic_models.py:11-43`
