# Rule details

- **Rule:** Predict call path must return the LM output as result.output when invoked with an input.
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** Modifying the basic Predict call path or its result.output contract.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_call_method configures DummyLM with a canned output and asserts result.output equals that canned output, establishing the Predict call result.output contract.
```

- **Sources:**
  - `tests/predict/test_predict.py:69-74`
