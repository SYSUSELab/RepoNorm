# Rule details

- **Rule:**
  ```text
  The PyPI job updates the version in ./dspy/__metadata__.py by replacing the line after the #replace_package_version_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: sed -i '/#replace_package_version_marker/{n;s/__version__ *= *"[^"]*"/__version__="${{ needs.extract-tag.outputs.version }}"/;}' ./dspy/__metadata__.py

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:88`
