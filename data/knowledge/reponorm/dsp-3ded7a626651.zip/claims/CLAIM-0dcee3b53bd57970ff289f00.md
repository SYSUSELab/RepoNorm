# Rule details

- **Rule:** Ruff linting/formatting applies to Python files under dspy/ and tests/ as included by the include setting.
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
include = ["dspy/**/*.py", "tests/**/*.py"]

```

- **Sources:**
  - `pyproject.toml:116`
