# Rule details

- **Rule:**
  ```text
  The check-added-large-files pre-commit hook runs with args ["--maxkb=1024"].
  ```
- **Applies to:**
  - `**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - id: check-added-large-files
        args: ["--maxkb=1024"]

```

- **Sources:**
  - `.pre-commit-config.yaml:25-26`
