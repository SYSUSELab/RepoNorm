# Rule details

- **Rule:**
  ```text
  The test server helper allocates a free port by binding a socket to port 0 and reading getsockname, and _wait_for_port polls a TCP connection every 0.5 seconds until timeout, raising TimeoutError if the server never accepts; contributors modifying server test helpers must preserve this port-allocation and readiness contract.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when modifying test server port allocation or readiness polling helpers
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test server helper binds a socket to port 0 to obtain a free port and polls TCP readiness every 0.5s, raising TimeoutError on timeout.
```

- **Sources:**
  - `tests/test_utils/server/__init__.py`
