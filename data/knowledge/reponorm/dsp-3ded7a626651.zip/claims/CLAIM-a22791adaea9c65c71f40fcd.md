# Rule details

- **Rule:** Tests that exercise DSPy ensemble behavior must use a minimal dspy.Module subclass stand-in (e.g. MockProgram) rather than real programs, so ensemble logic is tested in isolation.
- **Applies to:**
  - `tests/teleprompt/test_ensemble.py`
- **Condition:** when adding or modifying ensemble tests that need a program stand-in
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
MockProgram subclasses dspy.Module and provides a minimal forward implementation, serving as the minimal stand-in for ensemble tests.
```

- **Sources:**
  - `tests/teleprompt/test_ensemble.py:7-13`
