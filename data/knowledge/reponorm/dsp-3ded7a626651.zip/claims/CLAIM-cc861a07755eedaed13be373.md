# Rule details

- **Rule:**
  ```text
  The usage-tracker context-manager test must remain gated on the OPENAI_API_KEY environment variable so it is skipped without a live key.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:**
  ```text
  When modifying test_track_usage_context_manager or its skip/gating decorators.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_track_usage_context_manager carries a pytest.mark.skipif decorator gated on the OPENAI_API_KEY environment variable, matching the rule.
```

- **Sources:**
  - `tests/utils/test_usage_tracker.py:144-159`
