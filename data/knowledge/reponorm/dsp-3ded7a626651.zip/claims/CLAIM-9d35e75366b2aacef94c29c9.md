# Rule details

- **Rule:** The MkDocs Material palette uses the slate scheme with a toggle to switch to light mode, primary color black, and accent color lime.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        - scheme: slate
          toggle:
            icon: material/weather-sunny
            name: Switch to light mode
          primary: black
          accent: lime

```

- **Sources:**
  - `docs/mkdocs.yml:167-172`
