# Rule details

- **Rule:** When modifying DataLoader.sample in dspy/datasets/dataloader.py, preserve the input-validation contract: raise ValueError when the dataset argument is not a list, so callers must pass a list of dspy.Example objects.
- **Applies to:**
  - `dspy/datasets/dataloader.py`
- **Condition:** When changing argument handling or validation in DataLoader.sample.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
DataLoader.sample validates that dataset is a list and raises ValueError otherwise, then delegates to random.sample, preserving the input-validation contract.
```

- **Sources:**
  - `dspy/datasets/dataloader.py:138-150`
