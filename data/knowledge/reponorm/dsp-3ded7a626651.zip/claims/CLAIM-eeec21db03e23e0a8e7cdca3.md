# Rule details

- **Rule:**
  ```text
  The project declares requires-python = ">=3.9, <3.14".
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
requires-python = ">=3.9, <3.14"

```

- **Sources:**
  - `pyproject.toml:16`
