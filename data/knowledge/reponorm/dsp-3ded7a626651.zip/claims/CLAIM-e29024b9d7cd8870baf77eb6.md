# Rule details

- **Rule:**
  ```text
  The reliability test configuration defines a model_list whose entries include model_name values judge, gpt-4o, gpt-4o-mini, gpt-4-turbo, gpt-o1, gpt-o1-mini, claude-3.5-sonnet, claude-3.5-haiku, gemini-1.5-pro, gemini-1.5-flash, llama-3.1-405b-instruct, llama-3.1-70b-instruct, llama-3.1-8b-instruct, llama-3.2-3b-instruct, and deepseek-r1.
  ```
- **Applies to:**
  - `tests/reliability/reliability_conf.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
  - model_name: "judge"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:6`

### Evidence 2 — explicit

```text
  - model_name: "gpt-4o"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:11`

### Evidence 3 — explicit

```text
  - model_name: "gpt-4o-mini"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:16`

### Evidence 4 — explicit

```text
  - model_name: "gpt-4-turbo"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:21`

### Evidence 5 — explicit

```text
  - model_name: "gpt-o1"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:26`

### Evidence 6 — explicit

```text
  - model_name: "gpt-o1-mini"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:31`

### Evidence 7 — explicit

```text
  - model_name: "claude-3.5-sonnet"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:36`

### Evidence 8 — explicit

```text
  - model_name: "claude-3.5-haiku"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:41`

### Evidence 9 — explicit

```text
  - model_name: "gemini-1.5-pro"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:46`

### Evidence 10 — explicit

```text
  - model_name: "gemini-1.5-flash"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:51`

### Evidence 11 — explicit

```text
  - model_name: "llama-3.1-405b-instruct"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:56`

### Evidence 12 — explicit

```text
  - model_name: "llama-3.1-70b-instruct"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:61`

### Evidence 13 — explicit

```text
  - model_name: "llama-3.1-8b-instruct"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:66`

### Evidence 14 — explicit

```text
  - model_name: "llama-3.2-3b-instruct"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:71`

### Evidence 15 — explicit

```text
  - model_name: "deepseek-r1"

```

- **Sources:**
  - `tests/reliability/reliability_conf.yaml:76`
