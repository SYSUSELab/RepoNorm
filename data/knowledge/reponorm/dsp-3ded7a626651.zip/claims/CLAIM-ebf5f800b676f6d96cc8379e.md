# Rule details

- **Rule:**
  ```text
  When modifying BaseCallback in dspy/utils/callback.py, preserve the callback registration contract: handlers fire before/after component execution and can be registered globally via dspy.settings.configure(callbacks=[...]) or locally per component (e.g. dspy.LM(..., callbacks=[...])), with local callbacks scoped to that instance.
  ```
- **Applies to:**
  - `dspy/utils/callback.py`
- **Condition:** When changing callback registration, scoping, or before/after execution hooks.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
BaseCallback's docstring documents before/after hooks and both global registration via dspy.settings.configure(callbacks=[...]) and local per-component registration with instance scoping, matching the callback registration contract.
```

- **Sources:**
  - `dspy/utils/callback.py:15-255`
