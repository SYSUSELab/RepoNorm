# Rule details

- **Rule:**
  ```text
  When modifying BaseType.serialize_model, preserve the list-valued format() wrapping: list outputs must be wrapped in CUSTOM_TYPE_START_IDENTIFIER/CUSTOM_TYPE_END_IDENTIFIER markers, while non-list formatted values are returned unchanged.
  ```
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:**
  ```text
  when changing BaseType.serialize_model or the format() output handling for custom types
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
BaseType.serialize_model wraps list-valued format() output in CUSTOM_TYPE_START_IDENTIFIER/CUSTOM_TYPE_END_IDENTIFIER and returns non-list values unchanged, matching the rule.
```

- **Sources:**
  - `dspy/adapters/types/base_type.py:64-68`
