# Rule details

- **Rule:**
  ```text
  get_account_name must be registered as an MCP tool via the @mcp.tool() decorator and extract the name from an Account's profile, defining the tool's input schema and return value.
  ```
- **Applies to:**
  - `tests/utils/resources/mcp_server.py`
- **Condition:**
  ```text
  when modifying the MCP test server's tool registration or get_account_name behavior
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
get_account_name is registered via @mcp.tool() and returns account.profile.name, matching the MCP tool registration and Account profile extraction rule.
```

- **Sources:**
  - `tests/utils/resources/mcp_server.py:36-38`
