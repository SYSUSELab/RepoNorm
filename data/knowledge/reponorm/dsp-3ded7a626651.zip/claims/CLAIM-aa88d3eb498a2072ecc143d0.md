# Rule details

- **Rule:**
  ```text
  setuptools package discovery includes the packages matching "dsp.*", "dspy.*", "dsp", and "dspy".
  ```
- **Applies to:**
  - `dspy/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
[tool.setuptools.packages.find]  
include = ["dsp.*", "dspy.*", "dsp", "dspy"] 
```

- **Sources:**
  - `dspy/.internal_dspyai/pyproject.toml:21-22`
