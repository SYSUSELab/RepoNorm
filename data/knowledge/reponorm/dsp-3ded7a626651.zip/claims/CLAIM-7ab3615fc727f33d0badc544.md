# Rule details

- **Rule:** The fix job runs ruff check with --fix-only --diff --exit-non-zero-on-fix, and on failure prints guidance to run pre-commit run --all-files and exits 1.
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: |
          ruff check --fix-only --diff --exit-non-zero-on-fix || (
            echo ""
            echo "❌ Ruff found issues that can be fixed automatically."
            echo "💡 To fix them locally, run:"
            echo ""
            echo "    pre-commit run --all-files"
            echo ""
            echo "Then commit and push the changes."
            exit 1
          )

```

- **Sources:**
  - `.github/workflows/run_tests.yml:36-46`
