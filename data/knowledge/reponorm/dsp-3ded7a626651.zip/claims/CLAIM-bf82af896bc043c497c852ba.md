# Rule details

- **Rule:**
  ```text
  Tests for eval_candidate_program failure handling must assert that when the evaluate callable raises, the function returns (0.0, [0.0]*len(trainset)) when return_all_scores is True and the scalar 0.0 otherwise.
  ```
- **Applies to:**
  - `tests/teleprompt/test_utils.py`
- **Condition:**
  ```text
  When adding or modifying tests for eval_candidate_program failure return shape under return_all_scores
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
structural support
```

- **Sources:**
  - `tests/teleprompt/test_utils.py:48-61`
