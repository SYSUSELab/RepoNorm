# Rule details

- **Rule:** Ruff linting enables the rule sets E, W, F, I, C, B, UP, N, RUF, and Q.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`

## Supporting evidence

### Evidence 1 — explicit

```text
select = [
    "E",   # pycodestyle errors
    "W",   # pycodestyle warnings
    "F",   # pyflakes
    "I",   # isort
    "C",   # flake8-comprehensions
    "B",   # flake8-bugbear
    "UP",  # pyupgrade
    "N",   # pep8-naming
    "RUF", # ruff-specific rules
    "Q",   # flake8-quotes
]

```

- **Sources:**
  - `pyproject.toml:130-141`
