# Rule details

- **Rule:**
  ```text
  The TestPyPI job updates the package name in pyproject.toml to dspy-ai-test by replacing the line after the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: sed -i '/#replace_package_name_marker/{n;s/name="[^"]*"/name="dspy-ai-test"/;}' pyproject.toml

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:46`
