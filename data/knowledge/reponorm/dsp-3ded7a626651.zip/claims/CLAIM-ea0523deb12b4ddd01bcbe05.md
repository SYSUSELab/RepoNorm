# Rule details

- **Rule:** The PyPI job installs dependencies with python3 -m pip install --upgrade setuptools wheel twine build.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: python3 -m pip install --upgrade setuptools wheel twine build

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:84`
