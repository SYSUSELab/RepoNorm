# Rule details

- **Rule:**
  ```text
  The configuration must specify a DSPy adapter to use when testing, e.g. `"chat"` for `dspy.ChatAdapter` or `"json"` for `dspy.JSONAdapter`.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `required`

## Supporting evidence

### Evidence 1 — explicit

```text
  The configuration must also specify a DSPy adapter to use when testing, e.g. `"chat"` (for `dspy.ChatAdapter`) or `"json"` (for `dspy.JSONAdapter`).

```

- **Sources:**
  - `tests/reliability/README.md:19`
