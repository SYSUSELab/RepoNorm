# Rule details

- **Rule:**
  ```text
  Predict with dspy.History must produce exactly one LM call with four messages where history question/answer appear in messages[1]/[2] and the new question in messages[3], for both chat and json adapters.
  ```
- **Applies to:**
  - `tests/predict/test_predict.py`
- **Condition:** Modifying Predict handling of dspy.History or the message layout produced for chat and json adapters.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The parametrized test asserts exactly one LM call with four messages, history question/answer at messages[1]/[2], and the new question at messages[3] for both chat and json adapters.
```

- **Sources:**
  - `tests/predict/test_predict.py:454-494`
