# Rule details

- **Rule:**
  ```text
  PythonInterpreter must wrap a raised ValueError into InterpreterError with a message matching 'ValueError: [<token>]', preserving the exception-formatting contract.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** when modifying PythonInterpreter exception wrapping or its error-message formatting
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_exception_args deliberately raises ValueError inside pytest.raises(InterpreterError, match='ValueError: [<token>]'), asserting the interpreter's expected wrapping behavior.
```

- **Sources:**
  - `tests/primitives/test_python_interpreter.py:49-54`
