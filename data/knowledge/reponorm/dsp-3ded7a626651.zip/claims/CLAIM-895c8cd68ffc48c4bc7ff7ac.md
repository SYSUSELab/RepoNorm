# Rule details

- **Rule:**
  ```text
  langchain_tool must import BaseTool only under TYPE_CHECKING so LangChain remains an optional runtime dependency for this module.
  ```
- **Applies to:**
  - `dspy/utils/langchain_tool.py`
- **Condition:**
  ```text
  when modifying imports or LangChain integration in dspy/utils/langchain_tool.py
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The module imports BaseTool only under TYPE_CHECKING, keeping LangChain an optional runtime dependency as the rule requires.
```

- **Sources:**
  - `dspy/utils/langchain_tool.py`
