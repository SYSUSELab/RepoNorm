# Rule details

- **Rule:**
  ```text
  read_litellm_test_server_request_logs must read a LiteLLM server request-log jsonlines file and return one parsed dict per request, defining the log format used by DSPy integration tests.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** When modifying how integration tests read LiteLLM server request logs.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The helper opens the server log file and appends json.loads(line) for each line, returning one parsed dict per request, matching the jsonlines parsing rule.
```

- **Sources:**
  - `tests/test_utils/server/__init__.py:48-62`
