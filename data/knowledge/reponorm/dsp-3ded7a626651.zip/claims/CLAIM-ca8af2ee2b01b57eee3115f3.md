# Rule details

- **Rule:** Tests that exercise DSPy tool construction from a function must assert that the tool name derives from the function name, description from the docstring, and args schema from the signature including type and default values.
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:** when adding or modifying tests that verify Tool construction from a Python function
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_tool_from_function constructs a Tool from dummy_function and asserts name, description, and args schema including type and default values, matching the introspection rule.
```

- **Sources:**
  - `tests/adapters/test_tool.py:128-137`
