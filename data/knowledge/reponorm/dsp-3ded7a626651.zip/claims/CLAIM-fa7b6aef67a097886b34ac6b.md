# Rule details

- **Rule:**
  ```text
  When modifying env_worker in dspy/datasets/alfworld/alfworld.py, preserve the worker-process protocol: a single AlfredTWEnv instance is created in the worker, missing alfworld raises ImportError with the pip install alfworld==0.3.5 hint, and 'init', 'step', and 'close' commands are handled over the inq/outq queues.
  ```
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:**
  ```text
  When changing env_worker's command handling, environment construction, or dependency-error path.
  ```
- **Normative strength:** `observed`
- **Use:** `reference_only`
- **Execution risk:** `external_side_effect`

## Supporting evidence

### Evidence 1 — current_observation

```text
env_worker creates a single AlfredTWEnv, raises ImportError with the alfworld==0.3.5 install hint when missing, and dispatches init/step/close over inq/outq queues, matching the worker protocol rule.
```

- **Sources:**
  - `dspy/datasets/alfworld/alfworld.py:6-49`
