# Rule details

- **Rule:**
  ```text
  Unbatchify.__exit__ must delegate to self.close() so resource cleanup is guaranteed on context exit regardless of exception type.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:**
  ```text
  When modifying Unbatchify.__exit__ or its context-manager cleanup path.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Unbatchify.__exit__ delegates to self.close(), guaranteeing cleanup on context exit regardless of exception type, matching the rule.
```

- **Sources:**
  - `dspy/utils/unbatchify.py:102-106`
