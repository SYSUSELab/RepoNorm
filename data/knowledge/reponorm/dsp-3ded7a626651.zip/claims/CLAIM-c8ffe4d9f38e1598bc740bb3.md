# Rule details

- **Rule:**
  ```text
  `track_usage` is a context manager that installs a fresh `UsageTracker` via `settings.context(usage_tracker=tracker)` and yields it, so usage tracking is scoped to the context block.
  ```
- **Applies to:**
  - `dspy/utils/usage_tracker.py`
- **Condition:**
  ```text
  When modifying usage tracking, preserve the context-manager scoping that installs a fresh `UsageTracker` via `settings.context` and yields it.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
track_usage in dspy/utils/usage_tracker.py is a contextmanager that creates a fresh UsageTracker and installs it via settings.context(usage_tracker=tracker) before yielding it.
```

- **Sources:**
  - `dspy/utils/usage_tracker.py:64-69`
