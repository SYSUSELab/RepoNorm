# Rule details

- **Rule:**
  ```text
  convert_langchain_tool must preserve the tool name and description, generate a JSON schema for nested pydantic args, map arg_types to the pydantic class, and default arg_desc to 'No description provided. (Required)' when absent.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:**
  ```text
  When modifying langchain tool conversion tests or the convert_langchain_tool behavior they exercise, including name/description preservation, nested pydantic schema generation, arg_types mapping, and arg_desc defaulting.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The langchain tool tests assert name and description preservation, nested pydantic JSON schema generation, arg_types mapping to the pydantic class, and default arg_desc 'No description provided. (Required)'.
```

- **Sources:**
  - `tests/utils/test_langchain_tool.py`
