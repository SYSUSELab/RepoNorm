# Rule details

- **Rule:**
  ```text
  MultiChainComparison.__init__ must append M reasoning_attempt input fields and prepend a rationale output field to the signature, capturing the last original output field as last_key; signature field ordering is part of the module contract.
  ```
- **Applies to:**
  - `dspy/predict/multi_chain_comparison.py`
- **Condition:** When modifying MultiChainComparison signature construction or field ordering.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
MultiChainComparison.__init__ appends M reasoning_attempt input fields, prepends a rationale output field, and captures the last original output field as last_key, satisfying the field ordering contract.
```

- **Sources:**
  - `dspy/predict/multi_chain_comparison.py:8-33`
