# Rule details

- **Rule:** The mkdocstrings Python handler shows signature annotations.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
                    show_signature_annotations: true

```

- **Sources:**
  - `docs/mkdocs.yml:210`
