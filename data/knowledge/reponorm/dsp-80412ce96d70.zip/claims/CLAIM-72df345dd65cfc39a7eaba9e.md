# Rule details

- **Rule:**
  ```text
  The litellm test server config sets num_retries to 0.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
  num_retries: 0

```

- **Sources:**
  - `tests/test_utils/server/litellm_server_config.yaml:10`
