# Rule details

- **Rule:** The mkdocstrings Python handler orders members by source.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
                    members_order: source

```

- **Sources:**
  - `docs/mkdocs.yml:204`
