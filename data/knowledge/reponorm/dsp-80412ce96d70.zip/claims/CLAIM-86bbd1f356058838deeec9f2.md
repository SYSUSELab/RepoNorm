# Rule details

- **Rule:**
  ```text
  Reliability tests for multi-output signatures must assert each output field separately via assert_program_output_correct with field-specific grading guidelines, including a '|'-separated categories convention.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when modifying reliability tests for multi-output signatures or their grading assertions
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test asserts each output field separately via assert_program_output_correct with field-specific grading guidelines, including the '|'-separated categories convention.
```

- **Sources:**
  - `tests/reliability/test_pydantic_models.py:66-107`
