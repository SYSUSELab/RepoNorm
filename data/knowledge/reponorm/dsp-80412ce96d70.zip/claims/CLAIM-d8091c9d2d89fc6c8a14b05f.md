# Rule details

- **Rule:**
  ```text
  When num_dspy_examples_per_grpo_step exceeds dataset size, each select_training_sample_and_update_shuffled_trainset call must still return that many items, and over repeated calls every dataset element must appear equally often.
  ```
- **Applies to:**
  - `tests/teleprompt/test_grpo.py`
- **Condition:** When modifying the GRPO dataset shuffler or its oversampling behavior when the per-step count exceeds dataset size.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test asserts each call returns 5 items and every dataset element appears 10 times across repeated calls, matching the oversampling invariant.
```

- **Sources:**
  - `tests/teleprompt/test_grpo.py:41-61`
