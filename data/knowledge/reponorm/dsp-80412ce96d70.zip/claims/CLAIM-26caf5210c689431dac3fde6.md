# Rule details

- **Rule:**
  ```text
  When a test asserts that dspy.LM forwards model, api_base, api_key, and azure_ad_token_provider to litellm.completion, a callable azure_ad_token_provider must be passed through to the underlying completion call.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:**
  ```text
  Modifying dspy.LM parameter forwarding to litellm.completion, especially callable parameters such as azure_ad_token_provider.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_lm_calls_support_callables constructs dspy.LM with a callable azure_ad_token_provider and asserts it is forwarded to litellm.completion.
```

- **Sources:**
  - `tests/clients/test_lm.py:125-148`
