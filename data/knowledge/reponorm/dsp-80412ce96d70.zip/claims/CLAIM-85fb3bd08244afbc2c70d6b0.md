# Rule details

- **Rule:** AdapterParseError's string form must follow a fixed template including the adapter name, raw LM response, and the list of expected output fields; changes to that message format are compatibility-relevant.
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:** When modifying AdapterParseError's string representation or its expected message template
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test asserts AdapterParseError's string form follows the fixed template including adapter name, raw LM response, and expected output fields, matching the message-template rule.
```

- **Sources:**
  - `tests/utils/test_exceptions.py:24-42`
