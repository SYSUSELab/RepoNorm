# Rule details

- **Rule:**
  ```text
  _parse_type_node must recursively convert AST type annotations into Python types, raising ValueError for unhandled AST nodes with guidance to use class-based Signatures, and must special-case PEP 604 X | None into Optional and typing.Union/typing.Optional subscripts.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When extending _parse_type_node to handle additional AST node kinds or new typing constructs.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_parse_type_node recursively handles the documented AST node kinds, raises ValueError with class-based Signature guidance for unhandled nodes, and special-cases PEP 604 and typing.Union/Optional subscripts.
```

- **Sources:**
  - `dspy/signatures/signature.py:481-614`
