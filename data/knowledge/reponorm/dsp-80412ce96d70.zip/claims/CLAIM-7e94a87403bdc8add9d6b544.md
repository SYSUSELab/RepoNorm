# Rule details

- **Rule:**
  ```text
  The EnsembledProgram should imitate the structure of individual programs (if compatible) so it can serve as a singular teacher, with the top majority-compatible trace used when dspy.majority is the reduce_fn.
  ```
- **Applies to:**
  - `dspy/teleprompt/ensemble.py`
- **Condition:**
  ```text
  When changing EnsembledProgram structure or its reduce_fn behavior for dspy.majority.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The ensemble module contains a module-level TODO documenting that EnsembledProgram should imitate individual program structure and use the top majority-compatible trace when dspy.majority is the reduce_fn.
```

- **Sources:**
  - `dspy/teleprompt/ensemble.py`
