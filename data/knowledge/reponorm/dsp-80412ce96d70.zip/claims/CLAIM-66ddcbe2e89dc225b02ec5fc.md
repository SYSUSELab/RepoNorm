# Rule details

- **Rule:** dspy.configure must not be called from a different async task than the initial one; calling it from a sync function invoked by an async task must raise RuntimeError with the message 'dspy.settings.configure(...) can only be called from the same async'.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that exercises dspy.configure across async task boundaries
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_dspy_configure_allowance_async asserts that dspy.configure called from a sync function invoked by a different async task raises RuntimeError with the same-async message.
```

- **Sources:**
  - `tests/utils/test_settings.py`
