# Rule details

- **Rule:** The mkdocstrings Python handler unwraps Annotated types.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
                    unwrap_annotated: true

```

- **Sources:**
  - `docs/mkdocs.yml:211`
