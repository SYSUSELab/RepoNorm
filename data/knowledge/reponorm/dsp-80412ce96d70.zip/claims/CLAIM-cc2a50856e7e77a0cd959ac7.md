# Rule details

- **Rule:**
  ```text
  Code.validate_input must accept an existing Code instance, a raw string wrapped as {'code': _filter_code(data)}, or a dict requiring a string 'code' key, raising ValueError for missing/non-string code or other types; all string inputs pass through _filter_code.
  ```
- **Applies to:**
  - `dspy/adapters/types/code.py`
- **Condition:** When changing Code input validation or the accepted input forms for the Code type.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Code.validate_input implements the described normalization: accepts Code instances, wraps strings via _filter_code, requires a string 'code' key in dicts, and raises ValueError otherwise.
```

- **Sources:**
  - `dspy/adapters/types/code.py:88-102`
