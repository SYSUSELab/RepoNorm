# Rule details

- **Rule:** AdapterParseError's string form must include the adapter name, raw LM response, expected output fields, and actually parsed output fields, making the message format a stable contract for parse-failure diagnostics.
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:** When modifying AdapterParseError message formatting or its diagnostic fields.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_adapter_parse_error_with_parsed_result asserts the AdapterParseError string includes the adapter name, raw LM response, expected output fields, and actually parsed output fields.
```

- **Sources:**
  - `tests/utils/test_exceptions.py:45-61`
