# Rule details

- **Rule:**
  ```text
  GRPO dataset shuffling must return samples of size num_dspy_examples_per_grpo_step whose elements are exactly the dataset set, and repeated calls must keep returning full-size samples from the same dataset.
  ```
- **Applies to:**
  - `tests/teleprompt/test_grpo.py`
- **Condition:** when modifying GRPO dataset shuffling, sample size, or repeated-call behavior
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test module exercises GRPO dataset shuffling with assertions on sample size and dataset membership, supporting the shuffling contract.
```

- **Sources:**
  - `tests/teleprompt/test_grpo.py`

### Evidence 2 — current_observation

```text
The test asserts each returned sample has length 3 and set equality with the dataset across repeated calls, matching the GRPO shuffling rule.
```

- **Sources:**
  - `tests/teleprompt/test_grpo.py:4-15`

### Evidence 3 — current_observation

```text
test_grpo_dataset_shuffler_with_num_ex_per_step_less_dataset asserts each returned sample has length 2 (the configured num_dspy_examples_per_grpo_step), that the union of samples covers all 3 dataset elements, and that repeated calls keep returning full-size samples, matching the GRPO shuffling rule.
```

- **Sources:**
  - `tests/teleprompt/test_grpo.py:18-38`

### Evidence 4 — current_observation

```text
The test body asserts sample size equals num_dspy_examples_per_grpo_step, dataset membership, and repeated full-size samples.
```

- **Sources:**
  - `tests/teleprompt/test_grpo.py:41-61`
