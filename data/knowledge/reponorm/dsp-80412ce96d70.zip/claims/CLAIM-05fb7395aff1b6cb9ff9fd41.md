# Rule details

- **Rule:**
  ```text
  DEFAULT_CONFIG must remain the baseline settings surface and be deep-copied into main_thread_config, with thread-local overrides held in a ContextVar, so that per-thread settings isolation is preserved.
  ```
- **Applies to:**
  - `dspy/dsp/utils/settings.py`
- **Condition:**
  ```text
  When adding, removing, or renaming a setting in DEFAULT_CONFIG or changing how thread-local overrides are stored.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
DEFAULT_CONFIG is deep-copied into main_thread_config and thread-local overrides are held in a ContextVar, preserving per-thread isolation.
```

- **Sources:**
  - `dspy/dsp/utils/settings.py`
