# Rule details

- **Rule:** The hooks can also be run manually, including a mode that checks staged files only.
- **Applies to:**
  - `**`
- **Normative strength:** `required`

## Supporting evidence

### Evidence 1 — explicit

```text
You can also run the hooks manually:

- Check staged files only:

```

- **Sources:**
  - `CONTRIBUTING.md:59-61`
