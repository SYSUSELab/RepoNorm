# Rule details

- **Rule:**
  ```text
  The build-and-publish-test-pypi job creates a virtual environment named test_before_testpypi.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Create test environment
        run: python -m venv test_before_testpypi

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:50-51`
