# Rule details

- **Rule:**
  ```text
  The build_package job creates a virtual environment at .venv and adds its bin directory to GITHUB_PATH.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        run: |
          uv venv .venv
          echo "${{ github.workspace }}/.venv/bin" >> $GITHUB_PATH

```

- **Sources:**
  - `.github/workflows/run_tests.yml:148-150`
