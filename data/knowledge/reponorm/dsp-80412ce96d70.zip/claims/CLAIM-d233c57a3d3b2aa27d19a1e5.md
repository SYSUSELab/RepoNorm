# Rule details

- **Rule:**
  ```text
  Test modules that depend on optional third-party packages must skip at module level using `importlib.util.find_spec` and `pytest.skip(..., allow_module_level=True)` when the dependency is absent, rather than failing at import time.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:**
  ```text
  when adding or modifying test modules that import optional third-party dependencies such as langchain_core
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The test module guards its optional langchain_core dependency with importlib.util.find_spec and a module-level pytest.skip(..., allow_module_level=True) before importing it.
```

- **Sources:**
  - `tests/utils/test_langchain_tool.py`
