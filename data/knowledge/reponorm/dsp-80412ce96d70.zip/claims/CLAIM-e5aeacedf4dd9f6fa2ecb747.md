# Rule details

- **Rule:** Ruff format indents with spaces (indent-style = "space").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
indent-style = "space"

```

- **Sources:**
  - `pyproject.toml:163`
