# Rule details

- **Rule:** dspy.LM.acall with cache disabled must return the mocked completion content as a list and invoke litellm.acompletion exactly once.
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:** When modifying dspy.LM.acall or its interaction with litellm.acompletion under disabled cache.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_async_lm_call patches litellm.acompletion, awaits dspy.LM.acall with cache disabled, asserts the result equals ["answer"], and asserts acompletion was called exactly once, matching the async LM call contract.
```

- **Sources:**
  - `tests/clients/test_lm.py:324-336`
