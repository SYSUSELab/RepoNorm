# Rule details

- **Rule:**
  ```text
  generate_models must configure datamodel-code-generator with enum_field_as_literal='one', field_constraints=True, use_annotated=False, then strip 'from __future__ import annotations' and generated comments to keep generated pydantic models compatible with built-in type hints.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying generate_models or the generated pydantic model compatibility settings
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
generate_models sets enum_field_as_literal='one', field_constraints=True, use_annotated=False, then strips 'from __future__ import annotations' and generated comments, matching the rule.
```

- **Sources:**
  - `tests/reliability/generate/utils.py:60-85`
