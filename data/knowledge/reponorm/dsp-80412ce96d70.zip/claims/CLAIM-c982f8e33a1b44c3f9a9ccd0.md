# Rule details

- **Rule:** The workflow sets up Python version 3.10 with pip caching.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        uses: actions/setup-python@v4
        with:
          python-version: "3.10"
          cache: "pip"

```

- **Sources:**
  - `.github/workflows/precommits_check.yml:11-14`
