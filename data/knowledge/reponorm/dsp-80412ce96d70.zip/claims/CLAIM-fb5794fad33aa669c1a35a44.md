# Rule details

- **Rule:**
  ```text
  Signature field constraints must be exposed through output_fields json_schema_extra, and tests must assert minimum/maximum length and greater/less-than-or-equal bounds on those fields.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** when adding or modifying signature field constraint assertions
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_signature_field_with_constraints asserts minimum/maximum length bounds for outputs1 and greater/less-than-or-equal bounds for outputs2 via output_fields json_schema_extra constraints.
```

- **Sources:**
  - `tests/signatures/test_signature.py:391-406`
