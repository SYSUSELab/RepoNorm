# Rule details

- **Rule:** Ruff format does not format code inside docstrings (docstring-code-format = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
docstring-code-format = false

```

- **Sources:**
  - `pyproject.toml:161`
