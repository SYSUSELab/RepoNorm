# Rule details

- **Rule:** The mkdocstrings Python handler enables category headings.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
                    show_category_heading: true

```

- **Sources:**
  - `docs/mkdocs.yml:206`
