# Rule details

- **Rule:** The alfworld init helper must communicate with a worker process by putting an ("init", idx) message on inq and blocking on outq.get(), so callers must have a corresponding worker consuming the queue.
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** When changing the alfworld environment session init helper or its worker-process IPC contract.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The _EnvSession.init method body puts an ("init", idx) tuple on self.inq and blocks on self.outq.get(), matching the alfworld worker IPC handshake contract.
```

- **Sources:**
  - `dspy/datasets/alfworld/alfworld.py:130-132`
