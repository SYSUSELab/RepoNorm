# Rule details

- **Rule:** The litellm test server module must define DSPyTestModel as a subclass of CustomLLM to provide a custom LLM implementation for server-based tests.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When modifying the litellm test server module or adding custom LLM implementations for server-based tests.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The full file source defines DSPyTestModel as a subclass of CustomLLM in tests/test_utils/server/litellm_server.py, satisfying the litellm test server custom LLM convention.
```

- **Sources:**
  - `tests/test_utils/server/litellm_server.py`
