# Rule details

- **Rule:** Ruff's flake8-tidy-imports rule bans all relative imports.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
ban-relative-imports = "all"

```

- **Sources:**
  - `pyproject.toml:171`
