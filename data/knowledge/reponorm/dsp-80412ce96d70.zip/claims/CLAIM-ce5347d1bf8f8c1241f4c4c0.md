# Rule details

- **Rule:** Pull request titles are checked against a regexp requiring a conventional-commit-style type prefix followed by a scope in parentheses, a colon, a space, and a description.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
        uses: Slashgear/action-check-pr-title@main
        with:
          regexp: '(break|build|ci|docs|feat|fix|perf|refactor|style|test|ops|hotfix|release|maint|init|enh|revert)\([a-z,A-Z,0-9,\-,\_,\/,:]+\)(:)\s{1}([\w\s]+)' # Regex the title should match.

```

- **Sources:**
  - `.github/workflows/precommits_check.yml:16-18`
