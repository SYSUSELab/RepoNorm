# Rule details

- **Rule:** A program signature can be built dynamically by iterating pydantic model fields and appending dspy.InputField/OutputField with the field's annotation and description to a BaseSignature.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying generated reliability test programs that construct signatures from pydantic model fields.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The program file iterates ProgramInputs/ProgramOutputs model_fields and appends dspy.InputField/OutputField with each field's annotation and description to BaseSignature, dynamically constructing the program signature.
```

- **Sources:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`

### Evidence 2 — current_observation

```text
The program iterates ProgramInputs/ProgramOutputs model_fields and appends dspy.InputField/OutputField with annotation and description to a BaseSignature.
```

- **Sources:**
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
