# Rule details

- **Rule:**
  ```text
  The workflow builds the dspy-ai binary wheel by running `python3 -m build .github/.internal_dspyai/`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/**`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Build a binary wheel (dspy-ai)
        run: python3 -m build .github/.internal_dspyai/

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:119-120`
