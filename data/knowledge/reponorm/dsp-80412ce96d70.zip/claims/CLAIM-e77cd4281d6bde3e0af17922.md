# Rule details

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.tabbed extension with alternate_style true.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
    - pymdownx.tabbed:
        alternate_style: true

```

- **Sources:**
  - `docs/mkdocs.yml:251-252`
