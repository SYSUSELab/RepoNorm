# Rule details

- **Rule:** Type is the base class for DSPy custom types; subclasses must implement format returning a list of content-part dicts matching the OpenAI content field.
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:** when adding or modifying a DSPy custom type subclass or the Type base class format contract
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
The Type base class docstring establishes it as the parent of DSPy custom types and requires subclasses to implement format returning a list of content-part dicts matching the OpenAI content field.
```

- **Sources:**
  - `dspy/adapters/types/base_type.py:12-68`
