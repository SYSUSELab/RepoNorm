# Rule details

- **Rule:**
  ```text
  The build-and-publish-pypi job updates the version in pyproject.toml using sed against the #replace_package_version_marker.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Update version in pyproject.toml
        run: sed -i '/#replace_package_version_marker/{n;s/version *= *"[^"]*"/version="${{ needs.extract-tag.outputs.version }}"/;}' pyproject.toml

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:85-86`
