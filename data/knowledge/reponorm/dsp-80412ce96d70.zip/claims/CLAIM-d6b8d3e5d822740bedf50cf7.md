# Rule details

- **Rule:**
  ```text
  Unbatchify.close must be idempotent: it only sets stop_event and joins the worker thread when stop_event is not already set, so repeated close calls do not re-join.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:** When modifying Unbatchify.close or its worker-thread shutdown logic.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Unbatchify.close guards with stop_event.is_set() before setting and joining, preserving idempotent repeated-close behavior.
```

- **Sources:**
  - `dspy/utils/unbatchify.py:88-94`
