# Rule details

- **Rule:**
  ```text
  ColBERTv2.__init__ must build self.url as '{url}:{port}' when a port is provided and otherwise use url unchanged, and store post_requests; this defines the endpoint URL construction contract.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:**
  ```text
  when modifying ColBERTv2.__init__ or its endpoint URL construction
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
ColBERTv2.__init__ stores post_requests and builds self.url as f"{url}:{port}" when port is provided, otherwise uses url unchanged, matching the endpoint URL construction contract.
```

- **Sources:**
  - `dspy/dsp/colbertv2.py:14-21`
