# Rule details

- **Rule:**
  ```text
  Compiled Predict programs saved with save_program=True and reloaded via dspy.load must preserve both demos and signature; do not change save/load behavior in a way that drops either.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:**
  ```text
  when modifying save_program or dspy.load behavior for compiled Predict programs
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_save_compiled_model saves a compiled Predict with save_program=True, reloads via dspy.load, and asserts demos and signature equality.
```

- **Sources:**
  - `tests/utils/test_saving.py`
