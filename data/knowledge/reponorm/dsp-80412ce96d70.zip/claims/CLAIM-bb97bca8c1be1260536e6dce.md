# Rule details

- **Rule:** The mkdocs-jupyter plugin ignores H1 titles.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
    - mkdocs-jupyter:
        ignore_h1_titles: true

```

- **Sources:**
  - `docs/mkdocs.yml:219-220`
