# Rule details

- **Rule:**
  ```text
  Save/load version-mismatch tests must patch get_dependency_versions separately in dspy.primitives.base_module (save path) and dspy.utils.saving (load path), assert exactly three mismatch warnings are logged, and verify the model still loads with an equal signature despite mismatched python/dspy/cloudpickle versions.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** When modifying save/load version-mismatch tests or the dependency-version warning behavior they exercise across the save and load modules.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
test_load_with_version_mismatch patches get_dependency_versions in both dspy.primitives.base_module and dspy.utils.saving, asserts exactly three mismatch warnings, and verifies signature equality.
```

- **Sources:**
  - `tests/utils/test_saving.py`
