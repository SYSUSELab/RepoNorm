# Rule details

- **Rule:**
  ```text
  Signature.with_instructions must return a new Signature subclass derived from the existing fields with replaced instructions, preserving the immutable-style derivation contract rather than mutating the receiver.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When modifying or extending Signature.with_instructions or adding sibling derivation helpers on Signature.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
Signature.with_instructions returns Signature(cls.fields, instructions), constructing a new Signature subclass from existing fields with replaced instructions rather than mutating the receiver, preserving the immutable-style derivation contract.
```

- **Sources:**
  - `dspy/signatures/signature.py:247-248`
