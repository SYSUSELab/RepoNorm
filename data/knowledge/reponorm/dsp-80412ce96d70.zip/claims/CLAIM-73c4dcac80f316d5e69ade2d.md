# Rule details

- **Rule:** Python 3.10 or later is required for the DSPy development environment.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`

## Supporting evidence

### Evidence 1 — explicit

```text
Python 3.10 or later is required.

```

- **Sources:**
  - `CONTRIBUTING.md:92`
