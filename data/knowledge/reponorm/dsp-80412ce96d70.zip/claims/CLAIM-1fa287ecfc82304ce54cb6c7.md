# Rule details

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the package name in .github/.internal_dspyai/pyproject.toml to dspy-ai using a sed command keyed on the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Update package name in pyproject.toml
        run: sed -i '/#replace_package_name_marker/{n;s/name *= *"[^"]*"/name="dspy-ai"/;}' .github/.internal_dspyai/pyproject.toml

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:112-113`
