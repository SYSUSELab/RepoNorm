# Rule details

- **Rule:**
  ```text
  The build-and-publish-test-pypi job updates the package name in pyproject.toml to dspy-ai-test using sed against the #replace_package_name_marker.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Update package name in pyproject.toml
        run: sed -i '/#replace_package_name_marker/{n;s/name="[^"]*"/name="dspy-ai-test"/;}' pyproject.toml

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:45-46`
