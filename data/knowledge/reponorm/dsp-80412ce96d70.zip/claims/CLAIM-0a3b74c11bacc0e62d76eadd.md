# Rule details

- **Rule:** The mkdocstrings Python handler shows the root heading.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
                    show_root_heading: true

```

- **Sources:**
  - `docs/mkdocs.yml:202`
