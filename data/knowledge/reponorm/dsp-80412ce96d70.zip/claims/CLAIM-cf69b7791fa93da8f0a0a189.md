# Rule details

- **Rule:** The mkdocstrings Python handler shows source.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
                    show_source: true

```

- **Sources:**
  - `docs/mkdocs.yml:201`
