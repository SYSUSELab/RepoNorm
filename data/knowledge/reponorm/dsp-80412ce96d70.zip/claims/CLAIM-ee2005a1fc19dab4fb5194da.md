# Rule details

- **Rule:** The build-and-publish-pypi job installs setuptools, wheel, twine, and build via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Install dependencies
        run: python3 -m pip install --upgrade setuptools wheel twine build

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:83-84`
