# Rule details

- **Rule:**
  ```text
  make_signature must validate that field names are strings, field values are tuples or FieldInfo, and field types are valid type constructs, silently defaulting None types to str to avoid breaking program-of-thought and teleprompters.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When changing make_signature validation or the handling of field names, values, or types.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
make_signature validates string field names, tuple/FieldInfo values, and valid type constructs, and silently defaults None types to str.
```

- **Sources:**
  - `dspy/signatures/signature.py:368-449`
