# Rule details

- **Rule:**
  ```text
  The unbatchify submit method enqueues an (input_item, future) tuple onto input_queue and returns the Future, defining the producer-side contract that callers await for results.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** when modifying the unbatchify submit method or tests that pin its queue/future contract
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
submit enqueues an (input_item, future) tuple onto input_queue and returns the Future, matching the producer-side contract.
```

- **Sources:**
  - `tests/utils/test_unbatchify.py:13-17`
