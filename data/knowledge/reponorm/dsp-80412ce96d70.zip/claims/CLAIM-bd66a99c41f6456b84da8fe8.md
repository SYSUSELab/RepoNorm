# Rule details

- **Rule:**
  ```text
  ArborReinforceJob.__init__ must raise ValueError when 'num_generations' is absent from train_kwargs, documenting a required teleprompter-set training parameter.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:**
  ```text
  When changing ArborReinforceJob construction or the required train_kwargs contract.
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
ArborReinforceJob.__init__ raises ValueError when 'num_generations' is absent from train_kwargs, documenting the required teleprompter-set training parameter, matching the rule.
```

- **Sources:**
  - `dspy/clients/lm_local_arbor.py:73-82`
