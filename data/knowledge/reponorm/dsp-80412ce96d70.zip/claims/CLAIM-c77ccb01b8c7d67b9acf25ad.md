# Rule details

- **Rule:** The mkdocstrings Python handler uses Google docstring style.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
                    docstring_style: google

```

- **Sources:**
  - `docs/mkdocs.yml:200`
