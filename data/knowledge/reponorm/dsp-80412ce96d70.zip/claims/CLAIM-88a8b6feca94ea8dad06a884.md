# Rule details

- **Rule:** The MkDocs site enables the pymdownx.arithmatex extension with generic true.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
    - pymdownx.arithmatex:
        generic: true

```

- **Sources:**
  - `docs/mkdocs.yml:258-259`
