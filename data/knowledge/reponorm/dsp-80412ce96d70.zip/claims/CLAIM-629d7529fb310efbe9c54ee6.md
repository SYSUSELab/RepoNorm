# Rule details

- **Rule:** The redirects plugin maps deep-dive/optimizers/miprov2.md to api/optimizers/MIPROv2.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
            "deep-dive/optimizers/miprov2.md": "api/optimizers/MIPROv2.md"

```

- **Sources:**
  - `docs/mkdocs.yml:233`
