# Rule details

- **Rule:** The redirects plugin maps quick-start/getting-started-01.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
            "quick-start/getting-started-01.md": "tutorials/rag/index.ipynb"

```

- **Sources:**
  - `docs/mkdocs.yml:237`
