# Rule details

- **Rule:**
  ```text
  Tests that exercise embeddings retrieval must use a dummy_embedder mapping texts containing 'cat' to [1,0,0], 'dog' to [0,1,0], and anything else to [0,0,1], returning a stacked float32 array, so retrieval assertions rely on fixed orthogonal embeddings.
  ```
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** When adding or modifying tests for embeddings retrieval that depend on deterministic embedding vectors.
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
tests/retrievers/test_embeddings.py defines dummy_embedder mapping 'cat' texts to [1,0,0], 'dog' texts to [0,1,0], and others to [0,0,1], returning a stacked float32 array, matching the deterministic embedding rule.
```

- **Sources:**
  - `tests/retrievers/test_embeddings.py`
