# Rule details

- **Rule:**
  ```text
  XMLAdapter._parse_field_value must wrap parse_value failures in AdapterParseError carrying adapter name, signature, LM response, and the failing field/value, so XML adapter parse errors surface structured diagnostic context.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:**
  ```text
  when modifying XMLAdapter._parse_field_value or the structured parse-error context
  ```
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — current_observation

```text
_parse_field_value wraps parse_value failures in AdapterParseError carrying adapter name, signature, LM response, and the failing field/value.
```

- **Sources:**
  - `dspy/adapters/xml_adapter.py:49-62`
