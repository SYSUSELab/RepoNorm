# Rule details

- **Rule:** The redirects plugin maps deep-dive/optimizers/bootstrap-fewshot.md to api/optimizers/BootstrapFewShot.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
            "deep-dive/optimizers/bootstrap-fewshot.md": "api/optimizers/BootstrapFewShot.md"

```

- **Sources:**
  - `docs/mkdocs.yml:227`
