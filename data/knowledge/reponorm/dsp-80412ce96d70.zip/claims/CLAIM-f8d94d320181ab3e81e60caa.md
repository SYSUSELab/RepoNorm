# Rule details

- **Rule:**
  ```text
  The build-and-publish-pypi job updates __version__ in ./dspy/__metadata__.py using sed against the #replace_package_version_marker.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
- **Normative strength:** `observed`

## Supporting evidence

### Evidence 1 — explicit

```text
      - name: Update version in __metadata__.py
        run: sed -i '/#replace_package_version_marker/{n;s/__version__ *= *"[^"]*"/__version__="${{ needs.extract-tag.outputs.version }}"/;}' ./dspy/__metadata__.py

```

- **Sources:**
  - `.github/workflows/build_and_release.yml:87-88`
