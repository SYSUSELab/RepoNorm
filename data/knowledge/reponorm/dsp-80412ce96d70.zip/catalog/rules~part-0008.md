# Full rule catalog

## Rule 119 — `.github/.internal_dspyai/**`

- **Rule:**
  ```text
  The workflow builds the dspy-ai binary wheel by running `python3 -m build .github/.internal_dspyai/`.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9ca58af418462cddde33941a.md)

## Rule 120 — `dspy/clients/databricks.py`

- **Rule:**
  ```text
  _save_data_to_local_file must write training data to a UUID-named JSONL file in the finetune directory, validating each item against the selected TrainDataFormat (CHAT or COMPLETION) before serializing with ujson.
  ```
- **Applies to:**
  - `dspy/clients/databricks.py`
- **Condition:** When modifying finetuning data persistence or the TrainDataFormat validation path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9cfba66b1a71654690b2fc6c.md)

## Rule 121 — `tests/test_utils/server/__init__.py`

- **Rule:**
  ```text
  The test server package must expose LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR from tests.test_utils.server.litellm_server so tests can read the log-file path via an environment variable.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when modifying the test server package exports or the log-file path environment variable
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9d0cf9582cfd2fa4ab6139f3.md)

## Rule 122 — `tests/utils/test_settings.py`

- **Rule:** dspy.configure must not be called from a child thread; tests must configure dspy in the main thread and assert that a ThreadPoolExecutor worker calling dspy.configure raises.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that exercises dspy.configure from a non-main thread
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9f8416215f690a8f6575c092.md)

## Rule 123 — `dspy/propose/utils.py`

- **Rule:**
  ```text
  propose/utils.py must import IPython's extract_symbols inside a try/except ImportError and set extract_symbols = None when unavailable, so notebook code extraction degrades gracefully without IPython installed.
  ```
- **Applies to:**
  - `dspy/propose/utils.py`
- **Condition:** Modifying notebook code extraction or IPython dependency handling in propose/utils.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a04483aed3527203cfd3ea06.md)

## Rule 124 — `dspy/datasets/dataset.py`

- **Rule:**
  ```text
  Dataset._shuffle_and_sample must shuffle with a seeded RNG regardless of requested size, truncate to size, and stamp each returned Example with a fresh dspy_uuid and dspy_split; dedup/group_uuid semantics remain unimplemented.
  ```
- **Applies to:**
  - `dspy/datasets/dataset.py`
- **Condition:**
  ```text
  when modifying Dataset._shuffle_and_sample or the sampling path it feeds
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a199f6077349fb62ff9b2617.md)

## Rule 125 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  generate_models must configure datamodel-code-generator with enum_field_as_literal='one', field_constraints=True, use_annotated=False, then strip 'from __future__ import annotations' and generated comments to keep generated pydantic models compatible with built-in type hints.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying generate_models or the generated pydantic model compatibility settings
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a2f899ac33bc39c6f4c32c12.md)

## Rule 126 — `tests/reliability/generate/__init__.py`

- **Rule:**
  ```text
  The reliability generate package must re-export GeneratedTestCase, generate_test_inputs, generate_test_program, load_generated_cases, and load_generated_program from its utils module, defining the package's public surface.
  ```
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:** When modifying the reliability generate package's public exports or adding/removing symbols from its utils module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a364759f45f2957b48d3749f.md)

## Rule 127 — `dspy/**`

- **Rule:**
  ```text
  Package discovery includes only the dspy and dspy.* packages.
  ```
- **Applies to:**
  - `dspy/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3f49fc8040a6325410e23b9.md)

## Rule 128 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site favicon is static/img/logo.png.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a49b27d67694be8cf911d337.md)

## Rule 129 — `**`

- **Rule:** The hooks can also be run manually, including a mode that checks staged files only.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-a7a364e6bac1e834c56be323.md)

## Rule 130 — `tests/utils/test_saving.py`

- **Rule:**
  ```text
  Compiled Predict programs saved with save_program=True and reloaded via dspy.load must preserve both demos and signature; do not change save/load behavior in a way that drops either.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:**
  ```text
  when modifying save_program or dspy.load behavior for compiled Predict programs
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a9e309d6c83cfe72704b21dc.md)

## Rule 131 — `tests/clients/test_lm.py`

- **Rule:** dspy.LM.acall with cache disabled must return the mocked completion content as a list and invoke litellm.acompletion exactly once.
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:** When modifying dspy.LM.acall or its interaction with litellm.acompletion under disabled cache.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-aaeeb7296c11c006a0eb8490.md)

## Rule 132 — `tests/utils/test_unbatchify.py`

- **Rule:**
  ```text
  The unbatchify submit method enqueues an (input_item, future) tuple onto input_queue and returns the Future, defining the producer-side contract that callers await for results.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** when modifying the unbatchify submit method or tests that pin its queue/future contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-acab880450faaf6162874fe2.md)

## Rule 133 — `dspy/dsp/colbertv2.py`

- **Rule:**
  ```text
  ColBERTv2.__init__ must build self.url as '{url}:{port}' when a port is provided and otherwise use url unchanged, and store post_requests; this defines the endpoint URL construction contract.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:**
  ```text
  when modifying ColBERTv2.__init__ or its endpoint URL construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ae12afed7f632acf87458f6d.md)

## Rule 134 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  Generated reliability case execution must load the generated program, convert the JSON input to program input, run the program, and assert each output assertion via assert_program_output_correct with grading guidelines.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying run_generated_case or the generated reliability case execution path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-af2664ce0527a2ad6a4c0923.md)

## Rule 135 — `**/*.py`

- **Rule:** No Ruff rules are marked unfixable.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b0a1c8571b4ed8d41f2424e1.md)
