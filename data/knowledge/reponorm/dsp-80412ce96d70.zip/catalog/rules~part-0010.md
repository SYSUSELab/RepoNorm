# Full rule catalog

## Rule 154 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  The reliability known_failing_models decorator must attach a _known_failing_models attribute to the wrapped test function; do not change the attribute name or attachment mechanism.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  when modifying the known_failing_models decorator or how tests are marked as known-failing for specific models
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c0c6536c58a432a1c6675648.md)

## Rule 155 — `dspy/signatures/signature.py`

- **Rule:**
  ```text
  Signature.insert must place a field into input or output fields according to the field's __dspy_field_type, support negative indices, default a missing type to str, raise ValueError for out-of-range indices, and return a new Signature that preserves instructions.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:** when modifying Signature.insert or the field-insertion behavior of Signature
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c1195364185d305f5ffb3485.md)

## Rule 156 — `**/*.py`

- **Rule:** Ruff linting enables the rule sets E, W, F, I, C, B, UP, N, RUF, and Q.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-c17683e6a727a1c167a69951.md)

## Rule 157 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler sets heading level 3.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c420d25dc8681e26f1c53509.md)

## Rule 158 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler uses Google docstring style.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c77ccb01b8c7d67b9acf25ad.md)

## Rule 159 — `tests/teleprompt/test_copro_optimizer.py`

- **Rule:**
  ```text
  When a test enables COPRO.track_stats, the compiled student must expose total_calls > 0 plus results_best and results_latest entries.
  ```
- **Applies to:**
  - `tests/teleprompt/test_copro_optimizer.py`
- **Condition:**
  ```text
  Modifying COPRO statistics tracking or compiled student statistics exposure when track_stats is enabled.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c7c8900809a9e6a0241f2a5d.md)

## Rule 160 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler enables category headings.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c8e3d601d839d34c2fb82d4b.md)

## Rule 161 — `dspy/**/*.py`

- **Rule:**
  ```text
  Ruff linting/formatting applies to Python files under dspy/ and tests/ as configured by include = ["dspy/**/*.py", "tests/**/*.py"].
  ```
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c96220426b095b5c3f51a757.md)

## Rule 162 — `.github/workflows/precommits_check.yml`

- **Rule:** The workflow sets up Python version 3.10 with pip caching.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c982f8e33a1b44c3f9a9ccd0.md)

## Rule 163 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings rendering options disable warnings.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c9e6eb9012b863f8c4944f93.md)

## Rule 164 — `tests/retrievers/test_embeddings.py`

- **Rule:**
  ```text
  Tests that exercise embeddings retrieval must use a dummy_embedder mapping texts containing 'cat' to [1,0,0], 'dog' to [0,1,0], and anything else to [0,0,1], returning a stacked float32 array, so retrieval assertions rely on fixed orthogonal embeddings.
  ```
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** When adding or modifying tests for embeddings retrieval that depend on deterministic embedding vectors.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ca6186b0ef9e2a1c3ee3b2e7.md)

## Rule 165 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/copro.md to api/optimizers/COPRO.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cbf511094cf52977e20d34fa.md)

## Rule 166 — `dspy/adapters/types/code.py`

- **Rule:**
  ```text
  Code.validate_input must accept an existing Code instance, a raw string wrapped as {'code': _filter_code(data)}, or a dict requiring a string 'code' key, raising ValueError for missing/non-string code or other types; all string inputs pass through _filter_code.
  ```
- **Applies to:**
  - `dspy/adapters/types/code.py`
- **Condition:** When changing Code input validation or the accepted input forms for the Code type.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc2a50856e7e77a0cd959ac7.md)

## Rule 167 — `tests/adapters/test_json_adapter.py`

- **Rule:**
  ```text
  Tests that exercise JSON adapter image formatting must assert that formatting a signature with two image demos and one image input yields exactly 6 messages, with image_url content dicts at messages[1], [3], and [5], fixing the few-shot image message layout.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When adding or modifying tests for JSON adapter formatting of image demos or image inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cc951da352c5939034c971d6.md)

## Rule 168 — `pyproject.toml`

- **Rule:**
  ```text
  The build-and-publish-test-pypi job updates the package name in pyproject.toml to dspy-ai-test using sed against the #replace_package_name_marker.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cda5252797e736b9b6fafc66.md)

## Rule 169 — `.github/workflows/precommits_check.yml`

- **Rule:** Pull request titles are checked against a regexp requiring a conventional-commit-style type prefix followed by a scope in parentheses, a colon, a space, and a description.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ce5347d1bf8f8c1241f4c4c0.md)

## Rule 170 — `tests/utils/test_langchain_tool.py`

- **Rule:**
  ```text
  convert_langchain_tool must preserve the tool name and description, generate a JSON schema for nested pydantic args, map arg_types to the pydantic class, and default arg_desc to 'No description provided. (Required)' when absent.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:**
  ```text
  When modifying langchain tool conversion tests or the convert_langchain_tool behavior they exercise, including name/description preservation, nested pydantic schema generation, arg_types mapping, and arg_desc defaulting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cf660abecd6e363a3bb1ae99.md)

## Rule 171 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler shows source.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-cf69b7791fa93da8f0a0a189.md)
