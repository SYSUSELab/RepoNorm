# Full rule catalog

## Rule 191 — `tests/reliability/reliability_tests_conf.yaml`

- **Rule:**
  ```text
  Populate `reliability_tests_conf.yaml` in the reliability tests directory with LiteLLM model/provider names and access credentials for each LLM to test and for the LLM judge, placing them in the `litellm_params` section for each model in the defined `model_list`.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-eb0e889d10d50354d187fae4.md)

## Rule 192 — `tests/metadata/test_metadata.py`

- **Rule:**
  ```text
  Before publishing to PyPI, the workflow creates a virtual environment named test_before_pypi, installs the locally built wheel with pytest and pytest-asyncio, and runs `pytest tests/metadata/test_metadata.py tests/predict`.
  ```
- **Applies to:**
  - `tests/metadata/test_metadata.py`
  - `tests/predict/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eb7e57457380ae572b408bc9.md)

## Rule 193 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ec5961331f0d9210e53cc277.md)

## Rule 194 — `dspy/dsp/utils/utils.py`

- **Rule:**
  ```text
  flatten must concatenate child lists via result += child_list, meaning it only works for list-of-lists and will extend with any iterable rather than recursively flattening nested structures.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:** When modifying flatten or relying on it for nested-structure flattening.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ece1cf49325a297e47f8220e.md)

## Rule 195 — `dspy/adapters/__init__.py`

- **Rule:**
  ```text
  dspy.adapters.__init__ must export a fixed __all__ including Adapter, ChatAdapter, Type, History, Image, Audio, Code, JSONAdapter, XMLAdapter, TwoStepAdapter, Tool, and ToolCalls, defining the public adapters API surface.
  ```
- **Applies to:**
  - `dspy/adapters/__init__.py`
- **Condition:**
  ```text
  when modifying dspy/adapters/__init__.py exports or __all__
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed19a971f0980eb91c349d81.md)

## Rule 196 — `dspy/datasets/alfworld/alfworld.py`

- **Rule:** The alfworld init helper must communicate with a worker process by putting an ("init", idx) message on inq and blocking on outq.get(), so callers must have a corresponding worker consuming the queue.
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** When changing the alfworld environment session init helper or its worker-process IPC contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ed63f327024d1b7c2cbdaae7.md)

## Rule 197 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-pypi job installs setuptools, wheel, twine, and build via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ee2005a1fc19dab4fb5194da.md)

## Rule 198 — `tests/utils/test_exceptions.py`

- **Rule:** AdapterParseError's string form must include the adapter name, raw LM response, expected output fields, and actually parsed output fields, making the message format a stable contract for parse-failure diagnostics.
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:** When modifying AdapterParseError message formatting or its diagnostic fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-efc55390f16f1fd9963fab68.md)

## Rule 199 — `**/*.py`

- **Rule:** Ruff format does not format code inside docstrings (docstring-code-format = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f0ce3d7cb437901fcb0b0e3a.md)

## Rule 200 — `tests/signatures/test_custom_types.py`

- **Rule:** When a test resolves signature string annotations, local, module-level, and nested (dot-notation) custom types must resolve, and an alias assigned to a nested type must resolve to the underlying nested class.
- **Applies to:**
  - `tests/signatures/test_custom_types.py`
- **Condition:** Modifying signature string annotation resolution for local, module-level, nested, or aliased custom types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f1834309fa5bc1dfe85174a6.md)

## Rule 201 — `dspy/signatures/signature.py`

- **Rule:**
  ```text
  Signature.with_instructions must return a new Signature subclass derived from the existing fields with replaced instructions, preserving the immutable-style derivation contract rather than mutating the receiver.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When modifying or extending Signature.with_instructions or adding sibling derivation helpers on Signature.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f18ac16b039aa7c8b70d9afe.md)

## Rule 202 — `dspy/streaming/messages.py`

- **Rule:** StatusMessage must remain a dataclass wrapping a single message string for status streaming, defining the minimal payload shape for status stream events.
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:** when modifying StatusMessage or the status stream event payload shape
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f43b4027676823aed2fbc69e.md)

## Rule 203 — `tests/utils/test_saving.py`

- **Rule:**
  ```text
  Save/load version-mismatch tests must patch get_dependency_versions separately in dspy.primitives.base_module (save path) and dspy.utils.saving (load path), assert exactly three mismatch warnings are logged, and verify the model still loads with an equal signature despite mismatched python/dspy/cloudpickle versions.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** When modifying save/load version-mismatch tests or the dependency-version warning behavior they exercise across the save and load modules.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f4fbca6c43fa5ed202828bea.md)

## Rule 204 — `dspy/signatures/signature.py`

- **Rule:**
  ```text
  make_signature must validate that field names are strings, field values are tuples or FieldInfo, and field types are valid type constructs, silently defaulting None types to str to avoid breaking program-of-thought and teleprompters.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When changing make_signature validation or the handling of field names, values, or types.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f6d3c0211e0191356edcebb8.md)

## Rule 205 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  The build-and-publish-pypi job updates __version__ in ./dspy/__metadata__.py using sed against the #replace_package_version_marker.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f8d94d320181ab3e81e60caa.md)

## Rule 206 — `tests/**`

- **Rule:** The test job runs pytest over the tests/ directory via uv run -p .venv pytest -vv tests/.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f986978ee8efc5002153cf9c.md)
