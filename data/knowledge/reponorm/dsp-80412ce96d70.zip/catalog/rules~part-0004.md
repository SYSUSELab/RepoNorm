# Full rule catalog

## Rule 053 — `pyproject.toml`

- **Rule:**
  ```text
  The build-and-publish-pypi job updates the version in pyproject.toml using sed against the #replace_package_version_marker.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4780dd16d6e1dbb18a3bae42.md)

## Rule 054 — `tests/reliability/generate/utils.py`

- **Rule:** The assertion-generation signature must instruct the model to produce natural-language assertions, ideally about 5, and to leave them blank when accurate assertions are too difficult.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying the assertion-generation signature or its output contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-48281badb30b0fb0fadda955.md)

## Rule 055 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/bootstrap-fewshot.md to api/optimizers/BootstrapFewShot.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-48db0a12edbb4dd32a8929d7.md)

## Rule 056 — `tests/signatures/test_signature.py`

- **Rule:** When a test constructs a Predict from a signature with multiline instructions, the Predict must still return the LM output field value, so multiline instruction text must be accepted without breaking prediction.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** Modifying instruction handling or signature parsing such that multiline instruction text could break Predict execution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4aac58e1e8a15154b3f31f41.md)

## Rule 057 — `tests/adapters/test_xml_adapter.py`

- **Rule:**
  ```text
  When a test formats a signature with nested ImageWrapper demos, XMLAdapter.format must produce four messages, place each demo image as an image_url content entry in the few-shot user message, and place the query image in the last user message.
  ```
- **Applies to:**
  - `tests/adapters/test_xml_adapter.py`
- **Condition:** Modifying XMLAdapter.format handling of nested image models in demos or query inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4eb16762c5d1d0a7cc43021c.md)

## Rule 058 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site loads the extra JavaScript file js/runllm-widget.js.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-4f9302a0096b617365b55012.md)

## Rule 059 — `tests/reliability/test_pydantic_models.py`

- **Rule:**
  ```text
  test_tool_calling_with_literals must parametrize over dspy.Predict and dspy.ChainOfThought and assert the predicted next_tool_name is one of a fixed set of valid tool names, checking literal-constrained tool selection.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  when modifying test_tool_calling_with_literals or the literal-constrained tool selection assertions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-512c146b1df56ae5be0d2182.md)

## Rule 060 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the dspy dependency in .github/.internal_dspyai/pyproject.toml to the extracted tag version using a sed command keyed on the #replace_dspy_version_marker comment.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5163f45807be350de525d205.md)

## Rule 061 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps intro/index.md to index.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-51f254b67b652d7b3d256590.md)

## Rule 062 — `dspy/streaming/streaming_listener.py`

- **Rule:**
  ```text
  When allow_reuse is set, a completed stream must reset stream_end, cache_hit, field_start_queue, field_end_queue, and stream_start so the listener can be reused for a subsequent stream; otherwise receive returns early.
  ```
- **Applies to:**
  - `dspy/streaming/streaming_listener.py`
- **Condition:**
  ```text
  when modifying StreamListener.receive or the allow_reuse stream-reset behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-522896dd19291c5142b50c61.md)

## Rule 063 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job installs setuptools, wheel, twine, build, semver, and packaging via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-53f70e4cd066c7182d219c28.md)

## Rule 064 — `dspy/teleprompt/infer_rules.py`

- **Rule:**
  ```text
  InferRules/RulesInductionProgram must initialize self.rng = random.Random(0) to keep rule induction deterministic across runs, and must default teacher_settings to an empty dict when none is provided.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  When modifying InferRules/RulesInductionProgram initialization or its randomness/teacher_settings defaults.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5688d5c8fee147f97dd9920e.md)

## Rule 065 — `tests/primitives/test_python_interpreter.py`

- **Rule:**
  ```text
  PythonInterpreter read-path sandbox tests must verify that enable_read_paths exposes files at /sandbox/<name> and that enable_read_paths=None denies access with a permission or no-such-file error.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** when modifying or extending PythonInterpreter read-path sandbox tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-56f7e4dceca6fb44415c55fc.md)

## Rule 066 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  parse_reliability_conf_yaml must remain lru_cache'd, require each model_list entry to have a model_name (raising ValueError otherwise), only record entries that have litellm_params, require a top-level adapter key, and wrap any failure in a ValueError naming the conf file.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  when modifying parse_reliability_conf_yaml or the reliability conf schema it validates
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5750a4716c87417d45db2223.md)

## Rule 067 — `tests/utils/test_langchain_tool.py`

- **Rule:**
  ```text
  The langchain tool test must define a @tool get_age taking a Pydantic Profile model and returning profile.age, exercising conversion of tools whose arguments are Pydantic models.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:** when modifying the langchain tool test or its Pydantic-model argument fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-5d9b5584aa257cb621b20d36.md)

## Rule 068 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/miprov2.md to api/optimizers/MIPROv2.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-629d7529fb310efbe9c54ee6.md)

## Rule 069 — `dspy/evaluate/evaluate.py`

- **Rule:**
  ```text
  merge_dicts must rename colliding keys by prefixing example_ for keys present in both dicts from d1 and pred_ for keys from d2, avoiding key collisions when merging example and prediction dicts.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:**
  ```text
  When modifying merge_dicts or the example/prediction key-collision handling in evaluation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-63700aa0e049ab35955d6b1c.md)
