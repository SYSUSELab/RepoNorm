# Full rule catalog

## Rule 102 — `tests/retrievers/test_embeddings.py`

- **Rule:** Tests that exercise concurrent multithreaded embeddings search must assert that search supports ThreadPoolExecutor concurrency and that results are returned in the original query order.
- **Applies to:**
  - `tests/retrievers/test_embeddings.py`
- **Condition:** When adding or modifying tests for concurrent multithreaded embeddings search.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-89b63c61c4e3792bced7296a.md)

## Rule 103 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job builds the package with uv run -p .venv python -m build.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8b2efa18dac198fc51051160.md)

## Rule 104 — `dspy/teleprompt/bootstrap_finetune.py`

- **Rule:**
  ```text
  FailedPrediction must hold completion_text and an optional format_reward float defaulting to None, so failed finetuning predictions may lack a format reward.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When changing the FailedPrediction record or its format_reward default.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8eb33a18e875ac4260443d39.md)

## Rule 105 — `tests/**/*.py`

- **Rule:**
  ```text
  Ruff per-file ignores for tests/**/*.py disable S101, TID252, and ARG001, allowing assert statements, relative imports, and unused arguments in test files.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9183669098b3302c3ee3a1c2.md)

## Rule 106 — `tests/utils/test_unbatchify.py`

- **Rule:**
  ```text
  The unbatchify test helper simple_batch_processor must return [item + 1 for item in batch], establishing the expected batch-processing shape used by unbatchify tests.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** When modifying unbatchify tests or the batch-processing helper shape they exercise.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-92416b843e9e3bee581a2378.md)

## Rule 107 — `tests/adapters/test_chat_adapter.py`

- **Rule:** Adapter tests that assert literal quoting must cover both single- and double-quote scenarios, including the case where both quote types appear in one value and escaping is required.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** when modifying or extending ChatAdapter literal-quoting assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9337ba0e576b6be2c2d9f049.md)

## Rule 108 — `tests/adapters/test_xml_adapter.py`

- **Rule:**
  ```text
  Adapter parse failures for missing required signature fields must raise AdapterParseError carrying adapter_name, signature, lm_response, and a message naming the missing field.
  ```
- **Applies to:**
  - `tests/adapters/test_xml_adapter.py`
- **Condition:** When modifying XML adapter parsing or its error handling for completions missing a required field.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-94e36327c050f8e0d0fb901a.md)

## Rule 109 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler sets the annotations path to brief.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-956d6b12e22bc563da4054ea.md)

## Rule 110 — `dspy/teleprompt/__init__.py`

- **Rule:**
  ```text
  dspy/teleprompt/__init__.py must re-export optimizer classes and declare __all__; Teleprompter is imported but intentionally omitted from __all__, so it is not part of the advertised public teleprompt API.
  ```
- **Applies to:**
  - `dspy/teleprompt/__init__.py`
- **Condition:**
  ```text
  when modifying dspy/teleprompt/__init__.py exports or __all__
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-96d9765de049ccf36b8c9a16.md)

## Rule 111 — `**/*.py`

- **Rule:**
  ```text
  Ruff's isort lint rule treats the `dspy` package as first-party when classifying imports.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-97d7b4213037c5096237b9ff.md)

## Rule 112 — `tests/utils/test_settings.py`

- **Rule:** dspy.configure called inside an async coroutine directly invoked by the entry task applies to that same async task, illustrating task-local settings propagation.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying async task-local dspy settings propagation or the foo4 coroutine
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-97ec065eabf4e001a8a6b151.md)

## Rule 113 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  expand_refs in the reliability generate utils must inline JSON-schema $ref definitions and preserve the DSPy-specific __dspy_field_type marker when a $ref node also carries it, so generated models retain DSPy field typing after ref expansion.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying JSON-schema ref expansion in the reliability generate utils, particularly handling of $ref nodes that also carry DSPy field-type markers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-983b3145d85c65128a003aa8.md)

## Rule 114 — `tests/**`

- **Rule:**
  ```text
  The llm_call_test job runs pytest with -m llm_call --llm_call -vv --durations=5 over the tests/ directory.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-98a3ca35d9ca7ed7a99790b2.md)

## Rule 115 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The build-and-publish-test-pypi job determines the TestPyPI version by running .github/workflows/build_utils/test_version.py with package name dspy-ai-test and the extracted tag version.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9958e5275bfe527484f4c844.md)

## Rule 116 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler enables symbol type headings.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9974268504775de6df4988a4.md)

## Rule 117 — `tests/reliability/generate/utils.py`

- **Rule:** Parameterized test decorators in tests/reliability/generate/utils.py must be implemented as decorator factories whose inner decorator returns a wrapper; do not implement them as single-level decorators.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying a parameterized test decorator in the reliability generate utils
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-99fbfa0bb4d2f06c2fff9809.md)

## Rule 118 — `tests/primitives/test_module.py`

- **Rule:**
  ```text
  Tests that exercise Module traversal must assert that named_sub_modules traverses nested lists, dicts, and tuples and includes the same module instance multiple times, while named_parameters does not allow recursive structures.
  ```
- **Applies to:**
  - `tests/primitives/test_module.py`
- **Condition:** When adding or modifying tests for Module traversal of nested containers or repeated module instances.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9c0a574774eb234704c2d088.md)
