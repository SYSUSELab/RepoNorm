# Full rule catalog

## Rule 207 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/bfrs.md to api/optimizers/BootstrapFewShotWithRandomSearch.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fb43601d97f77db3593a319d.md)

## Rule 208 — `tests/signatures/test_signature.py`

- **Rule:**
  ```text
  Signature field constraints must be exposed through output_fields json_schema_extra, and tests must assert minimum/maximum length and greater/less-than-or-equal bounds on those fields.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** when adding or modifying signature field constraint assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fb5794fad33aa669c1a35a44.md)

## Rule 209 — `tests/teleprompt/test_random_search.py`

- **Rule:** Tests that exercise the random search optimizer must import BootstrapFewShotWithRandomSearch from dspy.teleprompt and DummyLM from dspy.utils.dummies as the tested optimizer and dummy LM dependency.
- **Applies to:**
  - `tests/teleprompt/test_random_search.py`
- **Condition:** When adding or modifying tests for the random search optimizer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fb7f3e543211c9d19e3849e6.md)

## Rule 210 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model-2" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fb9716ac19cc6ef68638536e.md)

## Rule 211 — `dspy/adapters/xml_adapter.py`

- **Rule:**
  ```text
  XMLAdapter._parse_field_value must wrap parse_value failures in AdapterParseError carrying adapter name, signature, LM response, and the failing field/value, so XML adapter parse errors surface structured diagnostic context.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:**
  ```text
  when modifying XMLAdapter._parse_field_value or the structured parse-error context
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fc139a691af5f15db4a2d3e4.md)

## Rule 212 — `dspy/__init__.py`

- **Rule:**
  ```text
  Ruff per-file ignores for dspy/__init__.py disable I001, E402, and F405, allowing unsorted imports, imports not at the top of the file, and undefined names from wildcard imports.
  ```
- **Applies to:**
  - `dspy/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fc8217ce89ce5e090993c1de.md)

## Rule 213 — `tests/teleprompt/test_bootstrap.py`

- **Rule:** After BootstrapFewShot.compile, the compiled student's predictor demos must be at least as numerous as the validation set.
- **Applies to:**
  - `tests/teleprompt/test_bootstrap.py`
- **Condition:** When modifying BootstrapFewShot.compile or how validation examples are incorporated into predictor demos.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fe84a253af824e3541023059.md)

## Rule 214 — `tests/utils/test_settings.py`

- **Rule:**
  ```text
  test_dspy_configure_allowance_async must assert that dspy.configure may be called multiple times within the same async task, including setting lm and adapter, and that concurrent async tasks can run under that configuration.
  ```
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:**
  ```text
  when modifying test_dspy_configure_allowance_async or the async dspy.configure allowance behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-fed5673d22e3d212c41892d3.md)
