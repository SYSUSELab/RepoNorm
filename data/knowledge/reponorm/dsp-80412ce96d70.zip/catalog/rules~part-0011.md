# Full rule catalog

## Rule 172 — `tests/utils/test_langchain_tool.py`

- **Rule:**
  ```text
  Test modules that depend on optional third-party packages must skip at module level using `importlib.util.find_spec` and `pytest.skip(..., allow_module_level=True)` when the dependency is absent, rather than failing at import time.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:**
  ```text
  when adding or modifying test modules that import optional third-party dependencies such as langchain_core
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d233c57a3d3b2aa27d19a1e5.md)

## Rule 173 — `dspy/datasets/math.py`

- **Rule:** dspy/datasets/math.py must define the MATH dataset class as the entry point for the MATH dataset loader.
- **Applies to:**
  - `dspy/datasets/math.py`
- **Condition:** When changing the MATH dataset loader entry point in dspy/datasets/math.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d34c15a79a0058efa1249bb6.md)

## Rule 174 — `dspy/utils/unbatchify.py`

- **Rule:**
  ```text
  Unbatchify.close must be idempotent: it only sets stop_event and joins the worker thread when stop_event is not already set, so repeated close calls do not re-join.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:** When modifying Unbatchify.close or its worker-thread shutdown logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d6b8d3e5d822740bedf50cf7.md)

## Rule 175 — `primitives/*.js`

- **Rule:**
  ```text
  The dspy package includes JavaScript files matching primitives/*.js as package data.
  ```
- **Applies to:**
  - `primitives/*.js`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d7a3e788e0e61807a543a8fe.md)

## Rule 176 — `tests/teleprompt/test_grpo.py`

- **Rule:**
  ```text
  When num_dspy_examples_per_grpo_step exceeds dataset size, each select_training_sample_and_update_shuffled_trainset call must still return that many items, and over repeated calls every dataset element must appear equally often.
  ```
- **Applies to:**
  - `tests/teleprompt/test_grpo.py`
- **Condition:** When modifying the GRPO dataset shuffler or its oversampling behavior when the per-step count exceeds dataset size.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d8091c9d2d89fc6c8a14b05f.md)

## Rule 177 — `tests/signatures/test_signature.py`

- **Rule:**
  ```text
  Tests that exercise Signature type parsing must assert that nested generic annotations and PEP 604 unions are preserved through parsing, including dict/list/Union/tuple origins and their args, and must use a pydantic BaseModel custom type resolved via the custom_types mapping.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When adding or modifying tests for Signature annotation parsing, custom types, or PEP 604 unions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d8bc9914169445f12103b07f.md)

## Rule 178 — `docs/**`

- **Rule:** The update-docs-subtree job runs only on push events to the stanfordnlp/dspy repository and pushes the docs directory to the dspy-docs repository's master branch.
- **Applies to:**
  - `docs/**`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push' && github.repository == 'stanfordnlp/dspy'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d91ed001e982b3a322d404e4.md)

## Rule 179 — `tests/primitives/test_base_module.py`

- **Rule:**
  ```text
  Tests that exercise usage tracking under concurrent async calls must assert that each call under a shared settings context with track_usage=True receives independent per-LM usage records keyed by model name, with prompt/completion/total token counts matching the mocked response.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When adding or modifying tests for usage tracking under concurrent async LM calls.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d92939f52c860c02d520f1f0.md)

## Rule 180 — `tests/utils/test_asyncify.py`

- **Rule:**
  ```text
  The async limiter must remain a singleton whose default total_tokens is 8, and dspy.context(async_max_workers=16) must override the same singleton instance to report total_tokens 16; do not replace the singleton with per-context instances or change the default capacity.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** when modifying the async limiter singleton or its context-driven capacity override
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d9605a3d7f7931f68be00d80.md)

## Rule 181 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job installs the built wheel from dist/*.whl into the .venv environment.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dcf7455e352a370de08a6329.md)

## Rule 182 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job publishes the distribution to test-PyPI using pypa/gh-action-pypi-publish@release/v1 with repository-url https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dfaf9b3364c626751a5a05b7.md)

## Rule 183 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps quick-start/getting-started-01.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-dff9e211f6a4f46efb50a893.md)

## Rule 184 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler orders members by source.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e05cd19dd3cb563a6f1b18ed.md)

## Rule 185 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.highlight extension with anchor_linenums true.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e1ee6b01022fe9924f613317.md)

## Rule 186 — `pyproject.toml`

- **Rule:**
  ```text
  The build-and-publish-test-pypi job updates the version in pyproject.toml using sed against the #replace_package_version_marker.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e3f8e56bf03010c0c5761164.md)

## Rule 187 — `**/*.py`

- **Rule:** Ruff format indents with spaces (indent-style = "space").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e5aeacedf4dd9f6fa2ecb747.md)

## Rule 188 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/LabeledFewShot.md to api/optimizers/LabeledFewShot.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e610178ecd5da7704c73de04.md)

## Rule 189 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.tabbed extension with alternate_style true.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e77cd4281d6bde3e0af17922.md)

## Rule 190 — `**/*.py`

- **Rule:** Ruff format uses double quotes for string literals (quote-style = "double").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eaa4f89283d3668733306ba5.md)
