# Full rule catalog

## Rule 070 — `tests/utils/test_settings.py`

- **Rule:** dspy.configure must not be called from a different async task than the initial one; calling it from a sync function invoked by an async task must raise RuntimeError with the message 'dspy.settings.configure(...) can only be called from the same async'.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that exercises dspy.configure across async task boundaries
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-66ddcbe2e89dc225b02ec5fc.md)

## Rule 071 — `dspy/clients/lm.py`

- **Rule:**
  ```text
  LM.kill must delegate to the provider's kill method, so custom providers must implement a kill(self, lm, launch_kwargs) hook to support LM teardown.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** when modifying LM.kill or adding a custom provider that must support LM teardown
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-67f3e3a9d92fda945ce8aadd.md)

## Rule 072 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The build-and-publish-test-pypi job creates a virtual environment named test_before_testpypi.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-692500dae9eeab8a7cd11423.md)

## Rule 073 — `dspy/teleprompt/signature_opt.py`

- **Rule:**
  ```text
  SignatureOptimizer.__init__ must print a red WARNING that it is deprecated and replaced by COPRO and will be removed in a future release, then delegate to the parent initializer with the same arguments.
  ```
- **Applies to:**
  - `dspy/teleprompt/signature_opt.py`
- **Condition:** When modifying SignatureOptimizer initialization or its deprecation messaging.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6e2b75193eb7908449f33894.md)

## Rule 074 — `dspy/signatures/signature.py`

- **Rule:**
  ```text
  Signature.equals must compare instructions and the union of field names, requiring each field to exist on both signatures with identical json_schema_extra, and must return False for non-BaseModel types.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:** When modifying Signature.equals or adding signature comparison logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6e504b7614dd0b5dbed12195.md)

## Rule 075 — `tests/utils/test_asyncify.py`

- **Rule:**
  ```text
  test_asyncify must use the anyio pytest marker and await verify_asyncify with varying concurrency/iteration parameters (4/10, 8/15, 8/30), asserting asyncify behaves correctly under different concurrency levels.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:**
  ```text
  when modifying test_asyncify or the asyncify concurrency test parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-6f40fd0238d0f9095c685097.md)

## Rule 076 — `pyproject.toml`

- **Rule:**
  ```text
  The build-and-publish-pypi job updates the package name in pyproject.toml to dspy using sed against the #replace_package_name_marker.
  ```
- **Applies to:**
  - `pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-705a0abaec4819d030bf4e2a.md)

## Rule 077 — `tests/conftest.py`

- **Rule:**
  ```text
  Tests gated behind opt-in pytest flags must be registered in SKIP_DEFAULT_FLAGS and skipped by pytest_collection_modifyitems unless the matching --flag option is supplied; new opt-in test categories must add both the flag registration and the skip mapping rather than relying on markers alone.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  When adding or modifying tests that should only run under an explicit CLI flag, or when changing the SKIP_DEFAULT_FLAGS mapping or pytest_addoption registrations.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-713cbcb93e745ed801aa87a5.md)

## Rule 078 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config sets num_retries to 0.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-72df345dd65cfc39a7eaba9e.md)

## Rule 079 — `**/*.py`

- **Rule:** Python 3.10 or later is required for the DSPy development environment.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-73c4dcac80f316d5e69ade2d.md)

## Rule 080 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.emoji extension using the twemoji index and to_svg generator from material.extensions.emoji.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-73e838b0a08a2ebf4700142b.md)

## Rule 081 — `dspy/clients/databricks.py`

- **Rule:**
  ```text
  _validate_chat_data must enforce that each finetuning data dict has a 'messages' key whose value is a list of dicts, and each message must contain both 'role' and 'content' keys, raising ValueError with specific messages otherwise; this is the required shape for task=CHAT_COMPLETION.
  ```
- **Applies to:**
  - `dspy/clients/databricks.py`
- **Condition:**
  ```text
  when modifying _validate_chat_data or the CHAT_COMPLETION finetuning data shape checks
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-74c969489310500fd931bc2c.md)

## Rule 082 — `dspy/signatures/signature.py`

- **Rule:**
  ```text
  Signature.input_fields must return fields filtered by type input via _get_fields_with_type.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  when modifying Signature.input_fields or the field-type filtering helper
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-76162407b16553b1c6de6587.md)

## Rule 083 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps docs/quick-start/getting-started-01.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-787b99d45f77c42acf42de62.md)

## Rule 084 — `tests/adapters/test_chat_adapter.py`

- **Rule:**
  ```text
  When a test formats a signature with few-shot image examples and an input image, the adapter must produce exactly 6 messages (1 system, 2 user/assistant pairs, 1 user), with completed markers in assistant messages and image_url content blocks in user messages.
  ```
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** Modifying ChatAdapter message construction for signatures containing few-shot image examples and an input image.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-78fbc8ac15d1a90509ec8684.md)

## Rule 085 — `dspy/teleprompt/bootstrap_finetune.py`

- **Rule:**
  ```text
  When a wrapped program raises AdapterParseError, bootstrap_trace_data must locate the predictor whose signature matches the failed signature (raising ValueError if none found), compute a format_reward scaled between format_failure_score and failure_score by the ratio of present to expected output fields, and append a FailedPrediction to the trace.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When modifying bootstrap_trace_data failure handling for AdapterParseError.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7d65e27a803679f63f004d41.md)
