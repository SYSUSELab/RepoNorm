# Full rule catalog

## Rule 136 — `**`

- **Rule:** Contributors are recommended to open an issue (if one doesn't already exist) and discuss proposed changes before making any changes.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-b2062b6757d226c4bffb320c.md)

## Rule 137 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  The build-and-publish-pypi job updates __name__ in ./dspy/__metadata__.py to dspy using sed against the #replace_package_name_marker.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b256bde779c0acd044497727.md)

## Rule 138 — `tests/utils/test_mcp.py`

- **Rule:**
  ```text
  convert_mcp_tool must preserve name/desc, expose JSON-schema args, map JSON types to Python arg_types (integer→int, array→list), synthesize arg_desc as 'No description provided. (Required)' when absent, wrap call failures in a RuntimeError prefixed 'Failed to call a MCP tool:', and support nested Pydantic object args.
  ```
- **Applies to:**
  - `tests/utils/test_mcp.py`
- **Condition:**
  ```text
  when modifying convert_mcp_tool or the MCP tool conversion contract
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b3244f6dfe58a91d8449a60d.md)

## Rule 139 — `dspy/retrievers/databricks_rm.py`

- **Rule:**
  ```text
  DatabricksRM.forward must map legacy query_type values 'vector' and 'text' to 'ANN' for backwards compatibility, validate that docs_id_column_name and text_column_name exist in the index columns, and return either agent-framework dicts or a Prediction depending on use_with_databricks_agent_framework.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:**
  ```text
  when modifying DatabricksRM.forward or its legacy query_type mapping, column validation, or return-shape branching
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b49ef3562b1a483bf7a4a242.md)

## Rule 140 — `dspy/teleprompt/infer_rules.py`

- **Rule:**
  ```text
  get_predictor_demos must filter each trainset example down to keys present in the predictor signature's input or output fields, dropping extra example keys before demos are used.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when modifying get_predictor_demos or the demo-key filtering behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b774a1ac60d762716d5a122f.md)

## Rule 141 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job installs uv with caching enabled, keyed on **/pyproject.toml and **/uv.lock.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b7848721605a30eeff7c8fa4.md)

## Rule 142 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site loads the extra stylesheet stylesheets/extra.css.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b8bab0c9293f57aa5bf60b5e.md)

## Rule 143 — `dspy/evaluate/evaluate.py`

- **Rule:** EvaluationResult must subclass dspy.Prediction and expose score as a float and results as a list of (example, prediction, score) tuples, defining the expected shape of evaluation outputs.
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** when modifying EvaluationResult or the shape of evaluation outputs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ba6e3099bf1383072f5e935c.md)

## Rule 144 — `docs/mkdocs.yml`

- **Rule:** The mkdocs-jupyter plugin ignores H1 titles.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bb97bca8c1be1260536e6dce.md)

## Rule 145 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps quick-start/getting-started-02.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bb9b38d920b3561b05b0cee3.md)

## Rule 146 — `tests/teleprompt/test_grpo.py`

- **Rule:**
  ```text
  GRPO dataset shuffling must return samples of size num_dspy_examples_per_grpo_step whose elements are exactly the dataset set, and repeated calls must keep returning full-size samples from the same dataset.
  ```
- **Applies to:**
  - `tests/teleprompt/test_grpo.py`
- **Condition:** when modifying GRPO dataset shuffling, sample size, or repeated-call behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bc0ffc4c1aad816b0c283416.md)

## Rule 147 — `tests/utils/test_saving.py`

- **Rule:**
  ```text
  The saving test fixture must compose two ChainOfThought modules in sequence (question->refined_question then refined_question->answer) to exercise save/load of multi-module programs.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** When modifying save/load tests or the multi-module program fixtures they exercise.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bc4947509ac915c5b1db9b43.md)

## Rule 148 — `tests/primitives/test_base_module.py`

- **Rule:**
  ```text
  Tests that exercise Module.deepcopy must assert that parameter count is preserved, locks are shallow-copied (same lock object identity), and parameter objects are deep-copied so parameter ids differ while __dict__ values match.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When adding or modifying tests for Module.deepcopy of nested modules or parameters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bc8ebd6947353f0560e54f3d.md)

## Rule 149 — `dspy/clients/lm_local_arbor.py`

- **Rule:**
  ```text
  ArborReinforceJob.__init__ must raise ValueError when 'num_generations' is absent from train_kwargs, documenting a required teleprompter-set training parameter.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:**
  ```text
  When changing ArborReinforceJob construction or the required train_kwargs contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bd66a99c41f6456b84da8fe8.md)

## Rule 150 — `dspy/streaming/messages.py`

- **Rule:**
  ```text
  on_lm_end must return early when settings.send_stream is None and only emit a StatusMessage when the status message provider returns a non-empty message.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  When modifying StatusStreamingCallback.on_lm_end or the status message emission path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-be7dd451d83c67a8089b42d8.md)

## Rule 151 — `tests/test_utils/server/litellm_server.py`

- **Rule:** The litellm test server module must define DSPyTestModel as a subclass of CustomLLM to provide a custom LLM implementation for server-based tests.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When modifying the litellm test server module or adding custom LLM implementations for server-based tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-beb12f85e281365ce86db4fb.md)

## Rule 152 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps intro.md to index.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bf32065d63a29068481782ca.md)

## Rule 153 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler unwraps Annotated types.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-bfa911e4a55dd0f1032ab8c0.md)
