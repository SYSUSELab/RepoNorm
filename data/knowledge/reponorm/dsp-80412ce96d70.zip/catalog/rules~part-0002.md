# Full rule catalog

## Rule 019 — `dspy/retrievers/databricks_rm.py`

- **Rule:**
  ```text
  DatabricksRM._query_via_requests must require exactly one of query_text or query_vector, post to /api/2.0/vector-search/indexes/{index_name}/query with columns, num_results, query_type, and optional filters_json, and raise on error_code in the JSON response.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:**
  ```text
  when modifying DatabricksRM._query_via_requests or its request/response handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-15da08458ad74a59a1685596.md)

## Rule 020 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-16895e9fe3290a4e8ed80fd2.md)

## Rule 021 — `dspy/clients/openai.py`

- **Rule:**
  ```text
  OpenAIProvider.get_training_status must map every provider training status to a DSPy training status, returning not_started when job_id is None; adding a new provider status requires extending this mapping rather than falling through.
  ```
- **Applies to:**
  - `dspy/clients/openai.py`
- **Condition:**
  ```text
  When adding or changing a provider training status handled by OpenAIProvider.get_training_status.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1a4b5828a1d231cd69812f5a.md)

## Rule 022 — `.github/workflows/precommits_check.yml`

- **Rule:** The Pre-Commit Checks step installs and upgrades pip, installs pre-commit, and runs pre-commit run -v --files on the changed files.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1b41255bb4dd39857d12fcf7.md)

## Rule 023 — `tests/reliability/complex_types/generated/test_many_types_1/program.py`

- **Rule:** A program signature can be built dynamically by iterating pydantic model fields and appending dspy.InputField/OutputField with the field's annotation and description to a BaseSignature.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying generated reliability test programs that construct signatures from pydantic model fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1bcab8bcbf42e0902b6daf8c.md)

## Rule 024 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the package name in .github/.internal_dspyai/pyproject.toml to dspy-ai using a sed command keyed on the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1fa287ecfc82304ce54cb6c7.md)

## Rule 025 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler shows signature annotations.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1fd79fdcbbec67dfb7d1105c.md)

## Rule 026 — `dspy/signatures/signature.py`

- **Rule:**
  ```text
  _parse_type_node must recursively convert AST type annotations into Python types, raising ValueError for unhandled AST nodes with guidance to use class-based Signatures, and must special-case PEP 604 X | None into Optional and typing.Union/typing.Optional subscripts.
  ```
- **Applies to:**
  - `dspy/signatures/signature.py`
- **Condition:**
  ```text
  When extending _parse_type_node to handle additional AST node kinds or new typing constructs.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1fd91fae1e6fc93bdd999a62.md)

## Rule 027 — `dspy/retrievers/databricks_rm.py`

- **Rule:**
  ```text
  When use_with_databricks_agent_framework is True, DatabricksRM must import mlflow and call set_retriever_schema with primary_key='doc_id', text_column='page_content', doc_uri='doc_uri', raising ValueError if mlflow is missing.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:** When modifying DatabricksRM initialization or the Databricks agent framework integration path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-21095dcd623012e86f541500.md)

## Rule 028 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler uses the table docstring section style.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-21f120a0615458a1dbd6ad5f.md)

## Rule 029 — `tests/reliability/conftest.py`

- **Rule:**
  ```text
  The autouse configure_model fixture must read reliability_conf.yaml, configure dspy with the parametrized model and adapter, skip tests when no YAML config exists for the model, and store should_ignore_failure and model_name on the request node for post-test handling.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** when modifying the reliability test fixture or its model configuration and skip behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2256cd9806bdf36c0ff50ef4.md)

## Rule 030 — `dspy/predict/__init__.py`

- **Rule:**
  ```text
  dspy.predict.__init__ must export the fixed set of names in __all__ including majority, BestOfN, ChainOfThought, CodeAct, KNN, MultiChainComparison, Predict, ProgramOfThought, ReAct, Refine, Tool, and Parallel, defining the public predict API surface.
  ```
- **Applies to:**
  - `dspy/predict/__init__.py`
- **Condition:**
  ```text
  when modifying dspy.predict.__init__ or the public predict API surface
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2357011e76bd132a0bde91cd.md)

## Rule 031 — `**/*.py`

- **Rule:** Ruff linting ignores rules B027, FBT003, C901, E501, UP035, RUF005, B904, F403, E721, UP031, and RUF022.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-249c73f85684fc6b5c08fd26.md)

## Rule 032 — `tests/clients/test_lm.py`

- **Rule:**
  ```text
  When a test asserts that dspy.LM forwards model, api_base, api_key, and azure_ad_token_provider to litellm.completion, a callable azure_ad_token_provider must be passed through to the underlying completion call.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:**
  ```text
  Modifying dspy.LM parameter forwarding to litellm.completion, especially callable parameters such as azure_ad_token_provider.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-26caf5210c689431dac3fde6.md)

## Rule 033 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/Ensemble.md to api/optimizers/Ensemble.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-26f0e02b92c2331bc7c056f3.md)

## Rule 034 — `dspy/predict/code_act.py`

- **Rule:**
  ```text
  CodeAct._build_instructions must construct instructions from the signature's input/output field names, enumerate tools, and instruct the model to print outputs and mark finished=True when outputs are extractable.
  ```
- **Applies to:**
  - `dspy/predict/code_act.py`
- **Condition:**
  ```text
  when modifying CodeAct._build_instructions or the CodeAct instruction protocol
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-2a409efa37492c4202407667.md)
