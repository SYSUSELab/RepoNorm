# Full rule catalog

## Rule 001 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler shows docstring parameters.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-014168498c96f7385d860696.md)

## Rule 002 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/BootstrapFinetune.md to api/optimizers/BootstrapFinetune.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-035f663eb3736a40cac4210c.md)

## Rule 003 — `dspy/predict/multi_chain_comparison.py`

- **Rule:**
  ```text
  MultiChainComparison.__init__ must append M reasoning_attempt input fields and prepend a rationale output field to the signature, capturing the last original output field as last_key; signature field ordering is part of the module contract.
  ```
- **Applies to:**
  - `dspy/predict/multi_chain_comparison.py`
- **Condition:** When modifying MultiChainComparison signature construction or field ordering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-043cd3bda95dee229c07aa80.md)

## Rule 004 — `dspy/utils/caching.py`

- **Rule:**
  ```text
  The cache directory must default to ~/.dspy_cache but be overridden by the DSPY_CACHEDIR environment variable when set, establishing environment-variable precedence for cache location.
  ```
- **Applies to:**
  - `dspy/utils/caching.py`
- **Condition:** When changing cache directory resolution or environment-variable handling in caching.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0457148080da36225b4c8a2a.md)

## Rule 005 — `tests/utils/test_syncify.py`

- **Rule:** Syncify tests must define their program as a dspy.Module subclass; do not use a non-Module program shape in these tests.
- **Applies to:**
  - `tests/utils/test_syncify.py`
- **Condition:** when adding or modifying a syncify test program
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-05158a96597c9bb5dcf8de8a.md)

## Rule 006 — `dspy/dsp/utils/settings.py`

- **Rule:**
  ```text
  DEFAULT_CONFIG must remain the baseline settings surface and be deep-copied into main_thread_config, with thread-local overrides held in a ContextVar, so that per-thread settings isolation is preserved.
  ```
- **Applies to:**
  - `dspy/dsp/utils/settings.py`
- **Condition:**
  ```text
  When adding, removing, or renaming a setting in DEFAULT_CONFIG or changing how thread-local overrides are stored.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-05fb7395aff1b6cb9ff9fd41.md)

## Rule 007 — `tests/reliability/conftest.py`

- **Rule:**
  ```text
  Reliability tests must cover a standard cross-provider MODEL_LIST spanning OpenAI, Anthropic, Gemini, Llama, and DeepSeek models.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:** When modifying the reliability test model matrix or adding/removing providers from the standard list.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0643d27815be511138029924.md)

## Rule 008 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler disables separate signatures.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-06d524fd9911037a94b2362b.md)

## Rule 009 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The mkdocstrings Python handler merges __init__ into the class.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-08a8196bc5f60480e4785fc9.md)

## Rule 010 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job creates a virtual environment at .venv and adds its bin directory to GITHUB_PATH.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-08fb4034a533c871dcbe7a0a.md)

## Rule 011 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler shows the root heading.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0a3b74c11bacc0e62d76eadd.md)

## Rule 012 — `dspy/evaluate/evaluate.py`

- **Rule:**
  ```text
  truncate_cell must truncate cell content to 25 words and append '...', establishing the evaluation display truncation convention.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:**
  ```text
  When modifying evaluation display truncation or the truncate_cell helper.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0c22c18c57ce8a091b78304e.md)

## Rule 013 — `.github/workflows/build_utils/test_version.py`

- **Rule:**
  ```text
  When modifying the version-bump helper, preserve the CLI contract that the script requires exactly two arguments (package_name, tag_version), fetches the latest version, optionally increments it, and prints the resulting version.
  ```
- **Applies to:**
  - `.github/workflows/build_utils/test_version.py`
- **Condition:** Changing the command-line interface or argument handling of the version-bump helper.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0e13b2d3b6d81eb7b598b4d2.md)

## Rule 014 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site defines a default palette scheme with white primary and black accent.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0e25792068e846f773a55b85.md)

## Rule 015 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site enables the search plugin with language en.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0f94c3701e5592c1679695f1.md)

## Rule 016 — `tests/adapters/test_tool.py`

- **Rule:**
  ```text
  Calling an async Tool in sync mode must raise ValueError unless dspy.context(allow_tool_async_sync_conversion=True) is set, in which case the awaited result is returned.
  ```
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:**
  ```text
  When modifying async Tool invocation in sync mode or the allow_tool_async_sync_conversion context flag.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-0fea955e7c0355eca53a6985.md)

## Rule 017 — `tests/clients/test_lm.py`

- **Rule:**
  ```text
  LM.dump_state must return a dict containing model, model_type, temperature, max_tokens, num_retries, cache, cache_in_memory, finetuning_model, launch_kwargs, and train_kwargs, with cache defaulting to True and finetuning_model to None.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:**
  ```text
  when modifying or extending LM.dump_state serialization assertions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-1219683de14c962454e24638.md)

## Rule 018 — `.github/.internal_dspyai/dist/**`

- **Rule:**
  ```text
  The workflow publishes the dspy-ai distribution to PyPI using pypa/gh-action-pypi-publish@release/v1 with attestations disabled and packages-dir set to .github/.internal_dspyai/dist/.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/dist/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-15832739d482f5ef4283e3fc.md)
