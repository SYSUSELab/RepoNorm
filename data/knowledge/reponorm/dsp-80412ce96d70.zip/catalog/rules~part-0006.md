# Full rule catalog

## Rule 086 — `dspy/teleprompt/ensemble.py`

- **Rule:**
  ```text
  The EnsembledProgram should imitate the structure of individual programs (if compatible) so it can serve as a singular teacher, with the top majority-compatible trace used when dspy.majority is the reduce_fn.
  ```
- **Applies to:**
  - `dspy/teleprompt/ensemble.py`
- **Condition:**
  ```text
  When changing EnsembledProgram structure or its reduce_fn behavior for dspy.majority.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-7e94a87403bdc8add9d6b544.md)

## Rule 087 — `dspy/clients/lm_local_arbor.py`

- **Rule:**
  ```text
  ArborProvider.get_trained_model must raise unless job.status() equals TrainingStatus.succeeded, and while retrieving the fine-tuned model it must temporarily override openai.base_url to the Arbor base API.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:**
  ```text
  when modifying ArborProvider.get_trained_model or its job-status and base_url handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-803c9b973cef663c4022801b.md)

## Rule 088 — `tests/reliability/generate/__init__.py`

- **Rule:**
  ```text
  Reliability test generation must reuse an existing generated program when the destination directory already contains one, and must always generate inputs under dst_path/inputs before returning loaded generated cases.
  ```
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:**
  ```text
  when modifying generate_test_cases or the reliability test-generation entry point
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8045551fd72a73a2f1669ea8.md)

## Rule 089 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The MkDocs search plugin uses the separator regex '[\s\-\.]+'.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8066d5d9599b06cbf697a797.md)

## Rule 090 — `tests/reliability/test_pydantic_models.py`

- **Rule:**
  ```text
  test_qa_with_pydantic_answer_model must assert that a dspy.Predict(QA) answer exposes .value, .comments, and .certainty, with certainty in [0, 1] and at least 2 comments, and must use assert_program_output_correct with grading guidelines for both value and comments.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  when modifying test_qa_with_pydantic_answer_model or the pydantic answer model assertions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-8180e43ea2b5de921842986e.md)

## Rule 091 — `tests/clients/test_cache.py`

- **Rule:**
  ```text
  When a test resets the memory cache, reset_memory_cache() must empty only the in-memory cache while previously stored requests remain retrievable from the disk cache.
  ```
- **Applies to:**
  - `tests/clients/test_cache.py`
- **Condition:**
  ```text
  Modifying reset_memory_cache or cache reset behavior such that persisted disk entries could be cleared or memory entries retained.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-81f57f0c528d0cd6f7ea6051.md)

## Rule 092 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-84e319b9540293f6365062b1.md)

## Rule 093 — `.github/workflows/precommits_check.yml`

- **Rule:** The workflow obtains the list of changed files using the jitterbit/get-changed-files action with step id files.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-850a668db6577ebb3778648f.md)

## Rule 094 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  Reliability judge configuration must load reliability_conf.yaml from the module directory, require a LiteLLM config for JUDGE_MODEL_NAME or raise ValueError, and temporarily set dspy.settings.context with the judge LM and adapter.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When modifying reliability judge configuration loading or the dspy.settings.context setup used by reliability tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-850a9640005803fdcaa607ad.md)

## Rule 095 — `tests/reliability/reliability_tests_conf.yaml`

- **Rule:**
  ```text
  Models lacking configured `litellm_params` in the configuration file are ignored during testing.
  ```
- **Applies to:**
  - `tests/reliability/reliability_tests_conf.yaml`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-85cbe3780db719ed92f2a740.md)

## Rule 096 — `tests/utils/test_exceptions.py`

- **Rule:** AdapterParseError's string form must follow a fixed template including the adapter name, raw LM response, and the list of expected output fields; changes to that message format are compatibility-relevant.
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:** When modifying AdapterParseError's string representation or its expected message template
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-85fb3bd08244afbc2c70d6b0.md)

## Rule 097 — `tests/reliability/test_pydantic_models.py`

- **Rule:**
  ```text
  Reliability tests for multi-output signatures must assert each output field separately via assert_program_output_correct with field-specific grading guidelines, including a '|'-separated categories convention.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when modifying reliability tests for multi-output signatures or their grading assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-86bbd1f356058838deeec9f2.md)

## Rule 098 — `dspy/clients/__init__.py`

- **Rule:**
  ```text
  When LiteLLM cache initialization fails, configure_cache must log a warning and set litellm.cache = None instead of propagating the exception, keeping cache setup best-effort.
  ```
- **Applies to:**
  - `dspy/clients/__init__.py`
- **Condition:**
  ```text
  Modifying configure_cache cache-initialization error handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-88891a73ff8133e0f3d4b58e.md)

## Rule 099 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site enables the pymdownx.arithmatex extension with generic true.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-88a8b6feca94ea8dad06a884.md)

## Rule 100 — `tests/utils/test_usage_tracker.py`

- **Rule:**
  ```text
  Usage tracking tests must assert that track_usage() records per-LM usage_data keyed by the LM identifier and that get_total_tokens() returns a dict keyed by that same LM identifier, and UsageTracker.get_total_tokens must aggregate prompt_tokens, completion_tokens, total_tokens, and nested prompt_tokens_details/completion_tokens_details by summing across entries.
  ```
- **Applies to:**
  - `tests/utils/test_usage_tracker.py`
- **Condition:** When modifying usage tracking tests or the UsageTracker aggregation behavior they exercise, including per-LM keying and nested token detail summation.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-88fc184a0fccc347e6a305ea.md)

## Rule 101 — `**/*.py`

- **Rule:**
  ```text
  The project requires Python >=3.10, <3.14.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-89704dbe5bc998a372e64623.md)
