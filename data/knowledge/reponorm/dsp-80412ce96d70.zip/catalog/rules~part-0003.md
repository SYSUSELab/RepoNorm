# Full rule catalog

## Rule 035 — `tests/test_utils/server/litellm_server.py`

- **Rule:** The litellm test server must map substrings in the first message content to specific litellm exceptions: '429' to RateLimitError, '504' to Timeout, '400' to BadRequestError, and '401' to AuthenticationError.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying the litellm test server's exception injection or message-content mapping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-306065c671f3389b4b349e2f.md)

## Rule 036 — `dspy/propose/grounded_proposer.py`

- **Rule:**
  ```text
  GenerateSingleModuleInstruction must conditionally include input fields based on flags: dataset_description when use_dataset_summary, program/module fields when program_aware, previous_instructions when use_instruct_history, and tip when use_tip, so the signature shape varies with configuration.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:** when modifying GenerateSingleModuleInstruction or the flag-driven signature shape of instruction generation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-311e7c52c92459ef842ab03e.md)

## Rule 037 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps docs/quick-start/getting-started-02.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-31e856d90566018c6a54f99a.md)

## Rule 038 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job installs dependencies with uv sync --dev -p .venv --extra dev.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-328ca82a6f995f93b34557e8.md)

## Rule 039 — `tests/utils/test_mcp.py`

- **Rule:**
  ```text
  The MCP utility test module must skip the entire module at import time when the optional 'mcp' package is not installed, using pytest.skip(allow_module_level=True).
  ```
- **Applies to:**
  - `tests/utils/test_mcp.py`
- **Condition:** When modifying the MCP utility tests or their optional-dependency handling.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-33f61ff99a560a23495b6a16.md)

## Rule 040 — `**/*.py`

- **Rule:** Ruff's flake8-tidy-imports rule bans all relative imports.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-34a43db1457fc3d0ed2894bc.md)

## Rule 041 — `tests/reliability/conftest.py`

- **Rule:**
  ```text
  The reliability conftest hook must rewrite failed test reports to passed (marked wasxfail) when item.should_ignore_failure is set, so known-failing models do not fail the reliability suite.
  ```
- **Applies to:**
  - `tests/reliability/conftest.py`
- **Condition:**
  ```text
  When modifying the reliability conftest report hook or the should_ignore_failure handling.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-35d8a0c7a932252559623d13.md)

## Rule 042 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the version in .github/.internal_dspyai/pyproject.toml to the extracted tag version using a sed command keyed on the #replace_package_version_marker comment.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-38cc692412638bc80cbc51f6.md)

## Rule 043 — `dspy/adapters/types/base_type.py`

- **Rule:** Type is the base class for DSPy custom types; subclasses must implement format returning a list of content-part dicts matching the OpenAI content field.
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:** when adding or modifying a DSPy custom type subclass or the Type base class format contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3c2c88ef1626eef18d01be12.md)

## Rule 044 — `dspy/teleprompt/bootstrap_finetune.py`

- **Rule:**
  ```text
  build_call_data_from_trace must index the trace by pred_ind assuming order is preserved, and pass pred.signature plus demos (empty when exclude_demos) and the trace inputs/outputs to adapter.format_finetune_data.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  Modifying build_call_data_from_trace or finetune data formatting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3cd4311e800408bb5bb72b0f.md)

## Rule 045 — `dspy/evaluate/auto_evaluation.py`

- **Rule:** SemanticRecallPrecision must define recall and precision output fields whose descriptions fix their semantic meaning as fractions out of 1.0 of ground truth covered and system response covered respectively.
- **Applies to:**
  - `dspy/evaluate/auto_evaluation.py`
- **Condition:** When changing SemanticRecallPrecision output fields or their metric semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3d42eed372b2ef21780261e9.md)

## Rule 046 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  The reliability test helper _get_judge_program must return dspy.Predict(JudgeSignature); do not construct judge programs with a different module or signature.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  when modifying _get_judge_program or how judge programs are constructed in reliability tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3da6ec45ed4bd5f645d51fd8.md)

## Rule 047 — `**/__init__.py`

- **Rule:**
  ```text
  Ruff per-file ignores for __init__.py disable F401, allowing unused imports in init files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3e6170597c2b4cb39f82c997.md)

## Rule 048 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site defines a slate palette scheme with black primary and lime accent.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3e656ad07c68974a66eb3010.md)

## Rule 049 — `tests/predict/test_knn.py`

- **Rule:** KNN query must return the configured number of nearest samples ordered with the closest match first.
- **Applies to:**
  - `tests/predict/test_knn.py`
- **Condition:** when modifying KNN query behavior, sample count, or ordering logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-406f446b3dba93c53e169f0f.md)

## Rule 050 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  Ruff excludes dspy/__metadata__.py and tests/reliability/*.py from its checks.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-40d9fedfc6a70a90e94f8edb.md)

## Rule 051 — `dspy/datasets/colors.py`

- **Rule:** Colors must split sorted colors 60/40 into train/dev and shuffle both with random.Random(0) so the split is deterministic and avoids similar-color overlap between train and dev.
- **Applies to:**
  - `dspy/datasets/colors.py`
- **Condition:** When changing the Colors dataset split logic or its shuffling seed.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-41938ad972dbbd663dec7f2e.md)

## Rule 052 — `tests/metadata/test_metadata.py`

- **Rule:**
  ```text
  The build-and-publish-test-pypi job installs the locally built wheel plus pytest and pytest-asyncio, then runs pytest on tests/metadata/test_metadata.py and tests/predict.
  ```
- **Applies to:**
  - `tests/metadata/test_metadata.py`
  - `tests/predict/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-469ed003b54af3d4e8575a41.md)
