# Rules for `dspy/predict/multi_chain_comparison.py`

## Rule 003 — `dspy/predict/multi_chain_comparison.py`

- **Rule:**
  ```text
  MultiChainComparison.__init__ must append M reasoning_attempt input fields and prepend a rationale output field to the signature, capturing the last original output field as last_key; signature field ordering is part of the module contract.
  ```
- **Applies to:**
  - `dspy/predict/multi_chain_comparison.py`
- **Condition:** When modifying MultiChainComparison signature construction or field ordering.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-043cd3bda95dee229c07aa80.md)
