# Rules for `dspy/predict/code_act.py`

## Rule 034 — `dspy/predict/code_act.py`

- **Rule:**
  ```text
  CodeAct._build_instructions must construct instructions from the signature's input/output field names, enumerate tools, and instruct the model to print outputs and mark finished=True when outputs are extractable.
  ```
- **Applies to:**
  - `dspy/predict/code_act.py`
- **Condition:**
  ```text
  when modifying CodeAct._build_instructions or the CodeAct instruction protocol
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-2a409efa37492c4202407667.md)
