# Rules for `dspy/retrievers/databricks_rm.py`

## Rule 019 — `dspy/retrievers/databricks_rm.py`

- **Rule:**
  ```text
  DatabricksRM._query_via_requests must require exactly one of query_text or query_vector, post to /api/2.0/vector-search/indexes/{index_name}/query with columns, num_results, query_type, and optional filters_json, and raise on error_code in the JSON response.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:**
  ```text
  when modifying DatabricksRM._query_via_requests or its request/response handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-15da08458ad74a59a1685596.md)

## Rule 027 — `dspy/retrievers/databricks_rm.py`

- **Rule:**
  ```text
  When use_with_databricks_agent_framework is True, DatabricksRM must import mlflow and call set_retriever_schema with primary_key='doc_id', text_column='page_content', doc_uri='doc_uri', raising ValueError if mlflow is missing.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:** When modifying DatabricksRM initialization or the Databricks agent framework integration path.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-21095dcd623012e86f541500.md)

## Rule 139 — `dspy/retrievers/databricks_rm.py`

- **Rule:**
  ```text
  DatabricksRM.forward must map legacy query_type values 'vector' and 'text' to 'ANN' for backwards compatibility, validate that docs_id_column_name and text_column_name exist in the index columns, and return either agent-framework dicts or a Prediction depending on use_with_databricks_agent_framework.
  ```
- **Applies to:**
  - `dspy/retrievers/databricks_rm.py`
- **Condition:**
  ```text
  when modifying DatabricksRM.forward or its legacy query_type mapping, column validation, or return-shape branching
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b49ef3562b1a483bf7a4a242.md)
