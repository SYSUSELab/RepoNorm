# Rules for `dspy/evaluate/auto_evaluation.py`

## Rule 045 — `dspy/evaluate/auto_evaluation.py`

- **Rule:** SemanticRecallPrecision must define recall and precision output fields whose descriptions fix their semantic meaning as fractions out of 1.0 of ground truth covered and system response covered respectively.
- **Applies to:**
  - `dspy/evaluate/auto_evaluation.py`
- **Condition:** When changing SemanticRecallPrecision output fields or their metric semantics.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3d42eed372b2ef21780261e9.md)
