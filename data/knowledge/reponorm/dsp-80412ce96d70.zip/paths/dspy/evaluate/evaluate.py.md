# Rules for `dspy/evaluate/evaluate.py`

## Rule 012 — `dspy/evaluate/evaluate.py`

- **Rule:**
  ```text
  truncate_cell must truncate cell content to 25 words and append '...', establishing the evaluation display truncation convention.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:**
  ```text
  When modifying evaluation display truncation or the truncate_cell helper.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0c22c18c57ce8a091b78304e.md)

## Rule 069 — `dspy/evaluate/evaluate.py`

- **Rule:**
  ```text
  merge_dicts must rename colliding keys by prefixing example_ for keys present in both dicts from d1 and pred_ for keys from d2, avoiding key collisions when merging example and prediction dicts.
  ```
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:**
  ```text
  When modifying merge_dicts or the example/prediction key-collision handling in evaluation.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-63700aa0e049ab35955d6b1c.md)

## Rule 143 — `dspy/evaluate/evaluate.py`

- **Rule:** EvaluationResult must subclass dspy.Prediction and expose score as a float and results as a list of (example, prediction, score) tuples, defining the expected shape of evaluation outputs.
- **Applies to:**
  - `dspy/evaluate/evaluate.py`
- **Condition:** when modifying EvaluationResult or the shape of evaluation outputs
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ba6e3099bf1383072f5e935c.md)
