# Rules for `dspy/clients/openai.py`

## Rule 021 — `dspy/clients/openai.py`

- **Rule:**
  ```text
  OpenAIProvider.get_training_status must map every provider training status to a DSPy training status, returning not_started when job_id is None; adding a new provider status requires extending this mapping rather than falling through.
  ```
- **Applies to:**
  - `dspy/clients/openai.py`
- **Condition:**
  ```text
  When adding or changing a provider training status handled by OpenAIProvider.get_training_status.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1a4b5828a1d231cd69812f5a.md)
