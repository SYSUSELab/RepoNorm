# Rules for `dspy/clients/lm.py`

## Rule 071 — `dspy/clients/lm.py`

- **Rule:**
  ```text
  LM.kill must delegate to the provider's kill method, so custom providers must implement a kill(self, lm, launch_kwargs) hook to support LM teardown.
  ```
- **Applies to:**
  - `dspy/clients/lm.py`
- **Condition:** when modifying LM.kill or adding a custom provider that must support LM teardown
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-67f3e3a9d92fda945ce8aadd.md)
