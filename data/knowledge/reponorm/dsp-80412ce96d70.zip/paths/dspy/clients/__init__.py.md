# Rules for `dspy/clients/__init__.py`

## Rule 098 — `dspy/clients/__init__.py`

- **Rule:**
  ```text
  When LiteLLM cache initialization fails, configure_cache must log a warning and set litellm.cache = None instead of propagating the exception, keeping cache setup best-effort.
  ```
- **Applies to:**
  - `dspy/clients/__init__.py`
- **Condition:**
  ```text
  Modifying configure_cache cache-initialization error handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-88891a73ff8133e0f3d4b58e.md)
