# Rules for `dspy/clients/lm_local_arbor.py`

## Rule 087 — `dspy/clients/lm_local_arbor.py`

- **Rule:**
  ```text
  ArborProvider.get_trained_model must raise unless job.status() equals TrainingStatus.succeeded, and while retrieving the fine-tuned model it must temporarily override openai.base_url to the Arbor base API.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:**
  ```text
  when modifying ArborProvider.get_trained_model or its job-status and base_url handling
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-803c9b973cef663c4022801b.md)

## Rule 149 — `dspy/clients/lm_local_arbor.py`

- **Rule:**
  ```text
  ArborReinforceJob.__init__ must raise ValueError when 'num_generations' is absent from train_kwargs, documenting a required teleprompter-set training parameter.
  ```
- **Applies to:**
  - `dspy/clients/lm_local_arbor.py`
- **Condition:**
  ```text
  When changing ArborReinforceJob construction or the required train_kwargs contract.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bd66a99c41f6456b84da8fe8.md)
