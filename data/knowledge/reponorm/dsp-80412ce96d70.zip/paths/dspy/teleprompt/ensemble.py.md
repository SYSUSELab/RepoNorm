# Rules for `dspy/teleprompt/ensemble.py`

## Rule 086 — `dspy/teleprompt/ensemble.py`

- **Rule:**
  ```text
  The EnsembledProgram should imitate the structure of individual programs (if compatible) so it can serve as a singular teacher, with the top majority-compatible trace used when dspy.majority is the reduce_fn.
  ```
- **Applies to:**
  - `dspy/teleprompt/ensemble.py`
- **Condition:**
  ```text
  When changing EnsembledProgram structure or its reduce_fn behavior for dspy.majority.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7e94a87403bdc8add9d6b544.md)
