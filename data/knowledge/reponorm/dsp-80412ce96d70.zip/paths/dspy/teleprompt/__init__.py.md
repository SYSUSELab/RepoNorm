# Rules for `dspy/teleprompt/__init__.py`

## Rule 110 — `dspy/teleprompt/__init__.py`

- **Rule:**
  ```text
  dspy/teleprompt/__init__.py must re-export optimizer classes and declare __all__; Teleprompter is imported but intentionally omitted from __all__, so it is not part of the advertised public teleprompt API.
  ```
- **Applies to:**
  - `dspy/teleprompt/__init__.py`
- **Condition:**
  ```text
  when modifying dspy/teleprompt/__init__.py exports or __all__
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-96d9765de049ccf36b8c9a16.md)
