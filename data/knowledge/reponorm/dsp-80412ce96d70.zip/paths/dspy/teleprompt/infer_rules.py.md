# Rules for `dspy/teleprompt/infer_rules.py`

## Rule 064 — `dspy/teleprompt/infer_rules.py`

- **Rule:**
  ```text
  InferRules/RulesInductionProgram must initialize self.rng = random.Random(0) to keep rule induction deterministic across runs, and must default teacher_settings to an empty dict when none is provided.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  When modifying InferRules/RulesInductionProgram initialization or its randomness/teacher_settings defaults.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5688d5c8fee147f97dd9920e.md)

## Rule 140 — `dspy/teleprompt/infer_rules.py`

- **Rule:**
  ```text
  get_predictor_demos must filter each trainset example down to keys present in the predictor signature's input or output fields, dropping extra example keys before demos are used.
  ```
- **Applies to:**
  - `dspy/teleprompt/infer_rules.py`
- **Condition:**
  ```text
  when modifying get_predictor_demos or the demo-key filtering behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b774a1ac60d762716d5a122f.md)
