# Rules for `dspy/teleprompt/signature_opt.py`

## Rule 073 — `dspy/teleprompt/signature_opt.py`

- **Rule:**
  ```text
  SignatureOptimizer.__init__ must print a red WARNING that it is deprecated and replaced by COPRO and will be removed in a future release, then delegate to the parent initializer with the same arguments.
  ```
- **Applies to:**
  - `dspy/teleprompt/signature_opt.py`
- **Condition:** When modifying SignatureOptimizer initialization or its deprecation messaging.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6e2b75193eb7908449f33894.md)
