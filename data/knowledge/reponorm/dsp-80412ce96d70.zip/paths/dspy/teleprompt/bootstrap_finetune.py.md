# Rules for `dspy/teleprompt/bootstrap_finetune.py`

## Rule 044 — `dspy/teleprompt/bootstrap_finetune.py`

- **Rule:**
  ```text
  build_call_data_from_trace must index the trace by pred_ind assuming order is preserved, and pass pred.signature plus demos (empty when exclude_demos) and the trace inputs/outputs to adapter.format_finetune_data.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  Modifying build_call_data_from_trace or finetune data formatting
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3cd4311e800408bb5bb72b0f.md)

## Rule 085 — `dspy/teleprompt/bootstrap_finetune.py`

- **Rule:**
  ```text
  When a wrapped program raises AdapterParseError, bootstrap_trace_data must locate the predictor whose signature matches the failed signature (raising ValueError if none found), compute a format_reward scaled between format_failure_score and failure_score by the ratio of present to expected output fields, and append a FailedPrediction to the trace.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When modifying bootstrap_trace_data failure handling for AdapterParseError.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-7d65e27a803679f63f004d41.md)

## Rule 104 — `dspy/teleprompt/bootstrap_finetune.py`

- **Rule:**
  ```text
  FailedPrediction must hold completion_text and an optional format_reward float defaulting to None, so failed finetuning predictions may lack a format reward.
  ```
- **Applies to:**
  - `dspy/teleprompt/bootstrap_finetune.py`
- **Condition:**
  ```text
  When changing the FailedPrediction record or its format_reward default.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8eb33a18e875ac4260443d39.md)
