# Rules for `dspy/__metadata__.py`

## Rule 050 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  Ruff excludes dspy/__metadata__.py and tests/reliability/*.py from its checks.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-40d9fedfc6a70a90e94f8edb.md)

## Rule 137 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  The build-and-publish-pypi job updates __name__ in ./dspy/__metadata__.py to dspy using sed against the #replace_package_name_marker.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b256bde779c0acd044497727.md)

## Rule 205 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  The build-and-publish-pypi job updates __version__ in ./dspy/__metadata__.py using sed against the #replace_package_version_marker.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f8d94d320181ab3e81e60caa.md)
