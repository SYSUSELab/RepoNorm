# Rules for `dspy/adapters/__init__.py`

## Rule 195 — `dspy/adapters/__init__.py`

- **Rule:**
  ```text
  dspy.adapters.__init__ must export a fixed __all__ including Adapter, ChatAdapter, Type, History, Image, Audio, Code, JSONAdapter, XMLAdapter, TwoStepAdapter, Tool, and ToolCalls, defining the public adapters API surface.
  ```
- **Applies to:**
  - `dspy/adapters/__init__.py`
- **Condition:**
  ```text
  when modifying dspy/adapters/__init__.py exports or __all__
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ed19a971f0980eb91c349d81.md)
