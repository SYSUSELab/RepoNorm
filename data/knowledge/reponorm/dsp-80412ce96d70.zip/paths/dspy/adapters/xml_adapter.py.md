# Rules for `dspy/adapters/xml_adapter.py`

## Rule 211 — `dspy/adapters/xml_adapter.py`

- **Rule:**
  ```text
  XMLAdapter._parse_field_value must wrap parse_value failures in AdapterParseError carrying adapter name, signature, LM response, and the failing field/value, so XML adapter parse errors surface structured diagnostic context.
  ```
- **Applies to:**
  - `dspy/adapters/xml_adapter.py`
- **Condition:**
  ```text
  when modifying XMLAdapter._parse_field_value or the structured parse-error context
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fc139a691af5f15db4a2d3e4.md)
