# Rules for `dspy/adapters/types/base_type.py`

## Rule 043 — `dspy/adapters/types/base_type.py`

- **Rule:** Type is the base class for DSPy custom types; subclasses must implement format returning a list of content-part dicts matching the OpenAI content field.
- **Applies to:**
  - `dspy/adapters/types/base_type.py`
- **Condition:** when adding or modifying a DSPy custom type subclass or the Type base class format contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3c2c88ef1626eef18d01be12.md)
