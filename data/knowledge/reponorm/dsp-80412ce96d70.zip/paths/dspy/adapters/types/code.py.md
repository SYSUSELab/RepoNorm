# Rules for `dspy/adapters/types/code.py`

## Rule 166 — `dspy/adapters/types/code.py`

- **Rule:**
  ```text
  Code.validate_input must accept an existing Code instance, a raw string wrapped as {'code': _filter_code(data)}, or a dict requiring a string 'code' key, raising ValueError for missing/non-string code or other types; all string inputs pass through _filter_code.
  ```
- **Applies to:**
  - `dspy/adapters/types/code.py`
- **Condition:** When changing Code input validation or the accepted input forms for the Code type.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-cc2a50856e7e77a0cd959ac7.md)
