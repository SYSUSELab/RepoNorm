# Rules for `dspy/propose/grounded_proposer.py`

## Rule 036 — `dspy/propose/grounded_proposer.py`

- **Rule:**
  ```text
  GenerateSingleModuleInstruction must conditionally include input fields based on flags: dataset_description when use_dataset_summary, program/module fields when program_aware, previous_instructions when use_instruct_history, and tip when use_tip, so the signature shape varies with configuration.
  ```
- **Applies to:**
  - `dspy/propose/grounded_proposer.py`
- **Condition:** when modifying GenerateSingleModuleInstruction or the flag-driven signature shape of instruction generation
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-311e7c52c92459ef842ab03e.md)
