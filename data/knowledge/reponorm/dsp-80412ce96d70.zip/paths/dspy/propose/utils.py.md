# Rules for `dspy/propose/utils.py`

## Rule 123 — `dspy/propose/utils.py`

- **Rule:**
  ```text
  propose/utils.py must import IPython's extract_symbols inside a try/except ImportError and set extract_symbols = None when unavailable, so notebook code extraction degrades gracefully without IPython installed.
  ```
- **Applies to:**
  - `dspy/propose/utils.py`
- **Condition:** Modifying notebook code extraction or IPython dependency handling in propose/utils.py
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a04483aed3527203cfd3ea06.md)
