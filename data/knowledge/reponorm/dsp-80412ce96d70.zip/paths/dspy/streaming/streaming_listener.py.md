# Rules for `dspy/streaming/streaming_listener.py`

## Rule 062 — `dspy/streaming/streaming_listener.py`

- **Rule:**
  ```text
  When allow_reuse is set, a completed stream must reset stream_end, cache_hit, field_start_queue, field_end_queue, and stream_start so the listener can be reused for a subsequent stream; otherwise receive returns early.
  ```
- **Applies to:**
  - `dspy/streaming/streaming_listener.py`
- **Condition:**
  ```text
  when modifying StreamListener.receive or the allow_reuse stream-reset behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-522896dd19291c5142b50c61.md)
