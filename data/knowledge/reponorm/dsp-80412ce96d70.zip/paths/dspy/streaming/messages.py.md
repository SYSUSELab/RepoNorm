# Rules for `dspy/streaming/messages.py`

## Rule 150 — `dspy/streaming/messages.py`

- **Rule:**
  ```text
  on_lm_end must return early when settings.send_stream is None and only emit a StatusMessage when the status message provider returns a non-empty message.
  ```
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:**
  ```text
  When modifying StatusStreamingCallback.on_lm_end or the status message emission path.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-be7dd451d83c67a8089b42d8.md)

## Rule 202 — `dspy/streaming/messages.py`

- **Rule:** StatusMessage must remain a dataclass wrapping a single message string for status streaming, defining the minimal payload shape for status stream events.
- **Applies to:**
  - `dspy/streaming/messages.py`
- **Condition:** when modifying StatusMessage or the status stream event payload shape
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f43b4027676823aed2fbc69e.md)
