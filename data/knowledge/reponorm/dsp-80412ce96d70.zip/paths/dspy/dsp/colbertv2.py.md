# Rules for `dspy/dsp/colbertv2.py`

## Rule 133 — `dspy/dsp/colbertv2.py`

- **Rule:**
  ```text
  ColBERTv2.__init__ must build self.url as '{url}:{port}' when a port is provided and otherwise use url unchanged, and store post_requests; this defines the endpoint URL construction contract.
  ```
- **Applies to:**
  - `dspy/dsp/colbertv2.py`
- **Condition:**
  ```text
  when modifying ColBERTv2.__init__ or its endpoint URL construction
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ae12afed7f632acf87458f6d.md)
