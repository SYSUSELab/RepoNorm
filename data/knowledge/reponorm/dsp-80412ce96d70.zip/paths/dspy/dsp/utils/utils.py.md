# Rules for `dspy/dsp/utils/utils.py`

## Rule 194 — `dspy/dsp/utils/utils.py`

- **Rule:**
  ```text
  flatten must concatenate child lists via result += child_list, meaning it only works for list-of-lists and will extend with any iterable rather than recursively flattening nested structures.
  ```
- **Applies to:**
  - `dspy/dsp/utils/utils.py`
- **Condition:** When modifying flatten or relying on it for nested-structure flattening.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ece1cf49325a297e47f8220e.md)
