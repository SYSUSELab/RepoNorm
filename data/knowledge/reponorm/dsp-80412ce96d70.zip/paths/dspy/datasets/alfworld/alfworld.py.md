# Rules for `dspy/datasets/alfworld/alfworld.py`

## Rule 196 — `dspy/datasets/alfworld/alfworld.py`

- **Rule:** The alfworld init helper must communicate with a worker process by putting an ("init", idx) message on inq and blocking on outq.get(), so callers must have a corresponding worker consuming the queue.
- **Applies to:**
  - `dspy/datasets/alfworld/alfworld.py`
- **Condition:** When changing the alfworld environment session init helper or its worker-process IPC contract.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ed63f327024d1b7c2cbdaae7.md)
