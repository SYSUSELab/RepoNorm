# Rules for `dspy/datasets/colors.py`

## Rule 051 — `dspy/datasets/colors.py`

- **Rule:** Colors must split sorted colors 60/40 into train/dev and shuffle both with random.Random(0) so the split is deterministic and avoids similar-color overlap between train and dev.
- **Applies to:**
  - `dspy/datasets/colors.py`
- **Condition:** When changing the Colors dataset split logic or its shuffling seed.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-41938ad972dbbd663dec7f2e.md)
