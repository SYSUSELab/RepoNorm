# Rules for `dspy/datasets/dataset.py`

## Rule 124 — `dspy/datasets/dataset.py`

- **Rule:**
  ```text
  Dataset._shuffle_and_sample must shuffle with a seeded RNG regardless of requested size, truncate to size, and stamp each returned Example with a fresh dspy_uuid and dspy_split; dedup/group_uuid semantics remain unimplemented.
  ```
- **Applies to:**
  - `dspy/datasets/dataset.py`
- **Condition:**
  ```text
  when modifying Dataset._shuffle_and_sample or the sampling path it feeds
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a199f6077349fb62ff9b2617.md)
