# Rules for `dspy/datasets/math.py`

## Rule 173 — `dspy/datasets/math.py`

- **Rule:** dspy/datasets/math.py must define the MATH dataset class as the entry point for the MATH dataset loader.
- **Applies to:**
  - `dspy/datasets/math.py`
- **Condition:** When changing the MATH dataset loader entry point in dspy/datasets/math.py.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d34c15a79a0058efa1249bb6.md)
