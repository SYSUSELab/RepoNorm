# Rules for `dspy/utils/unbatchify.py`

## Rule 174 — `dspy/utils/unbatchify.py`

- **Rule:**
  ```text
  Unbatchify.close must be idempotent: it only sets stop_event and joins the worker thread when stop_event is not already set, so repeated close calls do not re-join.
  ```
- **Applies to:**
  - `dspy/utils/unbatchify.py`
- **Condition:** When modifying Unbatchify.close or its worker-thread shutdown logic.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d6b8d3e5d822740bedf50cf7.md)
