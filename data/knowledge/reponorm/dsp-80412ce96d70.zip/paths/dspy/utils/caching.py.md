# Rules for `dspy/utils/caching.py`

## Rule 004 — `dspy/utils/caching.py`

- **Rule:**
  ```text
  The cache directory must default to ~/.dspy_cache but be overridden by the DSPY_CACHEDIR environment variable when set, establishing environment-variable precedence for cache location.
  ```
- **Applies to:**
  - `dspy/utils/caching.py`
- **Condition:** When changing cache directory resolution or environment-variable handling in caching.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0457148080da36225b4c8a2a.md)
