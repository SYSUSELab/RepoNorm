# Rules for `repository root`

## Rule 031 — `**/*.py`

- **Rule:** Ruff linting ignores rules B027, FBT003, C901, E501, UP035, RUF005, B904, F403, E721, UP031, and RUF022.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-249c73f85684fc6b5c08fd26.md)

## Rule 040 — `**/*.py`

- **Rule:** Ruff's flake8-tidy-imports rule bans all relative imports.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-34a43db1457fc3d0ed2894bc.md)

## Rule 047 — `**/__init__.py`

- **Rule:**
  ```text
  Ruff per-file ignores for __init__.py disable F401, allowing unused imports in init files.
  ```
- **Applies to:**
  - `**/__init__.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-3e6170597c2b4cb39f82c997.md)

## Rule 079 — `**/*.py`

- **Rule:** Python 3.10 or later is required for the DSPy development environment.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-73c4dcac80f316d5e69ade2d.md)

## Rule 101 — `**/*.py`

- **Rule:**
  ```text
  The project requires Python >=3.10, <3.14.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-89704dbe5bc998a372e64623.md)

## Rule 111 — `**/*.py`

- **Rule:**
  ```text
  Ruff's isort lint rule treats the `dspy` package as first-party when classifying imports.
  ```
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-97d7b4213037c5096237b9ff.md)

## Rule 129 — `**`

- **Rule:** The hooks can also be run manually, including a mode that checks staged files only.
- **Applies to:**
  - `**`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-a7a364e6bac1e834c56be323.md)

## Rule 135 — `**/*.py`

- **Rule:** No Ruff rules are marked unfixable.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-b0a1c8571b4ed8d41f2424e1.md)

## Rule 136 — `**`

- **Rule:** Contributors are recommended to open an issue (if one doesn't already exist) and discuss proposed changes before making any changes.
- **Applies to:**
  - `**`
- **Normative strength:** `recommended`
- **Detail:** [Open claim details](../claims/CLAIM-b2062b6757d226c4bffb320c.md)

## Rule 156 — `**/*.py`

- **Rule:** Ruff linting enables the rule sets E, W, F, I, C, B, UP, N, RUF, and Q.
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `required`
- **Detail:** [Open claim details](../claims/CLAIM-c17683e6a727a1c167a69951.md)

## Rule 187 — `**/*.py`

- **Rule:** Ruff format indents with spaces (indent-style = "space").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-e5aeacedf4dd9f6fa2ecb747.md)

## Rule 190 — `**/*.py`

- **Rule:** Ruff format uses double quotes for string literals (quote-style = "double").
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-eaa4f89283d3668733306ba5.md)

## Rule 199 — `**/*.py`

- **Rule:** Ruff format does not format code inside docstrings (docstring-code-format = false).
- **Applies to:**
  - `**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f0ce3d7cb437901fcb0b0e3a.md)
