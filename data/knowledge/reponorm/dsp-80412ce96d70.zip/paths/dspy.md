# Rules for `dspy`

## Rule 127 — `dspy/**`

- **Rule:**
  ```text
  Package discovery includes only the dspy and dspy.* packages.
  ```
- **Applies to:**
  - `dspy/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-a3f49fc8040a6325410e23b9.md)

## Rule 161 — `dspy/**/*.py`

- **Rule:**
  ```text
  Ruff linting/formatting applies to Python files under dspy/ and tests/ as configured by include = ["dspy/**/*.py", "tests/**/*.py"].
  ```
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c96220426b095b5c3f51a757.md)
