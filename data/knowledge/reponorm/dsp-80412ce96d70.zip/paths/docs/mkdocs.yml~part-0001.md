# Rules for `docs/mkdocs.yml`

## Rule 001 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler shows docstring parameters.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-014168498c96f7385d860696.md)

## Rule 002 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/BootstrapFinetune.md to api/optimizers/BootstrapFinetune.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-035f663eb3736a40cac4210c.md)

## Rule 008 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler disables separate signatures.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-06d524fd9911037a94b2362b.md)

## Rule 009 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The mkdocstrings Python handler merges __init__ into the class.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-08a8196bc5f60480e4785fc9.md)

## Rule 011 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler shows the root heading.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0a3b74c11bacc0e62d76eadd.md)

## Rule 014 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site defines a default palette scheme with white primary and black accent.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0e25792068e846f773a55b85.md)

## Rule 015 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site enables the search plugin with language en.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0f94c3701e5592c1679695f1.md)

## Rule 025 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler shows signature annotations.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1fd79fdcbbec67dfb7d1105c.md)

## Rule 028 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler uses the table docstring section style.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-21f120a0615458a1dbd6ad5f.md)

## Rule 033 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/Ensemble.md to api/optimizers/Ensemble.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-26f0e02b92c2331bc7c056f3.md)

## Rule 037 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps docs/quick-start/getting-started-02.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-31e856d90566018c6a54f99a.md)

## Rule 048 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site defines a slate palette scheme with black primary and lime accent.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3e656ad07c68974a66eb3010.md)

## Rule 055 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/bootstrap-fewshot.md to api/optimizers/BootstrapFewShot.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-48db0a12edbb4dd32a8929d7.md)

## Rule 058 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site loads the extra JavaScript file js/runllm-widget.js.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-4f9302a0096b617365b55012.md)

## Rule 061 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps intro/index.md to index.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-51f254b67b652d7b3d256590.md)

## Rule 068 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/miprov2.md to api/optimizers/MIPROv2.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-629d7529fb310efbe9c54ee6.md)

## Rule 080 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.emoji extension using the twemoji index and to_svg generator from material.extensions.emoji.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-73e838b0a08a2ebf4700142b.md)

## Rule 083 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps docs/quick-start/getting-started-01.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-787b99d45f77c42acf42de62.md)

## Rule 089 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The MkDocs search plugin uses the separator regex '[\s\-\.]+'.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-8066d5d9599b06cbf697a797.md)

## Rule 099 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site enables the pymdownx.arithmatex extension with generic true.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-88a8b6feca94ea8dad06a884.md)

## Rule 109 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler sets the annotations path to brief.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-956d6b12e22bc563da4054ea.md)

## Rule 116 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler enables symbol type headings.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9974268504775de6df4988a4.md)

## Rule 128 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site favicon is static/img/logo.png.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a49b27d67694be8cf911d337.md)

## Rule 142 — `docs/mkdocs.yml`

- **Rule:** The MkDocs site loads the extra stylesheet stylesheets/extra.css.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b8bab0c9293f57aa5bf60b5e.md)

## Rule 144 — `docs/mkdocs.yml`

- **Rule:** The mkdocs-jupyter plugin ignores H1 titles.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bb97bca8c1be1260536e6dce.md)

## Rule 145 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps quick-start/getting-started-02.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bb9b38d920b3561b05b0cee3.md)

## Rule 152 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps intro.md to index.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bf32065d63a29068481782ca.md)

## Rule 153 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler unwraps Annotated types.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-bfa911e4a55dd0f1032ab8c0.md)
