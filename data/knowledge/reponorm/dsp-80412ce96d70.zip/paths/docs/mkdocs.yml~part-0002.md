# Rules for `docs/mkdocs.yml`

## Rule 157 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler sets heading level 3.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c420d25dc8681e26f1c53509.md)

## Rule 158 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler uses Google docstring style.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c77ccb01b8c7d67b9acf25ad.md)

## Rule 160 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler enables category headings.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c8e3d601d839d34c2fb82d4b.md)

## Rule 163 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings rendering options disable warnings.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c9e6eb9012b863f8c4944f93.md)

## Rule 165 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/copro.md to api/optimizers/COPRO.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cbf511094cf52977e20d34fa.md)

## Rule 171 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler shows source.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cf69b7791fa93da8f0a0a189.md)

## Rule 183 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps quick-start/getting-started-01.md to tutorials/rag/index.ipynb.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-dff9e211f6a4f46efb50a893.md)

## Rule 184 — `docs/mkdocs.yml`

- **Rule:** The mkdocstrings Python handler orders members by source.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e05cd19dd3cb563a6f1b18ed.md)

## Rule 185 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.highlight extension with anchor_linenums true.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e1ee6b01022fe9924f613317.md)

## Rule 188 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/LabeledFewShot.md to api/optimizers/LabeledFewShot.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e610178ecd5da7704c73de04.md)

## Rule 189 — `docs/mkdocs.yml`

- **Rule:**
  ```text
  The MkDocs site enables the pymdownx.tabbed extension with alternate_style true.
  ```
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e77cd4281d6bde3e0af17922.md)

## Rule 207 — `docs/mkdocs.yml`

- **Rule:** The redirects plugin maps deep-dive/optimizers/bfrs.md to api/optimizers/BootstrapFewShotWithRandomSearch.md.
- **Applies to:**
  - `docs/mkdocs.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-fb43601d97f77db3593a319d.md)
