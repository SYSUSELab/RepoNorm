# Rules for `tests/clients/test_cache.py`

## Rule 091 — `tests/clients/test_cache.py`

- **Rule:**
  ```text
  When a test resets the memory cache, reset_memory_cache() must empty only the in-memory cache while previously stored requests remain retrievable from the disk cache.
  ```
- **Applies to:**
  - `tests/clients/test_cache.py`
- **Condition:**
  ```text
  Modifying reset_memory_cache or cache reset behavior such that persisted disk entries could be cleared or memory entries retained.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-81f57f0c528d0cd6f7ea6051.md)
