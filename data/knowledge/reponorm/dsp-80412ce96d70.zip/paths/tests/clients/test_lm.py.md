# Rules for `tests/clients/test_lm.py`

## Rule 017 — `tests/clients/test_lm.py`

- **Rule:**
  ```text
  LM.dump_state must return a dict containing model, model_type, temperature, max_tokens, num_retries, cache, cache_in_memory, finetuning_model, launch_kwargs, and train_kwargs, with cache defaulting to True and finetuning_model to None.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:**
  ```text
  when modifying or extending LM.dump_state serialization assertions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1219683de14c962454e24638.md)

## Rule 032 — `tests/clients/test_lm.py`

- **Rule:**
  ```text
  When a test asserts that dspy.LM forwards model, api_base, api_key, and azure_ad_token_provider to litellm.completion, a callable azure_ad_token_provider must be passed through to the underlying completion call.
  ```
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:**
  ```text
  Modifying dspy.LM parameter forwarding to litellm.completion, especially callable parameters such as azure_ad_token_provider.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-26caf5210c689431dac3fde6.md)

## Rule 131 — `tests/clients/test_lm.py`

- **Rule:** dspy.LM.acall with cache disabled must return the mocked completion content as a list and invoke litellm.acompletion exactly once.
- **Applies to:**
  - `tests/clients/test_lm.py`
- **Condition:** When modifying dspy.LM.acall or its interaction with litellm.acompletion under disabled cache.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-aaeeb7296c11c006a0eb8490.md)
