# Rules for `tests/reliability/test_pydantic_models.py`

## Rule 059 — `tests/reliability/test_pydantic_models.py`

- **Rule:**
  ```text
  test_tool_calling_with_literals must parametrize over dspy.Predict and dspy.ChainOfThought and assert the predicted next_tool_name is one of a fixed set of valid tool names, checking literal-constrained tool selection.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  when modifying test_tool_calling_with_literals or the literal-constrained tool selection assertions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-512c146b1df56ae5be0d2182.md)

## Rule 090 — `tests/reliability/test_pydantic_models.py`

- **Rule:**
  ```text
  test_qa_with_pydantic_answer_model must assert that a dspy.Predict(QA) answer exposes .value, .comments, and .certainty, with certainty in [0, 1] and at least 2 comments, and must use assert_program_output_correct with grading guidelines for both value and comments.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:**
  ```text
  when modifying test_qa_with_pydantic_answer_model or the pydantic answer model assertions
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8180e43ea2b5de921842986e.md)

## Rule 097 — `tests/reliability/test_pydantic_models.py`

- **Rule:**
  ```text
  Reliability tests for multi-output signatures must assert each output field separately via assert_program_output_correct with field-specific grading guidelines, including a '|'-separated categories convention.
  ```
- **Applies to:**
  - `tests/reliability/test_pydantic_models.py`
- **Condition:** when modifying reliability tests for multi-output signatures or their grading assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-86bbd1f356058838deeec9f2.md)
