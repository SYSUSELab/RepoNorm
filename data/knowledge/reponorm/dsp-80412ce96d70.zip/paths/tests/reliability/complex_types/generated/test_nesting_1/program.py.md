# Rules for `tests/reliability/complex_types/generated/test_nesting_1/program.py`

## Rule 023 — `tests/reliability/complex_types/generated/test_many_types_1/program.py`

- **Rule:** A program signature can be built dynamically by iterating pydantic model fields and appending dspy.InputField/OutputField with the field's annotation and description to a BaseSignature.
- **Applies to:**
  - `tests/reliability/complex_types/generated/test_many_types_1/program.py`
  - `tests/reliability/complex_types/generated/test_nesting_1/program.py`
- **Condition:** When modifying generated reliability test programs that construct signatures from pydantic model fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../../../claims/CLAIM-1bcab8bcbf42e0902b6daf8c.md)
