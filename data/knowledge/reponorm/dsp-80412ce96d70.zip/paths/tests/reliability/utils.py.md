# Rules for `tests/reliability/utils.py`

## Rule 046 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  The reliability test helper _get_judge_program must return dspy.Predict(JudgeSignature); do not construct judge programs with a different module or signature.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  when modifying _get_judge_program or how judge programs are constructed in reliability tests
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-3da6ec45ed4bd5f645d51fd8.md)

## Rule 066 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  parse_reliability_conf_yaml must remain lru_cache'd, require each model_list entry to have a model_name (raising ValueError otherwise), only record entries that have litellm_params, require a top-level adapter key, and wrap any failure in a ValueError naming the conf file.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  when modifying parse_reliability_conf_yaml or the reliability conf schema it validates
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5750a4716c87417d45db2223.md)

## Rule 094 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  Reliability judge configuration must load reliability_conf.yaml from the module directory, require a LiteLLM config for JUDGE_MODEL_NAME or raise ValueError, and temporarily set dspy.settings.context with the judge LM and adapter.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:** When modifying reliability judge configuration loading or the dspy.settings.context setup used by reliability tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-850a9640005803fdcaa607ad.md)

## Rule 154 — `tests/reliability/utils.py`

- **Rule:**
  ```text
  The reliability known_failing_models decorator must attach a _known_failing_models attribute to the wrapped test function; do not change the attribute name or attachment mechanism.
  ```
- **Applies to:**
  - `tests/reliability/utils.py`
- **Condition:**
  ```text
  when modifying the known_failing_models decorator or how tests are marked as known-failing for specific models
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c0c6536c58a432a1c6675648.md)
