# Rules for `tests/reliability/generate/utils.py`

## Rule 054 — `tests/reliability/generate/utils.py`

- **Rule:** The assertion-generation signature must instruct the model to produce natural-language assertions, ideally about 5, and to leave them blank when accurate assertions are too difficult.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when modifying the assertion-generation signature or its output contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-48281badb30b0fb0fadda955.md)

## Rule 113 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  expand_refs in the reliability generate utils must inline JSON-schema $ref definitions and preserve the DSPy-specific __dspy_field_type marker when a $ref node also carries it, so generated models retain DSPy field typing after ref expansion.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** When modifying JSON-schema ref expansion in the reliability generate utils, particularly handling of $ref nodes that also carry DSPy field-type markers.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-983b3145d85c65128a003aa8.md)

## Rule 117 — `tests/reliability/generate/utils.py`

- **Rule:** Parameterized test decorators in tests/reliability/generate/utils.py must be implemented as decorator factories whose inner decorator returns a wrapper; do not implement them as single-level decorators.
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:** when adding or modifying a parameterized test decorator in the reliability generate utils
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-99fbfa0bb4d2f06c2fff9809.md)

## Rule 125 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  generate_models must configure datamodel-code-generator with enum_field_as_literal='one', field_constraints=True, use_annotated=False, then strip 'from __future__ import annotations' and generated comments to keep generated pydantic models compatible with built-in type hints.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying generate_models or the generated pydantic model compatibility settings
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a2f899ac33bc39c6f4c32c12.md)

## Rule 134 — `tests/reliability/generate/utils.py`

- **Rule:**
  ```text
  Generated reliability case execution must load the generated program, convert the JSON input to program input, run the program, and assert each output assertion via assert_program_output_correct with grading guidelines.
  ```
- **Applies to:**
  - `tests/reliability/generate/utils.py`
- **Condition:**
  ```text
  when modifying run_generated_case or the generated reliability case execution path
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-af2664ce0527a2ad6a4c0923.md)
