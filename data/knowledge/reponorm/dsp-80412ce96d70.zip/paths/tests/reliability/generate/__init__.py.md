# Rules for `tests/reliability/generate/__init__.py`

## Rule 088 — `tests/reliability/generate/__init__.py`

- **Rule:**
  ```text
  Reliability test generation must reuse an existing generated program when the destination directory already contains one, and must always generate inputs under dst_path/inputs before returning loaded generated cases.
  ```
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:**
  ```text
  when modifying generate_test_cases or the reliability test-generation entry point
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-8045551fd72a73a2f1669ea8.md)

## Rule 126 — `tests/reliability/generate/__init__.py`

- **Rule:**
  ```text
  The reliability generate package must re-export GeneratedTestCase, generate_test_inputs, generate_test_program, load_generated_cases, and load_generated_program from its utils module, defining the package's public surface.
  ```
- **Applies to:**
  - `tests/reliability/generate/__init__.py`
- **Condition:** When modifying the reliability generate package's public exports or adding/removing symbols from its utils module.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-a364759f45f2957b48d3749f.md)
