# Rules for `tests/primitives/test_python_interpreter.py`

## Rule 065 — `tests/primitives/test_python_interpreter.py`

- **Rule:**
  ```text
  PythonInterpreter read-path sandbox tests must verify that enable_read_paths exposes files at /sandbox/<name> and that enable_read_paths=None denies access with a permission or no-such-file error.
  ```
- **Applies to:**
  - `tests/primitives/test_python_interpreter.py`
- **Condition:** when modifying or extending PythonInterpreter read-path sandbox tests
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-56f7e4dceca6fb44415c55fc.md)
