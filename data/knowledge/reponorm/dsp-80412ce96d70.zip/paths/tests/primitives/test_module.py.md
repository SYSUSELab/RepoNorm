# Rules for `tests/primitives/test_module.py`

## Rule 118 — `tests/primitives/test_module.py`

- **Rule:**
  ```text
  Tests that exercise Module traversal must assert that named_sub_modules traverses nested lists, dicts, and tuples and includes the same module instance multiple times, while named_parameters does not allow recursive structures.
  ```
- **Applies to:**
  - `tests/primitives/test_module.py`
- **Condition:** When adding or modifying tests for Module traversal of nested containers or repeated module instances.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9c0a574774eb234704c2d088.md)
