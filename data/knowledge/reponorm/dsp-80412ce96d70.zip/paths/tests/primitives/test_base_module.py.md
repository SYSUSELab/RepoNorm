# Rules for `tests/primitives/test_base_module.py`

## Rule 148 — `tests/primitives/test_base_module.py`

- **Rule:**
  ```text
  Tests that exercise Module.deepcopy must assert that parameter count is preserved, locks are shallow-copied (same lock object identity), and parameter objects are deep-copied so parameter ids differ while __dict__ values match.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When adding or modifying tests for Module.deepcopy of nested modules or parameters.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bc8ebd6947353f0560e54f3d.md)

## Rule 179 — `tests/primitives/test_base_module.py`

- **Rule:**
  ```text
  Tests that exercise usage tracking under concurrent async calls must assert that each call under a shared settings context with track_usage=True receives independent per-LM usage records keyed by model name, with prompt/completion/total token counts matching the mocked response.
  ```
- **Applies to:**
  - `tests/primitives/test_base_module.py`
- **Condition:** When adding or modifying tests for usage tracking under concurrent async LM calls.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d92939f52c860c02d520f1f0.md)
