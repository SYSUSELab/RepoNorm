# Rules for `tests/teleprompt/test_bootstrap.py`

## Rule 213 — `tests/teleprompt/test_bootstrap.py`

- **Rule:** After BootstrapFewShot.compile, the compiled student's predictor demos must be at least as numerous as the validation set.
- **Applies to:**
  - `tests/teleprompt/test_bootstrap.py`
- **Condition:** When modifying BootstrapFewShot.compile or how validation examples are incorporated into predictor demos.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fe84a253af824e3541023059.md)
