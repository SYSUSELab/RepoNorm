# Rules for `tests/teleprompt/test_copro_optimizer.py`

## Rule 159 — `tests/teleprompt/test_copro_optimizer.py`

- **Rule:**
  ```text
  When a test enables COPRO.track_stats, the compiled student must expose total_calls > 0 plus results_best and results_latest entries.
  ```
- **Applies to:**
  - `tests/teleprompt/test_copro_optimizer.py`
- **Condition:**
  ```text
  Modifying COPRO statistics tracking or compiled student statistics exposure when track_stats is enabled.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c7c8900809a9e6a0241f2a5d.md)
