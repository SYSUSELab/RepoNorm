# Rules for `tests/teleprompt/test_random_search.py`

## Rule 209 — `tests/teleprompt/test_random_search.py`

- **Rule:** Tests that exercise the random search optimizer must import BootstrapFewShotWithRandomSearch from dspy.teleprompt and DummyLM from dspy.utils.dummies as the tested optimizer and dummy LM dependency.
- **Applies to:**
  - `tests/teleprompt/test_random_search.py`
- **Condition:** When adding or modifying tests for the random search optimizer.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fb7f3e543211c9d19e3849e6.md)
