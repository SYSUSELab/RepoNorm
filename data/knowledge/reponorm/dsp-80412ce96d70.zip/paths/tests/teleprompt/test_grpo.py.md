# Rules for `tests/teleprompt/test_grpo.py`

## Rule 146 — `tests/teleprompt/test_grpo.py`

- **Rule:**
  ```text
  GRPO dataset shuffling must return samples of size num_dspy_examples_per_grpo_step whose elements are exactly the dataset set, and repeated calls must keep returning full-size samples from the same dataset.
  ```
- **Applies to:**
  - `tests/teleprompt/test_grpo.py`
- **Condition:** when modifying GRPO dataset shuffling, sample size, or repeated-call behavior
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bc0ffc4c1aad816b0c283416.md)

## Rule 176 — `tests/teleprompt/test_grpo.py`

- **Rule:**
  ```text
  When num_dspy_examples_per_grpo_step exceeds dataset size, each select_training_sample_and_update_shuffled_trainset call must still return that many items, and over repeated calls every dataset element must appear equally often.
  ```
- **Applies to:**
  - `tests/teleprompt/test_grpo.py`
- **Condition:** When modifying the GRPO dataset shuffler or its oversampling behavior when the per-step count exceeds dataset size.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d8091c9d2d89fc6c8a14b05f.md)
