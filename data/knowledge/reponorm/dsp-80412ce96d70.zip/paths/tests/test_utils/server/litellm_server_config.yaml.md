# Rules for `tests/test_utils/server/litellm_server_config.yaml`

## Rule 078 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config sets num_retries to 0.
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-72df345dd65cfc39a7eaba9e.md)

## Rule 193 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-ec5961331f0d9210e53cc277.md)

## Rule 210 — `tests/test_utils/server/litellm_server_config.yaml`

- **Rule:**
  ```text
  The litellm test server config defines a model entry named "dspy-test-model-2" whose litellm_params model is "dspy-test-provider/dspy-test-model".
  ```
- **Applies to:**
  - `tests/test_utils/server/litellm_server_config.yaml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-fb9716ac19cc6ef68638536e.md)
