# Rules for `tests/test_utils/server/__init__.py`

## Rule 121 — `tests/test_utils/server/__init__.py`

- **Rule:**
  ```text
  The test server package must expose LITELLM_TEST_SERVER_LOG_FILE_PATH_ENV_VAR from tests.test_utils.server.litellm_server so tests can read the log-file path via an environment variable.
  ```
- **Applies to:**
  - `tests/test_utils/server/__init__.py`
- **Condition:** when modifying the test server package exports or the log-file path environment variable
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-9d0cf9582cfd2fa4ab6139f3.md)
