# Rules for `tests/test_utils/server/litellm_server.py`

## Rule 035 — `tests/test_utils/server/litellm_server.py`

- **Rule:** The litellm test server must map substrings in the first message content to specific litellm exceptions: '429' to RateLimitError, '504' to Timeout, '400' to BadRequestError, and '401' to AuthenticationError.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** when modifying the litellm test server's exception injection or message-content mapping
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-306065c671f3389b4b349e2f.md)

## Rule 151 — `tests/test_utils/server/litellm_server.py`

- **Rule:** The litellm test server module must define DSPyTestModel as a subclass of CustomLLM to provide a custom LLM implementation for server-based tests.
- **Applies to:**
  - `tests/test_utils/server/litellm_server.py`
- **Condition:** When modifying the litellm test server module or adding custom LLM implementations for server-based tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-beb12f85e281365ce86db4fb.md)
