# Rules for `tests/predict`

## Rule 052 — `tests/metadata/test_metadata.py`

- **Rule:**
  ```text
  The build-and-publish-test-pypi job installs the locally built wheel plus pytest and pytest-asyncio, then runs pytest on tests/metadata/test_metadata.py and tests/predict.
  ```
- **Applies to:**
  - `tests/metadata/test_metadata.py`
  - `tests/predict/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-469ed003b54af3d4e8575a41.md)

## Rule 192 — `tests/metadata/test_metadata.py`

- **Rule:**
  ```text
  Before publishing to PyPI, the workflow creates a virtual environment named test_before_pypi, installs the locally built wheel with pytest and pytest-asyncio, and runs `pytest tests/metadata/test_metadata.py tests/predict`.
  ```
- **Applies to:**
  - `tests/metadata/test_metadata.py`
  - `tests/predict/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-eb7e57457380ae572b408bc9.md)
