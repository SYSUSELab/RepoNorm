# Rules for `tests/reliability`

## Rule 050 — `dspy/__metadata__.py`

- **Rule:**
  ```text
  Ruff excludes dspy/__metadata__.py and tests/reliability/*.py from its checks.
  ```
- **Applies to:**
  - `dspy/__metadata__.py`
  - `tests/reliability/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-40d9fedfc6a70a90e94f8edb.md)
