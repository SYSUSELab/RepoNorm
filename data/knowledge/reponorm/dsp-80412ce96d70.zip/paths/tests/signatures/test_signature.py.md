# Rules for `tests/signatures/test_signature.py`

## Rule 056 — `tests/signatures/test_signature.py`

- **Rule:** When a test constructs a Predict from a signature with multiline instructions, the Predict must still return the LM output field value, so multiline instruction text must be accepted without breaking prediction.
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** Modifying instruction handling or signature parsing such that multiline instruction text could break Predict execution.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4aac58e1e8a15154b3f31f41.md)

## Rule 177 — `tests/signatures/test_signature.py`

- **Rule:**
  ```text
  Tests that exercise Signature type parsing must assert that nested generic annotations and PEP 604 unions are preserved through parsing, including dict/list/Union/tuple origins and their args, and must use a pydantic BaseModel custom type resolved via the custom_types mapping.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** When adding or modifying tests for Signature annotation parsing, custom types, or PEP 604 unions.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d8bc9914169445f12103b07f.md)

## Rule 208 — `tests/signatures/test_signature.py`

- **Rule:**
  ```text
  Signature field constraints must be exposed through output_fields json_schema_extra, and tests must assert minimum/maximum length and greater/less-than-or-equal bounds on those fields.
  ```
- **Applies to:**
  - `tests/signatures/test_signature.py`
- **Condition:** when adding or modifying signature field constraint assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fb5794fad33aa669c1a35a44.md)
