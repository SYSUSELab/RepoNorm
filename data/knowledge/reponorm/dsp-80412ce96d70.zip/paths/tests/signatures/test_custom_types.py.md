# Rules for `tests/signatures/test_custom_types.py`

## Rule 200 — `tests/signatures/test_custom_types.py`

- **Rule:** When a test resolves signature string annotations, local, module-level, and nested (dot-notation) custom types must resolve, and an alias assigned to a nested type must resolve to the underlying nested class.
- **Applies to:**
  - `tests/signatures/test_custom_types.py`
- **Condition:** Modifying signature string annotation resolution for local, module-level, nested, or aliased custom types.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f1834309fa5bc1dfe85174a6.md)
