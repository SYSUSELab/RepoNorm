# Rules for `tests/conftest.py`

## Rule 077 — `tests/conftest.py`

- **Rule:**
  ```text
  Tests gated behind opt-in pytest flags must be registered in SKIP_DEFAULT_FLAGS and skipped by pytest_collection_modifyitems unless the matching --flag option is supplied; new opt-in test categories must add both the flag registration and the skip mapping rather than relying on markers alone.
  ```
- **Applies to:**
  - `tests/conftest.py`
- **Condition:**
  ```text
  When adding or modifying tests that should only run under an explicit CLI flag, or when changing the SKIP_DEFAULT_FLAGS mapping or pytest_addoption registrations.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-713cbcb93e745ed801aa87a5.md)
