# Rules for `tests/adapters/test_json_adapter.py`

## Rule 167 — `tests/adapters/test_json_adapter.py`

- **Rule:**
  ```text
  Tests that exercise JSON adapter image formatting must assert that formatting a signature with two image demos and one image input yields exactly 6 messages, with image_url content dicts at messages[1], [3], and [5], fixing the few-shot image message layout.
  ```
- **Applies to:**
  - `tests/adapters/test_json_adapter.py`
- **Condition:** When adding or modifying tests for JSON adapter formatting of image demos or image inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cc951da352c5939034c971d6.md)
