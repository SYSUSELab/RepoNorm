# Rules for `tests/adapters/test_tool.py`

## Rule 016 — `tests/adapters/test_tool.py`

- **Rule:**
  ```text
  Calling an async Tool in sync mode must raise ValueError unless dspy.context(allow_tool_async_sync_conversion=True) is set, in which case the awaited result is returned.
  ```
- **Applies to:**
  - `tests/adapters/test_tool.py`
- **Condition:**
  ```text
  When modifying async Tool invocation in sync mode or the allow_tool_async_sync_conversion context flag.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-0fea955e7c0355eca53a6985.md)
