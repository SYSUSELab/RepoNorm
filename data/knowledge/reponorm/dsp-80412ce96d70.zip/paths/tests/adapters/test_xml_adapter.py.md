# Rules for `tests/adapters/test_xml_adapter.py`

## Rule 057 — `tests/adapters/test_xml_adapter.py`

- **Rule:**
  ```text
  When a test formats a signature with nested ImageWrapper demos, XMLAdapter.format must produce four messages, place each demo image as an image_url content entry in the few-shot user message, and place the query image in the last user message.
  ```
- **Applies to:**
  - `tests/adapters/test_xml_adapter.py`
- **Condition:** Modifying XMLAdapter.format handling of nested image models in demos or query inputs.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-4eb16762c5d1d0a7cc43021c.md)

## Rule 108 — `tests/adapters/test_xml_adapter.py`

- **Rule:**
  ```text
  Adapter parse failures for missing required signature fields must raise AdapterParseError carrying adapter_name, signature, lm_response, and a message naming the missing field.
  ```
- **Applies to:**
  - `tests/adapters/test_xml_adapter.py`
- **Condition:** When modifying XML adapter parsing or its error handling for completions missing a required field.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-94e36327c050f8e0d0fb901a.md)
