# Rules for `tests/adapters/test_chat_adapter.py`

## Rule 084 — `tests/adapters/test_chat_adapter.py`

- **Rule:**
  ```text
  When a test formats a signature with few-shot image examples and an input image, the adapter must produce exactly 6 messages (1 system, 2 user/assistant pairs, 1 user), with completed markers in assistant messages and image_url content blocks in user messages.
  ```
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** Modifying ChatAdapter message construction for signatures containing few-shot image examples and an input image.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-78fbc8ac15d1a90509ec8684.md)

## Rule 107 — `tests/adapters/test_chat_adapter.py`

- **Rule:** Adapter tests that assert literal quoting must cover both single- and double-quote scenarios, including the case where both quote types appear in one value and escaping is required.
- **Applies to:**
  - `tests/adapters/test_chat_adapter.py`
- **Condition:** when modifying or extending ChatAdapter literal-quoting assertions
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9337ba0e576b6be2c2d9f049.md)
