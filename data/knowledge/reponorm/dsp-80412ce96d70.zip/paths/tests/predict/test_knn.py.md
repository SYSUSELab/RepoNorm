# Rules for `tests/predict/test_knn.py`

## Rule 049 — `tests/predict/test_knn.py`

- **Rule:** KNN query must return the configured number of nearest samples ordered with the closest match first.
- **Applies to:**
  - `tests/predict/test_knn.py`
- **Condition:** when modifying KNN query behavior, sample count, or ordering logic
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-406f446b3dba93c53e169f0f.md)
