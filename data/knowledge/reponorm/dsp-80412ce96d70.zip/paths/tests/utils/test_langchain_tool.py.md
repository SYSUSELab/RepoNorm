# Rules for `tests/utils/test_langchain_tool.py`

## Rule 067 — `tests/utils/test_langchain_tool.py`

- **Rule:**
  ```text
  The langchain tool test must define a @tool get_age taking a Pydantic Profile model and returning profile.age, exercising conversion of tools whose arguments are Pydantic models.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:** when modifying the langchain tool test or its Pydantic-model argument fixture
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5d9b5584aa257cb621b20d36.md)

## Rule 170 — `tests/utils/test_langchain_tool.py`

- **Rule:**
  ```text
  convert_langchain_tool must preserve the tool name and description, generate a JSON schema for nested pydantic args, map arg_types to the pydantic class, and default arg_desc to 'No description provided. (Required)' when absent.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:**
  ```text
  When modifying langchain tool conversion tests or the convert_langchain_tool behavior they exercise, including name/description preservation, nested pydantic schema generation, arg_types mapping, and arg_desc defaulting.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-cf660abecd6e363a3bb1ae99.md)

## Rule 172 — `tests/utils/test_langchain_tool.py`

- **Rule:**
  ```text
  Test modules that depend on optional third-party packages must skip at module level using `importlib.util.find_spec` and `pytest.skip(..., allow_module_level=True)` when the dependency is absent, rather than failing at import time.
  ```
- **Applies to:**
  - `tests/utils/test_langchain_tool.py`
- **Condition:**
  ```text
  when adding or modifying test modules that import optional third-party dependencies such as langchain_core
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d233c57a3d3b2aa27d19a1e5.md)
