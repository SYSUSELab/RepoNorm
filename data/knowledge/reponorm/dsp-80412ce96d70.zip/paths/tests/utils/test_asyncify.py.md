# Rules for `tests/utils/test_asyncify.py`

## Rule 075 — `tests/utils/test_asyncify.py`

- **Rule:**
  ```text
  test_asyncify must use the anyio pytest marker and await verify_asyncify with varying concurrency/iteration parameters (4/10, 8/15, 8/30), asserting asyncify behaves correctly under different concurrency levels.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:**
  ```text
  when modifying test_asyncify or the asyncify concurrency test parameters
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-6f40fd0238d0f9095c685097.md)

## Rule 180 — `tests/utils/test_asyncify.py`

- **Rule:**
  ```text
  The async limiter must remain a singleton whose default total_tokens is 8, and dspy.context(async_max_workers=16) must override the same singleton instance to report total_tokens 16; do not replace the singleton with per-context instances or change the default capacity.
  ```
- **Applies to:**
  - `tests/utils/test_asyncify.py`
- **Condition:** when modifying the async limiter singleton or its context-driven capacity override
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-d9605a3d7f7931f68be00d80.md)
