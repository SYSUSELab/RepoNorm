# Rules for `tests/utils/test_syncify.py`

## Rule 005 — `tests/utils/test_syncify.py`

- **Rule:** Syncify tests must define their program as a dspy.Module subclass; do not use a non-Module program shape in these tests.
- **Applies to:**
  - `tests/utils/test_syncify.py`
- **Condition:** when adding or modifying a syncify test program
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-05158a96597c9bb5dcf8de8a.md)
