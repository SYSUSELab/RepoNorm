# Rules for `tests/utils/test_unbatchify.py`

## Rule 106 — `tests/utils/test_unbatchify.py`

- **Rule:**
  ```text
  The unbatchify test helper simple_batch_processor must return [item + 1 for item in batch], establishing the expected batch-processing shape used by unbatchify tests.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** When modifying unbatchify tests or the batch-processing helper shape they exercise.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-92416b843e9e3bee581a2378.md)

## Rule 132 — `tests/utils/test_unbatchify.py`

- **Rule:**
  ```text
  The unbatchify submit method enqueues an (input_item, future) tuple onto input_queue and returns the Future, defining the producer-side contract that callers await for results.
  ```
- **Applies to:**
  - `tests/utils/test_unbatchify.py`
- **Condition:** when modifying the unbatchify submit method or tests that pin its queue/future contract
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-acab880450faaf6162874fe2.md)
