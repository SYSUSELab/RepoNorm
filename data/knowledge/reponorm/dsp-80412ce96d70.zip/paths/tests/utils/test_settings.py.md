# Rules for `tests/utils/test_settings.py`

## Rule 070 — `tests/utils/test_settings.py`

- **Rule:** dspy.configure must not be called from a different async task than the initial one; calling it from a sync function invoked by an async task must raise RuntimeError with the message 'dspy.settings.configure(...) can only be called from the same async'.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that exercises dspy.configure across async task boundaries
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-66ddcbe2e89dc225b02ec5fc.md)

## Rule 112 — `tests/utils/test_settings.py`

- **Rule:** dspy.configure called inside an async coroutine directly invoked by the entry task applies to that same async task, illustrating task-local settings propagation.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when modifying async task-local dspy settings propagation or the foo4 coroutine
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-97ec065eabf4e001a8a6b151.md)

## Rule 122 — `tests/utils/test_settings.py`

- **Rule:** dspy.configure must not be called from a child thread; tests must configure dspy in the main thread and assert that a ThreadPoolExecutor worker calling dspy.configure raises.
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:** when adding or modifying a test that exercises dspy.configure from a non-main thread
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9f8416215f690a8f6575c092.md)

## Rule 214 — `tests/utils/test_settings.py`

- **Rule:**
  ```text
  test_dspy_configure_allowance_async must assert that dspy.configure may be called multiple times within the same async task, including setting lm and adapter, and that concurrent async tasks can run under that configuration.
  ```
- **Applies to:**
  - `tests/utils/test_settings.py`
- **Condition:**
  ```text
  when modifying test_dspy_configure_allowance_async or the async dspy.configure allowance behavior
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-fed5673d22e3d212c41892d3.md)
