# Rules for `tests/utils/test_exceptions.py`

## Rule 096 — `tests/utils/test_exceptions.py`

- **Rule:** AdapterParseError's string form must follow a fixed template including the adapter name, raw LM response, and the list of expected output fields; changes to that message format are compatibility-relevant.
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:** When modifying AdapterParseError's string representation or its expected message template
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-85fb3bd08244afbc2c70d6b0.md)

## Rule 198 — `tests/utils/test_exceptions.py`

- **Rule:** AdapterParseError's string form must include the adapter name, raw LM response, expected output fields, and actually parsed output fields, making the message format a stable contract for parse-failure diagnostics.
- **Applies to:**
  - `tests/utils/test_exceptions.py`
- **Condition:** When modifying AdapterParseError message formatting or its diagnostic fields.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-efc55390f16f1fd9963fab68.md)
