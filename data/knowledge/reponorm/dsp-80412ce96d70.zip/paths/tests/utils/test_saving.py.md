# Rules for `tests/utils/test_saving.py`

## Rule 130 — `tests/utils/test_saving.py`

- **Rule:**
  ```text
  Compiled Predict programs saved with save_program=True and reloaded via dspy.load must preserve both demos and signature; do not change save/load behavior in a way that drops either.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:**
  ```text
  when modifying save_program or dspy.load behavior for compiled Predict programs
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-a9e309d6c83cfe72704b21dc.md)

## Rule 147 — `tests/utils/test_saving.py`

- **Rule:**
  ```text
  The saving test fixture must compose two ChainOfThought modules in sequence (question->refined_question then refined_question->answer) to exercise save/load of multi-module programs.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** When modifying save/load tests or the multi-module program fixtures they exercise.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-bc4947509ac915c5b1db9b43.md)

## Rule 203 — `tests/utils/test_saving.py`

- **Rule:**
  ```text
  Save/load version-mismatch tests must patch get_dependency_versions separately in dspy.primitives.base_module (save path) and dspy.utils.saving (load path), assert exactly three mismatch warnings are logged, and verify the model still loads with an equal signature despite mismatched python/dspy/cloudpickle versions.
  ```
- **Applies to:**
  - `tests/utils/test_saving.py`
- **Condition:** When modifying save/load version-mismatch tests or the dependency-version warning behavior they exercise across the save and load modules.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f4fbca6c43fa5ed202828bea.md)
