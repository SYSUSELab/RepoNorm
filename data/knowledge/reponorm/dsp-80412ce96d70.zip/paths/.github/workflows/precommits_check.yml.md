# Rules for `.github/workflows/precommits_check.yml`

## Rule 022 — `.github/workflows/precommits_check.yml`

- **Rule:** The Pre-Commit Checks step installs and upgrades pip, installs pre-commit, and runs pre-commit run -v --files on the changed files.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1b41255bb4dd39857d12fcf7.md)

## Rule 093 — `.github/workflows/precommits_check.yml`

- **Rule:** The workflow obtains the list of changed files using the jitterbit/get-changed-files action with step id files.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-850a668db6577ebb3778648f.md)

## Rule 162 — `.github/workflows/precommits_check.yml`

- **Rule:** The workflow sets up Python version 3.10 with pip caching.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-c982f8e33a1b44c3f9a9ccd0.md)

## Rule 169 — `.github/workflows/precommits_check.yml`

- **Rule:** Pull request titles are checked against a regexp requiring a conventional-commit-style type prefix followed by a scope in parentheses, a colon, a space, and a description.
- **Applies to:**
  - `.github/workflows/precommits_check.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ce5347d1bf8f8c1241f4c4c0.md)
