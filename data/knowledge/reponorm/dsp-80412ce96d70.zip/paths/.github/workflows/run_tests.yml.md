# Rules for `.github/workflows/run_tests.yml`

## Rule 010 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job creates a virtual environment at .venv and adds its bin directory to GITHUB_PATH.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-08fb4034a533c871dcbe7a0a.md)

## Rule 038 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job installs dependencies with uv sync --dev -p .venv --extra dev.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-328ca82a6f995f93b34557e8.md)

## Rule 103 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job builds the package with uv run -p .venv python -m build.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-8b2efa18dac198fc51051160.md)

## Rule 141 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job installs uv with caching enabled, keyed on **/pyproject.toml and **/uv.lock.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-b7848721605a30eeff7c8fa4.md)

## Rule 181 — `.github/workflows/run_tests.yml`

- **Rule:**
  ```text
  The build_package job installs the built wheel from dist/*.whl into the .venv environment.
  ```
- **Applies to:**
  - `.github/workflows/run_tests.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dcf7455e352a370de08a6329.md)
