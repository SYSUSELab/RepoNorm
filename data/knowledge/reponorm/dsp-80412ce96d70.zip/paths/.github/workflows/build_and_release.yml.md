# Rules for `.github/workflows/build_and_release.yml`

## Rule 020 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-16895e9fe3290a4e8ed80fd2.md)

## Rule 063 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job installs setuptools, wheel, twine, build, semver, and packaging via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-53f70e4cd066c7182d219c28.md)

## Rule 072 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The build-and-publish-test-pypi job creates a virtual environment named test_before_testpypi.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-692500dae9eeab8a7cd11423.md)

## Rule 092 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-pypi job sets up Python 3.11 via actions/setup-python@v3.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-84e319b9540293f6365062b1.md)

## Rule 115 — `.github/workflows/build_and_release.yml`

- **Rule:**
  ```text
  The build-and-publish-test-pypi job determines the TestPyPI version by running .github/workflows/build_utils/test_version.py with package name dspy-ai-test and the extracted tag version.
  ```
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-9958e5275bfe527484f4c844.md)

## Rule 182 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-test-pypi job publishes the distribution to test-PyPI using pypa/gh-action-pypi-publish@release/v1 with repository-url https://test.pypi.org/legacy/.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dfaf9b3364c626751a5a05b7.md)

## Rule 197 — `.github/workflows/build_and_release.yml`

- **Rule:** The build-and-publish-pypi job installs setuptools, wheel, twine, and build via pip.
- **Applies to:**
  - `.github/workflows/build_and_release.yml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-ee2005a1fc19dab4fb5194da.md)
