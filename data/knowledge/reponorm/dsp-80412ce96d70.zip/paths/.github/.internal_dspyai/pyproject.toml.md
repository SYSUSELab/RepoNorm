# Rules for `.github/.internal_dspyai/pyproject.toml`

## Rule 024 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the package name in .github/.internal_dspyai/pyproject.toml to dspy-ai using a sed command keyed on the #replace_package_name_marker comment.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-1fa287ecfc82304ce54cb6c7.md)

## Rule 042 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the version in .github/.internal_dspyai/pyproject.toml to the extracted tag version using a sed command keyed on the #replace_package_version_marker comment.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-38cc692412638bc80cbc51f6.md)

## Rule 060 — `.github/.internal_dspyai/pyproject.toml`

- **Rule:**
  ```text
  For the dspy-ai release, the workflow rewrites the dspy dependency in .github/.internal_dspyai/pyproject.toml to the extracted tag version using a sed command keyed on the #replace_dspy_version_marker comment.
  ```
- **Applies to:**
  - `.github/.internal_dspyai/pyproject.toml`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-5163f45807be350de525d205.md)
