# Rules for `tests`

## Rule 105 — `tests/**/*.py`

- **Rule:**
  ```text
  Ruff per-file ignores for tests/**/*.py disable S101, TID252, and ARG001, allowing assert statements, relative imports, and unused arguments in test files.
  ```
- **Applies to:**
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9183669098b3302c3ee3a1c2.md)

## Rule 114 — `tests/**`

- **Rule:**
  ```text
  The llm_call_test job runs pytest with -m llm_call --llm_call -vv --durations=5 over the tests/ directory.
  ```
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-98a3ca35d9ca7ed7a99790b2.md)

## Rule 161 — `dspy/**/*.py`

- **Rule:**
  ```text
  Ruff linting/formatting applies to Python files under dspy/ and tests/ as configured by include = ["dspy/**/*.py", "tests/**/*.py"].
  ```
- **Applies to:**
  - `dspy/**/*.py`
  - `tests/**/*.py`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-c96220426b095b5c3f51a757.md)

## Rule 206 — `tests/**`

- **Rule:** The test job runs pytest over the tests/ directory via uv run -p .venv pytest -vv tests/.
- **Applies to:**
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-f986978ee8efc5002153cf9c.md)
