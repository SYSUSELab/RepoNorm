# Rules for `docs`

## Rule 178 — `docs/**`

- **Rule:** The update-docs-subtree job runs only on push events to the stanfordnlp/dspy repository and pushes the docs directory to the dspy-docs repository's master branch.
- **Applies to:**
  - `docs/**`
- **Condition:**
  ```text
  workflow predicate: github.event_name == 'push' && github.repository == 'stanfordnlp/dspy'
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d91ed001e982b3a322d404e4.md)
