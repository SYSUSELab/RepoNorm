# Rules for `primitives`

## Rule 175 — `primitives/*.js`

- **Rule:**
  ```text
  The dspy package includes JavaScript files matching primitives/*.js as package data.
  ```
- **Applies to:**
  - `primitives/*.js`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-d7a3e788e0e61807a543a8fe.md)
