# Rules for `docs/conf.py`

## Rule 143 — `docs/conf.py`

- **Rule:**
  ```text
  Sphinx documentation builds must be configured through docs/conf.py, which sets autodoc_member_order='bysource', autodoc_typehints='description', autodoc_preserve_defaults=True, extlinks for issue/pr references, intersphinx to Python docs, and the click HTML theme; changes to documentation build behavior must preserve or deliberately update these settings.
  ```
- **Applies to:**
  - `docs/conf.py`
- **Condition:** When modifying the Sphinx documentation build configuration in docs/conf.py, including autodoc ordering, typehint rendering, default preservation, external link roles, intersphinx mappings, or the HTML theme.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e2680efe734f2a64a8fef620.md)
