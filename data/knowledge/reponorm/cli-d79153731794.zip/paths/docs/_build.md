# Rules for `docs/_build`

## Rule 136 — `docs/_build/**`

- **Rule:**
  ```text
  The flit sdist build excludes docs/_build/ from the source distribution.
  ```
- **Applies to:**
  - `docs/_build/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-cebafb991183ec8e3efc4110.md)
