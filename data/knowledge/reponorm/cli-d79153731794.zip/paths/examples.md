# Rules for `examples`

## Rule 107 — `examples/**`

- **Rule:** Ruff excludes the examples/ directory from linting via extend-exclude.
- **Applies to:**
  - `examples/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-ac8f67bed5db1ab64f6db0e4.md)
