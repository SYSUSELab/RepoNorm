# Rules for `click`

## Rule 089 — `click/**`

- **Rule:** Coverage measurement is configured to source from the click and tests packages.
- **Applies to:**
  - `click/**`
  - `tests/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../claims/CLAIM-9aeaa14caa63bc7d00c05067.md)
