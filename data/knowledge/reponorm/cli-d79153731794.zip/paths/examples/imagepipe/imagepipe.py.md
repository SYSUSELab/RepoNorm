# Rules for `examples/imagepipe/imagepipe.py`

## Rule 018 — `examples/imagepipe/imagepipe.py`

- **Rule:** Imagepipe processor commands must be implemented as generator functions decorated with @processor that yield transformed images, so the pipeline can stream results and echo progress.
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When adding or modifying an imagepipe subcommand that transforms images.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-19364f0289f93bfcde4bf129.md)

## Rule 139 — `examples/imagepipe/imagepipe.py`

- **Rule:**
  ```text
  The example demonstrates a command with a show_default option and a processor decorator that yields processed images, showing the supported image processing pipeline pattern.
  ```
- **Applies to:**
  - `examples/imagepipe/imagepipe.py`
- **Condition:** When modifying or adding commands with processor decorators in the imagepipe example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-dc4a849e05cbff2eff95ebbb.md)
