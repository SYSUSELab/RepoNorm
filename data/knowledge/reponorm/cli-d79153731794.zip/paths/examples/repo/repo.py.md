# Rules for `examples/repo/repo.py`

## Rule 150 — `examples/repo/repo.py`

- **Rule:** The repo example's state object initializes home, an empty config dict, and verbose=False, establishing the default configuration shape used by the example.
- **Applies to:**
  - `examples/repo/repo.py`
- **Condition:** When modifying or adding state initialization in the repo example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-f62e03069b3597863f6c19d7.md)
