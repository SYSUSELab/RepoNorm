# Rules for `examples/complex/complex/cli.py`

## Rule 005 — `examples/complex/complex/cli.py`

- **Rule:** The complex example's vlog method must log to stderr only when verbose is enabled, preserving the conditional logging pattern.
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying the vlog method or verbose logging behavior in the complex example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-06517565780ec21f5dc13ed9.md)

## Rule 036 — `examples/complex/complex/cli.py`

- **Rule:** examples/complex/complex/cli.py defines an Environment class, part of the complex example's structure.
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When modifying or adding environment classes in the complex example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-3a4c3665298c0ab9334ba7ab.md)

## Rule 067 — `examples/complex/complex/cli.py`

- **Rule:**
  ```text
  Subcommands in the complex example are discovered dynamically: list_commands scans the cmd_folder for files named cmd_*.py, strips the cmd_ prefix and .py suffix, and sorts the names; get_command then imports complex.commands.cmd_{name} and returns its cli attribute, silently returning None on ImportError. New subcommands must therefore be added as cmd_<name>.py modules exposing a cli attribute rather than registered statically.
  ```
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** When adding or renaming a subcommand in the complex example, or changing how its command modules are discovered or loaded.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-694821764909ce0c2dad27e0.md)

## Rule 117 — `examples/complex/complex/cli.py`

- **Rule:** Example CLI context initialization must set default state values such as verbose to False and home to os.getcwd(), establishing the default context state used by the example.
- **Applies to:**
  - `examples/complex/complex/cli.py`
- **Condition:** when adding or modifying the CLI context initialization in the complex example
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../../claims/CLAIM-bcd96def3d19788305000d23.md)
