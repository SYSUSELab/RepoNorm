# Rules for `examples/termui/termui.py`

## Rule 110 — `examples/termui/termui.py`

- **Rule:** The termui example must remain a standalone demo script that imports math, random, time, and click, preserving these runtime dependencies.
- **Applies to:**
  - `examples/termui/termui.py`
- **Condition:** When modifying imports or runtime dependencies of the termui example.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-afe018134cdb3abb56add0a3.md)
