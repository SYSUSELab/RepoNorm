# Rules for `tests/test_normalization.py`

## Rule 094 — `tests/test_normalization.py`

- **Rule:**
  ```text
  Normalization tests must preserve the convention that CONTEXT_SETTINGS uses token_normalize_func=lambda x: x.lower(), establishing lowercase token normalization as the tested convention.
  ```
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:** When modifying token normalization tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-9c5e243fcd27c4912ad43a3a.md)

## Rule 097 — `tests/test_normalization.py`

- **Rule:** Tests that assert CLI option-name normalization must verify that uppercase long options and short options are accepted case-insensitively while the echoed values remain unchanged.
- **Applies to:**
  - `tests/test_normalization.py`
- **Condition:**
  ```text
  When adding or modifying option-normalization tests in tests/test_normalization.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a0cdb589a7168598a613000f.md)
