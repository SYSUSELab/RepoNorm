# Rules for `tests/test_parser.py`

## Rule 051 — `tests/test_parser.py`

- **Rule:**
  ```text
  Option prefixes are collected dynamically: adding options with '+p' and '!e' expands _opt_prefixes to include '-', '--', '+', and '!'.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:** When modifying option prefix collection logic or adding tests for dynamic prefix expansion.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-49318b7e2d838cb311936aac.md)

## Rule 098 — `tests/test_parser.py`

- **Rule:**
  ```text
  split_arg_string must tolerate unbalanced quotes and trailing backslashes, yielding the documented token lists (e.g. "cli 'my file" -> ["cli","my file"], "cli my\\" -> ["cli","my"], "cli my\\ file" -> ["cli","my file"]); tests must preserve these exact outputs.
  ```
- **Applies to:**
  - `tests/test_parser.py`
- **Condition:**
  ```text
  Modifying or adding tests for split_arg_string's handling of malformed quoting or trailing backslashes.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-a1817483a8fa11a820bbc1c2.md)
