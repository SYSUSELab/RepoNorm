# Rules for `tests/test_info_dict.py`

## Rule 011 — `tests/test_info_dict.py`

- **Rule:**
  ```text
  Tests that pin Click's public parameter/option introspection contract must keep the exact to_info_dict field set and values for each parameter kind (STRING/INT/BOOL, help option, name argument, number option, command, group), including group-only fields commands and chain.
  ```
- **Applies to:**
  - `tests/test_info_dict.py`
- **Condition:**
  ```text
  When modifying or extending the expected to_info_dict structures in the info-dict contract test.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1126906c942ed89f50f7d7af.md)
