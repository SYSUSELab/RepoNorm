# Rules for `tests/test_shell_completion.py`

## Rule 020 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Shell completion tests must use a _get_words helper that maps _get_completions results to their .value strings for assertions.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:** Modifying or adding shell completion tests that assert completion values.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-19c86316c3b175ebc72c143c.md)

## Rule 115 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Tests that exercise shell-completion behavior must isolate the global `click.shell_completion._available_shells` state by snapshotting it before the test and restoring the previous contents afterward.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying a test that reads or mutates shell-completion state in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b6e507d6349bbfcd5dadec33.md)

## Rule 127 — `tests/test_shell_completion.py`

- **Rule:**
  ```text
  Tests that assert shell-completion type mapping must verify that `File()` and `Path()` map to completion type 'file' while `Path(file_okay=False)` maps to 'dir'.
  ```
- **Applies to:**
  - `tests/test_shell_completion.py`
- **Condition:**
  ```text
  When adding or modifying shell-completion type-mapping tests in tests/test_shell_completion.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-c50aff1e527b48eab2f05269.md)
