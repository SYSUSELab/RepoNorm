# Rules for `tests/typing/typing_aliased_group.py`

## Rule 044 — `tests/typing/typing_aliased_group.py`

- **Rule:** Typing tests for aliased groups must preserve the convention that the cli object is an AliasedGroup subclass of click.Group, tying the documented command-aliases example to the AliasedGroup type contract.
- **Applies to:**
  - `tests/typing/typing_aliased_group.py`
- **Condition:** When modifying typing tests for aliased groups.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../../claims/CLAIM-40d7f33cda41b4555684be80.md)
