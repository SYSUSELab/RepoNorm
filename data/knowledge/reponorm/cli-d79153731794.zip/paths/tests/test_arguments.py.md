# Rules for `tests/test_arguments.py`

## Rule 004 — `tests/test_arguments.py`

- **Rule:** Tests for CLI decorator composition must preserve the convention that a group command can combine click.argument('arg2') and click.option('--opt2') on the same callback.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying tests that compose group, argument, and option decorators on one callback.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-044d4b6d08edeb272eaa376a.md)

## Rule 046 — `tests/test_arguments.py`

- **Rule:**
  ```text
  Tests that assert unbounded `nargs=-1` arguments must verify that supplying a default raises `TypeError` matching 'nargs=-1'.
  ```
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:**
  ```text
  When adding or modifying argument-validation tests in tests/test_arguments.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-43198279193c122547207733.md)

## Rule 056 — `tests/test_arguments.py`

- **Rule:** Tests covering envvar population of variadic arguments must preserve the convention that nargs=-1 accepts any count of envvar-split values while a fixed nargs (e.g. nargs=2) raises BadParameter when the value count differs.
- **Applies to:**
  - `tests/test_arguments.py`
- **Condition:** When modifying envvar handling tests for variadic or fixed-nargs arguments.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-53ef2debcc52aaedb8ed88d8.md)
