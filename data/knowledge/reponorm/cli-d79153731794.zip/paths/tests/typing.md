# Rules for `tests/typing`

## Rule 053 — `src/click/**`

- **Rule:** mypy is configured to check the files under src/click and tests/typing.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-50a30bf391a7e1f55b47a4b9.md)

## Rule 073 — `src/click/**`

- **Rule:** Pyright type checking is scoped to the src/click and tests/typing directories.
- **Applies to:**
  - `src/click/**`
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7bb17a22481594b0c5dcc52c.md)

## Rule 075 — `tests/typing/**`

- **Rule:** The typing tox environment runs pyright on tests/typing.
- **Applies to:**
  - `tests/typing/**`
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-7d162940f9e14224e5a7954f.md)
