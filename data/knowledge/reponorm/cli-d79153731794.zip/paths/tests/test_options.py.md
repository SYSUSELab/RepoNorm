# Rules for `tests/test_options.py`

## Rule 007 — `tests/test_options.py`

- **Rule:**
  ```text
  Tests that assert duplicate option-name detection must invoke the CLI and expect a `UserWarning`, covering both duplicate short names and duplicate long names.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying duplicate option-name detection tests in tests/test_options.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-0d396bf4da64442a8797836e.md)

## Rule 013 — `tests/test_options.py`

- **Rule:**
  ```text
  Tests for flag_value typing must preserve the convention that an Option with flag_value infers click.INT regardless of whether a default is also supplied.
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When modifying flag_value type-inference tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-1328422207e30d4f3548a151.md)

## Rule 038 — `tests/test_options.py`

- **Rule:**
  ```text
  Tests for option default validation must preserve the convention that constructing click.Option with an invalid default for the given multiple/nargs combination raises ValueError matching 'default', covering (False,2,[1]) and (True,2,[[1]]).
  ```
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying option default validation tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3b8c270227634f4f93b09755.md)

## Rule 086 — `tests/test_options.py`

- **Rule:** Tests that assert dynamic-default help output must verify that an unset dynamic default renders as '(dynamic)' without leaking the lambda source text, while still listing the option name.
- **Applies to:**
  - `tests/test_options.py`
- **Condition:**
  ```text
  When adding or modifying dynamic-default help tests in tests/test_options.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-92cd2c926c8790235d4f0a37.md)

## Rule 112 — `tests/test_options.py`

- **Rule:** Tests for option naming must preserve the convention that Click accepts multi-character single-dash option names such as "-whatever".
- **Applies to:**
  - `tests/test_options.py`
- **Condition:** When modifying option-naming tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-b4d37864e51f0ed1c1b4e35c.md)
