# Rules for `tests/test_termui.py`

## Rule 041 — `tests/test_termui.py`

- **Rule:**
  ```text
  Tests that assert progressbar ETA formatting must pin outputs including large values rendered as "1157407d 09:46:39" and `None` rendered as an empty string.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When adding or modifying progressbar ETA formatting tests in tests/test_termui.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-3e27d5b7f4ae3a47d6301a96.md)

## Rule 068 — `tests/test_termui.py`

- **Rule:**
  ```text
  Tests that assert `ProgressBar.time_per_iteration` must verify that an empty average list returns 0.0 and [1, 4] returns 2.5, defining the averaging behavior for iteration timing.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When adding or modifying `ProgressBar.time_per_iteration` tests in tests/test_termui.py
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-6caf35c74823e199473feead.md)

## Rule 148 — `tests/test_termui.py`

- **Rule:**
  ```text
  Tests for confirmed hidden input must preserve the convention that a password option combines prompt, hide_input=True, default, and confirmation_prompt.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:** When modifying tests for confirmed hidden input options.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-ed5145baea9e817a4400e4a7.md)

## Rule 149 — `tests/test_termui.py`

- **Rule:**
  ```text
  Tests for prompt_required=False must preserve the convention that a flag without a value prompts while a flag with a value does not, and the next option flag is not consumed as the value.
  ```
- **Applies to:**
  - `tests/test_termui.py`
- **Condition:**
  ```text
  When modifying prompt_required=False parametrized tests.
  ```
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-f1d38b12266a6cc75a866326.md)
