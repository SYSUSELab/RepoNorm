# Rules for `tests/test_testing.py`

## Rule 146 — `tests/test_testing.py`

- **Rule:** Tests for CliRunner.invoke with input must preserve the convention that provided input is echoed back in result.output without raising an exception.
- **Applies to:**
  - `tests/test_testing.py`
- **Condition:** When modifying CliRunner input-echo tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-e5052f59e756a39f33bbda2b.md)
