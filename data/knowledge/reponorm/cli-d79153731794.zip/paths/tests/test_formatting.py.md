# Rules for `tests/test_formatting.py`

## Rule 002 — `tests/test_formatting.py`

- **Rule:** Tests for usage-error formatting must preserve the convention that a missing required argument produces exit code 2 and a four-line usage/error output including a blank line before the Error line.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When modifying usage-error formatting tests.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-022c1a552ce02c81588d1173.md)

## Rule 054 — `tests/test_formatting.py`

- **Rule:** Tests that exercise a metavar override on a positional argument must define the argument with metavar="metavar" and assert the supported override.
- **Applies to:**
  - `tests/test_formatting.py`
- **Condition:** When adding or modifying tests for metavar override on a positional argument, preserve the use of metavar="metavar" and the assertion of the supported override.
- **Normative strength:** `observed`
- **Detail:** [Open claim details](../../claims/CLAIM-536a723aadfdcb51b0daf585.md)
